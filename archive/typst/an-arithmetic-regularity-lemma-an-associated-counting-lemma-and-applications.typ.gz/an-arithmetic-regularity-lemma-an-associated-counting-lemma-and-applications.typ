// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/
// Converted to Typst by tao2typ: "2026-10-14T08:54:38.341512+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An arithmetic regularity lemma, an associated counting lemma, and applications", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An arithmetic regularity lemma, an associated counting lemma, and applications")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")[#text("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/1002.2028")[#text("An arithmetic regularity lemma, an associated counting lemma, and applications")]#text("“, submitted (a little behind schedule) to the 70th birthday conference proceedings for Endre Szemerédi. In this paper we describe the general-degree version of the ")#emph[#text("arithmetic regularity lemma")]#text(", which can be viewed as the counterpart of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", in which the object being regularised is a function ")#mi("{f: [N] \\rightarrow [0,1]}")#text(" on a discrete interval ")#mi("{[N] = \\{1,\\ldots,N\\}}")#text(" rather than a graph, and the type of patterns one wishes to count are additive patterns (such as arithmetic progressions ")#mi("{n,n+d,\\ldots,n+(k-1)d}")#text(") rather than subgraphs. Very roughly speaking, this regularity lemma asserts that all such functions can be decomposed as a degree ")#mi("{\\leq s}")#text(" nilsequence (or more precisely, a variant of a nilsequence that we call an ")#emph[#text("virtual irrational nilsequence")]#text("), plus a small error, plus a third error which is extremely tiny in the Gowers uniformity norm ")#mi("{U^{s+1}[N]}")#text(". In principle, at least, the latter two errors can be readily discarded in applications, so that the regularity lemma reduces many questions in additive combinatorics to questions concerning (virtual irrational) nilsequences. To work with these nilsequences, we also establish a ")#emph[#text("arithmetic counting lemma")]#text(" that gives an integral formula for counting additive patterns weighted by such nilsequences.")

#text("The regularity lemma is a manifestation of the “dichotomy between structure and randomness”, as discussed for instance in my ")#link("http://front.math.ucdavis.edu/math.NT/0512114")[#text("ICM article")]#text(" or ")#link("https://terrytao.wordpress.com/2007/07/31/structure-and-randomness-in-combinatorics/")[#text("FOCS article")]#text(". In the degree ")#mi("{1}")#text(" case ")#mi("{s=1}")#text(", this result is essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("due to Green")]#text(". It is powered by the ")#emph[#text("inverse conjecture for the Gowers norms")]#text(", which we and Tamar Ziegler have recently established (paper to be forthcoming shortly; the ")#mi("{k=4}")#text(" case of our argument is ")#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/")[#text("discussed here")]#text("). The counting lemma is established through the quantitative equidistribution theory of nilmanifolds, which Ben and I set out ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("in this paper")]#text(".")

#text("The regularity and counting lemmas are designed to be used together, and in the paper we give three applications of this combination. Firstly, we give a new proof of Szemerédi’s theorem, which proceeds via an energy increment argument rather than a density increment one. Secondly, we establish a conjecture of ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson, Host, and Kra")]#text(", namely that if ")#mi("{A \\subset [N]}")#text(" has density ")#mi("{\\alpha}")#text(", and ")#mi("{\\epsilon > 0}")#text(", then there exist ")#mi("{\\gg_{\\alpha,\\epsilon} N}")#text(" shifts ")#mi("{h}")#text(" for which ")#mi("{A}")#text(" contains at least ")#mi("{(\\alpha^4 - \\epsilon)N}")#text(" arithmetic progressions of length ")#mi("{k=4}")#text(" of spacing ")#mi("{h}")#text(". (The ")#mi("{k=3}")#text(" case of this conjecture was established earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=2153903")[#text("by Green")]#text("; the ")#mi("{k=5}")#text(" case is false, as was shown by Ruzsa in an appendix to the ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson-Host-Kra paper")]#text(".) Thirdly, we establish a variant of a recent result of Gowers-Wolf, showing that the true complexity of a system of linear forms over ")#mi("{[N]}")#text(" indeed matches the conjectured value predicted in ")#link("http://arxiv.org/abs/0711.0185")[#text("their first paper")]#text(".")

#text("In all three applications, the scheme of proof can be described as follows:")

#list(
[#text("Apply the arithmetic regularity lemma, and decompose a relevant function ")#mi("{f}")#text(" into three pieces, ")#mi("{f_{nil}, f_{sml}, f_{unf}}")#text(".")],
[#text("The uniform part ")#mi("{f_{unf}}")#text(" is so tiny in the Gowers uniformity norm that its contribution can be easily dealt with by an appropriate “generalised von Neumann theorem”.")],
[#text("The contribution of the (virtual, irrational) nilsequence ")#mi("{f_{nil}}")#text(" can be controlled using the arithmetic counting lemma.")],
[#text("Finally, one needs to check that the contribution of the small error ")#mi("{f_{sml}}")#text(" does not overwhelm the main term ")#mi("{f_{nil}}")#text(". This is the trickiest bit; one often needs to use the counting lemma again to show that one can find a set of arithmetic patterns for ")#mi("{f_{nil}}")#text(" that is so sufficiently “equidistributed” that it is not impacted by the small error.")]
)

#text("To illustrate the last point, let us give the following example. Suppose we have a set ")#mi("{A \\subset [N]}")#text(" of some positive density (say ")#tao-math("{\\left|A\\right| = 10^{-1} N}", block: false)#text(") and we have managed to prove that ")#mi("{A}")#text(" contains a reasonable number of arithmetic progressions of length ")#mi("{5}")#text(" (say), e.g. it contains at least ")#mi("{10^{-10} N^2}")#text(" such progressions. Now we perturb ")#mi("{A}")#text(" by deleting a small number, say ")#mi("{10^{-2} N}")#text(", elements from ")#mi("{A}")#text(" to create a new set ")#mi("{A^{\\prime}}")#text(". Can we still conclude that the new set ")#mi("{A^{\\prime}}")#text(" contains any arithmetic progressions of length ")#mi("{5}")#text("?")

#text("Unfortunately, the answer could be no; conceivably, all of the ")#mi("{10^{-10} N^2}")#text(" arithmetic progressions in ")#mi("{A}")#text(" could be wiped out by the ")#mi("{10^{-2} N}")#text(" elements removed from ")#mi("{A}")#text(", since each such element of ")#mi("{A}")#text(" could be associated with up to ")#tao-math("{\\left|A\\right|}", block: false)#text(" (or even ")#tao-math("{5\\left|A\\right|}", block: false)#text(") arithmetic progressions in ")#mi("{A}")#text(".")

#text("But suppose we knew that the ")#mi("{10^{-10} N^2}")#text(" arithmetic progressions in ")#mi("{A}")#text(" were ")#emph[#text("equidistributed")]#text(", in the sense that each element in ")#mi("{A}")#text(" belonged to the same number of such arithmetic progressions, namely ")#mi("{5 \\times 10^{-9} N}")#text(". Then each element deleted from ")#mi("{A}")#text(" only removes at most ")#mi("{5 \\times 10^{-9} N}")#text(" progressions, and so one can safely remove ")#mi("{10^{-2} N}")#text(" elements from ")#mi("{A}")#text(" and still retain some arithmetic progressions. The same argument works if the arithmetic progressions are only ")#emph[#text("approximately")]#text(" equidistributed, in the sense that the number of progressions that a given element ")#mi("{a \\in A}")#text(" belongs to concentrates sharply around its mean (for instance, by having a small variance), provided that the equidistribution is sufficiently strong. Fortunately, the arithmetic regularity and counting lemmas are designed to give precisely such a strong equidistribution result.")

#text("A succinct (but slightly inaccurate) summation of the regularity+counting lemma strategy would be that in order to solve a problem in additive combinatorics, it “suffices to check it for nilsequences”. But this should come with a caveat, due to the issue of the small error above; in addition to checking it for nilsequences, the answer in the nilsequence case must be sufficiently “dispersed” in a suitable sense, so that it can survive the addition of a small (but not completely negligible) perturbation.")

#text("One last “production note”. Like our ")#link("https://terrytao.wordpress.com/2010/01/27/linear-approximate-groups/")[#text("previous paper with Emmanuel Breuillard")]#text(", we used ")#link("http://en.wikipedia.org/wiki/Subversion_(software)")[#text("Subversion")]#text(" to write this paper, which turned out to be a significant efficiency boost as we could work on different parts of the paper simultaneously (this was particularly important this time round as the paper was somewhat lengthy and complicated, and there was a submission deadline). When doing so, we found it convenient to split the paper into a dozen or so pieces (one for each section of the paper, basically) in order to avoid conflicts, and to help coordinate the writing process. I’m also looking into ")#link("http://en.wikipedia.org/wiki/Git_(software)")[#text("git")]#text(" (a more advanced version control system), and am planning to use it for another of my joint projects; I hope to be able to comment on the relative strengths of these systems (and with plain old email) in the future.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-43615")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Two questions. The first (based on not having thought about the problem at all, so there is probably a fairly simple answer) is whether it is easy to explain why the arithmetic regularity approach to the conjecture of Bergelson, Host and Kra works up to k=4 and fails at k=5. Of course, you can say that there is a counterexample for k=5 but then it makes it mysterious that the proof works for k=4. There must be something special about the k=4 case that you have to add in as an extra ingredient and I’m curious to know what that is.")

#text("My second question is whether there is any mileage in a trick that Julia Wolf and I used in our paper, which we needed in order to deal with a problem rather similar to the one you mention about the contribution from the small part of f in your decomposition. We had a similar difficulty, but our method of dealing with it was to decompose the function f in several ways. To take your example of APs of length 5, the idea would be to start by decomposing f into structured + small + uniform and argue that we could replace the first occurrence of f in the AP-counting expression by just the structured part, at the cost of only a small error. Then we would decompose the second occurrence of f with different parameters, in our case because the first structured part of f did not have to be bounded with the same bound as the original f, but was still bounded independently of n. And so on. In that way we ended up just having to consider the structured parts, but these were different for different occurrences of f. (We didn’t apply this idea to APs of length 5, but I’m using this example so as to relate it to your discussion above.)")

#text("A lot depends on precise error dependences, so it may well be that this doesn’t work in your context, but I thought I’d ask just in case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-43618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Dear Tim,")

#text("With regards to the first question, my take on it is that there is a residual “positive definite” structure to AP4’s that don’t show up in AP5’s or higher. Consider for instance the problem of counting the expression ")#mi("{\\Bbb E}_{n,d} f(n) f(n+d) f(n+2d) f(n+3d)")#text(" when f takes the quadratically quasiperiodic form")

#mi("f = F( \\theta n^2 \\text{ mod } 1)")

#text("for some irrational ")#mi("\\theta")#text(" and some smooth (or at least Lipschitz) ")#mi("F: {\\Bbb R}/{\\Bbb Z} \\to [0,1]")#text(". With irrationality, the only constraint between the ")#mi("\\theta (n+id)^2 \\text{ mod } 1")#text(" for i=0,1,2,3 is provided by the identity")

#mi("\\theta n^2 - 3 \\theta(n+d)^2 + 3 \\theta(n+2d)^2 - \\theta (n+3d)^2 = 0")#text(".")

#text("As a consequence, given sufficient equidistribution, the above average should collapse to an integral")

#mi("\\int_{x_1-3x_2+3x_3-x_4=0} F(x_1) F(x_2) F(x_3) F(x_4)")

#text("on a three-dimensional subtorus of ")#mi("({\\Bbb R}/{\\Bbb Z})^4")#text(". Now, by a minor miracle, this expression turns out to be positive definite; this can be seen from the Fourier representation")

#tao-math("\\sum_{k \\in {\\Bbb Z}} \\left|\\hat F(k)\\right|^2 \\left|\\hat F(3k)\\right|^2", block: false)

#text("of this expression. In particular, if F has mean ")#mi("\\alpha")#text(", then the average always has to be at least ")#mi("\\alpha^4")#text(", thanks to the contribution of the 0 Fourier mode.")

#text("If, in contrast, one looks at AP5s and a function of the form ")#mi("f(n) = F( \\theta n^3 \\text{ mod } 1)")#text(", the analogous expression")

#mi("\\int_{x_1-4x_2+6x_3-4x_4+x_5=0} F(x_1) \\ldots F(x_5)")

#text("has no obvious positivity properties; in particular, if F has mean ")#mi("\\alpha")#text(", this average can be significantly less than ")#mi("\\alpha^5")#text(".")

#text("[As for AP3s, with ")#mi("f(n) = F( \\theta n \\text{ mod } 1)")#text(", then the mean number of AP3s can certainly dip below ")#mi("\\alpha^3")#text(" (e.g. Behrend’s example), but if one fixes the difference d so that ")#mi("\\theta d \\text{ mod } 1")#text(" is very close to 0, then the AP3 count becomes ")#tao-math("\\int_{{\\Bbb R}/{\\Bbb Z}} \\left|F(x)\\right|^3\\ dx", block: false)#text(" which is indeed at least ")#mi("\\alpha^3")#text(". Note though that fixing the difference d does not constrain the quadratic or higher dynamics.]")

#text("With regards to the second question, it seems our approach is a little different from yours in this respect. We have only one structural decomposition, but then we work a little harder on the structured part to make it extremely “irrational”. This is roughly analogous to regularising a family of polynomials to make them “high rank” (or more precisely, to represent the original family as combinations of a new family of high rank polynomials). With this irrationality we were able to handle all the small errors.")

#text("Perhaps your trick with Julia is more closely related to a trick that comes up in hypergraph regularity. If regularising a 3-uniform graph, one might first do so by finding a colouring of the 2-uniform structure relative to which the 3-uniform component is reasonably regular, but then one has to do a secondary regularisation in order to regularise the resulting 2-uniform structures in terms of a (much finer) 1-uniform structure (i.e. a vertex partition). This hierarchy of regularisations is crucial in order to properly do counting (and in particular to deal with all the small errors), as of course you well know…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-45033")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] increment method (an energy increment argument is also possible, but is more complicated; see this paper). Let be a set of density at least containing no lines. This implies that the -linear […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-45211")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] of consequences, analogous to the consequences for the finite field analogues of these facts; see this paper of Green and myself for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Additive limits | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-429517")[#strong[#text("Additive limits | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("[…] of Green which is analogous to the graph regularity lemma of Szemerédi. (There is also a higher order arithmetic regularity lemma analogous to hypergraph regularity lemmas, but this is not the focus of the discussion here.) Given […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cancellation for the multilinear Hilbert transform | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-456096")[#strong[#text("Cancellation for the multilinear Hilbert transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2015")])]

#text("[…] additive combinatorics (and more specifically, the arithmetic regularity and counting lemmas from this paper of Ben Green and myself) to obtain a slight amount of progress towards the open problem of obtaining bounds for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A correction to “An arithmetic regularity lemma, an associated counting lemma, and applications” | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-606305")[#strong[#text("A correction to “An arithmetic regularity lemma, an associated counting lemma, and applications” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("[…] Green and I have updated our paper “An arithmetic regularity lemma, an associated counting lemma, and applications” to account for a somewhat serious issue with the paper that was pointed out to us recently […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Gowers uniformity norm of order 1+ | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/12/an-arithmetic-regularity-lemma-an-associated-counting-lemma-and-applications/#comment-631851")[#strong[#text("The Gowers uniformity norm of order 1+ | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2021")])]

#text("[…] be, at least for linear polynomials ; Ben Green and I thought we had resolved this conjecture back in 2010, though it turned out there was a subtle gap in our arguments and we were only able to resolve the […]")
]
