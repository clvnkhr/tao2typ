// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:35:29.313938+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On multiple choice questions in mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On multiple choice questions in mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")[#text("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Now that the project to upgrade my old ")#link("http://www.math.ucla.edu/~tao/java/MultipleChoice/MultipleChoice.html")[#text("multiple choice applet")]#text(" to a more modern and collaborative format is underway (see this ")#link("http://www.resueltosya.com/quiz/")[#text("server-side demo")]#text(" and this ")#link("http://scherk.pbwiki.com/")[#text("javascript/wiki demo")]#text(", as well as the ")#link("https://terrytao.wordpress.com/2008/12/01/upgrading-old-java-applets/")[#text("discussion here")]#text("), I thought it would be a good time to collect my own personal opinions and thoughts regarding how multiple choice quizzes are currently used in teaching mathematics, and on the potential ways they could be used in the future. The short version of my opinions is that multiple choice quizzes have significant limitations when used in the traditional classroom setting, but have a lot of interesting and underexplored potential when used as a self-assessment tool.")

#metadata(none) <tao-cddba823f0e386e2cc20>

#heading(level: 1)[#text("— Multiple choice quizzes in the classroom —")]

#text("In principle, it would seem that the unambiguous and precise nature of mathematical statements would lend itself well to the multiple choice format; in contrast to some other disciplines of knowledge, many questions in mathematics ")#emph[#text("do")]#text(" have a single and objective correct answer, with all other answers being agreed upon as being incorrect. With a multiple choice quiz, a student can be tested on such questions in an objective manner; indeed, the grading for such quizzes can even be automated to be done by a computer or scanning machine. As long as the question was phrased unambiguously (and that the solution key is correct), the grading of such quizzes is less subject to dispute than other means of examination. As a final positive, the multiple choice format is extremely familiar to virtually all college students (who have probably had to have taken standardised multiple choice tests as part of the university admission process) and so the rules of the quiz require very little explanation.")

#text("On the other hand, the multiple choice format, as it is currently used in maths exams, has a number of serious weaknesses which, in my opinion, render it inferior to other examination options for most upper-division maths courses, although there are ways to remove the most glaring defects of the format. Perhaps the most obvious problem is the zero-tolerance approach to mistakes, which can distort the relationship between aptitude and credit: a student who had the right approach to a question, but made a single sign error or misunderstood the question slightly, could lose all points for a question, whereas a student who had no clue whatsoever what to do, and is simply guessing randomly, could manage to earn credit for a multiple choice question by pure luck, which is much harder to achieve in other examination formats. (Admittedly, one can mitigate this problem by keeping the questions simple and unambiguous, and ensuring that the incorrect answers obtainable from sign errors and the like are not given as one of the alternatives.) Another issue is that multiple choice quizzes are more susceptible to certain types of cheating and corruption than other examination formats, since the answer key is easy to copy and use, even by students who do not actually understand the material. (This particular problem can be guarded against to some extent by shuffling the questions separately for each student, though this of course makes it more difficult to grade the quiz, or to provide a solution key afterwards.) A third problem is that if the student arrives at an answer that is not among the options listed, this often encourages a rather tortured and not particularly logical fudging of the computation in order to arrive at one of the listed answers, which is not a good habit to instill in a mathematician.")

#text("A more insidious problem, however, is that these quizzes give a misleading impression of what mathematical problem solving is, and how one should go about it. In actual mathematical research, problems do not usually come with a list of five alternatives, one of which is correct; often, figuring out what the potential, plausible, or likely answers could be, or even what type of answers one should expect or whether one should ask the question at all, is as important as actually identifying the correct answer. Multiple choice quizzes also tend to reward quick-and-dirty or sloppy approaches to problem solving, as opposed to careful, deliberate, and nuanced approaches; in particular, such quizzes tend to encourage the mindless application of formal rules in order to arrive at an answer, without devoting much thought as to whether these rules are actually applicable for the problem at hand. (Indeed, overthinking a multiple quiz problem, searching for some subtle trick, degeneracy, or exception in the wording of the problem, or trying to play some sort of “metagame” in which one is trying to divine the intent of the examiner [see ")#link("http://www.youtube.com/watch?v=9s0UURBihH8")[#text("this scene from “The Princess Bride”")]#text(" for an extreme example of this], can mean that the brighter students who actually understand the material can end up doing worse on the quiz than those who are simply applying the rules they are taught without that understanding. Conversely, an overly tricky quiz problem that is designed to trap those who carelessly apply a standard rule without checking to see that it applies will usually be (quite rightly) perceived as being rather unfair on the student.) While some drill of basic formal rules (e.g. the laws and algorithms of calculus) is certainly necessary, especially at the high-school and lower-division undergraduate levels of mathematics, by the time one transitions to upper-division mathematics, one needs to start understanding the underlying theory and justification behind such rules, as part of developing a more conceptual grounding in the subject. (Also, when one gets to more advanced topics, there tend to be so many exceptions and weaknesses to any given rule that it becomes quite dangerous to apply such rules mindlessly. For instance, computing an integral by unilaterally shifting contours is quite likely to give an incorrect answer if one does not have a good sense of which contour integrals will safely go to zero in some limit, and which ones do not. It is self-defeating to look for some easily memorised rule that will say which integrals are safe and which ones are not, as there are so many different variations, especially in real-world applications; the only reliable way to proceed is to actually understand the business of estimating integrals and computing limits.)")

#text("But perhaps most of all, multiple choice questions promote the idea that the answer to a mathematical question is more important than the ")#emph[#text("process")]#text(" used to arrive at that answer (and the insights acquired during that process, and the art of communicating that process effectively to others). In truth, the process is far more important than the answer, particularly if the answer is to an artificial question, such as one designed specifically for examination purposes. Knowing the thought processes that were used by a student to arrive at an answer – even an incorrect one – would give me a detailed picture of how well equipped the student would be to handle similar (or more complicated) questions in the future, whereas the mere knowledge that the student selected one correct answer out of five alternatives gives me much less information in this regard. This also allows for much more valuable feedback in the grading process than simply reporting whether a given question was answered correctly or incorrectly, by identifying specific strengths and weaknesses in a student’s reasoning.")

#heading(level: 1)[#text("— Multiple choice quizzes as self-examination —")]

#text("I have discussed my reservations about the use of multiple choice quizzes in classroom examinations, particularly in upper-division mathematics courses. On the other hand, I do feel that such quizzes can play a very useful supporting role in ")#emph[#text("self")]#text("-examination for such courses, particularly with regards to foundational material (e.g. definitions or basic rules of calculation). I will illustrate this with a hypothetical course in high school algebra, though the point is certainly applicable to more advanced mathematical courses.")

#text("Suppose this algebra course is intended to teach students how to solve various algebraic equations. There are of course several standard pitfalls that the student encounters when actually trying to solve such equations; a common one is starting with an equation such as ")#mi("x^2=y")#text(" and concluding incorrectly that ")#mi("x = \\sqrt{y}")#text(", when instead the best one can say is that ")#mi("x = \\sqrt{y}")#text(" or ")#mi("x = -\\sqrt{y}")#text(". Now, one can caution against this error in classes, and the student may even write down this warning when taking notes, but it still happens all too frequently that this error is committed while solving a more complicated algebra problem in an examination (or worse, in a real life application of one’s high school algebra). At that point, the student may well realise the cause of the error – but this feedback may come days or weeks after first learning the material; without reinforcement, the same error may then recur later in the course, or in subsequent courses. Repeated exposure to algebra will eventually eliminate the error, but it can be an inefficient process.")

#text("This is where a self-administered multiple choice quiz (in particular, an online quiz) can help, with questions such as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 1.")]#text(" If x and y are real numbers such that ")#mi("x^2=y")#text(", then the best we can say about x is that")

#enum(start: 1, 
[#mi("x = \\sqrt{y}")#text(".")],
[#mi("x = y^2")#text(".")],
[#mi("x = y^{-2}")#text(".")],
[#mi("x = \\sqrt{y}")#text(" or ")#mi("x = -\\sqrt{y}")#text(".")],
[#mi("x = y^{-2}")#text(" or ")#mi("x = -y^{-2}")#text(".")]
)
]

#text("mixed together with variants such as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 2.")]#text(" Let x and y be real numbers. Which of the following statements is ")#emph[#text("not")]#text(" sufficient to imply that ")#mi("x^2=y")#text("?")

#enum(start: 1, 
[#mi("x = \\sqrt{y}")#text(".")],
[#mi("x = - \\sqrt{y}")#text(".")],
[#text("x is either equal to ")#mi("+\\sqrt{y}")#text(" or ")#mi("-\\sqrt{y}")#text(".")],
[#mi("x = y^2")#text(".")],
[#mi("y = x^2")#text(".")]
)
]

#text("and")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 3.")]#text(" If x and y are real numbers such that ")#mi("x^3=y")#text(", then the best one can say about x is that")

#enum(start: 1, 
[#mi("x = \\sqrt{y}")#text(".")],
[#mi("x = y^{1/3}")#text(".")],
[#mi("x = +y^{1/3}")#text(" or ")#mi("x = -y^{1/3}")#text(".")],
[#mi("x = y^{-3}")#text(".")],
[#mi("x = y^{-3}")#text(" or ")#mi("x = - y^{-3}")#text(".")]
)
]

#text("Such questions can address quite directly (and with immediate feedback) whether one has any misunderstanding on this specific point, without needing the live intervention of a lecturer or teaching assistant. (Ideally, an automated quiz should not only respond immediately as to whether the selected answer was true or false, but also to explain what the error was in the latter case.)")

#text("Note some differences between these sorts of multiple choice questions and the ones that appear in a classroom examination. In an exam setting, one usually wants to have more complex questions that test several aspects of the material at once (e.g. factorisation, gathering terms, substitution, etc.) rather than focusing narrowly and simply on a single aspect. (In particular, a student who actually knows the material should be able to answer each question here readily, without the need for significant computation.) Also, while classroom quizzes take pains to make the correct answer quite distinct from the incorrect alternatives (to separate those who basically understand the material from those who are truly lost), it is more effective for self-examinations to have only quite subtle differences between the correct answer and the other answers, in order to encourage the student to think carefully and to address any misconceptions head-on; these kinds of “trick questions” would be rather unfair in the stressful environment of an assessed classroom exam, but can be safely administered in a self-examination.")

#text("Multiple choice questions seem most effective here for reinforcing the precise definition of a key concept (was it “For every ")#mi("\\varepsilon")#text(" there exists a ")#mi("\\delta")#text("“, or “for every ")#mi("\\delta")#text(" there exists an ")#mi("\\varepsilon")#text("?”), the precise formulation of some rule (is the derivative of ")#mi("f/g")#text(" equal to ")#mi("(fg^{\\prime}-gf^{\\prime})/g^2")#text(", or ")#mi("(f^{\\prime}g-gf^{\\prime})/g^2")#text(", or ")#mi("(f^{\\prime}g-gf^{\\prime})/f^2")#text(", etc.?), or the direct testing of a specific and commonly made error (if ")#mi("x<y")#text(", does this imply that ")#mi("-x<-y")#text(", or ")#mi("-x>-y")#text("? See also this ")#link("http://www.math.vanderbilt.edu/~schectex/commerrs/")[#text("list of common errors in college maths")]#text("). But with a bit of imagination, one could come up with some useful multiple choice questions for self-examination for other purposes, even for rather advanced maths topics. For instance, consider the following question to test one’s grasp of the properties of the Fourier transform:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 4. ")]#text(" Let ")#mi("f: {\\Bbb R} \\to {\\Bbb C}")#text(" be a function. Among all the hypotheses listed below, which one is the weakest that still implies that the Fourier transform ")#mi("\\hat f: {\\Bbb R} \\to {\\Bbb C}")#text(" exists and is continuous?")

#enum(start: 1, 
[#text("f is smooth and rapidly decreasing.")],
[#text("f is absolutely integrable.")],
[#text("f is square-integrable.")],
[#text("f is continuous.")],
[#text("f is continuous and compactly supported.")],
[#text("f is a tempered distribution.")]
)
]

#text("The type of knowledge in Fourier analysis that this question is probing seems difficult to examine by other types of questioning (other than an oral examination).")

#text("Another interesting possibility is to use multiple choice quizzes to explore specific mathematical problem solving ")#emph[#text("tactics")]#text(", which is an issue which is only indirectly addressed by most examination methods. For instance, in a single-variable calculus course, one could focus on integration tactics, using questions such as these:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 5.")]#text(" Which of the following techniques would you feel to be a good first step towards finding an antiderivative ")#mi("\\int x^2 \\log(1+x)\\ dx")#text(" of the function ")#mi("x^2 \\log(1+x)")#text("?")

#enum(start: 1, 
[#text("Integration by parts, differentiating ")#mi("x^2")#text(" and integrating ")#mi("\\log(1+x)")#text(".")],
[#text("Integration by parts, differentiating ")#mi("\\log(1+x)")#text(" and integrating ")#mi("x^2")#text(".")],
[#text("Substitution, setting ")#mi("y = x^2")#text(".")],
[#text("Substitution, setting ")#mi("y = 1+x")#text(".")],
[#text("Substitution, setting ")#mi("y = \\log(1+x)")#text(".")],
[#text("Trial differentiation, using functions such as ")#mi("x^3 \\log(1+x)")#text(".")],
[#text("Sketching a graph of ")#mi("x^2 \\log(1+x)")#text(".")],
[#text("Taylor series expansion of ")#mi("\\log(1+x)")#text(".")],
[#text("Start up Maple, Mathematica, or SAGE. :-)")]
)
]

#text("Note that this question is of a more subjective nature than the preceding questions, with different answers having different strengths and weaknesses; there is no single “correct” or even “best” answer here. As such, this would be a terrible question to place in an assessed exam, but I think it would be a good thought-provoking question to give in a self-administered quiz. (This would be one example of a question where the process of arriving at one’s chosen answer is definitely more valuable than the answer itself. Also, having a place to discuss the various answers to a question such as this – as would be the case, for instance, if the question was hosted on a wiki – would also add an extra dimension to this exercise.) Note the difference between the above question and the more traditional “Compute the antiderivative of ")#mi("x^2 \\log(1+x)")#text(".”; the emphasis is now on tactics rather than computation.")

#text("In summary, I believe that there are a number of interesting ways – many of which appear to be underexplored at present – in which some well-designed and self-administered online multiple choice questions can efficiently assess one’s strengths and weaknesses in a given mathematical subject. Of course, having one-on-one interaction with a lecturer or teaching assistant would be a greatly preferable way to achieve this sort of instant feedback, but this is impractical for larger classes. It is also true that a certain level of maturity and discipline is needed on the student’s part in order to actually benefit from these sort of self-assessments, especially since they are not directly contributing to the student’s grade in the class, but my philosophy here is to give the students the benefit of the doubt in this regard; I feel that being able to explore beyond the bare minimum of what is needed to obtain a passing grade is part of what an upper-division course should be about.")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9566b81cb7b1eac198b1d5c9d9bd72d09b77847fd92d344bf6dab967bbe04f82-5f2a5ea2656531b8a3338ef64f178cf0056f39e097f2585911b02f89a9156703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33909")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("As a European currently applying for graduate school in the US I was surprised to find out I needed to take multiple choice tests like the GRE subject math exam at this stage in my education. Do you think the benefit of having a standardised test to asses all candidates, which is also easy to administer, outweighs the various drawbacks mentioned in your post?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33912")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Such questions can address quite directly (and with immediate feedback) whether one has any misunderstanding on this specific point, without needing the live intervention of a lecturer or teaching assistant. (Ideally, an automated quiz should not only respond immediately as to whether the selected answer was true or false, but also to explain what the error was in the latter case.)")
]

#text("I suppose algebra lends itself more easily to this sort of feedback more readily than other areas of mathematics, blurring the line between quizzes and tutorial software. For what seems to be a good example of the latter, check out ")#link("http://www.theoryyalgebra.com/")[#text("Theory Y Algebra")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1561559b8cbbc25aabf69fbbb14d1ecfb338ac7be60ce2d736746c9863f2755c-0312cbcf6360721c9d7b0c3e186b11cf9df779cb1ab34776263529949ffd5e76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33914")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("You sound like you should be using ")#link("http://en.wikipedia.org/wiki/Moodle")[#text("Moodle")]#text(", which was started by a fellow Australian. It seems pretty easy to have multiple choice quizzes that the students use for self-assessment. Your ideas above seem to mesh with their ideas of “social constructivism”.")

#text("I have used Moodle for a graduate class and found it pretty easy and flexible. I recommend giving it a try.")

#text("Also, I’m glad to see Sage mentioned alongside Maple and Mathematica…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33918")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Why should multiple choice tests be used in mathematics courses?")

#text("a.) According to the “Does one have to be a genius” section of this blog, luck")#linebreak()#text(" is one of the essential ingredients in doing mathematics.")

#text("b.) It would allow the University of South Queensland to replace all its remaining")#linebreak()#text(" faculty with automatons.")

#text("c.) According to the axiom of choice, the test can be completed independent of its")#linebreak()#text(" cardinality.")

#text("d.) All of the above.")

#text("e.) None of the above")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92709b19b3a3b3c34f60aff36c1cb17bae5e04f4dedd24fc63a499e2eca8bca0-20641a8a4f29f929a3e929855720497e20559e6c17d83b6cfdaa7a1e8d6e1e85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larry Sheldon")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33926")[#strong[#text("Larry Sheldon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("An Off-the-topic question: When did (or where did) the practice of using the plural of “math” (as in “…as it is currently used in maths exams…” above) begin?")

#text("I don’t remember hearing it before a year or two ago. (I should say that we have documented evidence of my failure to pay attention in Mathematics classes, although I personally think the problem had more to do with a failure to do the homework).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288f076b258a03beb192c93c7fa92fd941b52fee3ffb2d9dbe84493cd05a5ec2-73ec104c504249d9ffb6b981e6a5b43cd834beb236db0a88dbcf21d2f45e7071.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AngeloPardi")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-323869")[#strong[#text("AngeloPardi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")])]

#text("Maths : British")#linebreak()#text(" Math : American")#linebreak()#text(" Interestingly, French people use the plural “les mathématiques”, shortened as “maths”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-477421")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("It is because before, music was part of the mathematics so we used the plural.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33927")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I think there’s a hat missing is Question 4. [")#emph[#text("Corrected – T.")]#text("]")

#text("As a silly aside, I’d point out that there are some real math problems that have a multiple choice form. For example, say I need to know the dimension of some subspace of ")#mi("{\\Bbb R}^3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/162b70c9320d4f8cada2a88cec9bddd77ed4aa17398c276d371eb12625da66a0-e7437f5aedf61a5f5fdc038f77fd8cf24ef90350ab05377285297c7333e4afdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beetle B.")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33928")[#strong[#text("Beetle B.")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#emph[#text("An Off-the-topic question: When did (or where did) the practice of using the plural of “math” (as in “…as it is currently used in maths exams…” above) begin?")]

#text("In British English (and I can only assume, Australian English), they say “maths” and not “math”. It’s not a plural of the other.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33949")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("A lot of the usefulness of multiple choice tests I think depends on the care that is taken picking the “incorrect” answers. If you guess which mistakes would likely be made you could have appropriate answers. If the wrong answers are just random answers there is no need for those since nobody will come up with those in a true calculation only by guessing an answer if he/she has no clue at all.")

#text("In addition there are the types of meta-thoughts the student could have: For example in maths olympiads you could ofthen get an idea how to approach the question by using the fact that this was an olympiad question, i.e. it had to have a unique answer and usually there is a cute way of finding it. This often ruled out many dull things one would have tried otherwise.")

#text("Also, often the possible answers give something away: In question 1, anybody who actually reads all the possible answers and has only heard the waring one will remember that -sqrt(y) has to be considered as well once he sees this is a possible answer. If there were a problem where at some point x^2=y had to be solved for x and the possible answers would not suggest that one has to take care of the sign many more people would forget about -sqrt I would believe.")

#text("Similarly, question 2 is a no brainer since obviously only one answer can be correct and that one is obvious. One does not have to think about signs of squar roots to find x=y^2 as wrong. It would be better if it were not known in advance that only one answer is correct and some answers need several answers to be ticked.")

#text("But even when “proper” questions are asked (instead of multiple choice) I still believe oral exams are much superior to written ones: In my experience the grades in written exams cluster much more in the middle since there will always be “questions for everybody”. Some of the questions will be very easy and thus not eb discriminating between candidates. And even very good students will have a hard time getting exactly everything right and not doing some stupid mistake somewhere in the middle.")

#text("On the other hand I believe in the ideal oral exam the student can answer exactly have the questions right. But it is of course the questions that adopt to the student. By doing this the examinors can precisely map out the boundary of the student”s knowlede without wasting too much time by asking very good students trivial questions or poor students too hard ones.")

#text("Unfortunately, the work to have oral exams scales very badly for large number of students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of heatkernel")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33954")[#strong[#text("heatkernel")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Somewhat off-topic, but I think sufficiently related to the topic of this post to warrant asking this here: has anyone come across any good advice about how to structure and grade exams in proofs-based courses? I taught for the first time, an advanced undergraduate class (point-set topology) this semester. Since for many of the students, it was their principle introduction to proofs-writing and proof-centered mathematics, I made all the exams primarily consist of statements for them to prove. In order to bring about some consistency in the grading, I tried to come up with “grading schemes” awarding different point values to different parts or steps of the proofs. The problem is that, even though all the questions were very similar if not identical to exercises in the homework or the book’s theorems, on every question a most of the students (with the exception of the same small set of harder working or better prepared students) flailed around all over the place and submitted a combination of true, false, and nonsensical statements that didn’t exactly add up to a proof, but demonstrated usually at least some knowledge of the subject. Although obviously, it is still necessary to assign some partial credit in such situations, it can be very difficult and time consuming to do so in a consistent and fair manner. I just wondered if anyone had come across anything helpful on the web or in the literature by anyone who has put some thought into the question of how to structure and grade proofs-based exams and has come up with some helpful suggestions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0671581df4874e700acdfedc25287cbb20f58a67cde4b17750ea9905cb23a46a-d07f92930b2a0bff486661518fb8761614022977ed57dd1b06c43eb98771e5a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jelations")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33956")[#strong[#text("jelations")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I’m not taking math, but I did notice this part —")#linebreak()#text(" “(Ideally, an automated quiz should not only respond immediately as to whether the selected answer was true or false, but also to explain what the error was in the latter case.)”")#linebreak()#text(" We don’t have this immediately since some of our MCQ online quizzes are graded, but shortly thereafter we sometimes get to see where we went wrong; and I must say that the times when they actually explain it = times when I’m most grateful! :D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7fa0ef83317c215877307768471743992c315289e945f6d891276dd9fa7a2a1-c9e86f48b2c476cc7c4ebb3cd0330c59cf49004d701e9ccc9ed37231c249fcbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grant czerepak")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33972")[#strong[#text("grant czerepak")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("Really what you are making a good attempt to explain is this:")

#text("Multiple choice questions are convergent and rarely experienced in real life, while problem solving is often divergent where there may be multiple paths to the single answer.")

#text("My most vivid memory is solving all the statistical questions in a chemistry exam using calculus only to be asked by the professor afterward how I came to arrive at non-statistical solutions. Wondering what kinds of idiots I was being taught by led me to change majors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carissa")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33973")[#strong[#text("carissa")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2008")])]

#text("I too find multiple choice in mathematics to be tricky, they are terribly misleading, and I especially relate to it when you say talk about the student who had the right approach but simply made a small mistake somewhere in the middle, something I’ve done too many times, but have been saved the deduction point because my teacher saw my calculations and was kind enough to give me points for it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44bc599f036abe7f4b13b16aba738f33955dd459a7b8f5d1ace5859796fadcde-f5ed30e4242d96f22d73e970a56eead4dc15134a6fceebff18f8a20710246f70.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dodingdaga")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33975")[#strong[#text("dodingdaga")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I find the multiple choice exams in mathematics extremely difficult since it gives all the credit to the final answer and not to the solution which is very important.")

#text("One student can get the correct answer by guessing without even looking at the question and a student who studied hard for the exam who had a solution amounting to short bond paper but failed to correctly answer the question since he had the wrong sign for the final answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-33984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("My first comment is that I think that a very carefully designed multiple-choice test can test almost anything you want to test, with different partial credit for different wrong answers if you like.")

#text("My second comment is that there are even better ways to design a test to make it easy to grade, by careful choice of questions and the size of the space where the student must put the answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Here’s a standard SAT multiple choice question:")

#text("What’s next in the sequence:")#linebreak()#text(" 1, 2, 4, 9, 25, 36 (*)")

#text("Typically they are going for the fact that these are all squares and the next number is 49. However this has always struck me as a poorly thought through question (despite the fact that variations of it are frequently recurring). f(x)=x^2 is an arbitrary polynomial, and each of the other answers will corespond to evaluation of some polynomial at consecutive integers.")

#text("The first thing that jumps out at me when i see sequence (*) is that they are all squares, but then again I spend a fair amount of time thinking about number theory. Who am I (or rather the guys at the college board) to say that this is the best answer? Is this really what college admissions should be based on?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34007")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Um, 2 is a square? Interestingly, even the ")#link("http://www.research.att.com/~njas/sequences/index.html")[#text("on-line encyclopedia of integer sequences")]#text(" drew a blank on that one. (I am sure you didn’t mean to include 2 in the sequence, and most readers of this blog will catch it, but others might be puzzled, so I figured I might point out the mistake.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79111b1ca80e4c40e8844533bc648e03fc4809b3bbd6658c5bd32a892aa35431-d6fb418c95adaaeba8722e4f20e9ba8a8cfdc4bda3b4b78c69e68dc9aead584a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34010")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Robert,")

#text("I have recently been doing some private tutoring for some students taking a calculus class. The old final exams have been made available to the students, and these are all multiple-choice, so I’ve been spending a fair bit of time with them working through questions from the old exams. It is interesting to me to see how many of the multiple choice questions just have essentially random numbers as the distractors. I suspect that the writers of the tests in question would have preferred to write an exam that was not multiple-choice, but chose the multiple-choice format solely for ease of grading.")

#text("As for oral exams, the math PhD program here at UPenn (like at many other schools) has an oral qualifying exam, usually taken sometime during the second year. A lot of my friends are preparing for these exams right now. I’ve told them that they will feel stressed during the oral exam unless they are extraordinarily well prepared, because the examiners generally can quickly figure out the limits of what the examinee knows. So the majority of the time during the oral exam is spent flailing about, even for people who know what they’re doing.")

#text("Oral exams scale poorly, as you point out. One problem which is related to the scaling is that the real strength of the oral exam is that you can ask different questions to different students, depending on their level of knowledge. But if you do this, then can you really say that student A did better than student B? Student A may have answered less questions correctly than student B, but they were harder questions. This seems like it would be an issue in using such exams in a course. And even if the instructor feels that they can confidently rank students, I’m not sure the ")#emph[#text("students")]#text(" would share that feeling. This isn’t a problem for higher-level exams like the PhD qualifying exams, from what I’ve seen. The purpose of the qualifying exam is to certify that the student is ready to begin research, and so each student is tested on a syllabus which is created by the student and their exam committee (three professors). By the time we get to taking orals our various programs have diverged, so very few pairs of students have identical syllabi. Furthermore, there are only three possible grades (pass, marginal pass, and fail) so the issues of measurement that would come up in grading for a course aren’t a problem here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79111b1ca80e4c40e8844533bc648e03fc4809b3bbd6658c5bd32a892aa35431-d6fb418c95adaaeba8722e4f20e9ba8a8cfdc4bda3b4b78c69e68dc9aead584a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34011")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Anonymous (10:38 am):")

#text("assuming you meant the sequence 1, 4, 9, 16, 25, 36, you could argue that the best description of the sequence is f(x) = x^2, and so the best “next term” is 49, essentially because the description f(x) = x^2 is very short, or alternatively because a program to generate that sequence is very short. This is basically the idea of ")#link("http://en.wikipedia.org/wiki/Kolmogorov_complexity")[#text("Kolmogorov complexity")]#text(". And I think there may be a place for questions such as this in admissions testing. I admit that these sequence completion questions can be a bit subjective, but the ones that make their way onto tests never seem to be. Besides, ambiguity is a part of life.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8831c28918f694948e6b5259716111419afba243579a58971108cbab996ffe7e-dd1c349211d2b3b8f8e399c4494264464eaae9b1e70aef9b62b59d4d0e090ba5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34013")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I think that if multiple choice tests were completely eliminated from mathematics, we might see good results. We’d see less people succeeding, but the people who did succeed would be the cream of the crops.")

#text("On the other hand, in order to be truly egalitarian (which is the goal eventually!) perhaps we should allow multiple choice.")

#text("NS")#linebreak()#text(" ")#link("http://sciencedefeated.wordpress.com")[#text("http://sciencedefeated.wordpress.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34018")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("I may have something serious to say later, as a former Adjunct Professor of Mathematics who specialized in teaching students who’d flunked remedial algebra once, twice, even thrice.")

#text("But, for now, in answer to anonymous’s pseudo-SAT problem, I’d skip the 49 and go ahead with 121. Because of the integer sequence by Klaus Brockhaus:")

#link("http://www.research.att.com/~njas/sequences/A114110")[#text(" Records in A111390")]

#text("1, 2, 4, 9, 25, 49, 121, 625, 841, 961, 1369, 1681, 1849, 2209, 2401, 4096, 59049, 531441, 9765625, 244140625, 282475249, 282811489, 283484569, 283518244, 283619281, 283787716, 283821409, 284023609, 284091025, 284192164, 284225881")

#text("Of course, that presumes that one likes")#linebreak()#text(" A111390 a(1)=1. a(n) = smallest positive integer not occurring earlier in the sequence such that |d(a(n))-d(a(n-1))| = 1, where d(n) is the number of positive divisors of n.")

#text("The point is well taken, though, that the more Math one knows, the more that the “wrong” answers can be justified.")

#text("I’d add that the key to effective education, including in Math, and including self-education, is to maintain a proper balance oif:")#linebreak()#text(" (a) instruction;")#linebreak()#text(" (b) management;")#linebreak()#text(" (c) assessment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of erik davis")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34026")[#strong[#text("erik davis")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("The professor for my introductory topology course (basics of general topology with a bit of fundamental group and covering spaces) took a hybrid approach to exams. 80% of the exam grade was from 3-4 typical proof-oriented problems, and then there were 20 true/false questions accounting for the remaining 20% of the grade. The problems were usually straightforward — the majority would be things that had been explicitly covered in class, or else things that should be blatantly obvious to a student by that point. There would always be a few of them that were more substantial, in fact I would usually do a rough outline of a proof on scratch paper just to make sure I was not botching anything.")

#text("The purpose of these problems was, I think, to add some breadth since due to time constraints we couldn’t really write up a whole lot — the tests lasted only 50 minutes. I enjoyed them and appreciated the fact that they rewarded being able to think quickly when necessary. The obvious downside is that students can just guess on the problems, but the fact that they were only 20% of the grade reduced the effectiveness of this strategy — if you didn’t know your stuff, you could still fail pretty hard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/601e10c074afa664e642e68a88e7878fc23c359cf20c760f8c04e79e1b0fea06-1d3c0667750fcc141577086b6bdd1fa89f0b7152f2ee0cf882623c33f31a29ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matt")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34027")[#strong[#text("matt")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("On the other hand, the problem with written tests is that the professor often wants to see you do the answer in a certain way. I slept through most of my differential geometry class as an undergrad, and was kind of stuck on the test since I hadn’t really learned much (or anything). By using (ugly, explicit, brute force) coordinate approaches, I was able to solve all or almost all of the questions, but got basically a zero because I didn’t solve any of them in the (more advanced) ways that had been taught. Had to go talk to the guy in person to explain to him that my final answer was correct in almost every case. Multiple choice would have been nicer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/601e10c074afa664e642e68a88e7878fc23c359cf20c760f8c04e79e1b0fea06-1d3c0667750fcc141577086b6bdd1fa89f0b7152f2ee0cf882623c33f31a29ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matt")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34028")[#strong[#text("matt")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("Just to follow up that last one: if the prof wants to see the use of certain techniques, the problems should be set correctly. I took Serge Lang’s course in complex analysis, and he was upset that a lot of the class didn’t use contour integration to work out complex integrals on the first test (probably even threw some chalk), but then he realized that he should have just set more difficult integrals that would require contours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3be9bda587877fdef1ff3139bfcb76a628eb928f219960590f1b226772289815-9e3951eb3553e765bc07e16c1dc236ad627fde566927a3ebe927dc17a70d0a49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of multiple choice tests are: (a) totally useless, (b) ideal for all classrooms, (c) useful in some situations, or (d) all of the above « orgtheory.net")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34030")[#strong[#text("multiple choice tests are: (a) totally useless, (b) ideal for all classrooms, (c) useful in some situations, or (d) all of the above « orgtheory.net")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("[…] a comment » The answer is (c), if you read Tereance Tao’s post. He makes the case that there’s a good place for multiple choice questions in learning, just […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34073")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Erik Davis makes an important point: “I enjoyed them [tests with time constraints] and appreciated the fact that they rewarded being able to think quickly when necessary.”")

#text("I challenge my disadvantaged high school Science students, and before them my university and high school Math students, by giving them both short quizzes (5-10 questions) which they can master, and longer (also tricky) multiple choice tests with 20-30 questions that almost none of them can complete in time. The latter are to force them to develop better strategic test-taking skills, such as triage.")

#text("First skim each question on the entire test, and put a pencil check mark next to the ones that look easy. Do all the easy ones first. If you run out of time later, at least you have done the ones that looked easy to you, so if your easiness-estimator is good, you have an expectation of many answers correct. Then skim the remaining questions and tick the ones that look hard. Ignore them for now, and do the remaining intermediate-hard questions. Don’t mess with the hard questions unless you finish all the easy and intermediate questions before the deadline.")

#text("Also: eliminate the obviously silly answers and, if you narrow things down to two possibilities, guess. Also: look for questions which give you information to answer other questions.")

#text("College student have practiced many of these strategies. Students in good high schools may have, also. Students in bad high school usually have done none of the above.")

#text("They complain that my tests aren’t fair. I tell them that life isn’t fair; get used to it. They complain that my tests are too hard. I tell them that life is hard; get even.")

#text("I still haven’t discussed multiple choice exams as such, but this gives some points not just about “think[ing] quickly when necessary” but about resource management, including time and computational capability as resources.")

#text("This now connects with the thread about how to write papers, and the resource management issues of co-authorship and making progress in a portfolio of solo papers across a spectrum of difficulty.")

#text("One purpose of assessment is connected with one purpose of instruction: I (as a teacher) am not telling you WHAT to think, I’m showing you HOW to think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3d673fb32d9c24608594a70e088a3b49d1c94b28ccf14d81c0e75ddf8ed1fca-ac25f8bff55160d5ff71baff4d6997f506abbdb2034e48fe84bf880a149ce79d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Soddisfazione « In teoria")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34242")[#strong[#text("Soddisfazione « In teoria")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2008")])]

#text("[…] scoprire che Terry Tao la pensa (sostanzialmente) come me: vedere il suo pensiero in materia in questo […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8df4de204000ccb556240976e0122c54599b3f34e613009998ca344f770bc7af-ab8ab802a842dd9b1fff4419db45ae8d93efd5ff1f231dc5381a5183ba869b83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prasad yadav")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-34680")[#strong[#text("Prasad yadav")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2009")])]

#text("please i want to take a test now")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efcaed6e4fd0f0aaa4246058e9cf734e2e729e561c3da466edaccf287607bd1a-4559891c2208e648b8e785460ffdd9bf2a2c13e6aaf6e6fab39af71b5077c6c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AISHA")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-35419")[#strong[#text("AISHA")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("YA IT IS GOOD. I AM READY FOR TEST…………………………")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535c3400299827d55f22a1e5073fb14cb3316c38adae7e6969fe9a683a156d98-c0de0216a692fb574b3b8325a9bfc14a727671ff37498212435a891bb8174dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TAYEM")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-36142")[#strong[#text("TAYEM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("I LOVE SUCH EFFORTS TO ENABLE STUDENTS TO STUDY EASILLY ONLINE.PLEASE I’LL LOVE TO GET SOME EXERCISES FROM HERE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04c9a7ce9cc760964aa9835d9367e83f027bf6acba8fc9f7fd543259e6280817-d2084f4a0f62d00ca0e4f8e840efa49b9d9c007da6d7f0cb7ba2aee39f7a7422.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of salman abbas")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-37817")[#strong[#text("salman abbas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("I want to take exam as soon as possible")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-39400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2009")])]

#text("Do you think you could turn off the annoying “snap shots” on this blog? I finally found instructions on how to do it:")

#link("http://www.blork.org/blorkblog/2008/03/31/how-to-disable-snap-shots-on-blogs/")[#text("http://www.blork.org/blorkblog/2008/03/31/how-to-disable-snap-shots-on-blogs/")]

#emph[#text("[Snap shots has been disabled for about a month or so here. If others are still finding it activated, please notify me. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed8bc78bcba5371990b346a0b2f8753c6707f72e1813bada17d3d85425438bd-f36f0c15d8f93af59a7e41d4ec0676bc7cfe3dd27a0fb1a4cfe8c1d4a2f32de7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gérard P. Michon")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-39793")[#strong[#text("Gérard P. Michon")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2009")])]

#text("Not all multiple-choice questions are bad. However, students who have been routinely rewarded for speed with little or no “penalty for guessing” often miss the point of well-designed questions, like this superbly crafted example (not mine ;-) where actual thinking IS required and rewarded:")

#text("The source of every sound is something that is")#linebreak()#text(" A) undergoing simple harmonic motion.")#linebreak()#text(" B) accelerating.")#linebreak()#text(" C) a net emitter of energy.")#linebreak()#text(" D) moving.")#linebreak()#text(" E) vibrating.")

#link("http://answers.yahoo.com/question/index?qid=20080809103803AApEWeK")[#text("http://answers.yahoo.com/question/index?qid=20080809103803AApEWeK")]#linebreak()#text(" Apparently, fewer than 20% of “guessers” pick the ONLY correct choice (C) because most or all wrong answers may look better, or more “plausible” at first.")

#text("Questions of that quality being so rare, it’s still safe to say that multiple-choice exams are a disgrace (except, possibly, in quick self-evaluations).")

#text("Also, let’s not forget that exams graded by a teacher are a rare opportunity for students to assert themselves in a creative sense. That opportunity is denied to them if they are only asked to check boxes…")

#text("The Big Picture: Education consists in passing civilization and knowledge from one generation to the next. Ultimately, some students ought to be able to write better questions than their elders, or else the whole exercise is pointless and/or doomed… Checking boxes in front of existing questions does not help at all in that process.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4eb893ae2326480db8995a91a9e7207931fb9351be4c8e60f589759e2aa19f13-4855e36daeeb8e6e158ee8ba492fca8986ccd09b89896f36d501e9d06f659400.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manoj Srinivasan")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-46789")[#strong[#text("Manoj Srinivasan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("Gerard:")

#text("Your “source-of-sound” question, and especially what you call the correct answer, sounds a bit fishy to me.")

#text("You say every source of sound is a net emitter of sound.")

#text("Take some big machine (like a computer, say), that eats a LOT of energy (that is, work is performed on it), and produces a TINY little bit of sound. Such a machine would be emitting sound, but will be a net absorber of energy. So not all sound emitters are ‘net’ emitters of energy.")

#text("In fact, THE quintessential emitter of sound — a speaker — typically has about 1% efficiency. That is, 99% of electrical power input gets converted to heat. Now if you carefully heat-insulate the speaker, the speaker would be a very good net absorber of energy.")

#text("Anyway, I think one should carefully define what “a source of sound” means, before asking/answering this question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-248728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2013")])]

#text("Well, then the speaker will stop working from overheating…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cb4e73bcd9893a60143cdfc55186058924fb833f5bb634410786bf146be510-3bd957d178d5f32592c196e9bb6664d3cb99482a59b0a556dbbc86489e563e7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vishnu kumar")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-68242")[#strong[#text("vishnu kumar")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2011")])]

#text("i wants to more examples")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45ca141d9dc153d3d682e97c6ce05e7f97ef712d91e476ef71b3e8352c83fc1c-f179687296bd9855aded458f4774653e07843dc0be538acfd368bfafd80f9e03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PETER MWALIMU MWENDWA")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-113441")[#strong[#text("PETER MWALIMU MWENDWA")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2011")])]

#text("Rarely will you find life challenges well packaged into two, three or five sets of choices from which to pick one’s option. In the same vein, if mathematics is to be effectively used to enable persons to make useful decisions in life, then assessment should not be a package of choices for every problem posed. It should be a spark to ignite one’s variety of views to the problem with minimal restriction or distraction to sway ones creativity away from the norm. Multiple choice tests in mathematics may effectively discourage originality and advancement of theories by lingering around the established norms ( Pythagoras theory, Eulers theory, ….) and not allowing creative follow up and meaningful advancement or critique of the said norms.")

#text("When will mathematics be viewed as it should: a very cognitively nourishing spectrum of opportunities and a way to overcome many life puzzles? This cannot be the view if one is bound by perhaps faulty imaginations of another party in the name of the examiner. Mathematics should be a liberating rather than an enslaving and thought restricting discipline. It should be a bedrock of scientific disciplines as well as arts by setting the mind free to manipulate ideas and prove results. This encourages innovation and adventure and is a recipe for industrial revolution in any economy.")

#text("Whereas options may crop up in life, certainly not in all instances and when they do, first the liberal mind is the best to get the most appropriate option. Assessment should therefore encourage independence of thought in consideration of other people’s findings and not bind the learner in the perhaps shallow confines of the one or few persons’ setting the questions and devising the possible options. It should spark or rather elicit a rich response or opinion of the learner allowing him/her to believe in oneself and defend one’s stand point.")

#text("Multiple choice tests should rarely be used in summative evaluation unless in a very minimal extent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353db294574b77d85998015b42185b48eccfc964603d2dc00d32795d9e9e8a0a-a6511a8a49674f21017f17e09816198beff00bef720eb01660b6c7e1ccd82265.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Interesting and Must Read Papers and Articles in Mathematics | MY DIGITAL NOTEBOOK")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-118716")[#strong[#text("Interesting and Must Read Papers and Articles in Mathematics | MY DIGITAL NOTEBOOK")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2011")])]

#text("[…] Multiple Choice Questions in Mathematics ")#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")[#text("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")]#text(" Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-129629")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2012")])]

#text("The link to the “Princess Bride” video is defunct.")

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-236627")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/06/29/on-multiple-choice-questions-in-mathematics/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-265387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2014")])]

#text("I want to take a test as soon as possible…………i’m ready for it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953dcbeacebcd2919e2501201e24c9db07f90cd1df499d8ef3171d471e08fb26-3fefeadecfa08a7bbeb17c5c1f3a66de277b258acf241d58f04cb36b33082286.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rajbala")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-272491")[#strong[#text("rajbala")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("k somewhat confusing; if it would have been in easy language it would be realy intresting")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-431140")[#strong[#text("Multiple Choice Questions For Visual Art Test For 3rd Grade | News Latest Update")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2014")]

#text("[…] #, #, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79b07306096373833e6226d4fe526a736cdcf032256a08ff7b28746fb16776f4-c3f8c2f40d2c47f37c0c613c75566febab3db05abf067572384cf37c45fd8894.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-461848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("hi! I am MORWO lIKINJIYE FROM TANZANIA. I AM INTRESTED WITH THE DESCRIPTION ABOUT MULTIPLE CHOICE IN MATHEMATICS GIVEN ON THIS PAGE. PLEASE CAN I GET A MORE ACADEMIC ARTICLE CONTAINING THE EXPLANATIONS ABOVE? KINDLY HELP A MY RESEARCH ON MULTIPLE CHOICE IN MATHEMATICS.")#linebreak()#text(" MY EMAIL IS ")#link("mailto:grmorwo@outlook.com")[#text("grmorwo@outlook.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-509208")[#strong[#text("How Craig Barton wishes he’d taught maths | Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")]

#text("[…] Terence Tao has created a number of multiple-choice quizzes on university-level topics. He has also blogged about it here. They are not exactly diagnostic in the sense Barton is talking about, but one could imagine trying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-512325")[#strong[#text("How Craig Barton wishes he’d taught maths")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")]

#text("[…] Terence Tao has created a number of multiple-choice quizzes on university-level topics. He has also blogged about it here. They are not exactly diagnostic in the sense Barton is talking about, but one could imagine trying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-512326")[#strong[#text("How Craig Barton wishes he’d taught maths – gutuka")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2019")]

#text("[…] Terence Tao has created a number of multiple-choice quizzes on university-level topics. He has also blogged about it here. They are not exactly diagnostic in the sense Barton is talking about, but one could imagine trying […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/#comment-689465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#metadata(none) <tao-82bf9b7bd1ea654cdf00>

#text("Dr Tao, for Question 5, if I try to solve this question, I would choose the technique of integration by parts, because it would make sense to integrate the 𝑥² factor to move a derivative onto the log(1+x) factor.")

#metadata(none) <tao-d1907c5e238489b72668>

#text("But using substitution would be helpful too, which set u=1+x. So I wonder when ones try to solve an integral, for example integrating 1+e^{x} / 1+e^{-x}, you could set u=e^x then this integral can be done. But sometimes we would encounter some complex situations—— Thus I wonder generally speaking, what’s the “strategy” for the technique of integration by substitution?")
]
