// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/
// Converted to Typst by tao2typ: "2026-10-19T13:44:10.995380+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR’s Open Math Model initiative", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR’s Open Math Model initiative")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/")[#text("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-19 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Last year I co-founded the ")#link("https://sair.foundation/events")[#text("Foundation for Science and AI Research (SAIR)")]#text(" with some private donors to create a non-profit organization that could support responsible uses of AI in mathematics and the other sciences, independent of the major AI companies. Initially, our resources were rather limited, and our main activities consisted primarily of ")#link("https://www.youtube.com/@SAIRfoundation/videos")[#text("podcasts")]#text(", ")#link("https://sair.foundation/events")[#text("short events")]#text(", and ")#link("https://competition.sair.foundation/")[#text("competitions")]#text(". However, we have been slowly trying to expand in scale, ambition, and logistical capacity; for instance, we were very grateful to receive ")#link("https://blog.sair.foundation/an-open-commitment-to-mathematics-and-science/")[#text("recent support from XTX markets and Susquehanna")]#text(" to fund our next round of SAIR competitions. Furthermore, we have been negotiating with several key partners from academia and industry towards an initiative to build open weight models for science, as well as open source tooling for using both open and closed source LLMs for scientific applications.")

#text("We had initially planned a gradual rollout of this initiative, starting with a few pilot projects over the next few months, but given current events and the high demand for open models, we are accelerating our schedule and moving our ")#link("https://sair.foundation/open-math-model/")[#text("initial announcement of the initiative to today")]#text(", despite the fact that some key planning is still underway. In particular we are now ready to collect expressions of interest in the initiative, as we are seeking partners who can contribute funding, compute, expertise, or community building to our efforts. (Expressions of interest can be registered at the bottom of ")#link("https://sair.foundation/open-math-model/")[#text("the announcement page")]#text(".) I have replicated the text of our initial announcement below: we plan to provide more updates and information on the initiative shortly, including an announcement of our partners, as well as future plans to integrate this initiative into our existing portfolio of podcasts, events, and competitions.")

#heading(level: 1)[#text("Building Open Models for the Mathematical Community")]

#text("An Invitation from SAIR Foundation")

#text("Mathematics advances through discoveries that others can examine and build upon. Generations of researchers have created a shared body of knowledge, sustained by open exchange and respect for each other’s contributions. As AI becomes part of mathematical research, these principles should shape the tools we use. SAIR and its partners are commencing an initiative to be at the forefront of shaping and implementing these new tools. Let’s work together to build Math 2.0.")

#heading(level: 1)[#text("Models Shaped by the Community")]

#text("Through SAIR Open Models, we invite the mathematical community and its supporters to build open-source models together. Researchers can and will determine how these models are trained, what they are evaluated on, and how they serve research and education. The community needs models it can inspect, improve, and run independently, with development guided by shared scientific priorities. Participation should be open across institutions, regions, and career stages.")

#heading(level: 1)[#text("Tools for Everyday Research")]

#text("Our first phase will focus on everyday mathematical work: understanding difficult arguments, checking references, exploring examples, writing code, and formalizing proofs. Our models will help people develop understanding and pursue investigations they could not otherwise undertake. We will measure their value through reliable assistance, verifiable results, and the cost of sustained use.")

#heading(level: 1)[#text("Open Development")]

#text("Our models will have open licensed weights and code, published training methods, and reproducible evaluations. Training data will come with documented sources and compatible permissions, with limits on sharing stated clearly. Model releases will report failures and limitations alongside successes. Independent teams will be able to reproduce the work and adapt models to their own mathematical needs.")

#heading(level: 1)[#text("The Mathematical Community Owns the Data")]

#text("The mathematical community owns the data and decides how it is used. We will use users’ data to train or improve models only with their explicit consent, on terms agreed in advance. Researchers choose what to share and for what purposes.")

#heading(level: 1)[#text("Shared Intellectual Property")]

#text("Models, code, and tools developed through this initiative will be shared with the community under open licenses, for example Apache 2.0, MIT, or CC BY 4.0 where appropriate. Ownership, licensing, and attribution for jointly developed work should be agreed with contributors from the outset. Nevertheless, researchers retain ownership of their own independent and prior work which is shared with the initiative and receive credit for their mathematical ideas and results.")

#heading(level: 1)[#text("Open Community and Governance")]

#text("We welcome participation across institutions, regions, and career stages. The mathematical community should govern the initiative, setting priorities and deciding how shared resources are used. Governance rules and decisions will be public, with clear ways for members to propose changes, take part in decisions, and hold leaders accountable. While we will work with strategic industry partners to provide compute and other resources, it will be essential that these partnerships preserve the research independence of the community.")

#heading(level: 1)[#text("Join the Initiative")]

#text("We invite you to join SAIR Open Models and help make open models and affordable compute a shared foundation for mathematical research. We plan to make more detailed announcements on this initiative in the very near future: stay tuned!")

#text("Contact: ")#link("mailto:collaboration@sair.foundation")[#text("collaboration@sair.foundation")]

#text("You’re also welcome to join the discussion on SAIR Foundation Zulip:")#linebreak()#link("https://zulip.sair.foundation/#narrow/channel/27-Open-Math-Model")[#text("Join the discussion on Zulip")]

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695636")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I think you should license the code under the ")#link("https://www.gnu.org/licenses/agpl-3.0.en.html")[#text("AGPLv3")]#text(" rather than the Apache license.")

#text("Generally when the public pays for research is should get maximum rights in the fruits, and that militates in favour of releasing academic source code under permissive free software licenses such as the MIT and Apache licenses.")

#text("Here, however, when you are privately funded and when the AI industry is harrowing our field just for its advertizing purposes, I think strong free software licenses such as the GPL are the way to go.")

#text("The AGPL specifically is the right choice because LLMs are intended to be used remotely as a service, so we would need the provision that even providing access to the software remotely counts as distribution and requires releasing the source code.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695655")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I don’t think the AGPL is a good idea, because this is probably going to require cooperation from tech companies to make it work. Realistically, it will be too expensive to train or to host models of a comparable size to be near-frontier. You’ll need to be fine-tuning existing open models, and you’re going to want third-party companies to be able to host it as well. That means open enough that a private company can offer a service on it, and take a small fee to cover their expenses. The AGPL typically is incompatible with that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695891")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("The APGL (like the GPL) is entirely compatible with charging fees for access to computer programs — even charging fees for the computer programs themselves! For examples (now IBM-)Red Hat sells ")#link("https://www.redhat.com/en/technologies/linux-platforms/enterprise-linux")[#text("RHEL")]#text(" even though essentially the entire code base consists of GPL-licensed programs. In a different direction ")#link("https://moodle.com/services/certified-service-providers")[#text("many companies")]#text(" will sell Moodle to you (more precisely, the service of setting up the installation, connecting it to campus authentication and student/employee records systems, etc), even though Moodle is available for free.")

#text("I think you have things backwards: if LLM hosting costs are indeed an essential issue, then releasing the source code for a model is ")#emph[#text("less")]#text(" of a problem: any would-be competitor would not be able to offer the service for free just by having the model, because they would have hosting costs too. Observe that having the source code to Moodle doesn’t make running an LMS free, and indeed some universities have chosen to pay a for-profit company to host and adminsiter their Moodle instance.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695640")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("This model is the future.")

#text("The ideal is to protect intellectual property while enabling open collaboration. Existing infrastructure can move large datasets to advanced but closed cloud models and avoid AI scooping. A closed AI hosted in a data center with internet 2 access will stop the pilfering of academics’ work before they can receive credit and before their universities can protect their IP. While I strongly disagree that the velocity of the Navier-Stokes equation diverges, it is worrying that an AI company cannot determine whether its open model is based on proprietary work.")

#text("AI will become expensive, and offering students a free AI service hosted by a network of universities (priced into tuition) will let universities allow AI use but prevent the total cognitive surrender among students used as guinea pigs by big tech. AI wants to erode the university business model. I strongly believe that academia has the skills and endowments to outcompete unprofitable businesses. Universities have a moat and extremely skilled IP lawyers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695642")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I want to share here that the sci-hub people’s sci-bot elastic sparce encoder gets citations right, I cannot emphasize enough my amazement that people like Growers just completely excuse violation of academic standards that would get a student like me punished most definitely.")

#text("I want to thank Professor Tao for being such a sober and insightful soul and voice of reason in these psychotic times and providing overwhelmed and bewildered students like me some hope")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695650")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("What about using Chinese open model, such as Qwen 3.8 or Kimi K3")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695654")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I am all for open models, but you’re going to need a lot of money to run them.")

#text("Decent math models will almost certainly be frontier-level, multi-trillion parameter models. That’s a $300,000 setup just to run.")

#text("Perhaps we can figure out how to do math in a much smaller model. That would be my first project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695656")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("It’s going to be too expensive to run large models, so the best hope is to convince some third party like one of the Hugging Face Inference Providers to run it. If demand is high enough that would be possible. Then you don’t actually have to run this yourself.")

#text("Small models are cool but there’s billions of dollars of research already going into “how to make good small models” so I wouldn’t count on that getting solved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695659")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Internet 2 is funded through government research grants from the NSF, NASA, and NOAA. It is a secure network with high-speed data transfer, connected to cloud infrastructure to host AI models. Most importantly, it partners only with research institutions, and a committee of partners makes major decisions. The data remains secure, and AI could be offered to students for free as an educational tool rather than as a paid service to cheat their education. This benefits everyone by helping prevent college degrees from losing value.")

#text("A free service shifts user training to open-source AI that can be developed with safeguards, rather than using widespread unemployment and sci-fi armageddon as a business model to attract investors. Every university faces the same challenges. AI is devaluing education, appropriating their intellectual property, and making it harder for their recent graduates to find jobs. This is a systemic threat, and it’s in their best interest to work together to counter malicious AIs.")

#text("The ROI for every dollar spent lobbying the federal government is estimated to be around $700. I can spot you $500 to help you secure your $300k.")

#text("AI is losing money, and the companies building it believe they are locked into a winner take all race. They need an off-ramp.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695664")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Perhaps someone with contacts at OpenAI or Anthropic should see if they would be willing to distil a math-focused open model from their more advanced frontier models. Presumably this is child’s play for OpenAI and Anthropic, and it would be easier for the math community than trying to start from scratch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695674")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("This is a great idea. Some potential obstacles I see arising beyond what other commenters have said:")

#enum(start: 1, 
[#text("The frontier models were trained on vast amounts of data without consent. In fact, one can reasonably argue that models of that size can only exist without the consent of those who produce the data, due to the sheer logistic implausibility of asking for consent from everyone. What is the policy on that? And what about data where those who produced them can no longer consent?")],
[#text("US AI companies are likely to regard this as a threat (and had already started the process to shut down open models before this, at least in the US). Are you prepared for this?")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695675")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Will all the funders be public? I am glad to see the credit to XTX, but who are all the donors?")

#text("Will the board disclose their financial positions on tech companies, how much they have been paid, nonmonetary compensation, etc?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/640abcd14272f717cc9ed24a8e3176fb5f28b4c759d4c8b85f246d6821c54e5a-48ba211fd062688649bfd0f7963cd24b6b2059a1a9f55cb0bbd1a6af95aafaaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Starry Yu Zhang")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695685")[#strong[#text("Starry Yu Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("This initiative also seems to create an interesting opportunity to experiment with bounded AI agents in mathematical research.")

#text("In my PhD research on AI-mediated learning environments, I have been exploring an architecture in which different AI agents are bounded by different knowledge domains and interaction roles. I originally developed this as a way of structuring AI participation, but recent discussions around provenance have made me wonder whether boundedness could serve another purpose.")

#text("For example, mathematical agents might be bounded by particular knowledge sources, domains, or research functions. If their sources and interactions were logged, it might become easier to reconstruct which agent introduced an idea or method, what knowledge it drew upon, and how a mathematician subsequently accepted, rejected, questioned, or modified that contribution.")

#text("An open model initiative seems particularly well suited to testing this. One could compare general-purpose and bounded-agent architectures not only in terms of problem-solving performance, but also source traceability, contribution transparency, and whether the resulting interaction helps mathematicians reconstruct how an understanding developed.")

#text("I would be very interested to see what mathematicians themselves consider meaningful boundaries for such agents, since boundaries that improve traceability might also constrain useful connections across mathematical domains.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66d142b7d185f39fac1633330a138739d5662b65c6da90f0918ae9834df79457-5ca7ff8185d77fbbce6d3629a760b5865e45b1ddfd67c1649387c3ff4ddbde47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of friederrrr")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695745")[#strong[#text("friederrrr")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I should point out that there exists already one such initiative, the Fields Model Initiative (fieldsmodel.org), which has launched in July the first-ever fully open LLM ( training data, scripts, the “harness”, etc) that achieved a performance equivalent to a Bronze medal at the IMO26, with a talk given about it at the AITP26 (")#link("https://aitp-conference.org/2026")[#text("https://aitp-conference.org/2026")]#text(").")

#text("So what this post calls for already exists, at least in one form: a non-profit initiative doing much the same thing. That raises the question of whether duplicated efforts are worthwhile — possibly they are.")

#text("One important thing that is missing in the statement above on open development (“published training methods, and reproducible evaluations”) are checkpoints: E.g. Nvidia’s Nemoskill arguable may qualify under – but they do not publish checkpoints, and these are important in order to later build on the model: perhaps one may want an earlier checkpoint.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-695767")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Terry Is there evidence (strong ones) that AI solves problems (important and believed to be difficult ones) without 1) an ansatz or 2) a roughly defined prompting guidance?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/18/sairs-open-math-model-initiative/comment-page-1/#comment-696042")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("Human Insight + AI Exploration –> New Conjectures –> Proof –> Understanding –> More Knowledge")
]
