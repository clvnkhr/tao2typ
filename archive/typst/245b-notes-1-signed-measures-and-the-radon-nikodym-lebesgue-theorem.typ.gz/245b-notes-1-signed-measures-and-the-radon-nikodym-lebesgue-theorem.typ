// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:30.454940+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, notes 1: Signed measures and the Radon-Nikodym-Lebesgue theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("For these notes, ")#mi("X = (X, {\\mathcal X})")#text(" is a fixed ")#link("http://en.wikipedia.org/wiki/Measurable_space")[#text("measurable space")]#text(". We shall often omit the ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(", and simply refer to elements of ")#mi("{\\mathcal X}")#text(" as ")#emph[#text("measurable sets")]#text(". Unless otherwise indicated, all subsets of X appearing below are restricted to be measurable, and all functions on X appearing below are also restricted to be measurable.")

#text("We let ")#mi("{\\mathcal M}_+(X)")#text(" denote the space of ")#link("http://en.wikipedia.org/wiki/Measure_(mathematics)")[#text("measures")]#text(" on X, i.e. functions ")#mi("\\mu: {\\mathcal X} \\to [0,+\\infty]")#text(" which are countably additive and send ")#mi("\\emptyset")#text(" to 0. For reasons that will be clearer later, we shall refer to such measures as ")#emph[#text("unsigned")]#text(" measures. In this section we investigate the structure of this space, together with the closely related spaces of signed measures and finite measures.")

#text("Suppose that we have already constructed one unsigned measure ")#mi("m \\in {\\mathcal M}_+(X)")#text(" on X (e.g. think of X as the real line with the Borel ")#mi("\\sigma")#text("-algebra, and let m be Lebesgue measure). Then we can obtain many further unsigned measures on X by ")#emph[#text("multiplying")]#text(" m by a function ")#mi("f: X \\to [0,+\\infty]")#text(", to obtain a new unsigned measure ")#mi("m_f")#text(", defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("m_f(E) := \\int_X 1_E f\\ dm.")]]

#text("If ")#mi("f = 1_A")#text(" is an indicator function, we write ")#mi("m\\downharpoonright_A")#text(" for ")#mi("m_{1_A}")#text(", and refer to this measure as the ")#emph[#text("restriction")]#text(" of m to A.")

#strong[#text("Exercise 1.")]#text(" Show (using the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(") that ")#mi("m_f")#text(" is indeed a unsigned measure, and for any ")#mi("g: X \\to [0,+\\infty]")#text(", we have ")#mi("{}\\int_X g\\ dm_f = \\int_X gf\\ dm")#text(". We will express this relationship symbolically as")

#align(center)[#mi("dm_f = f dm")#text(".")#mi("\\diamond")#text(" (2)")]

#strong[#text("Exercise 2.")]#text(" Let m be ")#mi("\\sigma")#text("-finite. Given two functions ")#mi("f, g: X \\to [0,+\\infty]")#text(", show that ")#mi("m_f = m_g")#text(" if and only if ")#mi("f(x) = g(x)")#text(" for m-almost every x. (Hint: as usual, first do the case when m is finite. The key point is that if f and g are not equal m-almost everywhere, then either f>g on a set of positive measure, or f<g on a set of positive measure.) Give an example to show that this uniqueness statement can fail if m is not ")#mi("\\sigma")#text("-finite. (Hint: take a very simple example, e.g. let X consist of just one point.) ")#mi("\\diamond")

#text("In view of Exercises 1 and 2, let us temporarily call a measure ")#mi("\\mu")#text(" ")#emph[#text("differentiable")]#text(" with respect to m if ")#mi("d\\mu = f dm")#text(" (i.e. ")#mi("\\mu = m_f")#text(") for some ")#mi("f: X \\to [0,+\\infty]")#text(", and call f the ")#link("http://en.wikipedia.org/wiki/Radon-Nikodym_derivative")[#emph[#text("Radon-Nikodym derivative")]]#text(" of ")#mi("\\mu")#text(" with respect to m, writing")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f = \\frac{d\\mu}{dm};")]]

#text("by Exercise 2, we see if ")#mi("m")#text(" is ")#mi("\\sigma")#text("-finite that this derivative is defined up to m-almost everywhere equivalence.")

#strong[#text("Exercise 3. ")]#text(" (Relationship between Radon-Nikodym derivative and classical derivative) Let m be Lebesgue measure on ")#mi("{}[0,+\\infty)")#text(", and let ")#mi("\\mu")#text(" be an unsigned measure that is differentiable with respect to m. If ")#mi("\\mu")#text(" has a continuous Radon-Nikodym derivative ")#mi("\\frac{d\\mu}{dm}")#text(", show that the function ")#mi("x \\mapsto \\mu( [0,x])")#text(" is differentiable, and ")#mi("\\frac{d}{dx} \\mu([0,x]) = \\frac{d\\mu}{dm}(x)")#text(" for all x. ")#mi("\\diamond")

#strong[#text("Exercise 4.")]#text(" Let X be at most countable with the discrete sigma algebra. Show that every measure on X is differentiable with respect to counting measure ")#mi("\\#")#text(". ")#mi("\\diamond")

#text("If every measure was differentiable with respect to m (as is the case in Exercise 4), then we would have completely described the space of measures of X in terms of the non-negative functions of X (modulo m-almost everywhere equivalence). Unfortunately, not every measure is differentiable with respect to every other: for instance, if x is a point in X, then the only measures that are differentiable with respect to the Dirac measure ")#mi("\\delta_x")#text(" are the scalar multiples of that measure. We will explore the precise obstruction that prevents all measures from being differentiable, culminating in the ")#emph[#text("Radon-Nikodym-Lebesgue theorem")]#text(" that gives a satisfactory understanding of the situation in the ")#link("http://en.wikipedia.org/wiki/Sigma-finite")[#mi("\\sigma")#text("-finite")]#text(" case (which is the case of interest for most applications).")

#text("In order to establish this theorem, it will be important to first study some other basic operations on measures, notably the ability to ")#emph[#text("subtract")]#text(" one measure from another. This will necessitate the study of ")#emph[#text("signed")]#text(" measures, to which we now turn.")

#text("[The material here is largely based on Folland’s text, except for the last section.]")

#heading(level: 1)[#metadata(none) <tao-706093bf34bf04690157>#text("— Signed measures —")]

#text("We have seen that if we fix a reference measure m, then non-negative functions ")#mi("f: X \\to [0,+\\infty]")#text(" (modulo m-almost everywhere equivalence) can be identified with unsigned measures ")#mi("m_f: {\\mathcal X} \\to [0,+\\infty]")#text(". This motivates various operations on measures that are analogous to operations on functions (indeed, one could view measures as a kind of “generalised function” with respect to a fixed reference measure m). For instance, we can define the sum of two unsigned measures ")#mi("\\mu, \\nu: {\\mathcal X} \\to [0,+\\infty]")#text(" as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(\\mu+\\nu)(E) :=\\mu(E) + \\nu(E)")]]

#text("and non-negative scalar multiples ")#mi("c\\mu")#text(" for ")#mi("c \\geq 0")#text(" by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(c\\mu)(E) := c(\\mu(E)).")]]

#text("We can also say that one measure ")#mi("\\mu")#text(" is less than another ")#mi("\\nu")#text(" if")

#align(center)[#mi("\\mu(E) \\leq \\nu(E)")#text(" for all ")#mi("E \\in {\\mathcal X}")#text(". (6)")]

#text("These operations are all consistent with their functional counterparts, e.g. ")#mi("m_{f+g} = m_f + m_g")#text(", etc.")

#text("Next, we would like to define the difference ")#mi("\\mu-\\nu")#text(" of two unsigned measures. The obvious thing to do is to define")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(\\mu-\\nu)(E) := \\mu(E) - \\nu(E)")]]

#text("but we have a problem if ")#mi("\\mu(E)")#text(" and ")#mi("\\nu(E)")#text(" are both infinite: ")#mi("\\infty-\\infty")#text(" is undefined! To fix this problem, we will only define the difference of two unsigned measures ")#mi("\\mu,\\nu")#text(" if at least one of them is a finite measure. Observe that in that case, ")#mi("\\mu-\\nu")#text(" takes values in ")#mi("(-\\infty,+\\infty]")#text(" or ")#mi("{}[-\\infty,+\\infty)")#text(", but not both.")

#text("Of course, we no longer expect ")#mi("\\mu-\\nu")#text(" to be monotone. However, it is still finitely additive, and even countably additive in the sense that the sum ")#mi("\\sum_{n=1}^\\infty (\\mu-\\nu)(E_n)")#text(" converges to ")#mi("(\\mu-\\nu)(\\bigcup_{n=1}^\\infty E_n)")#text(" whenever ")#mi("E_1,E_2,\\ldots")#text(" are disjoint sets, and furthermore that the sum is absolutely convergent when ")#mi("(\\mu-\\nu)(\\bigcup_{n=1}^\\infty E_n)")#text(" is finite. This motivates")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Signed_measure")[#text("Signed measure")]#text(") A signed measure is a map ")#mi("\\mu: {\\mathcal X} \\to [-\\infty,+\\infty]")#text(" such that")

#enum(start: 1, 
[#mi("\\mu(\\emptyset) = 0")#text(";")],
[#mi("\\mu")#text(" can take either the value ")#mi("+\\infty")#text(" or ")#mi("-\\infty")#text(", but not both;")],
[#text("If ")#mi("E_1,E_2,\\ldots \\subset X")#text(" are disjoint, then ")#mi("\\sum_{n=1}^\\infty \\mu(E_n)")#text(" converges to ")#mi("\\mu( \\bigcup_{n=1}^\\infty E_n)")#text(", with the former sum being absolutely convergent if the latter expression is finite. [Actually, the absolute convergence is automatic from the ")#link("http://en.wikipedia.org/wiki/Riemann_series_theorem")[#text("Riemann rearrangement theorem")]#text(". Another consequence of 3. is that any subset of a finite measure set is again finite measure, and the finite union of finite measure sets again has finite measure.]")]
)
]

#text("Thus every unsigned measure is a signed measure, and the difference of two unsigned measures is a signed measure if at least one of the unsigned measures is finite; we will see shortly that the converse statement is also true, i.e. every signed measure is the difference of two unsigned measures (with one of the unsigned measures being finite). Another example of a signed measure are the measures ")#mi("m_f")#text(" defined by (1), where ")#mi("f: X \\to [-\\infty,+\\infty]")#text(" is now signed rather than unsigned, but with the assumption that at least one of the unsigned parts ")#mi("f_+ := \\max(f,0)")#text(", ")#mi("f_- := \\max(-f,0)")#text(" of f is absolutely integrable.")

#text("We also observe that a signed measure ")#mi("\\mu")#text(" is unsigned if and only if ")#mi("\\mu \\geq 0")#text(" (where we use (6) to define order on measures).")

#text("Given a function ")#mi("f: X \\to [-\\infty,+\\infty]")#text(", we can partition X into one set ")#mi("X_+ := \\{x: f(x) \\geq 0 \\}")#text(" on which f is non-negative, and another set ")#mi("X_- := \\{x: f(x) < 0\\}")#text(" on which f is negative; thus ")#mi("f\\downharpoonright_{X_+} \\geq 0")#text(" and ")#mi("f\\downharpoonright_{X_-} \\leq 0")#text(". It turns out that the same is true for signed measures:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Hahn_decomposition_theorem")[#text("Hahn decomposition theorem")]#text(") Let ")#mi("\\mu")#text(" be a signed measure. Then one can find a partition ")#mi("X = X_+ \\cup X_-")#text(" such that ")#mi("\\mu\\downharpoonright_{X_+} \\geq 0")#text(" and ")#mi("\\mu\\downharpoonright_{X_-} \\leq 0")#text(".")
]

#strong[#text("Proof. ")]#text("By replacing ")#mi("\\mu")#text(" with ")#mi("-\\mu")#text(" if necessary, we may assume that ")#mi("\\mu")#text(" avoids the value ")#mi("+\\infty")#text(".")

#text("Call a set E ")#emph[#text("totally positive")]#text(" if ")#mi("\\mu\\downharpoonright_E \\geq 0")#text(", and ")#emph[#text("totally negative")]#text(" if ")#mi("\\mu\\downharpoonright_E \\leq 0")#text(". The idea is to pick ")#mi("X_+")#text(" to be the totally positive set of maximal measure – a kind of “greedy algorithm”, if you will. More precisely, define ")#mi("m_+")#text(" to be the supremum of ")#mi("\\mu(E)")#text(", where E ranges over all totally positive sets. (The supremum is non-vacuous, since the empty set is totally positive.) We claim that the supremum is actually attained. Indeed, we can always find a maximising sequence ")#mi("E_1, E_2, \\ldots")#text(" of totally positive sets with ")#mi("\\mu(E_n) \\to m_+")#text(". It is not hard to see that the union ")#mi("X_+ := \\bigcup_{n=1}^\\infty E_n")#text(" is also totally positive, and ")#mi("\\mu(X_+) = m_+")#text(" as required. Since ")#mi("\\mu")#text(" avoids ")#mi("+\\infty")#text(", we see in particular that ")#mi("m_+")#text(" is finite.")

#text("Set ")#mi("X_- := X \\backslash X_+")#text(". We claim that ")#mi("X_-")#text(" is totally negative. We do this as follows. Suppose for contradiction that ")#mi("X_-")#text(" is not totally negative, then there exists a set ")#mi("E_1")#text(" in ")#mi("X_-")#text(" of strictly positive measure. If ")#mi("E_1")#text(" is totally positive, then ")#mi("X_+ \\cup E_1")#text(" is a totally positive set having measure strictly greater than ")#mi("m_+")#text(", a contradiction. Thus ")#mi("E_1")#text(" must contain a subset ")#mi("E_2")#text(" of strictly larger measure. Let us pick ")#mi("E_2")#text(" so that ")#mi("\\mu(E_2) \\geq \\mu(E_1) + 1/n_1")#text(", where ")#mi("n_1")#text(" is the smallest integer for which such an ")#mi("E_2")#text(" exists. If ")#mi("E_2")#text(" is totally positive, then we are again done, so we can find a subset ")#mi("E_3")#text(" with ")#mi("\\mu(E_3) \\geq \\mu(E_2) + 1/n_2")#text(", where ")#mi("n_2")#text(" is the smallest integer for whch such a ")#mi("E_3")#text(" exists. Continuing in this fashion, we either stop and get a contradiction, or obtain a nested sequence of sets ")#mi("E_1 \\supset E_2 \\supset \\ldots")#text(" in ")#mi("X_-")#text(" of increasing positive measure (with ")#mi("\\mu(E_{j+1}) \\geq \\mu(E_j) + 1/n_j")#text("). The intersection ")#mi("E := \\bigcap_j E_j")#text(" then also has positive measure, hence finite, which implies that the ")#mi("n_j")#text(" go to infinity; it is then not difficult to see that E itself cannot contain any subsets of strictly larger measure, and so E is a totally positive set of positive measure in ")#mi("X_-")#text(", and we again obtain a contradiction. ")#mi("\\Box")

#strong[#text("Remark 0.")]#text(" A somewhat simpler proof of the Hahn decomposition theorem is available if we assume ")#mi("\\mu")#text(" to be finite positive variation (which means that ")#mi("\\mu(E)")#text(" is bounded above as E varies). For each positive n, let ")#mi("E_n")#text(" be a set whose measure ")#mi("\\mu(E_n)")#text(" is within ")#mi("2^{-n}")#text(" of ")#mi("\\sup \\{ \\mu(E): E \\in {\\mathcal X} \\}")#text(". One can easily show that any subset of ")#mi("E_n \\backslash E_{n-1}")#text(" has measure ")#mi("O(2^{-n})")#text(", and in particular that ")#mi("E_n \\backslash \\bigcup_{n^{\\prime}=n_0}^{n-1} E_{n^{\\prime}}")#text(" has measure ")#mi("O(2^{-n})")#text(" for any ")#mi("n_0 \\leq n")#text(". This allows one to control the unions ")#mi("\\bigcup_{n=n_0}^\\infty E_n")#text(", and thence the lim sup ")#mi("X_+")#text(" of the ")#mi("E_n")#text(", which one can then show to have the required properties. One can in fact show that any signed measure that avoids ")#mi("+\\infty")#text(" must have finite positive variation, but this turns out to require a certain amount of work. ")#mi("\\diamond")

#text("Let us say that a set E is ")#emph[#text("null ")]#text("for a signed measure ")#mi("\\mu")#text(" if ")#mi("\\mu\\downharpoonright_E = 0")#text(". (This implies that ")#mi("\\mu(E)=0")#text(", but the converse is not true, since a set E of signed measure zero could contain subsets of non-zero measure.) It is easy to see that the sets ")#mi("X_-, X_+")#text(" given by the Hahn decomposition theorem are unique modulo null sets.")

#text("Let us say that a signed measure ")#mi("\\mu")#text(" is ")#emph[#text("supported")]#text(" on E if the complement of E is null (or equivalently, if ")#mi("\\mu\\downharpoonright_E = \\mu")#text(". If two signed measures ")#mi("\\mu, \\nu")#text(" can be supported on disjoint sets, we say that they are ")#link("http://en.wikipedia.org/wiki/Singular_measure")[#emph[#text("mutually singular")]]#text(" (or that ")#mi("\\mu")#text(" is ")#emph[#text("singular with respect to")]#text(" ")#mi("\\nu")#text(") and write ")#mi("\\mu \\perp \\nu")#text(". If we write ")#mi("\\mu_+ := \\mu\\downharpoonright_{X_+}")#text(" and ")#mi("\\mu_- := - \\mu \\downharpoonright_{X_-}")#text(", we thus soon establish")

#strong[#text("Exercise 5. ")]#text("(Jordan decomposition theorem) Every signed measure ")#mi("\\mu")#text(" can be uniquely decomposed as ")#mi("\\mu = \\mu_+ - \\mu_-")#text(", where ")#mi("\\mu_+, \\mu_-")#text(" are mutually singular unsigned measures. (The only claim not already established is the uniqueness.) We refer to ")#mi("\\mu_+, \\mu_-")#text(" as the ")#emph[#text("positive and negative parts ")]#text("(or ")#emph[#text("positive and negative variations")]#text(") of ")#mi("\\mu")#text(". ")#mi("\\diamond")

#text("This is of course analogous to the decomposition ")#mi("f = f_+ - f_-")#text(" of a function into positive and negative parts. Inspired by this, we define the ")#emph[#text("absolute value")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Total_variation")[#emph[#text("total variation")]]#text(") ")#tao-math("\\left|\\mu\\right|", block: false)#text(" of a signed measure to be ")#tao-math("\\left|\\mu\\right| := \\mu_+ + \\mu_-", block: false)#text(".")

#strong[#text("Exercise 6.")]#text(" Show that ")#tao-math("\\left|\\mu\\right|", block: false)#text(" is the minimal unsigned measure such that ")#tao-math("-\\left|\\mu\\right| \\leq \\mu \\leq \\left|\\mu\\right|", block: false)#text(". Furthermore, ")#tao-math("\\left|\\mu\\right|(E)", block: false)#text(" is equal to the maximum value of ")#tao-math("\\sum_{n=1}^\\infty \\left|\\mu(E_n)\\right|", block: false)#text(", where ")#mi("(E_n)_{n=1}^\\infty")#text(" ranges over the partitions of E. (This may help explain the terminology “total variation”.) ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Show that ")#mi("\\mu(E)")#text(" is finite for every E if and only if ")#tao-math("\\left|\\mu\\right|", block: false)#text(" is a finite unsigned measure, if and only if ")#mi("\\mu_+, \\mu_-")#text(" are finite unsigned measures. If any of these properties hold, we call ")#mi("\\mu")#text(" a ")#emph[#text("finite measure")]#text(". (In a similar spirit, we call a signed measure ")#mi("\\mu")#text(" ")#emph[#mi("\\sigma")#text("-finite")]#text(" if ")#tao-math("\\left|\\mu\\right|", block: false)#text(" is ")#mi("\\sigma")#text("-finite.) ")#mi("\\diamond")

#text("The space of finite measures on X is clearly a real vector space, and is denoted ")#mi("{\\mathcal M}(X)")#text(". (One can also complexify this space to obtain a complex vector space of complex finite measures, but we will not use such measures here.)")

#heading(level: 1)[#text("— The Lebesgue-Radon-Nikodym theorem —")]

#text("Let m be a reference unsigned measure. We saw in the introduction that the map ")#mi("f \\mapsto m_f")#text(" is an embedding of the space ")#mi("L^+(X,dm)")#text(" of non-negative functions (modulo m-almost everywhere equivalence) into the space ")#mi("{\\mathcal M}^+(X)")#text(" of unsigned measures. The same map is also an embedding of the space ")#mi("L^1(X,dm)")#text(" of absolutely integrable functions (again modulo m-almost everywhere equivalence) into the space ")#mi("{\\mathcal M}(X)")#text(" of finite measures. (To verify this, one first makes the easy observation that the Jordan decomposition of a measure ")#mi("m_f")#text(" given by an absolutely integrable function f is simply ")#mi("m_f = m_{f_+} - m_{f_-}")#text(".)")

#text("In the converse direction, one can ask if every finite measure ")#mi("\\mu")#text(" in ")#mi("{\\mathcal M}(X)")#text(" can be expressed as ")#mi("m_f")#text(" for some absolutely integrable f. Unfortunately, there are some obstructions to this. Firstly, from (1) we see that if ")#mi("\\mu = m_f")#text(", then any set that has measure zero with respect to ")#mi("m")#text(", must also have measure zero with respect to ")#mi("\\mu")#text(". In particular, this implies that a non-trivial measure that is singular with respect to m cannot be expressed in the form ")#mi("m_f")#text(".")

#text("In the ")#mi("\\sigma")#text("-finite case, this turns out to be the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (")#link("http://en.wikipedia.org/wiki/Lebesgue%27s_decomposition_theorem")[#text("Lebesgue")]#text("–")#link("http://en.wikipedia.org/wiki/Radon%E2%80%93Nikodym_theorem")[#text("Radon-Nikodym theorem")]#text(") Let m be an unsigned ")#mi("\\sigma")#text("-finite measure, and let ")#mi("\\mu")#text(" be a signed ")#mi("\\sigma")#text("-finite measure. Then there exists a unique decomposition ")#mi("\\mu = m_f + \\mu_s")#text(", where ")#mi("f: X \\to {\\bf R}")#text(" is measurable and ")#mi("\\mu_s \\perp m")#text(". If ")#mi("\\mu")#text(" is unsigned, then f and ")#mi("\\mu_s")#text(" are also. If ")#mi("\\mu")#text(" is finite, ")#mi("f")#text(" lies in ")#mi("L^1(X,dm)")#text(" and ")#mi("\\mu_s")#text(" is finite.")
]

#strong[#text("Proof. ")]#text(" We prove this only for the case when ")#mi("\\mu, m")#text(" are finite rather than ")#mi("\\sigma")#text("-finite, and leave the general case as an exercise. The uniqueness follows from Exercise 2 and the previous observation that ")#mi("m_f")#text(" cannot be mutually singular with m for any non-zero f, so it suffices to prove existence. By the Jordan decomposition theorem, we may assume that ")#mi("\\mu")#text(" is unsigned as well. (In this case, we expect f and ")#mi("\\mu_s")#text(" to be unsigned also.)")

#text("The idea is to select f “")#link("http://en.wikipedia.org/wiki/Greedy_algorithm")[#text("greedily")]#text("“. More precisely, let M be the supremum of the quantity ")#mi("\\int_X f\\ dm")#text(", where f ranges over all non-negative functions such that ")#mi("m_f \\leq \\mu")#text(". Since ")#mi("\\mu")#text(" is finite, M is finite. We claim that the supremum is actually attained for some f. Indeed, if we let ")#mi("f_n")#text(" be a maximising sequence, thus ")#mi("m_{f_n} \\leq \\mu")#text(" and ")#mi("\\int_X f_n\\ dm \\to M")#text(", one easily checks that the function ")#mi("f = \\sup_n f_n")#text(" attains the supremum.")

#text("The measure ")#mi("\\mu_s := \\mu - m_f")#text(" is a non-negative finite measure by construction. To finish the theorem, it suffices to show that ")#mi("\\mu_s \\perp m")#text(".")

#text("It will suffice to show that ")#mi("(\\mu_s - \\varepsilon m)_+ \\perp m")#text(" for all ")#mi("\\varepsilon")#text(", as the claim then easily follows by letting ")#mi("\\varepsilon")#text(" be a countable sequence going to zero. But if ")#mi("(\\mu_s - \\varepsilon m)_+")#text(" were not singular with respect to m, we see from the Hahn decomposition theorem that there is a set E with ")#mi("m(E)>0")#text(" such that ")#mi("(\\mu_s - \\varepsilon m)\\downharpoonright_E \\geq 0")#text(", and thus ")#mi("\\mu_s \\geq \\varepsilon m\\downharpoonright_E")#text(". But then one could add ")#mi("\\varepsilon 1_E")#text(" to f, contradicting the construction of f. ")#mi("\\Box")

#strong[#text("Exercise 8.")]#text(" Complete the proof of Theorem 2 for the ")#mi("\\sigma")#text("-finite case. ")#mi("\\diamond")

#text("We have the following corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Radon%E2%80%93Nikodym_theorem")[#text("Radon-Nikodym theorem")]#text(") Let m be an unsigned ")#mi("\\sigma")#text("-finite measure, and let ")#mi("\\mu")#text(" be a signed finite measure. Then the following are equivalent.")

#enum(start: 1, 
[#mi("\\mu = m_f")#text(" for some measurable ")#mi("f")#text(".")],
[#mi("\\mu(E)=0")#text(" whenever ")#mi("m(E)=0")#text(".")],
[#text("For every ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("\\delta > 0")#text(" such that ")#tao-math("\\left|\\mu(E)\\right| < \\varepsilon", block: false)#text(" whenever ")#mi("m(E) \\leq \\delta")#text(".")]
)

#text("When ")#mi("\\mu")#text(" is ")#mi("\\sigma")#text("-finite instead of finite, 1 and 2 are still equivalent.")

#text("When statement 1 or 2 (or 3, in the finite case) occurs, we say that ")#mi("\\mu")#text(" is ")#link("http://en.wikipedia.org/wiki/Absolute_continuity")[#emph[#text("absolutely continuous")]]#text(" with respect to m, and write ")#mi("\\mu \\ll m")#text(". As in the introduction, we call f the ")#emph[#text("Radon-Nikodym derivative")]#text(" of ")#mi("\\mu")#text(" with respect to m, and write ")#mi("f = \\frac{d\\mu}{dm}")#text(".")
]

#strong[#text("Proof. ")]#text("It suffices to establish the case when ")#mi("\\mu")#text(" is finite. The implication of 3. from 1. is Exercise 11 from ")#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("Notes 0")]#text(". The implication of 2. from 3. is trivial. To deduce 1. from 2., apply Theorem 2 to ")#mi("\\mu")#text(" and observe that ")#mi("\\mu_s")#text(" is supported on a set of m-measure zero E by hypothesis. Since E is null for m, it is null for ")#mi("m_f")#text(" and ")#mi("\\mu")#text(" also, and so ")#mi("\\mu_s")#text(" is trivial, giving 1. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" (Lebesgue decomposition theorem) Let m be an unsigned ")#mi("\\sigma")#text("-finite measure, and let ")#mi("\\mu")#text(" be a signed ")#mi("\\sigma")#text("-finite measure. Then there is a unique decomposition ")#mi("\\mu = \\mu_{ac} + \\mu_s")#text(", where ")#mi("\\mu_{ac} \\ll m")#text(" and ")#mi("\\mu_s \\perp m")#text(". (We refer to ")#mi("\\mu_{ac}")#text(" and ")#mi("\\mu_s")#text(" as the ")#emph[#text("absolutely continuous")]#text(" and ")#emph[#text("singular components")]#text(" of ")#mi("\\mu")#text(" with respect to m.) If ")#mi("\\mu")#text(" is unsigned, then ")#mi("\\mu_{ac}")#text(" and ")#mi("\\mu_s")#text(" are also.")
]

#strong[#text("Exercise 9.")]#text(" If every point in X is measurable, we call a signed measure ")#mi("\\mu")#text(" ")#emph[#text("continuous")]#text(" if ")#mi("\\mu(\\{x\\})=0")#text(" for all x. Let the hypotheses be as in Corollary 2, but suppose also that every point is measurable and m is continuous. Show that there is a unique decomposition ")#mi("\\mu = \\mu_{ac} + \\mu_{sc} + \\mu_{pp}")#text(", where ")#mi("\\mu_{ac} \\ll m")#text(", ")#mi("\\mu_{pp}")#text(" is supported on an at most countable set, and ")#mi("\\mu_{sc}")#text(" is both singular with respect to m and continuous. Furthermore, if ")#mi("\\mu")#text(" is unsigned, then ")#mi("\\mu_{ac}, \\mu_{sc}, \\mu_{pp}")#text(" are also. We call ")#mi("\\mu_{sc}")#text(" and ")#mi("\\mu_{pp}")#text(" the ")#emph[#text("singular continuous ")]#text("and ")#emph[#text("pure point")]#text(" components of ")#mi("\\mu")#text(" respectively. ")#mi("\\diamond")

#strong[#text("Example 1.")]#text(" A ")#link("http://en.wikipedia.org/wiki/Cantor_measure")[#text("Cantor measure")]#text(" is singular continuous with respect to Lebesgue measure, while Dirac measures are pure point. Lebesgue measure on a line is singular continuous with respect to Lebesgue measure on a plane containing that line. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" Suppose one is decomposing a measure ")#mi("\\mu")#text(" on a Euclidean space ")#mi("{\\Bbb R}^d")#text(" with respect to Lebesgue measure m on that space. Very roughly speaking, a measure is pure point if it is supported on a 0-dimensional subset of ")#mi("{\\Bbb R}^d")#text(", it is absolutely continuous if its support is spread out on a full dimensional subset, and is singular continuous if it is supported on some set of dimension intermediate between 0 and d. For instance, if ")#mi("\\mu")#text(" is the sum of a Dirac mass at ")#mi("(0,0) \\in {\\Bbb R}^2")#text(", one-dimensional Lebesgue measure on the x-axis, and two-dimensional Lebesgue measure on ")#mi("{\\Bbb R}^2")#text(", then these are the pure point, singular continuous, and absolutely continuous components of ")#mi("\\mu")#text(" respectively. This heuristic is not completely accurate (in part because I have left the definition of “dimension” vague) but is not a bad rule of thumb for a first approximation. ")#mi("\\diamond")

#text("To motivate the terminology “continuous” and “absolutely continuous”, we recall two definitions on an interval ")#mi("I \\subset {\\Bbb R}")#text(", and make a third:")

#enum(start: 1, 
[#text("A function ")#mi("f: I \\to {\\Bbb R}")#text(" is ")#emph[#text("continuous")]#text(" if for every ")#mi("x \\in I")#text(" and every ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("\\delta > 0")#text(" such that ")#tao-math("\\left|f(y)-f(x)\\right| \\leq \\varepsilon", block: false)#text(" whenever ")#mi("y \\in I")#text(" is such that ")#tao-math("\\left|y-x\\right| \\leq \\delta", block: false)#text(".")],
[#text("A function ")#mi("f: I \\to {\\Bbb R}")#text(" is ")#link("http://en.wikipedia.org/wiki/Uniformly_continuous")[#emph[#text("uniformly continuous")]]#text(" if for every ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("\\delta > 0")#text(" such that ")#tao-math("\\left|f(y)-f(x)\\right| \\leq \\varepsilon", block: false)#text(" whenever ")#mi("{}[x, y] \\subset I")#text(" has length at most ")#mi("\\delta")#text(".")],
[#text("A function ")#mi("f: I \\to {\\Bbb R}")#text(" is ")#link("http://en.wikipedia.org/wiki/Absolutely_continuous")[#emph[#text("absolutely continuous")]]#text(" if for every ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("\\delta > 0")#text(" such that ")#tao-math("\\sum_{i=1}^n \\left|f(y_i)-f(x_i)\\right| \\leq \\varepsilon", block: false)#text(" whenever ")#mi("{}[x_1,y_1],\\ldots,{}[x_n,y_n]")#text(" are disjoint intervals in I of total length at most ")#mi("\\delta")#text(".")]
)

#text("Clearly, absolute continuity implies uniform continuity, which in turn implies continuity. The significance of absolute continuity is that it is the largest class of functions for which the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_calculus")[#text("fundamental theorem of calculus")]#text(" holds (using the classical derivative, and the Lebesgue integral), as was shown in the previous course.")

#strong[#text("Exercise 10. ")]#text("Let m be Lebesgue measure on the interval ")#mi("{}[0,+\\infty]")#text(", and let ")#mi("\\mu")#text(" be a finite unsigned measure.")

#enum(start: 1, 
[#text("Show that ")#mi("\\mu")#text(" is a continuous measure if and only if the function ")#mi("x \\mapsto \\mu([0,x])")#text(" is continuous.")],
[#text("Show that ")#mi("\\mu")#text(" is an absolutely continuous measure with respect to m if and only if the function ")#mi("x \\mapsto \\mu([0,x])")#text(" is absolutely continuous. ")#mi("\\diamond")]
)

#heading(level: 1)[#text("— A finitary analogue of the Lebesgue decomposition (optional) —")]

#text("At first glance, the above theory is only non-trivial when the underlying set X is infinite. For instance, if X is finite, and m is the uniform distribution on X, then every other measure on X will be absolutely continuous with respect to m, making the Lebesgue decomposition trivial. Nevertheless, there is a non-trivial version of the above theory that can be applied to finite sets (cf. my blog post on the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("relationship between soft analysis and hard analysis")]#text("). The cleanest formulation is to apply it to a sequence of (increasingly large) sets, rather than to a single set:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (Finitary analogue of the Lebesgue-Radon-Nikodym theorem) Let ")#mi("X_n")#text(" be a sequence of finite sets (and with the discrete ")#mi("\\sigma")#text("-algebra), and for each n, let ")#mi("m_n")#text(" be the uniform distribution on ")#mi("X_n")#text(", and let ")#mi("\\mu_n")#text(" be another probability measure on ")#mi("X_n")#text(". Then, after passing to a subsequence, one has a decomposition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mu_n = \\mu_{n,ac} + \\mu_{n,sc} + \\mu_{n,pp}")]]

#text("where")

#enum(start: 1, 
[#text("(Uniform absolute continuity) For every ")#mi("\\varepsilon > 0")#text(", there exists ")#mi("\\delta > 0")#text(" (independent of n) such that ")#mi("\\mu_{n,ac}(E) \\leq \\varepsilon")#text(" whenever ")#mi("m_n(E) \\leq \\delta")#text(", for all n and all ")#mi("E \\subset X_n")#text(".")],
[#text("(Asymptotic singular continuity) ")#mi("\\mu_{n,sc}")#text(" is supported on a set of ")#mi("m_n")#text("-measure ")#mi("o(1)")#text(", and we have ")#mi("\\mu_{n,sc}(\\{x\\}) = o(1)")#text(" uniformly for all ")#mi("x \\in X_n")#text(", where ")#mi("o(1)")#text(" denotes an error that goes to zero as ")#mi("n \\to \\infty")#text(".")],
[#text("(Uniform pure point) For every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("N > 0")#text(" (independent of n) such that for each n, there exists a set ")#mi("E_n \\subset X_n")#text(" of cardinality at most N such that ")#mi("\\mu_{n,pp}(X_n \\backslash E_n) \\leq \\varepsilon")#text(".")]
)
]

#strong[#text("Proof. ")]#text(" Using the Radon-Nikodym theorem (or just working by hand, since everything is finite), we can write ")#mi("d\\mu_n = f_n\\ dm_n")#text(" for some ")#mi("f_n: X_n \\to [0,+\\infty)")#text(" with average value 1.")

#text("For each positive integer k, the sequence ")#mi("\\mu_n( \\{ f_n \\geq k \\} )")#text(" is bounded between 0 and 1, so by the ")#link("http://en.wikipedia.org/wiki/Bolzano-Weierstrass_theorem")[#text("Bolzano-Weierstrass theorem")]#text(", it has a convergent subsequence. Applying the usual diagonalisation argument (as in the proof of the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelà-Ascoli theorem")]#text("), we may thus assume (after passing to a subsequence, and relabeling) that ")#mi("\\mu_n( \\{ f_n \\geq k \\} )")#text(" converges for positive k to some limit ")#mi("c_k")#text(".")

#text("Clearly, the ")#mi("c_k")#text(" are decreasing and range between 0 and 1, and so converge as ")#mi("k \\to \\infty")#text(" to some limit ")#mi("0 < c < 1")#text(".")

#text("Since ")#mi("\\lim_{k \\to \\infty} \\lim_{n \\to \\infty} \\mu_n(\\{f_n \\geq k \\}) = c")#text(", we can find a sequence ")#mi("k_n")#text(" going to infinity such that ")#mi("\\mu_n( \\{f_n \\geq k_n\\} ) \\to c")#text(" as ")#mi("n \\to \\infty")#text(". We now set ")#mi("\\mu_{n,ac}")#text(" to be the restriction of ")#mi("\\mu_n")#text(" to the set ")#mi("\\{f_n < k_n\\}")#text(". We claim the absolute continuity property 1. Indeed, for any ")#mi("\\varepsilon > 0")#text(", we can find a k such that ")#mi("c_k \\leq c + \\varepsilon/10")#text(". For n sufficiently large, we thus have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\mu_n(\\{f_n \\geq k \\}) \\leq c + \\varepsilon/5")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\mu_n(\\{f_n \\geq k_n \\}) \\geq c - \\varepsilon/5")]]

#text("and hence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\mu_{n,ac}( \\{ f_n \\geq k \\} ) \\leq 2 \\varepsilon / 5.")]]

#text("If we take ")#mi("\\delta < \\varepsilon / 5k")#text(", we thus see (for n sufficiently large) that 1. holds. (For the remaining n, one simply shrinks delta as much as is necessary.)")

#text("Write ")#mi("\\mu_{n,s} := \\mu_n - \\mu_{n,ac}")#text(", thus ")#mi("\\mu_{n,s}")#text(" is supported on a set of size ")#tao-math("\\left|X_n\\right|/K_n = o(\\left|X_n\\right|)", block: false)#text(" by ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text(". It remains to extract out the pure point components. This we do by a similar procedure as above. Indeed, by arguing as before we may assume (after passing to a subsequence as necessary) that the quantities ")#mi("\\mu_n \\{ x: \\mu_n(\\{x\\}) \\geq 1/j \\}")#text(" converge to a limit ")#mi("d_j")#text(" for each positive integer j, that the ")#mi("d_j")#text(" themselves converge to a limit d, and that there exists a sequence ")#mi("j_n \\to \\infty")#text(" such that ")#mi("\\mu_n \\{ x: \\mu_n(\\{x\\}) \\geq 1/j_n \\}")#text(" converges to d. If one sets ")#mi("\\mu_{sc}")#text(" and ")#mi("\\mu_{pp}")#text(" to be the restrictions of ")#mi("\\mu_s")#text(" to the sets ")#mi("\\{ x: \\mu_n(\\{x\\}) < 1/j_n \\}")#text(" and ")#mi("\\{ x: \\mu_n(\\{x\\}) \\geq 1/j_n \\}")#text(" respectively, one can verify the remaining claims by arguments similar to those already given. ")#mi("\\Box")

#strong[#text("Exercise 11.")]#text(" Generalise Theorem 3 to the setting where the ")#mi("X_n")#text(" can be infinite and non-discrete (but we still require every point to be measurable), the ")#mi("m_n")#text(" are arbitrary probability measures, and the ")#mi("\\mu_n")#text(" are arbitrary finite measures of uniformly bounded total variation. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" This result is still not fully “finitary” because it deals with a sequence of finite structures, rather than with a single finite structure. It appears in fact to be quite difficult (and perhaps even impossible) to make a fully finitary version of the Lebesgue decomposition (in the same way that the finite convergence principle in ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this blog post of mine ")]#text("was a fully finitary analogue of the infinite convergence principle), though one can certainly form some weaker finitary statements that capture a portion of the strength of this theorem. For instance, one very cheap thing to do, given two probability measures ")#mi("\\mu, m")#text(", is to introduce a threshold parameter k, and partition ")#mi("\\mu = \\mu_{\\leq k} + \\mu_{>k}")#text(", where ")#mi("\\mu_{\\leq k} \\leq k m")#text(", and ")#mi("\\mu_{>k}")#text(" is supported on a set of m-measure at most ")#mi("1/k")#text("; such a decomposition is automatic from Theorem 2 and Markov’s inequality, and has meaningful content even when the underlying space X is finite, but this type of decomposition is not as powerful as the full Lebesgue decompositions (mainly because the size of the support for ")#mi("\\mu_{>k}")#text(" is relatively large compared to the threshold k). Using the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("finite convergence principle")]#text(", one can do a bit better, writing ")#mi("\\mu = \\mu_{\\leq k} + \\mu_{k < \\cdot \\leq F(k)} + \\mu_{\\geq F(k)}")#text(" for any function F and any ")#mi("\\varepsilon > 0")#text(", where ")#mi("k = O_{F,\\varepsilon}(1)")#text(", ")#mi("\\mu_{\\leq k} \\leq k m")#text(", ")#mi("\\mu_{\\geq F(k)}")#text(" is supported on a set of m-measure at most ")#mi("1/F(k)")#text(", and ")#mi("\\mu_{k < \\cdot \\leq F(k)}")#text(" has total mass at most ")#mi("\\varepsilon")#text(", but this is still fails to capture the full strength of the infinitary decomposition, because ")#mi("\\varepsilon")#text(" needs to be fixed in advance. I have not been able to find a fully finitary statement that is equivalent to, say, Theorem 3; I suspect that if it does exist, it will have quite a messy formulation. ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 5: Exercise added.]")

#text("[")#emph[#text("Update")]#text(", Jan 7: Proof of Hahn decomposition theorem altered; my original proof works, but one of the steps was much trickier than I had anticipated, so I am reverting to Folland’s proof.]")

#heading(level: 1)[#text("Comments (102)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-641528")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#emph[#text("Unfortunately, not every measure is differentiable with respect to every other: for instance, if x is a point in X, then the only measures that are differentiable with respect to the Dirac measure ")#mi("\\delta_x")#text(" are the scalar multiples of that measure.")]

#text("This remark in the notes may be changed to an exercise right after Exercise 4, which makes the Dirac measure a sharp contrast to the counting measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-641530")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("In the proof of Theorem 1:")#linebreak()#text(" ")#emph[#linebreak()#text(" Indeed, we can always find a maximising sequence ")#mi("E_1, E_2, \\ldots")#text(" of totally positive sets with ")#mi("\\mu(E_n) \\to m_+")#text(". It is not hard to see that the union ")#mi("X_+ := \\bigcup_{n=1}^\\infty E_n")#text(" is also totally positive, and ")#mi("\\mu(X_+) = m_+")#text(" as required. Since ")#mi("\\mu")#text(" avoids ")#mi("+\\infty")#text(", we see in particular that ")#mi("m_+")#text(" is finite.")#linebreak()#text(" ")]

#text("In the last sentence, how does ")#mi("\\mu")#text(" avoid ")#mi("+\\infty")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-641539")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("This reduction was obtained in the first sentence of the proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f14207c9ef7b129a7220b9138f1cd4cae31f541d3d39f9650fc81548183b67e7-9fd4cbe08a682c68b90783b9e709e1653106b3c11cabc08f03ba6ed027626c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-641580")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")])]

#text("1.")#linebreak()#text(" In (5), to be consistent, one either has “")#emph[#text("positive")]#text(" scalar multiples ")#mi("c\\mu")#text(" for ")#mi("c> 0")#text("” or “non-negative scalar multiples … for ")#mi("c\\ge 0")#text("“.")

#text("2. It may be worth making a remark/exercise to mention complex measures. In 245A, one mostly deals with complex-valued functions ")#mi("f:X\\to{\\Bbb C}")#text(". Also, ")#mi("L^p")#text(" spaces are defined in notes 3, where one again uses complex-valued functions. The space ")#mi("L^1(X,dm)")#text(" in the first paragraph under the title “The Lebesgue-Radon-Nikodym theorem”, however, consists of only real-valued functions. The measurable function ")#mi("f")#text(" in Theorem 2 and Corollary 1 is also real-valued.")

#text("3.")#linebreak()#text(" ")#emph[#linebreak()#text(" To motivate the terminology “continuous” and “singular continuous”, we recall two definitions on an interval ")#mi("I \\subset {\\Bbb R}")#text(", and make a third: …")#linebreak()#text(" ")]

#text("The following discussion seems to be more about “absolutely continuous” instead of “singular continuous”. Typo?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-641637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("Typo in the proof of Theorem 2:")

#emph[#linebreak()#text(" We prove this only for the case when ")#mi("\\mu")#text(", ")#mi("\\nu")#text(" are finite rather than ")#mi("\\sigma")#text("-finite, and leave the general case as an exercise.")#linebreak()#text(" ")]

#mi("\\nu")#text(" is supposed to be ")#mi("m")#text(". Or maybe you wanted to reserve ")#mi("m")#text(" for the Lebesgue measure in the notes.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b47109b4dcbc009635bba11efd9f3eedb5496913d6315522a9edc71c49baf0f-26b0a3642880e9c9b50e61e07a2e385e6bc9ac103a91d918e7b60c9feb1bff19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dingjun Bian")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-645082")[#strong[#text("Dingjun Bian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2022")])]

#text("In the proof of Corollary 1 when deducing 1 from 2, did you meant quoting Theorem 2 instead of Theorem 1? Thank you.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-645202")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2022")])]

#text("Prof. Tao when you refer to Folland’s text do you mean his book titled “Real analysis: Modern Techniques and Their Applications” ?")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-645211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2022")])]

#text("yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-645207")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2022")])]

#text("Prof. Tao in Exercise 2 is this the right way:")#linebreak()#text(" as you mention if f and g do not agree ")#mi("m")#text(" almost everywhere, then either ")#mi("\\{ x : f(x) > g(x) \\}")#text(" or ")#mi("\\{x : f(x)  g(x) \\} ) >0")#text(" then there is some ")#mi("\\varepsilon > 0")#text(" such that with ")#mi("E := \\{ x : f(x) > g(x) + \\varepsilon \\}")#text(" one has ")#mi("m(E) > 0")#text(" (otherwise take a sequence of positive reals ")#mi("\\varepsilon")#text(" which converges to 0 and use countable additivity to get a contradiction). Now take a covering of ")#mi("X")#text(" with measurable subsets of ")#mi("X")#text(" where each covering part has a finite ")#mi("m")#text(" measure, then intersecting this covering parts with ")#mi("E")#text(" it follows that ")#mi("m_g (A) < m_f (A)")#text(" for some measurable ")#mi("A \\subseteq X")#text(" with ")#mi("m(A) < \\infty,")#text(" but this gives a contradiction.")

#text("Note: we required ")#mi("m(A)  g+ \\varepsilon \\implies \\int_A f d m > \\int_A g dm")#text(" which is of course not true in general if ")#mi("m (A)")#text(" is infinite.")

#text("This gives us a recipe to construct counterexamples as asked for in the second part of the exercise.")#linebreak()#text(" Just notice that (as you suggest) if ")#mi("X = \\{1 \\}")#text(" and if ")#mi("m (\\emptyset) = 0 , m ( \\{ 1 \\} ) = \\infty")#text(" then for any non-negative extended real valued function ")#mi("f")#text(" defined on ")#mi("X")#text(" one has ")#mi("m_f (X) = \\infty , m_f (\\emptyset ) = 0.")

#text("Is this correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2025")])]

#text("Dear professor Tao:")

#text("Below definition 1, “at least one of the signed parts ” should be “at least one of the unsigned parts “.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dear professor Tao:")

#text("In Theorem 1, do we conclude that E has positive measure from downward monotone convergence?")

#emph[#text("[No, as the measure is signed, this tool is unavailable. Instead, we use property 3 of a signed measure in various ways.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dear professor Tao:")

#text("As the proof of continuity from above seems to rely only on countable additivity and the finite measure hypothesis, which are both present in our setting, I wonder why the tool fails for signed measures? In Follands text he directly claims that the measure of the intersection is the limit of the measures. Do you mean that this conclusion was arrived through property 3 instead?")

#emph[#text("[We only have one-sided finiteness in the current situation, although it is not difficult to reduce to the finite case for this specific calculation, in which case I guess one could proceed by developing a form of the monotone convergence theorem in this setting, though that is basically the same argument as the one I just outlined when one unpacks the proof of that theorem -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("The sets ")#mi("E_j")#text(" in the intersection are all of strictly positive measure, and we avoid the positive infinity case, so I assume the reduction is automatic by construction?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689319")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Dear professor Tao:")

#text("In Remark 0, ")#mi("E_n\\backslash \\bigcup_{n^{\\prime} = n_0}^{n-1} E_{n-1}")#text(" should be ")#mi("E_n \\backslash \\bigcup_{n^{\\prime} = n_0}^{n-1} E_{n^{\\prime}}")#text(". And in Exercise 5, an be should be can be.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Dear professor Tao:")

#text("In Remark 0, when you talk about controlling the limsup ")#mi("X_+")#text(" of the ")#mi("E_n")#text(", do you mean that we can actually show that its measure attains the sup of the measures, or simply that it has finite measure?")

#emph[#text("[In analysis, the verb “control” is not precisely defined, but generally refers to bounding, estimating, or otherwise constraining the behavior of a quantity. (Though in control theory, this verb has a more precise technical definition.) -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689324")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Dear professor Tao:")

#text("A follow-up on Remark 0: It is relevant that we can take the absolute constants in the big-O estimates to be the same (2 in this case) across n for the argument here to work, is it not?")

#emph[#text("[I don’t think so, since one can always increase these constants to make them match if desired. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Dear professor Tao:")

#text("May I ask how non-uniformity is not an issue here? For otherwise we are making countably many choices of ")#mi("C_n")#text(", one for each ")#mi("n > n_0")#text(".")

#emph[#text("[Unless otherwise specified, implicit constants are understood to be uniform in parameters such as ")#mi("n")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689330")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Dear professor Tao:")

#text("I might have misunderstood your previous comment: “since one can always increase these constants to make them match”, which I took as suggesting the implicit constants need not be uniform in ")#mi("n")#text(", since we can increase them to make all matched.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689334")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Ah, I understand your question now; I thought you were asking whether it was important whether the 2 separate uses of the O() notation in Remark 0 had to match each other (it is not), but it is important that the constant in the O() notations here are uniform (or at least uniformly bounded) in n.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689411")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Dear professor Tao:")

#text("Since complex measure is not yet defined, do we take f in the section of the Lebesgue-Radon-Nikodym theorem to be real-valued throughout?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689425")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Dear professor Tao:")

#text("In Theorem 2, should we add the assumption on f that at least one of its unsigned part is absolutely integrable?")

#emph[#text("[This is implicit, since ")#mi("m_f")#text(" is not defined otherwise – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689432")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2025")])]

#text("Dear professor Tao:")

#text("For Exercise 8, if one lets ")#mi("f = \\sum_n f_n")#text(" where ")#mi("f_n")#text(" are the absolutely integrable functions in the finite measure case, how do we make sure that ")#mi("m_f")#text(" is well-defined?")

#emph[#text("[One has to use the finiteness of either the positive or negative variation of ")#mi("\\mu")#text(" to constrain the corresponding variations of ")#mi("f")#text(" and ")#mi("f_n")#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("Dear professor Tao:")

#text("Is the sequence of finite sets ")#mi("X_n")#text(" in Theorem 3 assumed to be increasing?")

#emph[#text("[No – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689482")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2025")])]

#text("Dear professor Tao:")

#text("“absolute continuithy” should be “absolute continuity” in the proof of Theorem 3. Also, I don’t quiet see how (12) follows from (10) and (11), for large ")#mi("n")#text(", ")#mi("k_n")#text(" exceeds ")#mi("k")#text(", I then get a lower bound rather than an upper bound.")

#emph[#text("[There were some sign errors in the text, now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689507")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2025")])]

#text("Dear professor Tao:")

#text("Can you provide a little hint on Exercise 11 as well?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-689529")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2025")])]

#text("Dear professor Tao:")

#text("In Exercise 11 one no longer works in the finite space regime with uniform distribution, so the trivial decomposition is unattainable, do we perform the same argument on $mu_{n, ac}$ instead? What would be the desired direction of generalization? (In particular, how should one go about thinking about a generalization-type problem), thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-692632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2026")])]

#text("Dear Prof. Tao,")

#text("In this note, the first two theorems Theorem 1 and Theorem 2, both theorems employ ")#emph[#text("greedy algorithms")]#text(". It seems the intention behind choosing a greedy algorithm is to improve some object, hoping it will possess better properties (I am not so sure, this is my understanding). And if I understand it correctly, even the ")#emph[#text("Hahn-Banach Theorem")]#text(" could be proved by greedy algorithm. So I’m puzzled——what types of problems or theorems are most suitable for being proved using greedy algorithms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-692642")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2026")])]

#text("I am ")#link("https://claude.ai/share/6132a090-222a-434e-9803-2de85c687192")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("Dear Professor Tao:")

#text("Could we regard Corollary 2 as a special case of the dichotomy between structure and randomness? Also, I would like to ask: Can doing so provide some illuminating insights or heuristics into the proof or applications of Corollary 2 in analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("Yes; this is particularly visible in the ergodic theory setting, where for instance the Kronecker factor (one of the most structured components of a measure-preserving system) corresponds to the portion of the spectral measure coming from the pure point component (the eigenfunctions). A similar splitting is also seen in the soliton resolution of solutions to completely integrable equations such as PDE, where the solitons again correspond to the pure point components of a certain spectral measure, while the radiation corresponds to the continuous portion (a nonlinear version of the Riemann-Lebesgue lemma).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693305")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Thank you for your patient reply. I’m still wondering whether, for the proof of the Lebesgue decomposition theorem itself, there is a proof that corresponds to the structural versus randomness dichotomy. For example, the blog post uses a greedy algorithm to establish the Lebesgue-Radon-Nikodym theorem, and then derives the Lebesgue decomposition theorem from it. Alternatively, we could use projections between Hilbert spaces to obtain the absolutely continuous part of μ. Can these arguments, to some extent, also reflect this dichotomy between structure and randomness?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693310")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Greedy algorithms are already akin to many structure-randomness algorithms, as are arguments based in the existence of orthogonal projections (which one can think of as the infinitary end state of an “energy increment argument”). The parallels are easiest to see in the nonstandard analysis formalism; see for instance ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")]#text(" for a nonstandard analysis proof of the Szemeredi regularity lemma based on orthogonal projection. The post ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")]#text(" compares many of these methods in the context of the ergodic theorem, which is perhaps one of the simplest structure-randomness decompositions (this one corresponding to the U^1 Gowers-Host-Kra seminorm).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693461")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("When specializing to the case of signed ")#emph[#text("probability")]#text(" measures, I have seen authors impose normalization by either (a) requiring |")#emph[#text("m")]#text("|(")#emph[#text("X")]#text(") = 1 or (b) requiring ")#emph[#text("m")]#text("(")#emph[#text("X+")]#text(") = 1 = – ")#emph[#text("m")]#text("(")#emph[#text("X")]#text("-).")

#text("Is one of (a) or (b) more stable, well-behaved, or theoretically grounded than the other? Or are these just equally valid choices to be made on the basis of preference, setting, and/or application?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693464")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("It seems like (b) would be the natural normalization for mean-zero signed measures, while (a) would be the natural normaliation for signed measures that are not required to be of mean zero. But often the precise normalization is not too relevant; the important thing often is that the normalization either creates some sort of compactness (e.g., from Prokhorov’s theorem) or manages to quotient out a symmetry (in this case, homogeneity symmetry).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("I hope I understood you correctly—by “quotienting out a symmetry,” you mean spending a symmetry. But I don’t understand, why can normalization create some sort of compactness?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-2/#comment-693468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2026")])]

#text("A concrete example: a non-zero complex number ")#mi("z")#text(" takes values in the non-compact space ")#mi("{\\mathbb C} \\backslash \\{0\\}")#text(". But, if there is a homogeneity symmetry ")#mi("z \\mapsto \\lambda z")#text(", ")#mi("\\lambda > 0")#text(" present, then one can normalize this complex number to have unit magnitude: ")#tao-math("\\left|z\\right| = 1", block: false)#text(". The range is now the unit circle, which is compact. (Not coincidentally, the moduli space ")#mi("{\\mathbb C} \\backslash \\{0\\} / {\\mathbb R}^+")#text(" of non-zero complex numbers modulo homogeneity symmetry is also compact, and is in fact homeomorphic to the unit circle as per the indicated normalization.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34685")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2009")])]

#text("Dear Professor Tao:")

#text("Here are several typos,")

#text("1, In exercise 1, ")#mi("\\int_X g\\ dm_f = \\int_X gf\\ d\\mu")#text(" should be ")#mi("\\int_X g\\ dm_f = \\int_X gf\\ d m")#text(".")

#text("2, In Theorem 1, there is a “latex” missing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-520289")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("Typos 1 is still as before.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("For the function f in the statement of Theorem 2 to be in L^1, one needs to")#linebreak()#text(" assume that \\mu is finite. Similarly for the implication of 3. from 2. in Corollary 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34719")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("Dear Professor:")

#text("The existence of conditional expectation comes from R-N derivative, which I think is worth mentioning, as an exercise or something. ( maybe you have other plans. :-))")

#text("Thanks for the last theorem! I spent several hours to go over your previous post on soft analysis and hard analysis and learned a lot, again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34722")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("And two more corrections( if I am right):")

#text("1,Before (10) it should be ")#mi("c_k \\leq c + \\varepsilon")#text(", and (10) and (11) should be ")#mi("\\mu_n(\\{f_n \\geq k \\}) \\leq c + \\varepsilon/5")#text(" and ")#mi("\\mu_n(\\{f_n \\geq k_n \\}) \\geq c - \\varepsilon/5")

#text("2,In the last paragraph of the last proof, ")#tao-math("\\left|X_n\\right|/K_n = o(\\left|X_n\\right|)", block: false)#text(", the denominator of lefthand side should be ")#mi("k_n")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("Thanks for the corrections and suggestions!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2009")])]

#text("I believe there is a typo in Remark 2 line 9: We need that ")#mi("\\mu_{>k}")#text(" is supported on a set of ")#mi("m")#text("–measure at most ")#mi("1/k")#text(", not ")#mi("k")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34741")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("Dear Terry,")

#text("Off topic, but do you generally write your posts in some text editor first. and then copy and paste into wordpress?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f997fa2ad8839adf0ab215638d34a42be5eb2c2fc7a89d0a4d465fdb314cb49-9a8e97053fad47fd5d9e2f4a445c750d5c2359a3f03c0332cfa773d94338ac41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Baroi")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34748")[#strong[#text("Max Baroi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2009")])]

#text("I could be wrong, but in Corollary 2, you write ")#mi("\\mu_s")#text(" is mutually singular to ")#mi("\\mu")#text(" when I tihnk it should be ")#mi("\\mu_s")#text(" is mutually singular to m. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An Exercise of Real Analysis « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34827")[#strong[#text("An Exercise of Real Analysis « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("[…] 10, 2009 at 1:42 下午 | In Maths（数学）, Real Analysis(实分析) | The last exercise of Notes 1 of Terence Tao’s lecture notes of the course “Real Analysis” is relavent with his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-34835")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("[…] result should be compared with the Radon-Nikodym theorem (Corollary 1 from Notes 1). Both theorems start with an abstract function or , and create a function out of it. Indeed, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristi")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-35346")[#strong[#text("Cristi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Hello,")#linebreak()#text(" I think that in remark 0 :")#linebreak()#text(" “One can in fact show that any signed measure that avoids +inf must have finite positive variation, but this turns out to require a certain amount of work”")#linebreak()#text(" you should add that it must avoid -(infinity) too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-35347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("It is certainly easier to prove finite positive variation if one also avoids ")#mi("-\\infty")#text(", but it is not necessary. (Of course, signed measures that attain ")#mi("-\\infty")#text(" will have infinite negative variation, and thus infinite total variation as well, but will still have finite positive variation.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristi")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-35349")[#strong[#text("Cristi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("Oops, I thought, you meant finite total variation (because of the “measure is finite iff the total variation is finite” corollary) instead of positive variation.")#linebreak()#text(" Sorry.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-35459")[#strong[#text("245B, Notes 9: The Baire category theorem and its Banach space consequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2009")])]

#text("[…] finite and are all absolutely continuous with respect to ; now use the Radon-Nikodym theorem (see Notes 1) and the fact that .) On the other hand, is closed, hence weakly closed (by Hahn-Banach), and so […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-35894")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第一节是关于关于符号测度和Radon-Nikodym-Lebesgue定理。本节从正常测度开始讲起，事实上为符号测度做铺垫，为对符号测度有一个更清楚的了解而写的一个引子。我更看重陶教授在这方面做的事情。而且整个课程他一直是此种风格。本节主体内容跟常见的教材差不多，我更喜欢夹杂在证明过程中的一些解释。比如在证明Radon-Nikodym-Lebesgue定理的时候，正文中讲述整个过程中“贪婪”的思想，很有意思。结尾附上了一个选学的内容，即Lebesgue分解定理的有限形式。这个跟陶教授以前的一篇帖子有很大关系，我跟人很喜欢这个想法，我把最后的习题写了下来。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/410b9c9ca6499cc5209036257f3918ac4258d3c6701d9f991efa9e24528b2df8-432d3897d03068d8e0e31ec014f2ec7c73c14643504a78c2eabf86dfc22ae74b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ke")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-36502")[#strong[#text("Ke")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Regarding ")#strong[#text("Remark 0")]#text(", I don’t think ")#mi("X_+ := \\cup_n E_n")#text(" works, If the first one ")#mi("E_1")#text(" is ")#mi("X")#text(" then the union is also ")#mi("X")#text(". Limsup doesn’t work either. There is an nontrivial example where ")#mi("\\mu(E_n)")#text(" converges to ")#mi("\\sup \\{ \\mu(E): E \\in {\\mathcal X}\\}")#text(" while ")#mi("\\limsup E_n = X")#text(" and ")#mi("\\liminf E_n = \\emptyset")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-36506")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Dear Ke,")

#text("Yes, you’re right; but I think it can be fixed by making ")#mi("\\mu(E_n)")#text(" converge to the supremum sufficiently rapidly. I’ve amended the remark to reflect this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-36520")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Dear Prof. Tao,")

#text("in a finite measure space if a function is in all ")#mi("L_{p}")#text(" spaces for p greater than or equal to 1, what can we say about it?just it is a.e. bounded?")

#text("what happens, in sigma finite and infinite measure case?")

#text("thanks,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-36525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Dear student,")

#text("In the finite measure case, ")#mi("L^p")#text(" is included in ")#mi("L^q")#text(" for all ")#mi("p \\geq q")#text(", and so ")#mi("\\bigcap_{1 \\leq p \\leq \\infty} L^p")#text(" is the same as ")#mi("L^\\infty")#text(".")

#text("In general, this inclusion does not hold, but instead we have ")#mi("L^p \\cap L^r \\subset L^q")#text(" whenever ")#mi("p < q < r")#text(", and so ")#mi("\\bigcap_{1 \\leq p \\leq \\infty} L^p = L^1 \\cap L^\\infty")#text(".")

#text("One can get some intuition for this by looking at the special case of step functions ")#mi("f = A 1_E")#text(", in which ")#tao-math("\\left\\|f\\right\\|_{L^p} = A \\mu(E)^{1/p}", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-36526")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2009")])]

#text("Thank you very much Prof. Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-38199")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("“(indeed, one could view measures as a kind of “generalised function” with respect to a fixed reference measure m).”")

#text("Do you mean to say that we can view unsigned measure as a kind of “generalised function” with respect to a fixed reference measure m?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaed0abc7e358133c38f6cdbe201713e4f795ade6b5a9b50d90dc79fc437b7e6-169ed54092edba23e1076ef1642a3d9e616d91a4ba40bded81b3c34d5d4c29e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anush Tserunyan")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-41102")[#strong[#text("Anush Tserunyan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("Dear Prof. Tao,")

#text("I think there is a typo in Corollary 1 (Radon-Nikodym theorem). \\mu should be finite, otherwise 2 doesn’t imply 1 or 3: let m be the Lebesgue measure on (0,1) and \\mu = m_f with f(x) = 1/x.")

#text("Thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-41734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("If")#emph[#text("\\mu is unsigned, then ")]#emph[#text("m_f and ")]#emph[#text("\\mu_s are also.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-45206")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("I think in Exercise 4 one should add that $X$ is $\\sigma$-finite. Otherwise, if $X$ is countable and $\\{ \\emptyset, X\\}$ is the $\\sigma$-algebra, then no finite nonzero measure is differentiable wrt the counting measure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-45213")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("Ah, I forgot to add the assumption that X is endowed with the discrete ")#mi("\\sigma")#text("-algebra. Thanks for the correction!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-689247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2025")])]

#text("Dear professor Tao:")

#text("Is the discrete ")#mi("\\sigma")#text("– algebra condition still present in the current version of Exercise 4?")

#emph[#text("[Updated, thanks -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-47253")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] is a measure. (We will study such measures in greater detail in 245B.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-47650")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] If is bounded, then can be expressed as the sum of a continuous monotone non-decreasing function and a jump function . Remark 14 This decomposition is part of the more general Lebesgue decomposition, which we will discuss later in this course. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-47922")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] This is the final set of notes in this sequence. If time permits, the course will then begin covering the 245B notes, starting with the material on signed measures and the Radon-Nikodym-Lebesgue theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiang")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-49132")[#strong[#text("Qiang")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2010")])]

#text("Hi, Prof Tao")

#text("I’m a bit confused in the Hahn decomposition theorem. For a signed measure ")#mi("\\mu")#text(", there is a decomposition ")#mi("X=X_+ \\cup X_-")#text(" such that ")#mi("\\mu \\downharpoonright_{X_+} \\geq 0")#text(" or just ")#mi("\\mu \\geq 0")#text(". Cause both in the process of proof and wikipedia entry it’s the latter ?")

#text("Thanks, Qiang")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-49140")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2010")])]

#mi("\\mu\\downharpoonright_{X_+} \\geq 0")#text(" is equivalent to ")#mi("X_+")#text(" being totally positive (or a positive set, as per the Wikipedia notation), by definition. (I assume you mean here “")#mi("X_+")#text(" is positive” rather than ")#mi("\\mu \\geq 0")#text(", since of course a signed measure ")#mi("\\mu")#text(" need not be positive in general.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-49158")[#strong[#text("Hahn decomposition theory « Mcknight0219's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2010")]

#text("[…] am confused about the proof of Prof. Tao for a while, mainly due to notation mistaken. Here I try to write down the proof following […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-50862")[#strong[#text("O Teorema de Radon-Nikodym | renanfinder")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")]

#text("[…] não é a original. Outra linha de ataque pode ser encontrada no link da primeira linha, bem como aqui (mas acho que elas são essencialmente equivalentes). De toda forma, me parece que as ideias mais […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-127879")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("In the statement of the Lebesgue-Radon-Nikodym theorem, I think the assertion that the Radon-Nikodym derivative $f$ is absolutely integrable is not true.")

#text("For example, let $\\mu = dx$ be the Lebesgue measure on the real line and let $\\nu = 2dx$ so that $f$ is the constant function 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-127960")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("You’ll probably want to update this in your statement of Corollary 1 as well. The LaTeX in the statement of Theorem 2 now doesn’t seem to be parsing (at least on my computer).")

#text("In the general case, what can be said about the function f? I have heard that it should be locally integrable, but I didn’t see anything in the proof to indicate this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-127981")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("Corrected, thanks. With the assumptions given, f need not be locally integrable; consider for instance ")#mi("m_f")#text(" on ")#mi("{\\bf R}")#text(" when ")#tao-math("f(x)=1/\\left|x\\right|^2", block: false)#text(". However, if one makes the further assumption that ")#mi("\\mu")#text(" is a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" (and is in particular locally finite), then ")#mi("f")#text(" will be locally integrable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-127952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2012")])]

#text("f ought to be *locally* integrable, though")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-382169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("Why is ")#mi("L^1(X,dm)")#text(" instead of ")#mi("L^1(X,m)")#text(" used in this note? Are they the same?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-434769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")])]

#text("“Indeed, if we let ")#mi("f_n")#text(" be a maximising sequence, thus ")#mi("m_{f_n} \\leq \\mu")#text(" and ")#mi("\\int_X f_n\\ dm \\to M")#text(", one easily checks that the function ")#mi("f = \\sup_n f_n")#text(" attains the supremum (and that ")#mi("f")#text(" is in the set of all non-negative functions such that ")#mi("m_f \\leq \\mu")#text(").”")

#text("I don’t see how easily one can check this.. If ")#mi("f_n")#text(" is monotone, then one can use MCT. If not, let ")#mi("g_n=\\max\\{f_1,\\cdots, f_n\\}")#text(". ")#mi("g_n")#text(" increases to ")#mi("f")#text(" and ")#mi("\\int g_n\\leq \\int f_n")#text(". It follows that ")#mi("\\int g_n\\leq M")#text(". How can one show that ")#mi("g_n=M")#text(" to complete the argument?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-434788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")])]

#text("One has ")#mi("\\int f_n \\leq \\int g_n")#text(", rather than ")#mi("\\int g_n \\leq \\int f_n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-434816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")])]

#text("Ah… I meant ")#mi("\\int g_n\\geq \\int f_n")#text(" and ")#mi("\\int g_n\\geq M")#text(". Still this only gives one half of the desired equality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-434856")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")])]

#text("Since ")#mi("m_{f_1},\\dots,m_{f_n} \\leq \\mu")#text(", we have ")#mi("m_{g_n} \\leq \\mu")#text(", so ")#mi("\\int g_n \\leq M")#text(" by definition of ")#mi("M")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-447454")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")])]

#text("Is 245B notes 2 missing? I find that notes 3 is the one right after this.")

#emph[#text("[Notes 2 is at ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-454755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")])]

#text("The Randon-Nikodym Theorem looks very much “like” the Riesz Representation Theorem: the first one says when a measure ")#mi("\\nu")#text(" can be ")#emph[#text("represented")]#text(" as ")#mi("\\nu(A)=\\int_A f\\ d\\mu")#text(" given a reference measure ")#mi("\\mu")#text("; the later one tells a ")#emph[#text("representation")]#text(" of a positive linear functional on ")#mi("C_c(X)")#text(" where ")#mi("X")#text(" is some LCH space. Is there any relationship between these two theorems?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-454767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2015")])]

#text("The Radon-Nikodym theorem is more closely related to the dual of ")#mi("L^p")#text(" spaces than the dual of ")#mi("C_c")#text(" spaces; see the last section of ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")]#text(" , particularly Remark 10. Other than that, the connection is fairly loose; Riesz representation requires a topology on the domain, which is not present in the Radon-Nikodym theorem, and conversely Radon-Nikodym requires a reference measure, which is not present in the Riesz representation setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-454872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2015")])]

#text("In exercise 2 by the fundamental theorem of calclus I get ")#mi("\\dfrac{d}{d x} \\mu([0,x]) = f(x) - f(0).")#text(" Is it assumed that ")#mi("f(0) = 0")#text("?")

#emph[#text("[No, but you should be getting ")#mi("\\dfrac{d}{dx} \\mu([0,x]) = f(x)")#text(" a.e. instead. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97a0bfc3f2276149edb42bcd0c0a1a576fe4aee4ed2a9e9d2c9bdfa9d0e036a8-ff98180769d5f18aff5cf9404c0b015381fad4cdd154d0b914edf5c34f13d9b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of augustsonne1")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-467884")[#strong[#text("augustsonne1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2016")])]

#text("In corollary 1 part iii) I believe there should be an absolute value around ")#mi("\\mu(E)")#text(".")#linebreak()#text(" Thank you for being so active on your blog!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-477087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("Suppose the signed measure in Theorem 1 is given by ")#mi("\\nu(E)=\\int_E f\\ d\\mu")#text(". How should one perform the “greedy algorithm” to find ")#mi("X_+")#text(" and ")#mi("X_{-}")#text("? Can one describe ")#mi("X_+")#text(" and ")#mi("X_{-}")#text(" in terms of ")#mi("f")#text(" and ")#mi("\\mu")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-477274")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("In this case, ")#mi("X_+")#text(" will be the set where ")#mi("f")#text(" is positive (up to null sets of ")#mi("\\nu")#text("), and ")#mi("X_-")#text(" will be the set where ")#mi("f")#text(" is negative. You may wish to see how the algorithm works in the simple case when ")#mi("X")#text(" is finite and ")#mi("\\mu")#text(" is counting measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-488353")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2017")])]

#text("Dear Prof. Tao,")

#text("In the end of the proof of Lebesgue-Radon-Nikodum theorem, how do you")

#text("come ")#mi("(\\mu_s - \\varepsilon m)_+")#text(" were not singular with respect to ")#mi("m")#linebreak()#text(" to")#linebreak()#text(" ")#mi("(\\mu_s-\\varepsilon m)\\downharpoonright_E \\geq 0")#text("?")

#text("And then ")#mi("\\mu_s \\geq \\varepsilon m\\downharpoonright_E")#text("?")

#text("I think both ")#mi("m")#text(" and ")#mi("(\\mu_s - \\varepsilon m)_+")#text(" have positive measure on E: ")#mi("(\\mu_s - \\varepsilon m)_+(E) > 0")#text(". But then how do you remove the positive part?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-488572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2017")])]

#text("By the Hahn decomposition theorem, ")#mi("(\\mu_s-\\varepsilon m)_+")#text(" is the restriction of ")#mi("\\mu_s - \\varepsilon m")#text(" to some set ")#mi("E")#text(". If ")#mi("m(E)=0")#text(", then ")#mi("(\\mu_s - \\varepsilon m)_+")#text(" would be singular; taking contrapositives, we conclude that ")#mi("\\mu(E)>0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f047644cf589eb8f9dcd8ecc1b272f3241b38b5d453fafe04e46018d34d3589a-ebf50be3611cf1cffe614915874d9872f92720ee82fa323d427330fdeddf71fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-496950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Dear Prof Tao,")

#text("For Corollary 1 of Lebesgue-Radon-Nikodym, do we not need $\\mu$ to be a finite measure rather than a $\\sigma$-finite measure? (Please correct me if I am wrong). I am unsure why it is true we can modify ex11 from notes 0 to prove 1 to 3.")

#text("Best")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-497068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2018")])]

#text("Oh dear, you are right, the Radon-Nikodym theorem was not stated correctly. I have reworded Corollary 1 to address this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f9e823fc85ab1b3b8ec1912f506f009a6927774efbbaf57cf2ee37df0fa4e45-72e73bd236d95ed762477505fef9abf8434b09edbbd4c6519e7e5a07a6832851.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Filon")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-549592")[#strong[#text("Filon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Is there an unstated reason for denoting the restriction of ")#mi("m")#text(" to ")#mi("A")#text(" with ")#mi("m\\downharpoonright_A")#text(" instead of ")#mi("m|_A")#text("? Is it to emphasize the difference between it and “standard functional” restriction of ")#mi("m")#text(" to a ")#mi("\\sigma")#text("-subalgebra?")#linebreak()#text(" Best")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-549653")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Not really, but ")#mi("\\downharpoonright")#text(" is more or less exclusively used for restriction type operations, whereas ")#mi("|")#text(" has multiple uses (for instance it is sometimes used for evaluation, e.g., ")#mi("f(x)|_{x=3}")#text(", or ")#mi("\\int_a^b f^{\\prime}(x)\\ dx = f(x)|^{x=b}_{x=a}")#text("), so I prefer using the former to reduce ambiguity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e98896bc286680814943c2d01dd5a269dcda3c7cc40c5b80f9be64a0a28acf4-f68aab55028e6e250b6402e1c809a102c78477386b89e44b23f93326eab358a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad tahir")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-555693")[#strong[#text("Mohammad tahir")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Define elementary set")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-603005")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I am a bit confused that there is no definition of a restriction of a measure to a set ")#mi("\\mu |_{X_+}")#text(" in the Hahn decomposition theorem. Could you put on some complements?")

#emph[#text("[This is defined shortly before Exercise 1, -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/742b91e9074f0887d2cb37f5759a4557206302bec98b72eaa2ad7ceb4a5b99d7-36d50c789146a43b5b90ea224beb4931dfa79dafd5e471f8abc4fe4f97ddc364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruijun Lin")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-605098")[#strong[#text("Ruijun Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2020")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In the second paragraph of the proof of Lebesgu-Radon-Nikodym Theorem (Theorem 2), you said that to select ")#mi("f")#text(" greedily, and take ")#mi("M= sup\\{ \\int_X fdm: f\\geq 0 \\text{ and } m_f \\leq \\mu\\}")#text(". I think we should explain that the set is empty, i.e., there exists such an ")#mi("f")#text(". The zero function is just OK. Am I right?")#linebreak()#text(" I raise this question because some of the other books use lot of words to demonstrate the existence of such a function (e.g. Royden’s Real Analysis).")

#text("Sincerely")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-614187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("Are all the functions in this set of notes implicitly assumed to be measurable? For instance")

#emph[#linebreak()#text(" Then we can obtain many further unsigned measures on ")#mi("X")#text(" by multiplying ")#mi("m")#text(" by a *function* ")#mi("f: X \\to [0,+\\infty]")#text(", to obtain a new unsigned measure ")#mi("m_f")#text(", defined by the formula")#linebreak()#text(" ")#mi("\\displaystyle m_f(E) := \\int_X 1_E f\\ dm. (1)")#linebreak()#text(" ")]

#text("and various other places. Would one gain anything if not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-614188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("… I’ve just found this is claimed at the beginning of the post. Sorry for the trivial comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-614195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#emph[#linebreak()#text(" … In view of Exercises 1 and 2, let us temporarily call a measure ")#mi("\\mu")#text(" differentiable with respect to ")#mi("m")#text(" if ")#mi("d\\mu = f dm")#text(" (i.e. ")#mi("\\mu = m_f")#text(") for some ")#mi("f: X \\to [0,+\\infty]")#text(",")#linebreak()#text(" ")]

#text("If one only looks at the definitions, ")#mi("d\\mu = f dm")#text(" is not quite the same as ")#mi("\\mu = m_f")#text(" since the latter only requires that the integrals hold for indicator functions of measurable sets. Maybe a remark is useful there.")

#text("Does one need some absolute integrability condition in order to say that these two notions are equivalent?")

#emph[#text("[Exercise 1 provides the required equivalence. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-614214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2020")])]

#text("Regarding Exercise 3, if one starts with a differentiable function ")#mi("f:\\mathbb{R}\\to\\mathbb{R}")#text(" such that its derivative is non-negative. Trivially, one has ")#mi("f^{\\prime}(x)=\\frac{dm_{f^{\\prime}}}{dm}(x)")#text(" where ")#mi("m")#text(" is the Lebesgue measure. Can one write ")#mi("m_{f^{\\prime}}")#text(" in terms of ")#mi("m_f")#text(" (assuming ")#mi("f")#text(" is also non-negative)?")

#emph[#text("[The former measure is the distributional derivative of the latter. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1706a91ec04958764113579d08ca151967744df4d4586bf0d0cbfa3a998f572a-f4079e69f6017b88b3f24ceca50f7f11fb3c9f6b6ee46969bbb6761c723ee634.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minyoung Jeong")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-631334")[#strong[#text("Minyoung Jeong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2021")])]

#text("Thank you for the article. I have a question on Exercise 3. I get ")#mi("\\lim_{h\\rightarrow 0} \\frac{\\mu([0, x+h]) - \\mu([0, x])}{h} = 1")#text(" since ")#mi("\\mu([0, x+h]) - \\mu([0, x]) = \\mu([x, x+h]) = h")#text(". But I don’t think ")#mi("\\frac{d\\mu}{dm}")#text(" is identically equal to 1. What is wrong with my reasoning?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1706a91ec04958764113579d08ca151967744df4d4586bf0d0cbfa3a998f572a-f4079e69f6017b88b3f24ceca50f7f11fb3c9f6b6ee46969bbb6761c723ee634.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minyoung Jeong")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-631335")[#strong[#text("Minyoung Jeong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2021")])]

#text("Oh, never mind. I misread the exercise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/comment-page-1/#comment-637566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2021")])]

#text("Dear Prof Tao,")#linebreak()#text(" In the 4th paragraph of Theorem 2, you say “It will suffice to show that ")#mi("(\\mu_s - \\varepsilon m)_+ \\perp m")#text(" for all ")#mi("\\varepsilon")#text(", as the claim then easily follows by letting \\varepsilon be a countable sequence going to zero.” I am having difficulty showing this. Does this involve a standard trick? Can you please explain?")

#emph[#text("[Hint: ")#mi("(\\mu_s - \\varepsilon m)_+ \\perp m")#text(" implies that, outside of an ")#mi("m")#text("-null set, one has ")#mi("\\mu_s(E) \\leq \\varepsilon m(E)")#text(" for all ")#mi("E")#text(". -T]")]
]
