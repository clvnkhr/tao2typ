// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T07:15:15.920543+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A cheap version of nonstandard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A cheap version of nonstandard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 April 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("Nonstandard analysis")]#text(" is a mathematical framework in which one extends the standard mathematical universe ")#mi("{{\\mathfrak U}}")#text(" of standard numbers, standard sets, standard functions, etc. into a larger nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(" of nonstandard numbers, nonstandard sets, nonstandard functions, etc., somewhat analogously to how one places the real numbers inside the complex numbers, or the rationals inside the reals. This nonstandard universe enjoys many of the same properties as the standard one; in particular, we have the ")#emph[#text("transfer principle")]#text(" that asserts that any statement in the language of first order logic is true in the standard universe if and only if it is true in the nonstandard one. (For instance, because Fermat’s last theorem is known to be true for standard natural numbers, it is automatically true for nonstandard natural numbers as well.) However, the nonstandard universe also enjoys some additional useful properties that the standard one does not, most notably the ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation")]#text(" property, which is a property somewhat analogous to the ")#link("http://en.wikipedia.org/wiki/Complete_metric_space")[#text("completeness property")]#text(" of a metric space; much as metric completeness allows one to assert that the intersection of a countable family of nested closed balls is non-empty, countable saturation allows one to assert that the intersection of a countable family of nested satisfiable formulae is simultaneously satisfiable. (See ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous blog post")]#text(" for more on the analogy between the use of nonstandard analysis and the use of metric completions.) Furthermore, by viewing both the standard and nonstandard universes externally (placing them both inside a larger ")#link("http://en.wikipedia.org/wiki/Metatheory")[#text("metatheory")]#text(", such as a model of Zermelo-Frankel-Choice (ZFC) set theory; in some more advanced set-theoretic applications one may also wish to add some ")#link("http://en.wikipedia.org/wiki/Large_cardinal")[#text("large cardinal")]#text(" axioms), one can place some useful additional definitions and constructions on these universes, such as defining the concept of an ")#link("http://en.wikipedia.org/wiki/Infinitesimal")[#text("infinitesimal")]#text(" nonstandard number (a number which is smaller in magnitude than any positive standard number). The ability to rigorously manipulate infinitesimals is of course one of the most well-known advantages of working with nonstandard analysis.")

#text("To build a nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(" from a standard one ")#mi("{{\\mathfrak U}}")#text(", the most common approach is to take an ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" of ")#mi("{{\\mathfrak U}}")#text(" with respect to some non-principal ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" over the natural numbers; see e.g. ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this blog post")]#text(" for details. Once one is comfortable with ultrafilters and ultrapowers, this becomes quite a simple and elegant construction, and greatly demystifies the nature of nonstandard analysis.")

#text("On the other hand, nonprincipal ultrafilters do have some unappealing features. The most notable one is that their very existence requires the axiom of choice (or more precisely, a weaker form of this axiom known as the ")#link("http://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem")[#text("boolean prime ideal theorem")]#text("). Closely related to this is the fact that one cannot actually write down any explicit example of a nonprincipal ultrafilter, but must instead rely on nonconstructive tools such as Zorn’s lemma, the Hahn-Banach theorem, Tychonoff’s theorem, the Stone-Cech compactification, or the boolean prime ideal theorem to locate one. As such, ultrafilters definitely belong to the “infinitary” side of mathematics, and one may feel that it is inappropriate to use such tools for “finitary” mathematical applications, such as those which arise in hard analysis. From a more practical viewpoint, because of the presence of the infinitary ultrafilter, it can be quite difficult (though usually not impossible, with sufficient patience and effort) to take a finitary result proven via nonstandard analysis and coax an effective quantitative bound from it.")

#text("There is however a “cheap” version of nonstandard analysis which is less powerful than the full version, but is not as infinitary in that it is constructive (in the sense of not requiring any sort of choice-type axiom), and which can be translated into standard analysis somewhat more easily than a fully nonstandard argument; indeed, a cheap nonstandard argument can often be presented (by judicious use of asymptotic notation) in a way which is nearly indistinguishable from a standard one. It is obtained by replacing the nonprincipal ultrafilter in fully nonstandard analysis with the more classical ")#link("http://en.wikipedia.org/wiki/Fr%C3%A9chet_filter")[#text("Fréchet filter")]#text(" of cofinite subsets of the natural numbers, which is the filter that implicitly underlies the concept of the classical limit ")#mi("{\\lim_{{\\bf n} \\rightarrow \\infty} a_{\\bf n}}")#text(" of a sequence when the underlying asymptotic parameter ")#mi("{{\\bf n}}")#text(" goes off to infinity. As such, “cheap nonstandard analysis” aligns very well with traditional mathematics, in which one often allows one’s objects to be parameterised by some external parameter such as ")#mi("{{\\bf n}}")#text(", which is then allowed to approach some limit such as ")#mi("{\\infty}")#text(". The catch is that the Fréchet filter is merely a filter and not an ultrafilter, and as such some of the key features of fully nonstandard analysis are lost. Most notably, the ")#link("http://en.wikipedia.org/wiki/Law_of_the_excluded_middle")[#text("law of the excluded middle")]#text(" does not transfer over perfectly from standard analysis to cheap nonstandard analysis; much as there exist bounded sequences of real numbers (such as ")#mi("{0,1,0,1,\\ldots}")#text(") which do not converge to a (classical) limit, there exist statements in cheap nonstandard analysis which are neither true nor false (at least without passing to a subsequence, see below). The loss of such a fundamental law of mathematical reasoning may seem like a major disadvantage for cheap nonstandard analysis, and it does indeed make cheap nonstandard analysis somewhat weaker than fully nonstandard analysis. But in some situations (particularly when one is reasoning in a “")#link("http://en.wikipedia.org/wiki/Constructivism_(mathematics)")[#text("constructivist")]#text("” or “")#link("http://en.wikipedia.org/wiki/Intuitionism")[#text("intuitionistic")]#text("” fashion, and in particular if one is avoiding too much reliance on set theory) it turns out that one can survive the loss of this law; and furthermore, the law of the excluded middle is still available for standard analysis, and so one can often proceed by working from time to time in the standard universe to temporarily take advantage of this law, and then transferring the results obtained there back to the cheap nonstandard universe once one no longer needs to invoke the law of the excluded middle. Furthermore, the law of the excluded middle can be recovered by adopting the freedom to ")#emph[#text("pass to subsequences")]#text(" with regards to the asymptotic parameter ")#mi("{{\\bf n}}")#text("; this technique is already in widespread use in the analysis of partial differential equations, although it is generally referred to by names such as “the compactness method” rather than as “cheap nonstandard analysis”.")

#text("Below the fold, I would like to describe this cheap version of nonstandard analysis, which I think can serve as a pedagogical stepping stone towards fully nonstandard analysis, as it is formally similar to (though weaker than) fully nonstandard analysis, but on the other hand is closer in practice to standard analysis. As we shall see below, the relation between cheap nonstandard analysis and standard analysis is analogous in many ways to the relation between probabilistic reasoning and deterministic reasoning; it also resembles somewhat the preference in much of modern mathematics for viewing mathematical objects as belonging to families (or to categories) to be manipulated ")#emph[#text("en masse")]#text(", rather than treating each object individually. (For instance, nonstandard analysis can be used as a partial substitute for scheme theory in order to obtain uniformly quantitative results in algebraic geometry, as discussed for instance in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text(".)")

#metadata(none) <tao-99d1d90270a8038328bf>

#heading(level: 1)[#strong[#text(" — 1. Details — ")]]

#text("To set up cheap nonstandard analysis, we will need an asymptotic parameter ")#mi("{{\\bf n}}")#text(", which we will take to initially lie in the natural numbers ")#mi("{{\\bf N}}")#text(" (though it is certainly possible to set up cheap nonstandard analysis on other non-compact spaces than ")#mi("{{\\bf N}}")#text(" if one wishes). However, we reserve the right in the future to restrict the parameter space from ")#mi("{{\\bf N}}")#text(" to a smaller infinite subset ")#mi("{\\Sigma}")#text(" (which corresponds to the familiar operation of passing from a sequence ")#mi("{x_{\\bf n}}")#text(" to a subsequence, except that we do not bother to relabel the subsequence to be indexed by ")#mi("{{\\bf N}}")#text(" again). The dynamic nature of the parameter space ")#mi("{\\Sigma}")#text(" makes it a little tricky to properly formalise cheap nonstandard analysis in the usual static framework of mathematical logic, but it turns out not to make much difference in practice, because in cheap nonstandard analysis one only works with statements which remain valid under the operation of restricting the underlying domain of the asymptotic parameter. (This is analogous to how in probability theory one only works with statements which remain valid under the operation of extending the underlying probability space, as discussed in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this blog post")]#text(".)")

#text("We then distinguish two types of mathematical objects:")

#enum(start: 1, 
[#emph[#text("Standard objects")]#text(" ")#mi("{x}")#text(", which do not depend on the asymptotic parameter ")#mi("{{\\bf n}}")#text("; and")],
[#emph[#text("Nonstandard objects")]#text(" ")#mi("{x = x_{\\bf n}}")#text(", which are allowed to depend on the asymptotic parameter ")#mi("{{\\bf n}}")#text(".")]
)

#text("Similarly with “object” replaced by other mathematical concepts such as “number”, “point”, “set”, “function”, etc. Thus, for instance, a nonstandard real is a real number ")#mi("{x = x_{\\bf n}}")#text(" that depends on the asymptotic parameter ")#mi("{{\\bf n}}")#text("; a nonstandard function is a function ")#mi("{f = f_{\\bf n}: X_{\\bf n} \\rightarrow Y_{\\bf n}}")#text(" from a domain ")#mi("{X = X_{\\bf n}}")#text(" to a range ")#mi("{Y = Y_{\\bf n}}")#text(", which are all allowed to depend on the asymptotic parameter ")#mi("{{\\bf n}}")#text("; and so forth.")

#text("Of course, with these conventions, every standard object is automatically also a nonstandard object. (One can use the terminology ")#emph[#text("strictly nonstandard object")]#text(" to refer to a nonstandard object which is not a standard object.) This will lead to the following slight abuse of notation: if ")#mi("{X}")#text(" is a standard set, we consider a ")#emph[#text("cheap nonstandard element of ")#mi("{X}")]#text(" to be a nonstandard object ")#mi("{x = x_{\\bf n}}")#text(", such that each ")#mi("{x_{\\bf n}}")#text(" is an element of ")#mi("{X}")#text(". In the strict set-theoretic sense, this is not an actual element of ")#mi("{X}")#text(", which consists only of standard objects, but we will abuse notation and consider it as a nonstandard element of ")#mi("{X}")#text(". (This is analogous to how, in probability theory, a real-valued random variable is not actually a (deterministic) element of ")#mi("{{\\bf R}}")#text(", but can be considered as a ")#emph[#text("probabilistic")]#text(" element of ")#mi("{{\\bf R}}")#text(" instead.) If one wants to be more pedantic, one can use the notation ")#mi("{{}^* X}")#text(" to denote the collection of all nonstandard elements of ")#mi("{X}")#text(", which is what one usually does in fully nonstandard analysis (after quotienting by equivalence with respect to a non-principal ultrafilter), but we will avoid trying to collect cheap nonstandard elements into a set here because it interferes with the freedom to pass to subsequences. Because of this, though, it is best not to combine cheap nonstandard analysis with any advanced set theory unless one knows exactly what one is doing, as one can get quite confused if one is not already experienced in both set theory and nonstandard analysis. (In such circumstances, it is best to instead use fully nonstandard analysis, which can treat the nonstandard universe as an ")#link("http://en.wikipedia.org/wiki/Actual_infinity")[#text("actual")]#text(" set rather than a “potential” one.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Suppose ")#mi("{x_1, x_2, \\ldots}")#text(" is a bounded sequence of real numbers, with the uniform upper bound ")#tao-math("{\\left|x_{\\bf n}\\right| \\leq M}", block: false)#text(" for all ")#mi("{{\\bf n}}")#text(". Then one can interpret ")#mi("{x = x_{\\bf n}}")#text(" as a single nonstandard real, while the bound ")#mi("{M}")#text(" remains a standard real. Note the slight conceptual distinction between the cheap nonstandard approach of treating ")#mi("{x}")#text(" as a single nonstandard object, and the classical approach of treating ")#mi("{x}")#text(" as a sequence of standard objects. This distinction is analogous the distinction between treating a random variable as a single probabilistic object (as is done in probability theory), as opposed to a measurable function mapping the underlying measure space to a deterministic range space (which is the viewpoint taken in measure theory). The two viewpoints are mathematically equivalent, but can lead to somewhat different ways of thinking about such objects.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" In graph theory, an ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander family")]#text(" is a sequence of finite graphs ")#mi("{G_{\\bf n} = (V_{\\bf n}, E_{\\bf n})}")#text(" which have uniform edge expansion in the following sense: there exists an ")#mi("{\\epsilon>0}")#text(" independent of ")#mi("{{\\bf n}}")#text(", such that for any ")#mi("{{\\bf n}}")#text(" and any subset ")#mi("{A_{\\bf n}}")#text(" of ")#mi("{V_{\\bf n}}")#text(" of size at most ")#tao-math("{\\left|V_{\\bf n}\\right|/2}", block: false)#text(" is adjacent to at least ")#tao-math("{\\epsilon \\left|A_{\\bf n}\\right|}", block: false)#text(" other vertices in ")#mi("{V_{\\bf n}}")#text(". Adopting a cheap nonstandard analysis perspective, one can view this expander family as a single cheap nonstandard graph ")#mi("{G = (V,E)}")#text(" (with a cheap nonstandard finite vertex set ")#mi("{V = V_{\\bf n}}")#text(" and edge set ")#mi("{E = E_{\\bf n}}")#text(", while the expansion constant ")#mi("{\\epsilon}")#text(" remains a standard real number.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" In the above two examples, the asymptotic parameter ")#mi("{{\\bf n}}")#text(" was already inherent in the mathematical structure being studied. In other situations, there is initially no asymptotic parameter present, but one can be created by arguing by contradiction and selecting a sequence of counterexamples (in some cases, this requires countable version of the axiom of choice). For instance, suppose one has a (standard) function ")#mi("{F: X \\rightarrow {\\bf R}}")#text(" on some domain ")#mi("{X}")#text(", and one wishes to show that ")#mi("{F}")#text(" is bounded. If ")#mi("{F}")#text(" were not bounded, then for each natural number ")#mi("{{\\bf n}}")#text(" one could find a point ")#mi("{x_{\\bf n}}")#text(" in the domain with ")#tao-math("{\\left|F(x_{\\bf n})\\right| \\geq {\\bf n}}", block: false)#text("; one can then collect all of these standard points ")#mi("{x_{\\bf n}}")#text(" together to form a cheap nonstandard point ")#mi("{x}")#text(", with the property that ")#mi("{F(x)}")#text(" is unbounded (we will define what this means shortly). Taking contrapositives, we see that to show that ")#mi("{F}")#text(" is a bounded function, it suffices to show that ")#mi("{F(x)}")#text(" is bounded for each cheap nonstandard point ")#mi("{x}")#text(" in ")#mi("{X}")#text(".")
]

#text("We will only be interested in the behaviour of cheap nonstandard mathematical objects ")#mi("{x = x_{\\bf n}}")#text(" in the asymptotic limit ")#mi("{{\\bf n} \\rightarrow \\infty}")#text(". To this end, we will reserve the right to delete an arbitrary finite number of values from the domain ")#mi("{\\Sigma}")#text(" of the parameter ")#mi("{{\\bf n}}")#text(", and work only with ")#emph[#text("sufficiently large")]#text(" choices of this parameter. In particular, two nonstandard objects ")#mi("{x = x_{\\bf n}}")#text(", ")#mi("{y = y_{\\bf n}}")#text(" will be considered equal if one has ")#mi("{x_{\\bf n} = y_{\\bf n}}")#text(" for all sufficiently large ")#mi("{{\\bf n}}")#text(". (This is where the ")#link("http://en.wikipedia.org/wiki/Fr%C3%A9chet_filter")[#text("Frechet filter")]#text(" is implicitly coming into play.)")

#text("Any operation which can be applied to standard objects ")#mi("{x}")#text(", can also be applied to cheap nonstandard objects ")#mi("{x = x_{\\bf n}}")#text(" by applying the standard operation separately for each choice of asymptotic parameter ")#mi("{{\\bf n}}")#text(" in the current domain ")#mi("{\\Sigma}")#text(", with no interaction between different values of the asymptotic parameter. For instance, the sum ")#mi("{x+y}")#text(" of two cheap nonstandard reals ")#mi("{x = x_{\\bf n}}")#text(" and ")#mi("{y = y_{\\bf n}}")#text(" is given by ")#mi("{(x+y)_{\\bf n} := x_{\\bf n} + y_{\\bf n}}")#text(". Similarly, if ")#mi("{f = f_{\\bf n}: X_{\\bf n} \\rightarrow Y_{\\bf n}}")#text(" is a cheap nonstandard function from a cheap nonstandard set ")#mi("{X = X_{\\bf n}}")#text(" to another cheap nonstandard set ")#mi("{Y = Y_{\\bf n}}")#text(", and ")#mi("{x = x_{\\bf n}}")#text(" is a cheap nonstandard element of ")#mi("{X}")#text(" (thus ")#mi("{x_{\\bf n}}")#text(" is an element of ")#mi("{X_{\\bf n}}")#text(" for all ")#mi("{{\\bf n}}")#text(" in the current parameter space ")#mi("{\\Sigma}")#text("), then ")#mi("{f(x)}")#text(" is the cheap nonstandard element defined by ")#mi("{f(x)_{\\bf n} := f_{\\bf n}(x_{\\bf n})}")#text(". Since every standard function is also a nonstandard function, this also defines ")#mi("{f(x)}")#text(" when ")#mi("{f}")#text(" is standard and ")#mi("{x}")#text(" is nonstandard, and also vice versa.")

#text("(Again, one should note the analogy here with probability theory; any operation that can be applied to deterministic objects, can also be applied to probabilistic objects, by applying the deterministic operation to each individual point in the event space separately. For instance, the sum of two random variables ")#mi("{X+Y}")#text(" is defined by the formula ")#mi("{(X+Y)(\\omega) := X(\\omega)+Y(\\omega)}")#text(" for all points ")#mi("{\\omega}")#text(" in the event space. Because of things like this, the event parameter ")#mi("{\\omega}")#text(" can usually be suppressed entirely from view when doing probability, and similarly the parameter ")#mi("{{\\bf n}}")#text(" can also usually be suppressed from view when performing cheap nonstandard analysis.)")

#text("Similarly, any relation or predicate which can be applied to standard objects, can be applied to cheap nonstandard objects, with the relation or predicate considered to be true for some cheap nonstandard objects if it is true for all sufficiently large values of the asymptotic parameter (in the current domain ")#mi("{\\Sigma}")#text("). For instance, given two nonstandard real numbers ")#mi("{x = x_{\\bf n}}")#text(" and ")#mi("{y = y_{\\bf n}}")#text(", we say that ")#mi("{x>y}")#text(" if one has ")#mi("{x_{\\bf n} > y_{\\bf n}}")#text(" for all sufficiently large ")#mi("{{\\bf n}}")#text(". Similarly, we say that the relation is false if it is false for all sufficiently large values of the asymptotic parameter.")

#text("It is here that we run into the main defect of the cheap version of nonstandard analysis: it is possible for a statement concerning cheap nonstandard objects to neither be fully true nor fully false, but instead merely being both potentially true and potentially false. (Again, this is in analogy with probability theory, in which a probabilistic statement need not be almost surely true or almost surely false, but could instead be true with positive probability and also false with positive probability.) For instance, using the natural numbers ")#mi("{{\\bf N}}")#text(" as the initial domain of the asymptotic parameter, the nonstandard real number ")#mi("{x = x_{\\bf n} := (-1)^{\\bf n}}")#text(" is neither positive, negative, nor zero, because none of the three statements ")#mi("{(-1)^{\\bf n} > 0}")#text(", ")#mi("{(-1)^{\\bf n} < 0}")#text(", or ")#mi("{(-1)^{\\bf n} = 0}")#text(" are true for all sufficiently large ")#mi("{{\\bf n}}")#text(". However, if one restricts the asymptotic parameter to the even integers, then this real number ")#mi("{x}")#text(" becomes positive, while if one restricts the asymptotic parameter instead to the odd integers, then the real number becomes negative. Until we make such a restriction, though, we cannot assign a definite truth value to statements such as “")#mi("{x}")#text(" is positive”, and so we must accept the existence of statements in cheap nonstandard analysis whose truth value is currently indeterminate, although once the truth value does become determinate, it remains that way under any further refinement of the underlying domain ")#mi("{\\Sigma}")#text(". (This problem is precisely what is rectified by the use of an ultrafilter in fully nonstandard analysis, as ultrafilters always contain exactly one of a given subset of ")#mi("{{\\bf N}}")#text(" and its complement.) But there is certainly substantial precedent in mathematics for reasoning with statements with an indeterminate truth value: probability theory, intuitionistic logic, and modal logic, for instance, all contain this issue in some shape or form.")

#text("Despite this indeterminacy, we still largely retain the fundamental ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" of nonstandard analysis: many statements of first-order logic which are true (resp. false) when quantified over standard objects, remain true (resp. false) when quantified over nonstandard objects, regardless of what the current value of the domain ")#mi("{\\Sigma}")#text(" of the asymptotic parameter is. For instance, addition and multiplication are commutative and associative for the standard real numbers, and thus for the cheap nonstandard real numbers also, as can be easily verified after a moment’s thought. Because of the lack of the law of excluded middle, though, sometimes one has to take some care in phrasing statements properly before they will transfer. For instance, the statement “If ")#mi("{xy=0}")#text(", then either ")#mi("{x=0}")#text(" or ")#mi("{y=0}")#text("” is of course true for standard reals, but not for nonstandard reals; a counterexample can be given for instance by ")#mi("{x_{\\bf n} := 1 + (-1)^{\\bf n}}")#text(" and ")#mi("{y_{\\bf n} := 1 - (-1)^{\\bf n}}")#text(". However, the rephrasing “If ")#mi("{x \\neq 0}")#text(" and ")#mi("{y \\neq 0}")#text(", then ")#mi("{xy \\neq 0}")#text("” is true for nonstandard reals (why?). As a rough rule of thumb, as long as the logical connectives “or” and “not” are avoided, one can transfer standard statements to cheap nonstandard ones, but otherwise one may need to reformulate the statement first before transfer becomes possible. Even when one’s statements do contain an “or” or a “not”, one can often still recover a nonstandard formulation after invoking the freedom to pass to a subsequence. For instance, “If ")#mi("{xy=0}")#text(", then after passing to a subsequence if necessary, either ")#mi("{x=0}")#text(" or ")#mi("{y=0}")#text("” is a true statement in cheap nonstandard analysis (why? this is basically the infinite pigeonhole principle). Note that for fully nonstandard analysis, one does not need to be so careful with transfer, as ")#emph[#text("all")]#text(" first-order statements transfer properly (this fact is known as ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(").")

#text("We also retain a version of the equally fundamental ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation property")]#text(" of nonstandard analysis, although the cheap version is often referred to instead as the ")#emph[#text("Arzelá-Ascoli diagonalisation argument")]#text(". Let us call a nonstandard property ")#mi("{P(x)}")#text(" pertaining to a nonstandard object ")#mi("{x}")#text(" ")#emph[#text("satisfiable")]#text(" if, no matter how one restricts the domain ")#mi("{\\Sigma}")#text(" from its current value, one can find an ")#mi("{x}")#text(" for which ")#mi("{P(x)}")#text(" becomes true, possibly after a further restriction of the domain ")#mi("{\\Sigma}")#text(". The countable saturation property is then the assertion that if one has a countable sequence ")#mi("{P_1, P_2, \\ldots}")#text(" of properties, such that ")#mi("{P_1(x),\\ldots,P_n(x)}")#text(" is jointly satisfiable for any finite ")#mi("{n}")#text(", then the entire sequence ")#mi("{P_1(x), P_2(x), \\ldots}")#text(" is simultaneously satisfiable. The proof proceeds by mimicking the diagonalisation component of the proof of the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(", which explains the above terminology.")

#heading(level: 1)[#strong[#text(" — 2. Asymptotic notation — ")]]

#text("Thus far, there has been essentially no interaction between different choices of the parameter ")#mi("{{\\bf n}}")#text(". In classical analysis, such an interaction is obtained by the device of introducing the limit ")#mi("{\\lim_{{\\bf n} \\rightarrow \\infty} x_{\\bf n}}")#text(" of a convergent sequence, and also by introducing asymptotic notation such as ")#mi("{O()}")#text(" and ")#mi("{o()}")#text(" which tracks the dependence of various bounds on the parameter ")#mi("{{\\bf n}}")#text(". These devices can be easily translated to the cheap nonstandard analysis setting without much difficulty, as follows.")

#text("Firstly, given two cheap nonstandard numbers ")#mi("{X = X_{\\bf n}}")#text(" and ")#mi("{Y = Y_{\\bf n}}")#text(", we may write ")#mi("{X = O(Y)}")#text(" (or ")#mi("{X \\ll Y}")#text(", or ")#mi("{Y \\gg X}")#text(") if one has ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some standard real number ")#mi("{C>0}")#text(" (or equivalently, if ")#tao-math("{\\left|X_{\\bf n}\\right| \\leq C Y_{\\bf n}}", block: false)#text(" for all sufficiently large ")#mi("{n}")#text("). Similarly, we write ")#mi("{X = o(Y)}")#text(" if one has ")#tao-math("{\\left|X\\right| \\leq \\epsilon Y}", block: false)#text(" for ")#emph[#text("every")]#text(" standard real number ")#mi("{\\epsilon>0}")#text(" (or equivalently, if ")#tao-math("{\\left|X_{\\bf n}\\right| \\leq c({\\bf n}) Y_{\\bf n}}", block: false)#text(" for all ")#mi("{{\\bf n}}")#text(" and some quantity ")#mi("{c({\\bf n})}")#text(" that goes to zero as ")#mi("{{\\bf n} \\rightarrow \\infty}")#text("). Note that these conventions are essentially the same as the usual asymptotic notation (except that sometimes the bound for the ")#mi("{O()}")#text(" notation is required to hold for all ")#mi("{{\\bf n}}")#text(", rather than merely for sufficiently large ")#mi("{{\\bf n}}")#text(").")

#text("A cheap nonstandard quantity ")#mi("{X}")#text(" is said to be ")#emph[#text("bounded")]#text(" if one has ")#mi("{X=O(1)}")#text(", and ")#emph[#text("infinitesimal")]#text(" if ")#mi("{X=o(1)}")#text(".")

#text("Many quantitative statements about standard objects can be converted into equivalent qualitative statements about cheap nonstandard objects. We illustrate this with some simple examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Boundedness)")]#text(" ")#metadata(none) <tao-7dc96f776c8423e57a27>#text(" Let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a standard function. Show that the following are equivalent:")

#enum(start: 1, 
[#text("(Quantitative standard version) There exists a standard ")#mi("{M>0}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for all standard ")#mi("{x \\in X}")#text(".")],
[#text("(Quantitative nonstandard version) There exists a standard ")#mi("{M>0}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for all nonstandard elements ")#mi("{x}")#text(" of ")#mi("{X}")#text(".")],
[#text("(Qualitative nonstandard version) ")#mi("{f(x)}")#text(" is bounded for each nonstandard element ")#mi("{x}")#text(" of ")#mi("{X}")#text(".")],
[#text("(Qualitative subsequential nonstandard version) For each nonstandard element ")#mi("{x}")#text(" of ")#mi("{X}")#text(", ")#mi("{f(x)}")#text(" is bounded after passing to a subsequence.")]
)
]

#text("Call two nonstandard elements ")#mi("{x, y}")#text(" of a standard metric space ")#mi("{(X,d)}")#text(" ")#emph[#text("infinitesimally close")]#text(" if ")#mi("{d(x,y)=o(1)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Continuity)")]#text(" Let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a standard function on a standard metric space ")#mi("{X = (X,d)}")#text(". Show that the following are equivalent:")

#enum(start: 1, 
[#text("(Standard version) ")#mi("{f}")#text(" is continuous.")],
[#text("(Nonstandard version) If ")#mi("{x}")#text(" is a standard element of ")#mi("{X}")#text(" and ")#mi("{y}")#text(" is a cheap nonstandard element that is infinitesimally close to ")#mi("{x}")#text(", then ")#mi("{f(y)}")#text(" is infinitesimally close to ")#mi("{f(x)}")#text(".")],
[#text("(Subsequential nonstandard version) If ")#mi("{x}")#text(" is a standard element of ")#mi("{X}")#text(" and ")#mi("{y}")#text(" is a cheap nonstandard element that is infinitesimally close to ")#mi("{x}")#text(", then ")#mi("{f(y)}")#text(" is infinitesimally close to ")#mi("{f(x)}")#text(" after passing to a subsequence.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Uniform continuity)")]#text(" Let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be a standard function on a standard metric space ")#mi("{X = (X,d)}")#text(". Show that the following are equivalent:")

#enum(start: 1, 
[#text("(Standard version) ")#mi("{f}")#text(" is uniformly continuous.")],
[#text("(Nonstandard version) If ")#mi("{x}")#text(" is a ")#emph[#text("nonstandard")]#text(" element of ")#mi("{X}")#text(" and ")#mi("{y}")#text(" is a cheap nonstandard element that is infinitesimally close to ")#mi("{x}")#text(", then ")#mi("{f(y)}")#text(" is infinitesimally close to ")#mi("{f(x)}")#text(".")],
[#text("(Subsequential nonstandard version) If ")#mi("{x}")#text(" is a ")#emph[#text("nonstandard")]#text(" element of ")#mi("{X}")#text(" and ")#mi("{y}")#text(" is a cheap nonstandard element that is infinitesimally close to ")#mi("{x}")#text(", then ")#mi("{f(y)}")#text(" is infinitesimally close to ")#mi("{f(x)}")#text(" after passing to a subsequence.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (Differentiability)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" and ")#mi("{f^{\\prime}: {\\bf R} \\rightarrow {\\bf R}}")#text(" be standard functions. Show that the following are equivalent:")

#enum(start: 1, 
[#text("(Standard version) ")#mi("{f}")#text(" is everywhere differentiable, with derivative ")#mi("{f^{\\prime}}")#text(".")],
[#text("(Nonstandard version) If ")#mi("{x}")#text(" is a standard real and ")#mi("{h}")#text(" is infinitesimal, then ")#mi("{f(x+h) = f(x)+hf^{\\prime}(x) + o(h)}")#text(".")],
[#text("(Subsequential nonstandard version) If ")#mi("{x}")#text(" is a standard real and ")#mi("{h}")#text(" is infinitesimal, then ")#mi("{f(x+h) = f(x)+hf^{\\prime}(x) + o(h)}")#text(" after passing to a subsequence.")]
)
]

#text("One nice feature about nonstandard analysis is that it tends to automatically perform “epsilon management”, in that it tends to correctly figure out on its own what parameters are allowed to depend on what other parameters. Let us illustrate this with an simple example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{P(d,n,m)}")#text(" be a predicate depending on three natural numbers ")#mi("{d,n,m}")#text(". Show that the following are equivalent:")

#enum(start: 1, 
[#text("(Standard version) For every standard ")#mi("{d \\in {\\bf N}}")#text(", there exists a standard constant ")#mi("{C_d>0}")#text(", such that for every ")#mi("{n \\in {\\bf N}}")#text(", there exists ")#mi("{m}")#text(" with ")#mi("{m \\leq C_d n}")#text(" such that ")#mi("{P(d,n,m)}")#text(" holds.")],
[#text("(Nonstandard version) For every standard natural number ")#mi("{d}")#text(" and cheap nonstandard natural number ")#mi("{n}")#text(", there exists a cheap nonstandard natural number ")#mi("{m = O(n)}")#text(" such that ")#mi("{P(d,n,m)}")#text(" holds.")]
)

#text("Furthermore, show that requiring in the standard version that the constant ")#mi("{C_d}")#text(" is actually uniform in ")#mi("{d}")#text(" is equivalent to allowing ")#mi("{d}")#text(" to be nonstandard rather than standard in the nonstandard version.")
]

#text("As a consequence, the asymptotic notation in a nonstandard argument tends to be slightly simpler than in a standard counterpart; whereas in the standard world one usually has to subscript the asymptotic notation by various parameters (e.g. the bound ")#mi("{m \\leq C_d n}")#text(" in the above exercise could be written instead as ")#mi("{m=O_d(n)}")#text("), the subscripting is done automatically once one decides which variables are standard and which ones are nonstandard.")

#text("If a nonstandard real ")#mi("{x}")#text(" is of the form ")#mi("{y+o(1)}")#text(" for some standard real ")#mi("{y}")#text(", we call ")#mi("{y}")#text(" the ")#emph[#text("standard part")]#text(" of ")#mi("{x}")#text(" and write ")#mi("{y = \\text{st}(x)}")#text("; viewing ")#mi("{x}")#text(" as a sequence ")#mi("{x_{\\bf n}}")#text(", we see that this occurs precisely when the sequence ")#mi("{x_{\\bf n}}")#text(" converges to ")#mi("{y}")#text(" as ")#mi("{{\\bf n} \\rightarrow \\infty}")#text(". But because not all sequences are convergent, not all cheap nonstandard reals have a standard part. However, thanks to ")#link("http://en.wikipedia.org/wiki/Bolzano%E2%80%93Weierstrass_theorem")[#text("the Bolzano-Weierstrass theorem")]#text(", we know that any bounded nonstandard number ")#mi("{x}")#text(" will have a standard part after passing to a subsequence; more generally, we can extract a standard part from any nonstandard object lying in a sequentially compact set by passing to a subsequence.")

#text("We can then reformulate many basic compactness arguments in analysis using this observation (at least if the topologies involved are sufficiently non-pathological that they can be accurately probed by sequences). For instance, let us give the cheap non-standard proof that a continuous function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" on a compact metric space is bounded. By Exercise ")#link(<tao-7dc96f776c8423e57a27>)[#text("1")]#text(", it suffices to show that ")#mi("{f(x)}")#text(" is bounded for every nonstandard element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" after passing to a subsequence. But by the Bolzano-Weierstrass theorem, ")#mi("{x}")#text(" has a standard part ")#mi("{y}")#text("; by continuity, ")#mi("{f(x)}")#text(" is then infinitesimally close to ")#mi("{f(y)}")#text(". But ")#mi("{f(y)}")#text(" is standard, and so ")#mi("{f(x)}")#text(" is bounded as well.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Give a cheap nonstandard analysis proof of the fact that on a compact domain, every continuous function is uniformly continuous.")
]

#text("Readers who are familiar with traditional real analysis will note that the above proofs are basically just very lightly disguised versions of the usual sequence-based traditional proofs. Indeed, cheap nonstandard analysis is very close to sequence-based analysis (much as probability theory is very close to measure theory), and it is easy to translate from one to the other. (Fully nonstandard analysis is a bit different in this regard, because it relies on ultralimits rather than classical limits, but it is still analogous in many ways to sequence-based analysis.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cd7e89969ee36f56b9052851f8ce8f7ac2f4339f64db57655ce0e692427ed83-ece70002b800a5489a378c29fb90ce2938c70c1ec41fa976b759c767a46e0da8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ted Gast")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136483")[#strong[#text("Ted Gast")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2012")])]

#text("Excellent post. You mentioned that this cheap version of nonstandard analysis has a logic that somewhat intuitionistic. Does this mean that one can use Gödel–Gentzen negative translation in order to phrase things properly so that they transfer?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Something like this does seem to be the case. Indeed, to use the example in the text, Godel-Gentzen translates “If ")#mi("xy=0")#text(", then ")#mi("x=0")#text(" or ")#mi("y=0")#text("” “If ")#mi("xy \\neq 0")#text(" is not true, then (")#mi("x \\neq 0")#text(" and ")#mi("y \\neq 0")#text(") is not true” which is the contrapositive of the translation “If ")#mi("x \\neq 0")#text(" and ")#mi("y \\neq 0")#text(", then ")#mi("xy \\neq 0")#text("” offered in the text. (I am slightly worried about the use of the contrapositive, which is not allowed in intuitionistic logic, but I think it is OK because the metatheory remains in the realm of classical logic even after one restricts the internal logic of cheap nonstandard analysis to be intuitionistic.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136498")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Trivial fix: you wrote “an arbitrary number of finite values” but meant “an arbitrary finite number of values”. (*All* the values are finite.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73580563d7c4950acc40df90c80b55f28c954d1c4c2a37509f4ce79b5f7a789a-dfbab2e336939b5109d47ca22e5d90ea7618e680342d6cacdd3f708cb63aac9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Kreuzer")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136534")[#strong[#text("Alexander Kreuzer")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Dear Prof Tao,")

#text("thank you for your great post.")#linebreak()#text(" I would like to add that one can get even better results if one replaces the ultrafilter not with the Frechet filter but with other filters.")

#text("In fact, one can show that for any countable collection of set ")#mi("A\\subseteq \\mathcal{P}(\\mathbb{N})")#text(" one can construct (without AC) an approximate ultrafilter ")#mi("\\mathcal{F}")#text(" in the sense that")#linebreak()#text(" ")#mi("\\forall{X\\in \\mathcal{F}} X")#text(" is infinite")#linebreak()#text(" ")#mi("\\forall{X\\in A} X \\in \\mathcal{F} \\lor  \\mathbb{N}\\setminus X \\in \\mathcal{F}")#linebreak()#text(" ")#mi("\\forall{X,Y\\in A} (X\\subseteq Y \\land X\\in \\mathcal{F} \\implies Y\\in\\mathcal{F})")#linebreak()#text(" ")#mi("\\forall{X,Y\\in A} (X \\in \\mathcal{F} \\land Y\\in \\mathcal{F} \\implies X \\cap Y\\in\\mathcal{F})")

#text("For instance, Solovay constructed a filter which acts on the hyperarithmetical sets like an ultrafilter using such methods.")

#text("Thus, if one knows in advance that one uses an ultrafilter U only one countable many sets and these sets are given, then one can construct an approximate ultrafilter which could replace U in the proof.")

#text("This can be refined to eliminate general uses of ultrafilters over reasonable fragments of arithmetic (ACA_0).")#linebreak()#text(" See this paper by Henry Towsner for a treatment based on forcing")

#link("http://arxiv.org/abs/1109.3902")[#text("http://arxiv.org/abs/1109.3902")]

#text("and this paper of mine which is based on proof-mining techniques")

#link("http://www.mathematik.tu-darmstadt.de/~akreuzer/files/ultra.pdf")[#text("Click to access ultra.pdf")]

#text("Best wishes,")#linebreak()#text(" Alexander Kreuzer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Helfgott")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136574")[#strong[#text("Craig Helfgott")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Random question: Is anyone else seeing the background of this page as dark grey? Is it just me? Terry, is this intentional?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("Me too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2012")])]

#text("That’s strange; I reset it just now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28cc6f7cb13746fb7ada8107e4cd16e305746899349cadbe9a61fd8ef876dc9b-0cd9ed5a764100cee8c7a92d99976b36ca7321afe22b62342bfa8e2ac2f59502.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrejbauer")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136636")[#strong[#text("andrejbauer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("When you said “there exist statements in cheap nonstandard analysis which are neither true nor false”, it should be emphasized that this is a meta-statement about the cheap model. Inside the cheap model it is of course the case that the statement “there is a proposition which is neither true not false” is false, i.e., inside the model we do have “¬(P ∧¬P)” simply because this is intuitionisticically valid.")

#text("Erik Palmgren has studied constructive non-standard analysis, see ")#link("http://www.jstor.org/stable/421031")[#text("http://www.jstor.org/stable/421031")]#text(". Rather than fixing a particular filter, like you do, he used a variable filter. I think that got him more mileage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28cc6f7cb13746fb7ada8107e4cd16e305746899349cadbe9a61fd8ef876dc9b-0cd9ed5a764100cee8c7a92d99976b36ca7321afe22b62342bfa8e2ac2f59502.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrejbauer")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136637")[#strong[#text("andrejbauer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("Oh, and I forgot to mention that Erik’s paper contains a reference to the first construction of a non-standard model, by Schmeiden and Laugwitz from 1958, which was in fact the cheap model you describe, and it was constructive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ab22aa3b07dedcdd57b1850cb788dbaf778576436565e07a2b7a8d3bb9a058-126d492a274a39b4edd5dae0d735aa858551774f0c0f65717e4bacdb0b5af1b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-137532")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2012")])]

#text("Here is a link to the paper by Curt Schmieden and Detlef Laugwitz:")#linebreak()#text(" Eine Erweiterung der Infinitesimalrechnung. Mathematische Zeitschrift 69, 1958, pages.1-39.")#linebreak()#text(" ")#link("http://gdz.sub.uni-goettingen.de/no_cache/dms/load/img/?IDDOC=159786")[#text("http://gdz.sub.uni-goettingen.de/no_cache/dms/load/img/?IDDOC=159786")]

#text("As Robinson’s work on Nonstandandard analysis appeared soon after this paper, and as Robinson’s approach was quite succesful, the paper by Schmieden and Laugwitz is possibly not as well known as it deserves to be. It appears to me that for many applications an easier version (like Schmieden and Laugwitz and the current blog post) may have indeed pedagogical value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-142240")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2012")])]

#text("I would take the claim that the “first” construction of a non-standard model was given in 1958 by Schmieden and Laugwitz, with a grain of salt. First, Skolem constructed non-standard integers in 1934. Furthermore, E. Hewitt in 1948 constructed the hyper-reals (he coined the term), and Los proved what amounted to the transfer principle for them in 1955. Thus, three years before Schmieden and Laugwitz, a full infinitesimal theory was in place. It took Robinson to notice this.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8b9175a7e37933538e7f8d8229b0c35d0d26c9f63e23b27577444914c21595c-41a62dd534e254935bfe41da51ef0feaeb24404406377836fccbce4063d2dde3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-136774")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("I think that in parts 2,3 of exercises 2 and 3, “")#mi("f(y)")#text(" is infinitesimally close to ")#mi("x")#text("” should be “")#mi("f(y)")#text(" is infinitesimally close to ")#mi("f(x)")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9538e494b864bbc3c19d336ed593bd3650b65cfa9cce312c788028e91252fb57-750e927b283355a7ba2872771c19f17c0f92a1f5e2aab80dbb321f52723cd5f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Church")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-139648")[#strong[#text("Tom Church")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2012")])]

#text("The second parts of Exercises 2 and 3 still have $x$ instead of $f(x)$.")

#emph[#text("[Hopefully this edit fixes the problem -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-138890")[#strong[#text("Cheap non-standard analysis and expressions of certainty « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2012")]

#text("[…] liked Terry’s post on cheap nonstandard analysis. I’ll add one linguistic comment. As Terry points out, you lose the law of the excluded […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-141898")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("Thanks for this nice post. I have a question about applications. Can the cheap vesion of nsa as above be used in order to prove, for example, the mean value theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-141911")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2012")])]

#text("Yes, but the proofs are basically thinly disguised versions of more familiar sequential type proofs on analysis. For instance, consider the simpler result that every continuous function ")#mi("f:[0,1] \\to {\\bf R}")#text(" is bounded. If not, we can find standard ")#mi("x \\in [0,1]")#text(" for which ")#mi("f(x) \\geq n")#text(" for any given standard n, hence by saturation we can find cheap-nonstandard ")#mi("x \\in {}^*[0,1]")#text(" for which ")#mi("f(x)")#text(" is unbounded. Passing to a subsequence so that ")#mi("x")#text(" has a standard part ")#mi("st(x)")#text(", we see that ")#mi("f(x)")#text(" is not infinitesimally close to ")#mi("f(st(x))")#text(", contradicting differentiability. Similar arguments show that every continuous function attains a maximum, and then one can prove Rolle’s theorem, and then the mean value theorem, by minor variants of the usual arguments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of katz")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-142042")[#strong[#text("katz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2012")])]

#text("What I was wondering about is the mean value theorem for an infinitesimal interval, rather than the traditional mean value theorem. This question was posed by Felix Klein in 1908 and also by Abraham Fraenkel in 1926. They both viewed this as a criterion for the usefulness of a theory of infinitesimals. They both concluded that the theories available at the time did not meet this criterion. Note that the combination of the work of Hewitt of 1948 and that of Los of 1955 provides a framework that does satisfy the Klein-Fraenkel criterion. This is of course Robinson’s framework. Is there a cheap version of nsa that would satisfy the Klein-Fraenkel criterion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b466adb12dfc3cbcad0a24f6aa853a292c35d608ba684fe55a4fe08eca7b1f2d-d60e2fe2b0b7cfb7d2570703ee826833443d59c4406a305740f5b5a5967c9950.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Henle")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-181942")[#strong[#text("Jim Henle")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("I believe a version of the Mean Value Theorem holds in the cheap")#linebreak()#text(" version of nsa described here. The Transfer Principle holds for the")#linebreak()#text(" following set $\\mathcal H$ of statements: Take all atomic statements")#linebreak()#text(" and close under conjunction, universal and existential quantification,")#linebreak()#text(" and what I call “universal implication”. What I mean is, if $P(a)$")#linebreak()#text(" and $Q(a)$ are in $\\mathcal H$ for all constants a (standard or")#linebreak()#text(" nonstandard), then $\\forall x(P(x)\\Rightarrow Q(x))$ is also in")#linebreak()#text(" $\\mathcal H$. You can prove that any statement in $\\mathcal H$ true")#linebreak()#text(" about the real numbers is true about the cheap hyperreal numbers.")

#text("Then for real functions $f$ and $g$, there is a statement in $\\mathcal")#linebreak()#text(" H$ which says that $g$ is the derivative of $f$ at all points or at")#linebreak()#text(" all points in an interval. It is not difficult then to write a")#linebreak()#text(" statement $\\mathcal H$ equivalent to the Mean Value Theorem for $f$.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b466adb12dfc3cbcad0a24f6aa853a292c35d608ba684fe55a4fe08eca7b1f2d-d60e2fe2b0b7cfb7d2570703ee826833443d59c4406a305740f5b5a5967c9950.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Henle")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-175323")[#strong[#text("Jim Henle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2012")])]

#text("David Cohen and I wrote a calculus text which uses cheap nonstandard analysis in a disguised form, “Calculus: The Language of Change”, Jones and Bartlett, 2005. See especially chapters 5 and 12.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A mathematical formalisation of dimensional analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-211404")[#strong[#text("A mathematical formalisation of dimensional analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("[…] objects is analogous to the distinction between standard and (cheap) nonstandard objects in (cheap) nonstandard analysis. However, whereas in nonstandard analysis the underlying parameter is usually thought of as an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-232396")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("[…] will also need some asymptotic notation (in the spirit of “cheap nonstandard analysis“). We will need a parameter that one should think of going to infinity. Some mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-255861")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] to construct. We will not discuss such methods here, but see e.g. this paper of Palmgren. (See also this previous blog post for a “cheap” version of nonstandard analysis which uses the Frechet filter rather than […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real analysis relative to a finite measure space | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-394746")[#strong[#text("Real analysis relative to a finite measure space | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("[…] is particularly close when comparing with the “cheap nonstandard analysis” discussed in this previous blog post. We will also use “relative to ” as a synonym for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-458474")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] to be with respect to the parameter, e.g. means that for some fixed . (In the language of this previous blog post, we are thus implicitly using “cheap nonstandard analysis”, although we will not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b2ba8e95e99e6be84d8a407be5212ffee7d3b725b84e774374cf101763563e-3bdd8ba41e6d51a006749a8c3e9485db8f0f9b43debdb44c12fe882760214feb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saghe")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-467238")[#strong[#text("saghe")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2016")])]

#link("https://hal.inria.fr/hal-01248379/")[#text("https://hal.inria.fr/hal-01248379/")]#linebreak()#text(" in this link, we can find a new non approach to nonstandard analysis without using the model theory")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-487758")[#strong[#text("@no identd (@no_identd)")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2017")]

#text("You might wish to edit the following sentence from the post above:")

#text("“it is constructive (in the sense of not requiring any sort of choice-type axiom)”")

#text("…in lieu of the following result by Jon M. Sterling, showing that there does exist a version of the Axiom of Choice which DOES NOT imply the law of the excluded middle (and/or vice versa): ")#link("http://www.jonmsterling.com/posts/2015-04-24-note-on-diaconescus-theorem.html")[#text("http://www.jonmsterling.com/posts/2015-04-24-note-on-diaconescus-theorem.html")]

#text("Martin-Löf previously showed this in his paper “100 years of Zermelo’s axiom of choice: what was the problem with it?”, Martin-Löf’s paper falsely pinned the ‘blame’, so to speak, on extensionality, where really, it sat somewhere else entirely.")

#text("Technically, of course, this fails to in any way make that quoted sentence /wrong/ in any way, but the sentence would then seem to propagates the – now shown by Sterling as such – myth that Constructivism=Absence of AC; whereas really, and as you get to later anyway, Constructivism=Absence of LEM (or, as Sterling calls it, PEM).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for Kemperman’s inequality | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-488841")[#strong[#text("An inverse theorem for Kemperman’s inequality | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2017")])]

#text("[…] the language of “cheap” nonstandard analysis (aka asymptotic analysis), as discussed in this previous blog post; one could also have used the full-strength version of nonstandard analysis, but this does not seem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-508597")[#strong[#text("254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("[…] I discussed in a previous post, the manipulation of sequences and their limits is analogous to a “cheap” version of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-512548")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")])]

#text("Instead of using a nonintuionisitc logic, could one instead use a standard theory that is incomplete? So instead of “some things are neither true nor false”, you would say “some things are neither provable nor disprovable”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/289bbefa17a49a643a9e79e61d43de97158e840b59f753ea84b3ef3b64e045ad-35b6e8d7fa87950a12991d66ceecc92e20b6f9fa943d2ba5f4dc368d0e0fd925.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michelangelo")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-606318")[#strong[#text("Michelangelo")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("A little bibliographic note: the cheap non-standard analysis was invented in 1910 by Giuseppe Peano.")#linebreak()#text(" Giuseppe Peano, “Sugli ordini degli infiniti”, Atti della Reale Accademia dei Lincei: Rendiconti, 1910, s. 5, v. 19, pp. 778-781.")

#link("http://operedigitali.lincei.it/rendicontiFMN/rol/pdf/S5V19T1A1910P778_781.pdf")[#text("Click to access S5V19T1A1910P778_781.pdf")]

#text("The article is in Italian and is not known by the Italians themselves, so it is not surprising that it is not known in the English-speaking world.")#linebreak()#text(" The key point is formula (3), page 780.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0b78abd36bbcffaddcb36d4f4b0208a026643f09c907fa70d7eac29fb5e5332-b6da463146f4172baf43894e145e86b3d9c2ab46b65d67ced6b3d2bad1585ead.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-606432")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2020")])]

#text("Some of the comments in this thread involve an implicit assumption that working with Robinson-style infinitesimals in the context of a number system which is actually a field, necessarily requires a nonprincipal ultrafilter. Such an assumption turns out to be incorrect. Karel Hrbacek and I developed an axiom system SPOT, conservative over ZF (and therefore requiring neither ultrafilters nor the axiom of choice), which enables infinitesimal calculus a la Robinson. There is also a stronger system SCOT, conservative over ZF+ADC (dependent choice), which enables infinitesimal analysis and much else, including an infinitesimal treatment of the Lebesgue measure a la Loeb. See ")#link("https://u.math.biu.ac.il/~katzmik/spot.html")[#text("https://u.math.biu.ac.il/~katzmik/spot.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sendov’s conjecture for sufficiently high degree polynomials | What's new")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-608988")[#strong[#text("Sendov’s conjecture for sufficiently high degree polynomials | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2020")])]

#text("[…] There are many ways to effect such a strategy; we will use a formalism that I call “cheap nonstandard analysis” and which is common in the PDE literature, in which one repeatedly passes to subsequences as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-611732")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2020")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2020/12/21/a-cheap-version-of-nonstandard-analysis/")[#text("Aditya Guha Roy's weblog")]#text(" and commented:")#linebreak()#text(" Here is a blog post on non-standard analysis which I just read today. For more details on non-standard analysis one can check prof. Terence Tao’s book titled “Compactness and contradiction”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-612133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2020")])]

#text("… for instance, a nonstandard real is a real number ")#mi("{x = x_{\\bf n}}")#text(" that depends on the asymptotic parameter ")#mi("{{\\bf n}}")#text(";…")

#text("How should one understand the identity ")#mi("{x = x_{\\bf n}}")#text(" here?")

#text("Is the object “")#mi("x_{\\bf n}")#text("” understood as a sequence ")#mi("(x_n)_{n=1}^\\infty")#text(" of real number?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-612187")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2020")])]

#text("The notation ")#mi("x = x_{\\bf n}")#text(" indicates that the dependence on ")#mi("{\\bf n}")#text(" will often be suppressed, so that ")#mi("x_{\\bf n}")#text(" will be abbreviated as ")#mi("x")#text(" when it is not necessary to make the dependence on ")#mi("{\\bf n}")#text(" explicit.")

#text("As stated in the text (see in particular Example 1), it is ")#link("https://en.wikipedia.org/wiki/Map%E2%80%93territory_relation")[#text("slightly better")]#text(" to think about ")#mi("x")#text(" as a quantity that depends on ")#mi("{\\bf n}")#text(" as an ambient parameter, rather than as a sequence over all possible values of ")#mi("{\\bf n}")#text(". This is somewhat analogous (though not identical) to how a function ")#mi("T: X \\to Y")#text(" is usually best thought conceptually of as a transformation that maps arbitrary elements in ")#mi("X")#text(" to various points in ")#mi("Y")#text(", rather than a tuple ")#mi("(T(x))_{x \\in X}")#text(" or a graph ")#mi("\\{ (x, T(x)): x \\in X \\}")#text(", even if from a purely set theoretic point of view these models are a faithful representation of the transformation concept.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-641606")[#strong[#text("clique principle - Interpreting Conway's comment about utilizing the surreals for non-standard evaluation Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2022")]

#text("[…] with a bunch of definable properties and depart the relaxation launch; Terry Tao has written some very attention-grabbing stuff in that path which he calls “cheap nonstandard analysis.” So if Conway’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-680765")[#strong[#text("What Are Numbers? | Physics Forums")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-682285")[#strong[#text("What Are Numbers? -")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2023")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-687011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2025")])]

#text("In this paper, ")#link("https://www.researchgate.net/publication/331163198_A_New_Approach_to_Nonstandard_Analysis")[#text("https://www.researchgate.net/publication/331163198_A_New_Approach_to_Nonstandard_Analysis")]#text(" we find a new approach to construct the field of the inifnitesimal numbers without using the ultrafilters, in this method, we use a subeset different to IR^IN for the construction of the new numbers")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-687101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2025")])]

#text("Dear Terrence, this is an older post, but very interesting. I wonder how the cheap n.s.a. would help to render for example the intuitive 3-line proof of Fejer’s thm “rigorous”. First step:")

#tao-math("\\displaystyle \\int k_n(x-y) f(y) dy \\approx  \\int_{\\left|x-y\\right|<\\epsilon}  k_n(x-y) f(y)dy", block: false)

#text("by uniform convergence of Fejer kernels ")#mi("k_n")#text(" to zero outside any compact. Second step: since ")#mi("f")#text(" is continuous,")

#tao-math("\\displaystyle \\int_{\\left|x-y\\right|<\\epsilon}  k_n(x-y) f(y) dy  \\approx f(x)  \\int_{\\left|x-y\\right|<\\epsilon}  k_n(x-y) dy", block: false)

#text("Third and last step: extend integration region back, and use ")#mi("k_n")#text(" has integral one. It is of course not hard to transform this into a rigorous proof, but we have to fix ")#mi("\\epsilon")#text(" first, then some ")#mi("n")#text(" according to a ")#mi("\\delta")#text(" given by ")#mi("f")#text(" and so forth. How would “cheap n.s.a.” simplify the handling of such “nested” dependencies of epsilon’s?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/#comment-687112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2025")])]

#text("Yes, one can use either the cheap or the full form of nonstandard analysis to make this argument precise. The one slightly nontrivial thing is that one has to take advantage of the underspill principle and what I like to call the automatic uniformity principle (closely related to the omega-saturation property of nonstandard models). See for instance ")#link("https://teorth.github.io/expdb/blueprint/notation-chapter.html#a0000000003")[#text("https://teorth.github.io/expdb/blueprint/notation-chapter.html#a0000000003")]#text(" for a discussion.")
]
]
