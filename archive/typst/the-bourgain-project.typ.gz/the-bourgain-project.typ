// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/
// Converted to Typst by tao2typ: "2026-11-20T15:40:44.816896+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Bourgain Project", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Bourgain Project")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/")[#text("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-20 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://liehr.xyz/")[#text("Lukas Liehr")]#text(", ")#link("https://sites.google.com/view/gionnoramos/home")[#text("João Pedro Ramos")]#text(" and ")#link("https://mitchtaylormath.ca/")[#text("Mitchell Taylor")]#text(" – T.]")]

#text("We are launching the Bourgain Project, a community-driven initiative to revisit, expand upon, and explore the body of work of Jean Bourgain, one of the most prolific mathematicians of his time. The goal of this initiative is to develop a deep, comprehensive understanding of each one of Bourgain’s over 500 individual papers, while discussing and connecting the common threads and unifying ideas that run throughout his research.")#linebreak()#linebreak()#text("Bourgain made numerous contributions across many fields, such as harmonic analysis, number theory, partial differential equations, and functional analysis. However, many of his papers are notoriously difficult to grasp. Our initiative aims to make his ideas more accessible to the broader mathematical community.")#linebreak()#linebreak()#text("In addition to digesting Bourgain’s contributions, another main goal of the project is to explore new formats for presenting mathematics beyond the traditional journal article. We encourage contributors to share digestions and expositions of his papers in whatever form, to collaborate in groups, and to engage in discussions on our ")#link("https://bourgain-pedia.com/zulip")[#text("community Zulip channel.")]#linebreak()#linebreak()#text("For more information, we invite anyone interested to visit our website at ")#link("https://bourgain-pedia.com/")[#text("https://bourgain-pedia.com/")]#text(", and check out our ")#link("https://bourgain-pedia.com/digested")[#text("latest article digestions.")]

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc12d54dad69152bd760c680f234fd7409e064aab7c52a7d7ab0eb495dc3c860-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of igorrivin")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698398")[#strong[#text("igorrivin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("By an interesting coincidence, I have been doing something along these lines, and the results are not quite what I would have hoped for. Check out ")#link("https://mathreferee.dimensionreducers.ai")[#text("https://mathreferee.dimensionreducers.ai")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Igor Rivin, always trying to attach himself to the next big thing. I guess this is epsilon less degrading than managing a Russian oligarch’s money…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc12d54dad69152bd760c680f234fd7409e064aab7c52a7d7ab0eb495dc3c860-9b53f60821e931e171c610b1f40ed8d8962e378d5b89007a46bbe8ce84295827.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of igorrivin")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698448")[#strong[#text("igorrivin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Thank you, Anonymous Coward, for your slanderous statements. I wish I did manage a Russian oligarch’s money, though.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698470")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("There have been many questions on MathOverflow over the years of the form “I am trying to understand a technical step in a paper of Bourgain…”: see the comments to ")#link("https://mathoverflow.net/questions/121751")[#text("https://mathoverflow.net/questions/121751")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlya2e7c26b8c")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698483")[#strong[#text("boldlya2e7c26b8c")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#link("https://www.ams.org/journals/notices/202011/rnoti-p1716.pdf")[#text("https://www.ams.org/journals/notices/202011/rnoti-p1716.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698496")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Can I just suggest to find another name instead of “digestion”? Because we all know what is the end product of a digestion, maybe we could find some better naming. Besides jokes, this seems a great project honestly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01778383462074d1b4bb2c5b4e334c71cf386cbbea5b7611d73c5e838567f775-4b5cfe8cce91cfc71c32b936f7ece820fae589f8a2843ce02920e73f4d080e95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of el houcein")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/#comment-698920")[#strong[#text("el houcein")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2026")])]

#text("I’m posting here my email on Zulip, hopefully, it will reach more colleagues :")

#text("“Dear All")#linebreak()#text("I would be happy to start a collaboration on digesting the following paper of Bourgain: J. Bourgain, ")#emph[#text("Double recurrence and almost sure convergence")]#text(", J. Reine Angew. Math. 404 (1990), pp. 140-161.")

#text("This is one of Bourgain’s more difficult papers. A useful companion paper is available here: ")#link("https://arxiv.org/pdf/2012.06323")[#text("https://arxiv.org/pdf/2012.06323")]#text(". THis later paper was revised after un e-exchange of email with Prof. Terrence Tao!")

#text("I would like to specify that this digestion should be carried out in the spirit of the corollary of my recent paper: ")#link("https://arxiv.org/abs/2610.30797")[#text("https://arxiv.org/abs/2610.30797")]#text(". In particular, we may need to formalize Bourgain’s paper in Lean.")

#text("I hope to hear from any colleagues who are interested in the project.")

#text("With best regards,")#linebreak()#text("el-Houcein”")
]
