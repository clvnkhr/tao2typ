// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/
// Converted to Typst by tao2typ: "2026-10-20T11:54:12.014344+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Bourgain Project", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Bourgain Project")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/")[#text("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-20 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://liehr.xyz/")[#text("Lukas Liehr")]#text(", ")#link("https://sites.google.com/view/gionnoramos/home")[#text("João Pedro Ramos")]#text(" and ")#link("https://mitchtaylormath.ca/")[#text("Mitchell Taylor")]#text(" – T.]")]

#text("We are launching the Bourgain Project, a community-driven initiative to revisit, expand upon, and explore the body of work of Jean Bourgain, one of the most prolific mathematicians of his time. The goal of this initiative is to develop a deep, comprehensive understanding of each one of Bourgain’s over 500 individual papers, while discussing and connecting the common threads and unifying ideas that run throughout his research.")#linebreak()#linebreak()#text("Bourgain made numerous contributions across many fields, such as harmonic analysis, number theory, partial differential equations, and functional analysis. However, many of his papers are notoriously difficult to grasp. Our initiative aims to make his ideas more accessible to the broader mathematical community.")#linebreak()#linebreak()#text("In addition to digesting Bourgain’s contributions, another main goal of the project is to explore new formats for presenting mathematics beyond the traditional journal article. We encourage contributors to share digestions and expositions of his papers in whatever form, to collaborate in groups, and to engage in discussions on our ")#link("https://bourgain-pedia.com/zulip")[#text("community Zulip channel.")]#linebreak()#linebreak()#text("For more information, we invite anyone interested to visit our website at ")#link("https://bourgain-pedia.com/")[#text("https://bourgain-pedia.com/")]#text(", and check out our ")#link("https://bourgain-pedia.com/digested")[#text("latest article digestions.")]

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ec3ef1e7e0384b7a0cf6873f679ea6966daa6ae914c906a1da24ab6dfe28321-6d07e44ed8fe0c00b3d9184382ecd2352369188e7e175e9752e9c79899d9f2d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of igorrivin")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/comment-page-1/#comment-698398")[#strong[#text("igorrivin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("By an interesting coincidence, I have been doing something along these lines, and the results are not quite what I would have hoped for. Check out ")#link("https://mathreferee.dimensionreducers.ai")[#text("https://mathreferee.dimensionreducers.ai")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/19/the-bourgain-project/comment-page-1/#comment-698418")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Igor Rivin, always trying to attach himself to the next big thing. I guess this is epsilon less degrading than managing a Russian oligarch’s money…")
]
]
