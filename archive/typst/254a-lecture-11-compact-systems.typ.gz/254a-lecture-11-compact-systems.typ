// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/
// Converted to Typst by tao2typ: "2026-10-14T16:35:12.055627+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 11: Compact systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 11: Compact systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")[#text("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The primary objective of this lecture and the next few will be to give a proof of the Furstenberg recurrence theorem (Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("the previous lecture")]#text("). Along the way we will develop a structural theory for measure-preserving systems.")

#text("The basic strategy of Furstenberg’s proof is to first prove the recurrence theorems for very simple systems – either those with “almost periodic” (or ")#emph[#text("compact")]#text(") dynamics or with “weakly mixing” dynamics. These cases are quite easy, but don’t manage to cover all the cases. To go further, we need to consider various combinations of these systems. For instance, by viewing a general system as an extension of the maximal compact factor, we will be able to prove Roth’s theorem (which is equivalent to the k=3 form of the Furstenberg recurrence theorem). To handle the general case, we need to consider compact extensions of compact factors, compact extensions of compact extensions of compact factors, etc., as well as weakly mixing extensions of all the previously mentioned factors.")

#text("In this lecture, we will consider those measure-preserving systems ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" which are ")#emph[#text("compact")]#text(" or ")#emph[#text("almost periodic")]#text(". These systems are analogous to the equicontinuous or isometric systems in topological dynamics discussed in ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(", and as with those systems, we will be able to characterise such systems (or more precisely, the ergodic ones) algebraically as Kronecker systems, though this is not strictly necessary for the proof of the recurrence theorem.")

#heading(level: 1)[#metadata(none) <tao-4ef81c5e42876374e33d>#text(" — Almost periodic functions —")]

#text("We begin with a basic definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system. A function ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" is ")#emph[#text("almost periodic")]#text(" if the orbit closure ")#mi("\\overline{\\{ T^n f: n \\in {\\Bbb Z} \\}}")#text(" is compact in ")#mi("L^2(X, {\\mathcal X},\\mu)")#text(".")
]

#strong[#text("Example 1.")]#text(" If f is periodic (i.e. ")#mi("T^n f = f")#text(" for some ")#mi("n > 0")#text(") then it is clearly almost periodic. In particular, any shift-invariant function (such as a constant function) is almost periodic. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" In the circle shift system ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(", every function ")#mi("f \\in L^2({\\Bbb R}/{\\Bbb Z})")#text(" is almost periodic, because the orbit closure lies inside the set ")#mi("\\{ f(\\cdot+\\theta): \\theta \\in {\\Bbb R}/{\\Bbb Z} \\}")#text(", which is the continuous image of a circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" and therefore compact. ")#mi("\\diamond")

#strong[#text("Exercise 1. ")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(". Show that f is almost periodic in the ergodic theory sense (i.e. Definition 1 above) if and only if it is almost periodic in the topological dynamical systems sense (see ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text("), i.e. if the sets ")#tao-math("\\{ n \\in {\\Bbb Z}: \\left\\|T^n f - f \\right\\|_{L^2(X,{\\mathcal X},\\mu)} \\leq \\varepsilon \\}", block: false)#text(" are ")#link("http://en.wikipedia.org/wiki/Syndetic")[#text("syndetic")]#text(" for every ")#mi("\\varepsilon > 0")#text(". (")#emph[#text("Hint:")]#text(" if f is almost periodic in the ergodic theory sense, show that the orbit closure is an isometric system and thus a Kronecker system, at which point Theorem 2 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(" can be applied. For the converse implication, use the ")#link("http://en.wikipedia.org/wiki/Heine-Borel_theorem")[#text("Heine-Borel theorem")]#text(" and the isometric nature of T on ")#mi("L^2")#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 2. ")]#text(" Let ")#mi("(X, {\\mathcal X},\\mu,T)")#text(" be a measure-preserving system. Show that the space of almost periodic functions in ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" is a closed shift-invariant subspace which is also closed under the pointwise operations ")#mi("f, g \\mapsto \\max(f,g)")#text(" and ")#mi("f, g \\mapsto \\min(f,g)")#text(". Similarly, show that the space of almost periodic functions in ")#mi("L^\\infty(X,{\\mathcal X},\\mu)")#text(" is a closed subspace which is also an algebra (closed under products) as well as closed under ")#mi("\\max")#text(" and ")#mi("\\min")#text(". ")#mi("\\diamond")

#strong[#text("Exercise 3. ")]#text(" Show that in any Bernoulli system ")#mi("\\Omega^{\\Bbb Z}")#text(", the only almost periodic functions are the constants. (Hint: first show that if ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" has mean zero, then ")#mi("\\lim_{n \\to \\infty} \\int_X f T^n f\\ d\\mu = 0")#text(", by first considering elementary functions. ")#mi("\\diamond")

#text("Let us now recall the Furstenberg recurrence theorem, which we now phrase in terms of functions rather than sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text(" (Furstenberg recurrence theorem) Let ")#mi("(X, {\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, let ")#mi("k \\geq 1")#text(", and let ")#mi("f \\in L^\\infty(X,{\\mathcal X},\\mu)")#text(" be a non-negative function with ")#mi("\\int_X f\\ d\\mu > 0")#text(". Then we have ")#mi("\\liminf_{N \\to \\infty} \\frac{1}{N} \\sum_{r=0}^{N-1} \\int_X f T^r f \\ldots T^{(k-1)r} f > 0")#text(".")
]

#strong[#text("Exercise 4. ")]#text(" Show that Theorem 1 is equivalent to Theorem 2 from the ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("previous lecture")]#text(". ")#mi("\\diamond")

#text("We can now quickly establish this theorem in the almost periodic case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Theorem 1 is true whenever f is almost periodic.")
]

#strong[#text("Proof.")]#text(" Without loss of generality we may assume that f is bounded a.e. by 1. Let ")#mi("\\varepsilon > 0")#text(" be chosen later. Recall from Exercise 1 that ")#mi("T^n f")#text(" lies within ")#mi("\\varepsilon")#text(" of f in the ")#mi("L^2")#text(" topology for a syndetic set of n. For all such n, one also has ")#tao-math("\\left\\| T^{(j+1)n} f - T^{jn} f \\right\\|_{L^2(X,{\\mathcal X},\\mu)} \\leq \\varepsilon", block: false)#text(" for all j, since T acts isometrically. By the triangle inequality, we conclude that ")#mi("T^{jn} f")#text(" lies within ")#mi("O_k(\\varepsilon)")#text(" of f in ")#mi("L^2")#text(" for ")#mi("0 \\leq j \\leq k")#text(". On the other hand, from Hölder’s inequality we see that on the unit ball of ")#mi("L^\\infty(X, {\\mathcal X}, \\mu)")#text(" with the ")#mi("L^2")#text(" topology, pointwise multiplication is Lipschitz. Applying this fact repeatedly, we conclude that for n in this syndetic set, ")#mi("f T^n f \\ldots T^{(k-1)n} f")#text(" lies within ")#mi("O_k(\\varepsilon)")#text(" in ")#mi("L^2")#text(" of ")#mi("f^k")#text(". In particular,")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X f T^n f \\ldots T^{(k-1)n} f\\ d\\mu = \\int_X f^k\\ d\\mu + O_k(\\varepsilon).")]]

#text("On the other hand, since ")#mi("\\int f\\ d\\mu > 0")#text(", we must have ")#mi("\\int_X f^k\\ d\\mu > 0")#text(". Choosing ")#mi("\\varepsilon")#text(" sufficiently small, we thus see that the left-hand side of (1) is uniformly bounded away from zero in a syndetic set, and the conclusion of Theorem 1 follows. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" Because f lives in a Kronecker system, one can also obtain the above result using various multiple recurrence theorems from topological dynamics, such as Proposition 3 from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(" or the Birkhoff multiple recurrence theorem from ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text(" (though to get the full strength of the results, one needs to use either syndetic van der Waerden theorem, see Exercise 15.3 from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text(", or the Varnavides averaging trick from the ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("previous lecture")]#text("). We leave the details to the reader. ")#mi("\\diamond")

#heading(level: 1)[#text("— Kronecker systems and Haar measure —")]

#text("We have seen how nice almost periodic functions are. Motivated by this, we define")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2. ")]#text(" A measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" is said to be compact if every function in ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(" is almost periodic.")
]

#text("Thus, for instance, by Example 2, the circle shift system is compact, but from Exercise 3, no non-trivial Bernoulli system is compact. From Proposition 1 we know that the Furstenberg recurrence theorem is true for compact systems.")

#text("One source of compact systems comes from ")#emph[#text("Kronecker systems")]#text(", as introduced in ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(". As such systems are topological rather than measure-theoretic, we will need to endow them with a canonical measure – ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" – first.")

#text("Let G be a compact metrisable topological group (not necessarily abelian). Without an ambient measure, we cannot yet define the convolution ")#mi("f*g")#text(" of two continuous functions ")#mi("f, g \\in C(G)")#text(". However, we can define the convolution ")#mi("\\mu*f")#text(" of a finite Borel measure ")#mi("\\mu")#text(" on G and a continuous function ")#mi("f \\in C(G)")#text(" to be the function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mu * f(x) := \\int_G f(y^{-1} x)\\ d\\mu(y),")]]

#text("which (by the uniform continuity of f) is easily seen to be another continuous function. We similarly define")

#align(center)[#mi("f * \\mu(x) := \\int_G f(x y^{-1})\\ d\\mu(y).")#text(" (2′)")]

#text("Also, one can define the convolution ")#mi("\\mu * \\nu")#text(" of two finite Borel measures to be the finite Borel measure defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mu*\\nu(E) := \\int_G \\nu( y^{-1} \\cdot E )\\ d\\mu(y)")]]

#text("for all Borel sets E. For instance, the convolution ")#mi("\\delta_x * \\delta_y")#text(" of two Dirac masses is another Dirac mass ")#mi("\\delta_{xy}")#text(". Fubini’s theorem tells us that the convolution of two finite measures is another finite measure. Convolution is also bilinear and associative (thus ")#mi("(\\mu*\\nu)*\\rho = \\mu*(\\nu*\\rho)")#text(", ")#mi("f *(\\mu*\\nu)=(f*\\mu)*\\nu")#text(", ")#mi("(\\mu*f)*\\nu = \\mu*(f*\\nu)")#text(", and ")#mi("(\\mu*\\nu)*f = \\mu*(\\nu*f)")#text(" for measures ")#mi("\\mu,\\nu,\\rho")#text(" and continuous f); in particular, left-convolution and right-convolution commute. Also observe that the convolution of two Borel probability measures is again a Borel probability measure. Convolution also has a powerful ")#emph[#text("smoothing effect")]#text(" that can upgrade weak convergence to strong convergence. Specifically, if ")#mi("\\mu_n")#text(" converges in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague sense")]#text(" to ")#mi("\\mu")#text(", and f is continuous, then an easy application of compactness of the underlying group G reveals that ")#mi("\\mu_n*f")#text(" converges in the ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniform sense")]#text(" to ")#mi("\\mu*f")#text(".")

#text("Let us say that a number c is a ")#emph[#text("left-mean")]#text(" (resp. ")#emph[#text("right-mean")]#text(") of a continuous function ")#mi("f \\in C(G)")#text(" if there exists a probability measure ")#mi("\\mu")#text(" such that ")#mi("\\mu*f")#text(" (resp. ")#mi("f*\\mu_n")#text(") is equal to a constant c. For compact metrisable groups G, this mean is well defined:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" (Existence and uniqueness of mean) Let G be a compact metrisable topological group, and let ")#mi("f \\in C(G)")#text(". Then there exists a unique constant c which is both a left-mean and right-mean of f.")
]

#strong[#text("Proof. ")]#text(" Without loss of generality we can take f to be real-valued. Let us first show that there exists a left-mean. Define the oscillation of a real-valued continuous function to be the difference between its maximum and minimum. By the vague sequential compactness of probability measures (Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text("), one can find a probability measure ")#mi("\\mu")#text(" which minimises the oscillation of ")#mi("\\mu*f")#text(". If this oscillation is zero, we are done. If the oscillation is non-zero, then (using the compactness of the group and the transitivity of the group action) it is not hard to find a finite number of left rotations of ")#mi("\\mu*f")#text(" whose average has strictly smaller oscillation than that of ")#mi("\\mu*f")#text(" (basically by rotating the places where ")#mi("\\mu*f")#text(" is near its maximum to cover where it is near its mimum). Thus we have a finitely supported probability ")#mi("\\nu")#text(" with ")#mi("\\nu*\\mu*f")#text(" having smaller oscillation than ")#mi("\\mu*f")#text(", a contradiction. We thus see that a left-mean exists. Similarly, a right-mean exists. But since left-convolution commutes with right-convolution, we see that all left-means are equal to all right-means, and the claim follows. ")#mi("\\diamond")

#text("The map ")#mi("f \\mapsto c")#text(" from a continuous function to its mean is a bounded non-negative linear functional on C(G) which preserves constants, and thus by the Riesz representation theorem is given by a unique probability measure ")#mi("\\mu")#text("; since left- and right-convolution commute, we see that this measure is both left- and right- invariant. Conversely, given any such measure ")#mi("\\mu")#text(" we easily see (again using the commutativity of left-and right-convolution) that ")#mi("f*\\mu = \\mu*f = c")#text(". We have thus shown")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text("(Existence and uniqueness of Haar measure) If G is a compact metrisable topological group, then there exists a unique Borel probability measure ")#mi("\\mu")#text(" on G which is both left and right invariant.")
]

#text("In particular, every topological Kronecker system ")#mi("(K, x \\mapsto x+\\alpha)")#text(" can be canonically converted into a measure-preserving system, which is then compact by the same argument used to establish Example 2. (Actually this observation works for non-abelian Kronecker systems as well as abelian ones.)")

#strong[#text("Remark 2. ")]#text("One can also build left- and right- Haar measures for locally compact groups; these measures are locally finite Radon measures rather than Borel probability measures, and are unique up to constants; however it is no longer the case that such measures are necessarily equal to each other except in special cases, such as when the group is abelian or compact. These measures play an important role in the harmonic analysis and representation theory of such groups, but we will not discuss these topics further here. ")#mi("\\diamond")

#heading(level: 1)[#text("— Classification of compact systems —")]

#text("We have just seen that every Kronecker system is a compact system. The converse is not quite true; consider for instance the disjoint union of two Kronecker systems from different groups (with the probability measure being split, say, 50-50, between the two components). The situation is similar to that in ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(", in which every Kronecker system was equicontinuous and isometric, but the converse only held under the additional assumption of minimality. There is a similar situation here, but first we need to define the notion of ")#emph[#text("equivalence")]#text(" of two measure-preserving systems.")

#text("Define an ")#emph[#text("abstract measure-preserving system")]#text(" ")#mi("({\\mathcal X}, \\mu, T)")#text(" to be an abstract ")#link("http://en.wikipedia.org/wiki/Separable_sigma_algebra")[#text("separable")]#text(" ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text(" (which, by ")#link("http://en.wikipedia.org/wiki/Stone%27s_representation_theorem_for_Boolean_algebras")[#text("Stone’s theorem")]#text(", can be viewed as consisting of subsets of some ambient space X, though for our purposes it is better here to stay in the abstract world), together with an abstract probability measure ")#mi("\\mu: {\\mathcal X} \\to [0,1]")#text(" and an abstract invertible shift ")#mi("T: {\\mathcal X} \\to {\\mathcal X}")#text(" which preserves the measure ")#mi("\\mu")#text(" (but does not necessarily come from an invertible map ")#mi("T: X \\to X")#text(" on some ambient space). (An abstract measure space ")#mi("({\\mathcal X},\\mu)")#text(" is sometimes also known as a ")#emph[#text("measure algebra")]#text(".) There is an obvious notion of a morphism ")#mi("\\Phi: ({\\mathcal X}, \\mu, T) \\to ({\\mathcal Y},\\nu,S)")#text(" between abstract measure-preserving systems, in which ")#mi("\\Phi: {\\mathcal Y} \\to {\\mathcal X}")#text(" (note the contravariance) is a ")#mi("\\sigma")#text("-algebra homomorphism with ")#mi("\\nu = \\mu \\circ \\Phi")#text(" and ")#mi("S \\circ \\Phi = \\Phi \\circ T")#text(". This makes the class of abstract measure-preserving systems into a category. In particular we have a notion of two abstract measure-preserving systems being isomorphic.")

#strong[#text("Example 3.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a skew shift ")#mi("(y,z) \\mapsto (y+\\alpha,z+y)")#text(" and let ")#mi("(Y,{\\mathcal Y},\\nu,S)")#text(" be the underlying circle shift ")#mi("y \\mapsto y+\\alpha")#text(". These systems are of course non-isomorphic, although there is a factor map ")#mi("\\pi: X \\to Y")#text(" which is a morphism. If however we consider the ")#mi("\\sigma")#text("-algebra ")#mi("\\pi^\\#({\\mathcal Y}) \\subset {\\mathcal X}")#text(" (which are the Cartesian products of horizontal Borel sets with the vertical circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text("), we see that ")#mi("\\pi")#text(" induces an isomorphism between the abstract measure-preserving systems ")#mi("(\\pi^\\#({\\mathcal Y}), \\mu, T)")#text(" and ")#mi("({\\mathcal Y}, \\nu, S)")#text(". ")#mi("\\diamond")

#text("Given a concrete measure-preserving system ")#mi("(X,{\\mathcal X},\\mu,T)")#text(", we can define its ")#emph[#text("abstraction")]#text(" ")#mi("({\\mathcal X}/\\sim, \\mu, T)")#text(", where ")#mi("\\sim")#text(" is the equivalence relation of almost everywhere equivalence modulo ")#mi("\\mu")#text(". In category theoretic language, abstraction is a covariant ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" from the category of concrete measure-preserving systems to the category of abstract measure-preserving systems. We say that two concrete measure-preserving systems are ")#emph[#text("equivalent ")]#text("if their abstractions are isomorphic. Thus for instance, in Example 3 above, ")#mi("(X, \\pi^\\#({\\mathcal Y}), \\mu, T)")#text(" and ")#mi("(Y,  {\\mathcal Y}, \\nu, S)")#text(" are equivalent; there is no concrete isomorphism between these two systems, but once one abstracts away the underlying sets X and Y, we can recover an equivalence. As another example, we see that if we add or remove a null set to a measure-preserving system, we obtain an abstractly equivalent measure-preserving system.")

#strong[#text("Remark 3. ")]#text("Up to null sets, we can also identify an abstract measure-preserving system ")#mi("({\\mathcal X},\\mu,T)")#text(" with its ")#link("http://en.wikipedia.org/wiki/Abelian_von_neumann_algebra")[#text("abelian von Neumann algebra")]#text(" ")#mi("L^\\infty({\\mathcal X},\\mu)")#text(" (which acts on the Hilbert space ")#mi("L^2({\\mathcal X},\\mu)")#text(" by pointwise multiplication), together with an automorphism T of that algebra; conversely, one can recover the algebra ")#mi("{\\mathcal X}")#text(" as the idempotents ")#mi("1_E")#text(" of the von Neumann algebra, and the measure ")#mi("\\mu(E)")#text(" of a set being the trace of the idempotent ")#mi("1_E")#text(". A significant portion of ergodic theory can in fact be rephrased in terms of von Neumann algebras (which, in particular, naturally suggests a ")#link("http://en.wikipedia.org/wiki/Non-commutative_geometry")[#text("non-commutative")]#text(" generalisation of the subject), although we will not adopt this perspective here. ")#mi("\\diamond")

#text("Many results and notions about concrete measure-preserving systems ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" can be rephrased to not require knowledge of the underlying space X (and to be stable under modification by null sets), and so can be converted to statements about abstract measure-preserving systems; for instance, the Furstenberg recurrence theorem is of this form once one replaces “non-empty” with “positive measure” (see Exercise 1 from ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("Lecture 10")]#text("). The notion of ergodicity is also of this form. In particular, such results and notions automatically become preserved under equivalence. In view of this, the following classification result is of interest:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text(" (Classification of ergodic compact systems) Every ergodic compact system is equivalent to an (abelian) Kronecker system.")
]

#text("To prove this theorem, it is convenient to use a harmonic analysis approach. Define an ")#emph[#text("eigenfunction")]#text(" of a measure-preserving system ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" to be a bounded measurable function f, not a.e. zero, such that ")#mi("Tf = \\lambda f")#text(" a.e..")

#text("Let ")#mi("{\\mathcal Z}_1 \\subset {\\mathcal X}")#text(" denote the ")#mi("\\sigma")#text("-algebra generated by all the eigenfunctions. Note that this contains ")#mi("{\\mathcal Z}_0 := {\\mathcal X}^T")#text(", which is the ")#mi("\\sigma")#text("-algebra generated by the eigenfunctions with eigenvalue 1. We have the following fundamental result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2. ")]#text("(Description of the almost periodic functions) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be an ergodic measure-preserving system, and let ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(". Then f is almost periodic if and only if it lies in ")#mi("L^2(X,{\\mathcal Z}_1,\\mu)")#text(", i.e. if it is ")#mi("{\\mathcal Z}_1")#text("-measurable (note that ")#mi("{\\mathcal Z}_1")#text(" contains all null sets of ")#mi("{\\mathcal X}")#text(").")
]

#strong[#text("Remark 4.")]#text(" One can view ")#mi("(X,{\\mathcal Z}_1,\\mu,T)")#text(" as the maximal compact factor of ")#mi("(X,{\\mathcal X},\\mu,T)")#text(", in much the same way that ")#mi("(X,{\\mathcal Z}_0,\\mu,T)")#text(" is the maximal factor on which the system is essentially trivial (every function is essentially invariant). ")#mi("\\diamond")

#strong[#text("Proof. ")]#text("It is clear that every eigenfunction is almost periodic. From repeated application of Exercise 2 we conclude that the indicator of any set in ")#mi("{\\mathcal Z}_1")#text(" is also almost periodic, and thus (by more applications of Exercise 2) every function in ")#mi("L^2(X,{\\mathcal Z}_1,\\mu)")#text(" is almost periodic.")

#text("Conversely, suppose ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" is almost periodic. Then the orbit closure ")#mi("Y_f \\subset L^2(X,{\\mathcal X},\\mu)")#text(" of f is an isometric system; the orbit of f is clearly dense in ")#mi("Y_f")#text(", and thus by isometry the orbit of every other point is also dense. Thus ")#mi("Y_f")#text(" is minimal, and therefore Kronecker by Proposition 1 from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text("; thus we have an isomorphism ")#mi("\\phi: K \\to Y_f")#text(" from a group rotation ")#mi("(K, x \\mapsto x+\\alpha)")#text(" to ")#mi("Y_f")#text(". By rotating if necessary we may assume that ")#mi("\\phi(0) =f")#text(".")

#text("By Corollary 1, K comes with an invariant probability measure ")#mi("\\nu")#text(". The theory of ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Fourier analysis on compact abelian groups")]#text(" then says that ")#mi("L^2(K,\\nu)")#text(" is spanned by an (orthonormal) basis of ")#link("http://en.wikipedia.org/wiki/Character_%28mathematics%29")[#text("characters ")]#mi("\\chi")#text(". In particular, the Dirac mass at 0 (the group identity of K) can be expressed as the weak limit of finite linear combinations of such characters.")

#text("Now we need to move this information back to X. For this we use the operator ")#mi("S: L^2(K,\\nu) \\to L^2(X,{\\mathcal X},\\mu)")#text(" defined by ")#mi("Sh := \\int_K \\phi(y) h(y)\\ d\\nu(y)")#text("; one checks from Minkowski’s integral inequality that this is a bounded linear map. Because ")#mi("\\phi")#text(" is a morphism, and each character is an eigenfunction of the group rotation ")#mi("x \\mapsto x+\\alpha")#text(", one easily checks that the image ")#mi("S \\chi")#text(" of a character ")#mi("\\chi")#text(" is an eigenfunction. Since the image of the Dirac mass is (formally) just f, we thus conclude that f is the weak limit of finite linear combinations of characters. (One can in fact use compactness and continuity to make this a strong limit, but this is not necessary here.) In particular, f is equivalent a.e. to a ")#mi("{\\mathcal Z}_1")#text("-measurable function, as desired. ")#mi("\\Box")

#strong[#text("Exercise 5.")]#text(" (Spectral description of Kronecker factor) Show that the product of two eigenfunctions is again an eigenfunction. Using this and Proposition 2, conclude that ")#mi("L^2(X,{\\mathcal Z}_1,\\mu)")#text(" is in fact equal to ")#mi("{\\Bbb H}_{pp}")#text(", the closed subspace of the Hilbert space ")#mi("{\\Bbb H} := L^2(X,{\\mathcal X},\\mu)")#text(" generated by the eigenfunctions of the shift operator T. ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^2(X, {\\mathcal X},\\mu)")#text(". We say that f is quasiperiodic if the orbit ")#mi("\\{ T^n f: n \\in {\\Bbb Z} \\}")#text(" lies in a finite-dimensional space. Show that a function is quasiperiodic if and only if it is a finite linear combination of eigenfunctions. Deduce that a function is almost periodic if and only if it is the limit in ")#mi("L^2")#text(" of quasiperiodic functions. ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" The purpose of this exercise is to show how abstract measure-preserving systems, and the morphisms between them, can be satisfactorily modeled by concrete systems and morphisms.")

#enum(start: 1, 
[#text("Let ")#mi("({\\mathcal X},\\mu,T)")#text(" be an abstract measure-preserving system. Show that there exists a concrete regular measure-preserving system ")#mi("(X^{\\prime}, {\\mathcal X}^{\\prime}, \\mu^{\\prime}, T^{\\prime})")#text(" which is equivalent to ")#mi("({\\mathcal X},\\mu,T)")#text(" (thus after omitting X’ and quotienting out both ")#mi("\\sigma")#text("-algebras by null sets, the two resulting abstract measure-preserving systems are isomorphic); the notion of regularity was defined in Definition 2 of ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(". ")#emph[#text("Hint:")]#text(" take a countable shift-invariant family of sets that generate ")#mi("{\\mathcal X}")#text(" (thus T acts on this space by permutation), and use this to create a ")#mi("\\sigma")#text("-algebra morphism from ")#mi("{\\mathcal X}")#text(" to ")#mi("{\\mathcal X}^{\\prime}")#text(", the product ")#mi("\\sigma")#text("-algebra of some boolean space ")#mi("X^{\\prime} := 2^{\\Bbb Z}")#text(", endowed with a permutation action T’.")],
[#text("Let ")#mi("\\phi: ({\\mathcal X},\\mu,T) \\to ({\\mathcal Y},\\nu,S)")#text(" be an abstract morphism. Show that there exist regular measure-preserving systems ")#mi("(X^{\\prime},{\\mathcal X}^{\\prime},\\mu^{\\prime},T^{\\prime})")#text(" and ")#mi("(Y^{\\prime},{\\mathcal Y}^{\\prime},\\nu^{\\prime},S^{\\prime})")#text(" equivalent to ")#mi("({\\mathcal X},\\mu,T)")#text(" and ")#mi("({\\mathcal Y},\\nu,S)")#text(", together with a concrete morphism ")#mi("\\phi^{\\prime}: X^{\\prime} \\to Y^{\\prime}")#text(", such that obvious commuting square connecting the abstract ")#mi("\\sigma")#text("-algebras ")#mi("{\\mathcal X}, {\\mathcal Y}, {\\mathcal X}^{\\prime}, {\\mathcal Y}^{\\prime}")#text(" quotiented out by null sets does indeed commute. ")#mi("\\diamond")]
)

#strong[#text("Remark 6.")]#text(" Exercise 7 (and various related results) show that the distinction between concrete and abstract measure-preserving systems are very minor in practice. There are however other areas of mathematics in which taking an abstract or “point-less” approach by deleting (or at least downplaying) the underlying space can lead to non-trivial generalisations or refinements of the original concrete concept, for instance when moving from ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("varieties")]#text(" to ")#link("http://en.wikipedia.org/wiki/Scheme_%28mathematics%29")[#text("schemes")]#text(". ")#mi("\\diamond")

#strong[#text("Proof of Theorem 2.")]#text(" Note that if f is an eigenfunction then T|f|=|f|, and so (if the system is ergodic) |f| is a.e. constant (which implies also that the eigenvalue lies on the unit circle). In particular, any eigenfunction is invertible. The quotient of two eigenfunctions of the same eigenvalue is then T-invariant and thus constant a.e. by ergodicity, which shows that all eigenspaces have geometric multiplicity 1 modulo null sets. As T is ")#link("http://en.wikipedia.org/wiki/Unitary_operator")[#text("unitary")]#text(", any eigenfunctions of different eigenvalues are orthogonal to each other; as ")#mi("L^2(X, {\\mathcal X},\\mu)")#text(" is separable, we conclude that the number of eigenfunctions (up to constants and a.e. equivalence) is at most countable.")

#text("Let ")#mi("(\\phi_n)_{n \\in A}")#text(" be a collection of representative eigenfunctions for some at most countable index set A with eigenvalues ")#mi("\\lambda_n")#text("; we can normalise ")#tao-math("\\left|\\phi_n\\right|=1", block: false)#text(" a.e.. By modifying each eigenfunction on a set of measure zero (cf. Exercise 7 of ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("Lecture 8")]#text(") we can assume that ")#mi("T \\phi_n = \\lambda_n \\phi_n")#text(" and ")#tao-math("\\left|\\phi_n\\right|=1", block: false)#text(" ")#emph[#text("everywhere")]#text(" rather than just almost everywhere. Then the map ")#mi("\\Phi: x \\mapsto (\\log \\phi_n(x))_{n \\in A}")#text(" is a morphism from ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" to the torus ")#mi("({\\Bbb R}/{\\Bbb Z})^A")#text(" with the product ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(", the push-forward measure ")#mi("\\Phi_\\# \\mu")#text(", and the shift ")#mi("x \\mapsto x+\\alpha")#text(", where ")#mi("\\alpha := (\\log \\lambda_n)_{n \\in A}")#text(". From Proposition 2 we see that every measurable set in ")#mi("{\\mathcal X}")#text(" differs by a null set from a set in the pullback ")#mi("\\sigma")#text("-algebra ")#mi("\\Phi^\\#( {\\mathcal B} )")#text(". From this it is not hard to see that ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" is equivalent to the system ")#mi("({\\Bbb R}/{\\Bbb Z})^A, {\\mathcal B}, \\Phi_\\# \\mu, x \\mapsto x+\\alpha)")#text(".")

#text("Now, ")#mi("{\\Bbb R}/{\\Bbb Z})^A")#text(" is a compact metrisable space. The orbit closure K of ")#mi("\\alpha")#text(" inside this space is thus also compact metrisable. The support of ")#mi("\\Phi_\\# \\mu")#text(" is shift-invariant and thus K-invariant; but from the ergodicity of ")#mi("\\mu")#text(" we conclude that the support must in fact be a single translate of K. In particular, ")#mi("\\Phi_\\# \\mu")#text(" is just a translate of Haar measure on K. From this one easily concludes that ")#mi("({\\Bbb R}/{\\Bbb Z})^A, {\\mathcal B}, \\Phi_\\# \\mu, x \\mapsto x+\\alpha)")#text(" is equivalent to the Kronecker system ")#mi("(K, x \\mapsto x+\\alpha)")#text(" with the Borel ")#mi("\\sigma")#text("-algebra and Haar measure, and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 8.")]#text(" Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a compact system which is not necessarily ergodic, and let ")#mi("y \\mapsto \\mu_y")#text(" be the ergodic decomposition of ")#mi("\\mu")#text(" relative to the projection ")#mi("\\pi: (X,{\\mathcal X},\\mu,T) \\to (Y, {\\mathcal Y},\\nu,S)")#text(" given by Proposition 4 of ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("Lecture 9")]#text(". Show that ")#mi("(X,{\\mathcal X},\\mu_y,T)")#text(" is a compact ergodic system for ")#mi("\\nu")#text("-almost every y. From this and Theorem 2, we conclude that every compact system can be disintegrated into ergodic Kronecker systems (cf. the discussion after Proposition 2 of ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 7.")]#text(" We comment here on finitary versions of the above concepts. Consider the cyclic group system ")#mi("({\\Bbb Z}/N{\\Bbb Z},x \\mapsto x+1)")#text(" with the discrete ")#mi("\\sigma")#text("-algebra and uniform probability measure. Strictly speaking, every function on this system is periodic with period N and thus almost periodic, and so this is a compact system. But suppose we consider N as a large parameter going to infinity (in which case one can view these systems, together with some function ")#mi("f = f_N")#text(" on these systems, “converging” to some infinite system with some limit function f, as in the derivation of Theorem 3 from Theorem 2 in the ")#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("previous lecture")]#text("). Then we would be interested in ")#emph[#text("uniform")]#text(" control on the almost periodicity of the function or the compactness of the system, i.e. quantitative bounds involving expressions such as O(1) which are bounded uniformly in N. With such a perspective, the analogue of a quasiperiodic function (see Exercise 6) is a function ")#mi("f: {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb C}")#text(" which is a linear combination of at most O(1) characters (i.e. its Fourier transform is non-zero at only O(1) frequencies), whilst an almost periodic function f is one which is approximable in ")#mi("L^2")#text(" by quasiperiodic functions, thus for every ")#mi("\\varepsilon > 0")#text(" one can find a function with only ")#mi("O_\\varepsilon(1)")#text(" frequencies which lies within ")#mi("\\varepsilon")#text(" of f in ")#mi("L^2")#text(" norm. Most functions on ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" for large N are not like this, and so the cyclic shift system is not compact in the asymptotic limit ")#mi("N \\to \\infty")#text("; however if one coarsens the underlying ")#mi("\\sigma")#text("-algebra significantly one can recover compactness, though unfortunately one has to replace exact shift-invariance by approximate shift-invariance when one does so. For instance if one considers a ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(" generated by a bounded (O(1)) number of Bohr sets ")#mi("\\{ n \\in {\\Bbb Z}/N{\\Bbb Z}: \\frac{\\xi n}{N} - a\\|_{{\\Bbb R}/{\\Bbb Z}} \\leq \\varepsilon \\}")#text(", then ")#mi("{\\mathcal B}")#text(" is no longer shift-invariant in general, but all the functions which are measurable with respect to this algebra are uniformly almost periodic in the above sense. For some further developments of these sorts of “quantitative ergodic theory” ideas, see ")#link("http://front.math.ucdavis.edu/math.NT/0404188")[#text("these")]#text(" ")#link("http://www.arxiv.org/abs/math.CO/0509560")[#text("papers")]#text(" ")#link("http://front.math.ucdavis.edu/math.NT/0405581")[#text("of")]#text(" ")#link("http://front.math.ucdavis.edu/math.CO/0405251")[#text("Ben")]#text(" ")#link("http://front.math.ucdavis.edu/math.CO/0501314")[#text("Green ")]#link("http://arxiv.org/abs/math.NT/0610604")[#text("and")]#text(" ")#link("http://arxiv.org/abs/0707.1117")[#text("myself")]#text(". ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Feb 12: Another exercise and remark added.]")

#text("[")#emph[#text("Update")]#text(", Feb 13: Examples 1 and 2 corrected.]")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IU student")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26072")[#strong[#text("IU student")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Dear Dr. Tao,")

#text("I am interested in knowing that for what compact systems it can be")#linebreak()#text(" asserted that for any continuous function f, the averages")#linebreak()#text(" ")#mi("f_{n,m}(p) := \\frac{1}{n-m}  \\sum_{i=m+1}^n f(T^ip)")#text(" with ")#mi("n > m")#linebreak()#text(" converge a.e.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26078")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Dear IU student,")

#text("For Kronecker systems, at least, one can approximate any continuous function uniformly as the finite linear combination of eigenfunctions. For the latter, convergence (in the limit ")#mi("n-m \\to \\infty")#text(") is easy to establish, so for general continuous functions we in fact have uniform convergence in this case.")

#text("I would imagine one has the same result for general compact systems, though one needs to now how the topology of the system interacts with the measure structure. (Note that the notion of equivalence defined above need not preserve topological concepts such as continuity. But at least one can still use the ergodic decomposition to reduce to the ergodic case.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26116")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("I think in examples 1 and 2, the adjective “almost” is missing (“every periodic function is clearly almost periodic”, and “every function ")#mi("f\\in L^2")#text(" is almost periodic”, respectively).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26165")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Can you give some historical explanation? When was theorem 2 proved and what was reason this was studied?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26180")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Dear Emmanuel: Thanks for the corrections!")

#text("Dear Anonymous: I am not sure of the historical background of this result; the books and papers that I have read seem to attribute it either to folklore, or to be very classical. Perhaps other readers may know of a more precise origin of this classification of compact ergodic systems, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("An update to my previous comment: I have now been informed via email (by a friend who is too shy to post directly here :-) ) that Theorem 2 was essentially established by von Neumann and Halmos. More precisely, they showed that any ergodic system in which the spectrum of the shift map is purely discrete is equivalent to a Kronecker system, and the claim then follows from Proposition 2 and Exercise 5 (which are also extremely classical).")

#text("Furthermore, the Kronecker system can also be constructed quite explicitly via Pontraygin duality: if ")#mi("\\Gamma \\subset S^1")#text(" is the group of eigenvalues (with the discrete topology) and G is the Pontryagin dual (which is thus compact abelian metrisable), then the inclusion map from ")#mi("\\Gamma")#text(" to ")#mi("S^1")#text(" is a character of ")#mi("\\Gamma")#text(" and thus identifiable with a point ")#mi("\\alpha")#text(" on G. Then the proof of Theorem 2 shows that an ergodic compact system is equivalent to the Kronecker system ")#mi("(G, x \\mapsto x+\\alpha)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26508")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("[…] Hilbert-Schmidt, randomness, Roth’s theorem, strong mixing, van der Corput, weak mixing In the previous lecture, we studied the recurrence properties of compact systems, which are systems in which all measurable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26696")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2008")])]

#text("[…] compact extensions, Hilbert modules, multiple recurrence, structure, van der Waerden’s theorem In Lecture 11, we studied compact measure-preserving systems – those systems in which every function was almost […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 14: Weakly mixing extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-26859")[#strong[#text("254A, Lecture 14: Weakly mixing extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2008")])]

#text("[…] of a weakly mixing extension. Just as compact extensions are “relative” versions of compact systems, weakly mixing extensions are “relative” versions of weakly mixing systems, in which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-34052")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Dear Professor Tao:")

#text("The label of Examples and Exercises are confused:There are no example 3 and example 4 before example 5.")

#text("After definition 2, from”example 3″ should be “exercise 3”;")

#text("After example 5, “isomorphism between the these…”, where “the” should be deleted.")

#text("In the paragraph before Corollary 1, the first sentence, I don’t see why the mean is non-negative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-34056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2008")])]

#text("Thanks for the corrections! If f is non-negative, then ")#mi("\\mu*f")#text(" is non-negative for every probability measure ")#mi("\\mu")#text(", and hence every left-mean of f must also be non-negative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-34125")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear Professor Tao:")

#text("In the proof of theorem 2, the first sentence, why “any eigenfunction is invertible” is true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-34129")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear liuxiaochuan,")

#text("If f is an eigenfunction, then ")#tao-math("\\left|f\\right|", block: false)#text(" is T-invariant, hence constant; since f is non-zero, this implies that ")#tao-math("\\left|f\\right|", block: false)#text(" is always non-zero, hence invertible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-479815")[#strong[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("[…] this theorem, the Furstenberg recurrence theorem (Theorem 1 from Lecture 11) follows from the previous theorems and transfinite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-509203")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("Dear Professor Tao,")

#text("In the proof of proposition 2 we have a compact group ")#mi("K")#text(" with Haar measure ")#mi("\\nu")#text(". At one point you have mentioned that since the characters of ")#mi("K")#text(" form an orthonormal basis of ")#mi("L^2(K, \\nu)")#text(", the “Dirac mass at ")#mi("0")#text(" (the additive identity) can be expressed as a weak limit of a finite linear combinations of these characters.”")

#text("I am not able to follow the meaning of the statement in quotes. The Dirac mass is a probability measure while the characters are maps from ")#mi("K")#text(" to ")#mi("\\mathbb C^*")#text(".")

#text("Is it that we are thinking of the characters as members of ")#mi("C(K)^*")#text(" and the Dirac mass also as a member of ")#mi("C(K)^*")#text(" (by means of the Riesz representation theorem)?")

#text("If so, can you say why one can get the Dirac mass as a weak limit (or perhaps weak* limit?) of a linear combination of characters.")

#text("Thank you.")

#text("(I apologize if this is a stupid question. I am only starting to learn analysis.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-509226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("Here I am using the Haar measure ")#mi("\\nu")#text(" to identify locally integrable functions on ")#mi("K")#text(" with distributions (which in particular allows one to view elements of ")#mi("L^2(K,\\nu)")#text(", such as linear combinations of characters, as distributions).")

#text("Using approximations to the identity, one can express the Dirac distribution as the weak limit of elements of ")#mi("L^2(K)")#text(" (e.g., one can take ")#mi("\\frac{1}{\\nu(U)} 1_U")#text(" where ")#mi("U")#text(" are a shrinking set of neighbourhoods of the identity), and as the characters form a basis of ")#mi("L^2(K)")#text(", any such elements can be approximated to arbitrary accuracy by finite linear combinations of characters (in the ")#mi("L^2")#text(" metric). Combining the two statements give the claim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-509307")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("Dear Professor Tao,")

#text("I have a question regarding the notion of a *maximal* factor.")

#text("Suppose we have a measure preserving system ")#mi("(X, \\mathcal X, \\mu, T)")#text(" where ")#mi("X")#text(" is a compact metric space and ")#mi("\\mathcal X")#text(" is its Borel ")#mi("\\sigma")#text("-algebra.")

#text("Let ")#mi("\\mathcal A")#text(" be a sub-")#mi("\\sigma")#text("-algebra of ")#mi("\\mathcal X")#text(" which is invariant under ")#mi("T")#text(". Then we can find a factor ")#mi("(Y, \\mathcal Y, \\nu, S)")#text(" of ")#mi("(X, \\mathcal X, \\mu, T)")#text(" with factor map ")#mi("\\phi:X\\to Y")#text(" such that ")#mi("\\mathcal A=\\phi^{-1}\\mathcal Y\\pmod{\\mu}")#text(".")

#text("My question is: Is there a maximal such factor and is a maximal factor unique?")

#text("Admittedly, I am not very clear as to what I mean by maximality here. But at the very least, any other factor should be a factor of a maximal factor.")

#text("(I am asking this because of Remark 4 above. Also, I was reading Einsiedler and Wards Ergodic Theory with a view towards Number Theory, and Theorem 6.10 in the text uses the definite article when considering a factor of a certain sub-")#mi("\\sigma")#text("-algebra.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-509325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("I think if a maximal factor exists, then it is unique up to isomorphism by general abstract nonsense (uniqueness of universal objects in categories). If one works with abstract measurable spaces ")#mi("({\\mathcal X}, \\mu, T)")#text(" instead of concrete ones ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" then there is a canonical choice of maximal factor, namely ")#mi("({\\mathcal A}, \\mu, T)")#text("; in many applications one can get by just using these abstract spaces (and the corresponding abstract notion of factor). One could then use something like the ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Loomis-Sikorski theorem")]#text(" to generate a concrete measure-preserving space that is abstractly isomorphic to this factor, but there might be some descriptive set theory or measurability issues when trying to concretely exhibit this space as a factor of the original space (typically one needs some regularity hypotheses on the spaces, e.g. that they are standard Borel spaces or at least separable, to do this). One might have a look at ")#link("https://bookstore.ams.org/surv-101")[#text("Glasner’s book")]#text(" as I have a vague memory that he may discuss these sorts of issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-509362")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2018")])]

#text("I also thought that the uniqueness of a maximal factor would follow from abstract nonsense. But the problem is that, since we are not requiring factor maps to be surjective, a maximal factor may not be an initial object.")

#text("I guess I am sweating this too much. Let me read and reflect on your suggestion about using abstract measurable spaces.")

#text("Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-561270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2020")])]

#text("Dear Professor Tao,")

#text("Just before Proposition 2, you have defined ")#mi("\\mathcal Z_1")#text(" as the ")#mi("\\sigma")#text("-algerba generated by the bounded measurable eigenfunctions.")

#text("Suppose we define ")#mi("\\mathcal Z_1^{\\prime}")#text(" as the ")#mi("\\sigma")#text("-algebra generated by the eigenfunctions in ")#mi("L^2(\\mathcal X, \\mu)")#text(".")

#text("Then clearly ")#mi("\\mathcal Z_1\\subseteq \\mathcal Z_1^{\\prime}")#text(" and this is in fact an equality in the ergodic case.")

#text("I am wondering if this is also an equality in general.")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-561528")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2020")])]

#text("Yes; if ")#mi("f")#text(" is an eigenfunction then ")#tao-math("\\left|f\\right|", block: false)#text(" is invariant, so one can always truncate an eigenfunction ")#mi("f")#text(" to be bounded while still generating the same measurable sets, e.g., by replacing ")#mi("f")#text(" with ")#tao-math("\\frac{\\arctan \\left|f\\right|}{\\left|f\\right|} f", block: false)#text(" (with the convention that the latter vanishes when ")#mi("f")#text(" vanishes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-572410")[#strong[#text("Math Genius: Spectral description of the Kronecker factor - TECHPRPR")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2020")]

#text("[…] periodic if the closure of $set{T^nf: nin Z}$ is compact in $L^2$. It is shows in Proposition 2 of this blog post of Tao, assuming ergodicity of $T$, that$f$ is almost periodic if and only if $f$ is measurable with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0292b6d398bf1a10f5dfa36b75f795c63bdceeb421dd1b3ab4c60660d1c7a174-58af6a86b5b862fa40897aa07e9ec74b0fdec57cb33f68c48999f3fa2799647e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dante Tjowasi")]], [#link("https://terrytao.wordpress.com/2008/02/11/254a-lecture-11-compact-systems/#comment-641439")[#strong[#text("Dante Tjowasi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2022")])]

#text("Dear Professor Tao,")

#text("For Proposition 2, why does the system need to be ergodic? I tried following the proof and I can’t see where ergodicity is used.")

#text("Thank you.")

#emph[#text("[Ergodicity is indeed not needed in this proposition, but for the application to Theorem 2 we only need the ergodic case. -T]")]
]
