// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/
// Converted to Typst by tao2typ: "2026-10-14T15:16:55.662237+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Marker lecture IV: “Sieving for almost primes and expanders”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Marker lecture IV: “Sieving for almost primes and expanders”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/")[#text("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this final lecture in the ")#link("http://www.math.psu.edu/seminars/marker2008.php")[#text("Marker lecture series")]#text(", I discuss the recent work of Bourgain, Gamburd, and Sarnak on how ")#link("http://en.wikipedia.org/wiki/Arithmetic_combinatorics")[#text("arithmetic combinatorics")]#text(" and ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander graphs")]#text(" were used to ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve")]#text(" for ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(" in various ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic sets")]#text(".")

#metadata(none) <tao-cec21addf8d19dc020af>

#text("In previous lectures, we considered the problem of detecting tuples of primes in various linear or convex sets; in particular, we considered the size of sets of the form ")#mi("V \\cap {\\mathcal P}^k")#text(", where ")#mi("{\\mathcal P} = \\{2,3,5,\\ldots\\}")#text(" is the set of primes, and V is some ")#link("http://en.wikipedia.org/wiki/Affine_space")[#text("affine subspace")]#text(" of ")#mi("{\\Bbb R}^k")#text(". (For instance, the ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" would correspond to the case when k=2 and ")#mi("V = \\{ (x,x+2): x \\in {\\Bbb R}\\}")#text(", while the ")#link("http://en.wikipedia.org/wiki/Green-Tao_theorem")[#text("Green-Tao theorem")]#text(" would correspond to the case ")#mi("V = \\{ (x,x+r,\\ldots,x+(k-1)r): x,r \\in {\\Bbb R}\\}")#text(". We refer to elements of ")#mi("{\\mathcal P}^k")#text(" as ")#emph[#text("prime points")]#text(". The ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("prime tuples conjecture")]#text(" implies the following qualitative criterion for when such a set of prime points should be “large”:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Qualitative prime tuples conjecture.")]#text(" Let V be an affine subspace of ")#mi("{\\Bbb R}^k")#text(". Suppose that")

#enum(start: 1, 
[#text("(No obstructions at infinity) For any N, ")#mi("V \\cap {\\Bbb Z}_{>N}^k")#text(" affinely spans all of V, where ")#mi("{\\Bbb Z}_{>N} := \\{ n \\in {\\Bbb Z}: n > N \\}")#text(". (In particular, ")#mi("V \\cap {\\Bbb Z}_{>N}^k")#text(" is non-empty.)")],
[#text("(No obstructions at q) For any ")#mi("q > 1")#text(", ")#mi("V \\cap ({\\Bbb Z}_q^*)^k")#text(" affinely spans all of V, where ")#mi("{\\Bbb Z}_q^* := \\{ n \\in {\\Bbb Z}: (n,q) = 1 \\}")#text(". (In particular,")#mi("V \\cap ({\\Bbb Z}_q^*)^k")#text(" is non-empty.)")]
)

#text("Then ")#mi("V \\cap {\\mathcal P}^k")#text(" affinely spans all of V. (In particular, V contains at least one prime point.)")
]

#text("Both of the hypotheses in this conjecture are easily verified for any given V, the first by (integer) linear programming and the second by modular arithmetic. This conjecture would imply several other results and conjectures in number theory, including the twin prime conjecture and the Green-Tao theorem. Needless to say, it remains open in general (though the results mentioned in the previous lecture give partial results in the case when V is at least two-dimensional and non-degenerate).")

#text("Now we attempt to generalise the above conjecture to the setting in which V is an ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("algebraic variety")]#text(" rather than an affine subspace. (This would cover some famous open problems in number theory, for instance the ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau problem")]#text(" that asks whether there are infinitely many primes of the form ")#mi("n^2+1")#text(".) The notion of a set affinely spanning V is then naturally replaced by the notion of a set being ")#link("http://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski dense")]#text(" in V, which means that the set is not contained in any strictly smaller subvariety of V. One could then formulate a naive generalisation of the above conjecture by replacing “affine space” and “affinely spans all of” with “algebraic variety” and “is Zariski dense in” respectively. However, the hypotheses are now no longer easy to verify; indeed, just the problem of determining whether V contains an integer point ")#mi("{\\Bbb Z}^k")#text(" is essentially ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_tenth_problem")[#text("Hilbert’s tenth problem")]#text(", which by ")#link("http://en.wikipedia.org/wiki/Matiyasevich%27s_theorem")[#text("Matiyasevich’s theorem")]#text(" is known to be undecidable for general V. Indeed, since one can encode any computable set in terms of the integer points of a variety V, it is not too difficult to see that this conjecture fails in general. (An amusing historical connection here: one of the first demonstrations of the undecidability of Hilbert’s tenth problem by Robinson, Davis, and Putnam was conditional on the existence of arbitrarily long progressions of primes (i.e. the Green-Tao theorem), although subsequent proofs did not need this fact.)")

#text("Since arbitrary algebraic varieties are far too general to have any hope of a reasonable theory, one should look for prime points in much more special sets. An important class here is that of an orbit ")#mi("\\Lambda b")#text(" in ")#mi("{\\Bbb Z}^k")#text(", where b is some vector in ")#mi("{\\Bbb Z}^k")#text(" and ")#mi("\\Lambda")#text(" is some finitely generated subgroup of ")#mi("SL_k({\\Bbb Z})")#text(". (One can also consider the slightly more general set of images ")#mi("F(\\Lambda b)")#text(" under a polynomial map, but for simplicity let us stick to just orbits.) Of course one should take b to be primitive (not a multiple of any smaller vector), since one clearly will have a difficult time finding prime points in ")#mi("\\Lambda b")#text(" otherwise.")

#text("The orbit ")#mi("\\Lambda b")#text(" will be Zariski dense in some algebraic variety V, and is clearly a collection of integer points (though it may not cover all of ")#mi("V \\cap {\\Bbb Z}^k")#text("). Assuming no local obstructions at infinity or at q (which means that ")#mi("\\Lambda b \\cap {\\Bbb Z}_{>N}^k")#text(" and ")#mi("\\Lambda b \\cap ({\\Bbb Z}_q^*)^k)")#text(" are Zariski dense in V), one could then conjecture that ")#mi("\\Lambda b \\cap {\\Bbb P}^k")#text(" is also Zariski dense in V (which, if V is infinite, would in particular imply that the orbit ")#mi("\\Lambda b")#text(" contains infinitely many prime points).")

#text("For simplicity let us restrict attention to the two-dimensional case k=2, which is already highly non-trivial; Bourgain, Gamburd and Sarnak have recently begun to get some preliminary results in k=3 but I will not discuss them here. Thus ")#mi("\\Lambda")#text(" is now a finitely generated subgroup of ")#mi("SL_2({\\Bbb Z})")#text(". If this subgroup is ")#emph[#text("elementary")]#text(" – e.g. if it is cyclic – then the orbit ")#mi("\\Lambda b")#text(" can be exponentially sparse (a ball of radius R may only contain ")#mi("O(\\log R)")#text(" points), and it becomes extremely difficult to do any sieving or primality detection. (In this case, the problem becomes comparable to such notoriously difficult questions as whether there are infinitely many Mersenne primes.) It thus makes sense to restrict attention to non-elementary subgroups of ")#mi("SL_2({\\Bbb Z})")#text(" – groups which contain a copy of the ")#link("http://en.wikipedia.org/wiki/Free_group")[#text("free non-abelian group")]#text(" on two generators, or equivalently any group whose Zariski closure is all of ")#mi("SL_2")#text(" (or equivalently yet again, a group whose limit set consists of more than one point). In this situation, ")#link("http://www.ams.org/mathscinet-getitem?mr=2246331")[#text("Bourgain, Gamburd, and Sarnak conjectured")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2.")]#text(" Let ")#mi("\\Lambda")#text(" be a non-elementary subgroup of ")#mi("SL_2({\\Bbb Z})")#text(", and let b be a primitive element of ")#mi("{\\Bbb Z}^2")#text(". Suppose that there are no local obstructions at infinity or at finite places q. Then ")#mi("\\Lambda b \\cap {\\mathcal P}^2")#text(" is Zariski dense in the plane (in particular, ")#mi("\\Lambda b \\cap {\\mathcal P}^2")#text(" is infinite).")
]

#text("This conjecture remains open. However, as in the linear situation, one can make progress if one replaces primes with ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(" – products of at most r primes for some bounded r. (There are certainly prior results for nonlinear patterns in the almost primes; for instance, it is a famous ")#link("http://www.ams.org/mathscinet-getitem?mr=485740")[#text("result of Iwaniec")]#text(" that there are infinitely many numbers of the form ")#mi("n^2+1")#text(" that are the product of at most two primes.) In particular, Bourgain, Gamburd, and Sarnak were able to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem.")]#text(" Let ")#mi("\\Lambda, b")#text(" be as in Conjecture 2. Then there exists an r such that ")#mi("\\Lambda b \\cap {\\mathcal P}_r^2")#text(" is Zariski dense in the plane, where ")#mi("{\\mathcal P}_r")#text(" is the set of numbers that are the product of at most r primes.")
]

#text("Several further generalisations and extensions of this result, with a similar flavour, are known, but will not be discussed here. There are a number of amusing special cases of these results, for instance one can show that there exist infinitely many ")#link("http://en.wikipedia.org/wiki/Apollonian_gasket")[#text("Appollonian circle packings")]#text(" of the unit circle by four other mutually tangent circles, all of whose radii is the reciprocal of an almost prime, or infinitely many ")#link("http://en.wikipedia.org/wiki/Pythagorean_triple")[#text("Pythagorean triples")]#text(" whose area is an almost prime (for a sufficiently large r in the definition of “almost prime”).")

#text("Let me now discuss some of the key ideas in the proof of this theorem. One begins by rephrasing the question in a more quantitative (or finitary) manner. In the linear case, this would be done by counting the number of points in ")#mi("\\Lambda b \\cap {\\mathcal P}_r^2")#text(" that lie inside some large Euclidean ball, thus using the Euclidean (or Archimedean) notion of distance to localise the problem. This can also be done here, but it turns out to be more convenient to instead use the ")#link("http://en.wikipedia.org/wiki/Word_metric")[#text("word metric")]#text(" induced by the finite generating set S of ")#mi("\\Lambda")#text(" (which we can take to be symmetric for convenience, thus ")#mi("S = S^{-1}")#text("). One thus looks at sets of the form ")#mi("B_R b \\cap {\\mathcal P}_r^2")#text(", where ")#mi("B_R \\subset \\Lambda")#text(" consists of all words formed by products of at most R elements of S. A major new difficulty here compared to the linear theory is the exponential growth of ")#mi("B_R")#text(" (a consequence of the non-elementary nature of ")#mi("\\Lambda")#text("). (Though it is not immediately apparent, the same problem also arises if one uses Euclidean balls instead of word metric balls, due to the multiplicative rather than additive nature of the group ")#mi("\\Lambda")#text(".)")

#text("The next step is to use sieve theory. Recall the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(", which expresses the set of all (large) primes as the integers, minus the multiples of two, minus the multiples of three, and so forth. Using the ")#link("http://en.wikipedia.org/wiki/Inclusion-exclusion_principle")[#text("inclusion-exclusion principle")]#text(", we can thus view the indicator function ")#mi("1_{{\\mathcal P}}")#text(" of the primes, when restricted to an interval such as ")#mi("{}[N,2N]")#text(", as equal to 1, minus the indicator function ")#mi("1_{2{\\Bbb Z}}")#text(" of the even numbers, minus the indicator function ")#mi("1_{3{\\Bbb Z}}")#text(" of the multiples of three, plus the indicator function ")#mi("1_{6{\\Bbb Z}}")#text(" of the multiples of six, and so forth. This leads to the ")#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("Legendre sieve")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("1_{{\\mathcal P}} = \\sum_d \\mu(d) 1_{d {\\Bbb Z}},")]]

#text("valid in an interval ")#mi("{}[N,2N]")#text(" as long as one restricts d to those integers which are products of primes less than N. Here ")#mi("\\mu(d)")#text(" is the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(".")

#text("The basic idea of sieve theory is to replace the indicator function of the primes (or almost primes) by a more general divisor sum")

#align(center)[#mi("\\displaystyle \\sum_d c_d 1_{d{\\Bbb Z}}")#text(",")]

#text("where the sieve weights ")#mi("c_d")#text(" are chosen in order to optimise the final bounds in the sieve (they typically resemble “smoothed out” versions of the Möbius functionin order that these sieves be large on the almost primes and small elsewhere). In order for the sieve to be practical, one wants to restrict d in this sum to be relatively small, for instance ")#mi("d \\leq N^\\theta")#text(" for some absolute constant ")#mi("0 < \\theta < 1")#text(" (values such as ")#mi("\\theta=1/4")#text(" are fairly typical). The selection of the sieve weights ")#mi("c_d")#text(" is now a well-developed science (see also ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("my earlier post")]#text(", and ")#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/")[#text("Kowalski’s guest post")]#text(", on this topic), and Bourgain, Gamburd and Sarnak basically use off-the-shelf sieves (in particular, combinatorial sieves and the Selberg sieve) in their work. Inserting these standard sieves into the problem at hand, the task of counting almost primes in the finite set ")#mi("B_R b")#text(" then quickly reduces to the question of getting good estimates on sets such as ")#mi("B_R b \\cap (q {\\Bbb Z})^2")#text(" for various q. This amounts to much the same thing as asking for good equidistribution bounds for ")#mi("B_R")#text(" modulo q, thus we project the generating set S, and the ball ")#mi("B_R")#text(" it produces, from ")#mi("SL_2({\\Bbb Z})")#text(" to ")#mi("SL_2({\\Bbb Z}_q)")#text(". For sieving purposes it turns out to be necessary to consider all squarefree moduli q, but for simplicity we shall only discuss the (massively easier) case when q is prime.")

#text("The reduction to an equidistribution problem converts the original sieving problem to a more combinatorial one, involving the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graph")]#text(" G on ")#mi("SL_2({\\Bbb Z}_q)")#text(" induced by the set S, thus two vertices ")#mi("x, y \\in SL_2({\\Bbb Z}_q)")#text(" are connected by an edge in G if ")#mi("y x^{-1}")#text(" lie in S (modulo q). The image of the ball ")#mi("B_R")#text(" in ")#mi("SL_2({\\Bbb Z}_q)")#text(" is then the set of points one can reach in the graph G from the origin by walking on a path of length at most R. The desired equidistribution result one needs can then be viewed as a mixing result for the random walk along the graph G.")

#text("Standard graph theory then tells us that the task reduces to showing that the graphs G form a family of ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expander graphs")]#text(" as ")#mi("q \\to \\infty")#text(" (recall we are restricting q to be prime for simplicity). There are many equivalent definitions of what an expander graph is, but let us give a spectral definition that is specialised to Cayley graphs. The symmetric generating set S induces a natural measure")

#align(center)[#tao-fit-display[#tao-math("\\mu := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\delta_s", block: true)]]

#text("that is the uniform distribution on S, which controls the random walk along G; note that if ")#mi("f: SL_2({\\Bbb Z}_q) \\to {\\Bbb C}")#text(" is a function, then the convolution ")#mi("f*\\mu: SL_2({\\Bbb Z}_q) \\to {\\Bbb C}")#text(" is another function, whose value at any vertex x is the average value of f at all the neighbours of x. The operation ")#mi("f \\mapsto f*\\mu")#text(" is then a self-adjoint contraction on ")#mi("l^2(SL_2({\\Bbb Z}_q))")#text(" which leaves the function 1 invariant, so its largest eigenvalue ")#mi("\\lambda_1")#text(" is equal to 1. The expander graph condition is then equivalent to the existence of a ")#link("http://en.wikipedia.org/wiki/Spectral_gap")[#text("spectral gap")]#text(" ")#mi("\\lambda_2 \\leq 1-c")#text(" for the second largest eigenvalue, where ")#mi("c > 0")#text(" is a constant independent of q.")

#text("Of course, to have a spectral gap, one necessary condition is that ")#mi("\\lambda_2")#text(" be strictly less than 1. This can be easily seen to be equivalent to the statement that G is connected, which in turn is equivalent to the statement that the projection of S to ")#mi("SL_2({\\Bbb Z}_q)")#text(" generates all of ")#mi("SL_2({\\Bbb Z}_q)")#text(". This statement can be verified to be true, either by direct consideration of all possible subgroups of ")#mi("SL_2({\\Bbb Z}_q)")#text(", or by the ")#link("http://en.wikipedia.org/wiki/Approximation_in_algebraic_groups")[#text("strong approximation property")]#text(". However, mere connectedness is not enough to ensure that a Cayley graph is an expander family (which can be viewed as a sort of “robust” version of connectedness, which can survive the deletion of large numbers of edges). For instance, the Cayley graph of the generating set ")#mi("\\{-1,+1\\}")#text(" in ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" is connected, but does not form an expander family as ")#mi("N \\to \\infty")#text("; the second largest eigenvalue is about ")#mi("1 - O(1/N^2)")#text(" only. (One can also see that the random walk on this Cayley graph takes a long time (about O(N^2) steps) before it mixes to be close to the uniform distribution; with expander graphs on a set of N vertices, mixing instead occurs in time ")#mi("O(\\log N)")#text(", thanks to the spectral gap.)")

#text("Obtaining the spectral gap property requires more work. When the original subgroup ")#mi("\\Lambda")#text(" of ")#mi("SL_2({\\Bbb Z})")#text(" is as large as a finite index subgroup (in particular, if it is a ")#link("http://en.wikipedia.org/wiki/Congruence_subgroup")[#text("congruence subgroup")]#text("), this gap follows from a celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=182610")[#text("theorem of Selberg")]#text(" providing a similar spectral gap for arithmetic quotients of the upper half-plane. Smaller examples (in which the index is now infinite) were first constructed ")#link("http://www.ams.org/mathscinet-getitem?mr=1645694")[#text("by Shalom")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1900698")[#text("by Gamburd")]#text(", with the latter following the method of ")#link("http://www.ams.org/mathscinet-getitem?mr=1131400")[#text("Sarnak and Xue")]#text(". Then (in the case of prime q), ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("Bourgain and Gamburd")]#text(" extended the method using additional tools from additive combinatorics to handle all non-elementary subgroups.")

#text("Let us now describe the method of proof. As mentioned briefly earlier, the existence of a spectral gap implies a strong mixing property: the iterated convolutions ")#mi("\\mu^{(n)} := \\mu * \\ldots * \\mu")#text(" of the probability measure ")#mi("\\mu")#text(" (which can be interpreted as the probability distribution of a random walk on n steps) converges exponentially fast to the constant distribution on ")#mi("SL_2({\\Bbb Z}_q)")#text(". Since the latter distribution has an l^2 norm of ")#mi("O( q^{-3/2} )")#text(", we see in particular that for any fixed ")#mi("\\varepsilon > 0")#text(", we will have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\mu^{(n)}\\right\\|_{l^2(SL_2({\\Bbb Z}_q))} = O( q^{-3/2+\\varepsilon} )", block: true)]]

#text("once n is a sufficiently large multiple of ")#mi("\\log q")#text(". This can also be seen explicitly from the trace formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| \\mu^{(n)}\\right\\|_{l^2(SL_2({\\Bbb Z}_q))}^2 = \\frac{1}{\\left|SL_2({\\Bbb Z}_q)\\right|} \\sum_j \\lambda_j^n.", block: true)]]

#text("In general, this implication between spectral gap and rapid mixing (2) cannot be reversed; the problem is that ")#mi("\\lambda_2")#text(" only directly influences one term in the summation on the right-hand side of (3), and so upper bounds on the left-hand side do not translate efficiently to upper bounds on ")#mi("\\lambda_2")#text(". However, there is an algebraic miracle that happens in the case of groups such as ")#mi("SL_2({\\Bbb Z}_q)")#text(" that allows one to reverse the implication:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma")]#text(" (Frobenius) Let q be prime. Then every non-trivial finite-dimensional unitary representation of ")#mi("SL_2({\\Bbb Z}_q)")#text(" has dimension at least (q-1)/2.")
]

#strong[#text("Proof.")]#text(" Observe that ")#mi("SL_2({\\Bbb Z}_q)")#text(" can be generated by parabolic elements, so given a non-trivial representation ")#mi("\\rho: SL_2({\\Bbb Z}_q) \\to U(V)")#text(", there exists a parabolic element a whose representation ")#mi("\\rho(a)")#text(" is non-trivial. By a change of basis we may take")

#align(center)[#tao-fit-display[#mitex("a = \\begin{pmatrix} 1 & 1 \\\\ 0 & 1 \\end{pmatrix}.")]]

#text("On the one hand, we have ")#mi("a^q=1")#text(" and hence ")#mi("\\rho(a)^q=1")#text("; thus all eigenvalues of ")#mi("\\rho(a)")#text(" are ")#mi("q^{th}")#text(" roots of unity. On another hand, ")#mi("\\rho(a)")#text(" is non-trivial, so at least one of the eigenvalues of ")#mi("\\rho(a)")#text(" differs from 1. Thirdly, conjugating a by diagonal matrices in ")#mi("SL_2({\\Bbb Z}_q)")#text(", we see that a is conjugate to ")#mi("a^m")#text(" whenever m is a quadratic residue mod q, and so the eigenvalues of ")#mi("\\rho(a)")#text(" must be stable under the operation of taking ")#mi("m^{th}")#text(" powers. On the other hand, there are (q-1)/2 quadratic residues. Putting all this together we see that ")#mi("\\rho(a)")#text(" must take at least (q-1)/2 distinct eigenvalues, and the claim follows. ")#mi("\\Box")

#strong[#text("Remark. ")]#text("For our purposes, the exact value of ")#mi("(q-1)/2")#text(" is irrelevant; any multiplicity which grows like a power of q would suffice. ")#mi("\\diamond")

#text("Applying this lemma to the eigenspace of ")#mi("\\lambda_2")#text(", we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary.")]#text(" The second eigenvalue ")#mi("\\lambda_2")#text(" of the operation ")#mi("f \\mapsto f*\\mu")#text(" appears with multiplicity at least ")#mi("(q-1)/2")#text(".")
]

#text("Combining this corollary with (3), one can now reverse the previous implication and obtain a spectral gap ")#mi("\\lambda_2 \\leq 1-c")#text(" as soon as one gets a mixing estimate (2) for some ")#mi("n = O(\\log q)")#text(" and some sufficiently small ")#mi("\\varepsilon")#text(".")

#text("The task is now to obtain the mixing estimate (2). The quantity ")#tao-math("\\left\\|\\mu^{(n)}\\right\\|_{l^2(SL_2({\\Bbb Z}_q))}", block: false)#text(" starts at 1 when ")#mi("n=0")#text(" and decreases with n. If we assume (as we may) that S generates a free group, then it is not hard to see that ")#mi("\\mu^{(n)}")#text(" expands rapidly for ")#mi("n \\ll \\log q")#text(" (because all the words generated by S will be distinct until one encounters the “wrap-around” effect of taking residues modulo q). Using this one can get a preliminary mixing bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{l^2(SL_2({\\Bbb Z}_q))} \\leq q^{-\\delta}", block: true)]]

#text("for some absolute constant ")#mi("\\delta > 0")#text(" and some ")#mi("n = O(\\log q)")#text(". Also, since S modulo q generates all of ")#mi("SL_2({\\Bbb Z}_q)")#text(", we know that the probability measure ")#mi("\\mu^{(n)}")#text(" is not trapped inside any proper subgroup H of ")#mi("SL_2({\\Bbb Z}_q)")#text("; indeed, using the classification of subgroups of ")#mi("SL_2({\\Bbb Z}_q)")#text(" (or some general “escape from subvarieties” machinery of ")#link("http://www.ams.org/mathscinet-getitem?mr=2129706")[#text("Eskin, Moses, and Oh")]#text(") one can show that")

#align(center)[#tao-fit-display[#mitex("\\mu^{(n)}(H) \\leq q^{-\\delta}")]]

#text("for any such subgroup, and some ")#mi("n = O(\\log q)")#text(". The result now follows from iterating the following lemma, which is the heart of the argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#mi("l^2")#text(" flattening lemma.")]#text(" Let ")#mi("\\nu")#text(" be a symmetric probability measure on ")#mi("SL_2({\\Bbb Z}_q)")#text(" which is a little bit dispersed in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu \\right\\|_{l^2(SL_2({\\Bbb Z}_q))} \\leq q^{-\\delta}", block: true)]]

#text("for some ")#mi("\\delta > 0")#text(", and is not concentrated in a subvariety in the sense that ")#mi("\\nu*\\nu(H) \\leq q^{-\\delta}")#text(" for any proper subgroup H of ")#mi("SL_2({\\Bbb Z}_q)")#text(". Suppose also that ")#mi("\\nu")#text(" is not entirely flat in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu \\right\\|_{l^2(SL_2({\\Bbb Z}_q))} \\geq q^{-3/2+\\delta}", block: true)]]

#text("(note that the minimal ")#mi("l^2")#text(" norm for a probability measure is comparable to ")#mi("q^{-3/2}")#text(", attained for the uniform distribution). Then ")#mi("\\nu * \\nu")#text(" is “flatter” than ")#mi("\\nu")#text(" in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu * \\nu \\right\\|_{l^2(SL_2({\\Bbb Z}_q))} \\leq q^{-\\varepsilon} \\left\\|\\nu\\right\\|_{l^2(SL_2({\\Bbb Z}_q))}", block: true)]]

#text("for some ")#mi("\\varepsilon > 0")#text(" depending on ")#mi("\\delta")#text(".")
]

#text("In the special case when ")#mi("\\nu")#text(" is the uniform distribution on some set A, the flattening lemma is very close to the following theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=2415382")[#text("of Helfgott")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Product theorem.")]#text(" Let q be a prime. Let A be a subset of ")#mi("SL_2({\\Bbb Z}_q)")#text(" which is not too big in the sense that ")#tao-math("\\left|A\\right| \\leq q^{3-\\delta}", block: false)#text(" for some ")#mi("\\delta > 0")#text(", and which is not contained in any proper subgroup H of ")#mi("SL_2({\\Bbb Z}_q)")#text(". Then ")#tao-math("\\left|A \\cdot A \\cdot A\\right| \\geq \\left|A\\right|^{1+\\varepsilon}", block: false)#text(" for some ")#mi("\\varepsilon > 0")#text(" depending on ")#mi("\\delta")#text(".")
]

#text("Indeed, by using some standard additive combinatorics, in particular a (non-commutative version of) the Balog-Szemerédi-Gowers lemma (which can be found for instance in my ")#link("http://www.ams.org/mathscinet-getitem?mr=2289012")[#text("book with Van Vu")]#text("), which connects “statistical” multiplication, such as that provided by convolution ")#mi("\\mu, \\nu \\mapsto \\mu * \\nu")#text(", with “combinatorial” multiplication, coming from the product set operation ")#mi("A, B \\mapsto A \\cdot B")#text(", one can show that these two statements are in fact equivalent to each other.")

#text("The product theorem is a manifestation of certain “nonlinear” or “noncommutative” behaviour in the group ")#mi("SL_2({\\Bbb Z}_p)")#text("; see my ")#link("https://terrytao.wordpress.com/2007/12/06/milliman-lecture-iii-sum-product-estimates-expanders-and-exponential-sums/")[#text("Milliman lecture")]#text(" for a bit more discussion on this. For now, let me just say that Helfgott’s proof on this uses a variety of algebraic and combinatorial computations exploiting the special structure of ")#mi("SL_2({\\Bbb Z}_p)")#text(" (especially how commutativity or non-commutativity of various elements in this group interact with the trace of various combinations of these elements), as well as the following sum-product estimate of ")#link("http://www.ams.org/mathscinet-getitem?mr=2053599")[#text("Bourgain-Katz-Tao")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1998834")[#text("Bourgain-Glibichuk-Konyagin")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Sum-product theorem.")]#text(" Let q be prime. Let A be a subset of ")#mi("{\\Bbb Z}_q")#text(" which is not too big in the sense that ")#tao-math("\\left|A\\right| \\leq q^{1-\\delta}", block: false)#text(" for some ")#mi("\\delta > 0")#text(". Then ")#tao-math("\\left|A+A\\right| + \\left|A \\cdot A\\right| \\geq \\left|A\\right|^{1+\\varepsilon}", block: false)#text(" for some ")#mi("\\varepsilon > 0")#text(" depending only on ")#mi("\\delta")#text(".")
]

#text("There are now some quite elementary proofs of this theorem, but I will not discuss them here (see e.g. my ")#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")[#text("earlier blog post on this topic)")]#text(". I should note, though, that the bulk of the Bourgain-Gamburd-Sarnak work is preoccupied with establishing a suitable extension of this sum-product theorem to the case when q is not prime, in a manner which is uniform in the number of prime factors; this turns out to be a surprisingly difficult task.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/599acb904d2a88b394a673973693fae9f530b5f9f14663358c3a32e20a49bc39-d2fbe05b06a1eb3bee23fab00f6cd49eedf264335a34cef4b448211a9303fa15.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Mazur")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33589")[#strong[#text("Martin Mazur")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("Great lecture at Penn State today, Prof. Tao. I’m an acoustics researcher at PSU with a background in applied mathematics (MA, UCLA 1986). Still, I followed your talk.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33594")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("Hi Terry, thanks for making this beautiful material so accessible. A small correction: in the example of the Cayley graph of ")#mi("{\\mathbb Z} / N {\\mathbb Z}")#text(" with generators ")#mi("\\{ -1,+1 \\}")#text(", the second eigenvalue is about ")#mi("1-O(1/N^2)")#text(" (it is something like ")#mi("\\cos (2\\pi/N)")#text("), and the random walk takes about ")#mi("N^2")#text(" time to mix (because after ")#mi("t")#text(" steps you are likely to be within distance ")#mi("O(\\sqrt {t})")#text(" of your starting point).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33596")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("Could you give a reference to the elementary proofs of the sum-product theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("Dear Luca: thanks for the correction!")

#text("Dear Student: Some references can be found at my earlier post")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/06/17/the-sum-product-phenomenon-in-arbitrary-rings/")[#text("The sum-product phenomenon in arbitrary rings")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b7945537683801432fed04b774c01b918bd467095ef7d0a4c8279872bee1e84-189037ce6c85ebd358f067d7d9e08acb3b6dbb7ac2f2e1f56fc058d8c6a96695.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bob schmieder")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33650")[#strong[#text("bob schmieder")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2008")])]

#text("Are any of your lectures available on podcasts? Unfortunately I missed your visit to Penn State.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2008")])]

#text("Dear Bob,")

#text("My Penn State lectures were not recorded, but my Milliman lectures at U. Washington (which were on related topics to my Marker lectures) can be found online at")

#link("http://www.math.washington.edu/Seminars/milliman_0708.php")[#text("http://www.math.washington.edu/Seminars/milliman_0708.php")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/11/20/marker-lecture-iv-sieving-for-almost-primes-and-expanders/#comment-33669")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2008")])]

#text("Trivial typo: In the boxed theorem text for Sum-product theorem: “somem” should be “some” ")#emph[#text("[Fixed – T.]")]

#text("I love this thread. Cool results!")
]
