// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/
// Converted to Typst by tao2typ: "2026-10-14T16:35:55.563931+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Applications-oriented periodic table", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Applications-oriented periodic table")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")[#text("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Here is a ")#link("http://www.abpi.org.uk/publications/pdfs/Periodic-table-2005.pdf")[#text("nice version of the periodic table")]#text(" (produced jointly by the Association for the British Pharmaceutical Industry, British Petroleum, the Chemical Industry Education Centre, and the Royal Society for Chemistry) that focuses on the applications of each of the elements, rather than their chemical properties. A simple idea, but remarkably effective in bringing the table to life.")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/10/elements.jpg")[#image("../assets/9b8f4341c5a2d14343987a89714f18f11da8b09065a346dccaf0a45ee95d66db-c5425449be2ed1206d6357c54b12db465a281a48e96aeead25540a3d6d8d3f4b.jpg", width: 90%, alt: "elements")]]

#text("It might be amusing to attempt something similar for mathematics, for instance creating a poster that takes each of the top-level categories in the ")#link("http://www.ams.org/mathscinet/msc/msc2010.html")[#text("AMS 2010 Mathematics Subject Classification scheme")]#text(" (or perhaps the ")#link("http://arxiv.org/archive/math")[#text("arXiv math subject classification")]#text("), and listing four or five applications of each, one of which would be illustrated by some simple artwork. (Except, of course, for those subfields that are “seldom found in nature”. :-) )")

#text("A project like this, which would need expertise both in mathematics and in graphic design, and which could be decomposed into several loosely interacting subprojects, seems amenable to a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath")]#text("-type approach; it seems to me that popularisation of mathematics is as valid an application of this paradigm as research mathematics. (Admittedly, there is a danger of “")#link("http://en.wikipedia.org/wiki/Design_by_committee")[#text("design by committee")]#text("“, but a polymath project is not quite the same thing as a committee, and it would be an interesting experiment to see the relative strengths and weaknesses of this design method.) I’d be curious to see what readers would think of such an experiment.")

#text("[")#emph[#text("Update")]#text(", Oct 25: A ")#link("http://mathoverflow.net/")[#text("Math Overflow")]#text(" thread to collect applications of each of the major branches of mathematics has now been ")#link("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")[#text("formed here")]#text(", and is already rather active. Please feel free to contribute!]")

#text("[Via ")#link("http://www.redferret.net/?p=16523")[#text("this post from the Red Ferret")]#text(", which was suggested to me automatically ")#link("http://googlereader.blogspot.com/2009/10/reading-gets-personal-with-popular.html")[#text("via Google Reader’s recommendation algorithm")]#text(".]")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c8d284dd2ddbb40626c126309bc8e8f09a743a2912dbd9b7b72bfd1a29c8e63-fb26f3846087993e4a4209154a6ee4d8b3e21164c0e309de7f1e307e01f6612f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42009")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("I’ve just started a question over a mathoverflow: ")#link("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")[#text("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")]#text(" . I hope some readers here will come and help out. I’m really curious to see if it will work!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Looks like it’s working pretty well so far; Overflow seems like quite a good platform for this sort of activity (collecting diverse examples of a given phenomenon). This will be quite a handy resource if we ever get around to the graphic design project mentioned in the main post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42014")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Darn – I thought someone had come up with an applications-oriented version of the ")#link("http://ncatlab.org/nlab/show/periodic+table")[#text("periodic table of n-categories")]#text(".")

#text("Someday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd2e8f4d74af2ea8b4748654dc52240f2ab8ce0148f87ea6b1c1ac774cb2a906-f9e9d22a2584f0dda380443a4450041650dacd526b27e041114d06b2c1c56255.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42018")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("There’s a problem with the pictures: with chemical elements we have physical objects to draw, but in mathematics it’s not always possible.")

#text("However with the right pictures this is a nice idea. Maybe we may start with geometry, the eastiest to draw and then just see if the project flows on =)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42021")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Well, the applications of mathematics are easier to draw than the mathematics itself. My hope is that if we get enough people working on the project, there will be sufficient artistic creativity to find good depictions of at least one of the applications for each major branch of mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42023")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("One thing that’s been bugging me is that the diagram of the uses of elements already had a strong two dimensional representation to draw on, the periodic table. It is deceptively simple but quite dense in information.")

#text("I am wondering what that two dimensional representation ought to be in the case of mathematics. If one doesn’t exist, how might we go about generating one?")

#text("I thought perhaps the appropriate diagrammatic structure might be some kind of (directed?) graph rather than a table.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("A graph would indeed make a lot of sense. One could imagine for instance the purer branches of mathematics pointing outward to the more applied branches, which in turn point out to actual applications. (Note that some applications would draw from multiple fields of mathematics; error-correcting codes, for instance.)")

#text("One difficulty: the graph is unlikely to be planar. (But perhaps one could use artistic devices to make the graph look three-dimensional.)")

#text("Tim Gowers made a mock-up of such a graph some time ago in his Clay Millennium talk “The importance of mathematics”, which should be locatable online.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42026")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#link("http://www.msri.org/publications/ln/hosted/cmi/2000/cmiparis/gowers_hibit/")[#text("http://www.msri.org/publications/ln/hosted/cmi/2000/cmiparis/gowers_hibit/")]#linebreak()#text(" I found this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Ah, thanks! The slides I had in mind are #14-16.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab57e9002bec3490bbe57ea4d2aaeb6863d4bd581032243f8621551be2deaeac-8f6f9cd6fbae7084e5f021eb33e2be3ccad5ea5a1f9e4958afa19968608523d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42040")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("David Rusin has a ")#link("http://www.math.niu.edu/~rusin/known-math/index/mathmap.html")[#text("map of mathematics")]#text(" (by top-level MSC subject classifications). His ")#link("http://www.math.niu.edu/~rusin/known-math/collection/mathmap.html")[#text("explanation")]#text(" says that two MSC classifications are near each other if they often are used on the same paper; this positions them in a certain high-dimensional space, and he gives a two-dimensional projection.")

#text("It’s hard to say explicitly what the two dimensions there represent. Top-bottom seems to be discrete-continuous. I ")#emph[#text("want")]#text(" the other dimension to be pure-applied but I don’t really see it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42042")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("I’d say abstract versus concrete. The right hand side looks like the sort of fields that I associate with category theory, very infinite constructions and difficult machinary; the left I associate with detailed examples and clever tricks.")

#text("This isn’t the same as pure-applied: Quantum and Relativity are both on the right; Logic and Circuit theory are both on the left.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42043")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Ugg. Circuit theory, of course, is very applied. I wasn’t thinking when I wrote that.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42032")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Assuming the slides aren’t based on data, I’ve been thinking about ways to generate the graph. My best idea so far is to use a google docs spreadsheet to record an adjacency matrix. The topics can be across the top and down the side. Depending on how large it is, it might take quite a few people to think about the relationships and google docs would support such a collaboration. I am hoping that we can also figure out the degree of relationships between fields and represent it with a number between 0 and 1 (perhaps based on the percent of people that think there is a relationship?) rather than just having a 0 for unrelated and a 1 for related.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42035")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Just to be clear, I meant that google docs would be a reasonable way to generate the data needed to make the diagram; I wasn’t suggesting it as the end product.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stew diggles")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42034")[#strong[#text("stew diggles")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("I think, Kareem, Mr. T is talking about a professional-looking graphics presentation, molded by an artist; something that would rival the work done on the chemistry side. Don’t get me wrong, I love Google Docs, too, just not on the design front.")

#text("Big T, it looks like you’ve got a lot of pull around here, eh?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/648c9307566bf529ba51aa0185d3e5654a4835df74916028837e1cbb62548ddc-0ea4f173db4b344804dc9a949992f31e1e6026492f1e575d71ed67c8301dc5e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dilbert")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42038")[#strong[#text("Dilbert")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("I don’t have an account but AT (knot theory) is used when dealing with protein foldning and other DNA issues. ")#emph[#text("[Added, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42044")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Surely there’s a wonderful application of arsenic missing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42108")[#strong[#text("Weekend miscellany — The Endeavour")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")]

#text("[…] Application-oriented periodic table […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42137")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2009")])]

#text("I have been thinking about the concept of a representation of the relationships between different parts of mathematics and I finally got around to making the visualizaton: ")#link("http://twofoldgaze.wordpress.com/2009/11/01/an-attempt-at-mapping-mathematics/")[#text("http://twofoldgaze.wordpress.com/2009/11/01/an-attempt-at-mapping-mathematics/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42176")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2009")])]

#text("I made a small update where I adjusted the vertexes to have sizes proportional to the number of papers. The link is the same as above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52587c31312409490ed0d7aeb816dcb31208d3fb073489436ffba17090746bb8-1500e0585a06264003a7e45a0c7e2352d33fbfb8b1b235d548c3e34a5782e0fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ball")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42298")[#strong[#text("Ball")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("Do you think there are some online mathematics publication for general level? I am still not at the level to read specific mathematics journals, but I want to read some news about mathematics. For other science areas, I think Nature journal has done a good job. It contains some easier articles to help you to understand the more specific ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0125ee4d7ee3175a29b4f68896737a605156edbf46c48761f04c252ab7ba9b13-a618a10dea428ba0ceb9fb3f997339efccf88ab900aa0a38c31496f5ec71f7b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hiten Patel")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-42336")[#strong[#text("Hiten Patel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2009")])]

#text("I have a young boy (9 yo) who loves mathematics and chemistry. I have downloaded the periodic chart, and simply want to say thank you for posting. He will love this!")#linebreak()#text(" Also, I’d like to encourage the development of the mathematics chart. I am not a mathematician so do not understand the method that you propose in your post, but I do know that there is at least one customer out here for the end product! :)")#linebreak()#text(" Thanks.")#linebreak()#text(" Hiten")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d65893e23219d923959c6cb1fd478799d606350ef2a428f742d7e7d16f68620-67b1ad8c61248dd773aa320b81e1258fbd9b19dd36457511843fc51788401213.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bre")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-46770")[#strong[#text("Bre")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("I am a 8th grade teacher in NC and came across your site while researching some information about the periodic table for my chemistry class this year. I just wanted to thank you for the great information and articles about the the periodic table.")

#text("We would love it if you could write a few articles for us, but I understand if your busy so a link to some of the current articles would be very helpful as well to help us spread trusted resources to other teachers. I have included a link to the site in case you would like to help us out by linking to it, tweeting it, or adding it to your Facebook profile.")

#link("http://www.thefreeresource.com/the-periodic-table-elements-symbols-and-atomic-numbers")[#text("http://www.thefreeresource.com/the-periodic-table-elements-symbols-and-atomic-numbers")]

#text("Thanks and keep the great resources coming")

#text("Bre Matthews")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04aa0be22707e39d2e1c4f70fbd06c9cf1323a22e542c0792e10308993bb41ee-4e630970d7e89d6fdf692f3d5cb5a4008f3e9118f4cf5c3535d50b2961743bd1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Ortiz")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-238283")[#strong[#text("Arturo Ortiz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("I am sorry, but I could not find the *.pdf for the periodic table, based on applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")[#text("Applications-oriented periodic table")]
]

#linebreak()#text(" What happened? I really would like to have a look at it")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9521e98d660cc271844f73bbffc279f55fe0a15b317f2088883011d1c7d85724-f20a2ad7fb6a7f4b7b42f2e267f725604eceed14375e89dfea88ac48dafc2029.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-238288")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Fixed link:")

#link("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic-table-2005.pdf")[#text("Click to access Periodic-table-2005.pdf")]

#text("In general, it’s often good to google for the name of the pdf to see if it has moved.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9cbb4d12c393b5044aedeb3f350cb71c652a5e747d42ca728c262d580c15ec3-624bd4cba30772588ad93a65ddfa0a814073d11e3bf55600b0de4850bec938d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David B")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-428362")[#strong[#text("David B")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("There is an updated table here: ")#link("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic%20table%20Jan%2009.pdf")[#text("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic%20table%20Jan%2009.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-447465")[#strong[#text("Real-world applications of mathematics, by arxiv subject area? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")]

#text("[…] is inspired by Terry Tao’s recent post about a periodic table of the elements listing commercial applications. He suggested it might be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644bd2dfff2eef221383337ba5b0113532067230fbb8d507c5d46da3f539d124-8f7336cb70ed87898220320cde9e6a639b8409aa6fb62854b0eac4d2bce4bb88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-452068")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("Kids would see more hw in this periodic table methodology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/#comment-634556")[#strong[#text("Real-world purposes of arithmetic, by arxiv matter region? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2021")]

#text("[…] is impressed by Terry Tao’s current put up a couple of sporadic desk of the weather itemizing industrial purposes. He prompt it energy breathe […]")
]
