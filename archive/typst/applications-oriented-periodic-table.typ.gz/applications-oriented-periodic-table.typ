// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/
// Converted to Typst by tao2typ: "2026-10-25T11:50:47.142249+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Applications-oriented periodic table", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Applications-oriented periodic table")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")[#text("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-25 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Here is a ")#link("http://www.abpi.org.uk/publications/pdfs/Periodic-table-2005.pdf")[#text("nice version of the periodic table")]#text(" (produced jointly by the Association for the British Pharmaceutical Industry, British Petroleum, the Chemical Industry Education Centre, and the Royal Society for Chemistry) that focuses on the applications of each of the elements, rather than their chemical properties. A simple idea, but remarkably effective in bringing the table to life.")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2009/10/elements.jpg")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #text("elements") · #link("https://terrytao.wordpress.com/wp-content/uploads/2009/10/elements.jpg?w=500&h=226")[Original image]]]]]

#text("It might be amusing to attempt something similar for mathematics, for instance creating a poster that takes each of the top-level categories in the ")#link("http://www.ams.org/mathscinet/msc/msc2010.html")[#text("AMS 2010 Mathematics Subject Classification scheme")]#text(" (or perhaps the ")#link("http://arxiv.org/archive/math")[#text("arXiv math subject classification")]#text("), and listing four or five applications of each, one of which would be illustrated by some simple artwork. (Except, of course, for those subfields that are “seldom found in nature”. 🙂 )")

#text("A project like this, which would need expertise both in mathematics and in graphic design, and which could be decomposed into several loosely interacting subprojects, seems amenable to a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath")]#text("-type approach; it seems to me that popularisation of mathematics is as valid an application of this paradigm as research mathematics. (Admittedly, there is a danger of “")#link("http://en.wikipedia.org/wiki/Design_by_committee")[#text("design by committee")]#text("“, but a polymath project is not quite the same thing as a committee, and it would be an interesting experiment to see the relative strengths and weaknesses of this design method.) I’d be curious to see what readers would think of such an experiment.")

#text("[")#emph[#text("Update")]#text(", Oct 25: A ")#link("http://mathoverflow.net/")[#text("Math Overflow")]#text(" thread to collect applications of each of the major branches of mathematics has now been ")#link("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")[#text("formed here")]#text(", and is already rather active. Please feel free to contribute!]")

#text("[Via ")#link("http://www.redferret.net/?p=16523")[#text("this post from the Red Ferret")]#text(", which was suggested to me automatically ")#link("http://googlereader.blogspot.com/2009/10/reading-gets-personal-with-popular.html")[#text("via Google Reader’s recommendation algorithm")]#text(".]")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ec1c4105a9fcaa8cf338037cdabdfb5491874cd93f2687ee9e54bfc1cabfd5c-8630c4f4d1a3d9052f42c7ba6fba07a000d1ee59955911afceb9190d2722c0d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Morrison")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42009")[#strong[#text("Scott Morrison")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("I’ve just started a question over a mathoverflow: ")#link("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")[#text("http://mathoverflow.net/questions/2556/real-world-applications-of-mathematics-by-arxiv-subject-area")]#text(" . I hope some readers here will come and help out. I’m really curious to see if it will work!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Looks like it’s working pretty well so far; Overflow seems like quite a good platform for this sort of activity (collecting diverse examples of a given phenomenon). This will be quite a handy resource if we ever get around to the graphic design project mentioned in the main post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1808f04efb82ca11ba6e0910e0e4d9c9874a4a6910067c9effdaa63d6cf7f46d-bde3c7e1a9d2f46e03845b8c40fb1fcbf6d586a8e10f977f0aac80dcf2ffb93b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42014")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Darn – I thought someone had come up with an applications-oriented version of the ")#link("http://ncatlab.org/nlab/show/periodic+table")[#text("periodic table of n-categories")]#text(".")

#text("Someday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05a2cdd98aeda9c2ece2a92d8123db3c412f1cd941a53b1acb0c82e238c1e888-e09278d9aac3d5e14106d91b707e69c32ca7dba9909d305b97954c1cc775080b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42018")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("There’s a problem with the pictures: with chemical elements we have physical objects to draw, but in mathematics it’s not always possible.")

#text("However with the right pictures this is a nice idea. Maybe we may start with geometry, the eastiest to draw and then just see if the project flows on =)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42021")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Well, the applications of mathematics are easier to draw than the mathematics itself. My hope is that if we get enough people working on the project, there will be sufficient artistic creativity to find good depictions of at least one of the applications for each major branch of mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42023")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("One thing that’s been bugging me is that the diagram of the uses of elements already had a strong two dimensional representation to draw on, the periodic table. It is deceptively simple but quite dense in information.")

#text("I am wondering what that two dimensional representation ought to be in the case of mathematics. If one doesn’t exist, how might we go about generating one?")

#text("I thought perhaps the appropriate diagrammatic structure might be some kind of (directed?) graph rather than a table.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("A graph would indeed make a lot of sense. One could imagine for instance the purer branches of mathematics pointing outward to the more applied branches, which in turn point out to actual applications. (Note that some applications would draw from multiple fields of mathematics; error-correcting codes, for instance.)")

#text("One difficulty: the graph is unlikely to be planar. (But perhaps one could use artistic devices to make the graph look three-dimensional.)")

#text("Tim Gowers made a mock-up of such a graph some time ago in his Clay Millennium talk “The importance of mathematics”, which should be locatable online.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42026")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#link("http://www.msri.org/publications/ln/hosted/cmi/2000/cmiparis/gowers_hibit/")[#text("http://www.msri.org/publications/ln/hosted/cmi/2000/cmiparis/gowers_hibit/")]#linebreak()#text(" I found this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42028")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Ah, thanks! The slides I had in mind are #14-16.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dad2a4ea966da506c5c525388038eb0ea46ee014d84b5f57f903c2e397aaa43-f2537264dbc13dd9a4b6f1afb8b5facff7bb006bdb07b41623bcba44b4f12882.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Lugo")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42040")[#strong[#text("Michael Lugo")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("David Rusin has a ")#link("http://www.math.niu.edu/~rusin/known-math/index/mathmap.html")[#text("map of mathematics")]#text(" (by top-level MSC subject classifications). His ")#link("http://www.math.niu.edu/~rusin/known-math/collection/mathmap.html")[#text("explanation")]#text(" says that two MSC classifications are near each other if they often are used on the same paper; this positions them in a certain high-dimensional space, and he gives a two-dimensional projection.")

#text("It’s hard to say explicitly what the two dimensions there represent. Top-bottom seems to be discrete-continuous. I ")#emph[#text("want")]#text(" the other dimension to be pure-applied but I don’t really see it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba264123d2c3a6202f77c8b366578fd777d4acfd84d1ca97187ba3d9a3fb2d2-a4c1c775d56ad869bd9a0fa0f25b1b77b061b9d680bbdd26a8820c890aca2673.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42042")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("I’d say abstract versus concrete. The right hand side looks like the sort of fields that I associate with category theory, very infinite constructions and difficult machinary; the left I associate with detailed examples and clever tricks.")

#text("This isn’t the same as pure-applied: Quantum and Relativity are both on the right; Logic and Circuit theory are both on the left.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba264123d2c3a6202f77c8b366578fd777d4acfd84d1ca97187ba3d9a3fb2d2-a4c1c775d56ad869bd9a0fa0f25b1b77b061b9d680bbdd26a8820c890aca2673.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42043")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Ugg. Circuit theory, of course, is very applied. I wasn’t thinking when I wrote that.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42032")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("Assuming the slides aren’t based on data, I’ve been thinking about ways to generate the graph. My best idea so far is to use a google docs spreadsheet to record an adjacency matrix. The topics can be across the top and down the side. Depending on how large it is, it might take quite a few people to think about the relationships and google docs would support such a collaboration. I am hoping that we can also figure out the degree of relationships between fields and represent it with a number between 0 and 1 (perhaps based on the percent of people that think there is a relationship?) rather than just having a 0 for unrelated and a 1 for related.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42035")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Just to be clear, I meant that google docs would be a reasonable way to generate the data needed to make the diagram; I wasn’t suggesting it as the end product.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stew diggles")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42034")[#strong[#text("stew diggles")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2009")])]

#text("I think, Kareem, Mr. T is talking about a professional-looking graphics presentation, molded by an artist; something that would rival the work done on the chemistry side. Don’t get me wrong, I love Google Docs, too, just not on the design front.")

#text("Big T, it looks like you’ve got a lot of pull around here, eh?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6db349f76ec22b6b42122d984375dabe3eaf1732266ffb42eff27dadd2ddd3cc-503d8025f6a7f78f397d671411c2e14ba896c44990b379e4f7a86a0dcc97a555.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dilbert")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42038")[#strong[#text("Dilbert")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("I don’t have an account but AT (knot theory) is used when dealing with protein foldning and other DNA issues. ")#emph[#text("[Added, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fbd38cf9e13c5e26cb12dabe150c8944a955355744ffad32134e55aaeeedc11-2977d81b01681a87b0c5d80b507188f0c60cb3400f55c970440ee3d36b42ebff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42044")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("Surely there’s a wonderful application of arsenic missing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42108")[#strong[#text("Weekend miscellany — The Endeavour")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2009")]

#text("[…] Application-oriented periodic table […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42137")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2009")])]

#text("I have been thinking about the concept of a representation of the relationships between different parts of mathematics and I finally got around to making the visualizaton: ")#link("http://twofoldgaze.wordpress.com/2009/11/01/an-attempt-at-mapping-mathematics/")[#text("http://twofoldgaze.wordpress.com/2009/11/01/an-attempt-at-mapping-mathematics/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/195d4171697dc9e94148580f1883c193731040fd4ad965fbb8681da456483978-ff016f013f782e9f53775442369843721590f77f043b792688d5702a55ab39f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42176")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2009")])]

#text("I made a small update where I adjusted the vertexes to have sizes proportional to the number of papers. The link is the same as above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8d4b35af75f56bfcd3c5ffed5097ac8e96a5e76082e70056427e158afb9db60-9059b2996107620cae7a63f5fc9b59debd34ec3676e59cca98f49e712c772e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ball")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42298")[#strong[#text("Ball")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")])]

#text("Do you think there are some online mathematics publication for general level? I am still not at the level to read specific mathematics journals, but I want to read some news about mathematics. For other science areas, I think Nature journal has done a good job. It contains some easier articles to help you to understand the more specific ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6c5568c371baa599cbb3837e0cc759c1d42bb201bbaffe336d13d709cdf7482-9fbdb91f2d3c28c8ce39a6df67a2aaa52dfd6443f852210950a5ba61abcd3cd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hiten Patel")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-42336")[#strong[#text("Hiten Patel")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2009")])]

#text("I have a young boy (9 yo) who loves mathematics and chemistry. I have downloaded the periodic chart, and simply want to say thank you for posting. He will love this!")#linebreak()#text(" Also, I’d like to encourage the development of the mathematics chart. I am not a mathematician so do not understand the method that you propose in your post, but I do know that there is at least one customer out here for the end product! 🙂")#linebreak()#text(" Thanks.")#linebreak()#text(" Hiten")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d9ccbcb631d1ff02011d980a2ef538d1470f66b0dd2a94c7d407e82692794a1-c4d666e25851a950a3355c1cfd35ab2c9b1ebda479afd8bb6b89891ea73f8c04.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bre")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-46770")[#strong[#text("Bre")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2010")])]

#text("I am a 8th grade teacher in NC and came across your site while researching some information about the periodic table for my chemistry class this year. I just wanted to thank you for the great information and articles about the the periodic table.")

#text("We would love it if you could write a few articles for us, but I understand if your busy so a link to some of the current articles would be very helpful as well to help us spread trusted resources to other teachers. I have included a link to the site in case you would like to help us out by linking to it, tweeting it, or adding it to your Facebook profile.")

#link("http://www.thefreeresource.com/the-periodic-table-elements-symbols-and-atomic-numbers")[#text("http://www.thefreeresource.com/the-periodic-table-elements-symbols-and-atomic-numbers")]

#text("Thanks and keep the great resources coming")

#text("Bre Matthews")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/674484a505f5c81467f7e7b76f3a83cee54daf9011dcac85acdf49c1edc54a96-95795be0c0b0c69e0ed500032d7a7e5c995169d17928db73ded3bc4b622551fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arturo Ortiz")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-238283")[#strong[#text("Arturo Ortiz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("I am sorry, but I could not find the *.pdf for the periodic table, based on applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/")[#text("Applications-oriented periodic table")]
]

#linebreak()#text(" What happened? I really would like to have a look at it")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5beb8999b93a3bd34ddc5f6f6064281e71037e579d7d5ffdab659ffc1b44206c-b5d9dd9254784b68173af31d2a6de12c4eb78e88cd519ff16c2f4a4f7901a35c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-238288")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Fixed link:")

#link("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic-table-2005.pdf")[#text("Click to access Periodic-table-2005.pdf")]

#text("In general, it’s often good to google for the name of the pdf to see if it has moved.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83f2f7b3141db048695f74c2511a10946ad763bea75cd77a7c0783534876bd0e-1101b1d4cf7e20df22c1b26d093f3690c6f7667074e6c2297f3a81e3e517963f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David B")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-428362")[#strong[#text("David B")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("There is an updated table here: ")#link("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic%20table%20Jan%2009.pdf")[#text("http://www.abpi.org.uk/our-work/library/posters/Documents/Periodic%20table%20Jan%2009.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-447465")[#strong[#text("Real-world applications of mathematics, by arxiv subject area? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")]

#text("[…] is inspired by Terry Tao’s recent post about a periodic table of the elements listing commercial applications. He suggested it might be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1b7bfe25394d8813483f50b42fb229f9da2a689cd107dc2413cb3859bb156db-03c6392cdd25ae922ae32af9c3a329b403b8455a4985c2e75b78dd2c4a5132d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-452068")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("Kids would see more hw in this periodic table methodology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/25/applications-oriented-periodic-table/comment-page-1/#comment-634556")[#strong[#text("Real-world purposes of arithmetic, by arxiv matter region? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2021")]

#text("[…] is impressed by Terry Tao’s current put up a couple of sporadic desk of the weather itemizing industrial purposes. He prompt it energy breathe […]")
]
