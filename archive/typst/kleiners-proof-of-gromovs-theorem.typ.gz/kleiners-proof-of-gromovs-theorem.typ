// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/
// Converted to Typst by tao2typ: "2026-10-14T06:53:16.794130+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Kleiner’s proof of Gromov’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Kleiner’s proof of Gromov’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This week there is a conference here at ")#link("http://www.ipam.ucla.edu/")[#text("IPAM")]#text(" on ")#link("http://www.ipam.ucla.edu/programs/eg2008/")[#text("expanders in pure and applied mathematics")]#text(". I was an invited speaker, but I don’t actually work in expanders ")#emph[#text("per se")]#text(" (though I am certainly interested in them). So I spoke instead about the recent simplified proof ")#link("http://arxiv.org/abs/0710.4593")[#text("by Kleiner")]#text(" of the celebrated ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("theorem of Gromov on groups of polynomial growth")]#text(". (This proof does not directly mention expanders, but the argument nevertheless hinges on the ")#emph[#text("absence")]#text(" of expansion in the Cayley graph of a group of polynomial growth, which is exhibited through the smoothness properties of harmonic functions on such graphs.)")

#heading(level: 1)[#metadata(none) <tao-303275357f11934a43b8>#text("— Gromov’s theorem —")]

#text("Let G be an at most countable group generated by a finite set S of generators, which we can take to be symmetric (i.e. ")#mi("s^{-1} \\in S")#text(" whenever ")#mi("s \\in S")#text("). Then we can form the ")#emph[#text("Cayley graph")]#text(" ")#mi("\\Gamma")#text(", whose vertices are the elements of G, and with g and gs connected by an edge for every ")#mi("g \\in G")#text(" and ")#mi("s \\in S")#text(". This is a connected regular graph, with a transitive left-action of G. For any vertex x and ")#mi("R>0")#text(", one can define the ball B(x,R) in ")#mi("\\Gamma")#text(" to be the set of all vertices connected to x by a path of length at most R. We say that G has ")#emph[#text("polynomial growth")]#text(" if we have the bound ")#tao-math("\\left|B(x,R)\\right| = O( R^{O(1)} )", block: false)#text(" as ")#mi("R \\to \\infty")#text("; one can easily show that the left-hand side is independent of x, and that the polynomial growth property does not depend on the choice of generating set S.")

#text("Examples of finitely generated groups of polynomial growth include")

#enum(start: 1, 
[#text("Finite groups;")],
[#text("Abelian groups (e.g. ")#mi("{\\Bbb Z}^d")#text(");")],
[#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("Nilpotent")]#text(" groups (a generalisation of 2);")],
[#emph[#text("Virtually nilpotent")]#text(" groups, i.e. it has a nilpotent subgroup of finite index (a combination of 1 and 3).")]
)

#text("In 1981, ")#link("http://www.ams.org/mathscinet-getitem?mr=623534")[#text("Gromov proved")]#text(" that these are the only examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Gromov’s theorem). Let G be a finitely generated group of polynomial growth. Then G is virtually nilpotent.")
]

#text("Gromov’s original argument used a number of deep tools, including the ")#link("http://www.ams.org/mathscinet-getitem?mr=379739")[#text("Montgomery-Zippin-Yamabe structure theory")]#text(" of locally compact groups (related to ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text("), as well as various earlier partial results on the problem. Several proofs have subsequently been found. Recently, Kleiner obtained a proof which was significantly more elementary, although it still relies on some non-trivial partial versions of Gromov’s theorem. Specifically, it needs the following result proven ")#link("http://www.ams.org/mathscinet-getitem?mr=248688")[#text("by Wolf")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=248688")[#text("http://www.ams.org/mathscinet-getitem?mr=248688")]#link("http://www.ams.org/mathscinet-getitem?mr=244899")[#text("by Milnor")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text("(Gromov’s theorem for virtually solvable groups) Let G be a finitely generated group of polynomial growth which is ")#emph[#text("virtually solvable")]#text(" (i.e. it has a ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable")]#text(" subgroup of finite index). Then it is virtually nilpotent.")
]

#text("The argument also needs a related result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3. ")]#text("Let G be a finitely generated ")#link("http://en.wikipedia.org/wiki/Amenable")[#text("amenable")]#text(" group which is linear, thus ")#mi("G \\subset GL_n({\\Bbb C})")#text(" for some n. Then G is virtually solvable.")
]

#text("This theorem is an immediate consequence of the ")#link("http://www.ams.org/mathscinet-getitem?mr=286898")[#text("Tits alternative")]#text(", but also has a short elementary proof, due ")#link("http://www.ams.org/mathscinet-getitem?mr=1489360")[#text("to Shalom")]#text(". An easy application of the pigeonhole principle to the sequence ")#tao-math("\\left|B(x,R)\\right|", block: false)#text(" for ")#mi("R = 1,2,\\ldots")#text(" shows that every group of polynomial growth is amenable. Thus Theorem 2 and Theorem 3 already give Gromov’s theorem for linear groups.")

#text("Other than Theorem 2 and Theorem 3, Kleiner’s proof of Theorem 1 is essentially self contained. The argument also extends to groups of ")#emph[#text("weakly polynomial growth")]#text(", which means that ")#tao-math("\\left|B(x,R)\\right| = O( R^{O(1)} )", block: false)#text(" for some sequence of radii R going to infinity. (This extension of Gromov’s theorem was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("by van der Dries and Wilkie")]#text(".) But for simplicity we only discuss the polynomial growth case here.")

#heading(level: 1)[#text("— Reductions —")]

#text("The first few reductions follow the lines of Gromov’s original argument. The first observation is that it suffices to exhibit an infinite abelianisation of G, or more specifically to prove:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Existence of infinite abelian representation) Let G be an infinite finitely generated group of polynomial growth. Then there exists a subgroup G’ of finite index whose ")#link("http://en.wikipedia.org/wiki/Commutator_subgroup#Abelianization")[#text("abelianisation")]#text(" ")#mi("G^{\\prime}/[G^{\\prime},G^{\\prime}]")#text(" is infinite.")
]

#text("Indeed, if G’ has infinite abelianisation, then one can find a non-trivial homomorphism ")#mi("\\alpha: G^{\\prime} \\to {\\Bbb Z}")#text(". The kernel K of this homomorphism is a normal subgroup of G’. Using the polynomial growth hypothesis, one can show that K is also finitely generated; furthermore, it is polynomial growth of one lower order (i.e. the exponent in the ")#mi("O(R^{O(1)})")#text(" bound for ")#tao-math("\\left|B(x,R)\\right|", block: false)#text(" is reduced by 1). An induction hypothesis then gives that K is virtually nilpotent, which easily implies that G’ (and thus G) is virtually solvable. Gromov’s theorem for infinite G then follows from Theorem 2. (The theorem is of course trivial for finite G.)")

#text("[Note: the above argument not only shows that G is virtually solvable, but moreover that G’ is the ")#link("http://en.wikipedia.org/wiki/Semidirect_product")[#text("semidirect product")]#text(" ")#mi("K \\rtimes_\\phi {\\Bbb Z}")#text(" of a virtually nilpotent group K and the integers, which acts on K by some automorphism ")#mi("\\phi")#text(". So it seems to me that one does not actually need the full strength of Theorem 2 here, but only the special case of semidirect products of the above form, which might be doable “by hand”, for instance by inducting on the step of K. This might make Kleiner’s proof even more elementary, though I have not fully checked the details.]")

#text("To show Proposition 1, it suffices to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" (Existence of infinite linear representation) Let G be an infinite finitely generated group of polynomial growth. Then there exists a finite-dimensional representation ")#mi("\\rho: G \\to GL_n({\\Bbb C})")#text(" whose image ")#mi("\\rho(G)")#text(" is infinite.")
]

#text("Indeed, the image ")#mi("\\rho(G) \\subset GL_n({\\Bbb C})")#text(" is also finitely generated with polynomial growth, and hence by Theorem 3 and Theorem 2 is virtually nilpotent (actually, for this argument we don’t need Theorem 2 and would be content with virtual solvability). If the abelianisation of ")#mi("\\rho(G)")#text(" is finite, one can easily pass to a subgroup G’ of finite index and reduce the (virtual) step of ")#mi("\\rho(G^{\\prime})")#text(" by 1, so one can quickly reduce to the case when the abelianisation is infinite, at which point Proposition 1 follows.")

#text("So all we need to do now is to prove Proposition 2.")

#heading(level: 1)[#text("— Harmonic functions on Cayley graphs —")]

#text("Kleiner’s approach to Proposition 2 relies on the notion of a (possibly vector-valued) ")#emph[#text("harmonic function ")]#text("on the Cayley graph ")#mi("\\Gamma")#text(". This is a function ")#mi("f: G \\to H")#text(" taking values in a Hilbert space H such that ")#tao-math("f(g) = \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} f(gs)", block: false)#text(" for all ")#mi("g \\in G")#text(". Formally, harmonic functions are local minimisers of the energy functional")

#align(center)[#tao-fit-display[#tao-math("E(f) := \\frac{1}{2} \\sum_{g \\in G} \\left|\\nabla f(g)\\right|^2", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla f(g)\\right|^2 := \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} \\left\\| f(gs) - f(g)\\right\\|_H^2", block: true)]]

#text("though of course with the caveat that E(f) is often infinite. (This property is also equivalent to a certain graph Laplacian of f vanishing.)")

#text("Of course, every constant function is harmonic. But there are other harmonic functions too: for instance, on ")#mi("{\\Bbb Z}^d")#text(", any linear function is harmonic (regardless of the actual choice of generators). Kleiner’s proof of Proposition 2 follows by combining the following two results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text("Let G be an infinite finitely generated group of polynomial growth. Then there exists an (affine-) ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometric")]#text(" (left-)action of G on a Hilbert space H with no fixed points, and a harmonic map ")#mi("f: G \\to H")#text(" which is G-equivariant (thus ")#mi("f(gh) = g f(h)")#text(" for all ")#mi("g, h \\in G")#text("). (Note that by equivariance and the absence of fixed points, this harmonic map is necessarily non-constant.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4. ")]#text("Let G be an finitely generated group of polynomial growth, and let ")#mi("d \\geq 0")#text(". Then the linear space of harmonic functions ")#mi("u: G \\to {\\Bbb R}")#text(" which grow of order at most d (thus ")#mi("u(g) = O(R^d)")#text(" on ")#mi("B(\\text{id},R)")#text(") is finite-dimensional.")
]

#text("Indeed, if f is the vector-valued map given by Proposition 3, then from the G-equivariance it is easy to see that f is of polynomial growth (indeed it is Lipschitz). But the linear projections ")#mi("\\{ f \\cdot v: v \\in H \\}")#text(" of f to scalar-valued harmonic maps lie in a finite-dimensional space, by Proposition 4. This implies that the range f(G) of f lies in a finite-dimensional space V. On the other hand, the obvious action of G on V has no fixed points (being a restriction of the action of G on H), and so the image of G in ")#mi("GL_n(V)")#text(" must be infinite, and Proposition 2 follows.")

#text("It remains to prove Proposition 3 and Proposition 4. Proposition 3 follows by some more general results of ")#link("http://www.ams.org/mathscinet-getitem?mr=1483983")[#text("Korevaar-Schoen")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1364901")[#text("Mok")]#text(", though Kleiner provided an elementary proof which we sketch below. Proposition 4 was initially proven by ")#link("http://www.ams.org/mathscinet-getitem?mr=1491451")[#text("Colding and Minicozzi")]#text(" (for finitely ")#link("http://en.wikipedia.org/wiki/Presentation_of_a_group")[#text("presented")]#text(" groups, at least) using Gromov’s theorem; Kleiner’s key new observation was that Proposition 4 can be proven directly by an elementary argument based on a Poincaré inequalities.")

#heading(level: 1)[#text("— A non-constant equivariant harmonic function —")]

#text("We now sketch the proof of Proposition 2. The first step is to just get the action on a Hilbert space with no fixed points:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1. ")]#text("Let G be a countably infinite ")#link("http://en.wikipedia.org/wiki/Amenable")[#text("amenable")]#text(" group. Then there exists an action of G on a Hilbert space H with no fixed points.")
]

#text("This is essentially the well-known assertion that countably infinite amenable groups do not obey ")#link("http://en.wikipedia.org/wiki/Kazhdan%27s_property_%28T%29")[#text("Property (T)")]#text(", but we can give an explicit proof as follows. Using amenability, one can construct a nested ")#emph[#text("Følner sequence")]#text(" ")#mi("F_1 \\subset F_2 \\subset \\ldots \\subset \\bigcup_n F_n = G")#text(" of finite sets with the property that ")#tao-math("\\left|(F_{n-1} \\cdot F_n) \\Delta F_n\\right| \\leq 2^{-n} \\left|F_n\\right|", block: false)#text(" (say). (In the case of groups of polynomial growth, one can take ")#mi("F_n = B(\\text{id}, R_n)")#text(" for some rapidly growing, randomly chosen sequence of radii ")#mi("R_n")#text(".) We then look at ")#mi("H := l^2({\\Bbb N}; l^2(G))")#text(", the Hilbert space of sequences ")#mi("f_1, f_2, \\ldots \\in l^2(G)")#text(" with ")#tao-math("\\sum_n \\left\\|f_n\\right\\|_{l^2(G)}^2 < \\infty", block: false)#text(". This space has the obvious unitary action of G, defined as ")#mi("g: (f_n(\\cdot))_{n \\in {\\Bbb N}} \\to (f_n(g \\cdot))_{n \\in {\\Bbb N}}")#text(". This action has a fixed point of 0, but we can delete this fixed point by considering instead the affine-isometric action ")#mi("f \\mapsto gf + gh - h")#text(", where h is the sequence ")#tao-math("h = (\\frac{1}{\\left|F_n\\right|^{1/2}} 1_{F_n})_{n \\in {\\Bbb N}}", block: false)#text(". This sequence h does not directly lie in H, but observe that gh-h lies in H for every g. One can then easily show that this action obeys the conclusions of Lemma 1.")

#text("Another way of asserting that an action of G on H has no fixed point is to say that the energy functional ")#mi("E: H \\to {\\Bbb R}^+")#text(" defined by ")#tao-math("E(v) := \\frac{1}{2} \\sum_{s \\in S} \\left\\| sv - v \\right\\|_H^2", block: false)#text(" is always strictly positive. So Lemma 1 concludes that there exists an action of G on a Hilbert space on which E is strictly positive. It is possible to then conclude that there exists another action of G on another Hilbert space on which the energy E is not only strictly positive, but actually attains its minimum at some vector v. This observation follows from more general results ")#link("http://www.ams.org/mathscinet-getitem?mr=2198325")[#text("of Fisher and Margulis")]#text(", but one can also argue directly as follows. For every ")#mi("0 < \\lambda < 1")#text(" and ")#mi("A > 0")#text(" , there must exist a vector v which almost minimises E in the sense that ")#mi("E(v^{\\prime}) \\geq \\lambda E(v)")#text(" whenever ")#tao-math("\\left\\| v-v^{\\prime} \\right\\| \\leq A E(v)^{1/2}", block: false)#text(", since otherwise one could iterate and sum a ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann-type series")]#text(" to obtain a fixed point of v. But then by shifting v to the origin, and taking an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" limit (!) as ")#mi("\\lambda \\to 1")#text(" and ")#mi("A \\to \\infty")#text(", we obtain the claim.")

#text("Some elementary calculus of variations then shows that if v is the energy minimiser, the map ")#mi("f: g \\mapsto gv")#text(" is a harmonic G-equivariant function from G to H, and Proposition 2 follows.")

#heading(level: 1)[#text("— Poincaré’s inequality, and the complexity of harmonic functions —")]

#text("Now we turn to the proof of Proposition 4, which is the main new ingredient in Kleiner’s argument. To simplify the exposition, let us cheat and suppose that the polynomial growth condition ")#tao-math("\\left|B(x,R)\\right| = O( R^{O(1)} )", block: false)#text(" is replaced by the slightly stronger doubling condition ")#tao-math("\\left|B(x,2R)\\right| = O( \\left|B(x,R)\\right| )", block: false)#text(". (In practice, one can use pigeonholing arguments to show that polynomial growth implies doubling on large ranges of scales, which turns out to suffice.) Similarly, to simplify the argument, let us pretend that the harmonic functions ")#mi("u: G \\to {\\Bbb R}")#text(" are not only of polynomial growth, but also obey a doubling condition ")#mi("\\sum_{x \\in B(\\text{id},2R)} u(x)^2 = O( \\sum_{x \\in B(\\text{id},R)} u(x)^2 )")#text(".")

#text("The key point is to exploit the fact that harmonic functions are fairly smooth. For instance, a simple “integration by parts” argument shows that if u is harmonic, then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1);")])
#tao-math("\\sum_{x \\in B(\\text{id},R)} \\left|\\nabla u(x)\\right|^2\\ dx = O( R^{-2} \\sum_{x \\in B(\\text{id},2R)} \\left|u(x)\\right|^2\\ dx )", block: true)]]

#text("this estimate can be established by the usual trick of replacing the summation over ")#mi("B(\\text{id},R)")#text(" with a smoother cutoff function and then expanding out the gradient square.")

#text("To use this gradient control, Kleiner established the Poincaré inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B(x_0,R)} \\sum_{y \\in B(x_0,R)} \\left|u(x)-u(y)\\right|^2", block: true)]]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("= O( R^2 |B( x_0, R)| \\sum_{x \\in B(x_0,3R)} \\left|\\nabla u(x)\\right|^2 )", block: true)]]

#text("assuming the doubling condition on balls. This inequality (a variant of a similar inequality of ")#link("http://www.ams.org/mathscinet-getitem?mr=1232845")[#text("Coulhon and Saloff-Coste")]#text(") is actually quite easy to prove. Observe that if ")#mi("x, y \\in B(x_0,R)")#text(", then x=yg for some ")#mi("g \\in B(0,2R)")#text(". Thus it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B(x_0,R)} \\left|u(x)-u(xg)\\right|^2 = O( R^2 \\sum_{x \\in B(x_0,3R)} \\left|\\nabla u(x)\\right|^2 )", block: true)]]

#text("for each such g. But by expanding g as a product of at most 2R generators, splitting ")#mi("u(x)-u(xg)")#text(" as a telescoping series, and using Cauchy-Schwarz, the result follows easily.")

#text("Combining (1) and (2), one sees that a harmonic function which is controlled on a large ball ")#mi("B(0,R)")#text(", becomes nearly constant on small balls ")#mi("B(x,\\varepsilon R)")#text(" (morally speaking, we have ")#tao-math("\\left|u(x)-u(y)\\right| \\ll \\varepsilon \\left|u(x)\\right|", block: false)#text(" “on the average” on such small balls). In particular, given any ")#mi("0 < \\varepsilon < 1")#text(", one can now obtain an inequality of the form")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in B(\\text{id},R)} \\left|u(x)\\right|^2 \\leq", block: true)]]

#align(center)[#tao-fit-display[#tao-math("O( \\frac{1}{\\left|B(\\text{id},\\varepsilon R)\\right|} \\sum_j \\left|\\sum_{x \\in B_j} u(x)\\right|^2 + \\varepsilon^2 \\sum_{x \\in B(\\text{id},16 R)} \\left|u(x)\\right|^2)", block: true)]]

#text("where ")#mi("B_j")#text(" ranges over a cover of ")#mi("B(\\text{id},R)")#text(" by balls ")#mi("B_j")#text(" of radius ")#mi("\\varepsilon R")#text(" (the number of such balls can be chosen to be polynomially bounded in ")#mi("1/\\varepsilon")#text(", by the doubling condition). As a consequence, we see that if a harmonic function ")#mi("u")#text(" obeys a doubling condition, and has zero average on each ball ")#mi("B_j")#text(", then it vanishes identically. Morally speaking, this shows that the space of functions that obeys the doubling condition has finite dimension (bounded by the number of such balls), yielding Proposition 4 in the doubling case. It requires a small amount of combinatorial trickery to obtain this conclusion in the case when u and the balls ")#mi("B(\\text{id},R)")#text(" exhibit polynomial growth rather than doubling, but the general idea is still the same.")

#text("[")#emph[#text("Update")]#text(", Feb 17: some discrepancies in the order of group multiplication (e.g. left actions vs. right actions) fixed (I think…).]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IU student")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-26300")[#strong[#text("IU student")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Hi Dr. Tao,")

#text("Since you posted this article, I am courious that do you know any interesting theorems about ergodic theorems on nilpotent Lie groups or Lie groups of polynomial growth. My question might be too abstract.:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-26304")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Dear IU student,")

#text("For amenable groups (which include nilpotent groups and groups of polynomial growth as special cases), most of the standard ergodic theorems continue to apply with only minor modifications (at least if one is willing to restrict one’s average to lie along a Folner sequence). This observation is already implicitly in the classical work of Wiener; some further refinements in this direction can be found in a 1987 Journal d’Analyse paper of Ornstein-Weiss, and a 2001 Inventiones paper of Lindenstrauss.")

#text("There are some ergodic theorems for non-amenable groups too, though the theory here is significantly less systematic. For instance there is a 1997 Annals paper of Nevo and Stein which considers semisimple groups (and an earlier 1994 Acta paper by the same authors considering free groups).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-26441")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("I am communicating here an observation from my colleague, Yehuda Shalom, who noted that one does not need the full strength of Proposition 3 (constructing the vector-valued equivariant harmonic map) in order to deduce Proposition 2 from Proposition 4. Instead, all one needs is a single non-constant scalar harmonic map f of polynomial growth. Indeed, observe that G acts by left rotation on the space V of harmonic maps of a fixed polynomial growth, which is finite dimensional by Proposition 4. If the image of f is infinite then Proposition 2 is immediate, so suppose the image of f is finite. Then there is a normal subgroup N of G of finite index which stabilises f (and everyone else in the image of f also). Because of this, the harmonic map f on G pushes down to a harmonic map on the quotient space N\\G (which still has a right-action of the generator set S). But it is easy to see that a harmonic map on a finite connected graph is constant, and so f is constant, a contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f563bddef1ea6c900459b818043ae43f59604042e090bc80cd98e994ab2ad2d-855eee57d6ce545af19e1c1d482f30e9f9ca47a674424b7182685751495a71c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fisher")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-26762")[#strong[#text("David Fisher")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2008")])]

#text("Hi Terry,")

#text("While this isn’t directly germane to your post, it")#linebreak()#text(" is little known and should be better known. I")#linebreak()#text(" only learned it myself a few months ago. Figure if I say it here, more people will know it.")

#text("There is a relatively short account of the main")#linebreak()#text(" results of the Montgomery-Zippin-Yamabe theory of locally compact groups. It is in a twenty page paper by Joram Hirschfeld see ")#link("http://www.ams.org/mathscinet-getitem?mr=967314")[#text("http://www.ams.org/mathscinet-getitem?mr=967314")]#text(".")

#text("The proof is written in the language of nonstandard")#linebreak()#text(" analysis, but I think it should also be possible to give a standard version that would also be substantially simpler than the usual references to")#linebreak()#text(" books of Montgomery-Zippin or Kaplansky.")

#text("The fact that Kleiner’s proof doesn’t use this stuff at all is still a major breakthrough.")

#text("Best,")

#text("David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-26826")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2008")])]

#text("Dear David,")

#text("Thanks for the reference! It indeed is a surprise that this sort of thing is not better known (for instance, MathSciNet lists no citations for this paper).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54be98056580659ded2064b628d075e937d15513e5580a5fd8fdce4fa016517f-f995c40925b60a4b6bfd087470f76b077940a84f948143a913d46da323d146b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jrluw")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-29248")[#strong[#text("jrluw")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("By the way, your intuition that it should be easier to prove Theorem 2 in the case of semidirect products K x Z (where K is virtually nilpotent) seems correct. It is done in an appendix to Gromov’s original paper (by Tits): ")#link("http://www.numdam.org/item?id=PMIHES_1981__53__53_0")[#text("http://www.numdam.org/item?id=PMIHES_1981__53__53_0")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-30373")[#strong[#text("Eigenvalue multiplicity and growth of groups « tcs math - some mathematics of theoretical computer science")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2008")]

#text("[…] and the structure of finite groups. Earlier this year at an IPAM conference on expander graphs, Terry Tao presented Bruce Kleiner’s new proof of Gromov’s theorem. After the talk, Luca Trevisan asked whether there exists an analog of certain steps in the proof […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-32781")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2008")])]

#text("Dear Terry,")

#text("Sorry for this probably very stupid question,")#linebreak()#text(" but how do you define the gradient of f if it is a function from a graph (the Cayley graph) to the reals?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-32783")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2008")])]

#text("Dear student,")

#text("I define the gradient ")#mi("\\nabla f")#text(" (or more precisely, the magnitude squared ")#tao-math("\\left|\\nabla f\\right|^2", block: false)#text(") in the second display after Proposition 2. One could take the gradient to be the |S|-dimensional (H-valued) vector with components ")#mi("f(gs)-f(g)")#text(" for ")#mi("g \\in S")#text(", after normalising the norm of this vector space by ")#mi("1/\\sqrt{S}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f28160957b85b0b795af77e6dea6c99888f1d0e8b76b2b910249f77ebfc73a-0d11cc1252eba8719ed1bf3fb7b049debc2373b2e5a9579cd4cd35dd252d751d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Heilman")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-36326")[#strong[#text("Steven Heilman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Concerning the existence of Harnack Inequalities in this setting (i.e. groups of polynomial growth): they do actually exist. The modern procedure of proof is fairly abstract, as in say, the proof of Birkhoff’s Ergodic Theorem via the Maximal Lemma. Moderate technicalities aside, the result basically holds in any setting with a specific Poincare inequality and volume doubling. For the theorem, see:")

#text("Theorem VIII.3.6 of “Analysis and Geometry on Groups”, by Varopolous et al.")

#text("Also, a good survey of these kinds of results is:")

#text("“Sobolev Inequalities in Familiar and Unfamiliar Settings” by L. Saloff-Coste, in “Sobolev Spaces in Mathematics I” by V. Maz’ya, 2008.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Gromov wins 2009 Abel prize « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-37508")[#strong[#text("Mikhail Gromov wins 2009 Abel prize « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] The prize is, of course, richly deserved. I have mentioned some of Gromov’s work here on this blog; for instance, the Bishop-Gromov inequality in Riemannian geometry (which (together with its parabolic variant, the monotonicity of Perelman reduced volume) plays an important role in Perelman’s proof of the Poincaré conjecture), the concept of Gromov-Hausdorff convergence (a version of which is also key in the proof of the Poincaré conjecture), and Gromov’s celebrated theorem on groups of polynomial growth, which I discussed in this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A finitary version of Gromov’s polynomial growth theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-41989")[#strong[#text("A finitary version of Gromov’s polynomial growth theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("[…] hypothesis to requiring (1) just for infinitely many scales ; the later proof by Kleiner (which I blogged about here) also has this relaxed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A proof of Gromov’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-43664")[#strong[#text("A proof of Gromov’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2010")])]

#text("[…] The original proof of Gromov’s theorem was quite non-elementary, using an infinitary limit and exploiting the work surrounding the solution to Hilbert’s fifth problem. More recently, Kleiner provided a proof which was more elementary (based in large part on an earlier paper of Colding and Minicozzi), though still not entirely so, relying in part on (a weak form of the) Tits alternative and also on an ultrafilter argument of Korevaar-Schoen and Mok. I discuss Kleiner’s argument more in this previous blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-49768")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] role in Gromov’s proof of his theorem on groups of polynomial growth (discussed previously on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Planar rooted trees and Baker-Campbell-Hausdorff formula | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-54185")[#strong[#text("Planar rooted trees and Baker-Campbell-Hausdorff formula | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2011")])]

#text("[…] paper may be relevant (check also the bibliography!) for the subject of writing “finitary“, “noncommutative” BCH formulae, from self-similarity arguments using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/#comment-70864")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] and Minicozzi on harmonic functions of polynomial growth. (This latter proof is discussed in these previous blog posts.) The proof we will give in these notes is more recent, based on an . We remark […]")
]
