// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/
// Converted to Typst by tao2typ: "2026-10-21T12:07:37.268692+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Upcoming workshop on “Machine assisted proofs” at IPAM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Upcoming workshop on “Machine assisted proofs” at IPAM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/")[#text("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-21 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post to advertise the workshop “")#link("https://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/")[#text("Machine assisted proofs")]#text("” that will be held on Feb 13-17 next year, here at the ")#link("http://www.ipam.ucla.edu/")[#text("Institute for Pure and Applied Mathematics")]#text(" (IPAM); I am one of the organizers of this event together with ")#link("https://ths.rwth-aachen.de/people/erika-abraham/")[#text("Erika Abraham")]#text(", ")#link("https://www.andrew.cmu.edu/user/avigad/")[#text("Jeremy Avigad")]#text(", ")#link("https://www.imperial.ac.uk/people/k.buzzard")[#text("Kevin Buzzard")]#text(", ")#link("https://people.math.wisc.edu/~ellenber/")[#text("Jordan Ellenberg")]#text(", ")#link("https://www.dpmms.cam.ac.uk/~wtg10/")[#text("Tim Gowers")]#text(", and ")#link("https://www.cs.cmu.edu/~mheule/")[#text("Marijn Heule")]#text(". The purpose of this event is to bring together experts in the various types of formal computer-assisted methods used to verify, discover, or otherwise assist with mathematical proofs, as well as pure mathematicians who are interested in learning about the current and future state of the art with such tools; this seems to be an opportune time to bring these communities together, given some recent high-profile applications of formal methods in pure mathematics (e.g, the ")#link("https://leanprover-community.github.io/blog/posts/lte-final/")[#text("liquid tensor experiment")]#text("). The workshop will consist of a number of lectures from both communities, as well as a panel to discuss future directions. The workshop is open to general participants (both in person and remotely), although there is a registration process and a moderate registration fee to cover costs and to restrict the capacity to genuine applicants.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659312")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2022")])]

#text("The formalization process should be able to detect all the gaps and errors in a claimed proof, and also may help to settle controversies about claimed proofs of important conjectures (e.g. Mochizuki claimed proof of the ABC conjecture)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6f5bd8c6e653ab0656d64dd606ac3c8b4712997cb635892cda012355f8e7752-a62f7c34973bc0fe96b4d37e737012d3d31ac075788e80d9fbb35d4e2df5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659313")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2022")])]

#text("I do not think that formalization will help to settle controversies that are mostly social, as opposed to disagreement on technical matters. As a thought experiment, suppose a team of formalizers works hard on Mochizuki’s IUTT and gets stuck at the point where plenty other prominent mathematicians got stuck. What will happen? The most likely scenario will be that IUTT-proponents will say: “The proof is nevertheless correct, the formalizers don’t know what they are doing, and they should simply try harder.”")#linebreak()#text(" I do not expect that the IUTT camp will suddenly make large efforts to actually explain the proof in detail to people who are genuinely making an effort to understand IUTT. They have had plenty of opportunities to give such explanations, but they don’t seem to want to do that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d9925a2efe2d29b50d0ffb98a49d151a8e04976e82d1b78091024befc58e6f2-4eb7202fdb03571bc633170ec96b9955a57728d4b1b01b069ecc889f6bc6e20d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659325")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("This is only the case if the people claiming to have a proof are not the ones responsible for its formalization.")

#text("With a pen and paper proof you can always argue that it’s possible to provide better exposition, or that the verifier is doing some kind of mistake, so there’s no objective standard for what constitutes a complete proof.")

#text("With proof assistants we can consider controversial results false until they’re formalized. It wouldn’t be possible to argue that no amount of exposition could convince the verifier without admitting that the argument does not work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6f5bd8c6e653ab0656d64dd606ac3c8b4712997cb635892cda012355f8e7752-a62f7c34973bc0fe96b4d37e737012d3d31ac075788e80d9fbb35d4e2df5e271.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659328")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("That’s certainly true. You make a valid point. But I don’t think there will be a mathematical culture that requires formalizations of controversial results in the near future. Maybe a few decades from now, but not within 10 years. Of course that’s just my gut feeling.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-660154")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2022")])]

#text("There will be a mathematical culture to formalize the truly important results, just like there has been a culture to reprove important results using different methods such as elementary ones (PNT) or pure analytic ones (FTA).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659338")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("You say “both communities” in your post. Which two are you referring to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659420")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("The formalization community (e.g. proof assistant software developers), and pure mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b76255ac541d2c3494f7e10206d68648ff46ceacf67d4138ffda6b0eff88b923-b403292d9861c5e4e2d6075fe717a7778b2690178a6251f56d0792b0ef6f5224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2022")])]

#text("I just realized there is an unpublished Hilbert’s 24th problem")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")[#text("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")]#linebreak()#text(" with reference to work of Thiele and Larry Wos which seem relevant to the theme of the workshop ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659390")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("Will there be any kind of proceedings published, or online videos of the talks, or anything like that? I’m nowhere near clueful enough to contribute anything as a participant, but am interested enough in the topic to want to find out what happens. There are probably a lot of us out here in that situation. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659396")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("A recent article on some aspects of machine assisted proof is ")#link("https://arxiv.org/pdf/2207.04779.pdf")[#text("https://arxiv.org/pdf/2207.04779.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4451b5da3576dbeaed628fe9bf3a4d5054e19ff842d4b26067bc62bef8c6f8-2fc6258fd3fd6a216a860baf8b5c08b47abda4d0aabef42b1a2f49cafa97427e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balasubramanian Narasimhan")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659391")[#strong[#text("Balasubramanian Narasimhan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("Just a note to point out that the flyer has the wrong year in the date: February 13-17, 2022!")

#emph[#text("[I believe this is now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc99c2e1283475c3bb842cc9a672890d5cf2be494ffc21f598d9a8a87972702e-b6e1177a2447cdb85f1460579e58ae08e7b364fdb65d151460a14793ee10cd97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sourav")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659427")[#strong[#text("Sourav")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2022")])]

#text("Will the abstract of the talks be made public before the programme? This may be helpful for those on the fence about registering.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659433")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2022")])]

#text("Pretty sure the presentations will be on Youtube afterwards.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659614")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2022")])]

#text("Dear Prof. Tao, with the registration would it be possible to see the recordings asynchronously (I would be open to register and pay the fee, but I highly doubt I could take part in real time). Best regards, g.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6412120906906edce2cf3a7b8a556e59aa4285f6e4fd1564c62a598e0bd73d5d-4dc738d5d0759a6e32d8ccf68a5eea5f6f3fa0abb5caeab508a63711a9196e62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659730")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2022")])]

#text("First of all, thank you for this contribution to formal mathematics and computer-assisted proofs. This is a very important and relevant topic. I am genuinely curious how you look at the following situation.")

#text("I recently proved the following theorem in the theory of directed graphs: existence of a kernel implies the existence of a small quasi-kernel in a source-free directed graph (“small” meaning not greater than half of the number of vertices). The proof is here:")

#link("https://arxiv.org/abs/2110.00789")[#text("https://arxiv.org/abs/2110.00789")]

#text("I also verified this proof in Coq, just as an additional layer of verification. I then wrote the article in such a way that it resembled the Coq-proof by: (1) writing everything down in a very detailed way, and, (2) referring to the corresponding lemmas in the Coq-proof. This was a bit of an experiment (I was not affiliated with any institution at that point in time, so I had very little to lose).")

#text("This paper was rejected by the Electronic Journal in Combinatorics because its style does not “conform to the standards of EJ-C” (per the reviewers) and the Australasian Journal in Combinatorics rejected with similar feedback, after which I gave up and started working on other problems.")

#text("My main question at this point: do journals need to re-think what constitutes a ‘good’ proof in the age of formal verification? Or do we researchers need to think of better strategies to get machine-assisted proofs accepted by the wider community? Or perhaps both? Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9b49bd33424d18e6fd82ca38f626672754c103c2d7c231ec33aef6c10f79d04-9d0d6c116c8bfa69fdbb98f0e894459bf3db0b5e802996a68170378f24681fd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659810")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2022")])]

#text("These are interesting questions and one I hope they get aired at the workshop.")

#text("To me the answer to the second is a combination of controlled natural language, CNL for short, and a TeX-like formal syntax for equations, etc. The combination would be both verifiable and human readable.")

#text("See this blog article by Thomas Hales, which overall I heartily agree with:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://jiggerwit.wordpress.com/2019/06/20/an-argument-for-controlled-natural-languages-in-mathematics/")[#text("An Argument for Controlled Natural Languages in Mathematics")]
]

#text("From my time in academia I recall that there were plenty of journals that accepted formal papers, indeed there was talk of some journals getting to the stage where they accepted nothing else. So you should not give up hope of getting your results published.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40ad07086cce8b042d4edd5c92b2d11171de5d57666f6770e8fef88df0b7b99d-e17accb35bad190359a2e1a21bfcf2223fadb38c15a883383273a82039866364.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-659947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")])]

#text("As you probably know, Chen and Hou recently verified the Hou-Luo blowup scenario for 3D Euler with boundary using a computer assisted proof:")

#link("https://arxiv.org/abs/2210.07191")[#text("https://arxiv.org/abs/2210.07191")]

#text("If you are still planning speakers you may want to invite one of them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-660098")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2022")])]

#text("I do not need a machine in order to prove that Tao is a moron. This is pretty obvious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/701256c957543176923f1d1b23aabc97ae6cc09bedb105f4a985919f9510893c-efc8205322df6beb0a1b3dcf9fe0f7b7b7cfe5c16a43874cd62f90e773f68078.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-669521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2022")])]

#text("Maybe by the standards of genetically engineered cyborgs in 2200, but by the standards of modern humans he is pretty smart, and is a reasonable candidate for the smartest human alive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-673014")[#strong[#text("Upcoming workshop on “Machine assisted proofs” at IPAM – rosdahal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")]

#text("[…] Upcoming workshop on “Machine assisted proofs” at IPAM […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AI to Assist Mathematical Reasoning: A Workshop | What's new")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-678387")[#strong[#text("AI to Assist Mathematical Reasoning: A Workshop | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("[…] Michelle Schwalbe. There is some thematic overlap (and a few speakers in common) with the recent IPAM program on machine assisted proof, though with more of a focus on the current and projected technical capabilities of machine […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04f1c1a535b96f815160e3206f6badc752c7fc81b064376e646fd448e663a32f-8442cb7d905ef4a04200bfc9328343c62d6a5147c1e8ffba138ce88ce741b3f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/comment-page-1/#comment-678474")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("I hope recordings will be made available.")

#emph[#text("[Recordings may be found at ")#link("http://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/?tab=schedule")[#text("http://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/?tab=schedule")]#text(" – T.]")]
]
