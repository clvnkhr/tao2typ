// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/
// Converted to Typst by tao2typ: "2026-10-14T15:20:48.883414+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Upcoming workshop on “Machine assisted proofs” at IPAM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Upcoming workshop on “Machine assisted proofs” at IPAM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/")[#text("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Just a short post to advertise the workshop “")#link("https://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/")[#text("Machine assisted proofs")]#text("” that will be held on Feb 13-17 next year, here at the ")#link("http://www.ipam.ucla.edu/")[#text("Institute for Pure and Applied Mathematics")]#text(" (IPAM); I am one of the organizers of this event together with ")#link("https://ths.rwth-aachen.de/people/erika-abraham/")[#text("Erika Abraham")]#text(", ")#link("https://www.andrew.cmu.edu/user/avigad/")[#text("Jeremy Avigad")]#text(", ")#link("https://www.imperial.ac.uk/people/k.buzzard")[#text("Kevin Buzzard")]#text(", ")#link("https://people.math.wisc.edu/~ellenber/")[#text("Jordan Ellenberg")]#text(", ")#link("https://www.dpmms.cam.ac.uk/~wtg10/")[#text("Tim Gowers")]#text(", and ")#link("https://www.cs.cmu.edu/~mheule/")[#text("Marijn Heule")]#text(". The purpose of this event is to bring together experts in the various types of formal computer-assisted methods used to verify, discover, or otherwise assist with mathematical proofs, as well as pure mathematicians who are interested in learning about the current and future state of the art with such tools; this seems to be an opportune time to bring these communities together, given some recent high-profile applications of formal methods in pure mathematics (e.g, the ")#link("https://leanprover-community.github.io/blog/posts/lte-final/")[#text("liquid tensor experiment")]#text("). The workshop will consist of a number of lectures from both communities, as well as a panel to discuss future directions. The workshop is open to general participants (both in person and remotely), although there is a registration process and a moderate registration fee to cover costs and to restrict the capacity to genuine applicants.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2022")])]

#text("The formalization process should be able to detect all the gaps and errors in a claimed proof, and also may help to settle controversies about claimed proofs of important conjectures (e.g. Mochizuki claimed proof of the ABC conjecture)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d1a193d20465ba6e3531775d52deab7485eb13b67bdc8bde2ada397a4d77e69-a0b875f5d44f314f34a9847570bbe5a71beb37ac0babf62cedf5f411270e23cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659313")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2022")])]

#text("I do not think that formalization will help to settle controversies that are mostly social, as opposed to disagreement on technical matters. As a thought experiment, suppose a team of formalizers works hard on Mochizuki’s IUTT and gets stuck at the point where plenty other prominent mathematicians got stuck. What will happen? The most likely scenario will be that IUTT-proponents will say: “The proof is nevertheless correct, the formalizers don’t know what they are doing, and they should simply try harder.”")#linebreak()#text(" I do not expect that the IUTT camp will suddenly make large efforts to actually explain the proof in detail to people who are genuinely making an effort to understand IUTT. They have had plenty of opportunities to give such explanations, but they don’t seem to want to do that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62e8b8d67c132d3ec283ca9d0363f4ac99f847bfc686933cdd06e537eb5c551b-f9dd435147bc7e35d29afa26a6f1ef6c8f54d35076882aec59e91ed8e9d1adb8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("This is only the case if the people claiming to have a proof are not the ones responsible for its formalization.")

#text("With a pen and paper proof you can always argue that it’s possible to provide better exposition, or that the verifier is doing some kind of mistake, so there’s no objective standard for what constitutes a complete proof.")

#text("With proof assistants we can consider controversial results false until they’re formalized. It wouldn’t be possible to argue that no amount of exposition could convince the verifier without admitting that the argument does not work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d1a193d20465ba6e3531775d52deab7485eb13b67bdc8bde2ada397a4d77e69-a0b875f5d44f314f34a9847570bbe5a71beb37ac0babf62cedf5f411270e23cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659328")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("That’s certainly true. You make a valid point. But I don’t think there will be a mathematical culture that requires formalizations of controversial results in the near future. Maybe a few decades from now, but not within 10 years. Of course that’s just my gut feeling.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-660154")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2022")])]

#text("There will be a mathematical culture to formalize the truly important results, just like there has been a culture to reprove important results using different methods such as elementary ones (PNT) or pure analytic ones (FTA).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2022")])]

#text("You say “both communities” in your post. Which two are you referring to?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("The formalization community (e.g. proof assistant software developers), and pure mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3276e20f81c41be100b60014a05f509ffba4a6efe962f38e3b84e36b57432be1-f852860ad680f4a97470ce72ec682306ab2f0cb2fa52b7cf73afc8f7378eb9fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2022")])]

#text("I just realized there is an unpublished Hilbert’s 24th problem")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")[#text("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")]#linebreak()#text(" with reference to work of Thiele and Larry Wos which seem relevant to the theme of the workshop ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("Will there be any kind of proceedings published, or online videos of the talks, or anything like that? I’m nowhere near clueful enough to contribute anything as a participant, but am interested enough in the topic to want to find out what happens. There are probably a lot of us out here in that situation. Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659396")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("A recent article on some aspects of machine assisted proof is ")#link("https://arxiv.org/pdf/2207.04779.pdf")[#text("https://arxiv.org/pdf/2207.04779.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a74667609e40d6051cb172b6dda4f29097f2908457cd005baaea11b77f383bd1-9e3a68cedf88f657b4e3286de7a7e363fffbfb1bbf1ab9cd3a5ed75aa4e56ad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balasubramanian Narasimhan")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659391")[#strong[#text("Balasubramanian Narasimhan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2022")])]

#text("Just a note to point out that the flyer has the wrong year in the date: February 13-17, 2022!")

#emph[#text("[I believe this is now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1345c84b5c168588eca123ce234c242ba8759fac1aa4a2808b02989612ca1e61-0d2cdb6cb73b4f0f7d6dc1e9b21f92f1921927b0e05bce80546cbb7b3fa3f781.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sourav")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659427")[#strong[#text("Sourav")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2022")])]

#text("Will the abstract of the talks be made public before the programme? This may be helpful for those on the fence about registering.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2022")])]

#text("Pretty sure the presentations will be on Youtube afterwards.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2022")])]

#text("Dear Prof. Tao, with the registration would it be possible to see the recordings asynchronously (I would be open to register and pay the fee, but I highly doubt I could take part in real time). Best regards, g.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659730")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2022")])]

#text("First of all, thank you for this contribution to formal mathematics and computer-assisted proofs. This is a very important and relevant topic. I am genuinely curious how you look at the following situation.")

#text("I recently proved the following theorem in the theory of directed graphs: existence of a kernel implies the existence of a small quasi-kernel in a source-free directed graph (“small” meaning not greater than half of the number of vertices). The proof is here:")

#link("https://arxiv.org/abs/2110.00789")[#text("https://arxiv.org/abs/2110.00789")]

#text("I also verified this proof in Coq, just as an additional layer of verification. I then wrote the article in such a way that it resembled the Coq-proof by: (1) writing everything down in a very detailed way, and, (2) referring to the corresponding lemmas in the Coq-proof. This was a bit of an experiment (I was not affiliated with any institution at that point in time, so I had very little to lose).")

#text("This paper was rejected by the Electronic Journal in Combinatorics because its style does not “conform to the standards of EJ-C” (per the reviewers) and the Australasian Journal in Combinatorics rejected with similar feedback, after which I gave up and started working on other problems.")

#text("My main question at this point: do journals need to re-think what constitutes a ‘good’ proof in the age of formal verification? Or do we researchers need to think of better strategies to get machine-assisted proofs accepted by the wider community? Or perhaps both? Thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcc8dd35fd3341bd1f47d9472063440b46e7b5f3ab73ea865fb54e45ee88722f-bb4be7f57e927f772a1e062ffc44ee78703e605f4e8c811c8e97971d91ad5d36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659810")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2022")])]

#text("These are interesting questions and one I hope they get aired at the workshop.")

#text("To me the answer to the second is a combination of controlled natural language, CNL for short, and a TeX-like formal syntax for equations, etc. The combination would be both verifiable and human readable.")

#text("See this blog article by Thomas Hales, which overall I heartily agree with:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://jiggerwit.wordpress.com/2019/06/20/an-argument-for-controlled-natural-languages-in-mathematics/")[#text("An Argument for Controlled Natural Languages in Mathematics")]
]

#text("From my time in academia I recall that there were plenty of journals that accepted formal papers, indeed there was talk of some journals getting to the stage where they accepted nothing else. So you should not give up hope of getting your results published.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80186b23ecd7183baf3997fea0be9728242b29992242075d680bd57d5ecaf5e-c01d0095c1e1fd68ce186085beae7f7aa8012003d8a49df53762ddeb97b4ffff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-659947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2022")])]

#text("As you probably know, Chen and Hou recently verified the Hou-Luo blowup scenario for 3D Euler with boundary using a computer assisted proof:")

#link("https://arxiv.org/abs/2210.07191")[#text("https://arxiv.org/abs/2210.07191")]

#text("If you are still planning speakers you may want to invite one of them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-660098")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2022")])]

#text("I do not need a machine in order to prove that Tao is a moron. This is pretty obvious.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17c35e097624a672c243915dc3ce92ff0009fdeaf2a3d3b3ca14c96b91398b5b-00689193ca2f68c6ef001b525e243d2d7813a4f99c662ea7e782a3a311d79a6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-669521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2022")])]

#text("Maybe by the standards of genetically engineered cyborgs in 2200, but by the standards of modern humans he is pretty smart, and is a reasonable candidate for the smartest human alive.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-673014")[#strong[#text("Upcoming workshop on “Machine assisted proofs” at IPAM – rosdahal")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2023")]

#text("[…] Upcoming workshop on “Machine assisted proofs” at IPAM […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AI to Assist Mathematical Reasoning: A Workshop | What's new")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-678387")[#strong[#text("AI to Assist Mathematical Reasoning: A Workshop | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2023")])]

#text("[…] Michelle Schwalbe. There is some thematic overlap (and a few speakers in common) with the recent IPAM program on machine assisted proof, though with more of a focus on the current and projected technical capabilities of machine […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48cd89a484305c96fd83e4d56837e9077cdceeb21998b7ee484aa398b55e28d6-1608fbe5f166f7ce9d143c84e0e360451bdfe1ffb30fff0d46023d021ec21880.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2022/10/21/upcoming-workshop-on-machine-assisted-proofs-at-ipam/#comment-678474")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("I hope recordings will be made available.")

#emph[#text("[Recordings may be found at ")#link("http://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/?tab=schedule")[#text("http://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/?tab=schedule")]#text(" – T.]")]
]
