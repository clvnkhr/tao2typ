// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:38:12.241400+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Odd order cases of the logarithmically averaged Chowla conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Odd order cases of the logarithmically averaged Chowla conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")[#text("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.utu.fi/en/units/sci/units/math/staff/Pages/jopete.aspx")[#text("Joni Teräväinen")]#text(" and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/1710.02112")[#text("Odd order cases of the logarithmically averaged Chowla conjecture")]#text("“, submitted to ")#link("https://jtnb.math.u-bordeaux.fr/")[#text("J. Numb. Thy. Bordeaux")]#text(". This paper gives an alternate route to one of the main results of ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("our previous paper")]#text(", and more specifically reproves the asymptotic ")#metadata(none) <tao-ec005930dcb5b5eaa6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\frac{\\lambda(n+h_1) \\dots \\lambda(n+h_k)}{n} = o(\\log x)")]]



#text(" for all odd ")#mi("{k}")#text(" and all integers ")#mi("{h_1,\\dots,h_k}")#text(" (that is to say, all the odd order cases of the logarithmically averaged Chowla conjecture). Our previous argument relies heavily on some deep ergodic theory results of ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("Bergelson-Host-Kra")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=3294297")[#text("Leibman")]#text(", and ")#link("https://arxiv.org/abs/1708.01361")[#text("Le")]#text(" (and was applicable to more general multiplicative functions than the Liouville function ")#mi("{\\lambda}")#text("); here we give a shorter proof that avoids ergodic theory (but instead requires the Gowers uniformity of the (W-tricked) von Mangoldt function, established in ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("several")]#text(" ")#link("https://terrytao.wordpress.com/2008/07/13/the-mobius-and-nilsequences-conjecture/")[#text("papers")]#text(" ")#link("https://terrytao.wordpress.com/2010/09/21/an-inverse-theorem-for-the-gowers-us1n-norm/")[#text("of")]#text(" Ben Green, Tamar Ziegler, and myself). The proof follows the lines sketched in the ")#link("https://terrytao.wordpress.com/2017/08/09/the-structure-of-logarithmically-averaged-correlations-of-multiplicative-functions-with-applications-to-the-chowla-and-elliott-conjectures/")[#text("previous blog post")]#text(". In principle, due to the avoidance of ergodic theory, the arguments here have a greater chance to be made quantitative; however, at present the known bounds on the Gowers uniformity of the von Mangoldt function are qualitative, except at the ")#mi("{U^2}")#text(" level, which is unfortunate since the first non-trivial odd case ")#mi("{k=3}")#text(" requires quantitative control on the ")#mi("{U^3}")#text(" level. (But it may be possible to make the Gowers uniformity bounds for ")#mi("{U^3}")#text(" quantitative if one assumes GRH, although when one puts everything together, the actual decay rate obtained in ")#link(<tao-ec005930dcb5b5eaa6f0>)[#text("(1)")]#text(" is likely to be poor.)")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/#comment-487046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2017")])]

#text("If the shifts ")#mi("h_1, ... ,h_k")#text(" are consecutive and their number ")#mi("k")#text(" is allowed to grow (sufficiently slowly) with x, is it possible to improve the RHS of (1) by using also the Erdos-Kac theorem?")

#emph[#text("[I do not see a way to utilise the Erdos-Kac theorem for this purpose. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1936fc82c063643159fb6cd988f2dc8acb109ba5912c2cb923309ab4ee9c3274-f47fb36a6f934cdda1ead2f543239b33d2deaab686a3eeff7e8d73f4bcb34c31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MZW")]], [#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/#comment-487066")[#strong[#text("MZW")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2017")])]

#text("Small typo in the quoted title of the arXiv paper (2 “of”s)")

#emph[#text("[Corrected, thanks – T.")]#text("]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/#comment-487854")[#strong[#text("The logarithmically averaged and non-logarithmically averaged Chowla conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2017")])]

#text("[…] “>this previous blog post). And indeed, significantly more is now known for the logarithmically averaged Chowla conjecture; in this paper of mine I had proven (2) for , and in this recent paper with Joni Teravainen, we proved the conjecture for all odd (with a different proof also given here). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/#comment-508358")[#strong[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("[…] particular bound also follows from some slightly different arguments of Joni Teravainen and myself, but the implication would also work for other non-pretentious bounded multiplicative functions, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Value patterns of multiplicative functions and related sequences | What's new")]], [#link("https://terrytao.wordpress.com/2017/10/07/odd-order-cases-of-of-the-logarithmically-averaged-chowla-conjecture/#comment-514800")[#strong[#text("Value patterns of multiplicative functions and related sequences | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("[…] in that case it is even known that all sign patterns occur with equal logarithmic density (from this paper of myself and Teräväinen), but these techniques barely fail to handle the case by itself (largely because the […]")
]
