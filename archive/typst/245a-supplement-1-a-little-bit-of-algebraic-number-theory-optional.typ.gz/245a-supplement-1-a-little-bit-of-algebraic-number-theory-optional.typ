// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/
// Converted to Typst by tao2typ: "2026-10-14T15:19:15.067862+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 1: A little bit of algebraic number theory (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 1: A little bit of algebraic number theory (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Analytic number theory is only one of many different approaches to number theory. Another important branch of the subject is ")#link("http://en.wikipedia.org/wiki/Algebraic_number_theory")[#text("algebraic number theory")]#text(", which studies algebraic structures (e.g. groups, rings, and fields) of number-theoretic interest. With this perspective, the classical field of rationals ")#mi("{{\\bf Q}}")#text(", and the classical ring of integers ")#mi("{{\\bf Z}}")#text(", are placed inside the much larger field ")#mi("{\\overline{{\\bf Q}}}")#text(" of ")#link("http://en.wikipedia.org/wiki/Algebraic_number")[#text("algebraic numbers")]#text(", and the much larger ring ")#mi("{{\\mathcal A}}")#text(" of ")#link("http://en.wikipedia.org/wiki/Algebraic_integer")[#text("algebraic integers")]#text(", respectively. Recall that an algebraic number is a root of a polynomial with integer coefficients, and an algebraic integer is a root of a ")#link("http://en.wikipedia.org/wiki/Monic_polynomial")[#text("monic")]#text(" polynomial with integer coefficients; thus for instance ")#mi("{\\sqrt{2}}")#text(" is an algebraic integer (a root of ")#mi("{x^2-2}")#text("), while ")#mi("{\\sqrt{2}/2}")#text(" is merely an algebraic number (a root of ")#mi("{4x^2-2}")#text("). For the purposes of this post, we will adopt the concrete (but somewhat artificial) perspective of viewing algebraic numbers and integers as lying inside the complex numbers ")#mi("{{\\bf C}}")#text(", thus ")#mi("{{\\mathcal A} \\subset \\overline{{\\bf Q}} \\subset {\\bf C}}")#text(". (From a modern algebraic perspective, it is better to think of ")#mi("{\\overline{{\\bf Q}}}")#text(" as existing as an abstract field separate from ")#mi("{{\\bf C}}")#text(", but which has a number of embeddings into ")#mi("{{\\bf C}}")#text(" (as well as into other fields, such as the completed ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("p-adics")]#text(" ")#mi("{{\\bf C}_p}")#text("), no one of which should be considered favoured over any other; cf. ")#link("http://mathoverflow.net/a/3685/766")[#text("this mathOverflow post")]#text(". But for the rudimentary algebraic number theory in this post, we will not need to work at this level of abstraction.) In particular, we identify the algebraic integer ")#mi("{\\sqrt{-d}}")#text(" with the complex number ")#mi("{\\sqrt{d} i}")#text(" for any natural number ")#mi("{d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that the field of algebraic numbers ")#mi("{\\overline{{\\bf Q}}}")#text(" is indeed a ")#link("http://en.wikipedia.org/wiki/Field_(mathematics)")[#text("field")]#text(", and that the ring of algebraic integers ")#mi("{{\\mathcal A}}")#text(" is indeed a ")#link("http://en.wikipedia.org/wiki/Ring_(mathematics)")[#text("ring")]#text(", and is in fact an ")#link("http://en.wikipedia.org/wiki/Integral_domain")[#text("integral domain")]#text(". Also, show that ")#mi("{{\\bf Z} = {\\mathcal A} \\cap {\\bf Q}}")#text(", that is to say the ordinary integers are precisely the algebraic integers that are also rational. Because of this, we will sometimes refer to elements of ")#mi("{{\\bf Z}}")#text(" as ")#emph[#text("rational integers")]#text(".")
]

#text("In practice, the field ")#mi("{\\overline{{\\bf Q}}}")#text(" is too big to conveniently work with directly, having infinite dimension (as a vector space) over ")#mi("{{\\bf Q}}")#text(". Thus, algebraic number theory generally restricts attention to intermediate fields ")#mi("{{\\bf Q} \\subset F \\subset \\overline{{\\bf Q}}}")#text(" between ")#mi("{{\\bf Q}}")#text(" and ")#mi("{\\overline{{\\bf Q}}}")#text(", which are of finite dimension over ")#mi("{{\\bf Q}}")#text("; that is to say, ")#link("http://en.wikipedia.org/wiki/Degree_of_a_field_extension")[#text("finite degree extensions")]#text(" of ")#mi("{{\\bf Q}}")#text(". Such fields are known as ")#link("http://en.wikipedia.org/wiki/Algebraic_number_field")[#text("algebraic number fields")]#text(", or ")#emph[#text("number fields")]#text(" for short. Apart from ")#mi("{{\\bf Q}}")#text(" itself, the simplest examples of such number fields are the ")#link("http://en.wikipedia.org/wiki/Quadratic_field")[#text("quadratic fields")]#text(", which have dimension exactly two over ")#mi("{{\\bf Q}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that if ")#mi("{\\alpha}")#text(" is a rational number that is not a perfect square, then the field ")#mi("{{\\bf Q}(\\sqrt{\\alpha})}")#text(" generated by ")#mi("{{\\bf Q}}")#text(" and either of the square roots of ")#mi("{\\alpha}")#text(" is a quadratic field. Conversely, show that all quadratic fields arise in this fashion. (")#emph[#text("Hint:")]#text(" show that every element of a quadratic field is a root of a quadratic polynomial over the rationals.)")
]

#text("The ring of algebraic integers ")#mi("{{\\mathcal A}}")#text(" is similarly too large to conveniently work with directly, so in algebraic number theory one usually works with the rings ")#mi("{{\\mathcal O}_F := {\\mathcal A} \\cap F}")#text(" of algebraic integers inside a given number field ")#mi("{F}")#text(". One can (and does) study this situation in great generality, but for the purposes of this post we shall restrict attention to a simple but illustrative special case, namely the quadratic fields with a certain type of negative discriminant. (The positive discriminant case will be briefly discussed in Remark ")#link(<tao-0531a5a9dfcab00993f8>)[#text("42")]#text(" below.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{d}")#text(" be a square-free natural number with ")#mi("{d=1\\ (4)}")#text(" or ")#mi("{d=2\\ (4)}")#text(". Show that the ring ")#mi("{{\\mathcal O} = {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" of algebraic integers in ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("{\\mathcal O} = {\\bf Z}[\\sqrt{-d}] = \\{ a + b \\sqrt{-d}: a,b \\in {\\bf Z} \\}.")]]

#text("If instead ")#mi("{d}")#text(" is square-free with ")#mi("{d=3\\ (4)}")#text(", show that the ring ")#mi("{{\\mathcal O} = {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" is instead given by")

#align(center)[#tao-fit-display[#mitex("{\\mathcal O} = {\\bf Z}[\\frac{1+\\sqrt{-d}}{2}] = \\{ a + b \\frac{1+\\sqrt{-d}}{2}: a,b \\in {\\bf Z} \\}.")]]

#text("What happens if ")#mi("{d}")#text(" is not square-free, or negative?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" ")#metadata(none) <tao-4ff0977a56f7bf635689>#text(" In the case ")#mi("{d=3\\ (4)}")#text(", it may naively appear more natural to work with the ring ")#mi("{{\\bf Z}[\\sqrt{-d}]}")#text(", which is an index two subring of ")#mi("{{\\mathcal O}}")#text(". However, because this ring only captures some of the algebraic integers in ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(" rather than all of them, the algebraic properties of these rings are somewhat worse than those of ")#mi("{{\\mathcal O}}")#text(" (in particular, they generally fail to be ")#link("http://en.wikipedia.org/wiki/Dedekind_domain")[#text("Dedekind domains")]#text(") and so are not convenient to work with in algebraic number theory.")
]

#text("We refer to fields of the form ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(" for natural square-free numbers ")#mi("{d}")#text(" as ")#emph[#text("quadratic fields of negative discriminant")]#text(", and similarly refer to ")#mi("{{\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" as a ring of ")#link("http://en.wikipedia.org/wiki/Quadratic_integer")[#text("quadratic integers")]#text(" of negative discriminant. Quadratic fields and quadratic integers of positive discriminant are just as important to analytic number theory as their negative discriminant counterparts, but we will restrict attention to the latter here for simplicity of discussion.")#linebreak()#text(" Thus, for instance, when ")#mi("{d=1}")#text(", the ring of integers in ")#mi("{{\\bf Q}(\\sqrt{-1})}")#text(" is the ring of ")#link("http://en.wikipedia.org/wiki/Gaussian_integer")[#text("Gaussian integers")]

#align(center)[#tao-fit-display[#mitex("{\\bf Z}[\\sqrt{-1}] = \\{ x + y \\sqrt{-1}: x,y \\in {\\bf Z} \\}")]]

#text("and when ")#mi("{d=3}")#text(", the ring of integers in ")#mi("{{\\bf Q}(\\sqrt{-3})}")#text(" is the ring of ")#link("http://en.wikipedia.org/wiki/Eisenstein_integer")[#text("Eisenstein integers")]

#align(center)[#tao-fit-display[#mitex("{\\bf Z}[\\omega] := \\{ x + y \\omega: x,y \\in {\\bf Z} \\}")]]

#text("where ")#mi("{\\omega := e^{2\\pi i /3}}")#text(" is a cube root of unity.")#linebreak()#text(" As these examples illustrate, the additive structure of a ring ")#mi("{{\\mathcal O} = {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" of quadratic integers is that of a two-dimensional lattice in ")#mi("{{\\bf C}}")#text(", which is isomorphic as an additive group to ")#mi("{{\\bf Z}^2}")#text(". Thus, from an additive viewpoint, one can view quadratic integers as “two-dimensional” analogues of rational integers. From a ")#emph[#text("multiplicative")]#text(" viewpoint, however, the quadratic integers (and more generally, integers in a number field) behave very similarly to the rational integers (as opposed to being some sort of “higher-dimensional” version of such integers). Indeed, a large part of basic algebraic number theory is devoted to treating the multiplicative theory of integers in number fields in a unified fashion, that naturally generalises the classical multiplicative theory of the rational integers.")#linebreak()#text(" For instance, every rational integer ")#mi("{n \\in {\\bf Z}}")#text(" has an absolute value ")#tao-math("{\\left|n\\right| \\in {\\bf N} \\cup \\{0\\}}", block: false)#text(", with the multiplicativity property ")#tao-math("{\\left|nm\\right| = \\left|n\\right| \\left|m\\right|}", block: false)#text(" for ")#mi("{n,m \\in {\\bf Z}}")#text(", and the positivity property ")#tao-math("{\\left|n\\right| > 0}", block: false)#text(" for all ")#mi("{n \\neq 0}")#text(". Among other things, the absolute value detects units: ")#tao-math("{\\left|n\\right| = 1}", block: false)#text(" if and only if ")#mi("{n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Unit_(ring_theory)")[#text("unit")]#text(" in ")#mi("{{\\bf Z}}")#text(" (that is to say, it is multiplicatively invertible in ")#mi("{{\\bf Z}}")#text("). Similarly, in any ring of quadratic integers ")#mi("{{\\mathcal O} = {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" with negative discriminant, we can assign a ")#link("http://en.wikipedia.org/wiki/Field_norm")[#text("norm")]#text(" ")#mi("{N(n) \\in {\\bf N} \\cup \\{0\\}}")#text(" to any quadratic integer ")#mi("{n \\in {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("N(n) = n \\overline{n}")]]

#text("where ")#mi("{\\overline{n}}")#text(" is the complex conjugate of ")#mi("{n}")#text(". (When working with other number fields than quadratic fields of negative discriminant, one instead defines ")#mi("{N(n)}")#text(" to be the product of all the ")#link("http://en.wikipedia.org/wiki/Conjugate_element_(field_theory)")[#text("Galois conjugates")]#text(" of ")#mi("{n}")#text(".) Thus for instance, when ")#mi("{d=1,2\\ (4)}")#text(" one has ")#metadata(none) <tao-a6edef0a4889d36a327c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("N(x + y \\sqrt{-d}) = x^2 + dy^2")]]

#text("and when ")#mi("{d=3\\ (4)}")#text(" one has ")#metadata(none) <tao-dc9b98b703d71b49eb83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("N(x + y \\frac{1+\\sqrt{-d}}{2}) = x^2 + xy + \\frac{d+1}{4} y^2.")]]

#text("Analogously to the rational integers, we have the multiplicativity property ")#mi("{N(nm) = N(n) N(m)}")#text(" for ")#mi("{n,m \\in {\\mathcal O}}")#text(" and the positivity property ")#mi("{N(n) > 0}")#text(" for ")#mi("{n \\neq 0}")#text(", and the units in ")#mi("{{\\mathcal O}}")#text(" are precisely the elements of norm one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-c981a30c0e7b420b0ba5>#text(" Establish the three claims of the previous paragraph. Conclude that the units (invertible elements) of ")#mi("{{\\mathcal O}}")#text(" consist of the four elements ")#mi("{\\pm 1, \\pm i}")#text(" if ")#mi("{d=1}")#text(", the six elements ")#mi("{\\pm 1, \\pm \\omega, \\pm \\omega^2}")#text(" if ")#mi("{d=3}")#text(", and the two elements ")#mi("{\\pm 1}")#text(" if ")#mi("{d \\neq 1,3}")#text(".")
]

#text("For the rational integers, we of course have the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(", which asserts that every non-zero rational integer can be uniquely factored (up to permutation and units) as the product of irreducible integers, that is to say non-zero, non-unit integers that cannot be factored into the product of integers of strictly smaller norm. As it turns out, the same claim is true for a few additional rings of quadratic integers, such as the Gaussian integers and Eisenstein integers, but fails in general; for instance, in the ring ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(", we have the famous counterexample")

#align(center)[#tao-fit-display[#mitex("6 = 2 \\times 3 = (1+\\sqrt{-5}) (1-\\sqrt{-5})")]]

#text("that decomposes ")#mi("{6}")#text(" non-uniquely into the product of irreducibles in ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(". Nevertheless, it is an important fact that the fundamental theorem of arithmetic can be salvaged if one uses an “idealised” notion of a number in a ring of integers ")#mi("{{\\mathcal O}}")#text(", now known in modern language as an ")#link("http://en.wikipedia.org/wiki/Ideal_(ring_theory)")[#text("ideal")]#text(" of that ring. For instance, in ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(", the principal ideal ")#mi("{(6)}")#text(" turns out to uniquely factor into the product of (non-principal) ideals ")#mi("{(2) + (1+\\sqrt{-5}), (2) + (1-\\sqrt{-5}), (3) + (1+\\sqrt{-5}), (3) + (1-\\sqrt{-5})}")#text("; see Exercise ")#link(<tao-282f33bf8d858135c9bc>)[#text("27")]#text(". We will review the basic theory of ideals in number fields (focusing primarily on quadratic fields of negative discriminant) below the fold.")#linebreak()#text(" The norm forms ")#link(<tao-a6edef0a4889d36a327c>)[#text("(1)")]#text(", ")#link(<tao-dc9b98b703d71b49eb83>)[#text("(2)")]#text(" can be viewed as examples of positive definite ")#link("http://en.wikipedia.org/wiki/Quadratic_form")[#text("quadratic forms")]#text(" ")#mi("{Q: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" over the integers, by which we mean a polynomial of the form")

#align(center)[#tao-fit-display[#mitex("Q(x,y) = ax^2 + bxy + cy^2")]]

#text("for some integer coefficients ")#mi("{a,b,c}")#text(". One can declare two quadratic forms ")#mi("{Q, Q^{\\prime}: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" to be ")#emph[#text("equivalent")]#text(" if one can transform one to the other by an invertible linear transformation ")#mi("{T: {\\bf Z}^2 \\rightarrow {\\bf Z}^2}")#text(", so that ")#mi("{Q^{\\prime} = Q \\circ T}")#text(". For example, the quadratic forms ")#mi("{(x,y) \\mapsto x^2 + y^2}")#text(" and ")#mi("{(x^{\\prime},y^{\\prime}) \\mapsto 2 (x^{\\prime})^2 + 2 x^{\\prime} y^{\\prime} + (y^{\\prime})^2}")#text(" are equivalent, as can be seen by using the invertible linear transformation ")#mi("{(x,y) = (x^{\\prime},x^{\\prime}+y^{\\prime})}")#text(". Such equivalences correspond to the different choices of basis available when expressing a ring such as ")#mi("{{\\mathcal O}}")#text(" (or an ideal thereof) additively as a copy of ")#mi("{{\\bf Z}^2}")#text(".")#linebreak()#text(" There is an important and classical invariant of a quadratic form ")#mi("{(x,y) \\mapsto ax^2 + bxy + c y^2}")#text(", namely the ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("{\\Delta := b^2 - 4ac}")#text(", which will of course be familiar to most readers via the ")#link("http://en.wikipedia.org/wiki/Quadratic_formula")[#text("quadratic formula")]#text(", which among other things tells us that a quadratic form will be positive definite precisely when its discriminant is negative. It is not difficult (particularly if one exploits the multiplicativity of the determinant of ")#mi("{2 \\times 2}")#text(" matrices) to show that two equivalent quadratic forms have the same discriminant. Thus for instance any quadratic form equivalent to ")#link(<tao-a6edef0a4889d36a327c>)[#text("(1)")]#text(" has discriminant ")#mi("{-4d}")#text(", while any quadratic form equivalent to ")#link(<tao-dc9b98b703d71b49eb83>)[#text("(2)")]#text(" has discriminant ")#mi("{-d}")#text(". Thus we see that each ring ")#mi("{{\\mathcal O}[\\sqrt{-d}]}")#text(" of quadratic integers is associated with a certain negative discriminant ")#mi("{D}")#text(", defined to equal ")#mi("{-4d}")#text(" when ")#mi("{d=1,2\\ (4)}")#text(" and ")#mi("{-d}")#text(" when ")#mi("{d=3\\ (4)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Geometric interpretation of discriminant)")]#text(" ")#metadata(none) <tao-ca8562efd622e1a625af>#text(" Let ")#mi("{Q: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" be a quadratic form of negative discriminant ")#mi("{D}")#text(", and extend it to a real form ")#mi("{Q: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" in the obvious fashion. Show that for any ")#mi("{X>0}")#text(", the set ")#mi("{\\{ (x,y) \\in {\\bf R}^2: Q(x,y) \\leq X \\}}")#text(" is an ellipse of area ")#tao-math("{2\\pi X / \\sqrt{\\left|D\\right|}}", block: false)#text(".")
]

#text("It is natural to ask the converse question: if two quadratic forms have the same discriminant, are they necessarily equivalent? For certain choices of discriminant, this is the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-d4f568b800c6a61b3ba2>#text(" Show that any quadratic form ")#mi("{ax^2+bxy+cy^2}")#text(" of discriminant ")#mi("{-4}")#text(" is equivalent to the form ")#mi("{x^2+y^2}")#text(", and any quadratic form of discriminant ")#mi("{-3}")#text(" is equivalent to ")#mi("{x^2+xy+y^2}")#text(". (")#emph[#text("Hint:")]#text(" use elementary transformations to try to make ")#tao-math("{\\left|b\\right|}", block: false)#text(" as small as possible, to the point where one only has to check a finite number of cases; this argument is due to Legendre.) More generally, show that for any negative discriminant ")#mi("{D}")#text(", there are only finitely many quadratic forms of that discriminant up to equivalence (a result first established by Gauss).")
]

#text("Unfortunately, for most choices of discriminant, the converse question fails; for instance, the quadratic forms ")#mi("{x^2+5y^2}")#text(" and ")#mi("{2x^2+2xy+3y^2}")#text(" both have discriminant ")#mi("{-20}")#text(", but are not equivalent (Exercise ")#link(<tao-0889113e04d3203f0c40>)[#text("38")]#text("). This particular failure of equivalence turns out to be intimately related to the failure of unique factorisation in the ring ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(".")#linebreak()#text(" It turns out that there is a fundamental connection between quadratic fields, equivalence classes of quadratic forms of a given discriminant, and real Dirichlet characters, thus connecting the material discussed above with the last section of the ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("previous set of notes")]#text(". Here is a typical instance of this connection:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-a6dded7a1210bbe6bcc9>#text(" Let ")#mi("{\\chi_4: {\\bf N} \\rightarrow {\\bf R}}")#text(" be the real non-principal Dirichlet character of modulus ")#mi("{4}")#text(", or more explicitly ")#mi("{\\chi_4(n)}")#text(" is equal to ")#mi("{+1}")#text(" when ")#mi("{n = 1\\ (4)}")#text(", ")#mi("{-1}")#text(" when ")#mi("{n = 3\\ (4)}")#text(", and ")#mi("{0}")#text(" when ")#mi("{n = 0,2\\ (4)}")#text(".")

#list(
[#text("(i) For any natural number ")#mi("{n}")#text(", the number of Gaussian integers ")#mi("{m \\in {\\bf Z}[\\sqrt{-1}]}")#text(" with norm ")#mi("{N(m)=n}")#text(" is equal to ")#mi("{4(1 * \\chi_4)(n)}")#text(". Equivalently, the number of solutions to the equation ")#mi("{n = x^2+y^2}")#text(" with ")#mi("{x,y \\in{\\bf Z}}")#text(" is ")#mi("{4(1*\\chi_4)(n)}")#text(". (Here, as in the previous post, the symbol ")#mi("{*}")#text(" denotes ")#link("http://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]#text(".)")],
[#text("(ii) For any natural number ")#mi("{n}")#text(", the number of Gaussian integers ")#mi("{m \\in {\\bf Z}[\\sqrt{-1}]}")#text(" that divide ")#mi("{n}")#text(" (thus ")#mi("{n = dm}")#text(" for some ")#mi("{d \\in {\\bf Z}[\\sqrt{-1}]}")#text(") is ")#mi("{4(1*1*1*\\mu\\chi_4)(n)}")#text(".")]
)
]

#text("We will prove this proposition later in these notes. We observe that as a special case of part (i) of this proposition, we recover the ")#link("http://en.wikipedia.org/wiki/Fermat%27s_theorem_on_sums_of_two_squares")[#text("Fermat two-square theorem")]#text(": an odd prime ")#mi("{p}")#text(" is expressible as the sum of two squares if and only if ")#mi("{p = 1\\ (4)}")#text(". This proposition should also be compared with the fact, used crucially in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("the previous post")]#text(" to prove Dirichlet’s theorem, that ")#mi("{1*\\chi(n)}")#text(" is non-negative for any ")#mi("{n}")#text(", and at least one when ")#mi("{n}")#text(" is a square, for any quadratic character ")#mi("{\\chi}")#text(".")#linebreak()#text(" As an illustration of the relevance of such connections to analytic number theory, let us now explicitly compute ")#mi("{L(1,\\chi_4)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9")]#text(" ")#metadata(none) <tao-2f60014f825fa20dbc56>#text(" ")#mi("{L(1,\\chi_4) = \\frac{\\pi}{4}}")#text(".")
]

#text("This particular identity is also known as the ")#link("http://en.wikipedia.org/wiki/Leibniz_formula_for_%CF%80")[#text("Leibniz formula")]#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" For a large number ")#mi("{x}")#text(", consider the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}[\\sqrt{-1}]: N(n) \\leq x} 1")]]

#text("of all the Gaussian integers of norm less than ")#mi("{x}")#text(". On the one hand, this is the same as the number of lattice points of ")#mi("{{\\bf Z}^2}")#text(" in the disk ")#mi("{\\{ (a,b) \\in {\\bf R}^2: a^2+b^2 \\leq x \\}}")#text(" of radius ")#mi("{\\sqrt{x}}")#text(". Placing a unit square centred at each such lattice point, we obtain a region which differs from the disk by a region contained in an annulus of area ")#mi("{O(\\sqrt{x})}")#text(". As the area of the disk is ")#mi("{\\pi x}")#text(", we conclude the ")#link("http://en.wikipedia.org/wiki/Gauss_circle_problem")[#text("Gauss bound")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}[\\sqrt{-1}]: N(n) \\leq x} 1 = \\pi x + O(\\sqrt{x}).")]]

#text("On the other hand, by Proposition ")#link(<tao-a6dded7a1210bbe6bcc9>)[#text("8")]#text("(i) (and removing the ")#mi("{n=0}")#text(" contribution), we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}[\\sqrt{-1}]: N(n) \\leq x} 1 = 1 + 4 \\sum_{n \\leq x} 1 * \\chi_4(n).")]]

#text("Now we use the Dirichlet hyperbola method to expand the right-hand side sum, first expressing")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} 1 * \\chi_4(n)  & = \\sum_{d \\leq \\sqrt{x}} \\chi_4(d) \\sum_{m \\leq x/d} 1 + \\sum_{m \\leq \\sqrt{x}} \\sum_{d \\leq x/m} \\chi_4(d)", block: true)



#tao-math(" & - (\\sum_{d \\leq \\sqrt{x}} \\chi_4(d)) (\\sum_{m \\leq \\sqrt{x}} 1)", block: true)
]

#text("and then using the bounds ")#mi("{\\sum_{d \\leq y} \\chi_4(d) = O(1)}")#text(", ")#mi("{\\sum_{m \\leq y} 1 = y + O(1)}")#text(", ")#mi("{\\sum_{d \\leq \\sqrt{x}} \\frac{\\chi_4(d)}{d} = L(1,\\chi_4) + O(\\frac{1}{\\sqrt{x}})}")#text(" from the previous set of notes to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1 * \\chi_4(n) = x L(1,\\chi_4) + O(\\sqrt{x}).")]]

#text("Comparing the two formulae for ")#mi("{\\sum_{n \\in {\\bf Z}[\\sqrt{-1}]: N(n) \\leq x} 1}")#text(" and sending ")#mi("{x \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Give an alternate proof of Corollary ")#link(<tao-2f60014f825fa20dbc56>)[#text("9")]#text(" that relies on obtaining asymptotics for the Dirichlet series ")#mi("{\\sum_{n \\in {\\bf Z}} \\frac{1 * \\chi_4(n)}{n^s}}")#text(" as ")#mi("{s \\rightarrow 1^+}")#text(", rather than using the Dirichlet hyperbola method.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Give a direct proof of Corollary ")#link(<tao-2f60014f825fa20dbc56>)[#text("9")]#text(" that does not use Proposition ")#link(<tao-a6dded7a1210bbe6bcc9>)[#text("8")]#text(", instead using Taylor expansion of the complex logarithm ")#mi("{\\log(1+z)}")#text(". (One can also use Taylor expansions of some other functions related to the complex logarithm here, such as the arctangent function.)")
]

#text("More generally, one can relate ")#mi("{L(1,\\chi)}")#text(" for a real Dirichlet character ")#mi("{\\chi}")#text(" with the number of inequivalent quadratic forms of a certain discriminant, via the famous ")#link("http://en.wikipedia.org/wiki/Class_number_formula")[#text("class number formula")]#text("; we will give a special case of this formula below the fold.")#linebreak()#text(" The material here is only a very rudimentary introduction to algebraic number theory, and is not essential to the rest of the course. A slightly expanded version of the material here, from the perspective of analytic number theory, may be found in Sections 5 and 6 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1790423")[#text("Davenport’s book")]#text(". A more in-depth treatment of algebraic number theory may be found in a number of texts, e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1215934")[#text("Fröhlich and Taylor")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-88dc2964034c3bdf16dc>

#heading(level: 1)[#strong[#text(" — 1. Ideals — ")]]

#text("We begin by reviewing the notion of an ideal in an arbitrary commutative ring.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12 (Ideals)")]#text(" Let ")#mi("{R}")#text(" be a commutative ring (in this set of notes, rings are understood to contain a multiplicative unit ")#mi("{1}")#text("). An ")#emph[#text("ideal")]#text(" of ")#mi("{R}")#text(" is an additive subgroup ")#mi("{I}")#text(" of ")#mi("{R}")#text(" with the property that ")#mi("{nm \\in I}")#text(" whenever ")#mi("{n \\in I}")#text(" and ")#mi("{m \\in R}")#text(". Note that if ")#mi("{I}")#text(" is an ideal, then the quotient ")#mi("{R/I}")#text(" is well defined as a commutative ring. We write ")#mi("{n \\mapsto n \\text{ mod } I}")#text(" for the quotient map from ")#mi("{R}")#text(" to ")#mi("{R/I}")#text(", and write ")#mi("{n = m \\text{ mod } I}")#text(" if ")#mi("{n-m \\in I}")#text(", or equivalently if ")#mi("{n \\text{ mod } I}")#text(" is equal to ")#mi("{m \\text{ mod } I}")#text(".")#linebreak()#text(" An ideal is ")#emph[#text("proper")]#text(" if it is not all of ")#mi("{R}")#text(". An ideal is ")#emph[#text("principal")]#text(" if it is of the form ")#mi("{(n) := \\{ nm: m \\in R \\}}")#text(" for some ")#mi("{n \\in R}")#text(", and ")#emph[#text("non-zero")]#text(" if it is not the zero ideal ")#mi("{(0) = \\{0\\}}")#text(".")#linebreak()#text(" If ")#mi("{I, J}")#text(" are ideals, then the intersection ")#mi("{I \\cap J}")#text(" is an ideal, as is the sum ")#mi("{I + J := \\{ n+m: n \\in I, m \\in J \\}}")#text(". The product set ")#mi("{\\{ nm: n\\in I, m \\in J\\}}")#text(" need not be an ideal in general (it is not always closed under addition); however, we can define the product ideal ")#mi("{I \\cdot J}")#text(" to be the ideal generated by this product set (that is, the intersection of all the ideals containing this product set). One can then define powers ")#mi("{I^n}")#text(" for any ")#mi("{n \\geq 0}")#text(" in the obvious fashion, with the convention that ")#mi("{I^0 = R}")#text(". We say that ")#mi("{I}")#text(" ")#emph[#text("divides")]#text(" ")#mi("{J}")#text(" if ")#mi("{I \\supset J}")#text(", thus for instance ")#mi("{I}")#text(" divides ")#mi("{I \\cdot J}")#text(" for any ideals ")#mi("{I,J}")#text(". If ")#mi("{I \\supsetneq J}")#text(", we say that ")#mi("{I}")#text(" ")#emph[#text("strictly divides")]#text(" ")#mi("{J}")#text(".")#linebreak()#text(" An ideal is ")#link("http://en.wikipedia.org/wiki/Prime_ideal")[#text("prime")]#text(" if it is proper, and it has the property that for any ")#mi("{n,m \\in R}")#text(" with ")#mi("{nm \\in I}")#text(", one has at least one of ")#mi("{n \\in I}")#text(" or ")#mi("{m \\in I}")#text(" true. Equivalently, an ideal ")#mi("{I}")#text(" is prime if the quotient ring ")#mi("{R/I}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Integral_domain")[#text("integral domain")]#text(".")
]

#text("One can easily check in the rational integers ")#mi("{{\\bf Z}}")#text(" that product, divisibility, and primality correspond to their counterpart notions in the natural numbers. More precisely, if ")#mi("{n,m}")#text(" are natural numbers, then ")#mi("{(n) \\cdot (m) = (nm)}")#text(", that ")#mi("{(n)}")#text(" divides ")#mi("{(m)}")#text(" if and only if ")#mi("{n}")#text(" divides ")#mi("{m}")#text(", and that ")#mi("{(n)}")#text(" is prime if and only if ")#mi("{n}")#text(" is prime. (But note that the zero ideal ")#mi("{(0)}")#text(" is also prime, and can be viewed as a sort of “prime at infinity” from the perspective of ")#link("http://en.wikipedia.org/wiki/Scheme_%28mathematics%29")[#text("scheme theory")]#text(".) Also, if ")#mi("{n}")#text(" is a natural number and ")#mi("{a,b}")#text(" are integers, then ")#mi("{a=b \\text{ mod } (n)}")#text(" holds if and only if ")#mi("{a=b \\text{ mod } n}")#text(". Thus we see that the above operations on ideals are quite compatible with their classical counterparts in ")#mi("{{\\bf N}}")#text(" or ")#mi("{{\\bf Z}}")#text(". Also, the integers form a ")#link("http://en.wikipedia.org/wiki/Principal_ideal_domain")[#text("principal ideal domain")]#text(", in that every ideal ")#mi("{I}")#text(" is principal; indeed, if ")#mi("{I}")#text(" is non-zero, it is generated by the element of minimal norm. In particular, from the classical fundamental theorem of arithmetic we see that every non-zero ideal in ")#mi("{{\\bf Z}}")#text(" is uniquely factorisable (up to rearrangement) as the product of prime ideals.")#linebreak()#text(" Now we specialise to rings ")#mi("{{\\mathcal O} = {\\mathcal O}_{{\\bf Q}(\\sqrt{-d})}}")#text(" of quadratic integers, where ")#mi("{d}")#text(" is a squarefree natural number. These more general rings ")#mi("{{\\mathcal O}}")#text(" need no longer be principal ideal domains. For instance, ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(" contains the non-principal ideal ")#mi("{(2) + (1 + \\sqrt{-5})}")#text(". Closely related to this is the breakdown of the fundamental theorem of arithmetic for quadratic integers (i.e. ")#mi("{{\\mathcal O}}")#text(" need not be a ")#link("http://en.wikipedia.org/wiki/Unique_factorization_domain")[#text("unique factorisation domain")]#text("); for instance, ")#mi("{6 \\in {\\bf Z}[\\sqrt{-5}]}")#text(" factors non-uniquely as ")#mi("{6 = 2 \\times 3}")#text(" and ")#mi("{6 = (1+\\sqrt{-5}) \\times (1-\\sqrt{-5})}")#text(". Despite this, one still has unique factorisation at the level of ideals; for instance, in ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(" it turns out that ")#mi("{(6)}")#text(" factors uniquely as the product of ")#mi("{(2) + (1+\\sqrt{-5})}")#text(", ")#mi("{(2) + (1-\\sqrt{-5})}")#text(", ")#mi("{(3) + (1+\\sqrt{-5})}")#text(", and ")#mi("{(3) + (1-\\sqrt{-5})}")#text(". As we shall see, the precise failure of unique factorisation at the level of quadratic numbers can be quantified by an important number ")#mi("{h(D)}")#text(", known as the ")#link("http://en.wikipedia.org/wiki/Ideal_class_group")[#text("class number")]#text(" of the ring of integers, where ")#mi("{D}")#text(" is the discriminant mentioned in the introduction (equal to ")#mi("{-4d}")#text(" when ")#mi("{d=1,2\\ (4)}")#text(", and ")#mi("{-d}")#text(" when ")#mi("{d=3\\ (4)}")#text(").")

#heading(level: 1)[#strong[#text(" — 2. Unique factorisation of ideals — ")]]

#text("Henceforth ")#mi("{d}")#text(" is a fixed squarefree natural number, and ")#mi("{{\\mathcal O}}")#text(" is the ring of integers in ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(". We set the discriminant ")#mi("{D}")#text(" equal to ")#mi("{-4d}")#text(" when ")#mi("{d=1,2\\ (4)}")#text(" and equal to ")#mi("{-d}")#text(" when ")#mi("{d=3\\ (4)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Algebraic interpretation of discriminant)")]#text(" Let ")#mi("{a, b}")#text(" be an additive basis for ")#mi("{{\\mathcal O}}")#text(" (thus ")#mi("{{\\mathcal O}}")#text(" is generated by ")#mi("{a,b}")#text(" as an additive group). Show that")

#align(center)[#tao-fit-display[#mitex("D = \\text{det} \\begin{pmatrix} a & b \\\\ \\overline{a} & \\overline{b} \\end{pmatrix}^2.")]]

#text("We remark that the ")#link("http://en.wikipedia.org/wiki/Discriminant_of_an_algebraic_number_field")[#text("discriminant of a more general number field is defined similarly")]#text(".")
]

#text("As mentioned in the introduction, one can view ")#mi("{{\\mathcal O}}")#text(" additively, as a rank two lattice in the complex numbers ")#mi("{{\\bf C}}")#text(". Any non-zero ideal ")#mi("{I}")#text(" of ")#mi("{{\\mathcal O}}")#text(" can then be seen to be a rank two sublattice of ")#mi("{{\\mathcal O}}")#text(", and in particular must have finite index. We refer to this index as the norm ")#mi("{N(I)}")#text(" of the ideal, thus ")#mi("{N(I)}")#text(" is the natural number defined by the formula")

#align(center)[#tao-fit-display[#tao-math("N(I) := \\left| {\\mathcal O} / I \\right|.", block: true)]]

#text("For the ring ")#mi("{{\\mathcal O}}")#text(" of quadratic integers we are considering here, one can interpret ")#mi("{N(I)}")#text(" geometrically as the area of the torus ")#mi("{{\\bf C}/I}")#text(", divided by the area of the torus ")#mi("{{\\bf C}/{\\mathcal O}}")#text(", which can be easily computed to be ")#tao-math("{\\sqrt{\\left|D\\right|}/2}", block: false)#text(".")#linebreak()#text(" It is clear that if ")#mi("{I}")#text(" divides ")#mi("{J}")#text(", then ")#mi("{N(I)}")#text(" divides ")#mi("{N(J)}")#text(", since ")#mi("{{\\mathcal O}/I}")#text(" is a quotient of ")#mi("{{\\mathcal O}/J}")#text(". Similarly, if ")#mi("{I}")#text(" divides ")#mi("{J}")#text(" and ")#mi("{N(I)=N(J)}")#text(", then one must have ")#mi("{I=J}")#text(". This implies the important ")#link("http://en.wikipedia.org/wiki/Noetherian_ring")[#text("Noetherian property")]#text(": ")#mi("{{\\mathcal O}}")#text(" does not contain any infinite strictly increasing sequence of ideals")

#align(center)[#tao-fit-display[#mitex("I_1 \\subsetneq I_2 \\subsetneq I_3 \\subsetneq \\dots")]]

#text("since their norms must be strictly decreasing, creating an ")#link("http://en.wikipedia.org/wiki/Proof_by_infinite_descent")[#text("infinite descent")]#text(" which is absurd. This notion of norm is compatible with the notion of the norm of a quadratic integer:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-557cde45b25e35bc91ad>#text(" If ")#mi("{n}")#text(" is a quadratic integer, show that ")#mi("{N((n)) = N(n)}")#text(", where ")#mi("{N(n)}")#text(" was defined in the introduction.")
]

#text("We remark that for quadratic integers of positive discriminant the situation is slightly more complicated, because the norm ")#mi("{N(x + y \\sqrt{d}) = x^2 - dy^2}")#text(" of an individual element can now be negative, whereas the norm of an ideal is always positive. We will not dwell on this complication further here.")#linebreak()#text(" Now we develop a unique factorisation theory for ideals. We first establish that prime ideals are prime within the multiplicative structure of ideals (rather than of quadratic integers):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15")]#text(" ")#metadata(none) <tao-2804bad6fe94a55f18b2>#text(" Let ")#mi("{{\\mathfrak p}}")#text(" be a prime ideal that divides the product ")#mi("{I \\cdot J}")#text(" of two ideals ")#mi("{I,J}")#text(". Then ")#mi("{{\\mathfrak p}}")#text(" must divide at least one of ")#mi("{I,J}")#text(".")
]

#emph[#text("Proof:")]#text(" If ")#mi("{{\\mathfrak p}}")#text(" does not divide either of ")#mi("{I, J}")#text(", then we can find ")#mi("{n \\in I, m \\in J}")#text(" that lie outside of ")#mi("{{\\mathfrak p}}")#text(". As ")#mi("{{\\mathfrak p}}")#text(" is prime, we conclude that ")#mi("{nm \\in I \\cdot J}")#text(" also lies outside of ")#mi("{{\\mathfrak p}}")#text(", and so ")#mi("{{\\mathfrak p}}")#text(" does not divide ")#mi("{I \\cdot J}")#text(", a contradiction. ")#mi("\\Box")#linebreak()#text(" Also, in a ring of quadratic integers, prime ideals are maximal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-8b5cc4df7eec7d32a781>#text(" Show that the only ideals that divide a prime ideal ")#mi("{{\\mathfrak p}}")#text(" are ")#mi("{{\\mathfrak p}}")#text(" itself, and the full ring ")#mi("{(1)}")#text(".")
]

#text("If a non-zero ideal ")#mi("{I}")#text(" is not prime, then by definition there exist two quadratic integers ")#mi("{n,m}")#text(" outside of ")#mi("{I}")#text(" such that ")#mi("{nm \\in I}")#text(". If we set ")#mi("{I_1 := I + (n)}")#text(" and ")#mi("{I_2 := I + (m)}")#text(", we then see that ")#mi("{I_1, I_2}")#text(" strictly divide ")#mi("{I}")#text(", and that ")#mi("{I}")#text(" divides ")#mi("{I_1 \\cdot I_2}")#text(". Thus any non-zero ideal ")#mi("{I}")#text(" is either prime, or divides the product of two non-zero ideals that strictly divide it (and thus have smaller norm). Iterating this (and using the Noetherian property), we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17")]#text(" ")#metadata(none) <tao-f64551fcd6f07823cb87>#text(" Every non-zero ideal divides the product of a finite number of prime ideals.")
]

#text("A similar argument gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that every non-zero ideal is divisible by at least one prime ideal.")
]

#text("We now need a technical lemma that allows one to “invert” a prime ideal ")#mi("{{\\mathfrak p}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19")]#text(" Let ")#mi("{{\\mathfrak p}}")#text(" be a non-zero prime ideal. Then there exists a quadratic field element ")#mi("{x \\in {\\bf Q}(\\sqrt{-d})}")#text(" that is not a quadratic integer (thus ")#mi("{x \\not \\in {\\mathcal O}}")#text("), but is such that ")#mi("{x \\cdot {\\mathfrak p} \\subset {\\mathcal O}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{n}")#text(" be a non-zero element of ")#mi("{{\\mathfrak p}}")#text(". By Proposition ")#link(<tao-f64551fcd6f07823cb87>)[#text("17")]#text(", ")#mi("{(n)}")#text(" must divide some product ")#mi("{{\\mathfrak p}_1 \\dots {\\mathfrak p}_m}")#text(" of prime ideals. In particular, ")#mi("{{\\mathfrak p}}")#text(" also divides ")#mi("{{\\mathfrak p}_1 \\dots {\\mathfrak p}_m}")#text(", which by Lemma ")#link(<tao-2804bad6fe94a55f18b2>)[#text("15")]#text(" and Exercise ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("16")]#text(" implies that one of the ")#mi("{{\\mathfrak p}_1,\\dots,{\\mathfrak p}_m}")#text(", say ")#mi("{{\\mathfrak p}_m}")#text(", is equal to ")#mi("{{\\mathfrak p}}")#text(". By taking ")#mi("{m}")#text(" to be minimal, we may assume that ")#mi("{(n)}")#text(" does not divide ")#mi("{{\\mathfrak p}_1 \\dots {\\mathfrak p}_{m-1}}")#text(". Thus, we may find an element ")#mi("{a}")#text(" of ")#mi("{{\\mathfrak p}_1 \\dots {\\mathfrak p}_{m-1}}")#text(" that does not lie in ")#mi("{(n)}")#text(", but such that ")#mi("{a \\cdot {\\mathfrak p}}")#text(" is contained in ")#mi("{(n) = n \\cdot {\\mathcal O}}")#text(". Setting ")#mi("{x := \\frac{a}{n}}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" We can formalise the notion of inverting an ideal by introducing the concept of a ")#link("http://en.wikipedia.org/wiki/Fractional_ideal")[#text("fractional ideal")]#text(", which are to ideals as rational numbers are to integers, but we will not do so in this set of notes.")
]

#text("Now we can give the most difficult step of unique factorisation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 21")]#text(" ")#metadata(none) <tao-0c23d8d011de2a78ea63>#text(" Suppose ")#mi("{I}")#text(" is a non-zero ideal that is divisible by a prime ideal ")#mi("{{\\mathfrak p}}")#text(". Then one has ")#mi("{I = {\\mathfrak p} \\cdot J}")#text(" for some non-zero ideal ")#mi("{J}")#text(" which is a strict divisor of ")#mi("{I}")#text(".")
]

#emph[#text("Proof:")]#text(" By the previous lemma, we can find ")#mi("{x \\in {\\bf Q}(\\sqrt{-d})}")#text(" that is not a quadratic integer, such that ")#mi("{x \\cdot {\\mathfrak p} \\subset {\\mathcal O}}")#text(". Note that ")#mi("{x \\cdot {\\mathfrak p} + {\\mathfrak p}}")#text(" is an ideal dividing ")#mi("{{\\mathfrak p}}")#text(", so by Exercise ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("16")]#text(" is either equal to ")#mi("{{\\mathfrak p}}")#text(" or ")#mi("{{\\mathcal O}}")#text(".")#linebreak()#text(" Suppose first that ")#mi("{x \\cdot {\\mathfrak p} + {\\mathfrak p}= {\\mathfrak p}}")#text(". The ideal ")#mi("{{\\mathfrak p}}")#text(" is a rank two lattice, and thus isomorphic as an abelian group to ")#mi("{{\\bf Z}^2}")#text(". The action of multiplication by ")#mi("{x}")#text(" on ")#mi("{{\\mathfrak p}}")#text(" is then conjugate to the action of a ")#mi("{2 \\times 2}")#text(" matrix with integer coefficients. By the Cayley-Hamilton theorem, this implies that there is a monic quadratic polynomial of ")#mi("{x}")#text(" that annihilates ")#mi("{{\\mathfrak p}}")#text(", and is thus zero (since ")#mi("{{\\mathcal O}}")#text(" is an integral domain). In other words, ")#mi("{x}")#text(" is an algebraic integer, and hence ")#mi("{x \\in {\\mathcal O}}")#text(", a contradiction. (Note here that we crucially used the fact that ")#mi("{{\\mathcal O}}")#text(" contains ")#emph[#text("all")]#text(" the algebraic integers of ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text("; cf. Remark ")#link(<tao-4ff0977a56f7bf635689>)[#text("4")]#text(".)")#linebreak()#text(" Thus we must have ")#mi("{x \\cdot {\\mathfrak p} + {\\mathfrak p} = {\\mathcal O}}")#text(". If we then set ")#mi("{J := x \\cdot I + I}")#text(", then we have ")#mi("{I = {\\mathfrak p} \\cdot J}")#text(", and ")#mi("{J}")#text(" is an ideal dividing ")#mi("{I}")#text(". We are thus done unless ")#mi("{I=J}")#text(", that is to say ")#mi("{x \\cdot I + I = I}")#text(". But one can then repeat the previous argument to conclude that ")#mi("{x}")#text(" is an algebraic integer and thus in ")#mi("{{\\mathcal O}}")#text(", again reaching a contradiction. ")#mi("\\Box")#linebreak()#text(" We now have enough tools to mimic the usual proof of unique factorisation for natural numbers, to obtain the analogous result for ideals in a ring of quadratic integers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Unique factorisation)")]#text(" Show that any non-zero ideal can be uniquely expressed (up to rearrangement) as a product ")#mi("{{\\mathfrak p}_1^{a_1} \\dots {\\mathfrak p}_k^{a_k}}")#text(" of non-zero prime ideals, with ")#mi("{a_1,\\dots,a_k > 0}")#text(". Show that one non-zero ideal ")#mi("{I}")#text(" divides another ")#mi("{J}")#text(" if and only if the number of times any given prime ideal ")#mi("{{\\mathfrak p}}")#text(" appears in the unique factorisation of ")#mi("{I}")#text(" is less than or equal to the number of times it appears in ")#mi("{J}")#text(".")
]

#text("A basic application of unique factorisation is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23 (Chinese Remainder Theorem)")]#text(" Let ")#mi("{I, J}")#text(" be non-zero ideals that are coprime (they have no prime ideal divisors in common). Then the obvious ring homomorphism ")#mi("{\\phi}")#text(" from ")#mi("{{\\mathcal O}/(I \\cdot J)}")#text(" to ")#mi("{{\\mathcal O}/I \\times {\\mathcal O}/J}")#text(", defined by setting ")#mi("{\\phi( n \\text{ mod } I \\cdot J ) := (n \\text{ mod } I, n \\text{ mod } J)}")#text(", is an isomorphism.")
]

#emph[#text("Proof:")]#text(" Observe that the ideal ")#mi("{I+J}")#text(" divides both ")#mi("{I}")#text(" and ")#mi("{J}")#text(" and must therefore be all of ")#mi("{{\\mathcal O}}")#text(", by unique factorisation and coprimality. Similarly, the ideal ")#mi("{I \\cap J}")#text(" is divisible by both ")#mi("{I}")#text(" and ")#mi("{J}")#text(" while dividing ")#mi("{I \\cdot J}")#text(", and must therefore be exactly ")#mi("{I \\cdot J}")#text(", by unique factorisation and coprimality. Since the kernel of ")#mi("{\\phi}")#text(" is ")#mi("{(I \\cap J)/(I \\cdot J)}")#text(", we conclude that ")#mi("{\\phi}")#text(" is injective; it remains to show that ")#mi("{\\phi}")#text(" is surjective. Since ")#mi("{I + J = {\\mathcal O}}")#text(", we can split ")#mi("{1 = n+m}")#text(" for some ")#mi("{n \\in I}")#text(" and ")#mi("{m \\in J}")#text(". But then ")#mi("{\\phi( n \\text{ mod } I \\cdot J ) = (0 \\text{ mod } I, 1 \\text{ mod } J)}")#text(" and ")#mi("{\\phi( m \\text{ mod } I \\cdot J ) = (1 \\text{ mod } I, 0 \\text{ mod } J)}")#text(", and the surjectivity then follows since these two elements generate ")#mi("{{\\mathcal O}/I \\times {\\mathcal O}/J}")#text(" as an ")#mi("{{\\mathcal O}}")#text("-module. ")#mi("\\Box")#linebreak()#text(" In the non-coprime case, we have the following basic fact.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24")]#text(" ")#metadata(none) <tao-453d2ddfc888f9fcf871>#text(" Let ")#mi("{{\\mathfrak p}}")#text(" be a non-zero prime ideal. Then for any non-negative integer ")#mi("{j}")#text(", we have ")#mi("{{\\mathfrak p}^{j}/{\\mathfrak p}^{j+1}}")#text(" isomorphic (as a ring) to ")#mi("{{\\mathcal O} / {\\mathfrak p}}")#text(".")
]

#emph[#text("Proof:")]#text(" By unique factorisation, ")#mi("{{\\mathfrak p}^{j}}")#text(" is a strict divisor of ")#mi("{{\\mathfrak p}^{j+1}}")#text(", thus we can find ")#mi("{a \\in {\\mathfrak p}^{j}}")#text(" that does not lie in ")#mi("{{\\mathfrak p}^{j+1}}")#text(". This gives a ring homomorphism ")#mi("{\\phi: {\\mathcal O} \\rightarrow {\\mathfrak p}^{j}/{\\mathfrak p}^{j+1}}")#text(" defined by ")#mi("{\\phi(n) := an \\text{ mod } {\\mathfrak p}^{j+1}}")#text(". The kernel of this map is an ideal dividing ")#mi("{{\\mathfrak p}}")#text(" that does not contain ")#mi("{1}")#text(", and is thus ")#mi("{{\\mathfrak p}}")#text(". Thus we have an injection from ")#mi("{{\\mathcal O}/{\\mathfrak p}}")#text(" to ")#mi("{{\\mathfrak p}^{j}/{\\mathfrak p}^{j+1}}")#text(".")#linebreak()#text(" It remains to show surjectivity. By several applications of Proposition ")#link(<tao-0c23d8d011de2a78ea63>)[#text("21")]#text(", we may write ")#mi("{(a) = {\\mathfrak p}^j I}")#text(" for some non-zero ideal ")#mi("{I}")#text(" not divisible by ")#mi("{{\\mathfrak p}}")#text(". By the Chinese remainder theorem, we may then find, for any ")#mi("{n \\in {\\mathfrak p}^j}")#text(", a quadratic integer ")#mi("{b}")#text(" such that ")#mi("{b = n \\text{ mod } {\\mathfrak p}^{j+1}}")#text(" and ")#mi("{b = 0 \\text{ mod } I}")#text(". Thus ")#mi("{b}")#text(" lies in both ")#mi("{{\\mathfrak p}^j}")#text(" and ")#mi("{I}")#text(", and hence in ")#mi("{(a)}")#text(" by coprimality; thus ")#mi("{b/a}")#text(" is a quadratic integer. By construction, we have ")#mi("{\\phi(b/a) = n \\text{ mod } p^{j+1}}")#text(", giving the desired surjectivity.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 25 (Multiplicativity of norm)")]#text(" For any non-zero ideals ")#mi("{I, J}")#text(", we have ")#mi("{N(I \\cdot J) = N(I) N(J)}")#text(".")
]

#emph[#text("Proof:")]#text(" When ")#mi("{I,J}")#text(" are coprime this follows directly from the Chinese remainder theorem. By unique factorisation, it thus suffices to show that ")#mi("{N({\\mathfrak p}^j) = N({\\mathfrak p})^j}")#text(" for all natural numbers ")#mi("{j}")#text(". But this follows from Proposition ")#link(<tao-453d2ddfc888f9fcf871>)[#text("24")]#text(" and induction on ")#mi("{j}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Show that the Gaussian integers and the Eisenstein integers are principal ideal domains. (")#emph[#text("Hint:")]#text(" if ")#mi("{I}")#text(" is a non-zero ideal in one of these rings, consider a non-zero element of ")#mi("{I}")#text(" of minimal norm.) Conclude a unique factorisation theorem for elements of these rings.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-282f33bf8d858135c9bc>#text(" Verify that in ")#mi("{{\\bf Z}[\\sqrt{-5}]}")#text(", the principal ideal ")#mi("{(6)}")#text(" factors into the four ideals mentioned in the introduction, and that these ideals are prime. What are the norms of all the ideals involved?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 28")]#text(" The unique factorisation theorem for ideals holds in the more general context of ")#link("http://en.wikipedia.org/wiki/Dedekind_domain")[#text("Dedekind domains")]#text(", but we will not develop the abstract theory of Dedekind domains here.")
]

#heading(level: 1)[#strong[#text(" — 3. Connection with the Kronecker symbol — ")]]

#text("Let ")#mi("{{\\mathfrak p}}")#text(" be a prime ideal, then ")#mi("{{\\mathcal O}/{\\mathfrak p}}")#text(" is a finite integral domain, and is thus a ")#link("http://en.wikipedia.org/wiki/Finite_field")[#text("finite field")]#text(" (each non-zero element acts via multiplication by a permutation). On the other hand, since ")#mi("{{\\mathcal O}}")#text(" is a rank two abelian group, this finite field must have rank at most two. We conclude that ")#mi("{{\\mathcal O}/{\\mathfrak p}}")#text(" is isomorphic to a finite field of order either ")#mi("{p}")#text(" or ")#mi("{p^2}")#text(" for some rational prime ")#mi("{p}")#text(", which is the characteristic of the field. In particular, ")#mi("{N({\\mathfrak p})}")#text(" is either a prime ")#mi("{p}")#text(" or a square ")#mi("{p^2}")#text(" of that prime ")#mi("{p}")#text(". On the other hand, since ")#mi("{{\\mathcal O}/{\\mathfrak p}}")#text(" has characteristic ")#mi("{p}")#text(", ")#mi("{{\\mathfrak p}}")#text(" must divide ")#mi("{(p)}")#text(", which has norm exactly ")#mi("{p^2}")#text(" by Exercise ")#link(<tao-557cde45b25e35bc91ad>)[#text("14")]#text(". By unique factorisation, we conclude that for each rational prime ")#mi("{p}")#text(", the ideal ")#mi("{(p)}")#text(" is either prime of norm ")#mi("{p^2}")#text(", or is the product ")#mi("{{\\mathfrak p}_1 {\\mathfrak p}_2}")#text(" of two prime ideals that each have norm ")#mi("{p}")#text(", and furthermore that all prime ideals arise in this fashion.")#linebreak()#text(" We can determine precisely which of the two is the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29")]#text(" Let ")#mi("{p}")#text(" be a rational prime.")

#list(
[#text("If ")#mi("{D}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Quadratic_residue")[#text("quadratic residue")]#text(" modulo ")#mi("{p}")#text(", then ")#mi("{(p)}")#text(" is the product of two prime ideals ")#mi("{{\\mathfrak p}_1, {\\mathfrak p}_2}")#text(" of norm ")#mi("{p}")#text(".")],
[#mi("{D}")#text(" is a quadratic non-residue modulo ")#mi("{p}")#text(", then ")#mi("{(p)}")#text(" is a prime ideal of norm ")#mi("{p^2}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We just handle the case ")#mi("{d=1,2\\ (4)}")#text(" and leave the ")#mi("{d=3\\ (4)}")#text(" case as an exercise. Suppose there is an prime ideal ")#mi("{{\\mathfrak p}}")#text(" of norm ")#mi("{p}")#text(", then ")#mi("{{\\mathfrak p}/(p)}")#text(" is isomorphic to the field of order ")#mi("{p}")#text(". In particular, if ")#mi("{a + b \\sqrt{-d}}")#text(" is a element of ")#mi("{{\\mathfrak p}}")#text(" not divisible by ")#mi("{p}")#text(", then ")#mi("{\\sqrt{-d} ( a + b \\sqrt{-d} )}")#text(" must be a multiple of ")#mi("{a + b \\sqrt{-d}}")#text(" modulo ")#mi("{p}")#text(", thus one can find non-zero ")#mi("{k \\in {\\bf Z}/p{\\bf Z}}")#text(" such that ")#mi("{ka = -d b \\text{ mod } p}")#text(" and ")#mi("{kb = a \\text{ mod } p}")#text(", which implies that ")#mi("{k^2 = -d \\text{ mod } p}")#text(", since ")#mi("{a,b}")#text(" are not both zero modulo ")#mi("{p}")#text(". Thus ")#mi("{-d}")#text(" (and hence ")#mi("{D}")#text(") is a quadratic residue modulo ")#mi("{p}")#text(". Conversely, if ")#mi("{D}")#text(" (and hence ")#mi("{-d}")#text(") is a quadratic residue, then we can find ")#mi("{a,b,k}")#text(" with ")#mi("{ka = -d b \\text{ mod } p}")#text(" and ")#mi("{kb = a \\text{ mod } p}")#text(" with ")#mi("{a,b}")#text(" not both zero modulo ")#mi("{p}")#text(", and then ")#mi("{(a+b\\sqrt{-d}) + (p)}")#text(" is an ideal dividing ")#mi("{(p)}")#text(" of norm ")#mi("{p}")#text(", and thus prime. The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Complete the proof of the proposition in the case ")#mi("{d=3\\ (4)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Show that when ")#mi("{D}")#text(" is a quadratic residue modulo ")#mi("{p}")#text(", the two prime ideals ")#mi("{{\\mathfrak p}_1, {\\mathfrak p}_2}")#text(" appearing in the above proposition are distinct unless ")#mi("{p}")#text(" divides ")#mi("{D}")#text(", in which case the two ideals are equal.")
]

#text("The above proposition gives us a formula for the number of prime ideals of a given norm. For any natural number ")#mi("{n}")#text(", define the ")#link("http://en.wikipedia.org/wiki/Kronecker_symbol")[#text("Kronecker symbol")]#text(" ")#mi("{\\chi(n) := (\\frac{D}{n})}")#text(" to be the completely multiplicative function of ")#mi("{n}")#text(" such that for each prime ")#mi("{p}")#text(", ")#mi("{(\\frac{D}{p})}")#text(" equals ")#mi("{0}")#text(" if ")#mi("{p}")#text(" divides ")#mi("{D}")#text(", equals ")#mi("{+1}")#text(" if ")#mi("{D}")#text(" is a non-zero quadratic residue mod ")#mi("{p}")#text(", and ")#mi("{-1}")#text(" if ")#mi("{D}")#text(" is a non-zero quadratic nonresidue mod ")#mi("{p}")#text(". From the ")#link("http://en.wikipedia.org/wiki/Quadratic_reciprocity")[#text("law of quadratic reciprocity")]#text(", one can verify that ")#mi("{\\chi}")#text(" is a Dirichlet character of conductor ")#mi("{D}")#text(". For instance, if ")#mi("{d=1}")#text(", ")#mi("{\\chi = \\chi_4}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-4889e6086e60b206ef33>#text(" Show that for any natural number ")#mi("{n}")#text(", the number of ideals of norm ")#mi("{n}")#text(" is equal to ")#mi("{1 * \\chi(n)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Prove Proposition ")#link(<tao-a6dded7a1210bbe6bcc9>)[#text("8")]#text(".")
]

#text("Another way to phrase the conclusion of Exercise ")#link(<tao-4889e6086e60b206ef33>)[#text("32")]#text(" is as the factorisation")

#align(center)[#tao-fit-display[#mitex("\\zeta_{\\mathcal O}(s) = \\zeta(s) L(s,\\chi)")]]

#text("(for ")#mi("{\\text{Re}(s)>1}")#text(" at least), where ")#mi("{\\zeta}")#text(" is the Riemann zeta function, ")#mi("{\\zeta_{\\mathcal O}}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Dedekind_zeta_function")[#text("Dedekind zeta function")]

#align(center)[#tao-fit-display[#mitex("\\zeta_{\\mathcal O}(s) = \\sum_I \\frac{1}{N(I)^s}")]]

#text("where ")#mi("{I}")#text(" ranges over prime ideals, and ")#mi("{L(s,\\chi)}")#text(" is the Dirichlet ")#mi("{L}")#text("-function")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) = \\sum_n \\frac{\\chi(n)}{n^s}.")]]

#text("For instance, in the case of the Gaussian integers ")#mi("{{\\bf Z}[\\sqrt{-1}]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\zeta_{{\\bf Z}[\\sqrt{-1}]}(s) = \\zeta(s) L(s,\\chi_4).")]]

#heading(level: 1)[#strong[#text(" — 4. Connection with quadratic forms — ")]]

#text("Let us say that two ideals ")#mi("{I, J}")#text(" are ")#emph[#text("equivalent")]#text(" if one has ")#mi("{I = z \\cdot J}")#text(" for some ")#mi("{z \\in {\\bf Q}(\\sqrt{-d})}")#text(". This is clearly an equivalence relation; the equivalence class of ")#mi("{{\\mathcal O}}")#text(" is simply the class of principal ideals. Using unique factorisation (and the fact that every ideal divides a principal ideal), the space of such equivalence classes is a group, called the ")#link("http://en.wikipedia.org/wiki/Ideal_class_group")[#text("class group")]#text(" of the ring of integers ")#mi("{{\\mathcal O}}")#text(".")#linebreak()#text(" One can analyse this class group by associating a positive definite quadratic form ")#mi("{Q_I: I \\rightarrow {\\bf Z}_{\\geq 0}}")#text(" to each ideal ")#mi("{I}")#text(", by the formula")

#align(center)[#tao-fit-display[#mitex("Q_I(n) := N(n) / N(I)")]]

#text("for all ")#mi("{n \\in I}")#text(". Note that ")#tao-math("{Q_I(n) = \\left| I / (n) \\right|}", block: false)#text(" for ")#mi("{n \\neq 0}")#text(", and so ")#mi("{Q_I}")#text(" takes values in the non-negative integers (and is strictly positive for non-zero ")#mi("{n}")#text("). Since ")#mi("{N(n)}")#text(" is a quadratic form in ")#mi("{n}")#text(", we see that ")#mi("{Q_I}")#text(" is a quadratic form on ")#mi("{I}")#text(".")#linebreak()#text(" We call two quadratic forms ")#mi("{Q_I: I \\rightarrow {\\bf Z}}")#text(", ")#mi("{Q_J: J \\rightarrow {\\bf Z}}")#text(" ")#emph[#text("equivalent")]#text(" if there is an additive group isomorphism ")#mi("{\\phi: I \\rightarrow J}")#text(" such that ")#mi("{Q_I(n) = Q_J( \\phi(n) )}")#text(" for all ")#mi("{n \\in I}")#text(". This relation captures the equivalence relation on ideals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Let ")#mi("{I, J}")#text(" be ideals. Show that ")#mi("{Q_I}")#text(" and ")#mi("{Q_J}")#text(" are equivalent if and only if ")#mi("{I, J}")#text(" are equivalent.")
]

#text("A quadratic form ")#mi("{Q: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" on the standard lattice ")#mi("{{\\bf Z}^2}")#text(" is of the form ")#mi("{Q(x,y) = ax^2 + bxy + cy^2}")#text(" for some integers ")#mi("{a,b,c}")#text(". The ")#link("http://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" of this quadratic form is defined to be ")#mi("{b^2-4ac}")#text(". This is an invariant with respect to invertible linear transformations of ")#mi("{{\\bf Z}^2}")#text(". Thus, given any other quadratic form ")#mi("{Q_I: I \\rightarrow {\\bf Z}}")#text(" on a rank two lattice ")#mi("{I}")#text(", one can define the discriminant of ")#mi("{Q_I}")#text(" by identifying ")#mi("{I}")#text(" with ")#mi("{{\\bf Z}^2}")#text(" via a linear isomorphism; it is clear that this definition does not depend on the choice of isomorphism. It turns out that the quadratic form of all ideals have the same discriminant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{I}")#text(" be an ideal. Show that ")#mi("{Q_I}")#text(" has discriminant ")#mi("{D}")#text(". (")#emph[#text("Hint:")]#text(" if one identifies ")#mi("{{\\mathcal O}}")#text(" with ")#mi("{{\\bf Z}^2}")#text(", show that ")#mi("{I}")#text(" takes the form ")#mi("{T {\\bf Z}^2}")#text(" for some linear transformation ")#mi("{T: {\\bf Z}^2 \\rightarrow {\\bf Z}^2}")#text(" of determinant ")#mi("{N(I)}")#text(", and use this to show that ")#mi("{Q_I}")#text(" has the same discriminant as ")#mi("{Q_{{\\mathcal O}}}")#text(".)")
]

#text("From Exercise ")#link(<tao-d4f568b800c6a61b3ba2>)[#text("7")]#text(" we see that the class group of ")#mi("{{\\mathcal O}}")#text(" is finite. The order of this group is known as the ")#link("http://en.wikipedia.org/wiki/Ideal_class_group")[#text("class number")]#text(" and will be denoted ")#mi("{h=h(D)}")#text(".")#linebreak()#text(" In the converse direction, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 36")]#text(" Let ")#mi("{Q: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" be a positive definite quadratic form of discriminant ")#mi("{D}")#text(". Then there exists an ideal ")#mi("{I}")#text(" such that ")#mi("{Q_I}")#text(" is equivalent to ")#mi("{Q}")#text(".")
]

#text("In particular, the class group is in one-to-one correspondence with the equivalence classes of positive definite quadratic forms ")#mi("{Q: {\\bf Z}^2 \\rightarrow {\\bf Z}}")#text(" of a given discriminant, a famous result of Gauss. In particular, the group law on the class group induces the ")#emph[#text("Gauss composition law")]#text(" on equivalence classes of quadratic forms of a given discriminant.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We perform some ")#emph[#text("ad hoc")]#text(" computations in the case ")#mi("{d=1,2\\ (4)}")#text(". If ")#mi("{Q(x,y) = ax^2 + bxy + c y^2}")#text(", then ")#mi("{b^2-4ac = D}")#text(" and ")#mi("{a,c > 0}")#text(", which makes ")#mi("{b}")#text(" even. One may verify that the set")

#align(center)[#tao-fit-display[#mitex("I := \\{ 2ax - y (-b-\\sqrt{D}): x,y \\in {\\bf Z} \\}")]]

#text("is an additive subgroup of ")#mi("{{\\mathcal O}}")#text(" that is also closed under multiplication by ")#mi("{\\frac{-b+\\sqrt{D}}{2}}")#text(", and is thus an ideal; one may also calculate its norm to be ")#mi("{4a}")#text(", with")

#align(center)[#tao-fit-display[#mitex("N( 2ax - y (-b-\\sqrt{D}) ) = 4a Q(x,y)")]]

#text("for ")#mi("{x,y \\in {\\bf Z}}")#text(". This implies that ")#mi("{Q_I}")#text(" is equivalent to ")#mi("{Q}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Complete the proof of the lemma by treating the ")#mi("{d=3\\ (4)}")#text(" case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" ")#metadata(none) <tao-0889113e04d3203f0c40>#text(" Show that ")#mi("{x^2+5y^2}")#text(" and ")#mi("{2x^2+2xy+3y^2}")#text(" are inequivalent quadratic forms of discriminant ")#mi("{-20}")#text(", and that all other quadratic forms of this discriminant are equivalent to one of these two forms.")
]

#text("Now we relate the distribution of norms of ideals to representation by quadratic forms.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 39")]#text(" Let ")#mi("{n}")#text(" be a natural number, and let ")#mi("{Q_1,\\dots,Q_h}")#text(" be representatives of the equivalence classes of positive definite quadratic forms of discriminant ")#mi("{D}")#text(". Then the number of ideals ")#mi("{I}")#text(" with ")#mi("{N(I) = n}")#text(" is equal to the number of representations of ")#mi("{n}")#text(" of the form ")#mi("{Q_i(x,y)}")#text(" for some ")#mi("{i=1,\\dots,h}")#text(" and ")#mi("{x,y \\in {\\bf Z}}")#text(", divided by the number ")#mi("{w}")#text(" of units (i.e. ")#mi("{4}")#text(" if ")#mi("{d=1}")#text(", ")#mi("{6}")#text(" if ")#mi("{d=3}")#text(", or ")#mi("{2}")#text(" otherwise, thanks to Exercise ")#link(<tao-c981a30c0e7b420b0ba5>)[#text("5")]#text(").")
]

#emph[#text("Proof:")]#text(" Suppose we can write ")#mi("{n = Q_i(x,y)}")#text(" for some ")#mi("{i=1,\\dots,h}")#text(" and ")#mi("{x,y \\in {\\bf Z}}")#text(". By construction, ")#mi("{Q_i}")#text(" is isomorphic to ")#mi("{Q_J}")#text(" for some ideal ")#mi("{J = J_i}")#text(", and so we can write ")#mi("{n = Q_J(m)}")#text(" for some ")#mi("{m \\in J}")#text(", thus ")#mi("{N(m) = n N(J)}")#text(". By unique factorisation, we may write ")#mi("{(m) = I \\cdot J}")#text(" for some ideal ")#mi("{I}")#text(" of norm ")#mi("{n}")#text(". Note that if we replace ")#mi("{i}")#text(" with a different index, then ")#mi("{J = J_i}")#text(" is replaced with an inequivalent ideal, and then so is ")#mi("{I}")#text(". On the other hand, if we keep ")#mi("{i}")#text(" fixed and replace ")#mi("{x,y}")#text(" with some ")#mi("{x^{\\prime},y^{\\prime}}")#text(", thus also replacing ")#mi("{m}")#text(" with some ")#mi("{m^{\\prime} \\in J}")#text(", then we also change ")#mi("{I}")#text(" to a different ideal unless ")#mi("{(m) = (m^{\\prime})}")#text(", or equivalently if ")#mi("{m^{\\prime}}")#text(" differs from ")#mi("{m}")#text(" by a unit, in which case ")#mi("{I}")#text(" is unchanged. Thus we have a map from representations ")#mi("{n = Q_i(x,y)}")#text(" with ")#mi("{i=1,\\dots,h}")#text(" and ")#mi("{x,y \\in {\\bf Z}}")#text(" to ideals of norm ")#mi("{n}")#text(" whose multiplicity is exactly equal to the number ")#mi("{w}")#text(" of units.")#linebreak()#text(" To conclude the proposition, we need to show that every ideal ")#mi("{I}")#text(" of norm ")#mi("{n}")#text(" arises in this fashion. But by Lagrange’s theorem, ")#mi("{N(I)=n}")#text(" lies in ")#mi("{I}")#text(", and then ")#mi("{Q_I(n) = n}")#text(", giving the claim. ")#mi("\\Box")#linebreak()#text(" We can then give an elementary asymptotic for the norm of ideals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 40")]#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{I: N(I) \\leq x} 1 = \\frac{2\\pi h(D)}{w \\sqrt{\\left|D\\right|}} x + O_D( \\sqrt{x} )", block: true)]]

#text("for ")#mi("{x>1}")#text(", where ")#mi("{w \\in \\{2,4,6\\}}")#text(" is the number of units.")
]

#emph[#text("Proof:")]#text(" By the preceding proposition, the left-hand side can be written as")

#align(center)[#tao-fit-display[#mitex("1 + \\frac{1}{w} \\sum_{i=1}^{h(D)} \\sum_{a,b \\in {\\bf Z}: Q_i(a,b) \\leq x} 1.")]]

#text("The inner sum is the number of lattice points in the ellipse ")#mi("{\\{ (a,b) \\in {\\bf Z}^2: Q_i(a,b) \\leq x \\}}")#text(", which has area ")#tao-math("{\\frac{2\\pi x}{\\sqrt{\\left|D\\right|}}}", block: false)#text(" by Exercise ")#link(<tao-ca8562efd622e1a625af>)[#text("6")]#text(", since ")#mi("{Q_i}")#text(" has discriminant ")#mi("{D}")#text(". If one places a unit square centred at each such lattice point, one obtains a region that differs from the ellipse by a set of area ")#mi("{O_D(\\sqrt{x})}")#text(" (since the difference set is contained in a ")#mi("{O(1)}")#text("-neighbourhood of the boundary of the ellipse). The claim follows. ")#mi("\\Box")#linebreak()#text(" This, combined with Exercise ")#link(<tao-4889e6086e60b206ef33>)[#text("32")]#text(", gives a special case of the famous ")#link("http://en.wikipedia.org/wiki/Class_number_formula")[#text("Dirichlet class number formula")]#text(", generalising Exercise ")#link(<tao-2f60014f825fa20dbc56>)[#text("9")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Dirichlet class number formula)")]#text(" Show that")

#align(center)[#tao-fit-display[#tao-math("\\zeta_{\\mathcal O}(s) = \\frac{2\\pi h(D)}{w \\sqrt{\\left|D\\right|}} \\frac{1}{s-1} + O_D(1)", block: true)]]

#text("for ")#mi("{s>1}")#text(" sufficiently close to ")#mi("{1}")#text(", and then conclude that")

#align(center)[#tao-fit-display[#tao-math("h(D) = \\frac{w \\sqrt{\\left|D\\right|}}{2\\pi} L(1,\\chi).", block: true)]]
]

#text("In particular, since the class number ")#mi("{h(D)}")#text(" is clearly at least one, we obtain a “trivial” lower bound")

#align(center)[#tao-fit-display[#tao-math("L(1,\\chi) \\geq \\frac{2\\pi}{w \\sqrt{\\left|D\\right|}} \\gg \\frac{1}{\\sqrt{d}}.", block: true)]]

#text("This looks weaker than ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel’s bound")]

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) \\gg_\\varepsilon d^{-\\varepsilon}")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(" (which we will discuss in later notes), but a key difference is that the trivial bound has effective constants, whereas Siegel’s bound is ineffective. The best effective bound currently known on ")#mi("{L(1,\\chi)}")#text(" only improves on the trivial bound by a logarithmic factor, and involves quite deep and difficult mathematics relating to elliptic curves; see ")#link("http://www.ams.org/mathscinet-getitem?mr=788386")[#text("this survey of Goldfeld")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 42")]#text(" ")#metadata(none) <tao-0531a5a9dfcab00993f8>#text(" Most of the above discussion also extends to the rings of integers in real quadratic fields ")#mi("{{\\bf Q}(\\sqrt{d})}")#text(" of positive discriminant, with a few changes; for instance, there are now infinitely many units, quadratic integers may now have negative norm, and the field is now embedded (in two different ways) into ")#mi("{{\\bf R}}")#text(" rather than into ")#mi("{{\\bf C}}")#text(". The ellipses of Exercise ")#link(<tao-ca8562efd622e1a625af>)[#text("6")]#text(" become hyperbolae, which creates a logarithmic correction term (known as a ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_unit_theorem#The_regulator")[#text("regulator")]#text(") in the class number formula. We leave the detailed modifications needed to the interested reader. It turns out that every real Dirichlet character will essentially arise from a quadratic field (of either positive or negative discriminant); see Chapters 5, 6 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1790423")[#text("Davenport")]#text(" for details. One can also consider higher degree number fields than quadratic fields; again, much of the above theory carries through in this case, but the characters ")#mi("{\\chi}")#text(" that then emerge are not necessarily Dirichlet characters, but lie instead in the more general class of ")#link("http://en.wikipedia.org/wiki/Hecke_character")[#text("Hecke characters")]#text(". We will not discuss this more general theory here, but see for instance the book of ")#link("http://www.ams.org/mathscinet-getitem?mr=1215934")[#text("Fröhlich and Taylor")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 43")]#text(" There is an important connection between class groups and abelian extensions of fields (an abelian version of the connection between Galois groups and arbitrary extensions of fields), known as ")#link("http://en.wikipedia.org/wiki/Class_field_theory")[#text("class field theory")]#text(", but we will not discuss this topic further in this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{d}")#text(" be a rational prime with ")#mi("{d = 3\\ (4)}")#text(", thus generating a quadratic field ")#mi("{{\\bf Q}(\\sqrt{-d})}")#text(" of discriminant ")#mi("{D := -d}")#text(" and the associated ring of integers ")#mi("{{\\mathcal O}}")#text(".")

#list(
[#text("(i) Show that for any rational integer ")#mi("{x}")#text(" with ")#mi("{-\\frac{d-7}{4} \\leq x \\leq \\frac{d-3}{4}}")#text(", that the only solutions to the equation")

#align(center)[#tao-fit-display[#mitex("N(a + b \\frac{1+\\sqrt{-d}}{2}) = x^2 - x + \\frac{d+1}{4}")]]

#text("are ")#mi("{(a,b) = (x,-1), (-x,1), (x-1,1), (1-x,-1)}")#text(".")],
[#text("(ii) Suppose further that the class number ")#mi("{h(D)}")#text(" is ")#mi("{1}")#text(", that is to say that ")#mi("{{\\mathcal O}}")#text(" is a principal ideal domain. Conclude that ")#mi("{x^2 + x + \\frac{d+1}{4}}")#text(" is prime for all rational integers ")#mi("{-\\frac{d-7}{4} \\leq x \\leq \\frac{d-3}{4}}")#text(". (The converse statement is also true, a result of Rabinovitch.) For instance, the discriminant ")#mi("{D = -163}")#text(" is known to have class number one, giving Euler’s famous ")#link("http://en.wikipedia.org/wiki/Formula_for_primes#Prime_formulas_and_polynomial_functions")[#text("prime-generating polynomial")]#text(" ")#mi("{x^2-x+41}")#text(", which gives primes for ")#mi("{x=1,\\dots,40}")#text(", as well as Legendre’s variant ")#mi("{x^2+x+41}")#text(", which gives primes for ")#mi("{x=0,\\dots,39}")#text(". (This also generates some of the lines in ")#link("http://en.wikipedia.org/wiki/Ulam_spiral")[#text("Ulam’s spiral")]#text(".) Unfortunately, ")#mi("{163}")#text(" is the largest value of ")#mi("{d}")#text(" with this property, thanks to the ")#link("http://en.wikipedia.org/wiki/Stark%E2%80%93Heegner_theorem")[#text("Stark-Heegner theorem")]#text(".")]
)
]

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443221")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("Reblogged this on ")#link("http://tomcircle.wordpress.com/2014/11/30/254a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3f2f59c2d058f04eea57f24b9a0e8291fe8e8b471ad7a42fc8de27e6374848a-b7c16998b888ce84da886084967aa4c5122dc0319d1a15dcf3bfcff7fc049410.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443279")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2014")])]

#text("The algebraic numbers don’t embed into the p-adics.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443832")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("If I recall, ")#mi("\\mathbb{C}_p \\not \\simeq \\mathbb{C}")#text(" – isomorphic as fields, but not as normed spaces. This always confused me. ")#link("http://ncatlab.org/nlab/show/p-adic+complex+number")[#text("http://ncatlab.org/nlab/show/p-adic+complex+number")]#text(" ")#link("http://math.stackexchange.com/questions/338148/is-there-an-explicit-embedding-from-the-various-fields-of-p-adic-numbers-mathb")[#text("http://math.stackexchange.com/questions/338148/is-there-an-explicit-embedding-from-the-various-fields-of-p-adic-numbers-mathb")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5431199321ac4c25c1c037555b684e9d0babaa93bee4a78edeb9447b6d631a4-1cf84735aa42a310356593e37d31b7492d501e6fc5cb9c80d41d3a947fd8dd26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eigenlambda")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443446")[#strong[#text("eigenlambda")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("prime ideals are only proper in rings of low dimension")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5431199321ac4c25c1c037555b684e9d0babaa93bee4a78edeb9447b6d631a4-1cf84735aa42a310356593e37d31b7492d501e6fc5cb9c80d41d3a947fd8dd26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of eigenlambda")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443447")[#strong[#text("eigenlambda")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2014")])]

#text("derp principal sorry :(")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443749")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("I think the area in Exercise 5 is out by a factor of 2.")

#emph[#text("[It looks alright to me – e.g. if ")#mi("Q(x,y) = x^2+y^2")#text(" and ")#mi("X=1")#text(", then ")#mi("D=-4")#text(" and the area is ")#mi("\\pi")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443753")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("Oops.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443754")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("So now I’m doubting myself, but I’m having a hard time following the calculations after the use of the Dirichlet hyperbola method in the proof of Corollary 2. It looks as though the second and third terms are ")#mi("O(\\sqrt {x})")#text(". I don’t see why the first term is ")#mi("xL(1,\\chi_4)")#text(" though.")

#emph[#text("[Oops, there was a typo in one of the estimates needed to justify this first term; ")#mi("\\sum_{d \\leq \\sqrt{x}} \\chi_4(d) = L(1,\\chi_4) + O(1/\\sqrt{x})")#text(" should be ")#mi("\\sum_{d \\leq \\sqrt{x}} \\chi_4(d)/d = L(1,\\chi_4) + O(1/\\sqrt{x})")#text(". Hopefully this resolves the issue – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443755")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("In Exercise 7, the summation is over ")#mi("\\mathbf Z")#text(", not ")#mi("\\mathbf Z[\\sqrt{-1}]")#text(", right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443766")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2014")])]

#text("When defining the product of two ideals, the issue is that they may not be closed under addition (not multiplication) isn’t it?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e422ee6bacb820b822c4839cfad16bc676bf2be23665de0f25010ac8603a4a5-06dcf982b6352c520eeee605437a0e4c423addea5372530ac487d648bf3727e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MeromorphicFunction")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443908")[#strong[#text("MeromorphicFunction")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("Is there a straightforward explanation, in your view, to classify whether a number theoretic question would be amenable to analytic techniques, or where algebraic theory would be a better approach?")

#text("It is ‘obvious’ that Sato-Tate belongs in the realm of algebraic number theory whilst issues of gaps between primes fall into the analytic landscape, but I can’t express why in words.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-443923")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2014")])]

#text("A good question! Broadly, I’d say that algebraic techniques are strongest when there is a lot of algebraic structure present in the problem, and analytic techniques are strongest when there is a lot of exploitable “mixing” (e.g. Dirichlet convolutions or additive convolutions, or (preferably) both). For instance, when trying to count representations as the sum of two squares, one should definitely use the algebraic structure of the Gaussian integers, but when trying to count representations as the sum of five or more squares, there is so much additive convolution going on that analytic methods become much more effective. (Four squares is an interesting borderline case in which one needs a mix of methods to get good results.)")

#text("In a separate direction, analytic methods tend to be best at finding solutions to equations in which we expect to have quite a large number of solutions (e.g. the expected number of solutions of height up to X is some power of X). Such methods are much worse at finding solutions when the solution set is expected to be very sparse (e.g. logarithmic in the height), or to show that there are no solutions at all (although they can sometimes be used to show that the existence of one solution repels other solutions, giving a finiteness theorem on the number of solutions without an effective bound on heights). For instance, I see no plausible path to using analytic methods to prove Fermat’s last theorem, though perhaps one could use those methods to prove enough of Faltings’ theorem (say) to show that the number of solutions for a fixed exponent is finite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-450032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("A is much larger buts its inside Q…?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-450034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("+1…larger than the other Q, got it, plus one for being an idiot")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27b9bb2a3d46462670fcc10f5f29f33587adcdd963553f103041d2ce10bdb03a-5e0e81c578e0408b260f40b98bf5d9f693f7088cf214246c9f1d807bb0262e03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Hughes")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-450646")[#strong[#text("Martin Hughes")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("Has anyone ever tried to use wave theory to understand prime numbers? If you list all the numbers not excluded from being prime by 2 & 3 – i.e 6n-1 numbers in one column and 6n+1 numbers in the other – you get zigzag lines that could be thought of as waves between the columns.")

#text("The relation between the rows in these columns and the number is really neat. 5 has frequency of 5 rows and the wave is made up of a 3 down and then a 2. 7 has a 5 down then a 2. the waves – expressed as rows down – always relate to the numbers and so too to the combinations. The combined wave of 5 & 7 has a frequency. all the frequencies over 5 & 7 have a frequency defined in terms of 6n+-1 numbers.")

#text("There are many other patterns such as the two potential twin primes on each row share the same even number in their wave frequency. Each successive number has the previous one as its other wave part. we don’t need to sieve out the numbers that get hit by these waves since they don’t affect the pattern.")

#text("We just have to decide when we want to know if a particular number is prime and see what the wave theory tells us. numbers with lots of divisors show up as higher than those with less. primes will always have the same hight to their wave, their square will always have twice the height, and cubes three quarter the height. They look just like waves so why not treat them as such? I am not a maths wiz so I imagine that there is some reason why this is a ridiculous suggestion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-450647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2015")])]

#text("In a sense, yes: the main mathematical tool to analyse waves is Fourier analysis, which is also one of the major tools used to analyse the prime numbers, in effect treating the prime numbers (or proxies for the prime numbers, such as the von Mangoldt function) as a wave. This Fourier analysis can be done with respect to additive spacings between primes (leading to the Hardy-Littlewood circle method, which does indeed capture such phenomena as the primes being mostly supported on the numbers ")#mi("6n \\pm 1")#text(") or multiplicative spacings between primes (leading to the theory of the Riemann zeta function). The latter is sometimes referred to as the “music of the primes”, which again invokes a wave analogy (sound waves, in this case); for instance, the zeroes of the Riemann zeta function can be thought of as the “notes” in the “music” that the primes comprise (the mathematical formalisation of this statement is known as the ")#emph[#text("explicit formula")]#text(").")

#text("However, a major problem with either of these approaches to prime number theory is that they have difficulty handling the “noisy” part of the wave – in the additive approach this contribution is known as the “minor arc” contribution, and in the multiplicative approach this corresponds to the contribution of the bulk of the non-trivial zeroes of the zeta function. This noise also obscures what is going on in the late stages of sieving processes such as the sieve of Eratosthenes; we understand pretty well what happens when we sieve out multiples of (say) 2, 3, 5 from the natural numbers up to ")#mi("x")#text(" when trying to isolate (say) twin primes, but the process of sieving out the multiples between, say, ")#mi("x^{1/3}")#text(" and ")#mi("x^{1/2}")#text(" is much less well understood. One can make some pseudorandomness hypotheses about this “noise” which leads to predictions in analytic theory that look quite convincing (for instance giving asymptotics for the density of twin primes that agrees very well with numerics), but unfortunately fall short of a rigorous argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A wave equation approach to automorphic forms in analytic number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-458176")[#strong[#text("A wave equation approach to automorphic forms in analytic number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2015")])]

#text("[…] one (this fact is equivalent to the unique factorisation of the gaussian integers, as discussed in this previous post), every form in this space is equivalent (under the action of some element of ) with the standard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-517105")[#strong[#text("Fermat Primes and the Gauss-Wantzel Theorem - AMSI Vacation Research Scholarships 2018/19")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-&#8230")[#text("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab82efe8db2841454b1457793a9953a5a2a37cfd671dc7a9b01203b83c318270-25487a2c0a8940e06137563ee9850144e03d4637018ec997716042f03779ecb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiang Yu")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-601123")[#strong[#text("Xiang Yu")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2020")])]

#text("Line 2 of the proof of Proposition 21: It states that “Noting that ")#mi("x\\cdot \\mathfrak{p}")#text(" is an ideal dividing ")#mi("\\mathfrak{p}")#text("“. I do not understand how can we conclude this from the previous lemma. In Lemma 19, ")#mi("x")#text(" is defined as ")#mi("\\frac{a}{n}")#text(", so ")#mi("x\\cdot \\mathfrak{p}")#text(" dividing ")#mi("\\mathfrak{p}")#text(" means that ")#mi("a\\mathfrak{p}\\supset n\\mathfrak{p}")#text(", which seems not obvious in the proof of Lemma 19. Could you explain a little bit more on the problem? Thanks")

#text("Line 7 of the proof of Proposition 24: There might be a typo. I think it should be “quadratic integer ")#mi("b")#text(" such that ")#mi("b=n\\ \\text{mod}\\ \\mathfrak{p}^{j+1}")#text("“.")

#emph[#text("[Corrected, thanks. One should have worked with ")#mi("x \\cdot \\mathfrak{p} + \\mathfrak{p}")#text(" rather than ")#mi("x \\cdot \\mathfrak{p}")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f680d6065b871d86ea59304a47fa11d01d4c98420243df99780c7e65066572bd-d1e10746ec1254ecd362392a7ec6eebe4f94143890139bd0da21465438ad5a88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Prendiville")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-629790")[#strong[#text("Sean Prendiville")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2021")])]

#text("Thanks for another great introduction!")

#text("Regarding §2 (Unique factorisation of ideals):")

#text("In this section, it would be good to caveat which results are specific to the particular rings in which we are working. For example, Exercise 16 is specific to the context (not all non-zero prime ideals are maximal in general commutative rings), whilst the preamble before Lemma 15 emphasises that this result holds in general. As written, it is not clear which facts hold in general commutative rings, and this could be confusing for a beginner (at least it was for me!).")

#text("Additional pedantic comment: some of the results of §2 require the prime ideal to be non-zero.")

#emph[#text("[Post updated to incorporate suggestions, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/#comment-635693")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] to various finite groups of number-theoretic importance, such as the class groups discussed in Supplement 1, there are also heuristics of Cohen-Lenstra type. Historically, the first heuristic discussion of […]")
]
