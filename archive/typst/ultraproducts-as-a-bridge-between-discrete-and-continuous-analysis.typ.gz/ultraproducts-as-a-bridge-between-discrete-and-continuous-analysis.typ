// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:37:17.456752+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ultraproducts as a Bridge Between Discrete and Continuous Analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 December 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("(This is an extended blog post version of my talk “")#link("http://simons.berkeley.edu/talks/terry-tao-2013-12-04")[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis")]#text("” that I gave at the ")#link("http://simons.berkeley.edu/")[#text("Simons institute for the theory of computing")]#text(" at the workshop “")#link("http://simons.berkeley.edu/workshops/realanalysis2013-3")[#text("Neo-Classical methods in discrete analysis")]#text("“. Some of the material here is drawn from previous blog posts, notably “")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("Ultraproducts as a bridge between hard analysis and soft analysis")]#text("” and “")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("Ultralimit analysis and quantitative algebraic geometry")]#text("“‘. The text here has substantially more details than the talk; one may wish to skip all of the proofs given here to obtain a closer approximation to the original talk.)")

#text("Discrete analysis, of course, is primarily interested in the study of ")#emph[#text("discrete")]#text(" (or “finitary”) mathematical objects: integers, rational numbers (which can be viewed as ratios of integers), finite sets, finite graphs, finite or discrete metric spaces, and so forth. However, many powerful tools in mathematics (e.g. ergodic theory, measure theory, topological group theory, algebraic geometry, spectral theory, etc.) work best when applied to ")#emph[#text("continuous")]#text(" (or “infinitary”) mathematical objects: real or complex numbers, manifolds, algebraic varieties, continuous topological or metric spaces, etc. In order to apply results and ideas from continuous mathematics to discrete settings, there are basically two approaches. One is to directly discretise the ")#emph[#text("arguments")]#text(" used in continuous mathematics, which often requires one to keep careful track of all the bounds on various quantities of interest, particularly with regard to various error terms arising from discretisation which would otherwise have been negligible in the continuous setting. The other is to construct continuous objects as ")#emph[#text("limits")]#text(" of sequences of discrete objects of interest, so that results from continuous mathematics may be applied (often as a “black box”) to the continuous limit, which then can be used to deduce consequences for the original discrete objects which are quantitative (though often ineffectively so). The latter approach is the focus of this current talk.")

#text("The following table gives some examples of a discrete theory and its continuous counterpart, together with a limiting procedure that might be used to pass from the former to the latter:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("(Discrete)")],
table.cell(colspan: 1, rowspan: 1)[#text("(Continuous)")],
table.cell(colspan: 1, rowspan: 1)[#text("(Limit method)")],
table.cell(colspan: 1, rowspan: 1)[#text("Ramsey theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Topological dynamics")],
table.cell(colspan: 1, rowspan: 1)[#text("Compactness")],
table.cell(colspan: 1, rowspan: 1)[#text("Density Ramsey theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Ergodic theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Furstenberg correspondence principle")],
table.cell(colspan: 1, rowspan: 1)[#text("Graph/hypergraph regularity")],
table.cell(colspan: 1, rowspan: 1)[#text("Measure theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Graph limits")],
table.cell(colspan: 1, rowspan: 1)[#text("Polynomial regularity")],
table.cell(colspan: 1, rowspan: 1)[#text("Linear algebra")],
table.cell(colspan: 1, rowspan: 1)[#text("Ultralimits")],
table.cell(colspan: 1, rowspan: 1)[#text("Structural decompositions")],
table.cell(colspan: 1, rowspan: 1)[#text("Hilbert space geometry")],
table.cell(colspan: 1, rowspan: 1)[#text("Ultralimits")],
table.cell(colspan: 1, rowspan: 1)[#text("Fourier analysis")],
table.cell(colspan: 1, rowspan: 1)[#text("Spectral theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Direct and inverse limits")],
table.cell(colspan: 1, rowspan: 1)[#text("Quantitative algebraic geometry")],
table.cell(colspan: 1, rowspan: 1)[#text("Algebraic geometry")],
table.cell(colspan: 1, rowspan: 1)[#text("Schemes")],
table.cell(colspan: 1, rowspan: 1)[#text("Discrete metric spaces")],
table.cell(colspan: 1, rowspan: 1)[#text("Continuous metric spaces")],
table.cell(colspan: 1, rowspan: 1)[#text("Gromov-Hausdorff limits")],
table.cell(colspan: 1, rowspan: 1)[#text("Approximate group theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Topological group theory")],
table.cell(colspan: 1, rowspan: 1)[#text("Model theory")]
)

#text("As the above table illustrates, there are a variety of different ways to form a limiting continuous object. Roughly speaking, one can divide limits into three categories:")

#list(
[#strong[#text("Topological and metric limits")]#text(". These notions of limits are commonly used by analysts. Here, one starts with a sequence (or perhaps a ")#link("http://en.wikipedia.org/wiki/Net_(topology)")[#text("net")]#text(") of objects ")#mi("{x_n}")#text(" in a common space ")#mi("{X}")#text(", which one then endows with the structure of a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological space")]#text(" or a ")#link("http://en.wikipedia.org/wiki/Metric_space")[#text("metric space")]#text(", by defining a notion of distance between two points of the space, or a notion of open neighbourhoods or open sets in the space. Provided that the sequence or net is convergent, this produces a limit object ")#mi("{\\lim_{n \\rightarrow \\infty} x_n}")#text(", which remains in the same space, and is “close” to many of the original objects ")#mi("{x_n}")#text(" with respect to the given metric or topology.")],
[#strong[#text("Categorical limits")]#text(". These notions of limits are commonly used by algebraists. Here, one starts with a sequence (or more generally, a ")#link("http://en.wikipedia.org/wiki/Diagram_(category_theory)")[#text("diagram")]#text(") of objects ")#mi("{x_n}")#text(" in a ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(" ")#mi("{X}")#text(", which are connected to each other by various ")#link("http://en.wikipedia.org/wiki/Morphism")[#text("morphisms")]#text(". If the ambient category is well-behaved, one can then form the ")#link("http://en.wikipedia.org/wiki/Direct_limit")[#text("direct limit")]#text(" ")#mi("{\\operatorname*{\\underset{\\textstyle\\rightarrow}{lim}} x_n}")#text(" or the ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit")]#text(" ")#mi("{\\operatorname*{\\underset{\\textstyle\\leftarrow}{lim}} x_n}")#text(" of these objects, which is another object in the same category ")#mi("{X}")#text(", and is connected to the original objects ")#mi("{x_n}")#text(" by various morphisms.")],
[#strong[#text("Logical limits")]#text(". These notions of limits are commonly used by model theorists. Here, one starts with a sequence of objects ")#mi("{x_{\\bf n}}")#text(" or of spaces ")#mi("{X_{\\bf n}}")#text(", each of which is (a component of) a model for given (first-order) mathematical language (e.g. if one is working in the language of groups, ")#mi("{X_{\\bf n}}")#text(" might be groups and ")#mi("{x_{\\bf n}}")#text(" might be elements of these groups). By using devices such as the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" construction, or the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(" in logic, one can then create a new object ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" or a new space ")#mi("{\\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(", which is still a model of the same language (e.g. if the spaces ")#mi("{X_{\\bf n}}")#text(" were all groups, then the limiting space ")#mi("{\\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" will also be a group), and is “close” to the original objects or spaces in the sense that any assertion (in the given language) that is true for the limiting object or space, will also be true for many of the original objects or spaces, and conversely. (For instance, if ")#mi("{\\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" is an abelian group, then the ")#mi("{X_{\\bf n}}")#text(" will also be abelian groups for many ")#mi("{{\\bf n}}")#text(".)")]
)

#text("The purpose of this talk is to highlight the third type of limit, and specifically the ultraproduct construction, as being a “universal” limiting procedure that can be used to replace most of the limits previously mentioned. Unlike the topological or metric limits, one does not need the original objects ")#mi("{x_{\\bf n}}")#text(" to all lie in a common space ")#mi("{X}")#text(" in order to form an ultralimit ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text("; they are permitted to lie in different spaces ")#mi("{X_{\\bf n}}")#text("; this is more natural in many discrete contexts, e.g. when considering graphs on ")#mi("{{\\bf n}}")#text(" vertices in the limit when ")#mi("{{\\bf n}}")#text(" goes to infinity. Also, no convergence properties on the ")#mi("{x_{\\bf n}}")#text(" are required in order for the ultralimit to exist. Similarly, ultraproduct limits differ from categorical limits in that no morphisms between the various spaces ")#mi("{X_{\\bf n}}")#text(" involved are required in order to construct the ultraproduct.")

#text("With so few requirements on the objects ")#mi("{x_{\\bf n}}")#text(" or spaces ")#mi("{X_{\\bf n}}")#text(", the ultraproduct construction is necessarily a very “soft” one. Nevertheless, the construction has two very useful properties which make it particularly useful for the purpose of extracting good continuous limit objects out of a sequence of discrete objects. First of all, there is ")#link("http://en.wikipedia.org/wiki/Łos%27s_Theorem")[#text("Łos’s theorem")]#text(", which roughly speaking asserts that any first-order sentence which is asymptotically obeyed by the ")#mi("{x_{\\bf n}}")#text(", will be ")#emph[#text("exactly")]#text(" obeyed by the limit object ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text("; in particular, one can often take a discrete sequence of “partial counterexamples” to some assertion, and produce a continuous “complete counterexample” that same assertion via an ultraproduct construction; taking the contrapositives, one can often then establish a rigorous equivalence between a quantitative discrete statement and its qualitative continuous counterpart. Secondly, there is the ")#link("http://en.wikipedia.org/wiki/Saturated_model")[#text("countable saturation")]#text(" property that ultraproducts automatically enjoy, which is a property closely analogous to that of compactness in topological spaces, and can often be used to ensure that the continuous objects produced by ultraproduct methods are “complete” or “compact” in various senses, which is particularly useful in being able to upgrade qualitative (or “pointwise”) bounds to quantitative (or “uniform”) bounds, more or less “for free”, thus reducing significantly the burden of “epsilon management” (although the price one pays for this is that one needs to pay attention to which mathematical objects of study are “standard” and which are “nonstandard”). To achieve this compactness or completeness, one sometimes has to restrict to the “bounded” portion of the ultraproduct, and it is often also convenient to quotient out the “infinitesimal” portion in order to complement these compactness properties with a matching “Hausdorff” property, thus creating familiar examples of continuous spaces, such as locally compact Hausdorff spaces.")

#text("Ultraproducts are not the only logical limit in the model theorist’s toolbox, but they are one of the simplest to set up and use, and already suffice for many of the applications of logical limits outside of model theory. In this post, I will set out the basic theory of these ultraproducts, and illustrate how they can be used to pass between discrete and continuous theories in each of the examples listed in the above table.")

#text("Apart from the initial “one-time cost” of setting up the ultraproduct machinery, the main loss one incurs when using ultraproduct methods is that it becomes very difficult to extract explicit quantitative bounds from results that are proven by transferring qualitative continuous results to the discrete setting via ultraproducts. However, in many cases (particularly those involving regularity-type lemmas) the bounds are already of tower-exponential type or worse, and there is arguably not much to be lost by abandoning the explicit quantitative bounds altogether.")

#metadata(none) <tao-81ba74ab3b59960ef472>

#heading(level: 1)[#strong[#text(" — 1. Basic theory — ")]]

#text("To set up the machinery of ultraproducts (and nonstandard analysis) we will need to pick a ")#emph[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(" on the natural numbers ")#mi("{{\\bf N} = \\{1,2,\\ldots\\}}")#text(". By definition, this is a collection ")#mi("{\\alpha}")#text(" of subsets of the natural numbers ")#mi("{{\\bf N}}")#text(" that obeys the following axioms:")

#list(
[#text("(i) ")#mi("{\\alpha}")#text(" contains ")#mi("{{\\bf N}}")#text(", but does not contain ")#mi("{\\emptyset}")#text(".")],
[#text("(ii) If ")#mi("{A \\subset {\\bf N}}")#text(" is in ")#mi("{\\alpha}")#text(", then any subset of ")#mi("{{\\bf N}}")#text(" containing ")#mi("{A}")#text(" is in ")#mi("{\\alpha}")#text(".")],
[#text("(iii) If ")#mi("{A, B}")#text(" lie in ")#mi("{\\alpha}")#text(", then ")#mi("{A \\cap B}")#text(" also lies in ")#mi("{\\alpha}")#text(".")],
[#text("(iv) If ")#mi("{A \\subset {\\bf N}}")#text(", then exactly one of ")#mi("{A}")#text(" and ")#mi("{{\\bf N} \\backslash A}")#text(" lies in ")#mi("{\\alpha}")#text(".")],
[#text("(v) No finite set lies in ")#mi("{\\alpha}")#text(".")]
)

#text("A collection that obeys axioms (i)-(iii) is a ")#link("http://en.wikipedia.org/wiki/Filter_(mathematics)")[#text("filter")]#text(", a collection that obeys (i)-(iv) is an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(", and a collection that obeys (i)-(v) is a ")#emph[#text("non-principal ultrafilter")]#text(". (One can certainly build ultrafilters on other sets than the natural numbers ")#mi("{{\\bf N}}")#text(", but for the type of applications we have in mind, ultrafilters on ")#mi("{{\\bf N}}")#text(" are generally sufficient, much as how one can largely rely on sequences ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" instead of nets ")#mi("{(x_a)_{a \\in A}}")#text(" when using considering topological or metric notions of a limit in concrete applications.)")

#text("If ")#mi("{\\alpha}")#text(" is an ultrafilter, a subset ")#mi("{A}")#text(" of ")#mi("{{\\bf N}}")#text(" is said to be ")#emph[#mi("{\\alpha}")#text("-large")]#text(" if it lies in ")#mi("{\\alpha}")#text(", and ")#emph[#mi("{\\alpha}")#text("-small otherwise")]#text(". To emphasise the limit interpretation of ultrafilters, we will also use “for ")#mi("{n}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("” as a synonym for “for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text("“. Note from the above axioms that if ")#mi("{{\\bf N}}")#text(" is partitioned into finitely many components, then exactly one of these components is ")#mi("{\\alpha}")#text("-large. One can thus think of an ultrafilter as a voting protocol, which converts the preferences of a countably infinite number of voters (indexed by the natural numbers) amongst a finite number of candidates into a “winner”, namely the candidate who amasses an ")#mi("{\\alpha}")#text("-large set of votes; this voting protocol obeys all the hypotheses of ")#link("http://en.wikipedia.org/wiki/Arrow%27s_theorem")[#text("Arrow’s theorem")]#text(" (rationality, independence of irrelevant alternatives, etc.) but not its conclusion (there are no dictators), due to the infinite number of voters. One can also view an ultrafilter as a finitely additive, ")#mi("{\\{0,1\\}}")#text("-valued probability measure on the natural numbers, in which every subset of ")#mi("{{\\bf N}}")#text(" is measurable.")

#text("Every natural number ")#mi("{n}")#text(" defines a ")#emph[#text("principal ultrafilter")]#text(" ")#mi("{\\bar{n}}")#text(" (that is, an ultrafilter that does not obey axiom (v)), defined by setting ")#mi("{A \\in \\bar{n}}")#text(" if and only if ")#mi("{n \\in A}")#text(". By abuse of notation, we may identify ")#mi("{\\bar{n}}")#text(" with ")#mi("{n}")#text(", so that the set of principal ultrafilters is identified with ")#mi("{{\\bf N}}")#text(". The set of all ultrafilters (principal and non-principal) is denoted ")#mi("{\\beta {\\bf N}}")#text(", and may be identified with the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Cech compactification")]#text(" of the natural numbers; this space has a number of interesting structures on it (for instance, it is a left-continuous topological semigroup, which is a useful fact in Ramsey theory and topological dynamics, as discussed in ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("this previous post")]#text("), but we will ")#emph[#text("not")]#text(" discuss these structures further here. In particular, the use of ultrafilters in establishing correspondence principles between discrete and continuous structures is ")#emph[#text("unrelated")]#text(" to the use of ultrafilters (particularly minimal or idempotent ultrafilters) in Ramsey theory and topological dynamics that is discussed in that previous post. (However, it is certainly possible to use both types of ultrafilters in separate places for a single application; see ")#link("https://terrytao.wordpress.com/2012/11/28/multiple-recurrence-in-quasirandom-groups/")[#text("this paper of Bergelson and myself")]#text(" for an example.)")

#text("The existence of a non-principal ultrafilter ")#mi("{\\alpha}")#text(" can be guaranteed by an application of ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" (basically by running the transfinite version of a greedy algorithm to build the collection of ")#mi("{\\alpha}")#text("-large and ")#mi("{\\alpha}")#text("-small sets):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" There exists a non-principal ultrafilter ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(".")
]

#emph[#text("Proof:")]#text(" Define the ")#link("http://en.wikipedia.org/wiki/Frechet_filter")[#text("Frechet filter")]#text(" ")#mi("{F}")#text(" to be the collection of all the cofinite subsets of ")#mi("{{\\bf N}}")#text(", that is to say those subsets of ")#mi("{{\\bf N}}")#text(" whose complement is finite. This is a filter. A routine application of Zorn’s lemma shows that this filter must be contained in at least one maximal filter ")#mi("{\\alpha}")#text(". If ")#mi("{\\alpha}")#text(" is not an ultrafilter, then there is a set ")#mi("{E}")#text(" which is neither ")#mi("{\\alpha}")#text("-large or ")#mi("{\\alpha}")#text("-small; if we then let ")#mi("{\\alpha^{\\prime}}")#text(" be the filter generated by ")#mi("{\\alpha}")#text(" and ")#mi("{E}")#text(" (that is, ")#mi("{\\alpha^{\\prime}}")#text(" consists of those subsets of ")#mi("{{\\bf N}}")#text(" that either lie in ")#mi("{\\alpha}")#text(", or contain the intersection of ")#mi("{E}")#text(" with an ")#mi("{\\alpha}")#text("-large set), then one checks that ")#mi("{\\alpha^{\\prime}}")#text(" is a filter that is strictly larger than ")#mi("{\\alpha}")#text(", contradicting the maximality of ")#mi("{\\alpha}")#text(". Thus ")#mi("{\\alpha}")#text(" is an ultrafilter; since it contains ")#mi("{F}")#text(", it is non-principal as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument relied upon the axiom of choice. One can construct ultrafilters using slightly weaker set-theoretic axioms than the axiom of choice (e.g. the ")#link("http://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem")[#text("Boolean prime ideal theorem")]#text("), but if one has no choice-like axioms whatsoever (or more precisely, one uses just the axioms ZF of ")#link("http://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory")[#text("Zermelo-Fraenkel set theory")]#text(") then the existence of non-principal ultrafilters is undecidable. However, there is a ")#link("http://www.ncbi.nlm.nih.gov/pmc/articles/PMC1077160/")[#text("result of Gödel")]#text(" that asserts that if a result is finitary in the sense that it can be phrased as a first-order statement in Peano Arithmetic, and it can be proven using the axiom of choice (or more precisely in ZFC set theory), then it can also be proven without the axiom of choice (i.e. in ZF set theory). In practical terms, this means that one can ignore the reliance on the axiom of choice for any finitary application of ultraproduct methods. Alternatively, instead of using Zorn’s lemma to construct a genuine ultrafilter, it is often possible (though messy) to build some sort of “partial” or “incomplete” ultrafilter which is still close enough to an ultrafilter to prove a desired result, but which does not need the full strength of the axiom of choice to construct. We will not discuss such methods here, but see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1650475")[#text("this paper of Palmgren")]#text(". (See also ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous blog post")]#text(" for a “cheap” version of nonstandard analysis which uses the Frechet filter rather than an ultrafilter.) In any event, we will freely rely on the axiom of choice in the rest of this post.")
]

#text("Henceforth, we select a single non-principal ultrafilter ")#mi("{\\alpha \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(" to use in the rest of the post. The choice of this ultrafilter is highly non-unique (")#mi("{\\beta {\\bf N} \\backslash {\\bf N}}")#text(" is uncountable), but for the purposes of establishing a correspondence between discrete and continuous mathematics, the precise choice of ultrafilter ")#mi("{\\alpha}")#text(" will not be relevant, as long as it is kept fixed throughout the discussion.")

#text("We can use the ultrafilter ")#mi("{\\alpha}")#text(" to form limits of sequences ")#mi("{(x_{\\bf n})_{{\\bf n} \\in {\\bf N}}}")#text(", even if these sequences have no limit in the topological or metric senses. For instance, if ")#mi("{x_{\\bf n} \\in X}")#text(" takes values in a single finite space ")#mi("{X}")#text(" for all natural numbers ")#mi("{{\\bf n}}")#text(", then we can define the ")#emph[#text("ultralimit")]#text(" to be the unique element ")#mi("{x_\\alpha = \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" of ")#mi("{X}")#text(" such that ")#mi("{x_{\\bf n} = x_\\alpha}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("; this element exists and is unique by the ultrafilter axioms (i)-(iv). For instance, the ultralimit ")#mi("{(-1)^\\alpha := \\lim_{{\\bf n} \\rightarrow \\alpha} (-1)^{\\bf n}}")#text(" of the sequence ")#mi("{1,-1,1,-1,\\ldots}")#text(" is either ")#mi("{1}")#text(" or ")#mi("{-1}")#text(", with the former occurring if the even numbers are ")#mi("{\\alpha}")#text("-large, and the latter occurring if the odd numbers are ")#mi("{\\alpha}")#text("-large. So the ultralimit here depends on ")#mi("{\\alpha}")#text(", but once ")#mi("{\\alpha}")#text(" is fixed, the ultralimit is well-defined. One can also view ")#mi("{x_\\alpha = \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" as the outcome of an “election” among candidates in ")#mi("{X}")#text(", in which each “voter” ")#mi("{{\\bf n}}")#text(" has ")#mi("{x_{\\bf n}}")#text(" as a preferred candidate, and the ultrafilter ")#mi("{\\alpha}")#text(" is used as the election protocol. (See ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous post")]#text(" for further discussion of this viewpoint.)")

#text("Now we consider the more general situation in which the ")#mi("{x_{\\bf n}}")#text(" to not lie in a single finite space ")#mi("{X}")#text(", but instead each ")#mi("{x_{\\bf n}}")#text(" lies in a space ")#mi("{X_{\\bf n}}")#text(" which may depend on ")#mi("{{\\bf n}}")#text(", and may also be infinite. Here, there does not necessarily exist a single object ")#mi("{x_\\alpha}")#text(" that is equal to the ")#mi("{x_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". The situation here is similar to that in metric spaces, in that a Cauchy sequence in a metric space ")#mi("{X = (X,d)}")#text(" need not be convergent if the space ")#mi("{X}")#text(" is infinite. In the latter case, the problem can be resolved by constructing the ")#link("http://en.wikipedia.org/wiki/Complete_metric_space#Completion")[#text("metric completion")]#text(" ")#mi("{\\overline{X}}")#text(" of ")#mi("{X}")#text(", which can be defined (slightly non-rigorously) as the space of ")#emph[#text("formal limits")]#text(" ")#mi("{\\lim_{n \\rightarrow \\infty} x_n}")#text(" of Cauchy sequences ")#mi("{x_n}")#text(", with two formal limits ")#mi("{\\lim_{n \\rightarrow \\infty} x_n}")#text(", ")#mi("{\\lim_{n \\rightarrow \\infty} y_n}")#text(" declared to be equal if ")#mi("{d(x_n,y_n)}")#text(" converges to zero (in the classical sense) as ")#mi("{n \\rightarrow \\infty}")#text(". To construct this Cauchy completion rigorous within the framework of set theory, one can define ")#mi("{\\overline{X}}")#text(" to be the set of equivalence classes of tuples ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" of Cauchy sequences in ")#mi("{X}")#text(", with the equivalence relation ")#mi("{(x_n)_{n \\in {\\bf N}} \\sim (y_n)_{n \\in {\\bf N}}}")#text(" holding if and only if ")#mi("{d(x_n,y_n)}")#text(" converges to zero as ")#mi("{n \\rightarrow \\infty}")#text(". In order to view ")#mi("{X}")#text(" as a subset of its completion ")#mi("{\\overline{X}}")#text(", one usually identifies each point ")#mi("{x \\in X}")#text(" with the equivalence class of the corresponding constant sequence ")#mi("{(x)_{n \\in {\\bf N}}}")#text(". With this construction, one can for instance build the real numbers ")#mi("{{\\bf R}}")#text(" as the metric completion of the rationals ")#mi("{{\\bf Q}}")#text(" (and this is indeed one of the most popular ways to construct the reals, which is often covered in undergraduate analysis classes). Note though while one can use this set-theoretic machinery of equivalence classes of Cauchy sequences of rationals to construct the reals, for the purposes of ")#emph[#text("using")]#text(" the real numbers ")#mi("{{\\bf R}}")#text(" for mathematical applications, this set-theoretic construction is not relevant; the only thing one needs to retain is that Cauchy sequences of rationals (or of reals) will converge to a real, and conversely every real is the limit of a Cauchy sequence of rationals.")

#text("We can take a similar tack to construct ultralimits ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" of sequences ")#mi("{x_{\\bf n} \\in X_{\\bf n}}")#text(" in different spaces ")#mi("{X_{\\bf n}}")#text(". If one is willing to be slightly non-rigorous, the definition is almost the same: we can view these ultralimits as formal objects, with two ultralimits ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" and ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} y_{\\bf n}}")#text(" declared to be equal if and only if ")#mi("{x_{\\bf n}=y_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". To do things rigorously within the framework of set theory, one has to take a little extra care to avoid the set-theoretic issues associated to ")#link("http://en.wikipedia.org/wiki/Russell's_paradox")[#text("Russell’s paradox")]#text(" (or more precisely, avoiding the uses of ")#link("http://en.wikipedia.org/wiki/Proper_class")[#text("proper classes")]#text(" that are too large to be sets). One way to deal with this is as follows. One can postulate the existence of a ")#emph[#text("standard universe")]#text(" ")#mi("{{\\mathfrak U}}")#text(" that contains all the objects of interest for one’s particular mathematical problem: for instance, if one is interested in a sequence of groups ")#mi("{G_{\\bf n}}")#text(", then ")#mi("{{\\mathfrak U}}")#text(" might contain all the elements of all of the ")#mi("{G_{\\bf n}}")#text(". The only requirements we make of this standard universe are that (a) it is a set (rather than a proper class), and (b) it is fixed throughout the mathematical discussion. The former requirement means that ")#mi("{{\\mathcal U}}")#text(", in general, cannot contain ")#emph[#text("all")]#text(" spaces of a particular type; for instance, one cannot make ")#mi("{{\\mathcal U}}")#text(" contain ")#emph[#text("all")]#text(" groups, ")#emph[#text("all")]#text(" vector spaces, ")#emph[#text("all")]#text(" graphs, etc., as one would soon run into Russell-type paradoxes if this occurred. However, in practice, for any given mathematical problem (other than those arising within mathematical logic), one usually does not need to work simultaneously with ")#emph[#text("all")]#text(" spaces; usually a much smaller number of spaces, e.g. a countable or uncountable family of such spaces, will suffice. Henceforth we will take the existence of a standard universe ")#mi("{{\\mathfrak U}}")#text(" for granted. Elements of this universe will be referred to as ")#emph[#text("standard objects")]#text(", and subsets of the universe as ")#emph[#text("standard spaces")]#text("; for instance, we will usually place the classical number systems ")#mi("{{\\bf N}, {\\bf Z}, {\\bf R}}")#text(", etc. inside this standard universe, so elements of ")#mi("{{\\bf N}}")#text(" become standard natural numbers, elements of ")#mi("{{\\bf R}}")#text(" become standard reals, and so forth. We then have:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Formal definition of ultralimits and ultraproducts)")]#text(" Let ")#mi("{(x_{\\bf n})_{{\\bf n} \\in E}}")#text(" be a sequence of standard objects, defined for an ")#mi("{\\alpha}")#text("-large set ")#mi("{E}")#text(" (thus ")#mi("{x_{\\bf n} \\in {\\mathfrak U}}")#text(" for all ")#mi("{n \\in E}")#text("). The ")#emph[#text("ultralimit")]#text(" ")#mi("{x_\\alpha = \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" is then defined to be the equivalence class of tuples ")#mi("{(y_{\\bf n})_{{\\bf n} \\in E^{\\prime}}}")#text(" of standard objects defined on an ")#mi("{\\alpha}")#text("-large set ")#mi("{E^{\\prime}}")#text(", such that ")#mi("{x_{\\bf n} = y_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(" in the common domain ")#mi("{E \\cap E^{\\prime}}")#text(" of definition. Such an ultralimit is called a ")#emph[#text("nonstandard object")]#text(", and the set of all ultralimits is called the ")#emph[#text("nonstandard universe")]#text(" ")#mi("{{}^* {\\mathfrak U}}")#text(". We identify every standard object ")#mi("{x}")#text(" with the nonstandard object ")#mi("{\\lim_{{\\bf n} \\rightarrow \\alpha} x}")#text(", thus embedding ")#mi("{{\\mathfrak U}}")#text(" in ")#mi("{{}^* {\\mathfrak U}}")#text(".")

#text("Given a sequence ")#mi("{X_{\\bf n}}")#text(" of standard spaces (i.e. subsets of ")#mi("{{\\mathfrak U}}")#text(") defined for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{X_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" is defined as the set of all ultralimits ")#mi("{\\lim_{{\\bf n} \\rightarrow\\alpha} x_{\\bf n}}")#text(", where ")#mi("{x_{\\bf n}}")#text(" lies in ")#mi("{X_{\\bf n}}")#text(" for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(". Such an ultraproduct (which is a subset of ")#mi("{{}^* {\\mathfrak U}}")#text(") will be called a ")#emph[#text("nonstandard space")]#text(" (also known as an ")#emph[#text("internal space")]#text("). Similarly, the ultraproduct of a sequence of standard groups will be called a nonstandard group (or internal group), the ultraproduct of a sequence of standard fields will be called a nonstandard field (or internal field), and so forth.")

#text("If ")#mi("{X}")#text(" is a standard space, the nonstandard space ")#mi("{\\prod_{{\\bf n} \\rightarrow\\alpha} X}")#text(" (that is, the space of ultralimits of sequences in ")#mi("{X}")#text(") will be called the ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" of ")#mi("{X}")#text(" and is denoted ")#mi("{{}^* X}")#text("; note that ")#mi("{X}")#text(" embeds as a subset of ")#mi("{{}^* X}")#text(". The ultrapower ")#mi("{{}^* {\\bf N}}")#text(" of the standard natural numbers will be referred to as the ")#emph[#text("nonstandard natural numbers")]#text(", the ultrapower ")#mi("{{}^* {\\bf R}}")#text(" of the standard reals will be referred to as the ")#emph[#text("nonstandard real numbers")]#text(" (also known as the ")#link("http://en.wikipedia.org/wiki/Hyperreal_")[#text("umber")]#text("), and so forth.")
]

#text("One can verify that when ")#mi("{X}")#text(" is finite, the ultrapower ")#mi("{{}^* X}")#text(" is equal to ")#mi("{X}")#text(" itself, and that the notion of an ultralimit ")#mi("{\\lim_{{\\bf n} \\rightarrow\\alpha} x_{\\bf n}}")#text(" in the case when all the ")#mi("{x_{\\bf n}}")#text(" lie in ")#mi("{X}")#text(" corresponds to the notion of an ultralimit defined previously.")

#text("The basic ontological Venn diagram is this: the standard universe ")#mi("{{\\mathfrak U}}")#text(" embeds into the larger nonstandard universe ")#mi("{{}^* {\\mathfrak U}}")#text(", and both exist inside the even larger “external universe” of ZFC set theory, which we will not give a name to (it is not a set, but is instead a proper class). This allows us to study various mathematical objects on three different levels: standard, nonstandard, and external. For instance, we have standard groups (groups in ")#mi("{{\\mathfrak U}}")#text(") and nonstandard groups (ultraproducts of groups in ")#mi("{{\\mathfrak U}}")#text("); both are examples of external groups (groups that are somewhere in the external universe), but there are certainly examples of external groups that are neither standard groups nor nonstandard groups. It is also worth cautioning that while we identify standard objects ")#mi("{x}")#text(" with their nonstandard counterparts ")#mi("{\\lim_{{\\bf n} \\rightarrow\\alpha} x}")#text(", we do ")#emph[#text("not")]#text(" identify standard spaces ")#mi("{X}")#text(" with their nonstandard counterparts ")#mi("{{}^* X = \\prod_{{\\bf n} \\rightarrow\\alpha} X}")#text("; in particular, we do not view standard groups as examples of nonstandard groups (except in the finite case), nor do we view standard fields as examples of nonstandard fields, etc. Instead, one can view the nonstandard space ")#mi("{{}^* X}")#text(" as a “completion” of the standard space ")#mi("{X}")#text(", analogous to metric completion; see ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous blog post")]#text(" for further discussion of this perspective. A related perspective is to view ")#mi("{{}^* X}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Double_precision")[#text("double-precision")]#text(" version of ")#mi("{X}")#text(", so for instance ")#mi("{{}^* {\\bf R}}")#text(" can be viewed as the space of “double-precision real numbers” as opposed to the “single-precision” real numbers in ")#mi("{{\\bf R}}")#text(", or similarly ")#mi("{{}^* {\\bf Z}}")#text(" may be viewed as a space of “")#link("http://en.wikipedia.org/wiki/Long_integer")[#text("long integers")]#text("“, with ")#mi("{{\\bf Z}}")#text(" being a space of “short integers”.")

#text("The analogues of standard groups, nonstandard groups, and external groups in finitary mathematics would be “groups ")#mi("{G}")#text(" that do not depend on an asymptotic parameter ")#mi("{n}")#text("“, “groups ")#mi("{G_{\\bf n}}")#text(" that may depend on an asymptotic parameter ")#mi("{{\\bf n}}")#text("“, and “informal group-like objects (such as the “group” of all “bounded” integers ")#mi("{m = O(1)}")#text(") that may require asymptotic notation to define” respectively. The latter concept is hard to pin down rigorously in finitary mathematics, even though the intuition it captures (e.g. that the “set” of “bounded” integers should be closed under addition) is fairly clear; but once one uses ultraproducts to separate the three levels of standard, nonstandard, and external objects, it is possible to make rigorous sense of these sorts of intuitions, as we shall see later.")

#text("Given a sequence ")#mi("{f_{\\bf n}: X_{\\bf n} \\rightarrow Y_{\\bf n}}")#text(" of standard functions between standard sets ")#mi("{X_{\\bf n},Y_{\\bf n}}")#text(" for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(", we define the ")#emph[#text("ultralimit")]#text(" ")#mi("{f_\\alpha = \\lim_{{\\bf n} \\rightarrow\\alpha} f_{\\bf n}}")#text(" of this sequence to be the function ")#mi("{f_\\alpha: X_\\alpha \\rightarrow Y_\\alpha}")#text(" from the nonstandard space ")#mi("{X_\\alpha := \\prod_{{\\bf n} \\rightarrow\\alpha} X_{\\bf n}}")#text(" to the nonstandard space ")#mi("{Y_\\alpha := \\prod_{{\\bf n} \\rightarrow\\alpha} Y_{\\bf n}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("f_\\alpha( \\lim_{{\\bf n} \\rightarrow\\alpha} x_{\\bf n} ) := \\lim_{{\\bf n} \\rightarrow\\alpha} f_{\\bf n}( x_{\\bf n} )")]]

#text("for all sequences ")#mi("{x_{\\bf n}}")#text(" that lie in ")#mi("{X_{\\bf n}}")#text(" for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(". It is easy to see that this ultralimit is well-defined; we refer to such functions as ")#emph[#text("nonstandard functions")]#text(".")

#text("From the above construction, we may now transfer operations and relations on standard spaces to their nonstandard counterparts. For instance, if ")#mi("{G_{\\bf n}}")#text(" is a sequence of standard groups, then one can take the ultralimit of the multiplication operations ")#mi("{\\cdot_{\\bf n}: G_{\\bf n} \\times G_{\\bf n} \\rightarrow G_{\\bf n}}")#text(" to obtain a multiplication operation ")#mi("{\\cdot_\\alpha: G_\\alpha \\times G_\\alpha \\rightarrow G_\\alpha}")#text(" on the ultraproduct ")#mi("{G_\\alpha := \\prod_{{\\bf n} \\rightarrow\\alpha} G_{\\bf n}}")#text("; similarly, the inversion operation on ")#mi("{G_{\\bf n}}")#text(" gives rise to an inversion operation on ")#mi("{G_\\alpha}")#text(". Similarly, the arithmetic operations on the standard natural numbers ")#mi("{{\\bf N}}")#text(" can be transferred to arithmetic operations on the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(", and properties and relations on the natural numbers can similarly be transferred. For instance, a nonstandard number ")#mi("{N = \\lim_{{\\bf n} \\rightarrow\\alpha} N_{\\bf n}}")#text(" can be said to be prime if the ")#mi("{N_{\\bf n}}")#text(" are prime for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text(" (i.e. the ultralimit of the truth value of “")#mi("{N_{\\bf n}}")#text(" is prime” is true); one nonstandard number ")#mi("{N = \\lim_{{\\bf n} \\rightarrow\\alpha} N_{\\bf n}}")#text(" can be said to be larger than another ")#mi("{M = \\lim_{{\\bf n} \\rightarrow\\alpha} M_{\\bf n}}")#text(" if one has ")#mi("{N_{\\bf n} > M_{\\bf n}}")#text(" for an ")#mi("{\\alpha}")#text("-large set of ")#mi("{n}")#text("; and so forth.")

#text("One can then check by hand that statements that are true for standard objects are also true for their nonstandard counterparts. For instance, because the group operations of the standard groups ")#mi("{G_{\\bf n}}")#text(" are associative, the group operation on the nonstandard group ")#mi("{G_\\alpha}")#text(" is also associative, and in fact ")#mi("{G_\\alpha}")#text(" will also be a group (as viewed externally). Similarly, addition and multiplication in the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(" obey the usual commutative, associative, and distributive laws, because these transfer from the corresponding laws for the standard natural numbers ")#mi("{{\\bf N}}")#text(". For a more topical example, ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("it is now a theorem")]#text(" that given any standard natural number ")#mi("{N}")#text(", there exist standard primes ")#mi("{p,q}")#text(" such that ")#mi("{N < p < q \\leq p+600}")#text("; it is an instructive exercise to check that the same result then automatically holds in the nonstandard setting, thus for every nonstandard natural number ")#mi("{N}")#text(" there exist nonstandard primes ")#mi("{p,q}")#text(" such that ")#mi("{N < p < q \\leq p+600}")#text(".")

#text("These facts are special cases of the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(", and can be formalised by ")#emph[#text("Łos’s theorem")]#text(". Informally, this theorem asserts that if an “elementary” sentence holds for (an ")#mi("{\\alpha}")#text("-large subsequence of) a sequence of standard objects, then it also holds in the ultralimit, and conversely. To make this assertion rigorous, we need some of the notation from first-order logic; this is somewhat formal and the reader may wish to skim briefly over the definitions and proofs that follow. To simplify the discussion, we restrict attention to one-sorted languages, although in practice one often works with ")#link("http://en.wikipedia.org/wiki/Many-sorted_logic")[#text("many-sorted languages")]#text(" instead.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Languages and structures, formal definition)")]#text(" A ")#link("http://en.wikipedia.org/wiki/Signature_(logic)")[#text("signature")]#text(" is a collection of formal operation symbols ")#mi("{O}")#text(" and relation symbols ")#mi("{R}")#text(", each of which is assigned an ")#link("http://en.wikipedia.org/wiki/Arity")[#text("arity")]#text(" ")#mi("{k}")#text(" (a non-negative integer). (For instance, the signature of the language of groups would consist of the ")#mi("{2}")#text("-ary operation ")#mi("{\\cdot}")#text(", the ")#mi("{1}")#text("-ary operation ")#mi("{()^{-1}}")#text(", and the ")#mi("{0}")#text("-ary operation ")#mi("{1}")#text(".) ")#mi("{0}")#text("-ary operations are also known as ")#emph[#text("constant symbols")]#text(". Given a signature and an infinite supply of variable symbols ")#mi("{x}")#text(", define a ")#link("http://en.wikipedia.org/wiki/Term_(mathematics)")[#text("term")]#text(" to be a formal string generated by the following rules:")

#list(
[#text("Every variable symbol ")#mi("{x}")#text(" is a term.")],
[#text("If ")#mi("{O}")#text(" is a ")#mi("{k}")#text("-ary operation and ")#mi("{z_1,\\ldots,z_k}")#text(" are terms, then ")#mi("{O( z_1,\\ldots,z_k )}")#text(" is a term.")]
)

#text("By abuse of notation, we often move operation symbols to more traditional locations, for instance writing ")#mi("{+(x,y)}")#text(" as ")#mi("{(x+y)}")#text(", ")#mi("{\\cdot(x,y)}")#text(" as ")#mi("{(x \\cdot y)}")#text(", etc.. By further abuse of notation, parentheses are usually omitted when there is no loss of ambiguity, e.g. ")#mi("{(x+y)}")#text(" is often abbreviated as ")#mi("{x+y}")#text(".")

#text("A ")#link("http://en.wikipedia.org/wiki/Formula_(mathematical_logic)")[#text("formula")]#text(" ")#mi("{\\phi(x_1,\\ldots,x_m)}")#text(" involving some finite number of distinct variable symbols ")#mi("{x_1,\\ldots,x_m}")#text(" (known as the ")#emph[#text("free variables")]#text(" of the formula) for some ")#mi("{m \\geq 0}")#text(" is then a formal string generated by the following rules:")

#list(
[#text("If ")#mi("{R}")#text(" is a ")#mi("{k}")#text("-ary relation and ")#mi("{z_1,\\ldots,z_k}")#text(" are terms which only involve variables from ")#mi("{x_1,\\ldots,x_m}")#text(", then ")#mi("{R(z_1,\\ldots,z_k)}")#text(" is a formula of ")#mi("{x_1,\\ldots,x_m}")#text(".")],
[#text("If ")#mi("{z, z^{\\prime}}")#text(" are terms only involving variables from ")#mi("{x_1,\\ldots,x_m}")#text(", then ")#mi("{(z=z^{\\prime})}")#text(" is a formula with free variables ")#mi("{x_1,\\ldots,x_m}")#text(".")],
[#text("If ")#mi("{\\varphi = \\varphi(x_1,\\ldots,x_{\\bf n}), \\psi = \\psi(x_1,\\ldots,x_m)}")#text(" are formulae with free variables ")#mi("{x_1,\\ldots,x_m}")#text(", then ")#mi("{(\\neg \\varphi), (\\varphi \\wedge \\psi), (\\varphi \\vee \\psi), (\\varphi \\implies \\psi)}")#text(", and ")#mi("{(\\varphi \\iff \\psi)}")#text(" are formulae with free variables ")#mi("{x_1,\\ldots,x_m}")#text(".")],
[#text("If ")#mi("{\\varphi = \\varphi(x_1,\\ldots,x_m,x)}")#text(" is a formula with free variables ")#mi("{x_1,\\ldots,x_m,x}")#text(" (or some permutation thereof), then ")#mi("{(\\forall x: \\varphi)}")#text(" and ")#mi("{(\\exists x: \\varphi)}")#text(" are formulae with free variables ")#mi("{x_1,\\ldots,x_m}")#text(".")]
)

#text("A formula with no free variables is known as a ")#link("http://en.wikipedia.org/wiki/Sentence_(mathematical_logic)")[#text("sentence")]#text(". As before, we abuse notation by moving relation symbols to more traditional locations, e.g. writing ")#mi("{<(x,y)}")#text(" as ")#mi("{(x < y)}")#text(", and by removing parentheses whenever there is no loss of ambiguity; we also permit concatenation of quantifiers, for instance abbreviating ")#mi("{(\\forall x: (\\forall y: \\varphi(x,y)))}")#text(" as ")#mi("{\\forall x,y: \\varphi(x,y)}")#text(". Thus, for instance, in the language of the natural numbers,")

#align(center)[#tao-fit-display[#mitex("\\exists p,q: n = p+q \\wedge \\neg (\\exists a,b > 1: p=ab) \\wedge \\neg (\\exists c,d > 1: q=cd)")]]

#text("is a formula of one variable ")#mi("{n}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\forall n > 2: (\\exists m: n=2m) \\implies")]]

#align(center)[#tao-fit-display[#mitex("(\\exists p,q: n = p+q \\wedge \\neg (\\exists a,b > 1: p=ab) \\wedge \\neg (\\exists c,d > 1: q=cd))")]]

#text("is a sentence (which, in this case, encodes the ")#link("http://en.wikipedia.org/wiki/Goldbach_conjecture")[#text("even Goldbach conjecture")]#text(").")

#text("We refer to the collection ")#mi("{{\\mathcal L}}")#text(" of such formulae as the ")#emph[#text("first-order language")]#text(" (or ")#emph[#text("language")]#text(", for short) associated with the given signature (and to the supply of variable symbols).")

#text("A ")#link("http://en.wikipedia.org/wiki/Structure_(logic)")[#text("structure")]#text(" ")#mi("{M}")#text(" for a first-order language ")#mi("{{\\mathcal L}}")#text(" is a set ")#mi("{M}")#text(", together with a map ")#mi("{O_M: M^k \\rightarrow M}")#text(" for every ")#mi("{k}")#text("-ary operation ")#mi("{O}")#text(", and a boolean relation ")#mi("{R_M: M^k \\rightarrow \\{\\text{true}, \\text{false}\\}}")#text(" for every ")#mi("{k}")#text("-ary relation ")#mi("{R}")#text(". (For instance, a group is a structure for the first-order language of groups.) Any term ")#mi("{z}")#text(" of ")#mi("{n}")#text(" variables ")#mi("{x_1,\\ldots,x_{\\bf n}}")#text(" may be ")#emph[#text("interpreted")]#text(" as a function ")#mi("{z_M: M^{\\bf n} \\rightarrow M}")#text(" by viewing the variable symbols ")#mi("{x_1,\\ldots,x_{\\bf n}}")#text(" as ranging in ")#mi("{M}")#text(", and replacing each operation ")#mi("{O}")#text(" or relation ")#mi("{R}")#text(" with their respective interpretations ")#mi("{O_k, R_k}")#text(". Similarly, any formula ")#mi("{\\phi(x_1,\\ldots,x_{\\bf n})}")#text(" may be interpreted as a function ")#mi("{\\phi_M: M^{\\bf n} \\rightarrow\\{\\text{true}, \\text{false}\\}}")#text(", and in particular any sentence ")#mi("{\\phi}")#text(" is interpreted to be either true or false (and we write ")#mi("{M \\models \\phi}")#text(" if the former occurs), by interpreting quantifiers such as ")#mi("{\\forall x}")#text(" and ")#mi("{\\exists x}")#text(" as quantification over ")#mi("{M}")#text(". (For instance, ")#mi("{\\exists x: \\phi(x,y)}")#text(" is interpreted as true for ")#mi("{y \\in M}")#text(" if there exists ")#mi("{x \\in M}")#text(" such that ")#mi("{\\phi_M(x,y)}")#text(" is true.)")
]

#text("Given a sequence ")#mi("{M_{\\bf n}}")#text(" of standard structures for a given first-order language ")#mi("{{\\mathcal L}}")#text(", we can form the ultraproduct ")#mi("{M_\\alpha := \\prod_{{\\bf n} \\rightarrow\\alpha} M_{\\bf n}}")#text(" in the obvious manner, with the nonstandard interpretations ")#mi("{O_{M_\\alpha}, R_{M_\\alpha}}")#text(" of the operator and relation symbols ")#mi("{O,R}")#text(" being the ultralimits of their standard counterparts. We refer to this ultraproduct as a ")#emph[#text("nonstandard structure")]#text(" for the first-order language ")#mi("{{\\mathcal L}}")#text("; both standard structures and nonstandard structures are examples of external structures, but as remarked before we do not consider standard structures as examples of nonstandard structures (except when the structure is finite).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Łos’s theorem)")]#text(" Let ")#mi("{M_{\\bf n}}")#text(" be a sequence of standard structures for a first-order language ")#mi("{{\\mathcal L}}")#text(", and let ")#mi("{M_\\alpha = \\prod_{{\\bf n} \\rightarrow\\alpha} M_{\\bf n}}")#text(" be the associated nonstandard structure.")

#list(
[#text("(i) If ")#mi("{z}")#text(" is a term involving the variables ")#mi("{x_1,\\ldots,x_m}")#text(", then ")#mi("{z_{M_\\alpha}: M_\\alpha^m\\rightarrow M_\\alpha}")#text(" is the ultralimit of the ")#mi("{z_{M_{\\bf n}}: M_{\\bf n}^m \\rightarrow M_{\\bf n}}")#text(".")],
[#text("(ii) If ")#mi("{\\phi(x_1,\\ldots,x_m)}")#text(" is a formula with free variables ")#mi("{x_1,\\ldots,x_m}")#text(", then ")#mi("{\\phi_{M_\\alpha}: M_\\alpha^m \\rightarrow \\{ \\text{true}, \\text{false} \\}}")#text(" is the ultralimit of ")#mi("{\\phi_{M_{\\bf n}}: M_{\\bf n}^m \\rightarrow \\{ \\text{true}, \\text{false} \\}}")#text(".")],
[#text("(iii) If ")#mi("{\\phi}")#text(" is a sentence, then ")#mi("{M_\\alpha \\models \\phi}")#text(" is true if and only if ")#mi("{M_{\\bf n} \\models \\phi}")#text(" is true for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")]
)
]

#text("Informally, this theorem asserts that first-order logic is continuous with respect to ultralimits.")

#emph[#text("Proof:")]#text(" The claim (i) is obtained by a routine induction on the length of the term ")#mi("{z}")#text(" and the ultrafilter axioms, while the claim (iii) is a consequence of (ii). The claim (ii) is similarly obtained by a routine induction on the length of the formula ")#mi("{\\phi}")#text(" and the ultrafilter axioms; the only non-trivial claim to verify is that if the formula ")#mi("{(x_1,\\ldots,x_m,x) \\mapsto \\phi_{M_\\alpha}(x_1,\\ldots,x_m,x)}")#text(" is the ultralimit of the formulae ")#mi("{(x_1,\\ldots,x_m,x) \\mapsto \\phi_{M_{\\bf n}}(x_1,\\ldots,x_m,x)}")#text(", then the formula ")#mi("{(x_1,\\ldots,x_m) \\mapsto \\exists x \\in M_\\alpha: \\phi_{M_\\alpha}(x_1,\\ldots,x_m,x)}")#text(" is the ultralimit of the formulae ")#mi("{(x_1,\\ldots,x_m) \\mapsto \\exists x \\in M_{\\bf n}: \\phi_{M_{\\bf n}}(x_1,\\ldots,x_m,x)}")#text(", and similarly for the universal quantifier ")#mi("{\\forall}")#text(".")

#text("We just prove the claim for the existential quantifier ")#mi("{\\exists}")#text(", as the claim for ")#mi("{\\forall}")#text(" is similar (and can be deduced from the existential case by rewriting ")#mi("{\\forall x:\\phi}")#text(" in the equivalent form ")#mi("{\\neg( \\exists x: \\neg \\phi) )}")#text(". Suppose first that ")#mi("{x_{i,\\alpha} = \\lim_{{\\bf n} \\rightarrow \\alpha} x_{i,{\\bf n}} \\in M_\\alpha}")#text(" for ")#mi("{i=1,\\ldots,k}")#text(" are such that ")#mi("{\\exists x_{\\bf n} \\in M_{\\bf n}: \\phi_{M_{\\bf n}}(x_{1,{\\bf n}},\\ldots,x_{m,{\\bf n}},x_{\\bf n})}")#text(" holds for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("; by the axiom of choice, we may thus find ")#mi("{x_{\\bf n} \\in M_{\\bf n}}")#text(" such that ")#mi("{\\phi_{M_{\\bf n}}(x_{1,{\\bf n}},\\ldots,x_{m,{\\bf n}},x_{\\bf n})}")#text(" holds for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Taking ultralimits and using the induction hypothesis, we conclude that ")#mi("{\\phi_{M_{\\alpha}}(x_{1,{\\alpha}},\\ldots,x_{m,{\\alpha}},x_{\\alpha})}")#text(" where ")#mi("{x_\\alpha := \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(", so that ")#mi("{\\exists x \\in M_\\alpha: \\phi_{M_\\alpha}(x_{1,\\alpha},\\ldots,x_{m,\\alpha},x_\\alpha)}")#text(" is true. Conversely, suppose that ")#mi("{\\exists x_{\\bf n} \\in M_{\\bf n}: \\phi_{M_\\alpha}(x_{1,{\\bf n}},\\ldots,x_{m, {\\bf n}},x_{\\bf n})}")#text(" fails for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text("; then for any ")#mi("{x_\\alpha = \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" in ")#mi("{M_\\alpha}")#text(", ")#mi("{\\phi_{M_{\\bf n}}(x_{1,{\\bf n}},\\ldots,x_{m, {\\bf n}},x_{\\bf n})}")#text(" fails for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", and hence on taking ultralimits ")#mi("{\\phi_{M_{\\alpha}}(x_{1,{\\alpha}},\\ldots,x_{m, {\\alpha}},x_{\\alpha})}")#text(" fails also, and the claim follows. ")#mi("\\Box")

#text("We now give a classic consequence of Łos’s theorem to logic, namely the countable case of the ")#link("http://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Compactness theorem, countable case)")]#text(" Let ")#mi("{{\\mathcal L}}")#text(" be a first-order language, and let ")#mi("{\\phi_1, \\phi_2, \\ldots}")#text(" be a sequence of sentences. Suppose that for each natural number ")#mi("{{\\bf n}}")#text(", there exists a structure ")#mi("{M_{\\bf n}}")#text(" for ")#mi("{{\\mathcal L}}")#text(" such that ")#mi("{\\phi_1,\\ldots,\\phi_{{\\bf n}}}")#text(" are satisfied by this structure. Then there exists a structure ")#mi("{M}")#text(" such that ")#mi("{\\phi_1,\\phi_2,\\ldots}")#text(" are simultaneously satisfied by this structure.")
]

#text("The general case of the compactness theorem may be established by using ultraproducts on more general sets than the natural numbers; we leave the verification of this fact to the reader.")

#emph[#text("Proof:")]#text(" We select the standard universe ")#mi("{{\\mathfrak U}}")#text(" to contain all of the ")#mi("{M_{\\bf n}}")#text(", so that the ")#mi("{M_{\\bf n}}")#text(" are all standard structures. If we then set ")#mi("{M}")#text(" to be the nonstandard structure ")#mi("{\\prod_{{\\bf n} \\rightarrow \\alpha} M_{\\bf n}}")#text(", the claim follows from Łos’s theorem. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Rank decompositions — ")]]

#text("We can now give a simple example of how ultralimits may be used to connect quantitative finitary statements to qualitative infinitary statements, by giving an easy case of the ")#emph[#text("polyomial regularity lemma")]#text(", introduced ")#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("by Ben Green and myself")]#text(". Given a finite-dimensional vector space ")#mi("{V}")#text(" over a field ")#mi("{{\\bf F}}")#text(" and a natural number ")#mi("{d}")#text(", we define a polynomial ")#mi("{P: V \\rightarrow {\\bf F}}")#text(" of degree at most ")#mi("{d}")#text(" on ")#mi("{V}")#text(" to be a function of the form")

#align(center)[#tao-fit-display[#mitex("P( x_1 e_1 + \\ldots + x_n e_n ) = \\sum_{i_1,\\ldots,i_n \\geq 0: i_1+\\ldots+i_n \\leq d} c_{i_1,\\ldots,i_n} x_1^{i_1} \\ldots x_n^{i_n}")]]

#text("for any basis ")#mi("{e_1,\\ldots,e_n}")#text(" of ")#mi("{V}")#text(" and some coefficients ")#mi("{c_{i_1,\\ldots,i_n} \\in F}")#text("; it is easy to see that the choice of basis is irrelevant for this definition. If ")#mi("{V}")#text(" is infinite dimensional instead of finite dimensional, we say that ")#mi("{P: V \\rightarrow F}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(" if its restriction to any finite-dimensional subspace is still a polynomial of degree at most ")#mi("{d}")#text(". The space of such polynomials will be denoted ")#mi("{\\text{Poly}_d(V)}")#text("; this is itself a vector space over ")#mi("{{\\bf F}}")#text(".")

#text("If ")#mi("{P \\in \\text{Poly}_d(V)}")#text(" for some ")#mi("{d \\geq 2}")#text(", we define the ")#emph[#text("rank")]#text(" ")#mi("{\\text{rank}_{d-1}(P)}")#text(" to be the least integer ")#mi("{m}")#text(" such that we can find ")#mi("{Q_1,\\ldots,Q_m \\in \\text{Poly}_{d-1}(V)}")#text(" such that ")#mi("{P}")#text(" is a function of the ")#mi("{Q_1,\\ldots,Q_m}")#text(", that is to say there exists a function ")#mi("{f: {\\bf F}^m \\rightarrow {\\bf F}}")#text(" such that ")#mi("{P(x) = f(Q_1(x),\\ldots,Q_m(x))}")#text(" for all ")#mi("{x \\in V}")#text(". When ")#mi("{V}")#text(" is finite-dimensional, the rank is necessarily finite (just take ")#mi("{Q_1,\\ldots,Q_m}")#text(" to be the coordinate functions), but the rank may be infinite when ")#mi("{V}")#text(" is infinite dimensional. This notion of rank is analogous to the notion of the rank of a quadratic form (which is essentially the ")#mi("{d=2}")#text(" case of the above notion).")

#text("We then have the following simple fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Polynomial regularity lemma)")]#text(" ")#metadata(none) <tao-ae4a3092e16d599057c9>#text(" Let ")#mi("{a \\geq 0}")#text(" be a non-negative integer, and let ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" be a function. Then there exists a constant ")#mi("{C = C_{a,F}}")#text(" with the following properties: for any ")#mi("{d \\geq 2}")#text(", any vector space ")#mi("{V}")#text(" over a field ")#mi("{{\\bf F}}")#text(", and any polynomials ")#mi("{P_1,\\ldots,P_a \\in \\text{Poly}_d(V)}")#text(", there exists polynomials ")#mi("{Q_1,\\ldots,Q_b \\in \\text{Poly}_d(V)}")#text(" for some ")#mi("{0 \\leq b \\leq a}")#text(" and a quantity ")#mi("{1 \\leq M \\leq C}")#text(" with the following properties:")

#list(
[#text("(i) (Representation modulo low rank) For each ")#mi("{1 \\leq i \\leq a}")#text(", there exists a representation ")#mi("{P_i = \\sum_{j=1}^b c_{ij} Q_j + E_i}")#text(", where ")#mi("{c_{ij} \\in {\\bf F}}")#text(" and ")#mi("{\\text{rank}_{d-1}(E_i) \\leq M}")#text(".")],
[#text("(ii) (Independence modulo low rank) For every ")#mi("{c_1,\\ldots,c_b \\in {\\bf F}}")#text(", not all zero, we have ")#mi("{\\text{rank}_{d-1}(\\sum_{j=1}^b c_j Q_j) \\geq F(M)}")#text(".")]
)
]

#text("(In applications, one actually needs an iterated version of this lemma, in which the degree ")#mi("{d-1}")#text(" polynomials involved in ")#mi("{E_i}")#text(" are themselves regularised in terms of high rank or lower degree polynomials, and so on and so forth down to the linear polynomials; for simplicity we will not discuss this iterated version here, but see the above-mentioned paper of Ben and myself for more discussion.)")

#text("The standard proof of this lemma is not difficult, and can be described by the following algorithm:")

#list(
[#text("(Step 0) Initialise ")#mi("{a=b}")#text(", ")#mi("{Q_j = P_j}")#text(" for ")#mi("{j=1,\\ldots,b}")#text(", and ")#mi("{M = 1}")#text(".")],
[#text("(Step 1) If property (ii) holds then STOP. Otherwise, move on to Step 2.")],
[#text("(Step 2) By the failure of (ii), and by permuting the ")#mi("{Q_j}")#text(" if necessary, we may write ")#mi("{Q_b}")#text(" as a linear combination of ")#mi("{Q_1,\\ldots,Q_{b-1}}")#text(", plus a polynomial of rank at most ")#mi("{F(M)}")#text(". If we then delete ")#mi("{Q_b}")#text(", we see that every ")#mi("{P_i}")#text(" is still a linear combination of ")#mi("{Q_1,\\ldots,Q_{b-1}}")#text(", plus an error of rank at most ")#mi("{M+F(M)}")#text(".")],
[#text("(Step 3) Replace ")#mi("{b}")#text(" by ")#mi("{b-1}")#text(" (thus deleting ")#mi("{Q_b}")#text("), replace ")#mi("{M}")#text(" by ")#mi("{M+F(M)}")#text(", and return to Step 1.")]
)

#text("Since ")#mi("{b}")#text(" decreases by one at each loop of the algorithm, it loops at most ")#mi("{a}")#text(" times, and the claim follows.")

#text("The above quantitative lemma can be deduced instead from the following basic fact in linear algebra, a variant of the ")#link("http://en.wikipedia.org/wiki/Steinitz_exchange_lemma")[#text("Steinitz exchange lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-22472b38d8d4c4fe1228>#text(" Let ")#mi("{v_1,\\ldots,v_a}")#text(" be a finite collection of vectors in a vector space ")#mi("{W}")#text(". Then there exists a linearly independent set of vectors ")#mi("{w_1,\\ldots,w_b}")#text(" in ")#mi("{W}")#text(" for some ")#mi("{b \\leq a}")#text(" such that each ")#mi("{v_i}")#text(" is a linear combination of the ")#mi("{w_j}")#text(".")
]

#text("Indeed, one just sets ")#mi("{w_1,\\ldots,w_b}")#text(" to be a basis of the linear span of the ")#mi("{v_1,\\ldots,v_a}")#text(". The ")#mi("{w_1,\\ldots,w_b}")#text(" can also be constructed from the ")#mi("{v_1,\\ldots,v_a}")#text(" by an algorithm extremely similar to the one given above; we leave this to the reader as an exercise.")

#text("From Lemma ")#link(<tao-22472b38d8d4c4fe1228>)[#text("7")]#text(" we immediately obtain a qualitative version of Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Qualitative polynomial regularity lemma)")]#text(" ")#metadata(none) <tao-2ea421bcd5ef7c058db3>#text(" Let ")#mi("{a \\geq 0}")#text(" be a non-negative integer. Then for any ")#mi("{d \\geq 2}")#text(", any vector space ")#mi("{V}")#text(" over a field ")#mi("{{\\bf F}}")#text(", and any polynomials ")#mi("{P_1,\\ldots,P_a \\in \\text{Poly}_d(V)}")#text(", there exists polynomials ")#mi("{Q_1,\\ldots,Q_b \\in \\text{Poly}_d(V)}")#text(" for some ")#mi("{0 \\leq b \\leq a}")#text(" with the following properties:")

#list(
[#text("(i) (Representation modulo low rank) For each ")#mi("{1 \\leq i \\leq a}")#text(", there exists a representation ")#mi("{P_i = \\sum_{j=1}^b c_{ij} Q_j + E_i}")#text(", where ")#mi("{c_{ij} \\in {\\bf F}}")#text(" and ")#mi("{\\text{rank}_{d-1}(E_i) < \\infty}")#text(".")],
[#text("(ii) (Independence modulo low rank) For every ")#mi("{c_1,\\ldots,c_b \\in {\\bf F}}")#text(", not all zero, we have ")#mi("{\\text{rank}_{d-1}(\\sum_{j=1}^b c_j Q_j) = +\\infty}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{W}")#text(" be the set of all polynomials in ")#mi("{\\text{Poly}_d(V)}")#text(" of finite rank; this is clearly a subspace of ")#mi("{\\text{Poly}_d(V)}")#text(", so we may form the quotient space ")#mi("{\\text{Poly}_d(V)/W}")#text(", which is still a vector space over ")#mi("{{\\bf F}}")#text(". If we then apply Lemma ")#link(<tao-22472b38d8d4c4fe1228>)[#text("7")]#text(" to the projection ")#mi("{v_1,\\ldots,v_a}")#text(" of the ")#mi("{P_1,\\ldots,P_a}")#text(" to this quotient space ")#mi("{\\text{Poly}_d(V)/W}")#text(", we obtain the claim. ")#mi("\\Box")

#text("While Corollary ")#link(<tao-2ea421bcd5ef7c058db3>)[#text("8")]#text(" certainly looks very similar to Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(", it appears at first glance that it cannot be used to ")#emph[#text("prove")]#text(" Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(", because the latter lemma has meaningful content when ")#mi("{V}")#text(" is finite-dimensional, whereas the former Corollary is trivial in that setting. However, this can be rectified by passing from the finitary setting to the infinitary setting. This can be done in a number of ways, but we will do this using the ultrafilter machinery just developed.")

#emph[#text("Proof:")]#text(" (Proof of Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(" using Corollary ")#link(<tao-2ea421bcd5ef7c058db3>)[#text("8")]#text(".) We use the “compactness and contradiction” method. Suppose for contradiction that Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(" failed. Carefully negating the quantifiers, and using the axiom of choice, this means that there exists ")#mi("{a \\geq 0}")#text(" and ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(", with the property that for each ")#mi("{{\\bf n}}")#text(", we can find a vector space ")#mi("{V_{\\bf n}}")#text(" over a field ")#mi("{{\\bf F}_{\\bf n}}")#text(" and polynomials ")#mi("{P_{1,{\\bf n}},\\ldots,P_{a,{\\bf n}} \\in \\text{Poly}_d(V_{\\bf n})}")#text(", such that for any ")#mi("{1 \\leq M \\leq {\\bf n}}")#text(", there does NOT exist ")#mi("{0 \\leq b \\leq a}")#text(", ")#mi("{Q_{1,{\\bf n}},\\ldots,Q_{b,{\\bf n}} \\in \\text{Poly}_d(V_{\\bf n})}")#text(", obeying the properties (i), (ii) of Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(" with the given data.")

#text("We may place all of the objects just constructed in a standard universe ")#mi("{{\\mathfrak U}}")#text(". Taking ultralimits (and using Łos’s theorem repeatedly), we obtain a nonstandard field ")#mi("{{\\bf F}_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} {\\bf F}_{\\bf n}}")#text(", a nonstandard vector space ")#mi("{V_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} V_{\\bf n}}")#text(" over that field, polynomials ")#mi("{P_{1,{\\bf \\alpha}},\\ldots,P_{a,{\\bf \\alpha}} \\in \\text{Poly}_d(V_\\alpha)}")#text(", with the property that for any standard integer ")#mi("{M \\geq 1}")#text(", there does NOT exist ")#mi("{0 \\leq b \\leq a}")#text(", ")#mi("{Q_{1,\\alpha},\\ldots,Q_{b,\\alpha} \\in \\text{Poly}_d(V_\\alpha)}")#text(", obeying the properties (i), (ii) of Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(" with the given data. However, if one applies Corollary ")#link(<tao-2ea421bcd5ef7c058db3>)[#text("8")]#text(", we can find ")#mi("{Q_{1,\\alpha},\\ldots,Q_{b,\\alpha} \\in \\text{Poly}_d(V_\\alpha)}")#text(" obeying the conclusions (i), (ii) of Corollary ")#link(<tao-2ea421bcd5ef7c058db3>)[#text("8")]#text(". This implies the conclusions (i), (ii) of Lemma ")#link(<tao-ae4a3092e16d599057c9>)[#text("6")]#text(" if ")#mi("{M}")#text(" is chosen large enough, giving the required contradiction. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. Saturation and colouring — ")]]

#text("Ultraproducts enjoy a very useful compactness-type property, known as ")#emph[#text("countable saturation")]#text(" (or more precisely, ")#mi("{\\omega_1}")#text("-saturation). This property may be phrased in many ways, but we will use the following version which emphasises the analogy with topological compactness.")

#text("Let ")#mi("{X}")#text(" be a nonstandard set, thus ")#mi("{X = \\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" for some standard sets ")#mi("{X_{\\bf n}}")#text(". We call an ")#emph[#text("internal subset")]#text(" or ")#emph[#text("nonstandard subset")]#text(" of ")#mi("{X}")#text(" to be any subset ")#mi("{Y}")#text(" of ")#mi("{X}")#text(" of the form ")#mi("{Y = \\prod_{{\\bf n} \\rightarrow \\alpha} Y_{\\bf n}}")#text("; by Łos’s theorem we see that ")#mi("{Y_{\\bf n} \\subset X_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". For instance, in the nonstandard natural numbers ")#mi("{{}^* {\\bf N}}")#text(", the nonstandard intervals ")#mi("{[N] := \\{ n \\in {}^* {\\bf N}: n \\leq N \\}}")#text(" are internal sets for any nonstandard natural number ")#mi("{N \\in {}^* {\\bf N}}")#text("; indeed, if ")#mi("{N = \\lim_{{\\bf n} \\rightarrow \\alpha} N_n}")#text(", then ")#mi("{[N]}")#text(" is the ultraproduct of the standard intervals ")#mi("{[N_{\\bf n}]}")#text(". More generally, from Łos’s theorem we see that any subset of ")#mi("{X}")#text(" that is defined by a first-order predicate is an internal set. On the other hand, as we shall see later, the standard natural numbers ")#mi("{{\\bf N}}")#text(" are ")#emph[#text("not")]#text(" an internal subset of ")#mi("{{}^* {\\bf N}}")#text(" (and are thus merely an ")#emph[#text("external")]#text(" subset of ")#mi("{{}^* {\\bf N}}")#text(").")

#text("From Łos’s theorem we see that the internal subsets of a nonstandard set ")#mi("{X}")#text(" form a boolean algebra. We then have the following compactness property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Countable saturation)")]#text(" ")#metadata(none) <tao-69bd0a6aed863b12d486>#text(" Every countable cover of ")#mi("{X}")#text(" by internal sets ")#mi("{E_1,E_2,\\ldots}")#text(" has a finite subcover. Equivalently, if ")#mi("{F_1,F_2,\\ldots}")#text(" are a countable sequence of internal sets such that ")#mi("{F_1 \\cap \\ldots \\cap F_M}")#text(" is non-empty for each ")#mi("{M}")#text(", then ")#mi("{\\bigcap_{m=1}^\\infty F_m}")#text(" is also non-empty.")
]

#text("We remark that if we had used ultraproducts on larger index sets than the natural numbers, then we would be able to obtain stronger saturation properties than countable saturation, although it is never possible to get unlimited saturation (since every point in a nonstandard set ")#mi("{X}")#text(" is an internal set). In model theoretic applications it can be technically convenient to work with an extremely saturated model (e.g. a structure which is saturated up to an ")#link("http://en.wikipedia.org/wiki/Inaccessible_cardinal")[#text("inaccessible cardinal")]#text("), but for most applications outside of logic and set theory, such “monster models” are not necessary, and the more modest device of ultraproducts over countable index sets is often sufficient.")

#emph[#text("Proof:")]#text(" It suffices to prove the second claim, as the former follows by taking complements.")

#text("Write ")#mi("{F_m = \\prod_{{\\bf n} \\rightarrow \\alpha} F_{m,{\\bf n}}}")#text(", then for each ")#mi("{m}")#text(", ")#mi("{\\bigcap_{m=1}^M F_m}")#text(" is the ultraproduct of ")#mi("{\\bigcap_{m=1}^M F_{m,{\\bf n}}}")#text(". In particular, ")#mi("{\\bigcap_{m=1}^M F_{m,{\\bf n}}}")#text(" is non-empty for all ")#mi("{{\\bf n}}")#text(" in an ")#mi("{\\alpha}")#text("-large subset ")#mi("{E_M}")#text(" of the natural numbers. By shrinking the ")#mi("{E_M}")#text(" as necessary we may assume that they are monotone, thus ")#mi("{E_1 \\supset E_2 \\supset \\ldots}")#text(", and such that ")#mi("{E_M}")#text(" does not contain any natural number less than ")#mi("{M}")#text("; in particular, ")#mi("{\\bigcap_{M=1}^\\infty E_M = \\emptyset}")#text(". For any ")#mi("{{\\bf n} \\in E_1}")#text(", let ")#mi("{M_{\\bf n}}")#text(" denote the largest natural number ")#mi("{M}")#text(" such that ")#mi("{{\\bf n} \\in E_M}")#text(", and then let ")#mi("{x_{\\bf n}}")#text(" denote an element of ")#mi("{\\bigcap_{m=1}^{M_{\\bf n}} F_{m,{\\bf n}}}")#text(". Then by construction, for each ")#mi("{m \\geq 1}")#text(", we have ")#mi("{x_{\\bf n} \\in F_{m,{\\bf n}}}")#text(" for all ")#mi("{{\\bf n} \\in E_m}")#text(", and thus the nonstandard object ")#mi("{x := \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n}}")#text(" lies in ")#mi("{F_m}")#text(" for all ")#mi("{m}")#text(", and thus ")#mi("{\\bigcap_{m=1}^\\infty F_m}")#text(" is non-empty as required. ")#mi("\\Box")

#text("This shows for instance that (as claimed previously) ")#mi("{{\\bf N}}")#text(" is not an internal subset of ")#mi("{{}^* {\\bf N}}")#text(", since it can be countably covered by the singleton sets ")#mi("{\\{n\\}}")#text(" for ")#mi("{n \\in {\\bf N}}")#text(" which are internal, but for which no finite cover exists. Among other things, this establishes the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill principle")]#text(": if a nonstandard formula ")#mi("{P: {}^* {\\bf N} \\rightarrow \\{\\text{true},\\text{false}\\}}")#text(" holds for all standard natural numbers, then it must hold for at least one unbounded natural number (defined as a nonstandard natural number that is not a standard natural number).")

#text("Another immediate corollary of the above proposition is that if a nonstandard set ")#mi("{X}")#text(" is covered by a countable sequence ")#mi("{E_1,E_2,\\ldots}")#text(" of internal subsets, then the topology ")#mi("{{\\mathcal F}}")#text(" on ")#mi("{X}")#text(" generated by ")#mi("{E_1,E_2,\\ldots}")#text(" is compact (because it has a countable base of internal susbets, and Proposition ")#link(<tao-69bd0a6aed863b12d486>)[#text("9")]#text(" then gives countable compactness).")

#text("As an application of this compactness observation, we use ultraproducts to illustrate the topological dynamics version of the Furstenberg correspondence principle, that connects Ramsey theory to topological dynamics. More precisely, we consider the following results:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (van der Waerden’s theorem)")]#text(" ")#metadata(none) <tao-e340ddbffe550c8b647b>#text(" For any ")#mi("{k,r \\geq 1}")#text(" there exists ")#mi("{N \\geq 1}")#text(" such that whenever ")#mi("{[N]}")#text(" is partitioned into colour classes ")#mi("{[N] = E_1 \\cup \\ldots \\cup E_r}")#text(", one of the colour classes ")#mi("{E_i}")#text(" contains an arithmetic progression ")#mi("{a, a+n, \\ldots, a+(k-1)n}")#text(" of length ")#mi("{k}")#text(" with some ")#mi("{n>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Topological multiple recurrence)")]#text(" ")#metadata(none) <tao-c58e645ecd409301327e>#text(" Let ")#mi("{X}")#text(" be a non-empty compact topological space, and let ")#mi("{T: X \\rightarrow X}")#text(" be a homeomorphism. Then for any open cover ")#mi("{X = U_1 \\cup \\ldots \\cup U_r}")#text(" of ")#mi("{X}")#text(" and any ")#mi("{k \\geq 1}")#text(", there exists an open set ")#mi("{U_i}")#text(" in this cover, a point ")#mi("{x \\in X}")#text(", and a positive integer ")#mi("{n}")#text(" such that ")#mi("{x, T^n x, \\ldots, T^{(k-1)n} x \\in U_i}")#text(".")
]

#text("It is not difficult to use Theorem ")#link(<tao-e340ddbffe550c8b647b>)[#text("10")]#text(" to establish Theorem ")#link(<tao-c58e645ecd409301327e>)[#text("11")]#text(". Conversely, we will use ultraproducts to show that Theorem ")#link(<tao-c58e645ecd409301327e>)[#text("11")]#text(" implies Theorem ")#link(<tao-e340ddbffe550c8b647b>)[#text("10")]#text(". (We will not prove either of these theorems here, but see e.g. ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("this previous blog post")]#text(" for a proof.)")

#text("Again, we use compactness and contradiction. Suppose for contradiction that Theorem ")#link(<tao-e340ddbffe550c8b647b>)[#text("10")]#text(" failed. Then there exists ")#mi("{k,r \\geq 1}")#text(" such that for any standard ")#mi("{{\\bf n}}")#text(", we may partition ")#mi("{[{\\bf n}]}")#text(" into colour classes ")#mi("{[{\\bf n}] = E_{1,{\\bf n}} \\cup \\ldots E_{r,{\\bf n}}}")#text(", none of which contain any ")#mi("{k}")#text("-term arithmetic progressions. Taking ultraproducts, we obtain a partition ")#mi("{[N] = E_1 \\cup \\ldots E_r}")#text(" of the nonstandard interval ")#mi("{[N]}")#text(" associated to the unbounded natural number ")#mi("{N := \\lim_{{\\bf n} \\rightarrow \\alpha} {\\bf n}}")#text(" into internal colour classes ")#mi("{E_1,\\ldots,E_r}")#text(", none of which contains a nonstandard ")#mi("{k}")#text("-term arithmetic progression.")

#text("Now consider the shifted colour classes ")#mi("{E_i + n \\cap [N]}")#text(" for ")#mi("{n \\in {\\bf Z}}")#text(" and ")#mi("{i=1,\\ldots,r}")#text(". These are a countable family of internal sets that cover ")#mi("{[N]}")#text(", and so by countable saturation, this gives ")#mi("{[N]}")#text(" the structure of a compact topological space.")

#text("We would like to use the shift map ")#mi("{T: x \\mapsto x+1}")#text(" on ")#mi("{[N]}")#text(". Unfortunately, this map is not quite a bijection on ")#mi("{[N]}")#text(". To get around this, we work in the slightly smaller space")

#align(center)[#tao-fit-display[#mitex("X := \\bigcap_{n \\in {\\bf N}} [n, N-n].")]]

#text("A further application of countable saturation reveals that ")#mi("{X}")#text(" is still compact (with the induced topology from ")#mi("{[N]}")#text("). Furthermore, the shift map ")#mi("{T: x \\mapsto x+1}")#text(" can be verified to be a homeomorphism on ")#mi("{X}")#text(", and as ")#mi("{N}")#text(" is unbounded, we see from the overspill principle that ")#mi("{X}")#text(" is non-empty. It is covered by the open sets ")#mi("{E_i \\cap X}")#text(", so by Theorem ")#link(<tao-c58e645ecd409301327e>)[#text("11")]#text(", we can find ")#mi("{x \\in X}")#text(" and a (standard) positive integer ")#mi("{n}")#text(" such that ")#mi("{x, x+n, \\ldots, x+(k-1)n}")#text(" lie in a single ")#mi("{E_i \\cap X}")#text(", thus ")#mi("{E_i}")#text(" contains a non-standard ")#mi("{k}")#text("-term arithmetic progression, giving the required contradiction.")

#heading(level: 1)[#strong[#text(" — 4. Algebraic geometry and ultraproducts — ")]]

#text("Another use of ultraproducts is to provide a bridge between quantitative algebraic geometry and qualitative algebraic geometry. This topic is discussed in detail in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous post")]#text("; we will just give some key results here without proof.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 12 (Algebraic geometry is continuous with respect to ultralimits)")]#text(" Let ")#mi("{k_{\\bf n}}")#text(" be a sequence of algebraically closed fields, let ")#mi("{d \\geq 0}")#text(" be a natural number, and let ")#mi("{V_{\\bf n} \\subset k_{\\bf n}^d}")#text(" be a (standard) affine algebraic set, that is to say the solution set of some finite number of polynomials ")#mi("{P_{1,{\\bf n}}, \\ldots, P_{M,{\\bf n}}: k_{\\bf n}^d \\rightarrow k_{\\bf n}}")#text(". We define the ")#emph[#text("complexity")]#text(" of an algebraic set ")#mi("{V}")#text(" to be the least ")#mi("{M}")#text(" such that ")#mi("{V}")#text(" is cut out by at most ")#mi("{M}")#text(" polynomials, each of degree at most ")#mi("{M}")#text(".")

#text("Then the nonstandard set ")#mi("{V_\\alpha := \\prod_{{\\bf n} \\rightarrow \\alpha} V_{\\bf n}}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic set")]#text(" if and only if the complexity of the ")#mi("{V_{\\bf n}}")#text(" are uniformly bounded for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". Furthermore, if ")#mi("{V_\\alpha}")#text(" is indeed an algebraic set, then:")

#list(
[#text("(Continuity of dimension) The ")#link("http://en.wikipedia.org/wiki/Dimension_of_an_algebraic_variety")[#text("dimension")]#text(" of ")#mi("{V_\\alpha}")#text(" is equal to the dimension of ")#mi("{V_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")],
[#text("(Continuity of irreducibility) ")#mi("{V_\\alpha}")#text(" is irreducible if and only if ")#mi("{V_{\\bf n}}")#text(" is irreducible for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")],
[#text("(Continuity of degree) The ")#link("http://en.wikipedia.org/wiki/Degree_(algebraic_geometry)")[#text("degree")]#text(" of ")#mi("{V_\\alpha}")#text(" is equal to the degree of ")#mi("{V_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(".")]
)
]

#text("A similar statement holds for constructive sets: an ultraproduct ")#mi("{E_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} E_{\\bf n}}")#text(" of constructive sets ")#mi("{E_{\\bf n}}")#text(" is constructive if and only if the original sets have uniformly bounded complexity for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". These claims are proven in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("the previous blog post")]#text("; the basic idea is to express basic concepts such as dimension, irreducibility, and degree in first-order terms, so that Łos’s theorem may be applied.")

#text("Using this theorem and the compactness and contradiction method, one can easily convert a number of qualitative algebraic results into quantitative ones. For instance, it is a basic fact in qualitative algebraic geometry that every algebraic set decomposes into a finite number of irreducible sets. Using the above theorem (and a relationship between degree and complexity), one can then show that the number of such sets is bounded by a quantity depending only on the degree of the original set (and in particular, uniform in the choice of field); again, see ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("the previous blog post")]#text(" for details. Such quantitative bounds can be obtained by other means (for instance, by using the machinery of schemes), but the ultrafilter approach, being so general in nature, requires almost no actual algebraic geometry to set up and use.")

#heading(level: 1)[#strong[#text(" — 5. Metric completion and Gromov-Hausdorff limits — ")]]

#text("We previously gave an analogy between ultraproducts and metric completion. It turns out that this analogy can be made substantially more precise. We first need some basic nonstandard analysis notation. Call a nonstandard real number ")#mi("{x \\in {}^* {\\bf R}}")#text(" ")#emph[#text("bounded")]#text(" if one has ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(" for some standard ")#mi("{C>0}")#text(", and ")#emph[#text("infinitesimal")]#text(" if one has ")#tao-math("{\\left|x\\right| \\leq c}", block: false)#text(" for ")#emph[#text("all")]#text(" standard ")#mi("{c>0}")#text(". For instance, if ")#mi("{N}")#text(" is an unbounded natural number, then ")#mi("{1+\\frac{1}{N}}")#text(" is bounded (but not standard), and ")#mi("{\\frac{1}{N}}")#text(" is infinitesimal. We write ")#mi("{x=O(1)}")#text(" and ")#mi("{x=o(1)}")#text(" to denote the assertions that ")#mi("{x}")#text(" is bounded and infinitesimal respectively.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (Bolzano-Weierstrass theorem)")]#text(" ")#metadata(none) <tao-7bed79fdd7e4907dece0>#text(" If ")#mi("{x}")#text(" is a bounded nonstandard real, then there exists a unique standard real ")#mi("{\\text{st}(x)}")#text(", called the ")#emph[#text("standard part")]#text(" of ")#mi("{x}")#text(", such that ")#mi("{x = \\text{st}(x) + o(1)}")#text(", i.e. ")#mi("{x - \\text{st}(x)}")#text(" is infinitesimal.")
]

#emph[#text("Proof:")]#text(" Uniqueness is clear (as no non-zero standard real can be infinitesimal). For existence, we consider the “Dedekind cut” ")#mi("{\\{ y \\in {\\bf R}: y < x \\}}")#text(", which is a non-empty bounded half-line in ")#mi("{{\\bf R}}")#text(". Taking ")#mi("{\\text{st}(x)}")#text(" to be the supremum of this cut, we easily verify that ")#mi("{\\text{st}(x)-\\epsilon \\leq x \\leq \\text{st}(x)+\\epsilon}")#text(" for any standard ")#mi("{\\epsilon > 0}")#text(", and the claim follows. ")#mi("\\Box")

#text("One can also prove this theorem by the usual ")#link("http://en.wikipedia.org/wiki/Bolzano-Weierstrass_theorem")[#text("Bolzano-Weierstrass argument")]#text(", trapping ")#mi("{x}")#text(" in a nested sequence of dyadic standard intervals; we leave this argument to the interested reader.")

#text("One can view the standard part operation ")#mi("{\\text{st}: O({\\bf R}) \\rightarrow {\\bf R}}")#text(" algebraically, as a homomorphism from the bounded nonstandard reals ")#mi("{O({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x = O(1) \\}}")#text(" to the standard reals with kernel ")#mi("{o({\\bf R}) := \\{ x \\in {}^* {\\bf R}: x = o(1)\\}}")#text("; note that the sets ")#mi("{O({\\bf R}), o({\\bf R})}")#text(" are perfectly well-defined as an (external) set in the nonstandard analysis formalism, even though it does not quite make rigorous set-theoretic sense in finitary mathematics (one cannot use finitary asymptotic notation such as ")#mi("{O()}")#text(" inside set-builder notation). Thus for instance we can say that ")#mi("{o({\\bf R})}")#text(" is an ideal in the ring ")#mi("{O({\\bf R})}")#text(", which is an assertion which is intuitively obvious in the finitary setting, but a bit hard to formalise properly. Note that ")#mi("{{\\bf R}}")#text(" can then be interpreted as the image under the standard part map of the bounded nonstandard rationals ")#mi("{O({\\bf Q})}")#text(". This can in fact be used to give an alternative ")#emph[#text("definition")]#text(" of the real numbers, which is the nonstandard version of the Cauchy completion construction; we leave this construction to the reader.")

#text("We can perform similar constructions with other metric spaces. Actually, in order to have a reaonable notion of boundedness, it is convenient to work in the category of ")#emph[#text("pointed")]#text(" metric spaces ")#mi("{(X,x_0) = (X,d,x_0)}")#text(", that is to say a metric space ")#mi("{(X,d)}")#text(" with a preferred “origin” ")#mi("{x_0 \\in X}")#text(". If one has a sequence ")#mi("{(X_{\\bf n}, d_{\\bf n}, x_{0,{\\bf n}})}")#text(" of standard pointed metric spaces, one can take ultralimits and create a nonstandard pointed metric space ")#mi("{(X_\\alpha, d_\\alpha, x_{0,\\alpha})}")#text(". Here, ")#mi("{X_\\alpha := \\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" is the ultraproduct of the ")#mi("{X_{\\bf n}}")#text(", ")#mi("{x_{0,\\alpha} := \\lim_{{\\bf n} \\rightarrow \\alpha} x_{0,{\\bf n}}}")#text(" is a point in ")#mi("{X_\\alpha}")#text(", and ")#mi("{d_\\alpha: X_\\alpha \\times X_\\alpha \\rightarrow {}^* [0,+\\infty)}")#text(" is the ultralimit of the ")#mi("{d_{\\bf n}}")#text(".")

#text("At present, ")#mi("{(X_\\alpha,d_\\alpha)}")#text(" is a nonstandard metric space, but not an external metric space, because the nonstandard distance ")#mi("{d_\\alpha(x,y)}")#text(" between two points in ")#mi("{X_\\alpha}")#text(" is a nonstandard real, and not necessarily a bounded one. To create an external metric space, we cut down the size of ")#mi("{X_\\alpha}")#text(" in two different ways. Firstly, we restrict attention to the bounded portion ")#mi("{O(X_\\alpha) := \\{ x \\in X_\\alpha: d_\\alpha(x,x_{0,\\alpha}) = O(1) \\}}")#text(" of ")#mi("{X_\\alpha}")#text(". Next, we place an equivalence relation ")#mi("{\\sim}")#text(" on ")#mi("{O(X_\\alpha)}")#text(" by declaring ")#mi("{x \\sim y}")#text(" if ")#mi("{d_\\alpha(x,y) = o(1)}")#text(". The quotient space ")#mi("{O(X_\\alpha)/\\sim}")#text(", which we will denote suggestively as ")#mi("{O(X_\\alpha)/o(X_\\alpha)}")#text(" can then be checked to be a metric space with metric given by the formula")

#align(center)[#tao-fit-display[#mitex("d( [x], [y] ) := \\text{st}( d_\\alpha(x,y) )")]]

#text("whenever ")#mi("{x,y \\in O(X_\\alpha)}")#text(", with corresponding equivalence classes ")#mi("{[x],[y] \\in O(X_\\alpha)/o(X_\\alpha)}")#text(". The quotient map ")#mi("{\\text{st}: O(X_\\alpha) \\rightarrow O(X_\\alpha)/o(X_\\alpha)}")#text(" will be called the ")#emph[#text("standard part map")]#text(", as it generalises the map in Proposition ")#link(<tao-7bed79fdd7e4907dece0>)[#text("13")]#text(".")

#text("We refer to the pointed external metric spaces ")#mi("{(O(X_\\alpha)/o(x_\\alpha), x_{0,\\alpha})}")#text(" as the ")#emph[#text("nonstandard hull")]#text(" of the standard pointed metric spaces ")#mi("{(X_{\\bf n}, x_{0,{\\bf n}})}")#text("; it is also known as the ")#link("http://en.wikipedia.org/wiki/Ultralimit")[#text("ultralimit")]#text(" of these spaces, although we avoid this terminology here as we are using the term “ultralimit” for a slightly different (although certainly related) operation. These spaces are automatically complete, as can easily be verified using countable saturation. If the spaces ")#mi("{X_{\\bf n}}")#text(" are ")#emph[#text("asymptotically uniformly locally totally bounded")]#text(" in the sense that for every ")#mi("{R,r>0}")#text(" there exists ")#mi("{M>0}")#text(" such that for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", one can cover the balls ")#mi("{B(x_{0,{\\bf n}}, R)}")#text(" by at most ")#mi("{M}")#text(" balls of radius ")#mi("{r}")#text(", then the nonstandard hull ")#mi("{O(X_\\alpha)/o(x_\\alpha)}")#text(" is also locally totally bounded by Łos’s theorem, and thus locally compact by the Heine-Borel theorem. Furthermore, it is not difficult to show in this case that the ")#mi("{(X_{\\bf n}, x_{0,{\\bf n}})}")#text(" converge along ")#mi("{\\alpha}")#text(" to ")#mi("{(X_\\alpha, x_{0,\\alpha})}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("pointed Gromov-Hausdorff sense")]#text(", thus for every ")#mi("{R, \\epsilon > 0}")#text(", the Gromov-Hausdorff distance between ")#mi("{B(x_{0,{\\bf n}}, R)}")#text(" and ")#mi("{B(x_{0,{\\alpha}}, R)}")#text(" is less than ")#mi("{\\epsilon}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(". In particular, this demonstrates the basic fact that any sequence of asymptotically uniformly locally totally bounded pointed metric spaces has a convergent subsequence in the pointed Gromov-Hausdorff sense.")

#text("There are several interesting special cases of the nonstandard hull construction. For instance, if the spaces ")#mi("{X_{\\bf n} = X}")#text(" are equal to a single locally totally bounded space, then the nonstandard hull becomes a metric completion ")#mi("{\\overline{X}}")#text(" of ")#mi("{X}")#text(", with every bounded sequence ")#mi("{x_{\\bf n}}")#text(" in ")#mi("{X}")#text(" giving rise to a limit point ")#mi("{\\text{st}( \\lim_{{\\bf n} \\rightarrow \\alpha} x_{\\bf n})}")#text(" in ")#mi("{\\overline{X}}")#text(". When the metric spaces are normed vector spaces, in which nonstandard analysis can be used as a framework to describe the theory of ")#link("http://wiki.math.toronto.edu/DispersiveWiki/index.php/Concentration_compactness")[#text("concentration compactness")]#text("; see ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("this previous blog post")]#text(" for further discussion. Finally, if one starts with a finitely generated group ")#mi("{G}")#text(" with a word metric ")#mi("{d}")#text(", then by taking the nonstandard hull of ")#mi("{G}")#text(" with a rescaled word metric ")#mi("{\\frac{1}{R_{\\bf n}} d}")#text(" for a well-chosen set of radii ")#mi("{R_{\\bf n}}")#text(", one can obtain a useful metric space known as the ")#emph[#text("asymptotic cone")]#text(" of ")#mi("{G}")#text(", which for instance can be used to establish ")#link("http://en.wikipedia.org/wiki/Gromov%27s_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem on groups of polynomial growth")]#text("; see ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("this paper of van den Dries and Wilkie")]#text(" for details. Related to this, one can take the non-standard hull of a sequence of approximate groups (and the groups generated by such approximate groups) to obtain open neighbourhoods of locally compact groups, allowing one to use the theory of ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" (which classifies the latter) to study approximate groups; see ")#link("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")[#text("this text of mine")]#text(" for more discussion.")

#heading(level: 1)[#strong[#text(" — 6. Loeb measure and regularity — ")]]

#text("Measure theory, with its emphasis on countable additivity, is not obviously a first-order theory, and so it is not ")#emph[#text("a priori")]#text(" obvious that it interacts well with ultraproducts. Nevertheless, thanks primarily to the countable saturation property of ultraproducts, one can often obtain a good notion of measure on nonstandard spaces, by carefully taking the ultralimit of measures on standard spaces. We give a fundamental such construction here, namely the ")#link("http://en.wikipedia.org/wiki/Loeb_space")[#text("Loeb measure construction")]#text(", although for simplicity we restrict attention to the setting of nonstandard finite sets (also known as ")#link("http://en.wikipedia.org/wiki/Hyperfinite_set")[#text("hyperfinite sets")]#text(") to avoid some technicalities. Loeb measures are a special case of the more general concept of a ")#emph[#text("Kiesler measure")]#text(" in model theory, but we will not discuss this more general concept here.")

#text("Let ")#mi("{X_{\\bf n}}")#text(" be a sequence of standard non-empty finite sets, so that the ultraproduct ")#mi("{X_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} X_{\\bf n}}")#text(" is a nonstandard non-empty finite set. On each of the ")#mi("{X_{\\bf n}}")#text(", we can define the uniform probability measure ")#mi("{\\mu_{\\bf n}}")#text(", which assigns the measure ")#tao-math("{\\mu_{\\bf n}(E_{\\bf n}) := \\frac{\\left|E_{\\bf n}\\right|}{\\left|X_{\\bf n}\\right|}}", block: false)#text(" to each subset ")#mi("{E_{\\bf n}}")#text(" of ")#mi("{X_{\\bf n}}")#text(". Of course, ")#mi("{\\mu_{\\bf n}}")#text(" is a finitely additive probability measure. Taking ultraproducts and then taking standard parts, we can then define a finitely additive probability measure ")#mi("{\\mu_\\alpha^0}")#text(" on the boolean algebra ")#mi("{{\\cal B}_{X_\\alpha}}")#text(" of internal subsets ")#mi("{E_\\alpha = \\prod_{{\\bf n} \\rightarrow \\alpha} E_{\\bf n}}")#text(" of ")#mi("{X_\\alpha}")#text(", by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu_\\alpha^0( \\prod_{{\\bf n} \\rightarrow \\alpha} E_{\\bf n} ) := \\text{st}( \\lim_{{\\bf n} \\rightarrow \\alpha} \\mu_{\\bf n}( E_{\\bf n} ) ).")]]

#text("One easily verifies that this is a finitely additive probability measure. Furthermore, thanks to the countable saturation property, we see that ")#mi("{\\mu_\\alpha^0}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Premeasure")[#text("premeasure")]#text(", that is to say that one has the countable additivity property")

#align(center)[#tao-fit-display[#mitex("\\mu_\\alpha^0( \\bigcup_{m=1}^\\infty E_m ) = \\sum_{m=1}^\\infty \\mu_\\alpha^0( E_m )")]]

#text("whenever ")#mi("{E_1,E_2,\\ldots}")#text(" are a family of disjoint internal subsets of ")#mi("{X_\\alpha}")#text(" whose union is also an internal subset. Applying the ")#link("http://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Caratheodory extension theorem")]#text(" (or more precisely, the ")#link("http://en.wikipedia.org/wiki/Hahn-Kolmogorov_theorem")[#text("Hahn-Kolmogorov theorem")]#text("), we can then extend ")#mi("{\\mu_\\alpha^0}")#text(" to a countably additive probability measure ")#mi("{\\mu_\\alpha}")#text(" on the ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\cal L}_{X_\\alpha}}")#text(" generated by ")#mi("{{\\cal B}_{X_\\alpha}}")#text("; we refer to ")#mi("{(X_\\alpha, {\\cal L}_{X_\\alpha}, \\mu_\\alpha)}")#text(" as a ")#emph[#text("Loeb space")]#text(", with ")#mi("{\\mu_\\alpha}")#text(" being the ")#emph[#text("Loeb probability measure")]#text(" and ")#mi("{{\\cal L}_{X_\\alpha}}")#text(" being the ")#emph[#text("Loeb ")#mi("{\\sigma}")#text("-algebra")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One technical caveat: in general, the Loeb ")#mi("{\\sigma}")#text("-algebra will not be countably generated, and so in particular the Lebesgue spaces ")#mi("{L^p(X_\\alpha, {\\cal L}_{X_{\\alpha}},\\mu_\\alpha)}")#text(" associated to Loeb spaces will not be separable. However, in most finitary applications, one can often work with countably generated sub-")#mi("{\\sigma}")#text("-algebras of the Loeb ")#mi("{\\sigma}")#text("-algebra, in which case separability can be restored.")
]

#text("The relationship between ")#mi("{\\mu_\\alpha^0}")#text(" and ")#mi("{\\mu_\\alpha}")#text(" is closely analogous to that between the elementary measure (or Jordan measure) of elementary subsets of (say) the unit cube, and that of Lebesgue measure of Borel subsets of that cube; see e.g. ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("this text of mine")]#text(" for the basic theory here. For instance, it is not difficult to show that every Loeb measurable set ")#mi("{F \\subset X_\\alpha}")#text(" is “almost internal” in the sense that for any standard ")#mi("{\\epsilon > 0}")#text(", one can find an internal set ")#mi("{E \\subset X_\\alpha}")#text(" which is ")#mi("{\\epsilon}")#text("-close to ")#mi("{F}")#text(" in the sense that the ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure")]

#align(center)[#tao-fit-display[#mitex("\\mu_\\alpha^*(E \\Delta F) := \\inf \\{ \\sum_m \\mu_\\alpha^0(E_m): E_m \\text{ internal and cover } E \\Delta F \\}")]]

#text("of the symmetric difference ")#mi("{E \\Delta F}")#text(" is at most ")#mi("{\\epsilon}")#text(". Related to this, the Loeb measure and the outer measure agree on any Loeb measurable set, and the simple internal functions on ")#mi("{X_\\alpha}")#text(" (i.e. finite linear combinations of indicator functions of internal sets) will be dense in ")#mi("{L^p( X_\\alpha, {\\cal L}_{X_\\alpha}, \\mu_{X_\\alpha} )}")#text(" for any (standard) ")#mi("{1 \\leq p < \\infty}")#text(".")

#text("For instance, if ")#mi("{N}")#text(" is an unbounded natural number, then the set ")#mi("{[o(N)] := \\{ n \\in [N]: n = o(N) \\}}")#text(" is not an internal subset of ")#mi("{[N]}")#text(", but it is the intersection of the countable family ")#mi("{[N/k] = \\{ n \\in [N]: n \\leq N/k\\}}")#text(" of internal sets for ")#mi("{k \\in {\\bf N}}")#text(". Each of the internal sets ")#mi("{[N/k]}")#text(" has measure ")#mi("{\\mu_{[N]}^0([N/k]) = \\frac{1}{k}}")#text(", and so ")#mi("{[o(N)]}")#text(" is a Loeb measurable set with Loeb measure zero. As another example, for any standard ")#mi("{q \\geq 1}")#text(" and ")#mi("{a \\in {\\bf Z}/q{\\bf Z}}")#text(", the residue class ")#mi("{\\{ n \\in [N]: n = a\\text{ mod } q \\}}")#text(" is an internal subset of ")#mi("{[N]}")#text(" of Loeb measure exactly ")#mi("{1/q}")#text(" (regardless of what the remainder of ")#mi("{N}")#text(" is modulo ")#mi("{q}")#text(").")

#text("As a quick application of Loeb measure, we give an instance of the Furstenberg correspondence principle, closely analogous to the topological dynamics example from a few sections earlier. Specifically, we connect the following two theorems:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Szemeredi’s theorem)")]#text(" ")#metadata(none) <tao-625f410f6b59c48a3f33>#text(" For any ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\delta>0}")#text(" there exists ")#mi("{N \\geq 1}")#text(" such that whenever ")#mi("{E \\subset [N]}")#text(" has density ")#tao-math("{\\left|E\\right|/N}", block: false)#text(" at least ")#mi("{\\delta}")#text(", ")#mi("{E}")#text(" contains an arithmetic progression ")#mi("{a, a+n, \\ldots, a+(k-1)n}")#text(" of length ")#mi("{k}")#text(" with some ")#mi("{n>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Furstenberg multiple recurrence)")]#text(" ")#metadata(none) <tao-6da0d5758783134bd6d9>#text(" Let ")#mi("{(X, {\\cal X}, \\mu)}")#text(" be a probability space, and let ")#mi("{T: X \\rightarrow X}")#text(" be an almost everywhere defined bijection that is measure-preserving. Then for any set ")#mi("{A \\subset X}")#text(" of positive measure and any ")#mi("{k \\geq 1}")#text(", there exists a point ")#mi("{x \\in X}")#text(", and a positive integer ")#mi("{n}")#text(" such that ")#mi("{x, T^n x, \\ldots, T^{(k-1)n} x \\in A}")#text(".")
]

#text("Again, it is not difficult to show that Theorem ")#link(<tao-625f410f6b59c48a3f33>)[#text("14")]#text(" implies Theorem ")#link(<tao-6da0d5758783134bd6d9>)[#text("15")]#text(". To show the converse, we again use the compactness and contradiction method. If Theorem ")#link(<tao-625f410f6b59c48a3f33>)[#text("14")]#text(" failed, then there exist ")#mi("{k \\geq 1}")#text(" and ")#mi("{\\delta>0}")#text(", and a sequence ")#mi("{N_{\\bf n}}")#text(" going to infinity, together with subsets ")#mi("{E_{\\bf n} \\subset [N_{\\bf n}]}")#text(" of density at least ")#mi("{\\delta}")#text(" which contain no ")#mi("{k}")#text("-term arithmetic progressions. Taking ultralimits, we obtain an unbounded natural number ")#mi("{N}")#text(" and an internal subset ")#mi("{E \\subset [N]}")#text(" of Loeb measure at least ")#mi("{\\delta}")#text(" which contains no non-standard ")#mi("{k}")#text("-term arithmetic progressions. The shift map ")#mi("{T: x \\mapsto x+1}")#text(" is defined and bijective almost everywhere on ")#mi("{[N]}")#text(", and is measure-preserving, and Theorem ")#link(<tao-6da0d5758783134bd6d9>)[#text("15")]#text(" then provides the required contradiction. (As remarked earlier, this probability space is likely to be inseparable, but one can make it separable simply by reducing ")#mi("{{\\cal X}}")#text(" to the ")#mi("{\\sigma}")#text("-algebra generated by ")#mi("{E}")#text(" and its (standard) shifts ")#mi("{E+n}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The ultralimit construction actually gives a lot more relevant structure on ")#mi("{[N]}")#text(" than just that of a measure-preserving system. For instance, one can view the space ")#mi("{\\{ (x,x+h,x+k,x+h+k): x,x+h,x+k,x+h+k \\in [N] \\}}")#text(" of parallelograms as a special subset of ")#mi("{[N]^4}")#text(", which one can also endow with a Loeb measure, and these spaces (as well as higher-dimensional analogues) which can be used to analyse the further additive structure of ")#mi("{[N]}")#text(" (in a manner that closely parallels the structural theory ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("of Host and Kra")]#text(" on measure-preserving systems); see ")#link("http://arxiv.org/abs/1203.2260")[#text("this paper of Szegedy")]#text(" for some details of this approach.")
]

#text("The above example already shows the power of basic measure-theoretic tools (such as the Hahn-Kolmogorov theorem) in connecting discrete and continuous results together. Now we turn to some applications of other basic measure theory tools, such as product measure and conditional expectation. Specifically, we will use ultraproducts and measure theory to prove the following “strong” form of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Szemerédi regularity lemma)")]#text(" ")#metadata(none) <tao-93246d5309280f568f73>#text(" Let ")#mi("{\\epsilon>0}")#text(" and ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" be a function. Then there exists ")#mi("{C>1}")#text(" with the following property: whenever ")#mi("{V}")#text(" is a finite non-empty set and ")#mi("{f: V \\times V \\rightarrow [0,1]}")#text(" is a function, there exists ")#mi("{1 \\leq M \\leq C}")#text(" and a decomposition")

#align(center)[#tao-fit-display[#mitex("f = f_{str} + f_{err} + f_{psd}")]]

#text("where")

#list(
[#text("(Structure) ")#mi("{f_{str}}")#text(" takes values in ")#mi("{[0,1]}")#text(", and there exists a partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_M}")#text(" such that ")#mi("{f_{str}}")#text(" is constant on ")#mi("{V_i \\times V_j}")#text(" for all ")#mi("{1 \\leq i,j \\leq M}")#text(".")],
[#text("(Smallness) ")#mi("{f_{err}}")#text(" takes values in ")#mi("{[-1,1]}")#text(", and ")#tao-math("{{\\bf E}_{v,w \\in V} \\left|f_{err}(v,w)\\right|^2 \\leq \\epsilon}", block: false)#text(".")],
[#text("(Pseudorandomness) For any ")#mi("{A,B \\subset V}")#text(", one has ")#tao-math("{\\left|{\\bf E}_{v,w \\in V} 1_A(v) 1_B(w) f_{psd}(v,w)\\right| \\leq \\frac{1}{F(M)}}", block: false)#text(".")]
)
]

#text("The connection between the regularity lemma and nonstandard measure theory was first obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=2964622")[#text("by Elek and Szegedy")]#text(", in which the extension of the arguments here to hypergraphs was also obtained.")

#text("We will deduce Lemma ")#link(<tao-93246d5309280f568f73>)[#text("16")]#text(" from the following infinitary version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17 (Infinitary regularity lemma)")]#text(" ")#metadata(none) <tao-34f76eafca55c9d6c3dd>#text(" Let ")#mi("{\\epsilon>0}")#text(" be standard, and let ")#mi("{V}")#text(" be a nonstandard finite non-empty set. If ")#mi("{f: V \\times V \\rightarrow [0,1]}")#text(" is a Loeb measurable function on ")#mi("{V \\times V}")#text(", then there exists a decomposition")

#align(center)[#tao-fit-display[#mitex("f = f_{str} + f_{err} + f_{psd}")]]

#text("where")

#list(
[#text("(Structure) ")#mi("{f_{str}}")#text(" takes values in ")#mi("{[0,1]}")#text(", and there exists a partition ")#mi("{V = V_1 \\cup \\ldots \\cup V_M}")#text(" into finitely many internal sets such that ")#mi("{f_{str}}")#text(" is constant on ")#mi("{V_i \\times V_j}")#text(" for all ")#mi("{1 \\leq i,j \\leq M}")#text(".")],
[#text("(Smallness) ")#mi("{f_{err}}")#text(" takes values in ")#mi("{[-1,1]}")#text(", and ")#tao-math("{\\int_{V \\times V} \\left|f_{err}(v,w)\\right|^2\\ d\\mu_{V \\times V}(v,w) < \\epsilon}", block: false)#text(".")],
[#text("(Pseudorandomness) For any measurable ")#mi("{A,B \\subset V}")#text(", one has ")#mi("{\\int_{V \\times V} 1_A(v) 1_B(w) f_{psd}(v,w)\\ d\\mu_{V \\times V}(v,w) = 0}")#text(".")]
)
]

#text("We will prove Lemma ")#link(<tao-34f76eafca55c9d6c3dd>)[#text("17")]#text(" shortly, but let us first see how it implies Lemma ")#link(<tao-93246d5309280f568f73>)[#text("16")]#text(". We once again use the compactness and contradiction method. If Lemma ")#link(<tao-93246d5309280f568f73>)[#text("16")]#text(" fails, then there exists ")#mi("{\\epsilon>0}")#text(" and ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(", and for each ")#mi("{{\\bf n}}")#text(" there exists a finite non-empty set ")#mi("{V_{\\bf n}}")#text(" and a function ")#mi("{f_{\\bf n}: V_{\\bf n} \\times V_{\\bf n} \\rightarrow [0,1]}")#text(", such that for no ")#mi("{1 \\leq M \\leq {\\bf n}}")#text(" does there exist a decomposition")

#align(center)[#tao-fit-display[#mitex("f_{\\bf n} = f_{str,{\\bf n}} + f_{err,{\\bf n}} + f_{psd,{\\bf n}}")]]

#text("obeying the conclusions of Lemma ")#link(<tao-93246d5309280f568f73>)[#text("16")]#text(". We then take ultralimits to obtain a nonstandard finite non-empty set ")#mi("{V_\\alpha}")#text(" and an internal function ")#mi("{f_\\alpha: V_\\alpha \\times V_\\alpha \\rightarrow {}^* [0,1]}")#text(". The standard part ")#mi("{f := \\text{st} f_\\alpha}")#text(" is then a Loeb measurable function on ")#mi("{V \\times V}")#text(" taking values in ")#mi("{[0,1]}")#text(". We apply Lemma ")#link(<tao-34f76eafca55c9d6c3dd>)[#text("17")]#text(" to obtain a decomposition")

#align(center)[#tao-fit-display[#mitex("f = f_{str} + f_{err} + f_{psd}")]]

#text("with the stated properties for some finite ")#mi("{M}")#text(". Note that ")#mi("{f_{str}}")#text(" is already a simple internal function. The function ")#mi("{f_{psd}}")#text(" need not be simple internal, but may be approximated to arbitrary accuracy in ")#mi("{L^2(V \\times V, {\\cal L}_{V \\times V}, \\mu_{V \\times V})}")#text(" by a simple internal function. Thus we may find a decomposition")

#align(center)[#tao-fit-display[#mitex("f_\\alpha = f_{str} + f^{\\prime}_{err} + f^{\\prime}_{psd}")]]

#text("where ")#mi("{f^{\\prime}_{psd}}")#text(" is simple internal and is such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{V \\times V} 1_A(v) 1_B(w) f^{\\prime}_{psd}(v,w)\\ d\\mu_{V \\times V}(v,w)\\right| < \\frac{1}{F(M)}", block: true)]]

#text("for all measurable ")#mi("{A,B \\subset V}")#text(", and ")#mi("{f^{\\prime}_{err}}")#text(" is simple internal, takes values in ")#mi("{[-1,1]}")#text(", and is such that")

#align(center)[#tao-fit-display[#tao-math("\\int_{V \\times V} \\left|f^{\\prime}_{err}(v,w)\\right|^2\\ d\\mu_{V \\times V}(v,w) < \\epsilon.", block: true)]]

#text("By Łos’s theorem, an analogous decomposition then holds for ")#mi("{f_{\\bf n}}")#text(" for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{\\alpha}")#text(", but this contradicts the construction of the ")#mi("{f_{\\bf n}}")#text(".")

#text("Now we prove Lemma ")#link(<tao-34f76eafca55c9d6c3dd>)[#text("17")]#text(". The proof hinges on a comparison between two spaces, the Loeb space")

#align(center)[#tao-fit-display[#mitex("(V \\times V, {\\cal L}_{V \\times V}, \\mu_{V \\times V})")]]

#text("on the product space ")#mi("{V \\times V}")#text(", and the subtly different probability space")

#align(center)[#tao-fit-display[#mitex("(V \\times V, {\\cal L}_V \\times {\\cal L}_V, \\mu_V \\times \\mu_V)")]]

#text("that is the ")#link("http://en.wikipedia.org/wiki/Product_measure")[#text("product")]#text(" of the Loeb space ")#mi("{(V, {\\cal L}_V, \\mu_V)}")#text(" with itself, thus ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text(" is the ")#mi("{\\sigma}")#text("-algebra on ")#mi("{V \\times V}")#text(" generated by rectangles ")#mi("{A \\times B}")#text(" with ")#mi("{A,B}")#text(" Loeb measurable in ")#mi("{V}")#text(", and ")#mi("{\\mu_V \\times \\mu_V}")#text(" is the product measure, which is the unique probability measure on ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu_V \\times \\mu_V(A \\times B) = \\mu_V(A) \\mu_V(B)")]]

#text("for all Loeb measurable ")#mi("{A,B \\subset V}")#text(".")

#text("It is not difficult to show that the former probability space is a refinement of the latter, thus ")#mi("{{\\cal L}_{V \\times V}}")#text(" contains ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text(", and ")#mi("{\\mu_{V \\times V}}")#text(" and ")#mi("{\\mu_V \\times \\mu_V}")#text(" agree on their common domain ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text(" of definition. However, the former space is larger in general; the basic reason for this is for large finite spaces ")#mi("{V_{\\bf n}}")#text(", it is possible to find subsets of ")#mi("{V_{\\bf n} \\times V_{\\bf n}}")#text(" that are not well approximable by bounded boolean combinations of rectangles ")#mi("{A_{\\bf n} \\times B_{\\bf n}}")#text(" (e.g. random subsets of ")#mi("{V_{\\bf n} \\times V_{\\bf n}}")#text(" will have this property with high probability in the asymptotic limit when ")#tao-math("{\\left|V_{\\bf n}\\right|}", block: false)#text(" goes to infinity). Despite this disparity, we may still form the ")#emph[#text("conditional expectation")]#text(" ")#mi("{\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V )}")#text(" of ")#mi("{f}")#text(", which one can define as the orthogonal projection of ")#mi("{f}")#text(" in the Hilbert space ")#mi("{L^2( V \\times V, {\\cal L}_{V \\times V}, \\mu_{V \\times V})}")#text(" to the closed subspace ")#mi("{L^2( V \\times V, {\\cal L}_V \\times {\\cal L}_V, \\mu_V \\times \\mu_V )}")#text(". We then have a decomposition")

#align(center)[#tao-fit-display[#mitex("f = \\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V ) + f_{psd}")]]

#text("where ")#mi("{f_{psd}}")#text(" is orthogonal to all ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text("-measurable functions; in particular, it is orthogonal to ")#mi("{1_{A \\times B}}")#text(" for any Loeb measurable ")#mi("{A,B \\subset V}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("\\int_{V \\times V} 1_A(v) 1_B(w) f_{psd}(v,w)\\ d\\mu_{V \\times V}(v,w) = 0")]]

#text("for all such ")#mi("{A,B}")#text(".")

#text("Next, we know that ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text(" is generated (up to null sets) by products ")#mi("{A \\times B}")#text(" of internal sets, so we may approximate ")#mi("{\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V )}")#text(" to arbitary error in ")#mi("{L^2}")#text(" by a simple function ")#mi("{f_{str}}")#text(" that is a finite linear combination of indicators ")#mi("{1_{A \\times B}}")#text(" of rectangles; as ")#mi("{f}")#text(" takes values in ")#mi("{[0,1]}")#text(", we can ensure that ")#mi("{\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V )}")#text(" and ")#mi("{f_{str}}")#text(". This gives a decomposition")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V ) = f_{str} + f_{err}")]]

#text("and one easily verifies that all the required properties of Lemma ")#link(<tao-34f76eafca55c9d6c3dd>)[#text("17")]#text(" are obeyed.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" It is instructive to deconstruct this proof and compare it with the standard “energy increment” proof of the regularity lemma. The energy increment process is now concealed within the standard proof of the existence of orthogonal projections in Hilbert spaces (see e.g. Proposition 1 of ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("this previous blog post")]#text("), so on some level the two proofs of the regularity lemma are essentially equivalent. However, the ultrafilter proof allows one to hide many of the ingredients of the argument into existing Hilbert space theory.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" A similar construction allows one to extract a graph limit from a sequence of finite graphs ")#mi("{f_{\\bf n}: V_{\\bf n} \\times V_{\\bf n} \\rightarrow [0,1]}")#text(", by first forming the ultraproduct ")#mi("{f: V \\times V \\rightarrow [0,1]}")#text(" and then the conditional expectation ")#mi("{\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V )}")#text(", which is an ")#mi("{{\\cal L}_V \\times {\\cal L}_V}")#text("-measurable function from ")#mi("{V \\times V}")#text(" to ")#mi("{[0,1]}")#text(". At this point we encounter the technical issue noted previously that ")#mi("{{\\cal L}_V}")#text(" is not countably generated. However, we may find a countably generated sub-")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\cal V}}")#text(" of ")#mi("{{\\cal L}_V}")#text(" with the property that ")#mi("{\\mathop{\\bf E}( f | {\\cal L}_V \\times {\\cal L}_V )}")#text(" is equal ")#mi("{\\mu_{V \\times V}}")#text("-almost everywhere with a ")#mi("{{\\cal V} \\times {\\cal V}}")#text("-measurable function ")#mi("{f_\\infty: V \\times V \\rightarrow [0,1]}")#text(", by expressing ")#mi("{f}")#text(" as the almost everywhere limit of simple functions (bounded linear combinations of rectangles ")#mi("{1_{A \\times B}}")#text(" with ")#mi("{A,B \\in {\\cal L}_V}")#text(") and then letting ")#mi("{{\\cal V}}")#text(" be the ")#mi("{\\sigma}")#text("-algebra generated by the ")#mi("{A,B}")#text(". The function ")#mi("{f_\\infty}")#text(" is then essentially a graphon, after lifting the separable probability space ")#mi("{(V, {\\cal L}_V, \\mu_V)}")#text(" to the unit interval with uniform Lebesgue measure in the standard fashion. Among other things, this construction can give an alternate proof that every sequence of graphs has a subsequence converging to a graphon.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Although it is not needed here, one convenient fact about Loeb spaces on products is that they obey the following Fubini-Tonelli type theorem: if ")#mi("{V, W}")#text(" are nonstandard finite spaces and ")#mi("{f: V \\times W \\rightarrow [0,+\\infty]}")#text(" is Loeb measurable on ")#mi("{V \\times W}")#text(", then for all ")#mi("{v \\in V}")#text(", the function ")#mi("{w \\mapsto f(v,w)}")#text(" is Loeb measurable on ")#mi("{W}")#text(", the integral ")#mi("{v \\mapsto \\int_W f(v,w)\\ d\\mu_W(w)}")#text(" is Loeb measurable on ")#mi("{V}")#text(", and we have the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{V \\times W} f(v,w)\\ d\\mu_{V \\times W}(v,w) = \\int_V ( \\int_W f(v,w)\\ d\\mu_W(w) )\\ d\\mu_V(v).")]]

#text("Similarly if the roles of ")#mi("{V}")#text(" and ")#mi("{W}")#text(" are swapped; in particular we have the familiar identity")

#align(center)[#tao-fit-display[#mitex("\\int_V ( \\int_W f(v,w)\\ d\\mu_W(w) )\\ d\\mu_V(v) = \\int_W ( \\int_V f(v,w)\\ d\\mu_V(v) )\\ d\\mu_W(w).")]]

#text("These identities are obvious when ")#mi("{f}")#text(" is an internal simple function (as it follows from the corresponding claim in the finite case), and the general case follows from a standard approximation argument (using the monotone convergence theorem repeatedly). One can also obtain an analogous claim in the absolutely integrable category, in the spirit of Fubini’s theorem; we leave this to the interested reader.")
]

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02242c47c189bdeee6118d74b2f6d153f67b1257413b83486b2a8af92c31af13-2924c613ac702b4e69366a83b09c13ca5a2388f04ed910d1e729ca540e073d0d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terrence Tao Blog: Bridging Discrete & Continuous Analysis | Math Online Tom Circle")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255890")[#strong[#text("Terrence Tao Blog: Bridging Discrete & Continuous Analysis | Math Online Tom Circle")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-a&#8230")[#text("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-a&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255899")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Another approach to discrete mathematics is to use funcoids and reloid. A funcoid may represent both proximal space or a topological space, or a discrete object such as a graph. Such things as continuity are defined for funcoids, generalizing both continuous and discrete cases.")#linebreak()#text(" ")#link("http://www.mathematics21.org/algebraic-general-topology.html")[#text("http://www.mathematics21.org/algebraic-general-topology.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255915")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Pedantic note: “Los” should really be “Łoś”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0980986c8ee63d698de787a314155c20d71c18ce1309af3c542473e3dac59563-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255916")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("In the discussion after Proposition 13 “bounded nonstandard integers ")#mi("O(\\mathbb{Q})")#text("” should be “rationals”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255919")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Sorry for being off topic. I wish to know if this elementary result is really new? ")#link("http://www.academia.edu/3247833/Statistical_induction_and_prediction")[#text("http://www.academia.edu/3247833/Statistical_induction_and_prediction")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Porton")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-255940")[#strong[#text("Victor Porton")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Limits to ultrafilters are somehow similar to ")#link("http://portonmath.tiddlyspace.com/#[[Theory of singularities using generalized limits]]")[#text("my attempt to define a theory of generalized limits (in singularity points)")]#text(", but I consider filters rather than only ultrafilters. My attempt to construct in my way a theory in singularities is inhibited by some problems (some of which are precisely formulated and some are not), like ")#link("http://portonmath.tiddlyspace.com/#[[Singularities%20funcoids%3A%20some%20special%20cases]]")[#text("these open problems")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc6ba7abdc8a6c82b2c0b0ebab71fc1dca8d807a7f5e16573f38d2bf0b627591-5a45f423ae2bdec4ba97d45901a201e078e14ea1874653a4aae61549482f9f04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-256002")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Could this approach be useful in Graph theory problems such as Graph capaity ")#link("http://en.wikipedia.org/wiki/Shannon_capacity_of_a_graph")[#text("http://en.wikipedia.org/wiki/Shannon_capacity_of_a_graph")]#text("? When can solutions to semidefinite relaxations be thought of representing a property of a graph limit when the sequences of graphs are constructed in a particular way? Noga Alon with his student has show the capacity problem could be undecidable because the convergence property is true but the pace of convergence could have jumps. Can such difficult problems be studied with the technique at hand?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-256031")[#strong[#text("Boolean Algebra |")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")]

#text("[…] Ultraproducts as a Bridge Between Discrete and Continuous … ")#link("https://terrytao.wordpress.com/Some")[#text("https://terrytao.wordpress.com/Some")]#text(" of the material here is drawn from previous blog posts, notably “Ultraproducts as a bridge between hard analysis and soft analysis” and “Ultralimit analysis and quantitative algebraic geometry“'. The text … Discrete analysis, of course, is primarily interested in the study of discrete (or “finitary”) mathematical objects: integers, rational numbers (which can be viewed as ratios of integers), finite sets, finite graphs, finite or discrete metric spaces, and so forth. However … […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraprodukte | UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-256050")[#strong[#text("Ultraprodukte | UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("[…] In der Vorlesung zur Funktionalanalysis hatte ich Ultrafilter als ein Möglichkeit angesprochen, kompakte topologische Räume zu definieren. Dass diese auf H. Cartan zurückgehende Definition auch für viele andere mathematische Fragestellung sinnvoll ist belegt der Artikel von T. Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-256075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Near the end of definition 3, “for every k-ary operation M” should be “for every k-ary operation O”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-256392")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Typo: “Gromov-Hausorff limits”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d55931ba90f95625da689933acc8a1960bc75953f5c1dd010f7dbb1b37c8bab2-e98a470c8c49d63f09ea2eda58404291f8c864157af57dbe4490639bf144ab9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michelangelo")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-267406")[#strong[#text("Michelangelo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2014")])]

#text("I don’t know if it can be useful, there are two articles on a similar topic by Bruno de Finetti: “La struttura delle distribuzioni in un insieme astratto qualsiasi” and “Sulla teoria astratta della misura e dell’integrazione”; english translations (“The structure of distributions on abstract spaces” and “On the abstract theory of measure and integration”) can be found in “Probability, Induction and Statistics: The art of guessing”, J. Wiley, N. Y., 1972.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-324627")[#strong[#text("Hindman’s Theorem | Finite Playground")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")]

#text("[…] reading the posts on ultrafilters by Terry Tao [1,2], I find the following result […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of When is correlation transitive? | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-363827")[#strong[#text("When is correlation transitive? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2014")])]

#text("[…] (i.e. in the formalism of inner product spaces) we will need a non-principal ultrafilter (see e.g this previous blog post for basic theory of ultrafilters); we leave it as an exercise to the reader to figure out how to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lebesgue measure as the invariant factor of Loeb measure | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-379687")[#strong[#text("Lebesgue measure as the invariant factor of Loeb measure | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("[…] some basic familiarity with nonstandard analysis and ultraproducts, as covered for instance in this previous blog post.) Given an unbounded nonstandard natural number , one can define two external additive subgroups of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-388661")[#strong[#text("The subspace theorem approach to Siegel’s theorem on integral points on curves via nonstandard analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("[…] out that finiteness theorems are very compatible with the language of nonstandard analysis. (See this previous blog post for a review of the basics of nonstandard analysis, and in particular for the nonstandard […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Additive limits | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-429516")[#strong[#text("Additive limits | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("[…] analysis (or of ultraproducts); see for instance this paper of Elek and Szegedy, Section 6 of this previous blog post, or this paper of Towsner. (In this post we assume some familiarity with nonstandard analysis, as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-457535")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] of a standard part of a bounded real number, and the Loeb measure construction), see for instance this previous blog post for a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-457541")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("Correction: after Remark 1, in “One can also view [the ultralimit of a sequence in a finite set] as the outcome of an “election” among candidates in {X}, in which each “voter” ")#mi("\\mathbf{n}")#text(" has ")#mi("\\mathbf{n}")#text(" as a preferred candidate”, the second n should be ")#mi("x_\\mathbf{n}")#text(", I think.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-459337")[#strong[#text("The One About .999… |")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2015")]

#text("[…] than 1, you might at some point want to learn about the hyperreal number system, and the concept of ultralimits. In this context, .999… is less than 1, and for a very appealing reason: since each individual […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-466638")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("Dear Terry,")

#text("I’m trying to flesh out the details of Remark 5 here. Is it true for some reason that if ")#mi("\\Omega")#text(" is a hyperfinite set and ")#mi("\\Sigma")#text(" any separable sub-")#mi("\\sigma")#text("-algebra of the Loeb ")#mi("\\sigma")#text("-algebra then ")#mi("(\\Omega,\\Sigma,\\mu)")#text(" is a standard probability space (in the sense of ")#link("https://en.wikipedia.org/wiki/Standard_probability_space")[#text("https://en.wikipedia.org/wiki/Standard_probability_space")]#text(")?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-466650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("My guess would be that these spaces would not exactly be standard probability spaces, but ought to be equivalent modulo null sets to a standard probability space. If I recall correctly, there is some discussion of these issues in Furstenberg’s book, something along the lines that every separable probability space has a standard probability space model which is equivalent up to null sets. But I don’t have that book handy right now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-472593")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2016")])]

#text("Dear Prof. Tao,")

#text("in remark 1, it seems as though “ultrafilters” must be replaced by “non-principal ultrafilters”, for the existence of ultrafilters is given by the principal ultrafilters.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-472670")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2016")])]

#text("Dear Prof. Tao,")

#text("It seems as though in Definition 2 in the last line of the first paragraph (“We identify every standard object…”), the subscript from the limit has to be dropped, or one would set ")#mi("x_n = x")#text(" for all ")#mi("n")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Special cases of Shannon entropy | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-478565")[#strong[#text("Special cases of Shannon entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("[…] As before, every linear inequality or equality that is valid for the information-theoretic quantities discussed above, is automatically valid for the linear algebra counterparts for subspaces of a vector space over a finite field by applying the above specialisation (and dividing out by the normalising factor of ). In fact, the requirement that the field be finite can be removed by applying the compactness theorem from logic (or one of its relatives, such as Los’s theorem on ultraproducts, as done in this previous blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c98a424a37e39eaabdff9ae46662cea3bc2a47bb7e4aff4afda1f8818325fc10-7bebb4855515869c2d6244c3a0739825e56ee49b417f3eb458a1029ca7f5c0b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of espressonator")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-485808")[#strong[#text("espressonator")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2017")])]

#text("Perhaps instead of “finite subspace”, you meant “finite dimensional subspace”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto di Biase")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-503037")[#strong[#text("Fausto di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2018")])]

#text("It seems to me that the information encoded by a filter, say alfa, is given by the ”small” sets it contains. Indeed, if alfa contains a set A, it also necessarily contains the supersets of A, but it does not necessarily contain any given subset of A. So, I am not sure why you choose to call ”alfa-large” the members of alfa, rather than ”alfa-small”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-503086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("“Members of” is not the same as “information encoded by”. As you note, the larger the set is, the more likely it is to lie in the filter ")#mi("\\alpha")#text(", so it is natural to view sets in the filter as being large instead of small. For instance, in the cofinite filter, the only sets that lie in the filter are those that are so large that their complements are finite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto di Biase")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-503307")[#strong[#text("Fausto di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2018")])]

#text("You are right. Thank you!")

#text("I guess what tricked me is the fact that if we pick a point ")#mi("x")#text(" ”at random” in the powerset of ")#mi("\\mathbb{N}")#text(" (with the hope of getting elements of a given filter ")#mi("\\alpha")#text(" of subsets of ")#mi("\\mathbb{N}")#text("), and if we are lucky and end up finding that ")#mi("x")#text(" belongs to ")#mi("\\alpha")#text(", then the interesting thing to do, in order to find other elements of ")#mi("\\alpha")#text(", is to go ”downwards” and pick a subset of ")#mi("x")#text(" ”at random”, with the hope of finding another element of ")#mi("\\alpha")#text(" (since the supersets of ")#mi("x")#text(" will be trivially be elements of ")#mi("\\alpha")#text(").")

#text("I guess I had this in mind when I wrote that the ”information is given by the small sets”.")

#text("On the other hand, if we are unlucky and find out that ")#mi("x")#text(" is not an element of ")#mi("\\alpha")#text(", then the thing to do is to go ”upwards” and pick a superset of ")#mi("x")#text(" ”at random”, with the hope of finding an element of ")#mi("\\alpha")#text(", since no subset of ")#mi("x")#text(" will belong to ")#mi("\\alpha")#text(" in this case. We could say that this ")#mi("x")#text(" is not ”large enough” to belong to ")#mi("\\alpha")#text(".")

#text("A curious fact about the cofinite filter ")#mi("\\alpha")#text(" is that, if ")#mi("x")#text(" belongs to it, and if we look for an ascending chain ")#mi("x\\subset x_1\\subset x_2\\subset x_3\\subset\\ldots")#text(" of distinct elements of ")#mi("\\alpha")#text(" starting from ")#mi("x")#text(", then we will only find finite chains, while if we look for descending chains ")#mi("x\\supset z_1\\supset z_2\\supset z_3\\supset\\ldots")#text(" of distinct elements of $ latex \\alpha$ starting from ")#mi("x")#text(", we will find infinite chains. There is no ”smallest” element in ")#mi("\\alpha")#text(" contained in a given ")#mi("x\\in\\alpha")#text(". Indeed, the intersection of all elements of ")#mi("\\alpha")#text(" is empty.")

#text("Thank you for this beautiful post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-593240")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2020")])]

#text("Terry,")

#text("Previously I have been written in this comment stream that I “attempt” to construct “noncontinuous” analysis (common generalization of continuous analysis and discrete analysis, as well as analysis of any arbitrary functions (having some topological structure)). I succeeded!!")

#text("I already defined (generalized) limit of an arbitrary (even discontinuous) function. Now I have written a text how to manipulate these limits (e.g. add or multiply them). I even defined what a noncontinuous solution of a differential equation means.")

#text("Need to say that it makes obvious to define derivatives and integrals (as well as infinite sums) for arbitrary functions?")

#text("Hm, probably my generalized limit is equivalent to the limit \\union all the ultralimits on ultrafilters over the given filter (not checked the statement given in this paragraph yet). Quite an obvious idea, but nobody formulated it.")

#text("Here is the text about generalized limit:")#linebreak()#text(" ")#link("https://mathematics21.org/limit-of-discontinuous-function/")[#text("https://mathematics21.org/limit-of-discontinuous-function/")]

#text("Moreover, this generalized limit trivially generalizes further to limits on arbitrary “spaces”. I define the concept of “space” that encompasses all kinds of spaces in topology, including topological, proximity, uniform, metric spaces, locales and frames, etc. in this text:")#linebreak()#text(" ")#link("https://mathematics21.org/the-algebra-of-general-topology/")[#text("https://mathematics21.org/the-algebra-of-general-topology/")]

#text("Nominate me for Abel and Breakthrough prizes for these works! Seriously.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Professor Van Nostrand")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-593780")[#strong[#text("Professor Van Nostrand")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Dear Victor Porton,")

#text("I have just studied your work on algebraic general topology and I am nominating you for Abel prize.")

#text("Best of luck.")#linebreak()#text(" Van Nostrand")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-593785")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2020")])]

#text("Prof. Van,")

#text("Your reply would be absolutely feasible, unless one reason:")

#text("You had too little time to really study several hundreds pages. So, what you say is definitely a silly joke.")

#text("BTW, here are short introductions:")

#link("https://mathematics21.org/binaries/present.pdf")[#text("Click to access present.pdf")]

#link("https://mathematics21.org/binaries/intro.pdf")[#text("Click to access intro.pdf")]

#text("Oops, both those two introductions miss the discovery (probably, my main discovery) from")#linebreak()#text(" ")#link("https://mathematics21.org/the-algebra-of-general-topology/")[#text("https://mathematics21.org/the-algebra-of-general-topology/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-593989")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2020")])]

#text("Self-promoting comments are not allowed in this blog.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/#comment-689554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2026")])]

#text("Dr Tao, forgive my ignorance, could you specify how can we use ")#emph[#text("Graph limits")]#text(" to pass from ")#emph[#text("Graph/hypergraph regularity")]#text(" to ")#emph[#text("Measure theory")]#text("?")

#emph[#text("[Lovasz’s text ")#link("https://lovasz.web.elte.hu//bookxx/hombook-almost.final.pdf")[#text("https://lovasz.web.elte.hu//bookxx/hombook-almost.final.pdf")]#text(" covers this topic extensively -T.]")]
]
