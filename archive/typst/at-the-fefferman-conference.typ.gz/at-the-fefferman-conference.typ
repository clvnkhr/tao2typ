// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/
// Converted to Typst by tao2typ: "2026-10-14T15:17:13.838691+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "At the Fefferman conference", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("At the Fefferman conference")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/")[#text("https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I am currently at Princeton for the conference “")#link("http://www.math.princeton.edu/conference/fefferman09/")[#text("The power of Analysis")]#text("” honouring ")#link("http://en.wikipedia.org/wiki/Charles_Fefferman")[#text("Charlie Fefferman")]#text("‘s 60th birthday. I myself gave a talk at this conference entitled “Recent progress on the Kakeya conjecture”; I plan to post a version of this talk on this blog shortly.")

#text("But one nice thing about attending these sorts of conferences is that one can also learn some neat mathematical facts, and I wanted to show two such small gems here; neither is particularly deep, but I found both of them cute. The first one, which I learned from my former student ")#link("http://www.math.princeton.edu/~soonsikk/Home.html")[#text("Soonsik Kwon")]#text(", is a unified way to view the ")#link("http://en.wikipedia.org/wiki/Mean")[#text("mean")]#text(", ")#link("http://en.wikipedia.org/wiki/Median")[#text("median")]#text(", and ")#link("http://en.wikipedia.org/wiki/Mode_(statistics)")[#text("mode")]#text(" of a probability distribution ")#mi("{\\mu}")#text(" on the real line. If one assumes that this is a continuous distribution ")#mi("{\\mu = f(x)\\ dx}")#text(" for some smooth, rapidly decreasing function ")#mi("{f: {\\mathbb R} \\rightarrow {\\mathbb R}^+}")#text(" with ")#mi("{\\int_{\\mathbb R} f(x)\\ dx = 1}")#text(", then the mean is the value of ")#mi("{x_0}")#text(" that minimises the second moment")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\mathbb R} \\left|x-x_0\\right|^2 f(x)\\ dx,", block: true)]]

#text("the median is the value of ")#mi("{x_0}")#text(" that minimises the first moment")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} |x-x_0| f(x)\\ dx,")]]

#text("and the mode is the value of ")#mi("{x_0}")#text(" that ")#emph[#text("maximises")]#text(" the “pseudo-negative first moment”")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbb R} \\delta(x-x_0) f(x)\\ dx.")]]

#text("(Note that the Dirac delta function ")#mi("{\\delta(x-x_0)}")#text(" has the same scaling as ")#tao-math("{\\left|x-x_0\\right|^{-1}}", block: false)#text(", hence my terminology “pseudo-negative first moment”.)")

#text("The other fact, which I learned from my former classmate ")#link("http://www.mat.csic.es/fichapersonal.php?id=15")[#text("Diego Córdoba")]#text(" (and used in a ")#link("http://www.pubmedcentral.nih.gov/articlerender.fcgi?artid=307564")[#text("joint paper of Diego with Antonio Córdoba")]#text("), is a pointwise inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla\\right|^\\alpha ( f^2 )(x) \\leq 2 f(x) \\left|\\nabla\\right|^\\alpha f(x)", block: true)]]

#text("for the fractional differentiation operators ")#tao-math("{\\left|\\nabla\\right|^\\alpha}", block: false)#text(" applied to a sufficiently nice real-valued function ")#mi("{f: {\\mathbb R}^d \\rightarrow {\\mathbb R}}")#text(" (e.g. Schwartz class will do), in any dimension ")#mi("{d}")#text(" and for any ")#mi("{0 \\leq \\alpha \\leq 1}")#text("; this should be compared with the product rule ")#mi("{\\nabla (f^2 ) = 2 f \\nabla f}")#text(".")

#text("The proof is as follows. By a limiting argument we may assume that ")#mi("{0 < \\alpha < 1}")#text(". In this case, there is a formula")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nabla\\right|^\\alpha f(x) = c(\\alpha) \\int_{{\\mathbb R}^d} \\frac{f(x)-f(y)}{\\left|x-y\\right|^{d+\\alpha}}\\ dy", block: true)]]

#text("for some explicit constant ")#mi("{c(\\alpha) > 0}")#text(" (this can be seen by computations similar to those in my recent ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("lecture notes on distributions")]#text(", or by analytically continuing such computations; see also Stein’s “Singular integrals and differentiability properties of functions”). Using this formula, one soon sees that")

#align(center)[#tao-fit-display[#tao-math("2 f(x) \\left|\\nabla\\right|^\\alpha f(x) - \\left|\\nabla\\right|^\\alpha ( f^2 )(x) = c(\\alpha) \\int_{{\\mathbb R}^d} \\frac{\\left|f(x)-f(y)\\right|^2}{\\left|x-y\\right|^{d+\\alpha}}\\ dy", block: true)]]

#text("and the claim follows.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin")]], [#link("https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/#comment-38594")[#strong[#text("Kevin")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2009")])]

#text("Another way to view the mode, which is closer in form to the first two examples, is to think of it as the value of x_0 which minimizes the “0th” moment. That is, you look at the limiting case as the exponent on |x-x_0| goes to zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/#comment-38608")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e66v4")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")]

#text("[…] Math and more math. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2009/05/06/at-the-fefferman-conference/#comment-38610")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")])]

#text("Hi — a very small detail — I think that last integral should be over R^d, not from R to d.")

#text("Just fyi! Thanks.")

#emph[#text("[Corrected, thanks – T]")]
]
