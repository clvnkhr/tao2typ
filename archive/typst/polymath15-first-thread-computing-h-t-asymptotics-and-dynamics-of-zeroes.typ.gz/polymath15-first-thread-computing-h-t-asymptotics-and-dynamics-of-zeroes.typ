// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/
// Converted to Typst by tao2typ: "2026-10-14T10:44:31.979041+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, first thread: computing H_t, asymptotics, and dynamics of zeroes", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, first thread: computing H_t, asymptotics, and dynamics of zeroes")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 January 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")[#text("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the first official “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("The proposal naturally splits into at least three separate (but loosely related) topics:")

#list(
[#text("Numerical computation of the entire functions ")#mi("{H_t(z)}")#text(", with the ultimate aim of establishing zero-free regions of the form ")#mi("{\\{ x+iy: 0 \\leq x \\leq T, y \\geq \\varepsilon \\}}")#text(" for various ")#mi("{T, \\varepsilon > 0}")#text(".")],
[#text("Improved understanding of the dynamics of the zeroes ")#mi("{z_j(t)}")#text(" of ")#mi("{H_t}")#text(".")],
[#text("Establishing the zero-free nature of ")#mi("{H_t(x+iy)}")#text(" when ")#mi("{y \\geq \\varepsilon > 0}")#text(" and ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{t}")#text(" and ")#mi("{\\varepsilon}")#text(".")]
)

#text("Below the fold, I will present each of these topics in turn, to initiate further discussion in each of them. (I thought about splitting this post into three to have three separate discussions, but given the current volume of comments, I think we should be able to manage for now having all the comments in a single post. If this changes then of course we can split up some of the discussion later.)")

#text("To begin with, let me present some formulae for computing ")#mi("{H_t}")#text(" (inspired by similar computations in the ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("Ki-Kim-Lee paper")]#text(") which may be useful. The initial definition of ")#mi("{H_t}")#text(" is")

#align(center)[#tao-fit-display[#mitex("H_t(z) := \\int_0^\\infty e^{tu^2} \\Phi(u) \\cos(zu)\\ du")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Phi(u) := \\sum_{n=1}^\\infty (2\\pi^2 n^4 e^{9u} - 3 \\pi n^2 e^{5u}) \\exp(- \\pi n^2 e^{4u} )")]]

#text("is a variant of the ")#link("https://en.wikipedia.org/wiki/Theta_function#Jacobi_theta_function")[#text("Jacobi theta function")]#text(". We observe that ")#mi("{\\Phi}")#text(" in fact extends analytically to the strip ")#metadata(none) <tao-d60384034b77c13c2840>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\{ u \\in {\\bf C}: -\\frac{\\pi}{8} < \\mathrm{Im} u < \\frac{\\pi}{8} \\},")]]

#text("as ")#mi("{e^{4u}}")#text(" has positive real part on this strip. One can use the Poisson summation formula to verify that ")#mi("{\\Phi}")#text(" is even, ")#mi("{\\Phi(-u) = \\Phi(u)}")#text(" (see ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("this previous post")]#text(" for details). This lets us obtain a number of other formulae for ")#mi("{H_t}")#text(". Most obviously, one can unfold the integral to obtain")

#align(center)[#tao-fit-display[#mitex("H_t(z) = \\frac{1}{2} \\int_{-\\infty}^\\infty e^{tu^2} \\Phi(u) e^{izu}\\ du.")]]

#text("In my previous paper with Brad, we used this representation, combined with Fubini’s theorem to swap the sum and integral, to obtain a useful series representation for ")#mi("{H_t}")#text(" in the ")#mi("{t<0}")#text(" case. Unfortunately this is not possible in the ")#mi("{t>0}")#text(" case because expressions such as ")#mi("{e^{tu^2} e^{9u} \\exp( -\\pi n^2 e^{4u} ) e^{izu}}")#text(" diverge as ")#mi("{u}")#text(" approaches ")#mi("{-\\infty}")#text(". Nevertheless we can still perform the following contour integration manipulation. Let ")#mi("{0 \\leq \\theta < \\frac{\\pi}{8}}")#text(" be fixed. The function ")#mi("{\\Phi}")#text(" decays super-exponentially fast (much faster than ")#mi("{e^{tu^2}}")#text(", in particular) as ")#mi("{\\mathrm{Re} u \\rightarrow +\\infty}")#text(" with ")#mi("{-\\infty \\leq \\mathrm{Im} u \\leq \\theta}")#text("; as ")#mi("{\\Phi}")#text(" is even, we also have this decay as ")#mi("{\\mathrm{Re} u \\rightarrow -\\infty}")#text(" with ")#mi("{-\\infty \\leq \\mathrm{Im} u \\leq \\theta}")#text(" (this is despite each of the summands in ")#mi("{\\Phi}")#text(" having much slower decay in this direction – there is considerable cancellation!). Hence by the Cauchy integral formula we have")

#align(center)[#tao-fit-display[#mitex("H_t(z) = \\frac{1}{2} \\int_{i\\theta-\\infty}^{i\\theta+\\infty} e^{tu^2} \\Phi(u) e^{izu}\\ du.")]]

#text("Splitting the horizontal line from ")#mi("{i\\theta-\\infty}")#text(" to ")#mi("{i\\theta+\\infty}")#text(" at ")#mi("{i\\theta}")#text(" and using the even nature of ")#mi("{\\Phi(u)}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("H_t(z) = \\frac{1}{2} ( \\int_{i\\theta}^{i\\theta+\\infty} e^{tu^2} \\Phi(u) e^{izu}\\ du + \\int_{-i\\theta}^{-i\\theta+\\infty} e^{tu^2} \\Phi(u) e^{-izu}\\ du.")]]

#text("Using the functional equation ")#mi("{\\Phi(\\overline{u}) = \\overline{\\Phi(u)}}")#text(", we thus have the representation ")#metadata(none) <tao-c79c16a91848dd6b8ee2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("H_t(z) = \\frac{1}{2} ( K_{t,\\theta}(z) + \\overline{K_{t,\\theta}(\\overline{z})} )")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("K_{t,\\theta}(z)  & := \\int_{i\\theta}^{i \\theta+\\infty} e^{tu^2} \\Phi(u) e^{izu}\\ du", block: true)



#tao-math(" & = \\sum_{n=1}^\\infty 2 \\pi^2 n^4 I_{t, \\theta}( z - 9i, \\pi n^2 ) - 3 \\pi n^2 I_{t,\\theta}( z - 5i, \\pi n^2 )", block: true)
]

#text("where ")#mi("{I_{t,\\theta}(b,\\beta)}")#text(" is the oscillatory integral ")#metadata(none) <tao-ae8a3e3cda81343f4432>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("I_{t,\\theta}(b,\\beta) := \\int_{i\\theta}^{i\\theta+\\infty} \\exp( tu^2 - \\beta e^{4u} + i b u )\\ du.")]]

#text("The formula ")#link(<tao-c79c16a91848dd6b8ee2>)[#text("(2)")]#text(" is valid for any ")#mi("{0 \\leq \\theta < \\frac{\\pi}{8}}")#text(". Naively one would think that it would be simplest to take ")#mi("{\\theta=0}")#text("; however, when ")#mi("{z=x+iy}")#text(" and ")#mi("{x}")#text(" is large (with ")#mi("{y}")#text(" bounded), it seems asymptotically better to take ")#mi("{\\theta}")#text(" closer to ")#mi("{\\pi/8}")#text(", in particular something like ")#mi("{\\theta = \\frac{\\pi}{8} - \\frac{1}{4x}}")#text(" seems to be a reasonably good choice. This is because the integrand in ")#link(<tao-ae8a3e3cda81343f4432>)[#text("(3)")]#text(" becomes significantly less oscillatory and also much lower in amplitude; the ")#mi("{\\exp(ibu)}")#text(" term in ")#link(<tao-ae8a3e3cda81343f4432>)[#text("(3)")]#text(" now generates a factor roughly comparable to ")#mi("{\\exp( - \\pi x/8 )}")#text(" (which, as we will see below, is the main term in the decay asymptotics for ")#mi("{H_t(x+iy)}")#text("), while the ")#mi("{\\exp( - \\beta e^{4u} )}")#text(" term still exhibits a reasonable amount of decay as ")#mi("{u \\rightarrow \\infty}")#text(". We will use the representation ")#link(<tao-c79c16a91848dd6b8ee2>)[#text("(2)")]#text(" in the asymptotic analysis of ")#mi("{H_t}")#text(" below, but it may also be a useful representation to use for numerical purposes.")

#metadata(none) <tao-de7fd902c3a996b57098>

#heading(level: 1)[#strong[#text(" — 1. Numerical investigation of ")#mi("{H_t(z)}")#text(" — ")]]

#text("Python and Matlab code to compute ")#mi("{H_t(x+iy)}")#text(" for medium-sized values of ")#mi("{x}")#text(" are now available in the ")#link("https://github.com/km-git-acc/dbn_upper_bound")[#text("Polymath15 github repository")]#text(". It is expected that all the zeroes of these functions for ")#mi("{t \\geq 0}")#text(" are real (this is equivalent to the Riemann hypothesis). For ")#mi("{t=0}")#text(", ")#mi("{H_0(x)}")#text(" is zero precisely when ")#mi("{\\frac{1}{2}+\\frac{ix}{2}}")#text(" is a non-trivial zero of the Riemann zeta function, so the first few zeroes of ")#mi("{H_0}")#text(" occur at approximately")

#align(center)[#tao-fit-display[#mitex("28.25, 42.05, 50.05, 60.85, 65.85, 75.15, 81.85, 86.65, 96.05, 99.55.")]]

#text("As ")#mi("{t}")#text(" increases, we have observed that the zeroes drift slightly to the left. This is consistent with theory, for instance the number ")#mi("{N_t(T)}")#text(" of zeroes of ")#mi("{H_t}")#text(" of real part between ")#mi("{0}")#text(" and ")#mi("{T}")#text(" is known to be asymptotically ")#metadata(none) <tao-d4cc2e3bab6ba157a096>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("N_t(T) = \\frac{T}{4\\pi} \\log \\frac{T}{4\\pi} - \\frac{T}{4\\pi} + \\frac{t}{16} \\log \\frac{T}{4\\pi} + O_t(1)")]]

#text("so as ")#mi("{t}")#text(" increases we should expect a few more zeroes in this region. (I had incorrectly omitted the ")#mi("{16}")#text(" denominator in a previous version of ")#link(<tao-d4cc2e3bab6ba157a096>)[#text("(4)")]#text(".) It seems like a reasonable near-term aim to improve the numerics to the point where we can confirm this asymptotic.")

#text("A related theoretical result is that the gaps between zeroes ")#mi("{z_j(t)}")#text(" should behave locally like an arithmetic progression for large ")#mi("{j}")#text(", in the sense that")

#align(center)[#tao-fit-display[#mitex("z_{j+1}(t)-z_j(t) = (1+o_t(1)) \\frac{4\\pi}{\\log z_j(t)} = (1+o_t(1)) \\frac{4\\pi}{\\log j}.")]]

#text("This would also be nice to confirm numerically.")

#text("Theory also gives that the functions ")#mi("{H_t(x+iy)}")#text(" decay roughly like ")#mi("{\\exp(-\\pi x/8)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text("; see later sections for more precise asymptotics. To see this decay numerically for large ")#mi("{x}")#text(", it may be necessary to switch over to a representation such as ")#link(<tao-c79c16a91848dd6b8ee2>)[#text("(2)")]#text(" with ")#mi("{\\theta}")#text(" close to ")#mi("{\\pi/8}")#text(", otherwise the effect of numerical roundoff error may become unmanageably large.")

#heading(level: 1)[#strong[#text(" — 2. Dynamics of zeroes — ")]]

#text("Let ")#mi("{z_j(t)}")#text(" denote the zeroes of ")#mi("{H_t(z)}")#text(". For sake of discussion let us suppose that the zeroes are always simple (this is in fact predicted by theory assuming RH; see Corollary 2 of ")#link("https://link.springer.com/article/10.1007/BF01205170")[#text("Csordas-Smith-Varga")]#text(". It may in fact be possible to prove this claim unconditionally, but we may not need this claim for the present project). If we implicitly differentiate the equation")

#align(center)[#tao-fit-display[#mitex("H_t(z_j(t)) = 0")]]

#text("in time, we (formally, at least) obtain the equation")

#align(center)[#tao-fit-display[#mitex("(\\partial_t H_t)(z_j(t)) + \\partial_t z_j(t) (\\partial_z H_t)(z_j(t)) = 0.")]]

#text("The functions ")#mi("{H_t}")#text(" obey the backwards heat equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t H_t = - \\partial_{zz} H_t")]]

#text("and thus we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t z_j(t) = \\frac{(\\partial_{zz} H_t)(z_j(t))}{ (\\partial_{z} H_t)(z_j(t))}.")]]

#text("If we Taylor expand ")#mi("{H_t}")#text(" around the zero ")#mi("{z_j(t)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("H_t(z) = a_j (z - z_j(t)) + b_j (z-z_j(t))^2 + \\dots")]]

#text("for some coefficients ")#mi("{a_j,b_j}")#text(" with ")#mi("{a_j}")#text(" non-zero (because we are assuming the zeroes to be simple) then we have after a brief calculation")

#align(center)[#tao-fit-display[#mitex("\\frac{(\\partial_{zz} H_t)(z_j(t))}{ (\\partial_{z} H_t)(z_j(t))} = \\frac{2 b_j}{a_j}")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial_z H_t(z)}{H_t(z)} = \\frac{1}{z-z_j(t)} + \\frac{b_j}{a_j} + \\dots.")]]

#text("On the other hand, from Weierstrass factorisation we expect (formally at least) that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial_z H_t(z)}{H_t(z)} = \\sum_k \\frac{1}{z-z_k(t)}")]]

#text("and thus we should have")

#align(center)[#tao-fit-display[#mitex("\\frac{b_j}{a_j} = \\sum_{k \\neq j} \\frac{1}{z_j(t) - z_k(t)}.")]]

#text("Putting all this together, we should obtain the dynamics")

#align(center)[#tao-fit-display[#mitex("\\partial_t z_j(t) = - 2 \\sum_{k \\neq j} \\frac{1}{z_k(t) - z_j(t)}.")]]

#text("This is not rigorous for a number of reasons, most notably that the sum here is not absolutely convergent, but these equations should hold in a principal value sense at least. In the regime ")#mi("{t > \\Lambda}")#text(" this was established in Lemma 2.4 of ")#link("https://link.springer.com/article/10.1007/BF01205170")[#text("Csordas-Smith-Varga")]#text("; it may be possible to establish this in the entire region ")#mi("{t>0}")#text(".")

#text("If we write ")#mi("{z_j = x_j + i y_j}")#text(", we obtain the dynamics ")#metadata(none) <tao-3bdfca242cd70766d91d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_t x_j = - 2 \\sum_{k \\neq j} \\frac{x_k - x_j}{(x_k-x_j)^2 + (y_k - y_j)^2}")]]

#text("and ")#metadata(none) <tao-963b49f64ad6e7f7a85a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\partial_t y_j = 2 \\sum_{k \\neq j} \\frac{y_k - y_j}{(x_k-x_j)^2 + (y_k - y_j)^2}.")]]

#text("Informally, the real parts ")#mi("{x_j}")#text(" repel each other, while the imaginary parts attract each other. In particular, once a zero is real, it should stay real.")

#text("If a zero ")#mi("{x_j + i y_j}")#text(" is not real, then it has a complex conjugate ")#mi("{x_{j^{\\prime}} + iy_{j^{\\prime}} = x_j - iy_j}")#text(". Isolating the attraction that the imaginary part ")#mi("{y_j}")#text(" feels to its complex conjugate ")#mi("{y_{j^{\\prime}} = -y_j}")#text(", we obtain ")#metadata(none) <tao-09f5ffef28309853265c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t y_j = - \\frac{1}{y_j} + 2 \\sum_{k \\neq j, j^{\\prime}} \\frac{y_k - y_j}{(x_k-x_j)^2 + (y_k - y_j)^2}.")]]

#text("Suppose that ")#mi("{x_j + iy_j}")#text(" is a zero with maximal imaginary part ")#mi("{y_j}")#text(" (it is a result of Ki, Kim, and Lee that there are only finitely many non-real zeroes for ")#mi("{H_t}")#text(" with ")#mi("{t>0}")#text("). Then all the summands in ")#link(<tao-09f5ffef28309853265c>)[#text("(7)")]#text(" are non-positive, hence we have the differential inequality ")#metadata(none) <tao-a5141ad0906f3b94baed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\partial_t y_j \\leq - \\frac{1}{y_j}.")]]

#text("Hence if ")#mi("{\\sigma_{max}(t)}")#text(" denotes the maximal imaginary part of a zero of ")#mi("{H_t}")#text(", we (formally, at least) have")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\sigma_{max}(t) \\leq - \\frac{1}{\\sigma_{max}(t)}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\frac{1}{2} \\sigma_{max}^2(t) \\leq - 1")]]

#text("whenever ")#mi("{\\sigma_{max}(t)}")#text(" is positive. Thus the zeroes will be forced into the real axis in finite time, and in fact we can establish the bound")

#align(center)[#tao-fit-display[#mitex("\\Lambda \\leq t + \\frac{1}{2} \\sigma_{max}^2(t)")]]

#text("from this reasoning (this is a result of de Bruijn).")

#text("One could presumably do better by a more careful analysis of the sum in ")#link(<tao-09f5ffef28309853265c>)[#text("(7)")]#text(". The only way it seems that the inequality could be close to sharp is if the offending non-real zero ")#mi("{x_j + iy_j}")#text(" is somehow isolated far away from all other zeroes except for its complex conjugate ")#mi("{x_j + iy_j}")#text(". For large ")#mi("{x_j}")#text(", this is presumably in contradiction with the asymptotics ")#link(<tao-d4cc2e3bab6ba157a096>)[#text("(4)")]#text("; for small ")#mi("{x_j}")#text(", perhaps one could use numerics to exclude this possibility?")

#text("At time ")#mi("{t=0}")#text(", we know that the first ")#mi("{10^{13}}")#text(" zeroes are real (a ")#link("http://numbers.computation.free.fr/Constants/Miscellaneous/zetazeros1e13-1e24.pdf")[#text("result of Gourdon")]#text("). Thus any non-real zero will initially have a very large value of ")#mi("{x_j}")#text(". It would be nice to somehow be able to say that these zeroes continue to have very large real part for positive values of ")#mi("{t}")#text(" as well, but unfortunately the velocity in ")#link(<tao-3bdfca242cd70766d91d>)[#text("(5)")]#text(" could be large and negative if the zero is just to the left of another zero that is repelling it towards the origin. Is there some way to stop this? One may have to work with “clusters” of zeroes and study their centre of mass (or some similar statistic) as this may behave in a better way than an individual position function ")#mi("{x_j}")#text(". Perhaps some of the identities in this previous post could be adapted for this purpose?")

#heading(level: 1)[#strong[#text(" — 3. Asymptotics of ")#mi("{H_t}")#text(" — ")]]

#text("Standard calculations give the gaussian integral identity")

#align(center)[#tao-fit-display[#mitex("\\int \\exp( \\alpha_0 + \\frac{\\alpha_2}{2!} (u - u_0)^2 ) a_0\\ du = \\sqrt{\\frac{2\\pi}{-\\alpha_2}} a_0 \\exp(\\alpha_0)")]]

#text("whenever ")#mi("{a_0, \\alpha_0, \\alpha_2, u_0}")#text(" are complex numbers with ")#mi("{\\mathrm{Re} \\alpha_2 < 0}")#text(", where we integrate along a horizontal contour such as ")#mi("{{\\bf R}}")#text(" and we use the standard branch of the complex logarithm. More generally, ")#link("https://en.wikipedia.org/wiki/Laplace%27s_method")[#text("Laplace’s method")]#text(" suggests that one has the approximation")

#align(center)[#tao-fit-display[#mitex("\\int \\exp( f(u) ) a(u)\\ du \\approx \\sqrt{\\frac{2\\pi}{(-f^{\\prime\\prime}(u_0))}} a(u_0) \\exp( f(u_0) )")]]

#text("whenever ")#mi("{f}")#text(" is an oscillating phase that has a single stationary point ")#mi("{u_0}")#text(" (with ")#mi("{\\mathrm{Re} f^{\\prime\\prime}(u_0) < 0}")#text(") and ")#mi("{a}")#text(" is a slowly varying amplitude, and the integral is along a contour that does not start or end too close to ")#mi("{u_0}")#text(". (Here one uses the standard branch of the square root function.) There are several ways to make this approximation rigorous, such as the method of steepest descent, the saddle point method, or the method of stationary phase, but for this discussion let us work completely informally. One can apply this method to analyse the integrals ")#link(<tao-ae8a3e3cda81343f4432>)[#text("(3)")]#text(". For the highest accuracy, one should use the phase ")#mi("{f(u) = tu^2 - \\beta e^{4u} + ibu}")#text("; this is the approach taken for instance in ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("my paper with Brad")]#text(" (in the ")#mi("{t<0}")#text(" case), but has the drawback that the stationary point ")#mi("{u_0}")#text(" has to be defined using the ")#link("https://en.wikipedia.org/wiki/Lambert_W_function")[#text("Lambert ")#mi("{W}")#text("-function")]#text(". A more “quick and dirty” approach, which seems to give worse error bounds but still gives broadly correct qualitative conclusions, is only take the phase ")#mi("{f(u) = - \\beta e^{4u} + ibu}")#text(" and treat the factor ")#mi("{a(u) = \\exp( t u^2 )}")#text(" as an amplitude. In this case, the stationary point occurs at")

#align(center)[#tao-fit-display[#mitex("u_0 = \\frac{1}{4} \\log \\frac{ib}{4\\beta}")]]

#text("(where we use the branch of the logarithm that makes ")#mi("{u_0}")#text(" lie in the strip ")#link(<tao-d60384034b77c13c2840>)[#text("(1)")]#text("), with")

#align(center)[#tao-fit-display[#mitex("f(u_0) = - \\frac{ib}{4} + \\frac{ib}{4} \\log \\frac{ib}{4\\beta}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f^{\\prime\\prime}(u_0) = -4ib.")]]

#text("This suggests that we have the approximation")

#align(center)[#tao-fit-display[#mitex("I_{t,\\theta}(b,\\beta) \\approx \\sqrt{\\frac{\\pi}{2ib}} \\exp( \\frac{t}{16} \\log^2 \\frac{ib}{4\\beta} - \\frac{ib}{4} + \\frac{ib}{4} \\log \\frac{ib}{4\\beta} ).")]]

#text("(I think that in order for this approximation to be rigorous, one needs to take ")#mi("{\\theta}")#text(" to be close to the imaginary part of ")#mi("{u_0}")#text(", in particular close to ")#mi("{\\pi/8}")#text(".) Now, from ")#link(<tao-c79c16a91848dd6b8ee2>)[#text("(2)")]#text(" one has ")#metadata(none) <tao-c9c8dae3ad8ae94a7443>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("H_t(x+iy) = \\frac{1}{2} \\sum_{n=1}^\\infty")]]

#tao-aligned(keep: true)[


#tao-math("2 \\pi^2 n^4 I_{t, \\theta}( x - (9-y)i, \\pi n^2 )  & - 3 \\pi n^2 I_{t,\\theta}( x - (5-y)i, \\pi n^2 )", block: true)



#tao-math(" & + 2 \\pi^2 n^4 \\overline{I_{t, \\theta}( x - (9+y)i, \\pi n^2 )} - 3 \\pi n^2 \\overline{I_{t,\\theta}( x + (5-y)i, \\pi n^2 )}.", block: true)
]

#text("Here we consider the regime where ")#mi("{x}")#text(" is large and ")#mi("{y}")#text(" is positive but fairly small. Let’s just look at the term")

#align(center)[#tao-fit-display[#mitex("I_{t, \\theta}( x - (9+y)i, \\pi n^2 ).")]]

#text("Taking ")#mi("{b = x - (9+y)i}")#text(" and ")#mi("{\\beta = \\pi n^2}")#text(", we approximately have")

#align(center)[#tao-fit-display[#mitex("\\log \\frac{ib}{4\\beta} \\approx \\log \\frac{x}{4\\pi n^2} + i ( \\frac{\\pi}{2} - \\frac{9+y}{x} )")]]

#text("and so (after some calculation, and dropping terms of size ")#mi("{o(1)}")#text(") we have the somewhat crude approximation")

#align(center)[#tao-fit-display[#mitex("I_{t,\\theta}( x - (9+y)i, \\pi n^2 ) \\approx \\sqrt{\\frac{\\pi}{2ix}} \\exp( A + iB )")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("A := \\frac{t}{16} \\log^2 \\frac{x}{4\\pi n^2} - \\frac{t \\pi^2}{64} + \\frac{9+y}{4} \\log \\frac{x}{4\\pi n^2} - \\frac{\\pi x}{8}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B := \\frac{\\pi t}{16} \\log \\frac{x}{4\\pi n^2} - \\frac{x}{4} + \\frac{x}{4} \\log \\frac{x}{4\\pi n^2} + \\frac{\\pi (9+y)}{8}.")]]

#text("In particular, we expect the magnitude ")#tao-math("{\\left|I_{t,\\theta}( x - (9+y)i, \\pi n^2 )\\right|}", block: false)#text(" to behave like")

#align(center)[#tao-fit-display[#tao-math("\\left|I_{t,\\theta}( x - (9+y)i, \\pi n^2 )\\right| \\approx \\sqrt{\\frac{\\pi}{2x}} (\\frac{x}{4\\pi n^2})^{(9+y)/4} e^{-\\pi x/8}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( \\frac{t}{16} \\log^2 \\frac{x}{4\\pi n^2} - \\frac{t \\pi^2}{64} ).")]]

#text("Similarly for the other three ")#mi("{I_{t,\\theta}}")#text(" expressions that appear in ")#link(<tao-c9c8dae3ad8ae94a7443>)[#text("(9)")]#text(". If ")#mi("{t, y>0}")#text(" and ")#mi("{x}")#text(" is large, this suggests that the ")#mi("{n=1}")#text(" terms in ")#link(<tao-c9c8dae3ad8ae94a7443>)[#text("(9)")]#text(" dominate, and furthermore of the four terms, it is the third term which dominates the other three. Thus we expect to have")

#tao-aligned(keep: true)[


#tao-math("H_t(x+iy)  & \\approx \\pi^2 \\overline{I_{t, \\theta}( x - (9+y)i, \\pi )}", block: true)



#tao-math(" & \\approx \\pi^2 \\sqrt{\\frac{\\pi}{-2ix}} (\\frac{x}{4\\pi})^{(9+y)/4} e^{-\\pi x/8} \\exp( \\frac{t}{16} \\log^2 \\frac{x}{4\\pi} - \\frac{t \\pi^2}{64} ) \\exp(- iB )", block: true)
]

#text("where")

#align(center)[#tao-fit-display[#mitex("B := \\frac{\\pi t}{16} \\log \\frac{x}{4\\pi} - \\frac{x}{4} + \\frac{x}{4} \\log \\frac{x}{4\\pi} + \\frac{\\pi (9+y)}{8}.")]]

#text("Dividing the phase ")#mi("{B}")#text(" by ")#mi("{\\pi}")#text(" and using the argument principle, we now see where the asymptotic ")#link(<tao-d4cc2e3bab6ba157a096>)[#text("(4)")]#text(" is supposed to come from. Taking magnitudes we also expect")

#align(center)[#tao-fit-display[#tao-math("\\left|H_t(x+iy)\\right| \\approx \\pi^2 \\sqrt{\\frac{\\pi}{2x}} (\\frac{x}{4\\pi})^{(9+y)/4} e^{-\\pi x/8} \\exp( \\frac{t}{16} \\log^2 \\frac{x}{4\\pi} - \\frac{t \\pi^2}{64} ),", block: true)]]

#text("in particular ")#mi("{H_t(x+iy)}")#text(" should be non-zero for fixed ")#mi("{t,y>0}")#text(" and large ")#mi("{x}")#text(".")

#text("Hopefully we will be able to make these asymptotics more precise, and also they can be confirmed by numerics (in particular there may be some sign errors or other numerical inaccuracies in my calculations above which numerics might be able to detect).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (95)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491839")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Terry, do you have any particular ")#mi("t, T")#text(" in mind when you say numerically verify ")#mi("N_t(T)")#text("?")

#text("I am trying to understand how the numerical verification is going to be used?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491845")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Not yet; but I would like to get an idea of how large ")#mi("T")#text(" needs to be compared with ")#mi("t")#text(" for these asymptotics to become visible. This would give us some intuition as to how large the numerical zero free region would have to be for various choices of ")#mi("t")#text(", though perhaps we would not be directly using these asymptotics to bound the size of the zero free region.")

#text("Also, I think using the numerics to confirm a theoretical prediction would help root out any sign errors or other bugs in either the numerics or theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("In the statement of the third topic, ")#mi("\\epsilon = 0")#text(" can also be allowed (since for each ")#mi("t > 0")#text(", ")#mi("H_t")#text(" has only finitely many zeros).")

#text("It seems that (6) implies that the term ")#mi("-1/y_j")#text(" in (7) and (8) should be ")#mi("-4/y_j")#text(".")

#text("It is not clear where is formula (9).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491843")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("The equation (9) is now visible.")

#text("As for (7) and (8): if ")#mi("x_k+iy_k = x_j - iy_j")#text(" is the complex conjugate of ")#mi("x_j+iy_j")#text(", then ")#mi("-2 \\frac{y_k-y_j}{(x_k-x_j)^2+(y_k-y_j)^2}")#text(" will equal ")#mi("-\\frac{1}{y_j}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491842")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("It seems that in (4), the remainder term ")#mi("O(1)")#text(" should be ")#mi("O_t(1)")#text(", and in the next displayed formula ")#mi("o(1)")#text(" should be ")#mi("o_t(1)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491844")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("Good point; the estimates for ")#mi("H_t")#text(" for a fixed ")#mi("t>0")#text(" are in many ways much better than the estimates for the (far more intensively studied) ")#mi("H_0")#text(" (and the zeroes for the latter certainly do not arrange themselves in an arithmetic progression asymptotically), but there is no contradiction between the two, because the error terms for the former blow up in the limit ")#mi("t \\to 0^+")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491849")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("There are some updates.")

#text("There is now a function which can take complex initial guesses as input Ht_complex_root_finder(z,t) and try to find the closest complex root (for small to medium z values). Tried near the first few zeroes and it always converges near the actual zero location.")

#text("For eg.")#linebreak()#text(" guess_z, t, estimated_root_z")#linebreak()#text(" 28.2 + 0.1j, 0, 28.26945 + 8.79635e-09j")#linebreak()#text(" 28.2 + 0.1j, 0.5, 27.98018 – 4.55597e-10j")#linebreak()#text(" 39 + 0.4j, 0, 42.04407 + 3.96173e-15j")#linebreak()#text(" 58 + 0.3j, 0.35, 60.51891 – 1.37051e-05j")

#text("There are convergence problems as the imaginary part in the initial guess is increased too much, but the imaginary parts of potential roots are expected to be on the smaller side, so we can start with smaller guesses.")

#text("The approx function in the last section of the article, for computing H_t for large values of z has also been put in, but the calculations have to be verified.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491853")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Is there an error-bound on the imaginare part? that means, how can you relate the numerical error to the ")#mi("\\epsilon")#text(" for the error-free region in ")#mi("x+iy")#text(" with ")#mi("\\epsilon>0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Well the numerical error is quite influenced by roundoff errors, so I think unless epsilon is much greater than the computed imaginary parts, it will be difficult to confidently relate the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491855")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("But isn’t this the goal of such calculations? finding the zeros, identifying the imaginary part of them to get ")#mi("\\epsilon")#text("? (and improving the precision of the calculation to decrease ")#mi("\\epsilon")#text(") I might have misunderstood this, sorry. in this case, how else would one find zero-free regions?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Yeah we will just have to keep improving the precision while making the calculations as we keep decreasing epsilon. For a given T and epsilon, if we compute all the zeroes in the bounded region and they turn out to have x<T and y<<epsilon, then we can be confident that the x epsilon region is zero free.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("..The last line should be xepsilon should then be zero free..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491861")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Thanks, then I understood it correctly. I am just wondering about a quantitative way to get a lower-bound ")#mi("\\epsilon")#text(", or more concretely concerning your answer, how to quantify ")#mi("y << \\epsilon")#text("? Sorry if this is obvious for the experts, i am just curious.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f8f9b5a6cbc79efa82226a86929dbdbd2668da505056a2a49276ffcfc6a0d5a-85c0a936f7a9698a842b038b35e2c3079f82de78605ec9a35e01b7df0d8c1e81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dhjpolymath")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491850")[#strong[#text("dhjpolymath")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Here is some input values for which zeros have been calculated using the version of utility, h_t_probable…, h_t_real… which was available after the first few commits on github. In what follows “zeros a-b” correspond to replacing “enumerate(first_1000_H0_zeros)” with “enumerate(first_1000_H0_zero[600:700])” and the step in t is .01.")

#text("t=.20-.42, zeros 300-400,")#linebreak()#text(" t=.01-.19 zeros 400-500,")#linebreak()#text(" t=.15-.27 zeros 300-400,")#linebreak()#text(" t=.01-.09 zeros 500-600,")#linebreak()#text(" t=.05-.38 zeros 100-200,")#linebreak()#text(" t=.05-.26 zeros 200-300,")#linebreak()#text(" t=.15-.27 zeros 400-500,")#linebreak()#text(" t=.10-.28 zeros 300-400,")#linebreak()#text(" t=.15-.38 zeros 200-300.")

#text("These computations overlap some in places, are ongoing, and are set to terminate after t reaches .50 ( currently ~5 hours in on multiple 2.5 Ghz processors).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("enumerate(first_1000_H0_zero[600:700]) would be replaced by enumerate(first_1000_H0_zero[a:b]) from your description.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("There is a right parenthesis missing in the formula just before (2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("After ” using the even nature”, ")#mi("H_0(z)")#text(" has a missing closing bracket.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491856")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("This comment is targetted to those who plan to work on the numerical part of this project")

#text("=============================================")

#text("Hey All, I checked out the most recent commit and it has broken some functions. For example, “python python/H0_real_compute.py” doesn’t work anymore. And I don’t even know if it is supposed to work or not :(")

#text("I have some suggestions to make it easy for")

#text("(a) coders to understand the goals and objective of the code")#linebreak()#text(" (b) coders to contribute code to this project.")#linebreak()#text(" (c) non-coders to set up the code on their machines and run the files with minimal handholding")

#text("I foresee more people joining this project, and I recommend the following to build and maintain momentum.")

#text("1. Maintain a coding guideline — style (PEP-8 for python), appropriate comments, and docstrings.")

#text("2. Make clear what the expectations are for sending a PR. Having a good code structure and style will go a long way.")

#text("3. Only merge to master after a PR has been done and approved by at least one peer.")

#text("4. Migrate the code to Python 3+. The only minor conflicts I see are in the print statements and it is quite easy to port to 3+. The industry is moving in that direction. Moreover, Numpy is only going to support 2.7 until the end of the year.")

#text("Since polymath15 is just taking off, I thought I should put it out there before it becomes too big and unwieldy. I am happy to contribute in any way I can.")

#text("Thoughts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Thanks for the guidelines. 2) and 3) are especially important and its possible I made some changes without realizing it. Have also added you as a collaborator there so you can make the necessary changes. Do let me know how I can help in cleaning up things. – KM")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("One possible way to limit the number of complex zeroes of ")#mi("H_t")#text(" in the range ")#mi("\\{ x+iy: 0 \\leq x \\leq T \\}")#text(" is to get a lower bound on the number of real zeroes by numerically observing sign changes in ")#mi("H_t")#text(", and then also obtain an upper bound on the total number of zeroes by establishing an effective version of the formula (4). If we believe in the Riemann hypothesis, these two numbers should always only differ by ")#mi("O_t(1)")#text(" for any fixed ")#mi("t>0")#text(". So even without believing in the RH, this sort of computation should show that there are only ")#mi("O_t(1)")#text(" complex zeroes at most of real part at most ")#mi("T")#text(", whenever ")#mi("T")#text(" is large enough that we can numerically find all the real zeroes through sign changes. If we are _really_ lucky, we might be able to get the bound of complex zeroes below 2 in some cases, in which case there are no complex zeroes whatsoever in this region since they have to come in pairs.")

#text("One could imagine estimating ")#mi("N_t(T)")#text(" by the argument principle on a rectangle with vertices ")#mi("\\pm T \\pm i A")#text(" for some moderately large ")#mi("A")#text(". For ")#mi("A")#text(" large enough, the contribution of the two long horizontal sides should be manageable by theory, and one just has to numerically integrate ")#mi("H^{\\prime}_t(z)/H_t(z)")#text(" in the short vertical line segment from ")#mi("T-iA")#text(" to ")#mi("T+iA")#text(", which might be doable even for quite large values of ")#mi("T")#text(". Presumably tricks like this are already used in the literature on numerical verification of the RH; we might want to take a look at that literature for inspiration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491864")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("A variant strategy: thanks to numerical verification of RH, we know that there are no complex zeroes of ")#mi("H_0(x+iy)")#text(" in the rectangle ")#mi("\\{ x+iy: -T \\leq x \\leq T \\}")#text(" for some fairly large ")#mi("T")#text(" (of the order of ")#mi("10^{12}")#text("). If one can show that there are no zeroes of ")#mi("H_t(T+iy)=0")#text(" for ")#mi("0 \\leq t \\leq 1/2")#text(" and ")#mi("0 < y \\leq \\sqrt{1-2t}")#text(", then I think that this implies that there are no complex zeroes of ")#mi("H_t(x+iy)")#text(" in the region ")#mi("\\{ x+iy: -T \\leq x \\leq T \\}")#text(", because any complex zeroes of ")#mi("H_0")#text(" have no way to enter this region as time ")#mi("t")#text(" advances without becoming real, at which point they stay real indefinitely (note that all the zeroes of ")#mi("H_t")#text(" are known to have imaginary part at most ")#mi("\\sqrt{1-2t}")#text("). The point here is that the region that we have to keep zero-free has size ")#mi("O(1)")#text(" rather than ")#mi("O(T)")#text(" and so might be numerically feasible to work with even for quite large ")#mi("T")#text(". The one issue though is that we may need a fairly fine mesh of ")#mi("t")#text("'s, because there could be a complex zero that crosses this boundary at very high speed that might be somehow missed using a coarse mesh of ")#mi("t")#text("'s. Actually I'm not sure how to do a rigorous error analysis at present (but presumably theoretical estimates such as (4) will play a role).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491862")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("I would prefer “these equations should hold” instead of “it should be that these equations hold” which seems too clumsy to me.")

#emph[#text("[Edited – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491918")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("I was quoting the second line below the first display above (5) which looks unchanged.")

#emph[#text("[Hopefully the edit is more permanent now – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491863")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("For ")#mi("t > 0")#text(", the assumed dynamics for the simple zeros of ")#mi("H_t")#text(" can be proved as follows:")

#text("Since ")#mi("H_t(z)")#text(" is entire in both ")#mi("t")#text(" and ")#mi("z")#text(" and also satisfies the backwards heat equation, it follows (as shown above) that for each real ")#mi("t")#text(", any simple zero ")#mi("z_j(t)")#text(" satisfies")

#text("(*) ")#mi("\\partial_t z_j = H_{z z} (z_j) / H_z(z_j)")

#text("(dropping the “time” index ")#mi("t")#text(" for simplicity)")

#text("The main idea of the proof is to use the fact that the RHS involve only derivatives with respect to ")#mi("z")#text(" (thanks to the heat equation) and some analytic properties of ")#mi("H_t")#text(" for each ")#mi("t>0")#text(" to construct a sequence of polynomials ")#mi("P_N")#text(" converging locally uniformly on ")#mi("\\mathbb C")#text(" to ")#mi("H_t")#text(" with the following properties:")

#text("(i) Each zero of each ")#mi("P_N")#text(" is also a zero with the same multiplicity")#linebreak()#text(" of both ")#mi("P_{N+1}")#text(" and ")#mi("H_t")#text(".")

#text("(ii) Each zero of ")#mi("H_t")#text(" is a zero of some ")#mi("P_N")

#text("Note that for each simple(!) zero ")#mi("z_j")#text(" of ")#mi("H_t")#text(", the RHS of (*) is the limit of its values for the corresponding sequence of polynomials ")#mi("P_N")#text(" (converging locally uniformly to ")#mi("H_t")#text("). And the desired result follows (from the above ODE established above for polynomial zeros) since the LHS of (*) describes the dynamics for the same simple zeros (shared by both ")#mi("H_t")#text(" and its approximating polynomial sequence ")#mi("P_N")#text(").")

#text("To construct the polynomials, we use the fact ( KKL paper) that for each ")#mi("t > 0")#text(", ")#mi("H_t")#text(" is an entire even function of order 1, so by Hadamard’s factorization theorem, it has the form (after pairing its zeros ")#mi("z_k")#text(" and ")#mi("-z_k")#text(", which are distinct from zero, using any order with possibly finitely many repetitions – according to their multiplicities)")

#text("(**) ")#mi("H_t(z)  = c z^m \\prod_k (1 - z^2/z_k^2)")

#text("Where ")#mi("z_k")#text(" are the zeros of ")#mi("H_t")#text(" with positive real parts (and also, possibly, purely imaginary with positive imaginary parts), such that they are distinct from zero, ordered in any desired order (because (**) is absolutely locally uniformly convergent!) with possible repetitions (according to their multiplicities).")

#text("It remains only to define the polynomials")

#text("(***) ")#mi("P_N(z) = c z^m \\prod_{k =1}^N (1 - z^2 / z_k^2)")

#text("It follows that these polynomials have all the required properties above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("The proof I gave above has the issue that the approximating polynomial sequence ")#mi("P_N")#text(" not necessarily satisfy the heat equation (as ")#mi("H_t")#text(" does), but fortunately, I found a much simpler (and direct) proof: one needs only(!) to repeat your derivation above, using that the product representation (**) is converging locally uniformly to ")#mi("H_t(z)")#text(", thereby allowing termwise logarithmic derivative in (**) with the following result for each simple(!) zero ")#mi("z_j \\neq 0")#text(" of ")#mi("H_t(z)")#text(" :")

#mi("\\partial_t z_j =  2b_j/ a_j = 2 \\lim_{z \\to z_j} [H_z(z) / H(z) -1/(z-z_j)]")

#mi("= 2 [m / z_j +1/(2 z_j) + \\sum_{k \\neq j} [1/ (z_j - z_k) + 1/(z_j + z_k)]")

#text("where ")#mi("m")#text(" is the multiplicity of ")#mi("H_t(z)")#text(" at ")#mi("z = 0")#text(", and the convergent(!) summation is over the zeros ")#mi("z_k")#text(" of ")#mi("H_t(z)")#text(" (including multiplicities) which are distinct from ")#mi("z_j, -z_j")#text(" and having positive real parts or are purely imaginary with positive imaginary parts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e3465c667a783b4dd69e05a2dbd50aa88b0621ccb49edc2c3c79c97f81ba693-f0d95abd33b695e9233f3d83b27adeb50894436487ff9ddaf4c9309db7a283af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491869")[#strong[#text("Nick")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("I recently added sinh-sinh, exp-sinh, and trapezoidal quadrature into Boost.Math. They work in arbitrary precision using boost.multiprecision, but do not work in the complex plane, so these integrals will need to be split into real and complex parts to make them work in this case. I haven’t tried using it with interval arithmetic, but that might help establish more rigorous bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491872")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Here’s a small question that arose from trying to understand the dynamics of a simple zero under backwards heat flow. Suppose we replace ")#mi("H_0")#text(" by a monomial ")#mi("H_0(z) = z^k")#text(" for some natural number. Then the backwards heat flow ")#mi("\\partial_t H_t = -\\partial_{zz} H_t")#text(" (or ")#mi("H_t = \\exp(-t \\partial_{zz}) H_0")#text(") gives the family of polynomials")

#mi("H_t(z) = z^k - t \\partial_z^2 z^k + \\frac{t^2}{2!} \\partial_z^4 z^k - \\dots")

#text("so for instance")

#mi("H_t(z) = z^2 - 2t")

#text("for ")#mi("k=2")#text(",")

#mi("H_t(z) = z^3 - 6t z")

#text("for ")#mi("k=3")#text(",")

#mi("H_t(z) = z^4 - 12 t z^2 + 12 t^2")

#text("for ")#mi("k=4")#text(", and so forth.")

#text("Experimentally, it seems that in all of these cases, the zeroes of ")#mi("H_t")#text(" are purely imaginary for negative times and purely real for positive times. I wonder if this can be proven rigorously? It suggests that the only way zeroes can collide is if they approach each other vertically, and then repel each other horizontally.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("One may try to build a “Newtonian kinematic model” for the zeros distribution dynamics involving “acceleration” and “forces” applied on each zero by the others (assuming that the “mass measure” for each zero is its multiplicity) obviously we have the mass conservation law (i.e. multiplicity conservation law for clusters of zeros), it seems likely that “total momentum” of a cluster of zeros is also conserved with “elastic collisions” among zeros.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("Newtonian mechanics certainly provides a lot of intuition, but it should be taken with a grain of salt, because Newton’s second law ")#mi("F=ma")#text(" is a second-order equation, whereas the ODE here is first-order, with the repulsive “forces” directly affecting velocity rather than acceleration. Related to this is that these equations have a definite arrow of time: real zeroes repel each other going forward in time, but attract each other going backwards in time.")

#text("In my previous paper with Brad, we interpreted these equations as a gradient flow rather than a Newtonian system, but I am not sure if that is a useful perspective to take for the current project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Let ")#mi("v_j = \\partial_t z_j")#text(" be the “velocity” of a simple zero ")#mi("z_j")#text(" of ")#mi("H_t(z)")#text(". Its “acceleration” ")#mi("a_j = \\partial_t v_j")#text(" should be")

#mi("a_j = 2 \\sum_{k \\neq j} [(v_k - v_j) / (z_k - z_j)^2]")

#text("So (by using the expressions for the velocities ")#mi("v_k, v_j")#text(" in terms of the zeros locations) the acceleration ")#mi("a_j")#text(" can be expressed as a (complicated) function of the distances among the zeros.")#linebreak()#text(" This “acceleration function” seem to decay according to a “inverse cube law” with the distances among the zeros, but this second order ODE does not seem to have any apparent time arrow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491888")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Yeah, I am not sure how useful a first order flow vs. a second order flow perspective is. Both, the gradient flow and a Newtonian flow (with friction) brings down the potential function over time. The rate at which the potential decreases are different for these flows. For example, in a Newtonian flow with small friction (relative to inertial mass), there will be lots of oscillations before it settles down.")

#text("But, what we want in this context is an understanding of the contours of the potential itself, independent of where it is plugged in (gradient flow or a Newtonian flow with friction).")

#text("The purely imaginary for negative times and purely imaginary for positive times also makes it delicate. What stops the following: purely imaginary for ")#mi("t \\ll 0")#text(", purely real for ")#mi("t \\gg 0")#text(" and bouncing around in intermediate range?")

#text("Terry, you are missing a power of two in the derivative in the exponential sign above. ")#emph[#text("[Not sure what you are referring to here, but I am using ")#mi("\\partial_{zz}")#text(" as a synonym for ")#mi("\\partial_z^2")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("It may also be useful to note that the zeros dynamics seems to be invariant with respect to time translations, zeros locations translations and rotations. Does these symmetries indicate the possibility that this ODE zero dynamics has (still unknown) corresponding conserved invariants (analogous to “energy”, “linear momentum” and “angular momentum”) as in Newtonian mechanics")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491892")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("It’s not invariant under rotations (except by 180 degrees), because the reciprocal function ")#mi("z \\mapsto 1/z")#text(" is not rotation invariant. It’s not a Hamiltonian system, so symmetries don’t correspond with conservation laws; instead, it is a gradient flow, so I think symmetries have a chance instead of corresponding with monotonicity formulae. In the case of finitely many real zeroes, in ")#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("this previous blog post")]#text(" there were some interesting monotonicity formulae arising from the Hamiltonian ")#mi("\\sum_{i,j: i \\neq j} \\log\\frac{1}{z_i-z_j}")#text(", the energy ")#mi("\\sum_{i,j: i \\neq j} \\frac{1}{(z_i-z_j)^2}")#text(", the centre of mass ")#mi("\\frac{1}{N} \\sum_{i=1}^N z_i")#text(", and virial interaction ")#mi("\\sum_{i,j} (z_i-z_j)^2")#text(". Don’t know if any of these continue to be useful in our situation though, with infinitely many real zeroes and a finite number of additional complex zeroes.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491891")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("I think I am able to verify my previous claim that all the zeroes of the polynomials ")#mi("H_t")#text(" are real for ")#mi("t>0")#text(" and imaginary for ")#mi("t<0")#text(". By replacing ")#mi("t")#text(" with ")#mi("-t")#text(" (and ")#mi("z")#text(" with ")#mi("iz")#text(") it suffices to prove the first claim. Using the analysis in Section 2 of the above post we know that the zeroes of ")#mi("H_t")#text(" are eventually real and simple. On the other hand, they are self-similar: the zeroes of ")#mi("H_t")#text(" are ")#mi("\\sqrt{t}")#text(" times the zeroes of ")#mi("H_1")#text(". So the zeroes must be all real and simple.")

#text("By Rouche's theorem, this says more generally that when ")#mi("H_t")#text(" is a family of entire functions evolving by heat flow, at at some time ")#mi("t_0")#text(" they have a repeated zero of some order ")#mi("k")#text(" at some location ")#mi("z_0")#text(", then shortly after ")#mi("t_0")#text(" the ")#mi("k")#text(" zeroes will lie near the horizontal line through ")#mi("z_0")#text(", and shortly before ")#mi("t_0")#text(" they will lie near the vertical line through ")#mi("z_0")#text(". If we have the functional equation ")#mi("H_t(\\overline{z}) = \\overline{H_t(z)}")#text(", and ")#mi("z_0")#text(" is real, this means in particular that shortly after ")#mi("t_0")#text(" the ")#mi("k")#text(" zeroes will be purely real, and shortly before they will not be real (except perhaps for one zero if ")#mi("k")#text(" is odd).")

#text("So this seems to tell us how collisions of zeroes work for our functions ")#mi("H_t")#text(": it is possible for one or more pairs of complex zeroes fall into the real line (possibly hitting an existing real zero when doing so) and create a real zero of order two or more, which then immediately splits into real simple zeroes. Zeroes that are real stay real for all time, and can't collide with each other (but can collide with an incoming pair of complex zeroes as mentioned above). Finally it is in principle possible for two or more complex zeroes to collide with each other if they are approaching in an asymptotically vertical direction, in which case they will split away from each other in a horizontal direction. As there are only finitely many complex zeroes after any positive time, I think a compactness argument shows that there are only finitely many collisions after any positive time, though I don't see any way to rule them out completely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("I think that in case of a multiple zero of ")#mi("H_{t_0}")#text(", the dynamics of the zeros can be more complex, depending on the Puiseux expansion of each zero ")#mi("z_k(t)")#text(" trajectory as a power series in some fractional power of ")#mi("(t - t_0)")#text(". These Poiseux expansions of the trajectories of all the zeros (which can be determined by the Newton polygon method) can start with various directions (for instance, if the trajectory of some zero ")#mi("z_j(t)")#text(" has a power expansion in ")#mi("(t - t_0)^{1/3}")#text(" in a neighborhood of ")#mi("t_0")#text(", then there are two corresponding (or “conjugate”) trajectories of two other zeros such that all the three “conjugating” zero trajectories are “exploding” from the location of the multiple zero at ")#mi("t=t_0")#text(" with initial directions ")#mi("2 \\pi / 3")#text(" apart (so they can’t initially start at directions parallel to the horizontal or vertical axes.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491900")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Actually, it looks like the only Puiseux series dynamics that is consistent with the equation is if the zeroes move away from the fixed point at a rate of ")#mi("(t-t_0)^{1/2}")#text(". More precisely, if ")#mi("H_{t_0}")#text(" has a zero of order ")#mi("k")#text(" at ")#mi("z_0")#text(", then for ")#mi("t")#text(" near ")#mi("t_0")#text(", it appears that the ")#mi("k")#text(" zeroes ")#mi("z_1(t),\\dots,z_k(t)")#text(" of ")#mi("H_t")#text(" near ")#mi("z_0")#text(" take the form ")#mi("z_j(t) = z_0 + (t-t_0)^{1/2} (z_{j,0} + o(1))")#text(" as ")#mi("t \\to t_0")#text(", where ")#mi("z_{1,0},\\dots,z_{k,0}")#text(" are the (real, simple) roots of the degree ")#mi("k")#text(" polynomial ")#mi("\\sum_{j=0}^\\infty \\frac{1}{j!} (-\\partial_{zz})^j z^k")#text(". Indeed, one can normalise ")#mi("t_0 = 0, z_0 = 0")#text(" and ")#mi("H_0(z) = z^k + l.o.t.")#text(", in which case ")#mi("H_t(z)")#text(" is equal to ")#mi("\\sum_{j=0}^\\infty \\frac{1}{j!} t^j (-\\partial_{zz})^j z^k + l.o.t.")#text(", and the claim follows by rescaling by ")#tao-math("\\left|t\\right|^{1/2}", block: false)#text(" and using Rouche’s theorem.")

#text("In response to a previous blog post, there ")#link("https://twitter.com/gabrielpeyre/status/920731190461648896")[#text("was a tweet")]#text(" displaying some pictures of dynamics of zeroes under heat flow. I wonder if that sort of code could be placed in the repository, it might be useful to play with to get some intuition for this dynamics.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Gabriel’s code is now available in the matlab folder of the repo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Thanks! I see there’s a lot of new python code in the repo, I wonder if someone can summarise what’s been going on there in the last few days.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491907")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("Terry, regarding the code, here are some updates.")

#text("1. There was some amount of refactoring along with the addition of code of conduct and how to contribute.")#linebreak()#text(" 2. The outputs are moved out of the main code base. The plots and numbers are in output/plots and output/numbers folders respectively.")#linebreak()#text(" 3. There is some discussion happening on the GitHub /issues page. I think some of it should be moved to this blog, or maybe a separate page dedicated to just the numerical part.")#linebreak()#text(" 4. We have some additional data for the first 1000 roots of ")#mi("H_t")#text(" for various values of ")#mi("t")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491911")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("Also worth mentioning that only the data for the first 100 or so zeroes for a given t should be treated as accurate. Ht computation is currently relying on cos(zu) computation (theta=0), which is not very reliable for numerics after a point.")

#text("We are attempting to code the I_t_theta and K_t_theta functions for better estimates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491912")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("It means that if there is a zero ")#mi("z_0")#text(" of ")#mi("H_{t_0}")#text(" with multiplicity ")#mi("m")#text(", there is a neighborhood ")#mi("U_{z_0, t_0}")#text(" of ")#mi("z_0")#text(" such that for any ")#mi("t \\neq t_0")#text(" sufficiently close to ")#mi("t_0")#text(", all ")#mi("m")#text(" zeros ")#mi("z_j(t)")#text(" of ")#mi("H_t")#text(" in this neighborhood are simple and ")#mi("z_j(t)")#text(" can be either")

#text("(i) analytic trajectory passing through ")#mi("t_0")#text(", or")

#text("(ii) singular trajectory which is analytic in ")#mi("(t - t_0)^{1/2}")#text(" (i.e. has a converging power series in ")#mi("(t - t_0)^{1/2}")#text(") and consists of an “incoming singular trajectory” for ")#mi("t  t_0")#text(".")

#text("If there are ")#mi("m_1")#text(" analytic trajectories and ")#mi("m_2")#text(" singular trajectories, then (clearly) ")#mi("m = m_1 + m_2")#text(".")#linebreak()#text(" It is interesting to observe that ")#mi("m_2")#text(" must be even! (this is because each singular power series in ")#mi("(t-t_0)^{1/2}")#text(" has also a distinct(!) “conjugate” series induces by changing the argument ")#mi("(t-t_0)^{1/2}")#text(" in the series to ")#mi("-(t-t_0)^{1/2}")#text(" – thereby giving four(!) singular semi-branches – two incoming and two outgoing).")

#text("It seems that any partition of the multiplicity ")#mi("m")#text(" into ")#mi("m_1")#text(" analytic trajectories and ")#mi("m_2")#text(" singular trajectories (with corresponding ")#mi("m_2")#text(" incoming branches and ")#mi("m_2")#text(" outgoing branches) is allowed provided that m_2 is even.")

#text("This seems to imply that the velocity of any (incoming or outgoing) zero ")#mi("z_j(t)")#text(" near any multiple zero of ")#mi("H_{t_0}")#text(" is bounded by ")#tao-math("O(\\left|t-t_0\\right|^{-1/2})", block: false)#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/656f75c2dde532d30adb4a268be5822a46e45934a001d21ccb5286e8d3ea351a-32758fa3ffd5d1778e57e86ace0d6afb324ea402b27bef9f566a4dcaa1b43f90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien Friedli")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491899")[#strong[#text("Fabien Friedli")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")])]

#text("I think another way to prove this fact is to use Sturm theorem which relates the number of real roots of a polynomial to the number of sign changes in the corresponding Sturm sequence. If I’m not mistaken, in this particular case the n-th polynomial in the Sturm sequence is given by")

#mi("P_n(z)=2^{[\\frac{n}{2}]}t^{[\\frac{n-2}{2}]}\\sum_{j=1}^{\\frac{k}{2}-[\\frac{n-1}{2}]}\\frac{(-1)^{j+1}t^j\\lambda_k(n)}{(j-1)!(k-2j-n+2)!}z^{k-2j-n+2},")

#text("where ")#mi("\\lambda_k(n)=k(k-2)(k-4)\\cdots(k-n+1)!")#text(" if ")#mi("n")#text(" is odd and ")#mi("\\lambda_k(n)=(k-1)(k-3)(k-5)\\cdots(k-n+1)!")#text(" if ")#mi("n")#text(" is even.")

#text("(I hope the latex code appears correctly, sorry if that is not the case.)")

#text("In particular, if ")#mi("t>0")#text(", the main coefficient is always positive, so there is no sign changes in the sequence evaluated at ")#mi("+\\infty")#text(" and there is ")#mi("k")#text(" sign changes in the sequence evaluated at ")#mi("-\\infty")#text(". Since the polynomial is of degree ")#mi("k")#text(", we deduce that all the roots are real and simple.")

#text("This proof (if correct) is a bit longer and not as nice but it doesn’t use the analysis of Section 2. Also maybe it’s possible to have more information about the location of the zeros by using Sturm theorem on some finite interval instead of ")#mi("(-\\infty,+\\infty)")#text(", since we have an explicit formula.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92de18753b09812cfe78cbce04b76697dc7573ea3c4722016f2b8a9b4502f3a4-5e12eff0f87d0e218c957596559df00bf9c36b15eba61d0bb1667c6f3b57e4e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491878")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2018")])]

#text("There is a typo in the third line after “In my previous paper with Brad,”.")

#text("You meant “for ")#mi("H_t")#text(" in the ")#mi("t >0")#text(" case”, right?")

#emph[#text("[Not quite; I’ve fixed the text for now, but unfortunately due to the HTML parser eating text between < and > signs, the problem may recur with my next edit of the post if I’m not careful. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491882")[#strong[#text("Simo Ryu")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2018")]

#text("Always appreciate your good explanation on such interesting topic sir.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("Here is an example of how some further analysis of the dynamics of zeroes can make it easier to numerically establish a bound of the form ")#mi("\\sigma_{max}(t_0) \\leq \\varepsilon")#text(" for some ")#mi("t_0, \\varepsilon > 0")#text(".")

#text("Let ")#mi("x_j+iy_j")#text(" be a zero with positive imaginary part ")#mi("y_j > 0")#text(", then by equation (7) in the post we have the dynamics")

#mi("\\displaystyle \\partial_t y_j = -\\frac{1}{y_j} + 2 \\sum_{k \\neq j,j^{\\prime}} \\frac{y_k - y_j}{(x_k-x_j)^2 + (y_k-y_j)^2}")

#text("where ")#mi("x_{j^{\\prime}} + iy_{j^{\\prime}} = x_j - iy_j")#text(" is the conjugate zero to ")#mi("x_j + iy_j")#text(". The first term is of course negative, reflecting the downward pull of the conjugate zero. Any real zero ")#mi("x_k")#text(" (with ")#mi("y_k=0")#text("), or more generally any zero ")#mi("x_k+iy_k")#text(" lower than or equal to the current zero (so ")#mi("y_k \\leq y_j")#text(" also contributes a non-positive term. A zero ")#mi("x_k+iy_k")#text(" lying above the current zero (so ")#mi("y_k > y_j")#text(") contributes a positive term of ")#mi("2 \\frac{y_k - y_j}{(x_k-x_j)^2 + (y_k-y_j)^2}")#text(", but its conjugate zero ")#mi("x_k - iy_k")#text(" contributes a negative term of ")#mi("-2 \\frac{y_k + y_j}{(x_k-x_j)^2 + (y_k+y_j)^2}")#text(". So the net contribution of this zero and its conjugate is only positive if")

#mi("\\displaystyle \\frac{y_k - y_j}{(x_k-x_j)^2 + (y_k-y_j)^2} > \\frac{y_k + y_j}{(x_k-x_j)^2 + (y_k + y_j)^2}")

#text("which after some tedious calculation simplifies to")

#mi("\\displaystyle y_k^2 > y_j^2 + (x_k-x_j)^2.")

#text("(This probably relates to some classical fact about the geometry of hyperbolae, but I don’t recognise it immediately.)")

#text("In particular, if there are no zeroes in the hyperbola ")#mi("\\{ x+iy: y^2 > y_j^2 + (x-x_j)^2\\}")#text(" above ")#mi("x_j+iy_j")#text(", then the net velocity ")#mi("\\partial_t y_j")#text(" is negative.")

#text("This has the following consequence:")

#strong[#text("Proposition")]#text(" Suppose ")#mi("T, t_0, \\varepsilon > 0")#text(" are such that")

#text("1. All the zeroes of ")#mi("H_0")#text(" in the strip ")#mi("\\{ x+iy: 0 \\leq x \\leq T\\}")#text(" are real;")#linebreak()#text(" 2. There are no zeroes of ")#mi("H_t")#text(" in the hyperbolic wedge ")#mi("\\{ x+iy: y^2 \\geq \\varepsilon^2 + (x-T)^2; x \\geq T \\}")#text(" above ")#mi("T + i \\varepsilon")#text(" for any ")#mi("0 \\leq t \\leq t_0")#text(". (Actually one only needs to check this for ")#mi("y \\leq \\sqrt{1-2t}")#text(", as we know that there are no zeroes above this height.)")

#text("Then there are no zeroes of ")#mi("H_t")#text(" in the region ")#mi("\\{x+iy: 0 \\leq x \\leq T; y \\geq \\varepsilon \\}")#text(" for any ")#mi("0 \\leq t \\leq t_0")#text(".")

#strong[#text("Proof")]#text(" Suppose not, then let ")#mi("t")#text(" be the first time where there is a zero ")#mi("x_j+iy_j = x_j + i \\varepsilon")#text(" entering the forbidden region. By hypothesis 1, ")#mi("t")#text(" is positive. But by hypothesis 2, ")#mi("\\partial_t y_j")#text(" is negative, and so the zero in fact was in the forbidden region previous to time ")#mi("t")#text(", a contradiction. (To be fully rigorous, one may also have to treat separately the case of a repeated zero.) ")#mi("\\Box")

#text("This proposition is similar to a statement I made in a previous comment, in which ")#mi("\\varepsilon=0")#text(" and the wedge was replaced by a ray ")#mi("\\{T+iy: y >  0 \\}")#text(". But this new formulation has the advantage that the wedge in which one has to prevent zeroes is a positive distance away from the real line, which should make it easier to numerically exclude zeroes from this region, since we do expect there to be zeros traveling across the real axis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("Does condition 2 above should apply for all ")#mi("x > 0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491920")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("I had omitted a condition ")#mi("x \\geq T")#text(", although it is not terribly important. The region that one needs to keep zero free sits above ")#mi("T + i \\varepsilon")#text(" and has diameter ")#mi("O(1)")#text(", so it is hopefully numerically feasible to actually verify this condition even for quite large values of ")#mi("T")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("In particular, the simple condition ")#mi("T \\leq x \\leq T +1")#text(" should be sufficient (since for ")#mi("x > T+1")#text(", each point of the hyperbolic wedge has imaginary part greater than 1). So it seems that what is required now is an effective(!) upper bound on the horizontal velocities of zeros ")#mi("z_j(t)")#text(" with real parts ")#mi("x_j(t) = T +O(1)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491923")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("So, I’ve been playing around with some deformations of various formulas; I think I may have found one of interest.")

#text("Define ")#mi("H_{t,\\psi}(z) = \\int_0^{\\infty} e^{tu^2} e^{-\\psi \\cosh(4u)} \\Phi(u) \\cos(zu)")#text(". We have ")#mi("dH_{t,\\psi}/d\\psi = -\\frac{1}{2} ( H_{t,\\psi} (z + 4i) + H_{t,\\psi} (z - 4i) )")#text(". We can also propagate this deformation back through the definition of ")#mi("\\Phi")#text(" to get deformed zeta functions: ")#mi("\\zeta_{\\psi}(s) = \\sum_{n=1}^{\\infty} 2\\pi^2 n^4 (\\pi n^2 + \\psi)^{-(s+4)/4} K_{-(s+4)/2}(2\\sqrt{\\pi n^2 + \\psi}) - 3\\pi n^2 (\\pi n^2 + \\psi)^{-(s+2)/4} K_{-(s+2)/2}(2\\sqrt{\\pi n^2 + \\psi})")#text(". (I think — may have messed up a bit, please check me). One benefit of this deformation is that you can now (hopefully) get a useful series expression for ")#mi("H_{t,\\psi}")#text(" even when ")#mi("t>0")#text(". Unfortunately, I’m not sure how useful the difference-differential equation is.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e129a68dcf0bb46ecba772753b8f9af1ec273d49cbd7ace8069058648b03b58-7eb33440dcbae163fc1d170d08c9c52deb82d4eb4253cf0fbe7e8b13997f3aa7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491926")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("If you additionally turn the 4 in ")#mi("\\cosh(4u)")#text(" into a deformation parameter, you lose the deformed zeta functions, keep the difference-differential equation, and gain a 3rd-order PDE for ")#mi("H")#text(" in ")#mi("t,\\psi")#text(" and the new parameter. That last one may be of interest, giving a new flow for the zeros.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("I think that in considering the zeros dynamics, one may assume without loss of generality that all the zeros of ")#mi("H_t")#text(" are simple, because the set ")#mi("S_*")#text(" (say) of “singular times” ")#mi("t_*")#text(" for which ")#mi("H_{t_*}")#text(" has a multiple zero is countable (each such ")#mi("t_*")#text(" is an intersection time of two trajectories from a countably many trajectories of countably many zeros of ")#mi("H_t")#text(") and therefore has measure zero, and the integrability of the zeros velocities (thanks to the continuity of the zeros) shows that the “singular times” set can be ignored for the purpose of estimating the zeros dynamics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cdbd72c0f5aec33c714478608ad6e537ceb31603a9db46a5659ab80a801b259-90dd1d0fc86c630531fc91aae4adc745e1b3818ef36c371efbe91e8f9361c683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SH")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491930")[#strong[#text("SH")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("I was looking through the data of the first 1000 zeros of H_.2(z), and the asymptotic (4) above appears to be very tightly matched. However, the asymptotic spacing of zeros seems way off, i.e. numerical errors seem unable to confirm this asymptotic. Also, some zeros are very close to each other. Does this imply a double root occurs? For example, I see the entry:")

#text("0.2 977 2790.7960430143326")#linebreak()#text(" 0.2 978 2790.7962358872796")

#text("Can anyone confirm my observations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2018")])]

#text("Perhaps the root finding algorithm somehow converged to the same root of ")#mi("h_0.2")#text(" (hence the step size of ")#mi("t")#text(" should be decreased).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491945")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Currently please treat only the first 100 or so zeroes for a given t as reliable. We are implementing less oscillatory formulas for calculating H_t for larger values of z which should make the estimates much better.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491956")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("I used the PARI/gp software package to numerically estimate the 10th zero of H_{0.2} and I obtain z_10 ~= 99.4597665 . The file: out_01_1000_20_22.txt on the git repo gives the value: z_10 ~= 99.547664956, or twice 49.773832478, which is the same as the tenth zeta zero according to Odlyzko:")#linebreak()#text(" ")#link("http://www.dtc.umn.edu/~odlyzko/zeta_tables/zeros1")[#text("http://www.dtc.umn.edu/~odlyzko/zeta_tables/zeros1")]#linebreak()#text(" It might be useful at some point to add an estimated precision to the computed zeroes, for example when comparing various calculation methods.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cdbd72c0f5aec33c714478608ad6e537ceb31603a9db46a5659ab80a801b259-90dd1d0fc86c630531fc91aae4adc745e1b3818ef36c371efbe91e8f9361c683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SH")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491971")[#strong[#text("SH")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("By “implementing less oscillatory formulas” do you mean you are using equation (3) above numerically, instead of the original equation for H_t ?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492060")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Yes, there are some functions in the repo Ittheta and Ktheta implemented (but not present in the main branch yet), where we try to do this. These still have to be sorted out completely.")

#text("On the other hand, now that we have a approx functional eqn, and if we also get expansions of the first few error terms soon, then it could be much faster and still accurate enough compared to the expensive quadrature based approaches.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491939")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Vague idea: when numerically find zeroes of ")#mi("\\zeta(s)")#text(", a key feature is that while the error term in the counting formula (Riemann–von Mangoldt, generalized in (4) above) can somewhat large, it is oscillatory and has quite a bit of cancellation. This observation (due to Turing, improving on Littlewood) makes it easy to tell if a count of zeroes is complete.")

#text("Perhaps something similar works for the deformations ")#mi("H_t(z)")#text(", in that the error term of equation (4) above is small on average over ")#mi("T")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491947")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Apologies for the terrible editing — I should have been more careful late at night.")

#emph[#text("[Unfortunately this implementation of wordpress does not permit users to edit their comments, but you can send corrections either in email to me or in an additional comment and I will be able to insert them -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebf33b531b4e8dd08b454c5f771488c3eb69eefb28c1522dfd6abd7b5de3e90-3648a13ba16939805f798516267ff2452301134564bb5f7b96b681c1828ceb20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491940")[#strong[#text("SM")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Typo: “{x} is sufficiently large depending on {x} and {\\varepsilon}” Twice {x}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Some back of the envelope calculations as to the point at which the single term ")#mi("I_{t,\\theta}(x-(9+y)i, \\pi )")#text(" dominates the expression (9) (thus producing a zero-free region):")

#text("let’s say ")#mi("x \\sim T")#text(" and ")#mi("y \\geq \\varepsilon")#text(". Using the predicted asymptotics in the post, the summands decay in ")#mi("n")#text(" like ")#mi("\\frac{1}{n^{1/2 + y/2 + t \\log x / 4}}")#text(", so the ")#mi("n=1")#text(" terms should dominate as long as ")#mi("t \\log T \\gg 1")#text(". (There are some problems with these asymptotics for extremely large ")#mi("n")#text(", but the contribution of those terms should be very small from some other estimates that I have not yet worked out in detail.)")

#text("The terms involving ")#mi("5 \\pm y")#text(" are about ")#mi("12/x")#text(" as large as the terms involving ")#mi("9 \\pm y")#text(", so these should be negligible when ")#mi("T \\gg 1")#text(".")

#text("The term involving ")#mi("I_{t,\\theta}(x-(9-y)i, \\pi )")#text(" is about ")#mi("(4\\pi/x)^y")#text(" as large as that of ")#mi("I_{t,\\theta}(x-(9+y)i, \\pi )")#text(", so that should be negligible when ")#mi("\\varepsilon \\log T \\gg 1")#text(".")

#text("So it seems that we will need to be in a regime in which ")#mi("\\log T \\gg \\max( \\frac{1}{\\varepsilon}, \\frac{1}{t} )")#text(" before we can use these asymptotics to guarantee a zero free region for ")#mi("\\{ x+iy: x \\geq T, y \\geq \\varepsilon \\}")#text(" for ")#mi("H_t")#text(". Given that we’re not likely to get ")#mi("T")#text(" to be much larger than ")#mi("10^{12}")#text(", this suggests that we can realistically hope to take ")#mi("t, \\varepsilon")#text(" to be something like ")#mi("1/10")#text(", which would lead to an upper bound for ")#mi("\\Lambda")#text(" which is something like ")#mi("0.2")#text(". Somewhat discouragingly, further gains only improve logarithmically with ")#mi("T")#text(" (roughly speaking, it seems like we will be able to prove a bound of the shape ")#mi("\\Lambda \\ll \\frac{1}{\\log T}")#text(" where ")#mi("T")#text(" is the largest real part ")#mi("x")#text(" for which we can numerically evaluate ")#mi("H_t(x+iy)")#text("), so there may be a limit as to how dramatic an improvement one would get from serious computer power.")

#text("In the converse direction, suppose there was a serious violation of the Riemann hypothesis at some scale ")#mi("T")#text(", so that ")#mi("H_0(x+iy)")#text(" for some ")#mi("x \\sim T")#text(" and ")#mi("y \\sim 1")#text(". From the Riemann-von Mangoldt formula one would expect this zero to move at velocity comparable to ")#mi("\\log T")#text(" (from the attraction of all the real zeroes at distance O(1) from this zero), so that it should take time about ")#mi("1/\\log T")#text(" for this zero to hit the real axis. So this bound of ")#mi("\\Lambda \\ll \\frac{1}{\\log T}")#text(" is unlikely to be improvable other than in the size of the constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491951")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("In line 13, it seems that ")#mi("I_{t, \\theta}(x-(9-y) i, \\pi)")#text("” should be corrected (")#mi("9+y")#text(" instead of ")#mi("9-y")#text(").")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("Is it expected that the upper bound on ")#mi("\\Lambda")#text(" is optimized for optimal ")#mi("t, \\epsilon^2")#text(" about the same size ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491957")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2018")])]

#text("It seems from the back of the envelope calculation that ")#mi("t")#text(" and ")#mi("\\varepsilon")#text(" will both end up being comparable to ")#mi("1/\\log T")#text(", which suggests that in the inequality ")#mi("\\Lambda \\leq t + \\frac{1}{2} \\varepsilon^2")#text(", the first term will dominate. To put it another way, lowering the ")#mi("t")#text(" parameter looks like it is going to be more important than lowering the ")#mi("\\varepsilon")#text(" parameter (I’m assuming here that the computational difficulty of evaluating ")#mi("H_t(x+iy)")#text(" for ")#mi("x \\sim T")#text(" and ")#mi("y \\sim \\varepsilon")#text(" depends primarily on ")#mi("T")#text(" and not so much on ")#mi("t")#text(" or ")#mi("\\varepsilon")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491978")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("Suppose for a start we try to tackle the case of t=0.49. c*exp(1/t) could be quite reasonable unless the constant c is large. Within this range one could also run root finding algorithms in the complex plane to get an estimate of sigma_max (the imaginary values will likely come out to be << sqrt(1-2t)). Do you think this is a feasible strategy with the current numerical algos (which aren't behaving well for large T yet)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("Is it possible to get an effective upper bounds on the (finite!) number of the non-real zeros of ")#mi("H_t")#text(" and for their real parts for any given ")#mi("t > 0")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("Quite possibly. What one can certainly do is give an effective upper bound for the real part ")#mi("x")#text(" of a zero ")#mi("H_t(x+iy)")#text(" with ")#mi("y \\geq \\varepsilon")#text("; it seems the KKL asymptotics give a bound of shape ")#mi("\\log x \\ll \\frac{1}{t} + \\frac{1}{\\varepsilon}")#text(", which when combined with the Riemann-von Mangoldt formula for ")#mi("H_t")#text(" gives an exponential type upper bound for the number of zeroes of real part larger than ")#mi("\\varepsilon")#text(". Presumably one can do better than this by importing some of the technology used to prove zero density theorems for the zeta function.")

#text("Ki and Kim (see Theorem 2.2 of ")#link("https://link.springer.com/article/10.1007/BF02788795")[#text("this paper")]#text(") also have some argument that shows that if all but finitely many zeroes have real part less than ")#mi("\\varepsilon")#text(" at some time ")#mi("t")#text(", then at some time shortly afterwards, all but finitely many zeroes will in fact be real. I have not looked at this argument in detail and don’t know how effective it can be made.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("It is interesting to observe that (by symmetry) the dynamics of each simple non-real zero ")#mi("z_k(t)")#text(" of ")#mi("H_t")#text(" is closely related (in fact a reflection with respect to the real and imaginary axes) to the dynamics of its three “reflections” ")#mi("-z_k(t), \\overline {z_k(t)}, -\\overline {z_k(t)}")#text(" (except when ")#mi("z_k(t)")#text(" is purely imaginary, i.e. ")#mi("x_k = 0")#text(", but in this case any purely imaginary zero must have even multiplicity since ")#mi("H_t")#text(" is even). Therefore, non-real zeros of ")#mi("H_t")#text(" are “appearing in quartets”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("I’m recording here a heuristic relationship between the asymptotics in the last part of the blog post and the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("Riemann-Siegel formula")]#text(", which is a key tool in computing the Riemann zeta function numerically at large heights. Roughly speaking, this formula asserts that")

#mi("\\displaystyle \\zeta(s) \\approx \\sum_{n=1}^N \\frac{1}{n^s} + \\pi^{s-\\frac{1}{2}} \\frac{\\Gamma((1-s)/2)}{\\Gamma(s/2)} \\sum_{n=1}^N \\frac{1}{n^{1-s}}")

#text("for ")#mi("s")#text(" high in the critical strip, where ")#mi("N \\approx \\sqrt{\\mathrm{Im}(s)/2\\pi}")#text(". After some manipulation using Stirling’s formula, this eventually gives")

#mi("\\displaystyle H_0(x+iy) \\approx F_0(x-iy) + \\overline{F_0(x+iy)}")

#text("where (assuming I have not made any sign errors etc.)")

#mi("\\displaystyle F_0(x-iy) := A(x-iy) \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+ix+y}{2}}}")

#text("where ")#mi("N \\approx \\sqrt{x/4\\pi}")#text(" and")

#mi("\\displaystyle A(x-iy) := \\pi^2 \\sqrt{\\frac{\\pi}{-2ix}} (\\frac{x}{4\\pi})^{(9+y)/4} \\exp(-\\frac{\\pi x}{8} + i (\\frac{x}{4} - \\frac{x}{4} \\log \\frac{x}{4\\pi} - \\frac{\\pi(9+y)}{8}))")#text(".")

#text("In contrast, the heuristics in the above blog post seem to lead to the more general approximation")

#mi("\\displaystyle H_t(x+iy) \\approx F_t(x-iy) + \\overline{F_t(x+iy)}")

#text("where")

#mi("\\displaystyle F_t(x-iy) := A(x-iy) \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+ix+y}{2}}} \\exp( \\frac{t}{16} \\log^2 \\frac{x}{4\\pi n^2} - \\frac{t \\pi^2}{64} - \\frac{i \\pi t}{16} \\log \\frac{x}{4\\pi n^2} )")

#text("and ")#mi("A")#text(" and ")#mi("N")#text(" are as before. (I’ll write these calculations more carefully on the wiki soon.) The ")#mi("t")#text("-dependent factor in ")#mi("F_t")#text(" contains a term of the form ")#mi("\\exp( -\\frac{t}{4} \\log \\frac{x}{4\\pi} \\log n )")#text(", which begins to induce significant decay in the summation once ")#mi("\\frac{t}{4} \\log \\frac{x}{4\\pi} \\gg 1")#text(". So whereas computing ")#mi("H_0(x+iy)")#text(" accurately at height ")#mi("T")#text(" requires about ")#mi("O(\\sqrt{T})")#text(" operations, the number of operations drops down to ")#mi("O(1)")#text(" once ")#mi("t")#text(" is significantly larger than ")#mi("1 / \\log T")#text(". Indeed, for ")#mi("t")#text(" much larger than ")#mi("1/\\log T")#text(", the first term in the summation for ")#mi("F_t(x-iy)")#text(" dominates, and (assuming ")#mi("y \\gg 1/\\log T")#text(" also) the second term ")#mi("F_t(x+iy)")#text(" is significantly smaller, which is why ")#mi("H_t(x+iy)")#text(" has no zeroes in this regime.")

#text("It is probably going to be important to develop some rigorous analogue of the Riemann-Siegel formula (with explicit error term) for ")#mi("H_t")#text(" for all ")#mi("t")#text(" between 0 and some target ")#mi("t_0>0")#text(" in order to do numerics accurately for large values of ")#mi("T")#text(", and also to create effective zero-free regions for ")#mi("H_t")#text(". This is probably what I’ll be focusing my efforts on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("Perhaps the identification of the main error term (i.e. the second dominant term in some asymptotic expansion) may help to find a good effective upper bound on the error term.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491988")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("OK, I’ve written some computations at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")[#text("http://michaelnielsen.org/polymath1/index.php?title=Asymptotics_of_H_t")]#text(" which suggest that one has a generalised Riemann-Siegel approximation of the form")

#mi("\\displaystyle H_t(x+iy) \\approx \\frac{1}{4} (F_t(\\frac{1+ix-y}{2}) + \\overline{F_t(\\frac{1+ix+y}{2})})")

#text("when ")#mi("x")#text(" is large, where")

#mi("F_t(s) = \\pi^{-s/2} \\Gamma(\\frac{s+4}{2}) \\sum_{n \\leq \\sqrt{x/4\\pi}} \\frac{\\exp( \\frac{t}{16} \\log^2 \\frac{s+4}{2\\pi n^2} )}{n^s}.")

#text("It would be interesting to see if this approximation is already detectable in the numerics. If so, we could as a first pass pretend that this approximation is exact, and see if we are able to conclude a good zero free region for this approximation to ")#mi("H_t")#text(". The error term should be reasonably small – the usual Riemann-Siegel approximate functional equation has a relative error of ")#mi("O(x^{-1/2})")#text(", so if we can get ")#mi("x")#text(" into the range of ")#mi("10^6")#text(" or so then we should be in fairly good shape. (Of course, we will then have to do the messy work of actually getting an explicit error term in the above approximation, but this looks doable, albeit tedious. Also, it may be possible to add more terms to the Riemann-Siegel expansion to improve the error beyond ")#mi("O(x^{-1/2})")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491993")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("I tried to calculate explicitly the first zero of the above approximation to H , for t=0.")#linebreak()#text(" For t=0, I find using PARI/gp :")#linebreak()#text(" H(29.967325) = 1.087455808883869198146106527380154275744 E-11")#linebreak()#text(" as an approximation to the first zero of H_0, using your")#linebreak()#text(" approximate formulae.")

#text("This uses the defined functions H and F, with t a parameter set to zero:")

#text("F(Z) = Pi^(-Z/2)*gamma((Z+4)/2)*sum(Y=1, floor(sqrt(imag(Z)/(2*Pi))), exp((t/16)*(log((Z+4)/(2*Pi*Y*Y))^2))*Y^(-Z))")

#text("H(X,Y)= ( F((1+I*X-Y)/2) + conj(F((1+I*X+Y)/2)) )/4")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("That’s not too bad, considering that the actual zero is near 28 or so and the approximation is only supposed to get good for large values of X! Hopefully the agreement gets better as X increases.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492028")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("On estimating the first 2000 zeroes for t=0, using corresponding actual 2*zeta zero as a starting guess, we do find the median error decreasing with increasing T (average error seems to decrease much more slowly)")

#text("n in z_n avg z_n median absolute error")#linebreak()#text(" 1-400 771.185 0.131")#linebreak()#text(" 401-800 1874.222 0.076")#linebreak()#text(" 801-1200 2837.853 0.072")#linebreak()#text(" 1201-1600 3741.913 0.061")#linebreak()#text(" 1601-2000 4608.312 0.053")

#text("Also the function is much more well behaved near large T values and computes fairly rapidly, even with arbitrary precision libraries. We could now try integrating this into the Odlyzko–Schönhage framework.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492118")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("Up to x=500.0, I find 106 sign changes in H_0(x) , at a fine mesh/grid. According to tables of zeta zeros, there are 108 zeros with imaginary part below 250.0 .")#linebreak()#text(" One possibility is that the approximation has two sign changes (two zeros) missing, due to having the wrong sign. Otherwise, one would need a finer grid to capture the 2 missing zeros.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492120")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("According to my computations, of the first 108 zeros of ")#mi("H_{0}")#text(" , only two are missed by counting sign changes.")#linebreak()#text(" The approximation to ")#mi("H_{0}")#text(" has constant sign in the interval [440.0, 444.0]; but ")#mi("\\zeta")#text(" has zeros with imaginary parts 220.71491884, and 221.43070555 , according to tables of zeta zeros.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491998")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("A possible way to verify this approximation (as well as to derive an effective upper bound on the error term) is to use a good known asymptotic approximation ")#mi("F_0(z)")#text(" for ")#mi("H_0(z)")#text(" and to propagate ")#mi("F_0(z)")#text(" (in the “time” parameter ")#mi("t")#text(") according to the backwards heat equation (satisfied by ")#mi("H_t(z)")#text(") to be an asymptotic approximation ")#mi("F_t(z)")#text(" for ")#mi("H_t(z)")#text(".")#linebreak()#text(" The propagation of the initial approximation error ")#mi("E_0(z) := H_0(z) - F_0(z)")#text(" should give the approximation error ")#mi("E_t(z) = H_t(z) - F_t(z)")#text(". Moreover, since the heat kernel is positive, it may be used to derive an upper bound on the approximation error ")#mi("E_t(z)")#text(" by propagating a known upper bound on the the initial approximation error ")#mi("E_0(z)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492007")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("This is a promising idea! One speed bump to this is that the fundamental solution to the backwards heat equation is only positive definite if one propagates in an imaginary direction rather than a real one. Let’s illustrate this using the toy function ")#mi("F_0(z) = \\Gamma(1+iz) = \\int_{-\\infty}^\\infty \\exp( u + izu - e^u )\\ du")#text(", which is very roughly of the form that shows up in the actual approximation. To propagate to negative times ")#mi("t<0")#text(" is quite easy: in terms of heat kernels, one has ")#tao-math("F_t(z) = \\frac{1}{\\sqrt{4\\pi\\left|t\\right|}} \\int_{-\\infty}^\\infty e^{-y^2/4\\left|t\\right|} F_0(z+y)\\ dy", block: false)#text(", and one also has the explicit integral representation ")#mi("F_t(z) = \\int_{-\\infty}^\\infty \\exp( tu^2 + u + iz u - e^u )\\ du")#text(" which is quite tractable (this is basically the representation I use in my paper with Brad). But for positive times one instead has")

#mi("F_t(z) = \\frac{1}{\\sqrt{4\\pi t}} \\int_{-\\infty}^\\infty e^{-y^2/4 t} F_0(z+iy)\\ dy")

#text("which is problematic because ")#mi("z+iy")#text(" can get rather close to the poles of ")#mi("F_0")#text(" on the upper imaginary axis. One may be able to get around this by shifting the contour, but I don't immediately see a clean way to do it. Certainly there is a big problem with the convergence of the formal integral ")#mi("F_t(z) = \\int_{-\\infty}^\\infty \\exp( tu^2 + u + iz u - e^u )\\ du")#text(" as ")#mi("u \\to -\\infty")#text(" when ")#mi("t")#text(" is positive. In the case of the actual functions ")#mi("F_t, H_t")#text(", one can get around this by using the functional equations to work only on the ")#mi("\\int_0^\\infty\\ du")#text(" side of the integral, but this leads to messier formulae. But a good model problem would be to find a useful description of the forward propagation of ")#mi("\\Gamma(1+iz)")#text(" by the backwards heat equation. (Equivalently: how does the Gamma function behave under the forward heat equation?)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492011")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Is it possible to propagate the Gammma function by (at least formally) propagating the integrand in its integral representation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492012")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("Yes, but the formal integral is quite divergent, and I don’t see a quick way to renormalise it to be convergent again. If for instance one propagates")

#mi("\\Gamma(s) = \\int_0^\\infty x^s e^{-x} \\frac{dx}{x} = \\int_{-\\infty}^\\infty \\exp( su - e^u )\\ du")

#text("formally by the heat flow, one obtains")

#mi("\\Gamma_t(s) = \\int_0^\\infty \\exp( t \\log^2 x ) x^s e^{-x} \\frac{dx}{x} = \\int_{-\\infty}^\\infty \\exp( tu^2 + su - e^u )\\ du")

#text("which has a rather nasty singularity as ")#mi("x \\to 0^+")#text(" or ")#mi("u \\to -\\infty")#text(". There may be a way to formally shift contours to get a more tractable integral, though I don’t immediately see how to do it: to make the ")#mi("\\exp(tu^2)")#text(" term manageable one would like to move away from the real axis at an angle of at least 45 degrees, but on the other hand the ")#mi("\\exp(-e^u)")#text(" term becomes extremely problematic as soon as the imaginary part of ")#mi("u")#text(" reaches ")#mi("\\pm \\pi/2")#text(".")

#text("ADDED LATER: actually, it looks like the ")#mi("\\exp(-e^u)")#text(" term only becomes a problem on the right-half plane, not on the left. So one could potentially get a good representation by using for instance a contour consisting of the upper imaginary axis and the right real axis (assuming for sake of argument that ")#mi("\\mathrm{Im}(s) > 0")#text("). I’ll have to think more carefully about this…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("A similar idea is to find a (sufficiently simple) integral representation of a good initial approximation ")#mi("F_0(z)")#text(" of ")#mi("H_0(z)")#text(" and than propagate ")#mi("F_0(z)")#text(" (initially at least formally, and later perhaps by analytic continuation) to ")#mi("F_t(z)")#text(" by propagating the integrand in its representing integral (i.e. a kind of formal “propagation under the integral sign”).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("This approximation also helps explain some of the Ki-Kim-Lee results. IF one inspects what happens to ")#mi("H_t(x+iy)")#text(" near some large real number ")#mi("T")#text(" by making the ansatz ")#mi("x+iy = T + \\frac{a+ib}{\\log T}")#text(", and throws away some lower order terms (anything of size ")#mi("O(1/\\log T)")#text(" of the main terms), and using the Stirling approximation ")#mi("\\Gamma(s+\\delta) \\approx s^\\delta \\Gamma(s)")#text(" when ")#mi("s")#text(" is large and ")#mi("\\delta")#text(" is small, it looks like one eventually gets the approximation")

#mi("\\displaystyle H_t(T + \\frac{a+ib}{\\log T}) \\approx r_{t,T} \\cos( \\frac{a+ib}{4} + \\theta_{t,T} )")

#text("for ")#mi("t \\gg \\frac{1}{\\log T}")#text(", where ")#mi("r_{t,T}, \\theta_{t,T}")#text(" are the polar coordinates of the quantity")

#mi("r_{t,T} e^{i \\theta_{t,T}} = \\frac{1}{2} \\pi^{-(1+iT)/4} \\Gamma(\\frac{iT+9}{4}) \\exp( \\frac{t}{16} \\log^2 \\frac{iT+9}{4\\pi}) \\zeta( \\frac{1+iT}{2} + \\frac{t \\log\\frac{iT+9}{4\\pi}}{4} ).")

#text("In particular, one expects the zeroes to be real and equally spaced, with a spacing of about ")#mi("4\\pi")#text(" (in ")#mi("a")#text("-coordinates) or ")#mi("\\frac{4\\pi}{\\log T}")#text(" (in ")#mi("x")#text("-coordinates).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491981")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("These formulae also go under the title “approximate functional equation” (though in modern versions there is nothing approximate about them). A good reference is Theorem 5.3 of Iwaniec–Kowalski’s book; I also have ")#link("https://www.math.ubc.ca/~lior/work/notes/Booker_Lfcns.pdf")[#text("notes")]#text(" from a short course by Andy Booker on computing many values of L-functions through the AFE and Poisson sum, with a view toward locating zeroes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-491995")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2018")])]

#text("The errors in the Riemann-Siegel approximation could be taken (i.e. divided by) relative to { \\exp ( – \\pi x/8 ) } , although this factor seems a bit too small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meditationatae")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492035")[#strong[#text("meditationatae")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("According to Odlyzko’s zeta zeros tables, zeta has a zero at rho ~= 1/2 + i*49998.500133391 . So H_0 has a zero at 2 Im(rho) ~= 99997.000 . Your Riemann-Siegel type approximation to H_0 has a zero at x = 99997.02, giving an absolute error of about 0.02 .")#linebreak()#text(" For very large T, I have no tables, and PARI/gp’s own zeta(.) takes too long to finish.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492059")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2018")])]

#text("Odlyzko’s page also has a link with first 2 million zeroes. Will be trying that out.")#linebreak()#text(" ")#link("http://www.dtc.umn.edu/~odlyzko/zeta_tables/zeros6.gz")[#text("http://www.dtc.umn.edu/~odlyzko/zeta_tables/zeros6.gz")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492040")[#strong[#text("Polymath15, second thread: generalising the Riemann-Siegel approximate functional equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this previous thread. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492043")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2018")])]

#text("As this thread is getting rather long, I am rolling over to a new thread: ")#link("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/")[#text("https://terrytao.wordpress.com/2018/02/02/polymath15-second-thread-generalising-the-riemann-siegel-approximate-functional-equation/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492123")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("Something is a bit off in my calculation using formulas (2) and (3), because it finds a zero of ")#mi("H_0")#text(" close to 30.185 …")#linebreak()#text(" Broken over several lines, the input to PARI/gp is:")

#text("z=30.185;")#linebreak()#text(" t=0.0;")#linebreak()#text(" thet=Pi/8 – 1/(4*z);")#linebreak()#text(" K=0.0;")#linebreak()#text(" for(Y=1, 40,")#linebreak()#text(" b=z-9*I;")#linebreak()#text(" beta=Pi*Y^2;")#linebreak()#text(" K=K+2*Pi*Pi*(Y^4)*sum(J=1,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) ;")#linebreak()#text(" b = z-5*I; K=K – 3*Pi*(Y^2)*sum(J=1,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) );")#linebreak()#text(" print( real((K+conj(K)))/2)")

#text("output:")#linebreak()#text(" 2.034481 E-8")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff0ef047026292cfbc0f000a71a30e143c6e9bd4c4f658831de655c55a54ea6-d040742af603472f9b5be408fadfec9c24d4dcde94f7830150b49ec9d992eced.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Bernier (@doubledeckerpot)")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492124")[#strong[#text("David Bernier (@doubledeckerpot)")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2018")])]

#text("Changing the range of J to: 0, 64 improves things a lot. The formula evaluates to ~= 0 for 28.2694… (using Gaussian quadrature) :")

#text("z=2*z1;")#linebreak()#text(" t=0.0;")#linebreak()#text(" thet=Pi/8 – 1/(4*z);")#linebreak()#text(" K=0.0;")#linebreak()#text(" for(Y=1, 40, b=z-9*I;")#linebreak()#text(" beta=Pi*Y^2;")#linebreak()#text(" K=K+2*Pi*Pi*(Y^4)*sum(J=0,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) ;")#linebreak()#text(" b = z-5*I;")#linebreak()#text(" K=K – 3*Pi*(Y^2)*sum(J=0,64, intnumgauss(X=J/16, (J+1)/16, exp( t*(X+I*thet)^2 – beta*exp(4*(X+I*thet)) + I*b*(X+I*thet)), ) ) );")#linebreak()#text(" print( real((K+conj(K)))/2)")

#text("output using real-precision = 70 digits:")#linebreak()#text(" -1.767 E-15")

#text("I can get closer to an output of zero by, e.g., using real-precision = 150 digits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2018")])]

#text("It seems that because of the horizontal repulsion among zeros and clusters of zeros of ")#mi("H_t")#text(" and because of the increasingly regular zero gaps as ")#mi("t")#text(" increases, it is expected that for sufficiently large ")#mi("t")#text(", the horizontal zero velocities should become (asymptotically for large ")#mi("x")#text(") more uniform with a (slow) trend of drifting away(!) from the origin. Is it possible to show such asymptotic trend of the horizontal velocities?")

#text("If true, it may be exploited to show that a certain zero-free domain for some ")#mi("t_0")#text(" should remain so for any ")#mi("t > t_0")#text(" (i.e. by showing that zeros are not entering to this domain.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64cdcf6c5ad2c4a5b929477f6c6f6bc307654f648757e49291f4a15228879b96-65ec6802d77367cb10a2bfcf950b269cfbdf743be840fe341c5f6b3d13792b27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vassilis Papanicolaou")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-492585")[#strong[#text("Vassilis Papanicolaou")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2018")])]

#text("Dear Professor Tao,")

#text("thank you for presenting all these stuff to us in such a nice way.")

#text("This is my first comment to “Polymath.”")

#text("I would like to share few rough ideas regarding the dynamics of the zeros ")#mi("z_j(t)")#text(" of ")#mi("H_t(z)")#text(":")

#text("It seems clear that ")#mi("H_t(z)")#text(" is entire in both ")#mi("z")#text(" and ")#mi("t")#text(". Hence the zeros ")#mi("z_j(t)")#text(" are the branches of a global analytic function, say ")#mi("Z(t)")#text(", defined on an infinite-sheeted Riemann surface ")#mi("S")#text(". The projections of the branch points of ")#mi("S")#text(" on the complex plane are the values of ")#mi("t")#text(" for which we will have multiple zeros of ")#mi("H_t(z)")#text(", and these are countably many points, say ")#mi("t_k")#text(", ")#mi("k = 1, 2, ...")#text(" (possibly without accumulation points in the complex plane). Then, by analytic continuation one expects that the equations giving the dynamics of the zeros will continue to hold (in some sense?) for any complex ")#mi("t")#text(", except at ")#mi("t = t_k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/748d96e9cc9b82b2c9fc2aae1c44f4485215df1dbdfa1eb9fe18965cd2b6c7b8-841ec43682dec687cf7c5c39f175ce81172bca94e96647feb3349150a1ac3091.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of F_Adrien")]], [#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-495287")[#strong[#text("F_Adrien")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("Sorry I’m not sure but… Is there a missing equal between ")#mi("t")#text(" and ")#mi("0")#text(" in the sentence : «…to obtain a useful series representation for ")#mi("{H_t}")#text(" in the ")#mi("{t0}")#text(" case…» ? It should be the ")#mi("t=0")#text(" case no ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-499812")[#strong[#text("El proyecto Polymath15 logra reducir la cota superior de la constante de Bruijn-Newman | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2018")]

#text("[…] primer hilo [Tao, 27 Jan 2018] expuso la propuesta del propio Tao para resolver el problema en la línea de su […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/01/27/polymath15-first-thread-computing-h_t-asymptotics-and-dynamics-of-zeroes/#comment-513266")[#strong[#text("Dan Romik Studies the Riemann’s Zeta Function, and Other Zeta News. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2019")]

#text("[…] task of polymath15 (proposed here, launched here, last (11th) post here) was to use current analytic number theory technology that already has […]")
]
