// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/
// Converted to Typst by tao2typ: "2026-10-14T16:35:23.213510+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity of wave maps V. Large data local wellposedness in the energy class", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity of wave maps V. Large data local wellposedness in the energy class")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/")[#text("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have just uploaded to the ")#link("http://www.arxiv.org/")[#text("arXiv")]#text(" the third installment of my “")#link("http://wordpress.com/tag/project-heatwave/")[#text("heatwave")]#text("” project, entitled “")#link("http://arxiv.org/abs/0808.0368")[#text("Global regularity of wave maps V. Large data local well-posedness in the energy class")]#text("“. This (rather technical) paper establishes another of the key ingredients necessary to establish the global existence of smooth ")#link("https://terrytao.wordpress.com/2008/08/06/2007/08/30/pcm-deleted-scene-wave-maps/")[#text("wave maps")]#text(" from 2+1-dimensional spacetime ")#mi("{\\Bbb R}^{1+2}")#text(" to ")#link("http://en.wikipedia.org/wiki/Hyperbolic_space")[#text("hyperbolic space")]#text(" ")#mi("\\mathbf{H} = \\mathbf{H}^m")#text(". Specifically, a large data ")#emph[#text("local")]#text(" well-posedness result is established, constructing a local solution from any initial data with finite (but possibly quite large) energy, and furthermore that the solution depends continuously on the initial data in the energy topology. (This topology was constructed in ")#link("https://terrytao.wordpress.com/2008/06/24/global-regularity-of-wave-maps-iv-absence-of-stationary-or-self-similar-solutions-in-the-energy-class/")[#text("my previous paper")]#text(".) Once one has this result, the only remaining task is to show a “Palais-Smale property” for wave maps, in that if singularities form in the wave maps equation, then there exists a non-trivial minimal-energy blowup solution, whose orbit is almost periodic modulo the symmetries of the equation. I anticipate this to the most difficult component of the whole project, and is the subject of the fourth (and hopefully final) installment of this series.")

#text("This local result is closely related to the small energy global regularity theory developed in recent years ")#link("http://www.ams.org/mathscinet-getitem?mr=1869874")[#text("by myself")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2094472")[#text("by Krieger")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=2130618")[#text("by Tataru")]#text(". In particular, the complicated function spaces used in that paper (which ultimately originate from a precursor paper ")#link("http://www.ams.org/mathscinet-getitem?mr=1827277")[#text("of Tataru")]#text("). The main new difficulties here are to extend the small energy theory to large energy (by localising time suitably), and to establish continuous dependence on the data (i.e. two solutions which are initially close in the energy topology, need to stay close in that topology). The former difficulty is in principle manageable by exploiting finite speed of propagation (exploiting the fact (arising from the monotone convergence theorem) that large energy data becomes small energy data at sufficiently small spatial scales), but for technical reasons (having to do with my choice of gauge) I was not able to do this and had to deal with the large energy case directly (and in any case, a genuinely large energy theory is going to be needed to construct the minimal energy blowup solution in the next paper). The latter difficulty is in principle resolvable by adapting the existence theory to differences of solutions, rather than to individual solutions, but the nonlinear choice of gauge adds a rather tedious amount of complexity to the task of making this rigorous. (It may be that simpler gauges, such as the Coulomb gauge, may be usable here, at least in the case ")#mi("m=2")#text(" of the hyperbolic plane (cf. the ")#link("http://www.ams.org/mathscinet-getitem?mr=2094472")[#text("work of Krieger")]#text("), but such gauges cause additional analytic problems as they do not renormalise the nonlinearity as strongly as the caloric gauge. The paper of Tataru establishes these goals, but assumes an isometric embedding of the target manifold into a Euclidean space, which is unfortunately not available for hyperbolic space targets.)")

#text("The main technical difficulty that had to be overcome in the paper was that there were two different time variables t, s (one for the wave maps equation and one for the heat flow), and three types of PDE (hyperbolic, parabolic, and ODE) that one has to solve forward in t, forward in s, and backwards in s respectively. In order to close the argument in the large energy case, this necessitated a rather complicated iteration-type scheme, in which one solved for the caloric gauge, established parabolic regularity estimates for that gauge, propagated a “wave-tension field” by the heat flow, and then solved a wave maps type equation using that field as a forcing term. The argument can eventually be closed using mostly “off-the-shelf” function space estimates from previous papers, but is remarkably lengthy, especially when analysing differences of two solutions. (One drawback of using off-the-shelf estimates, though, is that one does not get particularly good control of the solution over extended periods of time; in particular, the spaces used here cannot detect the decay of the solution over extended periods of time (unlike, say, Strichartz spaces ")#mi("L^q_t L^r_x")#text(" for ")#mi("q < \\infty")#text(") and so will not be able to supply the long-time perturbation theory that will be needed in the next paper in this series. I believe I know how to re-engineer these spaces to achieve this, though, and the details should follow in the forthcoming paper.)")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/#comment-31883")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2008")])]

#text("Dear Terence,")#linebreak()#text(" it is quite amazing to observe how much work you manage to get done in what other people would tend to call a very short time. I have seen similar comments many times before on this blog and I wish to add my voice to the number of those who would be delighted to have an insight in your extremely efficient time management system. I think this would help many of us (re-) think about how we organize our time.")#linebreak()#text(" Thanks!")#linebreak()#text(" Mark")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/#comment-32691")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("[…] maps, a certain “caloric gauge” based on harmonic map heat flow is crucial (see e.g. this post of mine). But in many situations, it is not yet fully understood whether the use of the correct […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/#comment-38308")[#strong[#text("An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("[…] my previous “heatwave” paper, in which I established large data local well-posedness for this equation, I finessed this issue by […]")
]
