// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:17:03.755187+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hardy’s uncertainty principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hardy’s uncertainty principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/")[#text("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This post was typeset using a LaTeX to WordPress-HTML converter kindly provided to me by ")#link("http://lucatrevisan.wordpress.com/")[#text("Luca Trevisan")]#text(".]")]

#text("Many properties of a (sufficiently nice) function ")#mi("{f: {\\mathbb R} \\rightarrow {\\mathbb C}}")#text(" are reflected in its ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("{\\hat f: {\\mathbb R} \\rightarrow {\\mathbb C}}")#text(", defined by the formula ")#metadata(none) <tao-f9cfef864964efe9a286>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\hat f(\\xi) := \\int_{-\\infty}^\\infty f(x) e^{-2\\pi i x \\xi}\\ dx.")]]

#text("For instance, decay properties of ")#mi("{f}")#text(" are reflected in smoothness properties of ")#mi("{\\hat f}")#text(", as the following table shows:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("If ")#mi("{f}")#text(" is…")],
table.cell(colspan: 1, rowspan: 1)[#text("then ")#mi("{\\hat f}")#text(" is…")],
table.cell(colspan: 1, rowspan: 1)[#text("and this relates to…")],
table.cell(colspan: 1, rowspan: 1)[#text("Square-integrable")],
table.cell(colspan: 1, rowspan: 1)[#text("square-integrable")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]],
table.cell(colspan: 1, rowspan: 1)[#text("Absolutely integrable")],
table.cell(colspan: 1, rowspan: 1)[#text("continuous")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Riemann-Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Rapidly_decreasing")[#text("Rapidly decreasing")]],
table.cell(colspan: 1, rowspan: 1)[#text("smooth")],
table.cell(colspan: 1, rowspan: 1)[#text("theory of ")#link("http://en.wikipedia.org/wiki/Schwartz_function")[#text("Schwartz functions")]],
table.cell(colspan: 1, rowspan: 1)[#text("Exponentially decreasing")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Complex_analytic")[#text("analytic")]#text(" in a strip")],
table.cell(colspan: 1, rowspan: 1)[],
table.cell(colspan: 1, rowspan: 1)[#text("Compactly supported")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Entire_function")[#text("entire")]#text(" and at most exponential growth")],
table.cell(colspan: 1, rowspan: 1)[#link("http://en.wikipedia.org/wiki/Paley%E2%80%93Wiener_theorem")[#text("Paley-Wiener theorem")]]
)

#text("Another important relationship between a function ")#mi("{f}")#text(" and its Fourier transform ")#mi("{\\hat f}")#text(" is the ")#emph[#text("uncertainty principle")]#text(", which roughly asserts that if a function ")#mi("{f}")#text(" is highly localised in space, then its Fourier transform ")#mi("{\\hat f}")#text(" must be widely dispersed in space, or to put it another way, ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" cannot both decay too strongly at infinity (except of course in the degenerate case ")#mi("{f=0}")#text("). There are many ways to make this intuition precise. One of them is the ")#link("http://en.wikipedia.org/wiki/Heisenberg_uncertainty_principle")[#text("Heisenberg uncertainty principle")]#text(", which asserts that if we normalise")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\mathbb R}} \\left|f(x)\\right|^2\\ dx = \\int_{\\mathbb R} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi = 1", block: true)]]

#text("then we must have")

#align(center)[#tao-fit-display[#tao-math("(\\int_{\\mathbb R} \\left|x\\right|^2 \\left|f(x)\\right|^2\\ dx) \\cdot (\\int_{\\mathbb R} \\left|\\xi\\right|^2 \\left|\\hat f(\\xi)\\right|^2\\ d\\xi)\\geq \\frac{1}{(4\\pi)^2}", block: true)]]

#text("thus forcing at least one of ")#mi("{f}")#text(" or ")#mi("{\\hat f}")#text(" to not be too concentrated near the origin. This principle can be proven (for sufficiently nice ")#mi("{f}")#text(", initially) by observing the integration by parts identity")

#align(center)[#tao-fit-display[#tao-math("\\langle xf, f^{\\prime} \\rangle = \\int_{\\mathbb R} x f(x) \\overline{f^{\\prime}(x)}\\ dx = - \\frac{1}{2} \\int_{\\mathbb R} \\left|f(x)\\right|^2\\ dx", block: true)]]

#text("and then using ")#link("http://en.wikipedia.org/wiki/Cauchy-Schwarz_inequality")[#text("Cauchy-Schwarz")]#text(" and the Plancherel identity.")

#text("Another well known manifestation of the uncertainty principle is the fact that it is not possible for ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" to both be compactly supported (unless of course they vanish entirely). This can be in fact be seen from the above table: if ")#mi("{f}")#text(" is compactly supported, then ")#mi("{\\hat f}")#text(" is an entire function; but the zeroes of a non-zero entire function are isolated, yielding a contradiction unless ")#mi("{f}")#text(" vanishes. (Indeed, the table also shows that if one of ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" is compactly supported, then the other cannot have exponential decay.)")

#text("On the other hand, we have the example of the ")#link("http://en.wikipedia.org/wiki/Gaussian_function")[#text("Gaussian functions")]#text(" ")#mi("{f(x) = e^{-\\pi a x^2}}")#text(", ")#mi("{\\hat f(\\xi) = \\frac{1}{\\sqrt{a}} e^{-\\pi \\xi^2/a }}")#text(", which both decay faster than exponentially. The classical ")#emph[#text("Hardy uncertainty principle")]#text(" asserts, roughly speaking, that this is the fastest that ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" can simultaneously decay:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Hardy uncertainty principle)")]#text(" ")#emph[#text(" Suppose that ")#mi("{f}")#text(" is a (measurable) function such that ")#tao-math("{\\left|f(x)\\right| \\leq C e^{-\\pi a x^2 }}", block: false)#text(" and ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq C^{\\prime} e^{-\\pi \\xi^2/a}}", block: false)#text(" for all ")#mi("{x, \\xi}")#text(" and some ")#mi("{C, C^{\\prime}, a > 0}")#text(". Then ")#mi("{f(x)}")#text(" is a scalar multiple of the gaussian ")#mi("{e^{-\\pi ax^2}}")#text(". ")]
]

#text("This theorem is proven by complex-analytic methods, in particular the ")#link("http://en.wikipedia.org/wiki/Phragm%C3%A9n-Lindel%C3%B6f_principle")[#text("Phragmén-Lindelöf principle")]#text("; for sake of completeness we give that proof below. But I was curious to see if there was a real-variable proof of the same theorem, avoiding the use of complex analysis. I was able to find the proof of a slightly weaker theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Weak Hardy uncertainty principle)")]#text(" ")#emph[#metadata(none) <tao-b78d6361886f3786e25e>#text(" Suppose that ")#mi("{f}")#text(" is a non-zero (measurable) function such that ")#tao-math("{\\left|f(x)\\right| \\leq C e^{-\\pi a x^2 }}", block: false)#text(" and ")#tao-math("{\\left|\\hat f(\\xi)\\right| \\leq C^{\\prime} e^{-\\pi b \\xi^2}}", block: false)#text(" for all ")#mi("{x, \\xi}")#text(" and some ")#mi("{C, C^{\\prime}, a, b > 0}")#text(". Then ")#mi("{ab \\leq C_0}")#text(" for some absolute constant ")#mi("{C_0}")#text(". ")]
]

#text("Note that the correct value of ")#mi("{C_0}")#text(" should be ")#mi("{1}")#text(", as is implied by the true Hardy uncertainty principle. Despite the weaker statement, I thought the proof might still might be of interest as it is a little less “magical” than the complex-variable one, and so I am giving it below.")

#metadata(none) <tao-f66e187028cb420f1445>

#heading(level: 1)[#text("— 1. The complex-variable proof —")]

#text("We first give the complex-variable proof. By dilating ")#mi("{f}")#text(" by ")#mi("{\\sqrt{a}}")#text(" (and contracting ")#mi("{\\hat f}")#text(" by ")#mi("{1/\\sqrt{a}}")#text(") we may normalise ")#mi("{a=1}")#text(". By multiplying ")#mi("{f}")#text(" by a small constant we may also normalise ")#mi("{C=C^{\\prime}=1}")#text(".")

#text("The super-exponential decay of ")#mi("{f}")#text(" allows us to extend the Fourier transform ")#mi("{\\hat f}")#text(" to the complex plane, thus")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi + i \\eta) = \\int_{\\mathbb R} f(x) e^{-2\\pi i x \\xi} e^{2\\pi \\eta x}\\ dx")]]

#text("for all ")#mi("{\\xi, \\eta \\in {\\mathbb R}}")#text(". We may differentiate under the integral sign and verify that ")#mi("{\\hat f}")#text(" is entire. Taking absolute values, we obtain the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi + i \\eta)\\right| \\leq \\int_{\\mathbb R} e^{-\\pi x^2} e^{2\\pi \\eta x}\\ dx;", block: true)]]

#text("completing the square, we obtain ")#metadata(none) <tao-1c6e6c4c02e55178e858>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\hat f(\\xi + i \\eta)\\right| \\leq e^{\\pi \\eta^2}", block: true)]]

#text("for all ")#mi("{\\xi, \\eta}")#text(". We conclude that the entire function")

#align(center)[#tao-fit-display[#mitex("F(z) := e^{\\pi z^2} \\hat f(z)")]]

#text("is bounded in magnitude by ")#mi("{1}")#text(" on the imaginary axis; also, by hypothesis on ")#mi("{\\hat f}")#text(", we also know that ")#mi("{F}")#text(" is bounded in magnitude by ")#mi("{1}")#text(" on the real axis. ")#emph[#text("Formally")]#text(" applying the ")#link("http://en.wikipedia.org/wiki/Phragm%C3%A9n-Lindel%C3%B6f_principle")[#text("Phragmen-Lindelöf principle")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Maximum_modulus_principle")[#text("maximum modulus principle")]#text("), we conclude that ")#mi("{F}")#text(" is bounded on the entire complex plane, which by Liouville’s theorem implies that ")#mi("{F}")#text(" is constant, and the claim follows.")

#text("Now let’s go back and justify the Phragmén-Lindelöf argument. Strictly speaking, Phragmén-Lindelöf does not apply, since it requires exponential growth on the function ")#mi("{F}")#text(", whereas we have quadratic-exponential growth here. But we can tweak ")#mi("{F}")#text(" a bit to solve this problem. Firstly, we pick ")#mi("{0 < \\theta < \\pi/2}")#text(" and work on the sector")

#align(center)[#tao-fit-display[#mitex("\\Gamma_\\theta := \\{ re^{i\\alpha}: r > 0, 0 \\leq \\alpha \\leq \\theta \\}.")]]

#text("Using ")#link(<tao-1c6e6c4c02e55178e858>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F(\\xi + i\\eta)\\right| \\leq e^{\\pi \\xi^2}.", block: true)]]

#text("Thus, if ")#mi("{\\delta > 0}")#text(", and ")#mi("{\\theta}")#text(" is sufficiently close to ")#mi("{\\pi/2}")#text(" depending on ")#mi("{\\delta}")#text(", the function ")#mi("{e^{i\\delta z^2} F(z)}")#text(" is bounded in magnitude by ")#mi("{1}")#text(" on the boundary of ")#mi("{\\Gamma_\\theta}")#text(". Then, for any sufficiently small ")#mi("{\\epsilon > 0}")#text(", ")#mi("{e^{i\\epsilon e^{i\\epsilon} z^{2+\\epsilon}} e^{i\\delta z^2} F(z)}")#text(" (using the standard branch of ")#mi("{z^{2+\\epsilon}}")#text(" on ")#mi("{\\Gamma_\\theta}")#text(") is also bounded in magnitude by ")#mi("{1}")#text(" on this boundary, and goes to zero at infinity in the interior of ")#mi("{\\Gamma_\\theta}")#text(", so is bounded by ")#mi("{1}")#text(" in that interior by the maximum modulus principle. Sending ")#mi("{\\epsilon \\rightarrow 0}")#text(", and then ")#mi("{\\theta \\rightarrow \\pi/2}")#text(", and then ")#mi("{\\delta \\rightarrow 0}")#text(", we obtain ")#mi("{F}")#text(" bounded in magnitude by ")#mi("{1}")#text(" on the upper right quadrant. Similar arguments work for the other quadrants, and the claim follows.")

#heading(level: 1)[#text("— 2. The real-variable proof —")]

#text("Now we turn to the real-variable proof of Theorem ")#link(<tao-b78d6361886f3786e25e>)[#text("2")]#text(", which is based on the fact that polynomials of controlled degree do not resemble rapidly decreasing functions.")

#text("Rather than use complex analyticity ")#mi("{\\hat f}")#text(", we will rely instead on a different relationship between the decay of ")#mi("{f}")#text(" and the regularity of ")#mi("{\\hat f}")#text(", as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Derivative bound)")]#text(" ")#emph[#text(" Suppose that ")#tao-math("{\\left|f(x)\\right| \\leq C e^{-\\pi a x^2 }}", block: false)#text(" for all ")#mi("{x \\in {\\mathbb R}}")#text(", and some ")#mi("{C, a > 0}")#text(". Then ")#mi("{\\hat f}")#text(" is smooth, and furthermore one has the bound ")#tao-math("{\\left|\\partial_\\xi^k \\hat f(\\xi)\\right| \\leq \\frac{C}{\\sqrt{a}} \\frac{k! \\pi^{k/2}}{(k/2)! a^{(k+1)/2}}}", block: false)#text(" for all ")#mi("{\\xi \\in {\\mathbb R}}")#text(" and every even integer ")#mi("{k}")#text(". ")]
]

#emph[#text("Proof:")]#text(" The smoothness of ")#mi("{\\hat f}")#text(" follows from the rapid decrease of ")#mi("{f}")#text(". To get the bound, we differentiate under the integral sign (one can easily check that this is justified) to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_\\xi^k \\hat f(\\xi) = \\int_{\\mathbb R} (-2\\pi i x)^k f(x) e^{-2\\pi i x \\xi}\\ dx")]]

#text("and thus by the triangle inequality for integrals (and the hypothesis that ")#mi("{k}")#text(" is even)")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial_\\xi^k \\hat f(\\xi)\\right| \\leq C \\int_{\\mathbb R} e^{-\\pi a x^2} (2\\pi x)^k\\ dx.", block: true)]]

#text("On the other hand, by differentiating the Fourier analytic identity")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sqrt{a}} e^{-\\pi \\xi^2/a} = \\int_{\\mathbb R} e^{-\\pi a x^2} e^{-2\\pi i x \\xi}\\ dx")]]

#mi("{k}")#text(" times at ")#mi("{\\xi = 0}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{d^k}{d\\xi^k}(\\frac{1}{\\sqrt{a}} e^{-\\pi \\xi^2/a})|_{\\xi=0} = \\int_{\\mathbb R} e^{-\\pi a x^2} (2\\pi i x)^k\\ dx;")]]

#text("expanding out ")#mi("{\\frac{1}{\\sqrt{a}} e^{-\\pi \\xi^2/a}}")#text(" using Taylor series we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{k!}{\\sqrt{a}} \\frac{(-\\pi/a)^{k/2}}{(k/2)!} = \\int_{\\mathbb R} e^{-\\pi a x^2} (2\\pi i x)^k\\ dx")]]

#text("◻")

#text("Using ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(" ")#mi("{k! = k^k (e+o(1))^{-k}}")#text(", we conclude in particular that ")#metadata(none) <tao-4011393f356a69582a25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\partial_\\xi^k \\hat f(\\xi)\\right| \\leq (\\frac{2 \\pi}{e a}+o(1))^{k/2} k^{k/2}", block: true)]]

#text("for all large even integers ")#mi("{k}")#text(" (where the decay of ")#mi("{o(1)}")#text(" can depend on ")#mi("{a, C}")#text(").")

#text("We can combine ")#link(<tao-4011393f356a69582a25>)[#text("(3)")]#text(" with Taylor’s theorem with remainder, to conclude that on any interval ")#mi("{I \\subset {\\mathbb R}}")#text(", we have an approximation")

#align(center)[#tao-fit-display[#tao-math("\\hat f(\\xi) = P_I(\\xi) + O( \\frac{1}{k!} (\\frac{2 \\pi}{e a}+o(1))^{k/2} k^{k/2} \\left|I\\right|^k )", block: true)]]

#text("where ")#tao-math("{\\left|I\\right|}", block: false)#text(" is the length of ")#mi("{I}")#text(" and ")#mi("{P_I}")#text(" is a polynomial of degree less than ")#mi("{k}")#text(". Using Stirling’s formula again, we obtain ")#metadata(none) <tao-2e68a8e49fe8b9e6e94c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\hat f(\\xi) = P_I(\\xi) + O( (\\frac{2 \\pi e}{a}+o(1))^{k/2} k^{-k/2} \\left|I\\right|^k )", block: true)]]

#text("Now we apply a useful bound.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Doubling bound)")]#text(" ")#emph[#metadata(none) <tao-c5313b157b9b0b5f2eb2>#text(" Let ")#mi("{P}")#text(" be a polynomial of degree at most ")#mi("{k}")#text(" for some ")#mi("{k \\geq 1}")#text(", let ")#mi("{I = [x_0-r,x_0+r]}")#text(" be an interval, and suppose that ")#tao-math("{\\left|P(x)\\right| \\leq A}", block: false)#text(" for all ")#mi("{x \\in I}")#text(" and some ")#mi("{A>0}")#text(". Then for any ")#mi("{N \\geq 1}")#text(" we have the bound ")#tao-math("{\\left|P(x)\\right| \\leq (CN)^k A}", block: false)#text(" for all ")#mi("{x \\in NI := [x_0-Nr, x_0+Nr]}")#text(" and for some absolute constant ")#mi("{C}")#text(". ")]
]

#emph[#text("Proof:")]#text(" By translating we may take ")#mi("{x_0=0}")#text("; by dilating we may take ")#mi("{r=1}")#text(". By dividing ")#mi("{P}")#text(" by ")#mi("{A}")#text(", we may normalise ")#mi("{A=1}")#text(". Thus we have ")#tao-math("{\\left|P(x)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{-1 \\leq x \\leq 1}")#text(", and the aim is now to show that ")#tao-math("{\\left|P(x)\\right| \\leq (CN)^k}", block: false)#text(" for all ")#mi("{-N \\leq x \\leq N}")#text(".")

#text("Consider the trigonometric polynomial ")#mi("{P(\\cos \\theta)}")#text(". By de Moivre’s formula, this function is a linear combination of ")#mi("{\\cos(j \\theta)}")#text(" for ")#mi("{0 \\leq j \\leq k}")#text(". By Fourier analysis, we can thus write ")#mi("{P(\\cos \\theta) = \\sum_{j=0}^k c_j \\cos(j \\theta)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("c_j = \\frac{1}{\\pi} \\int_{-\\pi}^\\pi P(\\cos \\theta) \\cos(j \\theta)\\ d\\theta.")]]

#text("Since ")#mi("{P(\\cos \\theta)}")#text(" is bounded in magnitude by ")#mi("{1}")#text(", we conclude that ")#mi("{c_j}")#text(" is bounded in magnitude by ")#mi("{2}")#text(". Next, we use de Moivre’s formula again to expand ")#mi("{\\cos(j \\theta)}")#text(" as a linear combination of ")#mi("{\\cos(\\theta)}")#text(" and ")#mi("{\\sin^2(\\theta)}")#text(", with coefficients of size ")#mi("{O(1)^k}")#text("; expanding ")#mi("{\\sin^2(\\theta)}")#text(" further as ")#mi("{1 - \\cos^2(\\theta)}")#text(", we see that ")#mi("{\\cos(j \\theta)}")#text(" is a polynomial in ")#mi("{\\cos(\\theta)}")#text(" with coefficients ")#mi("{O(1)^k}")#text(". Putting all this together, we conclude that the coefficients of ")#mi("{P}")#text(" are all of size ")#mi("{O(1)^k}")#text(", and the claim follows. ◻")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#emph[#text("One can get slightly sharper results by using the theory of Chebyshev polynomials. (Is the best bound for ")#mi("{C}")#text(" known? I do not know the recent literature on this subject. I think though that even the sharpest bound for ")#mi("{C}")#text(" would not fully recover the sharp Hardy uncertainty principle, at least with the argument given here.) ")]
]

#text("We return to the proof of Theorem ")#link(<tao-b78d6361886f3786e25e>)[#text("2")]#text(". We pick a large integer ")#mi("{k}")#text(" and a parameter ")#mi("{r > 0}")#text(" to be chosen later. From ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = P_r(\\xi) + O( \\frac{r^2}{ak} )^{k/2}")]]

#text("for ")#mi("{\\xi \\in [-r,2r]}")#text(", and some polynomial ")#mi("{P_r}")#text(" of degree ")#mi("{k}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#mitex("P_r(\\xi) = O( e^{-br^2} ) + O( \\frac{r^2}{ak} )^{k/2}")]]

#text("for ")#mi("{\\xi \\in [r,2r]}")#text(". Applying Lemma ")#link(<tao-c5313b157b9b0b5f2eb2>)[#text("4")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("P_r(\\xi) = O( 1 )^k e^{-br^2} + O( \\frac{r^2}{ak} )^{k/2}")]]

#text("for ")#mi("{\\xi \\in [-r,r]}")#text(". Applying ")#link(<tao-2e68a8e49fe8b9e6e94c>)[#text("(4)")]#text(" again we conclude that")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = O( 1 )^k e^{-br^2} + O( \\frac{r^2}{ak} )^{k/2}")]]

#text("for ")#mi("{\\xi \\in [-r,r]}")#text(". If we pick ")#mi("{r := \\sqrt{\\frac{k}{cb}}}")#text(" for a sufficiently small absolute constant ")#mi("{c}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq 2^{-k} + O( \\frac{1}{ab} )^{k/2}", block: true)]]

#text("(say) for ")#mi("{\\xi \\in [-r,r]}")#text(". If ")#mi("{ab \\geq C_0}")#text(" for large enough ")#mi("{C_0}")#text(", the right-hand side goes to zero as ")#mi("{k \\rightarrow \\infty}")#text(" (which also implies ")#mi("{r \\rightarrow \\infty}")#text("), and we conclude that ")#mi("{\\hat f}")#text(" (and hence ")#mi("{f}")#text(") vanishes identically.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab633f4e7bd3512cca45bf70f11ec84e4d471a1dd4975d9cd8bdde744f006afc-717528f64aa2ac2d515362ebc1c7ebcb1e18ad7d47b352e9feee8fac62489bad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sjt")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-35985")[#strong[#text("sjt")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("This new LaTeX-to-HTML converter doesn’t make alt text for its images, which is very unfriendly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-35987")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("It’s WordPress that has stopped providing alt text for the latex formulas. (The alt text is missing from the other posts, and in all other WordPress.com blogs too.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36000")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e55v4")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")]

#text("[…] Uncertainty. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab633f4e7bd3512cca45bf70f11ec84e4d471a1dd4975d9cd8bdde744f006afc-717528f64aa2ac2d515362ebc1c7ebcb1e18ad7d47b352e9feee8fac62489bad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sjt")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36003")[#strong[#text("sjt")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("luca: “It’s WordPress that has stopped providing alt text for the latex formulas.” [not the new LaTeX-to-HTML converter]")

#text("My mistake. (Why on earth would they do that?!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dweebydoofus")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36004")[#strong[#text("dweebydoofus")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("Hi Dr. Tao")

#text("do you think that Luca Trevisan would be interested in making this LaTeX to WordPress-HTML converter available to more users?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dweebydoofus")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36006")[#strong[#text("dweebydoofus")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("By the way: Lemma 4 has a formula that doesn’t parse.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36049")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("Dear Prof. Tao,")

#text("There’s a related result, which seems to go back to Schrödinger (1926): the only minimisers of Heisenberg’s uncertainty principle are precisely the Gaussians (up to scaling, translation and modulation; I’m not sure if Schrödinger proved the “only” part). In quantum mechanics, these are called coherent states, although this name came much later (I think it was given by Klauder in the sixties).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Jones")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36054")[#strong[#text("Tom Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("Dear Terry,")

#text("I was just wondering: What is your favorite movie? Because in the Tomb Raider post you mentioned that you played this game when you were younger. But do you like the movies today?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Planchon")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36070")[#strong[#text("Fabrice Planchon")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")])]

#text("you may want to have a look at Bruno Demange’s PhD thesis, which has some interesting generalizations of Hardy’s theorem (building up on a theorem by Beurling). Still complex analysis, tho. A PDE oriented perspective may be found in a recent paper by Kenig-Ponce-Vega, and this is real analysis ;-)")

#link("http://www.univ-orleans.fr/mapmo/publications/theses/DemangeTHE.pdf")[#text("Click to access DemangeTHE.pdf")]

#link("http://arxiv.org/abs/0802.1608")[#text("http://arxiv.org/abs/0802.1608")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36074")[#strong[#text("Converting LaTeX to WordPress « in theory")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2009")]

#text("[…] Tao has tested it on a couple of posts. Thanks to his feedback, the current version, while surely bug-filled and very limited, is stable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/352f663776a16a42f084be1a5552b9d2c5e5fc6e2848eaae74bfece737ba9ef2-827047537248c157149d8e1a9a333d8e18ebf89f0638c2a2215ff141da209ce5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Jaming")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-36110")[#strong[#text("Philippe Jaming")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2009")])]

#text("Hi Terry,")

#text("thanks for this post. If I remember well, there was a similar proof of Hardy’s Uncertainty Principle (UP) in Thangavelu’s book on the subject. A real variable proof would also help to get some progress on versions of Hardy’s UP for (say) the Heisenberg group, that would characterize the heat kernel (the natural analogue of gaussians). This was, I believe,")#linebreak()#text(" one of Thangavelu’s motivation.")

#text("I would also like to mention that there is a proof of Hardy’s UP du to B. Demange that works in the distributional setting (if f is a tempared distribution such that ")#mi("e^{\\pi x^2}f")#text(" and ")#mi("e^{\\pi \\xi^2}\\hat f")#text(" are also tempered distributions, then ")#mi("f=P(x)e^{-\\pi x^2}")#text(" where P is a polynomial). This relies on transforming the problem into a complex analysis one via the Bargman transform and Phragmen Lindelöf. Demange’s result generalizes several extensions of Hardy’s UP most notably Beurling-Hörmander’s version of the UP (and the extension thereoff by Bonami-Demange and myself in 2003). He’s proof")#linebreak()#text(" should appear soon in Memoires de la Société Math. Française")#linebreak()#text(" (as far as I know).")

#text("Finally, there is a series of recent papers by L. Escauriaza, C.E. Kenig, G. Ponce, L. Vega (sorry if I forget somebody) on the UP from the PDE")#linebreak()#text(" point of view (Shrödinger equation) that mainly relies on real analysis too.")

#text("Best regards")#linebreak()#text(" Philippe")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-37406")[#strong[#text("Well, there’s a comparison I didn’t expect to see… « Feed The Bears")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")]

#text("[…] Tao, who amongst other things is a harmonic analyst, wrote a post a few weeks ago thinking about a similar question. Of course he thinks about it in a much deeper way, with much more advanced technology, and actually […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd546f5a9eb02f904cb159c02eb4ce57d8eddd84b120d4a1156f44d7bd027c2a-ea84a291a354302563999903364618427f2e81c0d2e930488c6d9c13413a8e86.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kaveh Khodjasteh")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-44117")[#strong[#text("Kaveh Khodjasteh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2010")])]

#text("I keep coming back to this post because I think it must have to do with a problem that has occupied my mine for a long time. In particular, what triggered my attention was Lemma 3. Unfortunately I cannot use it because it holds only (?) for even order derivatives. Is that the case?")

#text("The problem I am talking here appears here:")

#link("http://mathoverflow.net/questions/16771/lower-bounds-on-truncated-fourier-transform-of-functions-of-constant-modulus-an")[#text("http://mathoverflow.net/questions/16771/lower-bounds-on-truncated-fourier-transform-of-functions-of-constant-modulus-an")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yashar")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-44123")[#strong[#text("Yashar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2010")])]

#text("Good to see you at Terry’s blog Kaveh!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-45693")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] formalisations of this principle, most famously the Heisenberg uncertainty principle and the Hardy uncertainty principle – but in many situations, it is the heuristic formulation of the principle that is more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf92cdffba8a3d9bc4cec429bede87218aa60c103282a6861c56d2f5c6b24108-7cfd7a275a8c8207780e950ef46b4198f8ae33fd828821151e769bfbfe3a7927.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wilsonofgordon")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-416391")[#strong[#text("wilsonofgordon")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2014")])]

#text("Prof. Tao")#linebreak()#text(" Why does the exponent of the function ")#mi("e^{-i \\epsilon e^{i \\epsilon} z^{2+\\epsilon}} e^{i\\delta z^2}F(z)")#text(" (which occured in the complex analytical proof of the Hardy principle) have a minus sign? Doesn’t that make the first exponent have positive real part and diverge as z tends infinity? (I’m really new to wordpress and I’m sorry I dont know how to typeset LaTeX properly here so sorry.)")

#emph[#text("[Sorry, that was a sign error, now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81b0d38a95f82c98e826918c93bfc1e19b96f6df64b3fa0b294297822585dac8-1949caf0cd5264b8c0062b82a1446ef135e465e234e64a2ed9f3d0b0bd3e842e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-472464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2016")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Could you please explain to me what does you C on lemma 4 depend on ?")#linebreak()#text(" Thank you")

#emph[#text("[As stated in the lemma, C is an absolute constant (it can probably be conservatively taken to be something like 10, though I have not attempted to compute it explicitly.) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-490898")[#strong[#text("Uncertainty principle – Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2017")]

#text("[…] pdf version is Uncertainty principle. The nice note of terrence tao seems given a nice answer for the problem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivo")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-504226")[#strong[#text("Ivo")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2018")])]

#text("There is a small typo (dx –> d\\xi) towards the top:")

#text("<<>>")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-507434")[#strong[#text("ss nn")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2018")]

#text("Dear Prof. Tao,")

#text("Could you please explain why using Stirling’s formula after lemma 3 we get ")#mi("(\\frac{\\pi e}{a}+o(1))^{k/2}k^{k/2}")

#text("instead of ")#mi("(\\frac{2\\pi}{ae})^{k/2}k^{k/2}(1+o(1))^k")#text("?")

#text("If I am not mistaken,")#linebreak()#text(" ")#mi("\\frac{C}{\\sqrt{a}}\\frac{k!\\pi^{k/2}}{(k/2)!a^{(k+1)/2}} = (\\frac{k}{e})^k(\\frac{\\pi}{a})^{k/2}\\frac{e^{k/2}}{(k/2)^{k/2}}(1+o(1))^k=(\\frac{2\\pi}{ae})^{k/2}k^{k/2}(1+o(1))^k")

#text("Thanks")

#emph[#text("[This was a typo, now corrected -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-555662")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Does the result that a nonzero function cannot have both compact support and compact Fourier support extend to higher dimensions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-555682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Yes, because in any dimension the Fourier transform of an (absolutely integrable) function of compact support is real analytic in all variables, and this class of functions enjoys the unique continuation property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-555692")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")])]

#text("Does this mean that the open sets ")#mi("U_i")#text(" in the family ")#mi("\\mathcal{U}")#text(" for decoupling estimates should always be unbounded, because we are using test functions which are smooth with compact support?")

#emph[#text("[That was a typo; the Schwartz class should have been used instead. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/#comment-649090")[#strong[#text("Uncertainty principle - Relationship of relationship")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2022")]

#text("[…] pdf version is Uncertainty principle. The nice note of terrence tao seems given a nice answer for the problem […]")
]
