// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T10:52:46.643030+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Twisted convolution and the sensitivity conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Twisted convolution and the sensitivity conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 July 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/")[#text("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Earlier this month, ")#link("https://blog.nus.edu.sg/huanghao/")[#text("Hao Huang")]#text(" (who, incidentally, was a graduate student here at UCLA) gave a ")#link("http://www.mathcs.emory.edu/~hhuan30/papers/sensitivity_1.pdf")[#text("remarkably short proof")]#text(" of a long-standing problem in theoretical computer science known as the sensitivity conjecture. See for instance ")#link("https://gilkalai.wordpress.com/2019/07/02/amazing-hao-huang-proved-the-sensitivity-conjecture/")[#text("this blog post of Gil Kalai")]#text(" for further discussion and links to many other online discussions of this result. One formulation of the theorem proved is as follows. Define the ")#mi("{n}")#text("-dimensional ")#link("https://en.wikipedia.org/wiki/Hypercube_graph")[#text("hypercube graph")]#text(" ")#mi("{Q_n}")#text(" to be the graph with vertex set ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", and with every vertex ")#mi("{v \\in ({\\bf Z}/2{\\bf Z})^n}")#text(" joined to the ")#mi("{n}")#text(" vertices ")#mi("{v + e_1,\\dots,v+e_n}")#text(", where ")#mi("{e_1,\\dots,e_n}")#text(" is the standard basis of ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Lower bound on maximum degree of induced subgraphs of hypercube)")]#text(" ")#metadata(none) <tao-a6ed0e59c7903ee0c651>#text(" Let ")#mi("{E}")#text(" be a set of at least ")#mi("{2^{n-1}+1}")#text(" vertices in ")#mi("{Q_n}")#text(". Then there is a vertex in ")#mi("{E}")#text(" that is adjacent (in ")#mi("{Q_n}")#text(") to at least ")#mi("{\\sqrt{n}}")#text(" other vertices in ")#mi("{E}")#text(".")
]

#text("The bound ")#mi("{\\sqrt{n}}")#text(" (or more precisely, ")#mi("{\\lceil \\sqrt{n} \\rceil}")#text(") is completely sharp, as shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=957216")[#text("by Chung, Furedi, Graham, and Seymour")]#text("; we describe this example below the fold. When combined with earlier reductions ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1178392")[#text("of Gotsman-Linial")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1313531")[#text("Nisan-Szegedy")]#text("; we give these below the fold also.")

#text("Let ")#mi("{A = (a_{vw})_{v,w \\in ({\\bf Z}/2{\\bf Z})^n}}")#text(" be the adjacency matrix of ")#mi("{Q_n}")#text(" (where we index the rows and columns directly by the vertices in ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", rather than selecting some enumeration ")#mi("{1,\\dots,2^n}")#text("), thus ")#mi("{a_{vw}=1}")#text(" when ")#mi("{w = v+e_i}")#text(" for some ")#mi("{i=1,\\dots,n}")#text(", and ")#mi("{a_{vw}=0}")#text(" otherwise. The above theorem then asserts that if ")#mi("{E}")#text(" is a set of at least ")#mi("{2^{n-1}+1}")#text(" vertices, then the ")#mi("{E \\times E}")#text(" minor ")#mi("{(a_{vw})_{v,w \\in E}}")#text(" of ")#mi("{A}")#text(" has a row (or column) that contains at least ")#mi("{\\sqrt{n}}")#text(" non-zero entries.")

#text("The key step to prove this theorem is the construction of rather curious variant ")#mi("{\\tilde A}")#text(" of the adjacency matrix ")#mi("{A}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-3be7a505483c0050243c>#text(" There exists a ")#mi("{({\\bf Z}/2{\\bf Z})^n \\times ({\\bf Z}/2{\\bf Z})^n}")#text(" matrix ")#mi("{\\tilde A = (\\tilde a_{vw})_{v,w \\in ({\\bf Z}/2{\\bf Z})^n}}")#text(" which is entrywise dominated by ")#mi("{A}")#text(" in the sense that ")#metadata(none) <tao-923fe53966c6cd9343e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\tilde a_{vw}\\right| \\leq a_{vw} \\text{ for all } v,w \\in ({\\bf Z}/2{\\bf Z})^n", block: true)]]

#text("and such that ")#mi("{\\tilde A}")#text(" has ")#mi("{\\sqrt{n}}")#text(" as an eigenvalue with multiplicity ")#mi("{2^{n-1}}")#text(".")
]

#text("Assuming this proposition, the proof of Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(" can now be quickly concluded. If we view ")#mi("{\\tilde A}")#text(" as a linear operator on the ")#mi("{2^n}")#text("-dimensional space ")#mi("{\\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(" of functions of ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", then by hypothesis this space has a ")#mi("{2^{n-1}}")#text("-dimensional subspace ")#mi("{V}")#text(" on which ")#mi("{\\tilde A}")#text(" acts by multiplication by ")#mi("{\\sqrt{n}}")#text(". If ")#mi("{E}")#text(" is a set of at least ")#mi("{2^{n-1}+1}")#text(" vertices in ")#mi("{Q_n}")#text(", then the space ")#mi("{\\ell^2(E)}")#text(" of functions on ")#mi("{E}")#text(" has codimension at most ")#mi("{2^{n-1}-1}")#text(" in ")#mi("{\\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(", and hence intersects ")#mi("{V}")#text(" non-trivially. Thus the ")#mi("{E \\times E}")#text(" minor ")#mi("{\\tilde A_E}")#text(" of ")#mi("{\\tilde A}")#text(" also has ")#mi("{\\sqrt{n}}")#text(" as an eigenvalue (this can also be derived from the ")#link("https://en.wikipedia.org/wiki/Min-max_theorem#Cauchy_interlacing_theorem")[#text("Cauchy interlacing inequalities")]#text("), and in particular this minor has operator norm at least ")#mi("{\\sqrt{n}}")#text(". By ")#link("https://en.wikipedia.org/wiki/Schur_test")[#text("Schur’s test")]#text(", this implies that one of the rows or columns of this matrix has absolute values summing to at least ")#mi("{\\sqrt{n}}")#text(", giving the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" ")#metadata(none) <tao-b5e906c79dfd3193762d>#text(" The argument actually gives a strengthening of Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(": there exists a vertex ")#mi("{v_0}")#text(" of ")#mi("{E}")#text(" with the property that for every natural number ")#mi("{k}")#text(", there are at least ")#mi("{n^{k/2}}")#text(" paths of length ")#mi("{k}")#text(" in the restriction ")#mi("{Q_n|_E}")#text(" of ")#mi("{Q_n}")#text(" to ")#mi("{E}")#text(" that start from ")#mi("{v_0}")#text(". Indeed, if we let ")#mi("{(u_v)_{v \\in E}}")#text(" be an eigenfunction of ")#mi("{\\tilde A}")#text(" on ")#mi("{\\ell^2(E)}")#text(", and let ")#mi("{v_0}")#text(" be a vertex in ")#mi("{E}")#text(" that maximises the value of ")#tao-math("{\\left|u_{v_0}\\right|}", block: false)#text(", then for any ")#mi("{k}")#text(" we have that the ")#mi("{v_0}")#text(" component of ")#mi("{\\tilde A_E^k (u_v)_{v \\in E}}")#text(" is equal to ")#tao-math("{n^{k/2} \\left|u_{v_0}\\right|}", block: false)#text("; on the other hand, by the triangle inequality, this component is at most ")#tao-math("{\\left|u_{v_0}\\right|}", block: false)#text(" times the number of length ")#mi("{k}")#text(" paths in ")#mi("{Q_n|_E}")#text(" starting from ")#mi("{v_0}")#text(", giving the claim.")
]

#text("This argument can be viewed as an instance of a more general “interlacing method” to try to control the behaviour of a graph ")#mi("{G}")#text(" on all large subsets ")#mi("{E}")#text(" by first generating a matrix ")#mi("{\\tilde A}")#text(" on ")#mi("{G}")#text(" with very good spectral properties, which are then partially inherited by the ")#mi("{E \\times E}")#text(" minor of ")#mi("{\\tilde A}")#text(" by interlacing inequalities. In previous literature using this method (see e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1344588")[#text("this survey of Haemers")]#text(", or ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=771733")[#text("this paper of Wilson")]#text("), either the original adjacency matrix ")#mi("{A}")#text(", or some non-negatively weighted version of that matrix, was used as the controlling matrix ")#mi("{\\tilde A}")#text("; the novelty here is the use of signed controlling matrices. It will be interesting to see what further variants and applications of this method emerge in the near future. (Thanks to Anurag Bishoi in the comments for these references.)")

#text("The “magic” step in the above argument is constructing ")#mi("{\\tilde A}")#text(". In Huang’s paper, ")#mi("{\\tilde A}")#text(" is constructed recursively in the dimension ")#mi("{n}")#text(" in a rather simple but mysterious fashion. Very recently, ")#link("https://arxiv.org/abs/1907.11175")[#text("Roman Karasev gave an interpretation")]#text(" of this matrix in terms of the exterior algebra on ")#mi("{{\\bf R}^n}")#text(". In this post I would like to give an alternate interpretation in terms of the operation of ")#emph[#text("twisted convolution")]#text(", which originated in the theory of the ")#link("https://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]#text(" in quantum mechanics.")

#text("Firstly note that the original adjacency matrix ")#mi("{A}")#text(", when viewed as a linear operator on ")#mi("{\\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(", is a convolution operator")

#align(center)[#tao-fit-display[#mitex("A f = f * \\mu")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\mu(x) := \\sum_{i=1}^n 1_{x=e_i}")]]

#text("is the counting measure on the standard basis ")#mi("{e_1,\\dots,e_n}")#text(", and ")#mi("{*}")#text(" denotes the ordinary convolution operation")

#align(center)[#tao-fit-display[#mitex("f * g(x) := \\sum_{y \\in ({\\bf Z}/2{\\bf Z})^n} f(y) g(x-y) = \\sum_{y_1+y_2 = x} f(y_1) g(y_2).")]]

#text("As is well known, this operation is commutative and associative. Thus for instance the square ")#mi("{A^2}")#text(" of the adjacency operator ")#mi("{A}")#text(" is also a convolution operator")

#align(center)[#tao-fit-display[#mitex("A^2 f = f * (\\mu * \\mu)(x)")]]

#text("where the convolution kernel ")#mi("{\\mu * \\mu}")#text(" is moderately complicated:")

#align(center)[#tao-fit-display[#mitex("\\mu*\\mu(x) = n \\times 1_{x=0} + \\sum_{1 \\leq i < j \\leq n} 2 \\times 1_{x = e_i + e_j}.")]]

#text("The factor ")#mi("{2}")#text(" in this expansion comes from combining the two terms ")#mi("{1_{x=e_i} * 1_{x=e_j}}")#text(" and ")#mi("{1_{x=e_j} * 1_{x=e_i}}")#text(", which both evaluate to ")#mi("{1_{x=e_i+e_j}}")#text(".")

#text("More generally, given any bilinear form ")#mi("{B: ({\\bf Z}/2{\\bf Z})^n \\times ({\\bf Z}/2{\\bf Z})^n \\rightarrow {\\bf Z}/2{\\bf Z}}")#text(", one can define the ")#emph[#text("twisted convolution")]

#tao-aligned(keep: true)[


#tao-math("f *_B g(x)  & := \\sum_{y \\in ({\\bf Z}/2{\\bf Z})^n} (-1)^{B(y,x-y)} f(y) g(x-y)", block: true)



#tao-math(" & = \\sum_{y_1+y_2=x} (-1)^{B(y_1,y_2)} f(y_1) g(y_2)", block: true)
]

#text("of two functions ")#mi("{f,g \\in \\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(". This operation is no longer commutative (unless ")#mi("{B}")#text(" is symmetric). However, it remains associative; indeed, one can easily compute that")

#tao-aligned(keep: true)[


#tao-math("(f *_B g) *_B h(x)  & = f *_B (g *_B h)(x)", block: true)



#tao-math(" & = \\sum_{y_1+y_2+y_3=x} (-1)^{B(y_1,y_2)+B(y_1,y_3)+B(y_2,y_3)} f(y_1) g(y_2) h(y_3).", block: true)
]

#text("In particular, if we define the twisted convolution operator")

#align(center)[#tao-fit-display[#mitex("A_B f(x) := f *_B \\mu(x)")]]

#text("then the square ")#mi("{A_B^2}")#text(" is also a twisted convolution operator")

#align(center)[#tao-fit-display[#mitex("A_B^2 f = f *_B (\\mu *_B \\mu)")]]

#text("and the twisted convolution kernel ")#mi("{\\mu *_B \\mu}")#text(" can be computed as")

#tao-aligned(keep: true)[


#tao-math("\\mu *_B \\mu(x)  & = (\\sum_{i=1}^n (-1)^{B(e_i,e_i)}) 1_{x=0}", block: true)



#tao-math(" & + \\sum_{1 \\leq i < j \\leq n} ((-1)^{B(e_i,e_j)} + (-1)^{B(e_j,e_i)}) 1_{x=e_i+e_j}.", block: true)
]

#text("For general bilinear forms ")#mi("{B}")#text(", this twisted convolution is just as messy as ")#mi("{\\mu * \\mu}")#text(" is. But if we take the specific bilinear form ")#metadata(none) <tao-c03f6631cf7e0e1bcbd0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("B(x,y) := \\sum_{1 \\leq i < j \\leq n} x_i y_j")]]

#text("then ")#mi("{B(e_i,e_i)=0}")#text(" for ")#mi("{1 \\leq i \\leq n}")#text(" and ")#mi("{B(e_i,e_j)=1, B(e_j,e_i)=0}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(", and the above twisted convolution simplifies to")

#align(center)[#tao-fit-display[#mitex("\\mu *_B \\mu(x) = n 1_{x=0}")]]

#text("and now ")#mi("{A_B^2}")#text(" is very simple:")

#align(center)[#tao-fit-display[#mitex("A_B^2 f = n f.")]]

#text("Thus the only eigenvalues of ")#mi("{A_B}")#text(" are ")#mi("{+\\sqrt{n}}")#text(" and ")#mi("{-\\sqrt{n}}")#text(". The matrix ")#mi("{A_B}")#text(" is entrywise dominated by ")#mi("{A}")#text(" in the sense of ")#link(<tao-923fe53966c6cd9343e1>)[#text("(1)")]#text(", and in particular has trace zero; thus the ")#mi("{+\\sqrt{n}}")#text(" and ")#mi("{-\\sqrt{n}}")#text(" eigenvalues must occur with equal multiplicity, so in particular the ")#mi("{+\\sqrt{n}}")#text(" eigenvalue occurs with multiplicity ")#mi("{2^{n-1}}")#text(" since the matrix has dimensions ")#mi("{2^n \\times 2^n}")#text(". This establishes Proposition ")#link(<tao-3be7a505483c0050243c>)[#text("2")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Twisted convolution ")#mi("{*_B}")#text(" is actually just a component of ordinary convolution, but not on the original group ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text("; instead it relates to convolution on a Heisenberg group extension of this group. More specifically, define the Heisenberg group ")#mi("{H}")#text(" to be the set of pairs ")#mi("{(x, t) \\in ({\\bf Z}/2{\\bf Z})^n \\times ({\\bf Z}/2{\\bf Z})}")#text(" with group law")

#align(center)[#tao-fit-display[#mitex("(x,t) \\cdot (y,s) := (x+y, t+s+B(x,y))")]]

#text("and inverse operation")

#align(center)[#tao-fit-display[#mitex("(x,t)^{-1} = (-x, -t+B(x,x))")]]

#text("(one can dispense with the negative signs here if desired, since we are in characteristic two). Convolution on ")#mi("{H}")#text(" is defined in the usual manner: one has")

#align(center)[#tao-fit-display[#mitex("F*G( (x,t) ) := \\sum_{(y,s) \\in H} F(y,s) G( (y,s)^{-1} (x,t) )")]]

#text("for any ")#mi("{F,G \\in \\ell^2(H)}")#text(". Now if ")#mi("{f \\in \\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(" is a function on the original group ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", we can define the lift ")#mi("{\\tilde f \\in \\ell^2(H)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde f(x,t) := (-1)^t f(x)")]]

#text("and then by chasing all the definitions one soon verifies that")

#align(center)[#tao-fit-display[#mitex("\\tilde f * \\tilde g = 2 \\widetilde{f *_B g}")]]

#text("for any ")#mi("{f,g \\in \\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(", thus relating twisted convolution ")#mi("{*_B}")#text(" to Heisenberg group convolution ")#mi("{*}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" ")#metadata(none) <tao-372e8b17bc19492f1db5>#text(" With the twisting by the specific bilinear form ")#mi("{B}")#text(" given by ")#link(<tao-c03f6631cf7e0e1bcbd0>)[#text("(2)")]#text(", convolution by ")#mi("{1_{x=e_i}}")#text(" and ")#mi("{1_{x=e_j}}")#text(" now anticommute rather than commute. This makes the twisted convolution algebra ")#mi("{(\\ell^2(({\\bf Z}/2{\\bf Z})^n), *_B)}")#text(" isomorphic to a ")#link("https://en.wikipedia.org/wiki/Clifford_algebra")[#text("Clifford algebra")]#text(" ")#mi("{Cl({\\bf R}^n,I_n)}")#text(" (the real or complex algebra generated by formal generators ")#mi("{v_1,\\dots,v_n}")#text(" subject to the relations ")#mi("{(v_iv_j+v_jv_i)/2 = 1_{i=j}}")#text(" for ")#mi("{i,j=1,\\dots,n}")#text(") rather than the commutative algebra more familiar to abelian Fourier analysis. This connection to Clifford algebra (also observed independently by Tom Mrowka and ")#link("https://arxiv.org/abs/1907.12357")[#text("by Daniel Matthews")]#text(") may be linked to the exterior algebra interpretation of the argument in the ")#link("https://arxiv.org/abs/1907.11175")[#text("recent preprint of Karasev")]#text(" mentioned above.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" ")#metadata(none) <tao-5c8cf56f4c6350c50195>#text(" One could replace the form ")#link(<tao-c03f6631cf7e0e1bcbd0>)[#text("(2)")]#text(" in this argument by any other bilinear form ")#mi("{B^{\\prime}}")#text(" that obeyed the relations ")#mi("{B^{\\prime}(e_i,e_i)=0}")#text(" and ")#mi("{B^{\\prime}(e_i,e_j) + B^{\\prime}(e_j,e_i)=1}")#text(" for ")#mi("{i \\neq j}")#text(". However, this additional level of generality does not add much; any such ")#mi("{B^{\\prime}}")#text(" will differ from ")#mi("{B}")#text(" by an antisymmetric form ")#mi("{C}")#text(" (so that ")#mi("{C(x,x) = 0}")#text(" for all ")#mi("{x}")#text(", which in characteristic two implied that ")#mi("{C(x,y) = C(y,x)}")#text(" for all ")#mi("{x,y}")#text("), and such forms can always be decomposed as ")#mi("{C(x,y) = C^{\\prime}(x,y) + C^{\\prime}(y,x)}")#text(", where ")#mi("{C^{\\prime}(x,y) := \\sum_{i<j} C(e_i,e_j) x_i y_j}")#text(". As such, the matrices ")#mi("{A_B}")#text(" and ")#mi("{A_{B^{\\prime}}}")#text(" are conjugate, with the conjugation operator being the diagonal matrix with entries ")#mi("{(-1)^{C^{\\prime}(x,x)}}")#text(" at each vertex ")#mi("{x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-ec823d3edd0d07f78bba>#text(" (Added later) This remark combines the two previous remarks. One can view any of the matrices ")#mi("{A_{B^{\\prime}}}")#text(" in Remark ")#link(<tao-5c8cf56f4c6350c50195>)[#text("6")]#text(" as components of a single canonical matrix ")#mi("{A_{Cl}}")#text(" that is still of dimensions ")#mi("{({\\bf Z}/2{\\bf Z})^n \\times ({\\bf Z}/2{\\bf Z})^n}")#text(", but takes values in the Clifford algebra ")#mi("{Cl({\\bf R}^n,I_n)}")#text(" from Remark ")#link(<tao-372e8b17bc19492f1db5>)[#text("5")]#text("; with this “universal algebra” perspective, one no longer needs to make any arbitrary choices of form ")#mi("{B}")#text(". More precisely, let ")#mi("{\\ell^2( ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n))}")#text(" denote the vector space of functions ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n)}")#text(" from the hypercube to the Clifford algebra; as a real vector space, this is a ")#mi("{2^{2n}}")#text(" dimensional space, isomorphic to the direct sum of ")#mi("{2^n}")#text(" copies of ")#mi("{\\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(", as the Clifford algebra is itself ")#mi("{2^n}")#text(" dimensional. One can then define a canonical Clifford adjacency operator ")#mi("{A_{Cl}}")#text(" on this space by")

#align(center)[#tao-fit-display[#mitex("A_{Cl} f(x) := \\sum_{i=1}^n f(x+e_i) v_i")]]

#text("where ")#mi("{v_1,\\dots,v_n}")#text(" are the generators of ")#mi("{Cl({\\bf R}^n,I_n)}")#text(". This operator can either be identified with a Clifford-valued ")#mi("{2^n \\times 2^n}")#text(" matrix or as a real-valued ")#mi("{2^{2n} \\times 2^{2n}}")#text(" matrix. In either case one still has the key algebraic relations ")#mi("{A_{Cl}^2 = n}")#text(" and ")#mi("{\\mathrm{tr} A_{Cl} = 0}")#text(", ensuring that when viewed as a real ")#mi("{2^{2n} \\times 2^{2n}}")#text(" matrix, half of the eigenvalues are equal to ")#mi("{+\\sqrt{n}}")#text(" and half equal to ")#mi("{-\\sqrt{n}}")#text(". One can then use this matrix in place of any of the ")#mi("{A_{B^{\\prime}}}")#text(" to establish Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(" (noting that Schur’s test continues to work for Clifford-valued matrices because of the norm structure on ")#mi("{Cl({\\bf R}^n,I_n)}")#text(").")

#text("To relate ")#mi("{A_{Cl}}")#text(" to the real ")#mi("{2^n \\times 2^n}")#text(" matrices ")#mi("{A_{B^{\\prime}}}")#text(", first observe that each point ")#mi("{x}")#text(" in the hypercube ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(" can be associated with a one-dimensional real subspace ")#mi("{\\ell_x}")#text(" (i.e., a line) in the Clifford algebra ")#mi("{Cl({\\bf R}^n,I_n)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\ell_{e_{i_1} + \\dots + e_{i_k}} := \\mathrm{span}_{\\bf R}( v_{i_1} \\dots v_{i_k} )")]]

#text("for any ")#mi("{i_1,\\dots,i_k \\in \\{1,\\dots,n\\}}")#text(" (note that this definition is well-defined even if the ")#mi("{i_1,\\dots,i_k}")#text(" are out of order or contain repetitions). This can be viewed as a discrete line bundle over the hypercube. Since ")#mi("{\\ell_{x+e_i} = \\ell_x e_i}")#text(" for any ")#mi("{i}")#text(", we see that the ")#mi("{2^n}")#text("-dimensional real linear subspace ")#mi("{V}")#text(" of ")#mi("{\\ell^2( ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n))}")#text(" of sections of this bundle, that is to say the space of functions ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n)}")#text(" such that ")#mi("{f(x) \\in \\ell_x}")#text(" for all ")#mi("{x \\in ({\\bf Z}/2{\\bf Z})^n}")#text(", is an invariant subspace of ")#mi("{A_{Cl}}")#text(". (Indeed, using the left-action of the Clifford algebra on ")#mi("{\\ell^2( ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n))}")#text(", which commutes with ")#mi("{A_{Cl}}")#text(", one can naturally identify ")#mi("{\\ell^2( ({\\bf Z}/2{\\bf Z})^n \\rightarrow Cl({\\bf R}^n,I_n))}")#text(" with ")#mi("{Cl({\\bf R}^n,I_n) \\otimes V}")#text(", with the left action of ")#mi("{Cl({\\bf R}^n,I_n)}")#text(" acting purely on the first factor and ")#mi("{A_{Cl}}")#text(" acting purely on the second factor.) Any trivialisation of this line bundle lets us interpret the restriction ")#mi("{A_{Cl}|_V}")#text(" of ")#mi("{A_{Cl}}")#text(" to ")#mi("{V}")#text(" as a real ")#mi("{2^n \\times 2^n}")#text(" matrix. In particular, given one of the bilinear forms ")#mi("{B^{\\prime}}")#text(" from Remark ")#link(<tao-5c8cf56f4c6350c50195>)[#text("6")]#text(", we can identify ")#mi("{V}")#text(" with ")#mi("{\\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(" by identifying any real function ")#mi("{f \\in \\ell^2( ({\\bf Z}/2{\\bf Z})^n)}")#text(" with the lift ")#mi("{\\tilde f \\in V}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde f(e_{i_1} + \\dots + e_{i_k}) := (-1)^{\\sum_{1 \\leq j < j^{\\prime} \\leq k} B^{\\prime}(e_{i_j}, e_{i_{j^{\\prime}}})}")]]

#align(center)[#tao-fit-display[#mitex("f(e_{i_1} + \\dots + e_{i_k}) v_{i_1} \\dots v_{i_k}")]]

#text("whenever ")#mi("{1 \\leq i_1 < \\dots < i_k \\leq n}")#text(". A somewhat tedious computation using the properties of ")#mi("{B^{\\prime}}")#text(" then eventually gives the intertwining identity")

#align(center)[#tao-fit-display[#mitex("A_{Cl} \\tilde f = \\widetilde{A_{B^{\\prime}} f}")]]

#text("and so ")#mi("{A_{B^{\\prime}}}")#text(" is conjugate to ")#mi("{A_{Cl}|_V}")#text(".")
]

#metadata(none) <tao-66347e6ec470f9d61e96>

#heading(level: 1)[#strong[#text(" — 1. The Chung, Furedi, Graham, and Seymour example — ")]]

#metadata(none) <tao-a7422bd8309af63b415c>

#text("The paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=957216")[#text("by Chung, Furedi, Graham, and Seymour")]#text(" gives, for any ")#mi("{n \\geq 1}")#text(", an example of a subset ")#mi("{E}")#text(" of ")#mi("{Q_n}")#text(" of cardinality ")#mi("{2^{n-1}+1}")#text(" for which the maximum degree of ")#mi("{Q_n}")#text(" restricted to ")#mi("{E}")#text(" is at most ")#mi("{\\lceil \\sqrt{n} \\rceil}")#text(", thus showing that Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(" cannot be improved (beyond the trivial improvement of upgrading ")#mi("{\\sqrt{n}}")#text(" to ")#mi("{\\lceil \\sqrt{n} \\rceil}")#text(", because the maximum degree is obviously a natural number).")

#text("Define the “Möbius function” ")#mi("{\\mu: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("\\mu(x) := (-1)^{x_1+\\dots+x_n}")]]

#text("for ")#mi("{x = (x_1,\\dots,x_n) \\in ({\\bf Z}/2{\\bf Z})^n}")#text(". This function is extremely balanced on coordinate spaces. Indeed, from the binomial theorem (which uses the convention ")#mi("{0^0=1}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n} \\mu(x) = (1-1)^n = 1_{n=0}.")]]

#text("More generally, given any index set ")#mi("{I \\subset \\{1,\\dots,n\\}}")#text(" of cardinality ")#tao-math("{\\left|I\\right|}", block: false)#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n: x_i=0 \\forall i \\in I} \\mu(x) = (1-1)^{n-\\left|I\\right|} = 1_{n=\\left|I\\right|}.", block: true)]]

#text("Now let ")#mi("{I_1,\\dots,I_k}")#text(" be a partition of ")#mi("{\\{1,\\dots,n\\}}")#text(" into disjoint non-empty sets. For each ")#mi("{j \\in J}")#text(", let ")#mi("{V_j}")#text(" be the subspace of ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(" consisting of those ")#mi("{x = (x_1,\\dots,x_n)}")#text(" such that ")#mi("{x_i = 0}")#text(" for all ")#mi("{i \\in I_j}")#text(". Then for any ")#mi("{J \\subset \\{1,\\dots,k\\}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in \\bigcap_{j \\in J} V_j} \\mu(x) = (1-1)^{1_{n= \\sum_{j \\in J}\\left|I_i\\right|}} = 1_{n = \\sum_{j \\in J} \\left|I_i\\right|},", block: true)]]

#text("and the right-hand side vanishes if ")#mi("{J \\neq \\{1,\\dots,k\\}}")#text(" and equals ")#mi("{1}")#text(" when ")#mi("{J = \\{1,\\dots,k\\}}")#text(". Applying the inclusion-exclusion principle, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n \\backslash \\bigcup_{j=1}^k V_j} \\mu(x) = (-1)^k")]]

#text("and thus also (assuming ")#mi("{n \\geq 1}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in \\bigcup_{j=1}^k V_j} \\mu(x) = (-1)^{k+1}")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n \\backslash \\bigcup_{j=1}^k V_j} (-1)^k \\mu(x) + \\sum_{x \\in \\bigcup_{j=1}^k V_j} (-1)^{k+1} \\mu(x) = 2")]]

#text("Thus, if ")#mi("{E}")#text(" denotes the set of those ")#mi("{x \\in ({\\bf Z}/2{\\bf Z})^n \\backslash \\bigcup_{j=1}^k V_j}")#text(" with ")#mi("{(-1)^k \\mu(x) = 1}")#text(", together with those ")#mi("{x \\in \\bigcup_{j=1}^k V_j}")#text(" with ")#mi("{(-1)^{k+1} \\mu(x) = 1}")#text(", then ")#mi("{E}")#text(" has to have two more elements than its complement ")#mi("{({\\bf Z}/2{\\bf Z})^n \\backslash E}")#text(", and hence ")#mi("{E}")#text(" has cardinality ")#mi("{2^{n-1}+1}")#text(".")

#text("Now observe that, if ")#mi("{x \\in \\bigcup_{j=1}^k V_j}")#text(" with ")#mi("{(-1)^{k+1} \\mu(x)=1}")#text(" and ")#mi("{i = 1,\\dots,n}")#text(", then ")#mi("{(-1)^k \\mu(x+e_i)=1}")#text(", and if ")#mi("{x \\in V_j}")#text(" then ")#mi("{x+e_i \\in V_j}")#text(" unless ")#mi("{i \\in I_j}")#text(". Thus in this case the total number of ")#mi("{i}")#text(" for which ")#mi("{x+e_i \\in E}")#text(" is at most ")#tao-math("{\\max_j \\left|I_j\\right|}", block: false)#text(". Conversely, if ")#mi("{x \\not \\in \\bigcup_{j=1}^k V_j}")#text(" with ")#mi("{(-1)^k \\mu(x)=1}")#text(" and ")#mi("{i=1,\\dots,n}")#text(", then ")#mi("{(-1)^{k+1} \\mu(x+e_i)=1}")#text(", and for each ")#mi("{j}")#text(" there is at most one ")#mi("{i}")#text(" that will make ")#mi("{x+e_i}")#text(" lie in ")#mi("{V_j}")#text(". Hence in this case the total number of ")#mi("{i}")#text(" for which ")#mi("{x+e_i \\in E}")#text(" is at most ")#mi("{k}")#text(". Thus the maximum degree of the subgraph of ")#mi("{Q_n}")#text(" induced by ")#mi("{E}")#text(" is at most ")#tao-math("{\\max( \\max_j \\left|I_j\\right|, k )}", block: false)#text(". By choosing the ")#mi("{I_j}")#text(" to be a partition of ")#mi("{\\{1,\\dots,n\\}}")#text(" into ")#mi("{k=\\lceil \\sqrt{n} \\rceil}")#text(" pieces, each of cardinality at most ")#mi("{\\lceil \\sqrt{n} \\rceil}")#text(", we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Suppose that ")#mi("{n = k^2}")#text(" is a perfect square, then the lower bound here exactly matches the upper bound in Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(". In particular, the ")#mi("{E \\times E}")#text(" minor of the matrix ")#mi("{\\tilde A}")#text(" must have an eigenvector of eigenvalue ")#mi("{\\sqrt{n}}")#text(". Such an eigenvector can be explicitly constructed as follows. Let ")#mi("{f \\in \\ell^2(E)}")#text(" be the vector defined by setting")

#align(center)[#tao-fit-display[#mitex("f(x) := (-1)^{\\sum_{1 \\leq j < j^{\\prime} \\leq k} B( e_{i_j}, e_{i_{j^{\\prime}}} )}")]]

#text("whenever ")#mi("{x}")#text(" is of the form ")#metadata(none) <tao-792525db00993809e3a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x = \\sum_{j=1}^k e_{i_j}")]]

#text("for some ")#mi("{i_j \\in I_j}")#text(", ")#mi("{j =1,\\dots,k}")#text(", and")

#align(center)[#tao-fit-display[#mitex("f(x) := (-1)^{\\sum_{1 \\leq j < j^{\\prime} \\leq k: j,j^{\\prime} \\neq j_0} B( e_{i_j}, e_{i_{j^{\\prime}}} ) + k - j_0}")]]

#text("whenever ")#mi("{x}")#text(" is of the form ")#metadata(none) <tao-e9058ab198f6908f7021>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("x = \\sum_{1 \\leq j \\leq k: j \\neq j_0} e_{i_j}")]]

#text("for some ")#mi("{i_j \\in I_j}")#text(", ")#mi("{j =1,\\dots,k}")#text(", ")#mi("{j \\neq j_0}")#text(", and ")#mi("{f(x)=0}")#text(" for all other ")#mi("{x \\in E}")#text(" (one easily verifies that the previous types of ")#mi("{x}")#text(" lie in ")#mi("{E}")#text("). We claim that")

#align(center)[#tao-fit-display[#mitex("A_B f(x) = k f(x)")]]

#text("for all ")#mi("{x \\in E}")#text(". Expanding out the left-hand side, we wish to show that ")#metadata(none) <tao-2a7c4eeee64689d177b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{1 \\leq i \\leq n: x+e_i \\in E} (-1)^{B(x,e_i)} f(x+e_i) = k f(x)")]]

#text("for all ")#mi("{x \\in E}")#text(".")

#text("First suppose that ")#mi("{x}")#text(" is of the form ")#link(<tao-792525db00993809e3a3>)[#text("(3)")]#text(". One checks that ")#mi("{x+e_i}")#text(" lies in ")#mi("{E}")#text(" precisely when ")#mi("{i = i_{j_0}}")#text(" for one of the ")#mi("{j_0=1,\\dots,k}")#text(", in which case")

#align(center)[#tao-fit-display[#mitex("f(x+e_{i_{j_0}}) = f(x) (-1)^{\\sum_{1 \\leq j < j_0} B( e_{i_j}, e_{i_{j_0}}) + \\sum_{j_0 < j \\leq k} B(e_{i_{j_0}}, e_{i_j}) + k-j_0}.")]]

#text("Since ")#mi("{B(e_{i_{j_0}}, e_{i_j}) = B(e_{i_j}, e_{i_{j_0}}) + 1}")#text(", this simplifies using ")#link(<tao-792525db00993809e3a3>)[#text("(3)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("(-1)^{B(x,e_{i_{j_0}})} f(x + e_{i_{j_0}}) = f(x)")]]

#text("giving ")#link(<tao-2a7c4eeee64689d177b9>)[#text("(5)")]#text(" in this case. Similarly, if ")#mi("{x}")#text(" is of the form ")#link(<tao-e9058ab198f6908f7021>)[#text("(4)")]#text(", then ")#mi("{y+e_i}")#text(" lies in ")#mi("{E}")#text(" precisely when ")#mi("{i \\in I_{j_0}}")#text(", in which case one can argue as before to show that")

#align(center)[#tao-fit-display[#mitex("(-1)^{B(x,e_{i})} f(x + e_{i}) = f(x)")]]

#text("and ")#link(<tao-2a7c4eeee64689d177b9>)[#text("(5)")]#text(" again follows. Finally, if ")#mi("{x \\in E}")#text(" is not of either of the two forms ")#link(<tao-792525db00993809e3a3>)[#text("(3)")]#text(", ")#link(<tao-e9058ab198f6908f7021>)[#text("(4)")]#text(", one can check that ")#mi("{x+e_i}")#text(" is never of these forms either, and so both sides of ")#link(<tao-2a7c4eeee64689d177b9>)[#text("(5)")]#text(" vanish.")

#text("The same analysis works for any of the other bilinear forms ")#mi("{B^{\\prime}}")#text(" in Remark ")#link(<tao-5c8cf56f4c6350c50195>)[#text("6")]#text(". Using the Clifford-valued operator ")#mi("{A_{Cl}}")#text(" from Remark ")#link(<tao-ec823d3edd0d07f78bba>)[#text("7")]#text(", the eigenfunction ")#mi("{f \\in \\ell^2( E \\rightarrow Cl({\\bf R}^n,I_n) )}")#text(" is cleaner; it is defined by")

#align(center)[#tao-fit-display[#mitex("f(x) := v_{e_{i_1}} \\dots v_{e_{i_k}}")]]

#text("when ")#mi("{x}")#text(" is of the form ")#link(<tao-792525db00993809e3a3>)[#text("(3)")]#text(", and")

#align(center)[#tao-fit-display[#mitex("f(x) := (-1)^{k-j_0} v_{e_{i_1}} \\dots v_{e_{i_{j_0-1}}} v_{e_{i_{j_0+1}}} v_{e_{i_k}}")]]

#text("when ")#mi("{x}")#text(" is of the form ")#link(<tao-e9058ab198f6908f7021>)[#text("(4)")]#text(", with ")#mi("{f(x)=0}")#text(" otherwise.")
]

#heading(level: 1)[#strong[#text(" — 2. From induced subgraph bounds to the sensitivity conjecture — ")]]

#text("On the hypercube ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", let ")#mi("{X_1,\\dots,X_n: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(" denote the functions")

#align(center)[#tao-fit-display[#mitex("X_i(x) := (-1)^{x_i}.")]]

#text("The monomials ")#mi("{\\prod_{i \\in I} X_i}")#text(" in ")#mi("{X_i}")#text(" are then the characters of ")#mi("{({\\bf Z}/2{\\bf Z})^n}")#text(", so by Fourier expansion every function ")#mi("{f \\in \\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(" can be viewed as a polynomial in the ")#mi("{X_i}")#text(" (with each monomial containing at most one copy of ")#mi("{X_i}")#text("; higher powers of each ")#mi("{X_i}")#text(" are unnecessary since ")#mi("{X_i^2=1}")#text(". In particular, one can meaningfully talk about the degree of a function ")#mi("{f \\in \\ell^2(({\\bf Z}/2{\\bf Z})^n)}")#text(". Observe also that the Möbius function ")#mi("{\\mu}")#text(" from the preceding section is just the monomial ")#mi("{X_1 \\dots X_n}")#text(".")

#text("Define the ")#emph[#text("sensitivity")]#text(" ")#mi("{s(f)}")#text(" of a Boolean function ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(" to be the largest number for which there is an ")#mi("{x}")#text(" such that there are at least ")#mi("{s(f)}")#text(" values of ")#mi("{i = 1,\\dots,n}")#text(" with ")#mi("{f(x+e_i) \\neq f(x)}")#text(". Using an argument ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1178392")[#text("of Gotsman and Linial")]#text(", we can now relate the sensitivity of a function to its degree:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9 (Lower bound on sensitivity)")]#text(" ")#metadata(none) <tao-fd26db45a8b53034aa38>#text(" For any boolean function ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(", one has ")#mi("{s(f) \\geq \\sqrt{\\mathrm{deg}(f)}}")#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{m = \\mathrm{deg}(f)}")#text(". By permuting the indices, we may assume that ")#mi("{f}")#text(" contains a non-trivial multiple of the monomial ")#mi("{X_1 \\dots X_m}")#text(". By restricting to the subspace ")#mi("{({\\bf Z}/2{\\bf Z})^m \\times \\{0\\}^{n-m} \\equiv ({\\bf Z}/2{\\bf Z})^m}")#text(" (which cannot increase the sensitivity), we may then assume without loss of generality that ")#mi("{\\mathrm{deg}(f)=m=n}")#text(". The Fourier coefficient of ")#mi("{X_1 \\dots X_n}")#text(" is just the mean value")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2^n} \\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n} f(x) X_1 \\dots X_n = \\frac{1}{2^n} \\sum_{x \\in ({\\bf Z}/2{\\bf Z})^n} f(x) \\mu(x)")]]

#text("of ")#mi("{f}")#text(" times the Möbius function ")#mi("{\\mu}")#text(", so this mean value is non-zero. This means that one of the sets ")#mi("{\\{ \\mu(x) f(x) = +1\\}}")#text(" or ")#mi("{\\{\\mu(x) f(x)=-1\\}}")#text(" has cardinality at least ")#mi("{2^{n-1}+1}")#text(". Let ")#mi("{E}")#text(" denote the larger of these two sets. By Theorem ")#link(<tao-a6ed0e59c7903ee0c651>)[#text("1")]#text(", there is an ")#mi("{x \\in E}")#text(" such that ")#mi("{x + e_i \\in E}")#text(" for at least ")#mi("{\\sqrt{n}}")#text(" values of ")#mi("{i}")#text("; since ")#mi("{\\mu(x+e_i) = -\\mu(x)}")#text(", this implies that ")#mi("{f(x+e_i) \\neq f(x)}")#text(" for at least ")#mi("{\\sqrt{n}}")#text(" values of ")#mi("{i}")#text(", giving the claim. ")#mi("\\Box")

#text("The construction of Chung, Furedi, Graham, and Seymour from the previous section can be easily adapted to show that this lower bound is tight (other than the trivial improvement of replacing ")#mi("{\\sqrt{\\mathrm{deg}(f)}}")#text(" by ")#mi("{\\lceil \\sqrt{\\mathrm{deg}(f)} \\rceil}")#text(").")

#text("Now we need to digress on some bounds involving polynomials of one variable. We begin with an ")#link("https://en.wikipedia.org/wiki/Bernstein%27s_theorem_(polynomials)")[#text("inequality of Bernstein")]#text(" concerning trigonometric polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Bernstein inequality)")]#text(" Let ")#mi("{P(\\theta)}")#text(" be a trigonometric polynomial of degree at most ")#mi("{n}")#text(", that is to say a complex linear combination of ")#mi("{\\sin(k \\theta), \\cos(k \\theta)}")#text(" for ")#mi("{k=0,\\dots,n}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P^{\\prime}(\\theta)\\right| \\leq n \\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P(\\theta)\\right|.", block: true)]]
]

#text("Observe that equality holds when ")#mi("{P(\\theta)=\\sin(n\\theta)}")#text(" or ")#mi("{P(\\theta) = \\cos(n\\theta)}")#text(". Specialising to linear combinations of ")#mi("{e^{ik\\theta} = \\cos(k\\theta) + i \\sin(k \\theta)}")#text(", we obtain the classical Bernstein inequality")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\left|z\\right|=1} \\left|P^{\\prime}(z)\\right| \\leq n \\sup_{\\left|z\\right|=1} \\left|P(z)\\right|", block: true)]]

#text("for complex polynomials of degree at most ")#mi("{n}")#text(".")

#emph[#text("Proof:")]#text(" If one is willing to lose a constant factor in this estimate, this bound can be easily established from modern Littlewood-Paley theory (see e.g., Exercise 52 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("these lecture notes")]#text("). Here we use an interlacing argument ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=259429")[#text("due to Boas")]#text(". We first restrict to the case when ")#mi("{P}")#text(" has real coefficients. We may normalise ")#tao-math("{\\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P(\\theta)\\right| =1}", block: false)#text(". Let ")#mi("{\\lambda}")#text(" be a real parameter in ")#mi("{(-1,1)}")#text(". The trigonometric polynomial ")#mi("{\\cos(n\\theta)}")#text(" alternately takes the values ")#mi("{+1}")#text(" and ")#mi("{-1}")#text(" at the ")#mi("{2n}")#text(" values ")#mi("{\\frac{j\\pi}{n}, j=0,\\dots,2n-1}")#text(". Thus the trigonometric polynomial ")#mi("{\\cos(n\\theta) + \\lambda P(\\theta)}")#text(" alternates in sign at these values, and thus by the intermediate value theorem has a zero on each of the intervals ")#mi("{[\\frac{j\\pi}{n}, \\frac{(j+1)\\pi}{n}]}")#text(". On the other hand, a trigonometric polynomial ")#mi("{P(\\theta)}")#text(" of degree at most ")#mi("{n}")#text(" can be expressed by de Moivre’s theorem as ")#mi("{e^{-in\\theta}}")#text(" times a complex polynomial in ")#mi("{e^{i\\theta}}")#text(" of degree at most ")#mi("{2n}")#text(", and thus has at most ")#mi("{2n}")#text(" zeroes. Thus we see that ")#mi("{\\cos(n\\theta) + \\lambda P(\\theta)}")#text(" has exactly one zero in each ")#mi("{[\\frac{j\\pi}{n}, \\frac{(j+1)\\pi}{n}]}")#text(". Furthermore, at this zero, the derivative ")#mi("{-n \\sin(n \\theta) + \\lambda P^{\\prime}(\\theta)}")#text(" of this function must be positive if ")#mi("{\\cos(n\\theta)}")#text(" is increasing on this interval, and negative if ")#mi("{\\cos(n\\theta)}")#text(" is decreasing on this interval. In summary, we have shown that if ")#mi("{\\lambda \\in (-1,1)}")#text(" and ")#mi("{\\theta,\\alpha}")#text(" are such that ")#mi("{\\cos(n\\theta) + \\lambda P(\\theta)=0}")#text(", then ")#mi("{-n \\sin(n \\theta) + \\lambda P^{\\prime}(\\theta)}")#text(" has the same sign as ")#mi("{-n\\sin(n\\theta)}")#text(". By translating the function ")#mi("{\\cos(n\\theta)}")#text(", we also conclude that if ")#mi("{\\lambda \\in (-1,1)}")#text(" and ")#mi("{\\theta,\\alpha}")#text(" are such that ")#mi("{\\cos(n(\\theta+\\alpha)) + \\lambda P(\\theta)=0}")#text(" for some ")#mi("{\\alpha \\in {\\bf R}}")#text(", then ")#mi("{-n \\sin(n(\\theta+\\alpha)) + \\lambda P^{\\prime}(\\theta)}")#text(" has the same sign as ")#mi("{-n\\sin(n(\\theta+\\alpha))}")#text(".")

#text("If ")#mi("{\\lambda \\in (-1,1)}")#text(", then we can find ")#mi("{\\alpha}")#text(" such that ")#mi("{\\cos(n(\\theta+\\alpha)) + \\lambda P(\\theta)=0}")#text(" and ")#mi("{n\\sin(n(\\theta+\\alpha))}")#text(" is positive, and we conclude that ")#mi("{\\lambda P^{\\prime}(\\theta) < n \\sin(n(\\theta+\\alpha)) \\leq n}")#text("; thus we have the upper bound")

#align(center)[#tao-fit-display[#tao-math("P^{\\prime}(\\theta) \\leq n \\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P(\\theta)\\right|.", block: true)]]

#text("A similar argument (with ")#mi("{n \\sin(n(\\theta+\\alpha))}")#text(" now chosen to be negative) similarly bounds ")#mi("{-P^{\\prime}(\\theta)}")#text(". This gives the claim for real-valued trigonometric polynomials ")#mi("{P}")#text(". (Indeed, this argument even gives the slightly sharper bound ")#tao-math("{\\sup_{\\theta} \\frac{1}{n^2} \\left|P^{\\prime}(\\theta)\\right|^2 + \\left|P(\\theta)\\right|^2 = \\sup_{\\theta} \\left|P(\\theta)\\right|^2}", block: false)#text(".)")

#text("To ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" this to complex valued polynomials, we take advantage of phase rotation invariance. If ")#mi("{P}")#text(" is a complex trigonometric polynomial, then by applying Bernstein’s inequality to the real part ")#mi("{\\mathrm{Re} P}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|\\mathrm{Re} P^{\\prime}(\\theta)\\right| \\leq n \\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P(\\theta)\\right|.", block: true)]]

#text("But then we can multiply ")#mi("{P}")#text(" by any complex phase ")#mi("{e^{i\\alpha}}")#text(" and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|\\mathrm{Re} e^{i\\alpha} P^{\\prime}(\\theta)\\right| \\leq n \\sup_{\\theta \\in {\\bf R}/2\\pi {\\bf Z}} \\left|P(\\theta)\\right|.", block: true)]]

#text("Taking suprema in ")#mi("{\\alpha}")#text(", one obtains the claim for complex polynomials ")#mi("{P}")#text(". ")#mi("\\Box")

#text("The analogue of Bernstein’s inequality for the unit interval is known as ")#link("https://en.wikipedia.org/wiki/Markov_brothers%27_inequality")[#text("Markov’s inequality")]#text(" for polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Markov’s inequality for polynomials)")]#text(" Let ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a polynomial of degree ")#mi("{n}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in [-1,1]} \\left|P^{\\prime}(x)\\right| \\leq n^2 \\sup_{x \\in [-1,1]} \\left|P(x)\\right|.", block: true)]]
]

#text("This bound is sharp, as is seen by inspecting the ")#link("https://en.wikipedia.org/wiki/Chebyshev_polynomials")[#text("Chebyshev polynomial")]#text(" ")#mi("{T_n}")#text(", defined as the unique polynomial giving the trigonometric identity ")#metadata(none) <tao-64053ca7ee3fcd9c4a32>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("T_n(\\cos \\theta) := \\cos(n \\theta).")]]

#text("Differentiating ")#link(<tao-64053ca7ee3fcd9c4a32>)[#text("(6)")]#text(" using the chain rule, we see that ")#metadata(none) <tao-1b2ffa27d8046b022abb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("T^{\\prime}_n(\\cos \\theta) := n \\frac{\\sin(n \\theta)}{\\sin(\\theta)};")]]

#text("the right-hand side approaches ")#mi("{n^2}")#text(" as ")#mi("{\\theta \\rightarrow 0}")#text(", demonstrating that the ")#mi("{n^2}")#text(" factor here is sharp.")

#emph[#text("Proof:")]#text(" We again use an ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=259429")[#text("argument of Boas")]#text(". We may normalise so that ")#metadata(none) <tao-4304b34b5647ec1956ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sup_{x \\in [-1,1]} \\left|P(x)\\right| = 1.", block: true)]]

#text("The function ")#mi("{P(\\cos \\theta)}")#text(" is a trigonometric polynomial of degree at most ")#mi("{n}")#text(", so by Bernstein’s inequality and the chain rule we have ")#metadata(none) <tao-6c126e81fa8dc29d6413>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left|\\sin \\theta\\right| \\left|P^{\\prime}(\\cos \\theta)\\right| \\leq n", block: true)]]

#text("for all ")#mi("{\\theta}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|P^{\\prime}(x)\\right| \\leq \\frac{n}{\\sqrt{1-x^2}}", block: true)]]

#text("for all ")#mi("{x \\in [-1,1]}")#text(". This already gives Markov’s inequality except in the edge regions ")#tao-math("{\\left|x\\right| \\geq \\sqrt{1 - \\frac{1}{n^2}} \\geq \\cos \\frac{\\pi}{2n}}", block: false)#text(" (since ")#mi("{\\sin \\frac{\\pi}{2n} \\geq \\frac{1}{n} \\sin \\frac{\\pi}{2} = \\frac{1}{n}}")#text("). By reflection symmetry, it then suffices to verify Markov’s inequality in the region ")#mi("{\\cos \\frac{\\pi}{2n} \\leq x \\leq 1}")#text(".")

#text("From ")#link(<tao-64053ca7ee3fcd9c4a32>)[#text("(6)")]#text(", the Chebyshev polynomial ")#mi("{T_n}")#text(" attains the values ")#mi("{\\pm 1}")#text(" alternately at the ")#mi("{n+1}")#text(" different points ")#mi("{\\cos(\\frac{j\\pi}{n}), j=0,\\dots,n}")#text(". Thus, if ")#mi("{\\lambda \\in (-1,1)}")#text(", the polynomial ")#mi("{T_n(x)+\\lambda P(x)}")#text(" changes sign at least ")#mi("{n}")#text(" times on ")#mi("{[-1,1]}")#text(", and thus must have all ")#mi("{n}")#text(" zeroes inside this interval by the intermediate value theorem; furthermore, ")#mi("{n-1}")#text(" of these zeroes will lie to the left of ")#mi("{\\cos(\\frac{\\pi}{n})}")#text(". By Rolle’s theorem, the derivative ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(" then has all ")#mi("{n-1}")#text(" zeroes in the interval ")#mi("{[-1,1]}")#text(", and at least ")#mi("{n-2}")#text(" of these will lie to the left of ")#mi("{\\cos( \\frac{\\pi}{n} )}")#text(". In particular, the derivative ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(" can have at most one zero to once to the right of ")#mi("{\\cos(\\frac{\\pi}{2n} ) \\geq \\cos(\\frac{\\pi}{n})}")#text(".")

#text("Since ")#mi("{T_n(1)=1}")#text(", ")#mi("{T_n(x)+\\lambda P(x)}")#text(" is positive at ")#mi("{x=+1}")#text(", and hence positive as ")#mi("{x \\rightarrow \\infty}")#text(" since there are no zeroes outside of ")#mi("{[-1,1]}")#text(". Thus the leading coefficient of ")#mi("{T_n(x) + \\lambda P(x)}")#text(" is positive, which implies the same for its derivative ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(". Thus ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(" is positive when ")#mi("{x \\rightarrow \\infty}")#text(".")

#text("From ")#link(<tao-6c126e81fa8dc29d6413>)[#text("(9)")]#text(" one has ")#tao-math("{\\left|P^{\\prime}(\\cos(\\frac{\\pi}{2n}))\\right| \\leq \\frac{n}{\\sin(\\pi/2n)}}", block: false)#text(", hence by ")#link(<tao-1b2ffa27d8046b022abb>)[#text("(7)")]#text(" we see that ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(" is also positive at ")#mi("{x = \\cos(\\frac{\\pi}{2n})}")#text(". Thus ")#mi("{T^{\\prime}_n(x) + \\lambda P^{\\prime}(x)}")#text(" cannot become negative for ")#mi("{x > \\cos(\\frac{\\pi}{2n})}")#text(", as this would create at least two zeroes to the right of ")#mi("{\\cos(\\frac{\\pi}{2n})}")#text(". We conclude that in this region we have")

#align(center)[#tao-fit-display[#tao-math("\\left|P^{\\prime}(x)\\right| \\leq T^{\\prime}_n(x).", block: true)]]

#text("From ")#link(<tao-1b2ffa27d8046b022abb>)[#text("(7)")]#text(" we have ")#tao-math("{\\left|T^{\\prime}_n(x)\\right| \\leq n^2}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" The following slightly shorter argument gives the slightly weaker bound ")#tao-math("{\\sup_{x \\in [-1,1]} \\left|P^{\\prime}(x)\\right| \\leq n \\mathrm{cosec}(1/n) \\sup_{x \\in [-1,1]} \\left|P(x)\\right|}", block: false)#text(". We again use the normalisation ")#link(<tao-4304b34b5647ec1956ca>)[#text("(8)")]#text(". By two applications of Bernstein’s inequality, the function ")#mi("{\\theta \\mapsto P(\\cos(\\theta))}")#text(" has first derivative bounded in magnitude by ")#mi("{n}")#text(", and second derivative bounded in magnitude by ")#mi("{n^2}")#text(". As this function also has vanishing first derivative at ")#mi("{0}")#text(", we conclude the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{d}{d\\theta} P(\\cos \\theta)\\right| \\leq \\min( n^2 \\left|\\theta\\right|, n )", block: true)]]

#text("and thus by the chain rule")

#align(center)[#tao-fit-display[#tao-math("\\left|P(\\cos \\theta)\\right| \\leq \\min( n^2 \\left|\\theta\\right|, n ) \\mathrm{cosec}(\\theta).", block: true)]]

#text("For ")#tao-math("{\\left|\\theta\\right| \\leq \\pi}", block: false)#text(", one easily checks that the right-hand side is at most ")#mi("{n \\mathrm{cosec}(1/n)}")#text(", giving the claim.")
]

#text("This implies a result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=168972")[#text("of Ehlich-Zeller")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=204938")[#text("of Rivlin-Cheney")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Discretised Markov inequality)")]#text(" ")#metadata(none) <tao-6bf99799d0ef91be6c25>#text(" Let ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a polynomial of degree ")#mi("{d}")#text(". If ")#metadata(none) <tao-3bea44f95b17af14e750>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sup_{x \\in [0,n]} \\left|P^{\\prime}(j)\\right| > A \\sup_{j =0,\\dots,n} \\left|P(j)\\right|", block: true)]]

#text("then we have ")#mi("{d > \\sqrt{\\frac{An}{A+2}}}")#text(".")
]

#emph[#text("Proof:")]#text(" We use an argument of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1313531")[#text("Nisan and Szegedy")]#text(". Assume for sake of contradiction that ")#mi("{d \\leq \\sqrt{\\frac{An}{A+2}}}")#text(", so in particular ")#mi("{d < \\sqrt{n}}")#text(". From the fundamental theorem of calculus and the triangle inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in [0,n]} \\left|P(x)\\right| \\leq \\sup_{j =0,\\dots,n} \\left|P(j)\\right| + \\frac{1}{2} \\sup_{x \\in [0,n]} \\left|P^{\\prime}(x)\\right|.", block: true)]]

#text("By a rescaled and translated version of Markov’s inequality we have ")#metadata(none) <tao-1129e6f195d97e9ec38c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sup_{x \\in [0,n]} \\left|P^{\\prime}(x)\\right| \\leq \\frac{2d^2}{n} \\sup_{x \\in [0,n]} \\left|P(x)\\right|", block: true)]]

#text("which when inserted into the preceding inequality gives after some rearranging")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in [0,n]} \\left|P(x)\\right| \\leq (1 - \\frac{d^2}{n})^{-1} \\sup_{j =0,\\dots,n} \\left|P(j)\\right|", block: true)]]

#text("and then after a second application of ")#link(<tao-1129e6f195d97e9ec38c>)[#text("(11)")]#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in [0,n]} \\left|P^{\\prime}(x)\\right| \\leq \\frac{2d^2}{n} (1 - \\frac{d^2}{n})^{-1} \\sup_{j =0,\\dots,n} \\left|P(j)\\right|.", block: true)]]

#text("Comparing with ")#link(<tao-3bea44f95b17af14e750>)[#text("(10)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("A < \\frac{2d^2}{n} (1 - \\frac{d^2}{n})^{-1}")]]

#text("and the claim follows after some rearranging. ")#mi("\\Box")

#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1313531")[#text("Nisan and Szegedy observed")]#text(" that this one-dimensional degree bound can be lifted to the hypercube by a symmetrisation argument:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14 (Multidimensional Markov inequality bound)")]#text(" ")#metadata(none) <tao-65880b0e42d0c1b0a112>#text(" Let ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow [-1,1]}")#text(" be such that ")#mi("{f(0)=1}")#text(" and ")#mi("{f(e_i)=-1}")#text(" for ")#mi("{i=1,\\dots,n}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{deg}(f) \\geq \\sqrt{n/2}.")]]
]

#emph[#text("Proof:")]#text(" By averaging ")#mi("{f}")#text(" over all permutations of the indices (which can decrease the degree of ")#mi("{f}")#text(", but not increase it), we may assume that ")#mi("{f}")#text(" is a symmetric function of the inputs ")#mi("{x_1,\\dots,x_n}")#text(". Using the ")#link("https://en.wikipedia.org/wiki/Newton%27s_identities")[#text("Newton identities")]#text(", we can then write")

#align(center)[#tao-fit-display[#tao-math("f(x) = P(\\left|x\\right|)", block: true)]]

#text("for some real polynomial ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" of degree at most ")#mi("{\\mathrm{deg}(f)}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\left|x\\right| = \\# \\{ i =1,\\dots,n: x_i = 1 \\}", block: true)]]

#text("is the Hamming length of ")#mi("{x}")#text(". By hypothesis, ")#tao-math("{\\sup_{j = 0,\\dots,n} \\left|P(j)\\right| \\leq 1}", block: false)#text(", ")#mi("{P(0)=1}")#text(", and ")#mi("{P(1)=-1}")#text(", hence by the mean-value theorem ")#tao-math("{\\sup_{x \\in [0,n]} \\left|P^{\\prime}(x)\\right| \\geq 2}", block: false)#text(". Applying Corollary ")#link(<tao-6bf99799d0ef91be6c25>)[#text("13")]#text(" with ")#mi("{A=2}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Define the ")#emph[#text("block sensitivity")]#text(" ")#mi("{bs(f)}")#text(" of a Boolean function ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(" to be the largest number for which there is an ")#mi("{x}")#text(" such that there are at least ")#mi("{bs(f)}")#text(" disjoint subsets ")#mi("{I_1,\\dots,I_{bs(f)}}")#text(" of ")#mi("{\\{1,\\dots,n\\}}")#text(" with ")#mi("{f(x+\\sum_{i \\in I_j} e_i) \\neq f(x)}")#text(" for ")#mi("{j=1,\\dots,bs(f)}")#text(". We have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Sensitivity conjecture)")]#text(" ")#metadata(none) <tao-741e8c5450cd04daa226>#text(" One has")

#align(center)[#tao-fit-display[#mitex("s(f) \\leq bs(f) \\leq 2 s(f)^4.")]]
]

#text("More precisely, the sensitivity conjecture of Nisan and Szegedy asserted the bound ")#mi("{bs(f) = O( s(f)^{O(1)})}")#text("; Huang’s result thus gives explicit values for the exponents. It is still open whether the exponent ")#mi("{4}")#text(" in this theorem can be improved; it is known that one cannot improve it to below ")#mi("{2}")#text(", by analysing a variant of the Chung-Furedi-Graham-Seymour example (see ")#link("https://cse.buffalo.edu/~regan/cse705/wsensitivity.pdf")[#text("these notes of Regan")]#text(" for details). ")#emph[#text("Proof:")]#text(" The lower bound for ")#mi("{bs(f)}")#text(" is immediate from the definitions, since the sensitivity arises by restricting the ")#mi("{I_i}")#text(" in the definition of block sensitivity to singleton sets. To prove the upper bound, it suffices from Proposition ")#link(<tao-fd26db45a8b53034aa38>)[#text("9")]#text(" to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\mathrm{deg}(f) \\geq \\sqrt{bs(f)/2}.")]]

#text("Let ")#mi("{m = bs(f)}")#text(". By hypothesis, there are ")#mi("{x \\in ({\\bf Z}/2{\\bf Z})^n}")#text(" and ")#mi("{m}")#text(" disjoint subsets ")#mi("{I_1,\\dots,I_m}")#text(" of ")#mi("{\\{1,\\dots,n\\}}")#text(" such that ")#mi("{f(x+\\sum_{i \\in I_j} e_i) \\neq f(x)}")#text(" for ")#mi("{j=1,\\dots,m}")#text(". We may normalise ")#mi("{x=0}")#text(", ")#mi("{f(0)=1}")#text(" and ")#mi("{f(\\sum_{i\\in I_j}e_i)=-1}")#text(". If we then define the pullback boolean function ")#mi("{\\tilde f: ({\\bf Z}/2{\\bf Z})^m \\rightarrow \\{-1,1\\}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde f( y_1,\\dots,y_m) := f( \\sum_{j=1}^m y_j \\sum_{i \\in I_j} e_i )")]]

#text("then it is easy to see that ")#mi("{\\mathrm{deg}(\\tilde f) \\leq \\mathrm{deg}(f)}")#text(", ")#mi("{\\tilde f(0)=1}")#text(", and ")#mi("{\\tilde f(e_i)=-1}")#text(" for ")#mi("{i=1,\\dots,m}")#text(". The claim now follows from Corollary ")#link(<tao-65880b0e42d0c1b0a112>)[#text("14")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" The following slightly shorter variant of the argument lets one remove the factor ")#mi("{2}")#text(". Let ")#mi("{m, I_1,\\dots,I_m}")#text(" be as above. We again may normalise ")#mi("{f(0)=1}")#text(" and ")#mi("{f(\\sum_{i \\in I_j} e_i)=-1}")#text(". For any ")#mi("{\\theta}")#text(", let ")#mi("{\\xi_{\\theta,1},\\dots,\\xi_{\\theta,m} \\in \\{0,1\\}}")#text(" be iid Bernoulli random variable that equal ")#mi("{1}")#text(" with probability ")#mi("{\\sin^2 \\theta}")#text(" and ")#mi("{0}")#text(" with probability ")#mi("{\\cos^2 \\theta}")#text(". The quantity")

#align(center)[#tao-fit-display[#mitex("F(\\theta) := \\mathop{\\bf E} f( \\sum_{j=1}^m \\xi_{\\theta,i} \\sum_{i \\in I_j} e_i )")]]

#text("is a trigonometric polynomial of degree at most ")#mi("{2\\mathrm{deg}(f)}")#text(" that is bounded in magnitude by ")#mi("{1}")#text(", so by two applications of Bernstein’s inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|F^{\\prime\\prime}(0)\\right| \\leq 4 \\mathrm{deg}(f)^2.", block: true)]]

#text("On the other hand, for small ")#mi("{\\theta}")#text(", the random variable ")#mi("{\\sum_{j=1}^m \\xi_{\\theta,i} \\sum_{i \\in I_j} e_i}")#text(" is equal to zero with probability ")#mi("{1 - m \\theta^2 + O(\\theta^3)}")#text(" and equal to each ")#mi("{\\sum_{i \\in I_j} e_i}")#text(" with probability ")#mi("{\\theta^2 + O(\\theta^3)}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("F(\\theta) = 1 - 2m \\theta^2 + O(\\theta^3)")]]

#text("and hence ")#mi("{F^{\\prime\\prime}(0) = - 4m}")#text(". Combining these estimates we obtain ")#mi("{\\mathrm{deg}(f) \\geq \\sqrt{bs(f)}}")#text(" and hence ")#mi("{bs(f) \\leq s(f)^4}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" The sensitivity ")#mi("{s(f)}")#text(" of a Boolean function ")#mi("{f: ({\\bf Z}/2{\\bf Z})^n \\rightarrow \\{-1,1\\}}")#text(" can be split as ")#mi("{s(f) = \\max( s_{+1}(f), s_{-1}(f))}")#text(", where ")#mi("{s_c(f)}")#text(" is largest number for which there is an ")#mi("{x}")#text(" such that there are at least ")#mi("{s_c(f)}")#text(" values of ")#mi("{i = 1,\\dots,n}")#text(" with ")#mi("{f(x+e_i) \\neq f(x) = c}")#text(". It is not difficult to use the ")#mi("{k=2}")#text(" case of Remark ")#link(<tao-b5e906c79dfd3193762d>)[#text("3")]#text(" to improve Corollary ")#link(<tao-fd26db45a8b53034aa38>)[#text("9")]#text(" slightly to ")#mi("{s_{+1}(f) s_{-1}(f) \\geq \\mathrm{deg}(f)}")#text(". Combining this with the previous remark, we can thus improve the upper bound in Theorem ")#link(<tao-741e8c5450cd04daa226>)[#text("15")]#text(" slightly to")

#align(center)[#tao-fit-display[#mitex("bs(f) \\leq s_{+1}(f)^2 s_{-1}(f)^2.")]]
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (62)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0a852cb82bbc339a17724a4514eabb9ea858f52202810b4a9d8b7a4be44b93e-cb2d3ce6a655739dc0f76f2121f0e47ee51fd8b000035c2717c51f53e6ca8fd1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YI HAO")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518952")[#strong[#text("YI HAO")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("Impressive. Solving harder problems with lesser mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Bravo! More pride for UCLA")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Your “lesser mathematics” comment implies the use of simpler mathematical methods to prove conjectures or to solve problems. And I strongly agree with you…")

#text("Relevant Reference Link:")

#link("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")[#text("https://en.wikipedia.org/wiki/Hilbert%27s_twenty-fourth_problem")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518953")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("“…gave a of a long-standing problem…”")

#text("could be revised to (you forgot to add, “proof” above)")

#text("“…gave a proof of a long-standing problem” in your first statement above.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518954")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2019")])]

#text("This is more illuminating than the original proof. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519055")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Please don’t forget to add the illuminating questions/comments/explanations… of Prof. T. Tao, Prof. Huang and others too. We are very fortunate! Thank you very much! :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spectral proofs of theorems on the boolean hypercube | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518958")[#strong[#text("Spectral proofs of theorems on the boolean hypercube | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("[…] discussions on Huang’s proof of the sensitivity conjecture, see the following blog posts: Terry Tao, Gil Kalai, Scott Aaronson, Ken […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518960")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Interlacing methods in general have been used before, see for example this 1995 survey of Haemers: ")#link("https://www.sciencedirect.com/science/article/pii/0024379595001992")[#text("https://www.sciencedirect.com/science/article/pii/0024379595001992")]#text(", where it goes beyond the Cauchy interlacing inequalities.")

#text("Also, using a pseudo-adjacency matrices instead of just the adjacency matrix, was already used by Rick Wilson in his 1984 paper where he proved the general Erdős-Ko-Rado theorem:")#linebreak()#text(" ")#link("https://link.springer.com/article/10.1007/BF02579226")[#text("https://link.springer.com/article/10.1007/BF02579226")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c257ec4509388d8e9f186e1ef453458356a2f9940f80d4c20f997595b54d2353-40978253acb14b75f7c8c045398eedb0a7aa78e2b9b130ca8f0533bebd9d1797.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao Huang")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518962")[#strong[#text("Hao Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Terry: thanks for this great expository article! I have been following your amazing blog for 10+ years (well before taking your 254 sequence at UCLA), and it is certainly a great honor to see my name mentioned here:)")

#text("Let me try to give an alternative explanation of where the pseudo-adjacency matrix comes from, from a more combinatorial perspective. Recall that for the proof to work, the pseudo-adjacency matrix needs to have entries between -1 and 1, and its 2^{n-1}-th largest eigenvalue must be \\sqrt{n}. Hadamard’s inequality tells us that the determinant of such matrix is at most the product of the lengths of its row vectors, which is upper bounded by \\sqrt{n}^{2^{n-1}}. On the other hand, the constraint on the 2^{n-1}-th largest eigenvalue requires that all eigenvalues have absolute value at least \\sqrt{n}, since the hypercube is bipartite and its spectrum is symmetric about 0. Therefore the determinant, which is the product of eigenvalues, is at least \\sqrt{n}^{2^{n-1}}.")

#text("Now for the Hadamard inequality to be tight, the rows must be pairwise orthogonal. By decomposing the matrix into 2 by 2 blocks (each corresponding to a (n-1)-dimensional subcube), it is not hard to see that each (n-1)-cube also needs to have a good signing. And for example if we fix the signing of the top (n-1)-cube, and an arbitrary signing of the vertical perfect matching, then the signing of the bottom cube is fixed. When choosing all vertical edges to be positive, this is exactly the recursive construction in the paper.")

#text("I am quite interested to see that to what extent the same signing exists for other very symmetric graphs. Moreover, it seems that certain signing “compresses” the positive (negative) spectrum of the adjacency matrix, maybe this recursively constructed matrix is no more than composing a number of “compressing signing”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519031")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Dear Hao, what do you mean by the last sentence?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519053")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("I can take a stab at this. The unsigned adjacency matrix ")#mi("A")#text(" has a rather “spread out” spectrum; the ")#mi("2^n")#text(" eigenvalues are all the signed sums ")#mi("\\pm 1 \\pm 1 \\dots \\pm 1")#text(" of ")#mi("n")#text(" signs. These eigenvalues mostly cluster within a distance ")#mi("O(\\sqrt{n})")#text(" from the origin but the spectral radius is huge (equal to ")#mi("n")#text("). With the right signing of the matrix, however, the spectrum is “compressed” down to just ")#mi("+\\sqrt{n}")#text(" and ")#mi("-\\sqrt{n}")#text(", which is what is needed for this application – very roughly speaking, the ")#mi("n")#text(" signs ")#mi("\\pm 1")#text(" have somehow become “orthogonal” to each other (perhaps in some Clifford algebra sense) and hence their sums now always have “magnitude ")#mi("\\sqrt{n}")#text("” (by some sort of “Pythagorean theorem”). (Any symmetric signing of the matrix will preserve the first two moments, so this is the best compression of the spectral radius that one can hope for.) The compression is achieved by an iterative method in which the ")#mi("n^{th}")#text(" spectrally compressed matrix is constructed as a sort of skew tensor product of the ")#mi("(n-1)^{th}")#text(" matrix and an explicit ")#mi("2 \\times 2")#text(" matrix. So the proof can be ultimately boiled down to the properties of explicit ")#mi("2 \\times 2")#text(" matrices (another comment on this blog post reached a similar conclusion, where the ")#mi("2 \\times 2")#text(" matrices were Pauli matrices). This reminds me a bit of how hypercontractivity type inequalities can often be proven by iterating an elementary inequality involving a small number real variables (as few as two, in some cases), though in those cases the iteration is fairly straightforward and does not involve any “skewness”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("One can also interpret everything in terms of eigenvalues of sums of Hermitian matrices, a topic I am personally rather fond of :). If ")#mi("A_1,\\dots,A_n")#text(" are Hermitian matrices that each have eigenvalues in ")#mi("\\{-1,+1\\}")#text(", then the sum ")#mi("A_1+\\dots+A_n")#text(" can have eigenvalues anywhere in the interval between ")#mi("-n")#text(" and ")#mi("n")#text(" (though if one requires the ")#mi("A_i")#text(" to commute, then the eigenvalues have to be integers of the same parity as ")#mi("n")#text("). However, if one instead requires that the ")#mi("A_i")#text(" all ")#emph[#text("anticommute")]#text(", then the spectrum of the sum ")#mi("A_1+\\dots+A_n")#text(" has now been compressed into the set ")#mi("\\{-\\sqrt{n},\\sqrt{n}\\}")#text(", because this matrix now squares to ")#mi("n")#text(" times the identity matrix (one can interpret the anticommutator identity ")#mi("\\{A_i,A_j\\} := A_i A_j + A_j A_i = 0")#text(" as a sort of “orthogonality” between ")#mi("A_i")#text(" and ")#mi("A_j")#text("). This is the matrix analogue of the vector fact that the sum of ")#mi("n")#text(" unit vectors can have magnitude anywhere between ")#mi("0")#text(" and ")#mi("n")#text(" in general, but is forced to have magnitude ")#mi("\\sqrt{n}")#text(" if all the unit vectors are orthogonal to each other. So the game is all about weighting the graph to make the different edges anticommute with each other, which is what one sees in all the different interpretations of the argument appearing in this blog.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("If this is the matrix analogue for orthogonality, is it follows from a more general underlying matrix analogue for inner product?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519076")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("I think the role of the inner product here is played by the ")#link("http://mathworld.wolfram.com/Anticommutator.html")[#text("anticommutator")]#text(" ")#mi("\\{A,B\\} := AB+BA")#text(" of two Hermitian matrices ")#mi("A,B")#text(": it is symmetric, bilinear, and is “positive definite” in the sense that ")#mi("\\{A,A\\}")#text(" is positive definite when ")#mi("A")#text(" is non-zero. The one catch is that the anticommutator is matrix-valued rather than scalar valued. But it is related to the more usual scalar (")#link("https://en.wikipedia.org/wiki/Frobenius_inner_product")[#text("Frobenius")]#text(") inner product ")#mi("\\langle A, B \\rangle := \\mathrm{tr}(AB)")#text(" by the identity ")#mi("\\langle A, B \\rangle = \\frac{1}{2} \\mathrm{tr} \\{A,B\\}")#text(". This analogy helps explain why anticommutation seems to be a matrix analogue of orthogonality, which is a nice insight that I was not consciously aware of until looking at this recent work.")

#text("Another relationship between the anticommutator and the Frobenius inner product is the cyclic symmetry ")#mi("\\langle \\{ A, B \\}, C \\rangle = \\langle \\{ B, C\\}, A \\rangle")#text(" (and similarly for other permutations, since both the anticommutator and Frobenius inner product are symmetric). In particular, if ")#mi("A,B")#text(" anticommute, then not only are they orthogonal to each other in the Frobenius sense, but also ")#mi("A")#text(" is Frobenius orthogonal to ")#mi("\\{B,C\\}")#text(" (and ")#mi("B")#text(" is similarly Frobenius orthogonal to ")#mi("\\{A,C\\}")#text(") for any matrix ")#mi("C")#text(". So this is another way to connect anticommutation with orthogonality.")

#text("The analogy between anticommutators and inner products seems to break down a bit once one goes beyond the Hermitian setting though; one either has to abandon positive definiteness, or abandon (complex) bilinearity. But for real non-symmetric matrices one might possibly be able to work with ")#mi("AB^T + BA^T")#text(" as a substitute for the anticommutator.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20eb84fe8c7f52c3123cac3ff99f35068a5d8977c7b2d5d6c683fbd8de2dfea6-9d759619b5cbd7dc4ec6802db40d6bc382566196a0f78e6855b3b01fc0fd064d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519118")[#strong[#text("T")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("What operators preserve this inner product? Is there an analog of orthogonality here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("The anticommutator ")#mi("\\{A,B\\} = AB + BA")#text(" on Hermitian matrices is equivariant with respect to unitary conjugation: ")#mi("\\{ UAU^{-1}, UBU^{-1} \\} = U \\{A,B\\} U^{-1}")#text(". (Given that the anticommutator is matrix-valued rather than scalar-valued, equivariance is arguably a more natural notion of symmetry here than invariance.) I suspect these are basically the only (invertible) linear operations on Hermitian matrices that make the anticommutator equivariant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81441d4381138164831773df44c0ba0ef082fb910c9ceb25f661f68ca99a6c2c-feaf6a44fefae70bcdfdc0232b4811a36a5699a6efc0dd200bb179c2a41d1704.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519140")[#strong[#text("T")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("Coordinatization of some space?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36522f1d982e6aaf9911c21b59a531cbb335a13dc742d5ad8e5e7f70cdb73924-3c80298975e2ae4851b3075af6465d18f4da0e51a5fcdd6c891839135c01efe1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ferdinand Ihringer")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519045")[#strong[#text("Ferdinand Ihringer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Today this paper on the arXiv appeared [1] (by my old colleagues of the Discrete Math Group in Regina) which reminded me that there is a research area devoted towards the study of such weighted adjacency matrices. The are called multiplicity partitions and in this particular case it is an example for a multiplicity partition of the form [ 2^{n-1}, 2^{n-1} ] of the hypercube.")

#text("Now for the fun of it I was looking at some older results on this. It turns out that your matrix was already constructed in [2], Theorem 6.7 and Corollary 6.9, as an example for a graph with only two different eigenvalues. (The scaling is different to your matrix to keep the eigenvalues restricted to -1 and 1, but I guess that one can ignore this fact.)")

#text("[1] ")#link("https://arxiv.org/abs/1907.11328")[#text("https://arxiv.org/abs/1907.11328")]#linebreak()#text(" [2] ")#link("https://arxiv.org/abs/1304.1205")[#text("https://arxiv.org/abs/1304.1205")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Scott Aaronson noted in ")#link("https://www.scottaaronson.com/blog/?p=4229")[#text("his own blog post on this result")]#text(" that this argument was a great example of the empirical ")#mi("P \\neq NP")#text(" phenomenon in mathematical proofs, and now I think the case is even stronger; the result can now be deduced in a paragraph from existing results in the literature, using a method that was also already in the literature, but the task of ")#emph[#text("finding")]#text(" that short proof ")#emph[#text("ab nihilo")]#text(" was highly nontrivial!")

#text("Another example of this is ")#link("https://arxiv.org/abs/0803.2336")[#text("Dvir’s proof of the finite field Kakeya conjecture")]#text(". I’m still kicking myself for coming up with half of that proof six years earlier with a coauthor (see Proposition 8.1 of ")#link("https://arxiv.org/abs/math/0204234")[#text("this paper")]#text(") and completely failing to see that the conjecture could then be resolved with an additional paragraph of effort [amusingly, in both cases the “additional effort” consists of “a tiny bit of undergraduate linear algebra”]. Of course, this doesn’t detract at all from Dvir’s accomplishment, instead it is another example of the empirical ")#mi("P \\neq NP")#text(" phenomenon. Perhaps when attributing credit to a result, one has to make a distinction between the “NP-credit” (the credit one would assign based on the optimised argument from the literature that one can construct ")#emph[#text("after")]#text(" seeing a proof) for a result and the “P-credit” (the credit one would assign to each mathematician for their contribution in advancing the explicit state of knowledge on the problem [as opposed to what can be implicitly extrapolated from the total corpus of literature with the benefit of hindsight] closer to a solution (or pushing beyond a mere solution of the problem and gaining further insight and understanding around the problem and its connection with the rest of mathematics)).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd359611dcd2f86f898cdfd52fee6637d6538d54297cbbd90b1774a160e31800-4c896c27a793f80a4c9cceee939f6877733ec37331fd89d5198d894a4765dee5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519047")[#strong[#text("Bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("This is a bizarre conclusion. Is the analogy ‘the problem is encodable somehow with a boolean formula with n variables with say n=100 and we are are finding some version of satisfiability’ and if so did it take 2^(c.100) time?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd359611dcd2f86f898cdfd52fee6637d6538d54297cbbd90b1774a160e31800-4c896c27a793f80a4c9cceee939f6877733ec37331fd89d5198d894a4765dee5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519048")[#strong[#text("Bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Then the evidence is towards P=NP since apparently it did not take that long. He is probably the only a handful who persisted on this graph theoretic approach and that too for 5 years (and/but that too only for 5 years).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519050")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("I think the analogy is that it often appears more difficult to generate a correct solution than to check or justify or reformulate the solution with the benefit of hindsight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Pretty much, yes (though I would replace the exponential bound here with something more empirically realistic, such as a superpolynomial or even superquadratic bound). The proof already has been encoded into a ")#link("https://twitter.com/BooleanAnalysis/status/1145837576487612416")[#text("single tweet")]#text(", which is very roughly of the same order of difficulty as satisfying a boolean formula with ")#mi("n \\sim 100")#text(" variables, and can now be verified using results in the literature in less than an hour; yet, as you note, it took at least 5 years (=43800 hours) to locate this proof (actually a more accurate metric here would be the total amount of expert person-hours expended on the problem, which is more difficult to compute but similarly substantial, as Scott pointed out in his blog post).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd359611dcd2f86f898cdfd52fee6637d6538d54297cbbd90b1774a160e31800-4c896c27a793f80a4c9cceee939f6877733ec37331fd89d5198d894a4765dee5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519056")[#strong[#text("Bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Don’t know about expert man hours. None of the experts suggested graph theory approach even though the strategy was pointed by Nisan in Scott`s MO problem years back. More realistic might be an year of intense effort (about 5000 hours) and also checkable by whom is 1/2 half (again by experts). If at all the moral seems to be be stay convinced in your belief on the conjecture (whether conjecture was correct) and be lucky in your toolkit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Jones")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519061")[#strong[#text("Alex Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("I think this P vs NP distinction strengthens Timothy Gowers’s claim that computers can have a meaningful impact on generating new mathematical proofs. It seems very reasonable (to me) that a smart computer can get that ‘NP-credit’ that Terry commented about above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd359611dcd2f86f898cdfd52fee6637d6538d54297cbbd90b1774a160e31800-4c896c27a793f80a4c9cceee939f6877733ec37331fd89d5198d894a4765dee5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519086")[#strong[#text("Bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("FLT took 350 years. Assume 10 mathematicians each worked intensely 4000 hours everyday for 400 years then we have 16000000 person hours. 16000000/50 is roughly 300000. Would you agree 300000 bits is a reasonable measure to encode all of algebraic number theory, scheme theory, arithmetic geometry necessary to encode the proof of FLT notwithstanding the amount of essential information that was written down on these topics in 400 years? Just asking because it is tempting to understand the complexity of mathematics because it is one evidence shown in favor of P not NP inspite of the fact SAT has no evidence of being outside linear time as far as we know.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36522f1d982e6aaf9911c21b59a531cbb335a13dc742d5ad8e5e7f70cdb73924-3c80298975e2ae4851b3075af6465d18f4da0e51a5fcdd6c891839135c01efe1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ferdinand Ihringer")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519051")[#strong[#text("Ferdinand Ihringer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Recently, Hajime Tanaka and I slightly modified a proof by Frankl from the 1980s on the independence number of the orthogonality graph [1] (the vertices are the hypercube and adjacency is Hamming distance n/2). It is all about writing down the right matrix. Frankl took an argument by Delsarte and showed it for ")#mi("n = 4p^k")#text(", p an odd prime. Hajime and I added a divided by 2 into Frankl’s argument to cover p even.")

#text("I am sure that the complete solution will also be easy. Just that someone needs to find the right matrix and apply the right variation of one of the known rank arguments.")

#text("[1] ")#link("https://arxiv.org/abs/1901.04860")[#text("https://arxiv.org/abs/1901.04860")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("A reasonable “standard” measure for the complexity of a mathematical problem may be defined as a the smallest complexity (with respect to some fixed “standard” complexity measure) over all its possible proofs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-637075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2021")])]

#text("Deus ex machina")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518963")[#strong[#text("Huangs’ Breakthrough, Cvetković’s Bound, Godsil’s Question, and Sinkovic’s Answer | Ratio Bound – A Combinatorics Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")]

#text("[…] ” and everyone is blogging about it (only a small selection): Anurag Bishnoi, Gil Kalai, Terry Tao, Fedya Petrov. Here I am jumping on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518970")[#strong[#text("Amazing: Hao Huang Proved the Sensitivity Conjecture! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")]

#text("[…] and many other share: Huang’s new method is very very promising. July 27: A great expository post on WN (What’s new) where Terry Tao presents the proof and describe a connection with Clifford […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518981")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Very interesting… There are three formulae which give the “formula does not parse” error, and I have not been able to tell exactly why, since they look the same as other formulae which parse OK. I’ve tried both safari and chrome on iOS which give the same errors:")

#text("Section 1:")

#text("Then for any {J \\subset \\{1,\\dots,k\\}}, we have [the formula below doesn’t parse, maybe a missing }?]")

#text("\\displaystyle \\sum_{x \\in \\bigcap_{j \\in J} V_j} \\mu(x) = (-1)^{1_{n= \\sum_{j \\in J}|I_i|},")

#text("Remark 6:")

#text("Let {f \\in \\ell^2(E)} be the vector defined by setting [the formula below doesn’t parse, maybe a missing }?]")

#text("\\displaystyle f(x) := (-1)^{\\sum_{1 \\leq j < j' \\leq k} B( e_{i_j}, e_{i_{j'}} )")

#text("and further on")

#text("Since {B(e_{i_{j_0}}, e_{i_j}) = B(e_{i_j}, e_{i_{j_0}) + 1}, this simplifies using (3) as")

#text("The above doesn't parse either.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b851600b20fb42aac8415eb89b412d1c1e37007f81ed5ea05252162c80d3266-66f8341e6b8790342d10f81cfd6520976cf007f3d580bba966aa9a643f85a269.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518982")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("It is a pity that Oleksiy Klurman and Cosmin Pohoata are not receiving more credit since the method in Huang’s paper appeared first in a joint paper with them, ")#link("https://arxiv.org/abs/1812.05989")[#text("https://arxiv.org/abs/1812.05989")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518985")[#strong[#text("T")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("As Anurag mentioned in his comment, the use of pseudo-adjacency matrix is not new at all. The difficult step is to realize that it can be applied to this specific cube problem. You could also say that it is a pity that Wilson is not receiving more credit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518988")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("In this case the concerned are coauthors however the related paper does not appear as a reference in the celebrated proof paper. May be the author of the proof had a different path to realization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36522f1d982e6aaf9911c21b59a531cbb335a13dc742d5ad8e5e7f70cdb73924-3c80298975e2ae4851b3075af6465d18f4da0e51a5fcdd6c891839135c01efe1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ferdinand Ihringer")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519043")[#strong[#text("Ferdinand Ihringer")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Or Cvetkovic (if we want to find earliest written precedent). His PhD from 1971 already had it. There are other theses from the 1970s with similar observations (maybe Lovasz’s, Delsarte’s and Haemer’s are the ones which I know). These methods are also often rediscovered as they are not too complicated linear algebra.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b851600b20fb42aac8415eb89b412d1c1e37007f81ed5ea05252162c80d3266-66f8341e6b8790342d10f81cfd6520976cf007f3d580bba966aa9a643f85a269.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518986")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")])]

#text("Sure, but Wilson is retired whereas Oleksiy Klurman and Cosmin Pohoata are young mathematicians who are Huang’s coauthors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("grind up old mathematicians to feed the young")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518987")[#strong[#text("La conjetura de la sensibilidad ha sido demostrada - La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2019")]

#text("[…] Los interesados en los detalles de la demostración, que es fácil de entender si ya se conocía su enunciado, así como los conceptos de subgrafo inducido y autovalor, pueden disfrutarla en Hao Huang, «Induced subgraphs of hypercubes and a proof of the Sensitivity Conjecture,» arXiv:1907.00847 [math.CO] (01 Jul 2019). Una presentación divulgativa para matemáticos en Scott Aaronson, «Sensitivity Conjecture resolved,» Shtetl-Optimized, 02 Jul 2019; sobre la relación entre el grado y la sensibilidad recomiendo Lance Fortnow, «Degree and Sensitivity,» Computational Complexity, 11 Jul 2019; las consecuencias del nuevo teorema no han tardado en llegar, como R. J. Lipton, K. W. Regan, «Discrepancy Games and Sensitivity,» Gödel’s Lost Letter and P=NP, 25 Jul 2019; y Terence TaoTwisted convolution and the sensitivity conjecture,» What’s new, 26 Jul 2019. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ac3c76aa80d152ff714ebde7860c6f7faa34ec75003e82518a3612d564cfe22-1ebff00a84a42d109c55c13c09f479a57e6eaee2aac59060c8356b26585ebe2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gh")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518993")[#strong[#text("gh")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("I wonder if there is some “homology” involved. Namely, for ")#mi("SA")#text(" the standard adjacency matrix of the hypercube graph, ")#mi("SA^2")#text(" counts the paths of length 2 from vertex ")#mi("i")#text(" to vertex ")#mi("j")#text(", and hence ")#mi("SA^2_{ii} = n")#text(" because each vertex has n neighbors and ")#mi("SA^2_{ij}=2")#text(" because for ")#mi("i\\neq j")#text(" there are two paths (a square just as in the case (0,0) to (1,1).")#linebreak()#text(" Now the pseudo-adjacency matrix ")#mi("A")#text(" considered in the proof similarly has ")#mi("(A^2)_{ii} = n")#text(" (paths of length 2 returning to ")#mi("i")#text(" each contributing ")#mi("(\\pm 1)^2 = 1")#text(") and ")#mi("(A^2)_{ij}=0")#text(") because the contribution of the two paths from ")#mi("i")#text(" to ")#mi("j")#text(" now cancel each other out. So “the square spanned by ")#mi("i")#text(" and ")#mi("j")#text(" is filled in”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519003")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("I’ve added a new remark (Remark 6) in which the proof is reformulated without reference to a bilinear form ")#mi("B")#text(" or any arbitrary choice of signs, and the controlling matrix ")#mi("A_{Cl}")#text(" is now canonically defined using the Clifford algebra generated by ")#mi("v_1,\\dots,v_n")#text(" with the relations ")#mi("v_i^2 = 1, v_i v_j = -v_j v_i")#text(", which abstract the two properties that make the matrix ")#mi("A_{Cl}")#text(" square to ")#mi("n")#text(". (Basically, each edge ")#mi("\\{x,x+e_i\\}")#text(" is now weighted by a Clifford generator ")#mi("v_i")#text(", rather than by a sign ")#mi("\\pm 1")#text(".) This is in some sense the “universal” version of Huang’s argument. Perhaps these Clifford generators ")#mi("v_i")#text(" also have some homological interpretation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-518997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("This short proof seem to be “from the Book” !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519002")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("Shortly before Remark 6, there is ‘Conversely, if x not in bigcap…’ should be bigcup")#linebreak()#text(" Near the end of the proof of Corollary 10, there is eqreef{disco} should be eqref{disco} ; then in the displayed equation, ‘frac’ is spelled out; then a paragraph with just the letter b.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f7f245429786040bab910d040af71dcd754ff66c0c1e02810caa2f67291c05b-60777bb901483cddaae165fe8145af6a6b1b99174a69ed17e7bedad40be7b46f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519012")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("Most studies on spectral graph theory seem to be related to geometry (such as embedding type) and looking at Clifford algebra and related avatars there seems to be more essential reasoning in terms of purely geometric terms. Is there a way to look at things purely in geometric terms and interpret the result geometrically?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08e0085fa2b6ee141f712217afd54b8359ba4804db536f8e81ce282d70b6cb09-d2f600bf89c0b3fa7457923dc5692a473280b38b4675590c15ce1857c72f76dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr Sniady")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519014")[#strong[#text("Piotr Sniady")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2019")])]

#text("The explanation of Roman Karasev of the structure of the matrix ")#mi("\\tilde{A}")#text(" can be rephrased in a slightly more concrete language as follows.")

#text("It will be convenient to identify the square matrices of size ")#mi("2^n")#text(" with the tensor power of square matrices of size ")#mi("2")#text(".")

#text("Let ")#mi("\\sigma_1=\\begin{bmatrix} 0 & 1 \\\\ 1 & 0 \\end{bmatrix}")#text(" and ")#mi("\\sigma_3=\\begin{bmatrix}  1 & 0 \\\\  0 & -1 \\end{bmatrix}")#text(" be Pauli matrices and let ")#mi("I=\\begin{bmatrix}  1 & 0 \\\\  0 & 1 \\end{bmatrix}")#text(" be the identity matrix.")

#text("Now let")#linebreak()#text(" ")#mi("B_1 = \\sigma_1 \\otimes I \\otimes \\cdots \\otimes I")#text(",")#linebreak()#text(" ")#mi("B_2= \\sigma_3 \\otimes \\sigma_1 \\otimes I \\otimes \\cdots \\otimes I")#text(",")#linebreak()#text(" ")#mi("B_3= \\sigma_3 \\otimes \\sigma_3 \\otimes \\sigma_1 \\otimes I \\otimes \\cdots \\otimes I")#text(",")#linebreak()#text(" …")#linebreak()#text(" ")#mi("B_n= \\sigma_3 \\otimes \\cdots \\otimes \\sigma_3 \\otimes \\sigma_1")#text(";")#linebreak()#text(" (")#mi("B_i")#text(" contains exactly one factor ")#mi("\\sigma_1")#text(" on ")#mi("i")#text("-th position, all factors before it are equal to ")#mi("\\sigma_3")#text(" and all factors after it are equal to the identity matrix ")#mi("I")#text(").")

#text("Note that the matrices ")#mi("B_i")#text(" described above appear naturally in the context of quantum mechanics for the following reason: since Pauli matrices anticommute: ")#mi("\\sigma_1 \\sigma_3=- \\sigma_3 \\sigma_1")#text(", it follows that the matrices ")#mi("B_i")#text(" anticommute as well: ")#mi("B_i B_j = - B_j B_i")#text(" whenever ")#mi("i\\neq j")#text(". Also, ")#mi("(B_i)^2=I\\otimes \\cdots \\otimes I")#text(" is the identity matrix.")

#text("Luckily, we have that ")#mi("\\tilde{A}=B_1+\\cdots+B_n")#text(" is a (signed) adjacency matrix for the graph we are interested in.")

#text("From the anticommutation of the matrices ")#mi("B_i")#text(" it follows immediately that")#linebreak()#text(" ")#mi("\\tilde{A}^2=(B_1+\\cdots+B_n)^2= n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fiodr")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519028")[#strong[#text("Fiodr")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("I think ")#mi("\\sigma_1")#text(" and ")#mi("\\sigma_3")#text(" should be switched in the definition of ")#mi("B_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08e0085fa2b6ee141f712217afd54b8359ba4804db536f8e81ce282d70b6cb09-d2f600bf89c0b3fa7457923dc5692a473280b38b4675590c15ce1857c72f76dc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Piotr Sniady")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519029")[#strong[#text("Piotr Sniady")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Oops, you are right, thanks!")

#emph[#text("[I have now swapped ")#mi("\\sigma_1")#text(" and ")#mi("\\sigma_3")#text(" in the original comment – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MikeR")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519072")[#strong[#text("MikeR")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("This exposition by Wenjie Zheng is crystal clear. Not written at the same level, but definitely comprehensible.")

#link("http://www.zhengwenjie.net/huanghao/")[#text("http://www.zhengwenjie.net/huanghao/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519074")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("Simplicity is clear, wonderful, and essential! Thank you!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08f858ed6e4d1f02faf0a185bd951568a5186d1d5147a2eaf598752b882ebc98-fd39093e3a98f343783d35367163c32200bf888d7c24ff86d95ff22d614406a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karl Mahlburg")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519079")[#strong[#text("Karl Mahlburg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("Terry,")

#text("Thanks for an extremely informative post! Huang’s proof is extraordinarily clean and concise, but I also appreciate all of the background material that you have provided.")

#text("I believe that I noticed a few minor typos, which are listed below.")

#text("1. The fourth displayed equation in Section 1 should be")

#tao-math("\\displaystyle \\sum_{x \\in \\cap_{j \\in J} V_j} \\mu(x) = (1-1)^{n - \\sum_{j \\in J} \\left|I_j\\right|} = 1_{n = \\sum_{j \\in J} \\left|I_j\\right|}.", block: false)

#text("This follows from applying the third displayed equation.")

#text("2. Near the end of the proof of Lemma 11 is the statement: “From (9) one has ")#tao-math("\\left| P^{\\prime}(\\cos(\\frac{\\pi}{2n})) \\right| \\leq n", block: false)#text(".” However, I believe this should instead be")

#tao-math("\\displaystyle \\left| P^{\\prime}\\left(\\cos\\left(\\frac{\\pi}{2n}\\right)\\right) \\right| \\leq \\frac{n}{\\sin\\left(\\frac{\\pi}{2n}\\right)}.", block: false)

#text("The point is then that by (7)")

#mi("\\displaystyle T^{\\prime}_n\\left(\\cos\\frac{\\pi}{2n}\\right) = \\frac{n}{\\sin\\frac{\\pi}{2n}} \\cdot \\sin \\frac{\\pi}{2} = \\frac{n}{\\sin\\frac{\\pi}{2n}},")

#text("so in all ")#tao-math("\\left| P^{\\prime}\\left(\\cos\\frac{\\pi}{2n}\\right)\\right| \\leq T^{\\prime}_n \\left(\\cos\\frac{\\pi}{2n}\\right).", block: false)

#text("3. In the proof of Theorem 15, the sentence before the first displayed equation says “it suffices from (9)”. However, the link actually points to Corollary 9, which I believe is the correct reference.")

#text("4. Towards the end of Remark 16, there is the statement “and equal to each ")#mi("e_i")#text(" with probability ")#mi("\\theta^2 + O(\\theta^3)")#text("“. I think this should instead be “and equal to each ")#mi("\\sum_{i \\in I_j} e_i")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-519124")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("The relation with the Heisenberg group suggests there might be a reformulation in terms of symplectic capacities?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520056")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2019")])]

#text("Dear Mathematicians,")#linebreak()#text(" This goes to show that even Terrence Tao could be wrong, Hao Huang is a fraud and he copied my work I posted on research gate he is also concurrently wrong… in part, his answer is implied as wrong… Due to his misuse of the mechanisms involved. I would write it up if it didn’t make my stomach turn that somebody would just openly steal my shit or claim money over its false conception…It is not 2^(N-1)+1 it is 2^(n-1)-1 the minus is key and Terrance is probably the only other person on the earth beside the few of you that understands why…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f3cb24dfc41e5521953fbeb5714f17f0e515a6a80b3c9e252c48c9bc7251342-3b999398bd771087d0853b2699a8720dc241f8e8cf61203d814f8608ca57a6cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520122")[#strong[#text("bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2019")])]

#text("Highest upvoted comment truly bizarre.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f7e3b731b2d0763598d6afd68099d10d4ca4ba73656f597b8b05bf632c270be-b2358f95360f149cf0658f3ce2add483d0ea9e80b71fa7335c994d1c31e4b816.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bizarre.")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520248")[#strong[#text("bizarre.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Self-voting perhaps.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520193")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Thanks to you all lol my faith in humanity is restored…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520194")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("#ResearchGate me…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-520195")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2019")])]

#text("Because People have copied me in physics and engineering aswell…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c6a36407d4be468c0a8024beb25723d5c8c8caf75cb7b116d69955550ba9f2c-c7727639b732d46296836c835109404887e284338b2082ff5dce07cbb7997a98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zachary Kyle Knutson")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-529867")[#strong[#text("Zachary Kyle Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2019")])]

#text("Research my work those (Those who thumbed up Hao Huang cannot see) Research gate my work… I will sleep at night…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-637065")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2021")])]

#text("Terry, unless I am mistaken I think it may need to be explicitly remarked that twisted convolution with $\\mu$ is diagonalisable. I think this is so because the kernel $(-1)^{B(y,x-y)} \\mu(x-y)$ is symmetric, because of the particular choice of $B$ which has $B(e_i, e_i) = 0$. (I think you may be implicitly using this symmetry when you refer to using the Cauchy interlacing theorem.)")

#text("I’m not sure there is any reason to expect that twisted convolution by a function is diagonalisable in general, is there?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-637071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2021")])]

#text("Fair enough, twisted convolution need not be diagonalisable in general, but once one knows that the matrix squares to a constant multiple of the identity one gets diagonalisability at once from the Jordan normal form.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e3946a0c6e26b008ce27654a3c533ccd251ed1113a619c5fcea4244cc90b8db-5322f84d9e77049642945696154a90b808c9fad5901dd30686966bf47887395b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WP")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-678441")[#strong[#text("WP")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2023")])]

#text("I just realized a surprising fact that all the essential ingredients in Huang’s succinct beautiful proof seem already being contained in the marvlous work of Marcus & Spielman & Srivastava “Interlacing Families I: Bipartite Ramanujan Graphs of AllDegrees” (2015 Annals).")

#text("i) d-regular Ramanujan graph and Alon-Boppana bound")

#text("A d-regular graph is Ramanujan if all of its non-trivial eigenvalues’ absolute value no greater than 2*sqrt(d-1). The relationship between ‘d-regular’ and ‘sqrt(d)-eigenvalue’ reminds us of the relationship between ‘n-regular’ and ‘sqrt(n)-eigenvalue’ for the hypercube case 2^n in Sensitivity Conjecture.")

#text("Alon-Boppana (1986) proved every sufficiently large d-regular graph has a non-trivial eigenvalue with absolute value at least 2*sqrt(d-1)-epsilon, which is called Alon-Boppana bound. Bilu & Linial (2006) conjectured that every d-regular graph has a 2-lift in which all the new eigenvalues have absolute value at most 2*sqrt(d-1). Marcus & Spielman & Srivastava proved this conj in the bipartite case using their interlacing polynomial method.")

#text("ii) Pseudo-adjacency matrices and good Signing")

#text("The brilliant usage of pseudo-adjacency matrices in Huang’s proof is also somewhat natural from the viewpoint of 2-lift of graph. Given a graph G, Bilu & Linial firstly produce the double-cover of G, then for each pair of (parellel) edges leave on either side or makes them cross. For the resulting 2-lift of G, they create a signed adjacency matrix A_s, with -1 for crossing edges and +1 for parellel edges. Although Huang’s signing and MSS’s signing have different meanings, they both get the pseudo-adjacency matrices, which is key for the proof.")

#text("Huang built up the 2^n hypercube by duplicating two 2^(n-1) hypercube recursively. Marcus & Spielman & Srivastava built up larger Ramanujan graph by 2-lift operation recursively. Obviously a 2^n hypercube can be seen as a trivial 2-lift of a 2^(n-1) hypercube (adding extra 2^(n-1) vertical edges).")

#text("Huang purchased a good signing of the pseudo-adjacency matrix for the orthogonality of pseudo-adjacency matrix rows through a determinstic way by alernating the sign of matrix in every step. Marcus & Spielman & Srivastava purchased a good signing of the pseudo-adjacency matrix for boundness of the largest eigenvalue through a probabalistic way by considering all random 2-lift.")

#text("iii) interlacing polynomials")

#text("Marcus & Spielman & Srivastava proved the characteristic polynomials for all random 2-lift A_s / signings form an interlacing family which are interlaced by their sum polynomial, which is just the well-studied matching polynomial of the graph. The family always contain a polynomial whose largest root is at most the largest root of the matching polynomial.")

#text("Huang made use the Cauchy’s interlace theorem to show that all the characteristic polynomials of the principle submatrices of pseudo-adjacency matrix are interlaced by the characteristic polynomial of pseudo-adjacency matrix. Finally the pigeonhole principle finishes the job.")

#text("iv) Sum up")

#text("The Alon-Boppana bound reveals the natural ‘n-sqrt(n)’ relationship; the Bilu-Linial 2-lift operation introduces the key pseudo-adjacency matrices; the Marcus-Spielman-Srivastava interlacing polynomial method could be used to bound the eigenvalues of pseudo-adjacency matrices. Although the Marcus-Spielman-Srivastava’s approach is not off-the-shelf for tackling Sensitivity conjecture, Huang’s approach and Marcus-Spielman-Srivastava’s approach seem just like a twin!")

#text("Given all of these ingredients, it’s a surprise that the solution of Sensitivity Conjecture didn’t root from Marcus-Spielman-Srivastava interlacing polynomial methodolgy. It seems that Huang didn’t noticed MMS’s work. Subsequent discussions on several math blogs like Gil Kalai’s didn’t pay any attention to Marcus-Spielman-Srivastava’s paper.")

#text("Finally, sensitivity conjecture considers a very special n-regular graph with 2^n vertices. The 2^(n-1) even vertices induce an empty subgraph, but any subgraph with just one more vertex would have its maximum degree suddenly jump to sqrt(n). This phase-transition phenomenon is a pigeonhole-principle-phenomenon coming from the the highly structured structure of hypercube {0,1}^n. But from the viewpoint of graph theory (dealing with somewhat more general and flexible graphs), comparing with the concept of d-regular Ramanujan graph, hypercube is somewhat too limited and artificial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/26/twisted-convolution-and-the-sensitivity-conjecture/#comment-684809")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2024")])]

#text("Hao Huang link broken ")#link("https://blog.nus.edu.sg/huanghao/")[#text("https://blog.nus.edu.sg/huanghao/")]

#emph[#text("[Corrected, thanks -T]")]
]
