// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/
// Converted to Typst by tao2typ: "2026-10-14T07:16:58.937739+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The sunflower lemma via Shannon entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The sunflower lemma via Shannon entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 July 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/")[#text("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A family ")#mi("{A_1,\\dots,A_r}")#text(" of sets for some ")#mi("{r \\geq 1}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Sunflower_(mathematics)")[#text("sunflower")]#text(" if there is a ")#emph[#text("core set")]#text(" ")#mi("{A_0}")#text(" contained in each of the ")#mi("{A_i}")#text(" such that the ")#emph[#text("petal sets")]#text(" ")#mi("{A_i \\backslash A_0, i=1,\\dots,r}")#text(" are disjoint. If ")#mi("{k,r \\geq 1}")#text(", let ")#mi("{\\mathrm{Sun}(k,r)}")#text(" denote the smallest natural number with the property that any family of ")#mi("{\\mathrm{Sun}(k,r)}")#text(" distinct sets of cardinality at most ")#mi("{k}")#text(" contains ")#mi("{r}")#text(" distinct elements ")#mi("{A_1,\\dots,A_r}")#text(" that form a sunflower. The celebrated ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=111692")[#text("Erdös-Rado theorem")]#text(" asserts that ")#mi("{\\mathrm{Sun}(k,r)}")#text(" is finite; in fact Erdös and Rado gave the bounds ")#metadata(none) <tao-914ff41a2b1acf1c0f9c>#mi("\\displaystyle  (r-1)^k \\leq \\mathrm{Sun}(k,r) \\leq (r-1)^k k! + 1. \\ \\ \\ \\ \\ (1)")#text(" ")#text(" The ")#emph[#text("sunflower conjecture")]#text(" asserts in fact that the upper bound can be improved to ")#mi("{\\mathrm{Sun}(k,r) \\leq O(1)^k r^k}")#text(". This remains open at present despite much effort (including a ")#link("https://polymathprojects.org/tag/polymath10/")[#text("Polymath project")]#text("); after a long series of improvements to the upper bound, the best general bound known currently is ")#metadata(none) <tao-9818fd6f8448510d5d71>#mi("\\displaystyle  \\mathrm{Sun}(k,r) \\leq O( r \\log(kr) )^k \\ \\ \\ \\ \\ (2)")#text(" ")#text(" for all ")#mi("{k,r \\geq 2}")#text(", established in 2019 ")#link("https://arxiv.org/abs/1909.04774")[#text("by Rao")]#text(" (building upon a recent breakthrough a month previously ")#link("https://arxiv.org/abs/1908.08483")[#text("of Alweiss, Lovett, Wu, and Zhang")]#text("). Here we remove the easy cases ")#mi("{k=1}")#text(" or ")#mi("{r=1}")#text(" in order to make the logarithmic factor ")#mi("{\\log(kr)}")#text(" a little cleaner.")

#text("Rao’s argument used the Shannon noiseless coding theorem. It turns out that the argument can be arranged in the very slightly different language of Shannon entropy, and I would like to present it here. The argument proceeds by locating the core and petals of the sunflower separately (this strategy is also followed in Alweiss-Lovett-Wu-Zhang). In both cases the following definition will be key. In this post all random variables, such as random sets, will be understood to be discrete random variables taking values in a finite range. We always use boldface symbols to denote random variables, and non-boldface for deterministic quantities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Spread set)")]#text(" Let ")#mi("{R > 1}")#text(". A random set ")#mi("{{\\bf A}}")#text(" is said to be ")#mi("{R}")#text("-spread if one has")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb P}( S \\subset {\\bf A}) \\leq R^{-\\left|S\\right|}", block: true)]]

#text("for all sets ")#mi("{S}")#text(". A family ")#mi("{(A_i)_{i \\in I}}")#text(" of sets is said to be ")#mi("{R}")#text("-spread if ")#mi("{I}")#text(" is non-empty and the random variable ")#mi("{A_{\\bf i}}")#text(" is ")#mi("{R}")#text("-spread, where ")#mi("{{\\bf i}}")#text(" is drawn uniformly from ")#mi("{I}")#text(".")
]

#text("The core can then be selected greedily in such a way that the remainder of a family becomes spread:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Locating the core)")]#text(" ")#metadata(none) <tao-0d45f5fd462b8c70bffb>#text(" Let ")#mi("{(A_i)_{i \\in I}}")#text(" be a family of subsets of a finite set ")#mi("{X}")#text(", each of cardinality at most ")#mi("{k}")#text(", and let ")#mi("{R > 1}")#text(". Then there exists a “core” set ")#mi("{S_0}")#text(" of cardinality at most ")#mi("{k}")#text(" such that the set")

#metadata(none) <tao-fe51c16ce31cecca7193>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("J := \\{ i \\in I: S_0 \\subset A_i \\}")]]

#text("has cardinality at least ")#tao-math("{R^{-\\left|S_0\\right|} \\left|I\\right|}", block: false)#text(", and such that the family ")#mi("{(A_j \\backslash S_0)_{j \\in J}}")#text(" is ")#mi("{R}")#text("-spread. Furthermore, if ")#tao-math("{\\left|I\\right| > R^k}", block: false)#text(" and the ")#mi("{A_i}")#text(" are distinct, then ")#tao-math("{\\left|S_0\\right| < k}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We may assume ")#mi("{I}")#text(" is non-empty, as the claim is trivial otherwise. For any ")#mi("{S \\subset X}")#text(", define the quantity")

#align(center)[#tao-fit-display[#tao-math("Q(S) := R^{\\left|S\\right|} \\left|\\{ i \\in I: S \\subset A_i\\}\\right|,", block: true)]]

#text("and let ")#mi("{S_0}")#text(" be a subset of ")#mi("{X}")#text(" that maximizes ")#mi("{Q(S_0)}")#text(". Since ")#tao-math("{Q(\\emptyset) = \\left|I\\right| > 0}", block: false)#text(" and ")#mi("{Q(S)=0}")#text(" when ")#tao-math("{\\left|S\\right| >k}", block: false)#text(", we see that ")#tao-math("{0 \\leq \\left|S_0\\right| \\leq K}", block: false)#text(". If the ")#mi("{A_i}")#text(" are distinct and ")#tao-math("{\\left|I\\right| > R^k}", block: false)#text(", then we also have ")#tao-math("{Q(S) \\leq R^k < \\left|I\\right| = Q(\\emptyset)}", block: false)#text(" when ")#tao-math("{\\left|S\\right|=k}", block: false)#text(", thus in this case we have ")#tao-math("{\\left|S_0\\right| < k}", block: false)#text(".")

#text("Let ")#mi("{J}")#text(" be the set ")#link(<tao-fe51c16ce31cecca7193>)[#text("(3)")]#text(". Since ")#mi("{Q(S_0) \\geq Q(\\emptyset)>0}")#text(", ")#mi("{J}")#text(" is non-empty. It remains to check that the family ")#mi("{(A_j \\backslash S_0)_{j \\in J}}")#text(" is ")#mi("{R}")#text("-spread. But for any ")#mi("{S \\subset X}")#text(" and ")#mi("{{\\bf j}}")#text(" drawn uniformly at random from ")#mi("{J}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb P}( S \\subset A_{\\bf j} \\backslash S_0 ) = \\frac{\\left|\\{ i \\in I: S_0 \\cup S \\subset A_i\\}\\right|}{\\left|\\{ i \\in I: S_0 \\subset A_i\\}\\right|} = R^{\\left|S_0\\right|-\\left|S_0 \\cup S\\right|} \\frac{Q(S)}{Q(S_0)}.", block: true)]]

#text("Observe that ")#mi("{Q(S) \\leq Q(S_0)}")#text(", and the probability is only non-empty when ")#mi("{S, S_0}")#text(" are disjoint, so that ")#tao-math("{\\left|S_0\\right|-\\left|S_0 \\cup S\\right| = - \\left|S\\right|}", block: false)#text(". The claim follows. ")#mi("\\Box")

#text("In view of the above lemma, the bound ")#link(<tao-9818fd6f8448510d5d71>)[#text("(2)")]#text(" will then follow from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Locating the petals)")]#text(" ")#metadata(none) <tao-676f6df8830744330f2f>#text(" Let ")#mi("{r, k \\geq 2}")#text(" be natural numbers, and suppose that ")#mi("{R \\geq C r \\log(kr)}")#text(" for a sufficiently large constant ")#mi("{C}")#text(". Let ")#mi("{(A_i)_{i \\in I}}")#text(" be a finite family of subsets of a finite set ")#mi("{X}")#text(", each of cardinality at most ")#mi("{k}")#text(" which is ")#mi("{R}")#text("-spread. Then there exist ")#mi("{i_1,\\dots,i_r \\in I}")#text(" such that ")#mi("{A_{i_1},\\dots,A_{i_r}}")#text(" is disjoint.")
]

#text("Indeed, to prove ")#link(<tao-9818fd6f8448510d5d71>)[#text("(2)")]#text(", we assume that ")#mi("{(A_i)_{i \\in I}}")#text(" is a family of sets of cardinality greater than ")#mi("{R^k}")#text(" for some ")#mi("{R \\geq Cr \\log(kr)}")#text("; by discarding redundant elements and sets we may assume that ")#mi("{I}")#text(" is finite and that all the ")#mi("{A_i}")#text(" are contained in a common finite set ")#mi("{X}")#text(". Apply Lemma ")#link(<tao-0d45f5fd462b8c70bffb>)[#text("2")]#text(" to find a set ")#mi("{S_0 \\subset X}")#text(" of cardinality ")#tao-math("{\\left|S_0\\right| < k}", block: false)#text(" such that the family ")#mi("{(A_j \\backslash S_0)_{j \\in J}}")#text(" is ")#mi("{R}")#text("-spread. By Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(" we can find ")#mi("{j_1,\\dots,j_r \\in J}")#text(" such that ")#mi("{A_{j_1} \\backslash S_0,\\dots,A_{j_r} \\backslash S_0}")#text(" are disjoint; since these sets have cardinality ")#tao-math("{k - \\left|S_0\\right| > 0}", block: false)#text(", this implies that the ")#mi("{j_1,\\dots,j_r}")#text(" are distinct. Hence ")#mi("{A_{j_1},\\dots,A_{j_r}}")#text(" form a sunflower as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(" is easy to prove if we strengthen the condition on ")#mi("{R}")#text(" to ")#mi("{R > k(r-1)}")#text(". In this case, we have ")#mi("{\\mathop{\\bf P}_{i \\in I}( x \\in A_i) < 1/k(r-1)}")#text(" for every ")#mi("{x \\in X}")#text(", hence by the union bound we see that for any ")#mi("{i_1,\\dots,i_j \\in I}")#text(" with ")#mi("{j \\leq r-1}")#text(" there exists ")#mi("{i_{j+1} \\in I}")#text(" such that ")#mi("{A_{i_{j+1}}}")#text(" is disjoint from the set ")#mi("{A_{i_1} \\cup \\dots \\cup A_{i_j}}")#text(", which has cardinality at most ")#mi("{k(r-1)}")#text(". Iterating this, we obtain the conclusion of Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(" in this case. This recovers a bound of the form ")#mi("{\\mathrm{Sun}(k,r) \\leq (k(r-1))^k+1}")#text(", and by pursuing this idea a little further one can recover the original upper bound ")#link(<tao-914ff41a2b1acf1c0f9c>)[#text("(1)")]#text(" of Erdös and Rado.")
]

#text("It remains to prove Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(". In fact we can locate the petals one at a time, placing each petal inside a random set.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Locating a single petal)")]#text(" ")#metadata(none) <tao-2d9547ff25f3782844ba>#text(" Let the notation and hypotheses be as in Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(". Let ")#mi("{{\\bf V}}")#text(" be a random subset of ")#mi("{X}")#text(", such that each ")#mi("{x \\in X}")#text(" lies in ")#mi("{{\\bf V}}")#text(" with an independent probability of ")#mi("{1/r}")#text(". Then with probability greater than ")#mi("{1-1/r}")#text(", ")#mi("{{\\bf V}}")#text(" contains one of the ")#mi("{A_i}")#text(".")
]

#text("To see that Proposition ")#link(<tao-2d9547ff25f3782844ba>)[#text("5")]#text(" implies Proposition ")#link(<tao-676f6df8830744330f2f>)[#text("3")]#text(", we randomly partition ")#mi("{X}")#text(" into ")#mi("{{\\bf V}_1 \\cup \\dots \\cup {\\bf V}_r}")#text(" by placing each ")#mi("{x \\in X}")#text(" into one of the ")#mi("{{\\bf V}_j}")#text(", ")#mi("{j=1,\\dots,r}")#text(" chosen uniformly and independently at random. By Proposition ")#link(<tao-2d9547ff25f3782844ba>)[#text("5")]#text(" and the union bound, we see that with positive probability, it is simultaneously true for all ")#mi("{j=1,\\dots,r}")#text(" that each ")#mi("{{\\bf V}_j}")#text(" contains one of the ")#mi("{A_i}")#text(". Selecting one such ")#mi("{A_i}")#text(" for each ")#mi("{{\\bf V}_j}")#text(", we obtain the required disjoint petals.")

#text("We will prove Proposition ")#link(<tao-2d9547ff25f3782844ba>)[#text("5")]#text(" by gradually increasing the density of the random set and arranging the sets ")#mi("{A_i}")#text(" to get quickly absorbed by this random set. The key iteration step is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Refinement inequality)")]#text(" ")#metadata(none) <tao-382b44b866b3ee498fa2>#text(" Let ")#mi("{R > 1}")#text(" and ")#mi("{0 < \\delta < 1}")#text(". Let ")#mi("{{\\bf A}}")#text(" be a random subset of a finite set ")#mi("{X}")#text(" which is ")#mi("{R}")#text("-spread, and let ")#mi("{{\\bf V}}")#text(" be a random subset of ")#mi("{X}")#text(" independent of ")#mi("{{\\bf A}}")#text(", such that each ")#mi("{x \\in X}")#text(" lies in ")#mi("{{\\bf V}}")#text(" with an independent probability of ")#mi("{\\delta}")#text(". Then there exists another ")#mi("{R}")#text("-spread random subset ")#mi("{{\\bf A}^{\\prime}}")#text(" of ")#mi("{X}")#text(" whose support is contained in the support of ")#mi("{{\\bf A}}")#text(", such that ")#mi("{{\\bf A}^{\\prime} \\backslash {\\bf V} \\subset {\\bf A}}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|{\\bf A}^{\\prime} \\backslash {\\bf V}\\right| \\leq \\frac{5}{\\log(R\\delta)} {\\mathbb E} |{\\bf A}|.", block: true)]]
]

#text("Note that a direct application of the first moment method gives only the bound")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|{\\bf A} \\backslash {\\bf V}\\right| \\leq (1-\\delta) {\\mathbb E} \\left|{\\bf A}\\right|,", block: true)]]

#text("but the point is that by switching from ")#mi("{{\\bf A}}")#text(" to an equivalent ")#mi("{{\\bf A}^{\\prime}}")#text(" we can replace the ")#mi("{1-\\delta}")#text(" factor by a quantity significantly smaller than ")#mi("{1}")#text(".")

#text("One can iterate the above proposition, repeatedly replacing ")#mi("{{\\bf A}, X}")#text(" with ")#mi("{{\\bf A}^{\\prime} \\backslash {\\bf V}, X \\backslash {\\bf V}}")#text(" (noting that this preserves the ")#mi("{R}")#text("-spread nature of ")#mi("{{\\bf A}}")#text(") to conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Iterated refinement inequality)")]#text(" ")#metadata(none) <tao-1899cdabb06569546a16>#text(" Let ")#mi("{R > 1}")#text(", ")#mi("{0 < \\delta < 1}")#text(", and ")#mi("{m \\geq 1}")#text(". Let ")#mi("{{\\bf A}}")#text(" be a random subset of a finite set ")#mi("{X}")#text(" which is ")#mi("{R}")#text("-spread, and let ")#mi("{{\\bf V}}")#text(" be a random subset of ")#mi("{X}")#text(" independent of ")#mi("{{\\bf A}}")#text(", such that each ")#mi("{x \\in X}")#text(" lies in ")#mi("{{\\bf V}}")#text(" with an independent probability of ")#mi("{1-(1-\\delta)^m}")#text(". Then there exists another random subset ")#mi("{{\\bf A}^{\\prime}}")#text(" of ")#mi("{X}")#text(" with support contained in the support of ")#mi("{{\\bf A}}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|{\\bf A}^{\\prime} \\backslash {\\bf V}\\right| \\leq (\\frac{5}{\\log(R\\delta)})^m {\\mathbb E} |{\\bf A}|.", block: true)]]
]

#text("Now we can prove Proposition ")#link(<tao-2d9547ff25f3782844ba>)[#text("5")]#text(". Let ")#mi("{m}")#text(" be chosen shortly. Applying Corollary ")#link(<tao-1899cdabb06569546a16>)[#text("7")]#text(" with ")#mi("{{\\bf A}}")#text(" drawn uniformly at random from the ")#mi("{(A_i)_{i \\in I}}")#text(", and setting ")#mi("{1-(1-\\delta)^m = 1/r}")#text(", or equivalently ")#mi("{\\delta = 1 - (1 - 1/r)^{1/m}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|{\\bf A}^{\\prime} \\backslash {\\bf V}\\right| \\leq (\\frac{5}{\\log(R\\delta)})^m k.", block: true)]]

#text("In particular, if we set ")#mi("{m = \\lceil \\log kr \\rceil}")#text(", so that ")#mi("{\\delta \\sim \\frac{1}{r \\log kr}}")#text(", then by choice of ")#mi("{R}")#text(" we have ")#mi("{\\frac{5}{\\log(R\\delta)} < \\frac{1}{2}}")#text(", hence")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb E} \\left|{\\bf A}^{\\prime} \\backslash {\\bf V}\\right| < \\frac{1}{r}.", block: true)]]

#text("In particular with probability at least ")#mi("{1 - \\frac{1}{r}}")#text(", there must exist ")#mi("{A_i}")#text(" such that ")#tao-math("{\\left|A_i \\backslash {\\bf V}\\right| = 0}", block: false)#text(", giving the proposition.")

#text("It remains to establish Proposition ")#link(<tao-382b44b866b3ee498fa2>)[#text("6")]#text(". This is the difficult step, and requires a clever way to find the variant ")#mi("{{\\bf A}^{\\prime}}")#text(" of ")#mi("{{\\bf A}}")#text(" that has better containment properties in ")#mi("{{\\bf V}}")#text(" than ")#mi("{{\\bf A}}")#text(" does. The main trick is to make a conditional copy ")#mi("{({\\bf A}^{\\prime}, {\\bf V}^{\\prime})}")#text(" of ")#mi("{({\\bf A}, {\\bf V})}")#text(" that is conditionally independent of ")#mi("{({\\bf A}, {\\bf V})}")#text(" subject to the constraint ")#mi("{{\\bf A} \\cup {\\bf V} = {\\bf A}^{\\prime} \\cup {\\bf V}^{\\prime}}")#text(". The point here is that this constrant implies the inclusions ")#metadata(none) <tao-5d03b223a3dc65f59905>#mi("\\displaystyle  {\\bf A}^{\\prime} \\backslash {\\bf V} \\subset {\\bf A} \\cap {\\bf A}^{\\prime} \\subset {\\bf A} \\ \\ \\ \\ \\ (4)")#text(" ")#text(" and ")#metadata(none) <tao-c6c6093cc9b00aea4c42>#mi("\\displaystyle  {\\bf A}^{\\prime} \\backslash {\\bf A} \\subset {\\bf V}. \\ \\ \\ \\ \\ (5)")#text(" ")#text(" Because of the ")#mi("{R}")#text("-spread hypothesis, it is hard for ")#mi("{{\\bf A}}")#text(" to contain any fixed large set. If we could apply this observation in the contrapositive to ")#mi("{{\\bf A} \\cap {\\bf A}^{\\prime}}")#text(" we could hope to get a good upper bound on the size of ")#mi("{{\\bf A} \\cap {\\bf A}^{\\prime}}")#text(" and hence on ")#mi("{{\\bf A} \\backslash {\\bf V}}")#text(" thanks to ")#link(<tao-5d03b223a3dc65f59905>)[#text("(4)")]#text(". One can also hope to improve such an upper bound by also employing ")#link(<tao-c6c6093cc9b00aea4c42>)[#text("(5)")]#text(", since it is also hard for the random set ")#mi("{{\\bf V}}")#text(" to contain a fixed large set. There are however difficulties with implementing this approach due to the fact that the random sets ")#mi("{{\\bf A} \\cap {\\bf A}^{\\prime}, {\\bf A}^{\\prime} \\backslash {\\bf A}}")#text(" are coupled with ")#mi("{{\\bf A}, {\\bf V}}")#text(" in a moderately complicated fashion. In Rao’s argument a somewhat complicated encoding scheme was created to give information-theoretic control on these random variables; below the fold we accomplish a similar effect by using Shannon entropy inequalities in place of explicit encoding. A certain amount of information-theoretic sleight of hand is required to decouple certain random variables to the extent that the Shannon inequalities can be effectively applied. The argument bears some resemblance to the “entropy compression method” discussed in ")#link("https://terrytao.wordpress.com/2009/08/05/mosers-entropy-compression-argument/")[#text("this previous blog post")]#text("; there may be a way to more explicitly express the argument below in terms of that method. (There is also some kinship with the ")#link("http://math.mit.edu/~fox/paper-dependent-random-choice.pdf")[#text("method of dependent random choice")]#text(", which is used for instance to establish the Balog-Szemerédi-Gowers lemma, and was also translated into information theoretic language in ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/chapter_entropy.dvi")[#text("these unpublished notes of Van Vu and myself")]#text(".)")

#metadata(none) <tao-3ddee748085b7544cb76>

#heading(level: 1)[#strong[#text(" — 1. Shannon entropy — ")]]

#text("In this section we lay out all the tools from the theory of Shannon entropy that we will need.")

#text("Define an ")#emph[#text("empirical sequence")]#text(" for a random variable ")#mi("{{\\bf X}}")#text(" taking values in a discrete set ")#mi("{S}")#text(" to be a sequence ")#mi("{X_1,X_2,\\dots}")#text(" in ")#mi("{S}")#text(" such that the empirical samples of this sequence converge in distribution to ")#mi("{{\\bf X}}")#text(" in the sense that ")#metadata(none) <tao-1e0afa83c8f066fd3f94>#mi("\\displaystyle  {\\mathbb P}( X_{\\bf n} = X ) = {\\mathbb P}( {\\bf X} = X ) + o(1) \\ \\ \\ \\ \\ (6)")#text(" ")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{{\\bf n} = {\\bf n}_N}")#text(" is a uniform random variable drawn from ")#mi("{\\{1,\\dots,N\\}}")#text(", and ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(" (uniformly over other parameters independent of ")#mi("{N}")#text("). Every random variable ")#mi("{{\\bf X}}")#text(" has at least one empirical sequence; indeed, from the strong law of large numbers one can find such a sequence almost surely by taking an infinite number of independent trials of ")#mi("{{\\bf X}}")#text(".")

#text("If ")#mi("{{\\bf X}}")#text(" is a random variable taking values in some set ")#mi("{S}")#text(", its ")#emph[#text("Shannon entropy")]#text(" ")#mi("{{\\mathbb H}({\\bf X})}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf X}) := \\sum_{X \\in S} {\\mathbb P}( {\\bf X} = X ) \\log \\frac{1}{{\\mathbb P}({\\bf X} = X)}")]]

#text("with the convention ")#mi("{0 \\log \\frac{1}{0} = 0}")#text(", and using the base two logarithm throughout. We can condition the Shannon entropy to events ")#mi("{E}")#text(" of positive probability,")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf X}|E) := \\sum_{X \\in S} {\\mathbb P}( {\\bf X} = X |E) \\log \\frac{1}{{\\mathbb P}({\\bf X} = X|E)},")]]

#text("and condition the Shannon entropy to other random variables ")#mi("{{\\bf Y}}")#text(" taking values in a set ")#mi("{T}")#text(" by")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf X}|{\\bf Y}) := \\sum_{Y \\in T} {\\mathbb P}( {\\bf Y} = Y) {\\mathbb H}( {\\bf X} | {\\bf Y} = Y)")]]

#text("with the convention that the summand is zero if ")#mi("{{\\mathbb P}({\\bf Y} = Y) = 0}")#text(".")

#text("We record the following standard and easily verified facts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Basic Shannon inequalities)")]#text(" ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>#text(" Let ")#mi("{{\\bf X}, {\\bf Y}, {\\bf Z}}")#text(" be random variables.")

#list(
[#text("(i) (Monotonicity) If ")#mi("{{\\bf X}}")#text(" is a deterministic function ")#mi("{{\\bf X} = f({\\bf Y})}")#text(" of ")#mi("{{\\bf Y}}")#text(", then ")#mi("{0 \\leq {\\mathbb H}({\\bf X}) \\leq {\\mathbb H}({\\bf Y})}")#text(". More generally, if ")#mi("{{\\bf X}}")#text(" is a deterministic function ")#mi("{{\\bf X} = f({\\bf Y}, {\\bf Z})}")#text(" of ")#mi("{{\\bf Y}}")#text(" and ")#mi("{{\\bf Z}}")#text(", then ")#mi("{0 \\leq {\\mathbb H}({\\bf X}|{\\bf Z}) \\leq {\\mathbb H}({\\bf Y}|{\\bf Z})}")#text(". If ")#mi("{{\\bf Y}}")#text(" is a deterministic function of ")#mi("{{\\bf Z}}")#text(", then ")#mi("{{\\mathbb H}({\\bf X}|{\\bf Z}) \\leq {\\mathbb H}({\\bf X}|{\\bf Y})}")#text(".")],
[#text("(ii) (Subadditivity) One has ")#mi("{{\\mathbb H}({\\bf X}, {\\bf Y}) \\leq {\\mathbb H}({\\bf X})+{\\mathbb H}({\\bf Y})}")#text(", with equality iff ")#mi("{{\\bf X}}")#text(", ")#mi("{{\\bf Y}}")#text(" are independent. More generally, one has ")#mi("{{\\mathbb H}({\\bf X}, {\\bf Y}|{\\bf Z}) \\leq {\\mathbb H}({\\bf X}|{\\bf Z})+{\\mathbb H}({\\bf Y}|{\\bf Z})}")#text(", with equality iff ")#mi("{{\\bf X}}")#text(", ")#mi("{{\\bf Y}}")#text(" are conditionally independent with respect to ")#mi("{{\\bf Z}}")#text(".")],
[#text("(iii) (Chain rule) One has ")#mi("{{\\mathbb H}({\\bf X}, {\\bf Y}) = {\\mathbb H}({\\bf X}) + {\\mathbb H}({\\bf Y}|{\\bf X}) = {\\mathbb H}({\\bf Y}) + {\\mathbb H}({\\bf X}|{\\bf Y})}")#text(". More generally ")#mi("{{\\mathbb H}({\\bf X}, {\\bf Y}|{\\bf Z}) = {\\mathbb H}({\\bf X}|{\\bf Z}) + {\\mathbb H}({\\bf Y}|{\\bf X},{\\bf Z}) = {\\mathbb H}({\\bf Y}|{\\bf Z}) + {\\mathbb H}({\\bf X}|{\\bf Y},{\\bf Z})}")#text(". In particular ")#mi("{0 \\leq {\\mathbb H}({\\bf X}|{\\bf Y}) \\leq {\\mathbb H}({\\bf X})}")#text(", and ")#mi("{{\\mathbb H}({\\bf X}|{\\bf Y}) = {\\mathbb H}({\\bf X})}")#text(" iff ")#mi("{{\\bf X},{\\bf Y}}")#text(" are independent; similarly, ")#mi("{0 \\leq {\\mathbb H}({\\bf X}|{\\bf Y},{\\bf Z}) \\leq {\\mathbb H}({\\bf X}|{\\bf Z})}")#text(", and ")#mi("{{\\mathbb H}({\\bf X}|{\\bf Y},{\\bf Z}) = {\\mathbb H}({\\bf X}|{\\bf Z})}")#text(" iff ")#mi("{{\\bf X},{\\bf Y}}")#text(" are conditionally independent with respect to ")#mi("{{\\bf Z}}")#text(".")],
[#text("(iv) (Jensen’s inequality) If ")#mi("{{\\bf X}}")#text(" takes values in a finite set ")#mi("{S}")#text(" then ")#tao-math("{{\\mathbb H}({\\bf X}) \\leq \\log \\left|S\\right|}", block: false)#text(", with equality iff ")#mi("{{\\bf X}}")#text(" is uniformly distributed in ")#mi("{S}")#text(". More generally, if ")#mi("{{\\bf X}}")#text(" takes values in a set ")#mi("{S_{\\bf Y}}")#text(" that depends on ")#mi("{{\\bf Y}}")#text(", then ")#tao-math("{{\\mathbb H}({\\bf X}|{\\bf Y}) \\leq {\\mathbb E} \\log \\left|S_{\\bf Y}\\right|}", block: false)#text(", with equality iff ")#mi("{{\\bf X}}")#text(" is uniformly distributed in ")#mi("{S_{\\bf Y}}")#text(" after conditioning on ")#mi("{{\\bf Y}}")#text(".")],
[#text("(v) (Gibbs inequality) If ")#mi("{{\\bf X}, {\\bf Y}}")#text(" take values in the same finite set ")#mi("{S}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf X}) \\leq \\sum_{X \\in S} {\\mathbb P}({\\bf X} = X) \\log \\frac{1}{{\\mathbb P}({\\bf Y}=X)}")]]

#text("(we permit the right-hand side to be infinite, which makes the inequality vacuously true).")]
)
]

#text("See ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("this previous blog post")]#text(" for some intuitive analogies to understand Shannon entropy.")

#text("Now we establish some inequalities of relevance to random sets.")

#text("We first observe that any small random set largely determines any of its subsets. Define a ")#emph[#text("random subset")]#text(" of a random set ")#mi("{{\\bf B}}")#text(" to be a random set ")#mi("{{\\bf A}}")#text(" such that ")#mi("{{\\bf B} \\subset {\\bf A}}")#text(" holds almost surely.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Subsets of small sets have small conditional entropy)")]#text(" ")#metadata(none) <tao-81db8ebbbbc69c6c6ad4>#text(" Let ")#mi("{{\\bf B}}")#text(" be a random finite set.")

#list(
[#text("(i) One has ")#tao-math("{{\\mathbb H}({\\bf A}|{\\bf B}) \\leq {\\mathbb E} \\left|{\\bf B}\\right|}", block: false)#text(" for any random subset ")#mi("{{\\bf A}}")#text(" of ")#mi("{{\\bf B}}")#text(".")],
[#text("(ii) One has ")#tao-math("{{\\mathbb H}( \\left|{\\bf B}\\right| ) \\leq 1+{\\mathbb E} \\left|{\\bf B}\\right|}", block: false)#text(". If ")#mi("{{\\bf B}}")#text(" is almost surely non-empty, we can improve this to ")#tao-math("{{\\mathbb H}( \\left|{\\bf B}\\right| ) \\leq {\\mathbb E} \\left|{\\bf B}\\right|}", block: false)#text(".")]
)
]

#emph[#text("Proof:")]#text(" The set ")#mi("{{\\bf A}}")#text(" takes values in the power set ")#mi("{2^{{\\bf B}}}")#text(" of ")#mi("{{\\bf B}}")#text(", so the claim (i) follows from Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(iv). (Note how it is convenient here that we are using the base ")#mi("{2}")#text(" for the logarithm.)")

#text("For (ii), apply Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(v) with ")#tao-math("{{\\bf X} = \\left|{\\bf B}\\right|}", block: false)#text(" and ")#mi("{{\\bf Y}}")#text(" the geometric random variable ")#mi("{{\\mathbb P}({\\bf Y} = n) = 2^{-n-1}}")#text(" for natural numbers ")#mi("{n}")#text(" (or ")#mi("{{\\mathbb P}({\\bf Y} = n) = 2^{-n}}")#text(" for positive ")#mi("{n}")#text(", if ")#mi("{{\\bf B}}")#text(" is non-empty). ")#mi("\\Box")

#text("Now we encode the property of a random variable ")#mi("{{\\bf A}}")#text(" being ")#mi("{R}")#text("-spread in the language of Shannon entropy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Information-theoretic interpretation of spread)")]#text(" ")#metadata(none) <tao-909802b269dee093387e>#text(" Let ")#mi("{{\\bf A}}")#text(" be a random finite set that is ")#mi("{R}")#text("-spread for some ")#mi("{R \\geq 1}")#text(".")

#list(
[#text("(i) If ")#mi("{{\\bf A}}")#text(" is uniformly distributed amongst some finite collection ")#mi("{{\\mathcal A}}")#text(" of sets, then")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf A} | {\\bf S} ) \\leq {\\mathbb H}({\\bf A}) - (\\log R) {\\mathbb E} \\left|{\\bf S}\\right|", block: true)]]

#text("for all random subsets ")#mi("{{\\bf S}}")#text(" of ")#mi("{{\\bf A}}")#text(".")],
[#text("(ii) In the general case, if ")#mi("{A_1, A_2, A_3,\\dots}")#text(" are an empirical sequence of ")#mi("{{\\bf A}}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf n} | {\\bf S} ) \\leq {\\mathbb H}({\\bf n}) - (\\log R) {\\mathbb E} \\left|{\\bf S}\\right| - o(1)", block: true)]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{{\\bf n}}")#text(" is drawn uniformly from ")#mi("{\\{1,\\dots,N\\}}")#text(" and ")#mi("{{\\bf S}}")#text(" is a random subset of ")#mi("{A_{\\bf n}}")#text(".")]
)
]

#text("Informally: large random subsets of an ")#mi("{R}")#text("-spread set ")#mi("{{\\bf A}}")#text(" necessarily have a lot of ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]#text(" with ")#mi("{{\\bf A}}")#text(". Conversely, one can bound the size of a random subset of an ")#mi("{R}")#text("-spread set by bounding its mutual information with ")#mi("{{\\bf A}}")#text(".")

#emph[#text("Proof:")]#text(" In case (i), it suffices by Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(iv) to establish the bound")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf A} | {\\bf S} = S ) \\leq \\log \\left|{\\mathcal A}\\right| - (\\log R) {\\mathbb E} \\left|S\\right|", block: true)]]

#text("for each finite set ")#mi("{S}")#text(" in the range of ")#mi("{{\\bf S}}")#text(". But as ")#mi("{{\\bf A}}")#text(" is ")#mi("{R}")#text("-spread and uniformly distributed in ")#mi("{{\\mathcal A}}")#text(", there are at most ")#tao-math("{R^{-S} \\left|{\\mathcal A}\\right|}", block: false)#text(" elements of ")#mi("{{\\mathcal A}}")#text(" that contain ")#mi("{S}")#text(", and the claim follows from a second appeal to Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(iv). Case (ii) follows from case (i) thanks to ")#link(<tao-1e0afa83c8f066fd3f94>)[#text("(6)")]#text(". ")#mi("\\Box")

#text("Given a finite non-empty set ")#mi("{X}")#text(" and ")#tao-math("{0 \\leq k \\leq \\left|X\\right|}", block: false)#text(", let ")#mi("{\\binom{X}{k}}")#text(" denote the collection of ")#mi("{k}")#text("-element subsets of ")#mi("{X}")#text(". A uniformly chosen element ")#mi("{{\\bf V}}")#text(" of ")#mi("{\\binom{X}{k}}")#text(" is thus a random ")#mi("{k}")#text("-element subset of ")#mi("{X}")#text("; we refer to the quantity ")#tao-math("{\\delta = k/\\left|X\\right|}", block: false)#text(" as the ")#emph[#text("density")]#text(" of this random subset, and ")#mi("{{\\bf V}}")#text(" as a ")#emph[#text("uniformly chosen random subset of ")#mi("{X}")#text(" of density ")#mi("{\\delta}")]#text(". (Of course, this is only defined when ")#mi("{0 \\leq \\delta \\leq X}")#text(" is an integer multiple of ")#tao-math("{1/\\left|X\\right|}", block: false)#text(".) Uniformly chosen random sets have the following information-theoretic relationships to small random sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-22b090dd46c756d3c307>#text(" Let ")#mi("{X}")#text(" be a finite non-empty set, let ")#mi("{{\\bf W}}")#text(" be a uniformly chosen random subset of ")#mi("{X}")#text(" of some density ")#mi("{0 \\leq \\delta \\leq 1}")#text(" (which is a multiple of ")#tao-math("{1/\\left|X\\right|}", block: false)#text(").")

#list(
[#text("(i) (Spread) If ")#mi("{{\\bf S}}")#text(" is a random subset of ")#mi("{{\\bf W}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf W} | {\\bf S} ) \\leq {\\mathbb H}({\\bf W}) - (\\log \\frac{1}{\\delta}) {\\mathbb E} |{\\bf S}|.")]]],
[#text("(ii) (Absorption) If ")#mi("{{\\bf S}}")#text(" is a random subset of ")#mi("{X}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf W} \\cup {\\bf S} ) \\leq {\\mathbb H}({\\bf W}) + 1 + (1+\\log \\frac{1}{\\delta}) {\\mathbb E} |{\\bf S}|.")]]]
)
]

#emph[#text("Proof:")]#text(" To prove (i), it suffices by Lemma ")#link(<tao-909802b269dee093387e>)[#text("10")]#text("(i) to show that ")#mi("{{\\bf W}}")#text(" is ")#mi("{\\frac{1}{\\delta}}")#text("-spread, which amounts to showing that")

#align(center)[#tao-fit-display[#tao-math("\\binom{\\left|X \\backslash S\\right|}{\\delta\\left|X\\right| - \\left|S\\right|} \\leq \\delta^{\\left|S\\right|} \\binom{\\left|X\\right|}{\\delta \\left|X\\right|}", block: true)]]

#text("for all subsets ")#mi("{S \\subset X}")#text(" with ")#tao-math("{0 \\leq \\left|S\\right| \\leq \\delta \\left|X\\right|}", block: false)#text(". But this comes from multiplying together the inequalities ")#tao-math("{\\frac{\\delta \\left|X\\right|-i}{\\left|X\\right|-i} \\leq \\delta}", block: false)#text(" for ")#tao-math("{0 \\leq i < \\left|S\\right|}", block: false)#text(".")

#text("For (ii), by replacing ")#mi("{{\\bf S}}")#text(" with ")#mi("{{\\bf S} \\backslash {\\bf W}}")#text(" we may assume that ")#mi("{{\\bf S}, {\\bf W}}")#text(" are disjoint. From Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(iii) and Lemma ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("9")]#text("(ii) it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf W} \\cup {\\bf S} | \\left|{\\bf S}\\right| ) \\leq {\\mathbb H}({\\bf W}) + \\log \\frac{1}{\\delta} {\\mathbb E} \\left|{\\bf S}\\right|", block: true)]]

#text("which in turn is implied by")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf W} \\cup {\\bf S} | \\left|{\\bf S}\\right| = k ) \\leq {\\mathbb H}({\\bf W}) + \\log \\frac{1}{\\delta} k", block: true)]]

#text("for each ")#tao-math("{0 \\leq k \\leq \\left|X\\right| - \\delta \\left|X\\right|}", block: false)#text(". By Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(iv) it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\binom{\\left|X\\right|}{\\delta \\left|X\\right|+k} \\leq \\delta^{-k} \\binom{\\left|X\\right|}{\\delta \\left|X\\right|}", block: true)]]

#text("but this follows from multiplying together the inequalities ")#tao-math("{\\frac{X+i}{\\delta \\left|X\\right|+i}\\leq \\frac{1}{\\delta}}", block: false)#text(" for ")#mi("{1 \\leq i \\leq k}")#text(". ")#mi("\\Box")

#text("The following “relative product” construction will be important for us. Given a random variable ")#mi("{{\\bf X}}")#text(" and a deterministic function ")#mi("{f({\\bf X})}")#text(" of that variable, one can construct a conditionally independent copy ")#mi("{{\\bf X}^{\\prime}}")#text(" of ")#mi("{{\\bf X}}")#text(" subject to the condition ")#mi("{f({\\bf X})=f({\\bf X}^{\\prime})}")#text(", with the joint distribution")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}( ({\\bf X}, {\\bf X}^{\\prime}) = (X,X^{\\prime}) ) = 1_{f(X)=f(X^{\\prime})} {\\mathbb P}( f({\\bf X}) = f(X) ) {\\mathbb P}( {\\bf X} = X | f({\\bf X}) = f(X) ) {\\mathbb P}( {\\bf X} = X^{\\prime} | f({\\bf X}) = f(X) ).")]]

#text("(Note that this is usually ")#emph[#text("not")]#text(" the same as starting with a completely independent copy ")#mi("{{\\bf X}^{\\prime}}")#text(" of ")#mi("{{\\bf X}}")#text(" and then conditioning to the event ")#mi("{f({\\bf X}) = f({\\bf X}^{\\prime})}")#text("; cf. ")#link("https://en.wikipedia.org/wiki/Simpson%27s_paradox")[#text("Simpson’s paradox")]#text(".) By construction, ")#mi("{{\\bf X}^{\\prime}}")#text(" has the same distribution as ")#mi("{{\\bf X}}")#text(", and is conditionally independent of ")#mi("{{\\bf X}}")#text(" relative to ")#mi("{{\\bf X}^{\\prime}}")#text(". In particular, from Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text(" we have")

#metadata(none) <tao-62846fbd68c1b929cce1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\mathbb H}( {\\bf X} | {\\bf X}^{\\prime} ) = {\\mathbb H}( {\\bf X} | f({\\bf X}) ) = {\\mathbb H}({\\bf X}) - {\\mathbb H}(f({\\bf X}))")]]

#text("which we can also write as a “entropy Cauchy-Schwarz identity”")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}({\\bf X}, {\\bf X}^{\\prime} ) = 2 {\\mathbb H}({\\bf X}) - {\\mathbb H}(f({\\bf X})).")]]

#text("This can be compared with the combinatorial inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ (x,x^{\\prime}) \\in X^2: f(x)=f(x^{\\prime}) \\}\\right| \\geq \\frac{\\left|X\\right|^2}{\\left|f(X)\\right|}", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|\\{ (x,x^{\\prime}) \\in X^2: f(x)=f(x^{\\prime}) \\}\\right| \\geq 2 \\log \\left|X\\right| - \\log \\left|f(X)\\right|", block: true)]]

#text("whenever ")#mi("{f: X \\rightarrow Y}")#text(" is a function on a non-empty finite set ")#mi("{X}")#text(", which is easily proven as a consequence of Cauchy-Schwarz. One nice advantage of the entropy formalism over the combinatorial one is that the analogue of this instance of the Cauchy-Schwarz inequality automatically becomes an equality (this is related to the ")#link("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")[#text("asymptotic equipartition property")]#text(" in the microstates interpretation of entropy).")

#heading(level: 1)[#strong[#text(" — 2. Proof of refinement inequality — ")]]

#text("Now we have enough tools to prove Proposition ")#link(<tao-382b44b866b3ee498fa2>)[#text("6")]#text(". Let ")#mi("{R, \\delta, {\\bf A}, {\\bf V}}")#text(" be as in that proposition. If ")#mi("{\\emptyset}")#text(" is in the support of ")#mi("{{\\bf A}}")#text(" we can set ")#mi("{{\\bf A}^{\\prime} = \\emptyset}")#text(" so we can instead assume that ")#mi("{{\\bf A}}")#text(" is never empty. In particular ")#metadata(none) <tao-8545f46d0c3a6cb00932>#tao-math("\\displaystyle  {\\mathbb E} \\left|{\\bf A}\\right| \\geq 1. \\ \\ \\ \\ \\ (8)", block: false)

#text("In order to use Lemma ")#link(<tao-909802b269dee093387e>)[#text("10")]#text(" we fix an empirical sequence ")#mi("{A_1,A_2,\\dots}")#text(" for ")#mi("{{\\bf A}}")#text(". We relabel ")#mi("{X}")#text(" as ")#tao-math("{\\{1,\\dots,\\left|X\\right|\\}}", block: false)#text(", and let ")#tao-math("{N \\geq \\left|X\\right|}", block: false)#text(" be a parameter going off to infinity (so in particular ")#mi("{X}")#text(" is identified with a subset of ")#mi("{\\{1,\\dots,N\\}}")#text(". We let ")#mi("{{\\bf n}}")#text(" be drawn uniformly at random from ")#mi("{\\{1,\\dots,N\\}}")#text(", and let ")#mi("{{\\bf W}}")#text(" be a uniform random subset of ")#mi("{\\{1,\\dots,N\\}}")#text(" of density ")#mi("{\\lfloor \\delta N\\rfloor/N = \\delta + o(1)}")#text(" independent of ")#mi("{{\\bf n}}")#text(". Observe from Stirling’s formula that ")#mi("{{\\bf W} \\cap X}")#text(" converges in distribution to ")#mi("{{\\bf V}}")#text(". Thus it will suffice to find another uniform random variable ")#mi("{{\\bf n}^{\\prime}}")#text(" from ")#mi("{\\{1,\\dots,N\\}}")#text(" such that ")#metadata(none) <tao-66dd231befc8120d323e>#tao-math("\\displaystyle  {\\mathbb E} \\left|A_{{\\bf n}^{\\prime}} \\backslash {\\bf W}\\right| \\leq \\frac{5}{\\log(R\\delta)} {\\mathbb E} \\left|A_{{\\bf n}}\\right| + o(1) \\ \\ \\ \\ \\ (9)", block: false)#text(" ")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", since we can pass to a subsequence in which ")#mi("{(A_{{\\bf n}^{\\prime}}, {\\bf W} \\cap X)}")#text(" converges in distribution to ")#mi("{({\\bf A}, {\\bf V})}")#text(". From ")#link(<tao-8545f46d0c3a6cb00932>)[#text("(8)")]#text(" we have ")#metadata(none) <tao-d940271528e874abf39c>#tao-math("\\displaystyle  {\\mathbb E} \\left|A_{\\bf n}\\right| \\geq 1 - o(1). \\ \\ \\ \\ \\ (10)", block: false)

#text("From ")#mi("{{\\bf n}, {\\bf W}}")#text(" we can form the random set ")#mi("{A_{\\bf n} \\cup {\\bf W}}")#text("; we then form a conditionally independent copy ")#mi("{({\\bf n}^{\\prime}, {\\bf W}^{\\prime})}")#text(" of ")#mi("{({\\bf n}, {\\bf W})}")#text(" subject to the constraint ")#metadata(none) <tao-f5fe88ee08735ae25926>#mi("\\displaystyle  A_{{\\bf n}} \\cup {\\bf W} = A_{{\\bf n}^{\\prime}} \\cup {\\bf W}^{\\prime}. \\ \\ \\ \\ \\ (11)")#text(" ")#text(" We use ")#mi("{{\\bf n}^{\\prime}}")#text(" as the uniform variable to establish ")#link(<tao-66dd231befc8120d323e>)[#text("(9)")]#text(". The point is that the relation ")#link(<tao-f5fe88ee08735ae25926>)[#text("(11)")]#text(" implies that")

#align(center)[#tao-fit-display[#mitex("A_{{\\bf n}^{\\prime}} \\backslash {\\bf W} \\subset A_{{\\bf n}} \\cap A_{{\\bf n}^{\\prime}}")]]

#text("so it will suffice to show that")

#metadata(none) <tao-0b7b76943b5fbaef66d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("{\\mathbb E} \\left|A_{{\\bf n}} \\cap A_{{\\bf n}^{\\prime}}\\right| \\leq \\frac{5}{\\log(R\\delta)} {\\mathbb E} \\left|A_{{\\bf n}}\\right| + o(1)", block: true)]]

#text("By Lemma ")#link(<tao-22b090dd46c756d3c307>)[#text("11")]#text("(ii), ")#link(<tao-d940271528e874abf39c>)[#text("(10)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}(A_{\\bf n} \\cup {\\bf W}) \\leq {\\mathbb H}({\\bf W}) + (2 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| + o(1),", block: true)]]

#text("and hence by ")#link(<tao-62846fbd68c1b929cce1>)[#text("(7)")]

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}( {\\bf n}, {\\bf W} | {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ) \\geq {\\mathbb H}({\\bf n}, {\\bf W}) - {\\mathbb H}({\\bf W}) - (2 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| - o(1)", block: true)]]

#text("and hence by Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(ii) and independence of ")#mi("{{\\bf n}, {\\bf W}}")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf n}) \\leq {\\mathbb H}( {\\bf n}, {\\bf W} | {\\bf n}^{\\prime}, {\\bf W} ) + (2 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| + o(1).", block: true)]]

#text("Now we try to relate the first term on the left-hand side with ")#mi("{A_{{\\bf n}} \\cap A_{{\\bf n}^{\\prime}}}")#text(". Note from ")#link(<tao-f5fe88ee08735ae25926>)[#text("(11)")]#text(" that we have the identity")

#align(center)[#tao-fit-display[#mitex("{\\bf W} = (A_{{\\bf n}^{\\prime}} \\cup {\\bf W}^{\\prime}) \\backslash (A_{\\bf n} \\backslash {\\bf W})")]]

#text("and hence by Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(i)")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( {\\bf n}, {\\bf W} | {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ) \\leq {\\mathbb H}( {\\bf n}, A_{\\bf n} \\backslash {\\bf W} | {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ).")]]

#text("We estimate the relative entropy of ")#mi("{{\\bf n}, A_{\\bf n} \\backslash {\\bf W}}")#text(" here by selecting first ")#mi("{A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}}")#text(", then ")#mi("{{\\bf n}}")#text(", then ")#mi("{A_{\\bf n} \\backslash {\\bf W}}")#text(". More precisely, using the chain rule and monotonicity (Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(i), (iii)) we have")

#tao-aligned(keep: true)[


#tao-math("{\\mathbb H}( {\\bf n}, A_{\\bf n} \\backslash {\\bf W} | {\\bf n}^{\\prime}, {\\bf W}^{\\prime} )  & \\leq {\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} | {\\bf n}^{\\prime}, {\\bf W}^{\\prime} )", block: true)



#tao-math(" & + {\\mathbb H}( {\\bf n} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ) + {\\mathbb H}( A_{\\bf n} \\backslash {\\bf W} | {\\bf n}, A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ).", block: true)
]

#text("From Lemma ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("9")]#text("(i) we have")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} | {\\bf n}^{\\prime}, {\\bf W} ) \\leq {\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} | A_{{\\bf n}^{\\prime}} ) \\leq {\\mathbb E} \\left|A_{\\bf n}\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( A_{\\bf n} \\backslash {\\bf W} | {\\bf n}, A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ) \\leq {\\mathbb H}( A_{\\bf n} \\backslash {\\bf W} | A_{{\\bf n}} ) \\leq {\\mathbb E} |A_{\\bf n}|.")]]

#text("Putting all this together, we conclude")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb H}({\\bf n}) \\leq {\\mathbb H}( {\\bf n} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime} ) + (4 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| + o(1).", block: true)]]

#text("If we apply Lemma ")#link(<tao-909802b269dee093387e>)[#text("10")]#text("(ii) right away we will get the estimate")

#align(center)[#tao-fit-display[#tao-math("(\\log R) {\\bf E} \\left|A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}\\right| \\leq (4 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| + o(1)", block: true)]]

#text("which is a bound resembling ")#link(<tao-0b7b76943b5fbaef66d6>)[#text("(12)")]#text(", but the dependence on the parameters ")#mi("{\\delta, R}")#text(" are too weak. To do better we return to the relative product construction to decouple some of the random variables here. From the tuple ")#mi("{({\\bf n}, {\\bf W}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime})}")#text(" we can form the random variable ")#mi("{(A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{{\\bf n}} \\cup {\\bf W})}")#text(", then form a conditionally independent copy ")#mi("{({\\bf m}, {\\bf U}, {\\bf m}^{\\prime}, {\\bf U}^{\\prime})}")#text(" of ")#mi("{({\\bf n}, {\\bf W}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime})}")#text(" subject to the constraints")

#metadata(none) <tao-9557b2847ecda13b716d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} = A_{\\bf m} \\cap A_{{\\bf m}^{\\prime}}; \\quad A_{\\bf n} \\cup {\\bf W} = A_{\\bf m} \\cup {\\bf U}.")]]

#text("From ")#link(<tao-f5fe88ee08735ae25926>)[#text("(11)")]#text(" and Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(i) we then have")

#tao-aligned(keep: true)[


#tao-math("{\\mathbb H}( {\\bf n} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime} )  & \\leq {\\mathbb H}( {\\bf n} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{\\bf n} \\cup {\\bf W} )", block: true)



#tao-math(" & = {\\mathbb H}( {\\bf m} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{\\bf n} \\cup {\\bf W} ).", block: true)
]

#text("The point is that ")#mi("{{\\bf m}}")#text(" is now conditionally independent of ")#mi("{{\\bf n}, {\\bf W}}")#text(" relative to ")#mi("{A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{\\bf n} \\cup {\\bf W}}")#text(", so we can also rewrite the above conditional entropy as")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( {\\bf m} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{\\bf n} \\cup {\\bf W}, {\\bf n}, {\\bf W} )")]]

#align(center)[#tao-fit-display[#mitex("={\\mathbb H}( {\\bf m} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n}, {\\bf W} )")]]

#text("We now use the chain rule to disentangle the role of ")#mi("{{\\bf W}}")#text(", writing the previous as")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( {\\bf m}, {\\bf W} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n} ) - {\\mathbb H}( {\\bf W} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n} )")]]

#tao-aligned(keep: true)[


#tao-math(" & = {\\mathbb H}( {\\bf m}, {\\bf W} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n} ) - {\\mathbb H}( {\\bf W} | {\\bf n} )", block: true)



#tao-math(" & + {\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n^{\\prime}}} | {\\bf n} ) - {\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n^{\\prime}}} | {\\bf n}, {\\bf W} ).", block: true)
]

#text("From independence we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( {\\bf W} | {\\bf n} ) = {\\mathbb H}( {\\bf W} )")]]

#text("and from Lemma ")#link(<tao-81db8ebbbbc69c6c6ad4>)[#text("9")]#text("(i) we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n^{\\prime}}} | {\\bf n} ) \\leq {\\bf E} |A_{\\bf n}|.")]]

#text("We discard the negative term ")#mi("{{\\mathbb H}( A_{\\bf n} \\cap A_{{\\bf n^{\\prime}}} | {\\bf n}, {\\bf W} )}")#text(". Putting all this together, we obtain")

#metadata(none) <tao-8979e6c9d931842ff295>

#tao-aligned(keep: true)[


#tao-math("{\\mathbb H}({\\bf n})  & \\leq {\\mathbb H}( {\\bf m}, {\\bf W} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n} )", block: true, numbering: n => [#text("(14)")])



#tao-math(" & - {\\mathbb H}( {\\bf W} ) + (5 + \\log \\frac{1}{\\delta}) {\\bf E} \\left|A_{\\bf n}\\right| + o(1).", block: true)
]

#text("Now, from the constraints ")#link(<tao-f5fe88ee08735ae25926>)[#text("(11)")]#text(", ")#link(<tao-9557b2847ecda13b716d>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} \\subset A_{{\\bf m}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("A_{{\\bf n}^{\\prime}} \\backslash A_{\\bf n} \\subset {\\bf W}.")]]

#text("Thus by Lemma ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("8")]#text("(i), (ii), followed by Lemma ")#link(<tao-909802b269dee093387e>)[#text("10")]#text("(ii) and Lemma ")#link(<tao-22b090dd46c756d3c307>)[#text("11")]#text("(i), we have")

#tao-aligned(keep: true)[


#tao-math("{\\mathbb H}( {\\bf m}, {\\bf W} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, {\\bf n} )  & \\leq {\\mathbb H}( {\\bf m} | A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} ) + {\\mathbb H}( {\\bf W} | A_{{\\bf n}^{\\prime}} \\backslash A_{\\bf n} )", block: true)



#tao-math(" & \\leq {\\mathbb H}({\\bf m}) - (\\log R) {\\mathbb E} \\left|A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}\\right| + {\\mathbb H}({\\bf W}) - \\log \\frac{1}{\\delta} {\\mathbb E} \\left|A_{{\\bf n}^{\\prime}} \\backslash A_{\\bf n}\\right| + o(1)", block: true)
]

#text("which when inserted back into ")#link(<tao-8979e6c9d931842ff295>)[#text("(14)")]#text(" using ")#mi("{{\\mathbb H}({\\bf m}) = {\\mathbb H}({\\bf n})}")#text(" and ")#tao-math("{\\left|A_{{\\bf n}^{\\prime}} \\backslash A_{\\bf n}\\right| = \\left|A_{{\\bf n}^{\\prime}}\\right| - \\left|A_{{\\bf n}^{\\prime}} \\cap A_{\\bf n}\\right|}", block: false)#text(" simplifies to")

#align(center)[#tao-fit-display[#tao-math("(\\log (R\\delta)) {\\mathbb E} \\left|A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}\\right| \\leq 5 {\\bf E} \\left|A_{\\bf n}\\right| + o(1)", block: true)]]

#text("and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-575995")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("The formatting around the two uses of Erdős’ name in the first paragraph is broken.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-576254")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2020")])]

#text("Unfortunately, though the diacritics are fixed, the link doesn’t stop where it’s meant to!")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77e5df31f015f32101f432ae511876f243b36a608c4f8a30fc38c55bdffd39fc-b53001af5a3ee374858f32ffc6872b06cffe4d3945247da5e734b00a2f9d2a16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-577369")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2020")])]

#text("There is one more spare ‘}’ too much in that link text (“… theorem}”).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fc58ee571101bd17e73bc9309d9fdd1cb86546cd1f3e5c4d6c6f8a83c2ce102-04739e81f2594a8ca740be7fef506450c9f4f75fc847e343189fc7b254d0998a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darko Veljan")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-576080")[#strong[#text("Darko Veljan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2020")])]

#text("Let G=(V,E) be a connected graph, n=#V. Let I be a subset of V with k el (“infected” vertices); let N(v) be the nbhd of v; suppose #N(v)<r+1 for all v.. Let J be the set of all vertices at distance at most s from infected vertices. What are bounds of probability that a random vertex will be infected")#linebreak()#text(" Answer (perhaps could be a better one). Between k/n and k[1+r+r(r-1)+r(r-1)^2+…+r(r-1)^(s-1)]/n. Exponential in s= distance from infected vertices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-576095")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2020")])]

#text("Dear Pro Tao,")#linebreak()#text(" Has Sunflower conjecture been solved completely? If not still yet, I expect good news from you. I am really excited to read your paper like watching a football match.")#linebreak()#text(" Thank sir,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29d44dee01c455a16fadcef24478460c4bfd3d13fe85cbc5a5862c5e22576b80-90f7d50cc41c743f2f4c1e48cf9c3083f45edf46739ca662520978ee754acab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitriy Zakharov")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-576934")[#strong[#text("Dmitriy Zakharov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2020")])]

#text("Thank you for the great post! Here are some typos I spotted:")

#text("In the proof of Lemma 11 V should be instead of W and S instead of X in some binomial coefficients.")

#text("In (11) take union instead of intersection.")

#text("“and hence by Lemma 8(i): …” In the formula below this line W’ should be instead of W.")

#text("After “we can form the random variable” ")#mi("A_n \\cup W")#text(" instead of ")#mi("n \\cup W")

#text("Missing “=” after “so we can also rewrite the above conditional entropy as”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-577391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2020")])]

#text("A natural generalization of the concept of “Sunflower” to a family of multisets is to similarly define ")#mi("Sun(k, r, m)")#text(" under the additional constraint that the multiplicity of each element in any multiset is at most ")#mi("m")#text(". Clearly ")#mi("Sun(k, r, 1) = Sun(k, r)")#text(".")#linebreak()#text(" Is it possible that ")#mi("Sun(k, r, m)")#text(" can be expressed as a function of ")#mi("Sun(k, r)")#text(" and ")#mi("m")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77e5df31f015f32101f432ae511876f243b36a608c4f8a30fc38c55bdffd39fc-b53001af5a3ee374858f32ffc6872b06cffe4d3945247da5e734b00a2f9d2a16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-577530")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2020")])]

#text("On the bottom of the Polymath wiki page, the section and table with f(k,r) appears to have k and r reversed w.r.t. here and the upper half of the page. (It says f(k,r) = k^r +… while we have here and earlier on the page Sun(k,r) ~ r^k.) I don’t know whom to contact for this, but the main author of the page is ")#link("https://asone.ai/polymath/index.php?title=User:Teorth")[#text("https://asone.ai/polymath/index.php?title=User:Teorth")]#text(" with user page signed(?) “Terence Tao”, so maybe …?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77e5df31f015f32101f432ae511876f243b36a608c4f8a30fc38c55bdffd39fc-b53001af5a3ee374858f32ffc6872b06cffe4d3945247da5e734b00a2f9d2a16.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-577575")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2020")])]

#text("(Note that in the paper by Kostochka et al., where the formula appears as “k^r”, r is the cardinality of the sets and k is the number of petals — the converse of what k & r stand for here and on the Polymath wiki page!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rafik zeraoulia")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-577656")[#strong[#text("rafik zeraoulia")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2020")])]

#text("@Terry Tao, I ask if there is any relationship between Szemerédi’s theorem and Sunflower conjecture?")

#text("pleas check my question here:")

#link("https://mathoverflow.net/q/366245/51189")[#text("https://mathoverflow.net/q/366245/51189")]

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c38f90a28e603cb0e11dcae55b140fd5a33a710c68ed7294b7d2317eea26a305-042cbdc9fe3d1612ee31ee3e0dbd58c680637626e28dc9b9a45fafc84750004d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-578719")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2020")])]

#text("Why is writing down things in information theoretic parlance better?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-579138")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")])]

#text("The bounds are a little sharper and I found the argument to be somewhat less ")#emph[#text("ad hoc")]#text(" when presented in this language as it is largely based on piecing together various basic estimates using the Shannon entropy inequalities (although the trick of passing to a conditional copy ")#emph[#text("twice")]#text(" to get a good bound still feels somewhat magical to me).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5583d0df3be1bbcfc29f3f1ba894953a37af8e44593c62f36786e3080308698b-c7c072304152aa6357f2c1937aca91f250b792a169a9d256ea48c75f4c53b703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lutz Warnke")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-578865")[#strong[#text("Lutz Warnke")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2020")])]

#text("Minor typo: in the proof of Proposition 5, below Corollary 7 I believe it should read E |A’ \\ V| < 1/r (to obtain the claimed probability via Markov).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-578977")[#strong[#text("Is there any relationship between Szemerédi's theorem and Sunflower conjecture? ~ MathOverflow ~ mathubs.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2020")]

#text("[…] rate. In the same time it is an open problem to determine the exact rate growth or exact bounds for The sunflower (the sunflower lemma via Shannon entropy). My question here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e154415b436e9bc8285736de147cd4f38daaec928c63342d457acc7a7cada98e-573c071666a829883ed2a9bbe3426924bc1ddb72b98f5d279797def52ba8e56c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuval Filmus")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-579462")[#strong[#text("Yuval Filmus")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2020")])]

#text("The proof of Lemma 10(i) uses Jensen’s inequality in the wrong direction.")

#emph[#text("[Here we are using the equality case of Jensen’s inequality (crucially relying on the uniform distribution of ")#mi("{\\bf A}")#text(") – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-579783")[#strong[#text("Amazing: Ryan Alweiss, Shachar Lovett, Kewen Wu, Jiapeng Zhang made dramatic progress on the Sunflower Conjecture | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2020")]

#text("[…] Updates: (from comments below) Anup Rao presents a simplification of the original Alweiss, Lovett, Wu, and Zhang argument. https://arxiv.org/abs/1909.04774; An excellent Quanta Magazine article by Kevin Hartnett ")#link("https://www.quantamagazine.org/mathematicians-begin-to-tame-wild-sunflower-problem-20191021/")[#text("https://www.quantamagazine.org/mathematicians-begin-to-tame-wild-sunflower-problem-20191021/")]#text(" . Terry Tao posted a version of Rao’s proof ")#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/")[#text("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/")]#text(". […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-581408")[#strong[#text("T")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2020")])]

#text("Could someone please explain what it means to say ‘")#mi("{{\\bf m}}")#text(" is now conditionally independent of ")#mi("{{\\bf n}, {\\bf W}}")#text(" relative to ")#mi("{A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}, A_{\\bf n} \\cup {\\bf W}}^{\\prime}")#text("? I read this to mean that when we fix ")#mi("{A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}}")#text(" and ")#mi("A_{\\bf n} \\cup {\\bf W}")#text(", then the random variable m conditioned on these is independent from the random variables ")#mi("n")#text(" and ")#mi("W")#text(" conditioned on these. But I don’t understand why we no longer condition on the events in (13). Is it just notation? So when you write the entropy of ")#mi("m")#text(" conditioned on ")#mi("{A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}}}")#text(", then you actually mean the constraint ")#mi("A_{\\bf n} \\cap A_{{\\bf n}^{\\prime}} = {A_{\\bf m} \\cap A_{{\\bf m}^{\\prime}}}")#text("? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-582177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("The constraints in (13) hold almost surely, they do not need to be conditioned on further. (")#mi("({\\bf m}, {\\bf U}, {\\bf m}^{\\prime}, {\\bf U}^{\\prime})")#text(" is a conditionally independent copy of ")#mi("({\\bf n}, {\\bf W}, {\\bf n}^{\\prime}, {\\bf W}^{\\prime})")#text(" subject to (13), which is ")#emph[#text("not")]#text(" the same as an unconditionally independent copy that is then conditioned to (13); see the discussion at the end of Section 1.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Ionescu-Wainger multiplier theorem and the adeles | What's new")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-582029")[#strong[#text("The Ionescu-Wainger multiplier theorem and the adeles | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2020")])]

#text("[…] losses in (i), and recent progress on the Erdos-Rado sunflower conjecture (as discussed in this recent post) to improve the bounds in (ii). For (i), the key point is that one can express a sum such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5583d0df3be1bbcfc29f3f1ba894953a37af8e44593c62f36786e3080308698b-c7c072304152aa6357f2c1937aca91f250b792a169a9d256ea48c75f4c53b703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lutz Warnke")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-591082")[#strong[#text("Lutz Warnke")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2020")])]

#text("In case someone finds it useful, let me remark that a very minor variant of the existing probabilistic arguments yields an upper bound of form Sun(k,r) \\le (Cr \\log k)^k for k,r \\ge 2.")#linebreak()#text(" This was observed during a 2020 REU with undergrads Tolson Bell and Suchakree Chueluecha,")#linebreak()#text(" and the minor twist is to randomly partition X into 2r sets V_1,…,V_{2r} (instead of r sets).")

#text("Indeed, for R \\ge C r \\log k and fixed j, the proof of Proposition 5 then shows that V_j contains at least one of the A_i with probability at least 1/2 whenever the universal constant C is sufficiently large (this can also be deduced from Lemma 4 in Rao’s paper).")#linebreak()#text(" The expected number of sets V_j containing at least one of the A_i is thus at least 2r * 1/2 = r, ensuring that the required r disjoint sets A_{i_1}, \\ldots, A_{i_r} must exist.")#linebreak()#text(" This establishes Proposition 3 for R \\ge C r \\log k, which in turn gives the claimed upper bound Sun(k,r) \\le (Cr \\log k)^k, see also ")#link("https://arxiv.org/abs/2009.09327")[#text("https://arxiv.org/abs/2009.09327")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d3dbd5508d51dad5ee260c4a2860fe39cc3b4085a64e2a14e669cfb88726c18-b8679ae6cdbe2ea06335839d99a427053f2068fd9e91c4cf403ffe7e8481e3ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lunjia Hu")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-625337")[#strong[#text("Lunjia Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2021")])]

#text("Thank you for the great post! Here is a minor technical issue I spotted:")

#text("At the beginning of Section 2: proof of refinement inequality, conditioning on the event that ")#mi("\\mathbf A")#text(" is non-empty may cause the resulting distribution to be no longer ")#mi("R")#text("-spread. This can be fixed by setting ")#mi("\\mathbf A^{\\prime}=\\emptyset")#text(" deterministically whenever ")#mi("\\emptyset")#text(" is in the support of ")#mi("\\mathbf A")#text(". Of course, this could make the distribution of ")#mi("\\mathbf A^{\\prime}")#text(" different from that of ")#mi("\\mathbf A")#text(" and thus violate a desired property of Proposition 6, but for the purpose of proving Proposition 5, we only need the weaker property that the support of ")#mi("\\mathbf A^{\\prime}")#text(" is contained in the support of ")#mi("\\mathbf A")#text(".")

#emph[#text("[Correction implemented, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed997b15b527ebc749c2dd61cbc5fc4270180701e6820eb06c5786ee7fb78d2e-84d34cd3b1f6f2f63a89081b843f472f6b21cf3c533f21760864b8ecd90abe44.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-626391")[#strong[#text("Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2021")])]

#text("[…] of this blog post is to present a streamlined proof of Theorem 1. The proof is largely based on a blog post by Terence Tao where he presented an elegant proof of Rao’s result using Shannon entropy. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-629931")[#strong[#text("How to write LaTeX on a static blog smoothly? ~ TeX - LaTeX ~ AsktoWorld.com")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")]

#text("[…] look of the blogpost I’m targeting is similar to this blog or this one. But anything goes if it’s easy to setup and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5282e47169db80ce51f6c9297afb2ff992df24017614536413cac42e8d1b0912-3c7db53449121333428c32dfdfa87eb419a08ea9568548bd3afa340e30302e15.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DeepC")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-632158")[#strong[#text("DeepC")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2021")])]

#text("A minor correction : in the last line of the proof of Lemma 2, ")#tao-math("\\left|S_0\\right| - \\left|S_0 \\cup S\\right| \\geq -\\left|S\\right|", block: false)#text(" is in the wrong direction : that would imply ")#tao-math("R^{\\left|S_0\\right| - \\left|S_0 \\cup S\\right|} \\geq R^{-\\left|S\\right|}", block: false)#text(".")

#text("Rather, one should say that if ")#mi("S\\cap S_0 \\neq \\emptyset")#text(", then the probability is indeed ")#mi("0")#text(". Therefore, ")#tao-math("\\left|S\\cup S_0\\right|", block: false)#text(" is in fact ")#tao-math("\\left|S\\right| + \\left|S_0\\right|", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-637119")[#strong[#text("Is there any relationship between Szemerédi's theorem and Sunflower conjecture? ~ MathOverflow ~ InsideDarkWeb.com")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2021")]

#text("[…] rate. In the same time it is an open problem to determine the exact rate growth or exact bounds for The sunflower (the sunflower lemma via Shannon entropy). My question here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed9142c212c4e7063d9b19ca471b082d4388c08e4dcd3d50623f9e3884ce5425-6b2782baa1b30aa60eade8d567ee2991f27fea9ac07d6cb6a453251097d4b43e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M Stoeckl")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-643174")[#strong[#text("M Stoeckl")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2022")])]

#text("I am confused by the part where Proposition 6 is used to prove Corollary 7. If anyone could help explain this, it would be much appreciated.")

#text("What precisely does replacing ")#mi("X")#text(" with ")#mi("X \\setminus \\mathbf{V}")#text(" mean? ")#mi("X \\setminus \\mathbf{V}")#text(" is a random variable (which may also depend on ")#mi("\\mathbf{A}^{\\prime}")#text("), but the statement of Prop 6 requires that ")#mi("X")#text(" be a finite set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-643366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2022")])]

#text("This is the conditioning trick. For each possible value ")#mi("V")#text(" of ")#mi("{\\bf V}")#text(", condition all the random variables to the event ")#mi("{\\bf V} = V")#text(", apply Proposition 6 to the deterministic finite set ")#mi("X \\backslash V")#text(" and the conditioned random variables, and then use the law of total probability to undo the conditioning.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed9142c212c4e7063d9b19ca471b082d4388c08e4dcd3d50623f9e3884ce5425-6b2782baa1b30aa60eade8d567ee2991f27fea9ac07d6cb6a453251097d4b43e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M Stoeckl")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-643406")[#strong[#text("M Stoeckl")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2022")])]

#text("Thank you, that was very helpful.")

#text("Also, you may be interested to hear that it is possible to improve the constant in Proposition 6 from ")#mi("5")#text(" to ")#mi("(1 + H_b(\\delta))")#text(", where ")#mi("H_b")#text(" is the binary entropy function. The approach I used is to modify Lunjia Hu’s proof of Proposition 6, to directly study the case where ")#mi("\\mathbf{W}")#text(" is a random subset with each ")#mi("x\\in X")#text(" contained in ")#mi("\\mathbf{W}")#text(" with independent probability ")#mi("\\delta")#text(", instead of having ")#mi("\\mathbf{W}")#text(" be a random set of size $\\delta |X|$. Much of the improvement comes from having a tighter version of the absorption property.")

#text("I’ve written up this argument as part of ")#link("https://mstoeckl.com/notes/research/sunflower_notes.html")[#text("https://mstoeckl.com/notes/research/sunflower_notes.html")]#text(" .")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72da63f199d47cc6a1051d8289ba1f6ea1ccaf001654fc568d59d6e2093b3612-40b76e5c6c038d6ff6454bc65e96e1be1e71057392f23433fe7f4c73c05bd9f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-657813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2022")])]

#text("Sorry, I don’t follow the first inequality in the second last inequality. More specificly, I don’t see where the $A_{n’}\\setminus A_{n}$ come from in $H(W|A_{n’}\\setminus A_n)$. Could someone explain it to me?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-657882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("Oops, this is actually a rather serious issue; I had thought that ")#mi("{\\bf n}")#text(" and ")#mi("A_{\\bf n} \\cap A_{\\bf n^{\\prime}}")#text(" determine ")#mi("A_{\\bf n^{\\prime}} \\backslash A_{\\bf n}")#text(", when instead they determine ")#mi("A_{\\bf n} \\backslash A_{\\bf n^{\\prime}}")#text(". It does not seem easy to implement a local fix for ths issue; however there are now better proofs of this lemma that do not proceed using this second independent copy that give better bounds, starting with ")#link("https://theorydish.blog/2021/05/19/entropy-estimation-via-two-chains-streamlining-the-proof-of-the-sunflower-lemma/")[#text("this argument of Hu")]#text(" and ")#link("https://mstoeckl.com/notes/research/sunflower_notes.html")[#text("this refinement of Stoeckl")]#text(". I’ll leave the original post unchanged for the historical record.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72da63f199d47cc6a1051d8289ba1f6ea1ccaf001654fc568d59d6e2093b3612-40b76e5c6c038d6ff6454bc65e96e1be1e71057392f23433fe7f4c73c05bd9f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-657890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2022")])]

#text("Thanks, I’ll take a look at their proofs.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-685658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2024")])]

#text("Dear Prof. Tao,")

#text("I’m having trouble understanding the key argument (7). What is the role of $mathbb{P} (mathbf{X} = f (X)) $ in the joint distribution of $ (mathbf{X},mathbf{X}’) $ defined above (7). Could you please provide more details for this argument?")

#text("Best,")

#text("-W.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/07/20/the-sunflower-lemma-via-shannon-entropy/#comment-685662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2024")])]

#text("This weight is required for all the probabilities ")#mi("\\mathbb{P}(({\\bf X}, {\\bf X}^{\\prime})=(X,X^{\\prime}))")#text(" to sum to one, and also for the marginal distributions to match the original random variable ")#mi("\\mathbf{X}")#text(", thus ")#mi("\\sum_{X^{\\prime}} \\mathbb{P}(({\\bf X}, {\\bf X}^{\\prime})=(X,X^{\\prime})) = \\mathbb{P}(\\mathbf{X}=X)")#text(" and ")#mi("\\sum_{X} \\mathbb{P}(({\\bf X}, {\\bf X}^{\\prime})=(X,X^{\\prime})) = \\mathbb{P}(\\mathbf{X}=X^{\\prime})")#text(".")
]
]
