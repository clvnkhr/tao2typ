// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/
// Converted to Typst by tao2typ: "2026-10-14T16:35:18.811595+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")[#text("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("Having completed a heuristic derivation of the monotonicity of Perelman reduced volume (Conjecture 1 from the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text("), we now turn to a rigorous proof. Whereas in the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(" we derived this monotonicity by converting a parabolic spacetime to a high-dimensional Riemannian manifold, and then formally applying tools such as the ")#link("http://en.wikipedia.org/wiki/Bishop%E2%80%93Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(" to that setting, our approach here shall take the opposite tack, finding parabolic analogues of the ")#emph[#text("proof")]#text(" of the elliptic Bishop-Gromov inequality, in particular obtaining analogues of the classical first and second variation formulae for geodesics, in which the notion of length is replaced by the notion of ")#mi("{\\mathcal L}")#text("-length introduced in the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(".")

#text("The material here is primarily based on ")#link("http://arxiv.org/abs/math.DG/0211159")[#text("Perelman’s first paper")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2251315")[#text("Müller’s book")]#text(", but detailed treatments also appear in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2342013")[#text("paper of Ye")]#text(", the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", the book of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(", and the ")#link("http://arxiv.org/abs/math/0612069")[#text("paper of Cao-Zhu")]#text(".")

#metadata(none) <tao-2f7b75f9c275323d8b5c>

#heading(level: 1)[#text("— Reduction to a pointwise inequality —")]

#text("Recall that the Bishop-Gromov inequality (Corollary 1 from the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(") states (among other things) that if a d-dimensional complete Riemannian manifold (M,g) is Ricci-flat (or more generally, has non-negative Ricci curvature), and ")#mi("x_0")#text(" is any point in M, then the Bishop-Gromov reduced volume ")#mi("\\text{Vol}(B(x_0,r))/r^d")#text(" is a non-increasing function of r. In fact one can obtain the slightly sharper result that ")#mi("\\text{Area}(S(x_0,r))/r^{d-1}")#text(" is a non-increasing function of r, where ")#mi("S(x_0,r)")#text(" is the sphere of radius r centred at ")#mi("x_0")#text(".")

#text("From the basic formula ")#mi("{\\mathcal L}_{\\partial r} d\\mu = (\\Delta r)\\ d\\mu")#text(" (equation (1) from the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(") and the ")#link("http://en.wikipedia.org/wiki/Gauss%27s_lemma_%28Riemannian_geometry%29")[#text("Gauss lemma")]#text(", one readily obtains the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{d}{dr} \\text{Area}(S(x_0,r)) = \\int_{S(x_0,r)} \\Delta r\\ dS")]]

#text("where ")#mi("dS")#text(" is the area element. The monotonicity of ")#mi("\\text{Area}(S(x_0,r))/r^{d-1}")#text(" then follows (formally, at least) from the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta r \\leq \\frac{d-1}{r}")]]

#text("which we will derive shortly (at least for the portion of the manifold inside the cut locus) as a consequence of the first and second variation formulae for geodesics. (In the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(", the inequality (2) was derived from a transport inequality for ")#mi("\\Delta r")#text(", but we will take a slightly different tack here.) Observe that (2) is an equality when (M,g) is a Euclidean space ")#mi("{\\Bbb R}^d")#text(".")

#text("It turns out that the monotonicity of Perelman reduced volume for Ricci flows can similarly be reduced to a pointwise inequality, in which the Laplacian ")#mi("\\Delta")#text(" is replaced by a heat operator, and the radial variable r is replaced by the Perelman reduced length. More precisely, given an ancient Ricci flow ")#mi("t \\mapsto (M,g(t))")#text(" for ")#mi("t \\in (-\\infty,0]")#text(", a time ")#mi("-\\tau")#text(", and two points ")#mi("x_0, x \\in M")#text(", recall that the reduced length ")#mi("l_{(0,x_0)}( -\\tau,x)")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("l_{(0,x_0)}( -\\tau,x) := \\frac{1}{2\\sqrt{\\tau}} \\inf_\\gamma {\\mathcal L}(\\gamma)")]]

#text("where the ")#emph[#mi("{\\mathcal L}")#text("-length")]#text(" ")#mi("{\\mathcal L}(\\gamma)")#text(" of a curve ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" from ")#mi("x_0")#text(" to ")#mi("x_1")#text(" is defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("{\\mathcal L}(\\gamma) = \\int_0^{\\tau_1} \\sqrt{\\tau} (R + \\left|X\\right|_{g(-\\tau)}^2)\\ d\\tau,", block: true)]]

#text("where we adopt the shorthand ")#mi("X := \\partial_{\\tau} \\gamma")#text(", and that Conjecture 1 from the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(" asserts that the Perelman reduced volume")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tilde V_{(0,x_0)}(-\\tau) = \\int_M \\tau^{-d/2} \\exp( - l_{(0,x_0)}(-\\tau,x) )\\ d\\mu_{g(-\\tau)}(x)")]]

#text("is non-increasing in ")#mi("\\tau")#text(" for Ricci flows. If we differentiate (5) in ")#mi("\\tau")#text(", using the variation formula ")#mi("\\frac{d}{d\\tau} d\\mu = R\\ d\\mu")#text(", we easily verify that the monotonicity of (5) will follow (assuming ")#mi("l_{(0,x_0)}")#text(" is sufficiently smooth, and that either M is compact, or ")#mi("l_{(0,x_0)}")#text(" grows sufficiently quickly at infinity) from the pointwise inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\partial_{\\tau} l_{(0,x_0)} - \\Delta_{g(-\\tau)} l_{(0,x_0)} + \\left|\\nabla l\\right|_{g(-\\tau)}^2 - R + \\frac{d}{2\\tau} \\geq 0", block: true)]]

#text("which should be viewed as a parabolic analogue to (2).")

#strong[#text("Exercise 1. ")]#text("Verify that (6) is an equality in the case of the (trivial) Ricci flow on Euclidean space, using Example 1 from the ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("previous lecture")]#text(". (This is of course consistent with Example 2 from that lecture.) ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" Show that (6) is equivalent to the assertion that the function ")#mi("v(-\\tau,x) := (4\\pi \\tau)^{-d/2} \\exp(-l_{(0,x_0)}(-\\tau,x))")#text(" is a subsolution of the adjoint heat equation, or more precisely that ")#mi("\\partial_t v - \\Delta v + Rv \\leq 0")#text(". Note that this fact implies the monotonicity of Perelman reduced volume (cf. Exercise 2 from ")#link("https://terrytao.wordpress.com/2008/04/24/285a-lecture-8-ricci-flow-as-a-gradient-flow-log-sobolev-inequalities-and-perelman-entropy/")[#text("Lecture 8")]#text("). [It seems that the elliptic analogue of this fact is the assertion that the ")#link("http://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newton-type potential")]#text(" ")#mi("1/r^{d-2}")#text(" is subharmonic away from the origin for Ricci flat manifolds of dimension three or larger , which is a claim which is easily seen to be equivalent to (2) thanks to the Gauss lemma.] ")#mi("\\diamond")

#text("So to prove monotonicity of the Perelman reduced volume, the main task will be to establish the pointwise inequality (6). (There are some additional technical issues, mainly concerning the parabolic counterpart of the cut locus, which we will also have to address, but we will work formally for now, and deal with these analytical matters later.)")

#text("We will perform a minor simplification: by using the rescaling symmetry ")#mi("g(t,x) \\mapsto \\lambda^2 g(\\frac{t}{\\lambda^2})")#text(" (and noting the unsurprising fact that (6) is dimensionally consistent) we can normalise ")#mi("\\tau_1 = 1")#text(".")

#heading(level: 1)[#text("— First and second variation formulae for ")#mi("{\\mathcal L}")#text("-geodesics —")]

#text("To establish (6), we of course need some ")#emph[#text("variation formulae")]#text(" that compute the first and second derivatives of the reduced length function ")#mi("l_{(0,x_0)}")#text(". To motivate these formulae, let us first recall the more classical variation formulae that give the first and second derivatives of the metric function ")#mi("d(x_0,x)")#text(" on a Riemannian manifold (M,g), which in particular can be used to derive (2) when the Ricci curvature is non-negative.")

#text("We recall that the distance ")#mi("d(x_0,x)")#text(" can be defined by the energy-minimisation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\frac{1}{2} d(x_0,x)^2 = \\inf_\\gamma E(\\gamma)")]]

#text("where ")#mi("\\gamma: [0,1] \\to M")#text(" ranges over all ")#mi("C^1")#text(" curves from ")#mi("x_0")#text(" to x, where the ")#link("http://en.wikipedia.org/wiki/Dirichlet_energy")[#text("Dirichlet energy")]#text(" ")#mi("E(\\gamma)")#text(" of the curve is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("E(\\gamma) = \\frac{1}{2} \\int_0^1 \\left|X\\right|_g^2\\ dt", block: true)]]

#text("where we write ")#mi("X := \\partial_t \\gamma")#text(". It is known that this infimum is always attained by some geodesic ")#mi("\\gamma")#text("; we shall assume this implicitly in the computations which follow.")

#text("Now suppose that we deform such a curve ")#mi("\\gamma")#text(" with respect to a real parameter ")#mi("s \\in (-\\varepsilon,\\varepsilon)")#text(", thus ")#mi("\\gamma: (s,t) \\mapsto \\gamma(s,t)")#text(" is now a function on the two-dimensional parameter space ")#mi("(\\varepsilon,\\varepsilon) \\times [0,1]")#text(". The first variation here can be computed as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{d}{ds} E(\\gamma) = \\int_0^1 g( \\nabla_X X, X )\\ dt")]]

#text("where ")#mi("\\nabla_X")#text(" is the pullback of the Levi-Civita connection on M with respect to ")#mi("\\gamma")#text(" applied in the direction ")#mi("\\partial_t")#text("; here we of course use that g is parallel with respect to this connection. The torsion-free nature of this connection gives us the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\nabla_Y X = \\nabla_X Y")]]

#text("where ")#mi("Y = \\partial_s \\gamma")#text(" is the infinitesimal variation, and ")#mi("\\nabla_Y")#text(" is the pullback of the Levi-Civita connection applied in the direction ")#mi("\\partial_s")#text(" (cf. Exercise 5 from ")#link("https://terrytao.wordpress.com/2008/04/18/285g-lecture-6-finite-time-extinction-of-the-third-homotopy-group-ii/")[#text("Lecture 6")]#text("). An integration by parts (again using the parallel nature of g) then gives the first variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{d}{ds} E(\\gamma) = g( Y, X )|_{t=0}^1 - \\int_0^1 g( Y, \\nabla_X X )\\ dt.")]]

#text("If we fix the endpoints of ")#mi("\\gamma")#text(" to be ")#mi("\\gamma(s,0) = x_0")#text(" and ")#mi("\\gamma(s,1)=x_1")#text(", then the first term on the right-hand side of (11) vanishes. If we consider arbitrary infinitesimal variations ")#mi("Y")#text(" of ")#mi("\\gamma")#text(" with fixed endpoints, we thus conclude that in order to be a minimiser for (7), that ")#mi("\\gamma")#text(" must obey the ")#emph[#text("geodesic flow equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\nabla_X X = 0.")]]

#text("One consequence of this is that the speed ")#tao-math("\\left|X\\right|_g", block: false)#text(" of such a minimiser must be constant, and from (7) we then conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|X\\right|_g = d(x_0,x).", block: true)]]

#text("If we then vary a geodesic ")#mi("\\gamma(0,\\cdot)")#text(" with the initial endpoint ")#mi("\\gamma(s,0)")#text(" fixed at ")#mi("x_0")#text(" and the final endpoint ")#mi("\\gamma(s,1) = x(s)")#text(" variable, the variation formula (11) gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{d}{ds} E(\\gamma) = g( x^{\\prime}(s), X(s,1) )")]]

#text("which, if we insert this back into (7) and use (13), gives")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\frac{d}{ds} d(x_0,x) \\leq g( x^{\\prime}(s), X(s,1) / \\left|X(s,1)\\right|_g )", block: true)]]

#text("which is a (one-sided) version of the Gauss lemma. If one is inside the ")#link("http://en.wikipedia.org/wiki/Cut_locus")[#text("cut locus")]#text(", then the metric function is smooth, and one can then replace the inequality with an equality by considering variations both forwards and backwards in the s variable, recovering the full Gauss lemma. In particular, we conclude in this case that ")#mi("\\nabla d(x_0,x)")#text(" is a unit vector.")

#text("Now we consider the second variation ")#mi("\\frac{d^2}{ds^2} E(\\gamma)")#text(" of the energy, when ")#mi("\\gamma")#text(" is already a geodesic. For simplicity we assume that ")#mi("\\gamma")#text(" evolves geodesically in the s direction, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\nabla_Y Y = 0.")]]

#text("[Actually, since ")#mi("\\gamma")#text(" is already a geodesic and thus is stationary with respect to perturbations that respect the endpoints, the values of ")#mi("\\nabla_Y Y")#text(" away from endpoints – which represents a second-order perturbation respecting the endpoints – will have no ultimate effect on the second variation of ")#mi("E(\\gamma)")#text(". Nevertheless it is convenient to assume (14) to avoid a few routine additional calculations.]")

#text("Differentiating (9) once more we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\frac{d^2}{ds^2} E(\\gamma) = \\int_0^1 g( \\nabla_Y \\nabla_Y X, X ) + \\left|\\nabla_Y X\\right|_g^2 \\ dt.", block: true)]]

#text("Using (10), (14), and the definition of curvature, we have")

#tao-aligned(keep: true)[


#tao-math("\\nabla_Y \\nabla_Y X  & = \\nabla_Y \\nabla_X Y", block: true)



#tao-math(" & = \\nabla_X \\nabla_Y Y + \\text{Riem}( Y, X ) Y", block: true, numbering: n => [#text("(16)")])



#tao-math(" & = -\\text{Riem}( X, Y ) Y", block: true)
]

#text("and thus (by one further application of (10))")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\frac{d^2}{ds^2} E(\\gamma) = \\int_0^1 \\left|\\nabla_X Y\\right|_g^2 - g(\\text{Riem}(X, Y) Y, X)\\ dt.", block: true)]]

#text("Now let us fix the initial endpoint ")#mi("\\gamma(s,0) = x_0")#text(" and let the other endpoint ")#mi("\\gamma(s,1) = x(s)")#text(" vary, thus ")#mi("\\partial_s \\gamma")#text(" equals 0 at time t=0 and equals ")#mi("x^{\\prime}(s)")#text(" at time t=1. From Cauchy-Schwarz we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\int_0^1 \\left|\\nabla_X Y\\right|_g^2\\ dt \\leq \\int_0^1 (\\partial_t \\left|Y\\right|_g)^2\\ dt \\leq (\\int_0^1 \\partial_t \\left|Y\\right|_g\\ dt)^2 = \\left|x^{\\prime}(s)\\right|^2.", block: true)]]

#text("Actually, we can attain equality here by choosing the vector field ")#mi("Y")#text(" appropriately:")

#strong[#text("Exercise 3.")]#text(" If we set ")#mi("Y := t v")#text(", where v is the parallel transport of x'(s) along X, or more precisely the vector field that solves the ODE")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\nabla_X v = 0; v(s,1) = x^{\\prime}(s)")]]

#text("show that all the inequalities in (18) are obeyed with equality. ")#mi("\\diamond")

#text("For such a vector field, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\frac{d^2}{ds^2} E(\\gamma) = \\left|x^{\\prime}(s)\\right|^2 - \\int_0^1 - t^2 g(\\text{Riem}(X, v) v, X)\\ dt.", block: true)]]

#text("From this formula (and the first variation formula) we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\frac{d^2}{ds^2} \\frac{1}{2} d(x_0,x)^2 \\leq \\left|x^{\\prime}(s)\\right|^2 - \\int_0^1 t^2 g(\\text{Riem}(X, v) v, X)\\ dt.", block: true)]]

#text("Now let ")#mi("x^{\\prime}(0)")#text(" vary over an orthonormal basis of the tangent space of x(0); by (19) we see that v determines an ")#link("http://en.wikipedia.org/wiki/Orthonormal_frame")[#text("orthonormal frame")]#text(" for s=0 and ")#mi("0 \\leq t \\leq 1")#text(". Summing (21) over this basis (and using the formula for the Laplacian in ")#link("http://en.wikipedia.org/wiki/Normal_coordinates")[#text("normal coordinates")]#text(") we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\Delta \\frac{1}{2} d(x_0,x)^2 \\leq d - \\int_0^1 t^2 \\text{Ric}(X,X)\\ dt.")]]

#text("In particular, for manifolds of non-negative Ricci curvature we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Delta \\frac{1}{2} d(x_0,x)^2 \\leq d")]]

#text("from which (2) easily follows from the Gauss lemma. (Observe that (23) is obeyed with equality in the Euclidean case.)")

#text("Now we develop analogous variational formulae for ")#mi("{\\mathcal L}")#text("-length (and reduced length) on a Ricci flow. We shall work formally for now, assuming that all infima are actually attained and that all quantities are as smooth as necessary for the analysis that follows to work; we then discuss later how to justify all of these assumptions. As mentioned earlier, we normalise ")#mi("\\tau_1 = 1")#text(".")

#text("Let us take a path ")#mi("\\gamma: [0,1] \\to M")#text(" and vary it with respect to some additional parameter s as before. Differentiating (4), we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\frac{d}{ds} {\\mathcal L}(\\gamma) = \\int_0^1 \\sqrt{\\tau} ( \\nabla_Y R + 2 g( X,  \\nabla_Y X ))\\ d\\tau")]]

#text("where ")#mi("X := \\partial_\\tau \\gamma")#text(" and ")#mi("Y := \\partial_s \\gamma")#text(". On the other hand, if we have a Ricci flow ")#mi("\\partial_\\tau g = 2 \\text{Ric}")#text(", we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_\\tau g( X, Y ) = g( \\nabla_X X, Y ) + g( X, \\nabla_X Y ) + 2 \\text{Ric}( X, Y );")]]

#text("placing this into (24) and using the fundamental theorem of calculus, we can express the right-hand side of (24) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("2 g( X, Y )(\\tau_1) - 2 \\int_0^1 \\sqrt{\\tau} g( Y, G(X) )\\ d\\tau")]]

#text("where G(X) is the vector field")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("G := \\nabla_X X - \\frac{1}{2} \\nabla R + \\frac{1}{2\\tau} X + 2 \\text{Ric}(X,\\cdot)^*.")]]

#text("Here ")#mi("\\text{Ric}(X,\\cdot)^*")#text(" is the vector field ")#mi("(\\text{Ric}(X,\\cdot)^*)^\\alpha = g^{\\alpha \\beta} \\text{Ric}_{\\gamma \\beta} X^\\gamma")#text(", or equivalently it is the vector field Z such that ")#mi("\\text{Ric}(X,W) = g(Z,W)")#text(" for all vector fields W.")

#text("Note that G does not depend on Y. From this we see that in order for ")#mi("\\gamma")#text(" to be a minimiser of ")#mi("{\\mathcal L}(\\gamma)")#text(" with the endpoints fixed, we must have G(X)=0, which is the parabolic analogue of the geodesic flow equation (14).")

#strong[#text("Example 1. ")]#text("In the case of the trivial Euclidean flow, the minimal ")#mi("{\\mathcal L}")#text("-path from ")#mi("(0,x_0)")#text(" to ")#mi("(-1,x_1)")#text(" takes the form ")#mi("\\gamma(\\tau) = x_0 + v \\sqrt{\\tau}")#text(" where ")#mi("v := x_1-x_0")#text(", in which case ")#mi("X = \\frac{v}{2\\sqrt{\\tau}}")#text(". It is not hard to verify that G=0 in this case. ")#mi("\\diamond")#text(".")

#text("Arguing as in the elliptic case, we conclude (assuming the existence of a unique minimiser, and the local smoothness of reduced length) the first variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\partial_s l_{(0,x_0)}(-1,x_1) = g( X, \\partial_s x_1)(1)")]]

#text("or equivalently")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\nabla l_{(0,x_0)}(-1,x_1) = X(1).")]]

#strong[#text("Example 2. ")]#text("Continuing Example 1, note that ")#tao-math("l_{(0,x_0)}(-1,x_1) = \\left|x_1-x_0\\right|^2/4", block: false)#text(" and ")#mi("\\partial_\\tau \\gamma = (x_1-x_0)/2")#text(", which is of course consistent with (28). ")#mi("\\diamond")

#text("Having computed the spatial derivative of the reduced length, we turn to the time derivative. The simplest way to compute this is to observe that any partial segment of an ")#mi("{\\mathcal L}")#text("-minimising path must again be a ")#mi("{\\mathcal L}")#text("-minimising path. From (4) and the fundamental theorem of calculus we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\frac{d}{d\\tau_1} {\\mathcal L}(\\gamma)|_{\\tau_1 = 1} = R + \\left|X\\right|_g^2", block: true)]]

#text("where we vary ")#mi("\\gamma")#text(" in ")#mi("\\tau_1")#text(" by truncation; by (3) and the above discussion we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\frac{d}{d\\tau_1} ( 2\\sqrt{\\tau_1} l_{(0,x_0)}(-\\tau_1,x_1) )|_{\\tau_1=1} = (R + \\left|X\\right|_g^2)", block: true)]]

#text("where ")#mi("(\\tau_1,x_1)")#text(" varies along ")#mi("\\gamma")#text(" (in particular, ")#mi("\\partial_{\\tau_1} x_1 = X")#text("). Applying the product and chain rules, we can expand the left-hand side of (31) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("l_{(0,x_0)}(-1,x_1) + 2 \\partial_{\\tau_1}l_{(0,x_0)}(-\\tau_1,x_1)|_{\\tau_1=-1} + 2 g( \\nabla l_{(0,x_0)}(-1,x_1), X );")]]

#text("using (29), we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#tao-math("\\partial_{\\tau_1} l_{(0,x_0)}(-\\tau_1,x_1)|_{\\tau_1=1} = \\frac{1}{2} (R + \\left|X\\right|_g^2) - \\frac{1}{2} l_{(0,x_0)}(-1,x_1) -  \\left|X\\right|_g^2.", block: true)]]

#text("Now we turn to the second spatial variation of the reduced length. Let ")#mi("\\gamma")#text(" be a ")#mi("{\\mathcal L}")#text("-minimiser, so that G=0. Differentiating (24) again, we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#tao-math("\\frac{d^2}{ds^2} {\\mathcal L}(\\gamma) = \\int_0^{1} \\sqrt{\\tau} ( \\nabla_Y \\nabla_Y R + 2 \\left|\\nabla_Y X\\right|^2 + 2 g( X,  \\nabla_Y \\nabla_Y X ))\\ d\\tau.", block: true)]]

#text("As in the elliptic case, it is convenient to assume that we have a geodesic variation (14). In that case, we again have (16), and we also have ")#mi("\\nabla_Y \\nabla_Y R = \\text{Hess}(R)(Y,Y)")#text(". Using (10), we thus express (34) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#tao-math("\\int_0^{1} \\sqrt{\\tau} ( \\text{Hess}(R)(Y,Y) + 2 \\left|\\nabla_X Y\\right|^2 - 2 g(\\text{Riem}(X,Y) Y, X))\\ d\\tau.", block: true)]]

#text("As before, we optimise this in Y. Because the metric g now changes in time by Ricci flow, one has to modify the prescription in Exercise 3 slightly. More precisely, we now set ")#mi("Y := \\sqrt{\\tau} v")#text(", where v solves the following variant of (19),")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\nabla_X v = - \\text{Ric}(v,\\cdot)^*; v(s,1) = x^{\\prime}(s).")]]

#text("The point of doing this is that the ODE is orthogonal; the length of v is preserved along X, as is the inner product between any two such v’s (cf. equation (15) from ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 3")]#text("). A brief computation then shows that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\nabla_X Y = \\frac{1}{2\\sqrt{\\tau}}  v - \\sqrt{\\tau} \\text{Ric}(v,\\cdot)^*")]]

#text("and hence")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#tao-math("\\left|\\nabla_X Y\\right|_g^2 = \\frac{1}{4\\tau} \\left|x^{\\prime}(s)\\right|_g^2 + \\tau \\left|\\text{Ric}(v,\\cdot)\\right|^2 - \\text{Ric}(v,v).", block: true)]]

#text("Putting all of this into (35), we now see that the second variation (34) is equal to")

#tao-aligned(keep: true)[


#tao-math("\\int_0^1 \\tau^{3/2} \\text{Hess}(R)(v,v)  & + \\frac{1}{2\\tau^{1/2}} \\left|x^{\\prime}(s)\\right|_g^2 + 2\\tau^{3/2} \\left|\\text{Ric}(v,\\cdot)\\right|^2", block: true)



#tao-math(" & - 2 \\tau^{1/2} \\text{Ric}(v,v) - 2\\tau^{3/2} g(\\text{Riem}(X,v) v, X)\\ d\\tau.", block: true, numbering: n => [#text("(39)")])
]

#text("We now let ")#mi("x^{\\prime}(0)")#text(" range over an orthonormal basis of ")#mi("x(0)")#text(", which leads to v being an orthonormal frame at every point (0,t). Summing over (39) and also using (3), we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#tao-math("\\Delta l_{(0,x_0)}(-1,x_1) \\leq \\int_0^{1} \\frac{\\tau^{3/2}}{2} \\Delta R + \\frac{d}{4\\tau^{1/2}} + \\tau^{3/2}\\left|\\text{Ric}\\right|_g^2 - \\tau^{1/2} R - \\tau^{3/2} \\text{Ric}(X,X)\\ d\\tau.", block: true)]]

#text("Now we simplify the right-hand side of (40). The second term is of course elementary:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("\\int_0^1 \\frac{d}{4\\tau^{1/2}}\\ d\\tau = \\frac{d}{2}")]]

#text("and this is consistent with the Euclidean case (in which ")#mi("\\Delta l_{(0,x_0)}")#text(" is exactly ")#mi("\\frac{d}{2}")#text(" when ")#mi("\\tau_1=1")#text(", and all curvature terms vanish). To simplify the remaining terms, we recall the variation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#tao-math("-\\partial_\\tau R = \\Delta R + 2 \\left|\\text{Ric}\\right|_g^2", block: true)]]

#text("for the scalar curvature (equation (31) of ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("Lecture 1")]#text("); by the chain rule, we thu have the total derivative formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#tao-math("\\frac{d}{d\\tau} R = -\\Delta R - 2 \\left|\\text{Ric}\\right|_g^2 + \\nabla_X R.", block: true)]]

#text("Inserting (41), (43) into (40) and integrating by parts, we express the right-hand side of (40) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("\\frac{d}{2} - \\frac{1}{2} R + \\int_0^{1}  \\frac{\\tau^{3/2}}{2}  \\nabla_X R - \\frac{\\tau^{1/2}}{4} R - \\tau^{3/2} \\text{Ric}(X,X)\\ d\\tau.")]]

#text("To simplify this further, recall that the quantity G defined in (27) vanishes. This (and the fact that g evolves by Ricci flow ")#mi("\\partial_\\tau g = 2 \\text{Ric}")#text(") allows one to compute the variation of ")#tao-math("\\tau \\left|X\\right|_g^2", block: false)#text(":")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\partial_\\tau (\\tau \\left|X\\right|_g^2) = \\tau \\partial_X R - 2 \\tau \\text{Ric}(X,X).", block: true)]]

#text("Inserting this into (44) and integrating by parts, one can rewrite (44) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#tao-math("\\frac{d}{2} - \\frac{1}{2} R + \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{4} \\int_0^1 \\sqrt{\\tau} (R + \\left|X\\right|^2)\\ d\\tau", block: true)]]

#text("and so by (3) we obtain the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("\\Delta l_{(0,x_0)}(-1,x_1) \\leq \\frac{d}{2} - \\frac{1}{2} R + \\frac{1}{2} \\left|X\\right|_g^2 - \\frac{1}{2} l_{(0,x_0)}(-1,x_1).", block: true)]]

#text("Combining (29), (33), and (47) we obtain (6) as desired.")

#heading(level: 1)[#text("— Analytical issues —")]

#text("We now discuss in broad terms the analytical issues that one must address in order to make the above arguments rigorous. We first review the classical elliptic theory (i.e. the theory of geodesics in a Riemannian manifold) before turning to Perelman’s parabolic theory of ")#mi("{\\mathcal L}")#text("-geodesics in a flow of Riemannian metrics.")

#text("In a complete Riemannian manifold, a geodesic ")#mi("\\gamma: [0,1] \\to M")#text(" from a fixed point ")#mi("\\gamma(0) = x_0")#text(" to some other point ")#mi("\\gamma(1)=x_1")#text(" has a well-defined initial velocity vector ")#mi("\\gamma^{\\prime}(0) = X(0)")#text(", and conversely each initial velocity vector ")#mi("v = X(0)\\in T_{x_0} M")#text(" determines a unique geodesic with an endpoint ")#mi("x_1 = \\exp_{x_0}(v)")#text(", thus defining the ")#link("http://en.wikipedia.org/wiki/Exponential_map")[#text("exponential map ")]#text("based at ")#mi("x_0")#text(". One can show (from standard ODE theory) that this exponential map is smooth (with the derivative of this map controlled by ")#link("http://en.wikipedia.org/wiki/Jacobi_field")[#text("Jacobi fields")]#text("). Also, if M is connected, then any two points can be joined by a geodesic, and the exponential map is onto. However, there can be vectors v for which this map degenerates (i.e. its derivative ceases to be invertible) – these correspond to the ")#link("http://en.wikipedia.org/wiki/Conjugate_point")[#text("conjugate points")]#text(" of ")#mi("x_0")#text(" in M.")

#text("Define the ")#emph[#text("injectivity region")]#text(" of ")#mi("x_0")#text(" to be the set of all ")#mi("x_1")#text(" for which there is a unique minimising geodesic from ")#mi("x_0")#text(" to ")#mi("x_1")#text(", and that the exponential map is not degenerate along this geodesic (in particular, ")#mi("x_0")#text(" and ")#mi("x_1")#text(" are not conjugate points). An analysis of Jacobi fields reveals that the injectivity region is open, that the distance function is smooth in this region (except at the origin), and that all the computations given above for the distance function can be justified. So it remains to understand what happens on the complement of the injectivity region, known as the ")#link("http://en.wikipedia.org/wiki/Cut_locus")[#text("cut locus")]#text(". Points on the cut locus are either conjugate points to ")#mi("x_0")#text(", or are else places where minimising geodesics are not unique, which (by a variant of the Gauss lemma) forces the distance function to be non-differentiable at these points. The former type of points form a set of measure zero, thanks to ")#link("http://en.wikipedia.org/wiki/Sard%27s_theorem")[#text("Sard’s theorem")]#text(", whereas the latter set of points also form a set of measure zero, thanks to ")#link("http://en.wikipedia.org/wiki/Rademacher's_theorem")[#text("Radamacher’s differentiation theorem")]#text(" and the Lipschitz nature of the distance function (i.e. the ")#link("http://en.wikipedia.org/wiki/Triangle_inequality")[#text("triangle inequality")]#text("). Thus the injectivity region has full measure. While this does mean that pointwise inequalities such as (2) now hold almost everywhere, this is unfortunately not quite enough to ensure that (2) holds in the sense of distributions, which is what one really needs in order to fully justify results such as the Bishop-Gromov inequality. (Indeed, by considering simple examples such as the unit circle, we see that the distribution ")#mi("\\Delta r")#text(" can in fact contain some negative singular measures, although one should note that this does not actually contradict (2) due to the favourable sign of these singular components.) Fortunately, one can address this technical issue by constructing barrier functions to the radius function r at every point ")#mi("x_1")#text(", i.e. ")#mi("C^2")#text(" functions ")#mi("u=u_{\\varepsilon}")#text(" for each ")#mi("\\varepsilon > 0")#text(" which upper bound r near ")#mi("x_1")#text(" (and match r exactly at ")#mi("x_1")#text(", and which obeys the inequality (2) at ")#mi("x_1")#text(" up to a loss of ")#mi("\\varepsilon")#text(". Such functions can be constructed at any ")#mi("x_1")#text(", even those in the cut locus, by perturbing the origin ")#mi("x_0")#text(" by an epsilon, and then one can use these barrier functions to justify (2) in the sense of distributions. (I believe that these arguments to control the distance function outside of the injectivity region originate with ")#link("http://www.ams.org/mathscinet-getitem?mr=92069")[#text("a paper of Calabi")]#text(".) From this one can rigorously justify the Bishop-Gromov inequality for all radii, even those exceeding the radius of injectivity.")

#text("Analogues of the above assertions hold for the monotonicity of Perelman reduced volume on flows on compact Ricci flows (and more generally for Ricci flows of complete manifolds of bounded curvature). For instance, one can show (using compactness arguments in various weighted Sobolev spaces) that, as long as the manifold M is connected, a minimiser to (3) always exists, and is attained by an ")#mi("{\\mathcal L}")#text("-geodesic (defined as a curve ")#mi("\\gamma: [0,\\tau_1] \\to M")#text(" for which the G quantity defined in (27) vanishes). [One can easily reduce to the connected case, since the reduced length is clearly infinite when ")#mi("x_0")#text(" and ")#mi("x_1")#text(" lie on distinct connected components.] Such geodesics turn out to have a well-defined “initial velocity” ")#mi("v := \\lim_{\\tau \\to 0} \\sqrt{\\tau} X(\\tau)")#text(", as can be seen by working out the ODE for the quantity ")#mi("\\sqrt{\\tau} X(\\tau)")#text(" (it is also convenient to reparameterise in terms of the variable ")#mi("r := \\sqrt{\\tau}")#text(" to remove any apparent singularity at ")#mi("\\tau=0")#text("). This leads to an ")#mi("{\\mathcal L}")#text("-exponential map ")#mi("{\\mathcal L}\\exp_{(0,x_0),\\tau_1}: T_{x_0} M \\to M")#text(" for any fixed time ")#mi("-\\tau_1")#text(", which is smooth. The derivative of this map is controlled by ")#mi("{\\mathcal L}")#text("-Jacobi fields, which are close analogues of their elliptic counterparts, and which lead to the notion of a ")#mi("{\\mathcal L}")#text("-conjugate point ")#mi("x_1")#text(" to ")#mi("(0,x_0)")#text(" at the fixed time ")#mi("-\\tau_1")#text(". One can then define the injectivity domain and cut locus as before (again for a fixed time ")#mi("-\\tau_1")#text("), and show as before that the former region has full measure. This lets one rigorously derive (6) almost everywhere (especially after noting that any segment of a minimising ")#mi("{\\mathcal L}")#text("-geodesic without conjugate points is again a minimising ")#mi("{\\mathcal L}")#text("-geodesic without conjugate points, thus establishing that the injectivity region is in some sense “star-shaped”), but again one needs to justify (6) in the sense of distributions in order to derive the monotonicity of Perelman reduced volume. This can again be done by use of barrier functions, perturbing the base point ")#mi("(0,x_0)")#text(" both spatially and also backwards in time by an epsilon. The details of this become rather technical; see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=2342013")[#text("paper of Ye")]#text(" or the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", for details.")

#text("Thus far we have only discussed how reduced length and reduced volume behave on smooth Ricci flows of compact manifolds. Of course, to fully establish the global existence of Ricci flow with surgery, one also needs to build an analogous theory for Ricci flows with surgery. Here there turns out to be significant new technical difficulties, basically because one has to restrict attention to paths ")#mi("\\gamma")#text(" which avoid all regions in which surgery is taking place. This creates some “holes” in the region of integration for the reduced volume, as in some cases the minimising path between two points in spacetime goes through a surgery region. Fortunately it turns out that (very roughly speaking) these holes only occur when the reduced length (or a somewhat technical modification thereof) is rather large, which means that the holes do not significantly impact lower bounds on this reduced volume, which is what is needed to establish ")#mi("\\kappa")#text("-noncollapsing. If time permits, I will discuss this issue further in later lectures, once we have described surgery in more detail.")

#text("In order to control ancient ")#mi("\\kappa")#text("-noncollapsing solutions, which are complete but not necessarily compact, one also needs to extend the above theory to complete non-compact manifolds. It turns out that this can be done as long as one has uniform bounds on curvature; a key task here is to establish that the reduced length ")#mi("l_{(0,x_0)}(-\\tau_1,x_1)")#text(" behaves roughly like ")#mi("d(x_0,x_1)^2/4\\tau_1")#text(" (which is basically what it is in the Euclidean case) as ")#mi("x_1")#text(" goes to infinity, which allows the integrand in the definition of reduced volume to have enough decay to justify all computations. The technical details here can be found in several places, including the ")#link("http://www.ams.org/mathscinet-getitem?mr=2342013")[#text("paper of Ye")]#text(", the ")#link("http://arxiv.org/abs/math.DG/0605667")[#text("notes of Kleiner-Lott")]#text(", the book of ")#link("http://www.ams.org/mathscinet-getitem?mr=2334563")[#text("Morgan-Tian")]#text(", and the ")#link("http://arxiv.org/abs/math/0612069")[#text("paper of Cao-Zhu")]#text(".")

#strong[#text("Remark 1.")]#text(" A theory analogous to Perelman’s theory above was worked out earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=834612")[#text("by Li and Yau")]#text(", but with the Ricci flow replaced by a static manifold with a lower bound on Ricci curvature, and with a time-dependent potential attached to the Laplacian. ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Borcherds")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29677")[#strong[#text("Richard Borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2008")])]

#text("You say the Bishop-Gromov reduced volume is a non-decreasing function of r. This should either be “non-increasing” or I’ve misunderstood your sign conventions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2008")])]

#text("Oops! Thanks for the correction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29750")[#strong[#text("285G, Lecture 11: κ-noncollapsing via Perelman reduced volume « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2008")])]

#text("[…] volume, Ricci flow Having established the monotonicity of the Perelman reduced volume in the previous lecture (after first heuristically justifying this monotonicity in Lecture 9), we now show how this can be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29878")[#strong[#text("This past two weeks… « It’s Equal, but It’s Different…")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2008")]

#text("[…] 285G, Lecture 10: Variation of L-geodesics, and monotonicity of Perelman reduced volume, 285G, Lecture 11: κ-noncollapsing via Perelman reduced volume, 285G, Lecture 12: High curvature regions of Ricci flow and κ-solutions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29895")[#strong[#text("285G, Lecture 13: Li-Yau-Hamilton Harnack inequalities and κ-solutions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2008")])]

#text("[…] u by the epsilon-regularisation trick. (Observe the similarity here with the -geodesic theory from Lecture 10.) By choosing to be the constant-speed minimising geodesic from to , we thus conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-29965")[#strong[#text("285G, Lecture 14: Stationary points of Perelman entropy or reduced volume are gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2008")])]

#text("[…] gave a proof of (13) in Lecture 10 using the second variation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-30086")[#strong[#text("285G, Lecture 15: Geometric limits of Ricci flows, and asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2008")])]

#text("[…] the other hand, from the proof of the monotonicity of reduced volume from Lecture 10 we have (formally, at […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-30137")[#strong[#text("285G, Lecture 16: Classification of asymptotic gradient shrinking solitons « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2008")])]

#text("[…] the other hand, from the second variation formula for distance (or more precisely, equation (21) of Lecture 10) and the non-negative sectional curvature assumption we have . (Actually one has to justify this in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-31212")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Dear Professor Tao:")

#text("Some basic questions about the notions of geodesic and cut locus.")

#text("I’ve read that the notion of distance on a manifold is measured in the tangent plane. Hence, does d(x_0, x) measured via (7) imply that measured in the tangent plane?")

#text("Call a point x and its cut point Cut(x) on a manifold. Call exp^(-1)(x) a tangent point and exp^(-1)(Cut(x)) a tangent cut point. Is the distance from a point to a cut point same as the distance from the tangent point to the tangent cut point?")

#text("In addition to above, denote the midpoint between x and Cut(x) by y. Is the distance between x and y same as the distance between the tangent point and a tangent cut point divided by 2?")

#text("Is Exp map restricted to tangent cut points bijective??? It is clearly surjective but how can one determine if it is also injective? In other words, how would one know if four tangent cut points all go to four different cut points or possibly all to a same cut point??? This last one has been in particular mystery to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-31214")[#strong[#text("ky")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Dear Professor Tao:")

#text("More basic questions:")

#text("Take a sphere S^2, pick a North Pole and get its tangent plane. Again, I will call the North Pole in the tangent plane the tangent point. The cut locus in the manifold is the antipodal point (South Pole) and the set of midpoints is the equatorial sphere. Now where is the tangent cut point? It’s right “beneath” the tangent point, is it not???")

#text("Continuing the case of S^2 above, around the tangent point in the tangent plane, I see a circle of radius 1 which is a union of infinitely many endpoints of vectors emanating from the tangent point. Is this circle the tangent cut locus or the equatorial sphere when taken to the manifold through Exponential map???")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-31232")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2008")])]

#text("Dear ky,")

#text("Given a fixed point ")#mi("x_0")#text(" on a manifold M, there are two metric structures in play: the metric structure on the tangent space ")#mi("T_{x_0} M")#text(" given by the bilinear form ")#mi("g(x_0)")#text(" (which, when viewed in an orthonormal frame, is isometric to Euclidean space); and the metric structure on the manifold itself, given by the metric d defined in (7). The exponential map ")#mi("\\exp_{x_0}: T_{x_0} M \\to M")#text(" preserves distances between pairs of points only along rays from the origin to the cut locus. Thus, ")#mi("d( \\exp_{x_0}(v), \\exp_{x_0}(w) ) = g(x_0)(v-w,v-w)^{1/2}")#text(" when v, w lie along a ray from the origin (and lie inside the cut locus), but in other situations one does not expect this equality to hold (although comparison geometry can yield some weak substitutes for this equality).")

#text("In general, I do not think that one can determine when two points on the cut locus map to the same point under the exponential map without using some global information about the manifold; just knowing the metric inside the cut locus is not going to be enough (there may be multiple ways to glue the boundary of this locus to itself). On the other hand, the exponential map is always injective in the interior region bounded by the cut locus.")

#text("In the case of a unit sphere, the cut locus bounds a disk of radius ")#mi("\\pi")#text(" in the tangent plane, and the exponential map maps the entire boundary of this disk (i.e. a circle of radius ")#mi("\\pi")#text(") to the antipodal point on the sphere. So there is no unique “tangent cut point” in this case – the entire cut locus is being mapped to the antipodal point.")

#text("It may be best to work through a textbook in Riemannian geometry (especially one with exercises) in order to have a firm grasp of these concepts. (A good textbook will also have some useful diagrams which should be helpful for visualising what is going on; this is hard to convey in this blog medium.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ky2168")]], [#link("https://terrytao.wordpress.com/2008/05/09/285g-lecture-10-variation-of-l-geodesics-and-monotonicity-of-perelman-reduced-volume/#comment-31236")[#strong[#text("ky2168")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2008")])]

#text("Dear Professor Tao:")

#text("I understood your explanations completely. Thank you so much for the detailed reply.")
]
