// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/
// Converted to Typst by tao2typ: "2026-10-14T15:20:58.402266+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Talks at the JMM", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Talks at the JMM")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 March 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/")[#text("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Earlier this year, I gave a series of lectures at the ")#link("https://www.jointmathematicsmeetings.org/meetings/national/jmm2024/2300_program.html")[#text("Joint Mathematics Meetings at San Francisco")]#text(". I am uploading here the slides for these talks:")

#list(
[#text("“")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/03/machine-jan-3.pdf")[#text("Machine assisted proof")]#text("” (")#link("https://www.youtube.com/watch?v=AayZuuDDKP0")[#text("Video here")]#text(")")],
[#text("“")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/03/periodic-tiling-jan-4.pdf")[#text("Translational tilings of Euclidean space")]#text("” (")#link("https://www.youtube.com/watch?v=QQBqJZtWIhA")[#text("Video here")]#text(")")],
[#text("“")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/03/correlations-jan-5.pdf")[#text("Correlations of multiplicative functions")]#text("” (")#link("https://www.youtube.com/watch?v=t_plilnbAtM")[#text("Video here")]#text(")")]
)

#text("I also have written a ")#link("https://terrytao.wordpress.com/wp-content/uploads/2024/03/machine-assisted-proof-notices.pdf")[#text("text version of the first talk")]#text(", which has been submitted to the Notices of the American Mathematical Society.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2024")])]

#text("first!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684583")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2024")])]

#text("Thanks for posting the Slides and Videos for your talks. A role model for other mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2024")])]

#link("https://mathoverflow.net/questions/467247/subgroup-of-p-adic-units")[#text("https://mathoverflow.net/questions/467247/subgroup-of-p-adic-units")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2024")])]

#text("Thanks for sharing!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2024")])]

#text("Corrections to AMS article (in order):")

#text("“use computers assist” -> “use computers to assist”")

#text("“recent proof of Gowers, Green, Manners and myself” -> [GGMT23] is not")#linebreak()#text("referenced, so add it here")

#text("“an superintelligent” -> “a superintelligent”")

#text("“The computation could produce incur numerical errors” -> delete “produce”")

#text("“each step in a maathematical proof” -> “… mathematical …”")

#text("“..“only“ eleven years..” -> bad double quotes")

#text("“measured to the influence” -> “measured the influence”")

#text("“results on other PDEs” -> “results of other PDEs”")

#text("“ubiquitious” -> “ubiquitous”")

#text("“scaleable” -> “scalable”")

#emph[#text("[Thanks, this will be incorporated into the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2024")])]

#text("Some possible errors in the AMS article:")

#text("“Mathematicians have relied on upon computers” – should possibly be “Mathematicians have relied on computers” or “Mathematicians have relied upon computers”.")

#text("“Theorem 0.1 (Boolean Pythaogrean triples” – should probably be “Theorem 0.1 (Boolean Pythagorean triples”.")

#text("“The computation could produce incur numerical errors” – should possibly be “The computation could produce numerical errors” or “The computation could incur numerical errors”.")

#emph[#text("[Thanks, these will be corrected in the final version of the ms -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2024")])]

#text("How are the logarithmically averaged Chowla conjecture for ")#mi("k=1")#text(" and the logarithmically averaged prime number theorem (")#mi("\\sum_{n le x} \\frac{\\Lambda(n)}{n} = \\log(x) - \\gamma +o(1)")#text(") related?")

#text("Are they equivalent? If not, what is the difference in light of the normal Chowla conjecture being equivalent to the normal prime number theorem?")

#text("Why doesn’t the logarithmically averaged prime number theorem have a similarly simple proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684642")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("The closest analogues here are the elementary bound ")#mi("\\sum_{n \\leq x} \\mu(n)/n = O(1)")#text(" and Mertens’ theorem ")#mi("\\sum_{n \\leq x} \\Lambda(n)/n = \\log x + O(1)")#text(", which are proven the same way: one computes ")#mi("\\sum_{n \\leq x} (\\sum_{d|n} f(d)) = \\sum_{d \\leq x} f(d) \\sum_{m \\leq x/d} 1")#text(" in two different ways for ")#mi("f = \\mu")#text(" and for ")#mi("f = \\Lambda")#text(". I think of Mertens’ theorem as the natural logarithmically averaged version of the PNT. The stronger asymptotic you mention is analogous to the strengthened k=1 Chowla bound ")#mi("\\sum_{n \\leq x} \\mu(n)/n = o(1)")#text(", which is elementarily equivalent to PNT. (Note by the way that Chowla only claims the far weaker bound ")#mi("o(\\log x)")#text(" here.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684609")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2024")])]

#text("I enjoyed the “machine assisted proof” talk. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684617")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2024")])]

#text("It was so great to meet you! Hope everything’s going well :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/03/17/talks-at-the-jmm/#comment-684619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2024")])]

#text("What do you think of Kirti Joshi’s proof of the abc conjecture?")
]
