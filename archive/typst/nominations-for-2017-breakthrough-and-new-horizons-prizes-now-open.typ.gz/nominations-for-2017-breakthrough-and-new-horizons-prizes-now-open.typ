// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/
// Converted to Typst by tao2typ: "2026-10-14T10:29:32.788893+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nominations for 2017 Breakthrough and New Horizons Prizes now open", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nominations for 2017 Breakthrough and New Horizons Prizes now open")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 March 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/")[#text("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Nominations for the 2017 ")#link("https://breakthroughprize.org/Prizes/3")[#text("Breakthrough Prize in mathematics and the New Horizons Prizes in mathematics")]#text(" are now open. In 2016, the Breakthrough Prize was awarded to ")#link("https://breakthroughprize.org/Laureates/3/L162")[#text("Ian Agol")]#text(". The New Horizons prizes are for breakthroughs given by junior mathematicians, usually restricted to within 10 years of PhD; the 2016 prizes were awarded to ")#link("https://breakthroughprize.org/Laureates/3/L164")[#text("Andre Neves")]#text(", ")#link("https://breakthroughprize.org/Laureates/3/L163")[#text("Larry Guth")]#text(", and Peter Scholze (declined).")

#text("The rules for the prizes are listed ")#link("https://breakthroughprize.org/Rules/3")[#text("on this page")]#text(", and nominations can be made at ")#link("https://breakthroughprize.org/index.php?controller=Authorize&action=login")[#text("this page")]#text(". (No self-nominations are allowed, for the obvious reasons; also, a third-party letter of recommendation is also required.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01031073bdeadeb34d79da2a4860f4c6d6ba7c6b022c91b0e0ad0147d3d8f1-4d3df87d63e4e43c76c701404830e66ca6dbc443ec829a4a507e9b9e47a9ffdf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RicPed")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466577")[#strong[#text("RicPed")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("I’m a little curious now, what are (usually) the main reasons behind a refusal of a prize?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24ad40f040b9fc12cc852cd3ade3e505bfa9acdf8b6d4324009a484299af09bc-0e6cf15bc83383a5ce6ecefd8a855607e41412c7cbd20aa578b46760c986b40f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noel Gardeli")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466926")[#strong[#text("Noel Gardeli")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2016")])]

#text("I just hope Scholze doesn’t decline the Fields Medal for 2018, so that I will see him here in Brazil! (at least, according to ")#link("https://www.quora.com/What-are-your-predictions-for-the-2018-Fields-Medals")[#text("https://www.quora.com/What-are-your-predictions-for-the-2018-Fields-Medals")]#text(" , he is a favourite)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466595")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("I found many passages in Hatcher’s “Algebraic Topology” hard-going. Especially when he constructs homology and cohomolgy. Really, Chapter 0 (and bits of 1) have sufficed for a long time :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466601")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("I wanted to nominate D.H.J. Polymath for the New Horizons prize but the form requires email registration. Oh well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("Perhaps also Nicolas Bourbaki.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466623")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("Yitang Zhang is the definition of breakthrough prize.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f29b4f88291f64bbe9284b9e40ae163fc0552fc093ce28e714f3bae40c87e37-6a6d109d161f3312c67f8832afe06c106d92876b7af8839086704e72d9aa23d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of João Rimu")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466639")[#strong[#text("João Rimu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("From the rules: “The Breakthrough Prize in Mathematics recognizes a single person’s contribution to the field of mathematics, with special attention to recent developments (Contribution to the field of mathematics in the last 10 years, although earlier contributions may also be taken into account).”")

#text("This is interesting, and it makes easier to predict who will win.")

#text("What where the top mathematical achievements in the last ten years?")

#text("In fact, Yitang Zhang is a very serious contender. Specially considering the latest prize was for work topology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f29b4f88291f64bbe9284b9e40ae163fc0552fc093ce28e714f3bae40c87e37-6a6d109d161f3312c67f8832afe06c106d92876b7af8839086704e72d9aa23d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of João Rimu")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-466640")[#strong[#text("João Rimu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("My prediction for the New Horizons Prize:")

#text("# James Maynard (Ph.D. from 2013)")#linebreak()#text(" # John Pardon (Ph.D. from 2015)")#linebreak()#text(" # Corinna Ulcigrai (Ph.D. from 2007)")

#text("What do you guys think about it? :D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02b4eb289656d249f3ac17a47756274cadcf583a4e70c2bab0a4a29df4b34ce5-083e4d1190f79ca88c30f372530490d13df0384502f94c2a1cd21cd2efea905f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MMP")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-490022")[#strong[#text("MMP")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("I think the time is for the works related to à la “Einstein” to make universe great again")

#link("https://vote.pollcode.com/64327489")[#text("https://vote.pollcode.com/64327489")]

#text("Peter Scholze")

#text("Simon Brendle")

#text("Hugo Duminil-Copin")

#text("Hassan Jolany")

#text("John Pardon")

#text("Péter Varjú")

#text("Wei Zhang")

#text("Adrian Ioana")

#text("Subhash Khot")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/03/02/nominations-for-2017-breakthrough-and-new-horizons-prizes-now-open/#comment-687393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2025")])]

#text("Right now Mark Zuckerberg is aligning with Trump agenda (at least partially) by disowning DEI initiatives.")

#text("Would this be morally enough for you to give back the Breakthrough Prize or step down from the committee (")#link("https://breakthroughprize.org/Committee/3")[#text("https://breakthroughprize.org/Committee/3")]#text(") or at least morally clarify your position in the bigger scheme of things?")

#text("We have come a long way from the ends justify the means.")
]
