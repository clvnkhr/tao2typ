// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/
// Converted to Typst by tao2typ: "2026-10-14T16:39:09.503076+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bounding sums or integrals of non-negative quantities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bounding sums or integrals of non-negative quantities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/")[#text("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A common task in analysis is to obtain bounds on sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} f(n)")]]

#text("or integrals")

#align(center)[#tao-fit-display[#mitex("\\int_A f(x)\\ dx")]]

#text("where ")#mi("{A}")#text(" is some simple region (such as an interval) in one or more dimensions, and ")#mi("{f}")#text(" is an explicit (and ")#link("https://en.wikipedia.org/wiki/Elementary_function")[#text("elementary")]#text(") non-negative expression involving one or more variables (such as ")#mi("{n}")#text(" or ")#mi("{x}")#text(", and possibly also some additional parameters. Often, one would be content with an order of magnitude upper bound such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} f(n) \\ll X")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\int_A f(x)\\ dx \\ll X")]]

#text("where we use ")#mi("{X \\ll Y}")#text(" (or ")#mi("{Y \\gg X}")#text(" or ")#mi("{X = O(Y)}")#text(") to denote the bound ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some constant ")#mi("{C}")#text("; sometimes one wishes to also obtain the matching lower bound, thus obtaining")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} f(n) \\asymp X")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\int_A f(x)\\ dx \\asymp X")]]

#text("where ")#mi("{X \\asymp Y}")#text(" is synonymous with ")#mi("{X \\ll Y \\ll X}")#text(". Finally, one may wish to obtain a more precise bound, such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} f(n) = (1+o(1)) X")]]

#text("where ")#mi("{o(1)}")#text(" is a quantity that goes to zero as the parameters of the problem go to infinity (or some other limit). (For a deeper dive into asymptotic notation in general, see ")#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")[#text("this previous blog post")]#text(".)")

#text("Here are some typical examples of such estimation problems, drawn from recent questions on MathOverflow:")

#list(
[#text("(i) (From ")#link("https://mathoverflow.net/questions/455537/does-this-dyadic-sum-converge")[#text("this question")]#text(") If ")#mi("{d,p \\geq 1}")#text(" and ")#mi("{a>d/p}")#text(", is the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{j \\in {\\bf Z}} 2^{(\\frac{d}{p}+1-a)j} \\int_0^\\infty e^{-2^j s} \\frac{s^a}{1+s^{2a}}\\ ds")]]

#text("finite?")],
[#text("(ii) (From ")#link("https://mathoverflow.net/questions/455545/how-to-show-that-the-trace-of-a-regularized-laplacian-defined-on-two-sphere-with")[#text("this question")]#text(") If ")#mi("{h,m \\geq 1}")#text(", how can one show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d=0}^\\infty \\frac{2d+1}{2h^2 (1 + \\frac{d(d+1)}{h^2}) (1 + \\frac{d(d+1)}{h^2m^2})^2} \\ll 1 + \\log(m^2)?")]]],
[#text("(iii) (From ")#link("https://mathoverflow.net/questions/454544/what-is-the-exact-asymptotic-bound-on-the-following-sum-of-polynomials#comment1176606_454544")[#text("this question")]#text(") Can one show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=1}^{n-1} \\frac{k^{2n-4k-3}(n^2-2nk+2k^2)}{(n-k)^{2n-4k-1}} = (c+o(1)) \\sqrt{n}")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for an explicit constant ")#mi("{c}")#text(", and what is this constant?")]
)

#text("Compared to other estimation tasks, such as that of controlling ")#link("https://en.wikipedia.org/wiki/Oscillatory_integral")[#text("oscillatory integrals")]#text(", ")#link("https://en.wikipedia.org/wiki/Exponential_sum")[#text("exponential sums")]#text(", ")#link("https://en.wikipedia.org/wiki/Singular_integral")[#text("singular integrals")]#text(", or expressions involving one or more unknown functions (that are only known to lie in some function spaces, such as an ")#mi("{L^p}")#text(" space), high-dimensional geometry (or alternatively, large numbers of random variables), or number-theoretic structures (such as the primes), estimation of sums or integrals of non-negative elementary expressions is a relatively straightforward task, and can be accomplished by a variety of methods. The art of obtaining such estimates is typically not explicitly taught in textbooks, other than through some examples and exercises; it is typically picked up by analysts (or those working in adjacent areas, such as PDE, combinatorics, or theoretical computer science) as graduate students, while they work through their thesis or their first few papers in the subject.")

#text("Somewhat in the spirit of ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("this previous post on analysis problem solving strategies")]#text(", I am going to try here to collect some general principles and techniques that I have found useful for these sorts of problems. As with the previous post, I hope this will be something of a living document, and encourage others to add their own tips or suggestions in the comments.")

#metadata(none) <tao-1e0cb6e56c75e4da8695>

#heading(level: 1)[#strong[#text(" — 1. Asymptotic arithmetic — ")]]

#text("Asymptotic notation is designed so that many of the usual rules of algebra and inequality manipulation continue to hold, with the caveat that one has to be careful if subtraction or division is involved. For instance, if one knows that ")#mi("{A \\ll X}")#text(" and ")#mi("{B \\ll Y}")#text(", then one can immediately conclude that ")#mi("{A + B \\ll X+Y}")#text(" and ")#mi("{AB \\ll XY}")#text(", even if ")#mi("{A,B}")#text(" are negative (note that the notation ")#mi("{A \\ll X}")#text(" or ")#mi("{B \\ll Y}")#text(" automatically forces ")#mi("{X,Y}")#text(" to be non-negative). Equivalently, we have the rules")

#align(center)[#tao-fit-display[#mitex("O(X) + O(Y) = O(X+Y); \\quad O(X) \\cdot O(Y) = O(XY)")]]

#text("and more generally we have the triangle inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_\\alpha O(X_\\alpha) = O( \\sum_\\alpha X_\\alpha ).")]]

#text("Again, we stress that this sort of rule implicitly requires the ")#mi("{X_\\alpha}")#text(" to be non-negative, and that claims such as ")#mi("{O(X) - O(Y) = O(X-Y)}")#text(" and ")#mi("{O(X)/O(Y) = O(X/Y)}")#text(" are simply ")#emph[#text("false")]#text(". As a rule of thumb, if your calculations have arrived at a situation where a signed or oscillating sum or integral appears ")#emph[#text("inside")]#text(" the big-O notation, or on the right-hand side of an estimate, without being “protected” by absolute value signs, then you have probably made a serious error in your calculations.")

#text("Another rule of inequalities that is inherited by asymptotic notation is that if one has two bounds ")#metadata(none) <tao-1f95bd2781224843f396>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A \\ll X; \\quad A \\ll Y")]]

#text(" ")#text(" for the same quantity ")#mi("{A}")#text(", then one can combine them into the unified asymptotic bound")

#metadata(none) <tao-1f6fa6f69d185e6086d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A \\ll \\min(X, Y).")]]

#text("This is an example of a “free move”: a replacement of bounds that does not lose any of the strength of the original bounds, since of course ")#link(<tao-1f6fa6f69d185e6086d0>)[#text("(2)")]#text(" implies ")#link(<tao-1f95bd2781224843f396>)[#text("(1)")]#text(". In contrast, other ways to combine the two bounds ")#link(<tao-1f95bd2781224843f396>)[#text("(1)")]#text(", such as taking the geometric mean")

#metadata(none) <tao-41835ff14ac6b8c789e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("A \\ll X^{1/2} Y^{1/2},")]]

#text("while often convenient, are not “free”: the bounds ")#link(<tao-1f95bd2781224843f396>)[#text("(1)")]#text(" imply the averaged bound ")#link(<tao-41835ff14ac6b8c789e9>)[#text("(3)")]#text(", but the bound ")#link(<tao-41835ff14ac6b8c789e9>)[#text("(3)")]#text(" does not imply ")#link(<tao-1f95bd2781224843f396>)[#text("(1)")]#text(". On the other hand, the inequality ")#link(<tao-1f6fa6f69d185e6086d0>)[#text("(2)")]#text(", while it does not concede any logical strength, can require more calculation to work with, often because one ends up splitting up cases such as ")#mi("{X \\ll Y}")#text(" and ")#mi("{X \\gg Y}")#text(" in order to simplify the minimum. So in practice, when trying to establish an estimate, one often starts with using conservative bounds such as ")#link(<tao-1f6fa6f69d185e6086d0>)[#text("(2)")]#text(" in order to maximize one’s chances of getting any proof (no matter how messy) of the desired estimate, and only after such a proof is found, one tries to look for more elegant approaches using less efficient bounds such as ")#link(<tao-41835ff14ac6b8c789e9>)[#text("(3)")]#text(".")

#text("For instance, suppose one wanted to show that the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=-\\infty}^\\infty \\frac{2^n}{(1+n^2) (1+2^{2n})}")]]

#text("was convergent. Lower bounding the denominator term ")#mi("{1+2^{2n}}")#text(" by ")#mi("{1}")#text(" or by ")#mi("{2^{2n}}")#text(", one obtains the bounds")

#metadata(none) <tao-ca0df2c95aa144c1d0ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{2^n}{(1+n^2) (1+2^{2n})} \\ll \\frac{2^n}{1+n^2}")]]

#text("and also")

#metadata(none) <tao-29c1b289e7522195b362>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{2^n}{(1+n^2) (1+2^{2n})} \\ll \\frac{2^n}{(1+n^2) 2^{2n}} = \\frac{2^{-n}}{1+n^2}")]]

#text("so by applying ")#link(<tao-1f6fa6f69d185e6086d0>)[#text("(2)")]#text(" we obtain the unified bound")

#align(center)[#tao-fit-display[#mitex("\\frac{2^n}{(1+n^2) (1+2^{2n})} \\ll \\frac{2^n}{(1+n^2) 2^{2n}} = \\frac{\\min(2^n,2^{-n})}{1+n^2}.")]]

#text("To deal with this bound, we can split into the two contributions ")#mi("{n \\geq 0}")#text(", where ")#mi("{2^{-n}}")#text(" dominates, and ")#mi("{n < 0}")#text(", where ")#mi("{2^n}")#text(" dominates. In the former case we see (from the ratio test, for instance) that the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=0}^\\infty \\frac{2^{-n}}{1+n^2}")]]

#text("is absolutely convergent, and in the latter case we see that the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=-\\infty}^{-1} \\frac{2^{n}}{1+n^2}")]]

#text("is also absolutely convergent, so the entire sum is absolutely convergent. But once one has this argument, one can try to streamline it, for instance by taking the geometric mean of ")#link(<tao-ca0df2c95aa144c1d0ff>)[#text("(4)")]#text(", ")#link(<tao-29c1b289e7522195b362>)[#text("(5)")]#text(" rather than the minimum to obtain the weaker bound")

#metadata(none) <tao-c3ccedf562d9529001d8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{2^n}{(1+n^2) (1+2^{2n})} \\ll \\frac{1}{1+n^2}")]]

#text("and now one can conclude without decomposition just by observing the absolute convergence of the doubly infinite sum ")#mi("{\\sum_{n=-\\infty}^\\infty \\frac{1}{1+n^2}}")#text(". This is a less “efficient” estimate, because one has conceded a lot of the decay in the summand by using ")#link(<tao-c3ccedf562d9529001d8>)[#text("(6)")]#text(" (the summand used to be exponentially decaying in ")#mi("{n}")#text(", but is now only polynomially decaying), but it is still sufficient for the purpose of establishing absolute convergence.")

#text("One of the key advantages of dealing with order of magnitude estimates, as opposed to sharp inequalities, is that the arithmetic becomes ")#link("https://en.wikipedia.org/wiki/Tropical_semiring")[#text("tropical")]#text(". More explicitly, we have the important rule")

#align(center)[#tao-fit-display[#mitex("X + Y \\asymp \\max(X,Y)")]]

#text("whenever ")#mi("{X,Y}")#text(" are non-negative, since we clearly have")

#align(center)[#tao-fit-display[#mitex("\\max(X,Y) \\leq X+Y \\leq 2 \\max(X,Y).")]]

#text("In particular, if ")#mi("{Y \\leq X}")#text(", then ")#mi("{O(X) + O(Y) = O(X)}")#text(". That is to say, given two orders of magnitudes, any term ")#mi("{O(Y)}")#text(" of equal or lower order to a “main term” ")#mi("{O(X)}")#text(" can be discarded. This is a very useful rule to keep in mind when trying to estimate sums or integrals, as it allows one to discard many terms that are not contributing to the final answer. It also interacts well with monotone operations, such as raising to a power ")#mi("{p}")#text("; for instance, we have")

#align(center)[#tao-fit-display[#mitex("(X+Y)^p \\asymp \\max(X,Y)^p = \\max(X^p,Y^p) \\asymp X^p + Y^p")]]

#text("if ")#mi("{X,Y \\geq 0}")#text(" and ")#mi("{p}")#text(" is a fixed positive constant, whilst")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X+Y} \\asymp \\frac{1}{\\max(X,Y)} = \\min(\\frac{1}{X}, \\frac{1}{Y})")]]

#text("if ")#mi("{X,Y>0}")#text(". Finally, this relation also sets up the fundamental ")#emph[#text("divide and conquer")]#text(" strategy for estimation: if one wants to prove a bound such as ")#mi("{A \\ll X}")#text(", it will suffice to obtain a decomposition")

#align(center)[#tao-fit-display[#mitex("A = A_1 + \\dots + A_k")]]

#text("or at least an upper bound")

#align(center)[#tao-fit-display[#mitex("A \\ll A_1 + \\dots + A_k")]]

#text("of ")#mi("{A}")#text(" by some bounded number of components ")#mi("{A_1,\\dots,A_k}")#text(", and establish the bounds ")#mi("{A_1 \\ll X, \\dots, A_k \\ll X}")#text(" separately. Typically the ")#mi("{A_1,\\dots,A_k}")#text(" will be (morally at least) smaller than the original quantity ")#mi("{A}")#text(" – for instance, if ")#mi("{A}")#text(" is a sum of non-negative quantities, each of the ")#mi("{A_i}")#text(" might be a subsum of those same quantities – which means that such a decomposition is a “free move”, in the sense that it does not risk making the problem harder. (This is because, if the original bound ")#mi("{A \\ll X}")#text(" is to be true, each of the new objectives ")#mi("{A_1 \\ll X, \\dots, A_k \\ll X}")#text(" must also be true, and so the decomposition can only make the problem logically easier, not harder.) The only costs to such decomposition are that your proofs might be ")#mi("{k}")#text(" times longer, as you may be repeating the same arguments ")#mi("{k}")#text(" times, and that the implied constants in the ")#mi("{A_1 \\ll X, \\dots, A_k \\ll X}")#text(" bounds may be worse than the implied constant in the original ")#mi("{A \\ll X}")#text(" bound. However, in many cases these costs are well worth the benefits of being able to simplify the problem into smaller pieces. As mentioned above, once one successfully executes a divide and conquer strategy, one can go back and try to reduce the number of decompositions, for instance by unifying components that are treated by similar methods, or by replacing strong but unwieldy estimates with weaker, but more convenient estimates.")

#text("The above divide and conquer strategy does not directly apply when one is decomposing into an unbounded number of pieces ")#mi("{A_j}")#text(", ")#mi("{j=1,2,\\dots}")#text(". In such cases, one needs an additional ")#emph[#text("gain")]#text(" in the index ")#mi("{j}")#text(" that is summable in ")#mi("{j}")#text(" in order to conclude. For instance, if one wants to establish a bound of the form ")#mi("{A \\ll X}")#text(", and one has located a decomposition or upper bound")

#align(center)[#tao-fit-display[#mitex("A \\ll \\sum_{j=1}^\\infty A_j")]]

#text("that looks promising for the problem, then it would suffice to obtain exponentially decaying bounds such as")

#align(center)[#tao-fit-display[#mitex("A_j \\ll 2^{-cj} X")]]

#text("for all ")#mi("{j \\geq 1}")#text(" and some constant ")#mi("{c>0}")#text(", since this would imply")

#metadata(none) <tao-dfa4813716a33c95e6ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("A \\ll \\sum_{j=1}^\\infty 2^{-cj} X \\ll X")]]

#text("thanks to the geometric series formula. (Here it is important that the implied constants in the asymptotic notation are uniform on ")#mi("{j}")#text("; a ")#mi("{j}")#text("-dependent bound such as ")#mi("{A_j \\ll_j 2^{-cj} X}")#text(" would be useless for this application, as then the growth of the implied constant in ")#mi("{j}")#text(" could overwhelm the exponential decay in the ")#mi("{2^{-cj}}")#text(" factor). Exponential decay is in fact overkill; polynomial decay such as")

#align(center)[#tao-fit-display[#mitex("A_j \\ll \\frac{X}{j^{1+c}}")]]

#text("would already be sufficient, although harmonic decay such")

#metadata(none) <tao-b7be8cc5abe9650d65b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("A_j \\ll \\frac{X}{j}")]]

#text("is not quite enough (the sum ")#mi("{\\sum_{j=1}^\\infty \\frac{1}{j}}")#text(" diverges logarithmically), although in many such situations one could try to still salvage the bound by working a lot harder to squeeze some additional logarithmic factors out of one’s estimates. For instance, if one can improve ")#link(<tao-b7be8cc5abe9650d65b7>)[#text("(8)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("A_j \\ll \\frac{X}{j \\log^{1+c} j}")]]

#text("for all ")#mi("{j \\geq 2}")#text(" and some constant ")#mi("{c>0}")#text(", since (by the integral test) the sum ")#mi("{\\sum_{j=2}^\\infty \\frac{1}{j\\log^{1+c} j}}")#text(" converges (and one can treat the ")#mi("{j=1}")#text(" term separately if one already has ")#link(<tao-b7be8cc5abe9650d65b7>)[#text("(8)")]#text(").")

#text("Sometimes, when trying to prove an estimate such as ")#mi("{A \\ll X}")#text(", one has identified a promising decomposition with an unbounded number of terms")

#align(center)[#tao-fit-display[#mitex("A \\ll \\sum_{j=1}^J A_j")]]

#text("(where ")#mi("{J}")#text(" is finite but unbounded) but is unsure of how to proceed next. Often the next thing to do is to study the extreme terms ")#mi("{A_1}")#text(" and ")#mi("{A_J}")#text(" of this decomposition, and first try to establish (the presumably simpler) tasks of showing that ")#mi("{A_1 \\ll X}")#text(" and ")#mi("{A_J \\ll X}")#text(". Often once one does so, it becomes clear how to combine the treatments of the two extreme cases to also treat the intermediate cases, obtaining a bound ")#mi("{A_j \\ll X}")#text(" for each individual term, leading to the inferior bound ")#mi("{A \\ll JX}")#text("; this can then be used as a starting point to hunt for additional gains, such as the exponential or polynomial gains mentioned previously, that could be used to remove this loss of ")#mi("{J}")#text(". (There are more advanced techniques, such as those based on controlling moments such as the square function ")#tao-math("{(\\sum_{j=1}^J \\left|A_j\\right|^2)^{1/2}}", block: false)#text(", or trying to understand the precise circumstances in which a “large values” scenario ")#tao-math("{\\left|A_j\\right| \\gg X}", block: false)#text(" occurs, and how these scenarios interact with each other for different ")#mi("{j}")#text(", but these are beyond the scope of this post, as they are rarely needed when dealing with sums or integrals of elementary functions.)")

#text("If one is faced with the task of estimating a doubly infinite sum ")#mi("{\\sum_{j=-\\infty}^\\infty A_j}")#text(", it can often be useful to first think about how one would proceed in estimating ")#mi("{A_j}")#text(" when ")#mi("{j}")#text(" is very large and positive, and how one would proceed when ")#mi("{j}")#text(" is very large and negative. In many cases, one can simply decompose the sum into two pieces such as ")#mi("{\\sum_{j=1}^\\infty A_j}")#text(" and ")#mi("{\\sum_{j=-\\infty}^{-1} A_j}")#text(" and use whatever methods you came up with to handle the two extreme cases; in some cases one also needs a third argument to handle the case when ")#mi("{j}")#text(" is of bounded (or somewhat bounded) size, in which case one may need to divide into three pieces such as ")#mi("{\\sum_{j=J_+}^\\infty A_j}")#text(", ")#mi("{\\sum_{j=-\\infty}^{J_-} A_j}")#text(", and ")#mi("{\\sum_{j=J_-+1}^{J_+-1} A_j}")#text(". Sometimes there will be a natural candidate for the places ")#mi("{J_-, J_+}")#text(" where one is cutting the sum, but in other situations it may be best to just leave these cut points as unspecified parameters initially, obtain bounds that depend on these parameters, and optimize at the end. (Typically, the optimization proceeds by trying to balance the magnitude of a term that is increasing with respect to a parameter, with one that is decreasing. For instance, if one ends up with a bound such as ")#mi("{A \\lambda + B/\\lambda}")#text(" for some parameter ")#mi("{\\lambda>0}")#text(" and quantities ")#mi("{A,B>0}")#text(", it makes sense to select ")#mi("{\\lambda = \\sqrt{B/A}}")#text(" to balance the two terms. Or, if faced with something like ")#mi("{A e^{-\\lambda} + \\lambda}")#text(" for some ")#mi("{A > 2}")#text(", then something like ")#mi("{\\lambda = \\log A}")#text(" would be close to the optimal choice of parameter. And so forth.)")

#heading(level: 1)[#strong[#text(" — 1.1. Psychological distinctions between exact and asymptotic arithmetic — ")]]

#text("The adoption of the “divide and conquer” strategy requires a certain mental shift from the “simplify, simplify” strategy that one is taught in high school algebra. In the latter strategy, one tries to collect terms in an expression make them as short as possible, for instance by working with a common denominator, with the idea that unified and elegant-looking expressions are “simpler” than sprawling expressions with many terms. In contrast, the divide and conquer strategy is ")#emph[#text("intentionally")]#text(" extremely willing to greatly increase the total length of the expressions to be estimated, so long as each individual component of the expressions appears easier to estimate than the original one. Both strategies are still trying to reduce the original problem to a simpler problem (or collection of simpler sub-problems), but the ")#emph[#text("metric")]#text(" by which one judges whether the problem has become simpler is rather different.")

#text("A related mental shift that one needs to adopt in analysis is to move away from the exact identities that are so prized in algebra (and in undergraduate calculus), as the precision they offer is often unnecessary and distracting for the task at hand, and often fail to generalize to more complicated contexts in which exact identities are no longer available. As a simple example, consider the task of estimating the expression")

#align(center)[#tao-fit-display[#mitex("\\int_0^a \\frac{dx}{1+x^2}")]]

#text("where ")#mi("{a > 0}")#text(" is a parameter. With a trigonometric substitution, one can evaluate this expression exactly as ")#mi("{\\mathrm{arctan}(a)}")#text(", however the presence of the arctangent can be inconvenient if one has to do further estimation tasks (for instance, if ")#mi("{a}")#text(" depends in a complicated fashion on other parameters, which one then also wants to sum or integrate over). Instead, by observing the trivial bounds")

#align(center)[#tao-fit-display[#mitex("\\int_0^a \\frac{dx}{1+x^2} \\leq \\int_0^a\\ dx = a")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_0^a \\frac{dx}{1+x^2} \\leq \\int_0^\\infty\\ \\frac{dx}{1+x^2} = \\frac{\\pi}{2}")]]

#text("one can combine them using ")#link(<tao-1f6fa6f69d185e6086d0>)[#text("(2)")]#text(" to obtain the upper bound")

#align(center)[#tao-fit-display[#mitex("\\int_0^a \\frac{dx}{1+x^2} \\leq \\min( a, \\frac{\\pi}{2} ) \\asymp \\min(a,1)")]]

#text("and similar arguments also give the matching lower bound, thus")

#metadata(none) <tao-6fcba5d96a4fadfdd630>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_0^a \\frac{dx}{1+x^2} \\asymp \\min(a,1).")]]

#text("This bound, while cruder than the exact answer of ")#mi("{\\mathrm{arctan}(a)}")#text(", is often good enough for many applications (particularly in situations where one is willing to concede constants in the bounds), and can be more tractible to work with than the exact answer. Furthermore, these arguments can be adapted without difficulty to treat similar expressions such as")

#align(center)[#tao-fit-display[#mitex("\\int_0^a \\frac{dx}{(1+x^2)^\\alpha}")]]

#text("for any fixed exponent ")#mi("{\\alpha>0}")#text(", which need not have closed form exact expressions in terms of elementary functions such as the arctangent when ")#mi("{\\alpha}")#text(" is non-integer.")

#text("As a general rule, instead of relying exclusively on exact formulae, one should seek approximations that are valid up to the degree of precision that one seeks in the final estimate. For instance, suppose one one wishes to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sec(x) - \\cos(x) = x^2 + O(x^3)")]]

#text("for all sufficiently small ")#mi("{x}")#text(". If one was clinging to the exact identity mindset, one could try to look for some trigonometric identity to simplify the left-hand side exactly, but the quicker (and more robust) way to proceed is just to use Taylor expansion up to the specified accuracy ")#mi("{O(x^3)}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\cos(x) = 1 - \\frac{x^2}{2} + O(x^3)")]]

#text("which one can invert using the geometric series formula ")#mi("{(1-y)^{-1} = 1 + y + y^2 + \\dots}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\sec(x) = 1 + \\frac{x^2}{2} + O(x^3)")]]

#text("from which the claim follows. (One could also have computed the Taylor expansion of ")#mi("{\\sec(x)}")#text(" by repeatedly differentiating the secant function, but as this is a series that is usually not memorized, this can take a little bit more time than just computing it directly to the required accuracy as indicated above.) Note that the notion of “specified accuracy” may have to be interpreted in a relative sense if one is planning to multiply or divide several estimates together. For instance, if one wishes to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sin(x) \\cos(x) = x + O(x^3)")]]

#text("for small ")#mi("{x}")#text(", one needs an approximation")

#align(center)[#tao-fit-display[#mitex("\\sin(x) = x + O(x^3)")]]

#text("to the sine function that is accurate to order ")#mi("{O(x^3)}")#text(", but one only needs an approximation")

#align(center)[#tao-fit-display[#mitex("\\cos(x) = 1 + O(x^2)")]]

#text("to the cosine function that is accurate to order ")#mi("{O(x^2)}")#text(", because the cosine is to be multiplied by ")#mi("{\\sin(x)= O(x)}")#text(". Here the key is to obtain estimates that have a ")#emph[#text("relative")]#text(" error of ")#mi("{O(x^2)}")#text(", compared to the main term (which is ")#mi("{1}")#text(" for cosine, and ")#mi("{x}")#text(" for sine).")

#text("The following table lists some common approximations that can be used to simplify expressions when one is only interested in order of magnitude bounds (with ")#mi("{c>0}")#text(" an arbitrary small constant):")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("The quantity…")],
table.cell(colspan: 1, rowspan: 1)[#text("has magnitude comparable to …")],
table.cell(colspan: 1, rowspan: 1)[#text("provided that…")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X+Y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0 \\leq Y \\ll X}")#text(" or ")#tao-math("{\\left|Y\\right| \\leq (1-c)X}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{X+Y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\max(X,Y)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X,Y \\geq 0}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sin z}")#text(", ")#mi("{\\tan z}")#text(", ")#mi("{e^{iz}-1}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\leq \\frac{\\pi}{2} - c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\cos z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\leq \\pi/2 - c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sin x}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\mathrm{dist}(x, \\pi {\\bf Z})}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x}")#text(" real")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^{ix}-1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\mathrm{dist}(x, 2\\pi {\\bf Z})}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{x}")#text(" real")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\mathrm{arcsin} x}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x\\right| \\leq 1-c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\log(1+z)}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\leq 1-c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^z-1}")#text(", ")#mi("{\\sinh z}")#text(", ")#mi("{\\tanh z}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\leq \\frac{\\pi}{2}-c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\cosh z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\leq \\frac{\\pi}{2}-c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sinh x}")#text(", ")#mi("{\\cosh x}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^x}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|x\\right| \\gg 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\tanh x}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\min(\\left|x\\right|, 1)}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{x}")#text(" real")],
table.cell(colspan: 1, rowspan: 1)[#mi("{(1+x)^a-1}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{a\\left|x\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{a \\gg 1}")#text(", ")#tao-math("{a \\left|x\\right| \\ll 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{n!}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{n^n e^{-n} \\sqrt{n}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{n \\geq 1}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma(s)}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|s^s e^{-s}\\right| / \\left|s\\right|^{1/2}}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|z\\right| \\gg 1}", block: false)#text(", ")#tao-math("{\\left|\\mathrm{arg} z\\right| \\leq \\frac{\\pi}{2} - c}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\Gamma(\\sigma+it)}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|t\\right|^{\\sigma-1/2} e^{-\\pi \\left|t\\right|/2}}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\sigma = O(1)}")#text(", ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\binom{n}{m}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{e^{n (p \\log \\frac{1}{p} + (1-p) \\log \\frac{1}{1-p})} / n^{1/2}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{m=pn}")#text(", ")#mi("{c < p < 1-c}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\binom{n}{m}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2^n e^{-2(m-n/2)^2} / n^{1/2}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{m = n/2 + O(n^{2/3})}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\binom{n}{m}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{n^m/m!}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{m \\ll \\sqrt{n}}")]
)

#text("On the other hand, some exact formulae are still very useful, particularly if the end result of that formula is clean and tractable to work with (as opposed to involving somewhat exotic functions such as the arctangent). The geometric series formula, for instance, is an extremely handy exact formula, so much so that it is often desirable to control summands by a geometric series purely to use this formula (we already saw an example of this in ")#link(<tao-dfa4813716a33c95e6ec>)[#text("(7)")]#text("). Exact integral identities, such as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{a} = \\int_0^\\infty e^{-at}\\ dt")]]

#text("or more generally")

#align(center)[#tao-fit-display[#mitex("\\frac{\\Gamma(s)}{a^s} = \\int_0^\\infty e^{-at} t^{s-1}\\ dt")]]

#text("for ")#mi("{a,s>0}")#text(" (where ")#mi("{\\Gamma}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(") are also quite commonly used, and fundamental exact integration rules such as the change of variables formula, the Fubini-Tonelli theorem or integration by parts are all esssential tools for an analyst trying to prove estimates. Because of this, it is often desirable to estimate a sum by an integral. The ")#link("https://en.wikipedia.org/wiki/Integral_test_for_convergence")[#text("integral test")]#text(" is a classic example of this principle in action: a more quantitative versions of this test is the bound")

#metadata(none) <tao-1a20f6d5510e063e9244>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\int_{a}^{b+1} f(t)\\ dt \\leq \\sum_{n=a}^b f(n) \\leq \\int_{a-1}^b f(t)\\ dt")]]

#text("whenever ")#mi("{a \\leq b}")#text(" are integers and ")#mi("{f: [a-1,b+1] \\rightarrow {\\bf R}}")#text(" is monotone decreasing, or the closely related bound")

#metadata(none) <tao-6e87fa7123bd4c2d887c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{a \\leq n \\leq b} f(n) = \\int_a^b f(t)\\ dt + O( \\left|f(a)\\right| + \\left|f(b)\\right| )", block: true)]]

#text("whenever ")#mi("{a \\geq b}")#text(" are reals and ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is monotone (either increasing or decreasing); see Lemma 2 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("this previous post")]#text(". Such bounds allow one to switch back and forth quite easily between sums and integrals as long as the summand or integrand behaves in a mostly monotone fashion (for instance, if it is monotone increasing on one portion of the domain and monotone decreasing on the other). For more precision, one could turn to more advanced relationships between sums and integrals, such as the ")#link("https://en.wikipedia.org/wiki/Euler%E2%80%93Maclaurin_formula")[#text("Euler-Maclaurin formula")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(", but these are beyond the scope of this post.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-50781ae6a4d70a21d399>#text(" Suppose ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}^+}")#text(" obeys the quasi-monotonicity property ")#mi("{f(x) \\ll f(y)}")#text(" whenever ")#mi("{y-1 \\leq x \\leq y}")#text(". Show that ")#mi("{\\int_a^{b-1} f(t)\\ dt \\ll \\sum_{n=a}^b f(n) \\ll \\int_a^{b+1} f(t)\\ dt}")#text(" for any integers ")#mi("{a < b}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-5e5adde0e206420f674e>#text(" Use ")#link(<tao-6e87fa7123bd4c2d887c>)[#text("(11)")]#text(" to obtain the “cheap ")#link("https://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling approximation")]#text("”")

#align(center)[#tao-fit-display[#mitex("n! = \\exp( n \\log n - n + O(\\log n) )")]]

#text("for any natural number ")#mi("{n \\geq 2}")#text(". (Hint: take logarithms to convert the product ")#mi("{n! = 1 \\times 2 \\times \\dots \\times n}")#text(" into a sum.)")
]

#text("With practice, you will be able to identify any term in a computation which is already “negligible” or “acceptable” in the sense that its contribution is always going to lead to an error that is smaller than the desired accuracy of the final estimate. One can then work “modulo” these negligible terms and discard them as soon as they appear. This can help remove a lot of clutter in one’s arguments. For instance, if one wishes to establish an asymptotic of the form")

#align(center)[#tao-fit-display[#mitex("A = X + O(Y)")]]

#text("for some main term ")#mi("{X}")#text(" and lower order error ")#mi("{O(Y)}")#text(", any component of ")#mi("{A}")#text(" that one can already identify to be of size ")#mi("{O(Y)}")#text(" is negligible and can be removed from ")#mi("{A}")#text(" “for free”. Conversely, it can be useful to ")#emph[#text("add")]#text(" negligible terms to an expression, if it makes the expression easier to work with. For instance, suppose one wants to estimate the expression")

#metadata(none) <tao-8dda2c32a15161da56a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n=1}^N \\frac{1}{n^2}.")]]

#text("This is a partial sum for the zeta function")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^2} = \\zeta(2) = \\frac{\\pi^2}{6}")]]

#text("so it can make sense to add and subtract the tail ")#mi("{\\sum_{n=N+1}^\\infty \\frac{1}{n^2}}")#text(" to the expression ")#link(<tao-8dda2c32a15161da56a4>)[#text("(12)")]#text(" to rewrite it as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\pi^2}{6} - \\sum_{n=N+1}^\\infty \\frac{1}{n^2}.")]]

#text("To deal with the tail, we switch from a sum to the integral using ")#link(<tao-1a20f6d5510e063e9244>)[#text("(10)")]#text(" to bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=N+1}^\\infty \\frac{1}{n^2} \\ll \\int_N^\\infty \\frac{1}{t^2}\\ dt = \\frac{1}{N}")]]

#text("giving us the reasonably accurate bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\frac{1}{n^2} = \\frac{\\pi^2}{6} - O(\\frac{1}{N}).")]]

#text("One can sharpen this approximation somewhat using ")#link(<tao-6e87fa7123bd4c2d887c>)[#text("(11)")]#text(" or the Euler–Maclaurin formula; we leave this to the interested reader.")

#text("Another psychological shift when switching from algebraic simplification problems to estimation problems is that one has to be prepared to let go of constraints in an expression that complicate the analysis. Suppose for instance we now wish to estimate the variant")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq N, \\text{ square-free}} \\frac{1}{n^2}")]]

#text("of ")#link(<tao-8dda2c32a15161da56a4>)[#text("(12)")]#text(", where we are now restricting ")#mi("{n}")#text(" to be ")#link("https://en.wikipedia.org/wiki/Square-free_integer")[#text("square-free")]#text(". An identity from analytic number theory (the ")#link("https://en.wikipedia.org/wiki/Euler_product")[#text("Euler product identity")]#text(") lets us calculate the exact sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\geq 1, \\text{ square-free}} \\frac{1}{n^2} = \\frac{\\zeta(2)}{\\zeta(4)} = \\frac{15}{\\pi^2}")]]

#text("so as before we can write the desired expression as")

#align(center)[#tao-fit-display[#mitex("\\frac{15}{\\pi^2} - \\sum_{n > N, \\text{ square-free}} \\frac{1}{n^2}.")]]

#text("Previously, we applied the integral test ")#link(<tao-1a20f6d5510e063e9244>)[#text("(10)")]#text(", but this time we cannot do so, because the restriction to square-free integers destroys the monotonicity. But we can simply remove this restriction:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n > N, \\text{ square-free}} \\frac{1}{n^2} \\leq \\sum_{n > N} \\frac{1}{n^2}.")]]

#text("Heuristically at least, this move only “costs us a constant”, since a positive fraction (")#mi("{1/\\zeta(2)= 6/\\pi^2}")#text(", in fact) of all integers are square-free. Now that this constraint has been removed, we can use the integral test as before and obtain the reasonably accurate asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq n \\leq N, \\text{ square-free}} \\frac{1}{n^2} = \\frac{15}{\\pi^2} + O(\\frac{1}{N}).")]]

#heading(level: 1)[#strong[#text(" — 2. More on decomposition — ")]]

#text("The way in which one decomposes a sum or integral such as ")#mi("{\\sum_{n \\in A} f(n)}")#text(" or ")#mi("{\\int_A f(x)\\ dx}")#text(" is often guided by the “geometry” of ")#mi("{f}")#text(", and in particular where ")#mi("{f}")#text(" is large or small (or whether various component terms in ")#mi("{f}")#text(" are large or small relative to each other). For instance, if ")#mi("{f(x)}")#text(" comes close to a maximum at some point ")#mi("{x=x_0}")#text(", then it may make sense to decompose based on the distance ")#tao-math("{\\left|x-x_0\\right|}", block: false)#text(" to ")#mi("{x_0}")#text(", or perhaps to treat the cases ")#mi("{x \\leq x_0}")#text(" and ")#mi("{x>x_0}")#text(" separately. (Note that ")#mi("{x_0}")#text(" does not ")#emph[#text("literally")]#text(" have to be the maximum in order for this to be a reasonable decomposition; if it is in “within reasonable distance” of the maximum, this could still be a good move. As such, it is often not worthwhile to try to compute the maximum of ")#mi("{f}")#text(" ")#emph[#text("exactly")]#text(", especially if this exact formula ends up being too complicated to be useful.)")

#text("If an expression involves a distance ")#tao-math("{\\left|X-Y\\right|}", block: false)#text(" between two quantities ")#mi("{X,Y}")#text(", it is sometimes useful to split into the case ")#tao-math("{\\left|X\\right| \\leq \\left|Y\\right|/2}", block: false)#text(" where ")#mi("{X}")#text(" is much smaller than ")#mi("{Y}")#text(" (so that ")#tao-math("{\\left|X-Y\\right| \\asymp \\left|Y\\right|}", block: false)#text("), the case ")#tao-math("{\\left|Y\\right| \\leq \\left|X\\right|/2}", block: false)#text(" where ")#mi("{Y}")#text(" is much smaller than ")#mi("{X}")#text(" (so that ")#tao-math("{\\left|X-Y\\right| \\asymp \\left|X\\right|}", block: false)#text("), or the case when neither of the two previous cases apply (so that ")#tao-math("{\\left|X\\right| \\asymp \\left|Y\\right|}", block: false)#text("). The factors of ")#mi("{2}")#text(" here are not of critical importance; the point is that in each of these three cases, one has some hope of simplifying the expression into something more tractable. For instance, suppose one wants to estimate the expression ")#metadata(none) <tao-c23a85f58858f6b0917d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\int_{-\\infty}^\\infty \\frac{dx}{(1+(x-a)^2) (1+(x-b)^2)}")]]

#text(" ")#text(" in terms of the two real parameters ")#mi("{a, b}")#text(", which we will take to be distinct for sake of this discussion. This particular integral is simple enough that it can be evaluated exactly (for instance using contour integration techniques), but in the spirit of Principle 1, let us avoid doing so and instead try to decompose this expression into simpler pieces. A graph of the integrand reveals that it peaks when ")#mi("{x}")#text(" is near ")#mi("{a}")#text(" or near ")#mi("{b}")#text(". Inspired by this, one can decompose the region of integration into three pieces:")

#list(
[#text("(i) The region where ")#tao-math("{\\left|x-a\\right| \\leq \\frac{\\left|a-b\\right|}{2}}", block: false)#text(".")],
[#text("(ii) The region where ")#tao-math("{\\left|x-b\\right| \\leq \\frac{\\left|a-b\\right|}{2}}", block: false)#text(".")],
[#text("(iii) The region where ")#tao-math("{\\left|x-a\\right|, \\left|x-b\\right| > \\frac{\\left|a-b\\right|}{2}}", block: false)#text(".")]
)

#text("(This is not the only way to cut up the integral, but it will suffice. Often there is no “canonical” or “elegant” way to perform the decomposition; one should just try to find a decomposition that is convenient for the problem at hand.)")

#text("The reason why we want to perform such a decomposition is that in each of the three cases, one can simplify how the integrand depends on ")#mi("{x}")#text(". For instance, in region (i), we see from the triangle inequality that ")#tao-math("{\\left|x-b\\right|}", block: false)#text(" is now comparable to ")#tao-math("{\\left|a-b\\right|}", block: false)#text(", so that this contribution to ")#link(<tao-c23a85f58858f6b0917d>)[#text("(13)")]#text(" is comparable to")

#align(center)[#tao-fit-display[#tao-math("\\asymp \\int_{\\left|x-a\\right| \\leq \\left|a-b\\right|/2} \\frac{dx}{(1+(x-a)^2) (1+(a-b)^2)}.", block: true)]]

#text("Using a variant of ")#link(<tao-6fcba5d96a4fadfdd630>)[#text("(9)")]#text(", this expression is comparable to")

#metadata(none) <tao-28720365c5e7476a011e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\asymp \\min( 1, \\left|a-b\\right|/2) \\frac{1}{1+(a-b)^2} \\asymp \\frac{\\min(1, \\left|a-b\\right|)}{1+(a-b)^2}.", block: true)]]

#text("The contribution of region (ii) can be handled similarly, and is also comparable to ")#link(<tao-28720365c5e7476a011e>)[#text("(14)")]#text(". Finally, in region (iii), we see from the triangle inequality that ")#tao-math("{\\left|x-a\\right|, \\left|x-b\\right|}", block: false)#text(" are now comparable to each other, and so the contribution of this region is comparable to")

#align(center)[#tao-fit-display[#tao-math("\\asymp \\int_{\\left|x-a\\right|, \\left|x-b\\right| > \\left|a-b\\right|/2} \\frac{dx}{(1+(x-a)^2)^2}.", block: true)]]

#text("Now that we have centered the integral around ")#mi("{x=a}")#text(", we will discard the ")#tao-math("{\\left|x-b\\right| > \\left|a-b\\right|/2}", block: false)#text(" constraint, upper bounding this integral by")

#align(center)[#tao-fit-display[#tao-math("\\asymp \\int_{\\left|x-a\\right| > \\left|a-b\\right|/2} \\frac{dx}{(1+(x-a)^2)^2}.", block: true)]]

#text("On the one hand this integral is bounded by")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^\\infty \\frac{dx}{(1+(x-a)^2)^2} = \\int_{-\\infty}^\\infty \\frac{dx}{(1+x^2)^2} \\asymp 1")]]

#text("and on the other hand we can bound")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|x-a\\right| > \\left|a-b\\right|/2} \\frac{dx}{(1+(x-a)^2)^2} \\leq \\int_{\\left|x-a\\right| > \\left|a-b\\right|/2} \\frac{dx}{(x-a)^4}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\asymp \\left|a-b\\right|^{-3}", block: true)]]

#text("and so we can bound the contribution of (iii) by ")#tao-math("{O( \\min( 1, \\left|a-b\\right|^{-3} ))}", block: false)#text(". Putting all this together, and dividing into the cases ")#tao-math("{\\left|a-b\\right| \\leq 1}", block: false)#text(" and ")#tao-math("{\\left|a-b\\right| > 1}", block: false)#text(", one can soon obtain a total bound of ")#tao-math("{O(\\min( 1, \\left|a-b\\right|^{-2}))}", block: false)#text(" for the entire integral. One can also adapt this argument to show that this bound is sharp up to constants, thus")

#align(center)[#tao-fit-display[#tao-math("\\int_{-\\infty}^\\infty \\frac{dx}{(1+(x-a)^2) (1+(x-b)^2)} \\asymp \\min( 1, \\left|a-b\\right|^{-2})", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\asymp \\frac{1}{1+\\left|a-b\\right|^2}.", block: true)]]

#text("A powerful and common type of decomposition is ")#emph[#text("dyadic decomposition")]#text(". If the summand or integrand involves some quantity ")#mi("{Q}")#text(" in a key way, it is often useful to break up into dyadic regions such as ")#mi("{2^{j-1} \\leq Q < 2^{j}}")#text(", so that ")#mi("{Q \\sim 2^j}")#text(", and then sum over ")#mi("{j}")#text(". (One can tweak the dyadic range ")#mi("{2^{j-1} \\leq Q < 2^{j}}")#text(" here with minor variants such as ")#mi("{2^{j} < Q \\leq 2^{j+1}}")#text(", or replace the base ")#mi("{2}")#text(" by some other base, but these modifications mostly have a minor aesthetic impact on the arguments at best.) For instance, one could break up a sum ")#metadata(none) <tao-c7455cbed273010cc850>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{n=1}^{\\infty} f(n)")]]

#text(" ")#text(" into dyadic pieces")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^\\infty \\sum_{2^{j-1} \\leq n < 2^{j}} f(n)")]]

#text("and then seek to estimate each dyadic block ")#mi("{\\sum_{2^{j-1} \\leq n < 2^{j}} f(n)}")#text(" separately (hoping to get some exponential or polynomial decay in ")#mi("{j}")#text("). The classical technique of ")#link("https://en.wikipedia.org/wiki/Cauchy_condensation_test")[#text("Cauchy condensation")]#text(" is a basic example of this strategy. But one can also dyadically decompose other quantities than ")#mi("{n}")#text(". For instance one can perform a “vertical” dyadic decomposition (in contrast to the “horizontal” one just performed) by rewriting ")#link(<tao-c7455cbed273010cc850>)[#text("(15)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{k \\in {\\bf Z}} \\sum_{n \\geq 1: 2^{k-1} \\leq f(n) < 2^k} f(n);")]]

#text("since the summand ")#mi("{f(n)}")#text(" is ")#mi("{\\asymp 2^k}")#text(", we may simplify this to")

#align(center)[#tao-fit-display[#mitex("\\asymp \\sum_{k \\in {\\bf Z}} 2^k \\# \\{ n \\geq 1: 2^{k-1} \\leq f(n) < 2^k\\}.")]]

#text("This now converts the problem of estimating the sum ")#link(<tao-c7455cbed273010cc850>)[#text("(15)")]#text(" to the more combinatorial problem of estimating the size of the dyadic level sets ")#mi("{\\{ n \\geq 1: 2^{k-1} \\leq f(n) < 2^k\\}}")#text(" for various ")#mi("{k}")#text(". In a similar spirit, we have")

#align(center)[#tao-fit-display[#tao-math("\\int_A f(x)\\ dx \\asymp \\sum_{k \\in {\\bf Z}} 2^k \\left| \\{ x \\in A: 2^{k-1} \\leq f(x) < 2^k \\}\\right|", block: true)]]

#text("where ")#tao-math("{\\left|E\\right|}", block: false)#text(" denotes the Lebesgue measure of a set ")#mi("{E}")#text(", and now we are faced with a geometric problem of estimating the measure of some explicit set. This allows one to use geometric intuition to solve the problem, instead of multivariable calculus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{S}")#text(" be a smooth compact submanifold of ")#mi("{{\\bf R}^d}")#text(". Establish the bound")

#align(center)[#tao-fit-display[#mitex("\\int_{B(0,C)} \\frac{dx}{\\varepsilon^2 + \\mathrm{dist}(x,S)^2} \\ll \\varepsilon^{-1}")]]

#text("for all ")#mi("{0 < \\varepsilon < C}")#text(", where the implied constants are allowed to depend on ")#mi("{C, d, S}")#text(". (This can be accomplished either by a vertical dyadic decomposition, or a dyadic decomposition of the quantity ")#mi("{\\mathrm{dist}(x,S)}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Solve problem (ii) from the introduction to this post by dyadically decomposing in the ")#mi("{d}")#text(" variable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" By such tools as ")#link(<tao-1a20f6d5510e063e9244>)[#text("(10)")]#text(", ")#link(<tao-6e87fa7123bd4c2d887c>)[#text("(11)")]#text(", or Exercise ")#link(<tao-50781ae6a4d70a21d399>)[#text("1")]#text(", one could convert the dyadic sums one obtains from dyadic decomposition into integral variants. However, if one wished, one could “cut out the middle-man” and work with continuous dyadic decompositions rather than discrete ones. Indeed, from the integral identity")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty 1_{\\lambda < Q \\leq 2\\lambda} \\frac{d\\lambda}{\\lambda} = \\log 2")]]

#text("for any ")#mi("{Q>0}")#text(", together with the Fubini–Tonelli theorem, we obtain the continuous dyadic decomposition")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} f(n) = \\int_0^\\infty \\sum_{n \\in A: \\lambda \\leq Q(n) < 2\\lambda} f(n)\\ \\frac{d\\lambda}{\\lambda}")]]

#text("for any quantity ")#mi("{Q(n)}")#text(" that is positive whenever ")#mi("{f(n)}")#text(" is positive. Similarly if we work with integrals ")#mi("{\\int_A f(x)\\ dx}")#text(" rather than sums. This version of dyadic decomposition is occasionally a little more convenient to work with, particularly if one then wants to perform various changes of variables in the ")#mi("{\\lambda}")#text(" parameter which would be tricky to execute if this were a discrete variable.")
]

#heading(level: 1)[#strong[#text(" — 3. Exponential weights — ")]]

#text("Many sums involve expressions that are “exponentially large” or “exponentially small” in some parameter. A basic rule of thumb is that any quantity that is “exponentially small” will likely give a negligible contribution when compared against quantities that are not exponentially small. For instance, if an expression involves a term of the form ")#mi("{e^{-Q}}")#text(" for some non-negative quantity ")#mi("{Q}")#text(", which can be bounded on at least one portion of the domain of summation or integration, then one expects the region where ")#mi("{Q}")#text(" is bounded to provide the dominant contribution. For instance, if one wishes to estimate the integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-\\varepsilon x} \\frac{dx}{1+x}")]]

#text("for some ")#mi("{0 < \\varepsilon < 1/2}")#text(", this heuristic suggests that the dominant contribution should come from the region ")#mi("{x = O(1/\\varepsilon)}")#text(", in which one can bound ")#mi("{e^{-\\varepsilon x}}")#text(" simply by ")#mi("{1}")#text(" and obtain an upper bound of")

#align(center)[#tao-fit-display[#mitex("\\ll \\int_{x = O(1/\\varepsilon)} \\frac{dx}{1+x} \\ll \\log \\frac{1}{\\varepsilon}.")]]

#text("To make such a heuristic precise, one can perform a dyadic decomposition in the exponential weight ")#mi("{e^{-\\varepsilon x}}")#text(", or equivalently perform an additive decomposition in the exponent ")#mi("{\\varepsilon x}")#text(", for instance writing")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-\\varepsilon x} \\frac{dx}{1+x} = \\sum_{j=1}^\\infty \\int_{j-1 \\leq \\varepsilon x < j} e^{-\\varepsilon x} \\frac{dx}{1+x}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Use this decomposition to rigorously establish the bound")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-\\varepsilon x} \\frac{dx}{1+x} \\ll \\log \\frac{1}{\\varepsilon}")]]

#text("for any ")#mi("{0 < \\varepsilon < 1/2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Solve problem (i) from the introduction to this post.")
]

#text("More generally, if one is working with a sum or integral such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A} e^{\\phi(n)} \\psi(n)")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("\\int_A e^{\\phi(x)} \\psi(x)\\ dx")]]

#text("with some exponential weight ")#mi("{e^\\phi}")#text(" and a lower order amplitude ")#mi("{\\psi}")#text(", then one typically expects the dominant contribution to come from the region where ")#mi("{\\phi}")#text(" comes close to attaining its maximal value. If this maximum is attained on the boundary, then one typically has geometric series behavior away from the boundary, and one can often get a good estimate by obtaining geometric series type behavior. For instance, suppose one wants to estimate the error function")

#align(center)[#tao-fit-display[#mitex("\\mathrm{erf}(z) = \\frac{2}{\\sqrt{\\pi}} \\int_0^z e^{-t^2}\\ dt")]]

#text("for ")#mi("{z \\geq 1}")#text(". In view of the complete integral")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-t^2}\\ dt = \\frac{\\sqrt{\\pi}}{2}")]]

#text("we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{erf}(z) = 1 - \\frac{2}{\\sqrt{\\pi}} \\int_z^\\infty e^{-t^2}\\ dt.")]]

#text("The exponential weight ")#mi("{e^{-t^2}}")#text(" attains its maximum at the left endpoint ")#mi("{t=z}")#text(" and decays quickly away from that endpoint. One could estimate this by dyadic decomposition of ")#mi("{e^{-t^2}}")#text(" as discussed previously, but a slicker way to proceed here is to use the convexity of ")#mi("{t^2}")#text(" to obtain a geometric series upper bound")

#align(center)[#tao-fit-display[#mitex("e^{-t^2} \\leq e^{-z^2 - 2 z (t-z)}")]]

#text("for ")#mi("{t \\geq z}")#text(", which on integration gives")

#align(center)[#tao-fit-display[#mitex("\\int_z^\\infty e^{-t^2}\\ dt \\leq \\int_z^\\infty e^{-z^2 - 2 z (t-z)}\\ dt = \\frac{e^{-z^2}}{2z}")]]

#text("giving the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\mathrm{erf}(z) = 1 - O( \\frac{e^{-z^2}}{z})")]]

#text("for ")#mi("{z \\geq 1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" In the converse direction, establish the upper bound")

#align(center)[#tao-fit-display[#mitex("\\mathrm{erf}(z) \\leq 1 - c \\frac{e^{-z^2}}{z}")]]

#text("for some absolute constant ")#mi("{c>0}")#text(" and all ")#mi("{z \\geq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" If ")#mi("{\\theta n \\leq m \\leq n}")#text(" for some ")#mi("{1/2 < \\theta < 1}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=m}^n \\binom{n}{k} \\ll \\frac{1}{2\\theta-1} \\binom{n}{m}.")]]

#text("(")#emph[#text("Hint:")]#text(" estimate the ratio between consecutive binomial coefficients ")#mi("{\\binom{n}{k}}")#text(" and then control the sum by a geometric series).")
]

#text("When the maximum of the exponent ")#mi("{\\phi}")#text(" occurs in the interior of the region of summation or integration, then one can get good results by some version of ")#link("https://en.wikipedia.org/wiki/Laplace%27s_method")[#text("Laplace’s method")]#text(". For simplicity we will discuss this method in the context of one-dimensional integrals")

#align(center)[#tao-fit-display[#mitex("\\int_a^b e^{\\phi(x)} \\psi(x)\\ dx")]]

#text("where ")#mi("{\\phi}")#text(" attains a non-degenerate global maximum at some interior point ")#mi("{x = x_0}")#text(". The rule of thumb here is that")

#align(center)[#tao-fit-display[#tao-math("\\int_a^b e^{\\phi(x)} \\psi(x)\\ dx \\approx \\sqrt{\\frac{2\\pi}{\\left|\\phi^{\\prime\\prime}(x_0)\\right|}} e^{\\phi(x_0)} \\psi(x_0).", block: true)]]

#text("The heuristic justification is as follows. The main contribution should be when ")#mi("{x}")#text(" is close to ")#mi("{x_0}")#text(". Here we can perform a Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\phi(x) \\approx \\phi(x_0) - \\frac{1}{2} |\\phi^{\\prime\\prime}(x_0)| (x-x_0)^2")]]

#text("since at a non-degenerate maximum we have ")#mi("{\\phi^{\\prime}(x_0)=0}")#text(" and ")#mi("{\\phi^{\\prime\\prime}(x_0) > 0}")#text(". Also, if ")#mi("{\\psi}")#text(" is continuous, then ")#mi("{\\psi(x) \\approx \\psi(x_0)}")#text(" when ")#mi("{x}")#text(" is close to ")#mi("{x_0}")#text(". Thus we should be able to estimate the above integral by the gaussian integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} e^{\\phi(x_0) - \\frac{1}{2} |\\phi^{\\prime\\prime}(x_0)| (x-x_0)^2} \\psi(x_0)\\ dx")]]

#text("which can be computed to equal ")#tao-math("{\\sqrt{\\frac{2\\pi}{\\left|\\phi^{\\prime\\prime}(x_0)\\right|}} e^{\\phi(x_0)} \\psi(x_0)}", block: false)#text(" as desired.")

#text("Let us illustrate how this argument can be made rigorous by considering the task of estimating the factorial ")#mi("{n!}")#text(" of a large number. In contrast to what we did in Exercise ")#link(<tao-5e5adde0e206420f674e>)[#text("2")]#text(", we will proceed using a version of Laplace’s method, relying on the integral representation")

#align(center)[#tao-fit-display[#mitex("n! = \\Gamma(n+1) = \\int_0^\\infty x^n e^{-x}\\ dx.")]]

#text("As ")#mi("{n}")#text(" is large, we will consider ")#mi("{x^n}")#text(" to be part of the exponential weight rather than the amplitude, writing this expression as")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty e^{-\\phi(x)}\\ dx")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\phi(x) = x - n \\log x.")]]

#text("The function ")#mi("{\\phi}")#text(" attains a global maximum at ")#mi("{x_0 = n}")#text(", with ")#mi("{\\phi^{\\prime}(n) = 0}")#text(" and ")#mi("{\\phi^{\\prime\\prime}(n) = 1/n}")#text(". We will therefore decompose this integral into three pieces")

#metadata(none) <tao-bfffcce68cbb01759777>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\int_0^{n-R} e^{-\\phi(x)}\\ dx + \\int_{n-R}^{n+R} e^{-\\phi(x)}\\ dx + \\int_{n+R}^\\infty e^{-\\phi(x)}\\ dx")]]

#text("where ")#mi("{0 < R < n}")#text(" is a radius parameter which we will choose later, as it is not immediately obvious for now what the optimal value of this parameter is (although the previous heuristics do suggest that ")#tao-math("{R \\approx 1 / \\left|\\phi^{\\prime\\prime}(x_0)\\right|^{1/2}}", block: false)#text(" might be a reasonable choice).")

#text("The main term is expected to be the middle term, so we shall use crude methods to bound the other two terms. For the first part where ")#mi("{0 < x \\leq n-R}")#text(", ")#mi("{\\phi}")#text(" is increasing so we can crudely bound ")#mi("{e^{-\\phi(x)} \\leq e^{-\\phi(n-R)}}")#text(" and thus")

#align(center)[#tao-fit-display[#mitex("\\int_0^{n-R} e^{-\\phi(x)}\\ dx \\leq (n-R) e^{-\\phi(n-R)} \\leq n e^{-\\phi(n-R)}.")]]

#text("(We expect ")#mi("{R}")#text(" to be much smaller than ")#mi("{n}")#text(", so there is not much point to saving the tiny ")#mi("{-R}")#text(" term in the ")#mi("{n-R}")#text(" factor.) For the third part where ")#mi("{x \\geq n+R}")#text(", ")#mi("{\\phi}")#text(" is decreasing, but bounding ")#mi("{e^{-\\phi(x)}}")#text(" by ")#mi("{e^{-\\phi(n+R)}}")#text(" would not work because of the unbounded nature of ")#mi("{x}")#text("; some additional decay is needed. Fortunately, we have a strict increase")

#align(center)[#tao-fit-display[#mitex("\\phi^{\\prime}(x) = 1 - \\frac{n}{x} \\geq 1 - \\frac{n}{n+R} = \\frac{R}{n+R}")]]

#text("for ")#mi("{x \\geq n+R}")#text(", so by the intermediate value theorem we have")

#align(center)[#tao-fit-display[#mitex("\\phi(x) \\geq \\phi(n+R) + \\frac{R}{n+R} (x-n-R)")]]

#text("and after a short calculation this gives")

#align(center)[#tao-fit-display[#mitex("\\int_{n+R}^\\infty e^{-\\phi(x)}\\ dx \\leq \\frac{n+R}{R} e^{-\\phi(n+R)} \\ll \\frac{n}{R} e^{-\\phi(n+R)}.")]]

#text("Now we turn to the important middle term. If we assume ")#mi("{R \\leq n/2}")#text(", then we will have ")#mi("{\\phi^{\\prime\\prime\\prime}(x) = O( 1/n^2 )}")#text(" in the region ")#mi("{n-R \\leq x \\leq n+R}")#text(", so by Taylor’s theorem with remainder")

#tao-aligned(keep: true)[


#tao-math("\\phi(x)  & = \\phi(n) + \\phi^{\\prime}(n) (x-n) + \\frac{1}{2} \\phi^{\\prime\\prime}(n) (x-n)^2 + O( \\frac{\\left|x-n\\right|^3}{n^2} )", block: true)



#tao-math(" & = \\phi(n) + \\frac{(x-n)^2}{2n} + O( \\frac{R^3}{n^2} ).", block: true)
]

#text("If we assume that ")#mi("{R = O(n^{2/3})}")#text(", then the error term is bounded and we can exponentiate to obtain")

#metadata(none) <tao-461e35a9bfb0c7ef6f50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("e^{-\\phi(x)} = (1 + O(\\frac{R^3}{n^2})) e^{-\\phi(n) - \\frac{(x-n)^2}{2n}}")]]

#text("for ")#mi("{n-R \\leq x \\leq n+R}")#text(" and hence")

#align(center)[#tao-fit-display[#mitex("\\int_{n-R}^{n+R} e^{-\\phi(x)}\\ dx = (1 + O(\\frac{R^3}{n^2})) e^{-\\phi(n)} \\int_{n-R}^{n+R} e^{-(x-n)^2/2n}\\ dx.")]]

#text("If we also assume that ")#mi("{R \\gg \\sqrt{n}}")#text(", we can use the error function type estimates from before to estimate")

#align(center)[#tao-fit-display[#mitex("\\int_{n-R}^{n+R} e^{-(x-n)^2/2n}\\ dx = \\sqrt{2\\pi n} + O( \\frac{n}{R} e^{-R^2/2n} ).")]]

#text("Putting all this together, and using ")#link(<tao-461e35a9bfb0c7ef6f50>)[#text("(17)")]#text(" to estimate ")#mi("{e^{-\\phi(n \\pm R)} \\ll e^{-\\phi(n) - \\frac{R^2}{2n}}}")#text(", we conclude that")

#tao-aligned(keep: true)[


#tao-math("n!  & = e^{-\\phi(n)} ( (1 + O(\\frac{R^3}{n^2})) \\sqrt{2\\pi n} + O( \\frac{n}{R} e^{-R^2/2n})", block: true)



#tao-math(" & + O( n e^{-R^2/2n} ) + O( \\frac{n}{R} e^{-R^2/2n} ) )", block: true)



#tao-math(" & = e^{-n+n \\log n} (\\sqrt{2\\pi n} + O( \\frac{R^2}{n} + n e^{-R^2/2n} ))", block: true)
]

#text("so if we select ")#mi("{R=n^{2/3}}")#text(" for instance, we obtain the ")#link("https://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling approximation")]

#align(center)[#tao-fit-display[#mitex("n! = \\frac{n^n}{e^n} (\\sqrt{2\\pi n} + O( n^{1/3}) ).")]]

#text("One can improve the error term by a finer decomposition than ")#link(<tao-bfffcce68cbb01759777>)[#text("(16)")]#text("; we leave this as an exercise to the interested reader.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" It can be convenient to do some initial rescalings to this analysis to achieve a nice normalization; see ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous blog post")]#text(" for details.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Solve problem (iii) from the introduction. (")#emph[#text("Hint:")]#text(" extract out the term ")#mi("{\\frac{k^{2n-4k}}{(n-k)^{2n-4k}}}")#text(" to write as the exponential factor ")#mi("{e^{\\phi(k)}}")#text(", placing all the other terms (which are of polynomial size) in the amplitude function ")#mi("{\\psi(k)}")#text(". The function ")#mi("{\\phi}")#text(" will then attain a maximum at ")#mi("{k=n/2}")#text("; perform a Taylor expansion and mimic the arguments above.)")
]

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("Last time I checked, $latex \\int \\frac{1}{x^4+1}dx is solvable in elementary functions :) very nice post regardless!")

#emph[#text("[Fair enough; example modified. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681888")[#strong[#text("William Maugham")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")]

#text("What is the target audience of this post?")#linebreak()#text(" Asking for my inner child.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17091d4a03d31ec4dcf328fd4d4d32db71be5b910e8d970cb06458f485a78ee0-f9203420c8451af72d62b1b2b4d5e95ce44a69b089d67063cdb25ebaac827640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of emmanuel")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681890")[#strong[#text("emmanuel")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2023")])]

#text("mistyping in eq. 10 ($\\sum$ instead of $\\int$).")#linebreak()#text(" Very nice and useful post, interesting for students and teachers alike.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ef416d4d65005c8c948ba1d552bca5b19817468eb0dee8254d21e31a58194c6-223b876ebec382062e2d73b2f69e1cb83720cbf9b4506b21b5e50432ab15b78f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681891")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")])]

#text("A couple of trivial typos:")#linebreak()#text(" – There’s an extra close-paren in the square function ")#tao-math("(\\sum_{j=1}^J\\left|A_j\\right|^2)^{1/2}", block: false)#linebreak()#text(" – There are a couple of hanging HTML tags, first in the Laplace integral, and second in the paragraph preceding the ")#mi("n!=\\Gamma(n+1)")#text(" display.")

#text("Also, thanks for typing this up! I remember being very confused about how to understand estimates of the form ")#mi("A\\lesssim B+C")#text(", until I realized that the right-hand side might as well be the tropical sum instead – especially good in some asymptotic settings when you can divide into regimes where either ")#mi("B=o(C)")#text(" or ")#mi("C=o(B)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")])]

#text("I like the balance between rigour and playful writing – thanks for a good read!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58144a90cb0af96a00e1ca65bd48516be8248a85a021c7037ab2c6dd27865b9b-8d0d5da389f68b19796f849703c9a482a554b4b2654d42084b5b851f421deec5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kunal Chawla")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681894")[#strong[#text("Kunal Chawla")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")])]

#text("Typo after exercise 9")

#text("<a href=\"")#link("https://en.wikipedia.org/wiki/Laplace")[#text("https://en.wikipedia.org/wiki/Laplace")]

#text("has no closing tag.")

#text("This was a great read! I'm sure I'll revisit it a few times while preparing for generals")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681895")[#strong[#text("GitHub Copilot让陶哲轩感到“不安” – AI 資訊")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")]

#text("[…] 参考链接：[1]https://mastodon.social/@tao@mathstodon.xyz/111158220516679670[2]https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2023")])]

#text("“One could also have computed the Taylor expansion of {\\sec(x)} directly, but … this can take a little bit more time than just computing it [the Taylor expansion?] directly…” -> perhaps this sentence could be rewritten?")

#emph[#text("[Rewritten, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681898")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Typo, I think: the statement:")

#text("“… the triangle inequality \\displaystyle \\sum_\\alpha O(X_\\alpha) = O( \\sum_\\alpha X_\\alpha ) …”")

#text("includes an equals sign, rather than an inequality.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681903")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("This is intentional. There is a useful convention that expressions such as ")#mi("O(X) + O(Y) = O(X+Y)")#text(" that involve asymptotic notation on both sides should be interpreted as saying “any expression which is of the form of the left-hand side, is also of the form of the right-hand side”. This breaks the symmetry of the equality symbol ")#mi("=")#text(", but one gains the ability to chain many such identities together, which ends up being a net win when doing analysis. I discuss this more in my previous blog post ")#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")[#text("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681920")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("Thanks for your reply. However, this seems to be more in the realm of “apologetics” than “explication”! The overloading of the poor equality symbol, to mean something so vastly different from what Robert Recorde intended by it, certainly will create more confusion than necessary. Why not invent another symbol for “is of the same form as” or (to coin a term) “iso-formal”? (Perhaps patterned somewhat on the two parallel line segments of the equals sign, as has been done for so many other mathematical concepts, e.g. equivalence, approximately equal, modular congruence, etc. E.g. an “F” with two parallel horizontal arms of equal length.) Surely doing so would help reduce confusion and increase our clarity of expression!")

#text("Thank you also for the practical guidance given by your post on asymptotic notation, which many mathematics students struggle to make sense of.")

#emph[#text("[See my previous post ")#link("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")[#text("https://terrytao.wordpress.com/2022/05/10/partially-specified-mathematical-objects-ambient-parameters-and-asymptotic-notation/")]#text(" , where I propose the use of two symbols == and = to denote the two types of equality, and argue that the usage I indicate here is closer to that captured by the mathematical English verb “is”, e.g., “odd + odd = even”. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8ba38b00d9b995f8af73bcb4496496fe1a96a0db20191f290a7b061325dc3e-5f6bb55c5f5c5e7e885ddd26df2209a39bdc5d2e7c6899a3b180448eb1fce7f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron F.")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-682093")[#strong[#text("Aaron F.")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2023")])]

#text("(Whoops, wrong MathJax delimiters before.)")

#text("I always think of ")#mi("O(X)")#text(" as a set of functions within some implicitly or explicitly specified world of functions, making it natural to use notation like ")#mi("f \\in O(X)")#text(" and ")#mi("O(X) + O(Y) \\subset O(X + Y)")#text(". I can then use the equals sign to say that two sets of functions are the same: for example, ")#mi("r \\to 0")#text(" asymptotic classes obey equations like ")#mi("O(r) + O(r^3) = O(r)")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681899")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("I haven’t read this yet, but I remember looking for math books on asymptotics and found very few results, there didn’t seem to be any popular textbooks on the topic. I found this disappointing because it seems like a useful and powerful technique used in a wide range of fields. The class that taught me the most about asymptotic analysis was actually a very theoretical algorithms course from the computer science department.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681900")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("My Discontinuous Analysis discovery is about analysis of asymptotics. One way to describe Discontinuous Analysis is as taking limits at all ultrafilters in vicinity of a point simultaneously.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://teachsector.com/discontinuous-analysis/")[#text("Discontinuous Analysis")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681907")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("Why Terry hasn’t blocked you yet is beyond me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/241c453790595b86bfacace439c11d51734e27a0fa7d0509cd39bddcb0433175-1408306db5ec056703f5973b9650a0fb0e172c2f55f752d168b118b0f8839f7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian D-B")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681902")[#strong[#text("Ian D-B")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")])]

#text("I think in the example raising to a power $p$, I think you need $p \\ge 0$? The next example kind of shows why.")

#text("I raise this because it comes up in some work I’ve done in economics. We very often — as in, almost any paper you could look at — have sums of powers like this. Specifically, expected utility is a sum or integral of some sort of power (or occasionally exponential) of a random variable, and our canonical function mapping a firm’s inputs to its outputs is a sum of powers (the constant elasticity of substitution production function).")

#emph[#text("[Clarified that ")#mi("p")#text(" is intended to be non-negative. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2023")])]

#text("In the Stirling approximation formula, on the righr side of equation it should be n^n instead of n!")#linebreak()#text(" Thank you for very interesting post!")

#text("Aleksander")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681931")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("i say this with all my good intentions;")#linebreak()#text(" this is just a wishy washy mess that no one really needs.")#linebreak()#text(" who ordered this ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f0b9a908987dfdfc75dae02356a635e8ff78f8d3d1ca98913514ae4baf88d46-d00c0befd789903b432aea6071945fa92bf8636b4820e83fbd2e6a03dea15f9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681938")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2023")])]

#text("In exercise 3, the bound should be ")#mi("\\epsilon^{-1}")#text(" instead of ")#mi("\\epsilon")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2023")])]

#text("In the equation below (5), should max be min?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2023")])]

#text("Does anyone have an intuition behind the approximation of ")#mi("\\int_a^b e^{\\phi(x)} \\psi(x)\\lambda(\\mathrm{d}x)")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2023")])]

#text("“elemEntary” -> “elementary” in first paragraph")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2023")])]

#text("At the beginning of the section “Asymptotic Arithmetic,” if A << X and B << Y, I don't think we can conclude AB << XY. For example, if A = B = –100, but X = Y = 0.")

#emph[#text("[Read the definition of the ")#mi("\\ll")#text(" notation carefully – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681967")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2023")])]

#text("Title of the article: “Bounding sums or integrals of *non-negative* quantities”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach Hunter")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-681971")[#strong[#text("Zach Hunter")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("“whenver”-> “whenever”. “praticular”-> “particular”.")

#text("“\\eqre{ajx}”-> “\\eqref{ajx}” (presumably).")

#text("“par ticularly”-> “particularly”.")

#text("“$\\phi'(x_)$”-> “$\\phi'(x_0)$” when discussing Laplace stuff.")

#text("[Nitpick] you say there is no obvious choice for the radius ‘$R$’. but wouldn’t the Laplace heuristic suggest that ‘$R ~ \\sqrt{1/\\phi”(x_0)}$’ is appropriate?")

#emph[#text("[Corrections made, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-682666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2023")])]

#text("I repeat, p ≥ 5 (mod6) and combinatorics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-682667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2023")])]

#text("great work! Terrence Tao. bless, you are, your incredible mind will acomplish wonders")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-682827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2024")])]

#text("Hello!")#linebreak()#text(" If ")#tao-math("\\left|a-b\\right|>1", block: false)#text(" then (14) reads ")#mi("\\frac 1{1+(a-b)^2}")#text(" and ")#tao-math("\\left|a-b\\right|^{-3}<1", block: false)#text(", but then the integral follows their sum ")#tao-math("\\frac 1{1+(a-b)^2} + \\left|a-b\\right|^{-3}", block: false)#text(" that is comparable with ")#mi("\\frac 1{1+(a-b)^2}")#text(", so how can the final result be ")#tao-math("O(\\min(1,\\left|a-b\\right|^{-3}))", block: false)#text(" that is not comparable with ")#mi("\\frac 1{1+(a-b)^2}")#text("?")

#emph[#text("[Oops, the exponents have now been corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-684458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2024")])]

#text("Thank you for this masterful lesson. Right before equation (16), where it says “with {\\phi(n) = 0},” it should read “with {\\phi^\\prime(n) = 0}”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-692666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2026")])]

#text("A small typo: ”establsh” should be ”establish”.")

#text("The Stirling’s formula is mentioned in this great post- I’d like to ask that: Why is Stirling’s formula particularly suitable for estimating or analyzing discrete random walks?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-692676")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2026")])]

#text("Thanks for the correction!")

#text("The combinatorics of discrete random walks often involve binomial coefficients, which are well-suited to analysis via Stirling’s formula. The ")#link("https://en.wikipedia.org/wiki/De_Moivre%E2%80%93Laplace_theorem")[#text("De Moivre-Laplace theorem")]#text(" is an early example of this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-693155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("Dear Prof. Tao,")

#text("“A_j is very large and negative”- isn’t A_j non-negative?")

#text("After reading the brilliant third section of this article, a thought suddenly struck me: if we also express the integral of the probability density function of the standard normal distribution, ∫(1/√(2π)) e^{-x²/2} dx, in the form of the error function—1/2 + 1/2 erf(t/√2)—does this offer any advantages in analyzing results in probability theory compared to the traditional perspective? In particular, the third section also mentions arguments and principles related to estimating the error function, This made me even more curious!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-693157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("The typo has been corrected.")

#text("As far as asymptotic analysis is concerned, the error function isn’t actually all that useful, as it doesn’t obey too many useful identities; it tends to be better to just work with integral expressions of Gaussians directly. It’s more useful in real-world applications, where one can precompute the error function (or create highly optimized routines to calculate it) instead of having to compute various different integrals of gaussian type functions all the time.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/09/30/bounding-sums-or-integrals-of-non-negative-quantities/#comment-693179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2026")])]

#text("Dear Professor Tao,")

#text("​I follow your blog daily. As a high schooler, your work showed me that mathematics is alive and exploratory—inspiring me to build ")#emph[#text("Beyond the Answer")]#text(" (")#link("https://9z76k3.csb.app/")[#text("https://9z76k3.csb.app/")]#text(") purely because I needed to see these ideas move.")

#text("​Exhibit III animates a \\zeta(s) spiral crossing the origin at \\sigma = 0.5. The first time I saw it, I finally understood why mathematicians find this beautiful.")

#text("​I know your time is precious, but even a single line of feedback on Exhibit III would mean the world to me. Thank you so much!")
]
