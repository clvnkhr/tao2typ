// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:17:00.121655+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The high exponent limit $p \\to \\infty$ for the one-dimensional nonlinear wave equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The high exponent limit $p \\to \\infty$ for the one-dimensional nonlinear wave equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/")[#text("https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0901.3548")[#text("The high exponent limit $p \\to \\infty$ for the one-dimensional nonlinear wave equation")]#text("“, submitted to ")#link("http://pjm.math.berkeley.edu/apde/about/journal/about.html")[#text("Analysis & PDE")]#text(". This paper concerns an under-explored limit for the Cauchy problem")

#tao-math("\\displaystyle -\\phi_{tt} + \\phi_{xx} = \\left|\\phi\\right|^{p-1} \\phi; \\quad \\phi(0,x) = \\phi_0(x); \\quad \\phi_t(0,x) = \\phi_1(x)", block: false)#text(" (1)")

#text("to the one-dimensional defocusing nonlinear wave equation, where ")#mi("\\phi: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb R}")#text(" is the unknown scalar field, ")#mi("p > 1")#text(" is an exponent, and ")#mi("\\phi_0, \\phi_1: {\\Bbb R} \\to {\\Bbb R}")#text(" are the initial position and velocity respectively, and the t and x subscripts denote differentiation in time and space. To avoid some (extremely minor) technical difficulties let us assume that p is an odd integer, so that the nonlinearity is smooth; then standard energy methods, relying in particular on the conserved energy")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("E(\\phi)(t) = \\int_{\\Bbb R} \\frac{1}{2} \\left|\\phi_t(t,x)\\right|^2 + \\frac{1}{2} \\left|\\phi_x(t,x)\\right|^2 + \\frac{1}{p+1} \\left|\\phi(t,x)\\right|^{p+1}\\ dx,", block: true)]]

#text("on finite speed of propagation, and on the one-dimensional Sobolev embedding ")#mi("H^1({\\Bbb R}) \\subset L^\\infty({\\Bbb R})")#text(", show that from any smooth initial data ")#mi("\\phi_0, \\phi_1")#text(", there is a unique global smooth solution ")#mi("\\phi")#text(" to the Cauchy problem (1).")

#text("It is then natural to ask how the solution ")#mi("\\phi")#text(" behaves under various asymptotic limits. Popular limits for these sorts of PDE include the ")#emph[#text("asymptotic time limit")]#text(" ")#mi("t \\to \\pm \\infty")#text(", the ")#emph[#text("non-relativistic limit")]#text(" ")#mi("c \\to \\infty")#text(" (where we insert suitable powers of c into various terms in (1)), the ")#emph[#text("small dispersion limit")]#text(" (where we place a small factor in front of the dispersive term ")#mi("+\\phi_{xx}")#text("), the ")#emph[#text("high-frequency limit")]#text(" (where we send the frequency of the initial data ")#mi("\\phi_0, \\phi_1")#text(" to infinity), and so forth.")

#link("http://www.math.ucla.edu/~triroy/")[#text("Tristan Roy")]#text(" recently posed to me a different type of limit, which to the best of my knowledge has not been explored much in the literature (although some of the literature on limits of the ")#link("http://en.wikipedia.org/wiki/Ginzburg-Landau_theory")[#text("Ginzburg-Landau equation")]#text(" has a somewhat similar flavour): the ")#emph[#text("high exponent limit")]#text(" ")#mi("p \\to \\infty")#text(" (holding the initial data ")#mi("\\phi_0, \\phi_1")#text(" fixed). From (1) it is intuitively plausible that as p increases, the nonlinearity gets “stronger” when ")#tao-math("\\left|\\phi\\right| > 1", block: false)#text(" and “weaker” when ")#tao-math("\\left|\\phi\\right| < 1", block: false)#text("; the “limiting equation”")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("-\\phi_{tt} + \\phi_{xx} = \\left|\\phi\\right|^{\\infty} \\phi; \\quad \\phi(0,x) = \\phi_0(x); \\quad \\phi_t(0,x) = \\phi_1(x)", block: true)]]

#text("would then be expected to be linear when ")#tao-math("\\left|\\phi\\right| < 1", block: false)#text(" and infinitely repulsive when ")#tao-math("\\left|\\phi\\right| > 1", block: false)#text(" (i.e. in the limit, the solution should be confined to range in the interval [-1,1], much as is the case with linear wave and Schrödinger equations with an infinite barrier potential; though with the key difference that the nonlinear barrier in (3) is confining the ")#emph[#text("range")]#text(" of ")#mi("\\phi")#text(" rather than the ")#emph[#text("domain")]#text(".).")

#text("Of course, the equation (3) does not make rigorous sense as written; we need to formalise what an “infinite nonlinear barrier” is, and how the wave ")#mi("\\phi")#text(" will react to that barrier (e.g. will it reflect off of it, or be absorbed?). So the questions are to find the correct description of the limiting equation, and to rigorously demonstrate that solutions to (1) converge in some sense to that equation.")

#text("It is natural to require that ")#mi("\\phi_0")#text(" stays away from the barrier, in the sense that ")#tao-math("\\left|\\phi_0(x)\\right| < 1", block: false)#text(" for all x; in particular this implies that the energy (2) stays (locally) bounded as ")#mi("p \\to \\infty")#text("; it also ensures that (1) converges in a satisfactory sense to the free wave equation for sufficiently short times. For technical reasons we also have to make a mild assumption that either of the null energy densities ")#mi("\\phi_1 \\pm \\partial_x \\phi_0")#text(" vanish on a set with at most finitely many connected components. The main result is then that as ")#mi("p \\to \\infty")#text(", the solution ")#mi("\\phi = \\phi^{(p)}")#text(" to (1) converges locally uniformly to a Lipschitz, piecewise smooth limit ")#mi("\\phi = \\phi^{(\\infty)}")#text(", which is restricted to take values in [-1,1], with ")#mi("-\\phi_{tt}+\\phi_{xx}")#text(" (interpreted in a weak sense) being a negative measure supported on ")#mi("\\{ \\phi=+1\\}")#text(" plus a positive measure supported on ")#mi("\\{\\phi = -1\\}")#text(". Furthermore, we have the reflection conditions")

#align(center)[#tao-math("\\displaystyle (\\partial_t \\pm \\partial_x) \\left|\\phi_t \\mp \\phi_x\\right| = 0", block: false)#text(".")]

#text("It turns out that the above conditions uniquely determine ")#mi("\\phi")#text(", and one can even solve for ")#mi("\\phi")#text(" explicitly for any given data; such solutions start off smooth but pick up an increasing number of (Lipschitz continuous) singularities over time as they reflect back and forth across the nonlinear barriers ")#mi("\\{\\phi=+1\\}")#text(" and ")#mi("\\{\\phi=-1\\}")#text(". (An explicit example of such a reflection is given in the paper.)")

#text("[The above conditions vaguely resemble entropy conditions, as appear for instance in kinetic formulations of conservation laws, though I do not know of a precise connection in this regard.]")

#text("In the remainder of this post I would like to describe the strategy of proof and one of the key a priori bounds needed. I also want to point out the connection to ")#link("http://en.wikipedia.org/wiki/Liouville%27s_equation")[#text("Liouville’s equation")]#text(", which was discussed in the ")#link("https://terrytao.wordpress.com/2009/01/22/an-explicitly-solvable-nonlinear-wave-equation/")[#text("previous post")]#text(".")

#heading(level: 1)[#metadata(none) <tao-148efff0e6cbd6ead751>#text("— Strategy —")]

#text("The top level strategy is based on compactness methods: first show that the family ")#mi("\\phi^{(p)}")#text(" of solutions is compact in a suitable topology, show that any limit point ")#mi("\\phi")#text(" of these solutions obeys the properties stated above, and then show that these properties uniquely determine the limit ")#mi("\\phi")#text(".")

#text("The compactness (in the local uniform topology) is easy, coming from the ")#link("http://en.wikipedia.org/wiki/Ascoli%27s_Theorem")[#text("Arzelà-Ascoli theorem")]#text(" and energy conservation (and relies crucially on the fact that the one-dimensional NLW (1) remains subcritical even as ")#mi("p \\to \\infty")#text("; I do not know what to predict in the critical case of two dimensions, or the supercritical case of higher dimensions). The uniqueness is also not too difficult, as one can solve for ")#mi("\\phi")#text(" obeying these conditions by quite classical means based on the ")#link("http://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(" (i.e. following the solution along null rays) and the fundamental theorem of calculus. The main difficulty is to show that a limit point ")#mi("\\phi")#text(" of the solutions ")#mi("\\phi^{(p)}")#text(" actually do satisfy all of the properties listed above. For this, it turns out to be necessary to establish a number of ")#emph[#text("a priori")]#text(" estimates on ")#mi("\\phi^{(p)}")#text(" and its first derivatives that will survive the passage to the limit. Some of these estimates are based on the pointwise conservation laws for Liouville’s equation that I discussed in the previous post; but now I want to turn to another key estimate, namely the pointwise estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\phi^{(p)}(t,x)\\right| \\leq 1 + \\frac{\\log p}{p} + O( \\frac{1}{p} )", block: true)]]

#text("as ")#mi("p \\to \\infty")#text(", which of course will keep the limiting solution ")#mi("\\phi^{(\\infty)}")#text(" confined to range in the interval [-1,1]. This bound turns out to be best possible, and is important in bounding the nonlinear effects of (1) (for instance, it implies that the nonlinear term in (1) is pointwise bounded by O(p) ).")

#text("The connection to the Liouville equation arises from the ")#link("http://en.wikipedia.org/wiki/Ansatz")[#text("ansatz")]

#align(center)[#tao-fit-display[#mitex("\\phi^{(p)} = p^{1/(p-1)} (1 + \\frac{1}{p} \\psi( p t, p x ) )")]]

#text("then (1) becomes (for positive ")#mi("\\phi")#text(")")

#align(center)[#tao-fit-display[#mitex("-\\psi_{tt} + \\psi_{xx} = (1 + \\frac{1}{p} \\psi)^p")]]

#text("which formally converges to the Liouville equation ")#mi("- \\psi_{tt} + \\psi_{xx} = e^\\psi")#text(" in the limit ")#mi("p \\to -\\infty")#text(". For comparison, the estimate (4) corresponds in this ansatz to an upper bound ")#mi("\\psi \\leq O(1)")#text(" on ")#mi("\\psi")#text(".")

#heading(level: 1)[#text("— Confinement —")]

#text("Now we prove (4). To simplify the discussion let us assume that ")#mi("\\phi = \\phi^{(p)}")#text(" is always non-negative (one can restrict to this case by sign reversal symmetry, finite speed of propagation, and energy conservation). As in the previous post, it is convenient to work in null coordinates")

#align(center)[#tao-fit-display[#mitex("u = t+x, v = t-x")]]

#text("in which case the equation (1) becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\phi_{uv} = - \\frac{1}{4} \\phi^p.")]]

#text("In particular, ")#mi("\\phi_u")#text(" is decreasing in the v direction, and ")#mi("\\phi_v")#text(" is decreasing in the u direction. With fixed initial data, this gives us an upper bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\phi_u, \\phi_v \\leq O(1)")]]

#text("uniformly in p.")

#text("Now suppose that ")#mi("(t_0,x_0)")#text(" is the first time and place in which (4) fails, in the sense that")

#align(center)[#tao-fit-display[#mitex("\\phi(t_0,x_0) = 1 + \\frac{\\log p}{p} + \\frac{K}{p}")]]

#text("for some large constant K. Then from (6) we know that ")#mi("\\phi")#text(" is also large just a bit before ")#mi("(t_0,x_0)")#text("; in particular, we will have")

#align(center)[#tao-fit-display[#mitex("\\phi(t,x) \\geq 1 + \\frac{\\log p}{p}")]]

#text("on the spacetime diamond")

#align(center)[#tao-fit-display[#mitex("\\{ (t,x): t_0 + x_0-\\frac{cK}{p} \\leq t + x \\leq t_0 + x_0; t_0 - x_0-\\frac{cK}{p} \\leq t - x \\leq t_0 - x_0 \\}")]]

#text("where c is a small cosntant (independent of K). Inserting this into (5), we obtain")

#align(center)[#tao-fit-display[#mitex("\\phi_{uv} \\leq - c^{\\prime} p")]]

#text("on this diamond, for some other small constant c’ > 0. Integrating this on this diamond and using the various bounds on ")#mi("\\phi")#text(" at the corners, one arrives at")

#align(center)[#tao-fit-display[#mitex("-c^{\\prime\\prime} \\frac{K^2}{p} = O(\\frac{K}{p})")]]

#text("for some other small constant c” > 0, which leads to a contradiction for K large enough (independently of p).")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Reutel")]], [#link("https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/#comment-35246")[#strong[#text("Reutel")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2009")])]

#text("Dear prof. Tao.")

#text("Snall typo: You seem to miss a \\ in the $t\\rightarrow\\pm infty$ just below equation 2.")

#text("Best regards ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aef5952340bb6bff3731f98d2d3c1dd9678b3cf7a31e8adaa413d5a449849a63-2282b8795059a7dc66cca6eef5758b61dc6bc6914983ed58ca5a96044d3d7376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of McGuigan")]], [#link("https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/#comment-35266")[#strong[#text("McGuigan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("Very nice post.")#linebreak()#text(" A similar approach was used to study")#linebreak()#text(" g phi ^n in dimension D = 2n/(n-2) by")#linebreak()#text(" L. Lipatov in")#linebreak()#text(" “Calculation of the Gell-Mann-Low Function in a Scalar Field Theory with Strong Nonlinearity.”")#linebreak()#text(" L.N. Lipatov Published in Sov.Phys.JETP 44:1055,1976, Zh.Eksp.Teor.Fiz.71:2010-2024,1976.")

#text("He was able to calculate the beta function to leading order in")#linebreak()#text(" 1/n by summing Feynman diagrams.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/24/the-high-exponent-limit-p-to-infty-for-the-one-dimensional-nonlinear-wave-equation/#comment-38195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("in the title some latex codes are problematic")

#text("thanks")
]
