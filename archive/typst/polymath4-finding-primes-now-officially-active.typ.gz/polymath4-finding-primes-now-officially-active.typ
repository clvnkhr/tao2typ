// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/08/polymath4-finding-primes-now-officially-active/
// Converted to Typst by tao2typ: "2026-10-14T07:25:47.469987+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath4 (“Finding Primes”) now officially active", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath4 (“Finding Primes”) now officially active")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/08/polymath4-finding-primes-now-officially-active/")[#text("https://terrytao.wordpress.com/2009/08/08/polymath4-finding-primes-now-officially-active/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath")]#text(" project “")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("Finding primes")]#text("” has now officially launched at the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(" as Polymath4, with the opening of a ")#link("http://polymathprojects.org/2009/08/09/research-thread-ii-deterministic-way-to-find-primes/")[#text("fresh research thread")]#text(" to discuss the following problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1. ")]#text("Find a deterministic algorithm which, when given an integer k, is guaranteed to locate a prime of at least k digits, in time polynomial in k.")
]

#text("From the preliminary research thread, we’ve discovered some good reasons why this problem is difficult (unless one assumes some powerful conjectures in number theory or complexity theory), so we have also identified some simpler toy problems:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2.")]#text(" Find a deterministic algorithm which, when given an integer k, is guaranteed to locate an adjacent pair n, n+1 of square-free numbers of at least k digits, in time polynomial in k.")
]

#text("(Note that finding one large square-free number is easy – just multiply a lot of small primes together. Adjacent large square-free numbers exist in abundance, but it is not obvious how to actually find one deterministically and quickly.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 3.")]#text(" Assume access to a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Factoring")[#text("factoring oracle")]#text(". Find an algorithm which, when given an integer k, is guaranteed to find a prime of at least k digits (or an integer divisible by a prime of at least k digits) in time ")#mi("\\exp(o(k))")#text(".")
]

#text("The current record time is ")#mi("O(10^k)^{0.535}")#text(" unconditionally, or about ")#mi("O( (10^k)^{1/2} )")#text(" on the Riemann hypothesis.")

#text("In the new ")#link("http://polymathprojects.org/2009/08/09/research-thread-ii-deterministic-way-to-find-primes/")[#text("research thread")]#text(", a number of possible strategies are discussed, and will hopefully be explored soon. In addition to this thread, there is also the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("wiki page")]#text(" for the project, and a ")#link("http://polymathprojects.org/2009/07/28/deterministic-way-to-find-primes-discussion-thread/")[#text("discussion thread")]#text(" aimed at more casual participants. Everyone is welcome to contribute to any of these three components of the project, as always.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/08/polymath4-finding-primes-now-officially-active/#comment-40932")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2009")]

#text("[…] Polymath4 (”Finding Primes”) now officially active The polymath project “Finding primes” has now officially launched at the polymath blog as Polymath4, with […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8cfc64887cf8e8f83cd2885d56488d122943983aa6a87bba37011b5d358dc33-ce52454922983bb2a97013eb026c6fe8b0d919eb0ba9a54645ba203b48cc0de1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paraskevas")]], [#link("https://terrytao.wordpress.com/2009/08/08/polymath4-finding-primes-now-officially-active/#comment-41086")[#strong[#text("Paraskevas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2009")])]

#text("Hello! please allow me to ask two questions:")

#text("1) If you raise a prime p in the power of 2 how many primes greater than p do you leave behind ?")

#text("2) If you raise 2 in a power n, how many primes do you leave behind ?")

#text("thank you!")

#text("Paraskevas")
]
