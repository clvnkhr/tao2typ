// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/09/09/vaughan-jones/
// Converted to Typst by tao2typ: "2026-10-14T11:00:27.888505+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Vaughan Jones", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Vaughan Jones")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 September 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/")[#text("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://en.wikipedia.org/wiki/Vaughan_Jones")[#text("Vaughan Jones")]#text(", who made fundamental contributions in operator algebras and knot theory (in particular developing a surprising connection between the two), ")#link("https://news.vanderbilt.edu/2020/09/09/vaughan-jones-preeminent-vanderbilt-mathematician-has-died/")[#text("died this week")]#text(", aged 67.")

#text("Vaughan and I grew up in extremely culturally similar countries, worked in adjacent areas of mathematics, shared (as of this week) a coauthor in ")#link("https://www.math.ucla.edu/~shlyakht/")[#text("Dima Shylakhtenko")]#text(", started out our career with the same postdoc position (as UCLA Hedrick Assistant Professors, sixteen years apart) and even ended up in sister campuses of the University of California, but surprisingly we only interacted occasionally, via chance meetings at conferences or emails on some committee business. I found him extremely easy to get along with when we did meet, though, perhaps because of our similar cultural upbringing.")

#text("I have not had much occasion to directly use much of Vaughan’s mathematical contributions, but I did very much enjoy reading his influential ")#link("https://arxiv.org/abs/math/9909027")[#text("1999 preprint on planar algebras")]#text(" (which, for some odd reason has never been formally published). Traditional algebra notation is one-dimensional in nature, with algebraic expressions being described by strings of mathematical symbols; a linear operator ")#mi("T")#text(", for instance, might appear in the middle of such a string, taking in an input ")#mi("x")#text(" on the right and returning an output ")#mi("Tx")#text(" on its left that might then be fed into some other operation. There are a few mathematical notations which are two-dimensional, such as the commutative diagrams in homological algebra, the tree expansions of solutions to nonlinear PDE (particularly stochastic nonlinear PDE), or the Feynman diagrams and ")#link("https://en.wikipedia.org/wiki/Penrose_graphical_notation")[#text("Penrose graphical notations")]#text(" from physics, but these are the exception rather than the rule, and the notation is often still concentrated on a one-dimensional complex of vertices and edges (or arrows) in the plane. Planar algebras, by contrast, fully exploit the topological nature of the plane; a planar “operator” (or “operad”) inhabits some punctured region of the plane, such as an annulus, with “inputs” entering from the inner boundaries of the region and “outputs” emerging from the outer boundary. These algebras arose for Vaughan in both operator theory and knot theory, and have since been used in some other areas of mathematics such as representation theory and homology. I myself have not found a direct use for this type of algebra in my own work, but nevertheless I found the mere possibility of higher dimensional notation being the natural choice for a given mathematical problem to be conceptually liberating.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/124f2317c08c4d35f23785e647ba4da7ea5b54e91cc0b97f90495f7b029a8950-52e8d46162151a102d40dcda946c298a4443f49577a98fe9dd24447fc7395ac3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zeraoulia Rafik")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-587830")[#strong[#text("zeraoulia Rafik")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2020")])]

#text("Dear our Genial Prof Tao , I have asked about contribution of Vaughan Jones refeering to your post here, you may find the link of question in MO here :")#link("https://mathoverflow.net/q/371275/51189")[#text("https://mathoverflow.net/q/371275/51189")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-587868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2020")])]

#text("Perhaps the dominating linear notation is due to the linear (i.e. chronologial) presentation of mathematical arguments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-587939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2020")])]

#text("I was lucky enough to meet Prof. Jones when he spoke at IPAM. As a joke I asked him to autograph my Jones polynomial for the trefoil and he was happy to do so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-588066")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2020")])]

#text("The theory of Feynman diagrams is motivated by atomic physics and is standard material in the quantum field theory class. Example: Peskin and Schroeder talk about a spinor valued field over real or Lorentzian 4-space. These lead to badly divergent series and creative regularization methods.")

#text("I have a question what the Jones polynomials has to do with von Neumann algebras?")

#emph[#text("[See the answers to ")#link("https://mathoverflow.net/questions/97788/on-connection-between-knot-theory-and-operator-algebra")[#text("https://mathoverflow.net/questions/97788/on-connection-between-knot-theory-and-operator-algebra")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-588117")[#strong[#text("Quick Links | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2020")]

#text("[…] the recent death of Vaughan Jones. A few things about his life and work have started to appear, see here, here and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45258fdf07391a283aa4fed70a67a2b2deeab5505448ed5c3be80487bf829ae6-d1dd982c6b8e7de58d65bccf3a9329c4b2f73a9b6db69d91727ec0de5566b431.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kim Hutcheson")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-589612")[#strong[#text("Kim Hutcheson")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2020")])]

#text("It was nice to meet & chat with him about knots when he flew back to the Dept of Mathematics & Statistics at Auckland University while I was there. He famously wore a New Zealand rugby jersey when awarded the Fields Medal in 1990 in Kyoto for his work on the Jones Polynomial, a link between Knot Theory & Statistical Mechanics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eacfc8e1210258a6fb0996a7c582e438589232b43b45f70474202d9a965a6fbf-a7c24908489e041415a74c3a76051f157aa9a8e342523a18283b9e1d064c10dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre de la Harpe")]], [#link("https://terrytao.wordpress.com/2020/09/09/vaughan-jones/#comment-593308")[#strong[#text("Pierre de la Harpe")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("Dear Terry,")

#text("Vaughan Jones has made so many human and mathematical contributions which are justly celebrated.")#linebreak()#text(" You have chosen to insist on mathematical notation, and I like this. Notation is so important for all of us,")#linebreak()#text(" but I know only very few places where this is appreciated and commented. For interested people, I’d like to make a link to the Mathematical Miniatures of Beno Eckmann. In the first of them, he writes about using arrows for a map $A \\to B$. According to Eckmann, arrows are not used until about 1950 (even not by Heinz Hopf). Then arrows, exact sequences and diagrams occur systematically, for example in the books by Eilenberg and Steenrod (1952) and Cartan and Eilenberg (1956). See")

#link("https://jfdmath.sitehost.iu.edu/notes/eckmann.pdf")[#text("Click to access eckmann.pdf")]

#text("Do arrows point in the direction of planar algebras?")
]
