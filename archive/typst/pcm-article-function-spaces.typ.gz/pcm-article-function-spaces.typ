// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/
// Converted to Typst by tao2typ: "2026-10-14T15:16:41.733838+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Function spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Function spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 March 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/")[#text("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("From ")#link("http://www.dpmms.cam.ac.uk/~wtg10/")[#text("Tim Gowers")]#text(", I hear the good news that the editing process of the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" is finally nearing completion. It therefore seems like a good time to resume ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("my own series")]#text(" of Companion articles, while there is still time to correct any errors.")

#text("I’ll start today with my article on “")#link("https://terrytao.wordpress.com/wp-content/uploads/2008/03/function_spaces1.pdf")[#text("Function spaces")]#text("“. Just as the analysis of numerical quantities relies heavily on the concept of magnitude or absolute value to measure the size of such quantities, or the extent to which two such quantities are close to each other, the analysis of functions relies on the concept of a norm to measure various “sizes” of such functions, as well as the extent to which two functions resemble to each other. But while numbers mainly have just one notion of magnitude (not counting the ")#link("http://en.wikipedia.org/wiki/Valuation_%28mathematics%29#p-adic_valuation")[#text("p-adic valuations")]#text(", which are of importance in number theory), functions have a wide variety of such magnitudes, such as “height” (")#mi("L^\\infty")#text(" or ")#mi("C^0")#text(" norm), “mass” (")#mi("L^1")#text(" norm), “mean square” or “energy” (")#mi("L^2")#text(" or ")#mi("H^1")#text(" norms), “slope” (")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz")]#text(" or ")#mi("C^1")#text(" norms), and so forth. In modern mathematics, we use the framework of ")#emph[#text("function spaces")]#text(" to understand the properties of functions and their magnitudes; they provide a precise and rigorous way to formalise such “fuzzy” notions as a function being tall, thin, flat, smooth, oscillating, etc. In this article I focus primarily on the analytic aspects of these function spaces (inequalities, interpolation, etc.), leaving aside the algebraic aspects or the connections with mathematical physics.")

#text("The Companion has several short articles describing specific landmark achievements in mathematics. For instance, here is ")#link("http://www.maths.qmul.ac.uk/~pjc/")[#text("Peter Cameron")]#text("‘s short article on “")#link("http://www.maths.qmul.ac.uk/~pjc/preprints/goedel.pdf")[#text("Gödel’s theorem")]#text("“, on what is arguably one of the most popularised (and most misunderstood) theorems in all of mathematics.")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425b5e7ce8a3177722b83f666dc73db2187d304c7b7c01f809a32c891a9df920-058bdb93b350639608b14dfa7aa4e05501c2b9e3b1f93c49944b359e45674b43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-26943")[#strong[#text("Anton")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Terry,")#linebreak()#text(" Nice intuitive description, but two comments. You misspelled Marcinkiewicz")#linebreak()#text(" and what you call Marcinkiewicz’s interpolation theorem is really Riesz’s interpolation theorem (which is itself a special case of what is called the Riesz-Thorin theorem). I understand that you can’t cover the subtleties which distinguish these results, but the version you stated is really due to Riesz, so that it might be more appropriate to call it the Riesz-Thorin interpolation theorem and maybe mention then that there exist even a stronger result, the Marcinkiewicz interpolation theorem.")#linebreak()#text(" Anton")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-26944")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Hello,")#linebreak()#text(" At the top two paragraphs of page 5, you might be missing a few x’s in the exponents.")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-26947")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“This space [")#mi("L^2")#text("] is exceptionally stable under a wide class of transformations; for instance, any unitary transformation on ")#mi("L^2([-1, 1])")#text(" will preserve this space.”")
]

#text("The first part make a good point, but the second is vacuous – the unitary transformations preserve the space by definition. Perhaps what you mean to say is that while the unitary group of all other ")#mi("L^p")#text(" spaces consists of the semidirect product of the measure preserving transformations and the phase functions, the unitary group of Hilbert space is really big?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0335cb2820bf266214f8461962c8ffa02c51b0849bb6cf74607286c521ac72-833977c6de5fd5d096cc7266f4edffa0f20ea68776fc848b929e53ae8f474803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-26951")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Fun book for those who want to see how Gödel is misunderstood: ")#emph[#text("Gödel’s Theorem: An Incomplete Guide to Its Use and Abuse")]#text(" by Torkel Franzen.")

#text("I’m very excited about the PCM!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-26953")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2008")])]

#text("Thanks for the comments and corrections! Regarding interpolation, it is true that the statement I wrote (that L^2 boundedness follows from L^1 boundedness and L^infty boundedness) follows both from the Marcinkiewicz and Riesz-Thorin interpolation theorems, but the proof of the Marcinkeiwicz interpolation theorem hews more closely to the decompositions discussed earlier in the article (that an L^2 function can be decomposed into a sum of an L^1 and L^infty function), whereas the Riesz-Thorin interpolation theorem relies more on complex-analytic methods. (Actually, it turns out that the PCM editors ended up rewriting that part of the article anyway, as one can see from the copy of this article that is at the PCM website.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390f81bc403abbaa8705d528326b2523fa57d0b8d96a8625fdf3137195984de9-d72493108d6c1d94a82de1fb4c8ac5733837bfe3934e27530cdeee359b8b1909.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaennio")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-27152")[#strong[#text("nicolaennio")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2008")])]

#text("really clear and interesting article!")

#text("I hope in the future there will be a post dedicated to interpolation methods.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-34823")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("[…] a little bit in this lecture and then in much greater detail in later lectures. (See also my previous blog post on function […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quantum probability")]], [#link("https://terrytao.wordpress.com/2008/03/04/pcm-article-function-spaces/#comment-49010")[#strong[#text("quantum probability")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2010")])]

#text("THANK YOU. This is exactly the intro to functional spaces I have been looking for.")
]
