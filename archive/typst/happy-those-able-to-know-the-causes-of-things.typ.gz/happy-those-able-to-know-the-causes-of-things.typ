// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/
// Converted to Typst by tao2typ: "2026-10-14T11:19:12.894016+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Happy, those able to know the causes of things", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Happy, those able to know the causes of things")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/")[#text("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://www.ndguillen.com")[#text("Nestor Guillen")]#text(", crossposted from ")#link("https://birdsnfrogs.github.io/2026/09/12/Felix_qui_potuit_rerum_cognoscere_causas.html")[#text("his blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#strong[#text("Keywords")]#text(": LLMs, cultural technologies, skateboarding, creative communities, AI industry.")

#strong[#text("A note on the timing of this essay.")]#text(" I started writing this in the middle of the ICM, and it has taken me this long to finish writing, see also my shorter ")#link("https://birdsnfrogs.github.io/2026/08/23/Math_is_life.html")[#text("post")]#text(" from August. In any case the bulk of the essay was done in August and shared with a few close friends for feedback. Earlier this week, Tristan Buckmaster ")#link("https://mathstodon.xyz/@tristanbuckmaster@mastodon.social/117233413735526010")[#text("announced")]#text(" a breakthrough finding, done in collaboration with Levent Alpöge, of a finite-time blow up for 3D incompressible Euler with forcing. He also made serious allegations of misconduct by OpenAI (see announcement). The next day, OpenAI announced a finite-time blow up result for 3D Navier-Stokes with forcing, obtained from their internal LLM. There has been lots of press coverage, I recommend Kenneth Chang’s ")#link("https://www.nytimes.com/2026/09/10/science/tristan-buckmaster-openai-math-navier-stokes.html")[#text("reporting")]#text(". I have decided not to change the opening of the essay and instead make a note of the news here. Tristan gave considerable credit to the ideas of Córdoba and Martínez-Zoroa in the blow up construction; I found this important detail to be quite validating of the perspective on LLMs I advocate in this essay, and found that to be further reason to leave the content of the essay largely unchanged.")

#text("What would be the significance if one day we woke up to the news that output from a Large Language Model contains a definitive answer to the question of blow up for the incompressible Navier-Stokes equations, and to the question of where the zeros of the Riemann zeta function lie? (Or, to mention problems dear to my heart: a proof of a nonlocal version of the ABP maximum principle or a resolution of the Mahler or Komlós conjectures?)")

#text("Many of my fellow mathematicians consider this a kind of nightmare situation, and I think this is a very valid position. Here I would like to make a different case, however. Personally, I have come to believe that the news of a Large Model output containing an interesting, insightful, novel mathematical idea can and should be received ")#strong[#text("as a source of communal pride for mathematics and for mathematicians")]#text(". I also believe there can be a world where LLMs are not harmful but rather supportive of mathematicians as we follow our prime directive: ")#strong[#text("understanding")]#text(" things.")

#text("My intention in this essay is to elaborate on what I mean by this. I believe this perspective can assuage fears many of us feel amid the daily hype and doom narratives around AI and the alleged impending obsolescence of mathematicians. I will not be talking about the less existential / philosophical and more practical / material concerns here, such as challenges to the funding of the mathematics occupation, how journals will work, changes to the training mathematicians, and so. Those issues are also important, but I think clarifying the perspective I push here will make the discussion of the more practical matters easier.")

#metadata(none) <tao-7984666c897d96600828>

#text("Bill Thurston touched on the same idea in his famous 1994 essay, ")#link("https://birdsnfrogs.github.io/pdf/Thurston_OnProofandProgress.pdf")[#text("“On proof and progress in mathematics”")]#text(", which is more relevant than ever. Thurston observes that mathematicians (as a group) prove theorems and solve problems, but that is not all they do: they also absorb these solutions, and find new uses for them once they are proven. This “digestion” [1] in turn allows for the next wave of breakthroughs, and thus advances our understanding of mathematics.")

#text("This is not secondary to what mathematicians do, but our very purpose. The value of mathematics to humanity lies not in determining whether a statement or conjecture is true or false, but rather in the ")#strong[#text("understanding gained")]#text(" as we make those determinations (even if the facts themselves are also of great value). To put it briefly, mathematicians are people who try to understand the causes of things.")

#image("../assets/7ec7a94bf0cfc96cf7a82940ebb63d999554459862fa85bea944a4d3db40e493-0cbc762931d2eb7c751c362367c0a29fd30a17d26848bdbb374ecb296c9980e0.jpg", width: 90%)

#emph[#text("Felix, qui potuit rerum cognoscere causas")]

#strong[#text("LLMs, the technology ")#mi("{\\neq}")#text(" AI, the product from large companies")]

#text("The conversation about LLMs and generative AI within the mathematical community at large must deal with an obstacle before we can get to the substance of the matter. That obstacle is the current and unfortunate identification of generative AI, ")#strong[#text("the technology")]#text(", with generative AI, ")#strong[#text("the specific product and vision from the large AI companies")]#text(". It is imperative for us to make that distinction and separate the two. The private AI lab vision is what most people have in mind when discussing AI, and this is no accident, for this vision has been aggressively pushed into every part of our daily lives.")

#text("It might seem impossible at the moment, but we can imagine an alternative world with many parallel approaches to the use of LLMs developed by the grassroots, reflecting the variety of circumstances across different communities, industries, and institutions. A seed for this world is the emergence of open-weight models. This is a matter for a different essay.")

#text("So in all that follows, I will crucially rely on the above distinction, so that when I say LLMs or “Large Model” I am talking about the technology itself, and very much ")#strong[#text("not")]#text(" any of the major AI companies or their products.")

#text("With all this throat clearing behind us, let me get to the matter at hand. Why should the output of an LLM containing new and exciting mathematical ideas be a source of pride for mathematicians, and not of anxiety? My answer owes a lot to this very interesting ")#link("https://par.nsf.gov/servlets/purl/10600511")[#text("article")]#text(" by Henry Farrell, Alison Gopnik, Cosma Shalizi, and James Evans. I quote here one of their central assertions:")

#emph[]#emph[#text("…Large models should not be viewed primarily as intelligent agents but as a new kind of cultural and social technology, allowing humans to take advantage of information other humans have accumulated.")]

#text("I will do my best to apply the ideas in their article to mathematics and the work of mathematicians. If, rather than continue reading this, you stop and go read their article and Thurston’s article instead, I would consider this essay a success.")

#strong[#text("Cultural and social technologies")]

#text("Humans have always lived in a complex world and their survival has hinged on their ability to process information in amounts beyond what any individual can handle — and it is likely this has been so nearly as long as humans have existed. Herbert Simon’s concept of “bounded rationality” captures this well: in real life, unlike in the simplest control theory models, we have limitations on the time available to decide and on the accuracy of our information. This means that an agent making decisions must give up optimality and settle for “good enough.”")

#text("Simon saw that one implication of bounded rationality is that humans have to (and do) develop systems to process information, as a group. We see that humans have built states, stories, bureaucracies, markets, libraries, and more. These are cultural and social technologies. They are means by which humans (not individually but as a group) navigate amounts of information so vast that they cannot be handled by any individual on their own. An important feature of these technologies is that they are to some extent forgetful: you ignore or downplay smaller details in order to make a bigger picture easier to comprehend.")

#text("Markets, governments, and bureaucracies mean each human can focus on a few things and still get the aggregate benefits. Thanks to markets, governments, and bureaucracies, I can rely on being able to buy fresh fruits and vegetables around the block from my Manhattan apartment. Thanks to markets, governments, and the field of modern medicine, we now have high confidence that a newborn child will live to be an adult — in stark contrast to what was the norm for most of human history. Cultural technologies are powerful and awe-inspiring things. It is understandable that we tend to anthropomorphize them so often.")

#text("This week I started teaching my graduate-level optimal transport course. I wrapped up the first class by showing one neat application of optimal transport: a “one-page proof” of the isoperimetric inequality in ")#mi("{\\mathbb{R}^n}")#text(". Of course, the proof being just one page depends on what we are assuming as given.")

#text("This is standard, not only when teaching advanced courses but also very much in day-to-day research, and it is made possible by the power of cultural technologies. In the proof I don’t have to explain from scratch the notion of Lebesgue measure or sets of finite perimeter. When in the middle of a proof I say “I will do the details only when the domain has a smooth boundary, and I will assume the Lebesgue measure is ")#mi("{1}")#text(" without loss of generality thanks to scaling,” I am relying on a shared trick that I can trust a first-year PhD student to be familiar with.")

#text("All of this is to my benefit and the students’. We can focus on “the one page” proof with the interesting new idea: how Brenier’s theorem provides a map through which the isoperimetric inequality is essentially reduced to the arithmetic-geometric mean inequality.")

#text("So, here is basically what I showed on the blackboard: assuming ")#mi("{E \\subset \\mathbb{R}^n}")#text(" has Lebesgue measure ")#mi("{1}")#text(", we want to prove that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\partial B\\right| \\leq \\left|\\partial E\\right|", block: true)]]

#text("where ")#mi("{B}")#text(" is the ")#mi("{n}")#text("-dimensional Euclidean ball with the same volume as ")#mi("{E}")#text(", so ")#tao-math("{\\left|B\\right|=1}", block: false)#text(". Then, I tell my class how Brenier’s theorem says there is always a map ")#mi("{T}")#text(" from ")#mi("{E}")#text(" to ")#mi("{B}")#text(", that this map is volume-preserving, and that ")#mi("{T = \\nabla u}")#text(" for some convex function ")#mi("{u}")#text(". Then, since ")#mi("{\\det(D^2u(x))=1}")#text(" and all the eigenvalues of ")#mi("{D^2u(x)}")#text(" are non-negative, the arithmetic-geometric mean inequality says that ")#mi("{1 \\leq \\frac{1}{n}\\Delta u}")#text(" everywhere in ")#mi("{E}")#text(", and so")

#align(center)[#tao-fit-display[#tao-math("1 = \\left|E\\right| = \\int_{E}1\\;dx \\leq \\frac{1}{n}\\int_{E}\\Delta u(x)\\;dx.", block: true)]]

#text("Then, the divergence theorem and the fact that ")#tao-math("{\\left|\\left|\\nabla u(x)\\right|\\right|\\leq r := (1/\\omega_n)^{1/n}}", block: false)#text(" (where ")#mi("{\\omega_n}")#text(" = volume of the unit ball) guarantee that")

#align(center)[#tao-fit-display[#mitex("1 \\leq \\frac{1}{n}\\int_{\\partial E}\\nabla u(x)\\cdot \\nu(x)\\;d\\sigma(x) \\leq \\frac{1}{n}(1/\\omega_n)^{1/n}|\\partial E|.")]]

#text("For a ball of volume ")#mi("{1}")#text(", scaling shows that ")#tao-math("{\\left|\\partial B\\right| = n\\omega_n^{1/n}}", block: false)#text(", so we conclude that ")#tao-math("{\\left|\\partial E\\right| \\geq \\left|\\partial B\\right|}", block: false)#text(", as we wanted.")

#text("In interacting with this proof, we are engaging in a conversation through space and time with many mathematicians, but especially with Knothe (1957) and Gromov (1986), followed later by separate works of Brenier, McCann, and Trudinger — and even with my younger self in a set of ")#link("https://www.math.toronto.edu/mccann/papers/FiveLectures.pdf")[#text("lecture notes")]#text(" with McCann, where we go over the above proof (see concretely Section 1.6). The conversation is mediated by a common mathematical culture, which encompasses the common definitions and methods I can count on the graduate students to know. I don’t have to prove the divergence theorem or the change of variables formula to justify these computations, and I don’t have to worry about the smoothness of ")#mi("{T(x)}")#text(", since I can work by approximation.")

#text("Without having to go into all that detail, I presented on one blackboard the idea that the Brenier map takes you from the arithmetic-geometric mean inequality to the isoperimetric inequality, and I did this in the last 15 minutes of the class. These are cultural technologies in action! Which cultural technology in particular? In this case it is the technology of a scientific community with standards in what is taught, the mathematical literature, and so on.")

#strong[#text("Large Language Models as cultural technologies")]

#text("Farrell et al.’s main point is that LLMs are cultural technologies, just like markets, bureaucracies, and scientific disciplines. Accordingly, the framework of cultural technologies is a very useful one as we seek to understand and navigate the impact of Large Models on our disciplines.")

#text("LLMs indeed are a lot like the example from my class, and in a way they are “wrappers” around an older cultural technology: the scientific literature. When you ask an LLM a question about the isoperimetric inequality, the ABP maximum principle, or a PDE, you are effectively interacting with every person who has thought about and worked on those things — provided the data the LLM was trained on contained those contributions in one way or another. Surely the lecture notes I reference above are in the training data of most LLMs in use today, just as a vast portion of the digitized mathematical literature (across all disciplines) was part of the training data. LLMs are lossy, so while a model might not be able to reproduce a given paper ")#strong[#text("exactly")]#text(" as in the training data, it can reproduce large parts of it.")

#text("What sets LLMs apart from older cultural and social technologies is the fact that we have digitized all this data, and can now explore it, reproduce it, and recombine it with ease by sending text commands (prompts) from a computer terminal, or even a phone. LLMs are, in essence, top-tier information-processing tools. They are also an excellent tool for generating conversational level-text, and for coherently combining patterns of information even if they come from very different sources.")

#text("By a product-design choice at a few private labs, the output of most LLMs is conversational in tone and made easy to anthropomorphize. These properties have amplified an ELIZA-like effect that reaches even people with advanced training in mathematics and computer science. In a way, anthropomorphizing this technology — which, as some have argued, did not have to be the case — does everyone a disservice: the conversational setup of the LLM gives the appearance of a single “thinking” entity, and buries the work by vast groups of people and which are being recombined. This appearance is a feature not of LLMs, but of the LLMs as the AI companies want them. We are not dealing with a very smart, genius-level intelligence; we are interacting with something greater (and yet somehow more human): the aggregate creations of millennia of human ingenuity and creativity, digitized and efficiently compressed — all mediated by state-of-the-art statistical and generative algorithms.")

#text("In particular, any mathematical proof found in an LLM output is the collective outcome of lifetimes of work by mathematicians. It must be welcomed as the fruit of our shared mathematical heritage, belonging to all of humanity, carried through millennia by people who at various times went by names other than mathematician (natural philosophers, astronomers, geometers). This applies very much to LLM output containing what we might consider novel proofs or ideas, for in the end, it is all an outgrowth of that gigantic body of knowledge. Now ")#strong[#text("there")]#text(" lies a scaling law that has been going for centuries. The recently arrived software is just a kind of harness or wrapper for it.")

#text("Now, let’s reconsider the “nightmare scenario” I opened this essay with. One day we wake up to the news that the output of a Large Model contains a resolution to the Riemann Hypothesis. We are now equipped with the ideas of Farrell et al., and especially the idea of cultural technologies. Reading the news under this framework, we are learning a new mathematical fact, but we are also learning that this fact is the fruit of the collective efforts of researchers in the field ")#strong[#text("up to this moment")]#text(". The problem was cracked by the ideas of one or two (or maybe many) researchers to the point that a resolution could be reached by the sampling and recombining of ideas an LLM is good at.")

#text("This leaves us with a delicate question: what ideas are reachable from the totality of ideas in the mathematical literature at a given time? I am going to borrow from geometry and loosely use the metaphor of “convex combination” of ideas to discuss this.")

#strong[#text("Convex hulls of ideas")]

#image("../assets/f4101c6035f946291bba9d848e493d3aaf4e402d3aeae4c024526b0600626ef2-20d42c159fb213c2ed3b94c2b9625424e8f46a13d856c4f145f02e294b81e795.png", width: 90%)

#emph[#text("A convex body containing another, from ")#strong[#text("Geometry and the Imagination")]#text(" by Hilbert and Cohn-Vossen")]

#text("The capabilities of LLMs have progressed quite a bit in the last couple of years, and dramatically so in mathematics this year alone. The rapid improvement makes this discussion difficult. The question “what can LLMs do?” is a rather moving target, at least for the time being. This being said, let’s try to think of a related question that might not be as LLM-dependent, and has a chance of being useful, even if it is still vague.")

#text("Ideas sometimes are very clearly compositions of other, more fundamental ones. Sometimes a new idea really stands apart from what came before. What would the finding of a solution the Riemann Hypothesis, or of the 3D Navier-Stokes smoothness problem, within the output of an LLM, tell us? One toy model (which might not reflect empirical reality) is that the result might belong to some sort of “closure” or “convex hull” of the available literature. In broader terms, one could pose the following question: given a collection of ideas, what ideas could be said to stand squarely beyond them, and which are lying closer to their “convex hull”?")

#text("I will not give a more concrete definition for this, because I am not able to. However, I can discuss by way of example what this definition ought to cover. I also do not use “convex hull” to mean that the point is derivative or that the finding of a point of something inside a convex hull to be easy — high dimensional convex sets are deeply complex objects!")

#text("At the very least, we can agree that the proof of the infinitude of primes ")#mi("{p \\equiv b \\mod a}")#text(" with ")#mi("{a,b}")#text(" coprime is certainly not in the “convex hull” of number theory that preceded Euler and Dirichlet: using an infinite series to quantify the “amount of primes” is precisely the sort of idea that stood squarely outside of what was considered number theory until it was proposed. However, the question of the infinitude of primes of the form ")#mi("{an+b}")#text(" (")#mi("{a,b}")#text(" coprime) could be posed within the number theory that existed before Euler. In fact, this was known already for special choices of ")#mi("{a}")#text(" and ")#mi("{b}")#text(", say for primes of the form ")#mi("{4n+1}")#text(". Likewise, number fields, ideals, and their unique factorization are all ideas lying well beyond all the number theory that preceded them. However, once we have these ideas together, it is slightly less outside the convex hull (or maybe it is even inside the convex hull) to develop a proof of the fact that every ideal class contains infinitely many prime ideals — a combination of Euler’s and Dirichlet’s ideas with the idea of, say, Gaussian integers.")

#text("From what I have seen (so far) in research areas that I am closest to, no LLM has produced anything remotely like Euler’s introduction of the methods of analysis in the study of primes. One possibility is that LLMs are not even being used so far for such things. In fact, one could put it like this: Euler was not simply answering a well-known question, but rather saying “here is actually a whole new question that we did not know we could ask, and is actually a very important one that connects to older problems!” The framework of LLMs as cultural technologies, to the extent that it reflects existing LLMs, suggests that this is a type of contribution we cannot expect to find in their output.")

#text("According to Farrell et al., cultural and social technologies are ")#emph[#text("preceded")]#text(" by individual capabilities, which are then aggregated and transmitted by the technology. In their essay, they note that “without innovation, there would be no point to imitation.” Suppose Euler had access to an LLM trained on all of the mathematics known up to the moment he started working in number theory. Without an individual first introducing the analytical perspective on prime numbers, it would be very hard for our hypothetical LLM to ")#emph[#text("innovate")]#text(" analytic number theory into existence, and then use this innovation to solve the “conjecture” [2] on the infinitude of primes that are congruent to ")#mi("{b}")#text(" modulo ")#mi("{a}")#text(", for ")#strong[#text("any")]#text(" ")#mi("{a,b}")#text(" coprime. All the same, the framework is compatible with the happy possibility that a person working with an LLM might have a eureka moment where they, ")#emph[#text("the person")]#text(", arrive at this innovation.")

#text("Here is another example, of a slightly different character. One of the most important theorems in PDE is the Krylov-Safonov theorem for non-divergence form elliptic and parabolic equations. For those not in PDE, these are versions of the Laplace equation and the heat equation, except the “coefficients” in front of the partial derivatives are not constant but rather change from point to point.")

#text("Such equations, linear and nonlinear, appear in the study of stochastic processes as well as in optimal control and geometry. The Krylov-Safonov theorem produces a Hölder regularity estimate for solutions of the PDE that only depends on the uniform ellipticity — what is notable is that this estimate works even if the coefficients are potentially very discontinuous. Consider, for concreteness, a linear equation such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i,j=1}^n a_{ij}(x)\\partial_{ij}u(x) = 0")]]

#text("When the coefficients ")#mi("{a_{ij}}")#text(" are smooth, the regularity of solutions to this equation can be understood from the theory for the Laplace equation. Heuristically, the coefficients being smooth means that as you zoom in near a point, the coefficients are closer and closer to being constant, which puts you just an affine change of variables away from Laplace’s equation. Therefore the good regularization properties of Laplace’s equation carry upward to the larger scales and so one proves ")#mi("{u}")#text(" is smooth. This estimate, however, depends very much on the modulus of continuity of the functions ")#mi("{a_{ij}(x)}")#text(".")

#text("Now, I cannot go on at length about this here, but obtaining estimates for ")#mi("{u}")#text(" that do not depend on the continuity of the coefficients ")#mi("{a_{ij}(x)}")#text(" is extremely important. In fact, the importance of this question cannot be overstated — such estimates have profound implications in the theory of stochastic processes, in geometric analysis and differential geometry (say, for the many PDE related to curvature), in stochastic homogenization, and more. For this reason the Krylov-Safonov theorem is one of the most important PDE results we have.")

#text("The Krylov-Safonov theorem, however, depends on a mathematical fact that comes from a very different area: convex analysis. There is an estimate by Aleksandrov that says the following: for ")#mi("{B\\subset\\mathbb{R}^n}")#text(" denoting the unit ball, given any function ")#mi("{h:B \\rightarrow\\mathbb{R}}")#text(" convex in ")#mi("{B}")#text(" and with ")#mi("{h=0}")#text(" on ")#mi("{\\partial B}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|h\\right\\|_\\infty \\leq C_n \\left|\\partial h(B)\\right|^{1/n}", block: true)]]

#text("where ")#mi("{\\partial h}")#text(" denotes the subdifferential of the convex function. This estimate holds for general convex bodies, not just ")#mi("{B}")#text(", and in this generality it is equivalent to the reverse Blaschke-Santaló inequality from convex geometry. The estimate is the key component in what is known as the Aleksandrov-Bakelman-Pucci (ABP) estimate, which in turn is essential for the Krylov-Safonov theorem.")

#text("To state it in simple terms: without this fact from convex geometry the Krylov-Safonov theorem cannot be proved, not in any way we know today. This is a significant statement, as many important theorems in analysis have multiple, independent lines of attack that do not necessarily use the same tools. This would be like asking how to prove results in geometric analysis and probability without knowledge of the Poincaré inequality. Without the advances in convex geometry done many decades earlier, the theory of fully nonlinear elliptic PDE, which seems at first sight so remote from convex geometry, could not have advanced the way it did onward from Krylov and Safonov.")

#text("Imagine a parallel universe where we came to LLM technology before we knew about the Krylov-Safonov theorem, so that the question of regularity for non-divergence elliptic equations without dependence on coefficients is considered an important open problem. The cultural technologies framework suggests that in this universe an LLM (at least at the current level of power) would not be able to settle this open problem if the mathematical literature in this parallel universe does not have a well-developed field of convex geometry/analysis. By the same token, if in this parallel universe there is a well-developed convex geometry literature, including the Aleksandrov estimate, then it is plausible an LLM could bridge the two things and arrive at the ABP estimate and Krylov-Safonov’s theorem.")

#text("Thinking in terms of “convex hull of ideas,” one sees that whether an LLM can solve a given mathematical problem is in large part a function of the status of the mathematical literature at any given time, and is not just a function of how large the LLM is. With this perspective, the event of an LLM output containing the solution of a hard problem ought to be welcome as a happy occurrence: an LLM helped us dig out a gem buried somewhere in our mathematical heritage, or in the convex hull, if you will.")

#text("In fact, this has already happened: less than a year ago, we heard news of “Erdős problems” solved by an LLM, which then turned out to be instances of the LLM finding solutions in old (and in some cases, forgotten!) papers. At the time, this realization was seen as a defeat for LLMs. Now, that situation illustrates the perspective I am advocating here, in miniature.")

#strong[#text("Creative communities during turbulent times")]

#text("The framework of LLMs as cultural technologies, together with the “convex hull” of ideas it inspired, has addressed my own philosophical concerns with LLMs. It has reinforced my optimism that the mathematics I value will endure. However, this does not change the fact that the mathematical community is facing serious and urgent challenges. The AI companies’ aggressive and narrow-minded push of their vision is hurting the field, exacerbating old fault lines and dysfunctions of our profession, and creating new ones.")

#text("This is not the first time a creative community has faced a turbulent period or a big change brought by new technologies or economic realities. There are lessons we can learn from past instances, in mathematics and in other disciplines. One can think of painters facing the advent of photography, musicians facing the arrival of the synthethizer, or mathematicians themselves — think for instance of the creation of the arXiv in the 1990s. However unusual it might seem, chapters from the history of ")#strong[#text("professional skateboarding")]#text(" present uncanny parallels to the circumstances in mathematics, and this is a history with many teachings and warnings for mathematicians.")

#image("../assets/1f53a8d5ca629a5dd522a7be230adb8b1399735d670de1fb86cdb65a8b2f6062-c0c821f16d9142e93d431fde7aa97366cf3633ab4108141a5f0a984a0308b2c5.jpg", width: 90%)

#emph[#text("Rodney Mullen performing “the Impossible” trick in an episode of the ")#link("https://youtu.be/yFRPhi0jhGc?t=229")[#text("Physics Girl")]#text(" (Dianna Cowern)")]

#text("By the 1980s, skateboarding had been around for several decades. It had professional contests, sponsorship deals, and a specialized press. Like mathematics, skateboarding had an ecosystem that allowed practitioners to develop their craft and advance it, and even make some money along the way. It also had subfields, like freestyle, vert, and street skating. In 1984, Kevin Harris, who came from the subfield of freestyling, observed street skaters with only “six months of experience” were already earning more than ")#link("https://www.youtube.com/watch?v=H8VtyS9jqxg&t=2074s")[#text("Rodney Mullen")]#text(", who at the time had tens of thousands of hours of experience and a nearly perfect record in professional competitions. Harris ")#link("https://juicemagazine.com/home/bones-brigade-chronicles-kevin-harris/")[#text("has recalled his reaction")]#text(" to this observation as: “Okay, this is the death of freestyle and it’s going to hurt vert skating hugely.”")

#text("The recession around 1990 dealt the finishing blow to the professional skateboarding ecosystem as it existed at the time. Within a few years, the discipline lost many of the venues and big public events it was built around, even largely losing its version of “funding” — sponsorships. This crisis drove many pros into early retirement. One could argue that with championships and sponsorships gone, the metric for measuring success was gone, and with it all the incentives for participation in competitive skateboarding. However, this was not the only metric, nor even the main one, for skateboarding continued and evolved in the coming years.")

#text("Without public contests with large audiences and related sponsorships, skateboarders had to find some other means to communicate and show their work. The economic and social problems in this case were solved with a technology that already existed. Skating videos became the new medium by which skateboarders recorded and communicated their work. Before, if a skater spent countless days perfecting a delicate trick, they could showcase it to at most a few hundred, maybe a thousand people during a championship. Now, a videotape showcasing the work of several skaters could be seen by tens of thousands of people. Before, a skater who did not win several championships was likely to go unappreciated. Now, a skater needed only one good “part” –a single skater’s segment within a video– to be recognized and contribute new tricks to the skating community. The most successful “parts” would introduce a new trick or a new twist on an old one that would get replicated and adopted by others.")

#text("I find it notable that the resolution to the crisis in skateboarding made it a bit less a competitive sport and a bit more a collaborative, creative field, with videotapes playing the role of journals [3], and a “part” playing the role of the articles in the journals. This turbulent transition turned out to be for the best for skateboarding as a discipline, while it also turned out for the worse for many individual skateboarders. This ecosystem remains largely unchanged today (with internet videos replacing videotapes). The motivation for a skater to participate in the community, aside from their love for skating itself, was that their contributions could be showcased in video, and their ideas could be shared with others who could try to repeat them or recombine them in new ways.")

#text("Mullen said that an invention only becomes an innovation once the community adopts it. This provides a measure of the value of a work. In mathematics we often talk about “the impact” of a paper or idea, and this is completely analogous to a trick being impactful: has the community taken this idea, and used it, and modified it further? Has this work made it easier for newcomers to the field to understand the state of the art?")

#strong[#text("Reclaiming our mathematical heritage, and the future of mathematics")]

#text("One lesson I take from cultural technologies is that the most precious component in a Large Language Model, the part most responsible for whatever value lies in its output, is the human-generated work, the cultural and technical heritage encoded in it. Throughout the summer the largest AI companies have been treating the solution of high-profile mathematical problems as a form of PR for their products. We as mathematicians need to lean into our curiosity and love of math and welcome this new knowledge, without letting its provenance ruin our enjoyment of it. We must counter the damaging misconception that “AI has beaten mathematicians at solving problem X,” which is being promoted by the corporate AI labs. Instead, we can celebrate how our understanding of mathematics, together with our creativity, lies behind the gems of mathematics LLMs are helping us uncover.")

#text("Earlier in this essay I touched on the importance of separating LLMs (the technology) from AI (the product and vision of the AI companies). Well, we need to also make this a reality for our mathematical infrastructure. It needs to be a top priority of the community to promote and work towards a world with open LLMs — think of the LLM equivalent of free software. It would be quite bad if our profession became dependent on the whims of the AI industry, whose leaders inhabit a moral universe ")#emph[#text("so distinct")]#text(" from ours in science and mathematics that nothing fruitful or sincere can emerge from associating with them [4]. We must remember that the combustion engine was never the heritage or exclusive creation of car makers in Detroit; and railroads and locomotives were not the exclusive heritage of the robber barons of the Gilded Age; and so it is also true that LLMs do not belong in any fundamental way to large industry labs in the Bay Area. The convex hull perspective in this essay suggests it is worthwhile to look into lighter, mathematics-specific LLMs with well curated data, and asses the scale of the technical (and financial) obstacles for such a thing. It would demostrate that the big labs’ “moat” is not as deep as they’d like it to be.")

#text("We also ought to approach the use of LLMs with an open attitude, experimenting and exploring until we find those LLM practices that best serve our values: advancing human understanding of mathematics, as Thurston would put it. This also means working as a community to minimize the disruption to mathematical careers, so that as few people as possible share the fate of those skateboarders who had no choice but to retire early. This must also involve policy advocacy: to dramatically increase public funding for science, and policy advocacy for serious public oversight of the large AI labs. We must also experiment with the creation of new social structures and professional arrangements within mathematics, so that we can allow as many individuals as possible to remain part of the mathematical community. If we are successful in this, the mathematical community will come out stronger from this turbulent time, serving as a model for other communities and industries working to transition to a world of ubiquitous LLMs.")

#text("To return to where we started, an LLM’s output “solving” the nonlocal ABP or the Mahler conjecture would be, circumstances aside and in a strict sense, a triumph for the discipline. That does not mean that we cannot have mixed feelings about it. It is not pleasant to be scooped by a living, thinking person, and it is no more pleasant to be scooped by the collective knowledge of the field, processed and recombined via an LLM. Rather than being shocked, we ought to be in awe, not of the technology, but of the immensity and power of the mathematical knowledge we have built to this day. Large Models have made this enormity apparent and impossible to miss. Mathematicians must claim such developments as the rightful fruit of our discipline, and accordingly take pride in them, understand them, adopt them, and continue advancing mathematics. Fortunate are we, able to know the causes of things.")

#strong[#text("Notes")]

#text("[1] “Digestion” is a term Terry Tao proposed in his ")#link("https://www.youtube.com/watch?v=M0--ZH1lOzg&t=285s")[#text("ICM lecture on mathematics in the age of AI")]#text(", part of a metaphor of LLM generated proofs as bringing us to an era of proof abundance, as in mass produced food.")

#text("[2] I say “conjecture” only in the context of this hypothetical scenario of Euler and his 18th century LLM.")

#text("[3] In mathematics, meanwhile, we are actually approaching a situation where we will have to switch towards whatever ")#strong[#text("comes after")]#text(" journals, or at least journals as they are presently understood.")

#text("[4] Here I am very purposefully borrowing a phrase I have long been fond of. It was written by Bertrand Russell in a response to Oswald Mosley.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695133")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Mathematicians must claim such developments as the rightful fruit of our discipline, and accordingly take pride in them, understand them, adopt them, and continue advancing mathematics.")
]

#text("Amen. Though I don’t really see any reason to believe that LLMs will be confined to the “convex hull” of existing knowledge, other than that seems to be the case so far.")

#text("We’re less than a year into AI capabilities clearly exceeding our own in scientific domains. Perhaps there’s a fundamental barrier to the kind of creativity required to escape the convex hull, but I wouldn’t bet on it myself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This is a very well thought-out essay and I appreciate all the insights of the article. But, at the same time I agree with this comment, that what LLM’s have shown is a possibility of generating a move in the orthogonal and additional dimension to the current convex hull. It is also only a beginning and the technology seems to be accelerating. The current prominent technology is LLM, but, it may possible that we will soon see a more capable AI technology. I remember that 20 year ago, people were talking which area between AI and quantum computing would fade away soon… and we now have the current situation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("This is a fair objection, but I think it is also fair to say, we have no idea where we are heading. I don’t see good evidence to say that the AI capabilities will move beyond the convex hull, just as I don’t see good evidence that they won’t.")

#text("But this framing is something that drives me crazy. I see so many people dispassionately commenting along these lines here, on reddit, on twitter, in conversations in math department hallways. If that is what you believe — that LLMs will increase in capabilities ad infinitum beyond what humans can do — how can you not feel urgency to make broad societal change?")

#text("If you *truly* believe that that is where AI is headed, what happens to mathematicians is the least of our worries. The consequence of AI having superhuman intelligence and creativity is that any intellectual job (which, I think it is fair to say, are some of the most highly prized, most human, most fulfilling, most meaningful) is likely to be wiped out and replaced by AI. The economic fallout will be disastrous, not to mention the psychological effects on hundreds of millions of people feeling existential malaise. The energy costs will accelerate climate change, which we had previously been making strides on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of birdsnfrogs")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695259")[#strong[#text("birdsnfrogs")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Right, that’s why its good to think about things that we need to be doing regardless of how much more (or how little) the system advance from where they are now. Even if they don’t advance any more from where they are today, big reforms are needed. In fact, a bit of what I was trying to get to with the section on skateboarding is that some of the things that need reform now already needed reform for a while.")

#text("The fast push of the LLMs from the big companies are creating new problems for the community, for sure, but a lot of the damage is coming from the way their products and their fast adaption interact with fault lines and dysfunctions already present in our profession")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695144")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Should we be setting a higher bar for what we expect AI to deliver, now that it has assimilated the collective knowledge of our civilization? Said differently, how many discoveries would human academics make if they had anything close to the resources it takes to train a state of the art LLM?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695146")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thank you for the post, it does help ease the sadness of an LLM solving big open math problems to think it’s standing on the shoulders of giants that built the theory (not to mention that created the math for AI itself). Yet regarding this quote: “The framework of LLMs as cultural technologies, to the extent that it reflects existing LLMs, suggests that this is a type of contribution we cannot expect to find in their output.” Is there any research that would suggest this lack of capabilities? Are we not ourselves also in our own convex hull? Euler didn’t just have the math from before his time but thousands of stimuli that entered his eyes and ears, ideas and concepts of his time. When would we even know that AI left the convex hull we left for it? We are currently completely unaware of the reach that can be achieved by combining every idea in its training. It seems to me that all that we know for sure to be new could just be a lack of awareness of the effects that alter the inner processes of our thoughts. I could see a place where math becomes the joy of understanding through our own lenses what AI discovered, as the joy a student has in understanding the complex nature that has been already discovered before her, but for discovery itself, I think it might be harder to tell.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a2e9b47c8b2f5f94ef201a03c1b78925c1e3dfc4d4fae54a5982c4556acc66-63defeab6eae6572faf845285de5a655ca985eb2ae60c492e8cfae8ad5bdbb68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lnurbek")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695166")[#strong[#text("lnurbek")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Hi Nestor, thanks for the post. Today I had the same thought: it is not accurate to treat current AI developments (in general, and in mathematics specifically) as exogenous to our discipline and profession. These results are a direct consequence, and therefore part, of science and mathematics. Narrowly, the basic technology is based on, among other things, the mathematical theory of optimization, probability theory, differential equations, etc. Broadly, mathematics and other sciences have contributed by training the workforce that built these technologies, including the very framework for performing and communicating research (a super basic example that everyone now takes for granted is standard mathematical notation, which is relatively recent). Of course, not to mention the contribution of the huge body of mathematical and scientific work as training data for these models.")

#text("Hence, recent developments must be treated as developments within mathematics and the sciences (at least the aspects related to mathematics and the sciences) and acted upon as such. So the situation has indeed similarities with the developments related to the crisis in foundations that Terry Tao mentions in his article “Mathematics in the Age of AI.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I think the AMS — in collaboration with world math organizations — should set up a new kind of on-line reviewing journal. Quick response is essential. Various Blogs have facilities for reader comments (which can also be reviewed). Reviews do not have to be “complete” — as early awareness is important. A new kind of index will also be needed so people can search quickly for relevant opinions. AI is here to stay, and we have to learn how to cope in real time with these developments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The effect of reading this piece for me is like going through a $200/hour therapy session. Very comforting. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of birdsnfrogs")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695257")[#strong[#text("birdsnfrogs")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("That’s very kind of you, thank you! it means a lot the essay could be helpful")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93ea3721bdd8548d14fa4a9b76621a160c698690a6e1b0143f201ba8e6d0684c-7a5d2d1cce7ce5687644d9966f0c0cebe096b721d796fb994311c503718fc5a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jhschenker")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695232")[#strong[#text("jhschenker")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Nestor, this is a beautiful post. You have distilled an optimistic vision of how mathematics can grow with this new technology. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef56db71d958f5047139912a0c9b31b770236c367cfa407466708f3d3ed9626e-8536151e32c141f00c22d3db8a7c045b3e045c1ab1cdb6157c04c755d0e6b6c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of birdsnfrogs")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695258")[#strong[#text("birdsnfrogs")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Thank you Jeff — and I am optimistic despite the serious challenges because I have hope that we can do the needed reforms to take our profession into the new era, this is why this conversations are so important")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Wish granted? ")#link("https://arxiv.org/pdf/2609.11189")[#text("Vector Balancing via Directional Total Variation")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d44d47ab6900dede7250a9c2cb7021ec1de817e4eed7e1ad7056e426d2e1060-b99ccc36339356d3dc3db6916e7f145f9208b6cf747871342c9d6820fc062780.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kamdh")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695417")[#strong[#text("kamdh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("While I agree that LLMs are cultural technologies, I disagree about the “convex hull”. In the particular use case where many thousands of hours of compute time by many agents arrives at the result, as with these math proofs, new ideas can be found. In machine learning we would call this “generalization” rather than “interpolation” (although I think this is a kind of metaphor here).")

#text("With so much compute, LLMs can perform random search in idea space, and it seems reasonable find new kinds of approaches. I’m not sure we’ve seen evidence for it yet, but it seems possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-695671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("This is a fantastic essay—well-written and well-considered. This concept of LLMs as a cultural/social technology reminds me of a recent ")#link("https://www.youtube.com/watch?v=a_ZKYH8v_do")[#text("StarTalk podcast")]#text(" where Neil deGrasse Tyson invited Jaron Lanier to discuss what he calls the “AI illusion.” There, he argues that “AI should be understood as a massive collaboration of people, built from human data.”")

#text("I agree with the notion that LLMs have been built on, and therefore represent, the enormous corpus of human knowledge. However, if this technology is to advance the field of mathematics (and of other scientific disciplines) constructively, then there needs to be a democratization of this technology, placing its power in the hands of the public, that allows for researchers to trust it. The recent ")#link("https://terrytao.wordpress.com/2026/09/17/a-cern-for-ai-assisted-science/")[#text("guest post by Dimitris Koukoulopoulos")]#text(" on this very blog makes an excellent case for this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What should we tell our students? | What's new")]], [#link("https://terrytao.wordpress.com/2026/09/13/happy-those-able-to-know-the-causes-of-things/#comment-697233")[#strong[#text("What should we tell our students? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("[…] literature. I am particularly fond of the hypothesis (or toy model, as he called it) put forward by Nestor Guillen in a recent blog post, where he argues that LLMs may work within the confines of the convex hull of ideas that are […]")
]
