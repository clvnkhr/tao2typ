// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/
// Converted to Typst by tao2typ: "2026-10-14T16:37:55.434614+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 May 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/")[#text("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A ")#emph[#text("capset")]#text(" in the vector space ")#mi("{{\\bf F}_3^n}")#text(" over the finite field ")#mi("{{\\bf F}_3}")#text(" of three elements is a subset ")#mi("{A}")#text(" of ")#mi("{{\\bf F}_3^n}")#text(" that does not contain any lines ")#mi("{\\{ x,x+r,x+2r\\}}")#text(", where ")#mi("{x,r \\in {\\bf F}_3^n}")#text(" and ")#mi("{r \\neq 0}")#text(". A basic problem in additive combinatorics (discussed in one of the ")#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("very first posts on this blog")]#text(") is to obtain good upper and lower bounds for the maximal size of a capset in ")#mi("{{\\bf F}_3^n}")#text(".")

#text("Trivially, one has ")#tao-math("{\\left|A\\right| \\leq 3^n}", block: false)#text(". Using Fourier methods (and the density increment argument of Roth), the bound of ")#tao-math("{\\left|A\\right| \\leq O( 3^n / n )}", block: false)#text(" was obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=1335785")[#text("by Meshulam")]#text(", and improved only as late as 2012 to ")#mi("{O( 3^n /n^{1+c})}")#text(" for some absolute constant ")#mi("{c>0}")#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2869028")[#text("by Bateman and Katz")]#text(". But in a very recent breakthrough, ")#link("https://quomodocumque.wordpress.com/2016/05/13/bounds-for-cap-sets/")[#text("Ellenberg")]#text(" (and independently ")#link("http://homepage.tudelft.nl/64a8q/progressions.pdf")[#text("Gijswijt")]#text(") obtained the exponentially superior bound ")#tao-math("{\\left|A\\right| \\leq O( 2.756^n )}", block: false)#text(", using a version of the polynomial method recently introduced ")#link("https://arxiv.org/abs/1605.01506")[#text("by Croot, Lev, and Pach")]#text(". (In the converse direction, a ")#link("http://www.ams.org/mathscinet-getitem?mr=2031694")[#text("construction of Edel")]#text(" gives capsets as large as ")#mi("{(2.2174)^n}")#text(".) Given the success of the polynomial method in superficially similar problems such as the finite field Kakeya problem (discussed in ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("this previous post")]#text("), it was natural to wonder that this method could be applicable to the cap set problem (see for instance ")#link("http://mathoverflow.net/a/43549/766")[#text("this MathOverflow comment of mine")]#text(" on this from 2010), but it took a surprisingly long time before Croot, Lev, and Pach were able to identify the precise variant of the polynomial method that would actually work here.")

#text("The proof of the capset bound is very short (Ellenberg’s and Gijswijt’s preprints are both 3 pages long, and Croot-Lev-Pach is 6 pages), but I thought I would present a slight reformulation of the argument which treats the three points on a line in ")#mi("{{\\bf F}_3}")#text(" symmetrically (as opposed to treating the third point differently from the first two, as is done in the Ellenberg and Gijswijt papers; Croot-Lev-Pach also treat the middle point of a three-term arithmetic progression differently from the two endpoints, although this is a very natural thing to do in their context of ")#mi("{({\\bf Z}/4{\\bf Z})^n}")#text("). The basic starting point is this: if ")#mi("{A}")#text(" is a capset, then one has the identity ")#metadata(none) <tao-45e84635bc4803c5cc5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\delta_{0^n}( x+y+z ) = \\sum_{a \\in A} \\delta_a(x) \\delta_a(y) \\delta_a(z)")]]



#text(" for all ")#mi("{(x,y,z) \\in A^3}")#text(", where ")#mi("{\\delta_a(x) := 1_{a=x}}")#text(" is the Kronecker delta function, which we view as taking values in ")#mi("{{\\bf F}_3}")#text(". Indeed, ")#link(<tao-45e84635bc4803c5cc5d>)[#text("(1)")]#text(" reflects the fact that the equation ")#mi("{x+y+z=0}")#text(" has solutions precisely when ")#mi("{x,y,z}")#text(" are either all equal, or form a line, and the latter is ruled out precisely when ")#mi("{A}")#text(" is a capset.")

#text("To exploit ")#link(<tao-45e84635bc4803c5cc5d>)[#text("(1)")]#text(", we will show that the left-hand side of ")#link(<tao-45e84635bc4803c5cc5d>)[#text("(1)")]#text(" is “low rank” in some sense, while the right-hand side is “high rank”. Recall that a function ")#mi("{F: A \\times A \\rightarrow {\\bf F}}")#text(" taking values in a field ")#mi("{{\\bf F}}")#text(" is of ")#emph[#text("rank one")]#text(" if it is non-zero and of the form ")#mi("{(x,y) \\mapsto f(x) g(y)}")#text(" for some ")#mi("{f,g: A \\rightarrow {\\bf F}}")#text(", and that the ")#link("https://en.wikipedia.org/wiki/Rank_(linear_algebra)")[#text("rank")]#text(" of a general function ")#mi("{F: A \\times A \\rightarrow {\\bf F}}")#text(" is the least number of rank one functions needed to express ")#mi("{F}")#text(" as a linear combination. More generally, if ")#mi("{k \\geq 2}")#text(", we define the ")#emph[#text("rank")]#text(" of a function ")#mi("{F: A^k \\rightarrow {\\bf F}}")#text(" to be the least number of “rank one” functions of the form")

#align(center)[#tao-fit-display[#mitex("(x_1,\\dots,x_k) \\mapsto f(x_i) g(x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_k)")]]

#text("for some ")#mi("{i=1,\\dots,k}")#text(" and some functions ")#mi("{f: A \\rightarrow {\\bf F}}")#text(", ")#mi("{g: A^{k-1} \\rightarrow {\\bf F}}")#text(", that are needed to generate ")#mi("{F}")#text(" as a linear combination. For instance, when ")#mi("{k=3}")#text(", the rank one functions take the form ")#mi("{(x,y,z) \\mapsto f(x) g(y,z)}")#text(", ")#mi("{(x,y,z) \\mapsto f(y) g(x,z)}")#text(", ")#mi("{(x,y,z) \\mapsto f(z) g(x,y)}")#text(", and linear combinations of ")#mi("{r}")#text(" such rank one functions will give a function of rank at most ")#mi("{r}")#text(".")

#text("It is a standard fact in linear algebra that the rank of a diagonal matrix is equal to the number of non-zero entries. This phenomenon extends to higher dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Rank of diagonal hypermatrices)")]#text(" ")#metadata(none) <tao-a4cf5e703ea05d936c9c>#text(" Let ")#mi("{k \\geq 2}")#text(", let ")#mi("{A}")#text(" be a finite set, let ")#mi("{{\\bf F}}")#text(" be a field, and for each ")#mi("{a \\in A}")#text(", let ")#mi("{c_a \\in {\\bf F}}")#text(" be a coefficient. Then the rank of the function ")#metadata(none) <tao-0e5befa2da36fed29214>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(x_1,\\dots,x_k) \\mapsto \\sum_{a \\in A} c_a \\delta_a(x_1) \\dots \\delta_a(x_k)")]]



#text(" is equal to the number of non-zero coefficients ")#mi("{c_a}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{k}")#text(". As mentioned above, the case ")#mi("{k=2}")#text(" follows from standard linear algebra, so suppose now that ")#mi("{k>2}")#text(" and the claim has already been proven for ")#mi("{k-1}")#text(".")

#text("It is clear that the function ")#link(<tao-0e5befa2da36fed29214>)[#text("(2)")]#text(" has rank at most equal to the number of non-zero ")#mi("{c_a}")#text(" (since the summands on the right-hand side are rank one functions), so it suffices to establish the lower bound. By deleting from ")#mi("{A}")#text(" those elements ")#mi("{a \\in A}")#text(" with ")#mi("{c_a=0}")#text(" (which cannot increase the rank), we may assume without loss of generality that all the ")#mi("{c_a}")#text(" are non-zero. Now suppose for contradiction that ")#link(<tao-0e5befa2da36fed29214>)[#text("(2)")]#text(" has rank at most ")#tao-math("{\\left|A\\right|-1}", block: false)#text(", then we obtain a representation")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in A} c_a \\delta_a(x_1) \\dots \\delta_a(x_k)")]]

#metadata(none) <tao-c608880ca8bf6120ce82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("= \\sum_{i=1}^k \\sum_{\\alpha \\in I_i} f_{i,\\alpha}(x_i) g_{i,\\alpha}( x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_k)")]]



#text(" for some sets ")#mi("{I_1,\\dots,I_k}")#text(" of cardinalities adding up to at most ")#tao-math("{\\left|A\\right|-1}", block: false)#text(", and some functions ")#mi("{f_{i,\\alpha}: A \\rightarrow {\\bf F}}")#text(" and ")#mi("{g_{i,\\alpha}: A^{k-1} \\rightarrow {\\bf R}}")#text(".")

#text("Consider the space of functions ")#mi("{h: A \\rightarrow {\\bf F}}")#text(" that are orthogonal to all the ")#mi("{f_{k,\\alpha}}")#text(", ")#mi("{\\alpha \\in I_k}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\in A} f_{k,\\alpha}(x) h(x) = 0")]]

#text("for all ")#mi("{\\alpha \\in I_k}")#text(". This space is a vector space whose dimension ")#mi("{d}")#text(" is at least ")#tao-math("{\\left|A\\right| - \\left|I_k\\right|}", block: false)#text(". A basis of this space generates a ")#tao-math("{d \\times \\left|A\\right|}", block: false)#text(" coordinate matrix of full rank, which implies that there is at least one non-singular ")#mi("{d \\times d}")#text(" minor. This implies that there exists a function ")#mi("{h: A \\rightarrow {\\bf F}}")#text(" in this space which is nowhere vanishing on some subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of cardinality at least ")#tao-math("{\\left|A\\right|-\\left|I_k\\right|}", block: false)#text(".")

#text("If we multiply ")#link(<tao-c608880ca8bf6120ce82>)[#text("(3)")]#text(" by ")#mi("{h(x_k)}")#text(" and sum in ")#mi("{x_k}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in A} c_a h(a) \\delta_a(x_1) \\dots \\delta_a(x_{k-1})")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{i=1}^{k-1} \\sum_{\\alpha \\in I_i} f_{i,\\alpha}(x_i)\\tilde g_{i,\\alpha}( x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_{k-1})")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde g_{i,\\alpha}(x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_{k-1})")]]

#align(center)[#tao-fit-display[#mitex(":= \\sum_{x_k \\in A} g_{i,\\alpha}(x_1,\\dots,x_{i-1},x_{i+1},\\dots,x_k) h(x_k).")]]

#text("The right-hand side has rank at most ")#tao-math("{\\left|A\\right|-1-\\left|I_k\\right|}", block: false)#text(", since the summands are rank one functions. On the other hand, from induction hypothesis the left-hand side has rank at least ")#tao-math("{\\left|A\\right|-\\left|I_k\\right|}", block: false)#text(", giving the required contradiction. ")#mi("\\Box")

#text("On the other hand, we have the following (symmetrised version of a) beautifully simple observation of Croot, Lev, and Pach:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-6f17fbded209ebec21bc>#text(" On ")#mi("{({\\bf F}_3^n)^3}")#text(", the rank of the function ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)}")#text(" is at most ")#mi("{3N}")#text(", where")

#align(center)[#tao-fit-display[#mitex("N := \\sum_{a,b,c \\geq 0: a+b+c=n, b+2c \\leq 2n/3} \\frac{n!}{a!b!c!}.")]]
]

#emph[#text("Proof:")]#text(" Using the identity ")#mi("{\\delta_0(x) = 1 - x^2}")#text(" for ")#mi("{x \\in {\\bf F}_3}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\delta_{0^n}(x+y+z) = \\prod_{i=1}^n (1 - (x_i+y_i+z_i)^2).")]]

#text("The right-hand side is clearly a polynomial of degree ")#mi("{2n}")#text(" in ")#mi("{x,y,z}")#text(", which is then a linear combination of monomials")

#align(center)[#tao-fit-display[#mitex("x_1^{i_1} \\dots x_n^{i_n} y_1^{j_1} \\dots y_n^{j_n} z_1^{k_1} \\dots z_n^{k_n}")]]

#text("with ")#mi("{i_1,\\dots,i_n,j_1,\\dots,j_n,k_1,\\dots,k_n \\in \\{0,1,2\\}}")#text(" with")

#align(center)[#tao-fit-display[#mitex("i_1 + \\dots + i_n + j_1 + \\dots + j_n + k_1 + \\dots + k_n \\leq 2n.")]]

#text("In particular, from the pigeonhole principle, at least one of ")#mi("{i_1 + \\dots + i_n, j_1 + \\dots + j_n, k_1 + \\dots + k_n}")#text(" is at most ")#mi("{2n/3}")#text(".")

#text("Consider the contribution of the monomials for which ")#mi("{i_1 + \\dots + i_n \\leq 2n/3}")#text(". We can regroup this contribution as")

#align(center)[#tao-fit-display[#mitex("\\sum_\\alpha f_\\alpha(x) g_\\alpha(y,z)")]]

#text("where ")#mi("{\\alpha}")#text(" ranges over those ")#mi("{(i_1,\\dots,i_n) \\in \\{0,1,2\\}^n}")#text(" with ")#mi("{i_1 + \\dots + i_n \\leq 2n/3}")#text(", ")#mi("{f_\\alpha}")#text(" is the monomial")

#align(center)[#tao-fit-display[#mitex("f_\\alpha(x_1,\\dots,x_n) := x_1^{i_1} \\dots x_n^{i_n}")]]

#text("and ")#mi("{g_\\alpha: {\\bf F}_3^n \\times {\\bf F}_3^n \\rightarrow {\\bf F}_3}")#text(" is some explicitly computable function whose exact form will not be of relevance to our argument. The number of such ")#mi("{\\alpha}")#text(" is equal to ")#mi("{N}")#text(", so this contribution has rank at most ")#mi("{N}")#text(". The remaining contributions arising from the cases ")#mi("{j_1 + \\dots + j_n \\leq 2n/3}")#text(" and ")#mi("{k_1 + \\dots + k_n \\leq 2n/3}")#text(" similarly have rank at most ")#mi("{N}")#text(" (grouping the monomials so that each monomial is only counted once), so the claim follows.")

#text("Upon restricting from ")#mi("{({\\bf F}_3^n)^3}")#text(" to ")#mi("{A^3}")#text(", the rank of ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)}")#text(" is still at most ")#mi("{3N}")#text(". The two lemmas then combine to give the Ellenberg-Gijswijt bound")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| \\leq 3N.", block: true)]]

#text("All that remains is to compute the asymptotic behaviour of ")#mi("{N}")#text(". This can be done using the general tool of ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_theorem")[#text("Cramer’s theorem")]#text(", but can also be derived from Stirling’s formula (discussed in ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("this previous post")]#text("). Indeed, if ")#mi("{a = (\\alpha+o(1)) n}")#text(", ")#mi("{b = (\\beta+o(1)) n}")#text(", ")#mi("{c = (\\gamma+o(1)) n}")#text(" for some ")#mi("{\\alpha,\\beta,\\gamma \\geq 0}")#text(" summing to ")#mi("{1}")#text(", Stirling’s formula gives")

#align(center)[#tao-fit-display[#mitex("\\frac{n!}{a!b!c!} = \\exp( n (h(\\alpha,\\beta,\\gamma) + o(1)) )")]]

#text("where ")#mi("{h}")#text(" is the entropy function")

#align(center)[#tao-fit-display[#mitex("h(\\alpha,\\beta,\\gamma) = \\alpha \\log \\frac{1}{\\alpha} + \\beta \\log \\frac{1}{\\beta} + \\gamma \\log \\frac{1}{\\gamma}.")]]

#text("We then have")

#align(center)[#tao-fit-display[#mitex("N = \\exp( n (X + o(1))")]]

#text("where ")#mi("{X}")#text(" is the maximum entropy ")#mi("{h(\\alpha,\\beta,\\gamma)}")#text(" subject to the constraints")

#align(center)[#tao-fit-display[#mitex("\\alpha,\\beta,\\gamma \\geq 0; \\alpha+\\beta+\\gamma=1; \\beta+2\\gamma \\leq 2/3.")]]

#text("A routine Lagrange multiplier computation shows that the maximum occurs when")

#tao-aligned(keep: true)[


#tao-math("\\alpha  & = \\frac{32}{3(15 + \\sqrt{33})}", block: true)



#tao-math("\\beta  & = \\frac{4(\\sqrt{33}-1)}{3(15+\\sqrt{33})}", block: true)



#tao-math("\\gamma  & = \\frac{(\\sqrt{33}-1)^2}{6(15+\\sqrt{33})}", block: true)
]

#text("and ")#mi("{h(\\alpha,\\beta,\\gamma)}")#text(" is approximately ")#mi("{1.013455}")#text(", giving rise to the claimed bound of ")#mi("{O( 2.756^n )}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" As noted in the Ellenberg and Gijswijt papers, the above argument extends readily to other fields than ")#mi("{{\\bf F}_3}")#text(" to control the maximal size of subset of ")#mi("{{\\bf F}^n}")#text(" that has no non-trivial solutions to the equation ")#mi("{ax+by+cz=0}")#text(", where ")#mi("{a,b,c \\in {\\bf F}}")#text(" are non-zero constants that sum to zero. Of course one replaces the function ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)}")#text(" in Lemma ")#link(<tao-6f17fbded209ebec21bc>)[#text("2")]#text(" by ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(ax+by+cz)}")#text(" in this case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" This symmetrised formulation suggests that one possible way to improve slightly on the numerical quantity ")#mi("{2.756}")#text(" by finding a more efficient way to decompose ")#mi("{\\delta_{0^n}(x+y+z)}")#text(" into rank one functions, however I was not able to do so (though such improvements are reminiscent of the ")#link("https://en.wikipedia.org/wiki/Strassen_algorithm")[#text("Strassen type algorithms for fast matrix multiplication")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" It is tempting to see if this method can get non-trivial upper bounds for sets ")#mi("{A}")#text(" with no length ")#mi("{4}")#text(" progressions, in (say) ")#mi("{{\\bf F}_5^n}")#text(". One can run the above arguments, replacing the function")

#align(center)[#tao-fit-display[#mitex("(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)")]]

#text("with")

#align(center)[#tao-fit-display[#mitex("(x,y,z,w) \\mapsto \\delta_{0^n}(x-2y+z) \\delta_{0^n}(y-2z+w);")]]

#text("this leads to the bound ")#tao-math("{\\left|A\\right| \\leq 4N}", block: false)#text(" where")

#align(center)[#tao-fit-display[#mitex("N := \\sum_{a,b,c,d,e \\geq 0: a+b+c+d+e=n, b+2c+3d+4e \\leq 2n} \\frac{n!}{a!b!c!d!e!}.")]]

#text("Unfortunately, ")#mi("{N}")#text(" is asymptotic to ")#mi("{\\frac{1}{2} 5^n}")#text(" and so this bound is in fact slightly worse than the trivial bound ")#tao-math("{\\left|A\\right| \\leq 5^n}", block: false)#text("! However, there is a slim chance that there is a more efficient way to decompose ")#mi("{\\delta_{0^n}(x-2y+z) \\delta_{0^n}(y-2z+w)}")#text(" into rank one functions that would give a non-trivial bound on ")#mi("{A}")#text(". I experimented with a few possible such decompositions but unfortunately without success.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Return now to the capset problem. Since Lemma ")#link(<tao-a4cf5e703ea05d936c9c>)[#text("1")]#text(" is valid for any field ")#mi("{{\\bf F}}")#text(", one could perhaps hope to get better bounds by viewing the Kronecker delta function ")#mi("{\\delta}")#text(" as taking values in another field than ")#mi("{{\\bf F}_3}")#text(", such as the complex numbers ")#mi("{{\\bf C}}")#text(". However, as soon as one works in a field of characteristic other than ")#mi("{3}")#text(", one can adjoin a cube root ")#mi("{\\omega}")#text(" of unity, and one now has the Fourier decomposition")

#align(center)[#tao-fit-display[#mitex("\\delta_{0^n}(x+y+z) = \\frac{1}{3^n} \\sum_{\\xi \\in {\\bf F}_3^n} \\omega^{\\xi \\cdot x} \\omega^{\\xi \\cdot y} \\omega^{\\xi \\cdot z}.")]]

#text("Moving to the Fourier basis, we conclude from Lemma ")#link(<tao-a4cf5e703ea05d936c9c>)[#text("1")]#text(" that the function ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)}")#text(" on ")#mi("{{\\bf F}_3^n}")#text(" now has rank exactly ")#mi("{3^n}")#text(", and so one cannot improve upon the trivial bound of ")#tao-math("{\\left|A\\right| \\leq 3^n}", block: false)#text(" by this method using fields of characteristic other than three as the range field. So it seems one has to stick with ")#mi("{{\\bf F}_3}")#text(" (or the algebraic completion thereof).")
]

#text("Thanks to Jordan Ellenberg and Ben Green for helpful discussions.")

#heading(level: 1)[#text("Comments (81)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468730")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Beautiful! The symmetric formulation “feels right” and is surely the best way to express it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("It seems to be a proof from “the book”!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3edc2b5793392836af950eeb23fe4605cd1a49edfd489217490ae36ad4439b53-0befbbaa0c92eb31ff3b7ad1eb168e3471bcece25afb5f3e4263ee0f85a8dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nets Katz")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468732")[#strong[#text("Nets Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Terry, is it obvious that decompositions of the quadratic form in Remark 5 into rank 1 pieces is the only way to go? Any argument that gives a lower bound for the dimension of a set of vectors which pairwise vanish would work. Must such an argument have a simple algebraic formulation? I would like to comment that applying the technology to characteristic zero meets with similar obstructions. A simple model for characteristic zero is to replace F_p^d addition with addition that has carrying but for which the carrying in each digit is independent. Then you have to look at a product of 2^{d-1} forms, one for each carrying profile.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468740")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I was thinking along similar lines, Nets. It’s an interesting question — what formal properties of polynomials are needed to make some argument of this kind work? Are there families of functions on (Z/NZ) which are “polynomial-like” enough? I truly don’t know. My first instinct would be to look at the Witt vector construction of (Z/p^n Z), which is somehow of the most canonical way of expressing “carrying” and passing from char p to char 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468746")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("It could well be that working with more general classes of functions than polynomials of a given degree would be useful – for instance polynomials taking values in some other commutative ring, or even a non-commutative ring (though the linear algebra becomes replaced by something nastier of course if one strays too far from the field setting). One could possibly play with completely non-linear spaces also. Maybe it is worth working with very low dimensional examples (as in my other recent comment here) to experiment if there are other decompositions than the polynomial ones which are more efficient. I played around for a while with multi-degrees instead of degrees, for instance, but eventually concluded that one did not gain much asymptotically by doing so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468765")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("It depends on whether we want to replace the additive structure of polynomials or just multiplicative. Since like most mathematicians I will only stop using linear algebra under extreme duress, I thought about how to generalize the polynomial method here while still using the notion of tensor rank to measure the complexity of functions.")

#text("So we can ask the general question: given a tensor f in V^3, viewing f tensor f tensor … f as a tensor in (V^k)^3, how may we upper bound its tensor rank as a function of k?")

#text("We may also try to lower bound its tensor rank, to let us know that we are not missing an easy way to improve the bound, or for use on the other side of the inequality. So maybe the right question is what is the asymptotic of the tensor rank – is it always an exponential function in k?")

#text("Anyways the upper bound argument generalizes immediately from polynomial functions to any functions that can be written as a sum of v_a tensor v_b tensor v_c, where v_a,v_b,v_c lie in some list of vector that come with weights w_a,w_b,w_c, such that we have an upper bound w_a + w_b + w_c < W for every term appearing in the sum.")

#text("Then we get an upper bound in terms of the maximum entropy of a probability distribution on the indices a where the expected value of w_a is at most W/3, by precisely the same argument.")

#text("To recover the polynomial special case, take v_a,v_b,v_c to be monomials in one variable, w_a,w_b,w_c the degree of the monomial, and W the degree of the polynomial function.")

#text("In the case where v_a range through a basis v_1,..,v_n (e.g. the monomials in one variable over F_p of degree less than p), then as soon as W/3 is less than the average value of w under the uniform distribution we will force the distribution to have an entropy slightly smaller than log n and hence we will get a nontrivial bound for the tensor ranks.")

#text("So for a 3-variable polynomial over F_p, the degree needs to be less than 3(p-1)/2 to get a nontrivial bound, and for a d-variable polynomial, less than d(p-1)/2.")

#text("In what should be interesting to some, this condition is precisely the Hilbert-Mumford criterion for GIT-instability under the action of (SL_n)^3 on P^{n^3-1}. So we can summarize the key idea in higher-level language as: There is a power savings bound for the rank of powers of GIT-unstable tensors.")

#text("Are there any known bounds for ranks of tensor powers that cannot be derived in this way from tuples of vectors and weight functions? Is there any method that would allow us to lower bound tensor ranks so as to show that this upper bound is sometimes sharp?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("If ")#mi("V")#text(" has some basis ")#mi("v_1,\\dots,v_n")#text(", then we can associate a “Newton diagram” ")#mi("\\Delta \\subset \\{1,\\dots,n\\}^3")#text(" to a function ")#mi("f \\in V^{\\otimes 3}")#text(" by declaring ")#mi("(i,j,k)")#text(" to be an element of ")#mi("\\Delta")#text(" if the ")#mi("v_i \\otimes v_j \\otimes v_k")#text(" coefficient of ")#mi("f")#text(" is non-zero. Define the “capacity” ")#mi("c(\\Delta)")#text(" of this diagram to be the maximum value of ")#mi("\\min( h(X), h(Y), h(Z))")#text(", where ")#mi("(X,Y,Z)")#text(" ranges over random variables taking values in ")#mi("\\Delta")#text(" and ")#mi("h")#text(" denotes Shannon entropy. Then I think Stirling’s formula ends up saying that the rank of ")#mi("f^{\\otimes n}")#text(" (viewed as an element of ")#mi("(V^{\\otimes n})^{\\otimes 3}")#text(") is at most ")#mi("\\exp( (c(\\Delta)+o(1)) n)")#text(", basically because every “monomial” in ")#mi("f^{\\otimes n}")#text(" becomes associated with a discrete random variable ")#mi("(X,Y,Z)")#text(" in ")#mi("\\Delta")#text(" (taking ")#mi("n")#text(" values). I think this bound covers the previous bounds on rank mentioned here, though I haven’t checked fully.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468817")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("I think the bound you sketched and the bound I sketched are the same because the problems you need to solve to compute each bound are dual in a convex optimization sense. Given a weight function, you can upper bound the entropy of the marginal distributions of any probability distribution by observing min(E(w_X,w_Y,w_Z))<E(w_X+w_Y+w_Z)<sup(w_X+w_Y+w_Z)<W. If you have any distribution, you can define a weight function as the derivative of the entropy of each marginal distribution by the probability of each marginal value times the Lagrange multiplier of the entropy. Then the upper bound we get from the weight function is exactly the minimum entropy of a marginal distribution.")

#text("This makes it easy to check you aren't missing an obvious improvement – write down a weight function and a distribution and check that their entropies agree.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("I think one may have to generalise to the non-symmetric setting where the weight functions associated to each of the three components ")#mi("v_a, v_b, v_c")#text(" are allowed to be different from each other, but I think I agree with your point that the two formulations are dual.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468733")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Typos (presumptive?):")#linebreak()#text(" for “F_3^n” read “F_{3^n}” (throughout);")#linebreak()#text(" for “F^3” read “F_3” (once).")

#emph[#text("[Second erratum corrected. First is not an erratum, I have tried to clarify in post – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468736")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("One can not improve on your bound for 4-term arithmetic progressions using only polynomials. Indeed if ")#mi("f")#text(" is any multivariate polynomial over ")#mi("\\mathbb F_p")#text(" that is ")#mi("0")#text(" outside a a linear subspace of codimension ")#mi("c")#text(" but not ")#mi("0")#text(" everywhere, then ")#mi("f")#text(" restricted to some subspace of dimension ")#mi("d")#text(" is a polynomial that vanishes outside a point but not at that point, which by a fragment of Chevalley-Warning (")#link("http://mathoverflow.net/a/238527/18060")[#text("http://mathoverflow.net/a/238527/18060")]#text(") has degree at least ")#mi("c(p-1)")#text(". So a nontrivial polynomial which is nonvanishing for ")#mi("4")#text("-term arithmetic progressions in ")#mi("\\mathbb F_p^n")#text(" has degree at least ")#mi("2n(p-1)")#text(", and the upper bound for the degree in a single vector is ")#mi("n(p-1)/2")#text(", which is precisely the critical value one needs to beat to improve the bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468741")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("One note about this higher notion of “rank” is that rank <= r is not a closed condition, the way it is for matrices! I always find this confusing and it's probably good to keep it in mind.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468763")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Are you sure that is true for this notion of tensor rank and not just the more commonly used notion of tensor rank? I might have a proof that this notion of rank is in fact semicontinuous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468766")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Oh is Terry’s notion not the same as usual tensor rank? I thought it was, but didn’t think about it carefully.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468769")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("The usual definition allows only functions of the form f(x)g(y)h(z), which is much more restrictive. For instance it is clear that every n x n x n tensor has rank at most n in Terry’s sense but this is not true in the usual sense. Maybe we should call Terry’s version something like lax tensor rank to remove ambiguity.")

#text("Let me sketch my argument that the space of tensors of bounded lax tensor rank is closed:")

#text("A tensor in V tensor V tensor V is of rank < k if it is in the space spanned by W1 x V x V + V x W2 x V + V x V x W3 where dim W1 + dim W2 + dim W3 < k. Now for fixed W1, W2, W3 the space spanned by W1 x V x V + V x W2 x V + V x V x W3 is a linear subspace of V x V x V and varies smoothly as W1 , W2, W3 vary in the Grassmanian of subspaces of fixed dimension, so this forms a closed subset of V tensor V tensor V x G(dim W1, V) x G(dim W2, V) x G(dim W3, V) that projects to a closed subset of V tensor V tensor V. Then a finite sum over all triples of dimensions satisfying the inequality gives the desired result.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468784")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Oh good point! I had failed to grasp this distinction.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468743")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Also two quick observations:")

#text("1. It seems that the bound given for sets in F_p^n with no 3-term arithmetic progressions is ((c+o(1))p)^n for some constant c<1 that I doubt can be put in closed form.")

#text("2. For each set S of size 2n+1 in F_p one gets power-saving bounds for subsets of F_p^n that do not contain the image of S under any nonconstant map whose coordinates are polynomials of degree n. I didn't see a trivial proof of power savings here for general S (though for special S we may reduce using special polynomials to a simpler bound) but I also didn't see a relationship to any well-known open problem in combinatorics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8854e8079e138fed1f54f00abd9964ce13a0014016e08ba09f39fb2497a482-9bfab7bae0919ae8f5ea05180089a63d8071ed16317a8a460c981ca3ac36de5b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Naslund")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468748")[#strong[#text("Eric Naslund")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("In fact we can show that c=e^{-1/6}. That is we have the upper bound (e^{-1/6}+o(1))^n p^n, where the o(1) term is positive and tending to zero as p–>infty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468745")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("A small but perhaps amusing computation: for the question of finding the largest number of cards in the game Set without a “set” (or equivalently, the largest capset in ")#mi("{\\bf F}_3^4")#text("), the upper bound given here is")

#mi("3\\sum_{a+b+c = 4; b+2c \\leq 8/3} \\frac{4!}{a!b!c!} = 45.")

#text("This can be compared with the asymptotic prediction of ")#mi("(2.756)^4 \\approx 58")#text(" for the upper bound (or the asymptotic prediction of ")#mi("(2.2174)^4 \\approx 24")#text(" for the lower bound. Theorem 1.2 of ")#link("http://www.sciencedirect.com/science/article/pii/0097316595900241")[#text("Meshulam’s paper")]#text(" using the Fourier method gives an upper bound of ")#mi("2 \\times 3^4 / 3 = 54")#text(". The maximal size of a capset in ")#mi("{\\bf F}_3^4")#text(" is actually known to be 20 by the ")#link("http://www.ams.org/mathscinet-getitem?mr=363952")[#text("work of Pellegrino")]#text(". So even in this low dimensional case, the bound given by the polynomial method improves upon existing bounds, but is a bit short of the truth. One could imagine in this case at least one could improve upon the bound of ")#mi("45")#text(" while staying within the framework of the polynomial method (it might also be worth working out numbers for other low dimensional cases).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cca25fa7c7b5a0309b53fb0b1dff04301c3b6e6e145654ecdaac35793c2c11a7-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468780")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Well, 45 may be replaced by 30, as ")#mi("3N")#text(" may be replaced to ")#mi("2N")#text(" always, see a proof here (sorry for doubling this link, but I think it may be convenient)")

#link("https://dl.dropboxusercontent.com/u/15433464/f3_eng.pdf")[#text("Click to access f3_eng.pdf")]

#text("For specific ")#mi("N")#text(" this looks better improvement than it actually is:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6def420a06fd003a9920717079f6c46bf7c0e7ef4e32038aee8d7cd9e725d256-d4be4d5b498d24884b0a2d9ffceae8db9e1f471279e0383dba37bb9dda8dd0b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Bishnoi")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-470085")[#strong[#text("Anurag Bishnoi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2016")])]

#text("The bounds given by Bierbrauer and Edel (based on Meshulam’s Fourier-Analytic proof) seem to be closer to the truth in the low-dimensional cases than the polynomial method bound. For dimensions 4, 5 and 6, they get upper bounds, 21, 48 and 114, respectively. See Section 3 in ")#link("http://onlinelibrary.wiley.com/doi/10.1002/jcd.10000/abstract")[#text("http://onlinelibrary.wiley.com/doi/10.1002/jcd.10000/abstract")]#text(". The values of the polynomial bound (constant 2 instead of 3, as obtained by Fedor) for these dimensions are 30, 102 and 336.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/836e5847b121c17ba4dedb946f72275b2d02925eff54a7e34651030f26710806-0ce55af6f70360ace9f05b9397ec8a8bb3775ab1831cb28b079912a4507a9442.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468749")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I think remark 5 has a typo. As written, ")#mi("N")#text(" is asymptotic to ")#mi("4^n")#text(". Should it say")

#mi("\\displaystyle N := \\sum_{a,b,c,d,e \\geq 0: a+b+c+d+e=n, b+2c+3d+4e \\leq 2n} \\frac{n!}{a!b!c!d!e!}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8854e8079e138fed1f54f00abd9964ce13a0014016e08ba09f39fb2497a482-9bfab7bae0919ae8f5ea05180089a63d8071ed16317a8a460c981ca3ac36de5b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Naslund")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468750")[#strong[#text("Eric Naslund")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Using this general approach, Will and I applied this directly to the Erdos-Szemeredi sunflower problem, proving that if F is a sunflower-free collection of subsets of {1,2,3,…,n}, then |F|< (3/2^{2/3})^n: ")#link("https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxuYXNsdW5kZXJpY3xneDozZDQ2NzRjNzAxNmJjNDlh")[#text("https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxuYXNsdW5kZXJpY3xneDozZDQ2NzRjNzAxNmJjNDlh")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Ellenberg-Gijswijt bound on cap sets | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468753")[#strong[#text("The Ellenberg-Gijswijt bound on cap sets | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("[…] [2] Polymath 10 Emergency Post 5: The Erdos-Szemeredi Sunflower Conjecture is Now Proven. [3] A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound [4] Large caps in projective Galois […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("It seems that the above constant ")#mi("2.755...")#text(" is (simply) given by")

#mi("\\alpha^{-\\alpha} \\beta^{-\\beta} \\gamma^{-\\gamma}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d64593fdd67a17ee48c9d5c4ecfc32f34ad452fdea5ebde6a5f61dee9c467cba-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468759")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("I think, we may improve multiple 3 to 2 (not a big deal, yes.) But maybe modification of method is useful elsewhere.")

#text("For ")#mi("\\alpha\\in\\{0,1,\\dots,2n\\}")#text(" denote by ")#mi("d(\\alpha)")#text(" a number of points")#linebreak()#text(" in ")#mi("\\{0,1,2\\}^n")#text(" with sum of coordiantes at most")#linebreak()#text(" ")#mi("\\alpha")#text(". Assume that ")#mi("A\\subset \\mathbb{F}_3^n")#text(" and")#linebreak()#text(" ")#tao-math("N=\\left|A\\right|>d(\\alpha)+d(2n-2\\alpha-1)", block: false)#text(" for some")#linebreak()#text(" ")#mi("\\alpha<n")#text(" (min is attained, of course,")#linebreak()#text(" for ")#mi("\\alpha")#text(" about")#linebreak()#text(" ")#mi("2n/3")#text(" and is exponentially smaller than ")#mi("3^n")#text(" by a suitable verison of Law of Large Numbers.)")

#text("We need")

#text("Lemma. Let ")#mi("\\mathbb{F}")#text(" be a field, ")#mi("U")#text(" be a finite set and let")#linebreak()#text(" ")#mi("X")#text(" be a ")#mi("k")#text("-dimensional linear subspace of the space ")#mi("\\mathbb{F}^U")#text(" of functions")#linebreak()#text(" on ")#mi("U")#text(". Then the squares of functions from ")#mi("X")#text(" span a space of dimension at least ")#mi("k")#text(".")

#text("Proof (inspired by Ilya Bogdanov). Let ")#tao-math("U=\\{1,\\dots,\\left|U\\right|\\}", block: false)#text(".")#linebreak()#text(" By Gauss' method, we may find a basis ")#mi("v_1,\\dots,v_k")#text(" of ")#mi("X")#text(" such that")#linebreak()#text(" ")#mi("s(v_1)<s(v_2)<\\dots<s(v_k)")#text(", where ")#mi("s(v)")#text(" is the number of the first nonzero")#linebreak()#text(" entry in ")#mi("v")#text(". Their squares work.")

#text("Denote by ")#mi("F")#text(" the space of ")#mi("\\mathbb{F}_3")#text("-valued functions on ")#mi("A")#text(" such that")#linebreak()#text(" ")#mi("\\sum_{a\\in A} f(a) W(a)=0")#text(" for any polynomial ")#mi("W")#linebreak()#text(" over ")#mi("\\mathbb{F}_3")#text(", which has degree at most 2 in each variable and total degree at most ")#mi("\\alpha")#text(".")#linebreak()#text(" Dimension ")#mi("\\dim F")#text(" of this space")#linebreak()#text(" is at least ")#mi("N-d(\\alpha)")#text(".")#linebreak()#text(" If ")#mi("f,g\\in F")#text(", for any polynomial ")#mi("Q(x,y)")#text(" of degree at most ")#mi("2\\alpha+1")#text(" we have")

#mi("\\displaystyle \\sum_{a\\in A,b\\in B} f(a)g(b) Q(a,b)=0")

#text("(this is clear for monomials: sum factorizes, and there exists zero factor).")

#text("Assume that ")#mi("a+b\\ne 2c")#text(" for ")#mi("a\\ne b")#text(", ")#mi("c")#text(" in ")#mi("A")#text(". Consider the space of polynomials")#linebreak()#text(" ")#mi("P(x)")#text(" of degree at most 2 in each variable, equal to 0")#linebreak()#text(" 0 outside ")#mi("2A=\\{2a,a\\in A\\}")#text(", of total degree at most ")#mi("2\\alpha+1")#text(".")#linebreak()#text(" Dimension of the space of such polynomials is at least ")#mi("d(2\\alpha+1)-3^n+N=N-d(2n-2\\alpha-1)")#text(".")#linebreak()#text(" And these polynomials are all different as functions on")#linebreak()#text(" ")#mi("2A")#text(" (since they are different as functions on")#linebreak()#text(" ")#mi("\\mathbb{F}_3^n")#text("). For all ")#mi("f\\in F")#linebreak()#text(" we have")

#mi("\\displaystyle \\sum_{a\\in A} f^2(a)P(2a)=\\sum_{a\\in A,b\\in B} f(a)f(b)P(a+b)=0.")

#text("By lemma the functions ")#mi("f^2")#text(", ")#mi("f\\in F")#text(", form a space of dimension at least ")#mi("N-d(\\alpha)")#text(",")#linebreak()#text(" and functions ")#mi("P(2a)")#text(" form a space of dimension at least ")#mi("N-d(2n-2\\alpha-1)")#text(". Sum of dimensions")#linebreak()#text(" exceed ")#mi("N")#text(", thus orthogonal complement of the first subspace can not lie in the second.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cca25fa7c7b5a0309b53fb0b1dff04301c3b6e6e145654ecdaac35793c2c11a7-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468762")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Formatting looks really ugly, sorry. Here is pdf")

#link("https://dl.dropboxusercontent.com/u/15433464/f3_eng.pdf")[#text("Click to access f3_eng.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468805")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Nice! I actually get ")#mi("d(2n-2\\alpha-2)")#text(" instead of ")#mi("d(2n-2\\alpha-1)")#text(" (as I believe it is the former that is equal to ")#mi("3^n - d(2\\alpha+1)")#text(". This seems to give the bounds ")#mi("r_3({\\bf F}_3) \\leq 2")#text(", ")#mi("r_3({\\bf F}_3^2) \\leq 4")#text(", ")#mi("r_3({\\bf F}_3)^3) \\leq 11")#text(", ")#mi("r_3({\\bf F}_3^4) \\leq 30")#text(", if I did the arithmetic correctly; this is sharp in one and two dimensions but misses a little in three (I believe ")#mi("r_3({\\bf F}_3^3)=9")#text(") and higher. In terms of the tensor rank formulation, the point seems to be this: if one wishes to write ")#mi("\\sum_{a \\in A} \\delta_a(x) \\delta_a(y) \\delta_a(z)")#text(" as a sum")

#mi("\\displaystyle \\sum_{i=1}^I f_{1,i}(x) g_{1,i}(y,z) + \\sum_{j=1}^J f_{2,j}(y) g_{2,j}(x,z) + \\sum_{k=1}^K f_{3,k}(z) g_{3,k}(x,y)")

#text("then Lemma 1 of the post tells us that we need ")#tao-math("I+J+K \\geq \\left|A\\right|", block: false)#text(". But if we have the additional information that ")#mi("I=J")#text(" and ")#mi("f_{1,i} = f_{2,i}")#text(" for ")#mi("i=1,\\dots,I")#text(", then we can improve this condition to ")#tao-math("I+K \\geq \\left|A\\right|", block: false)#text(". I guess there is some sort of “symmetric rank” here where we symmetrise under the operation of interchanging x and y. (It also seems tempting to symmetrise in all of x,y,z, but there seems to be some issue in characteristic 3 in that one can’t divide by 3!. Given that the bound is now sharp in one and two dimensions, I guess it is not too realistic to hope for a really big further gain.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce491590c3e260b7d1581dcd4198fbfd9c28077a9ea1612fd61810005a559286-8b3d0c68cf147da61413922a1c9e1d625bde6b7bd9ee3dce96cf75de749543e7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468809")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("Yes, of course ")#mi("d(2n-2\\alpha-2)=3^n-d(2\\alpha+1)")#text(". I hope that now everything in the linked pdf is correct, and it is expressed in more symmetric form, without two steps. The space ")#mi("F")#text(" satisfies a condition ")#mi("\\sum_{a\\in A} u(a)v(a)w(a)=0")#text(" for all ")#mi("u,v,w")#text(" in ")#mi("F")#text(". In general it implies that ")#tao-math("\\dim F\\leqslant \\left|A\\right|/2", block: false)#text(", but we are additionally given that supports of all functions in ")#mi("F")#text(" are quite large. Does it allow to get essentially better bound on the dimension? Without conditions on the support it is tight, but the example I have in mind (linear span of vectors ")#mi("e_{2i-1}-e_{2i}")#text(") has small supports.")

#text("It gives at least some improvement, say, estimate 30 in the game set problem may be easily improved (though I doubt that down to 20.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468785")[#strong[#text("Polymath 10 Emergency Post 5: The Erdos-Szemeredi Sunflower Conjecture is Now Proven. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")]

#text("[…] nice modification) of the Croot-Lev-Pach-Ellenberg-Gijswijt capset and further discussion see this post and comment thread on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd8854e8079e138fed1f54f00abd9964ce13a0014016e08ba09f39fb2497a482-9bfab7bae0919ae8f5ea05180089a63d8071ed16317a8a460c981ca3ac36de5b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric Naslund")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468786")[#strong[#text("Eric Naslund")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Here is another application of this method which can be seen as progress on the Erdos-Rado sunflower problem. The functions used are combinations of indicator functions of the elements in the underlying set rather than polynomials: ")#link("https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxuYXNsdW5kZXJpY3xneDozZWM4ZTI0ZTcyNGMyY2M2")[#text("https://docs.google.com/viewer?a=v&pid=sites&srcid=ZGVmYXVsdGRvbWFpbnxuYXNsdW5kZXJpY3xneDozZWM4ZTI0ZTcyNGMyY2M2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e84001e820a160a7d0093319db0273e5cfe027eb9f6bff448f73c50d4ac727d-f47bc6e455548c4dcf5b8a1bddc34e6a14294e5f48d42da2b71109e37a74f90c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jop Briet")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468790")[#strong[#text("Jop Briet")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("Dear Terry, thanks for the great post! Tiny typo: Eq (3) seems to be missing an equality symbol.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468827")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("For the record: the known values of ")#mi("r_3({\\bf F}_3^n)")#text(" (i.e.for ")#mi("n \\leq 6")#text(") are at ")#link("https://oeis.org/A090245")[#text("https://oeis.org/A090245")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cca25fa7c7b5a0309b53fb0b1dff04301c3b6e6e145654ecdaac35793c2c11a7-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468836")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("We may mix Croot-Lev-Pach and Olson’s ideas to rephrase this proof using group rings.")

#text("Let ")#mi("p")#text(" be odd prime. Denote by ")#mi("C_m")#text(" a cyclic group of order ")#mi("m")#text(". Let ")#mi("G=\\prod_{i=1}^n C_{p^{k_i}}")#text(" be a finite Abelian ")#mi("p")#text("-group with ")#mi("n")#text(" generators ")#mi("g_1,\\dots,g_n")#text(", ")#mi("g_i")#text(" generates ")#mi("C_{p^{k_i}}")#text(". Assume that we managed to find a subspace ")#mi("X")#text(" of a group algebra ")#mi("\\mathbb{F}_p[G]")#text(" of codimension ")#mi("t")#text(" satisfying ")#mi("uvw=0")#text(" for all ")#mi("u,v,w\\in X")#text(". Then any subset ")#mi("A\\subset G")#text(" of cardinality at least ")#mi("2t+1")#text(" contains three different elements ")#mi("a,b,c")#text(" such that ")#mi("ab=c^2")#text(".")

#text("Why? Assume the contrary. Consider the subspaces ")#mi("X_1,X_{-2}")#text(" of ")#mi("X")#text(" with all coefficients outside ")#mi("A")#text(" (resp. outside ")#mi("A^{-2}")#text(") equal to 0. They have dimensions at least ")#mi("t+1")#text(". Consider the product")

#mi("0=(\\sum_{a\\in A} u(a) a)(\\sum_{b\\in A} v(b) b)(\\sum_{c\\in A} w(c^{-2})c^{-2}),")

#text("where two first summands are chosen from ")#mi("X_1")#text(" and the second from ")#mi("X_{-2}")#text(". If ")#mi("abc^{-2}=1")#text(" only for ")#mi("a=b=c")#text(", the coefficient of 1 in this product is nothing but ")#mi("\\sum_{u\\in A} u(a)v(a)w(a^{-2})")#text(". But the space of functions of the form ")#mi("u(a)v(a)")#text(", ")#mi("u,v\\in X_1")#text(" is at least ")#mi("\\dim X_1")#text(", as we may see by choosing basis in ")#mi("X_1")#text(" by Gauss elimination, and it can not be orthogonal to the space formed by functions ")#mi("w(a^{-2})")#text(", which is isomorphic to ")#mi("X_2")#text(". (This argument is the same as before.)")

#text("Now how to choose such a space with low codimension. Group algebra is generated by the products ")#mi("\\prod (1-g_i)^{m_i}")#text(", where ")#mi("m_i\\in \\{0,1,\\dots,p^{k_i}-1\\}")#text(". Let ")#mi("X")#text(" be a subspace generated by monomials for which ")#mi("\\sum_{i=1}^n m_i/(p^{k_i}-1)>n/3")#text(". Then any product ")#mi("uvw")#text(" for ")#mi("u,v,w\\in X")#text(" has some ")#mi("1-g_i")#text(" in a power strictly greater than ")#mi("p^{k_i}-1")#text(", but ")#mi("(1-g_i)^{p^{k_i}}=0")#text(".")

#text("What is the codimension ")#mi("t")#text(" of this subspace? If ")#mi("\\xi_i")#text(" are random variables uniformly distributed in the set")#linebreak()#text(" ")#mi("\\frac1{p^{k_i}-1}\\{0,1,\\dots,p^{k_i}-1\\}")#text(", then ")#tao-math("t/\\left|G\\right|", block: false)#text(" is the probability that ")#mi("\\sum (\\xi_i-E(\\xi_i))\\leqslant -n/6")#text(". It decays expoentially in ")#mi("n")#text(". Alas, this does not seem to be better than partitioning ")#mi("G")#text(" onto classes modulo ")#mi("C_p^n")#text(" and reasoning in them separately.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cca25fa7c7b5a0309b53fb0b1dff04301c3b6e6e145654ecdaac35793c2c11a7-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468842")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2016")])]

#text("Well, at least this gives better exponent for, say, $C_9^n$ compared to $3^n$ copies of $C_3^n$, so I hope that it touches some effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d64593fdd67a17ee48c9d5c4ecfc32f34ad452fdea5ebde6a5f61dee9c467cba-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469099")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2016")])]

#text("It gives similar estimates for progression-free sets ")#tao-math("\\left|A\\right|\\leqslant \\left|G\\right|^{\\kappa}", block: false)#text(", where ")#mi("\\kappa1/2")#text(" such that any large enough finite group ")#mi("G")#text(" (at least of odd order, though this is hardily important) contains ")#tao-math("\\left|G\\right|^c", block: false)#text(" elements without 3-progressions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cca25fa7c7b5a0309b53fb0b1dff04301c3b6e6e145654ecdaac35793c2c11a7-97732522f6bff1f514df6d29f130b14fa750cd6fcf5199a4d26762ae9f395201.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469100")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2016")])]

#text("I tried to say that it works for non-Abelian ")#mi("p")#text("-groups, but something went wrong, probably inequality signs have eaten my post. Never mind. Here is a draft")

#link("https://dl.dropboxusercontent.com/u/15433464/grouprings1.pdf")[#text("Click to access grouprings1.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Gur")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468873")[#strong[#text("Tom Gur")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2016")])]

#text("Should delta(x_1 – a) * … * delta(x_k – a) be delta_a(x_1) *…* delta_a(x_k) ?")#linebreak()#text(" (Near the end of the proof of Lemma 1.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468948")[#strong[#text("Mind Boggling: Following the work of Croot, Lev, and Pach, Jordan Ellenberg settled the cap set problem! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2016")]

#text("[…] See also this post by Tao (presenting a symmetric version of the proof) and this post by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77d8f10982bf9d18d94d1589809c12e317f4406af02d07d04f9d90f6edf88af1-e147a5ce09708973c42a344f021b3cd65b79fb92f489da48e357f14a58d28637.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Bloom")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468949")[#strong[#text("Thomas Bloom")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2016")])]

#text("Interestingly, this proof also works for the similar problem over polynomial rings. For example, bounding the size of the largest subset of F_2[t]_{\\deg f< n} without non-trivial solutions to a+tb=(1+t)c, this method gives an exponential upper bound (I think something like 1.9^n for this particular problem).")

#text("This is great, because before this not even the $N/\\log N$ bound was known, but rather $N(\\log\\log N)^2/\\log N$ – I used to think that this problem was closer to the normal integer setting than the cap set problem, but not any more!")

#text("And, of course, there are many analogues between the integers and polynomials over finite fields…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2016")])]

#text("Ben Green has recently obtained an exponential bound for the analogue of Sarkozy’s theorem in function fields using these methods: ")#link("http://arxiv.org/abs/1605.07263")[#text("http://arxiv.org/abs/1605.07263")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aaa38f15bcf8e524a92ee2560340d1aeef043b40d25e6b481176edef37a2b3e-f79f03aa26ccb15bd10b86719cc7cb4da489b47335643479796aa972413f506e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario Carneiro")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-468997")[#strong[#text("Mario Carneiro")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("You comment on ")#link("https://oeis.org/A090245")[#text("https://oeis.org/A090245")]#text(" that “Asymptotically, a(n) = O(3^n/n)” which contradicts this post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("In combinatorics, ")#mi("O()")#text(" ")#link("https://en.wikipedia.org/wiki/Big_O_notation")[#text("is used to denote")]#text(" an upper bound only (one would write instead ")#mi("a(n) = \\Theta(3^n/n)")#text(" if one wanted to assert the exact order of magnitude).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aaa38f15bcf8e524a92ee2560340d1aeef043b40d25e6b481176edef37a2b3e-f79f03aa26ccb15bd10b86719cc7cb4da489b47335643479796aa972413f506e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mario Carneiro")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469002")[#strong[#text("Mario Carneiro")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")])]

#text("Oops, newbie mistake. Indeed I read it as a(n) ~ 3^n/n.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469012")[#strong[#text("Polymath 10 post 6: The Erdos-Rado sunflower conjecture, and the Turan (4,3) problem: homological approaches. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")]

#text("[…] We will not regard attacks on the sunflower conjecture based on the recent solution of the cap set problem and the Erdos Szemeredi sunflower conjecture (which is a weaker version of the Erdos-Rado conjecture) as part of the present polymath10 project, but, of course, I will be happy to hear also reports on progress or comments on these directions. Some updates on this story: Eric Naslund and Will Sawin gave a direct proof based on the polynomial method for the Erdos-Szemeredi sunflower conjecture, and an even stronger result is given by Naslund here. (Eric also has stronger quantitative bounds for Erdos-Szemeredi based on bounds for cap sets.) More cap set updates are added to this post, and can be found in the comment threads here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2016")])]

#text("Typo: I believe $k$ should be $k-1$ in the equation following “If we multiply (3) by…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5532625b5077728d3b36ee69ade51a3091f374b35f8cc6e36a974cda3cca0d11-051c4e4b8691f0d7e520b97aa39a976bf545595ab27c2e734bec837b4024af09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus85")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469065")[#strong[#text("Klaus85")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2016")])]

#text("This is a very interesting post, thanks. I wonder, do you have a personal favorite-list of open problems? (it seemed this one was on the list). Or do professional mathematicians not have such lists but concentrate in developing the field further independent whether there is some identified open question? I’m honestly interested in this. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469069")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2016")])]

#text("The blog posts listed at ")#link("https://terrytao.wordpress.com/category/question/")[#text("https://terrytao.wordpress.com/category/question/")]#text(" are devoted to discussion of a number of open questions that I am interested in. I did at one point try to maintain a list of such open questions more systematically, but have not done so for more than a decade.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("A shout out, by the way, to Ben Green, who to my knowledge was the first to dare conjecture [EDIT: ")#emph[#text("explicitly")]#text(", and ")#emph[#text("in print")]#text("] that cap sets had to be exponentially sparse (see Conjecture 4.3 of ")#link("http://arxiv.org/abs/math/0409420")[#text("http://arxiv.org/abs/math/0409420")]#text(" ). I actually disagreed with him at the time, and even said so in ")#link("https://terrytao.wordpress.com/2007/02/23/open-question-best-bounds-for-cap-sets/")[#text("my 2007 blog post")]#text(", but am happy to have been proven wrong on this.")

#text("While on the topic of past inaccuracies, it seems I may have inadvertently propagated a slightly incorrect terminology in that post: sets in ")#mi("{\\bf F}_3^n")#text(" free of collinear triples are known as ")#emph[#text("affine caps")]#text(" or simply ")#emph[#text("caps")]#text(" in the design theory literature, rather than ")#emph[#text("cap sets")]#text(". The latter terminology seems to have become rather entrenched, though, at least in additive combinatorics circles…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469122")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("In the commentary after Conjecture 4.3, Green says he would expect any progress on that conjecture to lead to improvements on bounding the size of a maximum subset of $\\mathbb{Z}_n$ without 3-term APs. Is the jury out at the moment about the possibility of these latest developments being applied to the $\\mathbb{Z}_n$ setting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469128")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("It is interesting to look at ")#link("http://www.sciencedirect.com/science/article/pii/0097316587900537")[#text("the original 1987 paper of Peter Frankl, Ron Graham, and Vojta Rodl")]#text(".")#linebreak()#text(" FGR gave a ")#mi("o(3^n)")#text(" upper bound using Rusza-Szemeredi’s theorem (that applies also to show that ")#mi("r_3(n)=o(n)")#text("). In that paper FGR asked if cap sets are exponentially sparse. They also relate the question to the Erdos-Rado’s sunflower conjecture.")

#text("I myself worked with Meshulam on this problem around 2000, and we had a Fourier statement about inequality between certain norms that in its strongest form would give exponentially good upper bound, (and in some weaker forms will give weaker improvement to Roy’s original 95 bound.) (These norm-inequalities are still completely open, I think.) Roy certainly conjectured that cap sets are exponentially sparse while I changed sides several times over the years. In 2009 ")#link("https://gilkalai.wordpress.com/2009/02/07/frankl-rodls-theorem-and-variations-on-the-cap-set-problem-a-recent-research-project-with-roy-meshulam-a/")[#text("I discussed another approach")]#text(" also initiated with discussions with Roy with certain weakening and strengthening of the 3AP condition, potential relations to variants of the Frankl-Wilson and Frankl-Rodl theorems, and some slightly related polynomial-method lemmas.")

#text("On another matter it is certainly an obvious question at this point to try to give upper bounds for the rank of subsets of ")#mi("\\{0,1,2\\}^n")#text(" without a ")#emph[#text("combinatorial")]#text(" line. The most optimistic constructions are given in terms of minimum of level sets corresponding to 3AP free sets of levels. Maybe there could be a way to dualize somehow and get upper bounds in terms of maximum of some related question. (It will be sufficiently wonderful to relate upper bounds for DHJ to upper bounds for ")#mi("r_3(n)")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("One can certainly try to apply the same method to the DHJ problem – one replaces the function ")#mi("\\delta_0(x+y+z)")#text(" by the indicator function of all the triples in ")#mi("\\{0,1,2\\}^3")#text(" that form a combinatorial line. Unfortunately the rank of this tensor appears to be too large for the method to work (and in any event, a suitable modification of the Behrend construction shows that an exponential gain is not possible in this case anyway).")

#text("At present it seems like the most plausible way one could use these methods to improve upon the ")#mi("{\\bf Z}/N{\\bf Z}")#text(" problem is through progress on DHJ (or slight variants thereof), perhaps in ")#mi("\\{0,1,\\dots,r\\}^n")#text(" for some suitable choice of ")#mi("r")#text(" and ")#mi("n")#text(" with ")#mi("r^n \\approx N")#text(" (the Behrend example suggests that ")#mi("r")#text(" has to grow with ")#mi("N")#text(" in order for there to be any chance here). I myself haven’t seriously tried this, but presumably some of the many other mathematicians now experimenting with this method would be considering it; it’s worth a shot, certainly.")

#text("p.s. Regarding by previous comment, I should clarify that Ben was certainly not the first to pose the question of whether capsets are exponentially sparse or not – the question was also raised as “an interesting open problem” in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2031694")[#text("2004 paper of Edel")]#text(". But I don’t know of an earlier reference in the literature in which the author came out strongly in favour of the exponentially sparse scenario, rather than being undecided or posing the opposing scenario as a question (as was done for instance in the Frankl-Graham-Rodl paper).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e3b0b3c7cb598816eba09b71d1b6daed4ea34fd144f055032f44944357328ac-755e71d858c6044b00f837c857efbec5b1dcc4e83104318d17348d7f6f243265.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Delhanty")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469211")[#strong[#text("Paul Delhanty")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Edel, in the 2004 paper that you linked previously, writes, “That leaves us with two research problems. Firstly to improve the bounds on $\\mu(3)$ by finding better *capsets*.”")

#text("So you get a pass on the 2nd point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e3b0b3c7cb598816eba09b71d1b6daed4ea34fd144f055032f44944357328ac-755e71d858c6044b00f837c857efbec5b1dcc4e83104318d17348d7f6f243265.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Delhanty")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469221")[#strong[#text("Paul Delhanty")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Ah, my bad – sorry! On reading through Edel’s paper more carefully, *capset* is defined in Definition 9 and it is a somewhat different and much more specific concept from a cap. It looks like a capset is a set of indexing tuples that represent a set of product caps that get unioned together to create the final cap.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469132")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("Very nice! I have 3 minor comments and a question.")#linebreak()#text(" 1) I think it would be helpful to say that ")#mi("h")#text(" is *nowhere zero* on ")#mi("A^{\\prime}")#text(" (rather than non-zero, which is ambiguous);")#linebreak()#text(" 2) In the first line of Lemma 2, ")#mi("\\delta(x)=1-x^2")#text(" for ")#mi("x\\in\\mathbf F_3")#text(" (not for general ")#mi("\\mathbf F")#text(";")#linebreak()#text(" 3) In my browser, I was unable to find the equation label (3) (but I inferred where it was).")

#text("And the question: Am I right that the term “capset” comes from spherical caps that were used to build large sets without arithmetic progressions? The terminology is a bit mysterious to non-experts.")

#emph[#text("[Corrected, thanks. The notion of an “affine cap” comes from design theory, but I do not know the provenance exactly – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469166")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("In Remark 3, “to control the maximal size of aubset” should end with “a subset”, I presume.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60206d41a404eb8bdf7a9a9b59ee982ceb0d347a2c54dde08f347850691c3cc9-e1143ae1b28cbe3efaefb9e1472d91c3cfeea91b6596a3b722d64796ddc50e18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aram")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469630")[#strong[#text("aram")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("I’m confused about (1). The LHS =1 if x,y,z form a line but the RHS = 0 then. And the empty set is a valid capset, so the RHS could be always 0. And the RHS could be sometimes 2 but the LHS is always 0 or 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469645")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("The case when ")#mi("x,y,z")#text(" form a line never occurs when ")#mi("x,y,z \\in A")#text(" and ")#mi("A")#text(" is a capset, by definition of capset. In the case of the empty set, (1) is vacuously true for ")#mi("x,y,z \\in A")#text(". The RHS cannot actually attain 2 because at most one of the summands can be non-zero at a time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60206d41a404eb8bdf7a9a9b59ee982ceb0d347a2c54dde08f347850691c3cc9-e1143ae1b28cbe3efaefb9e1472d91c3cfeea91b6596a3b722d64796ddc50e18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aram")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469654")[#strong[#text("aram")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("Oh, I missed that x,y,z have to belong to A! That makes sense.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1f616de2cc53ad7ab82924fb5ce1684e1490f4853ec894784f90ee724172e5e-bd1ef283d8b7fc601ca82531a9518de255bc0366364dcc2bff302e4b27362625.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abbas")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-469999")[#strong[#text("Abbas")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("Nice argument and presentation!")

#text("On the last line of Remark 3, ")#mi("\\delta(ax+by+cz)")#text(" should be ")#mi("\\delta_{0^n}(ax+by+cz)")#text(" ? Also in Remark 5, 3rd line from below.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-470377")[#strong[#text("Bounds for sum free sets in prime power cyclic groups — three ways | Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")]

#text("[…] now-standard argument (I like Terry Tao’s exposition) shows that is bounded by three times the number of monomials of degree . One needs to check that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-471122")[#strong[#text("Comments on the Ellenberg-Gijswijt bound for caps in higher characteristic | Blogderbeweise - Proofs from the blog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2016")]

#text("[…] breakthrough due to Croot, Lev and Pach, recycled by Ellenberg-Gijswijt and streamlined by Tao on this blog post, revolutionised the landscape of Roth’s type problems in vector spaces over finite fields. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the “slice rank” of tensors | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-471772")[#strong[#text("Notes on the “slice rank” of tensors | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("[…] the previous blog post, one of us (Terry) implicitly introduced a notion of rank for tensors which is a little different […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aee203720f098d6048142ae6184bb1708967fc05c298553debe7e8154fbed4f-19b07a54336dd0d17a7e49e8231fff18ced0a12a91b396708c8ea039bf59768c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paata Ivanishvili")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-472144")[#strong[#text("Paata Ivanishvili")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2016")])]

#text("Once at the end of a seminar about capset problem fedja said: “you don’t need Lagrange multipliers. For ")#mi("0<x<1")#text(" clearly ")#mi("\\frac{(1+x+x^{2})^{n}}{x^{2n/3}}\\geq  \\sum_{a+b+c=n, b+2c \\geq 2n/3} \\frac{n!}{a!b!c!}")#text(". Minimizing the LHS gives ")#mi("(2.75511..)^{n}")#text("\"")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5373e6e2b5c37b6ecb85e312486ae2341f231151d0622cdf3ec55cb25d9c3e9-56aa28a36f311d761f49dbd6ada99642034ebc1da82b3d575c2db21c6515a254.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-472173")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2016")])]

#text("Yes, a similar method is very useful for quickly doing slice rank calculations. Eric Naslund and I used it on the last page of this: ")#link("https://arxiv.org/pdf/1606.09575v1.pdf")[#text("https://arxiv.org/pdf/1606.09575v1.pdf")]

#text("However, it is not obvious that the upper bounds produced by this method are optimal. To analyze that question I don’t see how to avoid the use of Lagrange multipliers. See ")#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")[#text("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ce491590c3e260b7d1581dcd4198fbfd9c28077a9ea1612fd61810005a559286-8b3d0c68cf147da61413922a1c9e1d625bde6b7bd9ee3dce96cf75de749543e7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fedor Petrov")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-472175")[#strong[#text("Fedor Petrov")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2016")])]

#text("The multiplicative constant obtained on this way (variants of which are called Cramer theorem or Chernoff bound in probability and which is essentially a saddle-point method) is of course optimal. Further asymptotics (polynomial multiples) may be also obtained by saddle-point method, this is more technical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-472179")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2016")])]

#text("But in the probability theory problem we are trying to bound the tail probability of a fixed random variable. I agree that the method is optimal there. Here we have the freedom to choose the random variable, subject to some constraints. If you write down the constraints, then any way you slice it, you have a convex optimization problem for which Lagrange multipliers are a suitable tool.")

#text("Of course optimizing the random variable for progression-free sets in F_q^n with q=3 is not very hard. But for higher values of q it is nontrivial, though solved by these papers: ")#link("https://arxiv.org/abs/1608.00243")[#text("https://arxiv.org/abs/1608.00243")]#text(" ")#link("https://arxiv.org/abs/1608.05740")[#text("https://arxiv.org/abs/1608.05740")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b12027774f3eff9babb096744eea3a78c36ebfb71640d00e4d40a6aa468f9cc-9c3cdb8a1366db66028aec98932112aa8cae85ff13a2b8a8059f9a2f29564e9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-473718")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2016")])]

#text("Wait, why is that clearly an upper bound?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b12027774f3eff9babb096744eea3a78c36ebfb71640d00e4d40a6aa468f9cc-9c3cdb8a1366db66028aec98932112aa8cae85ff13a2b8a8059f9a2f29564e9e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-473719")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2016")])]

#text("Ah, ")#mi("\\frac{(1+x+x^2)^n}{x^{2n/r}} = \\sum_{a+b+c=n}x^{b+2c-2n/3}")#text(". You just flipped the inequality on ")#mi("b+2c\\le 2n/3")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-472236")[#strong[#text("Introduction to the polynomial method (and other similar things) | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2016")]

#text("[…] result then follows from analyzing the asymptotic behavior of (see this post for details). The proof of the lemma is perhaps more interesting, considering this is where polynomials […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca1b86a8af9c99d875999f4948ee99b054181f00e4246d3ce2c116c7fc91c8db-c1fc8940af2cb8e68eee194775cc7f18c82f561b83b76be2181aa3c577e7e710.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes of the seminar ‘On the slice rank of functions’ | Points And Lines")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-480730")[#strong[#text("Notes of the seminar ‘On the slice rank of functions’ | Points And Lines")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("[…] try to elude the idea of ‘slice rank’ of a tensor, as was defined by Terry Tao in his reformulation of the Ellenberg-Gijswijt proof. I will try to indicate where the idea might have come from and how […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-483086")[#strong[#text("TheoryFest Day 3: Plenaries | A bunch of data")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2017")]

#text("[…] came out of the recent flurry of work by Croot, Lev, Pach, Ellenberg, Gijswijt and Tao (and cited Tao’s blog post as well as the papers, which I thought was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-483326")[#strong[#text("수학동아 연재 (2016년) - Prof. Sang-il Oum")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2017")]

#text("[…] 참고 블로그글: Ellenberg 블로그, Tim Gowers 블로그, Terrence Tao 블로그 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-496372")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("In regards to Remark 5 and Will’s nice response to it above, it seems that Hongze Li has made progress for large q. ")#link("https://arxiv.org/pdf/1610.00247.pdf")[#text("https://arxiv.org/pdf/1610.00247.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6bee38a54cd2271be89034454fa2ba8ff424bf6591e45bc91dda1f9cac5fa17-8f4d488bc24daa25daf62c14b64c16d6318202346fc3b9765214d6fd1010b1f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Shakan")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-496418")[#strong[#text("George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("After reading the paper and getting in touch with the author, unfortunately there is an error.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-513978")[#strong[#text("수학동아 연재 (2016년) - Sang-il Oum")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")]

#text("[…] 참고 블로그글: Ellenberg 블로그, Tim Gowers 블로그, Terrence Tao 블로그 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Trifference Problem | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-672478")[#strong[#text("The Trifference Problem | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2023")])]

#text("[…] have led to any improvement in the bounds on . For example, Costa and Dalai have shown that the slice rank method, which was recently used to make breakthroughs on the cap set problem, and many other combinatorial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-675097")[#strong[#text("Theory at the Institute and Beyond, February 2023 | Calvin Café: The Simons Institute Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2023")]

#text("[…] Kelley-Meka proof in this mold). A few years ago, an ingenious use of the polynomial method led to stunning progress on the capset problem, leading to a short proof of an upper bound of O(2.756n) for q = 3, a vast improvement to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92cb755ccf42015a4cf4dc8fe12790100b690a5496009f056114a629f89bb6aa-32d0989e0076e5eea3faa01ead81efd729b0a274d20ca6d7278f197f63a586d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Gunning")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-684921")[#strong[#text("Alex Gunning")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2024")])]

#text("I suppose it’s not really relevant in the ")#mi("k=3")#text(" case but I think if you use an even weaker notion of tensor rank where")

#mi("\\displaystyle f(x_{i_1},x_{i_2},\\cdots,x_{i_l})g(x_{j_1},x_{j_2},\\cdots,x_{j_{k-l}}): {i_1, \\cdots, i_j, j_1, \\cdots, j_{k-l}}=[k]")

#text("the lemma about ranks of diagonal hypermatrices ought to still hold using the same argument.")

#text("Sorry for reviving this comment section so late :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-684926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("Yes, this was also observed by Naslund (see Lemma 11 of ")#link("https://arxiv.org/abs/1701.04475")[#text("https://arxiv.org/abs/1701.04475")]#text("), and this weaker notion of rank is now known as “partition rank” (while the notion of rank discussed here is now known as “slice rank”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e7aace1950e8f09b631b2109b26c8f0327eb8b7b8b9f169d19abc344b37ccf-be9e78a7f3bad0de2624c4c8e89165a7be1302d23e8b04627bb87f155bab4a48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Gunning")]], [#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/#comment-684930")[#strong[#text("Alex Gunning")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2024")])]

#text("Huh, I’m quite pleased that people are able to squeeze anything out of this at all — I think usually most rank one partition tensors should be rank one slice?")

#text("Will take a look")
]
]
]
