// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/
// Converted to Typst by tao2typ: "2026-10-14T16:36:06.419988+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 6: Gaussian ensembles", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 6: Gaussian ensembles")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Our study of random matrices, to date, has focused on somewhat general ensembles, such as iid random matrices or Wigner random matrices, in which the distribution of the individual entries of the matrices was essentially arbitrary (as long as certain moments, such as the mean and variance, were normalised). In these notes, we now focus on two much more special, and much more symmetric, ensembles:")

#list(
[#text("The ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("Gaussian Unitary Ensemble")]#text(" (GUE), which is an ensemble of random ")#mi("{n \\times n}")#text(" Hermitian matrices ")#mi("{M_n}")#text(" in which the upper-triangular entries are iid with distribution ")#mi("{N(0,1)_{\\bf C}}")#text(", and the diagonal entries are iid with distribution ")#mi("{N(0,1)_{\\bf R}}")#text(", and independent of the upper-triangular ones; and")],
[#text("The ")#emph[#text("Gaussian random matrix ensemble")]#text(", which is an ensemble of random ")#mi("{n \\times n}")#text(" (non-Hermitian) matrices ")#mi("{M_n}")#text(" whose entries are iid with distribution ")#mi("{N(0,1)_{\\bf C}}")#text(".")]
)

#text("The symmetric nature of these ensembles will allow us to compute the spectral distribution by exact algebraic means, revealing a surprising connection with orthogonal polynomials and with determinantal processes. This will, for instance, recover the semi-circular law for GUE, but will also reveal ")#emph[#text("fine")]#text(" spacing information, such as the distribution of the gap between ")#emph[#text("adjacent")]#text(" eigenvalues, which is largely out of reach of tools such as the Stieltjes transform method and the moment method (although the moment method, with some effort, is able to control the extreme edges of the spectrum).")#linebreak()#text(" Similarly, we will see for the first time the ")#emph[#text("circular law")]#text(" for eigenvalues of non-Hermitian matrices.")#linebreak()#text(" There are a number of other highly symmetric ensembles which can also be treated by the same methods, most notably the Gaussian Orthogonal Ensemble (GOE) and the Gaussian Symplectic Ensemble (GSE). However, for simplicity we shall focus just on the above two ensembles. For a systematic treatment of these ensembles, see the ")#link("http://www.ams.org/mathscinet-getitem?mr=1677884")[#text("text by Deift")]#text(".")#linebreak()#text(" ")#metadata(none) <tao-dfff2f99f063598704e5>

#heading(level: 1)[#strong[#text(" — 1. The spectrum of GUE — ")]]

#text("We have already shown using Dyson Brownian motion in ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text(" that we have the ")#link("http://www.ams.org/mathscinet-getitem?mr=173726")[#text("Ginibre formula")]#text(" ")#metadata(none) <tao-94695a4b667b958b8fe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\rho_n(\\lambda) = \\frac{1}{(2\\pi)^{n/2} 1! \\ldots (n-1)!} e^{-\\left|\\lambda\\right|^2/2} \\left|\\Delta_n(\\lambda)\\right|^2", block: true)]]

#text("for the density function of the eigenvalues ")#mi("{(\\lambda_1,\\ldots,\\lambda_n) \\in {\\bf R}^n_\\geq}")#text(" of a GUE matrix ")#mi("{M_n}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Delta_n(\\lambda) = \\prod_{1 \\leq i < j \\leq n} (\\lambda_i - \\lambda_j)")]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Vandermonde_determinant")[#text("Vandermonde determinant")]#text(". We now give an alternate proof of this result (omitting the exact value of the normalising constant ")#mi("{\\frac{1}{(2\\pi)^{n/2} 1! \\ldots (n-1)!}}")#text(") that exploits unitary invariance and the change of variables formula (the latter of which we shall do from first principles). The one thing to be careful about is that one has to somehow quotient out by the invariances of the problem before being able to apply the change of variables formula.")#linebreak()#text(" One approach here would be to artificially “fix a gauge” and work on some slice of the parameter space which is “transverse” to all the symmetries. With such an approach, one can use the classical change of variables formula. While this can certainly be done, we shall adopt a more “gauge-invariant” approach and carry the various invariances with us throughout the computation. (For a comparison of the two approaches, see ")#link("https://terrytao.wordpress.com/2008/09/27/what-is-a-gauge/")[#text("this previous blog post")]#text(".)")#linebreak()#text(" We turn to the details. Let ")#mi("{V_n}")#text(" be the space of Hermitian ")#mi("{n \\times n}")#text(" matrices, then the distribution ")#mi("{\\mu_{M_n}}")#text(" of a GUE matrix ")#mi("{M_n}")#text(" is a absolutely continuous probability measure on ")#mi("{V_n}")#text(", which can be written using the definition of GUE as")

#align(center)[#tao-fit-display[#tao-math("\\mu_{M_n} = C_n (\\prod_{1 \\leq i < j \\leq n} e^{-\\left|\\xi_{ij}\\right|^2}) (\\prod_{1 \\leq i \\leq n} e^{-\\left|\\xi_{ii}\\right|^2/2})\\ dM_n", block: true)]]

#text("where ")#mi("{dM_n}")#text(" is Lebesgue measure on ")#mi("{V}")#text(", ")#mi("{\\xi_{ij}}")#text(" are the coordinates of ")#mi("{M_n}")#text(", and ")#mi("{C_n}")#text(" is a normalisation constant (the exact value of which depends on how one normalises Lebesgue measure on ")#mi("{V}")#text("). We can express this more compactly as")

#align(center)[#tao-fit-display[#mitex("\\mu_{M_n} = C_n e^{- \\text{tr}(M_n^2) / 2}\\ dM_n.")]]

#text("Expressed this way, it is clear that the GUE ensemble is invariant under conjugations ")#mi("{M_n \\mapsto U M_n U^{-1}}")#text(" by any unitary matrix.")#linebreak()#text(" Let ")#mi("{D}")#text(" be the diagonal matrix whose entries ")#mi("{\\lambda_1 \\geq \\ldots \\geq \\lambda_n}")#text(" are the eigenvalues of ")#mi("{M_n}")#text(" in descending order. Then we have ")#mi("{M_n = U D U^{-1}}")#text(" for some unitary matrix ")#mi("{U \\in U(n)}")#text(". The matrix ")#mi("{U}")#text(" is not uniquely determined; if ")#mi("{R}")#text(" is diagonal unitary matrix, then ")#mi("{R}")#text(" commutes with ")#mi("{D}")#text(", and so one can freely replace ")#mi("{U}")#text(" with ")#mi("{UR}")#text(". On the other hand, if the eigenvalues of ")#mi("{M}")#text(" are simple, then the diagonal matrices are the ")#emph[#text("only")]#text(" matrices that commute with ")#mi("{D}")#text(", and so this freedom to right-multiply ")#mi("{U}")#text(" by diagonal unitaries is the only failure of uniqueness here. And in any case, from the unitary invariance of GUE, we see that even after conditioning on ")#mi("{D}")#text(", we may assume without loss of generality that ")#mi("{U}")#text(" is drawn from the invariant Haar measure on ")#mi("{U(n)}")#text(". In particular, ")#mi("{U}")#text(" and ")#mi("{D}")#text(" are independent.")#linebreak()#text(" Fix a diagonal matrix ")#mi("{D_0 = \\text{diag}(\\lambda_1^0,\\ldots,\\lambda_n^0)}")#text(" for some ")#mi("{\\lambda_1^0 > \\ldots > \\lambda_n^0}")#text(", let ")#mi("{\\varepsilon > 0}")#text(" be extremely small, and let us compute the probability ")#metadata(none) <tao-f16593cba0a64a33713e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\mathop{\\bf P}( \\left\\| M_n - D_0 \\right\\|_F \\leq \\varepsilon )", block: true)]]

#text("that ")#mi("{M_n}")#text(" lies within ")#mi("{\\varepsilon}")#text(" of ")#mi("{D_0}")#text(" in the Frobenius norm. On the one hand, the probability density of ")#mi("{M_n}")#text(" is proportional to")

#align(center)[#tao-fit-display[#tao-math("e^{-\\text{tr}(D_0^2)/2} = e^{-\\left|\\lambda^0\\right|^2/2}", block: true)]]

#text("near ")#mi("{D_0}")#text(" (where we write ")#mi("{\\lambda^0 := (\\lambda_1^0,\\ldots,\\lambda_n^0)}")#text(") and the volume of a ball of radius ")#mi("{\\varepsilon}")#text(" in the ")#mi("{n^2}")#text("-dimensional space ")#mi("{V_n}")#text(" is proportional to ")#mi("{\\varepsilon^{n^2}}")#text(", so ")#link(<tao-f16593cba0a64a33713e>)[#text("(2)")]#text(" is equal to ")#metadata(none) <tao-c476459dc1b0b71f2ee3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(C^{\\prime}_n + o(1)) \\varepsilon^{n^2} e^{-\\text{tr}(D_0^2)/2}")]]

#text("for some constant ")#mi("{C^{\\prime}_n > 0}")#text(" depending only on ")#mi("{n}")#text(", where ")#mi("{o(1)}")#text(" goes to zero as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" (keeping ")#mi("{n}")#text(" and ")#mi("{D_0}")#text(" fixed). On the other hand, if ")#tao-math("{\\left\\|M_n - D_0\\right\\|_F \\leq \\varepsilon}", block: false)#text(", then by the Weyl inequality (or Hoffman-Weilandt inequality) we have ")#mi("{D = D_0 + O(\\varepsilon)}")#text(" (we allow implied constants here to depend on ")#mi("{n}")#text(" and on ")#mi("{D_0}")#text("). This implies ")#mi("{UDU^{-1} = D + O(\\varepsilon)}")#text(", thus ")#mi("{UD - DU = O(\\varepsilon)}")#text(". As a consequence we see that the off-diagonal elements of ")#mi("{U}")#text(" are of size ")#mi("{O(\\varepsilon)}")#text(". We can thus use the inverse function theorem in this local region of parameter space and make the ansatz")

#align(center)[#tao-fit-display[#mitex("D = D_0 + \\varepsilon E; \\quad U = \\exp( \\varepsilon S ) R")]]

#text("where ")#mi("{E}")#text(" is a bounded diagonal matrix, ")#mi("{R}")#text(" is a diagonal unitary matrix, and ")#mi("{S}")#text(" is a bounded skew-adjoint matrix with zero diagonal. (Note here the emergence of the freedom to right-multiply ")#mi("{U}")#text(" by diagonal unitaries.) Note that the map ")#mi("{(R,S) \\mapsto \\exp( \\varepsilon S ) R}")#text(" has a non-degenerate Jacobian, so the inverse function theorem applies to uniquely specify ")#mi("{R, S}")#text(" (and thus ")#mi("{E}")#text(") from ")#mi("{U, D}")#text(" in this local region of parameter space.")#linebreak()#text(" Conversely, if ")#mi("{D, U}")#text(" take the above form, then we can Taylor expand and conclude that")

#align(center)[#tao-fit-display[#mitex("M_n = UDU^* = D_0 + \\varepsilon E + \\varepsilon (SD_0 - D_0S) + O(\\varepsilon^2)")]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\| M_n - D_0 \\right\\|_F = \\varepsilon \\left\\| E + (SD_0 - D_0S)\\right\\|_F + O(\\varepsilon^2).", block: true)]]

#text("We can thus bound ")#link(<tao-f16593cba0a64a33713e>)[#text("(2)")]#text(" from above and below by expressions of the form ")#metadata(none) <tao-1b4859dd82e401fc0325>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\mathop{\\bf P}( \\left\\| E + (SD_0 - D_0S)\\right\\|_F \\leq 1 + O(\\varepsilon) ).", block: true)]]

#text("As ")#mi("{U}")#text(" is distributed using Haar measure on ")#mi("{U(n)}")#text(", ")#mi("{S}")#text(" is (locally) distributed using ")#mi("{(1+o(1)) \\varepsilon^{n^2-n}}")#text(" times a constant multiple of Lebesgue measure on the space ")#mi("{W}")#text(" of skew-adjoint matrices with zero diagonal, which has dimension ")#mi("{n^2-n}")#text(". Meanwhile, ")#mi("{E}")#text(" is distributed using ")#mi("{(\\rho_n(\\lambda^0)+o(1)) \\varepsilon^{n}}")#text(" times Lebesgue measure on the space of diagonal elements. Thus we can rewrite ")#link(<tao-1b4859dd82e401fc0325>)[#text("(4)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("C^{\\prime\\prime}_n \\varepsilon^{n^2} (\\rho_n(\\lambda^0)+o(1)) \\int\\int_{\\left\\| E + (SD_0 - D_0S)\\right\\|_F \\leq 1 + O(\\varepsilon)}\\ dE dS", block: true)]]

#text("where ")#mi("{dE}")#text(" and ")#mi("{dS}")#text(" denote Lebesgue measure and ")#mi("{C^{\\prime\\prime}_n > 0}")#text(" depends only on ")#mi("{n}")#text(".")#linebreak()#text(" Observe that the map ")#mi("{S \\mapsto SD_0-D_0 S}")#text(" dilates the (complex-valued) ")#mi("{ij}")#text(" entry of ")#mi("{S}")#text(" by ")#mi("{\\lambda^0_j-\\lambda^0_i}")#text(", and so the Jacobian of this map is ")#tao-math("{\\prod_{1 \\leq i < j \\leq n} \\left|\\lambda^0_j-\\lambda^0_i\\right|^2 = \\left|\\Delta_n(\\lambda^0)\\right|^2}", block: false)#text(". Applying the change of variables, we can express the above as")

#align(center)[#tao-fit-display[#tao-math("C^{\\prime\\prime}_n \\varepsilon^{n^2} \\frac{\\rho_n(\\lambda^0)+o(1)}{\\left|\\Delta_n(\\lambda^0)\\right|^2} \\int\\int_{\\left\\| E + S\\right\\|_F \\leq 1 + O(\\varepsilon)}\\ dE dS.", block: true)]]

#text("The integral here is of the form ")#mi("{C^{\\prime\\prime\\prime}_n + O(\\varepsilon)}")#text(" for some other constant ")#mi("{C^{\\prime\\prime\\prime}_n > 0}")#text(". Comparing this formula with ")#link(<tao-c476459dc1b0b71f2ee3>)[#text("(3)")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\rho_n(\\lambda^0)+o(1) = C^{\\prime\\prime\\prime\\prime}_n e^{-\\left|\\lambda^0\\right|^2/2} \\Delta_n(\\lambda^0)|^2 + o(1)", block: true)]]

#text("for yet another constant ")#mi("{C^{\\prime\\prime\\prime\\prime}_n > 0}")#text(". Sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we recover an exact formula")

#align(center)[#tao-fit-display[#tao-math("\\rho_n(\\lambda)+o(1) = C^{\\prime\\prime\\prime\\prime}_n e^{-\\left|\\lambda\\right|^2/2} \\left|\\Delta_n(\\lambda)\\right|^2", block: true)]]

#text("when ")#mi("{\\lambda}")#text(" is simple. Since almost all Hermitian matrices have simple spectrum (see Exercise 10 of ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("Notes 3a")]#text("), this gives the full spectral distribution of GUE, except for the issue of the unspecified constant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In principle, this method should also recover the explicit normalising constant ")#mi("{\\frac{1}{(2\\pi)^{n/2}}}")#text(" in ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(", but to do this it appears one needs to understand the volume of the fundamental domain of ")#mi("{U(n)}")#text(" with respect to the logarithm map, or equivalently to understand the volume of the unit ball of Hermitian matrices in the operator norm. I do not know of a simple way to compute this quantity (though it can be inferred from ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(" and the above analysis). One can also recover the normalising constant through the machinery of determinantal processes, see below.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" ")#metadata(none) <tao-a096b50a34622f75864d>#text(" The above computation can be generalised to other ")#mi("{U(n)}")#text("-conjugation-invariant ensembles ")#mi("{M_n}")#text(" whose probability distribution is of the form")

#align(center)[#tao-fit-display[#mitex("\\mu_{M_n} = C_n e^{- \\text{tr} V(M_n)}\\ dM_n")]]

#text("for some potential function ")#mi("{V: {\\bf R} \\rightarrow {\\bf R}}")#text(" (where we use the spectral theorem to define ")#mi("{V(M_n)}")#text("), yielding a density function for the spectrum of the form")

#align(center)[#tao-fit-display[#tao-math("\\rho_n(\\lambda) = C^{\\prime}_n e^{- \\sum_{j=1}^n V(\\lambda_j)} \\left|\\Delta_n(\\lambda)\\right|^2.", block: true)]]

#text("Given suitable regularity conditions on ")#mi("{V}")#text(", one can then generalise many of the arguments in these notes to such ensembles. See ")#link("http://www.ams.org/mathscinet-getitem?mr=1677884")[#text("this book by Deift")]#text(" for details.")
]

#heading(level: 1)[#strong[#text(" — 2. The spectrum of gaussian matrices — ")]]

#text("The above method also works for gaussian matrices ")#mi("{G}")#text(", as was first observed by Dyson (though the final formula was first obtained by Ginibre, using a different method). Here, the density function is given by ")#metadata(none) <tao-9f584196e7fe6de85d38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("C_n e^{-\\text{tr}( GG^*)} dG = C_n e^{-\\left\\|G\\right\\|_F^2} dG", block: true)]]

#text("where ")#mi("{C_n > 0}")#text(" is a constant and ")#mi("{dG}")#text(" is Lebesgue measure on the space ")#mi("{M_n({\\bf C})}")#text(" of all complex ")#mi("{n \\times n}")#text(" matrices. This is invariant under both left and right multiplication by unitary matrices, so in particular is invariant under unitary conjugations as before.")#linebreak()#text(" This matrix ")#mi("{G}")#text(" has ")#mi("{n}")#text(" complex (generalised) eigenvalues ")#mi("{\\sigma(G) = \\{\\lambda_1,\\ldots,\\lambda_n\\}}")#text(", which are usually distinct:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{n \\geq 2}")#text(". Show that the space of matrices in ")#mi("{M_n({\\bf C})}")#text(" with a repeated eigenvalue has codimension ")#mi("{2}")#text(".")
]

#text("Unlike the Hermitian situation, though, there is no natural way to order these ")#mi("{n}")#text(" complex eigenvalues. We will thus consider all ")#mi("{n!}")#text(" possible permutations at once, and define the spectral density function ")#mi("{\\rho_n(\\lambda_1,\\ldots,\\lambda_n)}")#text(" of ")#mi("{G}")#text(" by duality and the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf C}^n} F(\\lambda) \\rho_n(\\lambda)\\ d\\lambda := \\mathop{\\bf E} \\sum_{\\{\\lambda_1,\\ldots,\\lambda_n\\} = \\sigma(G)} F(\\lambda_1,\\ldots,\\lambda_n)")]]

#text("for all test functions ")#mi("{F}")#text(". By the Riesz representation theorem, this uniquely defines ")#mi("{\\rho_n}")#text(" (as a distribution, at least), although the total mass of ")#mi("{\\rho_n}")#text(" is ")#mi("{n!}")#text(" rather than ")#mi("{1}")#text(" due to the ambiguity in the spectrum.")#linebreak()#text(" Now we compute ")#mi("{\\rho_n}")#text(" (up to constants). In the Hermitian case, the key was to use the factorisation ")#mi("{M_n = UDU^{-1}}")#text(". This particular factorisation is of course unavailable in the non-Hermitian case. However, if the non-Hermitian matrix ")#mi("{G}")#text(" has simple spectrum, it can always be factored instead as ")#mi("{G = UTU^{-1}}")#text(", where ")#mi("{U}")#text(" is unitary and ")#mi("{T}")#text(" is upper triangular. Indeed, if one applies the ")#link("http://en.wikipedia.org/wiki/Gram%E2%80%93Schmidt_process")[#text("Gram-Schmidt process")]#text(" to the eigenvectors of ")#mi("{G}")#text(" and uses the resulting orthonormal basis to form ")#mi("{U}")#text(", one easily verifies the desired factorisation. Note that the eigenvalues of ")#mi("{G}")#text(" are the same as those of ")#mi("{T}")#text(", which in turn are just the diagonal entries of ")#mi("{T}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that this factorisation is also available when there are repeated eigenvalues. (Hint: use the ")#link("http://en.wikipedia.org/wiki/Jordan_normal_form")[#text("Jordan normal form")]#text(".)")
]

#text("To use this factorisation, we first have to understand how unique it is, at least in the generic case when there are no repeated eigenvalues. As noted above, if ")#mi("{G = UTU^{-1}}")#text(", then the diagonal entries of ")#mi("{T}")#text(" form the same set as the eigenvalues of ")#mi("{G}")#text(".")#linebreak()#text(" Now suppose we fix the diagonal ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" of ")#mi("{T}")#text(", which amounts to picking an ordering of the ")#mi("{n}")#text(" eigenvalues of ")#mi("{G}")#text(". The eigenvalues of ")#mi("{T}")#text(" are ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(", and furthermore for each ")#mi("{1 \\leq j \\leq n}")#text(", the eigenvector of ")#mi("{T}")#text(" associated to ")#mi("{\\lambda_j}")#text(" lies in the span of the last ")#mi("{n-j+1}")#text(" basis vectors ")#mi("{e_j,\\ldots,e_n}")#text(" of ")#mi("{{\\bf C}^n}")#text(", with a non-zero ")#mi("{e_j}")#text(" coefficient (as can be seen by Gaussian elimination or Cramer’s rule). As ")#mi("{G=UTU^{-1}}")#text(" with ")#mi("{U}")#text(" unitary, we conclude that for each ")#mi("{1 \\leq j \\leq n}")#text(", the ")#mi("{j^{th}}")#text(" column of ")#mi("{U}")#text(" lies in the span of the eigenvectors associated to ")#mi("{\\lambda_j,\\ldots,\\lambda_n}")#text(". As these columns are orthonormal, they must thus arise from applying the Gram-Schmidt process to these eigenvectors (as discussed earlier). This argument also shows that once the diagonal entries ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" of ")#mi("{T}")#text(" are fixed, each column of ")#mi("{U}")#text(" is determined up to rotation by a unit phase. In other words, the only remaining freedom is to replace ")#mi("{U}")#text(" by ")#mi("{UR}")#text(" for some unit diagonal matrix ")#mi("{R}")#text(", and then to replace ")#mi("{T}")#text(" by ")#mi("{R^{-1}TR}")#text(" to counterbalance this change of ")#mi("{U}")#text(".")#linebreak()#text(" To summarise, the factorisation ")#mi("{G = UTU^{-1}}")#text(" is unique up to specifying an enumeration ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" of the eigenvalues of ")#mi("{G}")#text(" and right-multiplying ")#mi("{U}")#text(" by diagonal unitary matrices, and then conjugating ")#mi("{T}")#text(" by the same matrix. Given a matrix ")#mi("{G}")#text(", we may apply these symmetries randomly, ending up with a random enumeration ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" of the eigenvalues of ")#mi("{G}")#text(" (whose distribution invariant with respect to permutations) together with a random factorisation ")#mi("{UTU^{-1}}")#text(" such that ")#mi("{T}")#text(" has diagonal entries ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" in that order, and the distribution of ")#mi("{T}")#text(" is invariant under conjugation by diagonal unitary matrices. Also, since ")#mi("{G}")#text(" is itself invariant under unitary conjugations, we may also assume that ")#mi("{U}")#text(" is distributed uniformly according to the Haar measure of ")#mi("{U(n)}")#text(", and independently of ")#mi("{T}")#text(".")#linebreak()#text(" To summarise, the gaussian matrix ensemble ")#mi("{G}")#text(", together with a randomly chosen enumeration ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" of the eigenvalues, can almost surely be factorised as ")#mi("{UTU^{-1}}")#text(", where ")#mi("{T = ( t_{ij} )_{1 \\leq i \\leq j \\leq n}}")#text(" is an upper-triangular matrix with diagonal entries ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(", distributed according to some distribution")

#align(center)[#tao-fit-display[#mitex("\\psi( (t_{ij})_{1 \\leq i \\leq j \\leq n} )\\ \\prod_{1 \\leq i \\leq j \\leq n} dt_{ij}")]]

#text("which is invariant with respect to conjugating ")#mi("{T}")#text(" by diagonal unitary matrices, and ")#mi("{U}")#text(" is uniformly distributed according to the Haar measure of ")#mi("{U(n)}")#text(", independently of ")#mi("{T}")#text(".")#linebreak()#text(" Now let ")#mi("{T_0 = ( t_{ij}^0 )_{1 \\leq i \\leq j \\leq n}}")#text(" be an upper triangular matrix with complex entries whose entries ")#mi("{t_{11}^0,\\ldots,t_{nn}^0 \\in {\\bf C}}")#text(" are distinct. As in the previous section, we consider the probability ")#metadata(none) <tao-8fd769705377b461d569>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\mathop{\\bf P}( \\left\\| G - T_0 \\right\\|_F \\leq \\varepsilon ) .", block: true)]]

#text("On the one hand, since the space ")#mi("{M_n({\\bf C})}")#text(" of complex ")#mi("{n \\times n}")#text(" matrices has ")#mi("{2n^2}")#text(" real dimensions, we see from ")#link(<tao-9f584196e7fe6de85d38>)[#text("(9)")]#text(" that this expression is equal to ")#metadata(none) <tao-f21e63014346f9197bae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("(C^{\\prime}_n+o(1)) e^{-\\left\\|T_0\\right\\|_F^2} \\varepsilon^{2n^2}", block: true)]]

#text("for some constant ")#mi("{C^{\\prime}_n > 0}")#text(".")#linebreak()#text(" Now we compute ")#link(<tao-8fd769705377b461d569>)[#text("(6)")]#text(" using the factorisation ")#mi("{G = UTU^{-1}}")#text(". Suppose that ")#tao-math("{\\left\\|G-T_0\\right\\|_F \\leq \\varepsilon}", block: false)#text(", so ")#mi("{G = T_0+O(\\varepsilon)}")#text(" As the eigenvalues of ")#mi("{T_0}")#text(" are ")#mi("{t_{11}^0,\\ldots,t_{nn}^0}")#text(", which are assumed to be distinct, we see (from the inverse function theorem) that for ")#mi("{\\varepsilon}")#text(" small enough, ")#mi("{G}")#text(" has eigenvalues ")#mi("{t_{11}^0 +O(\\varepsilon), \\ldots, t_{nn}^0 + O(\\varepsilon)}")#text(". With probability ")#mi("{1/n!}")#text(", the diagonal entries of ")#mi("{T}")#text(" are thus ")#mi("{t_{11}^0 +O(\\varepsilon), \\ldots, t_{nn}^0 + O(\\varepsilon)}")#text(" (in that order). We now restrict to this event (the ")#mi("{1/n!}")#text(" factor will eventually be absorbed into one of the unspecified constants).")#linebreak()#text(" Let ")#mi("{u^0_1,\\ldots,u^0_n}")#text(" be eigenvector of ")#mi("{T_0}")#text(" associated to ")#mi("{t_{11}^0,\\ldots,t_{nn}^0}")#text(", then the Gram-Schmidt process applied to ")#mi("{u_1,\\ldots,u_n}")#text(" (starting at ")#mi("{u^0_n}")#text(" and working backwards to ")#mi("{u^0_1}")#text(") gives the standard basis ")#mi("{e_1,\\ldots,e_n}")#text(" (in reverse order). By the inverse function theorem, we thus see that we have eigenvectors ")#mi("{u_1 = u^0_1+O(\\varepsilon),\\ldots,u_n=u^0_n+O(\\varepsilon)}")#text(" of ")#mi("{G}")#text(", which when the Gram-Schmidt process is applied, gives a perturbation ")#mi("{e_1+O(\\varepsilon),\\ldots,e_n+O(\\varepsilon)}")#text(" in reverse order. This gives a factorisation ")#mi("{G=UTU^{-1}}")#text(" in which ")#mi("{U = I + O(\\varepsilon)}")#text(", and hence ")#mi("{T = T_0+O(\\varepsilon)}")#text(". This is however not the most general factorisation available, even after fixing the diagonal entries of ")#mi("{T}")#text(", due to the freedom to right-multiply ")#mi("{U}")#text(" by diagonal unitary matrices ")#mi("{R}")#text(". We thus see that the correct ansatz here is to have")

#align(center)[#tao-fit-display[#mitex("U = R + O(\\varepsilon); \\quad T = R^{-1} T_0 R + O(\\varepsilon)")]]

#text("for some diagonal unitary matrix ")#mi("{R}")#text(".")#linebreak()#text(" In analogy with the GUE case, we can use the inverse function theorem and make the more precise ansatz")

#align(center)[#tao-fit-display[#mitex("U = \\exp(\\varepsilon S) R; \\quad T = R^{-1} (T_0 + \\varepsilon E) R")]]

#text("where ")#mi("{S}")#text(" is skew-Hermitian with zero diagonal and size ")#mi("{O(1)}")#text(", ")#mi("{R}")#text(" is diagonal unitary, and ")#mi("{E}")#text(" is an upper triangular matrix of size ")#mi("{O(1)}")#text(". From the invariance ")#mi("{U \\mapsto UR; T \\mapsto R^{-1} TR}")#text(" we see that ")#mi("{R}")#text(" is distributed uniformly across all diagonal unitaries. Meanwhile, from the unitary conjugation invariance, ")#mi("{S}")#text(" is distributed according to a constant multiple of ")#mi("{\\varepsilon^{n^2-n}}")#text(" times Lebesgue measure ")#mi("{dS}")#text(" on the ")#mi("{n^2-n}")#text("-dimensional space of skew Hermitian matrices with zero diagonal; and from the definition of ")#mi("{\\psi}")#text(", ")#mi("{E}")#text(" is distributed according to a constant multiple of the measure")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\varepsilon^{n^2+n} \\psi(T_0)\\ dE,")]]

#text("where ")#mi("{dE}")#text(" is Lebesgue measure on the ")#mi("{n^2+n}")#text("-dimensional space of upper-triangular matrices. Furthermore, the invariances ensure that the random variables ")#mi("{S, R, E}")#text(" are distributed independently. Finally, we have")

#align(center)[#tao-fit-display[#mitex("G = UTU^{-1} = \\exp(\\varepsilon S) (T_0 + \\varepsilon E) \\exp(-\\varepsilon S).")]]

#text("Thus we may rewrite ")#link(<tao-8fd769705377b461d569>)[#text("(6)")]#text(" as ")#metadata(none) <tao-81b81b0f5bf5ef10c2ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("(C^{\\prime\\prime}_n \\psi(T_0)+o(1))\\varepsilon^{2n^2} \\int\\int_{\\left\\|\\exp(\\varepsilon S) (T_0 + \\varepsilon E) \\exp(-\\varepsilon S) - T_0\\right\\|_F \\leq \\varepsilon} dS dE", block: true)]]

#text("for some ")#mi("{C^{\\prime\\prime}_n>0}")#text(" (the ")#mi("{R}")#text(" integration being absorbable into this constant ")#mi("{C^{\\prime\\prime}_n}")#text("). We can Taylor expand")

#align(center)[#tao-fit-display[#mitex("\\exp(\\varepsilon S) (T_0 + \\varepsilon E) \\exp(-\\varepsilon S) = T_0 + \\varepsilon (E + ST_0 - T_0S) + O(\\varepsilon^2)")]]

#text("and so we can bound ")#link(<tao-81b81b0f5bf5ef10c2ff>)[#text("(8)")]#text(" above and below by expressions of the form")

#align(center)[#tao-fit-display[#tao-math("(C^{\\prime\\prime}_n \\psi(T_0)+o(1))\\varepsilon^{2n^2} \\int\\int_{\\left\\|E + ST_0 - T_0 S\\right\\|_F \\leq 1+O(\\varepsilon)} dS dE.", block: true)]]

#text("The Lebesgue measure ")#mi("{dE}")#text(" is invariant under translations by upper triangular matrices, so we may rewrite the above expression as ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("(C^{\\prime\\prime}_n \\psi(T_0)+o(1))\\varepsilon^{2n^2} \\int\\int_{\\left\\|E + \\pi(ST_0 - T_0 S)\\right\\|_F \\leq 1+O(\\varepsilon)} dS dE,", block: true)]]

#text("where ")#mi("{\\pi(ST_0 - T_0 S)}")#text(" is the strictly lower triangular component of ")#mi("{ST_0-T_0S}")#text(".")#linebreak()#text(" The next step is to make the (linear) change of variables ")#mi("{V := \\pi(ST_0-T_0 S)}")#text(". We check dimensions: ")#mi("{S}")#text(" ranges in the space ")#mi("{S}")#text(" of skew-adjoint Hermitian matrices with zero diagonal, which has dimension ")#mi("{(n^2-n)/2}")#text(", as does the space of strictly lower-triangular matrices, which is where ")#mi("{V}")#text(" ranges. So we can in principle make this change of variables, but we first have to compute the Jacobian of the transformation (and check that it is non-zero). For this, we switch to coordinates. Write ")#mi("{S = (s_{ij})_{1 \\leq i, j \\leq n}}")#text(" and ")#mi("{V = (v_{ij})_{1 \\leq j < i \\leq n}}")#text(". In coordinates, the equation ")#mi("{V=\\pi(ST_0-T_0S)}")#text(" becomes")

#align(center)[#tao-fit-display[#mitex("v_{ij} = \\sum_{k=1}^j s_{ik} t_{kj}^0 - \\sum_{k=i}^n t_{ik}^0 s_{kj}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("v_{ij} = (t_{jj}^0-t_{ii}^0) s_{ij} + \\sum_{k=1}^{j-1} t_{kj}^0 s_{ik}- \\sum_{k=i+1}^n t_{ik}^0 s_{kj}.")]]

#text("Thus for instance")

#tao-aligned(keep: true)[


#tao-math("v_{n1}  & = (t^0_{11}-t^0_{nn}) s_{n1}", block: true)



#tao-math("v_{n2}  & = (t^0_{22}-t^0_{nn}) s_{n2} + t_{12}^0 s_{n1}", block: true)



#tao-math("v_{(n-1)1}  & = (t^0_{11} - t^0_{(n-1)(n-1)}) s_{(n-1)1} - t_{(n-1)n}^0 s_{n1}", block: true)



#tao-math("v_{n3}  & = (t^0_{33}-t^0_{nn}) s_{n3} + t_{13}^0 s_{n1} + t_{23}^0 s_{n2}", block: true)



#tao-math("v_{(n-1)2}  & = (t^0_{22}-t^0_{(n-1)(n-1)}) s_{(n-1)2} +t_{12}^0 s_{(n-1)1} - t_{(n-1)n}^0 s_{n2}", block: true)



#tao-math("v_{(n-2)1}  & = (t^0_{11}-t^0_{(n-2)(n-2)}) s_{(n-2)1} - t_{(n-2)(n-1)}^0 s_{(n-1)1} - t_{(n-2)n}^0 s_{n1}", block: true)
]

#text("etc. We then observe that the transformation matrix from ")#mi("{s_{n1}, s_{n2}, s_{(n-1)1},\\ldots}")#text(" to ")#mi("{v_{n1}, v_{n2}, v_{(n-1)1}, \\ldots}")#text(" is triangular, with diagonal entries given by ")#mi("{t^0_{jj}-t^0_{ii}}")#text(" for ")#mi("{1 \\leq j < i \\leq n}")#text(". The Jacobian of the (complex-linear) map ")#mi("{S \\mapsto V}")#text(" is thus given by")

#align(center)[#tao-fit-display[#tao-math("\\left|\\prod_{1 \\leq j < i \\leq n} t^0_{jj}-t^0_{ii}\\right|^2 = \\left|\\Delta( t^0_{11},\\ldots,t^0_{nn})\\right|^2", block: true)]]

#text("which is non-zero by the hypothesis that the ")#mi("{t_0^{11},\\ldots,t_0^{nn}}")#text(" are distinct. We may thus rewrite ")#link(<tao-9f584196e7fe6de85d38>)[#text("(9)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\frac{C^{\\prime\\prime}_n \\psi(T_0)+o(1)}{\\left|\\Delta( t^0_{11},\\ldots,t^0_{nn})\\right|^2} \\varepsilon^{2n^2}\\int\\int_{\\left\\|E + V\\right\\|_F \\leq 1+O(\\varepsilon)} dS dV", block: true)]]

#text("where ")#mi("{dV}")#text(" is Lebesgue measure on strictly lower-triangular matrices. The integral here is equal to ")#mi("{C^{\\prime\\prime\\prime}_n + O(\\varepsilon)}")#text(" for some constant ")#mi("{C^{\\prime\\prime\\prime}_n}")#text(". Comparing this with ")#link(<tao-8fd769705377b461d569>)[#text("(6)")]#text(", cancelling the factor of ")#mi("{\\varepsilon^{2n^2}}")#text(", and sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the formula")

#align(center)[#tao-fit-display[#tao-math("\\psi( (t^0_{ij})_{1 \\leq i \\leq j \\leq n} ) = C^{\\prime\\prime\\prime\\prime}_n \\left|\\Delta( t^0_{11},\\ldots,t^0_{nn})\\right|^2 e^{-\\left\\|T_0\\right\\|_F^2}", block: true)]]

#text("for some constant ")#mi("{C^{\\prime\\prime\\prime\\prime}_n > 0}")#text(". We can expand")

#align(center)[#tao-fit-display[#tao-math("e^{-\\left\\|T_0\\right\\|_F^2} = \\prod_{1 \\leq i \\leq j \\leq n} e^{-\\left|t_{ij}^0\\right|^2}.", block: true)]]

#text("If we integrate out the off-diagonal variables ")#mi("{t^0_{ij}}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(", we see that the density function for the diagonal entries ")#mi("{(\\lambda_1,\\ldots,\\lambda_n)}")#text(" of ")#mi("{T}")#text(" is proportional to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\lambda_1,\\ldots,\\lambda_n)\\right|^2 e^{-\\sum_{j=1}^n \\left|\\lambda_j\\right|^2}.", block: true)]]

#text("Since these entries are a random permutation of the eigenvalues of ")#mi("{G}")#text(", we conclude the ")#emph[#text("Ginibre formula")]#text(" ")#metadata(none) <tao-b3d1bf2afb9e57cb0a62>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\rho_n(\\lambda_1,\\ldots,\\lambda_n) = c_n \\left|\\Delta(\\lambda_1,\\ldots,\\lambda_n)\\right|^2 e^{-\\sum_{j=1}^n \\left|\\lambda_j\\right|^2}", block: true)]]

#text("for the joint density of the eigenvalues of a gaussian random matrix, where ")#mi("{c_n > 0}")#text(" is a constant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Given that ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(" can be derived using Dyson Brownian motion, it is natural to ask whether ")#link(<tao-b3d1bf2afb9e57cb0a62>)[#text("(10)")]#text(" can be derived by a similar method. It seems that in order to do this, one needs to consider a Dyson-like process not just on the eigenvalues ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(", but on the entire triangular matrix ")#mi("{T}")#text(" (or more precisely, on the moduli space formed by quotienting out the action of conjugation by unitary diagonal matrices). Unfortunately the computations seem to get somewhat complicated, and we do not present them here.")
]

#heading(level: 1)[#strong[#text(" — 3. Mean field approximation — ")]]

#text("We can use the formula ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(" for the joint distribution to heuristically derive the semicircular law, as follows.")#linebreak()#text(" It is intuitively plausible that the spectrum ")#mi("{(\\lambda_1,\\ldots,\\lambda_n)}")#text(" should concentrate in regions in which ")#mi("{\\rho_n(\\lambda_1,\\ldots,\\lambda_n)}")#text(" is as large as possible. So it is now natural to ask how to optimise this function. Note that the expression in ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(" is non-negative, and vanishes whenever two of the ")#mi("{\\lambda_i}")#text(" collide, or when one or more of the ")#mi("{\\lambda_i}")#text(" go off to infinity, so a maximum should exist away from these degenerate situations.")#linebreak()#text(" We may take logarithms and write ")#metadata(none) <tao-3010f8fedb0184c88cd7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("- \\log \\rho_n(\\lambda_1,\\ldots,\\lambda_n) = \\sum_{j=1}^n \\frac{1}{2} \\left|\\lambda_j\\right|^2 + \\sum\\sum_{i \\neq j} \\log \\frac{1}{\\left|\\lambda_i-\\lambda_j\\right|} + C", block: true)]]

#text("where ")#mi("{C = C_n}")#text(" is a constant whose exact value is not of importance to us. From a mathematical physics perspective, one can interpret ")#link(<tao-3010f8fedb0184c88cd7>)[#text("(11)")]#text(" as a Hamiltonian for ")#mi("{n}")#text(" particles at positions ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(", subject to a confining harmonic potential (these are the ")#tao-math("{\\frac{1}{2} \\left|\\lambda_j\\right|^2}", block: false)#text(" terms) and a repulsive logarithmic potential between particles (these are the ")#tao-math("{\\log \\frac{1}{\\left|\\lambda_i-\\lambda_j\\right|}}", block: false)#text(" terms).")#linebreak()#text(" Our objective is now to find a distribution of ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" that minimises this expression.")#linebreak()#text(" We know from previous notes that the ")#mi("{\\lambda_i}")#text(" should have magnitude ")#mi("{O(\\sqrt{n})}")#text(". Let us then heuristically make a ")#link("http://en.wikipedia.org/wiki/Mean_field_theory")[#text("mean field approximation")]#text(", in that we approximate the discrete spectral measure ")#mi("{\\frac{1}{n} \\sum_{j=1}^n \\delta_{\\lambda_j/\\sqrt{n}}}")#text(" by a continuous probability measure ")#mi("{\\rho(x)\\ dx}")#text(". (Secretly, we know from the semi-circular law that we should be able to take ")#mi("{\\rho = \\frac{1}{2\\pi} (4-x^2)_+^{1/2}}")#text(", but pretend that we do not know this fact yet.) Then we can heuristically approximate ")#link(<tao-3010f8fedb0184c88cd7>)[#text("(11)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("n^2 ( \\int_{\\bf R} \\frac{1}{2} x^2 \\rho(x)\\ dx + \\int_{\\bf R} \\int_{\\bf R} \\log \\frac{1}{\\left|x-y\\right|} \\rho(x) \\rho(y)\\ dx dy ) + C^{\\prime}_n", block: true)]]

#text("and so we expect the distribution ")#mi("{\\rho}")#text(" to minimise the functional ")#metadata(none) <tao-9d067cb2f21af3da9584>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\int_{\\bf R} \\frac{1}{2} x^2 \\rho(x)\\ dx + \\int_{\\bf R} \\int_{\\bf R} \\log \\frac{1}{\\left|x-y\\right|} \\rho(x) \\rho(y)\\ dx dy.", block: true)]]

#text("One can compute the Euler-Lagrange equations of this functional:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Working formally, and assuming that ")#mi("{\\rho}")#text(" is a probability measure that minimises ")#link(<tao-9d067cb2f21af3da9584>)[#text("(12)")]#text(", argue that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} x^2 + 2 \\int_{\\bf R} \\log \\frac{1}{\\left|x-y\\right|} \\rho(y)\\ dy = C", block: true)]]

#text("for some constant ")#mi("{C}")#text(" and all ")#mi("{x}")#text(" in the support of ")#mi("{\\rho}")#text(". For all ")#mi("{x}")#text(" outside of the support, establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} x^2 + 2 \\int_{\\bf R} \\log \\frac{1}{\\left|x-y\\right|} \\rho(y)\\ dy \\geq C.", block: true)]]
]

#text("There are various ways we can solve this equation for ")#mi("{\\rho}")#text("; we sketch here a complex-analytic method. Differentiating in ")#mi("{x}")#text(", we formally obtain")

#align(center)[#tao-fit-display[#mitex("x - 2 p.v. \\int_{\\bf R} \\frac{1}{x-y} \\rho(y)\\ dy = 0")]]

#text("on the support of ")#mi("{\\rho}")#text(". But recall that if we let")

#align(center)[#tao-fit-display[#mitex("s(z) := \\int_{\\bf R} \\frac{1}{y-z} \\rho(y)\\ dy")]]

#text("be the Stieltjes transform of the probability measure ")#mi("{\\rho(x)\\ dx}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\text{Im}(s(x+i0^+)) = \\pi \\rho(x)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{Re}(s(x+i0^+)) = - p.v. \\int_{\\bf R} \\frac{1}{x-y} \\rho(y)\\ dy.")]]

#text("We conclude that")

#align(center)[#tao-fit-display[#mitex("(x + 2 \\text{Re}(s(x+i0^+)) \\text{Im}(s(x+i0^+))) = 0")]]

#text("for all ")#mi("{x}")#text(", which we rearrange as")

#align(center)[#tao-fit-display[#mitex("\\text{Im}( s^2(x+i0^+) + x s(x+i0^+) ) = 0.")]]

#text("This makes the function ")#mi("{f(z) = s^2(z) + z s(z)}")#text(" entire (it is analytic in the upper half-plane, obeys the symmetry ")#mi("{f(\\overline{z}) = \\overline{f(z)}}")#text(", and has no jump across the real line). On the other hand, as ")#mi("{s(z) = \\frac{-1+o(1)}{z}}")#text(" as ")#mi("{z \\rightarrow \\infty}")#text(", ")#mi("{f}")#text(" goes to ")#mi("{-1}")#text(" at infinity. Applying ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(", we conclude that ")#mi("{f}")#text(" is constant, thus we have the familiar equation")

#align(center)[#tao-fit-display[#mitex("s^2 + zs = -1")]]

#text("which can then be solved to obtain the semi-circular law as in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("previous notes")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Recall from ")#link("https://terrytao.wordpress.com/2010/01/18/254a-notes-3b-brownian-motion-and-dyson-brownian-motion/")[#text("Notes 3b")]#text(" that Dyson Brownian motion can be used to derive the formula ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(". One can then interpret the Dyson Brownian motion proof of the semi-circular law for GUE in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(" as a rigorous formalisation of the above mean field approximation heuristic argument.")
]

#text("One can perform a similar heuristic analysis for the spectral measure ")#mi("{\\mu_G}")#text(" of a random gaussian matrix, giving a description of the limiting density:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Using heuristic arguments similar to those above, argue that ")#mi("{\\mu_G}")#text(" should be close to a continuous probability distribution ")#mi("{\\rho(z)\\ dz}")#text(" obeying the equation")

#align(center)[#tao-fit-display[#tao-math("\\left|z\\right|^2 + 2\\int_{\\bf C} \\log \\frac{1}{\\left|z-w\\right|} \\rho(w)\\ dw = C", block: true)]]

#text("on the support of ")#mi("{\\rho}")#text(", for some constant ")#mi("{C}")#text(", with the inequality ")#metadata(none) <tao-d8c5aa59933214e8f3b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left|z\\right|^2 + 2\\int_{\\bf C} \\log \\frac{1}{\\left|z-w\\right|} \\rho(w)\\ dw \\geq C", block: true)]]

#text("outside of this support. Using the ")#link("http://en.wikipedia.org/wiki/Newtonian_potential")[#text("Newton potential")]#text(" ")#tao-math("{\\frac{1}{2\\pi} \\log \\left|z\\right|}", block: false)#text(" for the fundamental solution of the two-dimensional Laplacian ")#mi("{-\\partial_x^2 - \\partial_y^2}")#text(", conclude (non-rigorously) that ")#mi("{\\rho}")#text(" is equal to ")#mi("{\\frac{1}{\\pi}}")#text(" on its support.")#linebreak()#text(" Also argue that ")#mi("{\\rho}")#text(" should be rotationally symmetric. Use ")#link(<tao-d8c5aa59933214e8f3b8>)[#text("(13)")]#text(" and Green’s formula to argue why the support of ")#mi("{\\rho}")#text(" should be simply connected, and then conclude (again non-rigorously) the ")#emph[#text("circular law")]#text(" ")#metadata(none) <tao-f5060d458702a74ce89c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\mu_G \\approx \\frac{1}{\\pi} 1_{\\left|z\\right| \\leq 1}\\ dz.", block: true)]]
]

#text("We will see more rigorous derivations of the circular law later in these notes, and also in subsequent notes.")

#heading(level: 1)[#strong[#text(" — 4. Determinantal form of the GUE spectral distribution — ")]]

#text("In a previous section, we showed (up to constants) that the density function ")#mi("{\\rho_n(\\lambda_1,\\ldots,\\lambda_n)}")#text(" for the eigenvalues ")#mi("{\\lambda_1 \\geq \\ldots \\geq \\lambda_n}")#text(" of GUE was given by the formula ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(".")#linebreak()#text(" As is well known, the Vandermonde determinant ")#mi("{\\Delta(\\lambda_1,\\ldots,\\lambda_n)}")#text(" that appears in ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(" can be expressed up to sign as a determinant of an ")#mi("{n \\times n}")#text(" matrix, namely the matrix ")#mi("{(\\lambda_i^{j-1})_{1 \\leq i,j \\leq n}}")#text(". Indeed, this determinant is clearly a polynomial of degree ")#mi("{n(n-1)/2}")#text(" in ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(" which vanishes whenever two of the ")#mi("{\\lambda_i}")#text(" agree, and the claim then follows from the factor theorem (and inspecting a single coefficient of the Vandermonde determinant, e.g. the ")#mi("{\\prod_{j=1}^n \\lambda_j^{j-1}}")#text(" coefficient, to get the sign).")#linebreak()#text(" We can square the above fact (or more precisely, multiply the above matrix matrix by its adjoint) and conclude that ")#tao-math("{\\left|\\Delta(\\lambda_1,\\ldots,\\lambda_n)\\right|^2}", block: false)#text(" is the determinant of the matrix")

#align(center)[#tao-fit-display[#mitex("( \\sum_{k=0}^{n-1} \\lambda_i^k \\lambda_j^k )_{1 \\leq i,j \\leq n}.")]]

#text("More generally, if ")#mi("{P_0(x),\\ldots,P_{n-1}(x)}")#text(" are any sequence of polynomials, in which ")#mi("{P_i(x)}")#text(" has degree ")#mi("{i}")#text(", then we see from row operations that the determinant of")

#align(center)[#tao-fit-display[#mitex("(P_{j-1}(\\lambda_i))_{1 \\leq i,j \\leq n}")]]

#text("is a non-zero constant multiple of ")#mi("{\\Delta(\\lambda_1,\\ldots,\\lambda_n)}")#text(" (with the constant depending on the leading coefficients of the ")#mi("{P_i}")#text("), and so the determinant of")

#align(center)[#tao-fit-display[#mitex("( \\sum_{k=0}^{n-1} P_k(\\lambda_i) P_k(\\lambda_j) )_{1 \\leq i,j \\leq n}")]]

#text("is a non-zero constant multiple of ")#tao-math("{\\left|\\Delta(\\lambda_1,\\ldots,\\lambda_n)\\right|^2}", block: false)#text(". Comparing this with ")#link(<tao-94695a4b667b958b8fe9>)[#text("(1)")]#text(", we obtain the formula")

#align(center)[#tao-fit-display[#mitex("\\rho_n(\\lambda) = C \\det( \\sum_{k=0}^{n-1} P_k(\\lambda_i) e^{-\\lambda_i^2/4} P_k(\\lambda_j) e^{-\\lambda_j^2/4})_{1 \\leq i,j \\leq n}")]]

#text("for some non-zero constant ")#mi("{C}")#text(".")#linebreak()#text(" This formula is valid for any choice of polynomials ")#mi("{P_i}")#text(" of degree ")#mi("{i}")#text(". But the formula is particularly useful when we set ")#mi("{P_i}")#text(" equal to the (normalised) ")#link("http://en.wikipedia.org/wiki/Hermite_polynomials")[#text("Hermite polynomials")]#text(", defined by applying the Gram-Schmidt process in ")#mi("{L^2({\\bf R})}")#text(" to the polynomials ")#mi("{x^i e^{-x^2/4}}")#text(" for ")#mi("{i=0,\\ldots,n-1}")#text(" to yield ")#mi("{P_i(x) e^{-x^2/4}}")#text(". (Equivalently, the ")#mi("{P_i}")#text(" are the ")#link("http://en.wikipedia.org/wiki/Orthogonal_polynomials")[#text("orthogonal polynomials")]#text(" associated to the measure ")#mi("{e^{-x^2/2}\\ dx}")#text(".) In that case, the expression ")#metadata(none) <tao-c04bd90e26cc1fc255ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("K_n(x,y) := \\sum_{k=0}^{n-1} P_k(x) e^{-x^2/4} P_k(y) e^{-y^2/4}")]]

#text("becomes the integral kernel of the orthogonal projection ")#mi("{\\pi_{V_n}}")#text(" operator in ")#mi("{L^2({\\bf R})}")#text(" to the span of the ")#mi("{x^i e^{-x^2/4}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\pi_{V_n} f(x) = \\int_{\\bf R} K_n(x,y) f(y)\\ dy")]]

#text("for all ")#mi("{f \\in L^2({\\bf R})}")#text(", and so ")#mi("{\\rho_n(\\lambda)}")#text(" is now a constant multiple of")

#align(center)[#tao-fit-display[#mitex("\\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq n}.")]]

#text("The reason for working with orthogonal polynomials is that we have the trace identity ")#metadata(none) <tao-743260fe01faee8741a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\int_{\\bf R} K_n(x,x)\\ dx = \\text{tr}(\\pi_{V_n}) = n")]]

#text("and the reproducing formula ")#metadata(none) <tao-4973bf3f42a9b522ad8f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("K_n(x,y) = \\int_{\\bf R} K_n(x,z) K_n(z,y)\\ dz")]]

#text("which reflects the identity ")#mi("{\\pi_{V_n} = \\pi_{V_n}^2}")#text(". These two formulae have an important consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Determinantal integration formula)")]#text(" Let ")#mi("{K_n: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" be any symmetric rapidly decreasing function obeying ")#link(<tao-743260fe01faee8741a7>)[#text("(16)")]#text(", ")#link(<tao-4973bf3f42a9b522ad8f>)[#text("(17)")]#text(". Then for any ")#mi("{k \\geq 0}")#text(", one has ")#metadata(none) <tao-11a62c23412b77477a71>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\int_{\\bf R} \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k+1}\\ d\\lambda_{k+1} = (n-k) \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" This remarkable identity is part of the beautiful algebraic theory of ")#emph[#text("determinantal processes")]#text(", which I discuss further in ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("this blog post")]#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{k}")#text(". When ")#mi("{k=0}")#text(" this is just ")#link(<tao-743260fe01faee8741a7>)[#text("(16)")]#text(". Now assume that ")#mi("{k \\geq 1}")#text(" and that the claim has already been proven for ")#mi("{k-1}")#text(". We apply ")#link("http://en.wikipedia.org/wiki/Cofactor_(linear_algebra)")[#text("cofactor expansion")]#text(" to the bottom row of the determinant ")#mi("{\\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k+1}}")#text(". This gives a principal term ")#metadata(none) <tao-dbb4e692c9327807fd2d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k} K_n(\\lambda_{k+1},\\lambda_{k+1})")]]

#text("plus a sum of ")#mi("{k}")#text(" additional terms, the ")#mi("{l^{th}}")#text(" term of which is of the form ")#metadata(none) <tao-03115cc13ab7b19669d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("(-1)^{k+1-l} K_n(\\lambda_l,\\lambda_{k+1}) \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i \\leq k; 1 \\leq j \\leq k+1; j \\neq l}.")]]

#text("Using ")#link(<tao-743260fe01faee8741a7>)[#text("(16)")]#text(", the principal term ")#link(<tao-dbb4e692c9327807fd2d>)[#text("(19)")]#text(" gives a contribution of ")#mi("{n \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k}}")#text(" to ")#link(<tao-11a62c23412b77477a71>)[#text("(18)")]#text(". For each nonprincipal term ")#link(<tao-03115cc13ab7b19669d3>)[#text("(20)")]#text(", we use the multilinearity of the determinant to absorb the ")#mi("{K_n(\\lambda_l,\\lambda_{k+1})}")#text(" term into the ")#mi("{j=k+1}")#text(" column of the matrix. Using ")#link(<tao-4973bf3f42a9b522ad8f>)[#text("(17)")]#text(", we thus see that the contribution of ")#link(<tao-03115cc13ab7b19669d3>)[#text("(20)")]#text(" to ")#link(<tao-11a62c23412b77477a71>)[#text("(18)")]#text(" can be simplified as")

#align(center)[#tao-fit-display[#mitex("(-1)^{k+1-l} \\det( ( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i \\leq k; 1 \\leq j \\leq k; j \\neq l}, (K_n(\\lambda_i,\\lambda_l))_{1 \\leq i\\leq k} )")]]

#text("which after row exchange, simplifies to ")#mi("{-\\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k}}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" In particular, if we iterate the above lemma using the Fubini-Tonelli theorem, we see that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq n}\\ d\\lambda_1 \\ldots d\\lambda_n = n!.")]]

#text("On the other hand, if we extend the probability density function ")#mi("{\\rho_n(\\lambda_1,\\ldots,\\lambda_n)}")#text(" symmetrically from the Weyl chamber ")#mi("{{\\bf R}^n_{\\geq}}")#text(" to all of ")#mi("{{\\bf R}^n}")#text(", its integral is also ")#mi("{n!}")#text(". Since ")#mi("{\\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq n}}")#text(" is clearly symmetric in the ")#mi("{\\lambda_1,\\ldots,\\lambda_n}")#text(", we can thus compare constants and conclude the ")#link("http://www.ams.org/mathscinet-getitem?mr=112895")[#text("Gaudin-Mehta formula")]

#align(center)[#tao-fit-display[#mitex("\\rho_n(\\lambda_1,\\ldots,\\lambda_n) = \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq n}.")]]

#text("More generally, if we define ")#mi("{\\rho_k: {\\bf R}^k \\rightarrow {\\bf R}^+}")#text(" to be the function ")#metadata(none) <tao-7b83dce0377470e43481>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\rho_k(\\lambda_1,\\ldots,\\lambda_k) = \\det( K_n(\\lambda_i, \\lambda_j) )_{1 \\leq i,j \\leq k},")]]

#text("then the above formula shows that ")#mi("{\\rho_k}")#text(" is the ")#emph[#mi("{k}")#text("-point correlation function")]#text(" for the spectrum, in the sense that ")#metadata(none) <tao-db083e890b94bca2d0d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_{{\\bf R}^k} \\rho_k(\\lambda_1,\\ldots,\\lambda_k) F(\\lambda_1,\\ldots,\\lambda_k)\\ d\\lambda_1 \\ldots d\\lambda_k")]]

#align(center)[#tao-fit-display[#mitex("= \\mathop{\\bf E} \\sum_{1 \\leq i_1, \\ldots, i_k \\leq n, \\text{ distinct}} F( \\lambda_{i_1}(M_n),\\ldots,\\lambda_{i_k}(M_n) )")]]

#text("for any test function ")#mi("{F: {\\bf R}^k \\rightarrow {\\bf C}}")#text(" supported in the region ")#mi("{\\{ (x_1,\\ldots,x_k): x_1 \\leq \\ldots \\leq x_k \\}}")#text(".")#linebreak()#text(" In particular, if we set ")#mi("{k=1}")#text(", we obtain the explicit formula")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mu_{M_n} = \\frac{1}{n} K_n(x,x)\\ dx")]]

#text("for the expected empirical spectral measure of ")#mi("{M_n}")#text(". Equivalently after renormalising by ")#mi("{\\sqrt{n}}")#text(", we have ")#metadata(none) <tao-2cda36e6665669fdf88e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}} = \\frac{1}{n^{1/2}} K_n(\\sqrt{n}x,\\sqrt{n}x)\\ dx.")]]

#text("It is thus of interest to understand the kernel ")#mi("{K_n}")#text(" better.")#linebreak()#text(" To do this, we begin by recalling that the functions ")#mi("{P_i(x) e^{-x^2/4}}")#text(" were obtained from ")#mi("{x^i e^{-x^2/4}}")#text(" by the Gram-Schmidt process. In particular, each ")#mi("{P_i(x) e^{-x^2/4}}")#text(" is orthogonal to the ")#mi("{x^j e^{-x^2/4}}")#text(" for all ")#mi("{0 \\leq j<i}")#text(". This implies that ")#mi("{x P_i(x) e^{-x^2/4}}")#text(" is orthogonal to ")#mi("{x^j e^{-x^2/4}}")#text(" for ")#mi("{0 \\leq j < i-1}")#text(". On the other hand, ")#mi("{xP_i(x)}")#text(" is a polynomial of degree ")#mi("{i+1}")#text(", so ")#mi("{x P_i(x) e^{-x^2/4}}")#text(" must lie in the span of ")#mi("{x^j e^{-x^2/4}}")#text(" for ")#mi("{0 \\leq j \\leq i+1}")#text(". Combining the two facts, we see that ")#mi("{x P_i}")#text(" must be a linear combination of ")#mi("{P_{i-1}, P_i, P_{i+1}}")#text(", with the ")#mi("{P_{i+1}}")#text(" coefficient being non-trivial. We rewrite this fact in the form ")#metadata(none) <tao-bd75b3e080945674c035>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("P_{i+1}(x) = (a_i x + b_i) P_i(x) - c_i P_{i-1}(x)")]]

#text("for some real numbers ")#mi("{a_i,b_i,c_i}")#text(" (with ")#mi("{c_0=0}")#text("). Taking inner products with ")#mi("{P_{i+1}}")#text(" and ")#mi("{P_{i-1}}")#text(" we see that ")#metadata(none) <tao-6c1ff09db3a73dc4a854>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\int_{\\bf R} x P_i(x) P_{i+1}(x) e^{-x^2/2}\\ dx = \\frac{1}{a_i}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} x P_i(x) P_{i-1}(x) e^{-x^2/2}\\ dx = \\frac{c_i}{a_i}")]]

#text("and so ")#metadata(none) <tao-78214a4e70c8502794a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("c_i := \\frac{a_i}{a_{i-1}}")]]

#text("(with the convention ")#mi("{a_{-1}=\\infty}")#text(").")#linebreak()#text(" We will continue the computation of ")#mi("{a_i,b_i,c_i}")#text(" later. For now, we we pick two distinct real numbers ")#mi("{x,y}")#text(" and consider the ")#link("http://en.wikipedia.org/wiki/Wronskian")[#text("Wronskian")]#text("-type expression")

#align(center)[#tao-fit-display[#mitex("P_{i+1}(x) P_i(y) - P_i(x) P_{i+1}(y).")]]

#text("Using ")#link(<tao-bd75b3e080945674c035>)[#text("(24)")]#text(", ")#link(<tao-78214a4e70c8502794a6>)[#text("(26)")]#text(", we can write this as")

#align(center)[#tao-fit-display[#mitex("a_i(x-y) P_i(x) P_i(y) + \\frac{a_i}{a_{i-1}} (P_{i-1}(x) P_i(y) - P_i(x) P_{i-1}(y))")]]

#text("or in other words")

#tao-aligned(keep: true)[


#tao-math("P_i(x) P_i(y)  & = \\frac{P_{i+1}(x) P_i(y) - P_i(x) P_{i+1}(y)}{a_i(x-y)}", block: true)



#tao-math(" & - \\frac{P_i(x) P_{i-1}(y) - P_{i-1}(x) P_i(y)}{a_{i-1}(x-y)}.", block: true)
]

#text("We telescope this and obtain the ")#emph[#text("Christoffel-Darboux formula")]#text(" for the kernel ")#link(<tao-c04bd90e26cc1fc255ba>)[#text("(15)")]#text(": ")#metadata(none) <tao-06bbf794cc79dd26a786>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("K_n(x,y) = \\frac{P_{n}(x)P_{n-1}(y) - P_{n-1}(x) P_{n}(y)}{a_{n-1}(x-y)} e^{-(x^2+y^2)/4}.")]]

#text("Sending ")#mi("{y \\rightarrow x}")#text(" using ")#link("http://en.wikipedia.org/wiki/L%27H%C3%B4pital%27s_rule")[#text("L’Hopital’s rule")]#text(", we obtain in particular that ")#metadata(none) <tao-4f82af095980492a4a50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("K_n(x,x) = \\frac{1}{a_{n-1}}( P^{\\prime}_{n}(x)P_{n-1}(x) - P^{\\prime}_{n-1}(x) P_{n}(x) ) e^{-x^2/2}.")]]

#text("Inserting this into ")#link(<tao-2cda36e6665669fdf88e>)[#text("(23)")]#text(", we see that if we want to understand the expected spectral measure of GUE, we should understand the asymptotic behaviour of ")#mi("{P_n}")#text(" and the associated constants ")#mi("{a_n}")#text(". For this, we need to exploit the specific properties of the gaussian weight ")#mi("{e^{-x^2/2}}")#text(". In particular, we have the identity ")#metadata(none) <tao-3b8d14199277153e41ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("x e^{-x^2/2} = - \\frac{d}{dx} e^{-x^2/2}")]]

#text("so upon integrating ")#link(<tao-6c1ff09db3a73dc4a854>)[#text("(25)")]#text(" by parts, we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (P^{\\prime}_i(x) P_{i+1}(x) + P_i(x) P^{\\prime}_{i+1}(x)) e^{-x^2/2}\\ dx = \\frac{1}{a_i}.")]]

#text("As ")#mi("{P^{\\prime}_i}")#text(" has degree at most ")#mi("{i-1}")#text(", the first term vanishes by the orthonormal nature of the ")#mi("{P_i(x) e^{-x^2/4}}")#text(", thus ")#metadata(none) <tao-bb9af5d1915da1fbc132>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\int_{\\bf R} P_i(x) P^{\\prime}_{i+1}(x) e^{-x^2/2}\\ dx = \\frac{1}{a_i}.")]]

#text("To compute this, let us denote the leading coefficient of ")#mi("{P_i}")#text(" as ")#mi("{k_i}")#text(". Then ")#mi("{P^{\\prime}_{i+1}}")#text(" is equal to ")#mi("{\\frac{(i+1)k_{i+1}}{k_i} P_i}")#text(" plus lower-order terms, and so we have")

#align(center)[#tao-fit-display[#mitex("\\frac{(i+1)k_{i+1}}{k_i} = \\frac{1}{a_i}.")]]

#text("On the other hand, by inspecting the ")#mi("{x^{i+1}}")#text(" coefficient of ")#link(<tao-bd75b3e080945674c035>)[#text("(24)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("k_{i+1} = a_i k_i.")]]

#text("Combining the two formulae (and making the sign convention that the ")#mi("{k_i}")#text(" are always positive), we see that")

#align(center)[#tao-fit-display[#mitex("a_i = \\frac{1}{\\sqrt{i+1}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("k_{i+1} = \\frac{k_i}{\\sqrt{i+1}}.")]]

#text("Meanwhile, a direct computation shows that ")#mi("{P_0(x) = k_0 = \\frac{1}{(2\\pi)^{1/4}}}")#text(", and thus by induction")

#align(center)[#tao-fit-display[#mitex("k_i := \\frac{1}{(2\\pi)^{1/4} \\sqrt{i!}}.")]]

#text("A similar method lets us compute the ")#mi("{b_i}")#text(". Indeed, taking inner products of ")#link(<tao-bd75b3e080945674c035>)[#text("(24)")]#text(" with ")#mi("{P_i(x) e^{-x^2/2}}")#text(" and using orthonormality we have")

#align(center)[#tao-fit-display[#mitex("b_i = - a_i \\int_{\\bf R} x P_i(x)^2 e^{-x^2/2}\\ dx")]]

#text("which upon integrating by parts using ")#link(<tao-3b8d14199277153e41ea>)[#text("(29)")]#text(" gives")

#align(center)[#tao-fit-display[#mitex("b_i = - 2 a_i \\int_{\\bf R} P_i(x) P^{\\prime}_i(x) e^{-x^2/2}\\ dx.")]]

#text("As ")#mi("{P^{\\prime}_i}")#text(" is of degree strictly less than ")#mi("{i}")#text(", the integral vanishes by orthonormality, thus ")#mi("{b_i=0}")#text(". The identity ")#link(<tao-bd75b3e080945674c035>)[#text("(24)")]#text(" thus becomes ")#emph[#text("Hermite recurrence relation")]#text(" ")#metadata(none) <tao-420fce314175df402adb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("P_{i+1}(x) = \\frac{1}{\\sqrt{i+1}} x P_i(x) - \\frac{\\sqrt{i}}{\\sqrt{i+1}} P_{i-1}(x).")]]

#text("Another recurrence relation arises by considering the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} P_j(x) P^{\\prime}_{i+1}(x) e^{-x^2/2}\\ dx.")]]

#text("On the one hand, as ")#mi("{P^{\\prime}_{i+1}}")#text(" has degree at most ")#mi("{i}")#text(", this integral vanishes if ")#mi("{j>i}")#text(" by orthonormality. On the other hand, integrating by parts using ")#link(<tao-3b8d14199277153e41ea>)[#text("(29)")]#text(", we can write the integral as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (xP_j - P^{\\prime}_j)(x) P_{i+1}(x) e^{-x^2/2}\\ dx.")]]

#text("If ")#mi("{j < i}")#text(", then ")#mi("{xP_j-P^{\\prime}_j}")#text(" has degree less than ")#mi("{i+1}")#text(", so the integral again vanishes. Thus the integral is non-vanishing only when ")#mi("{j=i}")#text(". Using ")#link(<tao-bb9af5d1915da1fbc132>)[#text("(30)")]#text(", we conclude that ")#metadata(none) <tao-4cd9b7672d7fbee8fb51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("P^{\\prime}_{i+1} = \\frac{1}{a_i} P_i = \\sqrt{i+1} P_i.")]]

#text("We can combine ")#link(<tao-4cd9b7672d7fbee8fb51>)[#text("(32)")]#text(" with ")#link(<tao-420fce314175df402adb>)[#text("(31)")]#text(" to obtain the formula")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dx}( e^{-x^2/2} P_i(x) ) = - \\sqrt{i+1} e^{-x^2/2} P_{i+1}(x),")]]

#text("which together with the initial condition ")#mi("{P_0 = \\frac{1}{(2\\pi)^{1/4}}}")#text(" gives the explicit representation ")#metadata(none) <tao-c76b35cb04a4e944224e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("P_n(x) := \\frac{(-1)^n}{(2\\pi)^{1/4} \\sqrt{n!}} e^{x^2/2} \\frac{d^n}{dx^n} e^{-x^2/2}")]]

#text("for the Hermite polynomials. Thus, for instance, at ")#mi("{x=0}")#text(" one sees from Taylor expansion that ")#metadata(none) <tao-1d78e018e405ef26b7f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("P_n(0) = \\frac{(-1)^{n/2}\\sqrt{n!}}{(2\\pi)^{1/4} 2^{n/2} (n/2)!} ;\\quad P^{\\prime}_n(0) = 0")]]

#text("when ")#mi("{n}")#text(" is even, and ")#metadata(none) <tao-833e6fdf7fe6a8db0557>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("P_n(0) = 0;\\quad P^{\\prime}_n(0) = \\frac{(-1)^{(n-1)/2} (n+1) \\sqrt{n!}}{(2\\pi)^{1/4} 2^{(n+1)/2} ((n+1)/2)!}")]]

#text("when ")#mi("{n}")#text(" is odd.")#linebreak()#text(" In principle, the formula ")#link(<tao-c76b35cb04a4e944224e>)[#text("(33)")]#text(", together with ")#link(<tao-4f82af095980492a4a50>)[#text("(28)")]#text(", gives us an explicit description of the kernel ")#mi("{K_n(x,x)}")#text(" (and thus of ")#mi("{\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}}}")#text(", by ")#link(<tao-2cda36e6665669fdf88e>)[#text("(23)")]#text("). However, to understand the asymptotic behaviour as ")#mi("{n \\rightarrow \\infty}")#text(", we would have to understand the asymptotic behaviour of ")#mi("{\\frac{d^n}{dx^n} e^{-x^2/2}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", which is not immediately discernable by inspection. However, one can obtain such asymptotics by a variety of means. We give two such methods here: a method based on ODE analysis, and a complex-analytic method, based on the ")#link("http://en.wikipedia.org/wiki/Method_of_steepest_descent")[#text("method of steepest descent")]#text(".")#linebreak()#text(" We begin with the ODE method. Combining ")#link(<tao-420fce314175df402adb>)[#text("(31)")]#text(" with ")#link(<tao-4cd9b7672d7fbee8fb51>)[#text("(32)")]#text(" we see that each polynomial ")#mi("{P_m}")#text(" obeys the ")#emph[#text("Hermite differential equation")]

#align(center)[#tao-fit-display[#mitex("P^{\\prime\\prime}_m(x) - x P^{\\prime}_m(x) + m P_m(x) = 0.")]]

#text("If we look instead at the Hermite functions ")#mi("{\\phi_m(x) := P_m(x) e^{-x^2/4}}")#text(", we obtain the differential equation")

#align(center)[#tao-fit-display[#mitex("L \\phi_m(x) = (m+\\frac{1}{2}) \\phi_m")]]

#text("where ")#mi("{L}")#text(" is the ")#emph[#text("harmonic oscillator operator")]

#align(center)[#tao-fit-display[#mitex("L \\phi := - \\phi^{\\prime\\prime} + \\frac{x^2}{4} \\phi.")]]

#text("Note that the self-adjointness of ")#mi("{L}")#text(" here is consistent with the orthogonal nature of the ")#mi("{\\phi_m}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Use ")#link(<tao-c04bd90e26cc1fc255ba>)[#text("(15)")]#text(", ")#link(<tao-4f82af095980492a4a50>)[#text("(28)")]#text(", ")#link(<tao-c76b35cb04a4e944224e>)[#text("(33)")]#text(", ")#link(<tao-420fce314175df402adb>)[#text("(31)")]#text(", ")#link(<tao-4cd9b7672d7fbee8fb51>)[#text("(32)")]#text(" to establish the identities")

#tao-aligned(keep: true)[


#tao-math("K_n(x,x)  & = \\sum_{j=0}^{n-1} \\phi_j(x)^2", block: true)



#tao-math(" & = \\phi^{\\prime}_n(x)^2 + (n - \\frac{x^2}{4}) \\phi_n(x)^2", block: true)
]

#text("and thus by ")#link(<tao-2cda36e6665669fdf88e>)[#text("(23)")]

#tao-aligned(keep: true)[


#tao-math("\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}}  & = \\frac{1}{\\sqrt{n}} \\sum_{j=0}^{n-1} \\phi_j(\\sqrt{n} x)^2\\ dx =", block: true)



#tao-math(" & = [\\frac{1}{\\sqrt{n}} \\phi^{\\prime}_n(\\sqrt{n} x)^2 + \\sqrt{n} (1 - \\frac{x^2}{4}) \\phi_n(\\sqrt{n} x)^2]\\ dx.", block: true)
]
]

#text("It is thus natural to look at the rescaled functions")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi_m(x) := n^{1/4} \\phi_m(\\sqrt{n} x)")]]

#text("which are orthonormal in ")#mi("{L^2({\\bf R})}")#text(" and solve the equation")

#align(center)[#tao-fit-display[#mitex("L_{1/n} \\tilde \\phi_m(x) = \\frac{m+1/2}{n} \\tilde \\phi_m")]]

#text("where ")#mi("{L_h}")#text(" is the ")#emph[#text("semiclassical harmonic oscillator operator")]

#align(center)[#tao-fit-display[#mitex("L_h \\phi := - h^2 \\phi^{\\prime\\prime} + \\frac{x^2}{4} \\phi,")]]

#text("thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}} = \\frac{1}{n} \\sum_{j=0}^{n-1} \\tilde \\phi_j(x)^2\\ dx =")]]

#metadata(none) <tao-44ff30f3c7242b3c1bc8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("= [\\frac{1}{n^2} \\tilde \\phi^{\\prime}_n(x)^2 + (1 - \\frac{x^2}{4}) \\tilde \\phi_n(x)^2]\\ dx.")]]

#text("The projection ")#mi("{\\pi_{V_n}}")#text(" is then the spectral projection operator of ")#mi("{L_{1/\\sqrt{n}}}")#text(" to ")#mi("{[0,1]}")#text(". According to ")#link("http://en.wikipedia.org/wiki/Semiclassical")[#text("semi-classical analysis")]#text(", with ")#mi("{h}")#text(" being interpreted as analogous to Planck’s constant, the operator ")#mi("{L_h}")#text(" has symbol ")#mi("{p^2 + \\frac{x^2}{4}}")#text(", where ")#mi("{p := -i h \\frac{d}{dx}}")#text(" is the momentum operator, so the projection ")#mi("{\\pi_{V_n}}")#text(" is a projection to the region ")#mi("{\\{ (x,p): p^2 + \\frac{x^2}{4} \\leq 1 \\}}")#text(" of phase space, or equivalently to the region ")#tao-math("{\\{ (x,p): \\left|p\\right| < (4-x^2)_+^{1/2}\\}}", block: false)#text(". In the semi-classical limit ")#mi("{h \\rightarrow 0}")#text(", we thus expect the diagonal ")#mi("{K_n(x,x)}")#text(" of the normalised projection ")#mi("{h^2 \\pi_{V_n}}")#text(" to be proportional to the projection of this region to the ")#mi("{x}")#text(" variable, i.e. proportional to ")#mi("{(4-x^2)_+^{1/2}}")#text(". We are thus led to the semi-circular law via semi-classical analysis.")#linebreak()#text(" It is possible to make the above argument rigorous, but this would require developing the theory of ")#link("http://en.wikipedia.org/wiki/Microlocal_analysis")[#text("microlocal analysis")]#text(", which would be overkill given that we are just dealing with an ODE rather than a PDE here (and an extremely classical ODE at that). We instead use a more basic semiclassical approximation, the ")#link("http://en.wikipedia.org/wiki/WKB_approximation")[#text("WKB approximation")]#text(", which we will make rigorous using the classical ")#link("http://en.wikipedia.org/wiki/Method_of_variation_of_parameters")[#text("method of variation of parameters")]#text(" (one could also proceed using the closely related ")#emph[#text("Prüfer transformation")]#text(", which we will not detail here). We study the eigenfunction equation")

#align(center)[#tao-fit-display[#mitex("L_h \\phi = \\lambda \\phi")]]

#text("where we think of ")#mi("{h > 0}")#text(" as being small, and ")#mi("{\\lambda}")#text(" as being close to ")#mi("{1}")#text(". We rewrite this as ")#metadata(none) <tao-a17fe9d0c3908a85d7e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\phi^{\\prime\\prime} = - \\frac{1}{h^2} k(x)^2 \\phi")]]

#text("where ")#mi("{k(x) := \\sqrt{\\lambda - x^2/4}}")#text(", where we will only work in the “classical” region ")#mi("{x^2/4 < \\lambda}")#text(" (so ")#mi("{k(x) > 0}")#text(") for now.")#linebreak()#text(" Recall that the general solution to the constant coefficient ODE ")#mi("{\\phi^{\\prime\\prime} = -\\frac{1}{h^2} k^2 \\phi}")#text(" is given by ")#mi("{\\phi(x) = A e^{ikx/h} + B e^{-ikx/h}}")#text(". Inspired by this, we make the ansatz")

#align(center)[#tao-fit-display[#mitex("\\phi(x) = A(x) e^{i \\Psi(x)/h} + B(x) e^{-i \\Psi(x)/h}")]]

#text("where ")#mi("{\\Psi(x) := \\int_0^x k(y)\\ dy}")#text(" is the antiderivative of ")#mi("{k}")#text(". Differentiating this, we have")

#tao-aligned(keep: true)[


#tao-math("\\phi^{\\prime}(x)  & = \\frac{i k(x)}{h}( A(x) e^{i\\Psi(x)/h} - B(x) e^{-i\\Psi(x)/h} )", block: true)



#tao-math(" & + A^{\\prime}(x) e^{i\\Psi(x)/h} + B^{\\prime}(x) e^{-i\\Psi(x)/h}.", block: true)
]

#text("Because we are representing a single function ")#mi("{\\phi}")#text(" by two functions ")#mi("{A, B}")#text(", we have the freedom to place an additional constraint on ")#mi("{A,B}")#text(". Following the usual variation of parameters strategy, we will use this freedom to eliminate the last two terms in the expansion of ")#mi("{\\phi}")#text(", thus ")#metadata(none) <tao-7cc2b20e9ace6170e88e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("A^{\\prime}(x) e^{i\\Psi(x)/h} + B^{\\prime}(x) e^{-i\\Psi(x)/h} = 0.")]]

#text("We can now differentiate again and obtain")

#tao-aligned(keep: true)[


#tao-math("\\phi^{\\prime\\prime}(x)  & = -\\frac{k(x)^2}{h^2} \\phi(x) + \\frac{ik^{\\prime}(x)}{h} ( A(x) e^{i\\Psi(x)/h} - B(x) e^{-i\\Psi(x)/h} )", block: true)



#tao-math(" & + \\frac{ik(x)}{h} ( A^{\\prime}(x) e^{i\\Psi(x)/h} - B^{\\prime}(x) e^{-i\\Psi(x)/h} ).", block: true)
]

#text("Comparing this with ")#link(<tao-a17fe9d0c3908a85d7e5>)[#text("(37)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("A^{\\prime}(x) e^{i\\Psi(x)/h} - B^{\\prime}(x) e^{-i\\Psi(x)/h} = - \\frac{k^{\\prime}(x)}{k(x)} ( A(x) e^{i\\Psi(x)/h} - B(x) e^{-i\\Psi(x)/h} ).")]]

#text("Combining this with ")#link(<tao-7cc2b20e9ace6170e88e>)[#text("(38)")]#text(", we obtain equations of motion for ")#mi("{A}")#text(" and ")#mi("{B}")#text(":")

#tao-aligned(keep: true)[


#tao-math("A^{\\prime}(x)  & = - \\frac{k^{\\prime}(x)}{2 k(x)} A(x) + \\frac{k^{\\prime}(x)}{2 k(x)} B(x) e^{-2i\\Psi(x)/h}", block: true)



#tao-math("B^{\\prime}(x)  & = - \\frac{k^{\\prime}(x)}{2 k(x)} B(x) + \\frac{k^{\\prime}(x)}{2 k(x)} A(x) e^{2i\\Psi(x)/h}.", block: true)
]

#text("We can simplify this using the ")#link("http://en.wikipedia.org/wiki/Integrating_factor")[#text("integrating factor")]#text(" substitution")

#align(center)[#tao-fit-display[#mitex("A(x) = k(x)^{-1/2} a(x); \\quad B(x) = k(x)^{-1/2} b(x)")]]

#text("to obtain ")#metadata(none) <tao-f55ff16f66f43360266b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("a^{\\prime}(x) = \\frac{k^{\\prime}(x)}{2 k(x)} b(x) e^{-2i\\Psi(x)/h};")]]

#metadata(none) <tao-2c3a4249d77070058649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("b^{\\prime}(x) = \\frac{k^{\\prime}(x)}{2 k(x)} a(x) e^{2i\\Psi(x)/h}.")]]

#text("The point of doing all these transformations is that the role of the ")#mi("{h}")#text(" parameter no longer manifests itself through amplitude factors, and instead only is present in a phase factor. In particular, we have")

#align(center)[#tao-fit-display[#tao-math("a^{\\prime}, b^{\\prime} = O( \\left|a\\right| + \\left|b\\right| )", block: true)]]

#text("on any compact interval ")#mi("{I}")#text(" in the interior of the classical region ")#mi("{x^2/4 < \\lambda}")#text(" (where we allow implied constants to depend on ")#mi("{I}")#text("), which by ")#link("http://en.wikipedia.org/wiki/Gronwall's_inequality")[#text("Gronwall’s inequality")]#text(" gives the bounds")

#align(center)[#tao-fit-display[#tao-math("a^{\\prime}(x), b^{\\prime}(x), a(x), b(x) = O( \\left|a(0)\\right| + \\left|b(0)\\right| )", block: true)]]

#text("on this interval ")#mi("{I}")#text(". We can then insert these bounds into ")#link(<tao-f55ff16f66f43360266b>)[#text("(39)")]#text(", ")#link(<tao-2c3a4249d77070058649>)[#text("(40)")]#text(" again and integrate by parts (taking advantage of the non-stationary nature of ")#mi("{\\Psi}")#text(") to obtain the improved bounds ")#metadata(none) <tao-5317711b6b40b378f6b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#tao-math("a(x) = a(0) + O( h (\\left|a(0)\\right|+\\left|b(0)\\right|) ); \\quad b(x) = b(0) + O(h (\\left|a(0)\\right|+\\left|b(0)\\right|) )", block: true)]]

#text("on this interval. (More precise asymptotic expansions can be obtained by iterating this procedure, but we will not need them here.) This is already enough to get the asymptotics that we need:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Use ")#link(<tao-44ff30f3c7242b3c1bc8>)[#text("(36)")]#text(" to Show that on any compact interval ")#mi("{I}")#text(" in ")#mi("{(-2,2)}")#text(", the density of ")#mi("{\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}}}")#text(" is given by")

#align(center)[#tao-fit-display[#tao-math("4 a(0) b(0) ( \\sqrt{1-x^2/4} + o(1) ) + O( \\left|a(x)\\right| \\left|b(x)\\right| )", block: true)]]

#text("where ")#mi("{a, b}")#text(" are as above with ")#mi("{\\lambda=1+\\frac{1}{2n}}")#text(" and ")#mi("{h=\\frac{1}{n}}")#text(". Combining this with ")#link(<tao-5317711b6b40b378f6b3>)[#text("(41)")]#text(", ")#link(<tao-1d78e018e405ef26b7f7>)[#text("(34)")]#text(", ")#link(<tao-833e6fdf7fe6a8db0557>)[#text("(35)")]#text(", and Stirling’s formula, conclude that ")#mi("{\\mathop{\\bf E} \\mu_{M_n/\\sqrt{n}}}")#text(" converges in the vague topology to the semicircular law ")#mi("{\\frac{1}{2\\pi} (4-x^2)_+^{1/2}\\ dx}")#text(". (Note that once one gets convergence inside ")#mi("{(-2,2)}")#text(", the convergence outside of ")#mi("{[-2,2]}")#text(" can be obtained for free since ")#mi("{\\mu_{M_n/\\sqrt{n}}}")#text(" and ")#mi("{\\frac{1}{2\\pi} (4-x^2)_+^{1/2}\\ dx}")#text(" are both probability measures.")
]

#text("We now sketch out the approach using the ")#link("http://en.wikipedia.org/wiki/Method_of_steepest_descent")[#text("method of steepest descent")]#text(". The starting point is the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("e^{-x^2/2} = \\frac{1}{\\sqrt{2\\pi}} \\int_{\\bf R} e^{itx} e^{-t^2/2}\\ dt")]]

#text("which upon repeated differentiation gives")

#align(center)[#tao-fit-display[#mitex("\\frac{d^n}{dx^n} e^{-x^2/2} = \\frac{i^n}{\\sqrt{2\\pi}} \\int_{\\bf R} t^n e^{itx} e^{-t^2/2}\\ dt")]]

#text("and thus by ")#link(<tao-c76b35cb04a4e944224e>)[#text("(33)")]

#align(center)[#tao-fit-display[#mitex("P_n(x) = \\frac{(-i)^n}{(2\\pi)^{3/4} \\sqrt{n!}} \\int_{\\bf R} t^n e^{-(t-ix)^2/2}\\ dt")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\tilde \\phi_n(x) = \\frac{(-i)^n}{(2\\pi)^{3/4} \\sqrt{n!}} n^{\\frac{n}{2}+\\frac{1}{4}} \\int_{\\bf R} e^{n \\phi(t)} \\ dt")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\phi(t) := \\log t - (t-ix)^2/2 - x^2/4")]]

#text("where we use a suitable branch of the complex logarithm to handle the case of negative ")#mi("{t}")#text(".")#linebreak()#text(" The idea of the principle of steepest descent is to shift the contour of integration to where the real part of ")#mi("{\\phi(z)}")#text(" is as small as possible. For this, it turns out that the stationary points of ")#mi("{\\phi(z)}")#text(" play a crucial role. A brief calculation using the quadratic formula shows that there are two such stationary points, at")

#align(center)[#tao-fit-display[#mitex("z = \\frac{ix \\pm \\sqrt{4-x^2}}{2}.")]]

#text("When ")#tao-math("{\\left|x\\right| < 2}", block: false)#text(", ")#mi("{\\phi}")#text(" is purely imaginary at these stationary points, while for ")#tao-math("{\\left|x\\right| > 2}", block: false)#text(" the real part of ")#mi("{\\phi}")#text(" is negative at both points. One then draws a contour through these two stationary points in such a way that near each such point, the imaginary part of ")#mi("{\\phi(z)}")#text(" is kept fixed, which keeps oscillation to a minimum and allows the real part to decay as steeply as possible (which explains the name of the method). After a certain tedious amount of computation, one obtains the same type of asymptotics for ")#mi("{\\tilde \\phi_n}")#text(" that were obtained by the ODE method when ")#tao-math("{\\left|x\\right| < 2}", block: false)#text(" (and exponentially decaying estimates for ")#tao-math("{\\left|x\\right|>2}", block: false)#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(", ")#mi("{g:{\\bf C} \\rightarrow {\\bf C}}")#text(" be functions which are analytic near a complex number ")#mi("{z_0}")#text(", with ")#mi("{f^{\\prime}(z_0) = 0}")#text(" and ")#mi("{f^{\\prime\\prime}(z_0) \\neq 0}")#text(". Let ")#mi("{\\varepsilon > 0}")#text(" be a small number, and let ")#mi("{\\gamma}")#text(" be the line segment ")#mi("{\\{ z_0 + t v: -\\varepsilon < t < \\varepsilon \\}}")#text(", where ")#mi("{v}")#text(" is a complex phase such that ")#mi("{f^{\\prime\\prime}(z_0) v^2}")#text(" is a negative real. Show that for ")#mi("{\\varepsilon}")#text(" sufficiently small, one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma e^{\\lambda f(z)} g(z)\\ dz = (1+o(1)) \\frac{\\sqrt{2\\pi} v}{\\sqrt{f^{\\prime\\prime}(z_0) \\lambda}} e^{\\lambda f(z_0)} g(z_0)")]]

#text("as ")#mi("{\\lambda \\rightarrow +\\infty}")#text(". This is the basic estimate behind the method of steepest descent; readers who are also familiar with the ")#link("http://en.wikipedia.org/wiki/Stationary_phase_approximation")[#text("method of stationary phase")]#text(" may see a close parallel.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" The method of steepest descent requires an explicit representation of the orthogonal polynomials as contour integrals, and as such is largely restricted to the classical orthogonal polynomials (such as the Hermite polynomials). However, there is a non-linear generalisation of the method of steepest descent developed by Deift and Zhou, in which one solves a matrix Riemann-Hilbert problem rather than a contour integral; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1677884")[#text("this book by Deift")]#text(" for details. Using these sorts of tools, one can generalise much of the above theory to the spectral distribution of ")#mi("{U(n)}")#text("-conjugation-invariant discussed in Remark ")#link(<tao-a096b50a34622f75864d>)[#text("2")]#text(", with the theory of Hermite polynomials being replaced by the more general theory of orthogonal polynomials; this is discussed in the above book of Deift, as well as the more recent ")#link("http://www.ams.org/mathscinet-getitem?mr=2514781")[#text("book of Deift and Gioev")]#text(".")
]

#text("The computations performed above for the diagonal kernel ")#mi("{K_n(x,x)}")#text(" can be summarised by the asymptotic")

#align(center)[#tao-fit-display[#mitex("K_n( \\sqrt{n} x, \\sqrt{n} x ) = \\sqrt{n} ( \\rho_{sc}(x) + o(1) )")]]

#text("whenever ")#mi("{x \\in {\\bf R}}")#text(" is fixed and ")#mi("{n \\rightarrow \\infty}")#text(", and ")#mi("{\\rho_{sc}(x) := \\frac{1}{2\\pi} (4-x^2)_+^{1/2}}")#text(" is the semi-circular law distribution. It is reasonably straightforward to generalise these asymptotics to the off-diagonal case as well, obtaining the more general result ")#metadata(none) <tao-0f2ac564966850ce907c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("K_n( \\sqrt{n} x + \\frac{y_1}{\\sqrt{n} \\rho_{sc}(x)}, \\sqrt{n} x + \\frac{y_2}{\\sqrt{n} \\rho_{sc}(x)} ) = \\sqrt{n} ( \\rho_{sc}(x) K(y_1,y_2) + o(1) )")]]

#text("for fixed ")#mi("{x \\in (-2,2)}")#text(" and ")#mi("{y_1,y_2 \\in {\\bf R}}")#text(", where ")#mi("{K}")#text(" is the ")#emph[#text("Dyson sine kernel")]

#align(center)[#tao-fit-display[#mitex("K(y_1,y_2) := \\frac{\\sin(\\pi(y_1-y_2)}{\\pi(y_1-y_2)}.")]]

#text("In the language of semi-classical analysis, what is going on here is that the rescaling in the left-hand side of ")#link(<tao-0f2ac564966850ce907c>)[#text("(42)")]#text(" is transforming the phase space region ")#mi("{\\{ (x,p): p^2 + \\frac{x^2}{4} \\leq 1 \\}}")#text(" to the region ")#tao-math("{\\{ (x,p): \\left|p\\right| \\leq 1 \\}}", block: false)#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(", and the projection to the latter region is given by the Dyson sine kernel. A formal proof of ")#link(<tao-0f2ac564966850ce907c>)[#text("(42)")]#text(" can be given by using either the ODE method or the steepest descent method to obtain asymptotics for Hermite polynomials, and thence (via the Christoffel-Darboux formula) to asymptotics for ")#mi("{K_n}")#text("; we do not give the details here, but see for instance the recent book of Anderson, Guionnet, and Zeitouni.")#linebreak()#text(" From ")#link(<tao-0f2ac564966850ce907c>)[#text("(42)")]#text(" and ")#link(<tao-7b83dce0377470e43481>)[#text("(21)")]#text(", ")#link(<tao-db083e890b94bca2d0d1>)[#text("(22)")]#text(" we obtain the asymptotic formula")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} \\sum_{1 \\leq i_1 < \\ldots < i_k \\leq n} F( \\sqrt{n} \\rho_{sc}(x) (\\lambda_{i_1}(M_n) - \\sqrt{n} x),\\ldots,")]]

#align(center)[#tao-fit-display[#mitex("\\sqrt{n} \\rho_{sc}(x) (\\lambda_{i_k}(M_n) - \\sqrt{n} x) )")]]

#align(center)[#tao-fit-display[#mitex("\\rightarrow \\int_{{\\bf R}^k} F(y_1,\\ldots,y_k) \\det(K(y_i,y_j))_{1 \\leq i,j \\leq k}\\ dy_1 \\ldots dy_k")]]

#text("for the local statistics of eigenvalues. By means of further algebraic manipulations (using the general theory of determinantal processes), this allows one to control such quantities as the distribution of eigenvalue gaps near ")#mi("{\\sqrt{n} x}")#text(", normalised at the scale ")#mi("{\\frac{1}{\\sqrt{n} \\rho_{sc}(x)}}")#text(", which is the average size of these gaps as predicted by the semicircular law. For instance, for any ")#mi("{s_0>0}")#text(", one can show (basically by the above formulae combined with the inclusion-exclusion principle) that the proportion of eigenvalues ")#mi("{\\lambda_i}")#text(" with normalised gap ")#mi("{\\sqrt{n} \\frac{\\lambda_{i+1}-\\lambda_i}{\\rho_{sc}(t_{i/n})}}")#text(" less than ")#mi("{s_0}")#text(" converges as ")#mi("{n \\rightarrow \\infty}")#text(" to ")#mi("{\\int_0^{s_0} \\frac{d^2}{ds^2} \\det(1-K)_{L^2[0,s]}\\ ds}")#text(", where ")#mi("{t_c \\in [-2,2]}")#text(" is defined by the formula ")#mi("{\\int_{-2}^{t_c} \\rho_{sc}(x)\\ dx = c}")#text(", and ")#mi("{K}")#text(" is the integral operator with kernel ")#mi("{K(x,y)}")#text(" (this operator can be verified to be ")#link("http://en.wikipedia.org/wiki/Trace-class_operator")[#text("trace class")]#text(", so the determinant can be defined in a ")#link("http://en.wikipedia.org/wiki/Fredholm_determinant")[#text("Fredholm sense")]#text("). See for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=2129906")[#text("book of Mehta")]#text(" (and my ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("blog post on determinantal processes")]#text(" describe a finitary version of the inclusion-exclusion argument used to obtain such a result).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" One can also analyse the distribution of the eigenvalues at the edge of the spectrum, i.e. close to ")#mi("{\\pm 2 \\sqrt{n}}")#text(". This ultimately hinges on understanding the behaviour of the projection ")#mi("{\\pi_{V_n}}")#text(" near the corners ")#mi("{(0, \\pm 2)}")#text(" of the phase space region ")#mi("{\\Omega = \\{ (p,x): p^2 + \\frac{x^2}{4} \\leq 1 \\}}")#text(", or of the Hermite polynomials ")#mi("{P_n(x)}")#text(" for ")#mi("{x}")#text(" close to ")#mi("{\\pm 2 \\sqrt{n}}")#text(". For instance, by using steepest descent methods, one can show that")

#align(center)[#tao-fit-display[#mitex("n^{1/12} \\phi_n(2\\sqrt{n} + n^{1/6} x) \\rightarrow Ai(x)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{x,y}")#text(", where ")#mi("{Ai}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Airy_function")[#text("Airy function")]

#align(center)[#tao-fit-display[#mitex("Ai(x) := \\frac{1}{\\pi} \\int_0^\\infty \\cos( \\frac{t^3}{3} + tx )\\ dt.")]]

#text("This asymptotic and the Christoffel-Darboux formula then gives the asymptotic ")#metadata(none) <tao-0a3d5ddd2bc47324ba0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("n^{1/6} K_n(2\\sqrt{n} + n^{1/6} x, 2\\sqrt{n} + n^{1/6} y) \\rightarrow K_{Ai}(x,y)")]]

#text("for any fixed ")#mi("{x,y}")#text(", where ")#mi("{K_{Ai}}")#text(" is the ")#emph[#text("Airy kernel")]

#align(center)[#tao-fit-display[#mitex("K_{Ai}(x,y) := \\frac{Ai(x) Ai^{\\prime}(y) - Ai^{\\prime}(x) Ai(y)}{x-y}.")]]

#text("(")#emph[#text("Aside")]#text(": Semiclassical heuristics suggest that the rescaled kernel ")#link(<tao-0a3d5ddd2bc47324ba0a>)[#text("(43)")]#text(" should correspond to projection to the parabolic region of phase space ")#mi("{\\{ (p,x): p^2 + x \\leq 1\\}}")#text(", but I do not know of a connection between this region and the Airy kernel; I am not sure whether semiclassical heuristics are in fact valid at this scaling regime. On the other hand, these heuristics do explain the emergence of the length scale ")#mi("{n^{1/6}}")#text(" that emerges in ")#link(<tao-0a3d5ddd2bc47324ba0a>)[#text("(43)")]#text(", as this is the smallest scale at the edge which occupies a region in ")#mi("{\\Omega}")#text(" consistent with the Heisenberg uncertainty principle.) This then gives an asymptotic description of the largest eigenvalues of a GUE matrix, which cluster in the region ")#mi("{2\\sqrt{n} + O(n^{1/6})}")#text(". For instance, one can use the above asymptotics to show that the largest eigenvalue ")#mi("{\\lambda_1}")#text(" of a GUE matrix obeys the ")#link("http://en.wikipedia.org/wiki/Tracy%E2%80%93Widom_distribution")[#text("Tracy-Widom law")]

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( \\frac{\\lambda_1 - 2\\sqrt{n}}{n^{1/6}} < t ) \\rightarrow \\det(1 - A)_{L^2[0,t]}")]]

#text("for any fixed ")#mi("{t}")#text(", where ")#mi("{A}")#text(" is the integral operator with kernel ")#mi("{K_{Ai}}")#text(". See for instance the recent book of Anderson, Guionnet, and Zeitouni.")
]

#heading(level: 1)[#strong[#text(" — 5. Determinantal form of the gaussian matrix distribution — ")]]

#text("One can perform an analogous analysis of the joint distribution function ")#link(<tao-b3d1bf2afb9e57cb0a62>)[#text("(10)")]#text(" of gaussian random matrices. Indeed, given any family ")#mi("{P_0,\\ldots,P_{n-1}(z)}")#text(" of polynomials, with each ")#mi("{P_i}")#text(" of degree ")#mi("{i}")#text(", much the same arguments as before show that ")#link(<tao-b3d1bf2afb9e57cb0a62>)[#text("(10)")]#text(" is equal to a constant multiple of")

#align(center)[#tao-fit-display[#tao-math("\\det( \\sum_{k=0}^{n-1} P_k(\\lambda_i) e^{-\\left|\\lambda_i\\right|^2/2} \\overline{P_k(\\lambda_j)} e^{-\\left|\\lambda_j\\right|^2/2} )_{1 \\leq i,j \\leq n}.", block: true)]]

#text("One can then select ")#tao-math("{P_k(z) e^{-\\left|z\\right|^2/2}}", block: false)#text(" to be orthonormal in ")#mi("{L^2({\\bf C})}")#text(". Actually in this case, the polynomials are very simple, being given explicitly by the formula")

#align(center)[#tao-fit-display[#mitex("P_k(z) := \\frac{1}{\\sqrt{\\pi k!}} z^k.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Verify that the ")#tao-math("{P_k(z) e^{-\\left|z\\right|^2/2}}", block: false)#text(" are indeed orthonormal, and then conclude that ")#link(<tao-b3d1bf2afb9e57cb0a62>)[#text("(10)")]#text(" is equal to ")#mi("{\\det( K_n(\\lambda_i,\\lambda_j) )_{1 \\leq i,j \\leq n}}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("K_n(z,w) := \\frac{1}{\\pi} e^{-(\\left|z\\right|^2+\\left|w\\right|^2)/2} \\sum_{k=0}^{n-1} \\frac{(z\\overline{w})^k}{k!}.", block: true)]]

#text("Conclude further that the ")#mi("{m}")#text("-point correlation functions ")#mi("{\\rho_m(z_1,\\ldots,z_m)}")#text(" are given as")

#align(center)[#tao-fit-display[#mitex("\\rho_m(z_1,\\ldots,z_m) = \\det( K_n(z_i,z_j) )_{1 \\leq i,j \\leq m}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Show that as ")#mi("{n \\rightarrow \\infty}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("K_n( \\sqrt{n} z, \\sqrt{n} z ) = \\frac{1}{\\pi} 1_{\\left|z\\right| \\leq 1} + o(1)", block: true)]]

#text("and deduce that the expected spectral measure ")#mi("{{\\bf E} \\mu_{G/\\sqrt{n}}}")#text(" converges vaguely to the circular measure ")#tao-math("{\\mu_c := \\frac{1}{\\pi} 1_{\\left|z\\right| \\leq 1}\\ dz}", block: false)#text("; this is a special case of the ")#emph[#text("circular law")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" For any ")#tao-math("{\\left|z\\right| < 1}", block: false)#text(" and ")#mi("{w_1, w_2 \\in {\\bf C}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("K_n( \\sqrt{n} (z+w_1), \\sqrt{n} (z+w_2) ) = \\frac{1}{\\pi} \\exp( - \\left|w_1-w_2\\right|^2 / 2 ) + o(1)", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". This formula (in principle, at least) describes the asymptotic local ")#mi("{m}")#text("-point correlation functions of the spectrum of gaussian matrices.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" One can use the above formulae as the starting point for many other computations on the spectrum of random gaussian matrices; to give just one example, one can show that expected number of eigenvalues which are real is of the order of ")#mi("{\\sqrt{n}}")#text(" (see ")#link("http://www.ams.org/mathscinet-getitem?mr=1437734")[#text("this paper of Edelman")]#text(" for more precise results of this nature). It remains a challenge to extend these results to more general ensembles than the gaussian ensemble.")
]

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-43727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2010")])]

#text("There’s a minor typo (“frac” should be “\\frac”) in the statement of Exercise 9.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-43741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2010")])]

#text("Dear Prof. Tao,")

#text("Thank you for the great post.")

#text("Which course are you going to teach next semester? If you give a hint, we can start to read related materials. your lecture notes are terrific but requires strong background.")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: The least singular value « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-43790")[#strong[#text("254A, Notes 7: The least singular value « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2010")])]

#text("[…] of a gaussian random matrix can be computed explicitly by techniques similar to those employed in Notes 6. In particular, if is a real gaussian matrix (with all entries iid with distribution ), it was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-46435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("In deriving the pdf for GUE, “We can thus use the inverse function theorem in this local region of parameter space and make the ansatz ….”")

#text("How is this true? Is there any reference to detailing this step?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-46441")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2010")])]

#text("As stated immediately after that quote, one computes the Jacobian of ")#mi("(R,S) \\mapsto \\exp(\\varepsilon S) R")#text(" at ")#mi("S=0")#text(" (and ")#mi("R")#text(" equal to a diagonal unitary) and verifies that it is non-zero. This already gives the desired parameterisation in the ")#mi("O(\\varepsilon)")#text(" neighbourhood of any diagonal unitary ")#mi("R")#text(", from the inverse function theorem (it may be convenient here to scale out the ")#mi("\\varepsilon")#text(" and look at the map ")#mi("(R,S) \\mapsto \\exp(S) R")#text(" instead). Since we already know ")#mi("U")#text(" lies within ")#mi("O(\\varepsilon)")#text(" of a diagonal unitary, the claim follows.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Dyson and Airy kernels of GUE via semiclassical analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-47807")[#strong[#text("The Dyson and Airy kernels of GUE via semiclassical analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("[…] standard computation (given for instance in these lecture notes of mine) gives the Ginebre […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-48608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I don’t quite understand the argument after equation (20). You said you want to absorb K_n(x_l,x_{k+1}) into the l-th column. But isn’t the l-th column omitted in the matrix that follows? Maybe you meant the k+1th column? But I couldn’t figure out how to make it work.")

#emph[#text("[Corrected, thanks. The strategy is to get to the point where one can use the identity ")#mi("\\int_{{\\bf R}} K_n(x_l,x_{k+1}) K_n(x_i,x_{k+1})\\ dx_{k+1} = K_n(x_l,x_i)")#text(".]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-48625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2010")])]

#text("Ah I see. You are integrating ")#mi("x_{k+1}")#text(" partially first. Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-99880")[#strong[#text("Smolin (2011) | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2011")]

#text("[…] is a real valued random matrix from the GOE ensemble whose eigenvalues for subscribe to Dyson Brownian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c48d0057e9c21e2c5de8bd525ac237b506aa9b1d6c1c5d1c74bf15eae788395-e64cbd11c91f029f82d355fb07ffa1b1c17504e7766b383bb74e2d33d8bd9940.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vishwajeet singh")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-147156")[#strong[#text("vishwajeet singh")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2012")])]

#text("Dear Dr Tao,")#linebreak()#text(" I have just started my venture into Random matrix. What puzzles me is that all the Gaussian ensembles assume zero mean entries. How does the entire formulation change when the entries do not have zero mean? i.e the entries are Normal(\\mu,\\sigma). How does the distribution of the eigenvalues change ??")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-191985")[#strong[#text("A direct proof of the stationarity of the Dyson sine process under Dyson Brownian motion « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2012")])]

#text("[…] where are the (normalised) Hermite polynomials; see this previous blog post for details. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7de62d5e29acf686dbda6ed7edb7e0fc3ab92d201a6112d40ec4026682d01192-ed814e40e0d10bf53cc4088f7da4fa4141746c73fc4c683ef7b1693411932b56.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ilya Razenshteyn")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-219714")[#strong[#text("Ilya Razenshteyn")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2013")])]

#text("My feeling that is (43) the normalization is wrong. There should be ")#mi("n^{-1/6} \\cdot K_n(\\ldots) \\to \\ldots")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e6ffa68d7217ab09e3895e918b12acff13750bdbbb8392acb1d0646e54f0eff9-c78a2fca147388d823dd2cbf86aa976f3d22c7e5d17c1280aa382ccf52635575.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-261633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("In Section 2, doesn’t conjugation by a permutation matrix make T lose its upper diagonal structure?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-261700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2014")])]

#text("Gah, you’re right. Fortunately, the permutation symmetry for T is not actually needed in the argument, provided that one augments the given data (i.e. the matrix G to be factorised) by also attaching a (randomly chosen) enumeration ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(" of the eigenvalues of G, and demanding that T has the diagonal entries ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(" in that order. While T indeed does not have permutation symmetry, the ")#emph[#text("data")]#text(" (the pair consisting of ")#mi("G")#text(" and the enumeration ")#mi("\\lambda_1,\\ldots,\\lambda_n")#text(") retains the permutation symmetry, which is what is actually used in the argument. I’ve rewritten the text to reflect this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chansoo Lee")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-452654")[#strong[#text("Chansoo Lee")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("Dear Professor Tao,")#linebreak()#text(" Does the fact that you used a heuristic mean field approximation imply that in general, you can’t find the actual eigenvalues that maximize the pdf for n > 4?")#linebreak()#text(" Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-452658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2015")])]

#text("The points that maximise the pdf are known as Fekete points; asymptotics for these points are known (by using a more rigorous version of the mean field approximation), but I doubt that there is any closed form for them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-470161")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("I know it’s a cheap trick, but you should definitely use raising and lowering operators since you are dealing with Hermite polynomials. And there’s probably an ")#mi("SL(2, \\mathbb{R})")#text(" representation or ")#mi("SU(2)")#text(" in there but don’t take my word for it. I appreciate you doing WKB approximation in a rigorous way but I had trouble recognizing it compared to what the physicists actually write. So Ratner theorem, WKB approximation and everything else is the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-476147")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2017")])]

#text("Hi Terry, A minor typo perhaps.")#linebreak()#text(" On the 5th line, in the paragraph above Eq. 2 starting with ” Let D be…”, M should probably be M_n.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/803266c7ab6472ec9611dec2a090501ff6a79f58d5fafdfa3adcb82545657a27-c970c3296e1dc3dc780be6c4b796c7dbe0400c04eb3c2551fa89687a5f60e113.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramis Movassagh")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-476348")[#strong[#text("Ramis Movassagh")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2017")])]

#text("Hi Terry,")#linebreak()#text(" I very much like this post as always.")

#text("Minor typos perhaps:")#linebreak()#text(" The first paragraph below Eq. 11 the I think instead of 1/|\\lambda_i – \\lambda_j|, it should say \\log 1/|\\lambda_i – \\lambda_j|.")

#text("Also three lines below “\\lambda_i should be have…” to “\\lambda_i should have…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-514670")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("Dear professor Tao")

#text("Right after making the ansatz {U=\\exp(\\epsilon S)R} you say")

#text("As {U} is distributed using Haar measure on {U(n)}, {S} is (locally) distributed using {\\epsilon^{n^2-n}} times a constant multiple of Lebesgue measure on the space {W} of skew-adjoint matrices with zero diagonal, which has dimension {n^2-n}.")

#text("Is there any refference to this step in details? Do i need to use the Baker–Campbell–Hausdorff formula?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-514675")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("Oops, there was a factor of ")#mi("(1+o(1))")#text(" missing in front of ")#mi("\\epsilon^{n^2-n}")#text(". One can indeed proceed using BCH: the fact that Haar measure is invariant under rotations of the form ")#mi("\\exp(\\varepsilon H)")#text(" for some skew-adjoint ")#mi("H")#text(" with zero diagonal means that the distribution of S is invariant under a transformation which looks like translation by ")#mi("H")#text(" plus errors of size ")#mi("o(1)")#text(" (and whose derivatives also have size o(1)), so after taking Jacobians we see that the density of this distribution is constant up to factors of ")#mi("1+o(1)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The alternative hypothesis for unitary matrices | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-515975")[#strong[#text("The alternative hypothesis for unitary matrices | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2019")])]

#text("[…] the the Vandermonde determinant; see for instance this previous blog post for the derivation of a very similar formula for the GUE distribution, which can be adapted to CUE […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a8c0d5eb2350f01abae1f66d91357ff482183aa1e2d8b786515df4ccb515fc-8a1f824969c9882fdf50f442379dff8ac43e376b2eeb7108e371c48375f6488f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tpfly")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-614867")[#strong[#text("tpfly")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2021")])]

#text("Dear Professor Tao,")

#text("In Exercise 4 should there be a factor of 2 before the logarithmic potential? Otherwise taking the Laplacian we would get $\\rho(z)=2/\\pi$ on its support.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a8c0d5eb2350f01abae1f66d91357ff482183aa1e2d8b786515df4ccb515fc-8a1f824969c9882fdf50f442379dff8ac43e376b2eeb7108e371c48375f6488f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tpfly")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-618617")[#strong[#text("tpfly")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2021")])]

#text("Dear Professor Tao,")

#text("The HTML code has been broken since last modification, and some latex formula do not parse.")

#text("I think there are still some more mistakes in this post and in the corresponding chapter of “topics in RMT”:")

#text("1): Using (34), I found (35) should be")#linebreak()#text(" ")#mi("\\displaystyle P_n^{\\prime}(0)=\\sqrt{n}P_{n-1}(0)=\\frac{(-1)^{(n-1)/2}\\sqrt{n!}}{(2\\pi)^{1/4}2^{(n-1)/2}((n-1)/2)!}")#linebreak()#text(" when n is odd. Comparing with (35), the sign is different (the power of -1 should be (n-1)/2).")

#text("2) The rescaled functions ")#mi("\\tilde{\\phi}_m")#text(" should be defined as ")#mi("\\tilde{\\phi}_m(x)=n^{1/4}\\phi_m(\\sqrt{n}x)")#text(" which are orthonormal. The scale ")#mi("\\sqrt{n}")#text(" outside of the functions do not make them orthonormal.")#linebreak()#text(" Then the following 3), 4), 5) are related to this.")#linebreak()#text(" 3) In the book, the harmonic oscillator operator on ")#mi("\\tilde\\phi_m")#text(" should be ")#mi("L_{1/n}")#text(" instead of ")#mi("L_{1/\\sqrt{n}}")#text(".")#linebreak()#text(" 4) In eq.(36), the coefficient of ")#mi("\\tilde{\\phi}^{\\prime}_m(x)^2")#text(" should be ")#mi("1/n^2")#text(".")#linebreak()#text(" 5) In the integral formula of ")#mi("\\tilde{\\phi}_n(x)")#text(" (in the sketch of steepest descent), the factor ")#mi("n^{1/4}")#text(" is missing.")

#text("6) In Exercise 12, the density of ")#mi("\\mathbf{E}\\mu_{M_n/\\sqrt{n}}")#text(" should be")

#tao-math("\\displaystyle 4a(x)b(x)(\\sqrt{1-x^2/4}+o(1))+O((\\left|a(x)\\right|^2+\\left|b(x)\\right|^2)/n).", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-687036")[#strong[#text("Jiaoyang Huang, Theo Mckenzie, Horng-Tzer Yau: Ramanujan Property and Edge Universality of Random Regular Graphs | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2025")]

#text("[…] This formula gives a lot of information on the distribution of individual eigenvalues. See also this post of Terry Tao on the Gaussian ensembles in random matrix […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-687943")[#strong[#text("Math 289A: Lecture 14 – Jonathan Novak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")]

#text("[…] 14.1. The Gaussian Unitary Ensemble is the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-689620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2026")])]

#text("Dr Tao, “matirx” should be matrix.")

#emph[#text("[Corrected, thanks – T.]")]

#text("I wonder is “ensemble” a formal term or an informal term? Is it the same meaning of “set”?")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Ensemble_(mathematical_physics)")[#text("https://en.wikipedia.org/wiki/Ensemble_(mathematical_physics)")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a79d063b973e4174948252e41f2e850039578563e8bfe6a37f301c0bf51de93-6e073f5fcff3e618257ff66706c0b4f15881ef544a88043e4ce5b23ca2dad73f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Clark")]], [#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/#comment-692464")[#strong[#text("William Clark")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2026")])]

#text("“And in any case, from the unitary invariance of GUE, we see that even after conditioning on D we may assume WLOG that U is drawn from the invariant Haar measure on U(n). In particular, U and D can be taken to be independent.”")

#text("I’m confused by this. In other books, the joint law of eigenvalue and distribution of eigenvector statements make it sound like one can deduce independence of U and D from the assumption that X is a GOE or GUE. But here it seems like its an additional choice, to take U and D independent.")

#emph[#text("[Corrected “can be taken to be” to “are” -T.]")]
]
