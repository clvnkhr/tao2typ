// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/
// Converted to Typst by tao2typ: "2026-10-14T16:37:21.891813+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, VIII: Time to start writing up the results?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, VIII: Time to start writing up the results?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 February 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/")[#text("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the eighth thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2014/01/28/polymath8b-vii-using-the-generalised-elliott-halberstam-hypothesis-to-enlarge-the-sieve-support-yet-further")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the wiki page")]#text(".")

#text("The big news since the last thread is that we have managed to obtain the (sieve-theoretically) optimal bound of ")#mi("{H_1 \\leq 6}")#text(" assuming the generalised Elliott-Halberstam conjecture (GEH), which pretty much closes off that part of the story. Unconditionally, our bound on ")#mi("{H_1}")#text(" is still ")#mi("{H_1 \\leq 270}")#text(". This bound was obtained using the “vanilla” Maynard sieve, in which the cutoff ")#mi("{F}")#text(" was supported in the original simplex ")#mi("{\\{ t_1+\\dots+t_k \\leq 1\\}}")#text(", and only Bombieri-Vinogradov was used. In principle, we can enlarge the sieve support a little bit further now; for instance, we can enlarge to ")#mi("{\\{ t_1+\\dots+t_k \\leq \\frac{k}{k-1} \\}}")#text(", but then have to shrink the J integrals to ")#mi("{\\{t_1+\\dots+t_{k-1} \\leq 1-\\epsilon\\}}")#text(", provided that the marginals vanish for ")#mi("{\\{ t_1+\\dots+t_{k-1} \\geq 1+\\epsilon \\}}")#text(". However, we do not yet know how to numerically work with these expanded problems.")

#text("Given the substantial progress made so far, it looks like we are close to the point where we should declare victory and write up the results (though we should take one last look to see if there is any room to improve the ")#mi("{H_1 \\leq 270}")#text(" bounds). There is actually a fair bit to write up:")

#list(
[#text("Improvements to the Maynard sieve (pushing beyond the simplex, the epsilon trick, and pushing beyond the cube);")],
[#text("Asymptotic bounds for ")#mi("{M_k}")#text(" and hence ")#mi("{H_m}")#text(";")],
[#text("Explicit bounds for ")#mi("{H_m, m \\geq 2}")#text(" (using the Polymath8a results)")],
[#mi("{H_1 \\leq 270}")#text(";")],
[#mi("{H_1 \\leq 6}")#text(" on GEH (and parity obstructions to any further improvement).")]
)

#text("I will try to create a skeleton outline of such a paper in the Polymath8 Dropbox folder soon. It shouldn’t be nearly as big as the Polymath8a paper, but it will still be quite sizeable.")

#heading(level: 1)[#text("Comments (135)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tou")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270668")[#strong[#text("tou")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("nice result!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52d0b2f78510e969df4b75bf4fa86694ea9c73824226016f5d94b8de91591e94-9cc1fae31f5ad6457322d456c19ef6ef4af9878773febb51518c1697d8bba823.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of GilYoung Cheong")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270688")[#strong[#text("GilYoung Cheong")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("I like this result because it shows me how important it is to understand other mathematicians’ ideas (and collaborate).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("A correction: when trying to use our various tricks to improve the ")#mi("H_1")#text(" bound on Bombieri-Vinogradov, the support of F can range in the quite large simplex ")#mi("\\{ t_1+\\dots+t_k \\leq \\frac{2k}{k-1}\\}")#text(", not just ")#mi("\\{t_1+\\dots+t_k \\leq \\frac{k}{k-1} \\}")#text(". So the epsilon in the “epsilon trick” can go all the way to 1 without difficulty, which could lead to a sizeable improvement by passing from ")#mi("M_k")#text(" to ")#mi("M_{k,\\varepsilon}")#text(" (without even touching the region outside the simplex ")#mi("\\{ t_1+\\dots+t_k \\leq 1+\\varepsilon\\}")#text(". This might be computable using some variant of the numerics used for the ")#mi("M_k")#text(" problem, since we are still only integrating on simplices and not imposing any moment conditions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270702")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Let’s hope so! Pace mentioned in ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262427")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-262427")]#text(" that there are issues with multiplying and integrating polynomials of the form ")#mi("(f(2-e_1)^k e_k)_{1,\\ldots, k}")#text(" – I don’t know whether that’s the main issue here. If it is, maybe it will be mitigated by optimising F first and then epsilon rather than the other way around (see ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")]#text(" ) and/or by restricting F to monomials with fewer than k variables. On the latter issue, I tried (I think correctly) modifying Pace’s code for k=3 to explore F’s whose monomials were restricted to just one variable (so in the d=2 case eliminating the xy, xz and yz terms) and the loss in M was very small (it still topped 1.99), so I suspect there is value there, even if there is no Lagrange-based argument that the optimal F will still be found.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270907")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("But (if I understand correctly) this means that for ")#mi("\\theta = 1/2")#text(" we may take ")#mi("R = \\frac {2k}{k-1} \\mathcal R_k")#text(" which seems “too good to be true” (since then ")#mi("M_k(R) =\\frac {2k}{k-1} M_k")#text(" which for ")#mi("k=2")#text(" gives ")#mi("M_2(R) = 4 M_2 > 4")#text(" – implying unconditionally the twin prime conjecture!) Therefore, some clarification is needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Well, one still has the vanishing moment conditions to deal with; F can range in ")#mi("\\frac{2k}{k-1} {\\cal R}_k")#text(", but its marginals must stay supported in ")#mi("(1+\\varepsilon) {\\cal R}_{k-1}")#text(" if we wish to use the ")#mi("J_{\\varepsilon}")#text(" functional (i.e. integration on ")#mi("(1-\\varepsilon) {\\cal R}_{k-1}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270915")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Do you mean that the new relaxation is only for the support of ")#mi("F")#text(" but not for the supports of the marginals?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Yes… although on rechecking what I said, I realise now that I screwed up a little, and need to correct my correction: using only Bombieri-Vinogradov, one can enlarge the support of F to be as large as ")#mi("2 {\\cal R}_k")#text(" (basically using the trivial distribution properties of the constant function 1), but not ")#mi("2 \\frac{k}{k-1} {\\cal R}_k")#text(" (this requires GEH, which we no longer have). Sorry about that. (One more reason to start writing up the results is so that these things can be clarified properly…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270928")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Terry, could you please elaborate on this? – I thought that the equivalent of GEH was indeed known for theta=1/2, courtesy of Motohashi?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("I meant that to get up to ")#mi("2\\frac{k}{k-1} {\\cal R}_k")#text(" at the ")#mi("\\theta=1/2")#text(" level requires GEH for ")#mi("\\theta=1")#text(", which is still a conjecture. From GEH for ")#mi("\\theta=1/2")#text(", which was indeed proven by Motohashi, one can get the support up to ")#mi("\\frac{k}{k-1} {\\cal R}_k")#text(", but this is superseded by the support of ")#mi("\\frac{1}{\\theta} {\\cal R}_k = 2 {\\cal R}_k")#text(" that one can get just from the trivial distributional properties of the constant function 1.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Just to repeat something from the previous thread: it looks like two of the eight vanishing marginal conditions ")#mi("M_1=\\dots=M_8=0")#text(" are actually unnecessary in the ")#mi("\\varepsilon=1/4")#text(" case, which could lead to either an improvement of the bound, or the ability to clean up the optimiser, e.g. by lowering the degree or by approximating the nasty fractions by cleaner fractions. Specifically, we need to test the marginals in the trapezoidal region ")#mi("\\{ x \\geq y \\geq 0; 5/4 \\leq x+y \\leq 3/2\\}")#text(".")

#text("The M7=0 condition takes care of the triangle where ")#mi("x \\leq 3/4")#text(".")

#text("The M5=0 conditiont akes care of the large trapezoidal region where ")#mi("x \\geq 3/4")#text(" and ")#mi("y \\geq 1/4")#text(".")

#text("What’s left is the parallelogram ")#mi("\\{ 0 \\leq y \\leq 1/4; 5/4 \\leq x+y \\leq 3/2\\}")#text(". One can divide this parallelogram into four triangles, depending on whether ")#mi("x")#text(" is larger than 5/4 or not, and whether ")#mi("x+2y")#text(" is larger than 3/2 or not.")

#text("The conditions M1=0, M2=0, M3=0, M4=0 then handle the triangles ")#mi("\\{ x+2y \\geq 3/2, x \\geq 5/4\\}")#text(", ")#mi("\\{ x+2y \\leq 3/2, x \\geq 5/4\\}")#text(". ")#mi("\\{ x+2y \\leq 3/2, x \\leq 5/4\\}")#text(". ")#mi("\\{ x+2y \\geq 3/2, x \\leq 5/4\\}")#text(" respectively.")

#text("The conditions ")#mi("M6=0, M8=0")#text(" do not appear to be needed in the ")#mi("\\varepsilon=1/4")#text(" case, although they do show up for larger values of epsilon.")

#text("Another minor simplification: the first integral in the expression for I6 is trivial in the ")#mi("\\varepsilon=1/4")#text(" case, although this only leads to a slightly simpler exposition rather than any numerical gain.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270698")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("If Pace can make what is presumably an easy change to his code (I tried to work out for myself what change is needed, but I’m still too new to Mathematica), I’d be happy to play with it and seek such improvements. (Pace told me that he is busy with other projects at present and lacks the time to do much more on this.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270703")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Indeed I am! (But it was a simple change, as you said. Just had to change the type of rational approximation and drop the two marginal conditions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270705")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Many thanks Pace. If you email me the new notebook I’ll probably tinker with it to see if smaller degrees can now be used.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270701")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Dropping the M6 and M8 conditions, and approximating the entries of the resulting optimized vector to within a thousandth, the following somewhat simpler fractions should still suffice:")

#text("FA= 1 – (1291 x)/1000 + (104 x^2)/125 – (659 y)/500 + (111 x y)/125 + (")#linebreak()#text(" 1099 y^2)/1000 – (1257 z)/1000 + (637 x z)/1000 + (56 y z)/125 + (")#linebreak()#text(" 839 z^2)/1000")

#text("FB= 57/100 – (303 x)/500 + (117 x^2)/250 – (136 y)/125 + (227 x y)/500 + (")#linebreak()#text(" 133 y^2)/125 – (303 z)/1000 – (9 x z)/125 + (57 y z)/250 + (")#linebreak()#text(" 37 z^2)/250")

#text("FC= 17/50 – (657 x)/1000 + (227 x^2)/500 – (13 y)/20 + (581 x y)/1000 + (")#linebreak()#text(" 21 y^2)/40 – (9 z)/1000 + (3 x z)/1000 + (3 y z)/200 + z^2/250")

#text("FD= 0")

#text("FE= 4711/16000 – (199 x)/2000 – (29 x^2)/1000 – (2101 y)/2000 + (")#linebreak()#text(" 413 x y)/1500 + (33 y^2)/25 – (19 z)/125 – (13 x z)/1000 + (")#linebreak()#text(" 31 y z)/125 + (7 z^2)/600")

#text("FS= 2409/16000 – (9 x)/80 – (61 x^2)/1000 – (493 y)/1000 + (")#linebreak()#text(" 401 x y)/1500 + (73 y^2)/125 – (73 z)/500 + (59 x z)/1000 – (")#linebreak()#text(" 9 y z)/250 + (79 z^2)/1000")

#text("FT= -(471/8000) + (367 x)/4000 – (7 x^2)/200 – (1133 y)/2000 + (")#linebreak()#text(" 9 x y)/25 + (129 y^2)/200 + (373 z)/1000 – (103 x z)/400 – (")#linebreak()#text(" 3 y z)/200 – (89 z^2)/400")

#text("FU= -(2548925261/40960000) + (378889 x)/500 – (1486281 x^2)/500 + (")#linebreak()#text(" 2109761 x^3)/500 – (1806913 x^4)/1000 – (823 y)/1000 + (")#linebreak()#text(" 1028 x y)/125 – (1276175057 x^2 y)/20800000 + (5231 x^3 y)/40 – (")#linebreak()#text(" 604 y^2)/125 + (465755881 x y^2)/10400000 – (")#linebreak()#text(" 33092919 x^2 y^2)/400000 + (1941 y^3)/500 – (21127 x y^3)/1000 + (")#linebreak()#text(" 28 y^4)/125 + (705 z)/8 – (196213 x z)/200 + (")#linebreak()#text(" 130643581043 x^2 z)/41600000 – (1270877 x^3 z)/500 + (")#linebreak()#text(" 51 y^2 z)/16000 – (91952143 z^2)/3328000 + (")#linebreak()#text(" 619313327 x z^2)/2080000 – (18524 x^2 z^2)/25 + (3 y^2 z^2)/5000 – (")#linebreak()#text(" 2561 z^3)/1000 + (4869 x z^3)/500 – (9 z^4)/200")

#text("FG= -(2695785741/10240000) + (2173499391 x)/1280000 – (")#linebreak()#text(" 12242903151 x^2)/2560000 + (52219413 x^3)/10000 – (")#linebreak()#text(" 1806913 x^4)/1000 + (96070478631 y)/83200000 + (")#linebreak()#text(" 1007933539 x y)/20800000 + (179877147 x^2 y)/2600000 – (")#linebreak()#text(" 36827397 x^3 y)/25000 – (669613358991 y^2)/166400000 – (")#linebreak()#text(" 1310180447 x y^2)/2600000 + (10110876 x^2 y^2)/3125 + (")#linebreak()#text(" 19620542273 y^3)/3900000 – (17662711 x y^3)/12500 – (")#linebreak()#text(" 1806913 y^4)/1000 + (104838525951 z)/166400000 – (")#linebreak()#text(" 126851653541 x z)/41600000 + (15524384001 x^2 z)/2600000 – (")#linebreak()#text(" 20898059 x^3 z)/6250 – (1531159429 y z)/640000 + (")#linebreak()#text(" 14385788557 y^2 z)/2600000 – (20898059 y^3 z)/6250 – (")#linebreak()#text(" 91851736253 z^2)/166400000 + (4642413047 x z^2)/2600000 – (")#linebreak()#text(" 738812349 x^2 z^2)/400000 + (2655529 y z^2)/1625 – (")#linebreak()#text(" 756836049 y^2 z^2)/400000 + (1081347403 z^3)/5200000 – (")#linebreak()#text(" 33823447 x z^3)/100000 – (36827397 y z^3)/100000 – (")#linebreak()#text(" 2238403 z^4)/80000")

#text("FH= -(37/250) + (71 x)/500 – (109 x^2)/1000 + (6 z)/125 – (3 x z)/1000 – (")#linebreak()#text(" 9 z^2)/250")

#text("The complicated forms for the F_G and F_U pieces arise when guaranteeing the other marginal conditions still hold.")

#text("(By the way, I concur that that when epsilon=1/4, the M6 and M8 conditions are indeed irrelevant. Sorry for not putting more description into the files I created earlier about when the different vanishing marginal conditions arise.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270707")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Is it possible to simplify further these expressions by dropping the vanishing constraint on ")#mi("FD")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270767")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("There is no constraint forcing the D-component 0. It just happens that this is the optimal choice. (The D-region only contributes to the I-integral, and doesn’t appear in any of the J-integrals, so anything nonzero only hurts us.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270909")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("This checks out (I = 0.03057904694, J = 0.06116827145, all marginals other than M6 and M8 OK). [I had initially gotten ridiculous answers, but on inspecting which marginal conditions had failed, I realised I had input in the FU data incorrectly.] I’ll update the wiki with this simplified example.")

#text("Nice to see that we’ve flipped from playing “Zeno’s paradox” to playing “Jenga”: what is the minimally complex construction we can do to stay above 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270963")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Thanks for these values Terry – their ratio is 2.0003, as against the previous 2.00003 with that degree set – maybe there’s more simplification to be had here. I also notice the curiosity that FU and FH have some monomials missing (FU lacks yz, (y^3)z, y(z^2) and y(z^3) and FH lacks y, y^2, xy and yz) – is that to be expected from the elimination of those marginals?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270964")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("It is possible that the vanishing of the additional coefficients is due to the approximation (within 0.001) that Pace made (further simplification is possible by slightly increasing the 0.001 value – but of course not too much).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270969")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("I had considered that, but I’m dissuaded from it by the fact that the coefficients of those monomials of FH in Pace’s original post (where they were given in floating-point) were actually the largest of all the FH monomials.")

#text("However, a further look back at that post reveals that FU (and only FU) is missing six monomials – yz, (y^2)z, (y^3)z, y(z^2), (y^2)(z^2) and y(z^3). The two that are missing there but not in the more recent FU (namely (y^2)z and (y^2)(z^2)) have the smallest values of all F monomials, so your suggestion is more likely for FU. And even though some of the other polynomials are very similar in all coefficients in the two cases, others are very different, so there’s probably nothing in this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270970")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("From the denominators of the coefficients it seems that their approximations (within 0.001) are decimal fractions (probably with denominator 1000), therefore further simplification is possible by such approximations (within the same tolerance) – using fractions (not necessarily decimal) having minimal denominators.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270972")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("The numerical coefficients of the polynomials in the recent post are not necessarily close to the corresponding ones in the former post since the optimization in the recent post is different (without two marginal constraints M6 and M8).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270981")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Eytan: yes, I agree. Regarding further simplifications, I think it could also be interesting to see whether the elimination of M6 and M8 causes M to rise enough, when leaving the precision as before, to allow the various degrees to be lowered further – or, conversely, whether with modestly increased degrees (and maybe with the monomials featuring all three variables added back in) the denominators can be made really small. It will then, of course, be a matter of taste which such variant is viewed as the simplest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271033")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("Perhaps the last simplification should be to make (by multiplying with the common denominator) all the coefficients integers (hopefully not “too big”).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270694")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("“")#mi("M6 = 0, M8 = 0")#text("” –> “")#mi("M_6 = 0, M_8 = 0")#text("”")

#text("Just to make it more readable, should all of the math expressions be typeset using LaTeX?")

#emph[#text("[The notation is from these notes ")#link("http://www.math.byu.edu/~pace/BddGapsSize6.pdf")[#text("http://www.math.byu.edu/~pace/BddGapsSize6.pdf")]#text(", with the variable names being formatted for Mathematica rather than for LaTeX use. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270725")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("I’ve been away for the past week, but I’ve just gone through Pace’s decompositions for the ")#mi("H_1\\le 6")#text(" result.")

#text("I was a bit concerned about the possibility of making a careless error in all the decompositions or when typing it into the computer, so I wrote some code to automatically do the I and J integral decompositions. This naturally splits the integrals up into many more parts and so the code takes a lot longer to run, but I’m happy to confirm that I get exactly the same quadratic forms and the same bound of ")#mi("2.0009")#text(" when using the same polynomial decomposition and same marginal conditions as Pace used.")

#text("I noticed that for ")#mi("\\epsilon=1/4")#text(" the ")#mi("M6")#text(" and ")#mi("M8")#text(" conditions are not necessary, and I also noticed that one gets a small numerical improvement to about 2.012 if one doesn’t restrict to polynomials with monomials involving two of the variables.")

#text("I think that since the automatic decompositions give exactly the same result, this is fairly strong evidence that all of Pace’s decompositions are correct and the ")#mi("H_1\\le 6")#text(" result holds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270729")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("2.012 is quite a big improvement! I imagine the improvement will be less for the version that’s just been Maple-validated, though, since in that case (because most of the degrees are lower) the total number of monomials will only rise from 132 to 140.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("This is great news! So the ")#mi("H_1 \\leq 6")#text(" result is now confirmed twice, and we also have a significantly larger margin of safety in case there is still something we all missed. Well done to everyone involved :)")

#text("Amusingly, this means that both of the Polymath8b results on ")#mi("H_1")#text(" will improve upon the corresponding results in your paper by a factor of two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270735")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Ooops, I meant ")#mi("2.0012")#text(", not ")#mi("2.012")#text(" – not such a huge improvement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270784")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("James, did you try to do the computation without splitting the F-region into the S,T,U pieces? I have a suspicion that it may be possible to still get ")#mi("M\\geq 2")#text(" (especially without the two unnecessary marginal constraints).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270881")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Pace: Using degrees 5 and 2 as before, and keeping the F region in one piece (and without using the M6 and M8 marginal conditions) I get a lower bound of 2.000146 – just over the line.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270887")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("James: one other setting that I don’t think has been explored yet is the extended prism with z ranging up to 2 rather than only 1 (per your Jan 27th observation about using GEH maximally). Since that prism has volume 1 as against only 9/16 for the untruncated simplex, there seems to be a pretty good chance that it would give better numerics and thus permit a cleaner F (with lower degrees and/or simpler fractions). Can your older code exploring the prism be easily adapted to this new setting?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270890")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Apropos: might there also be the possibility that a carefully-chosen, superficially sub-optimal epsilon would improve the prism’s numerics by obviating some of the vanishing marginal constraints, as we just saw with the simplex for epsilon=1/4? Recalling that the prism’s partial non-symmetry might motivate the use of two different epsilons, this might be a rather complex issue to explore…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270918")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Aubrey: It should be easy enough to do this – it just requires me to choose on which regions we have our function being polynomial, to input the marginal conditions and to make a couple of adjustments for the fact it is no longer symmetric. I’ll try to put something fairly simple together and see what comes out. That said, I’m away in Illinois as of tomorrow, so I’ll probably only be able to report back next week")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271881")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Aubrey: I made the modifications to look at the prism. Splitting the polytope up according to the ordering of x+z,y+z,1-e and 1+e gives a decomposition into 12 regions, and using degree 5 approximations I get a lower bound of about ")#mi("1.965..")#text(" (ignoring the trivial constructions which give a bound of exactly 2). It seems that one can increase this bound quite a bit (this seems a way from having converged), but it looks like unfortunately the prism isn’t going to give a simpler answer than we have already since we’d need more decompositions or higher degrees.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271885")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Interesting! Many thanks for this James. I wonder whether anyone has any intuition as to why there isn’t a reasonably tight correlation between polytope volume and M when other aspects are kept equal? I mean, the correlation should not be perfect, because different partitionings give different marginal constraints of different effective severity, but still it seems odd that the elongated prism’s being nearly twice as large as the untruncated simplex is outweighed by other factors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270889")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Thanks! That should simplify the exposition when we write this up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271129")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("As one additional data point, in this configuration it’s possible to reduce all degrees except F and G to 2 and keep just above 2 (2.000066 to be precise), but only by including monomials with all three variables.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270734")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("I think it should be numerically feasible to incorporate the epsilon trick into the existing numerical routine with only a slight slowdown.")

#text("The key observation for the numerical calculations to work was that it is easy to analytically calculate the ")#mi("k")#text("-dimensional integrals of monomials")#linebreak()#text(" ")#mi("\\prod_i t_i^{a_i}")#linebreak()#text(" over the simplex ")#mi("\\sum_i t_i<1")#text(", which allows us to easily calculate the I integrals. For the J-integrals we only need to perform a one-dimensional integral and then an integral of the above type (and provided the degree is suitably small, we can binomially expand to write the J integral of a monomial in terms of monomials as above, so everything remains feasible).")

#text("The same observation holds true with the epsilon-trick: we can still analytically write down the integral of a monomial over the simplex ")#mi("\\sum t_i<1+e")#text(" or ")#mi("\\sum t_i<1-e")#text(". We can still use the binomial expansion to do the first one-dimensional integral for the J-integrals when the degree is reasonably small.")

#text("The only thing that we've lost when using the ")#mi("\\epsilon")#text(" trick is that we were also using the fact that we also had a simple basis when we considered")#linebreak()#text(" ")#mi("(1-\\sum t_i)^a\\prod_i t_i^{a_i}")#text(",")#linebreak()#text(" and this allowed us to roughly double the degree of polynomial used. We can re-write our integrals in a similar form, but it would require another binomial expansion, and I don't know how costly (timewise) that would be. I think that overall this shouldn't pose too much of a problem, however, and so I think the ")#mi("\\epsilon")#text(" trick should be OK to use. I don't have a good intuition of how much gain we should expect from it, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270741")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("I’m unclear as to how the epsilon trick is dovetailing with other available tricks. The availability of the simplex of size 2, though not 2k/(k-1), originally arose as part of the discussion of expanding R’ to R’’. Is the current line of thinking that a large epsilon basically substitutes for that expansion to R’’ and thus avoids the need to dissect? How does this relate to the idea that Terry originally proposed for avoiding dissection of that simplex in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")]#text(" ? Could the two tricks be combined?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Certainly the two tricks can be combined – so that F is supported on a really big simplex of size 2 (or 2k/(k-1)), but whose marginals are supported on a simplex of size ")#mi("1+\\varepsilon")#text(" for some other value of ")#mi("\\varepsilon")#text(" – but then one has to deal with vanishing marginal conditions and we don’t know how to implement these when k is comparable to 50 (partitioning looks hopeless, as there would be an exponential or even factorial number of pieces to deal with).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270760")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Many thanks Terry. I must be misunderstanding ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")]#text(" where you proposed a way of automatically satisfying the vanishing marginal conditions and thereby not needing to partition the polytope. (Pace commented on this the following day in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")]#text(" but apparently hit combinatorial problems thereafter.) Are you saying that partitioning can be avoided when using the simplex of size 2 as R” or when using the epsilon trick on the original R but not when using both? Apologies if I’m missing something obvious. If there is indeed a barrier to combining these two ideas for k in the 50 range, it seems like the epsilon trick would be the less powerful of the two because the simplex would be enlarged by a smaller amount, but maybe there’s more to it?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("My feeling is that the way I proposed to automatically satisfy the vanishing marginal conditions would work on any simplex, but would likely only lead to an exponentially small improvement in k. Also it would require a more nontrivial amount of new code than the plain epsilon trick (moving from ")#mi("M_k")#text(" to ")#mi("M_{k,\\varepsilon}")#text(") would.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270782")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Got it. I guess I may have overinterpreted your comment there that “in the best case in which marginal conditions are ignored, M_k only improves by a factor of 2” – a factor of 2 would be huge, of course. (And yes, more code – but I was guessing from Pace’s comments that he may have already done most of that work.)")

#text("So there now seem to be two options in play for moving from M_k to M_k,epsilon: James’s suggestion from today, and Terry’s from a month ago ( ")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")]#text(" ). Is there any reason to prefer one over the other?")

#text("Once any kind of Mathematica code exists that can look at M_k,epsilon for k up to 54, it should be possible for neophytes like me to play with it for computational efficiency, such as by restricting total degree of monomials, restricting numbers of variables in monomials, etc.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270798")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("It is still possible to integrate over the original simplex using the transformation ")#mi("t_i = (1-\\epsilon)t^{\\prime}_i")#text(" using the same basis (in the variables ")#mi("t^{\\prime}_i")#text(") – with minor changes in the original code.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270874")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("James, are you sure we lose the degree doubling trick? How about using the basis ")#mi("(1+\\varepsilon -e_1)^a\\prod_i t_i^{a_i}")#text(". The I-integral computes as before, making the obvious change of variables and pulling out powers of ")#mi("1+\\varepsilon")#text(". The 1-dimensional part of the J-integral should also be computable as before.")

#text("Finally, the nice thing about multiplying ")#mi("m(\\alpha)")#text(" (for some signature ")#mi("\\alpha")#text(") by powers of ")#mi("e_1")#text(" is that one can quickly find the monomial symmetric polynomials that arise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270883")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("This is what I was attempting to say in my last paragraph: If we use the basis you mention then the I integral computes as before, and the first one-dimensional integral for the J part computes as before. We’d need to do an extra binomial expansion to convert this expression back into monomials for the final J integral, but this shouldn’t be too costly as the degree is still quite small. So I think we should get back to where we were before at the cost of roughly one binomial expansion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270896")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("Ah, I see now how I misread you. Thanks for the clarification.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270769")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("I’ve taken the liberty of starting a skeletal draft of a potential paper at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/raL055WXr5/Polymath8b")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/raL055WXr5/Polymath8b")]#text(" and more specifically at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/newergap.pdf")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/newergap.pdf")]#text(" . It is a little premature, since the unconditional bound on ")#mi("H_1")#text(" can still improve on 270, but I think it can serve as a first approximation for the structure of the paper. (I’ve put in a slightly weaker bound for the large m asymptotics because we haven’t proven the improved MPZ type estimate that we have been assuming there, and given how different the mathematics needed to prove that estimate (Deligne type stuff) is from the rest of the paper, it seems best to defer it for some future paper, and work with the estimate for ")#mi("\\frac{600}{7} \\varpi + \\frac{180}{7} \\delta < 1")#text(" rather than ")#mi("\\frac{1080}{13} \\varpi + \\frac{330}{13} \\delta < 1")#text(". (This will require some reworking of the numerics, of course, but this is presumably easy to do.)")

#text("In any case, there is no urgency to write things up just yet; we can still wait to see how the ")#mi("H_1 \\leq 270")#text(" bound withstands further attacks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270787")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2014")])]

#text("Is there a reason for writing “")#mi("me^{(4-\\frac{28}{157})m}")#text("” instead of “")#mi("me^{\\frac{600}{157}m}")#text("” in l. -3 of the abstract?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-270898")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("This is to emphasise the amount of improvement over the previous bound of ")#mi("m^3 e^{4m}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271005")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2014")])]

#text("In the quest for simplicity of ways to reach M_3=2 on GEH, I can report that with M6 and M8 removed and with monomials including all three variables included, M reaches 2.000033975 with all partitions’ maximum degrees set to only 3. M still stays above 2 when reducing the maximum denominator quite a lot from Pace’s original value of 10^40, but I haven’t yet played with that very much. It also works (for similar denominators) with the E, H, S and T degrees all reduced to 2, and even with E, H and S reduced to 1, but perhaps keeping all degrees equal can be considered cleaner. I don’t have the skills to throw in a re-merging of the S, T and U partitions, but it’s pretty clear that that would take M below 2 unless the G and U degrees are raised above 3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271006")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("Incidentally, I also found that the benefit of eliminating these marginals is quite a bit less – even in a setting where the optimal epsilon is really close to the one that allows such elimination – than that from restoring monomials which include all three variables. With M6 and M8 retained and epsilon optimised, I don’t quite get to 2 with all degrees being 3, but epsilon=257/1000 gets agonisingly close – 1.999987.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271091")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("Sheesh. If you really *were* playing Jenga, the humidity in your breath would take care of the rest..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271043")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("After I had asked James what happens when we merge components, I realized there is an easy way to already do that in my code. Here is one way to merge components. Just to illustrate, I’ll merge the S and T pieces.")

#text("1. Replace FTxyz with FSxyz (and similarly with all other necessary permutations of xyz). In the code, this is would done by removing the line {FTxyz,TTvars}=… and replacing it with FTxyz=FSxyz.")#linebreak()#text(" 2. Remove the TTvars from the list of variables a few lines later.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271052")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("It should be remarked that while ")#mi("F")#text(" as a piecewise polynomial is symmetric (by construction), on each component its polynomial representation is not(!) necessarily a symmetric polynomial (unless the component is symmetric, i.e. invariant to x, y, z permutations).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271228")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("A reasonable criterion for simplicity may be based on the so-called “minimal description length” which is roughly equivalent to the total number of digits in the coefficients describing the piecewise polynomial ")#mi("F")#text(". A strategy to approximate this may be based on two steps:")

#text("1. Representing ")#mi("F")#text(" with the smallest (or at least “reasonable”) number of corefficients (which depends of course on the partition and the monomials used in each component.)")

#text("2. Obtaining appropriate rational approximation (with minimal denominators) for the coefficients. (the coefficients may be converted to be integers – using the common denominator.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271235")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("This is indeed reasonable, except that it’s rather likely that there’s a substantial trade-off between the number of coefficients and the minimal denominator. As for step 1, though, the best I found for the number of coefficients is 110: that’s with monomials that use all three variables included, M6 and M8 eliminated, and no merging of S, T and U. The degree set in question is G=U=4, A=C=2, B=E=H=S=T=1 and M is 2.000223. Personally I think minimising the largest degree (to 3) is aesthetically preferable, even though that forces use of (I believe) at least 122 coefficients. (These coefficient counts don’t take account of the occasional case where the best F has some available coefficients set to zero, by the way.) But of course if James confirms my suspicion about the superiority of the elongated prism, we may see far simpler F’s soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271236")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("I agree about the trade-off (between the number of coefficients and minimal denominator): I think that this is mainly because a reduction in the number of coefficients should lead to a reduced ratio which is nearer to 2, and consequently to less flexibility in reducing the denominators of the coefficients.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271084")[#strong[#text("This and that | Ripple's Web » Yitang Zhang: A prime-number proof and a world of persistence")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")]

#text("[…] “Given the substantial progress made so far, it looks like we are close to the point where we should declare victory and write up the results,” Tao wrote on his blog Sunday. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271090")[#strong[#text("Yitang Zhang: A prime-number proof and a world of persistence | Tech Camp")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")]

#text("[…] “Given the substantial progress made so far, it looks like we are close to the point where we should declare victory and write up the results,” Tao wrote on his blog Sunday. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271102")[#strong[#text("Yitang Zhang: A prime-number proof and a world of persistence | TechNewsDB")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")]

#text("[…] “Given the substantial progress made so far, it looks like we are close to the point where we should declare victory and write up the results,” Tao wrote on his blog Sunday. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271145")[#strong[#text("Yitang Zhang: A prime-number proof and a world of persistence | TechyTrend")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")]

#text("[…] “Given the substantial progress made so far, it looks like we are close to the point where we should declare victory and write up the results,” Tao wrote on his blog Sunday. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271226")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("I haven’t had much time this week to think about the polymath project (as I’m working on another extremely interesting computation), but I did find a bit of time to hack together some code to test the gains from epsilon expansion for ")#mi("k=53")#text(". Using steps sizes of 1/1000, the optimal epsilon grows slightly as the degree of the approximation increases, as does the gain M receives over the non-epsilon computation.")

#text("Specifically, we have the following data for ")#mi("M_{\\epsilon}")#text(" (the optimal epsilon is given as the second subscript):")#linebreak()#text(" degree=1, ")#mi("M_0=2.840745,M_{8/1000}=2.856677")#linebreak()#text(" degree=2, ")#mi("M_0=3.158178,M_{10/1000}=3.173852")#linebreak()#text(" degree=3, ")#mi("M_0=3.341049,M_{10/1000}=3.363820")#linebreak()#text(" degree=4, ")#mi("M_0=3.472697,M_{14/1000}=3.499653")#linebreak()#text(" degree=5, ")#mi("M_0=3.572894,M_{12/1000}=3.600002")#linebreak()#text(" degree=6, ")#mi("M_0=3.651206,M_{16/1000}=3.683619")#linebreak()#text(" degree=7, ")#mi("M_0=3.713979,M_{16/1000}=3.745981")

#text("With these numbers, epsilon expansion should in principle be able to get us to ")#mi("k=53")#text(" (but probably not too much farther). However, at least as I’ve implemented it, there is a significant slow down. For instance, while a single run of the degree 7 computation before took a mere 2 seconds it now takes over 3 minutes. The primary source of the slow down is (I believe) how I’m expanding ")#mi("(1+\\varepsilon -P_1)^a m(\\alpha)")#text(". The binomial expansion is no problem, but re-expressing something of the form ")#mi("P_1^b m(\\alpha)")#text(" as a linear combination of monomial symmetric polynomials causes a slow-down.")

#text("I imagine there is probably a better way to deal with these terms. One possibility is perhaps to re-express powers of ")#mi("P_1")#text(" as polynomials in ")#mi("(1-\\varepsilon - P_1)")#text("; then the ")#mi("m(\\alpha)")#text(" term remains unaffected. I may have more time to think about these things next week, but I thought I’d raise the question now in case others of you have further ideas.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271227")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("Many thanks Pace. Can your code easily be run for any k? If so, one thing that I think would be very informative at this stage is to run it for k=2 through 5 (for some fixed degree), so as to give an initial sense of how M compares with what can be achieved using the broader range of choices for F that you and James have been exploring in the GEH setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271244")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("Expanding ")#mi("(1+\\varepsilon-P_1)^a=(2\\varepsilon +(1-\\varepsilon-P_1))^a")#text(" using the binomial theorem sped up the process quite a bit. It now appears that a major part of the lag comes from the complexity of epsilon. For instance taking the degree to be d=9, a run with epsilon=17/1000 takes 3.5 minutes, while with epsilon=16/1000 it takes 2.5 minutes. Because of this and the effectiveness of slightly bigger epsilons, I’ll probably take epsilon around 1/25 or so and run the d=18 computation over the next few days (after a few more small computations to give me a better judge of the most effective choice of epsilon).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271277")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("From the data above, it seems that the additive gain")#linebreak()#text(" ")#mi("M_{53,\\epsilon} - M_{53, 0}")#text(" tends (for large degrees) to about ")#mi("0.032")#text(".")#linebreak()#text(" Since the upper bounds on ")#mi("M_{52}, M_{53}")#text(" are quite tight and their difference is about ")#mi("0.018")#text(", it seems that also ")#mi("k=52")#text(" is possible (it was previously seems impossible without the ")#mi("\\epsilon")#text(" flexibility!)")#linebreak()#text(" But the difference ")#mi("M_{53} - M_{51}")#text(" (which should be about 0.036) seems to be (slightly) too large for ")#mi("k = 51")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271279")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("I’m a bit more optimistic than that, given the trend in the optimal epsilon. I think for large degree we could be looking at an optimal epsilon a few times bigger than we see for d=7, and thus a gain for M that’s also a few times bigger, maybe over 0.1. I think that’s where Pace was coming from in his plan to look at epsilon=0.04 when d=18. But the steep dependence of execution time on epsilon may get in the way – even a few days of execution time may be an underestimate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271292")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("To give some more data, the optimal epsilons I’m getting are:")#linebreak()#text(" ")#mi("d=8, M_0=3.764542, M_{17/1000}=3.800645")#linebreak()#text(" ")#mi("d=9, M_0=3.805925, M_{20/1000}=3.843085")#linebreak()#text(" ")#mi("d=10, M_0=3.839756, M_{1/50}=3.879280")#linebreak()#text(" ")#mi("d=11, M_0=3.867726, M_{1/45}=3.909358")

#text("The change in the structure of the optimal epsilons (from being measured in thousandths, to being measured in simple fractions) is due to the slow-down I noted above when using complicated fractions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271297")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("Looks like d=16 might make it, with epsilon around 1/30…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271298")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("Incidentally, I think it makes sense that we are seeing epsilons that are roughly on the order of 1/k. My thinking is this: if ")#mi("t_1 + \\dots + t_k")#text(" is bounded above by ")#mi("1+\\varepsilon")#text(", then “on average”, we expect ")#mi("t_1+\\dots + t_{k-1}")#text(" to be about ")#mi("\\frac{k-1}{k}")#text(" as large as ")#mi("t_1 + \\dots + t_k")#text(", i.e. to be about ")#mi("\\frac{k-1}{k} (1+\\varepsilon)")#text(" or less. So it is essentially “cost-free” to take any epsilon with ")#mi("\\frac{k-1}{k} (1+\\varepsilon) \\leq 1-\\varepsilon")#text(", which comes out to ")#mi("\\varepsilon \\sim 1/2k")#text(". After that, the cost of increasing epsilon starts creeping up, and eventually exceeds the marginal profit of expanding the support of F, and it does seem plausible to me that the crossover occurs for epsilon near 1/k. I’ll try to see if there is some formal way to make this precise (e.g. by generalising the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" to an upper bound on ")#mi("M_{k,\\varepsilon}")#text(" which peaks for ")#mi("\\varepsilon")#text(" comparable to 1/k).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271313")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2014")])]

#text("Terry, can this kind of argument also explain the dependence of the optimal epsilon on d for a given k?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271570")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("A simple partition for ")#mi("M_{k,\\epsilon}")#text(" computation:")

#mi("F")#text(" is supported on ")#mi("R = (1+\\epsilon) \\mathcal R_k")#text(".")

#text("The functional ")#mi("J^{(i)}(F)")#text(" is determined by ")#mi("F")#text(" values over")

#mi("A := (1-\\epsilon) \\mathcal R_{k-1}")

#text("and the domain ")#mi("B_i")#text(" which is determined by")

#mi("s_i \\leq 1-\\epsilon ; 1-\\epsilon < t_i \\leq 1+\\epsilon - s_i")

#text("where ")#mi("s_i := \\sum_{j \\neq i} t_j")#text(".")

#text("Let ")#mi("B := \\cup_i B_i")#text(" and")

#mi("C := R \\setminus (A \\cup B)")#text(".")

#text("Since the numerator ")#mi("J(F)")#text(" is independent on the values of ")#mi("F")#text(" on ")#mi("C")#text(", it follows that the optimal ")#mi("F")#text(" should vanish on ")#mi("C")#text(" (i.e. optimal ")#mi("F")#text(" is supported on ")#mi("A \\cup B")#text(").")

#text("My suggestion therefore is to optimize ")#mi("F")#text(" as a piecewise polynomial supported on the ")#mi("k+1")#text(" domains")

#mi("A, B_1, ... , B_k")

#text("In fact, only the polynomial representation of ")#mi("F")#text(" over ")#mi("A, B_1")#text(" are needed – using ")#mi("F")#text(" symmetry (it should be remarked that the polynomial representation of ")#mi("F")#text(" on ")#mi("B_1")#text(" is not(!) necessarily symmetric).")

#text("Remark: Since the optimal ")#mi("F")#text(" vanishes over ")#mi("C")#text(", it follows that it can't be real analytic (and, in particular, polynomial) on ")#mi("R")#text(" – explaining its slow convergence when represented by a single polynomial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271582")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("There is a problem in my suggestion above: in the definition of ")#mi("B_i")#text(" above, the lower bound for ")#mi("t_i")#text(" should be ")#mi("1-\\epsilon -s_i")#text(", but now the domains ")#mi("B_i")#text(" are not necessarily disjoint (so perhaps further decomposition is necessary).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271589")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("The simplest improvement is to use a single symmetric polynomial approximation for ")#mi("F")#text(" on ")#mi("A \\cup B")#text(" with ")#mi("F=0")#text(" on the remaining ")#mi("C")#text(". The resulting improvement is by computing the denominator ")#mi("I(F)")#text(" over ")#mi("A \\cup B")#text(" – without the (unnecessary) current contribution from the remaining region ")#mi("C")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271610")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("I managed to make a little bit of headway in clarifying the relationship between the lower bounds on ")#mi("M_k")#text(" (or ")#mi("M_{k,\\varepsilon}")#text(" coming from choosing good functions F, to the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" that one gets from Cauchy-Schwarz. One can abstract the Cauchy-Schwarz argument as follows: whenever one has a function ")#mi("G: {\\cal R}_k \\to {\\bf R}^+")#text(" which symmetrises to 1 (or to something bounded above by 1), we have the bound")

#mi("M_k \\leq k \\sup_{t_1+\\dots+t_{k-1} \\leq 1} \\int_0^{1-t_1-\\dots-t_{k-1}} \\frac{dt_k}{G(t_1,\\dots,t_k)}.")#text(" (*)")

#text("Indeed, given any F on ")#mi("{\\cal R}_k")#text(", we get from Cauchy-Schwarz that")

#mi("\\int_{t_1+\\dots+t_{k-1} \\leq 1} (\\int_0^{1-t_1-\\dots-t_{k-1}} F\\ dt_k)^2\\ dt_1 \\dots t_{k-1}")#linebreak()#text(" ")#mi("\\leq X \\int_{{\\cal R}_k} G(t_1,\\dots,t_k) F(t_1,\\dots,t_k)^2\\ dt_1 \\dots t_k,")

#text("where X is the supremum appearing in (*), and the claim then follows from symmetrising.")

#text("By taking ")#mi("G(t_1,\\dots,t_k) = 1 + (k-1) t_k - t_1 - \\dots - t_{k-1}")#text(" (which symmetrises to 1) we obtain the standard bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(".")

#text("On the other hand, if we have an eigenfunction")

#mi("M_k F(t_1,\\dots,t_k) = \\sum_{j=1}^k \\int F(t_1,\\dots,t_{j-1},t,t_{j+1},\\dots,t_k)\\ dt")

#text("with F positive, then we can take")

#mi("G(t_1,\\dots,t_k) := k \\frac{\\int F(t_1,\\dots,t_{k-1},t)\\ dt}{M_k F(t_1,\\dots,t_k)},")

#text("which symmetrises to 1, and obtain equality in (*). So this shows that Cauchy-Schwarz can in fact give optimal bounds if one chooses G correctly.")

#text("As such, if we wanted to, we could try to numerically improve the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" by experimenting with other G than ")#mi("1 + (k-1)t_k - t_1 - \\dots - t_{k-1}")#text(" that symmetrise to 1. Unfortunately, this is a nonlinear optimisation problem and not so easily settled by quadratic programming, as is the case with the lower bounds.")

#text("A similar story happens for ")#mi("M_{k,\\varepsilon}")#text(", where G is now supported on ")#mi("(1+\\varepsilon) \\cdot {\\cal R}_k")#text(" and the analogue of (*) is")

#mi("M_{k,\\varepsilon} \\leq k \\sup_{t_1+\\dots+t_{k-1} \\leq 1-\\varepsilon} \\int_0^{1-t_1-\\dots-t_{k-1}+\\varepsilon} \\frac{dt_k}{G(t_1,\\dots,t_k)}.")

#text("Again, this bound is sharp if we have a positive eigenfunction at ")#mi("M_{k,\\varepsilon}")#text(" and G is chosen appropriately. Taking G of the form")

#mi("G = 1 + a ((k-1)t_k - t_1 -\\dots - t_{k-1})")#text(" (**)")

#text("for some parameter ")#mi("\\frac{1}{1+\\varepsilon} \\leq a \\leq \\frac{1}{1-\\varepsilon}")#text(" that one is free to choose, one concludes the bound")

#mi("M_{k,\\varepsilon} \\leq \\frac{k}{a(k-1)} \\log( k + \\frac{(a(1+\\varepsilon)-1)(k-1)}{1-a(1-\\varepsilon)} ).")

#text("If one takes ")#mi("a=1/(1+\\varepsilon)")#text(" one recovers the crude bound ")#mi("M_{k.\\varepsilon} \\leq (1+\\varepsilon) \\frac{k}{k-1} \\log k")#text(". If one takes ")#mi("a=1")#text(", one instead gets the bound ")#mi("M_{k,\\varepsilon} \\leq \\frac{k}{k-1} \\log(2k-1)")#text(", which is slightly better for large epsilon. One could optimise in a to see what else one could get, but I suspect that one could do even better by playing with more general weight functions than (**).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-273644")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2014")])]

#text("It should be remarked that the last bound (with ")#mi("a =1")#text(") is already optimal! to see that, let (for fixed ")#mi("k")#text(" and ")#mi("\\epsilon \\in (0, 1)")#text(" denote for ")#mi("a\\in [\\frac {1}{1+\\epsilon}, \\frac {1}{1-\\epsilon})")#text(" by ")#mi("f(a)")#text(" the above upper bound for ")#mi("M_{k, \\epsilon}")#text(". Since")

#mi("f(a) = k \\int_0^{2 \\epsilon} \\frac {1}{1+a[(k-1)t-(1-\\epsilon)]} d t")

#text("It follows (e.g. by taking derivatives under the integral sign) that ")#mi("f")#text(" is convex (and therefore has a minimum at ")#mi("a=1")#text(" if ")#mi("f ^{\\prime}(1) = 0")#text(".")#linebreak()#text(" It remains only to find ")#mi("\\epsilon \\in (0, 1)")#text(" for which ")#mi("f ^{\\prime}(1) = 0")#text(".")#linebreak()#text(" A simple calculation shows that ")#mi("f ^{\\prime}(1) = 0")#text(" for")

#mi("\\epsilon = \\frac {2 k - 2}{(2 k - 1) \\log (2 k - 1)}")

#text("Remark: this ")#mi("\\epsilon")#text(" is quite large! (")#mi("O(1/ \\log k)")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-273839")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("A simple lower bound on ")#mi("\\epsilon")#text(" :")

#text("Suppose that ")#mi("M_{k, \\epsilon} > 4")#text(" for some ")#mi("k, \\epsilon")#text(".")#linebreak()#text(" Hence (by the crude bound above – with ")#mi("a = 1/(1+\\epsilon)")#text(")")

#mi("(1+\\epsilon)\\frac {k}{k-1} \\log k > 4")#text(", i.e.")

#mi("\\epsilon > \\frac {4(k-1)}{k \\log k} - 1")

#text("Examples:")

#mi("k = 50")#text(": ")#mi("\\epsilon > 0.00203")#linebreak()#text(" ")#mi("k = 49")#text(": ")#mi("\\epsilon > 0.00682")#linebreak()#text(" ")#mi("k = 48")#text(": ")#mi("\\epsilon > 0.01174")#linebreak()#text(" ")#mi("k = 47")#text(": ")#mi("\\epsilon > 0.01681")#linebreak()#text(" ")#mi("k = 46")#text(": ")#mi("\\epsilon > 0.02204")#linebreak()#text(" ")#mi("k = 45")#text(": ")#mi("\\epsilon > 0.02743")#linebreak()#text(" ")#mi("k = 40")#text(": ")#mi("\\epsilon > 0.05723")#linebreak()#text(" ")#mi("k = 35")#text(": ")#mi("\\epsilon > 0.09292")#linebreak()#text(" ")#mi("k = 30")#text(": ")#mi("\\epsilon > 0.13685")

#text("Remark: these (somewhat crude) numerical bounds show that ")#mi("\\epsilon")#text(" can be much larger than expected!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-276738")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2014")])]

#text("Let ")#mi("F_0")#text(" be positive and square integrable on ")#mi("\\mathcal R_k")#text(".")

#text("By taking (for ")#mi("i = 1, ... , k")#text(")")

#mi("G_i := \\mathcal L_k^{(i)} F_0 / F_0")

#text("We get ")#mi("\\sum_i G_i = \\mathcal L_k F_0 / F_0")#text(", and")

#mi("\\mathcal L_k^{(i)} (1/G_i) = 1")

#text("Which (by the above C-S bounding argument) gives the simple bound")

#tao-math("M_k \\le \\left|\\left| \\mathcal L_k F_0 / F_0 \\right|\\right|_{\\infty}", block: false)#text(" (1)")

#text("Remarks:")

#text("1. The bound (1) may be generalized (for ")#mi("F_0")#text(" not necessarily positive) by taking the supremum norm over the support of ")#mi("F_0")#text(".")

#text("2. This upper bound should be good for ")#mi("F_0")#text(" sufficiently close to an eigenfunction of ")#mi("\\mathcal L_k")#text(" (e.g. using ")#mi("F_0")#text(" giving good lower bound for ")#mi("M_k")#text(").")

#text("3. If ")#mi("F_0")#text(" is an eigenfunction of ")#mi("\\mathcal L_k")#text(" with corresponding eigenvalue ")#mi("\\lambda")#text(", the bound (1) shows that")#linebreak()#text(" ")#mi("M_k \\leq \\lambda")#text(" – implying that ")#mi("\\mathcal L_k")#text(" has at most one(!) eigenvalue (which must be ")#mi("M_k")#text(").")

#text("4. It seems that the above upper bound derivation can be generalized for ")#mi("M_{k, \\epsilon}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-281255")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("Remark 3 above gives a very simple proof that the exact expression found for the (necessarily single) eigenvalue of ")#mi("\\mathcal L_2")#text(" is in fact its norm ")#mi("M_2")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271612")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")])]

#text("The last upper bound shows that")

#mi("M_{23, \\epsilon} \\leq 3.9796 ... < 4")

#text("Implying (using this M-value) ")#mi("k \\geq 24")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271862")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("With ")#mi("d=16")#text(" we have ")#mi("M_{53,1/35}\\approx 4.000161")#text(". It turns out ")#mi("\\varepsilon=1/35")#text(" is optimal for degree 16 polynomial approximations. (Each individual run takes about 11 hours, and I started at 1/40, so it took all weekend to find this value.)")

#text("I still have no feeling about the relationship between larger epsilon, larger degrees of polynomial approximation, and corresponding improvement in the M computation. I’m running the ")#mi("k=52,d=18")#text(" computation now; I expect each individual run to take about a week.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271864")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Great job Pace. Perhaps a good way to obtain a better guess for the best d and epsilon for k=52 might be first to identify those values for k=54 and 55, which if I understand you you can determine relatively rapidly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271866")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Unfortunately, it takes just as long to find the optimal epsilon for other values of k. As for the best d, I’m getting close to the limit imposed by RAM issues, as well as run-time issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271867")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Apologies, I was unclear – what I meant was that as k increases one reaches M=4 with smaller degree and also smaller epsilon, and I think you said that execution time is very dependent on both d and epsilon even if not on k. (Right?) I was thinking therefore that if we knew the smallest d for which M_54, M_55 etc can top 4, and the corresponding best epsilon for those k and d, we might be able to extrapolate reasonably accurately to what d and epsilon to try first for k=52.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271884")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("I see what you mean now. Given that d=18 is already at the limit of my computing power there was no real need to try and extrapolate what degree was best; but it did look like d=18 had a decent chance of succeeding.")

#text("As for extrapolating epsilons, I started with ")#mi("\\varepsilon=1/33")#text(" as that seems to be a reasonable improvement when increasing the degree by 2. (The difference between 1/35 and 1/34 when d=16 was quite small, so even if this isn’t optimal it shouldn’t hurt us much.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271877")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("This improves H to 264!")

#text("In order to get faster convergence we need to use the fact that the optimal ")#mi("F")#text(" is supported only(!) on the region over which the integrands of the numerator functionals ")#mi("J^{(i)}_{k, \\epsilon}(F)")#text(" are integrated.")

#text("Therefore ")#mi("F=0")#text(" on the remaining region – (as in the case of region ")#mi("D")#text(" with ")#mi("FD = 0")#text(" in the computation of ")#mi("\\hat M^{\\prime\\prime}_{3, 1/4, 1}")#text(") – leading to discontinuities on the boundary of the support – resulting by very slow convergence when trying to approximate ")#mi("F")#text(" by a single polynomial over the whole region ")#mi("(1+\\epsilon) \\mathcal R_k")#text(".")

#text("The simplest solution is to compute the denominator functional ")#mi("I(F)")#text(" over the reduced support of ")#mi("F")#text(" (used in the numerator computation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271886")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("It may be possible to come up with a formula for the integral of a monomial over this region, similar to what James does in his paper. This is definitely something we should look at.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271892")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("The reduced support of ")#mi("F")#text(" is the union of the regions")#linebreak()#text(" ")#mi("D_i")#text(" on which the integrands of the numerator functionals")#linebreak()#text(" ")#mi("J^{(i)}_{k, \\epsilon}")#text(" are integrated. Each ")#mi("D_i")#text(" is determined by")

#mi("\\sum_j t_j \\le 1+\\epsilon ; \\sum_{j \\neq i} t_j \\le 1-\\epsilon")#text(".")

#text("Therefore ")#mi("F = 0")#text(" on the remaining region determined as the intersection of the ")#mi("k")#text(" half spaces")

#mi("(t_1, ... , t_j) : \\sum_{j \\neq i} t_j > 1-\\epsilon ; i = 1, ... , k")

#text("and the whole region ")#mi("(1+\\epsilon) \\mathcal R_k")#text(".")

#text("Therefore the remaining region is a convex polytope (on which it is perhaps easier to integrate its contribution to ")#mi("I(F)")#text(" – to be subtracted from the present value of ")#mi("I(F)")#text(" contributed by the whole region ")#mi("(1+\\epsilon) \\mathcal R_k")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Great news! I’ll update the wiki accordingly.")

#text("One amusing consequence of this calculation is that we now have a divergence between the H_2 bound on GEH, and the H_1 bound unconditionally. We now have ")#mi("H_1 \\leq 264")#text(" unconditionally, but on GEH we still only have ")#mi("H_2 \\leq 270")#text("; the value ")#mi("\\varepsilon=1/35")#text(" is inadmissible for the GEH calculation because it is larger than ")#mi("1/(k-1)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271994")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("That is fun fact! I imagine that it might be possible to get ")#mi("H_1\\leq 264")#text(" with ")#mi("\\varepsilon=1/52")#text(" by using even higher degree approximations, but I doubt we could continue such jerry-rigging indefinitely. In particular, I think we have a good chance to get ")#mi("k=52")#text(" (or even ")#mi("k=51")#text("), but not with ")#mi("\\varepsilon=1/(k-1)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271896")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("I’ve had a go at developing some extensions to Pace’s k=3 code (learning Mathematica as I go) that I hope may also be useful for two-digit k. My starting point is the suspicion that we can cut down the number of monomials included in the various polynomials quite considerably without impacting M very much, just by finding variables that can be set to zero with little impact. If that’s true, we might be able to develop a more systematic way to select monomials than the essentially serendipitous approach (e.g. Pace’s selection of only monomials with even total degree). The algorithm I’ve so far developed is pretty clunky and wouldn’t really scale, but it can certainly be streamlined.")

#text("I also added a system for simplifying the coefficients once the minimal set of monomials has been found: rather than normalising the eigenvector to the first variable (AA1) as Pace as doing, I mormalise the error in the Rationalize function to 1/2, thus making all the elements integers, and find the smallest multiple of the eigenvector that keeps M above 2. (This is actually more laborious than it sounds because, as might be expected from what Rationalize does, M does not vary remotely monotonically with the multiplier.) With this approach I can get the number of monomials down to 81 using the degree set G=U=4,A=C=2,B=E=H=S=T=1, with the following polynomials:")

#text("FA = -21 + 27 x – 17 x^2 + 24 y – 16 x y – 15 y^2 + 26 z – 12 x z – 9 y z – 17 z^2")

#text("FB = -9 + 6 x + 11 y + 2 z")

#text("FC = -7 + 14 x – 10 x^2 + 12 y – 11 x y – 8 y^2")

#text("FE = -2")

#text("FG = 6075420501/346240 – (16675800469 x)/173120 + 155635 x^2 – (6686927443 x^3)/64920 + 24572 x^4 – (9395259281 y)/86560 + (33229279693 x y)/81150 – (21832401219 x^2 y)/54100 + (5005953883 x^3 y)/40575 + (4054772621 y^2)/27050 – (38485294907 x y^2)/108200 + (86436312 x^2 y^2)/541 – (7063782421 y^3)/81150 + (3417366154 x y^3)/40575 + 24572 y^4 – (3180108497 z)/69248 + (124261104937 x z)/649200 – (90238133481 x^2 z)/432800 + (5649716833 x^3 z)/81150 + (142158687241 y z)/649200 – 556968 x y z + (3753280304 x^2 y z)/13525 – (88739020157 y^2 z)/432800 + (6718761079 x y^2 z)/27050 + (2430958652 y^3 z)/40575 + (1164494227 z^2)/25968 – (27311867067 x z^2)/216400 + (940600277 x^2 z^2)/13525 – (1983863621 y z^2)/13525 + (5100751699 x y z^2)/27050 + (3775389779 y^2 z^2)/54100 – (5026420987 z^3)/259680 + (4481310893 x z^3)/162300 + (1323771941 y z^3)/40575 + (101101127 z^4)/32460")

#text("FH = 2")

#text("FS = 0")

#text("FT = -(9/2) + 3 x + 6 y + 3 z")

#text("FU = -(53425823/20480) + 15471 x – 13354 x^2 – 25893 x^3 + 24572 x^4 + 12 y – (3119 x^2 y)/100 – (300147 y^2)/1280 + 5974 z – 34366 x z + (26850499 x^2 z)/800 + 7933 x^3 z + (789 y^2 z)/2 – (5615871 z^2)/1280 + 23540 x z^2 – 15951 x^2 z^2 – 180 y^2 z^2 + 952 z^3 – 4934 x z^3 + 60 z^4")

#text("The hope here is that a pattern can be discerned for which monomials can be most cheaply thrown out. If such a pattern emerges for small k and d, maybe it can indicate how enough of them might be eliminated from the outset for larger k and d to allow acceptable computational efficiency at the least cost in M. Presumably the place to start is with R or R’ rather than any domain that needs partitioning – at least until there is an implementation of Terry’s proposal for the simplex of size 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271901")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("It is perhaps possible to reduce this number of coefficients by locating the smallest coefficients (or the “less important” coefficients, using trial & error) and imposing more vanishing constraints for them, and see if the resulting M-value is still above 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271922")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("Yes, that’s exactly what I did. One thing I didn’t make clear is that the saving achieved in this way rises pretty rapidly as M is allowed to fall below what can be achieved at higher degree with all monomials used. I think the best M achieved so far with degrees as large as 5 (and 306 possible monomials) is only 2.0012, so staying above 2 with only 81 monomials seemed like a good sign. As a further data point I just looked more at the behaviour with constant degree (which is presumably the setting relevant to larger k). When all nine degrees are set to 2, allowing 90 monomials in principle, the best M is 1.9983, and when they are set to 3, which as I noted earlier allows M=2.0000339 using all possible monomials, we can reach M=1.9983 with only 96 monomials out of the possible 180 (and the actual 136 needed to reach M=2). M=1.96 can be reached using degree 3 with only 23 monomials! (All this is with epsilon=1/4 and dropping M6 and M8, by the way.)")

#text("Given this rather encouraging trend, I now plan to be more systematic than my previous intention to try to discern patterns: instead I plan to explore slowly introducing monomials of progressively higher total degree and number of dimensions featuring, while continuing to exclude monomials already eliminated in previous rounds. I’m fairly optimistic that this can be used in non-geological execution time for k quite a bit larger than has been explored thus far using all monomials.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-271905")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2014")])]

#text("I find the result of H_1<=6 on GEH very interesting, especially the proof that its optimal for sieve-theoretic methods. Now I wonder what would be – in a strange mathematical universe – the implications of H_1==6 (instead of 2 or 4)?")#linebreak()#text(" I'm thinking of implications that could be proven right or wrong, thus providing an alternative route to answere this question.")

#text("Thanks alot for your answere and good luck with continueing on unconditional H_1! (I'm following your research here on a daily basis, and i'm superexcited about every progress :-) )")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272036")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("This would indeed be an odd mathematical universe – assuming GEH, what it would mean is that there is a “conspiracy” between n and n+2, in that whenever these two numbers are both almost prime (in the sense of having no small prime factors), and one has an odd number of prime factors, then the other will almost always have an even number of prime factors (and vice versa). Similarly for n and n+4. (This doesn’t lead to a contradiction, because n, n+2, n+4 cannot all be almost prime at once, seeing that one of these numbers is necessarily divisible by 3.) This is extremely unlikely, but thus far we don’t seem to have any viable route to force a true contradiction out of this. (In a similar vein, it is incredibly unlikely that the digits of pi start exhibiting patterns such as alternating between odd and even numbers after some finite point, but we don’t know how to deduce a contradiction from such a bizarre scenario.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5162cf9bfb600aae7b0dc75c9f8954e80ab40e82e0a8fce12c188ea5c394ffa1-a5f3ee3445e76a613b7f243e63de1aa8fa020a569c47d4983450280115329df4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michel Eve")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272111")[#strong[#text("Michel Eve")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("I have a question regarding the value of the proof that H1 is less or equal to 6 under GEH. I understand that any progress on H1 unconditionnaly is a major step forward but why is a progress under GEH so important ? Is it because GEH is potentially easier to prove than the twin prime conjecture ? Can it be a step towards proving GEH ? For a non expert the use of an other conjecture to work towards the proof of a main conjecture is always puzzling….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272142")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("Yes, I would consider GEH as being closer to being provable than, say, the twin prime conjecture. One can very roughly gauge the complexity of a sum in analytic number theory by how many references it makes to a complicated arithmetic function, such as the von Mangoldt function ")#mi("\\Lambda")#text(". (There are other important measures of complexity, such as the amount of usable averaging present in the sum, or the level of accuracy one demands on the sum, but I will ignore these other dimensions of complexity for the purposes of this comment.) For instance, the sum ")#mi("\\sum_{x \\leq n \\leq 2x} 1")#text(" involves no such functions and is very easy to compute; the sum ")#mi("\\sum_{x \\leq n \\leq 2x} \\Lambda(n)")#text(" involves one such function and requires the prime number theorem to evaluate accurately. The twin prime conjecture is associated with the sum ")#mi("\\sum_{x \\leq n \\leq 2x} \\Lambda(n) \\Lambda(n+2)")#text(", which involves two separate occurrences of ")#mi("\\Lambda")#text(" and which we cannot yet evaluate accurately (although we do have some upper bounds). EH involves sums such as ")#mi("\\sum_{x \\leq n \\leq 2x: n = a\\ (q)} \\Lambda(n)")#text(" (or more precisely, certain averaged, renormalised versions of this sum) and is thus in principle on the same basic level of difficulty as the prime number theorem (and indeed results similar to the PNT, such as the Siegel-Walfisz theorem, are used in the proof of partial versions of EH such as the Bombieri-Vinogradov theorem). GEH has a similar story, but with ")#mi("\\Lambda")#text(" replaced by a more general arithmetic function (but still one of comparable complexity to ")#mi("\\Lambda")#text(").")

#text("Also, one can view things the other way around: each time one shows an implication of the form “Conjecture X implies Conjecture Y”, one obtains some more clarity and insight as to the relative level of difficulty of the two conjectures. In this case, it shows that despite superficial similarities, the ")#mi("H_1 \\leq 6")#text(" conjecture and the ")#mi("H_1 = 2")#text(" conjecture (i.e. the twin prime conjecture) have quite different levels of difficulty; we now know the former is much easier in that it is reducible to a “one arithmetic function” problem, namely GEH, whereas the latter seems to be an almost irreducible example of a “two arithmetic function” problem, which is still largely beyond our current methods.")

#text("It’s also worth noting that these arguments don’t just give ")#mi("H_1 \\leq 6")#text(" from GEH, but also give a bunch of other results as well. For instance, as noted recently here, we now know that GEH implies that _either_ the twin prime conjecture is true, _or_ the even Goldbach conjecture is asymptotically true up to an error of 2 (or both). One could imagine GEH eventually acquiring a status similar to GRH, which also has a large number of seemingly unrelated analytic number theory consequences which would follow from its resolution, and is now a central open problem in the subject.")

#text("Finally, it should be noted that Zhang’s most important technical achievement was his establishment of a certain restricted fragment of the Elliott-Halberstam conjecture that goes beyond what was previously known (i.e. Bombieri-Vinogradov theorem, together with some even more restricted fragments of EH from the work of Bombieri, Fouvry, Friedlander, and Iwaniec and later authors.) While Zhang’s work (or the numerical improvements to it in Polymath8a) are still quite far from a full resolution of EH or GEH, it does give us some hope that this conjecture is not utterly intractable. (Twin primes, on the other hand, are another story, as we have not made any serious dent in the parity barrier that guards this conjecture yet, although this barrier has been circumvented in some other contexts in which more averaging is present, so it is not completely hopeless.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I guess that its worth recalling a comment from a few weeks ago now we have shown ")#mi("H_1")#text(" is at most 6 under GEH.")

#text("Under GEH, at least one of the following is true;")#linebreak()#text(" 1. There are infinitely many twin primes")#linebreak()#text(" 2. Every large even integer ")#mi("N")#text(" is within 2 of a number which is the sum of 2 primes.")

#text("Therefore, if we do live in a bizarre world where there is a conspiracy preventing n and n+2 both being prime, we can almost prove the Goldbach conjecture (under GEH).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272034")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I’ve just been contacted by a senior employee at Dropbox, who has kindly offered some additional space for users of the Polymath dropbox folder (from 2GB to 10GB) as a gesture of support for our project. At present I don’t think we actually need this amount of space (the folder currently takes up just 0.02 GB of space), but it is conceivable that we might have some future need (e.g. if some of Pace’s monster-memory computations can somehow be parallelised). Anyway, this is something to keep in mind in case shared disk space somehow becomes the bottleneck.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272050")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I googled “parallel matrix inversion” and was led to the package LAPACK ")#link("http://www.netlib.org/lapack/")[#text("http://www.netlib.org/lapack/")]#text(" It looks like this might do the trick if we want to try do parallelize our computations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Perhaps the “cheapest” parallelisation one could do is simply to put (a copy of) the active code and data folder on Dropbox, and let different people try different values of k, different values of epsilon, etc. There might be a little bit of data sharing one could do; for instance, when keeping k fixed and trying different values of epsilon, one could rescale by 1+epsilon so that all polynomials are supported in the same simplex ")#mi("{\\cal R}_k")#text(", which means that the matrix for the I-functional is common to all choices of epsilon and only needs to be computed once. (But this is probably not the bottleneck; the J-functional is much more complicated. But perhaps one could precompute the inverse of I or whatever it is that is needed in the quadratic program.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272056")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I haven’t been following this project closely, but are you doing numerical (e.g. 64 bit floating point numbers) matrix inversion *without* lapack? The more explicitly parallel version of lapack is scalapack ")#link("http://www.netlib.org/scalapack/")[#text("http://www.netlib.org/scalapack/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272061")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("To this point we’ve been doing exact arithmetic in Mathematica. (Regarding the linear algebra, one step is an explicit matrix inversion, and the next is finding a floating point approximation for the largest eigenvector.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272073")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Is recent code anywhere? I don’t know anything about prime numbers or number theory, but I might help with applied linear algebra and numerical nonlinear optimization. If you care about extreme eigenvectors why bother explicitly inverting the matrix first? I’m sure I’m missing something..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272074")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I don’t understand why a matrix inversion is needed (in order to show that there is a vector ")#mi("x")#text(" for which ")#mi("x^{T}B x > 4 x^{T}A x")#text(", it is equivalent that ")#mi("B - 4 A")#text(" has a positive eigenvalue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272077")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("This was part of the code that I simply copied directly from James’ earlier code, but my impression for the reason for the matrix inversion is so that we can find explicit lower bounds for ")#mi("M_k")#text(" (i.e. we don’t know, a priori, what constant ")#mi("c")#text(" we can use to force ")#mi("B-cA")#text(" to have a positive eigenvalue). [It is also a sanity check that things are working correctly. I just did a separate computation where the matrix was not invertible; and I’m still trying figure out where in my code I made a mistake.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272078")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#mi("M_k")#text(" is the largest eigenvalue of the generalized eigenvalue problem ")#mi("(B - \\lambda A) x = 0")#text(". There is an efficient algorithm to find the generalized eigenvalues and eigenvectors of the pair ")#mi("(A, B)")#text(" without(!) matrix inversion (as I already mentioned in a previous comment) – see e.g. the wikipedia article on matrix pencils.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272079")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("@comment: The linear algebra problem is described on page 20 of Maynard’s paper ")#link("http://arxiv.org/pdf/1311.4600v2.pdf")[#text("http://arxiv.org/pdf/1311.4600v2.pdf")]#text(", and is the following: Given real, symmetric positive definite matrices ")#mi("M_2,M_1")#text(" (with ")#mi("M_1")#text(" invertible) find a vector ")#mi("a")#text(" maximizing the quotient ")#mi("(a^{T}M_2 a)/(a^{T}M_1 a)")#text(". This is currently being done by finding ")#mi("M_1^{-1}")#text(", then finding an (approximation to an) eigenvector ")#mi("a")#text(" of ")#mi("M_{1}^{-1}M_2")#text(" with largest eigenvalue.")

#text("It would also be sufficient to merely prove there exists a vector for which that quotient is bigger than 4. However, the actual value of the maximal quotient is helpful in other ways, such as helping us fix certain constants, it gives an intuition about how the quotient is behaving, etc…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272080")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("@ Eytan: Yes, I remember your earlier post! I looked into the function you linked to, and it is not currently implemented in Mathematica. Hopefully something similar is implemented in one of these other programs being currently discussed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272084")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Yes this is the generalized eigenvalue problem. Here’s a python example with four ways to solve it, plus output. I’m sure Mathematica, Matlab, etc. have similar implementations. Sorry for spamming it up, feel free to delete or move.")

#text("“””")

#link("http://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.eigsh.html")[#text("http://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.linalg.eigsh.html")]

#text("“””")#linebreak()#text(" from functools import partial")

#text("import numpy as np")

#text("from scipy.linalg import inv, eigh, eig, norm")#linebreak()#text(" from scipy.sparse.linalg import eigsh")#linebreak()#text(" from scipy.optimize import minimize")

#text("def normalized(x):")#linebreak()#text(" return x / np.linalg.norm(x)")

#text("def sample_matrix(n, s):")#linebreak()#text(" A = np.random.randn(n, n)")#linebreak()#text(" A = np.dot(A, A.T)")#linebreak()#text(" A = np.trunc(s*A)/s")#linebreak()#text(" return A")

#text("def generalized_rayleigh_ratio(A, B, x):")#linebreak()#text(" x = normalized(x)")#linebreak()#text(" return x.dot(A).dot(x) / x.dot(B).dot(x)")

#text("def objective(A, B, x):")#linebreak()#text(" disambig = np.square(1 – norm(x))")#linebreak()#text(" return disambig – generalized_rayleigh_ratio(A, B, x)")

#text("def main():")#linebreak()#text(" n = 4")#linebreak()#text(" s = 1e3")#linebreak()#text(" A = sample_matrix(n, s)")#linebreak()#text(" B = sample_matrix(n, s)")#linebreak()#text(" f = partial(objective, A, B)")#linebreak()#text(" result = minimize(f, np.ones(n), method=’bfgs’)")#linebreak()#text(" wa, va = eigsh(A, 1, B)")#linebreak()#text(" wb, vb = eig(np.dot(inv(B), A))")#linebreak()#text(" wc, vc = eigh(A, B, eigvals=(n-1, n-1))")#linebreak()#text(" print ‘A:’")#linebreak()#text(" print A")#linebreak()#text(" print")#linebreak()#text(" print ‘B:’")#linebreak()#text(" print B")#linebreak()#text(" print")#linebreak()#text(" print ‘eigsh:’")#linebreak()#text(" print wa[0]")#linebreak()#text(" print normalized(va[:, 0])")#linebreak()#text(" print")#linebreak()#text(" print ‘eig:’")#linebreak()#text(" print wb[0]")#linebreak()#text(" print normalized(vb[:, 0])")#linebreak()#text(" print")#linebreak()#text(" print ‘eigh:’")#linebreak()#text(" print wc[0]")#linebreak()#text(" print normalized(vc[:, 0])")#linebreak()#text(" print")#linebreak()#text(" print ‘optimization:’")#linebreak()#text(" print generalized_rayleigh_ratio(A, B, result.x)")#linebreak()#text(" print result.x")#linebreak()#text(" print")

#text("main()")

#text("—-")

#text("A:")#linebreak()#text(" [[ 1.115 0.869 0.656 0.501]")#linebreak()#text(" [ 0.869 5.201 1.734 -0.535]")#linebreak()#text(" [ 0.656 1.734 1.337 -0.132]")#linebreak()#text(" [ 0.501 -0.535 -0.132 0.554]]")

#text("B:")#linebreak()#text(" [[ 3.693 -0.663 0.265 -0.206]")#linebreak()#text(" [-0.663 1.708 0.021 0.281]")#linebreak()#text(" [ 0.265 0.021 0.72 -0.289]")#linebreak()#text(" [-0.206 0.281 -0.289 1.253]]")

#text("eigsh:")#linebreak()#text(" 4.38071133898")#linebreak()#text(" [ 0.16613191 0.7780925 0.59849769 -0.09366305]")

#text("eig:")#linebreak()#text(" (4.38071133898+0j)")#linebreak()#text(" [ 0.16613191 0.7780925 0.59849769 -0.09366305]")

#text("eigh:")#linebreak()#text(" 4.38071133898")#linebreak()#text(" [-0.16613191 -0.7780925 -0.59849769 0.09366305]")

#text("optimization:")#linebreak()#text(" 4.38071133898")#linebreak()#text(" [ 0.16613202 0.77809265 0.59849769 -0.09366297]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272144")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("It should be remarked that the exact matrix inversion has the drawback that the elements of the inverse matrix have very large denominators – (whose number of digits may be the order of the matrix size!) – requiring very large memory – which may explain the very slow computation!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272057")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("I think in principle this problem should be fairly ameanable to parallization, if we decide that is the next step.")

#text("The calculation of individual entries in the matrices are more-or-less independent, and can easily be calculated on separately.")

#text("For the eigenvalue step, a sufficient proof that ")#mi("M_1^{-1}M_2")#text(" has an eigenvalue which is bigger than 4 is that the determinant of ")#mi("4M_1-M_2")#text(" is negative. I think this should probably be parallelizale using e.g. the chinese remainder theorem (and I believe there is a large amount of literature on calculating large determinants).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272062")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("A necessary and sufficient condition is that ")#mi("4 M_1 - M_2")#text(" has a positive eigenvalue. (which is not implied by a negative determinant!)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272071")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("Correction: In my comment above it should be ")#mi("M_2 - 4 M_1")#text(" (instead of ")#mi("4 M_1 - M_2")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272070")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2014")])]

#text("To help implement the calculation of individual entries, we may also want to create a large look-up table for the structure constants that arise when we multiply elements of our basis. I haven’t thought much about this issue (because you had that excellent idea which doubled the degrees which had made it moot at the time), but I recall Terry had some ideas along those lines.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272138")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("I’ve uploaded my code for the k=53 computation to the Polymath8b dropbox. People are free to play around with it (if they have Mathematica). Some changes/things that should be done are the following:")

#text("1. Currently I have not imposed the (necessary) restriction that signatures should have length at most k, because the degree has never been big enough to make a difference.")

#text("2. My function for computing structure constants when multiplying elements of the basis is extremely slow and RAM intensive for large signatures. This should be fixed, perhaps along the lines Terry suggested earlier.")

#text("3. We should find a way to transfer the linear algebra portion to a better setup than Mathematica, that could possibly be parallelized.")

#text("4. Someone should double check that my computations are actually giving the correct values! (If we do parallelize this, we probably just want to rewrite the code from scratch in any case.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272163")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("By the way, I’m happy to run these computations on the BYU supercomputers if it looks like that will help. Before I go to the trouble of figuring out how to install and run LAPACK, it would be good to get confirmation that this program is the best one to do the generalized eigenvalue problem on very large sized (at least 1500 x 1500) rational (although we could use floating point approximations) symmetric matrices.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272169")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("I looked at Maynard’s code in the dropbox and those 42×42 matrices are dense with entries spanning more than 20 orders of magnitude and have condition numbers >1e30 which may pose challenges to straightforward application of the double precision LAPACK (or more appropriately ARPACK) library functions. Maybe it would be OK but I see that as a possible red flag. It will not do rational arithmetic. Everything else equal, large N=1500 matrix sizes should not be a problem because I think you could solve the optimization without doing anything like N^3 (no inversion, no matrix-matrix multiplication).")

#text("By the way I would be surprised if Mathematica does not already have LAPACK/ARPACK baked into it somehow. In Mathematica terms these libraries use MachinePrecision ")#link("http://reference.wolfram.com/mathematica/ref/MachinePrecision.html")[#text("http://reference.wolfram.com/mathematica/ref/MachinePrecision.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IIIIIIIIIIIII")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272179")[#strong[#text("IIIIIIIIIIIII")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("Indeed Mathematica does use LAPACK. ")#link("https://reference.wolfram.com/mathematica/tutorial/LinearAlgebraMatrixComputations.html")[#text("https://reference.wolfram.com/mathematica/tutorial/LinearAlgebraMatrixComputations.html")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272187")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2014")])]

#text("Thanks! The function “GeneralizedEigenvector” is no longer supported, but it appears that the functionality is still there within the usual “Eigenvector” function. I’ve tested it a bit, and it looks quite good so far.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48fce4eb8ee74132a21b83db48941b7755f7004fe88049fdc6070ff8064e71a0-7401a4eab5f795736c314dbe6614509e8052467db7407c1495e85fb1ade67d64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of foobar")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272227")[#strong[#text("foobar")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("Mathematica uses LAPACK numerics, but this doesn’t imply it’s limited to “machine precision” (that is, “doubles”). Mathematica also supports arbitrary precision reals with LAPACK. (This is mentioned on the page.) This is, no doubt, considerably slower, but extra numerical precision is available, and you are not really left to the mercy of precision supported by “double-precision” floats.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272245")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("As Pace mentions, the Mathematica Eigenvector function will do generalized eigendecomposition. Here’s the modification of the last bit of Maynard’s dropbox code that gets the same ratio.")

#text("ev = Eigenvectors[{N[M2, 150], N[M1, 150]}, 1][[1]];")#linebreak()#text(" rv = Rationalize[ev, 10^-40];")#linebreak()#text(" Ratio = k*(rv.M2.rv)/(rv.M1.rv);")#linebreak()#text(" N[Ratio, 20]")

#text("4.0020697619380471369")

#text("Some points are that Mathematica will do generalized eigenvector decomposition with more-than-machine precision (as foobar mentions), and that this formulation uses neither exact matrix inversion (as opposed to Maynard’s code) nor floating point matrix inversion nor matrix-matrix multiplication, so it should be fast. I have a hard time following the newer codes on the dropbox but presumably this modification could be applied there as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272269")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("I started testing the Mathematica functionality for solving the generalized eigenvector problem, and ran into what I hope is a small problem. We first compute the dense rational symmetric matrices corresponding to the I and J integrals. (I’m working on speeding up this step along the lines Terry outlined a while ago, but this might take a while as I have a few other projects on my plate.) We then have to use real approximations of these matrices since Mathematica doesn’t do the generalized eigenvector solving on rational matrices.")

#text("What I need to know is the best way to take real approximates of the matrices but still get the largest eigenvalue correct to (say) the first five decimal places. (I can do as in Comment’s code, and take Eigenvectors [{N[M2,*], N[M1,*],1] where * is a large number; but this has the potential to slow down the computation more than is necessary.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272274")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("The current code which uses the exact inverse also uses Eigenvectors[N[M, *], …] where * is a large number, so would the accuracy concern not apply to both the current method and the proposed generalized eigenvalue method?")

#text("In Maynard’s code I noticed that the entries of the matrices M1 and M2 both decrease in magnitude from the upper left towards the lower right, and that the condition number can be improved by left- and right- multiplying by a diagonal scaling matrix. Maybe tricks that use this diagonal scaling could help with the numerical stability, if Mathematica is not already doing something like this internally?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272275")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("@comment: Sorry I wasn’t clear! It is not accuracy, per se, that I’m concerned with. Rather it is *quick* accuracy. If taking 150 digit approximations of the matrices is the quickest way to get get 5 digit accuracy in the eigenvalue, so be it. But I’m hoping there is a better way.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272277")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("In a related but slightly different question, if you get a proposed rational vector then it is easy to use Mathematica to decide if its associated ratio is greater than or less than 4?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272278")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("Yes. Given a potential vector it is quite easy to compute the corresponding ratio. Put another way, the last 3 lines of the code you posted run fairly quickly. [There may be some room for improvement, but it isn’t currently the hangup.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/66a7e40444d8b0753ad1b6b223c1cb5c31e838d4b34acc858cf3ead206fdbf54-7ed5b743d02ca2cc55495dba89f6910305bb5beb74ed108ec14c0073debb1c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of comment")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272282")[#strong[#text("comment")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2014")])]

#text("Regarding the amount of precision of the two input matrices needed for a target precision for the max generalized eigenvalue, I guess a full answer would involve something like a ‘generalized eigenvalue problem condition number’ which I don’t know how to do. Googling shows that Maple and MATLAB have possibly related functions named EigenConditionNumbers and condeig.")

#text("On the other hand, a half-answer is easy because if low precision matrices give you a candidate rational vector whose associated ratio is > 4 then you are done.")

#text("For Maynard’s example the problem seems strangely stable. For example lowering the precision by changing N[M, 150] to N[M] gives a ratio that is equal to >12 places, even though the input matrices are badly conditioned with respect to matrix inversion.")

#text("ev = Eigenvectors[{N[M2], N[M1]}, 1][[1]];")#linebreak()#text(" rv = Rationalize[ev, 10^-40];")#linebreak()#text(" Ratio = k*(rv.M2.rv)/(rv.M1.rv);")#linebreak()#text(" N[Ratio, 20]")

#text("4.0020697619380349324")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("If I’ve understood correctly (not at all certain), the problem is equivalent to finding whether ")#mi("M_2 - 4M_1")#text(", where ")#mi("M_1")#text(" and ")#mi("M_2")#text(" are symmetric matrices, has a positive eigenvalue. Now ")#mi("M_2 - 4M_1")#text(" is also symmetric. But then it follows from ")#link("http://en.wikipedia.org/wiki/Bauer-Fike_theorem")[#text("http://en.wikipedia.org/wiki/Bauer-Fike_theorem")]#text(" that the eigenvalues are not sensitive to perturbations. So just machine precision may be enough for finding candidate vectors in many cases (although the final check should be done with rational numbers).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, IX: Large quadratic programs | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272387")[#strong[#text("Polymath8b, IX: Large quadratic programs | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on can be found at the wiki […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/335be765218d0a8ed08d93ed1fb026854138cbd88d354b93e7081044202e3774-368fa0dcc7e74630edd95533107902bb2f1e14f425305bb2ded42d81ced1a32b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of polonais")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-272474")[#strong[#text("polonais")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Mr Tao, please give prime numbers a chance to speak freely and do not censor them this time (it is neither nonsense nor spam). Look from a different angle can be helpful.")

#link("http://www.facebook.com/TableOfPrimeNumbers")[#text("http://www.facebook.com/TableOfPrimeNumbers")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99a2faca82e39d1b4bf8ccfaec2ad2d857edcd6c5e47c682511ae7092592702e-18b065bfaea4b6ba4afd28f878c4617fa9a7a58823d2b08dae692ed6363f7a65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan B.S.")]], [#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-274705")[#strong[#text("Dan B.S.")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2014")])]

#text("The Twin Prime Conjecture – Visual View")

#text("Let us imagine we are entering a train station and instead of taking the train, we’re flying by a helicopter and viewing the railway from a bird’s eye. From the helicopter, we see the starting point of the railway. The end can not be seen. Our railway is endless. Sitting in the helicopter, we can change the color of the railroad stripes as we wish.")

#text("First, we shall paint with red color every second stripe.")#linebreak()#text(" Thereafter we shall paint with yellow color every third stripe that is not painted red.")#linebreak()#text(" Thereafter we shall paint with blue color every fifth stripe that is not painted red or yellow.")#linebreak()#text(" Thereafter we shall paint with green color every seventh stripe that is not painted red or yellow or blue.")#linebreak()#text(" And so on according to the following prime numbers.")

#text("The question about the existence of an infinite number of twin primes, can be illustrated as follows: a coloring stage (coloring stage n) leaves behind an infinite number of pairs of stripes unpainted, which are separated by one red stripe. Is it possible to determine that the next coloring step (coloring stage n +1) will fail to “eliminate” these pairs ?")

#text("If the number of twin primes is finite, then there is a coloring stage which “eliminates” the pairs of white stripes which are left by its predecessor (from a certain point on the number line). Thus, if it appears that each coloring stage – no matter how advanced it is – leaves behind an infinite number of pairs of white stripes, then we can assume the existence of an infinite number of pairs of twin primes.")

#text("Read more")

#link("https://drive.google.com/file/d/0B3YBCg8YHwOjcmthUTlVSTdvZ1k/edit?usp=sharing")[#text("https://drive.google.com/file/d/0B3YBCg8YHwOjcmthUTlVSTdvZ1k/edit?usp=sharing")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comment-276746")[#strong[#text("【数学】「素数」がどのような間隔で分布するかに関する新たな定理を発見、数学者からは「教科書を書き換える」との声も | なばかり速報")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2014")]

#text("[…] よくわからんけどこれかな？例の中国人の人が双子素数が無限にある予想につながる定理の発見からいろいろ進展しているのか ")#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comme&#8230")[#text("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/#comme&#8230")]#text("; […]")
]
