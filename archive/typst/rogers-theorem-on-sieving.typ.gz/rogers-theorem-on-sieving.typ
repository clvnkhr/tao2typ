// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/
// Converted to Typst by tao2typ: "2026-10-14T15:21:09.855251+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Rogers’ theorem on sieving", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Rogers’ theorem on sieving")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 January 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/")[#text("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A basic problem in sieve theory is to understand what happens when we start with the integers ")#mi("{{\\bf Z}}")#text(" (or some subinterval of the integers) and remove some congruence classes ")#mi("{a_i \\pmod{q_i}}")#text(" for various moduli ")#mi("{q_i}")#text(". Here we shall concern ourselves with the simple setting where we are sieving the entire integers rather than an interval, and are only removing a finite number of congruence classes ")#mi("{a_1 \\pmod{q_1}, \\ldots, a_k \\pmod{q_k}}")#text(". In this case, the set of integers that remain after the sieving is periodic with period ")#mi("{Q = \\mathrm{lcm}(q_1,\\dots,q_k)}")#text(", so one work without loss of generality in the cyclic group ")#mi("{{\\bf Z}/Q{\\bf Z}}")#text(". One can then ask: what is the density of the sieved set ")#metadata(none) <tao-c33875196fc6b5ce64e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\{ n \\in {\\bf Z}/Q{\\bf Z}: n \\neq a_i \\text{ mod } q_i \\text{ for all } i=1,\\ldots,k \\}?")]]

#text(" ")#text(" If the ")#mi("{q_i}")#text(" were all coprime, then it is easy to see from the Chinese remainder theorem that the density is given by the product")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=1}^k \\left(1 - \\frac{1}{q_i}\\right).")]]

#text("However, when the ")#mi("{q_i}")#text(" are not coprime, the situation is more complicated. One can use the inclusion-exclusion formula to get a complicated expression for the density, but it is not easy to work with. Sieve theory also supplies one with various useful upper and lower bounds (starting with the classical ")#link("https://en.wikipedia.org/wiki/Boole%27s_inequality#Bonferroni_inequalities")[#text("Bonferroni inequalities")]#text("), but do not give exact formulae.")

#text("In this blog post I would like to note one simple fact, due to Rogers, that one can say about this problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Rogers’ theorem)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" For fixed ")#mi("{q_1,\\dots,q_k}")#text(", the density of the sieved set is maximized when all the ")#mi("{a_i}")#text(" vanish. Thus,")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\in {\\bf Z}/Q{\\bf Z}: n \\neq a_i \\text{ mod } q_i \\text{ for all } i=1,\\ldots,k \\}\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\left|\\{ n \\in {\\bf Z}/Q{\\bf Z}: n \\neq 0 \\text{ mod } q_i \\text{ for all } i=1,\\ldots,k \\}\\right|.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" If one sieves out ")#mi("{1 \\pmod{2}}")#text(", ")#mi("{1 \\pmod{3}}")#text(", and ")#mi("{2 \\pmod{6}}")#text(", then only ")#mi("{0 \\pmod{6}}")#text(" remains, giving a density of ")#mi("{1/6}")#text(". On the other hand, if one sieves out ")#mi("{0 \\pmod{2}}")#text(", ")#mi("{0 \\pmod{3}}")#text(", and ")#mi("{0 \\pmod{6}}")#text(", then the remaining elements are ")#mi("{1}")#text(" and ")#mi("{5 \\pmod{6}}")#text(", giving the larger density of ")#mi("{2/6}")#text(".")
]

#text("This theorem is somewhat obscure: its only appearance in print is in pages 242-244 of this 1966 text of ")#link("https://zbmath.org/0141.04405")[#text("Halberstam and Roth")]#text(", where the authors write in a footnote that the result is “unpublished; communicated to the authors by Professor Rogers”. I have only been able to find it cited in three places in the literature: in ")#link("https://www.ams.org/journals/proc/1996-124-02/S0002-9939-96-03088-2/")[#text("this 1996 paper of Lewis")]#text(", in ")#link("https://www.ams.org/journals/jams/2007-20-02/S0894-0347-06-00549-2/")[#text("this 2007 paper of Filaseta, Ford, Konyagin, Pomerance, and Yu")]#text(" (where they credit Tenenbaum for bringing the reference to their attention), and is also briefly mentioned in ")#link("https://annals.math.princeton.edu/2008/168-2/p01")[#text("this 2008 paper of Ford")]#text(". As far as I can tell, the result is not available online, which could explain why it is rarely cited (and also not known to AI tools). This became relevant recently with regards to ")#link("https://www.erdosproblems.com/281")[#text("Erdös problem 281")]#text(", posed by Erdös and Graham in 1980, which was solved recently by Neel Somani ")#link("https://chatgpt.com/share/696ac45b-70d8-8003-9ca4-320151e0816e")[#text("through an AI query")]#text(" by an elegant ergodic theory argument. However, shortly after this solution was located, it was ")#link("https://www.erdosproblems.com/forum/thread/281#post-3325")[#text("discovered by KoishiChan")]#text(" that Rogers’ theorem reduced this problem immediately to a ")#link("https://zbmath.org/0015.10001")[#text("very old result of Davenport and Erdös")]#text(" from 1936. Apparently, Rogers’ theorem was so obscure that even Erdös was unaware of it when posing the problem!")

#text("Modern readers may see some similarities between Rogers’ theorem and various rearrangement or monotonicity inequalites, suggesting that the result may be proven by some sort of “symmetrization” or “compression” method. This is indeed the case, and is basically Rogers’ original proof. We can modernize a bit as follows. Firstly, we can abstract ")#mi("{{\\bf Z}/Q{\\bf Z}}")#text(" into a finite cyclic abelian group ")#mi("{G}")#text(", with residue classes now becoming cosets of various subgroups of ")#mi("{G}")#text(". We can take complements and restate Rogers’ theorem as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Rogers’ theorem, again)")]#text(" ")#metadata(none) <tao-040264644dd55339c009>#text(" Let ")#mi("{a_1+H_1, \\dots, a_k+H_k}")#text(" be cosets of a finite cyclic abelian group ")#mi("{G}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{j=1}^k a_j + H_j\\right| \\geq \\left|\\bigcup_{j=1}^k H_j\\right|.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Take ")#mi("{G = {\\bf Z}/6{\\bf Z}}")#text(", ")#mi("{H_1 = 2{\\bf Z}/6{\\bf Z}}")#text(", ")#mi("{H_2 = 3{\\bf Z}/6{\\bf Z}}")#text(", and ")#mi("{H_3 = 6{\\bf Z}/6{\\bf Z}}")#text(". Then the cosets ")#mi("{1 + H_1}")#text(", ")#mi("{1 + H_2}")#text(", and ")#mi("{2 + H_3}")#text(" cover the residues ")#mi("{\\{1,2,3,4,5\\}}")#text(", with a cardinality of ")#mi("{5}")#text("; but the subgroups ")#mi("{H_1,H_2,H_3}")#text(" cover the residues ")#mi("{\\{0,2,3,4\\}}")#text(", having the smaller cardinality of ")#mi("{4}")#text(".")
]

#text("Intuitively: “sliding” the cosets ")#mi("{a_i+H_i}")#text(" together reduces the total amount of space that these cosets occupy. As pointed out in comments, the requirement of cyclicity is crucial; four lines in a finite affine plane already suffice to be a counterexample otherwise.")

#text("By factoring the cyclic group into ")#mi("p")#text("-groups, Rogers’ theorem is an immediate consequence of two observations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Rogers’ theorem for cyclic groups of prime order)")]#text(" ")#metadata(none) <tao-9708332be0e95efce990>#text(" Rogers’ theorem holds when ")#mi("{G = {\\bf Z}/p^n {\\bf Z}}")#text(" for some prime power ")#mi("{p^n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Rogers’ theorem preserved under products)")]#text(" ")#metadata(none) <tao-41859e3b247e23c7ee30>#text(" If Rogers’ theorem holds for two finite abelian groups ")#mi("{G_1, G_2}")#text(" of coprime orders, then it also holds for the product ")#mi("{G_1 \\times G_2}")#text(".")
]

#text("The case of cyclic groups of prime order is trivial, because the subgroups of ")#mi("{G}")#text(" are totally ordered. In this case ")#mi("{\\bigcup_{j=1}^k H_j}")#text(" is simply the largest of the ")#mi("{H_j}")#text(", which has the same size as ")#mi("{a_j + H_j}")#text(" and thus has lesser or equal cardinality to ")#mi("{\\bigcup_{j=1}^k a_j + H_j}")#text(".")

#text("The preservation of Rogers’ theorem under products is also routine to verify. By the coprime orders of ")#mi("{G_1,G_2}")#text(" and standard group theoretic arguments (e.g., ")#link("https://en.wikipedia.org/wiki/Goursat%27s_lemma")[#text("Goursat’s lemma")]#text(", the ")#link("https://en.wikipedia.org/wiki/Schur%E2%80%93Zassenhaus_theorem")[#text("Schur–Zassenhaus theorem")]#text(", or the classification of finite abelian groups), one can see that any subgroup ")#mi("{H_j}")#text(" of ")#mi("{G_1 \\times G_2}")#text(" splits as a direct product ")#mi("{H_j = H_{j,1} \\times H_{j,2}}")#text(" of subgroups of ")#mi("{G_1,G_2}")#text(" respectively, so the cosets ")#mi("{a_j + H_j}")#text(" also split as")

#align(center)[#tao-fit-display[#mitex("a_j + H_j = (a_{j,1} + H_{j,1}) \\times (a_{j,2} + H_{j,2}).")]]

#text("Applying Rogers’ theorem for ")#mi("{G_2}")#text(" to each “vertical slice” of ")#mi("{G_1 \\times G_2}")#text(" and summing, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{j=1}^k (a_{j,1} + H_{j,1}) \\times (a_{j,2} + H_{j,2})\\right| \\geq \\left|\\bigcup_{j=1}^k (a_{j,1} + H_{j,1}) \\times H_{j,2}\\right|", block: true)]]

#text("and then applying Rogers’ theorem for ")#mi("{G_1}")#text(" to each “horizontal slice” of ")#mi("{G_1 \\times G_2}")#text(" and summing, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{j=1}^k (a_{j,1} + H_{j,1}) \\times H_{j,2}\\right| \\geq \\left|\\bigcup_{j=1}^k H_{j,1} \\times H_{j,2}\\right|.", block: true)]]

#text("Combining the two inequalities, we obtain the claim.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Dear Terry,")

#text("The statement of Theorem 1 is illegible on my screen because the statement overflows the right boundary of the box.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("The “sliding cosets together” intuition feels closely related to compression arguments in discrete isoperimetry, where one monotonically reduces boundary while preserving measure. Is there a way to reinterpret Rogers’ theorem as a monotonicity statement for some natural boundary functional on finite abelian groups, or does the proof essentially rely on the subgroup lattice structure rather than an isoperimetric principle?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Yes, I feel there is a strong connection here. Perhaps there is also some continuous analogue of this result involving sliding Gaussians around (possibly involving some sort of entropy functional)? We have the Gaussian correlation inequality, of course, but that is a slightly different statement…")

#text("I also recently learned (from my colleague, Dominique Maldague) of a little-known ")#link("https://www.numdam.org/article/AIF_1976__26_2_29_0.pdf")[#text("rearrangement inequality of Montgomery for Fourier series")]#text(" from 1976, which surprised me somewhat given how oscillatory such series are.")

#text("EDIT: It seems one can view Rogers theorem as a statement about sliding together boxes (products of one-dimensional balls in various normed rings) to minimize the total volume occupied, with the theorem being that the minimum occurs when all the boxes are centered at the origin. The original context corresponds to the case where the normed rings in question are p-adic in nature.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4dac58488ffdd068dfa9e07d9066be6efb2a9ee45d878391fde15c56a39e528-3df670c88644e738af444cf932c91531175d639c8470ea7e8219e184ba696400.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pinkthoughtfullydc9abc2e99")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691650")[#strong[#text("pinkthoughtfullydc9abc2e99")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2026")])]

#text("This suggests that Rogers’ theorem is fundamentally tied to a totally ordered scale structure (as in the p-adic case). One can see a minimal continuous analogue in 1D with nested intervals, where sliding to the origin is a pure rearrangement of coverage multiplicity and convex functionals are monotone. Once partial intersections are allowed, this structure disappears, which may explain the absence of a general continuous entropy formulation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("A typical quadruple of affine lines over a finite field of cardinality q covers 4q-6 points, contradicting Theorem 3. For the proof to work the p-part of the group has to be cyclic.")

#emph[#text("[Good catch! Now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6951e482699df44ac12c5e137550500933499a93f15bb8314c81de197f92e812-77acf34543919daed7266f52845e92960b3fc35f790c52389561ed4321cae5a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of blissful6c33668ff8")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691605")[#strong[#text("blissful6c33668ff8")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Great news — thank you kindly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Which Professor Rogers is this? Hartley Rogers Jr., perhaps?")

#emph[#text("[The Halberstam-Roth text attributes this result to ")#link("https://en.wikipedia.org/wiki/Claude_Ambrose_Rogers")[#text("C. A. Rogers")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("C. A. Rogers ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/510c66552aeb522f5cb76b75c478fe636cf66825f909bb6c727daf61b2947f20-6dbbb40e17caf4d3068d1767901bd69105f87b499754457556d5c4ae80051e37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of secretlyobject05ab30fe9f")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691611")[#strong[#text("secretlyobject05ab30fe9f")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2026")])]

#text("What strikes me here is that the aligned case $a_i=0$ is not merely a convenient normalization, but an actual geometric extremum: it strictly bounds all shifted configurations in survivor density. From that perspective, many difficulties in analyzing arbitrary residue shifts come from modeling their entropy, when Rogers’ theorem says one can instead bound them by the coherent case. If the fully aligned configuration has no surviving density, no disordered configuration can either. In that sense, the theorem functions less as a counting identity and more as a dominance principle that collapses a large configuration space to a single extremal test.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2026")])]

#text("The aligned case seems to function less as a normalization and more as a stress test for the entire configuration space.")

#text("If even the most coherent configuration leaves no survivors, then no amount of shifting or disorder can rescue the situation.Viewed this way, Rogers’ theorem feels less about computing densities and more about identifying a universal extremal representative. This raises the question of whether alignment plays a similar extremal role for other monotone quantities …not just density, but perhaps entropy-like or stability functionals as well…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c3b312358923d660e96501bdbca513d7489f9a1df35d9d67253bcdb52689994-8a977d031895a6107893c9e2f97ff5fa897a155994117d302f0eb673f29fef88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonah Klein")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691939")[#strong[#text("Jonah Klein")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2026")])]

#text("You might be interested in knowing that ")#link("https://www.ams.org/journals/tran/0000-000-00/S0002-9947-2026-09670-9/home.html")[#text("this paper")]#text(" by Filaseta and Kalogirou also cites Roger’s Theorem. It appeared 3 days after this post, but the arxiv version has been out for a little less than 2 years.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691948")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2026")])]

#text("Thanks! I have also recently learned that the result was ")#link("https://www.sciencedirect.com/science/article/pii/0012365X86900798")[#text("established independently by Simpson in 1986")]#text(" (see Lemma 2.3, although seeing the equivalence with Rogers’ theorem requires the inclusion-exclusion formula).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90a71b15619c329bbd882285e8ed2d68480f3fb33997621bb0a06a6ce227cbdc-ba9feb9ab14713bf8584dad0cb24b8b2905cf1d486e2603c99e0fd36f724fb57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camille")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691944")[#strong[#text("Camille")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2026")])]

#text("Dear Professor Tao, Your p-adic box reformulation suggests that the compression argument can be made very explicit. Here is a short proof that makes the role of cyclicity transparent.")

#text("Compression argument: For each coset a_j + H_j, the map x → x – a_j is a bijection sending a_j + H_j to H_j, preserving the cardinality of the union exactly. Compressing all cosets this way yields the union of the subgroups directly, giving |⋃(a_j+H_j)| ≥ |⋃H_j|.")

#text("So… why is cyclicity essential? In a cyclic group of prime-power order, subgroups are totally ordered — this is precisely what makes the compression well-behaved simultaneously for all cosets. The Sylow decomposition extends this to all cyclic groups. In a non-cyclic group this fails: in G = Z/2Z × Z/2Z, taking H_1 = {(0,0),(1,0)}, H_2 = {(0,0),(0,1)} with a_1=(0,1), a_2=(1,0) gives |⋃(a_j+H_j)| = 4 > 3 = |⋃H_j|. The total ordering of subgroups is exactly the “stress test” others mention above — it is what collapses the entire configuration space to a single extremal representative.")

#text("In that sense, your p-adic box intuition was already the proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90a71b15619c329bbd882285e8ed2d68480f3fb33997621bb0a06a6ce227cbdc-ba9feb9ab14713bf8584dad0cb24b8b2905cf1d486e2603c99e0fd36f724fb57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camille")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691950")[#strong[#text("Camille")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2026")])]

#text("Ah… A small precision I forgot to mention: the compressions are applied one at a time — at each step, a single global bijection x↦x−aⱼ acts on all of G simultaneously, correctly transporting all intersections. The total ordering of subgroups is what ensures these successive steps remain compatible.")

#text("Apologies for the imprecision in the original comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90a71b15619c329bbd882285e8ed2d68480f3fb33997621bb0a06a6ce227cbdc-ba9feb9ab14713bf8584dad0cb24b8b2905cf1d486e2603c99e0fd36f724fb57.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camille")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-691954")[#strong[#text("Camille")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2026")])]

#text("Inspired by your discussion of Rogers’ inequality for unions of cosets, I tried to understand the structural mechanism behind it. My initial approaches repeatedly failed either locally (in the ppp-adic components) or globally (in the inclusion–exclusion structure), which led me to successively change the viewpoint.")

#text("Starting from the inclusion–exclusion formula in Z/QZ\\mathbb{Z}/Q\\mathbb{Z}Z/QZ, one can reorganize the intersection terms using the lattice generated by the least common multiples of the moduli. This leads naturally to a Möbius transform on that lattice.")

#text("Interpreting the progressions as cylinder sets in Z^\\widehat{\\mathbb{Z}}Z, the density becomes the Haar measure of a union of cylinders, and the intersection sizes factorize into ppp-adic contributions.")

#text("From this viewpoint, Rogers’ inequality reflects the fact that subgroup configurations maximize compatibility of local congruences, while translations destroy some intersections and therefore enlarge the union.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b2902ab6b4c5ffa7f5472ca40359e6ab0408f0b776fe38596b851c38aa4b6b8-e32ed10bc72f1a759ab74ac37918076a0b2574c6617a8b5e82527df0e6713fc0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Petr Kucheriaviy")]], [#link("https://terrytao.wordpress.com/2026/01/19/rogers-theorem-on-sieving/#comment-692024")[#strong[#text("Petr Kucheriaviy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2026")])]

#text("Dear Professor Tao, ")#linebreak()#text("Thank you for the interesting post!")

#text("For a ring, it seems natural to say that an analogue of Rogers’ theorem holds if it holds for all finite sets of ideals. I wrote ")#link("https://arxiv.org/abs/2603.14080")[#text("a short note")]#text(" showing that this analogue holds for an order if and only if it is a Dedekind domain. Interestingly, for an order that is not a Dedekind domain, the construction of a counterexample reduces to a counterexample with lines on a finite plane.")
]
