// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/
// Converted to Typst by tao2typ: "2026-10-14T15:19:25.581672+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 February 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")[#text("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("previous set of notes")]#text(", we saw how zero-density theorems for the Riemann zeta function, when combined with the zero-free region of Vinogradov and Korobov, could be used to obtain prime number theorems in short intervals. It turns out that a more sophisticated version of this type of argument also works to obtain prime number theorems in arithmetic progressions, in particular establishing the celebrated ")#link("http://en.wikipedia.org/wiki/Linnik%27s_theorem")[#text("theorem of Linnik")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Linnik’s theorem)")]#text(" ")#metadata(none) <tao-aac28e6b9f98104b92f5>#text(" Let ")#mi("{a\\ (q)}")#text(" be a primitive residue class. Then ")#mi("{a\\ (q)}")#text(" contains a prime ")#mi("{p}")#text(" with ")#mi("{p \\ll q^{O(1)}}")#text(".")
]

#text("In fact it is known that one can find a prime ")#mi("{p}")#text(" with ")#mi("{p \\ll q^{5}}")#text(", a ")#link("http://bib.math.uni-bonn.de/downloads/bms/BMS-404.pdf")[#text("result of Xylouris")]#text(". For sake of comparison, recall from Exercise 65 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/4")[#text("Notes 2")]#text(" that the Siegel-Walfisz theorem gives this theorem with a bound of ")#mi("{p \\ll \\exp( q^{o(1)} )}")#text(", and from Exercise 48 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" one can obtain a bound of the form ")#mi("{p \\ll \\phi(q)^2 \\log^2 q}")#text(" if one assumes the generalised Riemann hypothesis. The probabilistic random models from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(" suggest that one should in fact be able to take ")#mi("{p \\ll q^{1+o(1)}}")#text(".")

#text("We will not aim to obtain the optimal exponents for Linnik’s theorem here, and follow the treatment in Chapter 18 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(". We will in fact establish the following more quantitative result (a special case of a more powerful ")#link("http://www.ams.org/mathscinet-getitem?mr=279049")[#text("theorem of Gallagher")]#text("), which splits into two cases, depending on whether there is an exceptional zero or not:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Quantitative Linnik theorem)")]#text(" ")#metadata(none) <tao-363321e39b14339337aa>#text(" Let ")#mi("{a\\ (q)}")#text(" be a primitive residue class for some ")#mi("{q \\geq 2}")#text(". For any ")#mi("{x > 1}")#text(", let ")#mi("{\\psi(x;q,a)}")#text(" denote the quantity")

#align(center)[#tao-fit-display[#mitex("\\psi(x;q,a) := \\sum_{n \\leq x: n=a\\ (q)} \\Lambda(n).")]]

#text("Assume that ")#mi("{x \\geq q^C}")#text(" for some sufficiently large ")#mi("{C}")#text(".")

#list(
[#text("(i) (No exceptional zero) If all the real zeroes ")#mi("{\\beta}")#text(" of ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(" of real characters ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" are such that ")#mi("{1-\\beta \\gg \\frac{1}{\\log q}}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\psi(x;q,a) = \\frac{x}{\\phi(q)} ( 1 + O( \\exp( - c \\frac{\\log x}{\\log q} ) ) + O( \\frac{\\log^2 q}{q} ) )")]]

#text("for all ")#mi("{x \\geq 1}")#text(" and some absolute constant ")#mi("{c>0}")#text(".")],
[#text("(ii) (Exceptional zero) If there is a zero ")#mi("{\\beta}")#text(" of an ")#mi("{L}")#text("-function ")#mi("{L(\\cdot,\\chi_1)}")#text(" of a real character ")#mi("{\\chi_1}")#text(" of modulus ")#mi("{q}")#text(" with ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" for some sufficiently small ")#mi("{\\varepsilon>0}")#text(", then")

#metadata(none) <tao-d7c56b73d4f52151870b>

#tao-aligned(keep: true)[


#tao-math("\\psi(x;q,a)  & = \\frac{x}{\\phi(q)} ( 1 - \\chi_1(a) \\frac{x^{\\beta-1}}{\\beta}", block: true, numbering: n => [#text("(1)")])



#tao-math(" & + O( \\exp( - c \\frac{\\log x}{\\log q} \\log \\frac{1}{\\varepsilon} ) )", block: true)



#tao-math(" & + O( \\frac{\\log^2 q}{q} ) )", block: true)
]

#text("for all ")#mi("{x \\geq 1}")#text(" and some absolute constant ")#mi("{c>0}")#text(".")]
)

#text("The implied constants here are effective.")
]

#text("Note from the Landau-Page theorem (Exercise 54 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") that at most one exceptional zero exists (if ")#mi("{\\varepsilon}")#text(" is small enough). A key point here is that the error term ")#mi("{O( \\exp( - c \\frac{\\log x}{\\log q} \\log \\frac{1}{\\varepsilon} ) )}")#text(" in the exceptional zero case is an ")#emph[#text("improvement")]#text(" over the error term when no exceptional zero is present; this compensates for the potential reduction in the main term coming from the ")#mi("{\\chi_1(a) \\frac{x^{\\beta-1}}{\\beta}}")#text(" term. The splitting into cases depending on whether an exceptional zero exists or not turns out to be an essential technique in many advanced results in analytic number theory (though presumably such a splitting will one day become unnecessary, once the possibility of exceptional zeroes are finally eliminated for good).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Assuming Theorem ")#link(<tao-363321e39b14339337aa>)[#text("2")]#text(", and assuming ")#mi("{x \\geq q^C}")#text(" for some sufficiently large absolute constant ")#mi("{C}")#text(", establish the lower bound")

#align(center)[#tao-fit-display[#mitex("\\psi(x;a,q) \\gg \\frac{x}{\\phi(q)}")]]

#text("when there is no exceptional zero, and")

#align(center)[#tao-fit-display[#mitex("\\psi(x;a,q) \\gg \\varepsilon \\frac{x}{\\phi(q)}")]]

#text("when there is an exceptional zero ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(". Conclude that Theorem ")#link(<tao-363321e39b14339337aa>)[#text("2")]#text(" implies Theorem ")#link(<tao-aac28e6b9f98104b92f5>)[#text("1")]#text(", regardless of whether an exceptional zero exists or not.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The Brun-Titchmarsh theorem (Exercise 33 from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text("), in the sharp form of ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("Montgomery and Vaughan")]#text(", gives that")

#align(center)[#tao-fit-display[#mitex("\\pi(x; q, a) \\leq 2 \\frac{x}{\\phi(q) \\log (x/q)}")]]

#text("for any primitive residue class ")#mi("{a\\ (q)}")#text(" and any ")#mi("{x \\geq q}")#text(". This is (barely) consistent with the estimate ")#link(<tao-d7c56b73d4f52151870b>)[#text("(1)")]#text(". Any lowering of the coefficient ")#mi("{2}")#text(" in the Brun-Titchmarsh inequality (with reasonable error terms), in the regime when ")#mi("{x}")#text(" is a large power of ")#mi("{q}")#text(", would then lead to at least some elimination of the exceptional zero case. However, this has not led to any progress on the Landau-Siegel zero problem (and may well be just a reformulation of that problem). (When ")#mi("{x}")#text(" is a relatively small power of ")#mi("{q}")#text(", some improvements to Brun-Titchmarsh are possible that are not in contradiction with the presence of an exceptional zero; see ")#link("http://arxiv.org/abs/1201.1777")[#text("this paper of Maynard")]#text(" for more discussion.)")
]

#text("Theorem ")#link(<tao-363321e39b14339337aa>)[#text("2")]#text(" is deduced in turn from facts about the distribution of zeroes of ")#mi("{L}")#text("-functions. We first need a version of the truncated explicit formula that does not lose unnecessary logarithms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Log-free truncated explicit formula)")]#text(" With the hypotheses as above, show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda(n) \\chi(n) = - \\sum_{\\text{Re}(\\rho) > 3/4; \\left|\\text{Im}(\\rho)\\right| \\leq q^2; L(\\rho,\\chi)=0} \\frac{x^\\rho}{\\rho} + O( \\frac{x}{q^2} \\log^2 q)", block: true)]]

#text("for any non-principal character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(", where we assume ")#mi("{x \\geq q^C}")#text(" for some large ")#mi("{C}")#text("; for the principal character establish the same formula with an additional term of ")#mi("{x}")#text(" on the right-hand side. (")#strong[#text("Hint:")]#text(" this is almost immediate from Exercise 45(iv) and Theorem 21 of")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") with (say) ")#mi("{T := q^2}")#text(", except that there is a factor of ")#mi("{\\log^2 x}")#text(" in the error term instead of ")#mi("{\\log^2 q}")#text(" when ")#mi("{x}")#text(" is extremely large compared to ")#mi("{q}")#text(". However, a closer inspection of the proof (particularly with regards to the truncated Perron formula in Proposition 12 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") shows that the ")#mi("{\\log^2 x}")#text(" factor can be replaced fairly easily by ")#mi("{\\log x \\log q}")#text(". To get rid of the final factor of ")#mi("{\\log x}")#text(", note that the proof of Proposition 12 used the rather crude bound ")#mi("{\\Lambda(n) = O(\\log n)}")#text(". If one replaces this crude bound by more sophisticated tools such as the Brun-Titchmarsh inequality, one will be able to remove the factor of ")#mi("{\\log x}")#text(".")
]

#text("Using the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("1_{n = a\\ (q)} = \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q)} \\overline{\\chi(a)} \\chi(n)")]]

#text("(see Theorem 69 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("), we thus have")

#tao-aligned(keep: true)[


#tao-math("\\psi(x;a,q)  & = \\frac{x}{\\phi(q)} ( 1 - \\sum_{\\chi\\ (q)} \\overline{\\chi(a)} \\sum_{\\text{Re}(\\rho) > 3/4; \\left|\\text{Im}(\\rho)\\right| \\leq q^2; L(\\rho,\\chi)=0} \\frac{x^{\\rho-1}}{\\rho}", block: true)



#tao-math(" & + O( \\frac{\\log^2 q}{q} ) )", block: true)
]

#text("and so it suffices by the triangle inequality (bounding ")#mi("{1/\\rho}")#text(" very crudely by ")#mi("{O(1)}")#text(", as the contribution of the low-lying zeroes already turns out to be quite dominant) to show that ")#metadata(none) <tao-c668a971c77f4899414d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sum_{\\chi\\ (q)} \\sum_{\\sigma > 3/4; \\left|t\\right| \\leq q^2; L(\\sigma+it,\\chi)=0} x^{\\sigma-1} \\ll \\exp( - c \\frac{\\log x}{\\log q} )", block: true)]]

#text("when no exceptional zero is present, and ")#metadata(none) <tao-a8961db5510c0f37a224>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{\\chi\\ (q)} \\sum_{\\sigma > 3/4; \\left|t\\right| \\leq q^2; L(\\sigma+it,\\chi)=0; \\sigma+it \\neq \\beta} x^{\\sigma-1} \\ll \\exp( - c \\frac{\\log x}{\\log q} \\log \\frac{1}{\\varepsilon} )", block: true)]]

#text("when an exceptional zero is present.")

#text("To handle the former case ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(", one uses two facts about zeroes. The first is the classical zero-free region (Proposition 51 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), which we reproduce in our context here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Classical zero-free region)")]#text(" Let ")#mi("{q, T \\geq 2}")#text(". Apart from a potential exceptional zero ")#mi("{\\beta}")#text(", all zeroes ")#mi("{\\sigma+it}")#text(" of ")#mi("{L}")#text("-functions ")#mi("{L(\\cdot,\\chi)}")#text(" with ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" and ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" are such that")

#align(center)[#tao-fit-display[#mitex("\\sigma \\leq 1 - \\frac{c}{\\log qT}")]]

#text("for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("Using this zero-free region, we have")

#align(center)[#tao-fit-display[#mitex("x^{\\sigma-1} \\ll \\log x \\int_{1/2}^{1-c/\\log q} 1_{\\alpha < \\sigma} x^{\\alpha-1}\\ d\\alpha")]]

#text("whenever ")#mi("{\\sigma}")#text(" contributes to the sum in ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(", and so the left-hand side of ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\log x \\int_{1/2}^{1 - c/\\log q} N( \\alpha, q, q^2 ) x^{\\alpha-1}\\ d\\alpha")]]

#text("where we recall that ")#mi("{N(\\alpha,q,T)}")#text(" is the number of zeroes ")#mi("{\\sigma+it}")#text(" of any ")#mi("{L}")#text("-function of a character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" with ")#mi("{\\sigma \\geq \\alpha}")#text(" and ")#mi("{0 \\leq t \\leq T}")#text(" (here we use conjugation symmetry to make ")#mi("{t}")#text(" non-negative, accepting a multiplicative factor of two).")

#text("In Exercise 25 of ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(", the grand density estimate ")#metadata(none) <tao-7a6816dec58eafc68e51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("N(\\alpha,q,T) \\ll (qT)^{4(1-\\alpha)} \\log^{O(1)}(qT)")]]

#text("is proven. If one inserts this bound into the above expression, one obtains a bound for ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(" which is of the form")

#align(center)[#tao-fit-display[#mitex("\\ll (\\log^{O(1)} q) \\exp( - c \\frac{\\log x}{\\log q} ).")]]

#text("Unfortunately this is off from what we need by a factor of ")#mi("{\\log^{O(1)} q}")#text(" (and would lead to a weak form of Linnik’s theorem in which ")#mi("{p}")#text(" was bounded by ")#mi("{O( \\exp( \\log^{O(1)} q ) )}")#text(" rather than by ")#mi("{q^{O(1)}}")#text("). In the analogous problem for prime number theorems in short intervals, we could use the Vinogradov-Korobov zero-free region to compensate for this loss, but that region does not help here for the contribution of the low-lying zeroes with ")#mi("{t = O(1)}")#text(", which as mentioned before give the dominant contribution. Fortunately, it is possible to remove this logarithmic loss from the zero-density side of things:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Log-free grand density estimate)")]#text(" ")#metadata(none) <tao-663cb69f8ed0614a8c44>#text(" For any ")#mi("{q, T > 1}")#text(" and ")#mi("{1/2 \\leq \\alpha \\leq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("N(\\alpha,q,T) \\ll (qT)^{O(1-\\alpha)}.")]]

#text("The implied constants are effective.")
]

#text("We prove this estimate below the fold. The proof follows the methods of the previous section, but one inserts various sieve weights to restrict sums over natural numbers to essentially become sums over “almost primes”, as this turns out to remove the logarithmic losses. (More generally, the trick of restricting to almost primes by inserting suitable sieve weights is quite useful for avoiding any unnecessary losses of logarithmic factors in analytic number theory estimates.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Use Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(" to complete the proof of ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(".")
]

#text("Now we turn to the case when there is an exceptional zero ")#link(<tao-a8961db5510c0f37a224>)[#text("(3)")]#text(". The argument used to prove ")#link(<tao-c668a971c77f4899414d>)[#text("(2)")]#text(" applies here also, but does not gain the factor of ")#mi("{\\log \\frac{1}{\\varepsilon}}")#text(" in the exponent. To achieve this, we need an additional tool, a version of the Deuring-Heilbronn repulsion phenomenon due to Linnik:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Deuring-Heilbronn repulsion phenomenon)")]#text(" ")#metadata(none) <tao-53499abbfdfb4ad6959c>#text(" Suppose ")#mi("{q \\geq 2}")#text(" is such that there is an exceptional zero ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" with ")#mi("{\\varepsilon}")#text(" small. Then all other zeroes ")#mi("{\\sigma+it}")#text(" of ")#mi("{L}")#text("-functions of modulus ")#mi("{q}")#text(" are such that")

#align(center)[#tao-fit-display[#tao-math("\\sigma \\leq 1 - c \\frac{\\log \\frac{1}{\\varepsilon}}{\\log(q(2+\\left|t\\right|))}.", block: true)]]

#text("In other words, the exceptional zero enlarges the classical zero-free region by a factor of ")#mi("{\\log \\frac{1}{\\varepsilon}}")#text(". The implied constants are effective.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Use Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(" and Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(" to complete the proof of ")#link(<tao-a8961db5510c0f37a224>)[#text("(3)")]#text(", and thus Linnik’s theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Use Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(" to give an alternate proof of (Tatuzawa’s version of) Siegel’s theorem (Theorem 62 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). (")#emph[#text("Hint:")]#text(" if two characters have different moduli, then they can be made to have the same modulus by multiplying by suitable principal characters.)")
]

#text("Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(" is proven by similar methods to that of Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(", the basic idea being to insert a further weight of ")#mi("{1 * \\chi_1}")#text(" (in addition to the sieve weights), the point being that the exceptional zero causes this weight to be quite small on the average. There is a strengthening of Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=371840")[#text("due to Bombieri")]#text(" that is along the lines of Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(", obtaining the improvement ")#metadata(none) <tao-a60f76e94051a51ae5d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("N^{\\prime}(\\alpha,q,T) \\ll \\varepsilon (1 + \\frac{\\log T}{\\log q}) (qT)^{O(1-\\alpha)}")]]

#text("with effective implied constants for any ")#mi("{1/2 \\leq \\alpha \\leq 1}")#text(" and ")#mi("{T \\geq 1}")#text(" in the presence of an exceptional zero, where the prime in ")#mi("{N^{\\prime}(\\alpha,q,T)}")#text(" means that the exceptional zero ")#mi("{\\beta}")#text(" is omitted (thus ")#mi("{N^{\\prime}(\\alpha,q,T) = N(\\alpha,q,T)-1}")#text(" if ")#mi("{\\alpha \\leq \\beta}")#text("). Note that the upper bound on ")#mi("{N^{\\prime}(\\alpha,q,T)}")#text(" falls below one when ")#mi("{\\alpha > 1 - c \\frac{\\log \\frac{1}{\\varepsilon}}{\\log(qT)}}")#text(" for a sufficiently small ")#mi("{c>0}")#text(", thus recovering Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(". Bombieri’s theorem can be established by the methods in this set of notes, and will be given as an exercise to the reader.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" There are a number of alternate ways to derive the results in this set of notes, for instance using the Turan power sums method which is based on studying derivatives such as")

#tao-aligned(keep: true)[


#tao-math("\\frac{L^{\\prime}}{L}(s,\\chi)^{(k)}  & = (-1)^k \\sum_n \\frac{\\Lambda(n) \\chi(n) \\log^k n}{n^s}", block: true)



#tao-math(" & \\approx (-1)^{k+1} k! \\sum_\\rho \\frac{1}{(s-\\rho)^{k+1}}", block: true)
]

#text("for ")#mi("{\\text{Re}(s)>1}")#text(" and large ")#mi("{k}")#text(", and performing various sorts of averaging in ")#mi("{k}")#text(" to attenuate the contribution of many of the zeroes ")#mi("{\\rho}")#text(". We will not develop this method here, but see for instance Chapter 9 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1297543")[#text("Montgomery’s book")]#text(". See the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("text of Friedlander and Iwaniec")]#text(" for yet another approach based primarily on sieve-theoretic ideas.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" When one optimises all the exponents, it turns out that the exponent in Linnik’s theorem is ")#emph[#text("extremely")]#text(" good in the presence of an exceptional zero – indeed ")#link("http://www.ams.org/mathscinet-getitem?mr=1995146")[#text("Friedlander and Iwaniec showed")]#text(" can even get a bound of the form ")#mi("{p \\ll q^{2-c}}")#text(" for some ")#mi("{c>0}")#text(", which is even stronger than one can obtain from GRH! There are other places in which exceptional zeroes can be used to obtain results stronger than what one can obtain even on the Riemann hypothesis; for instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("Heath-Brown used")]#text(" the hypothesis of an infinite sequence of Siegel zeroes to obtain the twin prime conejcture.")
]

#metadata(none) <tao-1c539febe1395470e9cb>

#heading(level: 1)[#strong[#text(" — 1. Log-free density estimate — ")]]

#metadata(none) <tao-836ff184e7b41b1e13cb>

#text("We now prove Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(". We will make no attempt here to optimise the exponents in this theorem, and so will be quite wasteful in the choices of numerical exponents in the argument that follows in order to simplify the presentation.")

#text("By increasing ")#mi("{T}")#text(" if necessary we may assume that ")#metadata(none) <tao-89283e09afdbe2ffd8a6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("T \\geq q^{10}")]]

#text("(say); we may also assume that ")#mi("{T}")#text(" is larger than any specified absolute constant. We may then replace ")#mi("{qT}")#text(" by ")#mi("{T}")#text(" in the estimate, thus we wish to show that")

#align(center)[#tao-fit-display[#mitex("N(\\alpha,q,T) \\ll T^{O(1-\\alpha)}.")]]

#text("Observe that in the regime")

#align(center)[#tao-fit-display[#mitex("1-\\alpha \\gg \\frac{\\log\\log T}{\\log T}")]]

#text("the claim already follows from the non-log-free density estimate ")#link(<tao-7a6816dec58eafc68e51>)[#text("(4)")]#text(". Thus we may assume that")

#align(center)[#tao-fit-display[#mitex("\\alpha = 1 - \\frac{A}{\\log T}")]]

#text("for some ")#mi("{A = O( \\log \\log T )}")#text(", and the claim is now to show that there are at most ")#mi("{O( \\exp( O(A) ) )}")#text(" zeroes of ")#mi("{L}")#text("-functions ")#mi("{L(\\sigma+it,\\chi)}")#text(" with ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(", ")#mi("{\\sigma \\geq 1 - \\frac{A}{\\log T}}")#text(", and ")#mi("{\\chi}")#text(" a character of modulus ")#mi("{q}")#text(". We may assume that ")#mi("{A \\geq 1}")#text(", since the ")#mi("{A < 1}")#text(" case follows from the ")#mi("{A \\geq 1}")#text(" case (and also essentially follows from the classical zero-free region, in any event).")

#text("For minor technical reasons it is convenient to first dispose of the contribution of the principal character. In this case, the zeroes are the same as those of the Riemann zeta function. From the Vinogradov-Korobov zero-free region we conclude there are no zeroes ")#mi("{\\sigma}")#text(" with ")#mi("{\\sigma \\geq 1 - \\frac{A}{\\log T}}")#text(" and ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". Thus we may restrict attention to non-principal characters ")#mi("{\\chi}")#text(".")

#text("Suppose we have a zero ")#mi("{L(\\sigma+it,\\chi)=0}")#text(" of a non-principal character ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(" with ")#mi("{\\sigma \\geq 1 - \\frac{A}{\\log T}}")#text(" and ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". From equation (48) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{\\chi(n)}{n^{\\sigma+it}} \\ll q T x^{-\\sigma}")]]

#text("for any ")#mi("{x \\geq 1}")#text("; in particular ")#metadata(none) <tao-bb8c8605c55dcc2d650e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\sum_{n \\leq x} \\frac{\\chi(n)}{n^{\\sigma+it}} \\ll T^{-400}")]]

#text("(say) for all ")#mi("{T^{500} \\leq x \\leq T^{1000}}")#text(". One can of course obtain more efficient truncations than this, but as mentioned previously we are not trying to optimise the exponents. If one subtracts the ")#mi("{n=1}")#text(" term from the left-hand side, this already gives a zero-detecting polynomial, but it is not tractable to work with because it contains too many terms with small ")#mi("{n}")#text(" (and is also not concentrated on those ")#mi("{n}")#text(" that are almost prime). To fix this, we weight the previous Dirichlet polynomial by ")#mi("{\\rho*1}")#text(", where ")#mi("{\\rho}")#text(" is an arithmetic function supported on ")#mi("{[1,T^{500}]}")#text(" to be chosen later obeying the bound ")#mi("{\\rho(m) \\ll \\tau(m)^{O(1)}}")#text(". We expand")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq T^{1000}} \\rho*1(n) \\frac{\\chi(n)}{n^{\\sigma+it}} = \\sum_{m \\leq T^{500}} \\frac{\\rho(m) \\chi(m)}{m^{\\sigma+it}} \\sum_{n \\leq T^{1000}/m} \\frac{\\chi(n)}{n^{\\sigma+it}}")]]

#text("and hence by ")#link(<tao-bb8c8605c55dcc2d650e>)[#text("(7)")]#text(" and the upper bound on ")#mi("{\\rho(m)}")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq T^{1000}} \\rho*1(n) \\frac{\\chi(n)}{n^{\\sigma+it}} \\ll T^{-400} \\sum_{m \\leq T^{500}} \\frac{\\tau(m)^{O(1)}}{m^\\sigma}.")]]

#text("Since ")#mi("{\\sigma \\geq 1 - O( \\frac{\\log\\log T}{\\log T} )}")#text(", one sees from the divisor bound and the hypothesis that ")#mi("{T}")#text(" is large that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq T^{1000}} \\rho*1(n) \\frac{\\chi(n)}{n^{\\sigma+it}}\\right| \\leq \\frac{1}{2}", block: true)]]

#text("If we have ")#mi("{\\rho(1)=1}")#text(", then we can extract the ")#mi("{n=1}")#text(" term and obtain a zero-detecting polynomial:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{1 < n \\leq T^{1000}} \\rho*1(n) \\frac{\\chi(n)}{n^{\\sigma+it}}\\right| \\geq \\frac{1}{2}.", block: true)]]

#text("We now select the weights ")#mi("{\\rho}")#text(". There are a number of options here; we will use a variant of the “continuous Selberg sieve” from Section 2 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(". Fix a smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-1,1]}")#text(" and is supported on ")#mi("{[-2,2]}")#text("; we allow implied constants to depend on ")#mi("{f}")#text(". For any ")#mi("{R > 1}")#text(", define")

#align(center)[#tao-fit-display[#mitex("\\beta_R(n) := \\sum_{d|n} \\mu(d) f( \\frac{\\log d}{\\log R} ).")]]

#text("Observe from Möbius inversion that ")#mi("{\\beta_R(n) = 1_{n=1}}")#text(" for all ")#mi("{n \\leq R}")#text(". The weight ")#mi("{\\beta_R^2}")#text(" was used as an upper bound Selberg sieve in ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text(".")

#text("We observe that ")#metadata(none) <tao-224ef06c1b2cb20fc0c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\beta_{R_1} \\beta_{R_2} = 1 * \\rho_{R_1,R_2}")]]

#text("for any ")#mi("{R_1,R_2 > 1}")#text(", where ")#metadata(none) <tao-a68deda73329b42f131f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\rho_{R_1,R_2}(d) := \\sum_{d_1,d_2: [d_1,d_2] = d} \\mu(d_1) f( \\frac{\\log d_1}{\\log R_1} ) \\mu(d_2) f( \\frac{\\log d_2}{\\log R_2} ).")]]

#text("We will need the following general bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Sieve upper bound)")]#text(" ")#metadata(none) <tao-a5ad895656074bb12930>#text(" Let ")#mi("{1 \\leq R_1 \\leq R_2 \\ll R_1^{O(1)}}")#text(", and let ")#mi("{g}")#text(" be a completely multiplicative function such that ")#mi("{g(p) = O(1)}")#text(" for all primes ")#mi("{p}")#text(". Then ")#metadata(none) <tao-1b4c9133da73a7113224>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_d \\frac{g(d)}{d} \\rho_{R_1,R_2}(d) \\ll \\exp( - \\sum_{p \\leq R_1} \\frac{g(p)}{p} ).")]]
]

#emph[#text("Proof:")]#text(" Clearly, we can restrict ")#mi("{d}")#text(" to those numbers whose prime factors do not exceed ")#mi("{CR_1^C}")#text(", for some large absolute constant ")#mi("{C}")#text(".")

#text("By a Fourier expansion we can write ")#metadata(none) <tao-04efaf080f5a3e74e1c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("f(u) = \\int_{\\bf R} e^{-itu} F(t)\\ dt")]]

#text("for some rapidly decreasing function ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(", and thus the left-hand side of ")#link(<tao-1b4c9133da73a7113224>)[#text("(10)")]#text(" may be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\frac{g([d_1,d_2])}{[d_1,d_2] d_1^{it_1/\\log R_1} d_2^{it_2/\\log R_2}}\\ F(t_1) F(t_2) dt_1 dt_2")]]

#text("where we implicitly restrict ")#mi("{d_1,d_2}")#text(" to numbers whose prime factors do not exceed ")#mi("{CT^C}")#text(" (note that this makes the integrand absolutely summable and integrable, so that Fubini’s theorem applies). We may factor this as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\prod_{p \\leq CR_1^C} (1 - \\frac{g(p)}{p} (p^{-it_1/\\log R_1} + p^{-it_2/\\log R_2} - p^{-it_1/\\log R_1 - it_2/\\log R_2}))")]]

#align(center)[#tao-fit-display[#mitex("F(t_1) F(t_2) dt_1 dt_2.")]]

#text("By the rapid decrease of ")#mi("{F}")#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\leq CR_1^C} (1 - \\frac{g(p)}{p} (p^{-it_1/\\log R_1} + p^{-it_2/\\log R_2} - p^{-it_1/\\log R_1 - it_2/\\log R_2}))")]]

#align(center)[#tao-fit-display[#tao-math("\\ll (2+\\left|t_1\\right|+\\left|t_2\\right|)^{O(1)} \\exp( - \\sum_{p \\leq R_1} \\frac{g(p)}{p} ).", block: true)]]

#text("By Taylor expansion we can bound the left-hand side by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\left|\\exp( - \\sum_{p \\leq CR_1^C} \\frac{g(p)}{p} (p^{-it_1/\\log R_1} + p^{-it_2/\\log R_2} + p^{-it_1/\\log R_1 - it_2/\\log R_2}) )\\right|.", block: true)]]

#text("By Mertens theorem we can replace the constraint ")#mi("{p \\leq CR_1^C}")#text(" with ")#mi("{p \\leq R_1}")#text(". Since ")#mi("{g(p)=O(1)}")#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq R_1} \\frac{1}{p} |p^{-it_1/\\log R_1} + p^{-it_2/\\log R_2} - p^{-it_1/\\log R_1 - it_2/\\log R_2}) - 1|")]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\log( 2 + \\left|t_1\\right|+\\left|t_2\\right| ).", block: true)]]

#text("But we can factor")

#align(center)[#tao-fit-display[#tao-math("\\left|p^{-it_1/\\log R_1} + p^{-it_2/\\log R_2} - p^{-it_1/\\log R_1 - it_2/\\log R_2}) - 1\\right|", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & = \\left|p^{-it_1/\\log R_1}-1\\right| \\left|p^{-it_2/\\log R_1}-1\\right|", block: true)



#tao-math(" & \\ll \\left|p^{-it_1/\\log R_1}-1\\right|", block: true)



#tao-math(" & \\ll \\min( \\left|t_1\\right| \\frac{\\log p}{\\log R_1}, 1 )", block: true)
]

#text("and the claim follows from Mertens’ theorem. ")#mi("\\Box")

#text("We record a basic corollary of this estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 15")]#text(" ")#metadata(none) <tao-39a3ff752eb1dcae49c5>#text(" For any ")#mi("{R \\geq 1}")#text(", we have ")#metadata(none) <tao-f08e135fbd152e16c687>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\sum_{n \\leq x} \\beta_R(n)^2 \\ll \\frac{x}{\\log R}")]]

#text("for any ")#mi("{x \\geq R^5}")#text(", and ")#metadata(none) <tao-1ce24d2d49b744ca0f98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{n \\leq x} \\frac{\\beta_R(n)^2}{n} \\ll 1")]]

#text("for any ")#mi("{x \\ll R^{O(1)}}")#text(".")
]

#emph[#text("Proof:")]#text(" Writing ")#mi("{\\beta_R^2 = \\rho_{R,R}*1}")#text(", we can write the left-hand side of ")#link(<tao-f08e135fbd152e16c687>)[#text("(12)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\rho_{R,R}(d) (\\frac{x}{d} + O(1)).")]]

#text("Since ")#mi("{\\rho_{R,R}(d)}")#text(" is supported on ")#mi("{[1,R^4]}")#text(" and is bounded above by ")#mi("{\\tau(d)^{O(1)}}")#text(", the contribution of the ")#mi("{O(1)}")#text(" error is ")#mi("{O( R^4 \\log^{O(1)} R )}")#text(" which is acceptable. By Lemma ")#link(<tao-a5ad895656074bb12930>)[#text("14")]#text(" with ")#mi("{g=1}")#text(", the contribution of the main term is ")#mi("{O( x \\exp( - \\sum_{p \\leq R} \\frac{1}{p} )}")#text(", and the claim then follows from Mertens’ theorem.")

#text("Now we prove ")#link(<tao-1ce24d2d49b744ca0f98>)[#text("(13)")]#text(". Using Rankin’s trick, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\beta_R(n)^2}{n^{1+1/\\log R}} \\ll 1.")]]

#text("The left-hand side factorises as")

#align(center)[#tao-fit-display[#mitex("\\zeta(1 + \\frac{1}{\\log R}) \\sum_n \\frac{\\rho_{R,R}(n)}{n^{1+1/\\log R}}.")]]

#text("From Lemma ")#link(<tao-a5ad895656074bb12930>)[#text("14")]#text(" with ")#mi("{g(n) := n^{-1/\\log R}}")#text(", we see that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{\\rho_{R,R}(n)}{n^{1+1/\\log R}}  & \\ll \\exp( - \\sum_{p \\leq R} \\frac{1}{p^{1+1/\\log R}} )", block: true)



#tao-math(" & \\ll \\exp( - \\log \\zeta(1 + \\frac{1}{\\log R}) )", block: true)
]

#text("(using Mertens theorem to control the error between ")#mi("{\\log \\zeta(1 + \\frac{1}{\\log R}) = \\sum_p \\frac{1}{p^{1+1/\\log R}} + O(\\frac{1}{p^2})}")#text(" and ")#mi("{\\sum_{p \\leq R} \\frac{1}{p^{1+1/\\log R}}}")#text(") and the claim follows. ")#mi("\\Box")

#text("We will work primarily with the cutoff")

#align(center)[#tao-fit-display[#mitex("\\beta_{T^{10}} \\beta_{T^{100}} = \\rho_{T^{10}, T^{100}} * 1;")]]

#text("the reason for the separate scales ")#mi("{T^{10}}")#text(" and ")#mi("{T^{100}}")#text(" will become clearer later. The function ")#mi("{\\rho}")#text(" is supported on ")#mi("{[1,T^{500}]}")#text(", equals ")#mi("{1}")#text(" at ")#mi("{1}")#text(", and is bounded by ")#mi("{O( \\tau^{O(1)})}")#text(", so from the previous discussion we thus have the zero-detector inequality ")#metadata(none) <tao-52dbd7926f7dfd2f1b3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left|\\sum_{T^{100} \\leq n \\leq T^{1000}} \\beta_{T^{10}} \\beta_{T^{100}}(n) \\frac{\\chi(n)}{n^{\\sigma+it}}\\right| \\gg 1", block: true)]]

#text("whenever ")#mi("{L(\\sigma+it,\\chi)=0}")#text(" with ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(", ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(", and ")#mi("{\\sigma \\geq 1 - O( \\frac{A}{\\log T} )}")#text(". Our objective is to show that the number of such zeroes is ")#mi("{O( \\exp(O(A)))}")#text(".")

#text("We first control the number of zeroes that are very close together. From equation (48) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" with ")#mi("{x = T^2}")#text(" (say), we see that")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi) \\ll \\exp( O( A) ) \\log( q T )")]]

#text("whenever ")#mi("{\\text{Re}(s) \\geq 1 - O( \\frac{A}{\\log T} )}")#text(", ")#mi("{\\text{Im}(s) \\ll T}")#text(", and ")#mi("{\\chi}")#text(" is non-principal of modulus ")#mi("{q}")#text("; also from equation (45) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("1 / L( 1 + \\frac{1}{\\log T}, \\chi ) \\ll \\zeta( 1 + \\frac{1}{\\log T} ) \\ll \\log T.")]]

#text("From Jensen’s theorem (Theorem 16 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), we conclude that for any given non-principal ")#mi("{\\chi}")#text(" and any ")#mi("{t_0 \\in [-T,T]}")#text(", there are at most ")#mi("{O(A)}")#text(" zeroes of ")#mi("{L(\\sigma+it,\\chi)}")#text(" (counting multiplicity, of course) with ")#mi("{\\sigma \\geq 1 - \\frac{A}{\\log T}}")#text(" and ")#tao-math("{\\left|t-t_0\\right| \\leq \\frac{A}{\\log T}}", block: false)#text(". To prove Theorem ")#link(<tao-663cb69f8ed0614a8c44>)[#text("7")]#text(", it thus suffices by the usual covering argument to establish the bound ")#metadata(none) <tao-b42b57bcbabf7dff738e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("J \\ll \\exp( O( A) )")]]

#text("whenever one has a sequence ")#mi("{((\\chi_j, \\sigma_j+ i t_j))_{j=1}^J}")#text(" of zeroes ")#mi("{L( \\sigma_j + it_j, \\chi_j )=0}")#text(" with ")#mi("{\\chi_j}")#text(" a non-principal character of conductor ")#mi("{q}")#text(", ")#tao-math("{\\left|t_j\\right| \\leq T}", block: false)#text(", and ")#mi("{\\sigma_j \\geq 1 - \\frac{A}{\\log T}}")#text(", obeying the separation condition ")#metadata(none) <tao-b97271bb391ada212493>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|t_j - t_{j^{\\prime}}\\right| \\geq \\frac{A}{\\log T} \\text{ whenever } \\chi_j = \\chi_{j^{\\prime}}, j \\neq j^{\\prime}.", block: true)]]

#text("Note from the existing grand zero-density estimate in ")#link(<tao-7a6816dec58eafc68e51>)[#text("(4)")]#text(" that ")#metadata(none) <tao-02227f86e48b229dcece>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("J \\ll \\log^{O(1)} T.")]]

#text("We write ")#link(<tao-52dbd7926f7dfd2f1b3e>)[#text("(14)")]#text(" for the zeroes ")#mi("{L(\\sigma_j + it_j, \\chi_j)=0}")#text(" as ")#metadata(none) <tao-e4d2d0f8d29e943ceee2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|\\sum_n f(n) \\overline{g_j}(n)\\right| \\gg 1", block: true)]]

#text("for all ")#mi("{j=1,\\dots,J}")#text(", where")

#align(center)[#tao-fit-display[#mitex("f(n) := \\frac{1}{n} \\beta_{T^{10}} \\beta_{T^{100}}(n) 1_{T^{100} \\leq n \\leq T^{1000}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("g_j(n) := n^{1-\\sigma_j + it_j} \\overline{\\chi}_j(n) \\psi( \\frac{\\log n}{\\log T} )")]]

#text("and ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a smooth function supported on ")#mi("{[50, 2000]}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{[100, 1000]}")#text(". Note that the ")#mi("{n^{1-\\sigma_j}}")#text(" term in ")#mi("{g_j(n)}")#text(" is ")#mi("{O( \\exp( O(A) ) )}")#text(".")

#text("We use the generalised Bessel inequality (Proposition 2 from ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("Notes 3")]#text(") with ")#mi("{\\nu(n) := \\frac{1}{n} \\beta_{R_1}(n)^2}")#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\sum_n f(n) \\overline{g_j(n)}\\right|^2 \\leq (\\sum_{T^{100} \\leq n \\leq T^{1000}} \\frac{\\beta_{T^{100}}(n)^2}{n} )", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times (\\sum_{1 \\leq j,j^{\\prime} \\leq J} c_j \\overline{c_{j^{\\prime}}} \\sum_n \\frac{\\beta_{T^{10}}(n)^2}{n} g_j(n) \\overline{g_{j^{\\prime}}}(n) )")]]

#text("where ")#mi("{c_1,\\dots,c_J}")#text(" are complex numbers with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(". (Strictly speaking, one needs to deal with the issue that the ")#mi("{g_j, g_{j^{\\prime}}, \\nu}")#text(" are not finitely supported, but there is enough absolute convergence here that this is a routine matter.) From Corollary ")#link(<tao-39a3ff752eb1dcae49c5>)[#text("15")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{T^{100} \\leq n \\leq T^{1000}} \\frac{\\beta_{T^{100}}(n)^2}{n} \\ll 1")]]

#text("(note how the logarithmic factors cancel, which is crucial to obtaining our “log-free” estimate) and so from ")#link(<tao-e4d2d0f8d29e943ceee2>)[#text("(18)")]#text(", the inequality ")#tao-math("{c_j \\overline{c_{j^{\\prime}}} \\ll \\left|c_j\\right|^2 + \\left|c_{j^{\\prime}}\\right|^2}", block: false)#text(" and symmetry it suffices to show that ")#metadata(none) <tao-f9e5ce9baad1cb20da55>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_{j^{\\prime}=1}^J \\left|\\sum_n \\frac{\\beta_{T^{10}}(n)^2}{n} g_j(n) \\overline{g_{j^{\\prime}}}(n)\\right| \\ll \\exp(O(A))", block: true)]]

#text("for all ")#mi("{1 \\leq j \\leq J}")#text(".")

#text("We now estimate the expression ")#metadata(none) <tao-4ea4eaeb87c45b93f931>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_n \\frac{\\beta_{T^{10}}(n)^2}{n} g_j(n) \\overline{g_{j^{\\prime}}}(n).")]]

#text("We expand ")#link(<tao-4ea4eaeb87c45b93f931>)[#text("(20)")]#text(" using ")#link(<tao-224ef06c1b2cb20fc0c9>)[#text("(8)")]#text(" as ")#metadata(none) <tao-70626ea03c9959652cda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_d \\frac{\\rho_{T^{10}, T^{10}}(d)}{d} \\sum_m \\frac{1}{m} g_j(dm) \\overline{g_{j^{\\prime}}(dm)}.")]]

#text("From ")#link(<tao-a68deda73329b42f131f>)[#text("(9)")]#text(", the factor ")#mi("{\\rho_{T^{10},T^{10}}(d)}")#text(" vanishes unless ")#mi("{d \\leq T^{40}}")#text(", and from the support of ")#mi("{g_j}")#text(" we see that the inner sum vanishes unless ")#mi("{T^{50}/d \\leq m \\ll T^{O(1)}}")#text(". From Exercise 44 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", we then have ")#metadata(none) <tao-b6813f3af2d45fbfc768>

#tao-aligned(keep: true)[


#tao-math("\\sum_m \\frac{1}{m} g_j(dm) \\overline{g_{j^{\\prime}}(dm)}  & = 1_{\\chi_j=\\chi_{j^{\\prime}}} \\frac{\\phi(q)}{q} \\int x^{1-\\sigma_j+1-\\sigma_{j^{\\prime}}} x^{i(t_j-t_{j^{\\prime}})} \\psi( \\frac{\\log x}{\\log T} )^2\\ \\frac{dx}{x}", block: true, numbering: n => [#text("(22)")])



#tao-math(" & + O( \\exp( O(A) ) q \\frac{T}{T^{50}/d} ).", block: true)
]

#text("From the upper bound ")#mi("{\\rho_{T^{10}, T^{10}}(d) \\ll \\tau^{O(1)} d 1_{d \\leq T^{40}}}")#text(" we have ")#metadata(none) <tao-a4130d7d2c3a137f362d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\sum_d \\frac{\\left|\\rho_{T^{10}, T^{10}}(d)\\right|}{d} \\ll \\log^{O(1)} T,", block: true)]]

#text("so we see from ")#link(<tao-02227f86e48b229dcece>)[#text("(17)")]#text(" and ")#link(<tao-89283e09afdbe2ffd8a6>)[#text("(6)")]#text(" that the contribution of the error term ")#mi("{O( \\exp( O(A) ) q \\frac{T}{T^{50}/d} )}")#text(" to ")#link(<tao-f9e5ce9baad1cb20da55>)[#text("(19)")]#text(" is acceptable. For the main term in ")#link(<tao-b6813f3af2d45fbfc768>)[#text("(22)")]#text(", we see from Corollary ")#link(<tao-39a3ff752eb1dcae49c5>)[#text("15")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\frac{\\rho_{T^{10},T^{10}}(d)}{d} \\ll \\frac{1}{\\log T}")]]

#text("so (as the main term in ")#link(<tao-b6813f3af2d45fbfc768>)[#text("(22)")]#text(" is independent of ")#mi("{d}")#text(") the remaining contribution to ")#link(<tao-f9e5ce9baad1cb20da55>)[#text("(19)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{1}{\\log T} \\sum_{j^{\\prime}: \\chi_j = \\chi_{j^{\\prime}}} |\\int x^{1-\\sigma_j+1-\\sigma_{j^{\\prime}}} x^{i(t_j-t_{j^{\\prime}})} \\psi( \\frac{\\log x}{\\log T} )^2\\ \\frac{dx}{x}|.")]]

#text("Making the change of variables ")#mi("{x=\\exp(y \\log T)}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("\\sum_{j^{\\prime}: \\chi_j = \\chi_{j^{\\prime}}} |\\int e^{y(1-\\sigma_j+1-\\sigma_{j^{\\prime}}) \\log T} e^{iy (t_j-t_{j^{\\prime}}) \\log T} \\psi( y )^2\\ \\ dy|.")]]

#text("The integral is bounded by ")#mi("{\\exp(O(A))}")#text(", and from two integration by parts it is also bounded by")

#align(center)[#tao-fit-display[#tao-math("\\exp(O(A)) \\frac{1}{(\\left|t_j-t_{j^{\\prime}}\\right| \\log T)^2}.", block: true)]]

#text("On the other hand, for ")#mi("{\\chi_j = \\chi_{j^{\\prime}}}")#text(", the ")#mi("{t_{j^{\\prime}}}")#text(" are ")#mi("{\\frac{A}{\\log T}}")#text("-separated by hypothesis, and so")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j^{\\prime}: \\chi_j = \\chi_{j^{\\prime}}} \\min( 1, \\frac{1}{(\\left|t_j-t_{j^{\\prime}}\\right| \\log T)^2} ) \\ll 1,", block: true)]]

#text("and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. Consequences of an exceptional zero — ")]]

#text("In preparation for proving Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(", we investigate in this section the consequences of a Landau-Siegel zero, that is to say a real character ")#mi("{\\chi_1}")#text(" of some modulus ")#mi("{q \\geq 2}")#text(" with a zero")

#align(center)[#tao-fit-display[#mitex("L(\\beta,\\chi_1) = 0")]]

#text("for some ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" with ")#mi("{\\varepsilon>0}")#text(" small. For minor technical reasons we will assume that ")#mi("{q}")#text(" is a multiple of ")#mi("{6}")#text(", so that ")#mi("{\\chi_1(2) = \\chi_1(3) = 0}")#text("; this condition can be easily established by multiplying ")#mi("{\\chi}")#text(" by a principal character of modulus dividing ")#mi("{6}")#text(". (We will not need to assume here that ")#mi("{\\chi_1}")#text(" is primitive.)")

#text("In ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", we already observed that the presence of an exceptional zero was associated with a small (but positive) value of ")#mi("{L(1,\\chi_1)}")#text("; indeed, from Lemmas 57 and 59 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" we see that ")#metadata(none) <tao-4945a70fa7f9c13fe193>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\frac{\\varepsilon}{\\log q} \\ll L(1,\\chi_1) \\ll \\varepsilon \\log q.")]]

#text("Also, from the class number formula (equation (56) from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") we have ")#metadata(none) <tao-2804bad6fe94a55f18b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("L(1,\\chi_1) \\gg q^{-1/2} \\log^{-O(1)} q")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\varepsilon \\gg q^{-1/2} \\log^{-O(1)} q.")]]

#text("For the arguments below, one could also use the slightly weaker estimates in Exercise 67 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" or Exercise 57 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Notes 3")]#text(" and still obtain comparable results. We will however ")#emph[#text("not")]#text(" rely on Siegel’s theorem (Theorem 62 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") in order to keep all bounds effective.")

#text("We now refine this analysis. We begin with a complexified version of Exercise 58 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{\\chi_1}")#text(" be a non-principal character of modulus ")#mi("{q \\geq 2}")#text(". Let ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\frac{1}{2} \\leq \\sigma < 1}")#text(" and ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" for some ")#mi("{T \\geq 2}")#text(". Show that ")#metadata(none) <tao-6558838331b742a6f1d5>

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\frac{1*\\chi_1(n)}{n^s}  & = \\zeta(s) L(s,\\chi_1) + \\frac{x^{1-s}}{1-s} L(1,\\chi_1)", block: true, numbering: n => [#text("(26)")])



#tao-math(" & + O( (qT)^2 x^{-1/2} \\frac{x^{1-\\sigma}}{1-\\sigma} )", block: true)
]

#text("for any ")#mi("{x \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" use the Dirichlet hyperbola method and Exercise 44 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(".)")

#text("If ")#mi("{\\chi}")#text(" is a non-principal character of modulus ")#mi("{q}")#text(" with ")#mi("{\\chi \\neq \\chi_1}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{1*\\chi_1(n) \\chi(n)}{n^s} = L(s,\\chi) L(s,\\chi \\chi_1) + O( (qT)^2 x^{-1/2} \\frac{x^{1-\\sigma}}{1-\\sigma} ).")]]
]

#text("For technical reasons it will be convenient to work with a completely multiplicative variant of the function ")#mi("{1*\\chi_1}")#text(". Define the arithmetic function ")#mi("{g: {\\bf N} \\rightarrow {\\bf R}}")#text(" to be the completely multiplicative function such that ")#mi("{g(p) = 1 + \\chi_1(p)}")#text(" for all ")#mi("{p}")#text("; this is equal to ")#mi("{1*\\chi}")#text(" at square-free numbers, but is a bit larger at other numbers. Observe that ")#mi("{g}")#text(" is non-negative, and has the factorisation")

#align(center)[#tao-fit-display[#mitex("g = 1 * \\chi_1 * h")]]

#text("where ")#mi("{h = g * \\mu * \\chi_1 \\mu}")#text(" is a multiplicative function that vanishes on primes and obeys the bounds")

#align(center)[#tao-fit-display[#mitex("0 \\leq h(p^j) = (1+\\chi_1(p))^{j-2} \\chi_1(p) \\leq 2^{j-2}")]]

#text("for all ")#mi("{j \\geq 2}")#text(" and primes ")#mi("{p}")#text(". In particular ")#mi("{h}")#text(" is non-negative and ")#mi("{h(p^j)=0}")#text(" for ")#mi("{p=2,3}")#text(", since we assumed ")#mi("{\\chi_1(2)=\\chi_1(3)=0}")#text(". From Euler products we see that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{h(n)}{n^{\\frac{1}{2}+\\varepsilon}}  & = \\prod_p \\sum_{j=0}^\\infty \\frac{h(p^j)}{p^{j (\\frac{1}{2}+\\varepsilon)}}", block: true)



#tao-math(" & \\leq \\prod_{p \\geq 5} 1 + \\sum_{j=2}^\\infty \\frac{2^{j-2}}{p^{j (\\frac{1}{2}+\\varepsilon)}}", block: true)



#tao-math(" & \\ll_\\varepsilon 1", block: true)
]

#text("for any ")#mi("{\\varepsilon>0}")#text(", so in particular the Dirichlet series ")#mi("{{\\mathcal D} h(s) := \\sum_n \\frac{h(n)}{n^s}}")#text(" is analytic and uniformly bounded on ")#mi("{\\text{Re}(s)>1/2+\\varepsilon}")#text(". (The constraint ")#mi("{p \\geq 5}")#text(" is needed to ensure convergence of the geometric series.) This implies that ")#metadata(none) <tao-8693873cd8f8a2d9c7c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("1 \\leq {\\mathcal D} h(1) \\ll 1")]]

#text("and also that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{h(n)}{n^s} = {\\mathcal D} h(s) + O_\\varepsilon( x^{1/2-\\sigma+\\varepsilon} )")]]

#text("whenever ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{\\sigma \\geq 1/2+\\varepsilon}")#text(".")

#text("Taking Dirichlet series, we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{g(n)}{n^s} = \\zeta(s) L(s,\\chi_1) {\\mathcal D} h(s)")]]

#text("whenever ")#mi("{\\text{Re}(s) > 1}")#text("; more generally, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{g(n)\\chi(n)}{n^s} = L(s,\\chi) L(s,\\chi\\chi_1) {\\mathcal D}(\\chi h)(s)")]]

#text("for any character ")#mi("{\\chi}")#text(". Now we look at what happens inside the critical strip:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{\\chi_1}")#text(" be a real character of modulus ")#mi("{q}")#text(" a multiple of ")#mi("{6}")#text(", and let ")#mi("{g}")#text(" be as above. Let ")#mi("{s = \\sigma+it}")#text(" with ")#mi("{3/4 \\leq \\sigma < 1}")#text(" and ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(" for some ")#mi("{T \\geq 2}")#text(". Show that ")#metadata(none) <tao-ce48278629c48935b8a6>

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\frac{g(n)}{n^s}  & = \\zeta(s) L(s,\\chi_1) {\\mathcal D} h(s) + \\frac{x^{1-s}}{1-s} L(1,\\chi_1) {\\mathcal D} h(1)", block: true, numbering: n => [#text("(28)")])



#tao-math(" & + O_\\varepsilon( (qT)^2 x^{-1/4+\\varepsilon} \\frac{x^{1-\\sigma}}{1-\\sigma} )", block: true)
]

#text("for any ")#mi("{x \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(".")

#text("If ")#mi("{\\chi}")#text(" is a non-principal character of modulus ")#mi("{q}")#text(" with ")#mi("{\\chi \\neq \\chi_1}")#text(", show that ")#metadata(none) <tao-90f0a5ee800a5c29575a>

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq x} \\frac{g(n) \\chi(n)}{n^s}  & = L(s,\\chi) L(s,\\chi \\chi_1) {\\mathcal D}(\\chi h)(s)", block: true, numbering: n => [#text("(29)")])



#tao-math(" & + O( (qT)^2 x^{-1/4+\\varepsilon} \\frac{x^{1-\\sigma}}{1-\\sigma} )", block: true)
]

#text("for any ")#mi("{x \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(".")
]

#text("We record a nice corollary of these estimates ")#link("http://www.ams.org/mathscinet-getitem?mr=371840")[#text("due to Bombieri")]#text(", which asserts that the exceptional zero forces ")#mi("{g}")#text(" to vanish (or equivalently, ")#mi("{\\chi_1(p)}")#text(" to become ")#mi("{-1}")#text(") on most large primes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Bombieri’s lemma)")]#text(" ")#metadata(none) <tao-eb0afd90509c50678e29>#text(" Let ")#mi("{\\chi_1}")#text(" be a real character of modulus ")#mi("{q}")#text(" with an exceptional zero at ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" for some sufficiently small ")#mi("{\\varepsilon>0}")#text(". Then for any ")#mi("{x \\gg q^{20}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < p \\leq x^2} \\frac{1+\\chi_1(p)}{p} \\ll \\varepsilon \\frac{\\log x}{\\log q}.")]]
]

#text("Informally, Bombieri’s lemma asserts that ")#mi("{\\chi_1(p)=-1}")#text(" for most primes between ")#mi("{q^{20}}")#text(" and ")#mi("{q^{1/\\varepsilon}}")#text(". The exponent of ")#mi("{20}")#text(" here can be lowered substantially with a more careful analysis, but we will not do so here. For primes much larger than ")#mi("{q^{1/\\varepsilon}}")#text(", ")#mi("{\\chi_1}")#text(" becomes equidistributed; see Exercise ")#link(<tao-091e606752615c91da70>)[#text("24")]#text(" below.")

#emph[#text("Proof:")]#text(" Without loss of generality we may take ")#mi("{q}")#text(" to be a multiple of ")#mi("{6}")#text(". We may assume that ")#mi("{\\varepsilon \\frac{\\log x}{\\log q} \\leq 1}")#text(", as the claim follows from Mertens’ theorem otherwise; in particular ")#mi("{x^{1-\\beta} \\ll 1}")#text(".")

#text("By ")#link(<tao-ce48278629c48935b8a6>)[#text("(28)")]#text(" for ")#mi("{s=\\beta}")#text(" we have ")#metadata(none) <tao-54bca8d2372c18649c81>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{n \\leq x} \\frac{g(n)}{n^\\beta} = \\frac{x^{1-\\beta}}{1-\\beta} ( L(1,\\chi_1) {\\mathcal D} h(1) + O( q^2 x^{-1/4} ) )")]]

#text("for any ")#mi("{x \\geq 1}")#text(". Since ")#mi("{{\\mathcal D} h(1) \\geq 1}")#text(" and ")#mi("{x \\geq q^{20}}")#text(", we see from ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(25)")]#text(", ")#link(<tao-8693873cd8f8a2d9c7c5>)[#text("(27)")]#text(" that the error term is dominated by the main term, thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{g(n)}{n^\\beta} \\gg \\frac{x^{1-\\beta}}{1-\\beta} L(1,\\chi_1) {\\mathcal D} h(1).")]]

#text("Next, applying ")#link(<tao-54bca8d2372c18649c81>)[#text("(30)")]#text(" with ")#mi("{x}")#text(" replaced by ")#mi("{x^3}")#text(" and subtracting, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < n \\leq x^3} \\frac{g(n)}{n^\\beta} = \\frac{x^{1-\\beta}}{1-\\beta} ( (x^{2(1-\\beta)}-1) L(1,\\chi_1) {\\mathcal D} h(1) + O( q^2 x^{-1/4} ) ).")]]

#text("As ")#mi("{x^{1-\\beta} \\ll 1}")#text(", we have ")#mi("{x^{2(1-\\beta)}-1 \\ll \\varepsilon \\frac{\\log x}{\\log q}}")#text(" by Taylor expansion. As before, the error term can be bounded by the main term and so")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < n \\leq x^3} \\frac{g(n)}{n^\\beta} \\ll \\varepsilon \\frac{\\log x}{\\log q} \\frac{x^{1-\\beta}}{1-\\beta} L(1,\\chi_1) {\\mathcal D} h(1).")]]

#text("Since ")#mi("{g}")#text(" is non-negative and completely multiplicative, one has")

#align(center)[#tao-fit-display[#mitex("(\\sum_{n \\leq x} \\frac{g(n)}{n^\\beta}) \\times (\\sum_{x < p \\leq x^2} \\frac{g(p)}{p^\\beta}) \\leq \\sum_{x < n \\leq x^3} \\frac{g(n)}{n^\\beta}")]]

#text("and thus (since ")#mi("{g(p)=1+\\chi_1(p)}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{x < p \\leq x^2} \\frac{1+\\chi_1(p)}{p^\\beta} \\ll \\varepsilon \\frac{\\log x}{\\log q}.")]]

#text("Since ")#mi("{x^{1-\\beta} \\ll 1}")#text(", we have ")#mi("{\\frac{1}{p} \\ll \\frac{1}{p^\\beta}}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" With the hypotheses of Bombieri’s lemma, show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{q^{20/k} < p \\leq q^{20}} \\frac{1+\\chi_1(p)}{p} \\ll_k \\varepsilon^{1/k}")]]

#text("for any natural number ")#mi("{k}")#text(".")
]

#text("Now we can give a more precise version of ")#link(<tao-4945a70fa7f9c13fe193>)[#text("(24)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 20")]#text(" ")#metadata(none) <tao-b9ae0309808fc250ffbd>#text(" Let ")#mi("{\\chi_1}")#text(" be a real character of modulus ")#mi("{q}")#text(" with an exceptional zero at ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" for some sufficiently small ")#mi("{\\varepsilon>0}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi_1) \\asymp \\frac{\\varepsilon}{\\log q} \\exp( \\sum_{p \\leq T} \\frac{1+\\chi_1(p)}{p} )")]]

#text("for any ")#mi("{T \\geq 1}")#text(" with ")#mi("{\\log q \\ll \\log T \\ll \\frac{\\log q}{\\varepsilon}}")#text(".")
]

#text("Observe that ")#link(<tao-4945a70fa7f9c13fe193>)[#text("(24)")]#text(" is a corollary of the ")#mi("{T=q}")#text(" case of this proposition thanks to Mertens’ theorem and the trivial bounds ")#mi("{0 \\leq 1+\\chi_1(p) \\leq 2}")#text(". We thus see from this proposition and Bombieri’s lemma that the exceptional zero ")#mi("{\\beta}")#text(" controls ")#mi("{\\chi_1}")#text(" at primes larger than ")#mi("{q^{20}}")#text(", but that ")#mi("{L(1,\\chi)}")#text(" is additionally sensitive to the values of ")#mi("{\\chi_1}")#text(" at primes below this range. For an even more precise formula for ")#mi("{L(1,\\chi)}")#text(", see ")#link("http://www.ams.org/mathscinet-getitem?mr=404213")[#text("this paper of Goldfeld and Schinzel")]#text(", or Exercise ")#link(<tao-84fe8ac08da07a414056>)[#text("25")]#text(" below.")

#emph[#text("Proof:")]#text(" By Bombieri’s lemma and Mertens’ theorem, it suffices to prove the asymptotic for ")#mi("{T=q}")#text(".")

#text("We begin with the upper bound")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi_1) \\ll \\frac{\\varepsilon}{\\log q} \\exp( \\sum_{p \\leq q} \\frac{1+\\chi_1(p)}{p} ).")]]

#text("Applying ")#link(<tao-6558838331b742a6f1d5>)[#text("(26)")]#text(" with ")#mi("{s = 1 + \\frac{\\varepsilon}{\\log q}}")#text(" and ")#mi("{x=q^{10}}")#text(" we have ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_{n \\leq q^{10}} \\frac{1*\\chi_1(n)}{n^s} = \\zeta(s) L(s,\\chi_1) - \\frac{\\exp(-10\\varepsilon)}{s-1} ( L(1,\\chi_1) + O( q^{-3} ) ).")]]

#text("The left-hand side is non-negative and ")#mi("{\\zeta(s) \\gg \\frac{1}{s-1}}")#text(", so we conclude (using ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(25)")]#text(") that")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi_1) \\ll L(s,\\chi_1).")]]

#text("From Euler products and Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi_1) \\asymp \\exp( \\sum_p \\frac{\\chi_1(p)}{p^{1+\\varepsilon/\\log q}} )")]]

#align(center)[#tao-fit-display[#mitex("\\asymp \\frac{\\varepsilon}{\\log T} \\exp( \\sum_p \\frac{1+\\chi_1(p)}{p^{1+\\varepsilon/\\log q}} ).")]]

#text("But from Lemma ")#link(<tao-eb0afd90509c50678e29>)[#text("18")]#text(" and Mertens’ theorem we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{1+\\chi_1(p)}{p^{1+\\varepsilon/\\log q}} = \\sum_{p \\leq q} \\frac{g(p)}{p} + O(1)")]]

#text("and the claim follows.")

#text("Now we establish the matching lower bound")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi_1) \\gg \\frac{\\varepsilon}{\\log q} \\exp( \\sum_{p \\leq q} \\frac{1+\\chi_1(p)}{p} ).")]]

#text("Applying ")#link(<tao-6558838331b742a6f1d5>)[#text("(26)")]#text(" with ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" and ")#mi("{x=q^{10}}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq q^{10}} \\frac{1*\\chi_1(n)}{n^\\beta} = \\frac{\\exp(10\\varepsilon)}{1-\\beta} ( L(1,\\chi_1) + O( q^{-3} ) ).")]]

#text("For ")#mi("{n \\leq q^{10}}")#text(", we have ")#mi("{\\frac{1}{n^\\beta} \\ll \\frac{1}{n^s}}")#text(", and thus by ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(25)")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq q^{10}} \\frac{1*\\chi_1(n)}{n^s} \\ll \\frac{1}{s-1} L(1,\\chi_1).")]]

#text("Inserting this into ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("(31)")]#text(" and using ")#link(<tao-2804bad6fe94a55f18b2>)[#text("(25)")]#text(" and ")#mi("{\\zeta(s) \\ll \\frac{1}{s-1}}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("L(s,\\chi_1) \\ll L(1,\\chi_1)")]]

#text("and the claim then follows from the preceding calculations. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" One particularly striking consequence of an exceptional zero ")#mi("{L(\\beta,\\chi_1)}")#text(" is that the spacing of zeroes of other ")#mi("{L}")#text("-functions become extremely regular; roughly speaking, for most other characters ")#mi("{\\chi}")#text(" whose conductor ")#mi("{q}")#text(" is somewhat (but not too much) larger than the conductor ")#mi("{q_1}")#text(" of ")#mi("{\\chi_1}")#text(", the zeroes of ")#mi("{L(s,\\chi) L(s,\\chi\\chi_1)}")#text(" (at moderate height) mostly lie on the critical line and are spaced in approximate arithmetic progression; this “alternative hypothesis” is in contradiction to to the pair correlation conjecture discussed in Section 4 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(". This phenomenon was first discovered ")#link("http://www.ams.org/mathscinet-getitem?mr=357373")[#text("by Montgomery and Weinberger")]#text(" and can roughly be explained as follows. By an approximate functional equation similar to Exercise 54 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(", one can approximately write ")#mi("{L(s,\\chi) L(s,\\chi_1)}")#text(" as the sum of ")#mi("{\\sum_{n \\lessapprox \\sqrt{qq_1}} \\frac{\\chi (1*\\chi_1)(n)}{n^s}}")#text(" plus ")#mi("{\\sum_{n \\lessapprox \\sqrt{qq_1}} \\frac{\\bar{\\chi} (1*\\chi_1)(n)}{n^{1-s}}}")#text(" times a gamma factor which oscillates like ")#tao-math("{(q\\left|t\\right|)^{it}}", block: false)#text(" when ")#mi("{s = 1/2+it}")#text(". The smallness of ")#mi("{1*\\chi_1(n)}")#text(" on average for medium-sized ")#mi("{n}")#text(" (as suggested for instance by Bombieri’s lemma) suggests that these sums should be well approximated by much shorter sums, which oscillate quite slowly in ")#mi("{t}")#text(". This gives an approximation to ")#mi("{L(1/2+it,\\chi) L(1/2+it,\\chi_1)}")#text(" that is of the form ")#tao-math("{F(t) + (q\\left|t\\right|)^{it} G(t)}", block: false)#text(" for slowly varying ")#mi("{F,G}")#text(", which can then be used to place the zeroes of this function in approximate arithmetic progression on the real line.")
]

#heading(level: 1)[#strong[#text(" — 3. The Deuring-Heilbronn repulsion phenomenon — ")]]

#text("We now prove Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(". Let ")#mi("{q \\geq 2}")#text(" be such that there is an exceptional zero ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" with ")#mi("{\\varepsilon}")#text(" small, associated to some quadratic character ")#mi("{\\chi_1}")#text(" of modulus ")#mi("{q}")#text(":")

#align(center)[#tao-fit-display[#mitex("L( \\beta, \\chi_1 ) = 0.")]]

#text("From the class number bound (equation (56) of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("; one could also use Exercise 67 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" for a similar bound) we have ")#metadata(none) <tao-ef0b228fd6b3f7269bf8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("L(1,\\chi_1) \\gg q^{-1/2} \\log^{-O(1)} q")]]

#text("and ")#metadata(none) <tao-e1fd6c028c076f1cda5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\frac{1}{\\varepsilon} \\ll q^{1/2} \\log^{O(1)} q.")]]

#text("Let ")#mi("{T \\geq 2}")#text(", let ")#mi("{\\chi}")#text(" be a character of modulus ")#mi("{q}")#text(" (possibly equal to ")#mi("{\\chi_1}")#text(" or the principal character), and suppose we have ")#metadata(none) <tao-507a9a8be3d145a86daa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("L( \\sigma+it, \\chi ) = 0")]]

#text("for some ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(", with ")#mi("{\\sigma+it \\neq \\beta}")#text(". Our task is to show that ")#metadata(none) <tao-b737ca7ee563ae80e457>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("1 - \\sigma \\gg \\log\\frac{1}{\\varepsilon} \\frac{1}{\\log(qT)}.")]]

#text("We may assume that ")#metadata(none) <tao-36278cfc06c54f7d47b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\sigma > 0.99")]]

#text("(say), since the claim is trivial otherwise. By multiplying by the principal character of modulus ")#mi("{6}")#text(" if necessary, we may assume as before that ")#mi("{q}")#text(" is a multiple of ")#mi("{6}")#text(", so that we can utilise the multiplicative function ")#mi("{g}")#text(" from the previous section. By enlarging ")#mi("{T}")#text(", we may assume as in Section ")#link(<tao-836ff184e7b41b1e13cb>)[#text("1")]#text(" that ")#metadata(none) <tao-792cc6267588b21829ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("T \\geq q^{10};")]]

#text("we may also assume that ")#mi("{T}")#text(" is larger than any specified absolute constant. From the classical zero-free region and the Landau-Page theorem we have ")#metadata(none) <tao-fe06cd4412d898686101>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("1-\\sigma \\gg \\frac{1}{\\log T}.")]]

#text("The task ")#link(<tao-b737ca7ee563ae80e457>)[#text("(35)")]#text(" is then equivalent to showing that ")#metadata(none) <tao-74a5371b60650cf4a751>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("T^{1-\\sigma} \\gg \\varepsilon^{-c}")]]

#text("for some absolute constant ")#mi("{c>0}")#text(".")

#text("We recall the sieve cutoffs")

#align(center)[#tao-fit-display[#mitex("\\beta_R(n) = \\sum_{d|n} \\mu(d) f( \\frac{\\log d}{\\log R} )")]]

#text("from Section ")#link(<tao-836ff184e7b41b1e13cb>)[#text("1")]#text(", which were used in the zero detector. The main difference is that we will “twist” the polynomial by the completely multiplicative function ")#mi("{g}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 22 (Zero-detecting polynomial)")]#text(" Let the notation and assumptions be as above.")

#list(
[#text("(i) If ")#mi("{\\chi}")#text(" is not equal to ")#mi("{\\chi_1}")#text(" or the principal character, then")

#metadata(none) <tao-4eaae75f1df2f52bda44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#tao-math("\\left|\\sum_{T^{100} \\leq n \\leq T^{1000}} \\beta_{T^{10}}(n) \\beta_{T^{100}}(n) \\frac{g(n) \\chi(n)}{n^s}\\right| \\gg 1.", block: true)]]],
[#text("(ii) If ")#mi("{\\chi}")#text(" is equal to ")#mi("{\\chi_1}")#text(" or the principal character, then")

#metadata(none) <tao-89405f34849adc70cd38>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#tao-math("\\left|\\sum_{T^{100} \\leq n \\leq T^{1000}} \\beta_{T^{10}}(n) \\beta_{T^{100}}(n) \\frac{g(n)}{n^s}\\right| \\gg 1 - O( \\varepsilon T^{O(1-\\sigma)} ).", block: true)]]]
)
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{\\chi}")#text(" is not equal to ")#mi("{\\chi_1}")#text(" or the principal character. Since ")#mi("{L(s,\\chi)=0}")#text(", we see from ")#link(<tao-90f0a5ee800a5c29575a>)[#text("(29)")]#text(", ")#link(<tao-792cc6267588b21829ea>)[#text("(37)")]#text(", ")#link(<tao-36278cfc06c54f7d47b9>)[#text("(36)")]#text(", ")#link(<tao-fe06cd4412d898686101>)[#text("(38)")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{g(n) \\chi(n)}{n^s} \\ll T^{-10}")]]

#text("(say) for any ")#mi("{T^{500} \\leq x \\leq T^{1000}}")#text(". In particular, as ")#mi("{\\rho}")#text(" is supported on ")#mi("{[1,T^{500}]}")#text(" and one has ")#mi("{\\rho(n) g(n)=n^{o(1)}}")#text(" from the divisor bound, one has")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq T^{1000}} (\\rho*1)(n) \\frac{g(n) \\chi(n)}{n^s}  & \\ll \\sum_{d \\leq T^{500}} \\frac{\\left|\\rho(d) g(d)\\right|}{d^\\sigma} T^{-10}", block: true)



#tao-math(" & \\ll T^{-1}", block: true)
]

#text("(say), thanks to ")#link(<tao-36278cfc06c54f7d47b9>)[#text("(36)")]#text(". Since ")#mi("{\\rho*1(n) = \\beta_{T^{10}} \\beta_{T^{100}}(n)}")#text(" equals ")#mi("{1_{n=1}}")#text(" for ")#mi("{n < T^{100}}")#text(", we thus conclude ")#link(<tao-4eaae75f1df2f52bda44>)[#text("(40)")]#text(" since ")#mi("{T}")#text(" is assumed to be large.")

#text("Now suppose that ")#mi("{\\chi}")#text(" is ")#mi("{\\chi_1}")#text(" or the principal character, so that ")#mi("{\\zeta(s) L(s,\\chi)=0}")#text(". From ")#link(<tao-ce48278629c48935b8a6>)[#text("(28)")]#text(", ")#link(<tao-792cc6267588b21829ea>)[#text("(37)")]#text(", ")#link(<tao-36278cfc06c54f7d47b9>)[#text("(36)")]#text(", ")#link(<tao-fe06cd4412d898686101>)[#text("(38)")]#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\frac{g(n)}{n^s} = \\frac{x^{1-s}}{1-s} L(1,\\chi) {\\mathcal D} h(1) + O( T^{-10} )")]]

#text("for ")#mi("{T^{500} \\leq x \\leq T^{1000}}")#text(". By a similar calculation to before, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq T^{1000}} (\\rho*1)(n) \\frac{g(n)}{n^s}")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\sum_d \\frac{\\rho(d) g(d)}{d^s} \\frac{(T^{1000}/d)^{1-s}}{1-s} L(1,\\chi) {\\mathcal D} h(1) + O( T^{-1} )", block: true)



#tao-math(" & = \\frac{T^{1000(1-s)}}{1-s} {\\mathcal D} h(1) L(1,\\chi) \\sum_d \\frac{\\rho(d) g(d)}{d} + O( T^{-1} )", block: true)



#tao-math(" & \\ll T^{O(1-s)} \\varepsilon \\exp\\left( \\sum_{p \\leq T} \\frac{g(p)}{p} \\right) \\left|\\sum_d \\frac{\\rho(d) g(d)}{d}\\right| + T^{-1}", block: true)
]

#text("where we have used ")#link(<tao-fe06cd4412d898686101>)[#text("(38)")]#text(" and Proposition ")#link(<tao-b9ae0309808fc250ffbd>)[#text("20")]#text(" in the last line. The claim ")#link(<tao-89405f34849adc70cd38>)[#text("(41)")]#text(" then follows from Lemma ")#link(<tao-a5ad895656074bb12930>)[#text("14")]#text(". ")#mi("\\Box")

#text("Using the estimates from the previous section, we can establish the following bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23")]#text(" ")#metadata(none) <tao-cb5ae32cbd84a47c77ab>#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{T^{100} \\leq n \\leq T^{1000}} \\left|\\beta_{T^{10}}(n)\\right| \\left|\\beta_{T^{100}}(n)\\right| \\frac{g(n)}{n} \\ll \\varepsilon^{1/2}.", block: true)]]
]

#text("The point here is that the sieve weights ")#mi("{\\beta_{T^{10}}}")#text(" and ")#mi("{\\beta_{T^{100}}}")#text(" are morally restricting to almost primes, and that ")#mi("{g}")#text(" should be small on such numbers by Bombieri’s lemma. Assuming this proposition, we conclude that the left-hand sides of ")#link(<tao-4eaae75f1df2f52bda44>)[#text("(40)")]#text(" or ")#link(<tao-89405f34849adc70cd38>)[#text("(41)")]#text(" are ")#mi("{O( \\varepsilon^{1/2} T^{O(1-\\sigma)})}")#text(", and ")#link(<tao-74a5371b60650cf4a751>)[#text("(39)")]#text(" follows.")

#emph[#text("Proof:")]#text(" By the Cauchy-Schwarz inequality it suffices to show that ")#metadata(none) <tao-b11e23303e7d8bc69ecf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("\\sum_{T^{100} \\leq n \\leq T^{1000}} \\beta_{T^{10}}(n)^2 \\frac{g(n)}{n} \\ll \\varepsilon")]]

#text("and ")#metadata(none) <tao-e8d0d04fea35d6890558>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("\\sum_{T^{100} \\leq n \\leq T^{1000}} \\beta_{T^{100}}(n)^2 \\frac{g(n)}{n} \\ll 1.")]]

#text("We begin with the second bound ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(42)")]#text(", which we establish by quite crude estimates. By a Fourier expansion we can write ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#mitex("f(u) = \\int_{\\bf R} e^{-itu} F(t)\\ dt")]]

#text("for some rapidly decreasing function ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(", and thus ")#metadata(none) <tao-653ff637d0ac98dfe5cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#mitex("\\beta_R(n) = \\int_{\\bf R} \\sum_{d|n} \\mu(d) d^{-it/\\log R} F(t)\\ dt")]]

#text("which factorises as")

#align(center)[#tao-fit-display[#mitex("\\beta_R(n) = \\int_{\\bf R} \\prod_{p|n} (1 - p^{-it/\\log R}) F(t)\\ dt.")]]

#text("Bounding ")#mi("{1 - p^{-it/\\log R} \\ll \\min( t \\frac{\\log p}{\\log R}, 1 )}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\beta_R(n) \\ll_A \\int_{\\bf R} \\prod_{p|n} O( \\min( t \\frac{\\log p}{\\log R}, 1 ) ) (1+\\left|t\\right|)^{-A}\\ dt", block: true)]]

#text("for any ")#mi("{A}")#text(". Squaring and using Cauchy-Schwarz, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\beta_R(n)^2 \\ll_A \\int_{\\bf R} \\prod_{p|n} O( \\min( t \\frac{\\log p}{\\log R}, 1 )^2 ) (1+\\left|t\\right|)^{-A}\\ dt", block: true)]]

#text("for any ")#mi("{A}")#text(". In particular, for ")#mi("{n \\leq T^{1000}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\beta_{T^{100}}(n)^2 \\frac{g(n)}{n} \\ll_A \\int_{\\bf R} \\prod_{p \\leq T^{1000}: p|n} \\frac{2^{\\text{ord}_p(n)}}{p^{\\text{ord}_p(n)}} O( \\min( t \\frac{\\log p}{\\log T}, 1 )^2 ) (1+\\left|t\\right|)^{-A}\\ dt,", block: true)]]

#text("and so we can bound the left-hand side of ")#link(<tao-e8d0d04fea35d6890558>)[#text("(43)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\ll_A \\int_{\\bf R} \\prod_{p \\leq T^{1000}} (1 + O( \\frac{\\min( t \\frac{\\log p}{\\log T}, 1 )}{p} )) (1+\\left|t\\right|)^{-A}\\ dt,", block: true)]]

#text("which we bound by")

#align(center)[#tao-fit-display[#tao-math("\\ll_A \\int_{\\bf R} \\exp( \\sum_{p \\leq T^{1000}} O( \\frac{\\min( t \\frac{\\log p}{\\log T}, 1 )}{p} ) ) (1+\\left|t\\right|)^{-A}\\ dt.", block: true)]]

#text("By Mertens’ theorem we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq T^{1000}} \\frac{\\min( t \\frac{\\log p}{\\log T}, 1 )}{p} \\ll \\log(2+\\left|t\\right|),", block: true)]]

#text("and the claim follows by taking ")#mi("{A}")#text(" large enough.")

#text("Now we establish ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("(42)")]#text(". By dyadic decomposition it suffices to show that ")#metadata(none) <tao-653b325a1011f481c4a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("\\sum_{n \\leq x} \\beta_{T^{10}}(n)^2 g(n) \\ll \\frac{\\varepsilon}{\\log T} x")]]

#text("for all ")#mi("{T^{100} \\leq x \\leq T^{1000}}")#text(". The left-hand side may be written as as")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\rho_{T^{10},T^{10}}(d) g(d) \\sum_{n \\leq x/d} g(n).")]]

#text("From the hyperbola method we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq y} 1*\\chi(n) = L(1,\\chi) y + O( q y^{1/2} )")]]

#text("for any ")#mi("{y \\geq 1}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x/d} g(n) = L(1,\\chi) \\frac{x}{d} {\\mathcal D} h(1) + O( q x^{1/2} d^{-1/2} ).")]]

#text("Since ")#mi("{\\rho_{T^{10},T^{10}}(d)}")#text(" is supported on ")#mi("{[0,T^{40}]}")#text(" and is bounded by ")#mi("{\\tau(d)^{O(1)}}")#text(", the contribution of the ")#mi("{O( q x^{1/2} d^{-1/2} )}")#text(" is easily seen to be acceptable (using ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(33)")]#text(", ")#link(<tao-792cc6267588b21829ea>)[#text("(37)")]#text("). The contribution of the main term is")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) {\\mathcal D} h(1) \\sum_d \\rho_{T^{10},T^{10}}(d) \\frac{g(d)}{d}")]]

#text("but this is acceptable by Lemma ")#link(<tao-a5ad895656074bb12930>)[#text("14")]#text(", ")#link(<tao-8693873cd8f8a2d9c7c5>)[#text("(27)")]#text(", and Proposition ")#link(<tao-b9ae0309808fc250ffbd>)[#text("20")]#text(". ")#mi("\\Box")

#text("The proof of Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(" is now complete.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-091e606752615c91da70>#text(" Let ")#mi("{\\chi_1}")#text(" be a real quadratic character of modulus ")#mi("{q}")#text(" with a zero at ")#mi("{\\beta = 1 - \\frac{\\varepsilon}{\\log q}}")#text(" for some small ")#mi("{\\varepsilon > 0}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\chi(p) \\log p = - \\frac{x^\\beta}{\\beta} + O( \\exp( - c \\log \\frac{1}{\\varepsilon} \\frac{\\log x}{\\log q} ) x )")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\chi(p) \\log p \\ll \\exp( - \\varepsilon \\frac{\\log x}{\\log q} ) x")]]

#text("for all ")#mi("{x \\geq 1}")#text(" and some absolute constant ")#mi("{c>0}")#text(". (")#emph[#text("Hint:")]#text(" use ")#link(<tao-a8961db5510c0f37a224>)[#text("(3)")]#text(" and the explicit formula.) Roughly speaking, this exercise asserts that ")#mi("{\\chi(p)}")#text(" is equidistributed for primes ")#mi("{p}")#text(" with ")#mi("{\\log p}")#text(" much larger than ")#mi("{\\frac{1}{\\varepsilon} \\log q}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-84fe8ac08da07a414056>#text(" Let ")#mi("{\\chi_1}")#text(" be a real quadratic character of modulus ")#mi("{q}")#text(" with a zero at ")#mi("{1 - \\frac{\\varepsilon}{\\log q}}")#text(" for some small ")#mi("{\\varepsilon > 0}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("L(1,\\chi) = (1 + O(\\varepsilon)) \\frac{\\varepsilon}{\\log q} \\prod_{p \\leq q^C} (1-\\frac{1}{p})^{-1}(1-\\frac{\\chi(p)}{p})^{-1}")]]

#text("if ")#mi("{C}")#text(" is a sufficiently large absolute constant. (")#emph[#text("Hint:")]#text(" use Exercise 81, Lemma 40, and Theorem 41 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", as well as Exercise ")#link(<tao-091e606752615c91da70>)[#text("24")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Bombieri’s zero density estimate)")]#text(" Under the hypotheses of Theorem ")#link(<tao-53499abbfdfb4ad6959c>)[#text("9")]#text(", establish the estimate ")#link(<tao-a60f76e94051a51ae5d7>)[#text("(5)")]#text(". (")#emph[#text("Hint:")]#text(" repeat the arguments in Section ")#link(<tao-836ff184e7b41b1e13cb>)[#text("1")]#text(", but now “twisted” by ")#mi("{g}")#text(".)")
]

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f38db9fdbb362cc5c09b6e4c76b08dfe62a1e38eaf611adc0914a8170457ec87-8c2f549de973e7afdfa1df86048477ed102813a6e4dc65709015ee485dea0006.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Douglas J. Keenan")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452290")[#strong[#text("Douglas J. Keenan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("Regarding Xylouris, he has since shown that the exponent can be reduced to 5. See “")#link("http://bib.math.uni-bonn.de/downloads/bms/BMS-404.pdf")[#text("Über die Nullstellen der Dirichletschen L-Funktionen und die kleinste Primzahl in einer arithmetischen Progression")]#text("“. (The link is to his 2011 dissertation.)")

#emph[#text("[Reference updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2015")])]

#text("The link to Notes 2 (line 2 below theorem 1) is to Xylouris paper.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("Concerning the probabilistic prediction (below theorem 1) that ")#mi("p \\ll q^{1+o(1)}")#text(", what is known about the size of this ")#mi("o(1)")#text(" term, and is it possible to eliminate it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("In ")#link("http://www.ams.org/mathscinet-getitem?mr=1067261")[#text("this paper of Granville and Pomerance")]#text(" it is conjectured that the least p should be comparable to ")#mi("\\phi(q) \\log^2 q")#text(", and a lower bound a little bit larger than ")#mi("\\phi(q) \\log q")#text(" is established for some ")#mi("q")#text(". (The problem is similar to Cramer’s conjecture on large prime gaps. Actually, there is a good chance that the recent progress on large prime gaps can be adapted to improve the results of Granville and Pomerance; a graduate research project, perhaps?)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452356")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("In the box with Theorem 2, one of the lines containing math sticks into the margin. Maybe moving the last term to the next line will help.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-452369")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("[…] ingredients are in a similar spirit to the “log-free density theorem” from Theorem 6 of Notes 7. See the Matomaki-Radziwill paper for details (in the non-cheap […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-453604")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] replaced by “log-free” versions (analogous to the log-free zero-density theorems in Notes 7), combined with careful numerical optimisation of constants and also some numerical work on the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-482698")[#strong[#text("Repelling Numbers | Gaurish4Math")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2017")]

#text("[…] important fact in the theory of prime numbers is the Deuring-Heilbronn phenomenon, which roughly says […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prahlad")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-503629")[#strong[#text("Prahlad")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")])]

#text("I don’t see how the statement just after Remark 4 follows just from the truncated explicit formula as mentioned. The error term should been $O(x\\log^2(x)/q^2)$ from the referred exercise.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-503631")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2018")])]

#text("Ah, right; as with all the other components of the proof of Linnik’s theorem, one needs the log-free version of the truncated explicit formula, which was not quite the one in the referred exercise. Basically one has to replace the somewhat crude analysis in the proof of the truncated Perron formula in those notes with the log-free bound provided by the Brun-Titchmarsh inequality. I’ve now made this formula an exercise.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-684528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2024")])]

#text("In the last step of proof of proposition 23, if use proposition 20, it seems that we can only get a factor of ")#mi("x*\\epsilon/\\log q")#text(" instead of ")#mi("x*\\epsilon/\\log T")#text(" as required in (46), I am confused about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/02/22/254a-notes-7-linniks-theorem-on-primes-in-arithmetic-progressions/#comment-684581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("Ugh, this is actually a somewhat annoying issue to fix; I had intended this argument to be a simplification of the treatment of Iwaniec-Kowalski but I now see that the setup is not convenient for dealing with the case when ")#mi("T")#text(" is comparable to ")#mi("q^{1/\\varepsilon}")#text(". (In Iwaniec-Kowalski, the analogue of the function ")#mi("g")#text(" is called ")#mi("\\rho")#text(" and has a slightly different behavior in this regime.) Unfortunately, I will not be able to issue a patch for this issue in the near future, and will have to refer readers to other treatments of Linnik’s theorem in the meantime.")
]
]
