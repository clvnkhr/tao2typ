// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/
// Converted to Typst by tao2typ: "2026-10-14T16:35:23.910804+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tricks Wiki article: The tensor power trick", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tricks Wiki article: The tensor power trick")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 August 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As many readers may already know, my good friend and ")#link("http://gowers.wordpress.com/")[#text("fellow mathematical blogger")]#text(" ")#link("http://en.wikipedia.org/wiki/Timothy_Gowers")[#text("Tim Gowers")]#text(", having wrapped up work on the ")#link("http://wordpress.com/tag/princeton-companion-to-mathematics/")[#text("Princeton Companion to Mathematics")]#text(" (which I believe is now in press), has begun another mathematical initiative, namely a “")#link("http://gowers.wordpress.com/2007/09/11/what-might-an-expository-mathematical-wiki-be-like/")[#text("Tricks Wiki")]#text("” to act as a repository for mathematical tricks and techniques. Tim has already started the ball rolling with several seed articles on his own blog, and asked me to also contribute some articles. (As I understand it, these articles will be migrated to the Wiki in a few months, once it is fully set up, and then they will evolve with edits and contributions by anyone who wishes to pitch in, in the spirit of Wikipedia; in particular, articles are not intended to be permanently authored or signed by any single contributor.)")

#text("So today I’d like to start by extracting some material from an old post of mine on “")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("Amplification, arbitrage, and the tensor power trick")]#text("” (as well as from some of the comments), and converting it to the Tricks Wiki format, while also taking the opportunity to add a few more examples.")

#strong[#text("Title: The tensor power trick")#linebreak()#text(" ")]

#strong[#text("Quick description: ")]#text("If one wants to prove an inequality ")#mi("X \\leq Y")#text(" for some non-negative quantities X, Y, but can only see how to prove a quasi-inequality ")#mi("X \\leq CY")#text(" that loses a multiplicative constant C, then try to replace all objects involved in the problem by “")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor powers")]#text("” of themselves and apply the quasi-inequality to those powers. If all goes well, one can show that ")#mi("X^M \\leq C Y^M")#text(" for all ")#mi("M \\geq 1")#text(", with a constant C which is ")#emph[#text("independent")]#text(" of M, which implies that ")#mi("X \\leq Y")#text(" as desired by taking ")#mi("M^{th}")#text(" roots and then taking limits as ")#mi("M \\to \\infty")#text(".")

#metadata(none) <tao-14a2008889fbaa50e85c>

#strong[#text("General discussion:")]#text(" This trick works best when using techniques which are “dimension-independent” (or depend only weakly (e.g. polynomially) on the ambient dimension M). On the other hand, the constant C is allowed to depend on other parameters than the dimension M. In particular, even if the eventual inequality ")#mi("X \\leq Y")#text(" one wishes to prove is supposed to be uniform over all choices of some auxiliary parameter n, it is possible to establish this estimate by first establishing a non-uniform estimate ")#mi("X \\leq C_n Y")#text(", so long as this estimate “tensorises” to ")#mi("X^M \\leq C_n Y^M")#text(", where n does not grow with M.")

#text("It is of course essential that the problem “commutes” or otherwise “plays well” with the tensor power operation in order for the trick to be effective. In order for this to occur, one often has to phrase the problem in a sufficiently abstract setting, for instance generalising a one-dimensional problem to one in arbitrary dimensions.")

#strong[#text("Prerequisites: ")]#text("Advanced undergraduate analysis (real, complex, and Fourier). The user of the trick also has to be very comfortable with working in high-dimensional spaces such as ")#mi("{\\Bbb R}^M")#text(", or more generally ")#mi("G^M")#text(" for some mathematical object G (e.g. a set, a group, a measure space, etc.) The later examples are more advanced but are only given as sketches.")

#strong[#text("Example 1. ")]#text("(Convexity of ")#mi("L^p")#text(" norms) Let ")#mi("f: {\\Bbb R} \\to {\\Bbb C}")#text(" be a measurable function such that ")#tao-math("\\int_{\\Bbb R} \\left|f(x)\\right|^p\\ dx \\leq 1", block: false)#text(" and ")#tao-math("\\int_{\\Bbb R} \\left|f(x)\\right|^q\\ dx \\leq 1", block: false)#text(" for some ")#mi("0 < p < q < \\infty")#text(". Show that ")#tao-math("\\int_{\\Bbb R} \\left|f(x)\\right|^r\\ dx \\leq 1", block: false)#text(" for all ")#mi("p < r < q")#text(".")

#text("As a first attempt to solve this problem, observe that ")#tao-math("\\left|f(x)\\right|^r", block: false)#text(" is less than ")#tao-math("\\left|f(x)\\right|^q", block: false)#text(" when ")#tao-math("\\left|f(x)\\right| \\geq 1", block: false)#text(", and is less than ")#tao-math("\\left|f(x)\\right|^p", block: false)#text(" when ")#tao-math("\\left|f(x)\\right| \\leq 1", block: false)#text(". Thus the inequality ")#tao-math("\\left|f(x)\\right|^r \\leq \\left|f(x)\\right|^p + \\left|f(x)\\right|^q", block: false)#text(" holds for all x, regardless of whether ")#tao-math("\\left|f(x)\\right|", block: false)#text(" is larger or smaller than 1. This gives us the bound ")#tao-math("\\int_{\\Bbb R} \\left|f(x)\\right|^r\\ dx \\leq 2", block: false)#text(", which is off by a factor of 2 from what we need.")

#text("But we can eliminate this loss of 2 by the tensor power trick. We pick a large integer ")#mi("M \\ge 1")#text(", and define the tensor power ")#mi("f^{\\otimes M}: {\\Bbb R}^M \\to {\\Bbb C}")#text(" of f by the formula")

#align(center)[#mi("f^{\\otimes M}(x_1,\\ldots,x_M) = f(x_1) \\ldots f(x_M)")#text(".")]

#text("From the ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini-Tonelli theorem")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\Bbb R}^M} \\left|f^{\\otimes M}\\right|^p\\ dx = (\\int_{\\Bbb R} \\left|f\\right|^p\\ dx)^M \\leq 1", block: true)]]

#text("and similarly")

#align(center)[#tao-math("\\int_{{\\Bbb R}^M} \\left|f^{\\otimes M}\\right|^q\\ dx = (\\int_{\\Bbb R} \\left|f\\right|^q\\ dx)^M \\leq 1", block: false)#text(".")]

#text("If we thus apply our previous arguments with ")#mi("f")#text(" and ")#mi("{\\Bbb R}")#text(" replaced by ")#mi("f^{\\otimes M}")#text(" and ")#mi("{\\Bbb R}^M")#text(" respectively, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\Bbb R}^M} \\left|f^{\\otimes M}\\right|^r\\ dx \\leq 2;", block: true)]]

#text("applying Fubini-Tonelli again we conclude that")

#align(center)[#tao-fit-display[#tao-math("(\\int_{\\Bbb R} \\left|f\\right|^r\\ dx)^M \\leq 2.", block: true)]]

#text("Taking ")#mi("M^{th}")#text(" roots and then taking limits as ")#mi("M \\to \\infty")#text(" we obtain the claim.")

#strong[#text("Exercise. ")]#text("More generally, show that if ")#mi("0 < p < r < q < \\infty")#text(", ")#mi("(X,\\mu)")#text(" is a ")#link("http://en.wikipedia.org/wiki/Measure_space")[#text("measure space")]#text(", and ")#mi("f: X \\to {\\Bbb C}")#text(" is measurable, then we have the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{L^r(X,\\mu)} \\leq \\left\\|f\\right\\|_{L^p(X,\\mu)}^{1-\\theta} \\left\\|f\\right\\|_{L^q(X,\\mu)}^\\theta", block: true)]]

#text("whenever the right-hand side is finite, where ")#mi("0 < \\theta < 1")#text(" is such that ")#mi("\\frac{1}{r} = (1-\\theta) \\frac{1}{p} + \\theta \\frac{1}{q}")#text(". (Hint: by multiplying f and ")#mi("\\mu")#text(" by appropriate constants one can normalise ")#tao-math("\\left\\|f\\right\\|_{L^p(X,\\mu)} = \\left\\|f\\right\\|_{L^q(X,\\mu)}=1", block: false)#text(".)")

#strong[#text("Exercise. ")]#text("Use the previous exercise (and a clever choice of f, r, ")#mi("\\theta")#text(" and ")#mi("\\mu")#text(" – there is more than one choice available) to prove ")#link("http://en.wikipedia.org/wiki/Holder%27s_inequality")[#text("Hölder’s inequality")]#text(".")

#strong[#text("Example 2.")]#text(" (The maximum principle) This example is due to Landau. Let ")#mi("\\gamma")#text(" be a simple closed curve in the complex plane that bounds a domain D, and let ")#mi("f: \\overline{D} \\to {\\Bbb C}")#text(" be a function which is ")#link("http://en.wikipedia.org/wiki/Complex_analytic")[#text("complex analytic")]#text(" in the closure of this domain, and which obeys a bound ")#tao-math("\\left|f(z)\\right| \\leq A", block: false)#text(" on the boundary ")#mi("\\gamma")#text(". The ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" for such functions asserts that one also has ")#tao-math("\\left|f(z)\\right| \\leq A", block: false)#text(" on the interior D as well. One way to prove this is by using the ")#link("http://en.wikipedia.org/wiki/Cauchy_integral_formula")[#text("Cauchy integral formula")]

#align(center)[#tao-fit-display[#mitex("f(z) =\\frac{1}{2\\pi i} \\int_\\gamma \\frac{f(w)}{w-z}\\ dw")]]

#text("for ")#mi("z \\in D")#text(" (assuming that ")#mi("\\gamma")#text(" is oriented anti-clockwise). Taking absolute values and using the triangle inequality, we obtain the crude bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq \\frac{1}{2\\pi} \\frac{\\left|\\gamma\\right|}{\\text{dist}(z,\\gamma)} A", block: true)]]

#text("where ")#tao-math("\\left|\\gamma\\right|", block: false)#text(" is the length of ")#mi("\\gamma")#text(". This bound is off by a factor of ")#tao-math("\\frac{1}{2\\pi} \\frac{\\left|\\gamma\\right|}{\\text{dist}(z,\\gamma)}", block: false)#text(". This loss depends on the point z and the curve ")#mi("\\gamma")#text(", but it is crucial to observe that it does not depend on f. In particular, one can apply it with f replaced by ")#mi("f^M")#text(" (and A replaced by ")#mi("A^M")#text(") for any positive integer M, noting that ")#mi("f^M")#text(" is of course also complex analytic. We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right|^M \\leq \\frac{1}{2\\pi} \\frac{\\left|\\gamma\\right|}{\\text{dist}(z,\\gamma)} A^M", block: true)]]

#text("and on taking ")#mi("M^{th}")#text(" roots and then taking limits as ")#mi("M \\to \\infty")#text(" we obtain the maximum principle.")

#strong[#text("Example 3.")]#text(" (New Strichartz estimates from old; this observation is due to Jon Bennet) Technically, this is not an application of the tensor power trick as we will not let the dimension go off to infinity, but it is certainly in a similar spirit.")

#emph[#text("Strichartz estimates")]#text(" are an important tool in the theory of linear and nonlinear dispersive equations. Here is a typical such estimate: if ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^2 \\to {\\Bbb C}")#text(" solves the two-dimensional Schrödinger equation ")#mi("i u_t + \\Delta u = 0")#text(", then one has the inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^4_t L^4_x( {\\Bbb R} \\times {\\Bbb R}^2 )} \\leq C \\left\\| u(0) \\right\\|_{L^2( {\\Bbb R}^2 )}", block: true)]]

#text("for some absolute constant C. (In this case, the best value of C is known to equal ")#mi("1/\\sqrt{2}")#text(", a result ")#link("http://www.ams.org/mathscinet-getitem?mr=2341830")[#text("of Foschi")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2219206")[#text("of Hundertmark-Zharnitsky")]#text(".) It is possible to use this two-dimensional Strichartz estimate and a version of the tensor power trick to deduce a one-dimensional Strichartz estimate. Specifically, if ")#mi("u: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb C}")#text(" solves the one-dimensional Schrödinger equation ")#mi("iu_t + u_{xx} = 0")#text(", then observe that the tensor square ")#mi("u^{\\otimes 2}(t,x,y) := u(t,x) u(t,y)")#text(" solves the two-dimensional Schrödinger equation. (This tensor product symmetry of the Schrödinger equation is fundamental in quantum physics; it allows one to model many-particle systems and single-particle systems by essentially the same equation.) Applying the above Strichartz inequality to this product we conclude that")

#align(center)[#tao-math("\\left\\| u \\right\\|_{L^8_t L^4_x( {\\Bbb R} \\times {\\Bbb R} )} \\leq C^{1/2} \\left\\| u(0) \\right\\|_{L^2( {\\Bbb R} )}", block: false)#text(".")]

#strong[#text("Remark. ")]#text(" A similar trick allows us to deduce “interaction” or “many-particle” Morawetz estimates for the Schrödinger equation from their more traditional “single-particle” counterparts; see for instance Chapter 3.5 of ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("my book")]#text(".")

#strong[#text("Example 4.")]#text(" (Hausdorff-Young inequality) Let G be a finite abelian group, and let ")#mi("f: G \\to {\\Bbb C}")#text(" be a function. We let ")#mi("\\hat G")#text(" be the group of ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("characters")]#text(" ")#mi("\\chi: G \\to S^1")#text(" of G, and define the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Fourier transform")]#text(" ")#mi("\\hat f: \\hat G \\to {\\Bbb C}")#text(" by the formula")

#align(center)[#tao-math("\\hat f(\\xi) := \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} f(x) \\overline{\\chi(x)}", block: false)#text(".")]

#text("From the triangle inequality we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sup_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right| \\leq \\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|", block: true)]]

#text("while from ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("Plancherel’s theorem")]#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("(\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^2)^{1/2} = (\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^2)^{1/2}", block: true)]]

#text("By applying the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(", we can then conclude the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem#Hausdorff.E2.88.92Young_inequality")[#text("Hausdorff-Young inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("(\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^q)^{1/q} \\leq (\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^p)^{1/p}", block: true)]]

#text("whenever ")#mi("1 < p < 2")#text(" and ")#mi("\\frac{1}{p}+\\frac{1}{q}=1")#text(". However, it is also possible to deduce (3) from (2) and (1) by a more elementary method based on the tensor power trick. First suppose that f is supported on a set ")#mi("A \\subset G")#text(" and that |f| takes values between (say) ")#mi("2^m")#text(" and ")#mi("2^{m+1}")#text(" on A. Then from (1) and (2) we have")

#tao-aligned(keep: true)[


#tao-math("\\sup_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|  & \\leq \\frac{\\left|A\\right|}{\\left|G\\right|} 2^{m+1}", block: true)



#tao-math("(\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^2)^{1/2}  & \\leq (\\frac{\\left|A\\right|}{\\left|G\\right|})^{1/2} 2^{m+1}", block: true)
]

#text("from which we establish a “restricted weak-type” version of Hausdorff-Young, namely")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^q)^{1/q} \\leq (\\frac{\\left|A\\right|}{\\left|G\\right|})^{1/p} 2^{m+1}", block: true)]]

#text("and thus")

#align(center)[#tao-math("\\displaystyle (\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^q)^{1/q} \\leq 2 (\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^p)^{1/p}", block: false)#text(".")]

#text("This inequality is restricted to those f whose non-zero magnitudes |f(x)| range inside a dyadic interval ")#mi("{}[2^m, 2^{m+1}]")#text(", but by the technique of dyadic decomposition one can remove this restriction at the cost of an additional factor of ")#tao-math("O( 1 + \\log \\left|G\\right| )", block: false)#text(", thus obtaining the estimate")

#align(center)[#tao-math("\\displaystyle (\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^q)^{1/q} \\leq C (1 + \\log \\left|G\\right|) (\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^p)^{1/p}", block: false)#text(" (3′)")]

#text("for general f. (There are of course an infinite number of dyadic scales ")#mi("{}[2^m, 2^{m+1}]")#text(" in the world, but if one normalises ")#tao-math("(\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^p)^{1/p} = 1", block: false)#text(", then it is not hard to see that any scale above, say, ")#tao-math("\\left|G\\right|^{100}", block: false)#text(" or below ")#tao-math("\\left|G\\right|^{-100}", block: false)#text(" is very easy to deal with, leaving only ")#tao-math("O( 1 + \\log \\left|G\\right| )", block: false)#text(" dyadic scales to consider.)")

#text("The estimate (3′) is off by a factor of ")#tao-math("O( 1 + \\log \\left|G\\right| )", block: false)#text(" from the true Hausdorff-Young inequality, but if one replaces G with a Cartesian power ")#mi("G^M")#text(" and f with its tensor power ")#mi("f^{\\otimes M}")#text(", and makes the crucial observation that the Fourier transform of a tensor power is the tensor power of the Fourier transform, we see from applying (3′) to the tensor power that")

#align(center)[#tao-math("\\displaystyle (\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^q)^{M/q} \\leq C (1 + \\log \\left|G\\right|^M) (\\frac{1}{\\left|G\\right|} \\sum_{x \\in G} \\left|f(x)\\right|^p)^{M/p}", block: false)#text(".")]

#text("Taking ")#mi("M^{th}")#text(" roots and sending ")#mi("M \\to \\infty")#text(" we obtain the desired inequality. Note that the logarithmic dependence on |G| in the constants turned out not to be a problem, because ")#mi("M^{1/M} \\to 1")#text(". Thus the tensor power trick is able to handle a certain amount of dependence on the dimension in the constants, as long as the loss does not grow too rapidly in that dimension.")

#strong[#text("Exercise.")]#text(" Establish ")#emph[#text("Young’s inequality")]#text(" ")#tao-math("\\left\\|f*g\\right\\|_{l^r(G)} \\leq \\left\\|f\\right\\|_{l^p(G)} \\left\\|g\\right\\|_{l^q(G)}", block: false)#text(" for ")#mi("1 \\leq p,q,r < \\infty")#text(" and ")#mi("\\frac{1}{r}+1=\\frac{1}{p}+\\frac{1}{q}")#text(" and finite abelian groups G, where ")#mi("f*g(x) := \\sum_G f(y) g(x-y)")#text(", by the same method.")

#strong[#text("Exercise. ")]#text("Prove the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(" (in the regime ")#mi("q \\geq p")#text(") by this method, thus avoiding all use of complex analysis. (Note the similarity here with Example 1 and Example 2.)")

#strong[#text("Example 5.")]#text(" (An example from additive combinatorics, due to Imre Ruzsa.) An important inequality of Plünnecke asserts, among other things, that for finite non-empty sets A, B of an additive group G, and any positive integer k, the iterated sumset ")#mi("kB = B + \\ldots + B")#text(" obeys the bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|kB\\right| \\leq \\frac{\\left|A+B\\right|^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("(This inequality, incidentally, is itself proven using a version of the tensor power trick, in conjunction with ")#link("http://en.wikipedia.org/wiki/Marriage_theorem")[#text("Hall’s marriage theorem")]#text(", but never mind that here.) This inequality can be amplified to the more general inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{\\left|A+B_1\\right| \\ldots \\left|A+B_k\\right|}{\\left|A\\right|^{k-1}}", block: true)]]

#text("via the tensor power trick as follows. Applying (4) with ")#mi("B := B_1 \\cup \\ldots \\cup B_k")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{(\\left|A+B_1\\right| + \\ldots + \\left|A+B_k\\right|)^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("The right-hand side looks a bit too big, but we can resolve this problem with a Cartesian product trick (which can be viewed as a cousin of the tensor product trick). If we replace G with the larger group ")#mi("G \\times {\\Bbb Z}^k")#text(" and replace each set ")#mi("B_i")#text(" with the larger set ")#mi("B_i \\times \\{ e_i, 2e_i, \\ldots, N_i e_i \\}")#text(", where ")#mi("e_1,\\ldots,e_k")#text(" is the standard basis for ")#mi("{\\Bbb Z}^k")#text(" and ")#mi("N_i")#text(" are arbitrary positive integers (and replacing A with ")#mi("A \\times \\{0\\}")#text("), we obtain")

#align(center)[#tao-fit-display[#tao-math("N_1 \\ldots N_k \\left|B_1 + \\ldots + B_k\\right| \\leq \\frac{(N_1 \\left|A+B_1\\right| + \\ldots + N_k \\left|A+B_k\\right|)^k}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("Optimising this in ")#mi("N_1,\\ldots,N_k")#text(" (basically, by making the ")#tao-math("N_i \\left|A+B_i\\right|", block: false)#text(" close to constant; this is a general rule in optimisation, namely that to optimise X+Y it makes sense to make X and Y comparable in magnitude) we obtain the amplified estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|B_1 + \\ldots + B_k\\right| \\leq C_k \\frac{\\left|A+B_1\\right| \\ldots \\left|A+B_k\\right|}{\\left|A\\right|^{k-1}}.", block: true)]]

#text("for some constant ")#mi("C_k")#text("; but then if one replaces ")#mi("A, B_1, \\ldots, B_k")#text(" with their Cartesian powers ")#mi("A^M, B_1^M, \\ldots, B_k^M")#text(", takes ")#mi("M^{th}")#text(" roots, and then sends M to infinity, we can delete the constant ")#mi("C_k")#text(" and recover the inequality.")

#strong[#text("Example 6.")]#text(" (Cotlar-Knapp-Stein lemma) This example is not exactly a use of the tensor power trick, but is very much in the same spirit. Let ")#mi("T_1, T_2, \\ldots, T_N: H \\to H")#text(" be bounded linear operators on a Hilbert space; for simplicity of discussion let us say that they are self-adjoint, though one can certainly generalise the discussion here to more general operators. If we assume that the operators are uniformly bounded in the operator norm, say")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| T_i \\right\\|_{op} \\leq A", block: true)]]

#text("for all i and some fixed A, then this is not enough to ensure that the sum ")#mi("\\sum_{i=1}^N T_i")#text(" is bounded uniformly in N; indeed, the operator norm can be as large as AN. If however one has the stronger ")#emph[#text("almost orthogonality")]#text(" estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{j=1}^N \\left\\| T_i T_j \\right\\|_{op}^{1/2} \\leq A", block: true)]]

#text("for all i, then the very useful ")#link("http://en.wikipedia.org/wiki/Cotlar%E2%80%93Stein_lemma")[#text("Cotlar-Knapp-Stein lemma")]#text(" asserts that ")#mi("\\sum_{i=1}^N T_i")#text(" is now bounded uniformly in N, with ")#tao-math("\\left\\| \\sum_{i=1}^N T_i \\right\\|_{op} \\leq A", block: false)#text(". To prove this, we first recall that a direct application of the triangle inequality using (5) (which is a consequence of (6)) only gave the inferior bound of AN. To improve this, first observe from self-adjointness that")

#align(center)[#tao-math("\\left\\| \\sum_{i=1}^N T_i \\right\\|_{op} = \\left\\| (\\sum_{i=1}^N T_i)^2 \\right\\|_{op}^{1/2}", block: false)#text(".")]

#text("Expanding the right-hand side out using the triangle inequality, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^N T_i \\right\\|_{op} \\leq (\\sum_{i=1}^N \\sum_{j=1}^N \\left\\| T_i T_j \\right\\|_{op})^{1/2};", block: true)]]

#text("using (6) one soon ends up with a bound of ")#mi("A N^{1/2}")#text(". This is better than before as far as the dependence on N is concerned, but one can do better by using higher powers. In particular, if we raise ")#mi("\\sum_{i=1}^N")#text(" to the ")#mi("2M^{th}")#text(" power for some M, and repeat the previous arguments, we end up with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^N T_i \\right\\|_{op} \\leq (\\sum_{1 \\leq i_1,\\ldots,i_{2M} \\leq N} \\left\\| T_{i_1} \\ldots T_{i_{2M}} \\right\\|_{op})^{1/2M}.", block: true)]]

#text("Now, one can estimate the operator norm ")#tao-math("\\left\\| T_{i_1} \\ldots T_{i_{2M}} \\right\\|_{op}", block: false)#text(" either by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_{i_1} T_{i_2} \\right\\|_{op} \\ldots \\left\\| T_{i_{2M-1}} T_{i_{2M}} \\right\\|_{op},", block: true)]]

#text("or (using (5)) by")

#align(center)[#tao-fit-display[#tao-math("A^2 \\left\\| T_{i_2} T_{i_3} \\right\\|_{op} \\ldots \\left\\| T_{i_{2M-2}} T_{i_{2M-1}} \\right\\|_{op}.", block: true)]]

#text("We take the geometric mean of these upper bounds to obtain")

#align(center)[#tao-fit-display[#tao-math("A \\left\\| T_{i_1} T_{i_2} \\right\\|_{op}^{1/2} \\left\\| T_{i_2} T_{i_3} \\right\\|_{op}^{1/2} \\ldots \\left\\| T_{i_{2M-1}} T_{i_{2M}} \\right\\|_{op}^{1/2}.", block: true)]]

#text("Summing this in ")#mi("i_{2M}")#text(", then ")#mi("i_{2M-1}")#text(", and so forth down to ")#mi("i_1")#text(" using (6) repeatedly, one eventually establishes the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{i=1}^N T_i \\right\\|_{op} \\leq (N A^{2M})^{1/2M}.", block: true)]]

#text("Sending ")#mi("M \\to \\infty")#text(" one eliminates the dependence on N and obtains the claim.")

#strong[#text("Exercise.")]#text(" Show that the hypothesis of self-adjointness can be dropped if one replaces (6) with the two conditions")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^N \\left\\| T_i T_j^* \\right\\|_{op}^{1/2} \\leq A", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^N \\left\\| T_i^* T_j \\right\\|_{op}^{1/2} \\leq A", block: true)]]

#text("for all i.")

#strong[#text("Example 7.")]#text(" (Entropy estimates) Suppose that X is a random variable taking finitely many values. The ")#link("http://en.wikipedia.org/wiki/Information_entropy")[#text("Shannon entropy")]#text(" H(X) of this random variable is defined by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("H(X) := - \\sum_x {\\Bbb P}(X=x) \\log {\\Bbb P}(X=x),")]]

#text("where x runs over all possible values of X. For instance, if X is uniformly distributed over N values, then")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("H(X)=\\log N.")]]

#text("If X is not uniformly distributed, then the formula is not quite as simple. However, the entropy formula (7) does simplify to the uniform distribution formula (8) after using the tensor power trick. More precisely, let ")#mi("X^{\\otimes M} = (X_1,\\ldots,X_M)")#text(" be the random variable formed by taking M independent and identicaly distributed samples of X; thus for instance, if X was uniformly distributed on N values, then ")#mi("X^{\\otimes M}")#text(" is uniformly distributed on ")#mi("N^M")#text(" values. For more general X, it is not hard to verify the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("H( X^{\\otimes M} ) = M H(X),")]]

#text("which is of course consistent with the uniformly distributed case thanks to (8).")

#text("A key observation is that as ")#mi("M \\to \\infty")#text(", the probability distribution of ")#mi("X^{\\otimes M}")#text(" becomes “asymptotically uniform” in a certain sense. Indeed, the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" tells us that with very high probability, each possible value x of X will be attained by ")#mi("({\\Bbb P}(X=x)+o(1)) M")#text(" of the M trials ")#mi("X_1,\\ldots,X_M")#text(". The number of possible configurations of ")#mi("X^{\\otimes M} = (X_1,\\ldots,X_M)")#text(" which are consistent with this distribution can be computed (using ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(") to be ")#mi("e^{M (H(X)+o(1))}")#text(", and each such configuration appears with probability ")#mi("e^{-M (H(X)+o(1))}")#text(" (again by Stirling’s formula). Thus, at a heuristic level at least, ")#mi("X^{\\otimes M}")#text(" behaves like a uniform distribution on ")#mi("e^{M (H(X)+o(1))}")#text(" possible values; note that this is consistent with (8) and (9), and can in fact be taken as a ")#emph[#text("definition")]#text(" of Shannon entropy.")

#text("One can use this “")#link("http://en.wikipedia.org/wiki/Microstate_(statistical_mechanics)")[#text("microstate")]#text("” or “")#link("http://en.wikipedia.org/wiki/Statistical_mechanics")[#text("statistical mechanics")]#text("” interpretation of entropy in conjunction with the tensor power trick to give short (heuristic) proofs of various fundamental entropy inequalities, such as the subadditivity inequality")

#align(center)[#tao-fit-display[#mitex("H(X,Y) \\leq H(X) + H(Y)")]]

#text("whenever X, Y are discrete random variables which are not necessarily independent. Indeed, since ")#mi("X^{\\otimes M}")#text(" and ")#mi("Y^{\\otimes M}")#text(" (heuristically) take only ")#mi("e^{M (H(X)+o(1))}")#text(" and ")#mi("e^{M (H(Y)+o(1))}")#text(" values respectively, then ")#mi("(X,Y)^{\\otimes M} \\equiv (X^{\\otimes M}, Y^{\\otimes M})")#text(" will (mostly) take on at most ")#mi("e^{M (H(X)+o(1))} e^{M (H(Y)+o(1))}")#text(" values. On the other hand, this random variable is supposed to behave like a uniformly distributed random variable over ")#mi("e^{M (H(X,Y)+o(1))}")#text(" values. These facts are only compatible if")

#align(center)[#mi("e^{M (H(X,Y)+o(1))} \\leq e^{M (H(X)+o(1))} e^{M (H(Y)+o(1))}")#text(";")]

#text("taking ")#mi("M^{th}")#text(" roots and then sending ")#mi("M \\to \\infty")#text(" we obtain the claim.")

#strong[#text("Exercise. ")]#text("Make the above arguments rigorous. (The final proof will be significantly longer than the standard proof of subadditivity based on ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(", but it may be clearer conceptually. One may also compare the arguments here with those in Example 1.)")

#strong[#text("Example 8.")]#text(" (Monotonicity of Perelman’s reduced volume) One of the key ingredients of ")#link("http://en.wikipedia.org/wiki/Solution_of_the_Poincar%C3%A9_conjecture")[#text("Perelman’s proof of the Poincaré conjecture")]#text(" is a monotonicity formula for Ricci flows, that establishes that a certain geometric quantity, now known as the ")#emph[#text("Perelman reduced volume")]#text(", increases as time goes to negative infinity. Perelman gave both a rigorous proof and a heuristic proof of this formula. The heuristic proof is much shorter, and proceeds by first (formally) applying the ")#link("http://en.wikipedia.org/wiki/Bishop%E2%80%93Gromov_inequality")[#text("Bishop-Gromov inequality")]#text(" for Ricci flat metrics (which shows that another geometric quantity – the ")#emph[#text("Bishop-Gromov reduced volume")]#text(", increases as the radius goes to infinity) not to the Ricci flow itself, but to a high-dimensional version of this Ricci flow formed by adjoining an M-dimensional sphere to the flow in a certain way, and then taking (formal) limits as ")#mi("M \\to \\infty")#text(". This is not ")#emph[#text("precisely")]#text(" the tensor power trick, but is certainly in a similar spirit. For further discussion see “")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("285G Lecture 9: Comparison geometry, the high-dimensional limit, and Perelman’s reduced volume")]#text(".”")

#strong[#text("Example 9.")]#text(" (")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Riemann hypothesis for function fields")]#text(") This example is much deeper than the previous ones, and I am not qualified to explain it in its entirety, but I can at least describe the one piece of this argument which uses the tensor power trick. For simplicity let us restrict attention to the Riemann hypothesis for curves C over a finite field ")#mi("F_{p^M}")#text(" of prime power order. Using the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(" and some other tools from arithmetic geometry, one can show that the number ")#tao-math("\\left|C(F_{p^M})\\right|", block: false)#text(" of points in C taking values (projectively) in ")#mi("F_{p^r}")#text(" is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|C(F_{p^M})\\right| = p^M - \\sum_{i=1}^{2g} \\omega_i^M + 1", block: true)]]

#text("where g is the ")#link("http://en.wikipedia.org/wiki/Genus_of_an_algebraic_curve")[#text("genus")]#text(" of the curve, and ")#mi("\\omega_1,\\ldots,\\omega_{2g}")#text(" are complex numbers that depend on p but not on M. ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil showed")]#text(" that all of these complex numbers had magnitude exactly ")#mi("p^{1/2}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]#text(" case g=1 being ")#link("http://en.wikipedia.org/wiki/Hasse%27s_theorem_on_elliptic_curves")[#text("done earlier by Hasse")]#text(", and the g=0 case morally going all the way back to ")#link("http://en.wikipedia.org/wiki/Diophantus")[#text("Diophantus")]#text("!), which is the analogue of the Riemann hypotheses for such curves. There is also an analogue of the functional equation for these curves, which asserts that the 2g numbers ")#mi("\\omega_1,\\ldots,\\omega_{2g}")#text(" come in pairs ")#mi("\\omega, p/\\omega")#text(".")

#text("As a corollary, we see that ")#tao-math("\\left|C(F_{p^M})\\right|", block: false)#text(" stays quite close to ")#mi("p^M")#text(":")

#align(center)[#tao-math("\\left| \\left|C(F_{p^M})\\right| - p^M - 1 \\right| \\leq 2g p^{M/2}", block: false)#text(".")]

#text("But because of the formula (10) and the functional equation, one can in fact deduce the Riemann hypothesis from the apparently weaker statement")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left|C(F_{p^M})\\right| = p^M + O( p^{M/2} )", block: true)]]

#text("where the implied constants can depend on the curve C, the prime p, and the genus g, but must be independent of the “dimension” M. Indeed, from (12) and (11) one can see that the largest magnitude of the ")#mi("\\omega_1,\\ldots,\\omega_{2g}")#text(" (which can be viewed as a sort of “")#link("http://en.wikipedia.org/wiki/Spectral_radius")[#text("spectral radius")]#text("” for an underlying operator) is at most ")#mi("p^{1/2}")#text("; combining this with the functional equation, one obtains the Riemann hypothesis.")

#text("[This is of course only a small part of the story; the proof of (12) is by far the hardest part of the whole proof, and beyond the scope of this article.]")

#strong[#text("Further reading: ")]#text("The blog post “")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("Amplification, arbitrage, and the tensor power trick")]#text("” discusses the tensor product trick as an example of a more general “amplification trick”.")

#heading(level: 1)[#text("Comments (53)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32219")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Here’s a very simple application of this trick, from ")#link("http://www.ams.org/mathscinet-getitem?mr=1617052")[#text("this paper")]#text(". The disadvantage is that it only proves a conditional result about an open problem.")

#text("Conjecture (the Gaussian Correlation Conjecture): Let ")#mi("\\gamma")#text(" denote the standard Gaussian probability measure on ")#mi("R^n")#text(". Then for ")#mi("A")#text(" and ")#mi("B")#text(" convex sets symmetric about the origin, we have ")#mi("\\gamma(A \\cap B) \\ge \\gamma(A)\\gamma(B)")#text(".")

#text("Conditional theorem: it suffices to prove ")#mi("\\gamma(A \\cap B) \\ge c_n \\gamma(A)\\gamma(B)")#text(" for some sequence ")#mi("c_n >0")#text(" such that ")#mi("\\lim_{n\\to \\infty} c_n^{1/n} = 1")#text(".")

#text("Sketch of proof: For each ")#mi("N")#text(", apply the known inequality to the ")#mi("Nn")#text("-dimensional sets ")#mi("A^N")#text(" and ")#mi("B^N")#text(" and take ")#mi("N")#text("th roots.")

#text("The interest in such a conditional result is that it is also proved in the same paper that ")#mi("\\gamma(A \\cap B) \\ge 2^{-n/2} \\gamma(A)\\gamma(B)")#text(", which just falls short of being of use in connection with the conditional theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Cool post! One extraordinarily tiny correction: In your first example, in the two equations immediately following your first citation of Fubini-Tonelli, the rightmost ")#mi("=1")#text(" should be ")#mi("\\leq 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32230")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Dear Mark: Thanks for the example! It does seem that problems involving gaussians tend to be particularly amenable to the tensor power trick.")

#text("Dear Anonymous: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab0cd50e81332655db6b3f2e939cc7830561dcf352a3c24ccb1125c8295f9c1f-d1133fda8930800c53eced9ca2308e6a37b0a1b22edfcffebf5957235c63bd7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete L. Clark")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32235")[#strong[#text("Pete L. Clark")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Dear Prof. Tao,")

#text("I’m surprised that you didn’t mention (here) the use of this sort of trick in Z. Dvir’s bounds for Kakeya sets over finite fields. In")

#link("http://www.wisdom.weizmann.ac.il/~zdvir/papers/Dvir08b.pdf")[#text("Click to access Dvir08b.pdf")]

#text("he uses it to deduce Corollary 1.2 from Theorem 1.1. Admittedly it does not quite fit your model, because here the constant _does_ scale with the")#linebreak()#text(" dimension. (Ironically, the improvements given by Alon and yourself circumvent this argument.) Prof. Laba in her blog entry")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://ilaba.wordpress.com/2008/03/23/the-kakeya-problem-in-finite-fields/")[#text("The Kakeya problem in finite fields")]
]

#text("describes this as a “standard product set argument”, so I gather there are other Kakeya-type examples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f35cd52575d3b70420c2058eaed4fd261c8b1f593a75e06fbda8ed59eee972-4f3a90a0bc891b73bfcea4a2b84eab1c9d34401b21aef32cef2ab2be223b7932.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suresh")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32237")[#strong[#text("Suresh")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2008")])]

#text("Another application of the tensor trick is in proving that certain NP-hard problems are even hard to approximate well. A standard direct application of this is to prove that CLIQUE cannot be approximated to any constant factor (by taking graph products repeatedly).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32240")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("Dear Terry,")

#text("Many thanks for doing this — it will be a superb article for the site. Can I just take the chance to say two things? First, although we don’t have a definite date yet, we are hoping that it will be up and running, in some form at least, by the end of September, so a little sooner than you suggest. The other thing is to anyone who might be reading this: if you can think of a class of problems that you once found difficult and now find easy, at whatever level (anything from high school to cutting-edge research), and if you can explain clearly what it is that you now understand that you didn’t understand before, then please consider writing an article about it for the site. We’re eventually aiming for something very comprehensive, but in the initial stages we’d just like to get quickly to a large selection of interesting articles.")

#text("Tim")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3ea0e461d1d736c668411472d5f628588e8adf015c16fbbe10de0d15fd1eca-70ff2301f8f81ca485a632489f67c0312ea697218a8a0e60e2a3013f321cf13e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32253")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("Another application of this trick is to show that, for a norm on a field, the condition that the set of integers is bounded (non-archimedian property) implies the condition that the strong triangle inequality (ultrametric property) holds. Apply the usual triangle inequality to the binomial expansion of (x+y)^n and take n-th roots. The converse implication also holds and it’s easier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32254")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("Pete L. Clark:")

#text("There’s a very similar argument in ")#link("http://xxx.lanl.gov/abs/math/9906097")[#text("this paper by Katz and Tao")]#text(" (see the end of the proof of Lemma 2.1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32257")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("Hello Professor Tao,")

#text("Thanks for posting that. I thought of another example, which though not really analysis seems somewhat relevant: If G is a group, then the dimension of any irreducible representation of G divides the index (G:C) where C is the center (I believe this is due to Tate). Let V be an irreducible representation of degree ")#mi("n")#text(" and take the tensor power ")#mi("V^{\\otimes m}")#text(", which is an irreducible representation for ")#mi("G^m")#text(". The subgroup ")#mi("H^{(m)} \\subset G^m")#text(" consisting of elements ")#mi("(x_1, \\dots, x_m)")#text(" such that each ")#mi("x_i \\in C")#text(" and ")#mi("x_1 \\dots x_m = 1")#text(" acts trivially on ")#mi("V^{\\otimes m}")#text(". This means that we have an irreducible representation of ")#mi("G^m / H^{(m)}")#text(" on ")#mi("V^{\\otimes m}")#text(", whose dimension is ")#mi("n^m")#text(". Then since the dimension of an irreducible representation of a group divides the order of that group, and since the order of ")#mi("H^{(m)}")#text(" is ")#mi("c^{m-1}")#text(", we have: ")#mi("n^m \\mid \\frac{ g^m}{ c^{m-1} }")#text(". Here ")#mi("g")#text(" is the order of ")#mi("G")#text(", ")#mi("c")#text(" is the order of ")#mi("C")#text(". Choosing ")#mi("m")#text(" very large, we get ")#mi("n \\mid \\frac{g}{c}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32258")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("One can learn from these posts, thanks! Two small suggestions:")#linebreak()#text(" In the Exercise about Hölder’s inequality I would include the additional hint that one can take ")#mi("r=2")#text(" and ")#mi("\\theta=1/2")#text(" in the preceding Exercise. In (3) we have ")#mi("\\leq")#text(" in place of ")#mi("=")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Singularitarian")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32263")[#strong[#text("Singularitarian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2008")])]

#text("Wow, what a great blog where you have talented mathematicians posting insightful comments. Learning math is a lot easier than it used to be. (But it is still hard.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32272")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")])]

#text("Actually there are two displays numbered (3). I meant the display right after (2) in Example 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")])]

#text("I apologize for making a mistake in the proof of the result of Tate on group representations I posted above. The subgroup ")#mi("H^{(m)} \\subset G^m")#text(" acts trivially ")#mi("V^{\\otimes m}")#text(" because ")#mi("H^{(m)}")#text(" consists of a m-tuple of elements of the center ")#mi("C")#text(" of ")#mi("G")#text(". By Schur’s lemma, each of these elements is a homothety. This implies the statement. (Otherwise the theorem would work for arbitrary abelian normal subgroups.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32276")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")])]

#text("Thanks for the corrections and the many further examples! I can add one more from my own blog: the ")#link("https://terrytao.wordpress.com/2007/03/08/open-problem-the-mahler-conjecture-on-convex-bodies/")[#text("Mahler conjecture for convex bodies")]#text(" tensorises in much the same way as Mark’s example above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Borcherds.")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32277")[#strong[#text("Richard Borcherds.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")])]

#text("Example 9 can be extended a bit: Deligne used this idea in his proof of the Riemann")#linebreak()#text(" hypothesis in higher dimensions. Roughly speaking, he shows that any zero z of the Weil zeta function must be within a distance 1/2 of the critical line. Applying this to the n’th power of the variety shows that nz must also be within a distance 1/2 of some critical line, so z must be within a distance 1/2n of some critical line for any n.")

#text("Exercise: find a good way to take products of Spec Z with itself. A good solution will prove the Riemann hypothesis for the Riemann zeta function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32279")[#strong[#text("A wiki for math tricks! « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2008")]

#text("[…] wiki for math tricks! Terence Tao brings these glad tidings with his latest post: As many readers may already know, my good friend and fellow mathematical blogger Tim Gowers, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32280")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2008")])]

#text("Deligne’s argument was “helped” by the fact that given a polynomial zeta function with roots ")#mi("\\alpha_j")#text(", there is another one with roots ")#mi("\\alpha_j \\alpha_k")#text(", whose analytic properties could be established. For the Riemann zeta function, getting to additive normalization, a directly similar reasoning would need to know that there is a “natural” zeta function with zeros ")#mi("\\rho+\\rho^{\\prime}")#text(", where ")#mi("\\rho")#text(" and ")#mi("\\rho^{\\prime}")#text(" run over zeros of ")#mi("\\zeta(s)")#text(". I think some people have looked a bit, and such functions do not seem to be so nice (for instance, they do not seem to be automorphic ")#mi("L")#text("-functions).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32281")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2008")])]

#text("Thanks to Gergely Harcos for additional hint for exercise about Hölder’s inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32282")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2008")])]

#text("After the comments by Professors Borcherds and Kowalski I am tempted to remark that the Langlands Program envisions a proof of the Ramanujan-Selberg conjectures also by a tensor power trick. Namely, if ")#mi("\\alpha")#text(" is a Langlands parameter at a “nice prime” p of some automorphic form f then we expect, for each positive integer n, that there is some sort of “n-th power of f”, an automorphic form which has ")#mi("\\alpha^n")#text(" as a Langlands parameter at p. A general bound for Langlands parameters then would tell us that ")#tao-math("p^{-1/2} \\leq \\left|\\alpha^n\\right| \\leq p^{1/2}", block: false)#text(", hence in fact ")#tao-math("\\left|\\alpha\\right|=1", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32291")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2008")])]

#text("I like the idea of a “Tricks Wiki”, but surely it would be more fun to call it a “Tricky Wiki”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f4d6267926ff6fcaa95fa3acb42fbc60604953dd5e2e70bb4b91e8aac14cdcb-7f68bbd06582c02fbae43cf14c6797501a1681dfacf9a4584d5cfd9d6541ad0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32297")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2008")])]

#text("Speaking of clever or cute names, how about ")#link("http://www.tiddlywiki.com")[#text("TiddlyWiki")]#text(".")

#text("(There is more of interest here than just the name!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa5c3c299a180c0d9998abb82d53d628533ab35904f34095d360d57dc5632838-4532936b17c51733ae4aca91c16be820a1a6dc40d50c10c58b1cd294ff8ea63f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32436")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2008")])]

#text("(I apologize for repeating this comment at the two blogs)")

#text("I see I arrived a bit late to the party. Nevertheless I hope this comment")#linebreak()#text(" gets read somehow :D")

#text("· First thing I thought about the subject: we NEED to get organized! In particular, we need to open a forum about the Tricki: the planification and organization of such a feat can’t be done from the zero-level, we must keep adding layers of data and information distribution until we arrive to the Wiki, and it seems to me that the first step should be a forum (blogs were the 0-step).")

#text("· About the difficult and fascinating subject of naming and identifying every trick (btw, this should be not a thread, but a whole subforum on the forum!):")

#text("a) I suggest we “impose” the official name, by being the de facto most authoritative source for math tricks (as it happens with OEIS or Wikipedia). Once we have launched the project and having such skilled, expert, famous people on it, authority will follow fast. People will tend to use the names we give to the tricks just because the rest of the people will want to look at them at our Wiki (here, when I say “we” and “our” I refer to everyone who wants to collaborate, of course!)")

#text("b) The name should be composed of (at least) three components:")#linebreak()#text(" 1) An informal, catchy name.")#linebreak()#text(" This would be the best known name for the trick, and would methaphorically refer to its use or main characteristics, or to any circumstances around it or its first apparition, like theorems tend to be named “lately” (hairy ball theorem, sandwich theorem, rising sun lemma, egregius theorem, etc).")

#text("The word “TRICK” (or any other to be decide) should be the last name, just to let people know what we are talking about.")

#text("An invented example: The “1-is-not-so-trivial” trick -> In your main FORMULA [specialized term to be defined within the WIKI], substitute 1 for any fancy SUBFORMULA that does equal to 1, like sin^2(x)+cos^2(x), or partitions of unity, and REARRANGE the main formula (i.e. separate in “components”, simplify, glue, etc).")

#text("2) A technical name within an a priori specified naming rule system (to be defined yet) that already implies some categorization, something like the naming of new biological species. For example: FORMULA SUBSTITUTING+ (where Formula refers to the fact that the trick is about formulas, Substituting refers to the obvious fact, and the “+” means that the substitution actually gets more complex, and not less (-)).")

#text("Another invented categorization family name could be")#linebreak()#text(" Equation DifferentiatingN (take your equation and differentiate it N times)")

#text("3) A serial number. Just to catalogue the trick and make internal database work with it (but also to have it uniquely identified!)")

#text("c) To solve the search problem, a multitag system looks like the most reasonable system to me, but the selection of the tags is critical. I think we should have two kinds of tag:")#linebreak()#text(" predetermined distinguished tags, and configurably non-distinguished tags. The first ones would be created with the project (always subject to suggestions and changes) and would be things like:")

#text("WHERE (in which branchs of math)")#linebreak()#text(" IN (in which type of structures)")#linebreak()#text(" FROM (hypothesis and elements you need to have for the trick to make sense; i.e. the trick starting point)")#linebreak()#text(" TO (the generic result you accomplish by applying the trick)")#linebreak()#text(" WITH (”the how”, technical terms that describe key parts of the process)")#linebreak()#text(" NAME (informal name)")#linebreak()#text(" CATEGORY (formal name),")#linebreak()#text(" SN (serial number)")#linebreak()#text(" AUTHOR (the creator or best-known user of the trick, if it’s known)")#linebreak()#text(" REFERENCE (well-kown book, paper or source where it’s used in an important manner)")#linebreak()#text(" USES (well-known uses of this trick, theorems where it is important, etc)")

#text("The non-distinguished tags would all fall to the same category OTHERS, as a list, just like the tags in YouTube.")

#text("Not all the tags need to be filled, and some can be multivalued.")

#text("An example:")#linebreak()#text(" SN 0000")#linebreak()#text(" NAME “The connection trick”")#linebreak()#text(" CATEGORY Set Identificating Connected")#linebreak()#text(" WHERE Topology, Algebraic Topology")#linebreak()#text(" IN Topological spaces, Manifolds")#linebreak()#text(" FROM Connected set, subset")#linebreak()#text(" TO Subset is Whole Set")#linebreak()#text(" WITH Connected Sets Open-Closed Characterization")#linebreak()#text(" USES")#linebreak()#text(" OTHER Standard, Basic")

#text("Did you know what trick it was? The informal description (which I think it should be the first thing you get after the tags) would be “In a connected set C there are no subsets that are open and closed at the same time, other than the empty set and C. Therefore, if you want to prove that your subset D of your connected set S is in fact the whole S, just prove that D is open, closed, and non-empty”")

#text("·Other basic tricks I thought of just know (please forgive their triviality, I’m just a math student yet):")#linebreak()#text(" * Smart application of Hölder inequality")#linebreak()#text(" * Partitions of unity")#linebreak()#text(" * Linearization in the axioms of non-associative algebras")#linebreak()#text(" * Zorn’s Lemma and, similarly, the Ascending Chain Condition and Maximal Condition for noetherian modules")#linebreak()#text(" * If in a Normed Space you want to prove that x is 0, just prove that its norm is 0")#linebreak()#text(" * If you want to observe the ideals that contain I, then study A/I. If you want to study the ideals contained in the prime P, study the localization A_P.")#linebreak()#text(" * If you are working in a bound that involves exp(x) maybe you just need to work with (1+x). In general, if you are working in a bound that involves an analytic function, it may suffice to work with the first n terms of its Taylor Series (where n=0,1,…,5).")

#text("Well, I’ll adore to give more ideas and to get really involved with this great project, but we definitely need a forum! (If it isn’t implemented yet!). The other way all this effort will eventually come to waste…")

#text("Regards!")#linebreak()#text(" Jose Brox")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Rabkin")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32605")[#strong[#text("Max Rabkin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2008")])]

#text("Can you please turn off Snap Previews on your blog? I’d love to read it more often, but Snap Previews turn me off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-32718")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2008")])]

#text("I agree. Snap Previews have the merit of being both useful and annoying. :-)")

#text("I really like the idea of “trickopedia.” There are many cases when the ideas in the proof are more useful to learn than the statement being proved. For example, if I learn about Ostrowski’s theorem in a book on p-adic numbers, the only place I learn to think abstractly about valuations is in the proof itself. Incidentally, the proof in Section 1.2 of Neal Koblitz’ book on p-adic numbers uses something like the “tensor-power trick”. In any case, I think such a site would have helped me in my studies as an undergraduate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-33024")[#strong[#text("The forthcoming launch of the Tricki « Gowers’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")]

#text("[…] See some of my recent blog posts for examples of articles written in this format. See also this article by Terence Tao, and this one by Emmanuel […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n” « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-33265")[#strong[#text("Distinguished Lecture Series II: Elias Stein, “The Cauchy integral in C^n” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2008")])]

#text("[…] or decay exponentially fast in . Applying the Cotlar-Stein lemma (which I discussed in this earlier blog post) one obtains the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-34844")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("[…] Remark 4. For a different proof of this inequality (based on the tensor power trick), see Example 1 of this blog post of mine. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-36374")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2009")])]

#text("it so difficult to understand……………………………………………………………………………")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-37408")[#strong[#text("While I’m linking… « Feed The Bears")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")]

#text("[…] A further post on the tensor power trick. This gives more details an examples than the first post on how to use the tensor power trick. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 1: Interpolation of L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-37580")[#strong[#text("245C, Notes 1: Interpolation of L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] is off by a constant factor by what we want. But one can eliminate this constant by using the tensor power trick. Indeed, if one replaces with a Cartesian power (with the product -algebra and product measure […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-37984")[#strong[#text("254C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] asserts that the Fourier transform commutes with tensor products. (Because of this fact, the tensor power trick is often available when proving results about the Fourier transform on general groups.) Exercise […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of orr")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-39001")[#strong[#text("orr")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2009")])]

#text("Hello,")#linebreak()#text(" In example 2, in the denominator, w and z should be swapped (otherwise integrate in the clockwise direction). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-41807")[#strong[#text("Divisibility theorems for group representations « Delta Epsilons")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2009")]

#text("[…] proof (due to Tate) is an amusing application of the tensor power trick; one fixes an irreducible , and considers the representation of the direct product , which is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-50177")[#strong[#text("A new way of proving sumset estimates « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2011")]

#text("[…] of which is a trivially sufficient condition for the inequality to hold in this case); using the tensor product trick and the construction of Plünnecke graphs that approximately have certain magnification ratios, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The spectral theorem and its converses for unbounded symmetric operators « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-117270")[#strong[#text("The spectral theorem and its converses for unbounded symmetric operators « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")])]

#text("[…] (v) Show that for all . Improve the to . (Hint: to get this improvement, use the identity and the tensor power trick.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-117272")[#strong[#text("The spectral theorem and its converses for unbounded symmetric operators | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2011")]

#text("[…] (v) Show that for all . Improve the to . (Hint: to get this improvement, use the identity and the tensor power trick.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Lang-Weil bound « What’s new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-166331")[#strong[#text("The Lang-Weil bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2012")])]

#text("[…] For technical reasons, we only prove these bounds directly when is a perfect square; the general case then follows by using the explicit formula for as a function of and the tensor power trick, as explained in this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59c9126682c96c5c1275455e7bb12d10f65d71631e7a82c73fe718959499f2b-856f14e3561466d3b3636c110b19692d32efbe82a2741c60434e922e7fb7ac88.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ofir Gorodetsky")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-200760")[#strong[#text("Ofir Gorodetsky")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2012")])]

#text("Hello Prof. Tao,")#linebreak()#text(" Thank your for this beautiful post. I can share another example of this method – Harald Bohr’s proof of the arithmetic-geometric mean (in a paper named “The Arithmetic and Geometric Means”). It goes as follows:")#linebreak()#text(" By expanding, one can show that for any ")#mi("k \\ge 1")#text(":")#linebreak()#text(" ")#mi("(a_1 + \\cdots + a_n)^{nk} \\ge \\binom{nk}{k,k,\\cdots,k} (a_1 \\cdots a_n)^{k}")#linebreak()#text(" Taking the ")#mi("nk")#text("‘th root, the AM-GM follows by the following limit:")#linebreak()#text(" ")#mi("\\lim_{k \\to \\infty} \\frac{(nk)! ^{\\frac{1}{nk}}}{(k!)^{\\frac{1}{k}}} = n")#linebreak()#text(" One doesn’t need Stirling’s approximation, merely the simple limit ")#mi("\\lim_{n \\to \\infty} \\frac{(n!)^{\\frac{1}{n}}}{n/e} = 1")#text(". Alternatively, one can say that ")#mi("\\binom{nk}{k,k,\\cdots,k}")#text(" is the largest binomial coefficient, hence ")#mi("\\ge \\frac{n^{nk}}{\\binom{nk+n-1}{n-1}}")#text(", and after taking the ")#mi("nk")#text("‘th power and ")#mi("k \\to \\infty")#text(", we’re done again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-234233")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] that (this trick to “magically” delete the error is a canonical example of the tensor power trick), and the bound (15) then follows from […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Bombieri-Stepanov proof of the Hasse-Weil bound | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-321490")[#strong[#text("The Bombieri-Stepanov proof of the Hasse-Weil bound | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2014")])]

#text("[…] upper bound to a matching lower bound, and if one then uses the trace formula (1) (and the “tensor power trick” of sending to infinity to control the weights ) one can then recover the full Hasse-Weil […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dwork’s proof of rationality of the zeta function over finite fields | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-338596")[#strong[#text("Dwork’s proof of rationality of the zeta function over finite fields | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2014")])]

#text("[…] we can prove the ultra-triangle inequality via the tensor power trick. If , then from (4) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convex sets have many differences | George Shakan")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-498637")[#strong[#text("Convex sets have many differences | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("[…] This would imply Conjecture (Convex) and Conjecture 1 for . The goal of the rest of this post is to prove the current state of the art progress due to Shkredov and Schoen. The proof of Theorem 1 is simple enough that we compute the constant (though one can remove it using the tensor power trick). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-498957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2018")])]

#text("In Example 4, does the trick work for the setting of Euclidean spaces instead of finite abelian groups?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-499054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2018")])]

#text("With a little bit of effort, yes. Alternatively, once one has the Hausdorff-Young inequality for finite abelian groups, one can deduce the corresponding inequality on Euclidean spaces, basically by approximating the Euclidean Fourier transform by a discrete Fourier transform (assuming to begin with that the function belongs for instance to the Schwartz class, and removing this hypothesis with a limiting argument later).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 3: pseudodifferential operators | What's new")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-556774")[#strong[#text("247B, Notes 3: pseudodifferential operators | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("[…] the way to by iterating the method (this is an instance of a neat trick in analysis, namely the tensor power trick). For any integer that is a power of two, we see from iterating the method […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-565986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2020")])]

#text("I have seen tensor product of (multi)linear maps. Is it just a convenient notion or is there an algebraic setting for the tensor product of arbitrary maps as in this post?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7366fa80f69ae6e3aeb5bbe219be71540612d529b1055753cbcadbd8aabc5743-05692e02e470fabc4c049be10ca48b2e103834cadc24b9a2f576212f753fdeb0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gdallara")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-663413")[#strong[#text("gdallara")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2022")])]

#text("Dear Tao,")

#text("concerning Riesz-Thorin theorem, are you claiming that one can recover the full statement, without the restriction ")#mi("p_0\\leq q_0, p_1\\leq q_1")#text("? It seems to me that one needs to know that ")#tao-math("\\left\\| T^{\\otimes N}\\right\\|_{p_j\\rightarrow q_j}\\leq \\left\\| T\\right\\|_{p_j\\rightarrow q_j}^N", block: false)#text(", and I am only able to prove it if ")#mi("p\\leq q")#text(". But that could be a limit of my argument, of course…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7366fa80f69ae6e3aeb5bbe219be71540612d529b1055753cbcadbd8aabc5743-05692e02e470fabc4c049be10ca48b2e103834cadc24b9a2f576212f753fdeb0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gian Maria D")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-666254")[#strong[#text("Gian Maria D")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2022")])]

#text("ps. I just realized that the tensor power trick argument I had in mind does not distinguish the real from the complex case, and over the reals one one does not have log-convexity of operator norms on the upper triangle ")#mi("p>q")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-667947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("There are two proofs of this identity, one that works for ")#mi("p \\leq q")#text(" and one that does not require this restriction. See (2.11) (and footnote 4) in ")#link("https://arxiv.org/pdf/2008.00857.pdf")[#text("this recent paper of Ben Krause, Marius Mirek and myself")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7366fa80f69ae6e3aeb5bbe219be71540612d529b1055753cbcadbd8aabc5743-05692e02e470fabc4c049be10ca48b2e103834cadc24b9a2f576212f753fdeb0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gian Maria D")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-668498")[#strong[#text("Gian Maria D")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2022")])]

#text("Thanks! If I understand correctly, the linked paper indeed observes that one has the needed multiplicativity of the operator norm under tensoring when either ")#mi("p\\leq q")#text(" or the kernel is nonnegative.")

#text("Nevertheless, the log-convexity bound")

#tao-math("\\left\\| T\\right\\|_{p_\\theta\\rightarrow q_\\theta}\\leq \\left\\| T\\right\\|_{p_0\\rightarrow q_0}^{1-\\theta}\\left\\| T\\right\\|_{p_1\\rightarrow q_1}^\\theta", block: false)

#text("does not hold for general ")#mi("\\mathbb{R}")#text("-linear operators in the range ")#mi("p>q")#text(" (Riesz 1927 paper shows that a 45 degrees rotation in ")#mi("\\mathbb{R}^2")#text(" is a counterexample).")#linebreak()#text(" Hence, my suspect is that there cannot be a real-variable argument of Riesz-Thorin in complete generality. Does this make sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-668776")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2022")])]

#text("Hmm, I did not appreciate this subtlety before, that there are cases of Riesz-Thorin that lie outside of the scope of the tensor product trick (at least as naively applied). Will modify the text appropriately.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7366fa80f69ae6e3aeb5bbe219be71540612d529b1055753cbcadbd8aabc5743-05692e02e470fabc4c049be10ca48b2e103834cadc24b9a2f576212f753fdeb0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gian Maria D")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-668806")[#strong[#text("Gian Maria D")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2022")])]

#text("It seems indeed to be pretty subtle: given a real operator, one may complexify it, apply the complex Riesz-Thorin theorem, and recover an “almost log-convexity bound” in the real case:")

#tao-math("\\left\\| T\\right\\|_{p_\\theta\\rightarrow q_\\theta}\\lesssim \\left\\| T\\right\\|_{p_0\\rightarrow q_0}^{1-\\theta}\\left\\| T\\right\\|_{p_1\\rightarrow q_1}^\\theta\\qquad (\\theta\\in (0,1)),", block: false)

#text("where the implicit constant is absolute. If it were possible to apply the tensor power trick in the real case, one would expect this absolute constant to go away. But again, the rotation example shows that this cannot be done.")

#text("The moral is that one should use the fact that the ground field is ")#mi("\\mathbb{C}")#text(" in the proof of Riesz-Thorin.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/#comment-689026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2025")])]

#text("It is noted in this post (and the other one on the tensor power trick) that tensor-power works particularly well for entropy (and as noted in Example 7, is at the heart of already the definition of entropy).")

#text("I just wanted to add a pointer here to the Kraft-McMillan inequality ")#link("https://en.wikipedia.org/wiki/Kraft%E2%80%93McMillan_inequality#Proof_of_the_general_case")[#text("https://en.wikipedia.org/wiki/Kraft%E2%80%93McMillan_inequality#Proof_of_the_general_case")]#link("https://en.wikipedia.org/wiki/Kraft%E2%80%93McMillan_inequality#Proof_of_the_general_case")[#text("https://en.wikipedia.org/wiki/Kraft%E2%80%93McMillan_inequality#Proof_of_the_general_case")]#text(" (that some students may see in a first course on entropy/coding theory), which is proven using the tensor-power trick (for a very concrete combinatorial reason: to “bring into scope” words build from n codewords, which allows us to apply the hypothesis of unique decodability of strings of codewords).")

#text("The proof of the Kraft-McMillan inequality has always stood out to me as particularly interesting way to prove that a number C is ≤1, namely prove that C^n grows subexponentially (in the case of Kraft-McMillan, grows linearly in n)")
]
