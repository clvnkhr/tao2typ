// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/
// Converted to Typst by tao2typ: "2026-10-14T15:19:38.221004+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A cheap version of Halasz’s inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A cheap version of Halasz’s inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/")[#text("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A basic estimate in multiplicative number theory (particularly if one is using the Granville-Soundararajan “pretentious” approach to this subject) is the following inequality ")#link("http://www.ams.org/mathscinet-getitem?mr=319930")[#text("of Halasz")]#text(" (formulated here in a quantitative form introduced by Montgomery and ")#link("http://www.ams.org/mathscinet-getitem?mr=1342300")[#text("Tenenbaum")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Halasz inequality)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function bounded in magnitude by ")#mi("{1}")#text(", and suppose that ")#mi("{x \\geq 3}")#text(", ")#mi("{T \\geq 1}")#text(", and ")#mi("{ M \\geq 0}")#text(" are such that ")#metadata(none) <tao-aa29da6b8c5d39298ba0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{p \\leq x} \\frac{1 - \\text{Re}(f(p) p^{-it})}{p} \\geq M")]]

#text("for all real numbers ")#mi("{t}")#text(" with ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll (1+M) e^{-M} + \\frac{1}{\\sqrt{T}}.")]]
]

#text("As a qualitative corollary, we conclude (by standard compactness arguments) that if")

#align(center)[#tao-fit-display[#mitex("\\sum_{p} \\frac{1 - \\text{Re}(f(p) p^{-it})}{p} = +\\infty")]]

#text("for all real ")#mi("{t}")#text(", then ")#metadata(none) <tao-7ac79109ee3ecbd33d6d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) = o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". In the more recent work of ")#link("http://www.ams.org/mathscinet-getitem?mr=2016245")[#text("this paper of Granville and Soundararajan")]#text(", the sharper bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll (1+M) e^{-M} + \\frac{1}{T} + \\frac{\\log\\log x}{\\log x}")]]

#text("is obtained (with a more precise description of the ")#mi("{(1+M) e^{-M}}")#text(" term).")#linebreak()#text(" The usual proofs of Halasz’s theorem are somewhat lengthy (though there has been a recent simplification, in forthcoming work of Granville, Harper, and Soundarajan). Below the fold I would like to give a relatively short proof of the following “cheap” version of the inequality, which has slightly weaker quantitative bounds, but still suffices to give qualitative conclusions such as ")#link(<tao-7ac79109ee3ecbd33d6d>)[#text("(2)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Cheap Halasz inequality)")]#text(" ")#metadata(none) <tao-c6f556046e0c00469fe2>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a multiplicative function bounded in magnitude by ")#mi("{1}")#text(". Let ")#mi("{T \\geq 1}")#text(" and ")#mi("{M \\geq 0}")#text(", and suppose that ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{T,M}")#text(". If ")#link(<tao-aa29da6b8c5d39298ba0>)[#text("(1)")]#text(" holds for all ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(", then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll (1+M)^{1/6} e^{-M/3} + \\frac{1}{T}.")]]
]

#text("The non-optimal exponent ")#mi("{1/3}")#text(" can probably be improved a bit by being more careful with the exponents, but I did not try to optimise it here. A similar bound appears in the ")#link("http://www.ams.org/mathscinet-getitem?mr=319930")[#text("first paper of Halasz")]#text(" on this topic.")#linebreak()#text(" The idea of the argument is to split ")#mi("{f}")#text(" as a Dirichlet convolution ")#mi("{f = f_1 * f_2 * f_3}")#text(" where ")#mi("{f_1,f_2,f_3}")#text(" is the portion of ")#mi("{f}")#text(" coming from “small”, “medium”, and “large” primes respectively (with the dividing line between the three types of primes being given by various powers of ")#mi("{x}")#text("). Using a Perron-type formula, one can express this convolution in terms of the product of the Dirichlet series of ")#mi("{f_1,f_2,f_3}")#text(" respectively at various complex numbers ")#mi("{1+it}")#text(" with ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". One can use ")#mi("{L^2}")#text(" based estimates to control the Dirichlet series of ")#mi("{f_2,f_3}")#text(", while using the hypothesis ")#link(<tao-aa29da6b8c5d39298ba0>)[#text("(1)")]#text(" one can get ")#mi("{L^\\infty}")#text(" estimates on the Dirichlet series of ")#mi("{f_1}")#text(". (This is similar to the Fourier-analytic approach to ternary additive problems, such as Vinogradov’s theorem on representing large odd numbers as the sum of three primes.) This idea was inspired by a similar device used in the work of Granville, Harper, and Soundarajan. A variant of this argument also appears in unpublished work of Adam Harper.")#linebreak()#text(" I thank Andrew Granville for helpful comments which led to significant simplifications of the argument.")#linebreak()#text(" ")#metadata(none) <tao-7b34515afe4729b821a1>

#heading(level: 1)[#strong[#text(" — 1. Basic estimates — ")]]

#text("We need the following basic tools from analytic number theory. We begin with a variant of the classical ")#link("https://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron formula")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Perron type formula)")]#text(" ")#metadata(none) <tao-5111f93f8a30fe634de9>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be an arithmetic function bounded in magnitude by ")#mi("{1}")#text(", and let ")#mi("{x, T \\geq 1}")#text(". Assume that the Dirichlet series ")#mi("{F(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}}")#text(" is absolutely convergent for ")#mi("{\\text{Re}(s) \\geq 1}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll \\int_{-T}^T |F(1+it)| \\frac{dt}{1+\\left|t\\right|} + \\frac{1}{T} + \\frac{T}{x}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By telescoping series (and treating the contribution of ")#mi("{n \\ll T}")#text(" trivially), it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x/e \\leq n \\leq x} f(n) \\ll x \\int_{-T}^T |F(1+it)| \\frac{dt}{1+\\left|t\\right|} + \\frac{x}{T}", block: true)]]

#text("whenever ")#mi("{x \\geq T}")#text(".")#linebreak()#text(" The left-hand side can be written as ")#metadata(none) <tao-7bf53832b10726774320>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x \\sum_n \\frac{f(n)}{n} g( \\log x - \\log n )")]]

#text("where ")#mi("{g(u) := e^{-u} 1_{[0,1]}(u)}")#text(". We now introduce the mollified version")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) := \\int_{\\bf R} g(u + \\frac{v}{T}) \\Psi(v)\\ dv")]]

#text("of ")#mi("{g}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Psi(v) := \\frac{1}{2\\pi} \\int_{\\bf R} \\psi(t) e^{itv}\\ dt")]]

#text("and ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth function supported on ")#mi("{[-1,1]}")#text(" that equals ")#mi("{1}")#text(" at the origin. Basic Fourier analysis then tells us that ")#mi("{\\Psi}")#text(" is a Schwartz function with total mass one. This gives the crude bound")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) \\ll 1")]]

#text("for any ")#mi("{u}")#text(". For ")#mi("{u \\leq -\\frac{1}{T}}")#text(" or ")#mi("{u \\geq 1 + \\frac{1}{T}}")#text(", we use the bound ")#tao-math("{\\Psi(v) \\ll \\frac{1}{(1+\\left|v\\right|)^{10}}}", block: false)#text(" (say) to arrive at the bound")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) \\ll (T \\text{dist}(u, \\{0,1\\}))^{-9};")]]

#text("for ")#mi("{\\frac{1}{T} \\leq u \\leq 1 - \\frac{1}{T}}")#text(" we again use ")#tao-math("{\\Psi(v) \\ll \\frac{1}{(1+\\left|v\\right|)^{10}}}", block: false)#text(" and write")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) - g(u) = \\int_{\\bf R} (g(u + \\frac{v}{T}) - g(u)) \\Psi(v)\\ dv")]]

#text("and use the Lipschitz bound ")#mi("{g(u+\\frac{v}{T}) - g(u) \\ll \\frac{v}{T}}")#text(" for ")#mi("{u + \\frac{v}{T} \\in [0,1]}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\tilde g(u) - g(u) \\ll (T \\text{dist}(u, \\{0,1\\}))^{-9}")]]

#text("for such ")#mi("{u}")#text(". Putting all these bounds together, we see that")

#align(center)[#tao-fit-display[#tao-math("\\tilde g(u) = g(u) + O( \\frac{1}{(1 + T \\left|u\\right|)^9} ) + O( \\frac{1}{(1 + T \\left|u-1\\right|)^9} )", block: true)]]

#text("for all ")#mi("{u}")#text(". In particular, we can write ")#link(<tao-7bf53832b10726774320>)[#text("(3)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("x \\sum_n \\frac{f(n)}{n} \\tilde g(\\log x - \\log n)")]]

#align(center)[#tao-fit-display[#tao-math("+ O( \\sum_n \\frac{x}{n} \\frac{1}{(1 + T \\left|\\log x - \\log n\\right|)^9} + \\frac{1}{(1 + T \\left|\\log x/e - \\log n\\right|)^9} ).", block: true)]]

#text("The expression ")#tao-math("{\\frac{x}{n} \\frac{1}{(1 + T \\left|\\log x - \\log n\\right|)^9} + \\frac{1}{(1 + T \\left|\\log x/e - \\log n\\right|)^9}}", block: false)#text(" is bounded by ")#mi("{O( \\frac{x}{n} \\frac{1}{T \\log^9 x} )}")#text(" when ")#mi("{n \\leq x/10}")#text(", is bounded by ")#mi("{O( \\frac{x}{n} \\frac{1}{T \\log^9 n} )}")#text(" when ")#mi("{n \\geq 10x}")#text(", is bounded by ")#mi("{O(1)}")#text(" when ")#mi("{n = (1+O(1/T)) x}")#text(" or ")#mi("{n = (1+O(1/T)) x/e}")#text(", and is bounded by ")#tao-math("{(\\frac{T}{x} \\left|n-x\\right|)^{-9} + (\\frac{T}{x} \\left|n-x/e\\right|)^{-9}}", block: false)#text(" otherwise. From these bounds, a routine calculation (using the hypothesis ")#mi("{x \\geq T}")#text(") shows that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\frac{x}{n} \\frac{1}{(1 + T \\left|\\log x - \\log n\\right|)^9} + \\frac{1}{(1 + T \\left|\\log x/e - \\log n\\right|)^9} \\ll \\frac{x}{T}", block: true)]]

#text("and so it remains to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\frac{f(n)}{n} \\tilde g(\\log x - \\log n) \\ll \\int_{-T}^T |F(1+it)| \\frac{dt}{1+\\left|t\\right|}.", block: true)]]

#text("Writing")

#tao-aligned(keep: true)[


#tao-math("\\tilde g(u)  & = T \\int_{\\bf R} g(v) \\Psi( T(v-u) )\\ dv", block: true)



#tao-math(" & = \\frac{T}{2\\pi} \\int_{\\bf R} \\psi(t) G(Tt) e^{-iTtu} dt", block: true)



#tao-math(" & = \\frac{1}{2\\pi} \\int_{\\bf R} \\psi(t/T) G(t) e^{-itu}\\ dt", block: true)
]

#text("where")

#align(center)[#tao-fit-display[#mitex("G(t) := \\int_{\\bf R} g(v) e^{itv}\\ dv")]]

#text("we see from the triangle inequality and the support of ")#mi("{\\psi(t/T)}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\frac{f(n)}{n} \\tilde g(\\log x - \\log n)  & \\ll \\int_{\\left|t\\right| \\leq T} \\left|G(t)\\right| \\left|\\sum_n \\frac{f(n)}{n} e^{-it(\\log x- \\log n)}\\right|\\ dt", block: true)



#tao-math(" & \\ll \\int_{\\left|t\\right| \\leq T} \\left|G(t)\\right| \\left|F(1+it)\\right|\\ dt.", block: true)
]

#text("But from integration by parts we see that ")#tao-math("{G(t) \\ll \\frac{1}{1+\\left|t\\right|}}", block: false)#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Next, we recall a standard ")#mi("{L^2}")#text(" mean value estimate for Dirichlet series:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (")#mi("{L^2}")#text(" mean value estimate)")]#text(" ")#metadata(none) <tao-acc00388143c72bb5771>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be an arithmetic function, and let ")#mi("{T \\geq 1}")#text(". Assume that the Dirichlet series ")#mi("{F(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}}")#text(" is absolutely convergent for ")#mi("{\\text{Re}(s) \\geq 1}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F(1+it)\\right|^2\\ dt \\ll T \\sum_{n_1,n_2: \\log n_2 = \\log n_1 + O(1/T)} \\frac{\\left|f(n_1)\\right| \\left|f(n_2)\\right|}{n_1 n_2}.", block: true)]]
]

#emph[#text("Proof:")]#text(" This follows from Lemma 7.1 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text("; for the convenience of the reader we reproduce the short proof here. Introducing the normalised sinc function ")#mi("{\\text{sinc}(x) := \\frac{\\sin(\\pi x)}{\\pi x}}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F(1+it)\\right|^2\\ dt  & \\ll \\int_{\\bf R} \\left|F(1+it)\\right|^2 \\text{sinc}^2( t / 2T )\\ dt", block: true)



#tao-math(" & = \\sum_{n_1,n_2} f(n_1) \\overline{f(n_2)} \\int_{\\bf R} \\frac{1}{n_1^{1+it} n_2^{1-it}} \\text{sinc}^2(t/2T)\\ dt", block: true)



#tao-math(" & \\ll \\sum_{n_1,n_2} \\frac{\\left|f(n_1)\\right| \\left|f(n_2)\\right|}{n_1 n_2} |\\int_{\\bf R} \\text{sinc}^2(t/2T) e^{it (\\log n_1 - \\log n_2)}\\ dt|.", block: true)
]

#text("But a standard Fourier-analytic computation shows that ")#mi("{\\int_{\\bf R} \\text{sinc}^2(t/2T) e^{it (\\log n_1 - \\log n_2)}\\ dt}")#text(" vanishes unless ")#mi("{\\log n_2 = \\log n_1 + O(1/T)}")#text(", in which case the integral is ")#mi("{O(T)}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we recall a basic sieve estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Sieve bound)")]#text(" ")#metadata(none) <tao-e6367a6a683bc7367283>#text(" Let ")#mi("{x \\geq 1}")#text(", let ")#mi("{I}")#text(" be an interval of length ")#mi("{x}")#text(", and let ")#mi("{{\\mathcal P}}")#text(" be a set of primes up to ")#mi("{x}")#text(". If we remove one residue class mod ")#mi("{p}")#text(" from ")#mi("{I}")#text(" for every ")#mi("{p \\in {\\mathcal P}}")#text(", the number of remaining natural numbers in ")#mi("{I}")#text(" is at most ")#tao-math("{\\ll \\left|I\\right| \\prod_{p \\in {\\mathcal P}} (1 - \\frac{1}{p})}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" This follows for instance from the ")#link("https://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("fundamental lemma of sieve theory")]#text(" (see e.g. Corollary 19 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("this blog post")]#text("). (One can also use the Selberg sieve or the large sieve.) ")#mi("\\Box")#linebreak()#text(" Finally, we record a standard estimate on the number of smooth numbers:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-ac0b52a2ae6ef99999bc>#text(" Let ")#mi("{u \\geq 1}")#text(" and ")#mi("{\\varepsilon>0}")#text(", and suppose that ")#mi("{x}")#text(" is sufficiently large depending on ")#mi("{u,\\varepsilon}")#text(". Then the number of natural numbers in ")#mi("{[1,x]}")#text(" which have no prime factor larger than ")#mi("{x^{1/u}}")#text(" is at most ")#mi("{O( u^{-(1-\\varepsilon)u} x )}")#text(".")
]

#emph[#text("Proof:")]#text(" See Corollary 1.3 of ")#link("http://www.ams.org/mathscinet-getitem?mr=1265913")[#text("this paper of Hildebrand and Tenenbaum")]#text(". (The result also follows from the more classical work of Dickman.) We sketch a short proof here ")#link("http://www.math.uiuc.edu/~ford/sieve_notes_smoothnumbers.pdf")[#text("due to Kevin Ford")]#text(". Let ")#mi("{{\\mathcal S}}")#text(" denote the set of numbers that are “smooth” in the sense that they have no prime factor larger than ")#mi("{x^{1/u}}")#text(". It then suffices to prove the bound ")#metadata(none) <tao-94695a4b667b958b8fe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\in {\\mathcal S}: n \\leq x} \\log n \\ll \\exp( - u \\log u + O(u) ) x \\log x,")]]

#text("since the contribution of those ")#mi("{n}")#text(" less than (say) ")#mi("{\\sqrt{x}}")#text(" is negligible, and for the other values of ")#mi("{n}")#text(", ")#mi("{\\log n}")#text(" is comparable to ")#mi("{\\log x}")#text(". Writing ")#mi("{\\log n = \\sum_{dm=n} \\Lambda(d)}")#text(", we can rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\in {\\mathcal S}: m \\leq x} \\sum_{d \\in {\\mathcal S}: d \\leq x/m} \\Lambda(d).")]]

#text("By the prime number theorem, the contribution to ")#mi("{\\sum_{d \\in {\\mathcal S}: d \\leq x/m} \\Lambda(d)}")#text(" of those ")#mi("{d \\leq x^{1/u}}")#text(" is ")#mi("{O( \\min( x^{1/u}, x/m )}")#text(", and the contribution of those ")#mi("{d}")#text(" with ")#mi("{d > x^{1/u}}")#text(" consists only of prime powers, which contribute ")#mi("{O( (x/m)^{1/2} )}")#text(". Combining these estimates, we can get a bound of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}: d \\leq x/m} \\Lambda(d) \\ll (x/m)^{1-\\rho} (x^{1/u})^\\rho")]]

#text("where ")#mi("{0 < \\rho < 1/2}")#text(" is a quantity to be chosen later. Thus we can bound the left-hand side of ")#link(<tao-94695a4b667b958b8fe9>)[#text("(4)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("O( x^{\\rho/u} x^{1-\\rho} \\sum_{m \\in {\\mathcal S}} \\frac{1}{m^{1-\\rho}} )")]]

#text("which by Euler products can be bounded by")

#align(center)[#tao-fit-display[#mitex("O( x^{\\rho/u} x^{1-\\rho} \\exp( \\sum_{p \\leq x^{1/u}} \\frac{1}{p^{1-\\rho}} ) ).")]]

#text("By the mean value theorem applied to the function ")#mi("{t \\mapsto \\exp( \\rho t \\log x^{1/u})}")#text(", we can bound ")#mi("{p^\\rho = \\exp( \\rho \\log p )}")#text(" by ")#mi("{1 + \\frac{\\log p}{\\log x^{1/u}} \\exp( \\rho \\log x^{1/u} )}")#text(" for ")#mi("{p \\leq x^{1/u}}")#text(". By Mertens’ theorem, we thus get a bound of")

#align(center)[#tao-fit-display[#mitex("O( x^{\\rho/u} x^{1-\\rho} \\exp( \\log\\log x^{1/u} + O( \\exp( \\rho \\log x^{1/u} ) ) ).")]]

#text("If we make the choice ")#mi("{\\rho := \\frac{\\log u}{\\log x^{1/u}}}")#text(", we obtain the required bound ")#link(<tao-94695a4b667b958b8fe9>)[#text("(4)")]#text(". ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Proof of theorem — ")]]

#text("By increasing ")#mi("{M}")#text(" as necessary we may assume that ")#mi("{M \\geq 10}")#text(" (say). Let ")#mi("{0 < \\varepsilon_2 < \\varepsilon_1 \\leq 1/2}")#text(" be small parameters (depending on ")#mi("{M}")#text(") to be optimised later; we assume ")#mi("{x}")#text(" to be sufficiently large depending on ")#mi("{\\varepsilon_1,\\varepsilon_2,T}")#text(". Call a prime ")#mi("{p}")#text(" ")#emph[#text("small")]#text(" if ")#mi("{p \\leq x^{\\varepsilon_2}}")#text(", ")#emph[#text("medium")]#text(" if ")#mi("{x^{\\varepsilon_2} < p \\leq x^{\\varepsilon_1}}")#text(", and ")#emph[#text("large")]#text(" if ")#mi("{x^{\\varepsilon_1} < p \\leq x}")#text(". Observe that for any ")#mi("{n \\leq x}")#text(" we can factorise ")#mi("{f}")#text(" as a Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("f(n) = f_1 * f_2 * f_3(n)")]]

#text("where")

#list(
[#mi("{f_1}")#text(" is the restriction of ")#mi("{f}")#text(" to those natural numbers ")#mi("{n}")#text(" whose prime factors are all small;")],
[#mi("{f_2}")#text(" is the restriction of ")#mi("{f}")#text(" to those natural numbers ")#mi("{n}")#text(" whose prime factors are all medium;")],
[#mi("{f_3}")#text(" is the restriction of ")#mi("{f}")#text(" to those natural numbers ")#mi("{n}")#text(" whose prime factors are all large.")]
)

#text("We thus have ")#metadata(none) <tao-42da1e44c3668a088a3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) = \\frac{1}{x} \\sum_{n \\leq x} f_1*f_2*f_3(n).")]]

#text("It is convenient to remove the Dirac function ")#mi("{\\delta(n) := 1_{n=1}}")#text(" from ")#mi("{f_2,f_3}")#text(", so we write")

#align(center)[#tao-fit-display[#mitex("f_2 = \\delta + f^{\\prime}_2; \\quad f_3 = \\delta + f^{\\prime}_3")]]

#text("and split")

#align(center)[#tao-fit-display[#mitex("f_1*f_2*f_3 = f_1*f_2 + f_1*f^{\\prime}_3 + f_1*f^{\\prime}_2*f^{\\prime}_3.")]]

#text("Note that ")#mi("{f_1*f_2}")#text(" is the restriction of ")#mi("{f}")#text(" to those numbers ")#mi("{n \\leq x}")#text(" whose prime factors are all small or medium. By Proposition ")#link(<tao-ac0b52a2ae6ef99999bc>)[#text("6")]#text(", the number of such ")#mi("{n}")#text(" can certainly be bounded by ")#mi("{O(e^{-1/\\varepsilon_1} x)}")#text(" if ")#mi("{x}")#text(" is sufficiently large. Thus the contribution of this term to ")#link(<tao-42da1e44c3668a088a3a>)[#text("(5)")]#text(" is ")#mi("{O( e^{-1/\\varepsilon_1} )}")#text(".")#linebreak()#text(" Similarly, ")#mi("{f_1 * f^{\\prime}_3}")#text(" is the restriction of ")#mi("{f}")#text(" to those numbers ")#mi("{n \\leq x}")#text(" which contain at least one large prime factor, but no medium prime factors. By Proposition ")#link(<tao-e6367a6a683bc7367283>)[#text("5")]#text(" the number of such ")#mi("{n}")#text(" is bounded by ")#mi("{O( \\frac{\\varepsilon_2}{\\varepsilon_1} x )}")#text(" if ")#mi("{x}")#text(" is sufficiently large. Thus the contribution of this term to ")#link(<tao-42da1e44c3668a088a3a>)[#text("(5)")]#text(" is ")#mi("{O( \\frac{\\varepsilon_2}{\\varepsilon_1} )}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll \\left|\\frac{1}{x} \\sum_{n \\leq x} f_1*f^{\\prime}_2*f^{\\prime}_3(n)\\right| + e^{-1/\\varepsilon_1} + \\frac{\\varepsilon_2}{\\varepsilon_1}.", block: true)]]

#text("Note that ")#mi("{f_1*f^{\\prime}_2*f^{\\prime}_3}")#text(" is only supported on numbers whose prime factors do not exceed ")#mi("{x}")#text(", so the Dirichlet series of ")#mi("{f_1*f^{\\prime}_2*f^{\\prime}_3}")#text(" is absolutely convergent for ")#mi("{\\text{Re}(s) \\geq 1}")#text(" and is equal to ")#mi("{F_1(s) F^{\\prime}_2(s) F^{\\prime}_3(s)}")#text(", where ")#mi("{F_1,F^{\\prime}_2,F^{\\prime}_3}")#text(" are the Dirichlet series of ")#mi("{f_1,f^{\\prime}_2,f^{\\prime}_3}")#text(" respectively. Since ")#mi("{f_1*f^{\\prime}_2*f^{\\prime}_3}")#text(" is bounded in magnitude by ")#mi("{1}")#text(" (being a restriction of ")#mi("{f}")#text("), we may apply Proposition ")#link(<tao-5111f93f8a30fe634de9>)[#text("3")]#text(" and conclude (for ")#mi("{x}")#text(" large enough, and discarding the ")#tao-math("{\\frac{1}{1+\\left|t\\right|}}", block: false)#text(" denominator) that")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{x} \\sum_{n \\leq x} f(n)  & \\ll \\int_{\\left|t\\right| \\leq T} \\left|F_1(1+it)\\right| \\left|F^{\\prime}_2(1+it)\\right| |F^{\\prime}_3(1+it)|\\ dt", block: true)



#tao-math(" & + \\frac{1}{T} + e^{-1/\\varepsilon_1} + \\frac{\\varepsilon_2}{\\varepsilon_1}.", block: true)
]

#text("We now record some ")#mi("{L^2}")#text(" estimates:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" For sufficiently large ")#mi("{x}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F^{\\prime}_2(1+it)\\right|^2\\ dt \\ll \\frac{\\varepsilon_1}{\\varepsilon_2^2 \\log x}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F^{\\prime}_3(1+it)\\right|^2\\ dt \\ll \\frac{1}{\\varepsilon_1^2 \\log x}.", block: true)]]
]

#emph[#text("Proof:")]#text(" We just prove the former inequality, as the latter is similar. By Proposition ")#link(<tao-acc00388143c72bb5771>)[#text("4")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F^{\\prime}_2(1+it)\\right|^2\\ dt \\ll T \\sum_{n_1,n_2: \\log n_1 = \\log n_2 + O(1/T)} \\frac{\\left|f^{\\prime}_2(n_1)\\right| \\left|f^{\\prime}_2(n_2)\\right|}{n_1 n_2}.", block: true)]]

#text("The term ")#mi("{f^{\\prime}_2(n_1)}")#text(" vanishes unless ")#mi("{n_1 \\geq x^{\\varepsilon_2}}")#text(", and we have ")#mi("{n_2 = (1+O(1/T)) n_1}")#text(", so we can bound the right-hand side by")

#align(center)[#tao-fit-display[#tao-math("\\ll T \\sum_{n_1 \\geq x^{\\varepsilon_2}} \\frac{\\left|f^{\\prime}_2(n_1)\\right|}{n_1^2}\\sum_{n_2 = (1+O(1/T)) n_1} \\frac{\\left|f^{\\prime}_2(n_2)\\right|}{n}.", block: true)]]

#text("The inner summand is bounded by ")#mi("{1}")#text(" and supported on those ")#mi("{n_2}")#text(" that are not divisible by any small primes. From Proposition ")#link(<tao-e6367a6a683bc7367283>)[#text("5")]#text(" and Mertens’ theorem we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n_2 = (1+O(1/T)) n_1} \\left|f^{\\prime}_2(n_2)\\right| \\ll \\frac{1}{T \\varepsilon_2 \\log x} n_1", block: true)]]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\left|t\\right| \\leq T} \\left|F^{\\prime}_2(1+it)\\right|^2\\ dt  & \\ll \\frac{1}{\\varepsilon_2 \\log x} \\sum_{n_1} \\frac{\\left|f^{\\prime}_2(n_1)\\right|}{n_1}", block: true)



#tao-math(" & \\ll \\frac{1}{\\varepsilon_2 \\log x} \\prod_{x^{\\varepsilon_2} < p \\leq x^{\\varepsilon_1}} (1-\\frac{1}{p})^{-1}", block: true)



#tao-math(" & \\ll \\frac{\\varepsilon_1}{\\varepsilon^2_2 \\log x}", block: true)
]

#text("as desired. ")#mi("\\Box")#linebreak()#text(" We also have an ")#mi("{L^\\infty}")#text(" estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" For sufficiently large ")#mi("{x}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|F_1(1+it)\\right| \\ll \\frac{1}{\\varepsilon_2} e^{-M} \\log x", block: true)]]

#text("for all ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" From Euler products, Mertens’ theorem, and ")#link(<tao-aa29da6b8c5d39298ba0>)[#text("(1)")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("F_1(1+it)  & = \\prod_{p \\leq x^{\\varepsilon_2}} \\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{j(1+it)}}", block: true)



#tao-math(" & \\ll \\prod_{p \\leq x^{\\varepsilon_2}} \\left|1 + \\frac{f(p) p^{-it}}{p}\\right|", block: true)



#tao-math(" & \\ll \\exp( \\sum_{p \\leq x^{\\varepsilon_2}} \\text{Re} \\frac{f(p) p^{-it}}{p} )", block: true)



#tao-math(" & \\ll \\varepsilon_2 \\log x \\exp( - \\sum_{p \\leq x^{\\varepsilon_2}} \\frac{1 - \\text{Re} f(p) p^{-it}}{p} )", block: true)



#tao-math(" & \\ll \\varepsilon_2 \\log x \\exp( -M + 2\\log \\frac{1}{\\varepsilon_2} )", block: true)



#tao-math(" & \\ll \\frac{1}{\\varepsilon_2} e^{-M} \\log x", block: true)
]

#text("as desired. ")#mi("\\Box")#linebreak()#text(" Applying Hölder’s inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{x} \\sum_{n \\leq x} f(n) \\ll \\frac{1}{\\varepsilon_1^{1/2} \\varepsilon^2_2} e^{-M} + e^{-1/\\varepsilon_1} + \\frac{\\varepsilon_2}{\\varepsilon_1}.")]]

#text("Setting ")#mi("{\\varepsilon_1 := 1/M}")#text(" and ")#mi("{\\varepsilon_2 := M^{1/6} e^{-M/3}}")#text(" we obtain the claim.")

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96509e4e10f3574ed8885abb4d60023ad708f299b8e9fd3e4529c1c96133e1b7-ecc9c3c26aa84925f97b2952dc74e5e98f9f7f68c50532e8ace0132c6643f065.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of normsinc")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462337")[#strong[#text("normsinc")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("Is there a typo in the introduction of the normalised sinc function sinc(pi*x) = sin(pi*x) / (pi*x)? Should this be sinc(x) = sin(pi*x) / (pi*x) to match the wikipedia notation for normalised sinc?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462391")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("There may be a typo in the inequality (1) in Theorem 1. As it is stated now, as soon as (1) holds for some M it holds for any larger M’, and therefore the ")#mi("(1+M)e^{-M}")#text(" term could be made arbitrarily small in the conclusion of the theorem. Also, the fact that (1) requires a bound from above does not seem consistent with the corollary stated right after Theorem 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c356feedd92ebfabcde022b781f7a91de37975bce70dd7bf8c42811a2c19c3a-1da4b0c1530936e9e346447f18b77701725425a58c51b7041502657096e726e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pybienvenu")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462399")[#strong[#text("pybienvenu")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Indeed, in (1) this should be ")#mi("\\geq M")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462401")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Does Halasz inequality imply the prime number theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462402")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("The prime number theorem is equivalent to the assertion that ")#mi("\\sum_{n \\leq x} \\mu(n) = o(x)")#text(". Applying Halasz’s inequality, we see that to prove the prime number theorem, one needs to obtain a non-trivial lower bound on ")#mi("\\text{Re} \\sum_p \\frac{p^{-it}}{p}")#text(" for any real ")#mi("t")#text(", which is equivalent to the non-vanishing of ")#mi("\\zeta(1+it)")#text(". This is not surprising since the other proofs of the PNT already demonstrate the equivalence of the PNT with the lack of zeroes of zeta on the line ")#mi("\\text{Re} s = 1")#text(". Of course, one still has to establish the non-vanishing of ")#mi("\\zeta(1+it)")#text(", and for this one can use any of the standard techniques, e.g. one can use the inequality ")#mi("\\text{Re} 3 + 4 p^{-it} + p^{-2it} \\geq 0")#text(" together with an upper bound for ")#mi("\\text{Re} \\sum_p \\frac{p^{-2it}}{p}")#text(" (or equivalently, an upper bound for ")#tao-math("\\left|\\zeta(1+2it)\\right|", block: false)#text(").")

#text("In the pretentious approach to multiplicative number theory, Halasz’s inequality is basically used as a replacement for complex methods (such as those based on Perron’s formula), but does not directly address the most difficult part of the theory, which is to determine the location of the zeroes of various zeta and L-functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462411")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("There were a few conceptual leaps in understanding the prime number theorem, if at all.")

#text("Even though ")#mi("\\sum \\frac{1}{n}")#text(" diverges, any twist is finite ")#mi("0 < \\sum \\frac{1}{n^{1+it}} < \\infty")#text(". This is a very myopic – or astigmatic – way of looking at numbers; things are very blurry ")#mi("x \\approx  0,  1 \\text{ or } \\infty")#text(". All of these averages together prove the prime number theorem.")

#text("There are a few ways to show ")#mi("\\zeta(1 + it) \\neq 0")#text(" in the book Titchmarsh. If I read them again, I might understand why that trig equality ")#mi("3 + 4\\cos \\theta + \\cos 2\\theta \\geq 0")#text(" is so special here. IDK")

#text("I am also reminded of contest problems where we try to \"paint\" all real numbers which certain restrictions on rectangles, or triangles, or related pairs of points. Then the objective is to prove function must be 0.")

#text("What are mains is an \"engine\" which turns estimates of the zeta function into estimate about primes. Halasz inequality requires some multiplicative function with ")#tao-math("\\left|f(p)\\right| \\leq 1", block: false)#text(" and somehow you estimate the averages in (1) and out pops this averaging result.")

#text("A priori if we add a bunch of complex numbers we can't assume the average is zero can we?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Do you think a different approach can be made in a less “pretentious” way?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462413")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Is condition (1) “natural” in some sense? (i.e. is it based on some motivation from which it “naturally” follows in more or less systematic way ?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("One can view the quantity ")#mi("(\\sum_{p \\leq x} \\frac{1 - \\text{Re} f(p) \\overline{g(p)}}{p})^{1/2}")#text(" as a measure of “distance” between two multiplicative functions ")#mi("f, g")#text("; in the language of Granville and Soundarajan, this quantity measures the extent to which ")#mi("f")#text(" “pretends” to be like ")#mi("g")#text(" or vice versa. (With the square root, this distance obeys the triangle inequality.) The condition (1) is then asserting that the function ")#mi("f(n)")#text(" does not pretend to be like any of the Archimedean characters ")#mi("n^{it}")#text(".")

#text("Using the Euler product formula ")#mi("\\sum_n \\frac{f(n)}{n^s} = \\prod_p (1 + \\frac{f(p)}{p^s} + \\dots)")#text(", the condition (1) is also basically equivalent to an upper bound on the magnitude of the Dirichlet series of ")#mi("f")#text(" on the line segment ")#tao-math("\\{ 1+it: \\left|t\\right| \\leq T \\}", block: false)#text(", which is already known (through the Perron formula) to be closely tied to the problem of obtaining asymptotics for ")#mi("\\frac{1}{x} \\sum_{n \\leq x} f(n)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462467")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("This seems to motivate the following generalization of condition (1):")#linebreak()#text(" Let ")#mi("M(x, \\sigma, T)")#text(" denote for ")#mi("\\sigma \\leq 1")#text(" the minimum of the LHS of (1) with its denominator generalized to ")#mi("p^{\\sigma}")#text(".")#linebreak()#text(" This may give (for ")#mi("M(x, \\sigma, T) \\geq 0")#text(") generalized versions of theorems 1, 2.")#linebreak()#text(" Moreover, any additional information on possible meromorphic continuation of the Dirichlet series of ")#mi("f")#text(" into the half plane ")#mi("\\sigma \\leq 1")#text(", may help to improve further the estimates.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db54cdce6dc8c5d3d2b6d0ade4443bf06528b4e4787fa692b099bd204a551cf8-0b79c847b708f50019686686562fefe21067ef2c10cc75f933f2cac89bea14a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jessemckeown")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462463")[#strong[#text("jessemckeown")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("In the “cheap” version, is the algebraic term really meant to be 1/T ? for the interesting Ts, this is rather smaller than the “pretentious” version. (o.t.o.h, I suppose the interest is more for small M, where we get a lot for very little?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("Yes, 1/T appears to be the natural dependence on T (as one also sees from the Granville-Soundararajan refinement of the original Halasz inequality, mentioned in the blog post); this type of error also shows up for instance in the truncated Perron formula (up to logarithmic losses, at least).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5884c68dfe35321079402b02d8e1755ffe56a5ea7820c0a018a599cfa67cd55-6ca6970ce6cd88209b169124e0fcbb6ba442f0e120e5cc7213344eef906f9fa9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bittu")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462583")[#strong[#text("Bittu")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2015")])]

#text("Terry sir,I am a big fan of yours.I was proposing that calculus requires functions but most of the things around us are so irregular that a proper fitting function can’t be given to it.Can you develop a superior language than calculus please.")

#emph[#text("[See ")#link("https://en.wikipedia.org/wiki/Generalized_function")[#text("https://en.wikipedia.org/wiki/Generalized_function")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462644")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("There seems to be a few typos still. Right after the heading “2. Proof of theorem” there is “By increasing M ias necessary…” Then about half a page below that “By Proopsition 5 th enumber…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dea805f89ee00c35cfc8cc4573bb754fe7c944154a48164c0fb8e54e65342bb-c1ae1e6dc384f0ebf67aeb7d493a4623dda0620d7cd0144a4bfa1d33b56868dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ford")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462770")[#strong[#text("Kevin Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2015")])]

#text("A short proof of Proposition 6 can be found here: ")#link("http://www.math.uiuc.edu/~ford/sieve_notes_smoothnumbers.pdf")[#text("http://www.math.uiuc.edu/~ford/sieve_notes_smoothnumbers.pdf")]

#emph[#text("[Thanks for reminding me of your nice proof, I have added a version of it to the text. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dea805f89ee00c35cfc8cc4573bb754fe7c944154a48164c0fb8e54e65342bb-c1ae1e6dc384f0ebf67aeb7d493a4623dda0620d7cd0144a4bfa1d33b56868dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ford")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462867")[#strong[#text("Kevin Ford")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("I don’t claim any originality in the proof. It just combines the method of Wirsing (logarithmic weights) with the “Rankin trick” (introducing the parameter $\\rho$), both quite useful elementary tools for studying sums of multiplicative functions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2015")])]

#text("Dear Terry,")#linebreak()#text(" I’m always worry of you.I consider you like my brother.There’s recently a man claims to solve Riemann hypothesis but not give any proof.I never believe him.Terry, even yourself,a great genius, also very hard to struggle with Riemann.I advice you should’nt devote your result of Riemann early.It’s")#linebreak()#text(" dangerous .He certainly plagiarizes.This is a tip trick to trap you.At that time, he will have three things: money, fame, girls.The sixth sense tells me know about this.")#linebreak()#text(" Best regards,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462907")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("I was curious which part of the above argument fails to achieve the better quantitative bounds, and what kind of ideas are needed for improvements.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-462924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("Adam Harper has an unpublished variant of this argument (from a few years back) which obtains the sharp bound. I think the main additional idea is to use the trick (which Kevin attributed to Wirsing in this comment thread) of summing ")#mi("\\sum_{n \\leq x} f(n) \\log n")#text(" in place of ")#mi("\\sum_{n \\leq x} f(n)")#text(", and then decomposing ")#mi("n \\mapsto f(n) \\log n")#text(" as a triple convolution. (As far as I know, though, Adam has not yet made this argument publicly available.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9caef4b5028ca7355308de0c46c5b850ec5540b37d58342c19ada8249ad4a5d1-1d2a6405039b90a1e214593db2478ec2f5565fc5cc4075f766beb0d3547c7a46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mallesham")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-540861")[#strong[#text("Mallesham")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2020")])]

#text("There is typo in the proof Lemma 8.")

#emph[#text("[Can you be more precise about this? – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9caef4b5028ca7355308de0c46c5b850ec5540b37d58342c19ada8249ad4a5d1-1d2a6405039b90a1e214593db2478ec2f5565fc5cc4075f766beb0d3547c7a46.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mallesham")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-541479")[#strong[#text("Mallesham")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2020")])]

#text("In the fourth and fifth lines of the proof of Lemma 8, I think it should be exponential of sum over primes instead of product over primes.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/89ab064aed799c9cad7dbbd783452301b57722af66f723fe112aa51cbe3aa59d-1b5a15fb34a7105dab1417791021dc3dd51547a510ba9f49b762e96d4ca2af40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of irvingxryang")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-631247")[#strong[#text("irvingxryang")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2021")])]

#text("for proof of Lemma 7, in the second line of expressions, you missed a term 1/n_2")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-684940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2024")])]

#text("I think the proof of Lemma 8 is probably wrong, though the result is right. In the second last inequality of your proof, the log log should be 2 loglog . If you drop these negative terms, which has at most a constant contribution in the initial Euler expansion, you would obtain the loglog as desired.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-684941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2024")])]

#text("Can you clarify? I don’t see any log log terms in the proof of Lemma 8.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/#comment-688552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2025")])]

#text("The conclusion of Lemma 8 is actually wrong. If we take ")#mi("f(p)=-1")#text(" and ")#mi("t=0")#text(", then ")#mi("F_1(i+it)\\asymp \\epsilon^{-1}(\\log x)^{-1}")#text(" but ")#mi("e^{-M} \\log x\\sim (\\log x)^{-1}")#text(". Hence the correct result shall be ")#mi("F_1(i+it)\\ll e^{-M}\\epsilon_2^{-1}\\log x")#text(" and the exponent in the final result is ")#mi("1/3")#text(" in place of ")#mi("1/2")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
