// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/
// Converted to Typst by tao2typ: "2026-10-14T15:20:52.060576+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Host–Kra F^omega_2-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the U^6(F^n_2) norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse theorem for the U^k Gowers uniformity norms on finite abelian groups of bounded torsion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Host–Kra F^omega_2-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the U^6(F^n_2) norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse theorem for the U^k Gowers uniformity norms on finite abelian groups of bounded torsion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 March 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/")[#text("https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://asgarjam.wixsite.com/home")[#text("Asgar Jamneshan")]#text(", ")#link("http://www.math.huji.ac.il/~orshalom/")[#text("Or Shalom")]#text(", and myself have just uploaded to the arXiv our preprints “")#link("https://arxiv.org/abs/2303.04853")[#text("A Host–Kra ")#mi("{{\\bf F}^\\omega_2}")#text("-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the ")#mi("{U^6({\\bf F}^n_2)}")#text(" norm")]#text("” and “")#link("https://arxiv.org/abs/2303.04860")[#text("The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse theorem for the ")#mi("{U^k}")#text(" Gowers uniformity norms on finite abelian groups of bounded torsion")]#text("“. These two papers are both concerned with advancing the inverse theory for the Gowers norms and Gowers-Host-Kra seminorms; the first paper provides a counterexample in this theory (in particular disproving a conjecture of Bergelson, Ziegler and myself), and the second paper gives new positive results in the case when the underlying group is bounded torsion, or the ergodic system is totally disconnected. I discuss the two papers more below the fold.")

#metadata(none) <tao-f455b08f84d2490588d2>

#heading(level: 1)[#strong[#text(" — 1. System of order ")#mi("{5}")#text(" which is not Abramov of order ")#mi("{5}")#text(" — ")]]

#text("I gave a talk on this paper ")#link("https://www.youtube.com/watch?v=QMoRi_9Lmn4&ab_channel=InstituteforAdvancedStudy")[#text("recently at the IAS")]#text("; the slides for that talk are available ")#link("https://terrytao.wordpress.com/wp-content/uploads/2023/03/nonmeasurability.pdf")[#text("here")]#text(".")

#text("This project can be motivated by the inverse conjecture for the Gowers norm in finite fields, which is now a theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Inverse conjecture for the Gowers norm in finite fields)")]#text(" ")#metadata(none) <tao-89df50537dd8255045c5>#text(" Let ")#mi("{p}")#text(" be a prime and ")#mi("{k \\geq 1}")#text(". Suppose that ")#mi("{f: {\\bf F}_p^n \\rightarrow {\\bf C}}")#text(" is a one-bounded function with a lower bound ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}({\\bf F}_p^n)} \\geq \\delta > 0}", block: false)#text(" on the ")#link("https://en.wikipedia.org/wiki/Gowers_norm")[#text("Gowers uniformity norm")]#text(". Then there exists a (")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("non-classical")]#text(") polynomial ")#mi("{P: {\\bf F}_p^n \\rightarrow {\\bf T}}")#text(" of degree at most ")#mi("{k}")#text(" such that ")#tao-math("{\\left|{\\bf E}_{x \\in {\\bf F}_p^n} f(x) e(-P(x))\\right| \\gg_{p,k,\\delta} 1}", block: false)#text(".")
]

#text("This is now known for all ")#mi("{p,k}")#text(" (see ")#link("https://terrytao.wordpress.com/2011/01/11/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-in-low-characteristic/")[#text("this paper of Ziegler and myself")]#text(" for the first proof of the general case, and ")#link("https://arxiv.org/abs/2207.01591")[#text("this paper of Milicevic")]#text(" for the most recent developments concerning quantitative bounds), although initial results focused on either small values of ")#mi("{k}")#text(", or the “high characteristic” case when ")#mi("{p}")#text(" is large compared to ")#mi("{k}")#text(". One approach to this theorem proceeds via ergodic theory. Indeed it was observed in ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("this previous paper of Ziegler and myself")]#text(" that for a given choice of ")#mi("{p}")#text(" and ")#mi("{k}")#text(", the above theorem follows from the following ergodic analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Inverse conjecture for the Gowers-Host-Kra semi-norm in finite fields)")]#text(" ")#metadata(none) <tao-040264644dd55339c009>#text(" Let ")#mi("{p}")#text(" be a prime and ")#mi("{k \\geq 1}")#text(". Suppose that ")#mi("{f \\in L^\\infty(X)}")#text(" with ")#mi("{X}")#text(" an ergodic ")#mi("{{\\bf F}_p^\\omega}")#text("-system with positive Gowers-Host-Kra seminorm ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}(X)}}", block: false)#text(" (see for instance ")#link("https://terrytao.wordpress.com/2015/04/09/the-ergodic-theorem-and-gowers-host-kra-seminorms-without-separability-or-amenability/")[#text("this previous post")]#text(" for a definition). Then there exists a measurable polynomial ")#mi("{P: X \\rightarrow {\\bf T}}")#text(" of degree at most ")#mi("{k}")#text(" such that ")#mi("{f}")#text(" has a non-zero inner product with ")#mi("{e(P)}")#text(". (In the language of ergodic theory: every ")#mi("{{\\bf F}_p^\\omega}")#text("-system of order ")#mi("{k}")#text(" is an Abramov system of order ")#mi("{k}")#text(".)")
]

#text("The implication proceeds by a correspondence principle analogous to the Furstenberg correspondence principle developed in that paper (see also ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2889824")[#text("this paper of Towsner")]#text(" for a closely related principle, and ")#link("https://terrytao.wordpress.com/2021/12/28/the-inverse-theorem-for-the-u3-gowers-uniformity-norm-on-arbitrary-finite-abelian-groups-fourier-analytic-and-ergodic-approaches/")[#text("this paper of Jamneshan and I")]#text(" for a refinement). In ")#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("a paper with Bergelson and Ziegler")]#text(", we were able to establish Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" in the “high characteristic” case ")#mi("{p \\geq k+1}")#text(", thus also proving Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(" in this regime, and conjectured that Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" was in fact true for all ")#mi("{p,k}")#text(". This was recently verified in the slightly larger range ")#mi("{p \\geq k-1}")#text(" ")#link("https://arxiv.org/abs/2109.15281")[#text("by Candela, Gonzalez-Sanchez, and Szegedy")]#text(".")

#text("Even though Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(" is now known in full generality by other methods, there are still combinatorial reasons for investigating Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(". One of these is that the implication of Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(" from Corollary ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" in fact gives additional control on the polynomial ")#mi("{P}")#text(" produced by Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(", namely that it is some sense “measurable in the sigma-algebra generated by ")#mi("{f}")#text("” (basically because the ergodic theory polynomial ")#mi("{P}")#text(" produced by Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" is also measurable in ")#mi("{X}")#text(", as opposed to merely being measurable in an extension of ")#mi("{X}")#text("). What this means in the finitary setting of ")#mi("{{\\bf F}_p^n}")#text(" is a bit tricky to write down precisely (since the naive sigma-algebra generated by the translates of ")#mi("{f}")#text(" will mostly likely be the discrete sigma-algebra), but roughly speaking it means that ")#mi("{P}")#text(" can be approximated to arbitrary accuracy by functions of boundedly many (random) translates of ")#mi("{f}")#text(". This can be interpreted in a complexity theory sense by stating that Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(" can be made “algorithmic” in a “probabilistic bounded time oracle” or “local list decoding” sense which we will not make precise here.")

#text("The main result of this paper is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(" fails for ")#mi("{p=2, k=5}")#text(". In fact the “measurable inverse theorem” alluded to above also fails in this case.")
]

#text("Informally, this means that for large ")#mi("{n}")#text(", we can find ")#mi("{1}")#text("-bounded “pseudo-quintic” functions ")#mi("{f: {\\bf F}_2^n \\rightarrow {\\bf C}}")#text(" with large ")#mi("{U^6({\\bf F}^2_n)}")#text(" norm, which then must necessarily correlate with at least one quintic ")#mi("{e(P)}")#text(" by Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(", but such that none of these quintics ")#mi("{e(P)}")#text(" can be approximated to high accuracy by functions of (random) shifts of ")#mi("{f}")#text(". Roughly speaking, this means that the inverse ")#mi("{U^6({\\bf F}_2^n)}")#text(" theorem cannot be made locally algorithmic (though it is still possible that a Goldreich-Levin type result of polynomial time algorithmic inverse theory is still possible, as is already known for ")#mi("{U^k({\\bf F}^n)}")#text(" for ")#mi("{k=2,3,4}")#text("; see ")#link("https://arxiv.org/abs/2207.13281")[#text("this recent paper of Kim, Li and Tidor")]#text(" for further discussion).")

#text("The way we arrived at this theorem was by (morally) reducing matters to understanding a certain “finite nilspace cohomology problem”. In the end it boiled down to locating a certain function ")#mi("{\\rho: C^6( {\\mathcal D}^2({\\bf F}_2^2)) \\rightarrow \\frac{1}{2}{\\bf Z}/{\\bf Z}}")#text(" from a ")#mi("{2^{2(1+6+\\binom{6}{2})}}")#text("-element set ")#mi("{C^6( {\\mathcal D}^2({\\bf F}_2^2))}")#text(" to a two-element set which was a “strongly ")#mi("{2}")#text("-homogeneous cocycle” but not a “coboundary” (these terms are defined precisely in the paper). This strongly ")#mi("{2}")#text("-homogeneous cocycle ")#mi("{\\rho}")#text(" can be expressed in terms of a simpler function ")#mi("{\\psi: C^1( {\\mathcal D}^2({\\bf F}_2^2)) \\rightarrow {\\bf T}}")#text(" that takes values on a ")#mi("{2^4}")#text("-element space ")#mi("{C^1( {\\mathcal D}^2({\\bf F}_2^2))}")#text(". The task of locating ")#mi("{\\psi}")#text(" turned out to be one that was within the range of our (somewhat rudimentary) SAGE computation abilities (mostly involving computing the Smith normal form of some reasonably large integer matrices), but the counterexample functions ")#mi("{\\psi, \\rho}")#text(" this produced were initially somewhat opaque to us. After cleaning up these functions by hand (by subtracting off various “coboundaries”), we eventually found versions of these functions which were nice enough that we could verify all the claims needed in a purely human-readable fashion, without any further computer assistance. As a consequence, we can now describe the pseudo-quintic ")#mi("{f: {\\bf F}_2^n \\rightarrow {\\bf C}}")#text(" explicitly, though it is safe to say we would not have been able to come up with this example without the initial computer search, and we don’t currently have a broader conceptual understanding of which ")#mi("{p,k}")#text(" could potentially generate such counterexamples. The function ")#mi("{f}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("f = e( \\frac{\\binom{R}{2} Q}{2} + P )")]]

#text("where ")#mi("{Q: {\\bf F}_2^n \\rightarrow {\\bf F}_2}")#text(" is a randomly chosen (classical) quadratic polynomial, ")#mi("{R: {\\bf F}_2^n \\rightarrow {\\bf Z}/4{\\bf Z}}")#text(" is a randomly chosen (non-classical) cubic polynomial, and ")#mi("{P: {\\bf F}_2^n \\rightarrow \\frac{1}{2^5} {\\bf Z}/{\\bf Z}}")#text(" is a randomly chosen (non-classical) quintic polynomial. This function correlates with ")#mi("{e(P)}")#text(" and has a large ")#mi("{U^6({\\bf F}_2^n)}")#text(" norm, but this quintic ")#mi("{e(P)}")#text(" is “non-measurable” in the sense that it cannot be recovered from ")#mi("{f}")#text(" and its shifts. The quadratic polynomial ")#mi("{Q}")#text(" turns out to be measurable, as is the double ")#mi("{2R}")#text(" of the cubic ")#mi("{R}")#text(", but in order to recover ")#mi("{P}")#text(" one needs to apply a “square root” to the quadratic ")#mi("{2R}")#text(" to recover a candidate for the cubic ")#mi("{R}")#text(" which can then be used to reconstruct ")#mi("{P}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Structure of totally disconnected systems — ")]]

#text("Despite the above negative result, in our other paper we are able to get a weak version of Conjecture ")#link(<tao-040264644dd55339c009>)[#text("2")]#text(", that also extends to actions of bounded-torsion abelian groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Weak inverse conjecture for the Gowers-Host-Kra semi-norm in bounded torsion groups)")]#text(" ")#metadata(none) <tao-9708332be0e95efce990>#text(" Let ")#mi("{\\Gamma}")#text(" be a bounded-torsion abelian group and ")#mi("{k \\geq 1}")#text(". Suppose that ")#mi("{f \\in L^\\infty(X)}")#text(" with ")#mi("{X}")#text(" an ergodic ")#mi("{{\\bf F}_p^\\omega}")#text("-system with positive Gowers-Host-Kra seminorm ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}(X)}}", block: false)#text(". Then, after lifting ")#mi("{\\Gamma}")#text(" to a torsion-free group ")#mi("{\\tilde \\Gamma}")#text(", there exists a measurable polynomial ")#mi("{P: Y \\rightarrow {\\bf T}}")#text(" of degree at most ")#mi("{k}")#text(" defined on an ")#emph[#text("extension")]#text(" ")#mi("{Y}")#text(" of ")#mi("{X}")#text(" which has a non-zero inner product with ")#mi("{e(P)}")#text(".")
]

#text("Combining this with the correspondence principle and some additional tools, we obtain a weak version of Theorem ")#link(<tao-89df50537dd8255045c5>)[#text("1")]#text(" that also extends to bounded-torsion groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Inverse conjecture for the Gowers norm in bounded torsion groups)")]#text(" ")#metadata(none) <tao-41859e3b247e23c7ee30>#text(" Let ")#mi("{G}")#text(" be a finite abelian ")#mi("{m}")#text("-torsion group for some ")#mi("{m \\geq 1}")#text(" and ")#mi("{k \\geq 1}")#text(". Suppose that ")#mi("{f: G \\rightarrow {\\bf C}}")#text(" is a one-bounded function with ")#tao-math("{\\left\\|f\\right\\|_{U^{k+1}(G} \\geq \\delta > 0}", block: false)#text(". Then there exists a (non-classical) polynomial ")#mi("{P: G \\rightarrow {\\bf T}}")#text(" of degree at most ")#mi("{O_{k,m}(1)}")#text(" such that ")#tao-math("{\\left|{\\bf E}_{x \\in G} f(x) e(-P(x))\\right| \\gg_{m,k,\\delta} 1}", block: false)#text(".")
]

#text("The degree ")#mi("{O_{k,m}(1)}")#text(" produced by our arguments is polynomial in ")#mi("{k,m}")#text(", but we conjecture that it should just be ")#mi("{k}")#text(".")

#text("The way Theorem ")#link(<tao-9708332be0e95efce990>)[#text("4")]#text(" (and hence Theorem ")#link(<tao-41859e3b247e23c7ee30>)[#text("5")]#text(") is proven is as follows. The now-standard machinery of Host and Kra (as discussed for instance in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3839640")[#text("their book")]#text(") allows us to reduce ")#mi("{X}")#text(" to a system of order ")#mi("{k}")#text(", which is a certain tower of extensions of compact abelian structure groups ")#mi("{U_1,\\dots,U_k}")#text(" by various cocycles ")#mi("{\\rho_1,\\dots,\\rho_{k-1}}")#text(". In the ")#mi("{m}")#text("-torsion case, standard theory allows us to show that these structure groups ")#mi("{U_i}")#text(" are also ")#mi("{m}")#text("-torsion, hence totally disconnected. So it would now suffice to understand the action of torsion-free groups on totally disconnected systems ")#mi("{X}")#text(". For the purposes of proving Theorem ")#link(<tao-9708332be0e95efce990>)[#text("4")]#text(" we have the freedom to extend ")#mi("{X}")#text(" as we please, and we take advantage of this freedom by “extending by radicals”, in the sense that whenever we locate a polynomial ")#mi("{P: X \\rightarrow {\\bf T}}")#text(" in the system, we adjoin to it ")#mi("{d^{th}}")#text(" roots ")#mi("{Q: X \\rightarrow {\\bf T}}")#text(" of that polynomial (i.e., solutions to ")#mi("{dQ=P}")#text(") that are polynomials of the ")#emph[#text("same")]#text(" degree as ")#mi("{P}")#text("; this is usually not possible to do in the original system ")#mi("{X}")#text(", but can always be done in a suitable extension, analogously to how ")#mi("{d^{th}}")#text(" roots do not always exist in a given field, but can always be located in some extension of that field. After applying this process countably many times it turns out that we can arrive at a system which is ")#mi("{\\infty}")#text("-divisible in the sense that polynomials of any degree have roots of any order that are of the same degree. In other words, the group of polynomials of any fixed degree is a ")#link("https://en.wikipedia.org/wiki/Divisible_group")[#text("divisible abelian group")]#text(", and thus ")#link("https://en.wikipedia.org/wiki/Injective_module")[#text("injective")]#text(" in the category of such groups. This makes a lot of short exact sequences that show up in the theory split automatically, and greatly simplifies the cohomological issues one encounters in the theory, to the point where all the cocycles ")#mi("{\\rho_1,\\dots,\\rho_{k-1}}")#text(" mentioned previously can now be “straightened” into polynomials of the expected degree (or, in the language of ergodic theory, this extension is a Weyl system of order ")#mi("{k}")#text(", and hence also Abramov of order ")#mi("{k}")#text("). This is sufficient to establish Theorem ")#link(<tao-9708332be0e95efce990>)[#text("4")]#text(". To get Theorem ")#link(<tao-41859e3b247e23c7ee30>)[#text("5")]#text(", we ran into a technical obstacle arising from the fact that the remainder map ")#mi("{x \\mapsto x \\% m = m \\{ \\frac{x}{m} \\}}")#text(" is not a polynomial mod ")#mi("{m^r}")#text(" if ")#mi("{m}")#text(" is not itself a prime power. To resolve this, we established ergodic theory analogues of the Sylow decomposition ")#mi("{\\Gamma = \\bigoplus_{p|m} \\Gamma_p}")#text(" of abelian ")#mi("{m}")#text("-torsion groups into ")#mi("{p}")#text("-groups ")#mi("{\\Gamma_p}")#text(", as well as the ")#link("https://en.wikipedia.org/wiki/Schur%E2%80%93Zassenhaus_theorem")[#text("Schur-Zassenhaus theorem")]#text(". Roughly speaking, the upshot of these theorems is that any ergodic ")#mi("{\\Gamma}")#text("-system ")#mi("{X}")#text(", with ")#mi("{\\Gamma}")#text(" ")#mi("{m}")#text("-torsion, can be split as the “direct sum” of ergodic ")#mi("{\\Gamma_p}")#text("-systems ")#mi("{X_p}")#text(" for primes ")#mi("{p}")#text(" dividing ")#mi("{m}")#text(", where ")#mi("{\\Gamma_p}")#text(" is the subgroup of ")#mi("{\\Gamma}")#text(" consisting of those elements whose order is a power of ")#mi("{p}")#text(". This allows us to reduce to the case when ")#mi("{m}")#text(" is a prime power without too much difficulty.")

#text("In fact, the above analysis gives stronger structural classifications of totally disconnected systems (in which the acting group is torsion-free). Weyl systems can also be interpreted as translational systems ")#mi("{G/\\Lambda}")#text(", where ")#mi("{G}")#text(" is a nilpotent Polish group and ")#mi("{\\Lambda}")#text(" is a closed cocompact subgroup, with the action being given by left-translation by various elements of ")#mi("{G}")#text(". Perhaps the most famous examples of such translational systems are nilmanifolds, but in this setting where the acting group ")#mi("{\\Gamma}")#text(" is not finitely generated, it turns out to be necessary to consider more general translational systems, in which ")#mi("{G}")#text(" need not be a Lie group (or even locally compact), and ")#mi("{\\Lambda}")#text(" not discrete. Our previous results then describe totally disconnected systems as ")#emph[#text("factors")]#text(" of such translational systems. One natural candidate for such factors are the ")#emph[#text("double coset systems")]#text(" ")#mi("{K \\backslash G / \\Lambda}")#text(" formed by quotienting out ")#mi("{G/\\Lambda}")#text(" by the action of another closed group ")#mi("{K}")#text(" that is normalized by the action of ")#mi("{\\Gamma}")#text(". We were able to show that all totally disconnected systems with torsion-free acting group had this double coset structure. This turned out to be surprisingly subtle at a technical level, for at least two reasons. Firstly, after locating the closed group ")#mi("{K}")#text(" (which in general is Polish, but not compact or even locally compact), it was not immediately obvious that ")#mi("{K \\backslash G / \\Lambda}")#text(" was itself a Polish space (this amounts to the orbits ")#mi("{KA}")#text(" of a closed set ")#mi("{A}")#text(" still being closed), and also not obvious that this double coset space had a good nilspace structure (in particular that the factor map from ")#mi("{G/\\Lambda}")#text(" to ")#mi("{K \\backslash G/\\Lambda}")#text(" is a nilspace fibration). This latter issue we were able to resolve with a tool kindly shared to us in a forthcoming work by Candela, Gonzales-Sanchez, and Szegedy, who observed that the nilspace fibration property was available if the quotient groups ")#mi("{K, \\Lambda}")#text(" obeyed an algebraic “groupable” axiom which we were able to verify in this case (they also have counterexamples showing that the nilspace structure can break down without this axiom). There was however one further rather annoying complication. In order to fully obtain the identification of our system with a double coset system, we needed the equivalence")

#align(center)[#tao-fit-display[#mitex("L^\\infty(G/\\Lambda)^K \\equiv L^\\infty(K \\backslash G / \\Lambda)")]]

#text("between bounded measurable functions on ")#mi("{G/\\Lambda}")#text(" which were ")#mi("{K}")#text("-invariant up to null sets on one hand, and bounded measurable functions on ")#mi("{K \\backslash G/\\Lambda}")#text(" on the other. It is quite easy to embed the latter space isometrically into the former space, and we thought for a while that the opposite inclusion was trivial, but much to our surprise and frustration we were not able to achieve this identification by “soft” methods. One certainly has the topological analogue")

#align(center)[#tao-fit-display[#mitex("C(G/\\Lambda)^K \\equiv C(K \\backslash G / \\Lambda)")]]

#text("of this identification, and ")#mi("{L^\\infty(K \\backslash G / \\Lambda)}")#text(" is the weak closure of ")#mi("{C(K \\backslash G / \\Lambda)}")#text(" and ")#mi("{L^\\infty(G/\\Lambda)}")#text(" the weak closure of ")#mi("{C(G/\\Lambda)}")#text(", but this is not quite enough to close the argument; we also need to have a (weakly) continuous projection operator from ")#mi("{C(G/\\Lambda)}")#text(" to ")#mi("{C(G/\\Lambda)^K}")#text(" to make everything work. When ")#mi("{K}")#text(" is compact (or more generally, locally compact amenable) one could try to do this by averaging over the Haar measure of ")#mi("{K}")#text(", or (possibly) by some averages on Folner sets. In our setting, we know that ")#mi("{K}")#text(" can fail to be locally compact (it can contain groups like ")#mi("{{\\bf Z}^{\\bf N}}")#text("), but we were able to locate a “poor man’s Haar measure” ")#mi("{\\mu}")#text(" on this non-locally compact group ")#mi("{K}")#text(" that was a compactly supported Radon probability measure acted like a Haar measure when pushed forward to individual orbits ")#mi("{Kx}")#text(" of ")#mi("{K}")#text(" on ")#mi("{G/\\Lambda}")#text(", which turned out to be sufficient to get the averaging we needed (and also to establish the Polish nature of ")#mi("{K \\backslash G / \\Lambda}")#text(").")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/#comment-675843")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("The title seems to have some Latex issuses.")

#emph[#text("[Title simplified to make it more human readable – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f13085a13ffaca3e26f0901f9c89eaf17dee1bbed9202f37e34cd400fe231da5-4276c3967d6f431b7ff50a79134729edf4764455d2278e6a28343b9ede511443.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chasing integers")]], [#link("https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/#comment-675955")[#strong[#text("Chasing integers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2023")])]

#text("Structurally is there a difference between Group algebra and non-classical polynomials when the range is a group? Are there other objects besides groups which serve the purpose?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/03/10/a-host-kra-bf-fomega_2-system-of-order-5-that-is-not-abramov-of-order-5-and-non-measurability-of-the-inverse-theorem-for-the-u6bf-fn_2-norm-the-structure-of-totally-disconnected/#comment-676964")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("Dear, Professor Tao")#linebreak()#text(" I have been following you since you were a kid participating in IMO. And in the early days of the old years, I don’t know why I’m always impressed by that child prodigy, ” I thought to myself and strongly believed that this boy would grow up to be one of the greatest mathematicians in the world, he would win Field medal and had many awards in the world “.That’s right, when I heard that you won the Field medal in 2006, I burst into tears because I was so emotional. Back to the problem, I am very impressed with your nearly 200 page paper, I would love to see your 700-800 page paper today. You are very smart, you must know what I mean. I have a strongly faith in you like the heat of the sun.")#linebreak()#text(" Time flies so fast, I don’t know what to say more than when you were a cute boy and now you are almost 50 years old. 0ne day, one minute is very precious, Professor Tao ! I hope after you read my words, you think deeply and delete my sentences immediately.")#linebreak()#text(" Bye,")
]
]
