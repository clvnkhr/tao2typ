// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/
// Converted to Typst by tao2typ: "2026-10-14T16:37:49.342530+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 3: The weak and strong law of large numbers", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 3: The weak and strong law of large numbers")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the major activities in probability theory is studying the various statistics that can be produced from a complex system with many components. One of the simplest possible systems one can consider is a finite sequence ")#mi("{X_1,\\dots,X_n}")#text(" or an infinite sequence ")#mi("{X_1,X_2,\\dots}")#text(" of jointly independent scalar random variables, with the case when the ")#mi("{X_i}")#text(" are also identically distributed (i.e. the ")#mi("{X_i}")#text(" are ")#link("https://en.wikipedia.org/wiki/Independent_and_identically_distributed_random_variables")[#text("iid")]#text(") being a model case of particular interest. (In some cases one may consider a triangular array ")#mi("{(X_{n,i})_{1 \\leq i \\leq n}}")#text(" of scalar random variables, rather than a finite or infinite sequence.) There are many statistics of such sequences that one can study, but one of the most basic such statistics are the partial sums")

#align(center)[#tao-fit-display[#mitex("S_n := X_1 + \\dots + X_n.")]]

#text("The first fundamental result about these sums is the ")#link("https://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" (or LLN for short), which comes in two formulations, weak (WLLN) and strong (SLLN). To state these laws, we first must define the notion of ")#link("https://en.wikipedia.org/wiki/Convergence_of_random_variables#Convergence_in_probability")[#text("convergence in probability")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" Let ")#mi("{X_n}")#text(" be a sequence of random variables taking values in a separable metric space ")#mi("{R = (R,d)}")#text(" (e.g. the ")#mi("{X_n}")#text(" could be scalar random variables, taking values in ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text("), and let ")#mi("{X}")#text(" be another random variable taking values in ")#mi("{R}")#text(". We say that ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(" if, for every radius ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{{\\bf P}( d(X_n,X) > \\varepsilon ) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Thus, if ")#mi("{X_n, X}")#text(" are scalar, we have ")#mi("{X_n}")#text(" converging to ")#mi("{X}")#text(" in probability if ")#tao-math("{{\\bf P}( \\left|X_n-X\\right| > \\varepsilon ) \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for any given ")#mi("{\\varepsilon > 0}")#text(".")
]

#text("The measure-theoretic analogue of convergence in probability is ")#link("https://en.wikipedia.org/wiki/Convergence_in_measure")[#text("convergence in measure")]#text(".")#linebreak()#text(" It is instructive to compare the notion of convergence in probability with almost sure convergence. it is easy to see that ")#mi("{X_n}")#text(" converges almost surely to ")#mi("{X}")#text(" if and only if, for every radius ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{{\\bf P}( \\bigvee_{n \\geq N} (d(X_n,X)>\\varepsilon) ) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text("; thus, roughly speaking, convergence in probability is good for controlling how a single random variable ")#mi("{X_n}")#text(" is close to its putative limiting value ")#mi("{X}")#text(", while almost sure convergence is good for controlling how the entire ")#emph[#text("tail")]#text(" ")#mi("{(X_n)_{n \\geq N}}")#text(" of a sequence of random variables is close to its putative limit ")#mi("{X}")#text(".")#linebreak()#text(" We have the following easy relationships between convergence in probability and almost sure convergence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-68b076be5ba974795f92>#text(" Let ")#mi("{X_n}")#text(" be a sequence of scalar random variables, and let ")#mi("{X}")#text(" be another scalar random variable.")

#list(
[#text("(i) If ")#mi("{X_n \\rightarrow X}")#text(" almost surely, show that ")#mi("{X_n \\rightarrow X}")#text(" in probability. Give a counterexample to show that the converse does not necessarily hold.")],
[#text("(ii) Suppose that ")#tao-math("{\\sum_n {\\bf P}( \\left|X_n-X\\right| > \\varepsilon ) < \\infty}", block: false)#text(" for all ")#mi("{\\varepsilon > 0}")#text(". Show that ")#mi("{X_n \\rightarrow X}")#text(" almost surely. Give a counterexample to show that the converse does not necessarily hold.")],
[#text("(iii) If ")#mi("{X_n \\rightarrow X}")#text(" in probability, show that there is a subsequence ")#mi("{X_{n_j}}")#text(" of the ")#mi("{X_n}")#text(" such that ")#mi("{X_{n_j} \\rightarrow X}")#text(" almost surely.")],
[#text("(iv) If ")#mi("{X_n,X}")#text(" are absolutely integrable and ")#tao-math("{{\\bf E} \\left|X_n-X\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", show that ")#mi("{X_n \\rightarrow X}")#text(" in probability. Give a counterexample to show that the converse does not necessarily hold.")],
[#text("(v) (Urysohn subsequence principle) Suppose that every subsequence ")#mi("{X_{n_j}}")#text(" of ")#mi("{X_n}")#text(" has a further subsequence ")#mi("{X_{n_{j_k}}}")#text(" that converges to ")#mi("{X}")#text(" in probability. Show that ")#mi("{X_n}")#text(" also converges to ")#mi("{X}")#text(" in probability.")],
[#text("(vi) Does the Urysohn subsequence principle still hold if “in probability” is replaced with “almost surely” throughout?")],
[#text("(vii) If ")#mi("{X_n}")#text(" converges in probability to ")#mi("{X}")#text(", and ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" or ")#mi("{F: {\\bf C} \\rightarrow {\\bf C}}")#text(" is continuous, show that ")#mi("{F(X_n)}")#text(" converges in probability to ")#mi("{F(X)}")#text(". More generally, if for each ")#mi("{i=1,\\dots,k}")#text(", ")#mi("{X^{(i)}_n}")#text(" is a sequence of scalar random variables that converge in probability to ")#mi("{X^{(i)}}")#text(", and ")#mi("{F: {\\bf R}^k \\rightarrow {\\bf R}}")#text(" or ")#mi("{F: {\\bf C}^k \\rightarrow {\\bf C}}")#text(" is continuous, show that ")#mi("{F(X^{(1)}_n,\\dots,X^{(k)}_n)}")#text(" converges in probability to ")#mi("{F(X^{(1)},\\dots,X^{(k)})}")#text(". (Thus, for instance, if ")#mi("{X_n}")#text(" and ")#mi("{Y_n}")#text(" converge in probability to ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" respectively, then ")#mi("{X_n + Y_n}")#text(" and ")#mi("{X_n Y_n}")#text(" converge in probability to ")#mi("{X+Y}")#text(" and ")#mi("{XY}")#text(" respectively.")],
[#text("(viii) (Fatou’s lemma for convergence in probability) If ")#mi("{X_n}")#text(" are non-negative and converge in probability to ")#mi("{X}")#text(", show that ")#mi("{{\\bf E} X \\leq \\liminf_{n \\rightarrow \\infty} {\\bf E} X_n}")#text(".")],
[#text("(ix) (Dominated convergence in probability) If ")#mi("{X_n}")#text(" converge in probability to ")#mi("{X}")#text(", and one almost surely has ")#tao-math("{\\left|X_n\\right| \\leq Y}", block: false)#text(" for all ")#mi("{n}")#text(" and some absolutely integrable ")#mi("{Y}")#text(", show that ")#mi("{{\\bf E} X_n}")#text(" converges to ")#mi("{{\\bf E} X}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of scalar random variables converging in probability to another random variable ")#mi("{X}")#text(".")

#list(
[#text("(i) Suppose that there is a random variable ")#mi("{Y}")#text(" which is independent of ")#mi("{X_i}")#text(" for each individual ")#mi("{i}")#text(". Show that ")#mi("{Y}")#text(" is also independent of ")#mi("{X}")#text(".")],
[#text("(ii) Suppose that the ")#mi("{X_1,X_2,\\dots}")#text(" are jointly independent. Show that ")#mi("{X}")#text(" is almost surely constant (i.e. there is a deterministic scalar ")#mi("{c}")#text(" such that ")#mi("{X=c}")#text(" almost surely).")]
)
]

#text("We can now state the weak and strong law of large numbers, in the model case of iid random variables.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Law of large numbers, model case)")]#text(" Let ")#mi("{X_1, X_2, \\dots}")#text(" be an iid sequence of copies of an absolutely integrable random variable ")#mi("{X}")#text(" (thus the ")#mi("{X_i}")#text(" are independent and all have the same distribution as ")#mi("{X}")#text("). Write ")#mi("{\\mu := {\\bf E} X}")#text(", and for each natural number ")#mi("{n}")#text(", let ")#mi("{S_n}")#text(" denote the random variable ")#mi("{S_n := X_1 + \\dots + X_n}")#text(".")

#list(
[#text("(i) (Weak law of large numbers) The random variables ")#mi("{S_n/n}")#text(" converge in probability to ")#mi("{\\mu}")#text(".")],
[#text("(ii) (Strong law of large numbers) The random variables ")#mi("{S_n/n}")#text(" converge almost surely to ")#mi("{\\mu}")#text(".")]
)
]

#text("Informally: if ")#mi("{X_1,\\dots,X_n}")#text(" are iid with mean ")#mi("{\\mu}")#text(", then ")#mi("{X_1 + \\dots + X_n \\approx \\mu n}")#text(" for ")#mi("{n}")#text(" large. Clearly the strong law of large numbers implies the weak law, but the weak law is easier to prove (and has somewhat better quantitative estimates). There are several variants of the law of large numbers, for instance when one drops the hypothesis of identical distribution, or when the random variable ")#mi("{X}")#text(" is not absolutely integrable, or if one seeks more quantitative bounds on the rate of convergence; we will discuss some of these variants below the fold.")#linebreak()#text(" It is instructive to compare the law of large numbers with what one can obtain from the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%27s_zero%E2%80%93one_law")[#text("Kolmogorov zero-one law")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2015/10/12/275a-notes-2-product-measures-and-independence/")[#text("Notes 2")]#text(". Observe that if the ")#mi("{X_n}")#text(" are real-valued, then the limit superior ")#mi("{\\limsup_{n \\rightarrow \\infty} S_n/n}")#text(" and ")#mi("{\\liminf_{n \\rightarrow \\infty} S_n/n}")#text(" are tail random variables in the sense that they are not affected if one changes finitely many of the ")#mi("{X_n}")#text("; in particular, events such as ")#mi("{\\limsup_{n \\rightarrow \\infty} S_n/n > t}")#text(" are tail events for any ")#mi("{t \\in {\\bf R}}")#text(". From this and the zero-one law we see that there must exist deterministic quantities ")#mi("{-\\infty \\leq \\mu_- \\leq \\mu_+ \\leq +\\infty}")#text(" such that ")#mi("{\\limsup_{n \\rightarrow \\infty} S_n/n = \\mu_+}")#text(" and ")#mi("{\\liminf_{n \\rightarrow \\infty} S_n/n = \\mu_-}")#text(" almost surely. The strong law of large numbers can then be viewed as the assertion that ")#mi("{\\mu_- = \\mu_+ = \\mu}")#text(" when ")#mi("{X}")#text(" is absolutely integrable. On the other hand, the zero-one law argument does not require absolute integrability (and one can replace the denominator ")#mi("{n}")#text(" by other functions of ")#mi("{n}")#text(" that go to infinity as ")#mi("{n \\rightarrow \\infty}")#text(").")#linebreak()#text(" The law of large numbers asserts, roughly speaking, that the theoretical expectation ")#mi("{\\mu}")#text(" of a random variable ")#mi("{X}")#text(" can be approximated by taking a large number of independent samples ")#mi("{X_1,\\dots,X_n}")#text(" of ")#mi("{X}")#text(" and then forming the ")#link("https://en.wikipedia.org/wiki/Sample_mean_and_sample_covariance")[#text("empirical mean")]#text(" ")#mi("{S_n/n = \\frac{X_1+\\dots+X_n}{n}}")#text(". This ability to approximate the theoretical statistics of a probability distribution through empirical data is one of the basic starting points for ")#link("https://en.wikipedia.org/wiki/Mathematical_statistics")[#text("mathematical statistics")]#text(", though this is not the focus of the course here. The tendency of statistics such as ")#mi("{S_n/n}")#text(" to cluster closely around their mean value ")#mi("{\\mu}")#text(" is the simplest instance of the ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("concentration of measure phenomenon")]#text(", which is of tremendous significance not only within probability, but also in applications of probability to disciplines such as statistics, theoretical computer science, combinatorics, random matrix theory and high dimensional geometry. We will not discuss these topics much in this course, but see ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this previous blog post")]#text(" for some further discussion.")#linebreak()#text(" There are several ways to prove the law of large numbers (in both forms). One basic strategy is to use the ")#emph[#text("moment method")]#text(" – controlling statistics such as ")#mi("{S_n/n}")#text(" by computing moments such as the mean ")#mi("{{\\bf E} S_n/n}")#text(", variance ")#tao-math("{{\\bf E} \\left|S_n/n - {\\bf E} S_n/n\\right|^2}", block: false)#text(", or higher moments such as ")#tao-math("{{\\bf E} \\left|S_n/n - {\\bf E} S_n/n\\right|^k}", block: false)#text(" for ")#mi("{k = 4, 6, \\dots}")#text(". The joint independence of the ")#mi("{X_i}")#text(" make such moments fairly easy to compute, requiring only some elementary combinatorics. A direct application of the moment method typically requires one to make a finite moment assumption such as ")#tao-math("{{\\bf E} \\left|X\\right|^k < \\infty}", block: false)#text(", but as we shall see, one can reduce fairly easily to this case by a truncation argument.")#linebreak()#text(" For the strong law of large numbers, one can also use methods relating to the theory of ")#link("https://en.wikipedia.org/wiki/Martingale_(probability_theory)")[#text("martingales")]#text(", such as stopping time arguments and maximal inequalities; we present some classical arguments of Kolmogorov in this regard.")#linebreak()#text(" ")#metadata(none) <tao-1d87ac682c4340b3632b>

#heading(level: 1)[#strong[#text(" — 1. The moment method — ")]]

#text("We begin by using the moment method to establish both the strong and weak law of large numbers for sums of iid random variables, under additional moment hypotheses.")#linebreak()#text(" We first make a very simple observation: in order to prove the weak or strong law of large numbers for complex variables, it suffices to do so for real variables, as the complex case follows from the real case after taking real and imaginary parts. Thus we shall restrict attention henceforth to real random variables, in order to avoid some unnecessarily complications involving complex conjugation.")#linebreak()#text(" Let ")#mi("{X_1,X_2,X_3,\\dots}")#text(" be a sequence of iid copies of a scalar random variable ")#mi("{X}")#text(", and define the partial sums ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". Suppose that ")#mi("{X}")#text(" is absolutely integrable, with expectation (or ")#emph[#text("mean")]#text(") ")#mi("{{\\bf E} X = \\mu}")#text(". Then we can use linearity of expectation to compute the expectation (or ")#emph[#text("first moment")]#text(") of ")#mi("{S_n}")#text(":")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} S_n  & = {\\bf E} X_1 + \\dots + {\\bf E} X_n", block: true)



#tao-math(" & = n \\mu.", block: true)
]

#text("In particular, the expectation of ")#mi("{S_n/n}")#text(" is ")#mi("{\\mu}")#text(". This looks consistent with the strong and weak law of large numbers, but does not immediately imply these laws. However, thanks to Markov’s inequality, we do at least get the following very weak bound ")#metadata(none) <tao-2cda36e6665669fdf88e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( S_n \\geq \\lambda \\mu n ) \\leq \\frac{1}{\\lambda}")]]

#text("for any ")#mi("{\\lambda > 0}")#text(", in the case that ")#mi("{X}")#text(" is unsigned and absolutely integrable. Thus, in the unsigned case at least, we see that ")#mi("{S_n/n}")#text(" usually doesn’t get much larger than the mean ")#mi("{\\mu}")#text(". We will refer to ")#link(<tao-2cda36e6665669fdf88e>)[#text("(1)")]#text(" as a ")#emph[#text("first moment")]#text(" bound on ")#mi("{S_n}")#text(", as it was obtained primarily through a computation of the first moment ")#mi("{{\\bf E} S_n}")#text(" of ")#mi("{S_n}")#text(".")#linebreak()#text(" Now we turn to ")#link("https://en.wikipedia.org/wiki/Second_moment_method")[#text("second moment")]#text(" bounds on ")#mi("{S_n}")#text(", obtained through computations of second moments such as ")#tao-math("{{\\bf E} \\left|S_n\\right|^2}", block: false)#text(" or ")#tao-math("{{\\bf Var}(S_n) = {\\bf E} \\left|S_n - {\\bf E} S_n\\right|^2}", block: false)#text(". It will be convenient to normalise the mean ")#mi("{\\mu}")#text(" to equal zero, by replacing each ")#mi("{X_i}")#text(" with ")#mi("{X_i - \\mu}")#text(" (and ")#mi("{X}")#text(" by ")#mi("{X - \\mu}")#text("), so that ")#mi("{S_n}")#text(" gets replaced by ")#mi("{S_n - \\mu n}")#text(" (and ")#mi("{S_n/n}")#text(" by ")#mi("{S_n/n-\\mu}")#text("). With this normalisation, we see that to prove the strong or weak law of large numbers, it suffices to do so in the mean zero case ")#mi("{\\mu=0}")#text(". (On the other hand, if ")#mi("{X}")#text(" is unsigned, then normalising ")#mi("{X}")#text(" in this fashion will almost certainly destroy the unsigned property, so it is not always desirable to perform this normalisation.)")#linebreak()#text(" Suppose that ")#mi("{X}")#text(" has finite second moment (i.e. ")#tao-math("{{\\bf E} \\left|X\\right|^2 < \\infty}", block: false)#text(", that is to say ")#mi("{X}")#text(" is square-integrable) and has been normalised to have mean zero. We write the variance ")#tao-math("{{\\bf Var}(X) = {\\bf E} \\left|X\\right|^2}", block: false)#text(" as ")#mi("{\\sigma^2}")#text(". The first moment calculation then shows that ")#mi("{S_n}")#text(" has mean zero. Now we compute the variance of ")#mi("{S_n}")#text(", which in the mean zero case is simply ")#tao-math("{{\\bf E} \\left|S_n\\right|^2}", block: false)#text("; note from the triangle inequality that this quantity is finite. By linearity of expectation, we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf Var}(S_n)  & = {\\bf E} \\left|X_1 + \\dots + X_n\\right|^2", block: true)



#tao-math(" & = \\sum_{1 \\leq i,j \\leq n} {\\bf E} X_i X_j.", block: true)
]

#text("(All expressions here are absolutely integrable thanks to the Cauchy-Schwarz inequality.) If ")#mi("{i=j}")#text(", then the term ")#mi("{{\\bf E} X_i X_j}")#text(" is equal to ")#tao-math("{{\\bf E} \\left|X\\right|^2 = \\sigma^2}", block: false)#text(". If ")#mi("{i \\neq j}")#text(", then by hypothesis ")#mi("{X_i}")#text(" and ")#mi("{X_j}")#text(" are independent and mean zero, and thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X_i X_j = ({\\bf E} X_i) ({\\bf E} X_j) = 0.")]]

#text("Putting all this together, we obtain")

#align(center)[#tao-fit-display[#mitex("{\\bf Var}(S_n) = n \\sigma^2")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("{\\bf Var}(S_n/n) = \\frac{1}{n} \\sigma^2.")]]

#text("This bound was established in the mean zero case, but it is clear that it also holds in general, since subtracting a constant from a random variable does not affect its variance. Thus we see that while ")#mi("{S_n/n}")#text(" has the same mean ")#mi("{\\mu}")#text(" as ")#mi("{X}")#text(", it has a much smaller variance: ")#mi("{\\sigma^2/n}")#text(" in place of ")#mi("{\\sigma^2}")#text(". This is the first demonstration of the concentration of measure effect that comes from combining many independent random variables ")#mi("{X_1,\\dots,X_n}")#text(". (At the opposite extreme to the independent case, suppose we took ")#mi("{X_1,\\dots,X_n}")#text(" to all be exactly the same random variable: ")#mi("{X_1 = \\dots = X_n = X}")#text(". Then ")#mi("{S_n/n = X}")#text(" has exactly the same mean and variance as ")#mi("{X}")#text(". Decorrelating the ")#mi("{X_1,\\dots,X_n}")#text(" does not affect the mean of ")#mi("{S_n}")#text(", but produces significant cancellations that reduce the variance.)")#linebreak()#text(" If we insert this variance bound into ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]#text(", we obtain the bound ")#metadata(none) <tao-77d0916c6d6c878c4fa9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf P}( \\left|\\frac{S_n}{n}-\\mu\\right| \\geq \\varepsilon ) \\leq \\frac{1}{n} \\frac{\\sigma^2}{\\varepsilon^2}", block: true)]]

#text("for any natural number ")#mi("{n}")#text(" and ")#mi("{\\varepsilon > 0}")#text(", whenever ")#mi("{X}")#text(" has mean ")#mi("{\\mu}")#text(" and a finite variance ")#mi("{\\sigma^2 < \\infty}")#text(". The right-hand side goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for fixed ")#mi("{\\varepsilon}")#text(", so we have in fact established the weak law of large numbers in the case that ")#mi("{X}")#text(" has finite variance.")#linebreak()#text(" Note that ")#link(<tao-77d0916c6d6c878c4fa9>)[#text("(2)")]#text(" implies that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\sqrt{n}}{\\omega(n)} \\left|\\frac{S_n}{n}-\\mu\\right|", block: true)]]

#text("converges to zero in probability whenever ")#mi("{\\omega(n)}")#text(" is a function of ")#mi("{n}")#text(" that goes to infinity as ")#mi("{n \\rightarrow \\infty}")#text(". Thus for instance")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\sqrt{n}}{\\log n} \\left|\\frac{S_n}{n}-\\mu\\right| \\rightarrow 0", block: true)]]

#text("in probability. Informally, this means that ")#mi("{S_n/n}")#text(" tends to stray by not much more than ")#mi("{\\sqrt{n}}")#text(" from ")#mi("{\\mu}")#text(" typically. This intuition will be reinforced in the next set of notes when we study the ")#link("https://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(" and related results such as the ")#link("https://en.wikipedia.org/wiki/Chernoff_inequality")[#text("Chernoff inequality")]#text(". (It is also supported by the ")#link("https://en.wikipedia.org/wiki/Law_of_the_iterated_logarithm")[#text("law of the iterated logarithm")]#text(", which we will probably not be able to get to in this set of notes.)")#linebreak()#text(" One can hope to use ")#link(<tao-77d0916c6d6c878c4fa9>)[#text("(2)")]#text(" and the Borel-Cantelli lemma (Exercise ")#link(<tao-68b076be5ba974795f92>)[#text("2")]#text("(ii)) to also obtain the strong law of large numbers in the second moment case, but unfortunately the quantities ")#mi("{\\frac{1}{n} \\frac{\\sigma^2}{\\varepsilon^2}}")#text(" are not summable in ")#mi("{n}")#text(". To resolve this issue, we will go to higher moments than the second moment. One could calculate third moments such as ")#mi("{{\\bf E} S_n^3}")#text(", but this turns out to not convey too much information (unless ")#mi("{X_n}")#text(" is unsigned) because of the signed nature of ")#mi("{S_n^3}")#text("; the expression ")#tao-math("{{\\bf E} \\left|S_n\\right|^3}", block: false)#text(" would in principle convey more usable information, but is difficult to compute as ")#tao-math("{\\left|S_n\\right|^3}", block: false)#text(" is not a polynomial combination of the ")#mi("{X_i}")#text(". Instead, we move on to the fourth moment. Again, we normalise ")#mi("{X}")#text(" to have mean ")#mi("{\\mu=0}")#text(", and now assume a finite fourth moment ")#tao-math("{{\\bf E} \\left|X\\right|^4 < \\infty}", block: false)#text(" (which, by the Hölder or Jensen inequalities, implies that all lower moments such as ")#tao-math("{{\\bf E} \\left|X\\right|^2}", block: false)#text(" are finite). We again use ")#tao-math("{\\sigma^2 = {\\bf E} \\left|X\\right|^2}", block: false)#text(" to denote the variance of ")#mi("{X}")#text(". We can expand")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} \\left|S_n\\right|^4  & = {\\bf E} \\left|X_1 + \\dots + X_n\\right|^4", block: true)



#tao-math(" & = \\sum_{1 \\leq i,j,k,l \\leq n} {\\bf E} X_i X_j X_k X_l.", block: true)
]

#text("Note that all expectations here are absolutely integrable by Hölder’s inequality and the hypothesis of finite fourth moment. The correlation ")#mi("{{\\bf E} X_i X_j X_k X_l}")#text(" looks complicated, but fortunately it simplifies greatly in most cases. Suppose for instance that ")#mi("{i}")#text(" is distinct from ")#mi("{j,k,l}")#text(", then ")#mi("{X_i}")#text(" is independent of ")#mi("{(X_j,X_k,X_l)}")#text(" (even if some of the ")#mi("{j,k,l}")#text(" are equal to each other) and so")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X_i X_j X_k X_l = ({\\bf E} X_i) ({\\bf E} X_j X_k X_l) = 0")]]

#text("since ")#mi("{{\\bf E} X_i = {\\bf E} X = 0}")#text(". Similarly for permutations. This leaves only a few quadruples ")#mi("{(i,j,k,l)}")#text(" for which ")#mi("{{\\bf E} X_i X_j X_k X_l}")#text(" could be non-zero: the three cases ")#mi("{i=j \\neq k=l}")#text(", ")#mi("{i = k \\neq j = l}")#text(", ")#mi("{i=l \\neq j=k}")#text(" where each of the indices ")#mi("{i,j,k,l}")#text(" is paired up with exactly one other index; and the diagonal case ")#mi("{i=j=k=l}")#text(". If for instance ")#mi("{i=j \\neq k=l}")#text(", then")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} X_i X_j X_k X_l  & = {\\bf E} X_i^2 X_k^2", block: true)



#tao-math(" & = ({\\bf E} X_i^2) ({\\bf E} X_k^2)", block: true)



#tao-math(" & = \\sigma^2 \\times \\sigma^2.", block: true)
]

#text("Similarly for the cases ")#mi("{i=k \\neq j=l}")#text(" and ")#mi("{i=l \\neq j=k}")#text(", which gives a total contribution of ")#mi("{3 n(n-1) \\sigma^4}")#text(" to ")#tao-math("{{\\bf E} \\left|S_n\\right|^4}", block: false)#text(". Finally, when ")#mi("{i=j=k=l}")#text(", then ")#mi("{{\\bf E} X_i X_j X_k X_l = {\\bf E} X^4}")#text(", and there are ")#mi("{n}")#text(" contributions of this form to ")#tao-math("{{\\bf E} \\left|S_n\\right|^4}", block: false)#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|S_n\\right|^4 = 3n(n-1) \\sigma^4 + n {\\bf E} \\left|X\\right|^4", block: true)]]

#text("and hence by Markov’s inequality")

#align(center)[#tao-fit-display[#tao-math("{\\bf P} ( \\left|\\frac{S_n}{n}\\right| > \\varepsilon ) \\leq \\frac{3n(n-1) \\sigma^4 + n {\\bf E} \\left|X\\right|^4}{\\varepsilon^4 n^4}", block: true)]]

#text("for any ")#mi("{\\varepsilon>0}")#text(". If we remove the normalisation ")#mi("{\\mu=0}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P} ( \\left|\\frac{S_n}{n}-\\mu\\right| > \\varepsilon ) \\leq \\frac{3n(n-1) \\sigma^4 + n {\\bf E} \\left|X-\\mu\\right|^4}{\\varepsilon^4 n^4}", block: true)]]

#text("The right-hand side decays like ")#mi("{O(1/n^2)}")#text(", which is now summable in ")#mi("{n}")#text(" (in contrast to ")#link(<tao-77d0916c6d6c878c4fa9>)[#text("(2)")]#text("). Thus we may now apply the Borel-Cantelli lemma and conclude the ")#emph[#text("strong")]#text(" law of large numbers in the case when one has bounded fourth moment ")#tao-math("{{\\bf E} \\left|X\\right|^4 < \\infty}", block: false)#text(".")#linebreak()#text(" One can of course continue to compute higher and higher moments of ")#mi("{S_n}")#text(" (assuming suitable finite moment hypotheses on ")#mi("{X}")#text("), though as one can already see from the fourth moment calculation, the computations become increasingly combinatorial in nature. We will pursue this analysis more in the next set of notes, when we discuss the central limit theorem. For now, we turn to some applications and variants of the moment method (many of which are taken from Durrett’s book).")#linebreak()#text(" We begin with two quick applications of the weak law of large numbers to topics outside of probability. We first give an explicit version of the Weierstrass approximation theorem, which asserts that continuous functions on (say) the unit interval ")#mi("{[0,1]}")#text(" can be approximated by polynomials.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Approximation by Bernstein polynomials)")]#text(" Let ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" be a continuous function. Then the ")#link("https://en.wikipedia.org/wiki/Bernstein_polynomial")[#text("Bernstein polynomials")]

#align(center)[#tao-fit-display[#mitex("f_n(x) := \\sum_{i=0}^n \\binom{n}{i} x^i (1-x)^{n-i} f(\\frac{i}{n})")]]

#text("converges uniformly to ")#mi("{f}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" We first establish the pointwise bound ")#mi("{f_n(p) \\rightarrow f(p)}")#text(" for each ")#mi("{0 \\leq p \\leq 1}")#text(". Fix ")#mi("{0 \\leq p \\leq 1}")#text(", and let ")#mi("{X_1,X_2,X_3,\\dots}")#text(" be iid Bernoulli variables (i.e. variables taking values in ")#mi("{\\{0,1\\}}")#text(") with each ")#mi("{X_i}")#text(" equal to ")#mi("{1}")#text(" with probability ")#mi("{p}")#text(". The mean of the ")#mi("{X_i}")#text(" is clearly ")#mi("{p}")#text(", and the variance is bounded crudely by ")#mi("{1}")#text(" (in fact it is ")#mi("{p(1-p)}")#text("), so if we set ")#mi("{S_n := X_1 + \\dots + X_n}")#text(" then by the weak law of large numbers for random variables of finite second moment, we see that ")#mi("{S_n/n}")#text(" converges in probability to ")#mi("{p}")#text(" (note that ")#mi("{S_n/n}")#text(" is clearly dominated by ")#mi("{1}")#text("). By the dominated convergence theorem in probability, we conclude that ")#mi("{{\\bf E} f(S_n/n)}")#text(" converges to ")#mi("{f(p)}")#text(". But from direct computation we see that ")#mi("{S_n/n}")#text(" takes values in ")#mi("{\\{0, 1/n, \\dots, n/n\\}}")#text(", with each ")#mi("{i/n}")#text(" being attained with probability ")#mi("{\\binom{n}{i} p^i (1-p)^{n-i}}")#text(" (i.e. ")#mi("{S_n}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Binomial_distribution")[#text("binomial distribution")]#text("), and so from the definition of the Bernstein polynomials ")#mi("{f_n}")#text(" we see that ")#mi("{{\\bf E} f(S_n/n) = f_n(p)}")#text(". This concludes the pointwise convergence claim.")#linebreak()#text(" To establish the uniform convergence, we use the ")#emph[#text("proof")]#text(" of the weak law of large numbers, rather than the ")#emph[#text("statement")]#text(" of that law, to get the desired uniformity in the parameter ")#mi("{p}")#text(". For a given ")#mi("{p}")#text(", we see from ")#link(<tao-77d0916c6d6c878c4fa9>)[#text("(2)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n}{n}-p\\right| \\geq \\delta ) \\leq \\frac{1}{n} \\frac{p(1-p)}{\\delta^2}", block: true)]]

#text("for any ")#mi("{\\delta > 0}")#text(". On the other hand, as ")#mi("{f}")#text(" is continuous on ")#mi("{[0,1]}")#text(", it is uniformly continuous, and so for any ")#mi("{\\varepsilon>0}")#text(" there exists a ")#mi("{\\delta>0}")#text(" such that ")#tao-math("{\\left|f(x)-f(y)\\right| < \\varepsilon}", block: false)#text(" whenever ")#mi("{x,y \\in [0,1]}")#text(" with ")#tao-math("{\\left|x-y\\right| < \\delta}", block: false)#text(". For such an ")#mi("{\\varepsilon}")#text(" and ")#mi("{\\delta}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|f(\\frac{S_n}{n})-f(p)\\right| \\geq \\varepsilon ) \\leq \\frac{1}{n} \\frac{p(1-p)}{\\delta^2}.", block: true)]]

#text("On the other hand, being continuous on ")#mi("{[0,1]}")#text(", ")#mi("{f}")#text(" must be bounded in magnitude by some bound ")#mi("{M}")#text(", so that ")#tao-math("{\\left|f(\\frac{S_n}{n})-f(p)\\right| \\leq 2M}", block: false)#text(". This leads to the upper bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|f(\\frac{S_n}{n})-f(p)\\right| \\leq \\varepsilon + \\frac{2M}{n} \\frac{p(1-p)}{\\delta^2}", block: true)]]

#text("and thus by the triangle inequality and the identity ")#mi("{{\\bf E} f(S_n/n) = f_n(p)}")

#align(center)[#tao-fit-display[#tao-math("\\left|f_n(p) - f(p)\\right| \\leq \\varepsilon + \\frac{2M}{n} \\frac{p(1-p)}{\\delta^2}.", block: true)]]

#text("Since ")#mi("{p(1-p)}")#text(" is bounded by (say) ")#mi("{1}")#text(", and ")#mi("{\\varepsilon}")#text(" can be made arbitrarily small, we conclude that ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" as required. ")#mi("\\Box")#linebreak()#text(" The other application of the weak law of large numbers is to the geometry of high-dimensional cubes, giving the rather unintuitive conclusion that most of the volume of the high-dimensional cube is contained in a thin annulus.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(". Then, for sufficiently large ")#mi("{n}")#text(", a proportion of at least ")#mi("{1-\\varepsilon}")#text(" of the cube ")#mi("{[-1,1]^n}")#text(" (by ")#mi("{n}")#text("-dimensional Lebesgue measure) is contained in the annulus ")#tao-math("{\\{ x \\in {\\bf R}^n: (1-\\varepsilon) \\sqrt{n/3} \\leq \\left|x\\right| \\leq (1+\\varepsilon) \\sqrt{n/3} \\}}", block: false)#text(".")
]

#text("This proposition already indicates that high-dimensional geometry can behave in a manner quite differently from what one might naively expect from low-dimensional geometric intuition; one needs to develop a rather distinct high-dimensional geometric intuition before one can accurately make predictions in large dimensions.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid random variables drawn uniformly from ")#mi("{[-1,1]}")#text(". Then the random vector ")#mi("{(X_1,\\dots,X_n)}")#text(" is uniformly distributed on the cube ")#mi("{[-1,1]^n}")#text(". The variables ")#mi("{X_1^2,X_2^2,\\dots}")#text(" are also iid, and (by the change of variables formula) have mean")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 x^2\\ dx = \\frac{1}{3}.")]]

#text("Hence, by the weak law of large numbers, the quantity ")#mi("{\\frac{X_1^2+\\dots+X_n^2}{n}}")#text(" converges in probability to ")#mi("{\\frac{1}{3}}")#text(", so in particular the probability")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sqrt{X_1^2+\\dots+X_n^2} - \\sqrt{n/3}| > \\varepsilon \\sqrt{n/3})")]]

#text("goes to zero as ")#mi("{n}")#text(" goes to infinity. But this quantity is precisely the proportion of ")#mi("{[-1,1]^n}")#text(" that lies outside the annulus ")#tao-math("{\\{ x \\in {\\bf R}^n: (1-\\varepsilon) \\sqrt{n/3} \\leq \\left|x\\right| \\leq (1+\\varepsilon) \\sqrt{n/3} \\}}", block: false)#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" The first and second moment method are very general, and apply to sums ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" of random variables ")#mi("{X_1,\\dots,X_n}")#text(" that do not need to be identically distributed, or even independent (although the bounds can get weaker and more complicated if one strays too far from these hypotheses). For instance, it is clear from linearity of expectation that ")#mi("{S_n}")#text(" has mean ")#metadata(none) <tao-d03f3d5a8ba8d47c300a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf E} S_n = {\\bf E} X_1 + \\dots + {\\bf E} X_n")]]

#text("(assuming of course that ")#mi("{X_1,\\dots,X_n}")#text(" are absolutely integrable) and variance")

#align(center)[#tao-fit-display[#mitex("{\\bf Var}(S_n) = {\\bf Var}(X_1) + \\dots + {\\bf Var}(X_n) + \\sum_{1 \\leq i,j \\leq n: i \\neq j} \\text{Cov}(X_i,X_j)")]]

#text("(assuming now that ")#mi("{X_1,\\dots,X_n}")#text(" are square-integrable). (For the latter claim, it is convenient, as before, to first normalise each of the ")#mi("{X_i}")#text(" to have mean zero.) If the ")#mi("{X_1,\\dots,X_n}")#text(" are pairwise independent in addition to being square-integrable, then all the covariances vanish, and we obtain additivity of the variance: ")#metadata(none) <tao-7785872a8da68d8e8ea7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\bf Var}(S_n) = {\\bf Var}(X_1) + \\dots + {\\bf Var}(X_n).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Viewing the variance as the square of the standard deviation, the identity ")#link(<tao-7785872a8da68d8e8ea7>)[#text("(4)")]#text(" can be interpreted as a rigorous instantiation of the following informal ")#emph[#text("principle of square root cancellation")]#text(": if one has a sum ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" of random (or ")#link("https://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandom")]#text(") variables that “oscillate” in the sense that their mean is either zero or close to zero, and each ")#mi("{X_i}")#text(" has an expected magnitude of about ")#mi("{a_i}")#text(" (in the sense that a statistic such as the standard deviation of ")#mi("{X_i}")#text(" is comparable to ")#mi("{a_i}")#text("), and the ")#mi("{X_i}")#text(" “behave independently”, then the sum ")#mi("{S_n}")#text(" is expected to have a magnitude of about ")#tao-math("{(\\sum_{i=1}^n \\left|a_i\\right|^2)^{1/2}}", block: false)#text(". Thus for instance a sum of ")#mi("{n}")#text(" unbiased signs ")#mi("{X_i \\in \\{-1,+1\\}}")#text(" would be expected to have magnitude about ")#mi("{\\sqrt{n}}")#text(" if the ")#mi("{X_i}")#text(" do not exhibit strong correlations with each other. This principle turns out to be remarkably broadly applicable (at least as a heuristic, if not as a rigorous argument), even in situations for which no randomness is evident (e.g. in considering the type of exponential sums that occur in analytic number theory). We will see some further instantiations of this principle in later notes.")
]

#text("These identities, together with Chebyshev’s inequality, already gives some useful control on many statistics, including some which are not obviously of the form of a sum of independent random variables. A classic example of this is the ")#link("https://en.wikipedia.org/wiki/Coupon_collector%27s_problem")[#text("coupon collector problem")]#text(", which we formulate as follows. Let ")#mi("{N}")#text(" be a natural number, and let ")#mi("{Y_1, Y_2, \\dots}")#text(" be an infinite sequence of “coupons”, which are iid and uniformly distributed from the finite set ")#mi("{\\{1,\\dots,N\\}}")#text(". Let ")#mi("{T_N}")#text(" denote the first time at which one has collected all ")#mi("{N}")#text(" different types of coupons, thus ")#mi("{T_N}")#text(" is the first natural number for which the set ")#mi("{\\{Y_1,\\dots,Y_{T_N}\\}}")#text(" attains the maximal cardinality of ")#mi("{N}")#text(" (or ")#mi("{T_N=\\infty}")#text(" if no such natural number exists, though it is easy to see that this is a null event, indeed note from the strong law of large numbers that almost surely one will collect infinitely many of each coupon over time). The question is then to describe the behaviour of ")#mi("{T_N}")#text(" as ")#mi("{N}")#text(" gets large.")#linebreak()#text(" At first glance, ")#mi("{T_N}")#text(" does not seem to be easily describable as the sum of many independent random variables. However, if one looks at it the right way, one can see such a structure emerge (and much of the art of probability is in finding useful and different ways of thinking of the same random variable). Namely, for each ")#mi("{i=0,\\dots,N}")#text(", let ")#mi("{T_{i,N}}")#text(" denote the first time one has collected ")#mi("{i}")#text(" coupons out of ")#mi("{N}")#text(", thus ")#mi("{T_{i,N}}")#text(" is the first non-negative integer such that ")#mi("{\\{Y_1,\\dots,Y_{T_{i,N}}\\}}")#text(" has cardinality ")#mi("{i}")#text(", with")

#align(center)[#tao-fit-display[#mitex("0 = T_{0,N} < T_{1,N} < \\dots < T_{N,N} = T_N.")]]

#text("If we then write ")#mi("{X_i := T_{i,N} - T_{i-1,N}}")#text(" for ")#mi("{i=1,\\dots,n}")#text(", then the ")#mi("{X_i}")#text(" take values in the natural numbers, we have the telescoping sum")

#align(center)[#tao-fit-display[#mitex("T_N = X_1 + X_2 + \\dots + X_N.")]]

#text("Remarkably, the random variables ")#mi("{X_1,\\dots,X_N}")#text(" have a simple structure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" The random variables ")#mi("{X_1,\\dots,X_N}")#text(" are jointly independent, and each ")#mi("{X_i}")#text(" has a ")#link("https://en.wikipedia.org/wiki/Geometric_distribution")[#text("geometric distribution")]#text(" with parameter ")#mi("{\\frac{N-i+1}{N}}")#text(", in the sense that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X_i = j) = (1 - \\frac{N-i+1}{N})^{j-1} \\frac{N-i+1}{N}")]]

#text("for ")#mi("{j=1,2,\\dots}")#text(" and ")#mi("{i=1,\\dots,N}")#text(".")
]

#text("The joint independence of the ")#mi("{X_1,\\dots,X_N}")#text(" reflects the “")#link("https://en.wikipedia.org/wiki/Markov_process")[#text("Markovian")]#text("” or “memoryless” nature of a certain process relating to the coupon collector problem, and can be easily established once one has understood the concept of ")#link("https://en.wikipedia.org/wiki/Conditional_expectation")[#text("conditional expectation")]#text(", but the further exploration of these concepts will have to be deferred to the course after this one (which I will not be teaching or writing notes for). But as the coupon collecting problem is so simple, we shall proceed instead by direct computation.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" It suffices to show that")

#tao-aligned(keep: true)[


#tao-math("{\\bf P}(X_1 = j_1 \\wedge \\dots \\wedge X_N = j_N)  & = \\prod_{i=1}^N (1 - \\frac{N-i+1}{N})^{j_i-1} \\frac{N-i+1}{N}", block: true)



#tao-math(" & = N^{-(j_1+\\dots+j_N)} \\prod_{i=1}^N (N-i+1) (i-1)^{j_i-1}", block: true)
]

#text("for any choice of natural numbers ")#mi("{j_1,\\dots,j_N}")#text(". In order for the event ")#mi("{X_1 = j_1 \\wedge \\dots \\wedge X_N = j_N}")#text(" to hold, the first coupon ")#mi("{Y_1}")#text(" can be arbitrary (and ")#mi("{j_1}")#text(" must be ")#mi("{1}")#text("), but the coupons ")#mi("{Y_2,\\dots,Y_{j_1+j_2-1}}")#text(" have to be equal to ")#mi("{Y_{j_1}}")#text("; then ")#mi("{Y_{j_1+j_2}}")#text(" must be from one the remaining ")#mi("{N-1}")#text(" elements of ")#mi("{\\{1,\\dots,N\\}}")#text(" not equal to ")#mi("{Y_{j_1}}")#text(", and ")#mi("{Y_{j_1+j_2+1},\\dots,Y_{j_1+j_2+j_3-1}}")#text(" must be from the two-element set ")#mi("{\\{Y_{j_1},Y_{j_1+j_2}\\}}")#text("; and so on and so forth up to ")#mi("{Y_{j_1+\\dots+j_N}}")#text(". The claim then follows from a routine application of elementary combinatorics to count all the possible values for the tuple ")#mi("{(Y_1,\\dots,Y_{j_1+\\dots+j_N})}")#text(" of the above form and dividing by the total number ")#mi("{N^{j_1+\\dots+j_N}}")#text(" of such tuples. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that if ")#mi("{X}")#text(" is a geometric distribution with parameter ")#mi("{p}")#text(" for some ")#mi("{0 < p \\leq 1}")#text(" (thus ")#mi("{{\\bf P}(X=j) = (1-p)^{j-1} p}")#text(" for all ")#mi("{j}")#text(") then ")#mi("{X}")#text(" has mean ")#mi("{\\frac{1}{p}}")#text(" and variance ")#mi("{\\frac{1-p}{p^2}}")#text(".")
]

#text("From the above proposition and exercise as well as ")#link(<tao-d03f3d5a8ba8d47c300a>)[#text("(3)")]#text(", ")#link(<tao-7785872a8da68d8e8ea7>)[#text("(4)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} T_N = \\sum_{i=1}^N \\frac{N}{N-i+1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf Var} T_N = \\sum_{i=1}^N (\\frac{N}{N-i+1})^2 \\frac{i-1}{N}.")]]

#text("From the integral test (and crudely bounding ")#mi("{(i-1)/N = O(1)}")#text(") one can thus obtain the bounds")

#align(center)[#tao-fit-display[#mitex("{\\bf E} T_N = N \\log N + O(N)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\bf Var} T_N = O(N^2)")]]

#text("where we use the usual asymptotic notation of denoting by ")#mi("{O(X)}")#text(" any quantity bounded in magnitude by a constant multiple ")#mi("{CX}")#text(" of ")#mi("{X}")#text(". From Chebyshev’s inequality we thus see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|T_N - N \\log N\\right| \\geq \\lambda N ) = O( \\lambda^{-2} )", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(" (note the bound is trivial unless ")#mi("{\\lambda}")#text(" is large). This implies in particular that ")#mi("{T_N/N \\log N}")#text(" converges to ")#mi("{1}")#text(" in probability as ")#mi("{N \\rightarrow \\infty}")#text(" (assuming that our underlying probability space can model a separate coupon collector problem for each choice of ")#mi("{N}")#text("). Thus, roughly speaking, we see that one expects to take about ")#mi("{N \\log N}")#text(" units of time to collect all ")#mi("{N}")#text(" coupons.")#linebreak()#text(" Another application of the weak and strong law of large numbers (even with the moment hypotheses currently imposed on these laws) is a converse to the ")#link("https://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(" in the jointly independent case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Second Borel-Cantelli lemma)")]#text(" Let ")#mi("{E_1,E_2,\\dots}")#text(" be a sequence of jointly independent events. If ")#mi("{\\sum_{n=1}^\\infty {\\bf P}(E_n) = \\infty}")#text(", show that almost surely an infinite number of the ")#mi("{E_n}")#text(" hold simultaneously. (")#emph[#text("Hint:")]#text(" compute the mean and variance of ")#mi("{S_n= \\sum_{i=1}^n 1_{E_i}}")#text(". One can also compute the fourth moment if desired, but it is not necessary to do so for this result.)")
]

#text("One application of the second Borel-Cantelli lemma has the colourful name of the “")#link("https://en.wikipedia.org/wiki/Infinite_monkey_theorem")[#text("infinite monkey theorem")]#text("“:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Infinite monkey theorem)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid random variables drawn uniformly from a finite alphabet ")#mi("{A}")#text(". Show that almost surely, every finite word ")#mi("{a_1 \\dots a_k}")#text(" of letters ")#mi("{a_1,\\dots,a_k}")#text(" in the alphabet appears infinitely often in the string ")#mi("{X_1 X_2 X_3 \\dots}")#text(".")
]

#text("In the usual formulation of the weak or strong law of large numbers, we draw the sums ")#mi("{S_n}")#text(" from a single infinite sequence ")#mi("{X_1,X_2,\\dots}")#text(" of iid random variables. One can generalise the situation slightly by working instead with sums from rows of a triangular array, which are jointly independent within rows but not necessarily across rows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Triangular arrays)")]#text(" ")#metadata(none) <tao-cddd67830982a78cc839>#text(" Let ")#mi("{(X_{i,n})_{i,n \\in {\\bf N}: i \\leq n}}")#text(" be a triangular array of scalar random variables ")#mi("{X_{i,n}}")#text(", such that for each ")#mi("{n}")#text(", the row ")#mi("{X_{1,n},\\dots,X_{n,n}}")#text(" is a collection of independent random variables. For each ")#mi("{n}")#text(", we form the partial sums ")#mi("{S_n = X_{1,n} + \\dots + X_{n,n}}")#text(".")

#list(
[#text("(i) (Weak law) If all the ")#mi("{X_{i,n}}")#text(" have mean ")#mi("{\\mu}")#text(" and ")#tao-math("{\\sup_{i,n} {\\bf E} \\left|X_{i,n}\\right|^2 < \\infty}", block: false)#text(", show that ")#mi("{S_n/n}")#text(" converges in probability to ")#mi("{\\mu}")#text(".")],
[#text("(ii) (Strong law) If all the ")#mi("{X_{i,n}}")#text(" have mean ")#mi("{\\mu}")#text(" and ")#tao-math("{\\sup_{i,n} {\\bf E} \\left|X_{i,n}\\right|^4 < \\infty}", block: false)#text(", show that ")#mi("{S_n/n}")#text(" converges almost surely to ")#mi("{\\mu}")#text(".")]
)
]

#text("Note that the weak and strong law of large numbers established previously corresponds to the case ")#mi("{X_{i,n} = X_i}")#text(" when the triangular array collapses to a single sequence ")#mi("{X_1,X_2,\\dots}")#text(" of iid random variables.")#linebreak()#text(" We now illustrate the use of moment method and law of large number methods to two important examples of random structures, namely random graphs and random matrices.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" For a natural number ")#mi("{n}")#text(" and a parameter ")#mi("{0 \\leq p \\leq 1}")#text(", define an ")#emph[#text("Erdös-Renyi graph")]#text(" on ")#mi("{n}")#text(" vertices with parameter ")#mi("{p}")#text(" to be a random graph ")#mi("{(V,E)}")#text(" on a (deterministic) vertex set ")#mi("{V}")#text(" of ")#mi("{n}")#text(" vertices (thus ")#mi("{(V,E)}")#text(" is a random variable taking values in the discrete space of all ")#mi("{2^{\\binom{n}{2}}}")#text(" possible graphs one can place on ")#mi("{V}")#text(") such that the events ")#mi("{\\{i,j\\} \\in E}")#text(" for unordered pairs ")#mi("{\\{i,j\\}}")#text(" in ")#mi("{V}")#text(" are jointly independent and each occur with probability ")#mi("{p}")#text(".")#linebreak()#text(" For each ")#mi("{n}")#text(", let ")#mi("{(V_n,E_n)}")#text(" be an Erdös-Renyi graph on ")#mi("{n}")#text(" vertices with parameter ")#mi("{1/2}")#text(" (we do not require the graphs to be independent of each other).")

#list(
[#text("(i) If ")#tao-math("{\\left|E_n\\right|}", block: false)#text(" is the number of edges in ")#mi("{(V_n,E_n)}")#text(", show that ")#tao-math("{\\left|E_n\\right|/\\binom{n}{2}}", block: false)#text(" converges almost surely to ")#mi("{1/2}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-cddd67830982a78cc839>)[#text("12")]#text(".)")],
[#text("(ii) If ")#tao-math("{\\left|T_n\\right|}", block: false)#text(" is the number of triangles in ")#mi("{(V_n,E_n)}")#text(" (i.e. the set of unordered triples ")#mi("{\\{i,j,k\\}}")#text(" in ")#mi("{V_n}")#text(" such that ")#mi("{\\{i,j\\}, \\{i,k\\}, \\{j,k\\} \\in E_n}")#text("), show that ")#tao-math("{\\left|T_n\\right|/\\binom{n}{3}}", block: false)#text(" converges in probability to ")#mi("{1/8}")#text(". (Note: there is not quite enough joint independence here to directly apply the law of large numbers, however the second moment method still works nicely.)")],
[#text("(iii) Show in fact that ")#tao-math("{\\left|T_n\\right|/\\binom{n}{3}}", block: false)#text(" converges almost surely to ")#mi("{1/8}")#text(". (Note: in contrast with the situation with the strong law of large numbers, the fourth moment does not need to be computed here.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" For each ")#mi("{n}")#text(", let ")#mi("{A_n = (a_{ij,n})_{1 \\leq i,j \\leq n}}")#text(" be a random ")#mi("{n \\times n}")#text(" matrix (i.e. a random variable taking values in the space ")#mi("{{\\bf R}^{n \\times n}}")#text(" or ")#mi("{{\\bf C}^{n \\times n}}")#text(" of ")#mi("{n \\times n}")#text(" matrices) such that the entries ")#mi("{a_{ij,n}}")#text(" of ")#mi("{A_n}")#text(" are jointly independent in ")#mi("{i,j}")#text(" and take values in ")#mi("{\\{-1,+1\\}}")#text(" with a probability of ")#mi("{1/2}")#text(" each. (Such matrices are known as ")#emph[#text("random sign matrices")]#text(".) We do not assume any independence for the sequence ")#mi("{A_1,A_2,\\dots}")#text(".")

#list(
[#text("(i) Show that the random variables ")#mi("{\\text{tr} A_n A_n^* / n^2}")#text(" are deterministically equal to ")#mi("{1}")#text(", where ")#mi("{A_n^*}")#text(" denotes the adjoint (which, in this case, is also the transpose) of ")#mi("{A_n}")#text(" and ")#mi("{\\text{tr}}")#text(" denotes the trace (sum of the diagonal entries) of a matrix.")],
[#text("(ii) Show that for any natural number ")#mi("{k}")#text(", the quantities ")#mi("{{\\bf E} \\text{tr} (A_n A_n^*)^k / n^{k+1}}")#text(" are bounded uniformly in ")#mi("{n}")#text(" (i.e. they are bounded by a quantity ")#mi("{C_k}")#text(" that can depend on ")#mi("{k}")#text(" but not on ")#mi("{n}")#text("). (You may wish to first work with simple cases like ")#mi("{k=2}")#text(" or ")#mi("{k=3}")#text(" to gain intuition.)")],
[#text("(iii) If ")#tao-math("{\\left\\|A_n\\right\\|_{op}}", block: false)#text(" denotes the operator norm of ")#mi("{A_n}")#text(", and ")#mi("{\\varepsilon > 0}")#text(", show that ")#tao-math("{\\left\\|A_n\\right\\|_{op} / n^{1/2+\\varepsilon}}", block: false)#text(" converges almost surely to zero, and that ")#tao-math("{\\left\\|A_n\\right\\|_{op} / n^{1/2-\\varepsilon}}", block: false)#text(" diverges almost surely to infinity. (")#emph[#text("Hint:")]#text(" use the spectral theorem to relate ")#tao-math("{\\left\\|A_n\\right\\|_{op}}", block: false)#text(" with the quantities ")#mi("{\\text{tr} (A_n A_n^*)^k}")#text(".)")]
)
]

#text("One can obtain much sharper information on quantities such as the operator norm of a random matrix; see ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("this previous blog post")]#text(" for further discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" The ")#link("https://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér random model for the primes")]#text(" is a random subset ")#mi("{{\\mathcal P}}")#text(" of the natural numbers with ")#mi("{1 \\not \\in {\\mathcal P}}")#text(", ")#mi("{2 \\in {\\mathcal P}}")#text(", and the events ")#mi("{n \\in {\\mathcal P}}")#text(" for ")#mi("{n=3,4,\\dots}")#text(" being jointly independent with ")#mi("{{\\bf P}(n \\in {\\mathcal P}) = \\frac{1}{\\log n}}")#text(" (the restriction to ")#mi("{n \\geq 3}")#text(" is to ensure that ")#mi("{\\frac{1}{\\log n}}")#text(" is less than ")#mi("{1}")#text("). It is a simple, yet reasonably convincing, probabilistic model for the primes ")#mi("{\\{2,3,5,7,\\dots\\}}")#text(", which can be used to provide heuristic confirmations for many conjectures in analytic number theory. (It can be refined to give what are believed to be more accurate predictions; see ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this previous blog post")]#text(" for further discussion.)")

#list(
[#text("(i) (Probabilistic prime number theorem) Prove that almost surely, the quantity ")#tao-math("{\\frac{1}{x/\\log x} \\left|\\{ n \\leq x: n \\in {\\mathcal P}\\}\\right|}", block: false)#text(" converges to one as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(ii) (Probabilistic Riemann hypothesis) Show that if ")#mi("{\\varepsilon > 0}")#text(", then the quantity")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{x^{1/2+\\varepsilon}} ( \\left|\\{ n \\leq x: n \\in {\\mathcal P} \\}\\right| - \\int_2^x \\frac{dt}{\\log t} )", block: true)]]

#text("converges almost surely to zero as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(iii) (Probabilistic twin prime conjecture) Show that almost surely, there are an infinite number of elements ")#mi("{p}")#text(" of ")#mi("{{\\mathcal P}}")#text(" such that ")#mi("{p+2}")#text(" also lies in ")#mi("{{\\mathcal P}}")#text(".")],
[#text("(iv) (Probabilistic Goldbach conjecture) Show that almost surely, all but finitely many natural numbers ")#mi("{n}")#text(" are expressible as the sum of two elements of ")#mi("{{\\mathcal P}}")#text(".")]
)
]

#text("Probabilistic methods are not only useful for getting ")#emph[#text("heuristic")]#text(" predictions about the primes; they can also give ")#emph[#text("rigorous")]#text(" results about the primes. We give one basic example, namely a probabilistic proof (due to Turán) of a ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("theorem of Hardy and Ramanujan")]#text(", which roughly speaking asserts that a typical large number ")#mi("{n}")#text(" has about ")#mi("{\\log\\log n}")#text(" distinct prime factors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Hardy-Ramanujan theorem)")]#text(" Let ")#mi("{x \\geq 100}")#text(" be a natural number (so in particular ")#mi("{\\log \\log x \\geq 1}")#text("), and let ")#mi("{n}")#text(" be a natural number drawn uniformly at random from ")#mi("{1}")#text(" to ")#mi("{x}")#text(". Assume ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\frac{1}{p} =\\log\\log x + O(1)")]]

#text("for all ")#mi("{x \\geq 100}")#text(", where the sum is over primes up to ")#mi("{x}")#text(".")

#list(
[#text("(i) Show that the random variable ")#mi("{\\sum_{p \\leq x^{1/10}} 1_{p|n}}")#text(" (where ")#mi("{1_{p|n}}")#text(" is ")#mi("{1}")#text(" when ")#mi("{p}")#text(" divides ")#mi("{n}")#text(" and ")#mi("{0}")#text(" otherwise, and the sum is over primes up to ")#mi("{x^{1/10}}")#text(") has mean ")#mi("{\\log\\log x + O(1)}")#text(" and variance ")#mi("{O( \\log\\log x)}")#text(". (")#emph[#text("Hint:")]#text(" compute (up to reasonable error) the means, variances and covariances of the random variables ")#mi("{1_{p|n}}")#text(".)")],
[#text("(ii) If ")#mi("{\\omega(n)}")#text(" denotes the number of distinct prime factors of ")#mi("{n}")#text(", show that ")#mi("{\\frac{\\omega(n)}{\\log\\log n}}")#text(" converges to ")#mi("{1}")#text(" in probability as ")#mi("{x \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" first show that ")#mi("{\\omega(n) = \\sum_{p \\leq x^{1/10}} 1_{p|n} + O(1))}")#text(".) More precisely, show that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\omega(n) - \\log\\log n}{g(n) \\sqrt{\\log\\log n}}")]]

#text("converges in probability to zero, whenever ")#mi("{g: {\\bf N} \\rightarrow {\\bf R}}")#text(" is any function such that ")#mi("{g(n)}")#text(" goes to infinity as ")#mi("{n \\rightarrow \\infty}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Shannon entropy)")]#text(" Let ")#mi("{A}")#text(" be a finite non-empty set of some cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(", and let ")#mi("{X}")#text(" be a random variable taking values in ")#mi("{A}")#text(". Define the ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" ")#mi("{{\\bf H}(X)}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("{\\bf H}(X) := \\sum_{x \\in A} {\\bf P}(X = x) \\log \\frac{1}{{\\bf P}(X=x)}")]]

#text("with the convention that ")#mi("{0 \\log \\frac{1}{0}=0}")#text(". (In some texts, the logarithm to base ")#mi("{2}")#text(" is used instead of the natural logarithm ")#mi("{\\log}")#text(".)")

#list(
[#text("(i) Show that ")#tao-math("{0 \\leq {\\bf H}(X) \\leq \\log \\left|A\\right|}", block: false)#text(". (")#emph[#text("Hint:")]#text(" use Jensen’s inequality.) Determine when the equality ")#tao-math("{{\\bf H}(X) = \\log \\left|A\\right|}", block: false)#text(" holds.")],
[#text("(ii) Let ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{n}")#text(" be a natural number. Let ")#mi("{X_1,\\dots,X_n}")#text(" be ")#mi("{n}")#text(" iid copies of ")#mi("{X}")#text(", thus ")#mi("{\\vec X := (X_1,\\dots,X_n)}")#text(" is a random variable taking values in ")#mi("{A^n}")#text(", and the distribution ")#mi("{\\mu_{\\vec X}}")#text(" is a probability measure on ")#mi("{A^n}")#text(". Let ")#mi("{\\Omega \\subset A^n}")#text(" denote the set")

#tao-aligned(keep: true)[


#tao-math("\\Omega  & := \\{ \\vec x \\in A^n: \\exp(-(1+\\varepsilon) n {\\bf H}(X)) \\leq \\mu_{\\vec X}(\\{\\vec x\\})", block: true)



#tao-math(" & \\leq \\exp(-(1-\\varepsilon) n {\\bf H}(X)) \\}.", block: true)
]

#text("Show that if ")#mi("{n}")#text(" is sufficiently large, then")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\vec X \\in \\Omega) \\geq 1-\\varepsilon")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("\\exp((1-2\\varepsilon) n {\\bf H}(X))  & \\leq \\left|\\Omega\\right|", block: true)



#tao-math(" & \\leq \\exp((1+2\\varepsilon) n {\\bf H}(X)).", block: true)
]

#text("(")#emph[#text("Hint:")]#text(" use the weak law of large numbers to understand the number of times each element ")#mi("{x}")#text(" of ")#mi("{A}")#text(" occurs in ")#mi("{\\vec X}")#text(".)")]
)

#text("Thus, roughly speaking, while ")#mi("{\\vec X}")#text(" in principle takes values in all of ")#mi("{A^n}")#text(", in practice it is concentrated in a set of size about ")#mi("{\\exp( n {\\bf H}(X) )}")#text(", and is roughly uniformly distributed on that set. This is the beginning of the ")#link("https://en.wikipedia.org/wiki/Microstate_(statistical_mechanics)")[#text("microstate")]#text(" interpretation of Shannon entropy, but we will not develop the theory of Shannon entropy further in this course.")
]

#heading(level: 1)[#strong[#text(" — 2. Truncation — ")]]

#text("The weak and strong laws of large numbers have been proven under additional moment assumptions (of finite second moment and finite fourth moment respectively). To remove these assumptions, we use the simple but effective ")#emph[#text("truncation method")]#text(", decomposing a general scalar random variable ")#mi("{X}")#text(" into a truncated component such as ")#tao-math("{X 1_{\\left|X\\right| \\leq M}}", block: false)#text(" for some suitable threshold ")#mi("{M}")#text(", and a tail ")#tao-math("{X 1_{\\left|X\\right|>M}}", block: false)#text(". The main term ")#tao-math("{X 1_{\\left|X\\right| \\leq M}}", block: false)#text(" is bounded and thus has all moments finite. The tail ")#tao-math("{X 1_{\\left|X\\right| > M}}", block: false)#text(" will not have much better moment properties than the original variable ")#mi("{X}")#text(", but one can still hope to make it “small” in various ways. There is a tradeoff regarding the selection of the truncation parameter ")#mi("{M}")#text(": if ")#mi("{M}")#text(" is too large, then the truncated component ")#tao-math("{X 1_{\\left|X\\right| \\leq M}}", block: false)#text(" has poor estimates, but if ")#mi("{M}")#text(" is too small then the tail ")#tao-math("{X 1_{\\left|X\\right|>M}}", block: false)#text(" causes trouble.")#linebreak()#text(" Let’s first see how this works with the weak law of large numbers. As before, we assume we have an iid sequence ")#mi("{X_1,X_2,\\dots}")#text(" copies of a real absolutely integrable ")#mi("{X}")#text(" with no additional finite moment hypotheses. We write ")#mi("{S_n = X_1 + \\dots + X_n}")#text(". At present, we cannot take variances of the ")#mi("{X_i}")#text(" or ")#mi("{S_n}")#text(" and so the second moment method is not directly available. But we now perform a truncation; it turns out that a good choice of threshold here is ")#mi("{n}")#text(", thus we write ")#mi("{X_i = X_{i,\\leq n} + X_{i, > n}}")#text(" where ")#tao-math("{X_{i, \\leq n} := X_i 1_{\\left|X_i\\right| \\leq n}}", block: false)#text(" and ")#tao-math("{X_{i,>n} := X_i 1_{\\left|X_i\\right| > n}}", block: false)#text(", and then similarly decompose ")#mi("{S_n = S_{n,\\leq} + S_{n,>}}")#text(" where")

#align(center)[#tao-fit-display[#mitex("S_{n,\\leq} := X_{1,\\leq n} + \\dots + X_{n,\\leq n}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{n,>} := X_{1,>n} + \\dots + X_{n,>n}.")]]

#text("Write ")#mi("{\\mu := {\\bf E} X}")#text(". We wish to show that ")#metadata(none) <tao-ded988ef45eda60ae12b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any given ")#mi("{\\varepsilon > 0}")#text(" (not depending on ")#mi("{n}")#text("). By the triangle inequality, we can split")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq {\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon ) + {\\bf P}( S_{n,>} \\neq 0 ).", block: true)]]

#text("We begin by studying ")#mi("{S_{n,\\leq}/n}")#text(".")#linebreak()#text(" The random variables ")#mi("{X_{1,\\leq n},\\dots,X_{n,\\leq n}}")#text(" are iid with mean ")#tao-math("{\\mu_{\\leq n} := {\\bf E} X 1_{\\left|X\\right| \\leq n}}", block: false)#text(" and variance at most")

#tao-aligned(keep: true)[


#tao-math("{\\bf Var}(X 1_{\\left|X\\right| \\leq n})  & \\leq {\\bf E} (X 1_{\\left|X\\right| \\leq n})^2", block: true)



#tao-math(" & = {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq n}.", block: true)
]

#text("Thus, ")#mi("{S_{n,\\leq}/n}")#text(" has mean ")#mi("{\\mu_{\\leq n}}")#text(" and variance at most ")#tao-math("{\\frac{1}{n} {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq n}}", block: false)#text(". By dominated convergence, ")#mi("{\\mu_{\\leq n} \\rightarrow \\mu}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", so for sufficiently large ")#mi("{n}")#text(" we can bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon ) \\leq {\\bf P}( \\left|S_{n,\\leq}/n - \\mu_{\\leq n}\\right| \\geq \\varepsilon/2 )", block: true)]]

#text("and hence by the Chebyshev inequality")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon ) \\leq \\frac{1}{(\\varepsilon/2)^2} {\\bf E} \\frac{\\left|X\\right|^2}{n} 1_{\\left|X\\right| \\leq n}.", block: true)]]

#text("Observe that ")#tao-math("{\\frac{\\left|X\\right|^2}{n} 1_{\\left|X\\right| \\leq n}}", block: false)#text(" is bounded surely by the absolutely integrable ")#tao-math("{\\left|X\\right|}", block: false)#text(", and goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(", so by dominated convergence we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon ) \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" (keeping ")#mi("{\\varepsilon}")#text(" fixed).")#linebreak()#text(" To handle ")#mi("{S_{n,>}}")#text(", we observe that each ")#mi("{X_{i,>n}}")#text(" is only non-zero with probability ")#tao-math("{{\\bf P}(\\left|X\\right| > n)}", block: false)#text(", and hence by subadditivity")

#tao-aligned(keep: true)[


#tao-math("{\\bf P}( \\left|S_{n,>}\\right| > 0 )  & \\leq n {\\bf P}(\\left|X\\right|>n)", block: true)



#tao-math(" & = {\\bf E} n 1_{\\left|X\\right|>n}.", block: true)
]

#text("By dominated convergence again, ")#tao-math("{{\\bf E} n 1_{\\left|X\\right|>n} \\rightarrow 0}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_{n,>} \\neq 0 ) \\rightarrow 0.")]]

#text("Putting all this together, we conclude ")#link(<tao-ded988ef45eda60ae12b>)[#text("(5)")]#text(" as required. This concludes the proof of the weak law of large numbers (in the iid case) for arbitrary absolutely integrable ")#mi("{X}")#text(". For future reference, we observe that the above arguments give the bound ")#metadata(none) <tao-fb63d37ea6d30a132e44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq \\frac{1}{(\\varepsilon/2)^2} {\\bf E} \\frac{\\left|X\\right|^2}{n} 1_{\\left|X\\right| \\leq n} + {\\bf E} n 1_{\\left|X\\right|>n}", block: true)]]

#text("whenever ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(".")#linebreak()#text(" Due to the reliance on the dominated convergence theorem, the above argument does not provide any uniform rate of decay in ")#link(<tao-ded988ef45eda60ae12b>)[#text("(5)")]#text(". Indeed there is no such uniform rate. Consider for instance the sum ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" where ")#mi("{X_1,\\dots,X_n}")#text(" are iid random variables that equal ")#mi("{n}")#text(" with probability ")#mi("{1/n}")#text(" and ")#mi("{0}")#text(" with probability ")#mi("{1-1/n}")#text(". Then the ")#mi("{X_i}")#text(" are unsigned and all have mean ")#mi("{1}")#text(", but ")#mi("{S_n}")#text(" vanishes with probability ")#mi("{(1-1/n)^n}")#text(", which converges to ")#mi("{1/e}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Thus we see that the probability that ")#mi("{S_n/n}")#text(" stays a distance ")#mi("{1}")#text(" from the mean value of ")#mi("{1}")#text(" is bounded away from zero. This is not inconsistent with the weak law of large numbers, because the underlying random variable ")#mi("{X}")#text(" depends on ")#mi("{n}")#text(" in this example. However, it rules out an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq c_{\\varepsilon,M}(n)", block: true)]]

#text("that holds uniformly whenever ")#mi("{X}")#text(" obeys the bound ")#tao-math("{{\\bf E} \\left|X\\right| \\leq M}", block: false)#text(", and ")#mi("{c_{\\varepsilon,M}(n)}")#text(" is a quantity that goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for a fixed choice of ")#mi("{\\varepsilon,M}")#text(". (Contrast this with ")#link(<tao-77d0916c6d6c878c4fa9>)[#text("(2)")]#text(", which does provide such a uniform bound if one also assumes a bound on the second moment ")#tao-math("{{\\bf E} \\left|X\\right|^2}", block: false)#text(".)")#linebreak()#text(" One can ask what happens to the ")#mi("{S_n}")#text(" when the underlying random variable ")#mi("{X}")#text(" is not absolutely integrable. In the unsigned case, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an unsigned random variable ")#mi("{X}")#text(" with infinite mean, and write ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". Show that ")#mi("{S_n/n}")#text(" diverges to infinity in probability, in the sense that ")#mi("{{\\bf P}( S_n/n \\geq M ) \\rightarrow 1}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{M < \\infty}")#text(".")
]

#text("The above exercise shows that ")#mi("{S_n}")#text(" grows faster than ")#mi("{n}")#text(" (in probability, at least) when ")#mi("{X}")#text(" is unsigned with infinite mean, but this does not completely settle the question of the precise rate at which ")#mi("{S_n}")#text(" does grow. We will not answer this question in full generality here, but content ourselves with analysing a classic example of the unsigned infinite mean setting, namely the ")#link("https://en.wikipedia.org/wiki/St._Petersburg_paradox")[#text("Saint Petersburg paradox")]#text(". The paradox can be formulated as follows. Suppose we have a lottery whose payout ")#mi("{X}")#text(" takes values in the powers of two ")#mi("{2,2^2,2^3,\\dots}")#text(" with")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X = 2^i ) = 2^{-i}")]]

#text("for ")#mi("{i=1,2,\\dots}")#text(". The question is to work out what is the “fair” or “breakeven” price to pay for a lottery ticket. If one plays this lottery ")#mi("{n}")#text(" times, the total payout is ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" where ")#mi("{X_1,X_2,\\dots}")#text(" are independent copies of ")#mi("{X}")#text(", so the question boils down to asking what one expects the value of ")#mi("{S_n/n}")#text(" to be. If ")#mi("{X}")#text(" were absolutely integrable, the strong or weak law of large numbers would indicate that ")#mi("{{\\bf E} X}")#text(" is the fair price to pay, but in this case we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X = \\sum_{i=1}^\\infty 2^i \\times 2^{-i} = \\sum_{i=1}^\\infty 1 = \\infty.")]]

#text("This suggests, paradoxically, that any finite price for this lottery, no matter how high, would be a bargain!")#linebreak()#text(" To clarify this paradox, we need to get a better understanding of the random variable ")#mi("{S_n/n}")#text(". For a given ")#mi("{n}")#text(", we let ")#mi("{M}")#text(" be a truncation parameter to be chosen later, and split ")#mi("{X_i = X_{i,\\leq M} + X_{i,>M}}")#text(" where ")#mi("{X_{i,\\leq M} := X_i 1_{X_i \\leq M}}")#text(" and ")#mi("{X_{i,>M} := X_i 1_{X_i>M}}")#text(" as before (we no longer need the absolute value signs here as all random variables are unsigned). Since the ")#mi("{X_i}")#text(" take values in powers of two, we may as well also set ")#mi("{M=2^m}")#text(" to be a power of two. We split ")#mi("{S_n = S_{n,\\leq} + S_{n,>}}")#text(" where")

#align(center)[#tao-fit-display[#mitex("S_{n,\\leq} = X_{1,\\leq M} + \\dots + X_{n,\\leq M}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{n,>} = X_{1,> M} + \\dots + X_{n,>M}.")]]

#text("The random variable ")#mi("{X 1_{X \\leq M}}")#text(" can be computed to have mean")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X 1_{X \\leq M} = \\sum_{i=1}^m 2^i \\times 2^{-i} = m")]]

#text("and we can upper bound the variance by")

#tao-aligned(keep: true)[


#tao-math("{\\bf Var}(X 1_{X \\leq M})  & \\leq {\\bf E} (X 1_{X \\leq M})^2", block: true)



#tao-math(" & = \\sum_{i=1}^m 2^{2i} 2^{-i}", block: true)



#tao-math(" & \\leq 2^{m+1}", block: true)
]

#text("and hence ")#mi("{S_{n,\\leq}/n}")#text(" has mean ")#mi("{m}")#text(" and variance at most ")#mi("{2^{m+1}/n}")#text(". By Chebyshev’s inequality, we thus have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n,\\leq}/n - m\\right| \\geq \\lambda ) \\leq \\frac{2^{m+1}}{n \\lambda^2}", block: true)]]

#text("for any ")#mi("{\\lambda > 0}")#text(".")#linebreak()#text(" Now we turn to ")#mi("{S_{n,>}}")#text(". We cannot use the first or second moment methods here because the ")#mi("{X_{i,>M}}")#text(" are not absolutely integrable. However, we can instead use the following “zeroth moment method” argument. Observe that the random variable ")#mi("{X 1_{X>M}}")#text(" is only nonzero with probability ")#mi("{2^{-m}}")#text(" (that is to say, the “zeroth moment” ")#mi("{{\\bf E} (X 1_{X>M})^0}")#text(" is ")#mi("{2^{-m}}")#text(", using the convention ")#mi("{0^0=0}")#text("). Thus ")#mi("{S_{n,>}}")#text(" is nonzero with probability at most ")#mi("{n 2^{-m}}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n}/n - m\\right| \\geq \\lambda ) \\leq \\frac{2^{m+1}}{n \\lambda^2} + n 2^{-m}", block: true)]]

#text("This bound is valid for any natural number ")#mi("{m}")#text(" and any ")#mi("{\\lambda > 0}")#text(". Of course for this bound to be useful, we want to select parameters so that the right-hand side is somewhat small. If we pick for instance ")#mi("{m}")#text(" to be the integer part of ")#mi("{\\log_2 n + \\frac{1}{2} \\log_2 \\log_2 n}")#text(", and ")#mi("{\\lambda}")#text(" to be ")#mi("{\\sqrt{\\log_2 n}}")#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n/n - \\log_2 n - \\frac{1}{2}\\log_2 \\log_2 n\\right| \\geq \\sqrt{\\log_2 n} ) = O( \\frac{1}{\\log^{1/2} n} )", block: true)]]

#text("which (for large ")#mi("{n}")#text(") implies that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n}{n \\log_2 n} - 1\\right| \\geq \\frac{2}{\\sqrt{\\log_2 n}} ) = O( \\frac{1}{\\log^{1/2} n} ).", block: true)]]

#text("In particular, we see that ")#mi("{S_n / (n \\log_2 n)}")#text(" converges in probability to one. This suggests that the fair price to pay for the Saint Petersburg lottery is a function of the number ")#mi("{n}")#text(" of tickets one wishes to play, and should be approximately ")#mi("{\\log_2 n}")#text(" when ")#mi("{n}")#text(" is large. In particular, the lottery is indeed worth paying out any finite cost ")#mi("{M}")#text(", but one needs to buy about ")#mi("{2^M}")#text(" tickets before one breaks even!")#linebreak()#text(" In contrast to the absolutely integrable case, in which the weak law can be upgraded to the strong law, there is no strong law for the Saint Petersburg paradox:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" With the notation as in the above analysis of the Saint Petersburg paradox, show that ")#mi("{\\frac{S_n}{n \\log_2 n}}")#text(" is almost surely unbounded. (")#emph[#text("Hint:")]#text(" it suffices to show that ")#mi("{X_n / n \\log_2 n}")#text(" is almost surely unbounded. For this, use the second Borel-Cantelli lemma.)")
]

#text("The following exercise can be viewed as a continuous analogue of the Saint Petersburg paradox.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" A real random variable ")#mi("{X}")#text(" is said to have a ")#link("https://en.wikipedia.org/wiki/Cauchy_distribution")[#text("standard Cauchy distribution")]#text(" if it has the probability density function ")#mi("{x \\mapsto \\frac{1}{\\pi} \\frac{1}{1+x^2}}")#text(".")

#list(
[#text("(i) Verify that standard Cauchy distributions exist (this boils down to checking that the integral of the probability density function is ")#mi("{1}")#text(").")],
[#text("(ii) Show that a real random variable with the standard Cauchy distribution is not absolutely integrable.")],
[#text("(iii) If ")#mi("{X_1,X_2,\\dots}")#text(" are iid copies of a random variable ")#mi("{X}")#text(" with the standard Cauchy distribution, show that ")#tao-math("{\\frac{\\left|X_1\\right|+\\dots+\\left|X_n\\right|}{n \\log n}}", block: false)#text(" converges in probability to ")#mi("{\\frac{2}{\\pi}}")#text(" but is almost surely unbounded.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Weak law of large numbers for triangular arrays)")]#text(" Let ")#mi("{(X_{i,n})_{i,n \\in {\\bf N}: 1 \\leq i \\leq n}}")#text(" be a triangular array of random variables, with the variables ")#mi("{X_{1,n},\\dots,X_{n,n}}")#text(" jointly independent for each ")#mi("{n}")#text(". Let ")#mi("{M_n}")#text(" be a sequence going to infinity, and write ")#tao-math("{X_{i,n,\\leq} := X_{i,n} 1_{\\left|X_{i,n}\\right| \\leq M_n}}", block: false)#text(" and ")#mi("{\\mu_n := \\sum_{i=1}^n {\\bf E} X_{i,n,\\leq}}")#text(". Assume that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{i=1}^n {\\bf P}( \\left|X_{i,n}\\right| > M_n ) \\rightarrow 0", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{M_n^2} \\sum_{i=1}^n {\\bf E} \\left|X_{i,n,\\leq}\\right|^2 \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{X_{1,n}+\\dots+X_{n,n} - \\mu_n}{M_n} \\rightarrow 0")]]

#text("in probability.")
]

#text("Now we turn to establishing the strong law of large numbers in full generality. A first attempt would be to apply the Borel-Cantelli lemma to the bound ")#link(<tao-fb63d37ea6d30a132e44>)[#text("(6)")]#text(". However, the decay rates for quantities such as ")#tao-math("{{\\bf P}( \\left|S_n/n - \\mu\\right| > \\varepsilon )}", block: false)#text(" are far too weak to be absolutely summable, in large part due to the reliance on the dominated convergence theorem. To get around this we follow some ")#link("http://www.ams.org/mathscinet-getitem?mr=606010")[#text("arguments of Etemadi")]#text(". We first need to make a few preliminary reductions, aimed at “sparsifying” the set of times ")#mi("{n}")#text(" that one needs to control. It is here that we will genuinely use the fact that the averages ")#mi("{S_n}")#text(" are being drawn from a single sequence ")#mi("{X_1,X_2,\\dots}")#text(" of random variables, rather than from a triangular array.")#linebreak()#text(" We turn to the details. In previous arguments it was convenient to normalise the underlying random variable ")#mi("{X}")#text(" to have mean zero. Here we will use a different reduction, namely to the case when ")#mi("{X}")#text(" is unsigned; the strong law for real absolutely integrable ")#mi("{X}")#text(" clearly follows from the unsigned case by expressing ")#mi("{X}")#text(" as the difference of two unsigned absolutely integrable variables ")#mi("{\\max(X,0)}")#text(" and ")#mi("{\\max(-X,0)}")#text(" (and splitting ")#mi("{X_n}")#text(" similarly).")#linebreak()#text(" Henceforth we assume ")#mi("{X}")#text(" (and hence the ")#mi("{X_n}")#text(") to be unsigned. Crucially, this now implies that the partial sums ")#mi("{S_n}")#text(" are monotone: ")#mi("{S_n \\leq S_{n+1}}")#text(". While this does not quite imply any monotonicity on the sequence ")#mi("{S_n/n}")#text(", it does make it significantly easier to show that it converges. The key point is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 22")]#text(" Let ")#mi("{0 \\leq S_1 \\leq S_2 \\leq \\dots}")#text(" be an increasing sequence, and let ")#mi("{\\mu}")#text(" be a real number. Suppose that for any ")#mi("{\\delta > 0}")#text(", the sequence ")#mi("{S_{n_{j,\\delta}}/n_{j,\\delta}}")#text(" converges to ")#mi("{\\mu}")#text(" as ")#mi("{j \\rightarrow \\infty}")#text(", where ")#mi("{n_{j,\\delta} := \\lfloor (1+\\delta)^j \\rfloor}")#text(". Then ")#mi("{S_n/n}")#text(" converges to ")#mi("{\\mu}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{0 < \\delta < 1/2}")#text(". For any ")#mi("{n}")#text(", let ")#mi("{j}")#text(" be the index such that ")#mi("{n_{j,\\delta} \\leq n < n_{j+1,\\delta}}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("S_{n_{j,\\delta}} \\leq S_n \\leq S_{n_{j+1,\\delta}}")]]

#text("and (for sufficiently large ")#mi("{n}")#text(")")

#align(center)[#tao-fit-display[#mitex("(1+2\\delta) n_{j,\\delta} \\geq n \\geq \\frac{1}{1+2\\delta} n_{j+1,\\delta}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1+2\\delta} \\frac{S_{n_{j,\\delta}}}{n_{j,\\delta}} \\leq \\frac{S_n}{n} \\leq (1+2\\delta) \\frac{S_{n_{j+1,\\delta}}}{n_{j+1,\\delta}}.")]]

#text("Taking limit inferior and superior, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1+2\\delta} \\mu \\leq \\liminf_{n \\rightarrow \\infty} \\frac{S_n}{n} \\leq \\limsup_{n \\rightarrow \\infty} \\frac{S_n}{n} \\leq (1+2\\delta) \\mu,")]]

#text("and then sending ")#mi("{\\delta \\rightarrow 0}")#text(" we obtain the claim. ")#mi("\\Box")#linebreak()#text(" An inspection of the above argument shows that we only need to verify the hypothesis for a countable sequence of ")#mi("{\\delta}")#text(" (e.g. ")#mi("{\\delta=1/m}")#text(" for natural number ")#mi("{m}")#text("). Thus, to show that ")#mi("{S_n/n}")#text(" converges to ")#mi("{\\mu}")#text(" almost surely, it suffices to show that for any ")#mi("{\\delta>0}")#text(", one has ")#mi("{S_{n_{j,\\delta}}/n_{j,\\delta} \\rightarrow \\mu}")#text(" almost surely as ")#mi("{j \\rightarrow \\infty}")#text(".")#linebreak()#text(" Fix ")#mi("{\\delta > 0}")#text(". The point is that the “lacunary” sequence ")#mi("{n_{j,\\delta}}")#text(" is much sparser than the sequence of natural numbers ")#mi("{n}")#text(", and one now will lose a lot less from the Borel-Cantelli argument. Indeed, for any ")#mi("{\\varepsilon > 0}")#text(", we can apply ")#link(<tao-fb63d37ea6d30a132e44>)[#text("(6)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_{n_{j,\\delta}}/n_{j,\\delta} - \\mu\\right| \\geq \\varepsilon ) \\leq \\frac{1}{(\\varepsilon/2)^2} {\\bf E} \\frac{\\left|X\\right|^2}{n_{j,\\delta}} 1_{\\left|X\\right| \\leq n_{j,\\delta}} + {\\bf E} n_{j,\\delta} 1_{\\left|X\\right|>n_{j,\\delta}}", block: true)]]

#text("whenever ")#mi("{j}")#text(" is sufficiently large depending on ")#mi("{\\delta,\\varepsilon}")#text(". Thus, by the Borel-Cantelli lemma, it will suffice to show that the sums")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^\\infty {\\bf E} \\frac{\\left|X\\right|^2}{n_{j,\\delta}} 1_{\\left|X\\right| \\leq n_{j,\\delta}}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^\\infty {\\bf E} n_{j,\\delta} 1_{\\left|X\\right|>n_{j,\\delta}}", block: true)]]

#text("are finite. Using the monotone convergence theorem to interchange the sum and expectation, it thus suffices to show the pointwise estimates")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^\\infty \\frac{\\left|X\\right|^2}{n_{j,\\delta}} 1_{\\left|X\\right| \\leq n_{j,\\delta}} \\leq C_\\varepsilon \\left|X\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^\\infty n_{j,\\delta} 1_{\\left|X\\right|>n_{j,\\delta}} \\leq C_\\varepsilon \\left|X\\right|", block: true)]]

#text("for some ")#mi("{C_\\varepsilon}")#text(". But this follows from the geometric series formula (the first sum is over the elements of the sequence ")#mi("{n_{j,\\delta}}")#text(" that are greater than or equal to ")#tao-math("{\\left|X\\right|}", block: false)#text(", while the latter is over those that are less than ")#tao-math("{\\left|X\\right|}", block: false)#text("). This proves the strong law of large numbers for arbitrary absolutely integrable iid ")#mi("{X_1,X_2,\\dots}")#text(".")#linebreak()#text(" We remark that by carefully inspecting the above proof of the strong law of large numbers, we see that the hypothesis of joint independence of the ")#mi("{X_n}")#text(" can be relaxed to pairwise independence.")#linebreak()#text(" The next exercise shows how one can use the strong law of large numbers to approximate the cumulative distribution function of a random variable ")#mi("{X}")#text(" by an empirical cumulative distribution function.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of a real random variable ")#mi("{X}")#text(".")

#list(
[#text("(i) Show that for every real number ")#mi("{t}")#text(", one has almost surely that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n} \\left| \\{ 1 \\leq i \\leq n: X_i \\leq t \\}\\right| \\rightarrow {\\bf P}( X \\leq t )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n} \\left| \\{ 1 \\leq i \\leq n: X_i < t \\}\\right| \\rightarrow {\\bf P}( X < t )", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(ii) Establish the ")#link("https://en.wikipedia.org/wiki/Glivenko%E2%80%93Cantelli_theorem")[#text("Glivenko-Cantelli theorem")]#text(": almost surely, one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{n} \\left| \\{ 1 \\leq i \\leq n: X_i \\leq t \\}\\right| \\rightarrow {\\bf P}( X \\leq t )", block: true)]]

#emph[#text("uniformly in ")#mi("{t}")]#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" For any natural number ")#mi("{m}")#text(", let ")#mi("{f_m(x)}")#text(" denote the largest integer multiple of ")#mi("{1/m}")#text(" less than ")#mi("{x}")#text(". Show first that ")#tao-math("{f_m( \\frac{1}{n} \\left| \\{ 1 \\leq i \\leq n: X_i \\leq t \\}\\right| )}", block: false)#text(" is within ")#mi("{O(1/m)}")#text(" of ")#mi("{f_m( {\\bf P}( X \\leq t ) )}")#text(" for all ")#mi("{t}")#text(" when ")#mi("{n}")#text(" is sufficiently large.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Lack of strong law for triangular arrays)")]#text(" Let ")#mi("{X}")#text(" be a random variable taking values in the natural numbers with ")#mi("{{\\bf P}(X=n) = \\frac{1}{\\zeta(3)} \\frac{1}{n^3}}")#text(", where ")#mi("{\\zeta(3) := \\sum_{n=1}^\\infty \\frac{1}{n^3}}")#text(" (this is an example of a ")#link("https://en.wikipedia.org/wiki/Zeta_distribution")[#text("zeta distribution")]#text(").")

#list(
[#text("(i) Show that ")#mi("{X}")#text(" is absolutely integrable.")],
[#text("(ii) Let ")#mi("{(X_{i,n})_{i,n \\in {\\bf N}: 1 \\leq i \\leq n}}")#text(" be jointly independent copies of ")#mi("{X}")#text(". Show that the random variables ")#mi("{\\frac{X_{1,n}+\\dots+X_{n,n}}{n}}")#text(" are almost surely unbounded. (")#emph[#text("Hint:")]#text(" for any constant ")#mi("{A}")#text(", show that ")#mi("{\\frac{X_{1,n}+\\dots+X_{n,n}}{n} > A}")#text(" occurs with probability at least ")#mi("{\\varepsilon/n}")#text(" for some ")#mi("{\\varepsilon > 0}")#text(" depending on ")#mi("{A}")#text(". Then use the second Borel-Cantelli lemma.)")]
)
]

#heading(level: 1)[#strong[#text(" — 3. The Kolmogorov maximal inequality — ")]]

#text("Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of jointly independent square-integrable real random variables of mean zero; we do not assume the ")#mi("{X_i}")#text(" to be identically distributed. As usual, we form the sums ")#mi("{S_n := X_1 + \\dots + X_n}")#text(", then ")#mi("{S_n}")#text(" has mean zero and variance ")#metadata(none) <tao-0f4167b44403cbfb049f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf Var}(S_n) = {\\bf E} S_n^2 = {\\bf Var}(X_1)+\\dots+{\\bf Var}(X_n).")]]

#text("From Chebyshev’s inequality, we thus have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n\\right| \\geq t ) \\leq \\frac{{\\bf Var}(X_1)+\\dots+{\\bf Var}(X_n)}{t^2}", block: true)]]

#text("for any ")#mi("{0 < t < \\infty}")#text(" and natural number ")#mi("{n}")#text(". Perhaps surprisingly, we have the following improvement to this bound, known as the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%27s_inequality")[#text("Kolmogorov maximal inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 25 (Kolmogorov maximal inequality)")]#text(" With the notation and hypotheses as above, we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{1 \\leq i \\leq n} \\left|S_i\\right| \\geq t ) \\leq \\frac{{\\bf Var}(X_1)+\\dots+{\\bf Var}(X_n)}{t^2}", block: true)]]
]

#emph[#text("Proof:")]#text(" For each ")#mi("{i}")#text(", let ")#mi("{E_i}")#text(" be the event that ")#tao-math("{\\left|S_i\\right| \\geq t}", block: false)#text(", but that ")#tao-math("{\\left|S_j\\right| < t}", block: false)#text(" for all ")#mi("{1 \\leq j < i}")#text(". It is clear that the event ")#tao-math("{\\sup_{1 \\leq i \\leq n} \\left|S_i\\right| \\geq t}", block: false)#text(" is the disjunction of the disjoint events ")#mi("{E_1,\\dots,E_n}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{1 \\leq i \\leq n} \\left|S_i\\right| \\geq t ) = \\sum_{i=1}^n {\\bf P}(E_i).", block: true)]]

#text("On the event ")#mi("{E_i}")#text(", we have ")#mi("{1 \\leq \\frac{1}{t^2} S_i^2}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(E_i) \\leq \\frac{1}{t^2} {\\bf E} S_i^2 1_{E_i}.")]]

#text("We will shortly prove the inequality ")#metadata(none) <tao-87d4ae063e345044c585>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{\\bf E} S_i^2 1_{E_i} \\leq {\\bf E} S_n^2 1_{E_i}")]]

#text("for all ")#mi("{1 \\leq i \\leq n}")#text(". Assuming this inequality for the moment, we can put together all the above estimates, using the disjointness of the ")#mi("{E_i}")#text(", to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{1 \\leq i \\leq n} \\left|S_i\\right| \\geq t ) \\leq \\frac{1}{t^2} {\\bf E} S_n^2", block: true)]]

#text("and the claim follows from ")#link(<tao-0f4167b44403cbfb049f>)[#text("(7)")]#text(".")#linebreak()#text(" It remains to prove ")#link(<tao-87d4ae063e345044c585>)[#text("(8)")]#text(". Since")

#tao-aligned(keep: true)[


#tao-math("S_n^2  & = S_i^2 + (S_n - S_i)^2 + 2 (S_n-S_i) S_i", block: true)



#tao-math(" & \\geq S_i^2 + 2 (S_n-S_i) S_i", block: true)
]

#text("we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} S_n^2 1_{E_i} \\geq {\\bf E} S_i^2 1_{E_i} + 2 {\\bf E} S_i 1_{E_i} (S_n-S_i).")]]

#text("But note that the random variable ")#mi("{S_i 1_{E_i}}")#text(" is completely determined by ")#mi("{X_1,\\dots,X_i}")#text(", while ")#mi("{S_n-S_i}")#text(" is completely determined by the ")#mi("{X_{i+1},\\dots,X_n}")#text(". Thus ")#mi("{S_i 1_{E_i}}")#text(" and ")#mi("{S_n-S_i}")#text(" are independent. Since ")#mi("{S_n-S_i}")#text(" also has mean zero, we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} S_i 1_{E_i} (S_n-S_i) = 0")]]

#text("and the claim ")#link(<tao-87d4ae063e345044c585>)[#text("(8)")]#text(" follows. ")#mi("\\Box")#linebreak()#text(" An inspection of the above proof reveals that the key ingredient is the ")#emph[#text("lack of correlation between past and future")]#text(" – a variable such as ")#mi("{S_i 1_{E_i}}")#text(", which is determined by the portion of the sequence ")#mi("{X_1,X_2,\\dots}")#text(" to the “past” (and present) of ")#mi("{i}")#text(", is uncorrelated with a variable such as ")#mi("{S_n-S_i}")#text(" that depends only on the “future” of ")#mi("{i}")#text(". One can formalise such a lack of correlation through the concept of a ")#link("https://en.wikipedia.org/wiki/Martingale_(probability_theory)")[#text("martingale")]#text(", which will be covered in later courses in this sequence but which is beyond the scope of these notes. The use of the first time ")#mi("{i}")#text(" at which ")#tao-math("{\\left|X_i\\right|}", block: false)#text(" exceeds or attains the threshold ")#mi("{t}")#text(" is a simple example of a ")#link("https://en.wikipedia.org/wiki/Stopping_time")[#text("stopping time")]#text(", which will be a heavily used concept in the theory of martingales (and is also used extensively in harmonic analysis, which is also greatly interested in establishing maximal inequalities).")#linebreak()#text(" The Kolmogorov maximal inequality gives the following variant of the strong law of large numbers.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 26 (Convergence of random series)")]#text(" ")#metadata(none) <tao-1cf8531a22348eeb2abe>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be jointly independent square-integrable real random variables of mean zero with")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^\\infty {\\bf Var}(X_i) < \\infty.")]]

#text("Then the series ")#mi("{\\sum_{i=1}^\\infty X_i}")#text(" is almost surely convergent (i.e., the partial sums converge almost surely).")
]

#emph[#text("Proof:")]#text(" From the Kolmogorov maximal inequality and continuity from below we have ")#metadata(none) <tao-461c97c288849d4a538e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("{\\bf P}( \\sup_i \\left|S_i\\right| \\geq t ) \\leq \\frac{\\sum_{i=1}^\\infty {\\bf Var}(X_i)}{t^2}.", block: true)]]

#text("This is already enough to show that the partial sums ")#mi("{S_n = \\sum_{i=1}^n X_i}")#text(" are almost surely bounded in ")#mi("{n}")#text(", but this isn’t quite enough to establish conditional convergence. To finish the job, we apply ")#link(<tao-461c97c288849d4a538e>)[#text("(9)")]#text(" with ")#mi("{X_1,X_2,\\dots}")#text(" replaced by the shifted sequence ")#mi("{X_{n+1}, X_{n+2}, \\dots}")#text(" for a natural number ")#mi("{n}")#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{i > n} \\left|S_i - S_n\\right| \\geq t ) \\leq \\frac{\\sum_{i=n+1}^\\infty {\\bf Var}(X_i)}{t^2}.", block: true)]]

#text("Sending ")#mi("{n}")#text(" to infinity using continuity from above, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\sup_{i > n} \\left|S_i - S_n\\right| \\geq t \\forall n) = 0", block: true)]]

#text("for all ")#mi("{t>0}")#text("; applying this for all rational ")#mi("{t>0}")#text(", we conclude that ")#mi("{S_1,S_2,\\dots}")#text(" is almost surely a Cauchy sequence, and the claim follows. ")#mi("\\Box")#linebreak()#text(" We can use this result together with some elementary manipulation of sums to give the following alternative proof of the strong law of large numbers.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Strong law of large numbers)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an absolutely integrable variable ")#mi("{X}")#text(" of mean ")#mi("{{\\bf E} X = \\mu}")#text(", and let ")#mi("{S_n := X_1+\\dots+X_n}")#text(". Then ")#mi("{S_n/n}")#text(" converges almost surely to ")#mi("{\\mu}")#text(".")
]

#emph[#text("Proof:")]#text(" We may normalise ")#mi("{X}")#text(" to be real valued with ")#mi("{\\mu=0}")#text(". Note that that")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n=1}^\\infty {\\bf P}( \\left|X_n\\right| > n )  & = \\sum_{n=1}^\\infty {\\bf P}(\\left|X\\right| > n)", block: true)



#tao-math(" & = {\\bf E} \\sum_{n=1}^\\infty 1_{\\left|X\\right| > n}", block: true)



#tao-math(" & \\leq {\\bf E} \\left|X\\right|", block: true)



#tao-math(" & < \\infty", block: true)
]

#text("and hence by the Borel-Cantelli lemma we almost surely have ")#tao-math("{\\left|X_n\\right| \\leq n}", block: false)#text(" for all but finitely many ")#mi("{n}")#text(". Thus if we write ")#tao-math("{X^{\\prime}_n := X_n 1_{\\left|X_n\\right| \\leq n}}", block: false)#text(" and ")#mi("{S^{\\prime}_n := X^{\\prime}_1+\\dots+X^{\\prime}_n}")#text(", then the difference between ")#mi("{S_n/n}")#text(" and ")#mi("{S^{\\prime}_n/n}")#text(" almost surely goes to zero as ")#mi("{n \\rightarrow \\infty}")#text(". Thus it will suffice to show that ")#mi("{S^{\\prime}_n/n}")#text(" goes to zero almost surely.")#linebreak()#text(" The random variables ")#mi("{X^{\\prime}_1,X^{\\prime}_2,\\dots}")#text(" are still jointly independent, but are not quite mean zero. However, the normalised random variables ")#mi("{Y_n := \\frac{X^{\\prime}_n - {\\bf E} X^{\\prime}_n}{n}}")#text(" are of mean zero and")

#tao-aligned(keep: true)[


#tao-math("\\sum_{i=1}^\\infty {\\bf Var}(Y_i)  & = \\sum_{i=1}^\\infty {\\bf Var}(X^{\\prime}_i) / i^2", block: true)



#tao-math(" & \\leq \\sum_{i=1}^\\infty {\\bf E} \\left|X^{\\prime}_i\\right|^2 / i^2", block: true)



#tao-math(" & = \\sum_{i=1}^\\infty {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq i} / i^2", block: true)



#tao-math(" & = {\\bf E} \\left|X\\right|^2 \\sum_{i > \\left|X\\right|} \\frac{1}{i^2}", block: true)



#tao-math(" & = {\\bf E} O( \\left|X\\right| )", block: true)



#tao-math(" & < \\infty", block: true)
]

#text("so by Theorem ")#link(<tao-1cf8531a22348eeb2abe>)[#text("26")]#text(" we see that the sum ")#mi("{\\sum_{i=1}^\\infty Y_i}")#text(" is almost surely convergent.")#linebreak()#text(" Write ")#mi("{T_n := Y_1+\\dots+Y_n}")#text(", thus the sequence ")#mi("{T_n}")#text(" is almost surely a Cauchy sequence. From the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{n} \\sum_{i=1}^n i Y_i = \\frac{1}{n} \\sum_{i=0}^{n-1} (T_n - T_i)")]]

#text("we conclude that the sequence ")#mi("{\\frac{1}{n} \\sum_{i=1}^n i Y_i}")#text(" almost surely converges to zero, that is to say")

#align(center)[#tao-fit-display[#mitex("\\frac{S^{\\prime}_n}{n} - \\frac{\\sum_{i=1}^n {\\bf E} X^{\\prime}_i}{n} \\rightarrow 0")]]

#text("almost surely. On the other hand, we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} X^{\\prime}_i  & = {\\bf E} X 1_{\\left|X\\right| \\leq i}", block: true)



#tao-math(" & = - {\\bf E} X 1_{\\left|X\\right| > i}", block: true)
]

#text("and hence by dominated convergence")

#align(center)[#tao-fit-display[#mitex("{\\bf E} X^{\\prime}_i \\rightarrow 0")]]

#text("as ")#mi("{i \\rightarrow \\infty}")#text(", which implies that")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sum_{i=1}^n {\\bf E} X^{\\prime}_i}{n} \\rightarrow 0")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". By the triangle inequality, we conclude that ")#mi("{S^{\\prime}_n/n \\rightarrow 0}")#text(" almost surely, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Kronecker lemma)")]#text(" Let ")#mi("{\\sum_{n=1}^\\infty Y_n}")#text(" be a convergent series of real numbers ")#mi("{Y_n}")#text(", and let ")#mi("{0 < b_1 \\leq b_2 \\leq \\dots}")#text(" be a sequence tending to infinity. Show that ")#mi("{\\frac{1}{b_n} \\sum_{i=1}^n b_i Y_i}")#text(" converges to zero as ")#mi("{n \\rightarrow \\infty}")#text(". (This is known as ")#link("https://en.wikipedia.org/wiki/Kronecker%27s_lemma")[#text("Kronecker’s lemma")]#text("; the special case ")#mi("{b_i=i}")#text(" was implicitly used in the above argument.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Kolmogorov three-series theorem, one direction)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of jointly independent real random variables, and let ")#mi("{A>0}")#text(". Suppose that the two series ")#tao-math("{\\sum_{n=1}^\\infty {\\bf P}(\\left|X_n\\right| > A)}", block: false)#text(" and ")#tao-math("{\\sum_{n=1}^\\infty {\\bf Var}( X_n 1_{\\left|X_n\\right| \\leq A} )}", block: false)#text(" are absolutely convergent, and the third series ")#tao-math("{\\sum_{n=1}^\\infty {\\bf E} X_n 1_{\\left|X_n\\right| \\leq A}}", block: false)#text(" is convergent. Show that the series ")#mi("{\\sum_{n=1}^\\infty X_n}")#text(" is almost surely convergent. (The converse claim is also true, and will be discussed in later notes; the two claims are known collectively as the ")#link("https://en.wikipedia.org/wiki/Kolmogorov%27s_three-series_theorem")[#text("Kolmogorov three-series theorem")]#text(".)")
]

#text("One advantage that the maximal inequality approach to the strong law of large numbers has over the moment method approach is that it tends to offer superior bounds on the (almost sure) ")#emph[#text("rate")]#text(" of convergence. We content ourselves with just one example of this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Cheap law of iterated logarithm)")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be a sequence of jointly independent real random variables of mean zero and bounded variance (thus ")#mi("{\\sup_n {\\bf E} X_n^2 < \\infty}")#text("). Write ")#mi("{S_n := X_1+\\dots+X_n}")#text(". Show that ")#mi("{\\frac{S_n}{n^{1/2} \\log^{1/2+\\varepsilon} n}}")#text(" converges almost surely to zero as ")#mi("{n \\rightarrow \\infty}")#text(" for any given ")#mi("{\\varepsilon>0}")#text(". (")#emph[#text("Hint:")]#text(" use Theorem ")#link(<tao-1cf8531a22348eeb2abe>)[#text("26")]#text(" and the Kronecker lemma for a suitable weighted sum of the ")#mi("{X_n}")#text(".) There is a more precise version of this fact known as the ")#link("https://en.wikipedia.org/wiki/Law_of_the_iterated_logarithm")[#text("law of the iterated logarithm")]#text(", which is beyond the scope of these notes.")
]

#text("The exercises below will be moved to a more appropriate location later, but are currently placed here in order to not disrupt existing numbering.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an absolutely integrable random variable ")#mi("{X}")#text(" with mean ")#mi("{\\mu}")#text(". Show that the averages ")#mi("{\\frac{S_n}{n} = \\frac{X_1+\\dots+X_n}{n}}")#text(" converge in ")#mi("{L^1}")#text(" to ")#mi("{\\mu}")#text(", that is to say that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\frac{S_n}{n}-\\mu\\right| \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" A scalar random variable ")#mi("{X}")#text(" is said to be in ")#emph[#text("weak ")#mi("{L^1}")]#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\sup_{t>0} t {\\bf P}(\\left|X\\right| \\geq t) < \\infty.", block: true)]]

#text("Thus Markov’s inequality tells us that every absolutely integrable random variable is in weak ")#mi("{L^1}")#text(", but the converse is not true (e.g. random variables with the Cauchy distribution are weak ")#mi("{L^1}")#text(" but not absolutely integrable). Show that if ")#mi("{X_1,X_2,\\dots}")#text(" are iid copies of an unsigned weak ")#mi("{L^1}")#text(" random variable that is not almost surely zero, then there exists quantities ")#mi("{a_n \\rightarrow \\infty}")#text(" such that ")#mi("{S_n/a_n}")#text(" converges in probability to ")#mi("{1}")#text(", where ")#mi("{S_n = X_1 + \\dots + X_n}")#text(". (Thus: there is a weak law of large numbers for weak ")#mi("{L^1}")#text(" random variables, and a strong law for strong ")#mi("{L^1}")#text(" (i.e. absolutely integrable) random variables.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be iid copies of a real symmetric random variable ")#mi("{X}")#text(" (thus ")#mi("{-X}")#text(" has the same distribution as ")#mi("{X}")#text("), and write ")#mi("{S_i := X_1 + \\dots + X_n}")#text(" for ")#mi("{i=1,\\dots,n}")#text(". For any ")#mi("{\\lambda > 0}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sup_{1 \\leq i \\leq n} S_i \\geq \\lambda ) \\leq 2 {\\bf P}( S_n \\geq \\lambda ).")]]

#text("(")#emph[#text("Hint:")]#text(" for each ")#mi("{1 \\leq i \\leq n}")#text(", show that ")#mi("{S_n-S_i}")#text(" is non-negative with probability at least ")#mi("{1/2}")#text(". Then use the stopping time argument used to prove the Kolmogorov maximal inequality.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (Lévy’s inequality)")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be i.i.d. copies of a real random variable ")#mi("{X}")#text(", and write ")#mi("{S_i := X_1 + \\dots + X_i}")#text(" for ")#mi("{i=1,\\dots,n}")#text(". Suppose one has ")#mi("{\\lambda, \\varepsilon > 0}")#text(" with the property that ")#tao-math("{{\\bf P}(\\left|S_i\\right| \\geq \\lambda) \\leq \\varepsilon}", block: false)#text(" for ")#mi("{i=1,\\dots,n}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( \\sup_{1 \\leq i \\leq n} S_i \\geq 2\\lambda ) \\leq \\frac{\\varepsilon}{1-\\varepsilon}.")]]

#text("(")#emph[#text("Hint:")]#text(" for each ")#mi("{1 \\leq i \\leq n}")#text(", show that ")#mi("{S_n-S_i}")#text(" is at least ")#mi("{-\\lambda}")#text(" with probability at least ")#mi("{1-\\varepsilon}")#text(". Then use the stopping time argument used to prove the Kolmogorov maximal inequality.)")
]

#heading(level: 1)[#text("Comments (168)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2024")])]

#text("Dear professor Tao: For part (i) Exercise 15, as ")#mi("1 / log n(1 - 1 / log n)")#text(" are summable, by your previous comment and the Borel-Cantelli lemma it follows that ")#mi("S_x")#text(" converges to ")#mi("x / log x")#text(" almost surely. Is this correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2024")])]

#text("Wait, the root test gives 1 and one can’t conclude summability in this case. May I ask how is it that Chebyshev’s inequality is sufficient here?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2024")])]

#text("Dear prof Tao:")

#text("For part (i) of Exercise 15, if we let let ")#mi("S_x = sum_{2 < n leq x} frac{1}{x / log x} 1_{{mathcal P}}(n)")#text(", do you recommend calculating the fourth moment ")#tao-math("{bf E}\\left|S_x\\right|^4", block: false)#text(" for the Borel-Cantelli lemma? Do we need to use the triangular arrays form as in Exercise 12?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2024")])]

#text("Dear prof Tao:")

#text("May I ask if the solution to part (2) of Exercise 15 requires the use of part (1)?")

#emph[#text("[It is a stronger statement, and is more difficult to prove. Strictly speaking one could attack (2) directly without first establishing (1), but for beginners I would recommend trying (1) first. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2024")])]

#text("Dear professor Tao:")

#text("In part (2) of Exercise 15, let ")#mi("X_n")#text(" be independent Bernoulli random variables of parameter ")#mi("1 / \\log n")#text(". if one considers the partial sums ")#mi("S_x")#text(" of ")#mi("Y_{n,x}")#text(" from ")#mi("3")#text(" up to ")#mi("x")#text(", where ")#mi("Y_{n,x}")#text(" equals ")#mi("X_n - 1 / \\log n")#text(" over ")#mi("x^{1/2 + \\epsilon}")#text(", then the moment method for the fourth moment stills seems not strong enough for one to show that ")#mi("S_x")#text(" converges almost surely to zero. May I ask if this is the correct approach to pursuit, or if one needs to go to even higher moment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684878")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("For this problem, one needs to work with a high moment that depends on ")#mi("\\varepsilon")#text(" (or else utilize a more powerful concentration inequality, such as Hoeffding’s inequality).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2024")])]

#text("Dear professor Tao:")

#text("Since part (3) of Exercise 15 only asks for a qualitative prediction on the number of twin Cramer random model primes, is it possible to work out a solution without obtaining a bound as explicit as the one obtained in Prediction 8 of your note for 254A, Supplement 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2024")])]

#text("Yes, there are multiple ways to approach this question, that give various levels of strength in their conclusion. For instance, one relatively easy way to proceed here is to locate a number of independent events that would produce twins, and apply the converse of the Borel-Cantelli lemma for independent events.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2024")])]

#text("Dear professor Tao:")

#text("Thank you so much for the guidance on Exercise 15. For the second part of Exercise 16, regrading ")#mi("n = n_x")#text(" as a sequence of random variables indexed by ")#mi("x")#text(", one wishes to show that ")#tao-math("\\displaystyle {\\bf P}(\\left| \\frac{\\omega(n_x) - \\log\\log n_x}{g(n_x) \\sqrt{\\log\\log n_x}}\\right| > \\varepsilon)", block: false)#text(" goes to zero as ")#mi("x \\to \\infty")#text(", to this end, how should one combine the given hint with part (1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("Dear professor Tao: I think I get it now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("Dear professor Tao:")

#text("May I ask why is it that large deviation bounds are mostly for controlling fluctuation above rather than below the expectation? Is this asymmetry caused primarily by need in applications?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-684927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2024")])]

#text("In order to control lower tail fluctuations, one would need to compute normalized moments ")#tao-math("{\\bf E} \\left|X - {\\bf E} X\\right|^{2k}", block: false)#text(". For upper tail fluctuations, one could use either normalized moments or non-normalized moments ")#tao-math("{\\bf E} \\left|X\\right|^{2k}", block: false)#text(", which are often easier to compute in practice (especially if ")#mi("X")#text(" is itself the absolute value or norm of some other quantity).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("Dear professor Tao:")

#text("Can you explain a bit more on the hint for part 2 of Exercise 17? Are you suggesting using the WLLN on the random variable ")#mi("\\sum_{i=1}^n 1_{X_i = x}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("It appears the first claim in part 2 of Exercise 17 can be established by using the WLLN on the random variables ")#mi("\\log 1 / {\\bf P}(X_i)")#text(", may I ask if the hint is for the second claim about the size of ")#mi("\\Omega")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("You have already used the hint to achieve the first claim; one can then directly deduce the second claim from the first just from the definition of ")#mi("\\Omega")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2024")])]

#text("Thank you so much, professor Tao.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685137")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2024")])]

#text("Dear professor Tao:")

#text("In the last display of the Saint Petersburg paradox analysis, why do we have ")#mi("2 / \\sqrt{\\log_2 n}")#text(" rather than ")#mi("1 / \\sqrt{\\log_2 n}")#text(" inside the probability sign? Isn’t the expression follows from the previous one by dividing ")#mi("\\log_2 n")#text(" inside the probability sign?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685138")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2024")])]

#text("Also, may I ask a little more explanation on the conclusion of the paradox that one needs to buy about ")#mi("2^M")#text(" tickets to reach a break-even point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2024")])]

#text("I think I get ")#mi("2^M")#text(" tickets part now, but may I still ask why we have ")#mi("2")#text(" rather than ")#mi("1")#text(" over the square root of ")#mi("\\log_2 n")#text(" please?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("This is just a safety margin to absorb the additional factor of ")#mi("\\frac{\\frac{1}{2} \\log_2 \\log_2 n}{n \\log_2 n}")#text(" that would otherwise arise when dividing the expression in the preceding line by ")#mi("\\log_2 n")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2024")])]

#text("Dear professor Tao:")

#text("Can you provide some clarification on the hint of Exercise 19 about showing the ")#mi("X_n")#text(" expression is almost surely unbounded? Because the second BC lemma would have shown that the limit superior (rather than the limit) of the ")#mi("X_n")#text(" expression is unbounded almost surely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("Showing that the limit superior of the ")#mi("X_n/n \\log n")#text(" is infinite is equivalent to showing that the sequence ")#mi("X_n/x \\log n")#text(" is unbounded.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2024")])]

#text("Dear professor Tao:")

#text("In part 3 of Exercise 20, if one chooses the truncation parameter to be ")#mi("n")#text(", then the tail probability that ")#mi("S_{n, >}")#text(" is nonzero can not be controlled (where ")#mi("S_n")#text(" is the sum of the ")#tao-math("\\left|X_i\\right|", block: false)#text("), can you suggests a way to fix this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2024")])]

#text("Dear professor Tao:")

#text("As for the question above, it looks like the tail probability that ")#mi("S_{n,>}")#text(" is nonzero can be controlled by using one minus the probability that ")#mi("S_{n,>}")#text(" is zero. Is this feasible?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685195")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2024")])]

#text("You can do better by choosing the truncation parameter to be a large multiple of ")#mi("n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685212")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2024")])]

#text("Dear professor Tao:")

#text("Can you provide some explanation on why the second display of Lemma 22 follows as it does?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("By definition of ")#mi("n_{j,\\delta}")#text(", one has ")#mi("(1+2\\delta) n_{j,\\delta} \\geq n_{j+1,\\delta}")#text(" and ")#mi("\\frac{1}{1+2\\delta} n_{j+1,\\delta} \\leq n_{j,\\delta}")#text(" for ")#mi("n")#text(" (and hence ")#mi("j")#text(") large enough.")

#text("More generally, you may find ")#link("https://mathoverflow.net/a/455862/766")[#text("my advice here")]#text(" on how to locate justifications for a step in a given text to be helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2024")])]

#text("Dear professor Tao:")

#text("Your valuable advice on step justifications helps a lot. By Principle 2 and 3, the inequality holds since for sufficiently large ")#mi("n")#text(" we basically identify the floor of ")#mi("(1 + \\delta)^j")#text(" with the argument ")#mi("(1 + \\delta)^j")#text(", and the factor 2 serves more as a safety margin here, am I on the right path?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2024")])]

#text("Dear professor Tao:")

#text("Two questions on your remark following Lemma 22:")

#enum(start: 1, 
[#text("“An inspection of the above argument shows that we only need to verify the hypothesis for a countable sequence of ")#mi("\\delta")#text("“. I wonder why do we need this extra step of verification for the Lemma to be applied?")],
[#text("“… we see that the hypothesis of joint independence of the ")#mi("X_n")#text(" can be relaxed to pairwise independence.” Isn’t the joint independence hypothesis being used to derive (6) in calculating the bound for the mean and variance of the truncated average?")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685234")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2024")])]

#text("1. The countable intersection of events that occur almost surely, will continue to hold almost surely; but this is not necessarily the case when there are an uncountable number of events to be intersected. This is why it is necessary to place ")#mi("\\delta")#text(" inside a countable set.")

#text("2. The mean and variance of the truncated average only requires pairwise independence to calculate; joint independence is overkill. (In general, k^th moments can be calculated assuming k-wise independence.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2024")])]

#text("Dear professor Tao:")

#text("In part 2 of Exercise 23, denoting the empirical CDF and the CDF by ")#mi("F_n(t)")#text(" and ")#mi("F(t)")#text(" respectively, is the hint suggesting one shows that ")#tao-math("\\left|f_m(F_n(t)) - f_m(F(t))\\right| = O(1/m)", block: false)#text(" uniformly in ")#mi("t")#text(" almost surely? And how should one uses part 1 to achieve this uniform bound?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2024")])]

#text("By construction, one has ")#tao-math("\\left|F_n(t) - F(t)\\right| \\leq 2/m + \\left|f_m(F_n(t)) - f_m(F(t))\\right|", block: false)#text(", so if the distance between the discretized version is close in a uniform way almost surely, then so is the original quantity. May I ask if this is what is being hinted at and how should one get the desired uniformity on the parameter ")#mi("t")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("Dear professor Tao:")

#text("The proof on Wiki of the Glivenko-Cantelli theorem relies on a finite partition of ")#mi("{\\bf R}")#text(" into ")#mi("m")#text(" intervals such that ")#mi("F(t_j) - F(t_{j-1}) = 1/m")#text(". As the function ")#mi("f_m")#text(" in the hint is also piecewise constant on ")#mi("m")#text(" partitions of the unit interval such that ")#mi("f_m(j/m) - f_m(j-1/m) = 1/m")#text(", how should one get uniformity in ")#mi("t")#text(" by sending $n$ to infinity?")

#emph[#text("[First hold ")#mi("m")#text(" fixed while sending ")#mi("n \\to \\infty")#text(", to get uniformity in ")#mi("t")#text(" for the ")#mi("f_m")#text("-approximate version of the problem. Once one has that, the usual analysis arguments (splitting an epsilon into say three smaller epsilons, etc.) will then give uniformity in ")#mi("t")#text(" for the original problem. The argument on Wikipedia also works. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2024")])]

#text("Maybe a side note, ")#mi("m")#text(" needs to be large enough that ")#mi("\\frac1m<\\epsilon")#text(" for the analysis argument ")#strong[#text("starts")]#text(" ")#emph[#text("kicking")]#text(" ")#emph[#text("in")]#text(", and then ")#mi("m")#text(" also goes to infinity to fulfill the conclusion of ")#emph[#text("a.s.")]#text(" convergence.")

#text("T.Nguyen")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685303")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("Dear professor Tao:")

#text("Thank you for replying. To clarify, for Exercise 23, ")#mi("f_m")#text(" induced a partition of ")#mi("{bf R}")#text(" into ")#mi("m")#text(" intervals, by considering ")#mi("F^{-1}")#text(" of ")#mi("[j-1/m, j/m]")#text(". This is how we get uniformity in ")#mi("t")#text(" for the ")#mi("f_m")#text("-approximate version of the problem. Is this understanding correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2024")])]

#text("Dear professor Tao: In Exercise 29 (kronecker lemma), is the summation by parts formula assumed to be known and one is supposed to directly apply it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685388")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2024")])]

#text("Dear professor Tao:")

#text("The summation by parts formula in “Analysis 2” also gives the ")#mi("n")#text("th partial sum of ")#mi("b_i Y_i")#text(" to be the sum from ")#mi("i = 1")#text(" to ")#mi("i = n")#text(" of ")#mi("T_i(b_i - b_{i+1})")#text(", plus ")#mi("b_nT_n")#text(", whereas the index should really ranges from ")#mi("0")#text(" to ")#mi("n-1")#text(" instead, according to the same formula of your complex analysis note, is there a miscalculation here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2024")])]

#text("Dear professor Tao:")

#text("I think I get it now, apologize for the initial confusion.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2024")])]

#text("Dear professor Tao:")

#text("Since this set of notes do not focus on uniform integrability, are we supposed to prove Exercise 31 without invoking the result of uniformly integrable convergence in measure (e.g. Theorem 1.5.13 in your measure theory textbook)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2024")])]

#text("My understanding is that")#strong[#text(" ")]#text("the conclusion can be reached by using convergence for random variables with bounded moment, I am not sure if this is correct.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685414")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("Dear professor Tao:")

#text("In Exercise 32 if ")#mi("X = 0")#text(" almost surely then ")#mi("S_n/a_n = 0")#text(" almost surely for any scaling sequence ")#mi("a_n")#text(", and consequently ")#mi("S_n/a_n")#text(" won’t converge to 1 in probability. May I ask if there is a misinterpretation of your condition here?")

#emph[#text("[Exercise updated to exclude this degenerate case. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2024")])]

#text("For this Exercise (Exercise 32), may I ask if one should use the weak law of large numbers for triangular arrays?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685438")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("Dear professor Tao:")

#text("Thank you for the clarification. To show relative stability of the sequence ")#mi("S_n")#text(" in Exercise 32 when the underlying variable is not integrable, is it desirable to imitate the analysis of the Saint Petersburg paradox, and if so can you hint a little further on how one should choose the appropriate truncation parameter ")#mi("M")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2024")])]

#text("Dear professor Tao:")

#text("More specifically, regarding Exercise 32, my main obstacle comes from showing the existence of the truncation parameter ")#mi("M(n) = b_n")#text(" satisfying ")#mi("b_n = o(n \\mu^2(b_n))")#text(", where ")#mi("\\mu(b_n)")#text(" is the truncated expectation at ")#mi("b_n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685447")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2024")])]

#text("If the expectation is infinite, setting ")#mi("b_n = n")#text(" works. If the expectation is finite, the usual law of large numbers applies instead.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685450")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2024")])]

#text("Dear professor Tao:")

#text("Thank you so much for the feedback. In the non-integrable setting, if one sets ")#mi("b_n = n")#text(" and ")#mi("a_n = n mu(n)")#text(", then the zeroth moment method yields a term of ")#mi("n {bf P}(X > n)")#text(" on the right, which we only know to be bounded by the weak ")#mi("L^1")#text(" property, may I ask if there is a better way to control the tail probability?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("Dear professor Tao:")

#text("After pondering on your latest hint on Exercise 32, it looks like one can combine the Glivenko-Cantelli theorem with the weak $L^1$ property to achieve a better control. Is this correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("Dear professor Tao:")

#text("Just a small typo, in Exercise 34, ")#mi("S_i")#text(" should be the partial sum of the first ")#mi("i")#text("th terms.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2024")])]

#text("Prof.Tao")#linebreak()#text("why isn’t (8) obvious? we can assume ")#mi("X_i geq 0")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-685717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2024")])]

#text("In this result, the ")#mi("X_i")#text(" are assumed to have mean zero, so one cannot reduce to the non-negative case without destroying the mean zero condition (which is used elsewhere in the argument).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26080dd9f403661f19b69f700d72f47f2a8940c82688f86b617caeffc0e65459-9ac191b8cf60391c8a191e9cf45cc670cf6de3c7eaf965cb8d5a8459853b1a36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Rodríguez")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-686815")[#strong[#text("Luis Rodríguez")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2024")])]

#text("Dear prof. Tao")

#text("In this equivalence ")#mi("{X_n}")#text(" converges almost surely to ")#mi("{X}")#text(" if and only if, for every radius ")#mi("{\\varepsilon > 0}")#text(", one has ")#mi("{{\\bf P}( \\bigvee_{n \\geq N} (d(X_n,X)>\\varepsilon) ) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(". Could you clarify the notation of the ")#mi("\\bigvee")#text(" symbol for me?")

#emph[#text("[This is ")#link("https://en.wikipedia.org/wiki/Logical_disjunction")[#text("disjunction")]#text(" (“or”) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-689537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2025")])]

#text("Dr Tao,")

#text("A small typo: “takes taking values” should be “taking values”.")

#emph[#text("[Corrected, thanks – T.]")]

#text("I have seen a lot of cases where we assume that random variables being “iid”, say LLN, CLT or even definition of a sample. But I would like to ask: Why is “iid” important in probability? In other words, what makes “iid” special and why do probabilists care about this special case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-689544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2026")])]

#text("It’s basically a ")#link("https://en.wikipedia.org/wiki/Toy_model")[#text("toy model")]#text(" – very well studied and understood, with some convenient symmetries that allow the main phenomena (such as concentration of measure or universality) to be seen in a transparent fashion. A lot of followup work in probability though is devoted to generalizing beyond this toy case, to consider more coupled or more heteregenous processes of random variables.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-689551")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Thanks for the reply. But by “convient symmetries” you mean exchangeability or other things?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-691582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2026")])]

#text("Dear Prof. Tao,")

#text("Forgive me for asking a dumb question. When I saw that variances in the post all take the form of “divided by n,” I wondered why the notion of ")#emph[#text("sample variance")]#text(" is divided by n-1 instead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-691585")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2026")])]

#text("This is ")#link("https://en.wikipedia.org/wiki/Bessel%27s_correction")[#text("Bessel’s correction")]#text(".")

#text("Incidentally, these sorts of questions can be easily answered by modern AI tools.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-691589")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Thanks for the wiki link. I asked about AI but I’m satisfied with the answers they gave: Why n-1? Why not -2 ? Or minus 6,345 % ? I’m still confused by the explanation of the n-1 :-(.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-691594")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("I am ")#link("https://chatgpt.com/share/696e6efa-25e8-800e-8a44-af5aa50dbeb5")[#text("outsourcing this question to an AI")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2026")])]

#text("Dr Tao,")

#text("In this note, it seems that you use the method of normalisation very often, such as normalise the mean μ to equal 0 and so forth. I wonder why would you choose normalisation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2026")])]

#text("See Trick 19 of ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("this blog post")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692155")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2026")])]

#text("Dear Dr Tao,")

#text("The law of large numbers requires the assumption of independence. So in real life, if we observe the law of large numbers at work, can we infer that the underlying events are also independent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692158")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2026")])]

#text("I am ")#link("https://claude.ai/share/2ebad11b-a729-4cb7-ae24-ba83b87b4910")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2026")])]

#text("Dear Prof. Tao,")

#text("If X_n converges in probability, then there must exist a subsequence of X_n that converges almost surely. Why does the act of taking a subsequence itself allow strengthening from controlling a single random variable to controlling the entire ")#emph[#text("tail")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2026")])]

#text("This is for the same reason that the operation of passing to a subsequence can accelerate the decay of a sequence ")#mi("x_n")#text(" going to zero to such an extent that it becomes summable. (Indeed, by taking a sufficiently sparse subsequence, one can make the decay faster than, say, exponential, if desired.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2026")])]

#text("Is Borel-Cantelli lemma a more powerful technique than the first principle when proving almost sure convergence?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2026")])]

#text("Dr Tao,")

#emph[#text("The joint independence of the X_1 ,…, X_n reflects the “Markovian” or “memoryless” nature of a certain process relating to the coupon collector problem, and can be easily established once one has understood the concept of conditional expectation, but the further exploration of these concepts will have to be deferred to the course after this one (which I will not be teaching or writing notes for).")]

#text("Since you would not be writing new notes, could you provide some references of “Markovian” or “memoryless” nature for further studies?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-692662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2026")])]

#text("I am ")#link("https://claude.ai/share/d45be713-1443-4325-8563-881d3c6a4d62")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693153")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("It seems that in this set of notes, the second Borel-Cantelli lemma only appears once, namely in the proof of the infinite monkey theorem. Is the second Borel-Cantelli lemma less practical than the first Borel-Cantelli lemma in practice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2026")])]

#text("It depends on whether one is working with jointly independent random variables, or with more general families of variables. The second Borel-Cantelli lemma gives a strong claim in the former case, but says nothing in the general case. The first lemma is applicable in general, but does not always give the strongest results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693212")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2026")])]

#text("Dear Prof. Tao,")

#text("I was struck by the high-dimensional geometric intuition conveyed in Proposition 6, because at first glance, these seem like two separate disciplines. Could you elaborate on why high-dimensional geometry is well-suited to being viewed from a probabilistic perspective?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2026")])]

#text("The short answer is that many basic quantities in high-dimensional geometry, starting from the Pythagorean theorem ")#tao-math("\\left\\|x-y\\right\\|^2 = (x_1-y_1)^2 + \\dots + (x_d - y_d)^2", block: false)#text(", involve the sums of many components, which often behave in some independent manner if sampled from some common distributions such as the uniform measure on a box, or from a Gaussian measure. As such, probability theory tools such as the law of large numbers or the central limit theorem are very natural to use.")

#text("See also the probabilistic method in combinatorics, which one can think of as using probability theory to study discrete high-dimensional objects, such as the Hamming cube.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693480")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2026")])]

#text("Prof. Tao:")

#text("In Proposition 5, is the proof approach ")#emph[#text("the moment method")]#text("? Why is it appropriate to draw on the proof method of the weak law of large numbers when proving uniform convergence of Bernstein polynomial?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693491")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Or am I mistaken, and this proof is not the moment method?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-693604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2026")])]

#text("In harmonic analysis, the technique for proving almost everywhere convergence is to establish a weak-type estimate for the corresponding maximal function. If we adopt the perspective of harmonic analysis, does this correspond to the approach in the third section of the post, where the Kolmogorov maximal inequality is used to prove the SLLN and related results?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-2/#comment-694165")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2026")])]

#text("In the Infinite Monkey Theorem, is the assumption of infinity necessary, namely can we replace “infinite” with “finite”? Frankly, I often see this theorem used as a pop culture meme—But where in probability theory could one expect it to show up and to be applied?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-460863")[#strong[#text("Philip")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("Anyone working the exercises out? I have been rusty on the epsilon-delta proofs, but it seems that the inequalities can be found from the required conditions of the theorems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-460872")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("I think you want ")#mi("\\sqrt{n}")#text(" in the numerator in your discussion of the CLT under (2). In Exercise 18, I think you want that the probability goes to 1 instead of 0. Also, there is no mention of the limit X in your characterization of a.s. convergence under Definition 1. It’s too bad that you won’t be teaching 275B.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-460876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("it would be interesting to show some pseudo random properties (like CLT ) for lacunary trigonometric series.")

#emph[#text("[I plan to have some exercises on this in the next set of notes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760f3e43c9644599ba483b56ed3cbd2e1d35e869bc4d0a4a5272fad094b2ce71-2d6b600f1be10c8a97bd05b8b4911d625d087698e103b895caa5b17c32034d95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-460985")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2015")])]

#text("Dear Prof. Tao,")

#text("I have a question on exercise 12: I tried to work out what the weakest condition on the moments of the ")#mi("X_{i,n}")#text(" for the strong law of large numbers to hold is. I can show that if ")#tao-math("\\sup_{i,n}\\mathbb{E}[\\left|X_{i,n}\\right|^{2+\\delta}]<\\infty", block: false)#text(" for an arbitrary ")#mi("\\delta > 0")#text(" is sufficient, and now I am wondering whether one can even get further down to second moments being sufficient for the strong law to hold.")

#text("Best regards,")

#text("Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-460986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2015")])]

#text("See Exercise 24 for an example showing that one cannot go much below the second moment; it is likely one can adapt this construction to find the optimal threshold. (There are probability textbooks that carefully identify the minimal hypotheses required for various key theorems like the law of large numbers; I’ll try to track down such a reference for this and future inquiries of this nature.)")

#text("[EDIT: it seems that textbooks from the Russian school, such as V. V. Petrov, Sums of Independent Random Variables, Springer Ergebnisse Vol 82, V. V. Petrov, Limit Theorems of Probability Theory, Oxford Studies in Probability Vol 4, and B. V. Gnedenko and A. N. Kolmogorov, Limit Distributions for Sums of Independent Random Variables, Addison-Wesley, would be good resources for this sort of thing.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2015")])]

#text("Some people asked in a forum the differences between")#linebreak()#text(" the weak LLN and strong LLN. This may include different conditions")#linebreak()#text(" and the examples in which the weak LLN holds but the strong LLN does not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461361")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] of an absolutely integrable real scalar random variable , and form the partial sums . As we saw in the last set of notes, the law of large numbers ensures that the empirical averages converge (both in probability and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a6be96d0b33334c6a31c2b3bf2f20ef8ce2f7d97e0c701463b95bf4270e9e25-ce514ac0ea720ed87fa8c8930f4a34ce09507f5e810209a52d960dbea35d2d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venky")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461403")[#strong[#text("Venky")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2015")])]

#text("A small question: In the proof of the LLN (before Prop 5), should the denominator in the right hand side of the Markov inequality have epsilon^4 instead of epsilon? Thanks again for great notes. I really began to appreciate the importance of tail events.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2015")])]

#text("In Exercise 14(i), is the “almost surely” actually necessary? It seems that the trace expression is surely 1 by just expanding what ")#mi("A_{n}A_{n}^{\\ast}")#text(" is.")

#emph[#text("[Fair point – I’ve adjusted the exercise accordingly. For other ensembles, such as gaussian matrices, one only has convergence in probability and in almost sure senses, rather than deterministic equality, but indeed in this simple sign matrix model there is in fact no random fluctuation. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("Dear Terence Tao,")

#text("For the second term in the upper bound in Equation ")#mi("(6)")#text(", where does the ")#mi("\\frac{2}{\\varepsilon}")#text(" term come from? It seems that we are still using the inequality below Equation ")#mi("(5)")#text(". So maybe we are upper bounding ")#mi("\\textbf{P}(S_{n,>} \\neq 0)")#text(" by ")#tao-math("\\textbf{P}(n 1_{\\left|X\\right|>n} > \\frac{\\varepsilon}{2})", block: false)#text(", for large ")#mi("n")#text(", which is by Markov inequality upper bounded by ")#tao-math("\\frac{2}{\\varepsilon} \\textbf{E} n 1_{\\left|X\\right|>n}", block: false)#text(". But I am not sure even if for large ")#mi("n")#text(", we can relate the events ")#mi("\\{S_{n,>} \\neq 0\\}")#text(" and ")#tao-math("\\{n 1_{\\left|X\\right|>n} > \\frac{\\varepsilon}{2}\\}", block: false)#text(".")

#text("Thanks very much.")

#emph[#text("[Oops, this was a typo arising from a previous version of the argument, now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa640d4db917d4c5835f675b1fb2f8e99c6921ec6c00f11f1d482b9fc347a054-6ef36ab87c3a0d747b86f748c0cd5c1fdc2f8908a683e67ffcccfa2b0666608b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dillon")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461611")[#strong[#text("Dillon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2015")])]

#text("In exercise 17, should it be")

#mi("\\displaystyle \\Omega := \\{ \\vec x \\in A^n : \\exp(-(1-\\varepsilon) n \\mathbf{H}(X)) \\geq \\mu_{\\vec X}(\\{\\vec x\\}) \\geq \\exp(-(1+\\varepsilon) n \\mathbf{H}(X)) \\}")

#text("instead of")

#mi("\\displaystyle \\Omega := \\{ \\vec x \\in A^n : \\exp((1-\\varepsilon) n \\mathbf{H}(X))\\leq \\mu_{\\vec X}(\\{\\vec x\\}) \\leq \\exp((1+\\varepsilon) n \\mathbf{H}(X)) \\}")

#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2015")])]

#text("Is there a sign error in the second inequality in part (ii) of Exercise 17? In particular should it really be ")#mi("-(1 + 2\\varepsilon)")#text(" and ")#mi("-(1 - 2\\varepsilon)")#text(" (should the negative signs be there)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("I think the ")#mi("\\leq")#text(" in the second centered inequality of the proof of Lemma 22 should be reversed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461945")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#text("Dear Terry,")

#text("In the proof of the weak law of large numbers without finite moment assumptions, could you say a bit more about how we are using dominated convergence to get")#linebreak()#text(" ")#mi("{\\mu_{\\leq n} \\rightarrow \\mu}")#linebreak()#text(" and also")#linebreak()#text(" ")#tao-math("{{\\bf E} n 1_{\\left|X\\right|>n} \\rightarrow 0}", block: false)#text("? It is not obvious to me what the dominating functions here are.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-461947")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2015")])]

#tao-math("n 1_{\\left|X\\right|>n}", block: false)#text(" and ")#tao-math("X 1_{\\left|X\\right| \\leq n}", block: false)#text(" are dominated in magnitude by the absolutely integrable random variable ")#tao-math("\\left|X\\right|", block: false)#text(". (Here it is convenient to use the probabilistic version of the DCT rather than the measure theoretic version, i.e. Theorem 23 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 5: Variants of the central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462100")[#strong[#text("275A, Notes 5: Variants of the central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("[…] with Exercise 17 of Notes 3). One can check that is decreasing for , and so one can compute […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TM")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462473")[#strong[#text("TM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("Looks like there are some typos in the proof of the polynomial approximation theorem (estimates for ")#tao-math("\\left|S_{n}/n-p\\right|", block: false)#text(" and ")#mi("f(S_{n}/n)-f(p)")#text(" and $\\epsilon$, $\\delta$ parameters getting mixed up; in particular, the first and second displayed equations where in the first one ")#mi("\\epsilon")#text(" should be ")#mi("\\delta")#text(" and the second one doesn’t look like it should be there at all (the Markov inequality estimate seems wrong since the variance of ")#mi("f(S_{n}/n) - f(p)")#text(" is not ")#mi("p(1-p)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TM")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462474")[#strong[#text("TM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("Update: Sorry for the hasty comment above (couldn’t edit).")

#text("I believe I understand the point of the second displayed equation now – the mix-up with ")#mi("\\epsilon")#text(" and ")#mi("\\delta")#text(" along with the omission of an intermediate step threw me off the first couple times I went through the proof.")

#text("I reckon this was the intended statement (somewhat more explicitly):")#linebreak()#text(" ")#tao-math("P(\\left|f(S_{n}/n)-f(p)\\right|\\geq\\epsilon)\\leq P(\\left|S_{n}/n-p\\right|\\geq\\delta)\\leq \\frac{p(1-p)}{n\\delta^{2}}\\leq (4n\\delta^{2})^{-1}", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462639")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("In Proposition 5:")#linebreak()#text(" \\displaystyle f_n(x) := \\sum_{i=0}^n \\binom{n}{i} x^i (1-x)^{n-i} f(\\frac{x}{n})")#linebreak()#text(" should be:")#linebreak()#text(" \\displaystyle f_n(x) := \\sum_{i=0}^n \\binom{n}{i} x^i (1-x)^{n-i} f(\\frac{i}{n})")#linebreak()#text(" (AFAIK AIAM=…and it isn’t much).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("In the coupon collector exposition: ‘This implies in particular that…’ and then {T_N/N \\log N} should be {T_N/N \\log N \\to 1} ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("In truncation section, law large numbers, an equation:")

#tao-math("\\displaystyle {\\bf Var}(X 1_{\\left|X\\right| \\leq n}) \\leq {\\bf E} (X 1_{\\left|X\\right| \\leq n})^2", block: false)

#tao-math("\\displaystyle = {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq n}.", block: false)

#text("might have \\leq and = transposed i.e.")

#tao-math("\\displaystyle {\\bf Var}(X 1_{\\left|X\\right| \\leq n}) = {\\bf E} (X 1_{\\left|X\\right| \\leq n})^2", block: false)

#tao-math("\\displaystyle \\leq {\\bf E} \\left|X\\right|^2 1_{\\left|X\\right| \\leq n}.", block: false)

#emph[#text("[Actually, I believe it is correct as stated – note that ")#tao-math("X 1_{\\left|X\\right| \\leq n}", block: false)#text(" need not have mean zero. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("In St. Petersburg expectation formula:")#linebreak()#text(" \\displaystyle {\\bf E} X = \\sum_{i=0}^\\infty 2^i \\times 2^{-i} = \\sum_{i=0}^\\infty 1 = \\infty.")#linebreak()#text(" shouldn’t the sum begin at i=1?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("In St. Petersburg truncated variance equation:")#linebreak()#text(" \\displaystyle {\\bf Var}(X 1_{X \\leq M}) \\leq {\\bf E} (X 1_{X \\leq M})^2")#linebreak()#text(" \\displaystyle = \\sum_{i=1}^m 2^{2i} 2^i")#linebreak()#text(" \\displaystyle \\leq 2^{m+1}")#linebreak()#text(" there is a missing minus, 2^i should be 2^{-i}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-462678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("Hi Terry, theres a small typo in Proposition 5 (Approx by Bernstein polys).")#linebreak()#text(" The last term should be f(i/n) rather than f(x/n).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-464690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2016")])]

#text("“…..thus {T_{i,N}} is the first non-negative integer such that {\\{Y_1,\\dots,Y_{T_i}\\}} has cardinality {i}….”")

#text("Should the Y_T_j have an additional index N?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-464696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2016")])]

#text("Exercise 15, the set A in the first two lines should be P?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-465202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2016")])]

#text("The last point wise estimate in the (general) law of large numbers still has an expectation.")

#tao-math("\\displaystyle \\sum_{j=1}^\\infty {\\bf E} n_{j,\\delta} 1_{\\left|X\\right|>n_{j,\\delta}} \\leq C_\\varepsilon \\left|X\\right|", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760f3e43c9644599ba483b56ed3cbd2e1d35e869bc4d0a4a5272fad094b2ce71-2d6b600f1be10c8a97bd05b8b4911d625d087698e103b895caa5b17c32034d95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cosine30")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-468666")[#strong[#text("cosine30")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("Dear Prof. Tao,")

#text("I have a question on exercise 24: I tried to first expand the probability ")#mi("\\mathbb{P}[\\sum_{i=1}^n X_{in}\\geq nA]=\\sum_{\\ell=nA}^{\\infty}\\mathbb{P}[\\sum_{i=1}^n X_{in}= \\ell]")#text(" and to then get a lower bound on the individual summands of the form ")#mi("\\frac{c(A)}{\\ell^2}")#text(". I tried to do this by expanding further ")#mi("\\mathbb{P}[\\sum_{i=1}^n X_{in}= \\ell]=\\sum_{\\ell_1,\\ldots,\\ell_n:\\sum_i\\ell_i=\\ell}\\frac{1}{\\zeta(3)^n\\ell_1^3\\cdots\\ell_n^3}")#text(", and then I subdivided the sum further, but I am getting nowhere. To make my question more concrete: Is this the way to go, or is there some standard inequality that is applicable here (lower bounds on probabilities seem to be much rarer than upper bounds though)?")

#text("If your time permits it, I would be grateful for a short answer.")

#text("Best regards,")

#text("Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-468673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("Note that the question is not asking for an exact value for the tail probability ")#mi("{\\bf P}[ \\sum_{i=1}^n X_{in} \\geq nA ]")#text(", but only a lower bound. So one does not need to perform all of these exact computations. Instead, one only needs to think about some simpler events that are contained in the given event. I suggest starting with the events ")#mi("X_{in} \\geq nA")#text(" for ")#mi("i=1,\\dots,n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-685352")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2024")])]

#text("Dear professor Tao:")

#text("Following your hint on Exercise 24, one can use an integral to approximate from below and get ")#mi("{\\bf P}(X_{i,n} > nA) \\geq \\frac{1}{2 \\zeta(3) (nA)^2}")#text(", which is still not good enough for Borel-Cantelli, can you provide a little more hint on how to derive the bound in the hint for the row average?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-685359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("It occurs to me that we can use Exercise 3.8.2(a) in your “analysis 2”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-685361")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")])]

#text("As the binomial approximation is not given explicitly in these set of notes, I’m not sure what can we use to get a desired lower bound here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-685425")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("Now that you have bounded the individual events ")#mi("X_{i,n} > nA")#text(" for each ")#mi("i")#text(", use independence to lower bound the union event ")#mi("\\exists i, X_{i,n} > nA")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-468674")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2016")])]

#text("The more I look at your articles the more they look the same. Don’t you use 4-th moment estimates in the Wigner Semicircle Theorem (for all random variables) as well as certain special cases of Szemerédi’s Theorem (k=3,4 and weak-mixing)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-474295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("In the section of moment methods, if one assumes only finite third moment instead of four, then can one still finish the proof using only what you have for the finite second moment? ")#emph[#text("[Not easily – in particular, not without something like a truncation argument – T.]")]

#text("In the section of truncation, would you elaborate the following step?")

#emph[#text("By the triangle inequality, we can split")]

#tao-math("\\displaystyle {\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq {\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon ) + {\\bf P}( S_{n,>} \\neq 0 ).", block: false)

#text("I only get")

#tao-math("\\displaystyle {\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq {\\bf P}( \\left|S_{n,\\leq}/n - \\mu\\right| +\\left|S_{n,>}-\\mu\\right| \\geq \\varepsilon )", block: false)

#emph[#text("[You should have ")#tao-math("\\left|S_{n,>}\\right|", block: false)#text(" instead of ")#tao-math("\\left|S_{n,>}-\\mu\\right|", block: false)#text(". Then, observe that if ")#tao-math("\\left|S_{n,\\leq}/n - \\mu\\right| +\\left|S_{n,>}\\right| \\geq \\varepsilon", block: false)#text(", then either ")#mi("S_{n,>}")#text(" is non-zero, or ")#mi("S_{n,>}")#text(" is zero and ")#tao-math("\\left|S_{n,\\leq}/n - \\mu\\right| \\geq \\varepsilon", block: false)#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-474298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("Do you mean with only the finite first moment assumption (Theorem 4) or anything else in “Now we turn to establishing the strong law of large numbers in full generality.”?")

#emph[#text("[Yes – T.]")]

#text("In the argument in the section of truncation, I still don’t find where the assumption of independence is used in the proof of the WLLN and SLLN after several times of reading. Am I missing something? Would you please elaborate?")

#emph[#text("[Independence was used to compute the variance of ")#mi("S_{n,\\leq}/n")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-474299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2016")])]

#text("If one assumes the finite fourth moment, can one prove the SLLN without the Borel-Cantelli lemma but instead calculate")

#mi("\\displaystyle E\\sum_n(S_n/n)^4<\\infty?")

#emph[#text("[Yes – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-474314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2016")])]

#text("When one uses the approach of Borel-Cantelli in the case of finite fourth moment, one gets")#linebreak()#text(" ")#tao-math("\\displaystyle P(\\left|S_n/n-\\mu\\right|>\\epsilon)=0", block: false)#linebreak()#text(" for all ")#mi("n")#text(", which is ")#emph[#text("more")]#text(" than what is needed for giving almost sure convergence of ")#mi("S_n/n")#text(". Would you say that this is the “defect” that Etemadi remedies in his argument to prove the SLLN with assuming only finite first moment when one still wishes to use Borel-Cantelli?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-474341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Oops, one only gets")

#tao-math("\\displaystyle P(\\left|S_n/n-\\mu\\right|>\\epsilon)=0 \\quad\\text{i.o.}", block: false)

#text("not for all ")#mi("n")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-478160")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] of an absolutely integrable real scalar random variable , and form the partial sums . As we saw in the last set of notes, the law of large numbers ensures that the empirical averages converge (both in probability and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-510611")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2019")])]

#text("Hello Prof. Tao, I have a question regard the remarks just above Exercise 18. I do not quite see the connection between the counter example you provided leads to the conclusion that it rules out an estimate with decay rate in n. I can see that for the counter example, the moment proof where we applied Chebyshev inequality won’t hold, as the expectation would be constant 1 that does not decay to zero as n grows large. Do you mind elaborate a little bit more on the connection here? Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-510612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2019")])]

#text("As stated in the post, the counterexample shows that there does not exist a bound of the form ")#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon ) \\leq c_{\\varepsilon,M}(n)", block: false)#text(" uniform for all ")#mi("X")#text(" with ")#tao-math("{\\bf E} \\left|X\\right| \\leq M", block: false)#text(", where ")#mi("c_{\\varepsilon,M}(n) \\to 0")#text(" as ")#mi("n \\to \\infty")#text(". This is because (setting for instance ")#mi("\\varepsilon = 1/2")#text(" and ")#mi("M = 1")#text("), the counterexample obeys ")#tao-math("{\\bf E} \\left|X\\right| \\leq M", block: false)#text(", but the probability ")#tao-math("{\\bf P}( \\left|S_n/n - \\mu\\right| \\geq \\varepsilon )", block: false)#text(" converges to ")#mi("1/e")#text(" rather than 0 as ")#mi("n \\to\\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10748589181ac63dfc07bcdfe05517a711d0b94164cbeccb93bd167684b84add-9fc6b069f1ce1871ec9c8d992247266f3469d82534d2cc08c3d41bbe7b3db686.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-511885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2019")])]

#text("Hi Prof. Tao. Could you please clarify how you are using the change of variables formula in the proof of proposition 6?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-511903")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2019")])]

#text("See Theorem 32 of ")#link("https://terrytao.wordpress.com/2015/10/03/275a-notes-1-integration-and-expectation/")[#text("Notes 1")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10748589181ac63dfc07bcdfe05517a711d0b94164cbeccb93bd167684b84add-9fc6b069f1ce1871ec9c8d992247266f3469d82534d2cc08c3d41bbe7b3db686.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512019")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2019")])]

#text("I still don’t see how the limits of integration changed to [0,1].")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2019")])]

#text("The distribution of ")#mi("X")#text(" is symmetric around the origin, and ")#mi("X^2")#text(" is an even function of ")#mi("X")#text(", so ")#mi("\\int_{-1}^1 x^2 \\frac{1}{2}\\ dx")#text(" is equal to ")#mi("\\int_0^1 x^2\\ dx")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10748589181ac63dfc07bcdfe05517a711d0b94164cbeccb93bd167684b84add-9fc6b069f1ce1871ec9c8d992247266f3469d82534d2cc08c3d41bbe7b3db686.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512111")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")])]

#text("And the 1/2? Following Theorem 32 I obtain ")#mi("\\mathbb{E}(X_i^2) = \\int_{[-1,1]^n} x_i^2 dx_i")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512138")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")])]

#text("The uniform probability measure on ")#mi("[-1,1]")#text(" is ")#mi("\\frac{1}{2}\\ dx")#text(", not ")#mi("dx")#text(" (the total measure has to equal 1 to be a probability measure). Similarly, the uniform probability measure on ")#mi("[-1,1]^n")#text(" would be ")#mi("2^{-n} \\prod_{i=1}^n dx_i")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512343")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("Hello Professor. Tao, I have question regard the result of Saint Petersburg Paradox, as in your note, we have shown ")#mi("S_n/(n*log(n)")#text(" converges to 1 in probability, and in Exercise 19 we can show it is almost surely unbounded. I see this as another example to show that convergence in probability is a weaker notion than a.s convergence, However I could not convince myself without going through the proof a sequence of a.s unbounded random variable can converge in probability to a finite value. Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2019")])]

#text("I am not sure what the actual question is here, but you can try proving to yourself the opposite claim “A sequence of a.s. unbounded random variables cannot converge in probability to (say) zero” and see where any arguments you have in mind to justify this break down. (One can also concoct an example by modifying the “typewriter sequence”, see Example 4 of ")#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")]#text(" .)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512542")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")])]

#text("Thanks for your reply. I think I have found my source of confusion. I think the statement ")#mi("S_n/(nlog(n)")#text(" a.s unbounded here means the ")#mi("limsup S_n/(nlog(n)")#text(" is a.s unbounded as opposed to every term in the sequence is a.s unbounded. As if the later is the case (for simplicity I will denote my random variables as ")#mi("X_n")#text("). By definition of a.s unbounded, ")#tao-math("P(\\left|X_n\\right|\\geq M)=1", block: false)#text(" would be true for all M and n, which I can use to conclude that ")#mi("X_n")#text(" cannot converge to any finite value (more direct one is zero). Using the typer writer example, then one I can think about is some kind of moving train as (n,n+1/n) with positive probability in the interval and zero outside. Is my understanding here correct here? Thanks again,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-512543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2019")])]

#text("Yes, in these notes “")#mi("S_n/n\\log n")#text(" is a.s. unbounded” is short for “The sequence ")#mi("(S_n/n \\log n)_{n=1}^\\infty")#text(" is a.s. unbounded”, or equivalently that ")#tao-math("\\sup_n \\left|S_n/n\\log n\\right|", block: false)#text(" is almost surely infinite. One can also replace the supremum by a limit superior if desired. (Generally speaking, the terms “bounded” and “unbounded” only apply to functions and sequences, not to scalars, where one instead uses the distinction between “finite” and “infinite”.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641797")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("Prof. Tao, in Definition 1 of convergence in probability you write it for “separable metric spaces”.")#linebreak()#text(" Is there any particular reason why studying convergence in probability is more meaningful when the underlying metric space (where the random variables take values) is separable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("It is the same as studying convergence of sequences in analysis. I don’t think there is anything special about probability spaces. A separable space is much more easier to work with than non-separable spaces. If a space is not separable, convergence property usually fails.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641801")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("Thanks!")#linebreak()#text(" Could you please tell about some particular examples where speaking about convergence in non-separable spaces can lead to counter-intuitive or misleading directions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("Broadly speaking, by working in “countable” settings, one can safely ignore null events, since the countable union of null events is still null. Once one enters the “uncountable” world, though, it can require much more care to be able to view null events as negligible.")

#text("In my experience, one can often remove “countability” hypotheses such as separability (or being a ")#link("https://en.wikipedia.org/wiki/Polish_space")[#text("Polish space")]#text(", a ")#link("https://en.wikipedia.org/wiki/Standard_Borel_space")[#text("standard Borel space")]#text(", or ")#link("https://en.wikipedia.org/wiki/Standard_probability_space")[#text("a standard probability space")]#text(") from basic tools in analysis and probability as long as everything is defined carefully (for instance, it can be convenient to replace the Borel sigma-algebra by the slightly smaller Baire sigma-algebra), but imposing such hypotheses allows one to ignore these sorts of technical subtleties (and also gains access to some useful technical tools, such as disintegration and measurable selection lemmas). For a typical instance where such hypotheses can be dropped if one works carefully enough, see ")#link("https://mathoverflow.net/questions/352552/is-the-separability-of-the-space-needed-in-the-proof-of-the-prohorovs-theorem")[#text("https://mathoverflow.net/questions/352552/is-the-separability-of-the-space-needed-in-the-proof-of-the-prohorovs-theorem")]

#text("In the long term, I expect that eventually a fully “uncountable” foundation to analysis and probability will be given, in which countability axioms are rarely needed; but with our current state of literature many of our basic tools are still restricted to the countable setting and so it is most convenient (especially for beginners) to largely restrict the scope of our theory to such countable settings.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641800")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("In Exercise 2 part (ix) Dominated Convergence theorem: we see that one easy way to prove it is to use Urysohn subsequence principle and then use Dominated Convergence Theorem for almost sure convergence to obtain that every subsequence of the sequence ")#mi("( \\mathbf{E} [ X_n ] )")#text(" has a further subsequence converging to ")#mi("\\mathbf{E} [ X ]")#text(" whence (since these are reals) the sequence ")#mi("( \\mathbf{E} [ X_n ] )")#text(" itsef converges to ")#mi("\\mathbf{E} [ X ]")#text(".")

#text("Is there a more direct way to prove this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641803")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("The same reason allows us to prove (vii).")#linebreak()#text(" (I think this is a correct and neat way, but it seems like we are cheating somehow by passing on to a subsequence.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641809")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2022")])]

#text("As a warm up, establish the bounded case of the dominated convergence theorem, in which the dominating variable ")#mi("Y")#text(" is constant. The general case can then be established by truncating ")#mi("Y")#text(" and applying a limiting argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2022")])]

#text("A cute approach is to just change measures, define ")#tao-math("d\\nu := Y \\cdot \\mathbf{1}_{\\left|Y\\right| > 0} d\\mu", block: false)#text(" and apply Egorov’s theorem")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convergence of random variables: part 1 | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-641845")[#strong[#text("Convergence of random variables: part 1 | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2022")])]

#text("[…] reason why we took to be separable is briefly suggested in this comment by Professor Terence Tao. Unless mentioned otherwise, all random variables discussed here will be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" Is part (8) of Exercise 2 a duplicate to Lemma 15 in note 1?")

#emph[#text("[Not quite – convergence in probability does not necessarily imply almost sure convergence – but it is certainly very related. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2024")])]

#text("Also, I think the random variable $Y$ needs to be unsigned in part (9) of the same Exercise.")

#emph[#text("[This is automatic (a.s.) thanks to the condition ")#tao-math("\\left|X_n\\right| \\leq Y", block: false)#text(". -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In Example 1.5.2 of your measure theory textbook, it is stated that the escape to horizontal infinity is a case where we have pointwise convergence almost everywhere (almost surely), but not in measure (in probability). Does this contradict Exercise 2?")

#emph[#text("[No, because that example was on an infinite measure space, whereas in probability theory the measures are finite. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682885")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In the proof of Proposition 5 (approximation by Bernstein polynomials), it should be ")#mi("{S_n/n}")#text(" that takes values in ")#mi("{\\{0, 1/n, \\dots, n/n\\}}")#text(" rather than ")#mi("S_n")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682892")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("Also, in the proof of Proposition 8, the term ")#mi("N^{-(j_1 + \\dots + j_n)}")#text(" should be ")#mi("N^{-(j_1 + \\dots + j_N)}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2024")])]

#text("Regarding Proposition 8, it seems that there’re some other places (apart from the one mentioned above ) where some of the ")#mi("n")#text(" should be ")#mi("N")#text(", and based on the proof, may I ask if ")#mi("T_{i, N}")#text(" should really be defined as the last time one has collected ")#mi("i")#text(" coupons out of ")#mi("N")#text(", rather than the first time?")

#emph[#text("[Typos corrected – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682897")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In my comment above the definition of ")#mi("T_{i, N}")#text(" is correct as it is. Rather I would suggest the following change:")

#text("In order for the event ")#mi("X_1=j_1\\land\\cdots\\land X_N=j_N")#text(" to hold, we must have ")#mi("j_1=1")#text(" and the first coupon ")#mi("Y_{j_1}")#text(" can be arbitrary; then the coupons ")#mi("Y_{j_1+1},\\ldots,Y_{j_1+j_2-1}")#text(" have to be equal to ")#mi("Y_{j_1}")#text(", and ")#mi("Y_{j_1+j_2}")#text(" must be from one of the remaining ")#mi("N-1")#text(" elements of ")#mi("\\{1,\\ldots,N\\}")#text(" not equal to ")#mi("Y_{j_1}")#text("; then ")#mi("Y_{j_1+j_2+1},\\ldots,Y_{j_1+j_2+j_3-1}")#text(" must be from the two-element set ")#mi("\\{Y_{j_1},Y_{j_1+j_2}\\}")#text(", and ")#mi("Y_{j_1+j_2+j_3}")#text(" must be from the remaining ")#mi("N-2")#text(" elements of ")#mi("\\{1,\\ldots,N\\}")#text("; and so on and so forth up to ")#mi("Y_{j_1+\\cdots+j_N}")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682889")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In the proof of proposition 6, shouldn’t the proportion of ")#mi("{[-1,1]^n}")#text(" that lies outside the given annulus be ")#tao-math("{\\bf P}(\\left|\\sqrt{X_1^2+\\dots+X_n^2} - \\sqrt{n/3}\\right| > \\varepsilon \\sqrt{n/3})", block: false)#text(" instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a77951b0ad0e5691eeccddc1ea0cca51f2a5aab4398b0349ba66144825728534-8d7635eab87b5b914267ed04be55cb14fe489b59a3e0fe3411e0a1fe75a52986.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jas, the Physicist")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-682893")[#strong[#text("Jas, the Physicist")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2024")])]

#text("Well if we’re going to improve the AI models then the wikipedia pages for things need to be improved too. There is a section that says “Explain to me like I’m 10 years old” or something like this and I find the AI to be lacking in that way.")

#text("When we got to modes of convergence in Introduction to Measure theory, this is where I got confused. I suppose it is time for me to review “convergence in measure” and compare it to “convergence in probability” just so I can attempt the article.")

#text("Still not sure how I would explain that to a 10 year old.")

#text("Also, I’m still stuck on the uniqueness of Jordan (Lebesgue?) measure we talked about some months ago. I’m sorry it has taken me so long to finish the proof. I got the big picture idea but then I just moved on to something else.")

#text("It’s so hard to focus sometimes.")

#text("It reminds of the notion of Characteristic Property that Professor Lee always talked about in Introduction to Topological Manifolds. I suppose it is a category-theoretic thing, and maybe we can think of the Jordan measure as the image of some quotient, or some sort of embedding or something.")

#text("This all sounds not good to me, maybe I should em-bed myself in my sheets. Clearly I haven’t covered this enough. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684417")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" In the coupon collector problem, applying Chebyshev’s inequality with the given bounds seems to give ")#tao-math("\\displaystyle {\\bf P}( \\left|T_N - N \\log N - O(N)\\right| \\geq \\lambda N ) = O( \\lambda^{-2} )", block: false)#text(", why can we disregard the ")#mi("O(N)")#text(" term in ")#mi("{\\bf E} T_N")#text(" for this estimate?")

#emph[#text("[One can shift ")#mi("\\lambda")#text(" (which can be assumed to be large) by ")#mi("O(1)")#text(" to absorb this error. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2024")])]

#text("I got it now, thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 10 I used the Paley-Zygmund inequality to show that ")#mi("{\\bf P}(S_n > M) \\to 1")#text(" for any ")#mi("M > 0")#text(", but instead of the variance, this approach computes ")#tao-math("{\\bf E}\\left|S_n\\right|^2", block: false)#text(". May I ask your original intent in the hint for asking readers to compute the variance ")#mi("{\\bf Var}(S_n)")#text("?")

#emph[#text("[Computing ")#tao-math("{\\bf E}\\left|S_n\\right|^2", block: false)#text(" is much the same thing as computing ")#tao-math("{\\bf Var}(S_n) = {\\bf E}\\left|S_n\\right|^2 - ({\\bf E} S_n)^2", block: false)#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2024")])]

#text("Dear professor Tao:")#linebreak()#text(" As of (ii) of Exercise 14, it seems that the problem amounts to showing that the quantities ")#mi("\\sum_{i=1}^n {\\bf E}{\\lambda_{i,n}^k}/n^{k+1}")#text(" are bounded uniformly in ")#mi("n")#text(", where the ")#mi("\\lambda_{i,n}")#text("‘s are eigenvalues of the Gramian random matrix ")#mi("B_n = A_nA_n^*")#text(", counting with multiplicity. But then I am not sure how to proceed from here, having attempted to use the Gerschgorin disk theorem.")#linebreak()#text(" Also, as it is also related, can you provide some further hint on (iii) as well?")

#emph[#text("[Compute ")#mi("\\mathrm{tr}(A_n A_n^*)^k")#text(" as a polynomial of the coefficients of ")#mi("A_n")#text(", and avoid using the spectral theorem in part (ii) (it will be needed in part (iii) though). You may work out the first few cases ")#mi("k=1,2,3")#text(" by hand to get a sense of how to proceed -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2024")])]

#text("I understand that your time is precious, thank you so much for replying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2024")])]

#text("Dear professor Tao: Regarding you hint for part (ii) of Exercise 14, are we supposed to show by induction that the expectation of the trace of ")#mi("(A_nA_n^*)^k")#text(" equals ")#mi("2n^{k+1} - n^k")#text(" for any ")#mi("k > 1")#text("? It seems to hold for ")#mi("k = 2, 3")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2024")])]

#text("Dear professor Tao:")

#text("For part (iii) of Exercise 14, I get the bounds")

#tao-math("\\displaystyle {\\left|A_n\\right|_{op} / n^{1/2+\\varepsilon}} \\leq [\\text{tr}(A_nA_n^*)^k]^{\\frac{1}{2k}} / n^{1/2+\\varepsilon}", block: false)#text(" and")

#tao-math("\\displaystyle {\\left|A_n\\right|_{op} / n^{1/2-\\varepsilon}} \\geq [\\text{tr}(A_nA_n^*)^k]^{\\frac{1}{2k}} / n^{\\frac{1}{2k} + \\frac{1}{2} - \\varepsilon}", block: false)#text(".")

#text("Setting ")#mi("k = 1")#text(" in the second inequality gives the almost sure divergence to infinity part, but I can’t immediately see how to show the almost sure convergence to zero part by the first inequality. Am I on the right track?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684580")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("Yes. Now apply Chebyshev’s inequality with a large value of ")#mi("k")#text(" to get a good bound on when ")#tao-math("\\left\\|A_n\\right\\|_{op}/n^{1/2+\\varepsilon}", block: false)#text(" exceeds a small threshold ")#mi("\\delta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2024")])]

#text("Dear professor Tao: Reminded by your latest comment on Exercise 15 , is it necessary to use a concentration inequality like Chebyshev’s inequality for part (iii) of Exercise 14 as well? By induction it seems that ")#mi("{\\bf E}\\text{tr}(A_nA_n^*)^k = 2n^{k+1} - n^k")#text(" for all ")#mi("k \\geq 2")#text(", so if ")#mi("E_n")#text(" is the event that the RHS of the first inequality above exceeds ")#mi("\\delta")#text(", then by Markov’s inequality one gets the bound ")#mi("{\\bf P}(E_n) \\leq \\frac{2n - 1}{\\delta n^{2 \\varepsilon k}}")#text(", valid for all ")#mi("k \\geq 2")#text(", one can then choose a large ")#mi("k")#text(" depending on ")#mi("\\varepsilon")#text(" such that the denominator is, say, ")#mi("O(n^3)")#text(".")

#emph[#text("[For this problem, Markov’s inequality is sufficient for the first part; the second part is a bit trickier but can be done by a number of means. The moment formula is more complicated than what you conjecture here, but it is only the order of growth which is relevant, rather than the exact expression. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684766")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2024")])]

#text("Dear prof Tao;")

#text("As always, thank you so much for replying. I believe you meant to say that Markov’s inequality suffices for part (ii) (rather than part (i)) for this problem? To put it specifically, my confusion for part (iii) is related to your earlier hint about applying Chebyshev’s inequality with a large value of ")#mi("k")#text(", as it seems to suggest information on the variance of ")#mi("hbox{tr}(A_nA_n^*)^k")#text(" is somehow involved here, and I’m not sure how exactly that works in this case, as opposed to the use of Markov’s inequality outlined in my previous comment.")

#text("Likewise, my confusion on part (ii) concerns your earlier hint to compute ")#mi("hbox{tr}(A_nA_n^*)^k")#text(" as a polynomial of the coefficients of ")#mi("A_n")#text(". Trying with ")#mi("k = 2, 3")#text(", this trace expression appears to be exactly ")#mi("2n^{k+1} - n^k")#text(" upon taking expectation. Yet now that you points out that the actual moment formula is more complicated, I am not sure how to show that it is ")#mi("O_k(n^{k+1})")#text(" in an inductive manner.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2024")])]

#text("Dear professor Tao: Using the hint of part (3) of Exercise 14, one can show that ")#tao-math("\\left|A_n\\right|_{op}^{2k} = \\left|A_nA_n^{*}\\right|_{op}^k", block: false)#text(" is bounded by ")#mi("tr(A_nA_n^{*})^k")#text(", which is again bounded by ")#tao-math("n\\left|A_nA_n^{*}\\right|_{op}^k = n\\left|A_n\\right|_{op}^{2k}", block: false)#text(", when ")#mi("k = 2, 4, dots")#text(" are even integers. But then since the entries of ")#mi("(A_nA_n^{*})^k")#text(" are not iid, how do we use these bounds to get the convergence/divergence result?")

#emph[#text("[You are supposed to use part (ii) here. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2024")])]

#text("Thank you professor, I was able to eventually solve the problem with your help.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2024")])]

#text("Dear professor Tao:")

#text("For part (i) of Exercise 15, one considers a countable sequence of independent Bernoulli random variables ")#mi("X_n")#text(" with parameter ")#mi("\\frac{1}{\\log n}")#text(" for all ")#mi("n \\geq 3")#text(", and the sum ")#mi("S_x =  \\sum_{n \\leq x} X_n")#text(", do you intend for the reader to show that ")#mi("S_x = x / \\log x + O(x^{1/2 + \\varepsilon})")#text(" as in your other notes, and how should one achieve this bound?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2024")])]

#text("Supposedly, how does one show that ")#mi("\\sum_{n \\leq x} 1_{\\mathcal P}(n) = x / \\log x + O(x^{1/2+ \\varepsilon})")#text(", and does one need to first obtain this estimate for part (i) of Exercise 15?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2024")])]

#text("One can use Chebyshev’s inequality to get ")#mi("S_x")#text(" close to ")#mi("\\sum_{n \\leq x} \\frac{1}{\\log n}")#text(", which one can show in turn to be somewhat close to ")#mi("x /\\log x")#text(" (though no longer with as good an accuracy as ")#mi("O(x^{1/2+\\varepsilon})")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("Thank you professor Tao. Following your suggestion, I use Markov’s inequality to show that ")#mi("displaystyle sum_{2 < n leq x} 1_{{mathcal P}}(n) = sum_{2 < n leq x} frac{1}{log n}")#text(" almost surely, and then the estimate that ")#mi("displaystyle int_{3}^x frac{dt}{log t} = frac{x}{log x} + frac{x}{log^2 x} + O(frac{x}{log^3 x})")#text(" to get the desired result. Is this a working argument?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2024")])]

#text("Edit to the messy format above: One uses Markov’s inequality to show that the number of primes according to the Cramer’s model from three up to ")#mi("x")#text(" almost surely equals to the sum of ")#mi("1/\\log n")#text(" from three up to ")#mi("x")#text(". And then uses integration by parts to get the estimate that the integral of ")#mi("1 / \\log t")#text(" from 3 to ")#mi("x")#text(" is ")#mi("x / \\log x")#text(" plus ")#mi("x / \\log^2 x")#text(" plus ")#mi("O(x / \\log^3 x)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("Dear professor Tao: The reason for this concern is that in the hint above you smuggest the use of Chebyshev’s inequality rather than the Markov’s inequality, so I’m not sure if this argument works as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684676")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2024")])]

#text("Markov’s inequality will show that the number of Cramer random model primes is comparable to ")#mi("\\sum_{3 \\leq n \\leq x} 1/\\log n")#text(", but will not get concentration around the mean; for that one needs a tool such as Chebyshev’s inequality (or an even stronger concentration inequality).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684717")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2024")])]

#text("Dear professor Tao:")

#text("I see why Markov’s inequality isn’t quite sufficient now. By Chebyshev’s inequality, the probability that the number of Cramer random model primes up to ")#mi("x")#text(" differs at least ")#mi("\\varepsilon")#text(" from its mean is bounded by ")#mi("1 / \\varepsilon^2")#text(" times the sum up to ")#mi("x")#text(" of ")#mi("1/ \\log n(1 - 1/ \\log n)")#text(". On the other hand integration by parts shows that the mean is ")#mi("x / \\log x + x / \\log^2 x + O(x / \\log^3 x) + O(1)")#text(", I’m not sure how to use these bounds to get the claim.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684757")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("A stronger concentration of measure than Chebyshyev’s inequality will be needed here. The sparsification trick will also help keep the cumulative error probabilities under control (in particular, one wants to get to the point where the Borel-Cantelli lemma may be applied).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2024")])]

#text("Dear professor Tao: Doesn’t the Markov’s inequality show that the number of Cramer random model primes from ")#mi("3")#text(" to ")#mi("x")#text(" is almost surely the sum from ")#mi("3")#text(" to ")#mi("x")#text(" of ")#mi("1 / log n")#text(", since the difference has zero mean?")

#emph[#text("[Markov’s inequality only applies for non-negative quantities (or, by using the mean of the absolute value, rather than the mean without the absolute value) -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/comment-page-1/#comment-684767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2024")])]

#text("Dear prof Tao;")

#text("For part (i) of Exercise 15, you hinted earlier that one can use Chebyshev’s inequality to get ")#mi("S_x")#text(" close to its mean, which is close in turn to ")#mi("x / log x")#text(". Are you suggesting this alone is not enough for this problem when you say that a stronger concentration of measure will be needed? Does one need to go to higher moment, or something stronger like Hoeffding’s inequality is here required?")
]
]
