// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:17:14.041145+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Szemeredi’s regularity lemma via the correspondence principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Szemeredi’s regularity lemma via the correspondence principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 May 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/")[#text("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a ")#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")[#text("previous post")]#text(", we discussed the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(", and how a given graph could be regularised by partitioning the vertex set into random neighbourhoods. More precisely, we gave a proof of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Regularity lemma via random neighbourhoods)")]#text(" ")#metadata(none) <tao-7b343f11ada385c4d2eb>#text(" Let ")#mi("{\\varepsilon > 0}")#text(". Then there exists integers ")#mi("{M_1,\\ldots,M_m}")#text(" with the following property: whenever ")#mi("{G = (V,E)}")#text(" be a graph on finitely many vertices, if one selects one of the integers ")#mi("{M_r}")#text(" at random from ")#mi("{M_1,\\ldots,M_m}")#text(", then selects ")#mi("{M_r}")#text(" vertices ")#mi("{v_1,\\ldots,v_{M_r} \\in V}")#text(" uniformly from ")#mi("{V}")#text(" at random, then the ")#mi("{2^{M_r}}")#text(" vertex cells ")#mi("{V^{M_r}_1,\\ldots,V^{M_r}_{2^{M_r}}}")#text(" (some of which can be empty) generated by the vertex neighbourhoods ")#mi("{A_t := \\{ v \\in V: (v,v_t) \\in E \\}}")#text(" for ")#mi("{1 \\leq t \\leq M_r}")#text(", will obey the regularity property ")#metadata(none) <tao-667937c3e7a68ea37471>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_{(V_i,V_j) \\text{ not } \\varepsilon-\\text{regular}} \\left|V_i\\right| \\left|V_j\\right| \\leq \\varepsilon \\left|V\\right|^2", block: true)]]

#text("with probability at least ")#mi("{1-O(\\varepsilon)}")#text(", where the sum is over all pairs ")#mi("{1 \\leq i \\leq j \\leq k}")#text(" for which ")#mi("{G}")#text(" is not ")#mi("{\\varepsilon}")#text("-regular between ")#mi("{V_i}")#text(" and ")#mi("{V_j}")#text(". [Recall that a pair ")#mi("{(V_i,V_j)}")#text(" is ")#emph[#mi("{\\varepsilon}")#text("-regular")]#text(" for ")#mi("{G}")#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|d( A, B ) - d( V_i, V_j )\\right| \\leq \\varepsilon", block: true)]]

#text("for any ")#mi("{A \\subset V_i}")#text(" and ")#mi("{B \\subset V_j}")#text(" with ")#tao-math("{\\left|A\\right| \\geq \\varepsilon \\left|V_i\\right|, \\left|B\\right| \\geq \\varepsilon \\left|V_j\\right|}", block: false)#text(", where ")#tao-math("{d(A,B) := \\left|E \\cap (A \\times B)\\right|/\\left|A\\right| \\left|B\\right|}", block: false)#text(" is the density of edges between ")#mi("{A}")#text(" and ")#mi("{B}")#text(".]")
]

#text("The proof was a combinatorial one, based on the standard energy increment argument.")

#text("In this post I would like to discuss an alternate approach to the regularity lemma, which is an infinitary approach passing through a graph-theoretic version of the Furstenberg correspondence principle (mentioned briefly in ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this earlier post of mine")]#text("). While this approach superficially looks quite different from the combinatorial approach, it in fact uses many of the same ingredients, most notably a reliance on random neighbourhoods to regularise the graph. This approach was introduced ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("by myself")]#text(" back in 2006, and used ")#link("http://arxiv.org/abs/0801.1698")[#text("by Austin")]#text(" and ")#link("http://arxiv.org/abs/0801.2179")[#text("by Austin and myself")]#text(" to establish some property testing results for hypergraphs; more recently, a closely related infinitary hypergraph removal lemma developed in the 2006 paper was also used by Austin to give ")#link("http://arxiv.org/abs/0808.2267")[#text("new proofs of the multidimensional Szemeredi theorem")]#text(" and ")#link("http://arxiv.org/abs/0903.1633")[#text("of the density Hales-Jewett theorem")]#text(" (the latter being a spinoff of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 project")]#text(").")

#text("For various technical reasons we will not be able to use the correspondence principle to recover Lemma ")#link(<tao-7b343f11ada385c4d2eb>)[#text("1")]#text(" in its full strength; instead, we will establish the following slightly weaker variant.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Regularity lemma via random neighbourhoods, weak version)")]#text(" ")#metadata(none) <tao-32528cb2558a284e5b40>#text(" Let ")#mi("{\\varepsilon > 0}")#text(". Then there exist an integer ")#mi("{M_*}")#text(" with the following property: whenever ")#mi("{G = (V,E)}")#text(" be a graph on finitely many vertices, there exists ")#mi("{1 \\leq M \\leq M_*}")#text(" such that if one selects ")#mi("{M}")#text(" vertices ")#mi("{v_1,\\ldots,v_{M} \\in V}")#text(" uniformly from ")#mi("{V}")#text(" at random, then the ")#mi("{2^{M}}")#text(" vertex cells ")#mi("{V^{M}_1,\\ldots,V^{M}_{2^{M}}}")#text(" generated by the vertex neighbourhoods ")#mi("{A_t := \\{ v \\in V: (v,v_t) \\in E \\}}")#text(" for ")#mi("{1 \\leq t \\leq M}")#text(", will obey the regularity property ")#link(<tao-667937c3e7a68ea37471>)[#text("(1)")]#text(" with probability at least ")#mi("{1-\\varepsilon}")#text(".")
]

#text("Roughly speaking, Lemma ")#link(<tao-7b343f11ada385c4d2eb>)[#text("1")]#text(" asserts that one can regularise a large graph ")#mi("{G}")#text(" with high probability by using ")#mi("{M_r}")#text(" random neighbourhoods, where ")#mi("{M_r}")#text(" is chosen at random from one of a number of choices ")#mi("{M_1,\\ldots,M_m}")#text("; in contrast, the weaker Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("2")]#text(" asserts that one can regularise a large graph ")#mi("{G}")#text(" with high probability by using ")#emph[#text("some")]#text(" integer ")#mi("{M}")#text(" from ")#mi("{1,\\ldots,M_*}")#text(", but the exact choice of ")#mi("{M}")#text(" depends on ")#mi("{G}")#text(", and it is not guaranteed that a randomly chosen ")#mi("{M}")#text(" will be likely to work. While Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("2")]#text(" is strictly weaker than Lemma ")#link(<tao-7b343f11ada385c4d2eb>)[#text("1")]#text(", it still implies the (weighted) Szemerédi regularity lemma (Lemma 2 from the ")#link("https://terrytao.wordpress.com/2009/04/26/szemeredis-regularity-lemma-via-random-partitions/")[#text("previous post")]#text(").")

#metadata(none) <tao-25930ba9659f0af5ff72>

#heading(level: 1)[#strong[#text(" — 1. The graph correspondence principle — ")]]

#text("The first key tool in this argument is the ")#emph[#text("graph correspondence principle")]#text(", which takes a sequence of (increasingly large) graphs and uses random sampling to extract an infinitary limit object, which will turn out to be an infinite but random (and, crucially, ")#emph[#text("exchangeable")]#text(") graph. This concept of a graph limit is related to (though slightly different from) the “graphons” used as graph limits in the ")#link("http://arxiv.org/abs/math/0408173")[#text("work of Lovasz and Szegedy")]#text(", or the ultraproducts used in the work of ")#link("http://arxiv.org/abs/0810.4062")[#text("Elek and Szegedy")]#text(". It also seems to be related to the concept of an elementary limit that I discussed in ")#link("https://terrytao.wordpress.com/2009/04/10/the-completeness-and-compactness-theorems-of-first-order-logic/")[#text("this post")]#text(", though this connection is still rather tentative.")

#text("The correspondence works as follows. We start with a finite, deterministic graph ")#mi("{G = (V,E)}")#text(". We can then form an infinite, random graph ")#mi("{\\hat G = ({\\mathbb Z}, \\hat E)}")#text(" from this graph by the following recipe:")

#list(
[#text("The vertex set of ")#mi("{\\hat G}")#text(" will be the integers ")#mi("{{\\mathbb Z} = \\{ -2,-1,0,1,2,\\ldots\\}}")#text(".")],
[#text("For every integer ")#mi("{n}")#text(", we randomly select a vertex ")#mi("{v_n}")#text(" in ")#mi("{V}")#text(", uniformly and independently at random. (Note that there will be many collisions, i.e. integers ")#mi("{n,m}")#text(" for which ")#mi("{v_n=v_m}")#text(", but these collisions will become asymptotically negligible in the limit ")#tao-math("{\\left|V\\right| \\rightarrow \\infty}", block: false)#text(".)")],
[#text("We then define the edge set ")#mi("{\\hat E}")#text(" of ")#mi("{\\hat G}")#text(" by declaring ")#mi("{(n,m)}")#text(" to be an edge on ")#mi("{\\hat E}")#text(" if and only if ")#mi("{(v_n,v_m)}")#text(" is an edge in ")#mi("{E}")#text(" (which in particular requires ")#mi("{v_n \\neq v_m}")#text(").")]
)

#text("More succinctly, ")#mi("{\\hat G}")#text(" is the pullback of ")#mi("{G}")#text(" under a random map from ")#mi("{{\\mathbb Z}}")#text(" to ")#mi("{V}")#text(".")

#text("The random graph ")#mi("{\\hat G}")#text(" captures all the “local” information of ")#mi("{G}")#text(", while obscuring all the “global” information. For instance, the edge density of ")#mi("{G}")#text(" is essentially just the probability that a given edge, say ")#mi("{(1,2)}")#text(", lies in ")#mi("{\\hat G}")#text(". (There is a small error term due to the presence of collisions, but this goes away in the limit ")#tao-math("{\\left|V\\right| \\rightarrow \\infty}", block: false)#text(".) Similarly, the triangle density of ")#mi("{G}")#text(" is essentially the probability that a given triangle, say ")#mi("{\\{(1,2), (2,3), (3,1)\\}}")#text(", lies in ")#mi("{\\hat G}")#text(". On the other hand, it is difficult to read off global properties of ")#mi("{G}")#text(", such as being connected or ")#mi("{4}")#text("-colourable, just from ")#mi("{\\hat G}")#text(".")

#text("At first glance, it may seem a poor bargain to trade in a finite deterministic graph ")#mi("{G}")#text(" for an infinite random graph ")#mi("{\\hat G}")#text(", which is a more complicated and less elementary object. However, there are three major advantages of working with ")#mi("{\\hat G}")#text(" rather than ")#mi("{G}")#text(":")

#list(
[#strong[#text("Exchangeability")]#text(". The probability distribution of ")#mi("{\\hat G}")#text(" has a powerful symmetry or ")#link("http://en.wikipedia.org/wiki/Exchangeable_random_variables")[#text("exchangeability")]#text(" property: if one takes the random graph ")#mi("{\\hat G}")#text(" and interchanges any two vertices in ")#mi("{{\\mathbb Z}}")#text(", e.g. ")#mi("{3}")#text(" and ")#mi("{5}")#text(", one obtains a new graph which is not equal to ")#mi("{\\hat G}")#text(", but nevertheless has the same probability distribution as ")#mi("{\\hat G}")#text(", basically because the ")#mi("{v_n}")#text(" were selected in an ")#link("http://en.wikipedia.org/wiki/Independent_and_identically_distributed")[#text("iid")]#text(" manner. More generally, given any permutation ")#mi("{\\sigma: {\\mathbb Z} \\rightarrow {\\mathbb Z}}")#text(", the pullback ")#mi("{\\sigma^*(\\hat G)}")#text(" of ")#mi("{\\hat G}")#text(" by ")#mi("{\\sigma}")#text(" has the same probability distribution as ")#mi("{\\hat G}")#text("; thus we have a measure-preserving action of the symmetric group ")#mi("{S_\\infty}")#text(", which places us in the general framework of ergodic theory.")],
[#strong[#text("Limits")]#text(". The space of probability measures on the space ")#mi("{2^{\\binom{{\\mathbb Z}}{2}}}")#text(" of infinite graphs is sequentially compact; given any sequence ")#mi("{\\hat G_n = ({\\mathbb Z}, \\hat E_n)}")#text(" of infinite random graphs, one can find a subsequence ")#mi("{\\hat G_{n_j}}")#text(" which converges in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to another infinite random graph. What this means is that given any event ")#mi("{E}")#text(" on infinite graphs that involve only finitely many of the edges, the probability that ")#mi("{\\hat G_{n_j}}")#text(" obeys ")#mi("{E}")#text(" converges to the probability that ")#mi("{\\hat G}")#text(" obeys ")#mi("{E}")#text(". (Thus, for instance, the probability that ")#mi("{\\hat G_{n_j}}")#text(" contains the triangle ")#mi("{\\{(1,2), (2,3), (3,1)\\}}")#text(" will converge to the probability that ")#mi("{\\hat G}")#text(" contains the same triangle.) Note that properties that involve infinitely many edges (e.g. connectedness) need not be preserved under vague limits.")],
[#strong[#text("Factors")]#text(". The underlying probability space for the random variable ")#mi("{\\hat G}")#text(" is the space ")#mi("{2^{\\binom{{\\mathbb Z}}{2}}}")#text(" of infinite graphs, and it is natural to give this space the Borel ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}_{\\mathbb Z}}")#text(", which is the ")#mi("{\\sigma}")#text("-algebra generated by the ")#link("http://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder events")]#text(" “")#mi("{(i,j) \\in \\hat G}")#text("” for ")#mi("{i,j \\in {\\mathbb Z}}")#text(". But this ")#mi("{\\sigma}")#text("-algebra also has a number of useful sub-")#mi("{\\sigma}")#text("-algebras or ")#emph[#text("factors")]#text(", representing various partial information on the graph ")#mi("{\\hat G}")#text(". In particular, given any subset ")#mi("{I}")#text(" of ")#mi("{{\\mathbb Z}}")#text(", one can create the factor ")#mi("{{\\mathcal B}_I}")#text(", defined as the ")#mi("{\\sigma}")#text("-algebra generated by the events “")#mi("{(i,j) \\in \\hat G}")#text("” for ")#mi("{i,j \\in I}")#text(". Thus for instance, the event that ")#mi("{\\hat G}")#text(" contains the triangle is measurable in ")#mi("{{\\mathcal B}_{\\{1,2,3\\}}}")#text(", but not in ")#mi("{{\\mathcal B}_{\\{1,2\\}}}")#text(". One can also look at compound factors such as ")#mi("{{\\mathcal B}_I \\vee {\\mathcal B}_J}")#text(", the factor generated by the union of ")#mi("{{\\mathcal B}_I}")#text(" and ")#mi("{{\\mathcal B}_J}")#text(". For instance, the event that ")#mi("{\\hat G}")#text(" contains the edges ")#mi("{(1,2), (1,3)}")#text(" is measurable in ")#mi("{{\\mathcal B}_{\\{1,2\\}} \\vee {\\mathcal B}_{\\{1,3\\}}}")#text(", but the event that ")#mi("{\\hat G}")#text(" contains the triangle ")#mi("{\\{(1,2), (2,3), (3,1)\\}}")#text(" is not.")]
)

#text("The connection between the infinite random graph ")#mi("{\\hat G}")#text(" and partitioning through random neighbourhoods comes when contemplating the relative difference between a factor such as ")#mi("{{\\mathcal B}_{\\{-n,\\ldots,-1\\}}}")#text(" and ")#mi("{{\\mathcal B}_{\\{-n,\\ldots,-1\\} \\cup \\{1\\}}}")#text(" (say). The latter factor is generated by the former factor, together with the events “")#mi("{(1,-i) \\in \\hat E}")#text("” for ")#mi("{i=1,\\ldots,n}")#text(". But observe if ")#mi("{\\hat G = ({\\mathbb Z}, \\hat E)}")#text(" is generated from a finite deterministic graph ")#mi("{G = (V,E)}")#text(", then ")#mi("{(1,-i)}")#text(" lies in ")#mi("{\\hat E}")#text(" if and only if ")#mi("{v_1}")#text(" lies in the vertex neighbourhood of ")#mi("{v_{-i}}")#text(". Thus, if one uses the vertex neighbourhoods of ")#mi("{v_{-1},\\ldots,v_{-n}}")#text(" to subdivide the original vertex set ")#mi("{V}")#text(" into ")#mi("{2^n}")#text(" cells of varying sizes, the factor ")#mi("{{\\mathcal B}_{\\{-n,\\ldots,-1\\} \\cup \\{1\\}}}")#text(" is generated from ")#mi("{{\\mathcal B}_{\\{-n,\\ldots,-1\\}}}")#text(", together with the random variable that computes which of these ")#mi("{2^n}")#text(" cells the random vertex ")#mi("{v_1}")#text(" falls into. We will see this connection in more detail later in this post, when we use the correspondence principle to prove Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("2")]#text(".")

#text("Combining the exchangeability and limit properties (and noting that the vague limit of exchangeable random graphs is still exchangeable), we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Graph correspondence principle)")]#text(" Let ")#mi("{G_n = (V_n,E_n)}")#text(" be a sequence of finite deterministic graphs, and let ")#mi("{\\hat G_n = ({\\mathbb Z}, \\hat E_n)}")#text(" be their infinite random counterparts. Then there exists a subsequence ")#mi("{n_j}")#text(" such that ")#mi("{\\hat G_{n_j}}")#text(" converges in the vague topology to an exchangeable infinite random graph ")#mi("{\\hat G = ({\\mathbb Z}, \\hat E)}")#text(".")
]

#text("We can illustrate this principle with three main examples, two from opposing extremes of the “dichotomy between structure and randomness”, and one intermediate one.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Random example)")]#text(" ")#metadata(none) <tao-d30e64c1cd945e7d729c>#text(" Let ")#mi("{G_n = (V_n,E_n)}")#text(" be a sequence of ")#mi("{\\varepsilon_n}")#text("-regular graphs of edge density ")#mi("{p_n}")#text(", where ")#tao-math("{\\left|V_n\\right| \\rightarrow \\infty}", block: false)#text(", ")#mi("{\\varepsilon_n \\rightarrow 0}")#text(", and ")#mi("{p_n \\rightarrow p}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Then any graph limit ")#mi("{\\hat G = ({\\mathbb Z},\\hat G)}")#text(" of this sequence will be an ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93R%C3%A9nyi_model")[#text("Erdös-Rényi graph")]#text(" ")#mi("{\\hat G = G(\\infty,p)}")#text(", where each edge ")#mi("{(i,j)}")#text(" lies in ")#mi("{\\hat G}")#text(" with an independent probability of ")#mi("{p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Structured example)")]#text(" ")#metadata(none) <tao-07ba0c4bdc9c62c5fdc0>#text(" Let ")#mi("{G_n = (V_n,E_n)}")#text(" be a sequence of complete bipartite graphs, where the two cells of the bipartite graph have vertex density ")#mi("{q_n}")#text(" and ")#mi("{1-q_n}")#text(" respectively, with ")#tao-math("{\\left|V_n\\right| \\rightarrow \\infty}", block: false)#text(" and ")#mi("{q_n \\rightarrow q}")#text(". Then any graph limit ")#mi("{\\hat G = ({\\mathbb Z},\\hat E)}")#text(" of this sequence will be a random complete bipartite graph, constructed as follows: first, randomly colour each vertex ")#mi("{n}")#text(" of ")#mi("{{\\mathbb Z}}")#text(" red with probability ")#mi("{q}")#text(" and blue with probability ")#mi("{1-q}")#text(", independently for each vertex. Then define ")#mi("{\\hat G}")#text(" to be the complete bipartite graph between the red vertices and the blue vertices.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Random+structured example)")]#text(" ")#metadata(none) <tao-95c477eebbbd6f608163>#text(" Let ")#mi("{G_n = (V_n,E_n)}")#text(" be a sequence of ")#emph[#text("incomplete")]#text(" bipartite graphs, where the two cells of the bipartite graph have vertex density ")#mi("{p_n}")#text(" and ")#mi("{1-p_n}")#text(" respectively, and the graph ")#mi("{G_n}")#text(" is ")#mi("{\\varepsilon_n}")#text("-regular between these two cells with edge density ")#mi("{p_n}")#text(", with ")#tao-math("{\\left|V_n\\right| \\rightarrow \\infty}", block: false)#text(", ")#mi("{\\varepsilon_n \\rightarrow 0}")#text(", ")#mi("{p_n \\rightarrow p}")#text(", and ")#mi("{q_n \\rightarrow q}")#text(". Then any graph limit ")#mi("{\\hat G = ({\\mathbb Z},\\hat E)}")#text(" of this sequence will be a random bipartite graph, constructed as follows: first, randomly colour each vertex ")#mi("{n}")#text(" of ")#mi("{{\\mathbb Z}}")#text(" red with probability ")#mi("{q}")#text(" and blue with probability ")#mi("{1-q}")#text(", independently for each vertex. Then define ")#mi("{\\hat G}")#text(" to be the bipartite graph between the red vertices and the blue vertices, with each edge between red and blue having an independent probability of ")#mi("{p}")#text(" of lying in ")#mi("{\\hat E}")#text(".")
]

#text("One can use the graph correspondence principle to prove statements about finite deterministic graphs, by the usual ")#link("http://www.tricki.org/article/Use_the_compactness_and_contradiction_method_to_derive_finitary_quantitative_results_from_infinitary_qualitative_ones")[#text("compactness and contradiction approach")]#text(": argue by contradiction, create a sequence of finite deterministic graph counterexamples, use the correspondence principle to pass to an infinite random exchangeable limit, and obtain the desired contradiction in the infinitary setting. (See ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this earlier blog post of mine")]#text(" for further discussion.) This will be how we shall approach the proof of Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("2")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. The infinitary regularity lemma — ")]]

#text("To prove the finitary regularity lemma via the correspondence principle, one must first develop an infinitary counterpart. We will present this infinitary regularity lemma (first introduced in this paper) shortly, but let us motivate it by a discussion based on the three model examples of infinite exchangeable graphs ")#mi("{\\hat G = ({\\mathbb Z}, \\hat E)}")#text(" from the previous section.")

#text("First, consider the “random” graph ")#mi("{\\hat G}")#text(" from Example ")#link(<tao-d30e64c1cd945e7d729c>)[#text("1")]#text(". Here, we observe that the events “")#mi("{(i,j) \\in \\hat E}")#text("” are jointly independent of each other, thus for instance")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( (1,2), (2,3), (3,1) \\in \\hat E ) = \\prod_{(i,j) = (1,2), (2,3), (3,1)} {\\Bbb P}( (i,j) \\in \\hat E ).")]]

#text("More generally, we see that the factors ")#mi("{{\\mathcal B}_{\\{i,j\\}}}")#text(" for all distinct ")#mi("{i,j \\in {\\mathbb Z}}")#text(" are independent, which means that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( E_1 \\wedge \\ldots \\wedge E_n ) = {\\Bbb P}(E_1) \\ldots {\\Bbb P}(E_n)")]]

#text("whenever ")#mi("{E_1 \\in {\\mathcal B}_{\\{i_1,j_1\\}}, \\ldots, E_n \\in {\\mathcal B}_{\\{i_n,j_n\\}}}")#text(" and the ")#mi("{\\{i_1,j_1\\},\\ldots,\\{i_n,j_n\\}}")#text(" are distinct.")

#text("Next, we consider the “structured” graph ")#mi("{\\hat G}")#text(" from Example ")#link(<tao-07ba0c4bdc9c62c5fdc0>)[#text("2")]#text(", where we take ")#mi("{0 < p < 1}")#text(" to avoid degeneracies. In contrast to the preceding example, the events “")#mi("{(i,j) \\in \\hat E}")#text("” are now highly dependent; for instance, if ")#mi("{(1,2) \\in \\hat E}")#text(" and ")#mi("{(1,3) \\in \\hat E}")#text(", then this forces ")#mi("{(2,3)}")#text(" to lie outside of ")#mi("{\\hat E}")#text(", despite the fact that the events “")#mi("{(i,j) \\in \\hat E}")#text("” each occur with a non-zero probability of ")#mi("{p (1-p)}")#text(". In particular, the factors ")#mi("{{\\mathcal B}_{\\{1,2\\}}, {\\mathcal B}_{\\{1,3\\}}, {\\mathcal B}_{\\{2,3\\}}}")#text(" are not jointly independent.")

#text("However, one can recover a ")#emph[#text("conditional")]#text(" independence by introducing some new factors. Specifically, let ")#mi("{{\\mathcal B}_i}")#text(" be the factor generated by the event that the vertex ")#mi("{i}")#text(" is coloured red. Then we see that the factors ")#mi("{{\\mathcal B}_{\\{1,2\\}}, {\\mathcal B}_{\\{1,3\\}}, {\\mathcal B}_{\\{2,3\\}}}")#text(" now become ")#emph[#text("conditionally")]#text(" jointly independent, relative to the base factor ")#mi("{{\\mathcal B}_1 \\vee {\\mathcal B}_2 \\vee {\\mathcal B}_3}")#text(", which means that we have conditional independence identities such as")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( (1,2), (2,3), (3,1) \\in \\hat{E} | {\\mathcal B}_1 \\vee {\\mathcal B}_2 \\vee {\\mathcal B}_3 ) = \\prod_{(i,j) = (1,2), (2,3), (3,1)} {\\Bbb P}( (i,j) \\in \\hat{E} | {\\mathcal B}_1 \\vee {\\mathcal B}_2 \\vee {\\mathcal B}_3 ).")]]

#text("Indeed, once one fixes (conditions) the information in ")#mi("{{\\mathcal B}_1 \\vee {\\mathcal B}_2 \\vee {\\mathcal B}_3}")#text(" (i.e. once one knows what colour the vertices ")#mi("{1,2,3}")#text(" are), the events “")#mi("{(i,j) \\in \\hat E}")#text("” for ")#mi("{(i,j)=(1,2), (2,3), (3,1)}")#text(" either occur with probability ")#mi("{1}")#text(" (if ")#mi("{i, j}")#text(" have distinct colours) or probability ")#mi("{0}")#text(" (if ")#mi("{i,j}")#text(" have the same colour), and so the conditional independence is trivially true.")

#text("A similar phenomenon holds for the “random+structured” graph ")#mi("{\\hat G}")#text(" from Example ")#link(<tao-95c477eebbbd6f608163>)[#text("3")]#text(", with ")#mi("{0 < p,q < 1}")#text(". Again, the factors ")#mi("{{\\mathcal B}_{\\{i,j\\}}}")#text(" are not jointly independent in an absolute sense, but once one introduces the factors ")#mi("{{\\mathcal B}_i}")#text(" based on the colour of the vertex ")#mi("{i}")#text(", we see once again that the ")#mi("{{\\mathcal B}_{\\{i,j\\}}}")#text(" become conditionally jointly independent relative to the ")#mi("{{\\mathcal B}_i}")#text(".")

#text("These examples suggest, more generally, that we should be able to ")#emph[#text("regularise")]#text(" the graph ")#mi("{\\hat G}")#text(" (or more precisely, the system of edge factors ")#mi("{{\\mathcal B}_{\\{i,j\\}}}")#text(") by introducing some single-vertex factors ")#mi("{{\\mathcal B}_i}")#text(", with respect to which the edge factors become conditionally independent; this is the infinitary analogue of a finite graph becoming ")#mi("{\\varepsilon}")#text("-regular relative to a suitably chosen partition of the vertex set into cells.")

#text("Now, in Examples ")#link(<tao-07ba0c4bdc9c62c5fdc0>)[#text("2")]#text(", ")#link(<tao-95c477eebbbd6f608163>)[#text("3")]#text(" we were able to obtain this regularisation because the vertices of the graph were conveniently coloured for us (red or blue). But for general infinite exchangeable graphs ")#mi("{\\hat G}")#text(", such a vertex colouring is not provided to us, so how is one to generate the vertex factors ")#mi("{{\\mathcal B}_i}")#text("?")

#text("The key trick – which is the infinitary analogue of using random neighbourhoods to regularise a finitary graph – is to sequester half of the infinite vertices in ")#mi("{{\\mathbb Z}}")#text(" – e.g. the negative vertices ")#mi("{-1, -2, \\ldots}")#text(" – away as “reference” or “training” vertices, and then and colorise the remaining vertices ")#mi("{i}")#text(" of the graph based on how that vertex interacts with the reference vertices. More formally, we define ")#mi("{{\\mathcal B}_i}")#text(" for ")#mi("{i=0,1,2,\\ldots}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal B}_i := {\\mathcal B}_{\\{ -1,-2,\\ldots\\} \\cup \\{i\\}}.")]]

#text("We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Infinitary regularity lemma)")]#text(" Let ")#mi("{\\hat G = ({\\mathbb Z},\\hat E)}")#text(" be a infinite exchangeable random graph. Then the ")#mi("{{\\mathcal B}_{\\{i,j\\}} \\vee {\\mathcal B}_i \\vee {\\mathcal B}_j}")#text(" for natural numbers ")#mi("{i,j}")#text(" are conditinally jointly independent relative to the ")#mi("{{\\mathcal B}_i}")#text(". More precisely, if ")#mi("{I}")#text(" is a set of natural numbers, ")#mi("{E}")#text(" is a subset of ")#mi("{\\binom{I}{2}}")#text(", and ")#mi("{E_e}")#text(" is a ")#mi("{{\\mathcal B}_e \\wedge \\bigwedge_{i \\in e} {\\mathcal B}_i}")#text("-measurable event for all ")#mi("{e \\in E}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\mathbb P}( \\bigwedge_{e \\in E} E_{e} | \\bigwedge_{i \\in I} {\\mathcal B}_i ) = \\prod_{e \\in E} \\mathop{\\mathbb P}( E_e | \\bigwedge_{i \\in I} {\\mathcal B}_i ).")]]
]

#emph[#text("Proof:")]#text(" By induction on ")#mi("{E}")#text(", it suffices to show that for any ")#mi("{e_0 \\in E}")#text(", the event ")#mi("{E_{e_0}}")#text(" and the event ")#mi("{\\bigwedge_{e \\in E \\backslash \\{e_0\\}} E_e}")#text(" are independent relative to ")#mi("{\\bigwedge_{i \\in I} {\\mathcal B}_i}")#text(".")

#text("By relabeling we may take ")#mi("{I = \\{1,\\ldots,n\\}}")#text(" and ")#mi("{e_0=\\{1,2\\}}")#text(" for some ")#mi("{n \\geq 2}")#text(". We use the exchangeability of ")#mi("{\\hat G}")#text(" (and ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_paradox_of_the_Grand_Hotel")[#text("Hilbert’s hotel")]#text(") to observe that the random variables")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}( 1_{E_{e_0}} | {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{1\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{2\\}} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}( 1_{E_{e_0}} | {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{1\\} \\cup \\{3,\\ldots,n\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{2\\} \\cup \\{3,\\ldots,n\\}} )")]]

#text("have the same distribution; in particular, they have the same ")#mi("{L^2}")#text(" norm. By Pythagoras’ theorem, they must therefore be equal almost surely; furthermore, for any intermediate ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(" between ")#mi("{{\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{1\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{2\\}}}")#text(" and ")#mi("{{\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{1\\} \\cup \\{3,\\ldots,n\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots\\} \\cup \\{2\\} \\cup \\{3,\\ldots,n\\}}}")#text(", ")#mi("{{\\Bbb E}( 1_{E_{e_0}} | {\\mathcal B} )}")#text(" is also equal almost surely to the above two expressions. (The astute reader will observe that we have just run the “energy increment argument”; in the infinitary world, it is somewhat slicker than in the finitary world, due to the convenience of the Hilbert’s hotel trick, and the fact that the existence of orthogonal projections (and in particular, conditional expectation) is itself encoding an energy increment argument.)")

#text("As a special case of the above observation, we see that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}( 1_{E_{e_0}} | \\bigwedge_{i \\in I} {\\mathcal B}_i ) = {\\Bbb E}( 1_{E_{e_0}} | \\bigwedge_{i \\in I} {\\mathcal B}_i \\wedge \\bigwedge_{e \\in E \\backslash \\{e_0\\}} {\\mathcal B}_e ).")]]

#text("In particular, this implies that ")#mi("{E_0}")#text(" is conditionally independent of every event measurable in ")#mi("{\\bigwedge_{i \\in I} {\\mathcal B}_i \\wedge \\bigwedge_{e \\in E \\backslash \\{e_0\\}} {\\mathcal B}_e}")#text(", relative to ")#mi("{\\bigwedge_{i \\in I} {\\mathcal B}_i}")#text(", and the claim follows. ")#mi("\\Box")

#text("We remark that the same argument also allows one to easily regularise infinite exchangeable hypergraphs; see ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("my paper")]#text(" for details. In fact one can go further and obtain a structural theorem for these hypergraphs generalising ")#link("http://en.wikipedia.org/wiki/De_Finetti%27s_theorem")[#text("de Finetti’s theorem")]#text(", and also closely related to the graphons of Lovasz and Szegedy; see ")#link("http://aps.arxiv.org/abs/0801.1698")[#text("this paper of Austin")]#text(" for details.")

#heading(level: 1)[#strong[#text(" — 3. Proof of finitary regularity lemma — ")]]

#text("Having proven the infinitary regularity lemma, we now use the correspondence principle and the ")#link("http://www.tricki.org/article/Use_the_compactness_and_contradiction_method_to_derive_finitary_quantitative_results_from_infinitary_qualitative_ones")[#text("compactness and contradiction argument")]#text(" to recover the finitary regularity lemma, Lemma ")#link(<tao-32528cb2558a284e5b40>)[#text("2")]#text(".")

#text("Suppose this lemma failed. Carefully negating all the quantifiers, this means that there exists ")#mi("{\\varepsilon > 0}")#text(", a sequence ")#mi("{M_n}")#text(" going to infinity, and a sequence of finite deterministic graphs ")#mi("{G_n = (V_n,E_n)}")#text(" such that for every ")#mi("{1 \\leq M \\leq M_n}")#text(", if one selects vertices ")#mi("{v_1,\\ldots,v_M \\in V_n}")#text(" uniformly from ")#mi("{V_n}")#text(", then the ")#mi("{2^{M}}")#text(" vertex cells ")#mi("{V^{M}_1,\\ldots,V^{M}_{2^{M}}}")#text(" generated by the vertex neighbourhoods ")#mi("{A_t := \\{ v \\in V: (v,v_t) \\in E \\}}")#text(" for ")#mi("{1 \\leq t \\leq M}")#text(", will obey the regularity property ")#link(<tao-667937c3e7a68ea37471>)[#text("(1)")]#text(" with probability less than ")#mi("{1-\\varepsilon}")#text(".")

#text("We convert each of the finite deterministic graphs ")#mi("{G_n = (V_n,E_n)}")#text(" to an infinite random exchangeable graph ")#mi("{\\hat G_n = ({\\mathbb Z}, \\hat E_n)}")#text("; invoking the ocrrespondence principle and passing to a subsequence if necessary, we can assume that this graph converges in the vague topology to an exchangeable limit ")#mi("{\\hat G = ({\\mathbb Z}, \\hat E)}")#text(". Applying the infinitary regularity lemma to this graph, we see that the edge factors ")#mi("{{\\mathcal B}_{\\{i,j\\}} \\wedge {\\mathcal B}_i \\wedge {\\mathcal B}_j}")#text(" for natural numbers ")#mi("{i,j}")#text(" are conditionally jointly independent relative to the vertex factors ")#mi("{{\\mathcal B}_i}")#text(".")

#text("Now for any distinct natural numbers ")#mi("{i,j}")#text(", let ")#mi("{f(i,j)}")#text(" be the indicator of the event “")#mi("{(i,j)}")#text(" lies in ")#mi("{\\hat E}")#text("“, thus ")#mi("{f=1}")#text(" when ")#mi("{(i,j)}")#text(" lies in ")#mi("{\\hat E}")#text(" and ")#mi("{f(i,j)=0}")#text(" otherwise. Clearly ")#mi("{f(i,j)}")#text(" is ")#mi("{{\\mathcal B}_{\\{i,j\\}}}")#text("-measurable. We can write")

#align(center)[#tao-fit-display[#mitex("f(i,j) = f_{U^\\perp}(i,j) + f_U(i,j)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f_{U^\\perp}(i,j) := {\\Bbb E}( f(i,j) | {\\mathcal B}_i \\wedge {\\mathcal B}_j )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("f_U(i,j) := f(i,j) - f_{U^\\perp}(i,j).")]]

#text("The exchangeability of ")#mi("{\\hat G}")#text(" ensures that ")#mi("{f, f_U, f_{U^\\perp}}")#text(" are exchangeable with respect to permutations of the natural numbers, in particular ")#mi("{f_U(i,j)=f_U(j,i)}")#text(" and ")#mi("{f_{U^\\perp}(i,j)=f_{U^\\perp}(j,i)}")#text(".")

#text("By the infinitary regularity lemma, the ")#mi("{f_U(i,j)}")#text(" are jointly independent relative to the ")#mi("{{\\mathcal B}_i}")#text(", and also have mean zero relative to these factors, so in particular they are infinitely pseudorandom in the sense that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} f_U(1,2) f_U(3,2) f_U(1,4) f_U(3,4) = 0.")]]

#text("Meanwhile, the random variable ")#mi("{f_{U^\\perp}(1,2)}")#text(" is measurable with respect to the factor ")#mi("{{\\mathcal B}_1 \\vee {\\mathcal B}_2}")#text(", which is the limit of the factors ")#mi("{{\\mathcal B}_{\\{-1,-2,\\ldots,-M\\} \\cup \\{1\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots,-M\\} \\cup \\{2\\}}}")#text(" as ")#mi("{M}")#text(" increases. Thus, given any ")#mi("{\\tilde \\varepsilon > 0}")#text(" (to be chosen later), one can find an approximation ")#mi("{\\tilde f_{U^\\perp}(1,2)}")#text(" to ")#mi("{f_{U^\\perp}(1,2)}")#text(", bounded between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", which is ")#mi("{{\\mathcal B}_{\\{-1,-2,\\ldots,-M\\} \\cup \\{1\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots,-M\\} \\cup \\{2\\}}}")#text("-measurable for some ")#mi("{M}")#text(", and such that")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|\\tilde f_{U^\\perp}(1,2) - f_{U^\\perp}(1,2)\\right| \\leq \\tilde \\varepsilon.", block: true)]]

#text("We can also impose the symmetry condition ")#mi("{\\tilde f_{U^\\perp}(1,2) =\\tilde f_{U^\\perp}(2,1)}")#text(". Now let ")#mi("{\\tilde \\varepsilon^{\\prime} > 0}")#text(" be an extremely small number (depending on ")#mi("{\\tilde \\varepsilon,n}")#text(") to be chosen later. Then one can find an approximation ")#mi("{\\tilde f_U(1,2)}")#text(" to ")#mi("{f_U(1,2)}")#text(", bounded between ")#mi("{-1}")#text(" and ")#mi("{1}")#text(", which is ")#mi("{{\\mathcal B}_{\\{-1,-2,\\ldots,-M^{\\prime}\\} \\cup \\{1\\}} \\vee {\\mathcal B}_{\\{-1,-2,\\ldots,-M^{\\prime}\\} \\cup \\{2\\}}}")#text("-measurable for some ")#mi("{M^{\\prime}}")#text(", and such that")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|\\tilde f_{U}(1,2) - f_{U}(1,2)\\right| \\leq \\tilde \\varepsilon^{\\prime}.", block: true)]]

#text("Again we can impose the symmetry condition ")#mi("{\\tilde f_{U}(1,2) = \\tilde f_{U}(2,1)}")#text(". We can then extend ")#mi("{\\tilde f_U}")#text(" by exchangeability, so that")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|\\tilde f_{U}(i,j) - f_{U}(i,j)\\right| \\leq \\tilde \\varepsilon^{\\prime}.", block: true)]]

#text("for all distinct natural numbers ")#mi("{i,j}")#text(". By the triangle inequality we then have ")#metadata(none) <tao-3f524cdc07a11d7c6220>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\Bbb E} \\tilde f_U(1,2) \\tilde f_U(3,2) \\tilde f_U(1,4) \\tilde f_U(3,4) = O(\\tilde \\varepsilon^{\\prime})")]]

#text("and by a separate application of the triangle inequality ")#metadata(none) <tao-e4ab4e3b1493d5a997b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("{\\Bbb E} \\left|f(i,j) - \\tilde f_{U^\\perp}(i,j) - \\tilde f_U(i,j)\\right| = O(\\tilde \\varepsilon).", block: true)]]

#text("The bounds ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(2)")]#text(", ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(3)")]#text(" apply to the limiting infinite random graph ")#mi("{\\hat G = ({\\mathbb Z},\\hat E)}")#text(". On the other hand, all the random variables appearing in ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(2)")]#text(", ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(3)")]#text(" involve at most finitely many of the edges of the graph. Thus, by vague convergence, the bounds ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(2)")]#text(", ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(3)")]#text(" also apply to the graph ")#mi("{\\hat G_n = ({\\mathbb Z}, \\hat E_n)}")#text(" for sufficiently large ")#mi("{n}")#text(".")

#text("Now we unwind the definitions to move back to the finite graphs ")#mi("{G_n = (V_n,E_n)}")#text(". Observe that, when applied to the graph ")#mi("{\\hat G_n}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\tilde f_{U^\\perp}(1,2) = F_{U^\\perp,n}( v_1, v_2 )")]]

#text("where ")#mi("{F_{U,n}: V_n \\times V_n \\rightarrow [0,1]}")#text(" is a symmetric function which is constant on the pairs of cells ")#mi("{V^{M}_1,\\ldots,V^{M}_{2^{M}}}")#text(" generated the vertex neighbourhoods of ")#mi("{v_{-1},\\ldots,v_{-M}}")#text(". Similarly,")

#align(center)[#tao-fit-display[#mitex("\\tilde f_{U}(1,2) = F_{U,n}( v_1, v_2 )")]]

#text("for some symmetric function ")#mi("{F_{U,n}: V_n \\times V_n \\rightarrow [-1,1]}")#text(". The estimate ")#link(<tao-3f524cdc07a11d7c6220>)[#text("(2)")]#text(" can then be converted to a uniformity estimate on ")#mi("{F_{U,n}}")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} F_{U,n}(v_1,v_2) F_{U,n}(v_3,v_2) F_{U,n}(v_1,v_4) F_{U,n}(v_3,v_4) = O(\\tilde \\varepsilon^{\\prime})")]]

#text("while the estimate ")#link(<tao-e4ab4e3b1493d5a997b4>)[#text("(3)")]#text(" can be similarly converted to")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|1_{E_n}(v_1,v_2) - F_{U^\\perp,n}(v_1,v_2) - F_{U,n}(v_1,v_2)\\right| = O(\\tilde \\varepsilon).", block: true)]]

#text("If one then repeats the arguments in the preceding blog post, we conclude (if ")#mi("{\\tilde \\varepsilon}")#text(" is sufficiently small depending on ")#mi("{\\varepsilon}")#text(", and ")#mi("{\\tilde \\varepsilon^{\\prime}}")#text(" is sufficiently small depending on ")#mi("{\\varepsilon}")#text(", ")#mi("{\\tilde eps}")#text(", ")#mi("{M}")#text(") that for ")#mi("{1-\\varepsilon}")#text(" of the choices for ")#mi("{v_{-1},\\ldots,v_{-M}}")#text(", the partition ")#mi("{V^{M}_1,\\ldots,V^{M}_{2^{M}}}")#text(" induced by the corresponding vertex neighbourhoods will obey ")#link(<tao-667937c3e7a68ea37471>)[#text("(1)")]#text(". But this contradicts the construction of the ")#mi("{G_n}")#text(", and the claim follows.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The spectral proof of the Szemeredi regularity lemma « What’s new")]], [#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/#comment-199139")[#strong[#text("The spectral proof of the Szemeredi regularity lemma « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2012")])]

#text("[…] are many proofs of this lemma, which is actually not that difficult to establish; see for instance these previous blog posts for some examples. In this post I would like to record one further proof, based […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b300064aadcb4362ff0b39ff5c15b3747e5a7c23eeffe25b0bfd37f71104575-58068427667357743d50c54fa258e7b9f6c2c0ad555d1c3d8f37ebed96c5b91e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/#comment-460720")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2015")])]

#text("Hi Terry. When you say,")

#text("“One can also look at compound factors such as {{\\mathcal B}_I \\wedge {\\mathcal B}_J}, the factor generated by the union of {{\\mathcal B}_I} and {{\\mathcal B}_J}.”")

#text("Did you mean to say")

#text("“One can also look at compound factors such as {{\\mathcal B}_I \\vee {\\mathcal B}_J}, the factor generated by the union of {{\\mathcal B}_I} and {{\\mathcal B}_J}.”")

#text("Where I have replaced the \\wedge with the \\vee?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2009/05/08/szemeredis-regularity-lemma-via-the-correspondence-principle/#comment-478882")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] correspondence principle is discussed in these previous blog posts. One way to establish the principle is by introducing a Banach limit that extends the usual […]")
]
