// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/
// Converted to Typst by tao2typ: "2026-10-14T15:17:19.273232+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sumset and inverse sumset theorems for Shannon entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sumset and inverse sumset theorems for Shannon entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/")[#text("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("It turns out to be a favourable week or two for me to finally finish a number of papers that had been at a nearly completed stage for a while. I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my article “")#link("http://arxiv.org/abs/0906.4387")[#text("Sumset and inverse sumset theorems for Shannon entropy")]#text("“, submitted to ")#link("http://journals.cambridge.org/action/displayMoreInfo?jid=CPC&type=ifc")[#text("Combinatorics, Probability, and Computing")]#text(". This paper evolved from a “deleted scene” in ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(" entitled “")#link("http://www.math.ucla.edu/~tao/preprints/Expository/chapter_entropy.dvi")[#text("Entropy sumset estimates")]#text("“. In those notes, we developed analogues of the standard Plünnecke-Ruzsa sumset estimates (which relate quantities such as the cardinalities ")#tao-math("\\left|A+B\\right|, \\left|A-B\\right|", block: false)#text(" of the sum and difference sets of two finite sets ")#mi("A, B")#text(" in an additive group ")#mi("G")#text(" to each other), to the entropy setting, in which the finite sets ")#mi("A \\subset G")#text(" are replaced instead with discrete random variables ")#mi("X")#text(" taking values in that group G, and the (logarithm of the) cardinality |A| is replaced with the ")#link("http://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]

#align(center)[#tao-fit-display[#mitex("{\\textbf H}(X) := \\sum_{x \\in G} {\\Bbb P}(x \\in X) \\log \\frac{1}{{\\Bbb P}(x \\in X)}.")]]

#text("This quantity measures the information content of X; for instance, if ")#mi("{\\textbf H}(X) = k \\log 2")#text(", then it will take k bits on the average to store the value of X (thus a string of n independent copies of X will require about nk bits of storage in the asymptotic limit ")#mi("n \\to \\infty")#text("). The relationship between entropy and cardinality is that if X is the uniform distribution on a finite non-empty set A, then ")#tao-math("{\\textbf H}(X) = \\log \\left|A\\right|", block: false)#text(". If instead X is non-uniformly distributed on A, one has ")#tao-math("0 < {\\textbf H}(X) < \\log \\left|A\\right|", block: false)#text(", thanks to ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(".")

#text("It turns out that many estimates on sumsets have entropy analogues, which resemble the “logarithm” of the sumset estimates. For instance, the trivial bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right|, \\left|B\\right| \\leq \\left|A+B\\right| \\leq \\left|A\\right| \\left|B\\right|", block: true)]]

#text("have the entropy analogue")

#align(center)[#tao-fit-display[#mitex("{\\textbf H}(X), {\\textbf H}(Y) \\leq {\\textbf H}(X+Y) \\leq {\\textbf H}(X) + {\\textbf H}(Y)")]]

#text("whenever X, Y are independent discrete random variables in an additive group; this is not difficult to deduce from standard entropy inequalities. Slightly more non-trivially, the sum set estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|A+B\\right| \\leq \\frac{\\left|A-B\\right|^3}{\\left|A\\right| \\left|B\\right|}", block: true)]]

#text("established by Ruzsa, has an entropy analogue")

#align(center)[#mi("{\\textbf H}(X+Y) \\leq 3 {\\textbf H}(X-Y) - {\\textbf H}(X) - {\\textbf H}(Y)")#text(",")]

#text("and similarly for a number of other standard sumset inequalities in the literature (e.g. the Rusza triangle inequality, the Plünnecke-Rusza inequality, and the Balog-Szemeredi-Gowers theorem, though the entropy analogue of the latter requires a little bit of care to state). These inequalities can actually be deduced fairly easily from elementary arithmetic identities, together with standard entropy inequalities, most notably the ")#emph[#text("submodularity inequality")]

#align(center)[#tao-fit-display[#mitex("{\\textbf H}(Z) + {\\textbf H}(W) \\leq {\\textbf H}(X) + {\\textbf H}(Y)")]]

#text("whenever X,Y,Z,W are discrete random variables such that X and Y each determine W separately (thus ")#mi("W = f(X) = g(Y)")#text(" for some deterministic functions f, g) and X and Y determine Z jointly (thus ")#mi("Z = h(X,Y)")#text(" for some deterministic function f). For instance, if X,Y,Z are independent discrete random variables in an additive group G, then ")#mi("(X-Y,Y-Z)")#text(" and ")#mi("(X,Z)")#text(" each determine ")#mi("X-Z")#text(" separately, and determine ")#mi("X,Y,Z")#text(" jointly, leading to the inequality")

#align(center)[#tao-fit-display[#mitex("{\\textbf H}(X,Y,Z) + {\\textbf H}(X-Z) \\leq {\\textbf H}(X-Y,Y-Z) + {\\textbf H}(X,Z)")]]

#text("which soon leads to the ")#emph[#text("entropy Rusza triangle inequality")]

#align(center)[#tao-fit-display[#mitex("{\\textbf H}(X-Z) \\leq {\\textbf H}(X-Y) + {\\textbf H}(Y-Z) - {\\textbf H}(Y)")]]

#text("which is an analogue of the combinatorial Ruzsa triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|A-C\\right| \\leq \\frac{\\left|A-B\\right| \\left|B-C\\right|}{\\left|B\\right|}.", block: true)]]

#text("All of this was already in the unpublished notes with Van, though I include it in this paper in order to place it in the literature. The main novelty of the paper, though, is to consider the entropy analogue of Freiman’s theorem, which classifies those sets A for which ")#tao-math("\\left|A+A\\right| = O(\\left|A\\right|)", block: false)#text(". Here, the analogous problem is to classify the random variables ")#mi("X")#text(" such that ")#mi("{\\textbf H}(X_1+X_2) = {\\textbf H}(X) + O(1)")#text(", where ")#mi("X_1,X_2")#text(" are independent copies of X. Let us say that X has ")#emph[#text("small doubling")]#text(" if this is the case.")

#text("For instance, the uniform distribution U on a finite subgroup H of G has small doubling (in fact ")#tao-math("{\\textbf H}(U_1+U_2)={\\textbf H}(U) = \\log \\left|H\\right|", block: false)#text(" in this case). In a similar spirit, the uniform distribution on a (generalised) arithmetic progression P also has small doubling, as does the uniform distribution on a coset progression H+P. Also, if X has small doubling, and Y has bounded entropy, then X+Y also has small doubling, even if Y and X are not independent. The main theorem is that these are the only cases:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Informal statement) X has small doubling if and only if ")#mi("X = U + Y")#text(" for some uniform distribution U on a coset progression (of bounded rank), and Y has bounded entropy.")
]

#text("For instance, suppose that X was the uniform distribution on a dense subset A of a finite group G. Then Theorem 1 asserts that X is close in a “transport metric” sense to the uniform distribution U on G, in the sense that it is possible to rearrange or transport the probability distribution of X to the probability distribution of U (or vice versa) by shifting each component of the mass of X by an amount Y which has bounded entropy (which basically means that it primarily ranges inside a set of bounded cardinality). The way one shows this is by randomly translating the mass of X around by a few random shifts to approximately uniformise the distribution, and then deal with the residual fluctuation in the distribution by hand. Theorem 1 as a whole is established by using the Freiman theorem in the combinatorial setting combined with various elementary convexity and entropy inequality arguments to reduce matters to the above model case when X is supported inside a finite group G and has near-maximal entropy.")

#text("I also show a variant of the above statement: if X, Y are independent and ")#mi("{\\textbf H}(X+Y) = {\\textbf H}(X)+O(1) = {\\textbf H}(Y)+O(1)")#text(", then we have ")#mi("X \\equiv Y+Z")#text(" (i.e. X has the same distribution as Y+Z for some Z of bounded entropy (not necessarily independent of X or Y). Thus if two random variables are additively related to each other, then they can be additively transported to each other by using a bounded amount of entropy.")

#text("In the last part of the paper I relate these discrete entropies to their continuous counterparts")

#align(center)[#tao-fit-display[#mitex("{\\textbf H}_{\\Bbb R}(X) := \\int_{{\\Bbb R}} p(x) \\log \\frac{1}{p(x)}\\ dx,")]]

#text("where X is now a continuous random variable on the real line with density function ")#mi("p(x)\\ dx")#text(". There are a number of sum set inequalities known in this setting, for instance")

#align(center)[#mi("{\\textbf H}_{\\Bbb R}(X_1 + X_2) \\geq {\\textbf H}_{\\Bbb R}(X) + \\frac{1}{2} \\log 2")#text(",")]

#text("for independent copies ")#mi("X_1,X_2")#text(" of a finite entropy random variable X, with equality if and only if X is a Gaussian. Using this inequality and Theorem 1, I show a discrete version, namely that")

#align(center)[#mi("{\\textbf H}(X_1 + X_2) \\geq {\\textbf H}(X) + \\frac{1}{2} \\log 2 - \\varepsilon")#text(",")]

#text("whenever ")#mi("\\varepsilon> 0")#text(" and ")#mi("X_1,X_2")#text(" are independent copies of a random variable in ")#mi("{\\Bbb Z}")#text(" (or any other torsion-free abelian group) whose entropy is sufficiently large depending on ")#mi("\\varepsilon")#text(". This is somewhat analogous to the classical sumset inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|A+A\\right| \\geq 2 \\left|A\\right| - 1", block: true)]]

#text("though notice that we have a gain of just ")#mi("\\frac{1}{2} \\log 2")#text(" rather than ")#mi("\\log 2")#text(" here, the point being that there is a Gaussian counterexample in the entropy setting which does not have a combinatorial analogue (except perhaps in the high-dimensional limit). The main idea is to use Theorem 1 to trap most of X inside a coset progression, at which point one can use Fourier-analytic additive combinatorial tools to show that the distribution ")#mi("X_1+X_2")#text(" is “smooth” in some non-trivial direction r, which can then be used to approximate the discrete distribution by a continuous one.")

#text("I also conjecture more generally that the entropy monotonicity inequalities established ")#link("http://www.cims.nyu.edu/~naor/homepage%20files/growth.pdf")[#text("by Artstein, Barthe, Ball, and Naor")]#text(" in the continuous case also hold in the above sense in the discrete case, though my method of proof breaks down because I no longer can assume small doubling.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-39751")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2009")])]

#text("Dear Professor Tao,")

#text("“It turns out to be a favourable week or two for me to finally finish a number of papers that had been at a nearly completed stage for a while. ”")

#text("I would imagine that summer is a more productive time as you don’t have to put up with your students.")

#text("More seriously, does the similarity in form between the estimates involving the discrete Shannon entropy and the sumsets estimates of finite subsets of an additive group hold when you consider their continuous counterparts? Where I’m assuming the continuous analog is when we replace finite subsets of an additive group by Lebesgue measurable sets and instead of considering cardinality, we consider the Lebesgue measure.")

#text("Thanks for any reply,")#linebreak()#text(" Max")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-39763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Yes, the discrete sumset and entropy results can be used to derive continuous counterparts by discretising the latter at some small spatial scale ")#mi("\\delta > 0")#text(" and then sending that scale to zero.")

#text("The converse procedure is less clear though; there are some continuous entropy results (such as those of Artstein, Barthe, Ball and Naor mentioned above) which I was not able to easily convert to the discrete setting. (If one approximates a discrete random variable by a continuous counterpart, by adding a small amount of gaussian noise, this noise expands under addition and will eventually contribute unwanted correction terms such as ")#mi("\\frac{1}{2} \\log 2")#text(" to entropy sumset inequlaities.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-42653")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Professor Tao:")#linebreak()#text(" Regarding the continuous counter part to entropy, I have a comment. Continuous entropy is not usually well behaved. It can be negative, is not invariant to scaling, even worse there is no renormalized entropy in the sense that self entropy can be given a value of infinity. Given this could the results be still transferred? I would be interested in the continuous counterpart. Has anyone worked on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-42654")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("I apologize I did not read the ending comments on the blog.")

#text("But I think scale invariant and normalized continuous entropy would be an useful tool to information theorists.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6901e6f3a4aeff0c9e65a571b3513ba18cd5a2cf1123618d90eced15b554cae4-0dec33f410a763d82075e508bb8e1c6467df7189ee3996462be6e18d41e0b168.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YP")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-43739")[#strong[#text("YP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2010")])]

#text("Perhaps one way is to consider Kullback-Leibler divergence D(P||Q), where Q is something nice absolutely-continuous (e.g. N(0,1) gaussian); instead of H_R(P), which is simply a -D(P||Leb). The bad properties of H_R(P) come from the fact that you take divergence w.r.t. to a non-probability measure.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of link")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-39752")[#strong[#text("link")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2009")])]

#text("you can easily replace the Shannon entropy with the standard measurement of information in quantum states (a.f., S = ln N).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An entropy Plünnecke-Ruzsa inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-42054")[#strong[#text("An entropy Plünnecke-Ruzsa inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("[…] a recent paper, I adapted a number of sum set estimates to the entropy setting, in which finite sets such as in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LifeIsChill")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-47642")[#strong[#text("LifeIsChill")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("Let $\\mathbb N_{n} = \\{1,2,\\cdots,n\\}$.")

#text("Let $S$ be of cardinality $n$ where elements of $S$ are integers from $\\mathbb N_{n}$ and at least one element of $S$ is repeated (That is at least one integer from $\\mathbb N_{n}$ is skipped. One can easily find a set $S$ with the property that:")#linebreak()#text(" $\\displaystyle \\sum_{j \\in S}j^{i} = \\displaystyle \\sum_{j \\in \\mathbb N_{n}j^{i}$")#linebreak()#text(" when $i = 1$.")

#text("How about for $i \\ge 2$? It is not obvious that higher power sum sets exist due to constraint in the cardinality of $S$ and $\\mathbb N_{n}$. One cannot deny it either? Is there a easy way to tackle some sumset questions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-166789")[#strong[#text("On the entropy of a sum | MoVn - Linux Ubuntu Center")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2012")]

#text("[…] short, the bound $(*)$ overshoots by quite a bit in this situation. From perusing this blog post, I gather all sorts of bounds on $H(X+Y)$ are possible; is there a bound that gives the right […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-170430")[#strong[#text("On the entropy of a sum | Q&A System")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2012")]

#text("[…] a nutshell, the bound $(*)$ overshoots by a great deal in cases like this. From perusing this web site publish, I gather a variety of bounds on $H(X Y)$ are possible it is possible to bound that provides the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy and Sumsets: An example | George Shakan")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-503359")[#strong[#text("Entropy and Sumsets: An example | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2018")])]

#text("[…] of sumset inequalities hold and sometimes they do not (see this paper of Ruzsa or this paper this paper of Tao, or a host of work by Madiman and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-687460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("At the very end (Equation 6.15), I do understand how we conclude this proof. We need to restrict ")#mi("w_1, w_2")#text(" as follows:")

#mi("\\text{dist}_{TV}(X_{i,w_i} + 1, X_{i,w_i}) \\leq \\mu^{1/2}")

#text("for ")#mi("i = 1,2")#text(".")

#text("Then, we should repeat the arguments from the ")#mi("m = 1")#text(" case. But shouldn’t we have a hypothesis of the form:")

#mi("\\text{dist}_{TV}(X_{1,w_1} + X_{2,w_2} + 1, X_{1,w_1} + X_{2,w_2}) \\leq \\mu^{1/2}")

#text("to properly repeat the argument seen earlier?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-687462")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2025")])]

#text("The former estimate implies the latter (first condition on say ")#mi("X_{2,w_2}")#text(" to be constant, and then undo the conditioning using the triangle inequality).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-688962")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2025")])]

#text("Forgive my possibly trivial questions, but on page 26 of (the newest version) of this paper, when we invoke Theorem 1.9 of Tao–Vu (2008) to obtain a proper progression ")#mi("Q")#text(", is it obvious that we don’t need to worry about the symmetric assumptions of the GAPs in that paper? (I’m having trouble visualising the translation that would be required to “symmetrise” a GAP, do we just subtract the average?) I am also wondering about why we need ")#mi("Q")#text(" to be 4-proper. I believe the subsequent Freiman isomorphism only requires ")#mi("Q")#text(" to be 2-proper, and then maybe the embedding in Lemma 6.1 requires it to be 3-proper?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-688969")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2025")])]

#text("A non-symmetric GAP is of the form ")#mi("Q = a_0 + Q^{\\prime}")#text(" with ")#mi("Q^{\\prime}")#text(" a symmetric GAP (let’s say that all the sidelengths are odd for simplicity), and this is contained inside the symmetric GAP ")#mi("\\{-a_0,0,a_0\\} + Q^{\\prime}")#text(" which is only three times larger at most. If some sidelengths are even instead of odd then one has to enlarge them by one, but this also does not make a noticeable impact on the sizes.")

#text("It’s possible that one could reduce the parameter 4 to 3 or 2; as we were not tracking unspecified constants, I generally adopt the practice of adding a “safety margin” when such constants are introduced, precisely to deal with minor issues such as the one above.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d37acd3168f51540e6f38022029d25d6912cf600e66026775fe28f39dc61ed-5e143e4b26fd6214f13b243ac760d24309e2bbc14b5bbb38aaf788abdd0b3b75.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roelofvandijk")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-692465")[#strong[#text("roelofvandijk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2026")])]

#text("Dear Prof. Tao, I tried to work through the paper fully and got stuck on how 70 follows directly from 66. It would be very useful for a proof of mine if it did, but it seems stronger (and stronger than needed). Am I missing a constraint stated elsewhere in the paper?")

#text("I asked a frontier LLM the same question, which did not help to resolve the issue: ")#link("https://chatgpt.com/share/69f5edd3-6eb0-83eb-bff1-cc79eac2bd35")[#text("https://chatgpt.com/share/69f5edd3-6eb0-83eb-bff1-cc79eac2bd35")]

#text("Apologies in advance if I am missing something obvious here, which is not unlikely at all.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/25/sumset-and-inverse-sumset-theorems-for-shannon-entropy/#comment-692480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2026")])]

#text("This was a typo. As in the ")#mi("m=1")#text(" case, one should be controlling the sum ")#mi("X_{1,w_1}+X_{2,w_2}")#text(" here rather than the individual ")#mi("X_{i,w_i}")#text(" (and so the single sum in (70) should be a double sum with the appropriate weighting).")
]
]
