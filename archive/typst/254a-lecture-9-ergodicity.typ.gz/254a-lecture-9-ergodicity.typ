// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/
// Converted to Typst by tao2typ: "2026-10-14T06:53:11.888735+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 9: Ergodicity", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 9: Ergodicity")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("We continue our study of basic ergodic theorems, establishing the maximal and pointwise ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("ergodic theorems")]#text(" of Birkhoff. Using these theorems, we can then give several equivalent notions of the fundamental concept of ")#link("http://en.wikipedia.org/wiki/Ergodic_%28adjective%29")[#text("ergodicity")]#text(", which (roughly speaking) plays the role in measure-preserving dynamics that minimality plays in topological dynamics. A general measure-preserving system is not necessarily ergodic, but we shall introduce the ")#emph[#text("ergodic decomposition")]#text(", which allows one to express any non-ergodic measure as an average of ergodic measures (generalising the decomposition of a permutation into disjoint cycles).")

#metadata(none) <tao-3f3339c34b805dd8a52f>

#heading(level: 1)[#text("— The maximal ergodic theorem —")]

#text("Just as we derived the mean ergodic theorem from the more abstract von Neumann ergodic theorem in the ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("previous lecture")]#text(", we shall derive the maximal ergodic theorem from the following abstract maximal inequality.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". (Dunford-Schwartz maximal inequality) Let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a probability space, and let ")#mi("P: L^1(X,{\\mathcal X},\\mu) \\to L^1(X,{\\mathcal X},\\mu)")#text(" be a linear operator with P1=1 and ")#mi("P^* 1 = 1")#text(" (i.e. ")#mi("\\int_X Pf\\ d\\mu = \\int_X f\\ d\\mu")#text(" for all ")#mi("f \\in L^1(X,{\\mathcal X},\\mu)")#text(". Assume also that P maps non-negative functions to non-negative functions. Then the maximal function ")#mi("Mf := \\sup_{N > 0} \\frac{1}{N} \\sum_{n=0}^{N-1} P^n f")#text(" obeys the inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lambda \\mu( \\{ Mf > \\lambda \\} ) \\leq \\int_{Mf > \\lambda} f\\ d\\mu")]]

#text("for any ")#mi("\\lambda \\in {\\Bbb R}")#text(".")
]

#strong[#text("Proof.")]#text(" We can rewrite (1) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_{Mf - \\lambda > 0} (f-\\lambda)\\ d\\mu \\geq 0.")]]

#text("Since ")#mi("Mf-\\lambda = M(f-\\lambda)")#text(", we thus see (by replacing f with ")#mi("f-\\lambda")#text(") that we can reduce to proving (2) in the case ")#mi("\\lambda=0")#text(".")

#text("For every ")#mi("m \\geq 1")#text(", consider the modified maximal function ")#mi("F_m := \\sup_{0 \\leq N \\leq m} \\sum_{n=0}^{N-1} P^n f")#text(". Observe that ")#mi("Mf(x) > 0")#text(" if and only if ")#mi("F_m(x) > 0")#text(" for all sufficiently large m. By the dominated convergence theorem, it thus suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_{F_m > 0} f\\ d\\mu \\geq 0")]]

#text("for all m. But observe from definition of ")#mi("F_m")#text(" (and the positivity preserving nature of P) that we have the pointwise recursive inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F_m(x) \\leq F_{m+1}(x) = \\max( 0, f + P F_m(x) ).")]]

#text("Integrating this on the region ")#mi("F_m > 0")#text(" and using the non-negativity of ")#mi("F_m")#text(", we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\int_X F_m\\ d\\mu \\leq \\int_{F_m > 0} f + \\int_X P F_m\\ d\\mu.")]]

#text("Since ")#mi("F_m \\in L^1(X,{\\mathcal X},\\mu)")#text(" and ")#mi("P^* 1 = 1")#text(", the claim follows. ")#mi("\\Box")

#text("Applying this in the case when P is a shift operator, and replacing f by |f|, we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text(" (Maximal ergodic theorem) Let ")#mi("(X,{\\mathcal X},\\mu,T)")#text(" be a measure-preserving system. Then for any ")#mi("f \\in L^1(X,{\\mathcal X},\\mu)")#text(" and ")#mi("\\lambda > 0")#text(" one has")

#tao-math("\\mu( \\{ \\sup_N \\frac{1}{N} \\sum_{n=0}^{N-1} \\left|T^n f\\right| > \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\left\\|f\\right\\|_{L^1(X,{\\mathcal X},\\mu)}", block: false)#text(". (7)")
]

#text("Note that this inequality implies ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\mu( \\{ \\left|f\\right| > \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_X |f|\\ d\\mu.", block: true)]]

#text("as a special case. Applying the ")#link("http://en.wikipedia.org/wiki/Marcinkiewicz_theorem")[#text("real interpolation method")]#text(", one also easily deduces the maximal inequality")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| \\sup_N \\frac{1}{N} \\sum_{n=0}^{N-1} \\left|T^n f\\right| \\right\\|_{L^p(X,{\\mathcal X},\\mu)} \\leq C_p \\left\\|f\\right\\|_{L^p(X,{\\mathcal X},\\mu)}", block: true)]]

#text("for all ")#mi("1 < p \\leq \\infty")#text(", where the constant ")#mi("C_p")#text(" depends on p (it blows up like ")#mi("O(1/(p-1))")#text(" in the limit ")#mi("p \\to 1")#text(").")

#strong[#text("Exercise 1")]#text(" (Rising sun inequality). If ")#mi("f \\in l^1({\\Bbb Z})")#text(", and ")#mi("f^*(m) := \\sup_N \\frac{1}{N} \\sum_{n=0}^{N-1} f(m+n)")#text(", establish the ")#emph[#text("rising sun inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\lambda \\left| \\{ m \\in {\\Bbb Z}: f^*(m) > \\lambda \\}\\right| \\leq \\sum_{m \\in {\\Bbb Z}: f^*(m) > \\lambda} f(m)", block: true)]]

#text("for any ")#mi("\\lambda > 0")#text(". (")#emph[#text("Hint")]#text(": one can either adapt the proof of Theorem 1, or else partition the set appearing in (10) into disjoint intervals. The latter proof also leads to a proof of Corollary 1 which avoids the Dunford-Schwartz trick of introducing the functions ")#mi("F_m")#text(". The terminology “rising sun” comes from seeing how these intervals interact with the graph of the partial sums of f, which resembles the shadows cast on a hilly terrain by a rising sun.) ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" (Transference principle) Show that Corollary 1 can be deduced directly from (10). (")#emph[#text("Hint")]#text(": given ")#mi("f \\in L^1(X, {\\mathcal X},\\mu)")#text(", apply (10) to the functions ")#mi("f_x(n) := T^n f(x)")#text(" for each ")#mi("x \\in X")#text(" (truncating the integers to a finite set if necessary), and then integrate in x using Fubini’s theorem.) This is an example of a ")#emph[#text("transference principle")]#text(" between maximal inequalities on ")#mi("{\\Bbb Z}")#text(" and maximal inequalities on measure-preserving systems. ")#mi("\\diamond")

#strong[#text("Exercise 3")]#text(" (")#link("http://www.ams.org/mathscinet-getitem?mr=727348")[#text("Stein-Stromberg maximal inequality")]#text("). Derive a continuous version of the Dunford-Schwartz maximal inequality, in which the operators ")#mi("P^n")#text(" are replaced by a semigroup ")#mi("P_t")#text(" acting on both ")#mi("L^1")#text(" and ")#mi("L^\\infty")#text(", in which the underlying measure space is only assumed to be ")#mi("\\sigma")#text("-finite rather than a probability space, and the averages ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} P^n")#text(" are replaced by ")#mi("\\frac{1}{T} \\int_0^T P^t\\ dt")#text(". Apply this continuous version with ")#mi("P_t := e^{t\\Delta}")#text(" equal to the heat operator on ")#mi("{\\Bbb R}^d")#text(" for ")#mi("d \\geq 1")#text(" to deduce the ")#emph[#text("Stein-Stromberg maximal inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("m( \\{ x \\in {\\Bbb R}^d: \\sup_{R > 0} \\frac{1}{m(B(x,R))} \\int_{B(x,r)} |f|\\ dm> \\lambda \\} ) \\leq \\frac{Cd}{\\lambda} \\left\\| f \\right\\|_{L^1({\\Bbb R}^d, dm)}", block: true)]]

#text("for all ")#mi("\\lambda > 0")#text(" and ")#mi("f \\in L^1({\\Bbb R}^d, dm)")#text(", where m is Lebesgue measure, ")#mi("B(x,R)")#text(" is the Euclidean ball of radius R centred at x, and the constant C is absolute (independent of d). This improves upon the ")#link("http://en.wikipedia.org/wiki/Maximal_function")[#text("Hardy-Littlewood maximal inequality")]#text(", which gives the same estimate but with ")#mi("Cd")#text(" replaced by ")#mi("C^d")#text(". It is an open question whether the dependence on d can be removed entirely; the estimate (11) is still the best known in high dimension. For d=1, the best constant C is known to be ")#mi("\\frac{11+\\sqrt{61}}{12}=1.567\\ldots")#text(", a result ")#link("http://www.ams.org/mathscinet-getitem?mr=1973058")[#text("of Melas")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" The study of maximal inequalities in ergodic theory is, of course, a subject in itself; a classical reference is this ")#link("http://www.ams.org/mathscinet-getitem?mr=252961")[#text("monograph of Stein")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— The pointwise ergodic theorem —")]

#text("Using the maximal ergodic theorem and a standard limiting argument we can now deduce")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (Pointwise ergodic theorem). Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let ")#mi("f \\in L^1(X, {\\mathcal X}, \\mu)")#text(". Then for ")#mi("\\mu")#text("-almost every ")#mi("x \\in X")#text(", ")#mi("\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f(x)")#text(" converges to ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)(x)")#text(".")
]

#strong[#text("Proof.")]#text(" By subtracting ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)")#text(" from f if necessary, it suffices to show that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\limsup_{N \\to \\infty} \\left|\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f(x)\\right| = 0", block: true)]]

#text("a.e. whenever ")#mi("{\\Bbb E}(f|{\\mathcal X}^T) = 0")#text(". By telescoping series, (12) is already true when f takes the form ")#mi("f=Tg-g")#text(" for some ")#mi("g \\in L^\\infty(X,{\\mathcal X},\\mu)")#text(". So by the arguments used to prove the von Neumann ergodic theorem from the ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("previous lecture")]#text(", we have already established the claim for a dense class of functions f in ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" with ")#mi("{\\Bbb E}(f|{\\mathcal X}^T) = 0")#text(", and thus also for a dense class of functions in ")#mi("L^1(X,{\\mathcal X},\\mu)")#text(" with ")#mi("{\\Bbb E}(f|{\\mathcal X}^T) = 0")#text(" (since the latter space is dense in the former, and the ")#mi("L^2")#text(" norm controls the ")#mi("L^1")#text(" norm by the Cauchy-Schwarz inequality).")

#text("Now we use a standard limiting argument. Let ")#mi("f \\in L^1(X,{\\mathcal X},\\mu)")#text(" with ")#mi("{\\Bbb E}(f|{\\mathcal X}^T) = 0")#text(". Then we can find a sequence ")#mi("f_j")#text(" in the above dense class which converges in ")#mi("L^1")#text(" to f. For almost every x, we thus have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\lim_{N \\to \\infty} \\left|\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f_j(x)\\right| = 0", block: true)]]

#text("for all j, and so by the triangle inequality we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\limsup_{N \\to \\infty} \\left|\\frac{1}{N} \\sum_{n=0}^{N-1} T^n f(x)\\right| \\leq \\sup_N \\frac{1}{N} \\sum_{n=0}^{N-1} T^n |f-f_j|(x).", block: true)]]

#text("But by Corollary 1 we see that the right-hand side of (14) converges to zero in measure as ")#mi("j \\to \\infty")#text(". Since the left-hand side does not depend on j, it must vanish almost everywhere, as required. ")#mi("\\Box")

#strong[#text("Remark 2. ")]#text(" More generally, one can derive a pointwise convergence result on a class of rough functions by first establishing convergence for a dense subclass of functions, and then establishing a maximal inequality which is strong enough to allow one to take limits and establish pointwise convergence for all functions in the larger class. Conversely, principles such as ")#link("http://www.ams.org/mathscinet-getitem?mr=125392")[#text("Stein’s maximal principle")]#text(" indicate that in many cases this is in some sense the ")#emph[#text("only")]#text(" way to establish such pointwise convergence results for rough functions. ")#mi("\\diamond")

#strong[#text("Remark 3. ")]#text(" Using the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(" (starting first with bounded functions f in order to get the domination), one can deduce the mean ergodic theorem from the pointwise ergodic theorem. But the converse is significantly more difficult; pointwise convergence for various ergodic averages is often a much harder result to establish than the corresponding norm convergence result (in particular, many of the techniques discussed in this course appear to be of sharply limited utility for pointwise convergence problems), and many questions in this area remain open. ")#mi("\\diamond")

#strong[#text("Exercise 4")]#text(" (Lebesgue differentiation theorem). Let ")#mi("f \\in L^1({\\Bbb R}^d, dm)")#text(" with Lebesgue measure dm. Show that for almost every ")#mi("x \\in {\\Bbb R}^d")#text(", we have ")#mi("\\lim_{r \\to 0^+} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)-f(x)|\\ dy = 0")#text(", and in particular that ")#mi("\\lim_{r \\to 0^+} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} f(y)\\ dy = f(x)")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Ergodicity —")]

#text("Combining the mean ergodic theorem with the pointwise ergodic theorem (and with Exercises 7, 8 from the ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("previous lecture")]#text(") we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" (Characterisations of ergodicity) Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system. Then the following are equivalent:")

#enum(start: 1, 
[#text("Any set ")#mi("E \\in {\\mathcal X}")#text(" which is invariant (thus TE=E) has either full measure ")#mi("\\mu(E)=1")#text(" or zero measure ")#mi("\\mu(E)=0")#text(".")],
[#text("Any set ")#mi("E \\in {\\mathcal X}")#text(" which is almost invariant (thus TE differs from E by a null set) has either full measure or zero measure.")],
[#text("Any measurable function f with ")#mi("Tf = f")#text(" a.e. is constant a.e.")],
[#text("For any ")#mi("1 < p < \\infty")#text(" and ")#mi("f \\in L^p(X,{\\mathcal X},\\mu)")#text(", the averages ")#mi("\\frac{1}{N} \\sum_{n=0}^N T^n f")#text(" converge in ")#mi("L^p")#text(" norm to ")#mi("\\int_X f")#text(".")],
[#text("For any two ")#mi("f, g \\in L^\\infty(X, {\\mathcal X}, \\mu)")#text(", we have ")#mi("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N \\int_X (T^n f) g\\ d\\mu = (\\int_X f\\ d\\mu) (\\int_X g\\ d\\mu)")#text(".")],
[#text("For any two measurable sets E and F, we have ")#mi("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N \\mu(T^n E \\cap F) = \\mu(E) \\mu(F)")#text(".")],
[#text("For any ")#mi("f \\in L^1(X, {\\mathcal X},\\mu)")#text(", the averages ")#mi("\\frac{1}{N} \\sum_{n=0}^N T^n f")#text(" converge pointwise almost everywhere to ")#mi("\\int_X f\\ d\\mu")#text(".")]
)
]

#text("A measure-preserving system with any (and hence all) of the above properties is said to be ")#emph[#text("ergodic")]#text(".")

#strong[#text("Remark 4. ")]#text(" Strictly speaking, ergodicity is a property that applies to a measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(". However, we shall sometimes abuse notation and apply the adjective “ergodic” to a single component of a system, such as the measure ")#mi("\\mu")#text(" or the shift T, when the other three components of the system are clear from context. ")#mi("\\diamond")

#text("Here are some simple examples of ergodicity:")

#strong[#text("Example 1.")]#text(" If X is finite with uniform measure, then a shift map ")#mi("T: X \\to X")#text(" is ergodic if and only if it is a cycle. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" If a shift T is ergodic, then so is ")#mi("T^{-1}")#text(". However, from Example 1 we see that it is not necessarily true that ")#mi("T^n")#text(" is ergodic for all n (this latter property is also known as ")#emph[#text("total ergodicity")]#text("). ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Show that the circle shift ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" (with the usual Lebesgue measure) is ergodic if and only if ")#mi("\\alpha")#text(" is irrational. (")#emph[#text("Hint")]#text(": analyse the equation ")#mi("Tf=f")#text(" for (say) ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" using Fourier analysis. ")#emph[#text("Added")]#text(", Feb 21: As pointed out to me in class, another way to proceed is to use the Lebesgue density theorem (or Lebesgue differentiation theorem) combined with Exercise 14 from ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("Lecture 6")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Let ")#mi("(\\Omega,{\\mathcal B},\\mu)")#text(" be a ")#link("http://en.wikipedia.org/wiki/Borel_set#Standard_Borel_spaces_and_Kuratowski_theorems")[#text("standard Borel")]#text(" probability space. Show that the Bernoulli shift on the product system ")#mi("(\\Omega^{\\Bbb Z}, {\\mathcal B}^{\\Bbb Z}, \\mu^{\\Bbb Z})")#text(" is ergodic. (")#emph[#text("Hint")]#text(": first establish property 6 of Theorem 3 when E and F each depend on only finitely many of the coordinates of ")#mi("\\Omega^{\\Bbb Z}")#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 7.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be an ergodic system. Show that if ")#mi("\\lambda")#text(" is an eigenvalue of ")#mi("T: L^2(X, {\\mathcal X}, \\mu) \\to L^2(X, {\\mathcal X}, \\mu)")#text(", then ")#tao-math("\\left|\\lambda\\right|=1", block: false)#text(", the eigenspace ")#mi("\\{ f \\in L^2(X, {\\mathcal X}, \\mu): Tf = \\lambda f \\}")#text(" is one-dimensional, and that every eigenfunction f has constant magnitude |f| a.e.. Show that the the eigenspaces are orthogonal to each other in ")#mi("L^2(X, {\\mathcal X}, \\mu)")#text(", and the set of all eigenvalues of T forms an at most countable subgroup of the unit circle ")#mi("S^1")#text(". ")#mi("\\diamond")

#text("Now we give a less trivial example of an ergodic system.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("(Ergodicity of skew shift) Let ")#mi("\\alpha \\in {\\Bbb R}")#text(" be irrational. Then the skew shift ")#mi("(({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha,y+x))")#text(" is ergodic.")
]

#strong[#text("Proof.")]#text(" Write the skew shift system as ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(". To simplify the notation we shall omit the phrase “almost everywhere” in what follows.")

#text("We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=260975")[#text("of Parry")]#text(". If the system is not ergodic, then we can find a non-constant ")#mi("f \\in L^2(X, {\\mathcal X}, \\mu)")#text(" such that Tf = f. Next, we use Fourier analysis to write ")#mi("f = \\sum_m f_m")#text(", where ")#mi("f_m(x,y) := \\int_{{\\Bbb R}/{\\Bbb Z}} f(x,y+\\theta) e^{-2\\pi i m\\theta}\\ d\\theta")#text(". Since f is T-invariant, and the vertical rotations ")#mi("(x,y) \\mapsto (x,y+\\theta)")#text(" commute with T, we see that the ")#mi("f_m")#text(" are also T-invariant. The function ")#mi("f_0")#text(" depends only on the x variable, and so is constant by Exercise 5. So it suffices to show that ")#mi("f_m")#text(" is zero for all non-zero m.")

#text("Fix m. We can factorise ")#mi("f_m(x,y) = F_m(x) e^{2\\pi i my}")#text(". The T-invariance of ")#mi("f_m")#text(" now implies that ")#mi("F_m(x+\\alpha) = e^{-2\\pi i mx} F_m(x)")#text(". If we then define ")#mi("F_{m,\\theta} := F_m(x+\\theta) \\overline{F_m(x)}")#text(" for ")#mi("\\theta \\in {\\Bbb R}")#text(", we see that ")#mi("F_{m,\\theta}(x+\\alpha) = e^{-2\\pi i m \\theta} F_{m,\\theta}(x)")#text(", thus ")#mi("F_{m,\\theta}")#text(" is an eigenfunction of the circle shift with eigenvalue ")#mi("e^{-2\\pi i m \\theta}")#text(". But this implies (by Exercise 7) that ")#mi("F_{m,\\theta}")#text(" is orthogonal to ")#mi("F_{m,0}")#text(" for ")#mi("\\theta")#text(" close to zero. Taking limits we see that ")#mi("F_{m,0}")#text(" is orthogonal to itself and must vanish; this implies that ")#mi("F_m")#text(" and hence ")#mi("f_m")#text(" vanish as well, as desired. ")#mi("\\Box")

#strong[#text("Exercise 8")]#text(". Show that for any irrational ")#mi("\\alpha")#text(" and any ")#mi("d \\geq 1")#text(", the iterated skew shift system ")#mi("({\\Bbb R}/{\\Bbb Z}^d, (x_1,\\ldots,x_d) \\to (x_1+\\alpha,x_2+x_1,\\ldots,x_d+x_{d-1}))")#text(" is ergodic. ")#mi("\\diamond")

#heading(level: 1)[#text("— Generic points —")]

#text("Now let us suppose that we have a topological measure preserving system ")#mi("(X, {\\mathcal F}, \\mu, T)")#text(", i.e. a measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" which is also a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(", with ")#mi("{\\mathcal X}")#text(" the ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("Borel")]#text(" ")#mi("\\sigma")#text("-algebra of T. Then we have the space C(X) of continuous (real or complex-valued) functions on X, which is dense inside ")#mi("L^2(X)")#text(". From the ")#link("http://en.wikipedia.org/wiki/Stone-Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" we also see that C(X) is separable.")

#text("A sequence ")#mi("x_1, x_2, x_3, \\ldots")#text(" in X is said to be ")#emph[#text("uniformly distributed")]#text(" with respect to ")#mi("\\mu")#text(" if we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N f(x_n) = \\int_X f\\ d\\mu")]]

#text("for all ")#mi("f \\in C(X)")#text(". A point x in X is said to be ")#emph[#text("generic")]#text(" if the forward orbit ")#mi("x, Tx, T^2 x, \\ldots")#text(" is uniformly distributed.")

#strong[#text("Exercise 9. ")]#text("Let ")#mi("(X, {\\mathcal F},\\mu)")#text(" be a compact metrisable space with a Borel probability measure ")#mi("\\mu")#text(", and let ")#mi("x_1,x_2,\\ldots")#text(" be a sequence in X. Show that this sequence is uniformly distributed if and only if ")#tao-math("\\lim_{N \\to \\infty} \\frac{1}{N} \\left|\\{ 1\\leq i \\leq N: x_i \\in U\\}\\right| = \\mu(U)", block: false)#text(" for all open sets U in X with ")#mi("\\mu(\\partial U)=0")#text(". What happens if the hypothesis that the boundary of ")#mi("U")#text(" has measure zero is removed? ")#mi("\\diamond")

#text("From Theorem 3 and the separability of C(X) we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" A topological measure-preserving system is ergodic if and only if almost every point is generic.")
]

#text("A topological measure-preserving system is said to be uniquely ergodic if ")#emph[#text("every")]#text(" point is generic. The following exercise explains the terminology:")

#strong[#text("Exercise 10.")]#text(" Show that a topological measure-preserving system ")#mi("(X, {\\mathcal F}, \\mu, T)")#text(" is uniquely ergodic if and only if the only T-invariant Borel probability measure on T is ")#mi("\\mu")#text(". (Hint: use Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text(".) Because of this fact, one can sensibly define what it means for a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" to be uniquely ergodic, namely that it has a unique T-invariant Borel probability measure. ")#mi("\\diamond")

#text("It is not always the case that an ergodic system is uniquely ergodic. For instance, in the Bernoulli system ")#mi("\\{0,1\\}^{\\Bbb Z}")#text(" (with uniform measure on ")#mi("\\{0,1\\}")#text(", say), the point ")#mi("0^{\\Bbb Z}")#text(" is not generic. However, for more algebraic systems, it turns out that ergodicity and unique ergodicity are largely equivalent. We illustrate this with the circle and skew shifts:")

#strong[#text("Exercise 11.")]#text(" Show that the circle shift ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha)")#text(" (with the usual Lebesgue measure) is uniquely ergodic if and only if ")#mi("\\alpha")#text(" is irrational. (")#emph[#text("Hint")]#text(": first show in the circle shift system that any translate of a generic point is generic.) ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text("(Unique ergodicity of skew shift) Let ")#mi("\\alpha \\in {\\Bbb R}")#text(" be irrational. Then the skew shift ")#mi("(({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha,y+x))")#text(" is uniquely ergodic.")
]

#strong[#text("Proof.")]#text(" We use an argument ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("of Furstenberg")]#text(". We again write the skew shift as ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(". Suppose this system was not uniquely ergodic, then by Exercise 10 there is another shift-invariant Borel probability measure ")#mi("\\mu^{\\prime} \\neq \\mu")#text(". If we push ")#mi("\\mu")#text(" and ")#mi("\\mu^{\\prime}")#text(" down to the circle shift system ")#mi("({\\Bbb R}/{\\Bbb Z}, x \\mapsto x+\\alpha")#text(" by the projection map ")#mi("(x,y) \\mapsto x")#text(", then by Exercises 10, 11 we must get the same measure. Thus ")#mi("\\mu")#text(" and ")#mi("\\mu^{\\prime}")#text(" must agree on any set of the form ")#mi("A \\times ({\\Bbb R}/{\\Bbb Z})")#text(".")

#text("Let E denote the points in ")#mi("X")#text(" which are generic with respect to ")#mi("\\mu")#text("; note that this set is Borel measurable. By Proposition 2, this set has full measure in ")#mi("\\mu")#text(". Also, since the vertical rotations ")#mi("(x,y) \\mapsto (x,y+\\theta)")#text(" commute with T and preserve ")#mi("\\mu")#text(", we see that E must be invariant under such rotations; thus they are of the form ")#mi("A \\times ({\\Bbb R}/{\\Bbb Z})")#text(" for some A. By the preceding discussion, we conclude that E also has full measure in ")#mi("\\mu^{\\prime}")#text(". But then (by the pointwise or mean ergodic theorem for ")#mi("(X, {\\mathcal X}, \\mu^{\\prime}, T)")#text(") we conclude that ")#mi("{\\Bbb E}_{\\mu^{\\prime}}(f|{\\mathcal X}^T) = \\int_X f\\ d\\mu")#text(" ")#mi("\\mu^{\\prime}")#text("-almost everywhere for every continuous f, and thus on integrating with respect to ")#mi("\\mu^{\\prime}")#text(" we obtain ")#mi("\\int_X f\\ d\\mu^{\\prime} = \\int_X f\\ d\\mu")#text(" for every continuous f. But then by the Riesz representation theorem we have ")#mi("\\mu = \\mu^{\\prime}")#text(", a contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" If ")#mi("\\alpha \\in {\\Bbb R}")#text(" is irrational, then the sequence ")#mi("(\\alpha n^2 \\text{ mod } 1)_{n \\in {\\Bbb N}}")#text(" is uniformly distributed in ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" (with respect to uniform measure).")
]

#strong[#text("Exercise 11a.")]#text(" Show that the systems considered in Exercise 8 are uniquely ergodic. Conclude that the exponent 2 in Corollary 2 can be replaced by any positive integer d. ")#mi("\\diamond")

#text("Note that the topological dynamics theory developed in Lecture 6 only establishes the weaker statement that the above sequence is dense in ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" rather than uniformly distributed. More generally, it seems that ergodic theory methods can prove topological dynamics results, but not vice versa. Here is another simple example of the same phenomenon:")

#strong[#text("Exercise 12. ")]#text("Show that a uniquely ergodic topological dynamical system (with the support of the measure equal to the whole space) is necessarily minimal. (The converse is not necessarily true, as already mentioned in Remark 6 of ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text(".) ")#mi("\\diamond")

#heading(level: 1)[#text("— The ergodic decomposition —")]

#text("Just as not every topological dynamical system is minimal, not every measure-preserving system is ergodic. Nevertheless, there is an important decomposition that allows one to represent non-ergodic measures as averages of ergodic measures. One can already see this in the finite case, when X is a finite set with the discrete ")#mi("\\sigma")#text("-algebra, and ")#mi("T: X \\to X")#text(" is a permutation on X, which can be decomposed as the disjoint union of cycles on a partition ")#mi("X = C_1 \\cup \\ldots \\cup C_m")#text(" of X. In this case, all shift-invariant probability measures take the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\mu = \\sum_{j=1}^{m} \\alpha_j \\mu_j")]]

#text("where ")#mi("\\mu_j")#text(" is the uniform probability measure on the cycle ")#mi("C_j")#text(", and ")#mi("\\alpha_j")#text(" are non-negative constants adding up to 1. Each of the ")#mi("\\mu_j")#text(" are ergodic, but no non-trivial linear combination of these measures is ergodic. Thus we see in the finite case that every shift-invariant measure can be uniquely expressed as a convex combination of ergodic measures.")

#text("It turns out that a similar decomposition is available in general, at least if the underlying measure space is a compact topological space (or more generally, a ")#link("http://en.wikipedia.org/wiki/Radon_space")[#text("Radon space")]#text("). This is because of the following general theorem from measure theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 ")]#text("(Probability kernel). Let ")#mi("(X, {\\mathcal X})")#text(" and ")#mi("(Y, {\\mathcal Y})")#text(" be measurable spaces. A ")#emph[#text("probability kernel")]#text(" ")#mi("y \\mapsto \\mu_y")#text(" is an assignment of a probability measure ")#mi("\\mu_y")#text(" on X to each ")#mi("y \\in Y")#text(" in such a way that the map ")#mi("y \\mapsto \\int_X f\\ d\\mu_y")#text(" is measurable for every bounded measurable ")#mi("f: X \\mapsto {\\Bbb C}")#text(".")
]

#strong[#text("Example 3.")]#text(" Every measurable map ")#mi("\\phi: Y \\to X")#text(" induces a probability kernel ")#mi("y \\mapsto \\delta_{\\phi(y)}")#text(". Every probability measure on X can be viewed as a probability kernel from a point to X. If ")#mi("y \\mapsto \\mu_y")#text(" and ")#mi("x \\mapsto \\nu_x")#text(" are two probability kernels from Y to Z and from X to Y respectively, their composition ")#mi("x \\mapsto (\\mu \\circ \\nu)_x := \\int_Y \\mu_y\\ d\\nu_x(y)")#text(" is also a probability kernel, where ")#mi("\\int_Y \\mu_y\\ d\\nu_x(y)")#text(" is the measure that assigns ")#mi("\\int_Y \\mu_y(E)\\ d\\nu_x(y)")#text(" to any measurable set E in Z. Thus one can view the class of measurable spaces and their probability kernels as a category, which includes the class of measurable spaces and their measurable maps as a subcategory. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Regular space) A measurable space ")#mi("(X, {\\mathcal X})")#text(" is said to be ")#emph[#text("regular")]#text(" if there exists a compact metrisable topology ")#mi("{\\mathcal F}")#text(" on X for which ")#mi("{\\mathcal X}")#text(" is the Borel ")#mi("\\sigma")#text("-algebra.")
]

#strong[#text("Example 4.")]#text(" Every topological measure-preserving system is regular. ")#mi("\\diamond")

#strong[#text("Remark 5. ")]#text("Measurable spaces ")#mi("(X, {\\mathcal X})")#text(" in which ")#mi("{\\mathcal X}")#text(" is the Borel ")#mi("\\sigma")#text("-algebra of a topological space generated by a separable complete metric space (i.e. a ")#link("http://en.wikipedia.org/wiki/Polish_space")[#text("Polish space")]#text(") are known as ")#emph[#text("standard Borel spaces")]#text(". It is a non-trivial theorem from descriptive set theory that up to measurable isomorphism, there are only three types of standard Borel spaces: finite discrete spaces, countable discrete spaces, and the unit interval [0,1] with the usual Borel ")#mi("\\sigma")#text("-algebra. From this one can see that regular spaces are the same as standard Borel spaces, though we will not need this fact here. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" (")#link("http://en.wikipedia.org/wiki/Disintegration_theorem")[#text("Disintegration theorem")]#text("). Let ")#mi("(X, {\\mathcal X},\\mu)")#text(" and ")#mi("(Y, {\\mathcal Y},\\nu)")#text(" be probability spaces, with ")#mi("(X,{\\mathcal X})")#text(" regular. Let ")#mi("\\pi: X \\to Y")#text(" be a morphism (thus ")#mi("\\nu = \\pi_\\# \\mu")#text("). Then there exists a probability kernel ")#mi("y \\mapsto \\mu_y")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\int_X f (g \\circ \\pi)\\ d\\mu = \\int_Y (\\int_X f\\ d\\mu_y) g(y)\\ d\\nu(y)")]]

#text("for any bounded measurable ")#mi("f: X \\to {\\Bbb C}")#text(" and ")#mi("g: Y \\to {\\Bbb C}")#text(". Also, for any such g, we have")

#align(center)[#mi("g \\circ \\pi = g(y)")#text(" ")#mi("\\mu_y")#text("-a.e. (18)")]

#text("for ")#mi("\\nu")#text("-a.e. y.")

#text("Furthermore, this probability kernel is unique up to ")#mi("\\nu")#text("-almost everywhere equivalence, in the sense that if ")#mi("y \\mapsto \\mu^{\\prime}_y")#text(" is another probability kernel with the same properties, then ")#mi("\\mu_y = \\mu^{\\prime}_y")#text(" for ")#mi("\\nu")#text("-almost every ")#mi("y")#text(".")
]

#text("We refer to the probability kernel ")#mi("y \\mapsto \\mu_y")#text(" generated by the above theorem as the ")#emph[#text("disintegration")]#text(" of ")#mi("\\mu")#text(" relative to the factor map ")#mi("\\pi")#text(".")

#strong[#text("Proof.")]#text(" We begin by proving uniqueness. Suppose we have two probability kernels ")#mi("y \\mapsto \\mu_y, y \\mapsto \\mu^{\\prime}_y")#text(" with the above properties. Then on subtraction we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\int_Y (\\int_X f\\ d(\\mu_y-\\mu^{\\prime}_y)) g(y)\\ d\\nu(y) = 0")]]

#text("for all bounded measurable ")#mi("f: X \\to {\\Bbb C}")#text(", ")#mi("g: Y \\to {\\Bbb C}")#text(". Specialising to ")#mi("f=1_E")#text(" for some measurable set ")#mi("E \\in {\\mathcal X}")#text(", we conclude that ")#mi("\\mu_y(E) = \\mu^{\\prime}_y(E)")#text(" for ")#mi("\\nu")#text("-almost every y. Since ")#mi("{\\mathcal X}")#text(" is regular, it is separable and we conclude that ")#mi("\\mu_y = \\mu^{\\prime}_y")#text(" for ")#mi("\\nu")#text("-almost every y, as required.")

#text("Now we prove existence. The pullback map ")#mi("\\pi^\\#: L^2( Y, {\\mathcal Y}, \\nu) \\to L^2( X, {\\mathcal X}, \\mu)")#text(" defined by ")#mi("g \\mapsto g \\circ \\pi")#text(" has an ")#link("http://en.wikipedia.org/wiki/Adjoint_of_an_operator")[#text("adjoint")]#text(" ")#mi("\\pi_\\#: L^2(X, {\\mathcal X},\\mu) \\to L^2(Y, {\\mathcal Y}, \\nu)")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\int_X f (g \\circ \\pi)\\ d\\mu = \\int_Y (\\pi_\\# f) g\\ d\\nu")]]

#text("for all ")#mi("f \\in L^2(X,{\\mathcal X},\\mu)")#text(" and ")#mi("g \\in L^2(Y,{\\mathcal Y},\\nu)")#text(". It is easy to see from duality that we have ")#tao-math("\\left\\| \\pi_\\# f \\right\\|_{L^\\infty(Y, {\\mathcal Y}, \\nu)} \\leq \\left\\| f \\right\\|_{C(X)}", block: false)#text(" for all ")#mi("f \\in C(X)")#text(" (where we select a compact metrisable topology that generates the regular ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}")#text("). Recall that ")#mi("\\pi_\\# f")#text(" is not quite a measurable function, but is instead an equivalence class of measurable functions modulo ")#mi("\\nu")#text("-almost everywhere equivalence. Since C(X) is separable, we find a measurable representative ")#mi("\\tilde \\pi_\\# f: Y \\to {\\Bbb C}")#text(" of ")#mi("\\pi_\\# f")#text(" to every ")#mi("f \\in C(X)")#text(" which varies linearly with f, and is such that ")#tao-math("\\left|\\tilde \\pi_\\# f(y)\\right| \\leq \\left\\|f\\right\\|_{C(X)}", block: false)#text(" for all y outside of a set E of ")#mi("\\nu")#text("-measure zero and for all ")#mi("f \\in C(X)")#text(". For all such y, we can then apply the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" to obtain a Radon probability measure ")#mi("\\mu_y")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\tilde \\pi_\\# f(y) = \\int_X f\\ d\\mu_y")]]

#text("for all such y. We set ")#mi("\\mu_y")#text(" equal to some arbitrarily fixed Radon probability measure for ")#mi("y \\in E")#text(". We then observe that the required properties (including the measurability of ")#mi("y \\mapsto \\int_X f\\ d\\mu_y")#text(") are already obeyed for ")#mi("f \\in C(X)")#text(". To generalise this to bounded measurable f, observe that the class ")#mi("{\\mathcal C}")#text(" of f obeying the required properties is closed under dominated pointwise convergence, and so contains the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator functions")]#text(" of open or compact sets (by ")#link("http://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text("). Applying dominated pointwise convergence again and ")#link("http://en.wikipedia.org/wiki/Inner_regular_measure")[#text("inner")]#text(" and outer regularity, we see that the indicator functions of any Borel set lies in ")#mi("{\\mathcal C}")#text(". Thus all ")#link("http://en.wikipedia.org/wiki/Simple_function")[#text("simple")]#text(" measurable functions lie in ")#mi("{\\mathcal C}")#text(", and on taking uniform limits we obtain the claim.")

#text("Finally, we prove (18). From two applications of (17) we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_Y (\\int_X f (g \\circ \\pi)\\ d\\mu_y) h(y)\\ d\\nu(y) = \\int_Y (\\int_X f g(y)\\ d\\mu_y) h(y)\\ d\\nu(y)")]]

#text("for all bounded measurable ")#mi("f: X \\to {\\Bbb C}")#text(" and ")#mi("h: Y \\to {\\Bbb C}")#text(". The claim follows (using the separability of the space of all f). ")#mi("\\diamond")

#strong[#text("Exercise 13. ")]#text("Let the notation and assumptions be as in Theorem 4. Suppose that ")#mi("{\\mathcal Y}")#text(" is also regular, and that the map ")#mi("\\pi: X \\to Y")#text(" is continuous with respect to some compact metrisable topologies that generate ")#mi("{\\mathcal X}")#text(" and ")#mi("{\\mathcal Y}")#text(" respectively. Then show that for ")#mi("\\nu")#text("-almost every y, the probability measure ")#mi("\\mu_y")#text(" is supported in ")#mi("\\pi^{-1}(\\{y\\})")#text(". ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" (Ergodic decomposition). Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a regular measure-preserving system. Let ")#mi("(Y, {\\mathcal Y}, \\nu, S)")#text(" be the system defined by ")#mi("Y := X")#text(", ")#mi("{\\mathcal Y} := {\\mathcal X}^T")#text(", ")#mi("\\nu := \\mu\\downharpoonright_{\\mathcal Y}")#text(", and ")#mi("S := T")#text(", and let ")#mi("\\pi: X \\to Y")#text(" be the identity map. Let ")#mi("y \\mapsto \\mu_y")#text(" be the disintegration of ")#mi("\\mu")#text(" with respect to the factor map ")#mi("\\pi")#text(". Then for ")#mi("\\nu")#text("-almost every y, the measure ")#mi("\\mu_y")#text(" is T-invariant and ergodic.")
]

#strong[#text("Proof.")]#text(" Observe from the T-invariance ")#mi("\\mu = T_\\# \\mu")#text(" of ")#mi("\\mu")#text(" (and of ")#mi("{\\mathcal X}^T")#text(") that the probability kernel ")#mi("y \\mapsto T_\\# \\mu_y")#text(" would also be a disintegration of ")#mi("\\mu")#text(". Thus we have ")#mi("\\mu_y = T_\\# \\mu_y")#text(" for ")#mi("\\nu")#text("-almost every y.")

#text("Now we show the ergodicity. As the space of bounded measurable ")#mi("f: X \\to {\\Bbb C}")#text(" is separable, it suffices by Theorem 3 and a limiting argument to show that for any fixed such f, the averages ")#mi("\\frac{1}{N} \\sum_{n=1}^N T^n f")#text(" converge pointwise ")#mi("\\mu_y")#text("-a.e. to ")#mi("\\int_X f\\ d\\mu_y")#text(" for ")#mi("\\nu")#text("-a.e. y.")

#text("From the pointwise ergodic theorem, we already know that ")#mi("\\frac{1}{N} \\sum_{n=1}^N T^n f")#text(" converges to ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)")#text(" outside of a set of ")#mi("\\mu")#text("-measure zero. By (17), this set also has ")#mi("\\mu_y")#text("-measure zero for ")#mi("\\nu")#text("-almost every y. Thus it will suffice to show that ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)")#text(" is ")#mi("\\mu_y")#text("-a.e. equal to ")#mi("\\int_X f\\ d\\mu_y")#text(" for ")#mi("\\nu")#text("-a.e. y. Now observe that ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)(x) = \\pi_\\# f( \\pi(x) )")#text(", so the claim follows from (18) and (21). ")#mi("\\diamond")

#strong[#text("Exercise 14.")]#text(" Let ")#mi("(X, {\\mathcal X})")#text(" be a separable measurable space, and let T be bimeasurable bijection ")#mi("T: X \\to X")#text(". Let ")#mi("M({\\mathcal X})")#text(" denote the Banach space of all finite measures on ")#mi("{\\mathcal X}")#text(" with the total variation norm. Let ")#mi("\\text{Pr}({\\mathcal X})^T \\subset M({\\mathcal X})")#text(" denote the collection of probability measures on ")#mi("{\\mathcal X}")#text(" which are T-invariant. Show that this is a closed convex subset of ")#mi("M({\\mathcal X})")#text(", and the ")#link("http://en.wikipedia.org/wiki/Extreme_point")[#text("extreme points")]#text(" of ")#mi("\\text{Pr}({\\mathcal X})^T")#text(" are precisely the ergodic probability measures (which also form a closed subset of ")#mi("M({\\mathcal X})")#text("). We remark that one can use these facts to prove some variants of Proposition 4 using ")#link("http://en.wikipedia.org/wiki/Choquet_theory")[#text("Choquet’s theorem")]#text(", although I do not know of a way to prove this proposition in full generality just from Choquet. ")#mi("\\diamond")

#strong[#text("Exercise 15.")]#text(" Show that a topological measure-preserving system ")#mi("(X, {\\mathcal F}, T, \\mu)")#text(" is uniquely ergodic if and only if the only ergodic shift-invariant Borel probability measure on X is ")#mi("\\mu")#text(". ")#mi("\\diamond")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (85)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetanhek")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-505336")[#strong[#text("Abhishek Khetanhek")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("Dear Professor Tao,")

#text("In the second paragraph of the proof of Proposition 4 (ergodic decomposition theorem) there is a line which reads “it suffices by Theorem 3 and a limiting argument …” I am not able to follow the sufficiency. Can you please provide some details. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-505535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("One can find a countable set ")#mi("{\\mathcal F}")#text(" of bounded measurable functions that is dense in every ")#mi("L^2(X, \\mu_y)")#text("; indeed one can take ")#mi("{\\mathcal F}")#text(" to be rational linear combinations of indicator functions of the countable generating set of the sigma-algebra.")

#text("By hypothesis and countable union, we see that for ")#mi("\\nu")#text("-almost every ")#mi("y")#text(", the pointwise ergodic theorem holds in ")#mi("L^2(X,\\mu_y)")#text(" for every ")#mi("f \\in {\\mathcal F}")#text(". By a limiting argument, that shows that the mean ergodic theorem holds in ")#mi("L^2(X, \\mu_y)")#text(" for every ")#mi("f \\in L^2(X, \\mu_y)")#text(", hence by Theorem 3, ")#mi("(X,\\mu_y)")#text(" is ergodic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetanhek")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-505738")[#strong[#text("Abhishek Khetanhek")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("Thank you for the detailed response.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eeb5f4919f0c28d0a78254beecca95bd94a7c8123a33d99cef5b64bdb4f73aa0-0cf2992ffd14d870f4f7f86aae35deb385a53a5326f0a58522b99c23d2bca924.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuping Zhang")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-513482")[#strong[#text("Yuping Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2019")])]

#text("My conclusion: The Dr. Terence Tao’s the blue-eyed islanders puzzle only works out if N=2, N=1, and in condition N=0 ( see below)")

#text("The example 1) explain 2 colors in the puzzle .")

#text("The case, 10 and N=1, and N= is the only person to whose eyes are not green. Rest of the 9 are greens.")

#text("Someone announced: ”At least one of the ten has green eyes.”")

#text("In the 9th days, CAN all of the 9 greens figure it out their eye color logically? NO")

#text("The example 2) explain 2 colors in the puzzle")

#text("The case, 10 and N=0 or the entire ten has no green eyes")

#text("Someone announced:”At least one of the ten has no green eyes.")

#text("In the 10th days, CAN all of the 10 no greens figure it out their eye color logically? YES.")

#text("Why? Again!")

#text("the crucial key is the entire 10 of them could see the single color in the same amount of people=9, therefore, it’s not leaving each day that tells more and more works out.")

#text("But not in Dr. Terence Tao’s the blue-eyed island puzzle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-513867")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2019")])]

#text("Dear Prof. Tao,")

#text("in the proof of uniqueness in the disintegration theorem, do you really mean to say that ")#mi("\\mathcal X")#text(" is regular? Or do you mean that under a suitable metric, ")#mi("X")#text(" is separable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-513868")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2019")])]

#text("I see, what you mean is that regularity is in fact a property of the ")#mi("\\sigma")#text("-algebra. Perhaps this should be pointed out.")

#emph[#text("[See Definition 2 – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-535622")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2020")])]

#text("Dear Professor Tao,")

#text("Have you had a chance to see Daniel Worm’s Ph.D. thesis (Leiden 2010) and my 2014 Springer monograph?")

#text("In these works we discuss the KBBY (Kryloff-Bogoliouboff-Beboutoff-Yosida) ergodic decomposition. The KBBY decomposition is obtained in a constructive manner, while the decomposition based on the Choquet-Phelps approach is highly nonconstructive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto Di Biase")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-615321")[#strong[#text("Fausto Di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("In Remark 5 you say that ”regular spaces are the same as standard Borel spaces”, but a countably infinite discrete space is a standard Borel space but it is not compact, hence it is not a regular space. I am confused. Could you please help? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-615357")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("A countably infinite discrete space is measurably (though not topologically) equivalent to the countable compact set ")#mi("\\{ 1/n: n \\in {\\bf N} \\} \\cup \\{0\\}")#text(", so it (or more precisely, the measurable space associated to it) is a regular space. (The topology used in the definition of a regular space is not necessarily the one that one may initially wish to assign to the measurable space in question.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30a9f9b1621abd7b04ca420171aed30e91677989bb7de01be4c0c07125fda1aa-e9a2701704eead7eabed2961af49f1c84539a18fc9b0d03fa0dc12f18b164224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fausto Di Biase")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-615482")[#strong[#text("Fausto Di Biase")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2021")])]

#text("Thanks a lot!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-681818")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("Line (18) in the statement of the disintegration theorem doesn’t quite seem to make sense.")

#text("On the RHS $g(y)$ is a complex number afaict. And $g \\circ \\pi$ is a function on $X$. It is also followed by two ‘a.e.’ statements.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-681819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2023")])]

#text("OK scratch that; it makes sense, I just couldn’t parse the way it was written.")

#text("The following statement is true for nu-a.e. y: For mu_y a.e. x, we have that g(\\pi(x)) = g(y).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-681850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2023")])]

#text("In Exercise 13, why do you need ‘compact’??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-693214")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2026")])]

#text("Dear Dr Tao，")

#text("I have a vague idea: if we view a sequence of random variables X_1, X_2, … as a stationary process, then is the strong law of large numbers a special case of Theorem 2 (the pointwise ergodic theorem), and similarly, is the weak law of large numbers a special case of the mean ergodic theorem? If this is correct, what insights can the perspective of ergodic theory bring to understanding these two fundamental results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-2/#comment-693216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2026")])]

#text("I am ")#link("https://claude.ai/share/f3743635-e8fa-4830-834d-e79937ebc8e8")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-25512")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("In the proof of Thm 1, we should “[o]bserve that ")#mi("Mf(x)>0")#text(" …” and not as written. Ex.11 duplicates Ex. 5 (should ask to show the circle shift is uniquely ergodic). Def. 1 should note that ")#mi("\\mu_y")#text(" is a measure on ")#mi("X")#text(". Example 3 should have ")#mi("y\\mapsto \\nu_y")#text(" and not as written; “composition” there is a form of convolution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-25524")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Thanks, Lior, for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c6953ab4425d109767a7eef3ecc7c8cf8d944a87ec5e2a502981e671d9cc1a-1d73f6869dd4b3f2691c3f1f37c65f3584e7eca39cd73c5b09d3068e6ab0d958.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-25545")[#strong[#text("Lior")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Of course my remark on Example 3 is wrong — sorry about that. I too should re-read what I write.. To Exercize 14 you can add showing that the set of ergodic measures is closed (eliminating the annoyance with the meaning of the “support” of the measure you get from Choquet’s theorem).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-26123")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("[…] measure-preserving systems are isomorphic); the notion of regularity was defined in Definition 2 of Lecture 9. Hint: take a countable shift-invariant family of sets that generate (thus T acts on this space by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-26523")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("[…] system with irrational (and with uniform measure), thus this system is ergodic by Exercise 5 from Lecture 9. Then the function has mean zero, but one easily computes that . The coefficients converge in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-26699")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2008")])]

#text("[…] 8. Show that each of the iterated skew shifts (Exercise 8 from Lecture 9) are compact extensions of the preceding skew […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 14: Weakly mixing extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-26992")[#strong[#text("254A, Lecture 14: Weakly mixing extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2008")])]

#text("[…] 1. If X is regular, then we can disintegrate the measure as an average , see Theorem 4 from Lecture 9. It is then possible to construct a relative product system , which is the product system but with […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-27069")[#strong[#text("254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2008")])]

#text("[…] This result is originally due to Leon Green, using spectral theory methods. We will use an argument of Parry (and adapted by Leibman), relying on “vertical” Fourier analysis and topological arguments, which we have already used for the skew shift in Proposition 1 of Lecture 9. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-27324")[#strong[#text("254A, Lecture 17: A Ratner-type theorem for SL_2(R) orbits « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2008")])]

#text("[…] to H, and thus (by Corollary 1) ergodic with respect to U. This implies (cf. Proposition 2 from Lecture 9) that -almost every point x in is generic (with respect to U) in the sense […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sugata")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-27781")[#strong[#text("sugata")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("sir,")#linebreak()#text(" in proving thm.1, you have written F(m+1)=max{0,f+PFm}.this means f(m+1) is positive always.but from the definition that is not true for negative functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-27804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear sugata,")

#mi("F_m")#text(" is always non-negative, because the N=0 term ")#mi("\\sum_{n=0}^{N-1} T^n f")#text(" in the definition of ")#mi("F_m")#text(" is automatically zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The strong law of large numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-30526")[#strong[#text("The strong law of large numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("[…] Remark 4. By viewing the sequence as a stationary process, and thus as a special case of a measure-preserving system one can view the weak and strong law of large numbers as special cases of the mean and pointwise ergodic theorems respectively (see Exercise 9 from 254A Lecture 8 and Theorem 2 from 254A Lecture 9). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-34266")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("Dear Professor Tao:")

#text("In theorem 1, is the linear operation P asked to be positive?")

#text("in (10), should the right-hand side be ")#mi("f^*(m)")#text(" or ")#mi("f(m)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-34271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2008")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e7f0a479425683a7cd36cfa0ae449b8972057c0d8adc95ac23d26efd30217b1-bab8ebc16f09b79b3c1f5a2812e76dd1ff5a328841158dc9888b9c83a2710c31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mykola")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-36141")[#strong[#text("mykola")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("Dear Professor Tao,")

#text("in the last but one paragraph of the proof of Theorem 4 you claim:")

#text("“we see that the sets whose indicator functions lie in ")#mi("{\\mathcal C}")#text(" form a ")#mi("\\sigma")#text("-algebra.”")

#text("It is not clear that the mentioned collection (of the sets whose indicator functions lie in ")#mi("{\\mathcal C}")#text(") is closed under taking a union of (not disjoint) sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-36143")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("Fair enough. I guess we can use outer and inner regularity (and dominated or monotone convergence) to get indicator functions of Borel sets to lie in ")#mi("{\\mathcal C}")#text(", instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e7f0a479425683a7cd36cfa0ae449b8972057c0d8adc95ac23d26efd30217b1-bab8ebc16f09b79b3c1f5a2812e76dd1ff5a328841158dc9888b9c83a2710c31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mykola")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-36146")[#strong[#text("mykola")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2009")])]

#text("Thank you very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-37739")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("In the proof of the pointwise ergodic theorem (Theorem 2). I don’t see how one can aproximate a given ")#mi("L^1")#text(" variable by a ")#mi("L^2")#text(" one, while at the same time preserving the conditional expectation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-37740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("Dear pablolessa,")

#text("One can approximate (in ")#mi("L^1")#text(") an ")#mi("L^1")#text(" function f with zero conditional expectation by a function g in ")#mi("L^2")#text(" with arbitrarily high accuracy (in ")#mi("L^1")#text("). Now, g may not have zero conditional expectation ")#emph[#text("a priori")]#text(", but one can simply replace it by its projection ")#mi("g - {\\Bbb E}(g|{\\mathcal X})")#text(" onto the zero expectation functions. Since this projection is bounded on ")#mi("L^1")#text(", and also preserves f, we see that ")#mi("g - {\\Bbb E}(g|{\\mathcal X})")#text(" also approximates f in ")#mi("L^1")#text(" to arbitrarily high accuracy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-37749")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("You’re right! I got mixed up trying to bound the ")#mi("L^2")#text(" norm of ")#mi("E(g|\\mathcal{X})")#text(" which actually might be unbounded.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-39727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2009")])]

#text("Dear Terry,")

#text("I was wondering if it is true that in the setting of Proposition 4, the invariant $\\sigma$-algebra ${\\cal X}^T$ is always countably generated? If for some reason this is true, it would give an easy way to check that measures $\\mu_y$ are $T$-invariant and ergodic without appealing to the pointwise ergodic theorem, simply by looking at what happens on the sets that generate ${\\cal X}^T$.")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-39739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2009")])]

#text("Dear anonymous,")

#text("Hmm, the issue seems to be delicate. It is not hard to show that ")#mi("{\\mathcal X}^T")#text(" is countably generated ")#emph[#text("modulo ")#mi("\\mu")#text("-null sets")]#text(" – for instance one can take a countable dense subset of ")#mi("L^2(X,{\\mathcal X},\\mu)")#text(" and look at their projections to ")#mi("L^2(X,{\\mathcal X}^T,\\mu)")#text(". But this doesn’t necessarily mean that ")#mi("{\\mathcal X}^T")#text(" is countably generated ")#emph[#text("modulo ")#mi("\\mu_y")#text("-null sets")]#text(" for almost every y, unless one is very careful with the measure-theoretic issues. (One may also have to be more precise about how ")#mi("{\\mathcal X}^T")#text(" is defined – does one want genuinely ")#mi("T")#text("-invariant sets, or sets that are only invariant up to ")#mi("\\mu")#text("-null sets?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-40866")[#strong[#text("陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("[…] is similar to the proof of theorem 4, though some difference should be taken care of. I wrote another post in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-40867")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" about (10), I am wondering if the right hand should be ")#mi("\\sum_{m \\in {\\Bbb Z}:f^*(m)>\\lambda} f(m)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-40896")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" about (6), I only can get ")#mi("\\int_X F_m\\ d\\mu \\leq \\int_{F_m > 0} f + \\int_{F_m>0} P F_m\\ d\\mu")#text(", I don’t see why ")#mi("\\int_{F_m>0} P F_m\\ d\\mu=\\int_X P F_m d\\mu")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-40897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#mi("P F_m")#text(" is non-negative, so ")#mi("\\int_{F_m > 0} P F_m\\ d\\mu")#text(" is bounded above by ")#mi("\\int_X P F_m\\ d\\mu")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-40940")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Exercise 4 , the two integrals in the conclusion are both dy, instead of dx.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/106e5dcbb4c497e0b230364fba6b0376b0c8ab9c65df73812a3ff8f9a5727b70-c6c83d0a849944010c7e92d6760404ae7cbcb0ab569420724ae1ee79c8100f01.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carlos Meninho")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-41957")[#strong[#text("Carlos Meninho")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Dear Professor Terence Tao,")

#text("I have a question regarding Exercise 9; consider the following topological dynamical system on the circle:")

#text("Take the homeomorphism ")#mi("T=x^2:[0,1]\\to[0,1]")#text(". This map fixes 0 and 1, hence induces a homeomorphism of the circle into itself. It is easy to see that this dynamical system has only one invariant probability measure: the atomic measure on the point 0~1.")

#text("Therefore, is uniquely ergodic by Exercise 10 and every point on the circle is generic. The positive orbit of a point ")#mi("x")#text(" in ")#mi("(0,1)")#text(" is contained in this open set. If Exercise 9 is true then ")#mi("\\mu((0,1))=1")#text(", but ")#mi("\\mu((0,1))=0")#text(", that is a contradiction.")

#text("Could you indicate what is the problem in this example?")

#text("I can prove a version of this exercise changing “for all open sets ")#mi("U")#text(" in ")#mi("X")#text("” by “for all open sets ")#mi("U")#text(" in ")#mi("X")#text(" with ")#mi("\\mu(\\partial U)=0")#text("” (the measure is zero on the boundary). This is true with the local compacity condition (weaker than compacity) by using Urysohn’s Lemma.")

#text("Best wishes,")#linebreak()#text(" Carlos Meninho.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-41961")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Hmm, you’re right; I’ve changed Exercise 9 accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-43036")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("[…] for every random variable , by using tools such as the Radon-Nikodym theorem; see Theorem 4 of these previous lecture notes of mine. In practice, we will not invoke these general results here (as it is not natural for us to place […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-44063")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2010")])]

#text("Dear Professor Tao:")#linebreak()#text(" I think the right hand sidd of (22) should be ")#mi("\\int_Y \\int_Xf d\\mu_y g(y)h(y)dv(y)")#text(" and the last sentance of exercise 13 is “…measure ")#mi("\\mu_y")#text(" is …")

#text("While I am trying to do exercise 13, I construct a function g in order to get a contradiction with (18) as follows.")

#text("I fix a ")#mi("y_0")#text(" and define ")#mi("g(y)=d(y,y_0)")

#text("It seems this can work. But in this way the condition that “")#mi("\\pi")#text(" is continuous ” is not necessary. I don’t know if I am right.")

#text("On exercise 14, I didn’t found a way to prove “any non-ergodic measure is not extreme points” as one direction of the conclusion without using the Ergodic decomposition theorem. But since you said this can provide a alternative method for that theorem, could give a hint for this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-44066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2010")])]

#text("Thanks for the corrections!")

#text("The continuity of ")#mi("\\pi")#text(" is needed to make the preimage ")#mi("\\pi^{-1}(\\{y\\})")#text(" closed (note that the support of a measure is closed by definition).")

#text("For exercise 14, use the fact that a non-ergodic measure has an invariant set of measure strictly between 0 and 1. By conditioning the measure to that set or its complement one can show that the measure is not an extreme measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8b639a43211df10c1497a6a6d581ad39edf9adcc7d7df1d2780a6d95c609aae-fb030a1c4d0a1a639c6762bfa40be0bf334c84b04ba90ea3b6ba29fdb8564b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-44074")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2010")])]

#text("The tag you have used for this post is different from the tag for the other posts in the series.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8b639a43211df10c1497a6a6d581ad39edf9adcc7d7df1d2780a6d95c609aae-fb030a1c4d0a1a639c6762bfa40be0bf334c84b04ba90ea3b6ba29fdb8564b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-44075")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2010")])]

#text("Ah! Never mind, I thought this was part of the same series as the Random Matrices one (which stopped at nr 8)…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5e47b50686bf072e15c3783170d21989d4fefebedadc1d033edb151eab86c45-516811cebfad33fe8c2a9d365019078b11e46f906d8d419de98e2ad114845e04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael S.")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-44360")[#strong[#text("Michael S.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("Dear Professor Tao,")

#text("concerning Exercise 12 there seems to be a small problem (hope I understood the definitions and details):")#linebreak()#text(" Suppose T is a homeomorphism of the circle K with exactly one fixed point, say 0, whose complement K\\{0} is wandering. E.g. we may take the map")#linebreak()#text(" z=exp(2*pi*i*x) —> T(z)=exp(2*pi*i*x^2) where x is in [0,1].")#linebreak()#text(" Then T is uniquely ergodic as every invariant measure is supported in the non-wandering set, thus there is only one invariant measure, the Dirac mass in 0. Nevertheless T is not minimal as is has a fixed point.")

#text("Best")#linebreak()#text(" Michael")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-45562")[#strong[#text("Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")])]

#text("[…] First we recall the exercise 11a of lecture 9, which asserts thatthen the sequence is uniformly distributed in , which means (by choosing ) that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46467")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("I want an example of an ergodic measure preserving transformation T for which T^2 is not ergodic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("Dear Sam,")

#text("just take the non-trivial permutation (flip) on two points of measure 1/2 each. This is ergodic by definition (no invariant sets of measure strictly between 0 and 1), but its square will be the identity which is not ergodic (each point is an invariant subset of measure 1/2).")

#text("You can modify this idea to get more elaborate examples on more complicated measure spaces.")

#text("Best")#linebreak()#text(" Michael")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6440c6a4384105a1299d8ebd456529c8528a07bf64fd0ec6a87f9589bfef1cc3-ce70424e469614c21e6cead85e5af11eb929c525827cae8cae179225414336e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46469")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("By T^2, I mean the second iterate of T. That is, T(T(x)). …. and not T x T")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("That’s what it is…")

#text("Say you have the two points 1 and 2 and the transformation is 1 goes to 2 and 2 goes to 1, then T^2 is the identity…")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6440c6a4384105a1299d8ebd456529c8528a07bf64fd0ec6a87f9589bfef1cc3-ce70424e469614c21e6cead85e5af11eb929c525827cae8cae179225414336e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46471")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("well-understood now. Great!!!!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6440c6a4384105a1299d8ebd456529c8528a07bf64fd0ec6a87f9589bfef1cc3-ce70424e469614c21e6cead85e5af11eb929c525827cae8cae179225414336e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46472")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("oops!!! can I use the Dirac measure as a measure preserving transformation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46473")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("The Dirac measure is not a transformation, but what you probably mean is, can you define a (measure preserving) transformation which preserves just the Dirac measure.")

#text("The answer is yes. Suppose you have any space (set etc.). Put a Dirac mass on one of its points (the remaining set/space then has measure zero, as you normally want a probability space). Then a transformation is measure preserving iff it has the point with the Dirac mass as a fixed point and in fact then it is already an ergodic transformation.")

#text("The other way around it works too: Suppose you have a given transformation on some space and you want to get an invariant measure. If the transformation has a fixed point, just put a Dirac mass in this point and you produced an invariant measure.")#linebreak()#text(" If the transformation has a finite orbit (i.e. a periodic point with finite period) just put the same mass on each of the points of this finite orbit – the mass should be 1/(length of the orbit) – and you again produced an invariant measure.")

#text("In fact most often you construct arbitrary invariant measures as limits (in the weak star topology) of measures which have support on certain finite orbits. Usually those “periodic” measures are dense in the space of all invariant measures and thus you can always approximate an invariant measure using a sequence of those special measures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6440c6a4384105a1299d8ebd456529c8528a07bf64fd0ec6a87f9589bfef1cc3-ce70424e469614c21e6cead85e5af11eb929c525827cae8cae179225414336e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-46479")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")])]

#text("For the class of invariant events, I, how does one show that a random variable X is I-measurable if and only if X=XoT, where T is a map that preserves the probability P? I have tried it for an indicator variable, then simple r. v., then a nonnegative r. v. but having problem getting a formal derivation for the general r. v. Moreover, my idea on the indicator variable is not clear as to how I should put it mathematically.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-47646")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] this inequality implies Lemma 12. (Hint: First do the case, by invoking the rising sun lemma.) See these lecture notes for some further discussion of inequalities of this type, and applications to ergodic theory (and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s spherical maximal theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-53010")[#strong[#text("Stein’s spherical maximal theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")])]

#text("[…] abstract semigroup maximal inequality of Dunford and Schwartz (discussed for instance in these lecture notes of mine) shows that the heat kernel maximal function is of weak-type with a constant of , and this can be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-177407")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2012")])]

#text("In the statement of the Dunford-Schwartz maximal inequality, you write")#linebreak()#text(" “")#mi("Mf := \\sup_{N > 0} \\frac{1}{N} \\sum_{n=1}^N P^n f")#text("”")

#text("Do you want this to be ")#mi("Mf := \\sup_{N \\geq 0} \\frac{1}{N} \\sum_{n=0}^{N-1} P^n f")#text(" instead?")

#text("Otherwise, we seem to be missing the ")#mi("f")#text(" term in the sum, and then it is not clear to me why ")#mi("Mf(x) > 0")#text(" if and only if ")#mi("F_m(x) > 0")#text(" for sufficiently large ")#mi("m")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-177909")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("In the Dunford-Schwartz maximal inequality, is there any need to assume that ")#mi("(X,\\mu)")#text(" is a probability space? I don’t see any place where this assumption is used.")

#text("In particular, we should be able to just apply it directly to Exercise 1, yes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-177913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("It’s used implicitly via the fact that constant functions (such as ")#mi("\\lambda")#text(") lie in ")#mi("L^1")#text(", which is only true in measure spaces of finite measure.")

#text("But yes, if one formulates things carefully, one should be able to extend the Dunford-Schwarz inequality to the infinite measure spacing (but one would have to extend P from ")#mi("L^1")#text(" to some larger space, such as ")#mi("L^1 + L^\\infty")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-178294")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2012")])]

#text("In the statement of the pointwise ergodic theorem, we assume that ")#mi("f")#text(" is ")#mi("L^1")#text(", but not necessarily ")#mi("L^2")#text(". How do we define its conditional expectation ")#mi("{\\Bbb E}(f|{\\mathcal X}^T)(x)")#text(" then?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-178331")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2012")])]

#text("See Exercise 6.4 of Lecture notes 8. The point is that conditional expectation is a contraction in L^1 norm, and L^2 is a dense subspace of L^1, so one can extend conditional expectation to L^1 by density.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-178683")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("I’m a bit confused with the composition of probability kernels in Example 3.")

#text("The composition ")#mi("x \\mapsto (\\mu \\circ \\nu)_x := \\int_X \\mu_y\\ d\\nu_x(y)")#text(" seems to have domain ")#mi("X")#text(", but shouldn’t composing a map from ")#mi("Y")#text(" to ")#mi("X")#text(" and then ")#mi("X")#text(" to ")#mi("Z")#text(" should give us something with domain ")#mi("Y")#text("?")

#text("Also, we seem to be taking values ")#mi("\\mu_y(E)")#text(" where ")#mi("E \\subset Z")#text(", but ")#mi("\\mu_y")#text(" is a measure on ")#mi("X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-178700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("Sorry, ")#mi("\\mu")#text(" and ")#mi("\\nu")#text(" should be from Y to Z and from X to Y respectively.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-178704")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("Ah, okay. That makes more sense. I think you want to write the integrals")

#mi("\\int_X \\mu_y(E)\\ d\\nu_x(y)")

#text("to be taken over ")#mi("Y")#text(" rather than ")#mi("X")#text(" as well.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d58d09a280e91b2a57cce026165a7aafb74650a092938ef0e220fb08fa9d6fa-29f4a27a119ab5a60d5c685e6110717684c456f87cae39ffc401da7518f10d4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224234")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2013")])]

#text("I don’t think I know how to go from the hint in exercise 6 to the statement for general E, F. Also, don’t you need the space ")#mi("\\Omega")#text(" to be a standard Borel space or something so that you can take infinite product spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d58d09a280e91b2a57cce026165a7aafb74650a092938ef0e220fb08fa9d6fa-29f4a27a119ab5a60d5c685e6110717684c456f87cae39ffc401da7518f10d4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224236")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2013")])]

#text("To be specific, I know that the ")#mi("\\Pi-\\Lambda")#text(" theorem is useful here, but cannot check that the left side of condition 6 is a measure, because the limit may not commute with infinite sums. (Or you can view this as checking that the set where 6 holds for say fixed F is a lambda system.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224249")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2013")])]

#text("Yes, one needs a hypothesis such as standard Borel (actually inner regular should suffice) in the exercise; I’ve added it as such. To handle general measurable sets, show that such sets an be approximated in measure by sets that depend on only finitely many factors.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stéphane Laurent")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224374")[#strong[#text("Stéphane Laurent")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2013")])]

#text("There is an error in point 6 of Theorem. The exponent should be -n, not n. For instance take T(x)=2x(mod 1) and E=[0,1/2]. Then 6 fails but T is ergodic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224378")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2013")])]

#text("In these notes we are restricting attention to invertible systems (see ")#link("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")[#text("https://terrytao.wordpress.com/2008/01/08/254a-lecture-1-overview/")]#text(" ).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stéphane Laurent")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224381")[#strong[#text("Stéphane Laurent")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2013")])]

#text("Ooops sorry. But isn’t it more natural with the negative exponent ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-224397")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2013")])]

#text("I suppose so, though in the invertible case one has ")#mi("\\mu(T^n E \\cap F) = \\mu(E \\cap T^{-n} F)")#text(" so there is basically no distinction to be made in that case.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-230672")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] is the pushforward map associated to the map ; see e.g. this previous blog post. We can interpret this as an equidistribution result. If is a pair as before, then we no longer […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e992c9d6bd69dd80732ca5390a35dcd2f41def765f7553ed62128e4fb9b21ecb-4768d42197c2c4f660569b64d7705d69c7ec4ef2e7e1cbee040f09e195407ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Measure preserving dynamics | Peter's ruminations")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-244897")[#strong[#text("Measure preserving dynamics | Peter's ruminations")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("[…] ")#link(<tao-3f3339c34b805dd8a52f>)[#text("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/#more-252")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-376242")[#strong[#text("An abstract ergodic theorem, and the Mackey-Zimmer theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("[…] topology, where is the -invariant subspace of , and is the orthogonal projection to . (See e.g. these previous lecture notes for a proof.) The same proof extends to more general amenable groups: if is a countable amenable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-410727")[#strong[#text("G")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2014")])]

#text("Dear Prof Tao,")

#text("there is a typo in Exercise 13, the measure should be \\mu_y and not \\nu_y.")

#text("Best,")#linebreak()#text(" G")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0925fa351d5484b14f2c87c3068f671cffe2876dfa6e0d394bed22d4b4057b1d-e8ec9431d79c44168b3684a0d9c4696ca435c9a129f42c754eac05d167d3aa3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Biringer")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-468742")[#strong[#text("Ian Biringer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("For Exercise 14, is there actually a version of Choquet’s theorem that applies in such generality? The original needs the set of measures to be compact, not closed. Noncompact version like")

#link("http://www.ams.org/journals/proc/1975-049-02/S0002-9939-1975-0372586-2/S0002-9939-1975-0372586-2.pdf")[#text("Click to access S0002-9939-1975-0372586-2.pdf")]

#text("require things like the convex set to be separable and contained in a Banach space with the Radon-Nikodym property. The exercise is a good one, but the last sentence seems misleading. (I’m not an expert, though, so if you do have such a reference I’d love to see and use it.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-468747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("Fair enough; Choquet’s theorem can be applied as is only under some additional regularity hypotheses on the dynamical system (such as differentiability), see e.g.")#link("http://www.cimat.mx/~albarran/documentos/ergodicdesc.pdf")[#text("http://www.cimat.mx/~albarran/documentos/ergodicdesc.pdf")]#text(" . I’ll reword the final remark.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0925fa351d5484b14f2c87c3068f671cffe2876dfa6e0d394bed22d4b4057b1d-e8ec9431d79c44168b3684a0d9c4696ca435c9a129f42c754eac05d167d3aa3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian Biringer")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-468777")[#strong[#text("Ian Biringer")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("That’s right, although I’m not sure that differentiability matters much. In the notes you cite, there is a standing assumption that the underlying space is a compact manifold.")

#text("In general, whenever you have a group G acting continuously on a compact metric space, the weak* topology on the space of probability measures is compact and you can apply Choquet to the weak* closed subset of G-invariant measures.")

#text("After further investigation, it does seem that one can prove an ergodic decomposition theorem for (l.c.s.c.) G-actions on standard Borel spaces using Choquet, though. The basic idea is to use a result of Varadarajan that allows one to Borel-embed arbitrary standard Borel G-spaces into compact metric G-spaces on which the G-action is continuous.")

#text("Varadarajan: Theorem 3.2 of ")#link("http://www.ams.org/journals/tran/1963-109-02/S0002-9947-1963-0159923-5/S0002-9947-1963-0159923-5.pdf")[#text("http://www.ams.org/journals/tran/1963-109-02/S0002-9947-1963-0159923-5/S0002-9947-1963-0159923-5.pdf")]

#text("Here’s a paper where they use this approach:")

#link("http://www.mat.univie.ac.at/~kschmidt/Publications/decomposition.pdf")[#text("Click to access decomposition.pdf")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d856260dbd6b83dbfc4406187e506d1c436f28ef5070cae904c80572a467436-5bb0322461db47392f22f575fbbbcd10cc591a0d6aea769f4b902aa57998b96f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OCHONOGOR")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-471536")[#strong[#text("OCHONOGOR")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2016")])]

#text("Prove that the identity map on any measure space is measure preserving")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90dd425f012ebab1358959165943bfbe02cd773b37b5f9e12a370d6770c41d90-a651a16587c1b36de3e7674c0e96e2af27c2fd70ebf2f2dbcf3df681d013f119.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin M. Pilgrim")]], [#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/comment-page-1/#comment-486704")[#strong[#text("Kevin M. Pilgrim")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2017")])]

#text("In Proposition 3, it seems like you need to know E is nonempty; this would follow from ergodicity of the skew-shift with respect to Lebesgue measure. In turn, this follows from looking at the induced unitary operator on L^2–but did you have another argument in mind?")

#emph[#text("[See Proposition 1 -T.]")]
]
