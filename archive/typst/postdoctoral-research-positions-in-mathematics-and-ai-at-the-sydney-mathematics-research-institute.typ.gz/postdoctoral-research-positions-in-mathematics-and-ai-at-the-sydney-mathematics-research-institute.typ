// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/
// Converted to Typst by tao2typ: "2026-10-14T11:08:30.568580+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Postdoctoral Research Positions in Mathematics and AI at the Sydney Mathematics Research Institute", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Postdoctoral Research Positions in Mathematics and AI at the Sydney Mathematics Research Institute")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/")[#text("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[The following information was provided to me by ")#link("https://www.maths.usyd.edu.au/u/geordie/")[#text("Geordie Williamson")]#text(", who is Director of the ")#link("https://mathematical-research-institute.sydney.edu.au/")[#text("Sydney Mathematics Research Institute")]#text(" – T.]")]

#text("We are currently advertising two positions in math and AI:")

#list(
[#text("A ")#link("https://usyd.wd3.myworkdayjobs.com/en-US/USYD_EXTERNAL_CAREER_SITE/job/Westmead-Campus/Postdoctoral-Research-Associate-in-Mathematics-and-AI_0098843-3?q=Mathematics")[#text("Level A position")]#text(" (for first time postdocs, upcoming PhDs); and")],
[#text("a ")#link("https://usyd.wd3.myworkdayjobs.com/en-US/USYD_EXTERNAL_CAREER_SITE/job/Camperdown-Campus/Postdoctoral-Research-Fellow-in-Mathematics-and-AI_0098840-2?q=Mathematics")[#text("Level B position")]#text(" (for candidates with a postdoc / some research experience):")]
)

#text("Both positions are for three years and are based at the Sydney Mathematical Research Institute. The positions are research only, but teaching at the University of Sydney is possible if desired. The successful candidate will have considerable time and flexibility to pursue their own research program.")

#text("We are after either:")

#enum(start: 1, 
[#text("excellent mathematicians with some interest in programming and modern AI;")],
[#text("excellent computer scientists with some interest and background in mathematics, as well as an interest in using AI to attack tough problems in mathematics.")]
)

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rotating web of stars")]], [#link("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/#comment-670034")[#strong[#text("Rotating web of stars")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2022")])]

#text("And to which subject do you intend to emigrate once they are successful?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/158829d63c48361e3aa4d9b43e03336f8d8f092be94ea9a29662cdfa2355908e-17a68ffb504b34d6e9f72ff93dc4dcd93e9d6f2f2248ed81601dc54eaeeff51d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Postdoctoral Research Positions in Mathematics and AI at the Sydney Mathematics Research Institute | Observer")]], [#link("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/#comment-670120")[#strong[#text("Postdoctoral Research Positions in Mathematics and AI at the Sydney Mathematics Research Institute | Observer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2022")])]

#text("[…] Postdoctoral Research Positions in Mathematics and AI at the Sydney Mathematics Research Institute […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae33e63dcb17ea63f4021ef23c85170d4afe1222d7b135734fec6a53a235141b-7165fdc08740db9ab77c44b9d186842131b33b51d455c9fb3a83e22950d81241.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helia")]], [#link("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/#comment-670314")[#strong[#text("Helia")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2022")])]

#text("Inspiring opportunity!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a95327543d515e7764361cfe96690b394d5974d0f4c57559b4511efb00dadfd9-866af5712d767ca4e03f6a355895e7716d8b671ffcfdebec078dcaf032fbb1ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of futureleadershipacademy")]], [#link("https://terrytao.wordpress.com/2022/12/05/postdoctoral-research-positions-in-mathematics-and-ai-at-the-sydney-mathematics-research-institute/#comment-671970")[#strong[#text("futureleadershipacademy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2023")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://flacademy.school/2023/01/12/artificial-intelligence-and-human-rights-action-plan-recommendations-for-human-rights-sensitive-and-ethical-artificial-intelligence/")[#text("Artificial Intelligence and Human Rights: Action plan & recommendations for human rights-sensitive and ethical artificial intelligence.")]
]
]
