// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:16:50.675532+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tate’s proof of the functional equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tate’s proof of the functional equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("The ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("\\zeta(s)")#text(", defined for ")#mi("\\text{Re}(s) > 1")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(s) := \\sum_{n \\in {\\Bbb N}} \\frac{1}{n^s}")]]

#text("where ")#mi("{\\Bbb N} = \\{1,2,\\ldots\\}")#text(" are the natural numbers, and extended ")#link("http://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphically")]#text(" to other values of s by ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(", obeys the remarkable ")#link("http://en.wikipedia.org/wiki/Functional_equation")[#text("functional equation")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Xi(s) = \\Xi(1-s)")]]

#text("where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Xi(s) := \\Gamma_\\infty(s) \\zeta(s)")]]

#text("is the ")#link("http://en.wikipedia.org/wiki/Riemann_Xi_function")[#text("Riemann Xi function")]#text(",")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\Gamma_\\infty(s) := \\pi^{-s/2} \\Gamma(s/2)")]]

#text("is the ")#emph[#text("Gamma factor at infinity")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(" ")#mi("\\Gamma(s)")#text(" is defined for ")#mi("\\text{Re}(s) > 1")#text(" by")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Gamma(s) := \\int_0^\\infty e^{-t} t^s\\ \\frac{dt}{t}")]]

#text("and extended meromorphically to other values of s by analytic continuation.")

#text("There are many proofs known of the functional equation (2). One of them (dating back to Riemann himself) relies on the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{a \\in {\\Bbb Z}} f_\\infty(a t_\\infty) = \\frac{1}{\\left|t\\right|_\\infty} \\sum_{a \\in {\\Bbb Z}} \\hat f_\\infty(a/t_\\infty)", block: true)]]

#text("for the reals ")#mi("k_\\infty := {\\Bbb R}")#text(" and ")#mi("t \\in k_\\infty^*")#text(", where ")#mi("f")#text(" is a ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz function")]#text(", ")#tao-math("\\left|t\\right|_\\infty := \\left|t\\right|", block: false)#text(" is the usual ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean")]#text(" ")#link("http://en.wikipedia.org/wiki/Absolute_value")[#text("absolute value")]#text(" on ")#mi("k_\\infty")#text(", and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\hat f_\\infty(\\xi_\\infty) := \\int_{k_\\infty} e_\\infty(-x_\\infty \\xi_\\infty) f_\\infty(x_\\infty)\\ dx_\\infty")]]

#text("is the Fourier transform on ")#mi("k_\\infty")#text(", with ")#mi("e_\\infty(x_\\infty) := e^{2\\pi i x_\\infty}")#text(" being the standard ")#link("http://en.wikipedia.org/wiki/Character_(mathematics)")[#text("character")]#text(" ")#mi("e_\\infty: k_\\infty \\to S^1")#text(" on ")#mi("k_\\infty")#text(". (The reason for this rather strange notation for the real line and its associated structures will be made clearer shortly.) Applying this formula to the (Archimedean) Gaussian function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("g_\\infty(x_\\infty) := e^{-\\pi \\left|x_\\infty\\right|^2},", block: true)]]

#text("which is its own (additive) Fourier transform, and then applying the ")#emph[#text("multiplicative ")]#text("Fourier transform (i.e. the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text("), one soon obtains (2). (Riemann also had another proof of the functional equation relying primarily on contour integration, which I will not discuss here.) One can “clean up” this proof a bit by replacing the Gaussian by a Dirac delta function, although one now has to work formally and “renormalise” by throwing away some infinite terms. (One can use the theory of distributions to make this latter approach rigorous, but I will not discuss this here.) Note how this proof combines the additive Fourier transform with the multiplicative Fourier transform. [Continuing with this theme, the Gamma function (5) is an inner product between an additive character ")#mi("e^{-t}")#text(" and a multiplicative character ")#mi("t^s")#text(", and the zeta function (1) can be viewed both additively, as a sum over n, or multiplicatively, as an ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]#text(".]")

#text("In the famous thesis of Tate, the above argument was reinterpreted using the language of the ")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("adele ring")]#text(" ")#mi("{\\Bbb A}")#text(", with the Poisson summation formula (4) on ")#mi("k_\\infty")#text(" replaced by the Poisson summation formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{a \\in k} f(a t) = \\sum_{a \\in k} \\hat f(t/a)")]]

#text("on ")#mi("{\\Bbb A}")#text(", where ")#mi("k = {\\Bbb Q}")#text(" is the rationals, ")#mi("t \\in {\\Bbb A}")#text(", and f is now a ")#link("http://en.wikipedia.org/wiki/Schwartz-Bruhat_function")[#text("Schwartz-Bruhat function")]#text(" on ")#mi("{\\Bbb A}")#text(". Applying this formula to the adelic (or global) Gaussian function ")#mi("g(x) := g_\\infty(x_\\infty) \\prod_p 1_{{\\mathbb Z}_p}(x_p)")#text(", which is its own Fourier transform, and then using the adelic Mellin transform, one again obtains (2). Again, the proof can be cleaned up by replacing the Gaussian with a Dirac mass, at the cost of making the computations formal (or requiring the theory of distributions).")

#text("In this post I will write down both Riemann’s proof and Tate’s proof together (but omitting some technical details), to emphasise the fact that they are, in some sense, the same proof. However, Tate’s proof gives a high-level clarity to the situation (in particular, explaining more adequately why the Gamma factor at infinity (4) fits seamlessly with the Riemann zeta function (1) to form the Xi function (2)), and allows one to generalise the functional equation relatively painlessly to other zeta-functions and L-functions, such as ")#link("http://en.wikipedia.org/wiki/Dedekind_zeta_function")[#text("Dedekind zeta functions")]#text(" and Hecke L-functions.")

#text("[Note: the material here is very standard in modern algebraic number theory; the post here is partially for my own benefit, as most treatments of this topic in the literature tend to operate in far higher levels of generality than I would prefer.]")

#metadata(none) <tao-eb91206337e770d455ef>

#heading(level: 1)[#text("— Riemann’s proof —")]

#text("Applying the Poisson summation formula (2) for ")#mi("k_\\infty")#text(" to the Schwartz function (8), we see that the ")#link("http://en.wikipedia.org/wiki/Theta_function")[#text("theta function")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\Theta_\\infty( x_\\infty ) := \\sum_{n \\in {\\Bbb Z}} g_\\infty( n x_\\infty ) = 1 + 2 \\sum_{n=1}^\\infty e^{-\\pi n^2 \\left|x_\\infty\\right|_\\infty^2}", block: true)]]

#text("obeys the functional equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\Theta_\\infty( x_\\infty ) = \\frac{1}{\\left|x_\\infty\\right|_\\infty} \\Theta_\\infty( \\frac{1}{x_\\infty} )", block: true)]]

#text("for ")#mi("x_\\infty \\in k_\\infty^\\times := k_\\infty \\backslash \\{0\\}")#text(". In particular, since ")#mi("\\Theta_\\infty(x_\\infty)-1")#text(" is rapidly decreasing as ")#mi("x_\\infty \\to \\infty")#text(", we see that ")#mi("(\\Theta_\\infty(x_\\infty) - 1)/x_\\infty")#text(" is rapidly decreasing as ")#mi("x_\\infty \\to 0")#text(".")

#text("Formally, we can take Mellin transforms of (11) and conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\int_{k_\\infty^\\times} \\Theta_\\infty(x_\\infty) \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty = \\int_{k_\\infty^\\times} \\Theta_\\infty(x_\\infty) \\left|x_\\infty\\right|_\\infty^{1-s} d^\\times x_\\infty", block: true)]]

#text("for any s, where ")#tao-math("d^\\times x_\\infty := \\frac{dx_\\infty}{\\left|x_\\infty\\right|_\\infty}", block: false)#text(" is the standard multiplicative ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" on ")#mi("k_\\infty^\\times")#text(". This does not make rigorous sense, because the integrands here diverge at 0 and at infinity (which is ultimately due to the poles of the Riemann Xi function at s=0 and s=1), but let us forge ahead regardless. By making the change of variables ")#mi("y := \\pi n^2 t^2")#text(" and using (3), (4), we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\int_{k_\\infty^\\times}e^{-\\pi n^2 x_\\infty^2} \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty = \\Gamma_\\infty(s) n^{-s}", block: true)]]

#text("and so from (10) and (1) we formally have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\int_{k_\\infty^\\times} \\Theta_\\infty(x_\\infty) \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty = \\int_{k_\\infty^\\times} \\left|x_\\infty\\right|^s d^\\times x_\\infty + 2\\Gamma_\\infty(s) \\zeta(s).", block: true)]]

#text("If we casually discard the divergent integral ")#tao-math("\\int_{k_\\infty} \\left|x_\\infty\\right|^s d^\\times x_\\infty", block: false)#text(" and apply (12), we formally obtain the functional equation (2).")

#text("Of course, the above computations were totally formal in nature. Nevertheless it is possible to make the argument rigorous. For instance, when ")#mi("\\text{Re}(s) > 1")#text(", we have a rigorous version of (14), namely")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\int_{k_\\infty^\\times} (\\Theta_\\infty(x_\\infty)-1) \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty = 2 \\Gamma_\\infty(s) \\zeta(s),", block: true)]]

#text("which can be deduced from (13) and ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Fubini’s theorem")]#text(" (or by ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence")]#text("). Using (11) and a little undergraduate calculus, we can rewrite the left-hand side of (15) as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("2[ \\int_1^\\infty (\\Theta_\\infty(t)-1) (t^s + t^{1-s}) \\frac{dt}{t} - \\frac{1}{s} - \\frac{1}{1-s}].")]]

#text("Observe that this expression extends meromorphically to all of s and can thus be taken as a definition of ")#mi("\\Xi(s)")#text(" for all ")#mi("s \\neq 0, 1")#text(", and the functional equation (2) is then manifestly obvious.")

#text("Here is a slightly different way to view the above computations. Since the Gaussian (8) is its own Fourier transform, we see for every ")#mi("t > 0")#text(" that the Fourier transform of ")#tao-math("e^{-\\pi t^2 \\left|x\\right|_\\infty^2}", block: false)#text(" is ")#tao-math("\\frac{1}{t} e^{-\\pi \\left|x\\right|_\\infty^2/t^2}", block: false)#text(". Integrating this fact against ")#tao-math("\\left|t\\right|^s d^\\times t", block: false)#text(" on ")#mi("k_\\infty^\\times")#text(" using (13), we obtain (formally) at least that the Fourier transform of ")#tao-math("\\Gamma_\\infty(s) \\left|x\\right|_\\infty^{-s} d^\\times x", block: false)#text(" is ")#tao-math("\\Gamma_\\infty(1-s) \\left|x\\right|_\\infty^{1-s} d^\\times x", block: false)#text(". (Note from scaling considerations it is formally clear that the Fourier transform of ")#tao-math("\\left|x\\right|_\\infty^{-s} d^\\times x", block: false)#text(" must be some sort of constant multiple of ")#tao-math("\\left|x\\right|_\\infty^{1-s} d^\\times x", block: false)#text("; the Gamma factors can thus be viewed as the normalisation of these multiplicative characters that is compatible with the Fourier transform.) Formally applying the Poisson summation formula (4) to this, and casually discarding the singular terms at the origin, we obtain (2). One can make the above computations rigorous using the theory of distributions, and by using Gaussians to regularise the various integrals and summations appearing here, in which case the computations become essentially equivalent to the previous ones.")

#heading(level: 1)[#text("— p-adic analogues —")]

#text("The above “Archimedean” Fourier analysis on ")#mi("k_\\infty = {\\Bbb R}")#text(" has analogues in the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("p-adic")]#text(" completions ")#mi("k_p = {\\Bbb Q}_p")#text(" of the rationals ")#mi("k = {\\Bbb Q}")#text(". (This is analogous to my ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("discussion of dyadic models")]#text(", although the p-adics ")#mi("{\\Bbb Z}_p, {\\Bbb Q}_p")#text(" are still ")#link("http://en.wikipedia.org/wiki/Characteristic_%28algebra%29")[#text("characteristic")]#text(" 0 and are thus not as dyadic as their ")#link("http://en.wikipedia.org/wiki/Function_field_of_an_algebraic_variety")[#text("function field")]#text(" cousins ")#mi("{\\Bbb F}_p[[t]]")#text(", ")#mi("{\\Bbb F}_p((t))")#text(".)")

#text("Recall that the reals ")#mi("k_\\infty = {\\Bbb R}")#text(" are the ")#link("http://en.wikipedia.org/wiki/Complete_metric_space#Completion")[#text("metric completion")]#text(" of the rationals ")#mi("k = {\\Bbb Q}")#text(" with respect to the metric arising from the usual Archimedean absolute value ")#tao-math("x \\mapsto \\left|x\\right|_\\infty", block: false)#text(". This absolute value obeys the following basic properties:")

#enum(start: 1, 
[#text("Positivity: we have ")#tao-math("\\left|x\\right| \\geq 0", block: false)#text(" for all x, with equality if and only if x=0.")],
[#text("Multiplicativity: we have ")#tao-math("\\left|xy\\right| = \\left|x\\right| \\left|y\\right|", block: false)#text(" for all x, y.")],
[#text("Triangle inequality: We have ")#tao-math("\\left|x+y\\right| \\leq \\left|x\\right| + \\left|y\\right|", block: false)#text(" for all x, y.")]
)

#text("A function from k to ")#mi("{}[0,+\\infty)")#text(" with the above three properties is known as an ")#link("http://en.wikipedia.org/wiki/Absolute_value_%28algebra%29")[#text("absolute value")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Valuation_(algebra)")[#text("valuation")]#text(") on k. In addition to the Archimedean absolute value, each prime p defines a p-adic absolute value ")#tao-math("x \\mapsto \\left|x\\right|_p", block: false)#text(" on k, defined by the formula ")#tao-math("\\left|x\\right|_p := p^{-n}", block: false)#text(", where n is the number of times p divides x. (This number could be negative if the denominator of the rational number x contains factors of p.) Equivalently, ")#tao-math("\\left|x\\right|_p", block: false)#text(" is the unique valuation such that ")#tao-math("\\left|p\\right|_p = 1/p", block: false)#text(" and ")#tao-math("\\left|n\\right|_p = 1", block: false)#text(" whenever n is an integer coprime to p.")

#text("One easily verifies that ")#tao-math("\\left|x\\right|_p", block: false)#text(" is an absolute value; in fact it not only obeys the triangle inequality, but also the ")#link("http://en.wikipedia.org/wiki/Ultrametric_space")[#text("ultra-triangle inequality")]#text(" ")#tao-math("\\left|x+y\\right| \\leq \\max(\\left|x\\right|, \\left|y\\right|)", block: false)#text(", making the p-adic absolute value a non-Archimedean absolute value.")

#text("A ")#link("http://en.wikipedia.org/wiki/Ostrowski%27s_theorem")[#text("classical theorem of Ostrowski")]#text(" asserts that the Archimedean absolute value ")#tao-math("x \\mapsto \\left|x\\right|_\\infty", block: false)#text(" and the p-adic absolute values ")#tao-math("x \\mapsto \\left|x\\right|_p", block: false)#text(" are in fact the ")#emph[#text("only")]#text(" absolute values on the rationals k, up to the renormalisation of replacing an absolute value |x| with a power ")#tao-math("\\left|x\\right|^\\alpha", block: false)#text(". If we define a ")#link("http://en.wikipedia.org/wiki/Place_%28mathematics%29")[#text("place")]#text(" to be an absolute value up to renormalisation, we thus see that the rationals k have one Archimedean (or infinite) place ")#mi("\\infty")#text(", together with one non-Archimedean (or finite) place p for every prime.")

#text("One could have set ")#tao-math("\\left|p\\right|_p", block: false)#text(" to some other value between 0 and 1 than 1/p (thus replacing ")#tao-math("\\left|x\\right|_p", block: false)#text(" with some power ")#tao-math("\\left|x\\right|_p^\\alpha", block: false)#text(") and still get an absolute value; but this normalisation is natural because it allows one to write the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(" in the appealing form")

#align(center)[#tao-math("\\displaystyle \\prod_\\nu \\left|x\\right|_\\nu = 1", block: false)#text(" for all ")#mi("x \\in k^\\times")#text(" (17)")]

#text("where ")#mi("\\nu")#text(" ranges over all places, and ")#mi("k^\\times := k \\backslash \\{0\\}")#text(" is the multiplicative group of k.")

#text("If one takes the metric completion of the rationals ")#mi("k = {\\Bbb Q}")#text(" using a p-adic absolute value ")#tao-math("\\left|x\\right|_p", block: false)#text(" rather than the Archimedean one, one obtains the p-adic field ")#mi("k_p = {\\Bbb Q}_p")#text(". One can view this field as a kind of inverted version of the real field ")#mi("{\\Bbb R}")#text(", in which p has been inverted to be small rather than large. Some illustrations of this inversion:")

#enum(start: 1, 
[#text("In ")#mi("k_\\infty")#text(", the sequence ")#mi("p^n")#text(" goes to infinity as ")#mi("n \\to +\\infty")#text(" and goes to zero as ")#mi("n \\to -\\infty")#text("; in ")#mi("k_p")#text(", it is the other way around.")],
[#text("Elements of ")#mi("k_\\infty")#text(" can be expressed base p as strings of digits that need not terminate to the right of the decimal point, but must terminate to the left. In ")#mi("k_p")#text(", it is the other way around. (The famous ambiguity ")#mi("0.999\\ldots=1.000\\ldots")#text(" in ")#mi("k_\\infty")#text(" does not occur in the p-adic field ")#mi("k_p")#text(", because the latter has the topology of a ")#link("http://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(" rather than a ")#link("http://en.wikipedia.org/wiki/Continuum_%28mathematics%29#Topology")[#text("continuum")]#text(".)")],
[#text("In ")#mi("k_\\infty")#text(", the integers ")#mi("{\\Bbb Z}")#text(" is closed and forms a discrete ")#link("http://en.wikipedia.org/wiki/Cocompact")[#text("cocompact ")]#text("additive subgroup. In ")#mi("k_p")#text(", the integers are not closed, but their closure ")#mi("{\\mathcal O}_p = {\\Bbb Z}_p")#text(" (the ring of p-adic integers) forms a compact codiscrete additive subgroup.")]
)

#text("Despite this inversion, we can obtain analogues of most of the additive and multiplicative Fourier analytic computations of the previous section for the p-adics.")

#text("Let’s first begin with the additive Fourier structure. By the theory of Haar measures, there is a unique translation-invariant measure ")#mi("dx_p")#text(" on ")#mi("k_p = {\\Bbb Q}_p")#text(" which assigns a unit mass to the compact codiscrete subgroup ")#mi("{\\mathcal O}_p = {\\Bbb Z}_p")#text(". One can check that this measure interacts with dilations in the expected manner, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\int_{k_p} f(tx_p)\\ dx_p = \\frac{1}{\\left|t\\right|_p} \\int_{k_p} f(x_p)\\ dx_p", block: true)]]

#text("for all absolutely integrable f and all invertible ")#mi("t \\in k_p^\\times := k_p \\backslash \\{0\\}")#text(".")

#text("Just as ")#mi("k_\\infty")#text(" has a standard character ")#mi("e_\\infty: x \\mapsto e^{2\\pi i x}")#text(", we can define a standard character ")#mi("e_p: k_p \\to S^1")#text(" as the unique character (i.e. continuous homomorphism from ")#mi("k_p")#text(" to ")#mi("S^1")#text(") such that ")#mi("e_p(p^n) = e^{2\\pi i p^n}")#text(" for all integers n (in particular, ")#mi("e_p")#text(" is trivial on the integers, just as ")#mi("e_\\infty")#text(" is). One easily verifies that this is indeed a character. From this and the additive Haar measure ")#mi("dx_p")#text(", we can now define the p-adic Fourier transform")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\hat f(\\xi_p) := \\int_{k_p} e_p( - x_p \\xi_p ) f(x_p)\\ dx_p")]]

#text("for reasonable (e.g. absolutely integrable) f, and it is a routine matter to verify all the usual Fourier-analytic identities for this transform (or one can appeal to the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("general theory of Fourier analysis on locally compact abelian groups")]#text(").")

#text("In ")#mi("k_\\infty")#text(", we have the Gaussian function (8), which is its own Fourier transform. In ")#mi("k_p")#text(", the analogous Gaussian function ")#mi("g_p: k_p \\to {\\Bbb C}")#text(" is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("g_p := 1_{{\\mathcal O}_p},")]]

#text("i.e. the p-adic Gaussian is just the indicator function of the p-adic integers. One easily verifies that this function is also its own Fourier transform.")

#text("Now we turn to the multiplicative Fourier theory for ")#mi("k_p")#text(". The natural multiplicative Haar measure ")#mi("d^\\times x_p")#text(" on ")#mi("k_p^\\times")#text(" is given by the formula ")#tao-math("d^\\times x_p := \\frac{p}{p-1} \\frac{dx_p}{\\left|x_p\\right|_p}", block: false)#text("; the normalisation factor ")#mi("\\frac{p}{p-1}")#text(" is natural in order for the group of ")#link("http://en.wikipedia.org/wiki/Unit_%28ring_theory%29")[#text("units ")]#mi("{\\mathcal O}_p^\\times = {\\Bbb Z}_p \\backslash p {\\Bbb Z}_p")#text(" to have unit mass.")

#text("In ")#mi("k_\\infty")#text(", we see from (13) that the Gamma factor at infinity can be expressed (for ")#mi("\\text{Re}(s) > 1")#text(") as the Mellin transform of the Gaussian:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\Gamma_\\infty(s) = \\int_{k_\\infty^\\times} g_\\infty(x_\\infty) \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty.", block: true)]]

#text("In analogy with this, we can define the Gamma factor at p by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\Gamma_p(s) = \\int_{k_p^\\times} g_p(x_p) \\left|x_p\\right|_p^s d^\\times x_p.", block: true)]]

#text("Due to the simple and explicit nature of all the expressions on the right-hand side, it is a straightforward matter to compute this factor explicitly; it becomes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Gamma_p(s) = (1 - p^{-s})^{-1}")]]

#text("for ")#mi("\\text{Re}(s) > 1")#text(", at least; of course, one can then extend ")#mi("\\Gamma_p")#text(" meromorphically in the obvious manner.")

#text("In ")#mi("k_\\infty")#text(", we showed (formally, at least) that ")#tao-math("\\Gamma_\\infty(s) \\left|x\\right|_\\infty^s", block: false)#text(" and ")#tao-math("\\Gamma_\\infty(1-s) \\left|x\\right|_\\infty^{1-s}", block: false)#text(" were Fourier transforms of each other. One can similarly show that ")#tao-math("\\Gamma_p(s) \\left|x\\right|_p^s", block: false)#text(" and ")#tao-math("\\Gamma_p(1-s) \\left|x\\right|_p^{1-s}", block: false)#text(" are Fourier transforms of each other in ")#mi("k_p")#text(".")

#text("On the other hand, there is no obvious analogue of the Poisson summation formula manipulations for ")#mi("k_p")#text(", because (unlike ")#mi("k_\\infty")#text("), ")#mi("k_p")#text(" lacks a discrete cocompact subgroup.")

#heading(level: 1)[#text("— Tate’s proof —")]

#text("We have just performed some “local” additive and multiplicative Fourier analysis at a single place. (This use of “local” may seem unrelated to the topological or analytical notion of “local”, as in “in the vicinity of a single point”, but it is actually much the same concept; compare for instance the formal power series in p for a p-adic number with the Taylor series expansion in ")#mi("t-t_0")#text(" of a function f(t) around a point ")#mi("t_0")#text(". Indeed one can view local analysis at a place p as being the analysis of the integers or rationals when p is “close to zero”; one can make this precise using the language of schemes, but we will not do so here.)")

#text("In his famous thesis, Tate observed that all these local Fourier-analytic computations could be unified into a single global Fourier-analytic computation, using the languge of the adele ring ")#mi("{\\Bbb A}")#text(". This ring is the set of all tuples ")#mi("x = (x_\\nu)_\\nu")#text(", where ")#mi("\\nu")#text(" ranges over places and ")#mi("x_\\nu \\in k_\\nu")#text(", and furthermore all but finitely many of the ")#mi("x_\\nu")#text(" lie in their associated ring of integers ")#mi("{\\mathcal O}_\\nu")#text(". (Equivalently, the ")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("adele ring")]#text(" is the ")#link("http://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" of the rationals ")#mi("k = {\\Bbb Q}")#text(" with the ring of integral adeles ")#mi("{\\Bbb R} \\times \\prod_p {\\Bbb Z}_p")#text(".) This restriction that the ")#mi("x_\\nu")#text(" consists mostly of integers in ")#mi("k_\\nu")#text(" is important for a large variety of analytic and algebraic reasons; for instance, it keeps the adele ring ")#link("http://en.wikipedia.org/wiki/Sigma-compact")[#mi("\\sigma")#text("-compact")]#text(".")

#text("Many of the structures and objects on the local fields ")#mi("k_\\nu")#text(" can be multiplied together to form corresponding global structures on the adele ring. For instance:")

#enum(start: 1, 
[#text("The commutative ring structures on the ")#mi("k_\\nu")#text(" multiply together to give a commutative ring structure on ")#mi("{\\Bbb A}")#text(".")],
[#text("The locally compact Hausdorff structures on the ")#mi("k_\\nu")#text(" multiply together to give a locally compact Hausdorff structure on ")#mi("{\\Bbb A}")#text(".")],
[#text("The local additive Haar measures ")#mi("dx_\\nu")#text(" on the ")#mi("k_\\nu")#text(" multiply together to give a global additive Haar measure ")#mi("dx")#text(" on ")#mi("{\\Bbb A}")#text(".")],
[#text("The local characters ")#mi("e_\\nu: k_\\nu \\to S^1")#text(" on the ")#mi("k_\\nu")#text(" multiply together to give a global character ")#mi("e: {\\Bbb A} \\to S^1")#text(" (here it is essential that most components of an adele are integers, and so are trivial with respect to their local character).")],
[#text("The local additive Fourier transforms on the ")#mi("k_\\nu")#text(" then multiply to form a global additive Fourier transform on ")#mi("{\\Bbb A}")#text(", defined as ")#mi("\\hat f(\\xi) := \\int_{\\Bbb A} e(-x \\xi) f(x)\\ dx")#text(" for reasonable f.")],
[#text("The local absolute values ")#tao-math("x_\\nu \\mapsto \\left|x_\\nu\\right|_\\nu", block: false)#text(" on ")#mi("k_\\nu")#text(" multiply to form a global absolute value ")#tao-math("x \\mapsto \\left|x\\right|", block: false)#text(" on ")#mi("{\\Bbb A}")#text(", though with the important caveat that |x| can vanish for non-zero x (indeed, a simple calculation using Euler’s observation ")#mi("\\prod_p (1-\\frac{1}{p})=0")#text(" shows that almost every x does this, with respect to additive Haar measure). The x for which |x| is non-zero are invertible and known as ")#link("http://en.wikipedia.org/wiki/Idele")[#text("ideles")]#text(", and form a multiplicative group ")#mi("{\\Bbb A}^\\times")#text("; the ideles have measure zero inside the adeles.")],
[#text("The local gaussians ")#mi("g_\\nu: k_\\nu \\to {\\Bbb C}")#text(" multiply together to form a global gaussian ")#mi("g: {\\Bbb A} \\to {\\Bbb C}")#text(", which is its own Fourier transform.")],
[#text("The embeddings ")#mi("k \\subset k_\\nu")#text(" at each place ")#mi("\\nu")#text(" multiply together to form a diagonal embedding ")#mi("k \\subset {\\Bbb A}")#text(". This embedding is both discrete (by the fundamental theorem of arithmetic) and cocompact (this is basically because the integers are cocompact in the adelic integers).")],
[#text("The local multiplicative Haar measures ")#mi("d^\\times x_\\nu")#text(" multiply together to form a global multiplicative Haar measure ")#mi("d^\\times x")#text(", though one should caution that this measure is supported on the ideles ")#mi("{\\Bbb A}^\\times")#text(" rather than the adeles ")#mi("{\\Bbb A}")#text(".")],
[#text("The local Gamma factors ")#mi("\\Gamma_\\nu(s)")#text(" for each place ")#mi("\\nu")#text(" multiply together to form the Riemann Xi function (3) (for ")#mi("\\text{Re}(s)>1")#text(" at least), thanks to the Euler product formula ")#mi("\\zeta(s) = \\prod_p (1-p^{-s})^{-1}")#text(".")]
)

#text("Recall that the local Gamma factors were the local Mellin transforms of the local Gaussians. Multiplying this together, we see that the Riemann Xi function is the global Mellin transform of the global Gaussian:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\Xi(s) = \\int_{{\\Bbb A}^\\times} g(x) \\left|x\\right|^s d^\\times x.", block: true)]]

#text("Our derivation of (24) used the Euler product formula. Another way to establish (24) using the original form (1) of the zeta function is to observe (thanks to the fundamental theorem of arithmetic) that the set ")#mi("J := {\\Bbb R}^+ \\times \\prod_p {\\mathcal O}_p^\\times")#text(" is a fundamental domain for the action of ")#mi("k^\\times")#text(" on ")#mi("{\\Bbb A}^\\times")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("{\\Bbb A}^\\times = \\biguplus_{a\\in k^\\times} a \\cdot J.")]]

#text("Partitioning (24) using (25) and then using (13) and (1) one can give an alternate derivation of (24). (The two derivations are ultimately the same, of course, since the Euler product formula is itself essentially a restatement of the fundamental theorem of arithmetic.)")

#text("In his thesis, Tate established the Poisson summation formula (9) for the adeles for all sufficiently nice f (e.g. any f in the ")#link("http://en.wikipedia.org/wiki/Schwartz-Bruhat_function")[#text("Schwartz-Bruhat class")]#text(" would do). Applying this to the global gaussian g, we conclude that the global Theta function ")#mi("\\Theta(x) := \\sum_{a \\in k} g(ax)")#text(" obeys the functional equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\Theta(x) = \\frac{1}{\\left|x\\right|} \\Theta(\\frac{1}{x})", block: true)]]

#text("for all ideles t. This formally implies that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27),")])
#tao-math("\\int_J \\Theta(x) \\left|x\\right|^s d^\\times x =  \\int_J \\Theta(x) \\left|x\\right|^{1-s} d^\\times x", block: true)]]

#text("which on applying (25) and (24) (and casually discarding the singular contributions of ")#mi("a=0")#text(") yields the functional equation (2). One can make this formal computation rigorous in exactly the same way that Riemann’s proof was made rigorous in previous sections.")

#text("Recall that Riemann’s proof could also be established by inspecting the Fourier transforms of ")#tao-math("\\displaystyle \\Gamma_\\infty(s) \\left|x_\\infty\\right|_\\infty^s d^\\times x_\\infty", block: false)#text(". A similar approach can work here. If we (very formally!) apply the Poisson summation formula (9) to the measure ")#tao-math("\\displaystyle 1_J(x) \\left|x\\right|^s\\ d^\\times x", block: false)#text(", one obtains")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("1 = \\sum_{a \\in k} \\int_J e(-ax) \\left|x\\right|^s\\ d^\\times x.", block: true)]]

#text("Unpacking this summation using (25) (and (17)), and casually discarding the a=0 term, we formally conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("1 = \\int_{{\\mathbb A}^\\times} e(-x) \\left|x\\right|^s\\ d^\\times x.", block: true)]]

#text("Rescaling this, we formally conclude that the Fourier transform of ")#tao-math("\\left|x\\right|^s\\ d^\\times x", block: false)#text(" is ")#tao-math("\\left|x\\right|^{1-s}\\ d^\\times x", block: false)#text(". Inserting this into (24), the functional equation (2) formally follows from ")#link("http://en.wikipedia.org/wiki/Parseval%27s_theorem")[#text("Parseval’s theorem")]#text("; alternatively, one can derive it by multiplying together all the local facts that the Fourier transform of ")#tao-math("\\Gamma_\\nu(s) \\left|x_\\nu\\right|_\\nu^s\\ d^\\times x_\\nu", block: false)#text(" in ")#mi("k_\\nu")#text(" is ")#tao-math("\\Gamma_\\nu(1-s) \\left|x_\\nu\\right|_\\nu^{1-s}\\ d^\\times x_\\nu", block: false)#text(". These arguments can be made rigorous using the theory of distributions (and a lot of care), but we will not do so here.")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b59a0c8e1e75e348a723611c07a9ac5c0addeab6e3c34d3381d05caaa333c6c3-72a0ac370ffa13340531a236bb4fde5c1de43dcb0477d5fc03436b96133118cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chandan Singh Dalawat")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31570")[#strong[#text("Chandan Singh Dalawat")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2008")])]

#text("> their function field cousins {\\Bbb F}_p(t), {\\Bbb F}_p(t)[1/t].")

#text("You mean {\\Bbb F}_p[[t]] and {\\Bbb F}_p((t)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31573")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Borcherds")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31577")[#strong[#text("Richard Borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2008")])]

#text("Andre Weil gave a neat explanation for the mysterious gamma factor (p-adic or real). The key point is that for each degree (=character of k^*), there is a unique distribution (up to a constant) that is homogeneous of that degree. (This is obvious at non-zero points; one has to think a bit about what happens at 0.) The gamma factor is what one has to multiply the “obvious homogeneous distributions” |x|^s and so on by to get a function that is holomorphic for ALL complex s. (The gamma factor is uniquely determined by this given some normalization and growth conditions.) The functional equation then follows trivially becuase the Fourier transform of a homogeneous distribution is also homogeneous (of some other degree).")

#text("In higher rank groups, the analogue of Weil’s description of the gamma factor gives")#linebreak()#text(" the local L-factor of an automorphic form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anders")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31590")[#strong[#text("anders")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("Thanks for a very nice post. I was wondering, once you have Tate’s machinery in place, how much extra work is necessary in order to calculate the residue at 1 of the Xi function (in most textbooks dealing with Tate’s thesis the analytic class number formula seems to be proven more or less concurrently with the functional equation).")

#text("More generally do you always get results regarding special values of the zeta-function at suitable integers, when you have a Tate-style (=harmonic analysis on adele/idele) proof of the functional equation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anders")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31591")[#strong[#text("anders")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("I mean zeta-functions of more general arithmetic objects in my follow-up question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90c02f41607c68dc2bed941e13427d5caa05ebbef2fbcce8749d6ba70055a4a2-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31606")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("Hi Anders,")#linebreak()#text(" The special values of zeta and L-functions are a very subtle business. But a few words in response to your question:")

#text("1. When an L-function has a pole, this is expected to always be for a ‘good reason.’ For example, a cusp form on GL(2n) (satisfying some auxiliary conditions) is known to be a functorial lifting from either SO(2n) or SO(2n+1) according to whether its symmetric square or exterior square L-function has a pole, respectively. Another example arises in the Tate conjecture, whereby an L-function attached to the etale cohomology of a variety is expected to have a pole whose order equals the dimension of a certain group of algebraic cycles.")

#text("2. The question of determining at which points an L-function takes interesting or arithmetically significant values is a subtle business. There is a formalism due to Deligne which characterizes these critical points in terms of the archimedian Langlands parameters; so for example, the Riemann zeta function is interesting at n=2,4,6,8… while the Dirichlet L-function attached to the real character of conductor 4 is interesting at n=1,3,5,7…. because these two L-functions have different gamma factors. And to the best of my knowledge, proofs of special value formulae almost never arise from the Tate-style proof of analytic continuation, with Dedekind zeta functions and the associated analytic class number formula being a notable exception.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4e1a73953be134bb5fd91b9c5761a22ae99047f124b929a587fd309c0bf649c-87128c91c4823bae580e0e3609ea4e940f96a8809d71cc317a58651229746ec2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anders Karlsson")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31612")[#strong[#text("Anders Karlsson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("Hi,")#linebreak()#text(" I could add that Euler’s formula for the special values of the Riemann zeta at n=2,4,6,… in fact follows from Riemann’s approach taking a Laplace transform on (11) instead of the Mellin transform, and series expand both sides. See “Applications of heat kernels on abelian groups: ζ(2n), quadratic reciprocity, Bessel integrals” which is a preprint on my webpage for details. It’s the only reference for this that I know of. The approach generalizes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2008")])]

#text("is there a nice way to save a blog leaving out the links on the side?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31659")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("Dear Anonymous,")

#text("I have found the best way to save (or print) these entries is to cut and paste the text into a word processor. Most of the newer ones (MS Word, for example) will preserve the formatting and tex images.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31674")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("Dear Richard: Thanks for the comment! I can sort of see why the analyticity criterion would uniquely determine the Gamma factor (by Weierstrass factorisation) though it is not so obvious to me why there would be existence for this Gamma factor (unless one already possessed a “gaussian” function that was its own Fourier transform and had good decay and regularity properties, as in the post). Still, it is a very pretty way to canonically define these things.")

#text("Dear Anders: I don’t really have a good answer to your question, but once one has a functional equation, one can compute the values at positive integers from the values at negative integers, which have a more “polynomial” nature to them and so would presumably be able to be computable explicitly in many cases. For instance, I believe one can extract the value of ")#mi("\\zeta(-k)")#text(" for integer k by computing the asymptotics for partial sums like ")#mi("\\sum_{n=1}^N n^k")#text(", or perhaps ")#mi("\\sum_{n=1}^\\infty \\psi(n/N) n^k")#text(" for a suitable cutoff function ")#mi("\\psi")#text(", and discarding the leading (or “archimedean”) term. The explicit formulae for these sums involve Bernoulli numbers and so it is not terribly surprising that the same is true for the zeta function (though it is unfortunate that one does not get any non-trivial result when k is even).")

#text("Dear anonymous #1: If you “print preview” a page from this blog then you can get a version of that page without the sidebar, which you should then be able to save to a file using your browser.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yong-Hui")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31722")[#strong[#text("Yong-Hui")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2008")])]

#text("Some Questions:")

#text("If we fixed the Gamma factors, the L-functions with these fixed Gamma factors will form a linear space over C. Is that linear space finite dimension?")

#text("The answer is positive for automorphic L-function, because of the analytic strong multiplicity one theorem for automorphic forms.")

#text("It says, if the analytic conductor (conductor \\times parameter in Gamma factors) is fixed, then the automorphic L-function is determined by its finite coefficients.")

#text("But is that possible to determine the basis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31723")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2008")])]

#text("Yong-Hui, the space is not finite dimensional. For example, L-functions corresponding to even primitive Dirichlet characters all share the same Gamma factor, yet they do not form a finite dimensional space. Maybe your definition of the gamma factor differs from mine. At any rate, the strong multiplicity theorem implies that even when you don’t fix the analytic conductor, an automorphic L-function is still determined by its finite coefficients. You can even omit any finite number of local factors at various places, the remaining partial L-function still determines the underlying automorphic representation. Finally, “determining” an L-function is a vague concept. Most automorphic L-functions don’t even have algebraic coefficients, at least this is what we conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31724")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2008")])]

#text("It’s not even clear to me what")

#text("“the L-functions with these fixed Gamma factors will form a linear space over C”")

#text("really means. If L-functions are assumed to have an Euler product (as is often assumed to be part of the definition), then they do not form a vector space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31728")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2008")])]

#text("Maybe he/she meant the vector space generated by these objects, at least this is what I had in mind in my comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yong-Hui")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31739")[#strong[#text("Yong-Hui")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2008")])]

#text("Thanks for the comments of Harcos and Kowalski. Though they have answered my questions, I should still be responsible for clarifing my question in detail:")

#text("1. If we only consider the functional equation, (not Euler product), does the L-functions with the same Gamma factors form a linear space? Harcos has given the negative answer by the example of even Dirichlet L-function. Maybe I should add a further condition: also with the same conductors, that is, does the L-functions with the same type of functional equation form a linear space?")

#text("2. At a first glance, it seems to be true. But as Kowalski commented, if we assume that these L-functions also have an Euler Product, then they do not form a vector space. For example, look the classical Hecke modular form, the coefficients must obey")#linebreak()#text(" a(n)a(m)=a(mn) if (m,n)=1,")#linebreak()#text(" which shows the addition and scalar multiplication is not closed in that space.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d58677b4023c07b9b61cf0df9fef1bc113847e309100e069a0553cbecbd3aa2-30758f8d1f45cd3689e45046e6532a6d5e9799c1bc00d595c3d66f9be73b61c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yong-Hui")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31740")[#strong[#text("Yong-Hui")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2008")])]

#text("3. So take the classical holomorphic cusp form as the example:")

#text("a) ")#mi("S_k(SL_2(Z))")#text(" is a linear space, and hence the corresponding L-functions also form a linear space of finite dimension.")

#text("b) ")#mi("S_k(SL_2(Z))")#text(" has a basis consists of Hecke eigenfunctions, but the Hecke eigenfunctions does not form a linear space. That is, if the corresponding functions with assumption of Euler products does not form a linear space.")

#text("I remember that, it will be very difficult to find a basis in ")#mi("S_k(\\Gamma)")#text(", even ")#mi("\\Gamma=SL_2(Z)")#text(", is that true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2008")])]

#text("Finding a basis in the case that ")#mi("\\Gamma")#text(" is equal to the full modular group is actually very simple (one can give a basis quite explicitly in terms of Eisenstein series, and then linear algebra is essentially all that is required to find a basis of Hecke eigenforms). I suspect that it is not much different in the general case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39fc762daf6882898682f2453b1d80c6d317ad202a10c17afc6ac44392cf3d9d-3f5e375e884a1bf0fdb01172f635fb7f405b755bd11120acfcd7bd376b53ded7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ijon Tichy")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31768")[#strong[#text("Ijon Tichy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2008")])]

#text("Sorry to butt in with a monumental display of ignorance, but I was wondering what is the difference between ")#mi(":=")#text(" and ")#mi("=")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2008")])]

#text("The symbol $:=$ means ‘is defined to be.’ It’s usually used only when one is introducing a function or notation for the first time. Mathematically, it is equivalent to the more commonplace $=$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39fc762daf6882898682f2453b1d80c6d317ad202a10c17afc6ac44392cf3d9d-3f5e375e884a1bf0fdb01172f635fb7f405b755bd11120acfcd7bd376b53ded7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ijon Tichy")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31776")[#strong[#text("Ijon Tichy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2008")])]

#text("Thank you, Anonymous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b328a95363b93144d0b099b8d972c35a58b39e545337dcbcb912b70b404d220-a13fa6b910ac1b7dd98e9ae35e10d9a5a4f984e5f5025e60163db4f34feb804f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bad mathematician")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31830")[#strong[#text("bad mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2008")])]

#text("Terry, you are amazing! I will never be able to understand what you did there even with a Ph.D in maths!")

#text("You are true genious and my hero!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-31842")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2008")])]

#text("Just trying to understand Prof. Borcherds’s comment a bit better")#linebreak()#text(" (probably at the cost of some redundancy, but anyway): if I recall")#linebreak()#text(" correctly the discussion on homogeneous distributions on,")#linebreak()#text(" say, Section 3.2 of Hörmander’s 4-volume book on linear PDE, the")#linebreak()#text(" gamma function ")#mi("\\Gamma(a+1)")#text(" appears because it has")#linebreak()#text(" simple poles at precisely the location of the dimensional poles")#linebreak()#text(" of ")#mi("x^a_{\\pm}")#text(" (that is, the poles of ")#mi("x^a_{\\pm}(\\phi)")#linebreak()#text(" seen as a function of ")#mi("a")#text(", where ")#mi("\\phi")#text(" is any test")#linebreak()#text(" function), which are _also _simple, and also because the Gamma")#linebreak()#text(" function has no zeroes. Wouldn’t the normalization of ")#mi("\\frac{x^a_{\\pm}}{\\Gamma(a+1)}")#text(" at each pole $a$,")#linebreak()#text(" together with the above remark, uniquely determine the Gamma")#linebreak()#text(" factor by some, say, Mittag-Leffler-type argument?")

#text("If all of the above is true, I wonder how to go from this to")#linebreak()#text(" non-Archimedean valuations, or even the adèle ring…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("By the way, an interesting ")#link("http://arxiv.org/abs/0901.2057")[#text("proof of the Riemann hypothesis on the zeros of the zeta function")]#text(" is submitted to arXiv. Personally I could not find any errors in this proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Dear anonymous,")

#text("I took a look at the preprint. The strategy, at least, is clear (in contrast to some other attempts at the problem): create a class of holomorphic functions on a strip whose zeroes are necessarily on the real line, and show that the Riemann Xi function (a close cousin of the zeta function) is in this class. But there are three problems with this, in increasing order of generality:")

#text("1. The author’s claim that Xi is in this class (page 2) is incorrect: the function ")#mi("e^{-n^2 \\pi e^{2x}}")#text(" has the required super-Gaussian decay as ")#mi("x \\to +\\infty")#text(", but not as ")#mi("x \\to -\\infty")#text(".")

#text("2. More generally, the class of functions specified is in fact empty. This can be seen by combining the Paley-Wiener theorem with Hardy’s uncertainty principle (a non-trivial function and its Fourier transform cannot both decay at super-Gaussian rates). (It is likely that the author’s own arguments can also be modified to achieve this result.) This of course helps explain point 1. above.")

#text("3. More generally still, the conditions used to define the class are essentially linear (for any f, g in the class, f+tg will be in the class for all but at most one value of t), whereas the condition of having all zeroes on the real line is extremely nonlinear (for any f, g with zeroes on the real line, and not scalar multiples of each other, f+tg will have a zero off the real line for uncountably many t). So the only classes of this type for which all zeroes are real have to be at most one-dimensional (e.g. scalar multiples of the Xi function, assuming RH). This helps explain point 2. above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ADam")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35380")[#strong[#text("ADam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Hi Terry,")#linebreak()#text(" Can it be shown that 2/3 of the zeros are on the 1/2 line? Surely a nonlinear delay equation expert could get 9/10.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35383")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("> More generally, the class of functions specified is in fact empty.")

#text("What about the function ")#mi("e^{-x^4}")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2009")])]

#text("Hmm, fair enough; I managed to mis-apply the Paley-Wiener theorem, and so points 1. and 2. no longer apply. But point 3 is still valid: by taking a suitable linear combination of ")#mi("e^{-x^4}")#text(", ")#mi("e^{-x^6}")#text(", and ")#mi("e^{-x^8}")#text(", for instance, one can create a zero off the real line without violating any of the hypotheses of the theorem, so something must be wrong with the proof of that theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2009")])]

#text("Actually point 3. applies if the author considers complex-valued functions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bith")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35502")[#strong[#text("Bith")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2009")])]

#text("Hi ADam,")#linebreak()#text(" Lord Cherwell encountered y'(x) = – log2 y(x-1) [1+y(x)] in his application of probability methods to the distribution of prime numbers. However, it is not clear how to attack this model with \\alpha \\geq 37/24 replacing log2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ref2BB")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-35640")[#strong[#text("ref2BB")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2009")])]

#text("Hi Terry,")#linebreak()#text(" What do you think about the R\\'{e}dei zeta function for finite abelian groups? E.g., K. S. Alexander, K. Baclawski, G.-C. Rota, Proc. Nat. Acad. Sci. U.S.A. 90.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-37979")[#strong[#text("245C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] Another example of an LCA group, of importance in number theory, is the adele ring , discussed in this earlier blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Selberg’s limit theorem for the Riemann zeta function on the critical line « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-40033")[#strong[#text("Selberg’s limit theorem for the Riemann zeta function on the critical line « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("[…] can be viewed as a consequence of the Poisson summation formula, see e.g. my blog post on this topic) we know that there are no zeroes for either (except for the trivial zeroes at negative even […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-45496")[#strong[#text("Essay on Tate’s thesis « Motivic stuff")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2010")]

#text("[…] Posted by Andreas Holmstrom on June 14, 2010 Many years ago I wrote an essay on Tate’s thesis, which is now (finally) available here. This is the “baby case” of the global Langlands correspondence, and involves lots of interesting mathematics. Obviously there are many other introductions to Tate’s thesis on the web, for example on the blog of Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aaa3ed345f0c4f0f3f1984fc1a4d4cfcabd57babd2e1954273eac5b753c26474-1dab5af85287b948389d871ceeb60b9038f747adb86a17e5dbe644d42d18f276.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul-Olivier Dehaye")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-47197")[#strong[#text("Paul-Olivier Dehaye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("I think in equation (18), you need to clarify that you want the p-adic valuation of t, not the usual absolute value.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-53357")[#strong[#text("局部紧群上的Fourier分析 « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2011")]

#text("[…] Atiyah在谈到20世纪的数学时举出了几个趋势：从有限维到无穷维，从交换到非交换等等。Peter-Weyl定理保证拓扑群的所有不可约表示都是有限维的，这绝对依赖于的紧性，故可以视为一个“非交换却有限”的结果。如果我们限定是交换的，作为补偿，可以将对的紧性要求放宽为局部紧性。此时得到的理论推广了经典意义下的Fourier分析。特别的，整个类域论和自守形式理论都可以包括到这个框架里来（这方面的奠基性工作可以参考Tao Tate’s proof of the functional equation)。研究其非交换推广是当前数学的核心，这一研究涉及Langlands纲领，表示论，算子代数乃至数学物理等广阔的领域。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-340694")[#strong[#text("Some articles on Tate’s Thesis | My Math Diary")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2014")]

#text("[…] Analysis on Number Fields has a bit about Langland Terry Tao on Tate’s proof of the function equation An Introduction to Tate’s Thesis brief Introduction to L-function I: Tate’s thesis: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d8d6035940bbb6541eda1bb3af2e7719f20796c117de01c037cd90690165602-d30b6f547c94962fd0da8c72e3c1603d6ed7aa26363aa3130872fa9dd3616a5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of HASSINE SAIDANE")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-358205")[#strong[#text("HASSINE SAIDANE")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2014")])]

#text("Question: Is the Rieman Zeta function absolutely convergent in the critical strip?")

#text("I can’t find an wxplicit answer to the question above.")

#text("Thanks")

#emph[#text("[No, the Dirichlet series for the Riemann zeta function is not absolutely convergent in the critical strip. ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("http://en.wikipedia.org/wiki/Riemann_zeta_function")]#text(" -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-448167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2015")])]

#text("This is a convenient formula to keep in mind, because it holds for real values of s greater than 0, not just real values of s greater than 1:")

#mi("\\zeta(s) = \\frac{1}{1 - 2^{1-s}} \\sum_{n=1}^\\infty (-1)^{n-1} \\frac{1}{n^s}")

#text("\\zeta(s) = \\frac{1}{1 – 2^{1-s}} \\sum_{n=1}^\\infty (-1)^{n-1} \\frac{1}{n^s}")

#text("I also pasted the code in case the website doesn’t compile it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43712a8f8b0ffc9da4551750ab2dad06a66abed5dfbfeccbd97b40aa12c78ec1-b0452daad839c4474a70430e870acc03db433125acfa9faa888704b30d6ccc2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-410003")[#strong[#text("mike")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Hi:")

#text("I am not a professional mathematician but really love math.")

#text("I am looking for information on the in-depth analysis of Huseynov’s 2009 preprint titled” On a class of entire functions, all the zeros of which are real”. The latest version (v3) has been withdrawn by the author, due to an error in the inequality after the inequality (31)..")

#text("I downloaded v2.")

#text("I guess that there might be something useful if one applies similar approach but with different family of function $f_m(x)$.")

#text("My questions are the following,")

#text("(1) which inequality after the inequality (31) has an error ?")

#text("(2) suppose that this inequality is correct, can the rest of derivation follows through to the end?")

#text("thanks-")#linebreak()#text(" mike")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Sands")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-448666")[#strong[#text("George Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("Terry, You make a comment, I believe in the zeta function notes somewhere about certain functions which decay rapidly (go to zero very quickly as x grows large). I just can’t recall your use of language, which obviously comes from an extant literature. Consider the integral, which I think is an example of the phenomenon you were alluding to, ")#mi("\\int_1^\\infty e^{-e^x} Sin(ax)dx")#text(" for ")#mi("a \\in \\mathbb R")#text(". I don’t think that this integral, for any a suitably large and positive can equal zero….but that part may not have been included in what you said.")

#text("I wanted to make a note of it, but I failed to bookmark it, which is what would have been smart. If you can direct me, I’d appreciate it. Hope this jogs your memory. Best I can do.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Sands")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-448668")[#strong[#text("George Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("Please note — the example I posted does, I think, equal zero for some a. One might need a more rapidly declining function than ")#mi("e^{-e^x}")#text(" by which to multiply ")#mi("sin(ax)")#text(", but it is not a particular example with which I am concerned, but the language you used, which I can’t bring back to my own memory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Sands")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-448669")[#strong[#text("George Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("For some reason, I think it was on a December 16 post, and I can’t remember if it was in the main post in the comments and replies. Could be wrong, however, about the date.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bfa109f1478b0c1282dc15cdca155b0616e46fc01aeb29cd94b0248cb7759d2-d4a9c6a0c22abf1a9cb9af1741345c908aa62862a645a9fcfa6193d65a9a2727.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anderson de Araujo")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-472551")[#strong[#text("Anderson de Araujo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2016")])]

#text("Dear,")

#text("There is some importance in proving the result based on Riemann’s observation that if ")#mi("N (T)")#text(" denotes the number of roots ")#mi("\\rho")#text(" in the range ")#mi("0 <Im \\rho <T")#text(". Then")

#mi("N (2\\pi T) \\geq (\\Pi(T))^{1/2}")

#text("for ")#mi("T")#text(" large enough, where ")#mi("\\Pi(T)=\\#\\{p \\textup{ prime } / p\\leq T\\}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af9caae6febe5d6f9af61610108ef30c06711f173398a24f01ad2dac282d32eb-48d2574699d73596f7ffd2e774c6fad0286c722d22968087d4c12ee6c199cab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-474532")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2016")])]

#text("Dear Prof. Tao,")

#text("I think in equations (13) – (15) the domain of integration should be the nonzero field elements.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-474561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2016")])]

#text("Formula (15) does not parse.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8752ae92041fe72dffd3fa306cb74775fe2840d6a4da3588d728c54e093f5a8-647f1ba241a15852bec7f89b2357541e31cb985f1ea00c22919f37efa5963319.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-474920")[#strong[#text("h")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2016")])]

#text("On “we see that \\Theta_\\infty(x_\\infty) – 1/x_\\infty is rapidly decreasing as x_\\infty \\to 0”: maybe a bracket on “\\Theta_\\infty(x_\\infty) – 1” would make things clearer.")

#emph[#text("[Edited, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-477028")[#strong[#text("254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("[…] which among other things helps to clarify the nature of the functional equation, as discussed in this previous post. We will not pursue the adelic viewpoint further in these notes, but it does supply a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d497a85f77d9c0e9966c91ecfa08cb5d6cd5dbb01eddb493ed135489b6a82b3-f6adf6bb81914ebc73511216db3d31f44eab98b3da1aa4985ca505914b2e6092.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Masoud")]], [#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/#comment-676300")[#strong[#text("Masoud")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2023")])]

#text("Basic question: why is the characteristic function of Z_p a reasonable p-adic analogue of the Gaussian?")

#text("Ideally, one would have a general definition of Gaussian valid for every local field, which when specialised to R and Q_p, give the desired answers.")
]
