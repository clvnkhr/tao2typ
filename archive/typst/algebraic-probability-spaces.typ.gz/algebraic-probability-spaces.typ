// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/
// Converted to Typst by tao2typ: "2026-10-14T10:18:27.686991+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Algebraic probability spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Algebraic probability spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 June 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As laid out in the foundational work of Kolmogorov, a ")#emph[#text("classical probability space")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Probability_space")[#text("probability space")]#text(" for short) is a triplet ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(", where ")#mi("{X}")#text(" is a set, ")#mi("{{\\mathcal X}}")#text(" is a ")#mi("{\\sigma}")#text("-algebra of subsets of ")#mi("{X}")#text(", and ")#mi("{\\mu: {\\mathcal X} \\rightarrow [0,1]}")#text(" is a countably additive probability measure on ")#mi("{{\\mathcal X}}")#text(". Given such a space, one can form a number of interesting function spaces, including")

#list(
[#text("the (real) Hilbert space ")#mi("{L^2(X, {\\mathcal X}, \\mu)}")#text(" of square-integrable functions ")#mi("{f: X \\rightarrow {\\bf R}}")#text(", modulo ")#mi("{\\mu}")#text("-almost everywhere equivalence, and with the positive definite inner product ")#mi("{\\langle f, g\\rangle_{L^2(X, {\\mathcal X}, \\mu)} := \\int_X f g\\ d\\mu}")#text("; and")],
[#text("the unital commutative Banach algebra ")#mi("{L^\\infty(X, {\\mathcal X}, \\mu)}")#text(" of essentially bounded functions ")#mi("{f: X \\rightarrow {\\bf R}}")#text(", modulo ")#mi("{\\mu}")#text("-almost everywhere equivalence, with ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(X, {\\mathcal X}, \\mu)}}", block: false)#text(" defined as the essential supremum of ")#tao-math("{\\left|f\\right|}", block: false)#text(".")]
)

#text("There is also a trace ")#mi("{\\tau = \\tau_\\mu: L^\\infty(X, {\\mathcal X}, \\mu) \\rightarrow {\\bf C}}")#text(" on ")#mi("{L^\\infty}")#text(" defined by integration: ")#mi("{\\tau(f) := \\int_X f\\ d\\mu}")#text(".")

#text("One can form the ")#link("http://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(" ")#mi("{\\mathbf{Prb}}")#text(" of classical probability spaces, by defining a morphism ")#mi("{\\phi: (X, {\\mathcal X}, \\mu) \\rightarrow (Y, {\\mathcal Y}, \\nu)}")#text(" between probability spaces to be a function ")#mi("{\\phi: X \\rightarrow Y}")#text(" which is measurable (thus ")#mi("{\\phi^{-1}(E) \\in {\\mathcal X}}")#text(" for all ")#mi("{E \\in {\\mathcal Y}}")#text(") and measure-preserving (thus ")#mi("{\\mu(\\phi^{-1}(E)) = \\nu(E)}")#text(" for all ")#mi("{E \\in {\\mathcal Y}}")#text(").")

#text("Let us now abstract the algebraic features of these spaces as follows; for want of a better name, I will refer to this abstraction as an ")#emph[#text("algebraic probability space")]#text(", and is very similar to the non-commutative probability spaces studied in ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("this previous post")]#text(", except that these spaces are now commutative (and real).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" An ")#emph[#text("algebraic probability space")]#text(" is a pair ")#mi("{({\\mathcal A}, \\tau)}")#text(" where")

#list(
[#mi("{{\\mathcal A}}")#text(" is a unital commutative real algebra;")],
[#mi("{\\tau: {\\mathcal A} \\rightarrow {\\bf R}}")#text(" is a homomorphism such that ")#mi("{\\tau(1)=1}")#text(" and ")#mi("{\\tau( f^2 ) \\geq 0}")#text(" for all ")#mi("{f \\in {\\mathcal A}}")#text(";")],
[#text("Every element ")#mi("{f}")#text(" of ")#mi("{{\\mathcal A}}")#text(" is ")#emph[#text("bounded")]#text(" in the sense that ")#mi("{\\sup_{k \\geq 1} \\tau( f^{2k} )^{1/2k} < \\infty}")#text(". (Technically, this isn’t an algebraic property, but I need it for technical reasons.)")]
)

#text("A morphism ")#mi("{\\phi: ({\\mathcal A}_1, \\tau_1) \\rightarrow ({\\mathcal A}_2, \\tau_2)}")#text(" is a homomorphism ")#mi("{\\phi^*: {\\mathcal A}_2 \\rightarrow {\\mathcal A}_1}")#text(" which is trace-preserving, in the sense that ")#mi("{\\tau_1(\\phi^*(f)) = \\tau_2(f)}")#text(" for all ")#mi("{f \\in {\\mathcal A}_2}")#text(".")
]

#text("For want of a better name, I’ll denote the category of algebraic probability spaces as ")#mi("{\\mathbf{AlgPrb}}")#text(". One can view this category as the opposite category to that of (a subcategory of) the category of tracial commutative real algebras. One could emphasise this opposite nature by denoting the algebraic probability space as ")#mi("{({\\mathcal A}, \\tau)^{op}}")#text(" rather than ")#mi("{({\\mathcal A},\\tau)}")#text("; another suggestive (but slightly inaccurate) notation, inspired by the language of schemes, would be ")#mi("{\\text{Spec}({\\mathcal A},\\tau)}")#text(" rather than ")#mi("{({\\mathcal A},\\tau)}")#text(". However, we will not adopt these conventions here, and refer to algebraic probability spaces just by the pair ")#mi("{({\\mathcal A},\\tau)}")#text(".")

#text("By the previous discussion, we have a covariant ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functor")]#text(" ")#mi("{F: \\textbf{Prb} \\rightarrow \\textbf{AlgPrb}}")#text(" that takes a classical probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(" to its algebraic counterpart ")#mi("{(L^\\infty(X, {\\mathcal X},\\mu), \\tau_\\mu)}")#text(", with a morphism ")#mi("{\\phi: (X, {\\mathcal X}, \\mu) \\rightarrow (Y, {\\mathcal Y}, \\nu)}")#text(" of classical probability spaces mapping to a morphism ")#mi("{F(\\phi): (L^\\infty(X, {\\mathcal X},\\mu), \\tau_\\mu) \\rightarrow (L^\\infty(Y, {\\mathcal Y},\\nu), \\tau_\\nu)}")#text(" of the corresponding algebraic probability spaces by the formula")

#align(center)[#tao-fit-display[#mitex("F(\\phi)^* f := f \\circ \\phi")]]

#text("for ")#mi("{f \\in L^\\infty(Y, {\\mathcal Y}, \\nu)}")#text(". One easily verifies that this is a functor.")

#text("In this post I would like to describe a functor ")#mi("{G: \\textbf{AlgPrb} \\rightarrow \\textbf{Prb}}")#text(" which partially inverts ")#mi("{F}")#text(" (up to natural isomorphism), that is to say a recipe for starting with an algebraic probability space ")#mi("{({\\mathcal A}, \\tau)}")#text(" and producing a classical probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(". This recipe is not new – it is basically the (commutative) ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark%E2%80%93Segal_construction")[#text("Gelfand-Naimark-Segal construction")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("this previous post")]#text(") combined with the Loomis-Sikorski theorem (discussed in this ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("previous post")]#text("). However, I wanted to put the construction in a single location for sake of reference. I also wanted to make the point that ")#mi("{F}")#text(" and ")#mi("{G}")#text(" are not complete inverses; there is a bit of information in the algebraic probability space (e.g. topological information) which is lost when passing back to the classical probability space. In some future posts, I would like to develop some ergodic theory using the algebraic foundations of probability theory rather than the classical foundations; this turns out to be convenient in the ergodic theory arising from nonstandard analysis (such as that described in ")#link("https://terrytao.wordpress.com/2014/06/25/lebesgue-measure-as-the-invariant-factor-of-loeb-measure/")[#text("this previous post")]#text("), in which the groups involved are uncountable and the underlying spaces are not standard Borel spaces.")

#text("Let us describe how to construct the functor ")#mi("{G}")#text(", with details postponed to below the fold.")

#enum(start: 1, 
[#text("Starting with an algebraic probability space ")#mi("{({\\mathcal A}, \\tau)}")#text(", form an inner product on ")#mi("{{\\mathcal A}}")#text(" by the formula ")#mi("{\\langle f, g \\rangle := \\tau(fg)}")#text(", and also form the spectral radius ")#mi("{\\rho(f) :=\\lim_{k \\rightarrow \\infty} \\tau(f^{2^k})^{1/2^k}}")#text(".")],
[#text("The inner product is clearly positive semi-definite. Quotienting out the null vectors and taking completions, we arrive at a real Hilbert space ")#mi("{L^2 = L^2({\\mathcal A},\\tau)}")#text(", to which the trace ")#mi("{\\tau}")#text(" may be extended.")],
[#text("Somewhat less obviously, the spectral radius is well-defined and gives a norm on ")#mi("{{\\mathcal A}}")#text(". Taking ")#mi("{L^2}")#text(" limits of sequences in ")#mi("{{\\mathcal A}}")#text(" of bounded spectral radius gives us a subspace ")#mi("{L^\\infty = L^\\infty({\\mathcal A},\\tau)}")#text(" of ")#mi("{L^2}")#text(" that has the structure of a real commutative Banach algebra.")],
[#text("The idempotents ")#mi("{1_E}")#text(" of the Banach algebra ")#mi("{L^\\infty}")#text(" may be indexed by elements ")#mi("{E}")#text(" of an abstract ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}}")#text(".")],
[#text("The Boolean algebra homomorphisms ")#mi("{\\delta_x: {\\mathcal B} \\rightarrow \\{0,1\\}}")#text(" (or equivalently, the real algebra homomorphisms ")#mi("{\\iota_x: L^\\infty \\rightarrow {\\bf R}}")#text(") may be indexed by elements ")#mi("{x}")#text(" of a space ")#mi("{X}")#text(".")],
[#text("Let ")#mi("{{\\mathcal X}}")#text(" denote the ")#mi("{\\sigma}")#text("-algebra on ")#mi("{X}")#text(" generated by the basic sets ")#mi("{\\overline{E} := \\{ x \\in X: \\delta_x(E) = 1 \\}}")#text(" for every ")#mi("{E \\in {\\mathcal B}}")#text(".")],
[#text("Let ")#mi("{{\\mathcal N}}")#text(" be the ")#mi("{\\sigma}")#text("-ideal of ")#mi("{{\\mathcal X}}")#text(" generated by the sets ")#mi("{\\bigcap_n \\overline{E_n}}")#text(", where ")#mi("{E_n \\in {\\mathcal B}}")#text(" is a sequence with ")#mi("{\\bigcap_n E_n = \\emptyset}")#text(".")],
[#text("One verifies that ")#mi("{{\\mathcal B}}")#text(" is isomorphic to ")#mi("{{\\mathcal X}/{\\mathcal N}}")#text(". Using this isomorphism, the trace ")#mi("{\\tau}")#text(" on ")#mi("{L^\\infty}")#text(" can be used to construct a countably additive measure ")#mi("{\\mu}")#text(" on ")#mi("{{\\mathcal X}}")#text(". The classical probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(" is then ")#mi("{G( {\\mathcal A}, \\tau )}")#text(", and the abstract spaces ")#mi("{L^2, L^\\infty}")#text(" may now be identified with their concrete counterparts ")#mi("{L^2(X, {\\mathcal X}, \\mu)}")#text(", ")#mi("{L^\\infty(X, {\\mathcal X}, \\mu)}")#text(".")],
[#text("Every algebraic probability space morphism ")#mi("{\\phi: ({\\mathcal A}_1,\\tau_1) \\rightarrow ({\\mathcal A}_2,\\tau_2)}")#text(" generates a classical probability morphism ")#mi("{G(\\phi): (X_1, {\\mathcal X}_1, \\mu_1) \\rightarrow (X_2, {\\mathcal X}_2, \\mu_2)}")#text(" via the formula")

#align(center)[#tao-fit-display[#mitex("\\delta_{G(\\phi)(x_1)}( E_2 ) = \\delta_{x_1}( \\phi^*(E_2) )")]]

#text("using a pullback operation ")#mi("{\\phi^*}")#text(" on the abstract ")#mi("{\\sigma}")#text("-algebras ")#mi("{{\\mathcal B}_1, {\\mathcal B}_2}")#text(" that can be defined by density.")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The classical probability space ")#mi("{X}")#text(" constructed by the functor ")#mi("{G}")#text(" has some additional structure; namely ")#mi("{X}")#text(" is a ")#mi("{\\sigma}")#text("-Stone space (a ")#link("http://en.wikipedia.org/wiki/Stone's_representation_theorem_for_Boolean_algebras")[#text("Stone space")]#text(" with the property that the closure of any countable union of clopen sets is clopen), ")#mi("{{\\mathcal X}}")#text(" is the Baire ")#mi("{\\sigma}")#text("-algebra (generated by the clopen sets), and the null sets are the meager sets. However, we will not use this additional structure here.")
]

#text("The partial inversion relationship between the functors ")#mi("{F: \\textbf{Prb} \\rightarrow \\textbf{AlgPrb}}")#text(" and ")#mi("{G: \\textbf{AlgPrb} \\rightarrow \\textbf{Prb}}")#text(" is given by the following assertion:")

#enum(start: 1, 
[#text("There is a natural transformation from ")#mi("{F \\circ G: \\textbf{AlgPrb} \\rightarrow \\textbf{AlgPrb}}")#text(" to the identity functor ")#mi("{I: \\textbf{AlgPrb} \\rightarrow \\textbf{AlgPrb}}")#text(".")]
)

#text("More informally: if one starts with an algebraic probability space ")#mi("{({\\mathcal A},\\tau)}")#text(" and converts it back into a classical probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(", then there is a trace-preserving algebra homomorphism of ")#mi("{{\\mathcal A}}")#text(" to ")#mi("{L^\\infty( X, {\\mathcal X}, \\mu )}")#text(", which respects morphisms of the algebraic probability space. While this relationship is far weaker than an ")#link("http://en.wikipedia.org/wiki/Equivalence_of_categories")[#text("equivalence of categories")]#text(" (which would require that ")#mi("{F \\circ G}")#text(" and ")#mi("{G \\circ F}")#text(" are both natural isomorphisms), it is still good enough to allow many ergodic theory problems formulated using classical probability spaces to be reformulated instead as an equivalent problem in algebraic probability spaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The opposite composition ")#mi("{G \\circ F: \\textbf{Prb} \\rightarrow \\textbf{Prb}}")#text(" is a little odd: it takes an arbitrary probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(" and returns a more complicated probability space ")#mi("{(X^{\\prime}, {\\mathcal X}^{\\prime}, \\mu^{\\prime})}")#text(", with ")#mi("{X^{\\prime}}")#text(" being the space of homomorphisms ")#mi("{\\iota_x: L^\\infty(X, {\\mathcal X}, \\mu) \\rightarrow {\\bf R}}")#text(". while there is “morally” an embedding of ")#mi("{X}")#text(" into ")#mi("{X^{\\prime}}")#text(" using the evaluation map, this map does not exist in general because points in ")#mi("{X}")#text(" may well have zero measure. However, if one takes a “")#link("http://en.wikipedia.org/wiki/Pointless_topology")[#text("pointless")]#text("” approach and focuses just on the ")#link("http://en.wikipedia.org/wiki/Measure_algebra")[#text("measure algebras")]#text(" ")#mi("{({\\mathcal X}, \\mu)}")#text(", ")#mi("{({\\mathcal X}^{\\prime}, \\mu^{\\prime})}")#text(", then these algebras become naturally isomorphic after quotienting out by null sets.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" An algebraic probability space captures a bit more structure than a classical probability space, because ")#mi("{{\\mathcal A}}")#text(" may be identified with a proper subset of ")#mi("{L^\\infty}")#text(" that describes the “regular” functions (or random variables) of the space. For instance, starting with the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" (with the usual Haar measure and the usual trace ")#mi("{\\tau(f) = \\int_{{\\bf R}/{\\bf Z}} f}")#text("), any unital subalgebra ")#mi("{{\\mathcal A}}")#text(" of ")#mi("{L^\\infty({\\bf R}/{\\bf Z})}")#text(" that is dense in ")#mi("{L^2({\\bf R}/{\\bf Z})}")#text(" will generate the same classical probability space ")#mi("{G( {\\mathcal A}, \\tau )}")#text(" on applying the functor ")#mi("{G}")#text(", namely one will get the space ")#mi("{({\\bf R}/{\\bf Z})^{\\prime}}")#text(" of homomorphisms from ")#mi("{L^\\infty({\\bf R}/{\\bf Z})}")#text(" to ")#mi("{{\\bf R}}")#text(" (with the measure induced from ")#mi("{\\tau}")#text("). Thus for instance ")#mi("{{\\mathcal A}}")#text(" could be the continuous functions ")#mi("{C( {\\bf R}/{\\bf Z} )}")#text(", the ")#link("http://en.wikipedia.org/wiki/Wiener_algebra")[#text("Wiener algebra")]#text(" ")#mi("{A({\\bf R}/{\\bf Z})}")#text(" or the full space ")#mi("{L^\\infty({\\bf R}/{\\bf Z})}")#text(", but the classical space ")#mi("{G( {\\mathcal A}, \\tau )}")#text(" will be unable to distinguish these spaces from each other. In particular, the functor ")#mi("{F \\circ G}")#text(" loses information (roughly speaking, this functor takes an algebraic probability space and completes it to a ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(", but then forgets exactly what algebra was initially used to create this completion). In ergodic theory, this sort of “extra structure” is traditionally encoded in topological terms, by assuming that the underlying probability space ")#mi("{X}")#text(" has a nice topological structure (e.g. a ")#link("http://en.wikipedia.org/wiki/Standard_Borel_space")[#text("standard Borel space")]#text("); however, with the algebraic perspective one has the freedom to have non-topological notions of extra structure, by choosing ")#mi("{{\\mathcal A}}")#text(" to be something other than an algebra ")#mi("{C(X)}")#text(" of continuous functions on a topological space. I hope to discuss one such example of extra structure (coming from the Gowers-Host-Kra theory of uniformity seminorms) in a later blog post (this generalises the example of the Wiener algebra given previously, which is encoding “Fourier structure”).")
]

#text("A small example of how one could use the functors ")#mi("{F, G}")#text(" is as follows. Suppose one has a classical probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(" with a measure-preserving action of an uncountable group ")#mi("{\\Gamma}")#text(", which is only defined (and an action) up to almost everywhere equivalence; thus for instance for any set ")#mi("{E}")#text(" and any ")#mi("{g, h \\in \\Gamma}")#text(", ")#mi("{T^{gh} E}")#text(" and ")#mi("{T^g T^h E}")#text(" might not be exactly equal, but only equal up to a null set. For similar reasons, an element ")#mi("{E}")#text(" of the invariant factor ")#mi("{{\\mathcal X}^\\Gamma}")#text(" might not be exactly invariant with respect to ")#mi("{\\Gamma}")#text(", but instead one only has ")#mi("{T^g E}")#text(" and ")#mi("{E}")#text(" equal up to null sets for each ")#mi("{g \\in \\Gamma}")#text(". One might like to “clean up” the action of ")#mi("{\\Gamma}")#text(" to make it defined everywhere, and a genuine action everywhere, but this is not immediately achievable if ")#mi("{\\Gamma}")#text(" is uncountable, since the union of all the null sets where something bad occurs may cease to be a null set. However, by applying the functor ")#mi("{F}")#text(", each shift ")#mi("{T^g: X \\rightarrow X}")#text(" defines a morphism ")#mi("{T^g: L^\\infty(X, {\\mathcal X}, \\mu) \\rightarrow L^\\infty(X, {\\mathcal X}, \\mu)}")#text(" on the associated algebraic probability space (i.e. the Koopman operator), and then applying ")#mi("{G}")#text(", we obtain a shift ")#mi("{T^g: X^{\\prime} \\rightarrow X^{\\prime}}")#text(" on a new classical probability space ")#mi("{(X^{\\prime}, {\\mathcal X}^{\\prime}, \\mu^{\\prime})}")#text(" which now gives a genuine measure-preserving action of ")#mi("{\\Gamma}")#text(", and which is equivalent to the original action from a measure algebra standpoint. The invariant factor ")#mi("{{\\mathcal X}^\\Gamma}")#text(" now consists of those sets in ")#mi("{{\\mathcal X}^{\\prime}}")#text(" which are genuinely ")#mi("{\\Gamma}")#text("-invariant, not just up to null sets. (Basically, the classical probability space ")#mi("{(X^{\\prime}, {\\mathcal X}^{\\prime}, \\mu^{\\prime})}")#text(" contains a Boolean algebra ")#mi("{\\overline{\\mathcal B}}")#text(" with the property that every measurable set ")#mi("{A \\in {\\mathcal X}^{\\prime}}")#text(" is equivalent up to null sets to precisely one set in ")#mi("{\\overline{\\mathcal B}}")#text(", allowing for a canonical “retraction” onto ")#mi("{\\overline{\\mathcal B}}")#text(" that eliminates all null set issues.)")

#text("More indirectly, the functors ")#mi("{F, G}")#text(" suggest that one should be able to develop a “")#link("http://en.wikipedia.org/wiki/Pointless_topology")[#text("pointless")]#text("” form of ergodic theory, in which the underlying probability spaces are given algebraically rather than classically. I hope to give some more specific examples of this in later posts.")

#metadata(none) <tao-05d936a4a624b03251a1>

#heading(level: 1)[#strong[#text(" — 1. Details — ")]]

#text("We now flesh out the construction of ")#mi("{G}")#text(" that was sketched above. The arguments here are drawn from ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("these two")]#text(" ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("previous blog posts")]#text(", with some minor simplifications coming from the commutativity of the algebraic probability space.")

#text("We begin with an algebraic probability space ")#mi("{({\\mathcal A}, \\tau)}")#text(". As indicated, we then give ")#mi("{{\\mathcal A}}")#text(" an inner product ")#mi("{\\langle, \\rangle}")#text(" on ")#mi("{{\\mathcal A}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle := \\tau( fg ).")]]

#text("By construction we see that this is a positive semi-definite inner product. We let ")#mi("{L^2 = L^2({\\mathcal A},\\tau)}")#text(" be the associated completion of ")#mi("{{\\mathcal A}}")#text(" after quotienting out by null vectors, thus ")#mi("{L^2}")#text(" is a real Hilbert space and we have an isometry ")#mi("{\\iota: {\\mathcal A} \\rightarrow L^2}")#text(" with dense image. We use ")#mi("{\\| \\|_{L^2}}")#text(" to denote the norm on ")#mi("{L^2}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\iota(f) \\right\\|_{L^2} = \\tau(f^2)^{1/2}", block: true)]]

#text("for ")#mi("{f \\in {\\mathcal A}}")#text(".")

#text("From the Cauchy-Schwarz inequality, we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(fg)\\right| \\leq \\tau(f^2)^{1/2} \\tau(g^2)^{1/2}", block: true)]]

#text("for all ")#mi("{f, g \\in {\\mathcal A}}")#text(". In particular, since ")#mi("{\\tau(1)=1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(f)\\right| \\leq \\tau(f^2)^{1/2}", block: true)]]

#text("which implies that ")#mi("{\\tau(f^{2^k})^{1/2^k}}")#text(" is a non-decreasing function of ")#mi("{k=0,1,\\dots}")#text(". As each ")#mi("{f \\in {\\mathcal A}}")#text(" is assumed to be bounded, we thus have a well-defined spectral radius")

#align(center)[#tao-fit-display[#mitex("\\rho(f) := \\lim_{k \\rightarrow \\infty} \\tau(f^{2^k})^{1/2^k}.")]]

#text("By monotonicity, we have ")#metadata(none) <tao-c42a4f1674e21a4dfc0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\tau(f)\\right| \\leq \\left\\| \\iota(f)\\right\\|_{L^2} \\leq \\rho(f).", block: true)]]

#text("Also, from many applications of Cauchy-Schwarz we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(f^j g^k)\\right| \\leq \\tau(f^{j+k})^{\\frac{j}{j+k}} \\tau(g^{j+k})^{\\frac{k}{j+k}}", block: true)]]

#text("for ")#mi("{f,g \\in {\\mathcal A}}")#text(" and ")#mi("{j,k \\geq 0}")#text(" with ")#mi("{j+k}")#text(" summing to a power of two; in particular")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(f^j g^k)\\right| \\leq \\rho(f)^j \\rho(g)^k,", block: true)]]

#text("which by the binomial theorem gives")

#align(center)[#tao-fit-display[#mitex("\\rho(f+g) \\leq \\rho(f) + \\rho(g)")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("\\rho(fg) \\leq \\rho(f) \\rho(g),")]]

#text("thus ")#mi("{\\rho}")#text(" is an algebra norm on ")#mi("{\\iota({\\mathcal A})}")#text("; a similar argument also gives the inequality.")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\iota(fg) \\right\\|_{L^2} \\leq \\rho(f) \\left\\|\\iota(g)\\right\\|_{L^2}.", block: true)]]

#text("From this, we see that for each ")#mi("{f \\in {\\mathcal A}}")#text(", the multiplication operator ")#mi("{g \\mapsto fg}")#text(" on ")#mi("{{\\mathcal A}}")#text(" induces a self-adjoint bounded linear operator on ")#mi("{L^2}")#text("; of operator norm at most ")#mi("{\\rho(f)}")#text("; in fact, from the definition of ")#mi("{\\rho(f)}")#text(" we see that this operator cannot have norm strictly less than ")#mi("{\\rho(f)}")#text(". Thus we have identified ")#mi("{\\iota({\\mathcal A})}")#text(" as a commutative normed algebra with a subalgebra of the space ")#mi("{B(L^2)}")#text(" of bounded linear operators on ")#mi("{L^2}")#text(", with the operator norm.")

#text("We now define ")#mi("{L^\\infty = L^\\infty({\\mathcal A},\\tau)}")#text(" to be the space of functions ")#mi("{f}")#text(" in ")#mi("{L^2}")#text(" which are limits (in ")#mi("{L^2}")#text(") of sequences ")#mi("{f_n}")#text(" in ")#mi("{\\iota({\\mathcal A})}")#text(" of uniformly bounded spectral radius. The associated multiplication operators ")#mi("{g \\mapsto f_n g}")#text(" are then uniformly bounded in operator norm, and converge in ")#mi("{L^2}")#text(" for fixed ")#mi("{g \\in \\iota({\\mathcal A})}")#text("; thus ")#mi("{f}")#text(" defines a multiplication operator ")#mi("{g \\mapsto fg}")#text(" that is a self-adjoint bounded linear operator on ")#mi("{L^2}")#text(", which one can check to be independent of the choice of sequence. This identifies each element of ")#mi("{L^\\infty}")#text(" with a self-adjoint element of ")#mi("{B(H)}")#text("; we then define the ")#mi("{L^\\infty}")#text(" norm of an element ")#mi("{f \\in L^\\infty}")#text(" to be its operator norm in ")#mi("{B(H)}")#text(", thus this extends the spectral radius ")#mi("{\\rho}")#text(" on ")#mi("{\\iota({\\mathcal A})}")#text(". Specialising ")#mi("{g}")#text(" to ")#mi("{1}")#text(" we see that this identification of ")#mi("{L^\\infty}")#text(" with a subset of ")#mi("{B(H)}")#text(" is injective, and this gives ")#mi("{L^\\infty}")#text(" the structure of a commutative Banach algebra, with ")#mi("{L^2}")#text(" being a module over ")#mi("{L^\\infty}")#text(". From construction, we also see that every closed ball in ")#mi("{L^\\infty}")#text(" is also closed in ")#mi("{L^2}")#text(".")

#text("Define an ")#emph[#text("idempotent")]#text(" element of ")#mi("{L^\\infty}")#text(" to be an element ")#mi("{1_E}")#text(" such that ")#mi("{1_E^2 = 1_E}")#text("; we let ")#mi("{{\\mathcal B}}")#text(" denote an index set for the set of idempotents ")#mi("{\\{ 1_E: E \\in {\\mathcal B} \\}}")#text(". We have the following basic density result, which ensures an ample supply of idempotents:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-b43aae102b191a96b0ee>#text(" The linear space spanned by the idempotents is dense in ")#mi("{L^\\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{f \\in L^\\infty}")#text("; our task is to approximate ")#mi("{f}")#text(" to arbitrary accuracy in ")#mi("{L^\\infty}")#text(" norm by a finite linear combination of idempotents.")

#text("We view ")#mi("{f}")#text(" as a bounded self-adjoint linear operator on ")#mi("{L^2}")#text(", which contains the unit vector ")#mi("{1}")#text(". By the spectral theorem, we can find a Radon probability measure ")#mi("{\\mu_f}")#text(" on ")#tao-math("{[-\\left\\|f\\right\\|_{L^\\infty}, \\left\\|f\\right\\|_{L^\\infty}]}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle f^k 1, 1 \\rangle = \\int x^k\\ d\\mu_f(x)")]]

#text("for all ")#mi("{k}")#text(", and in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P(f) \\right\\|_{L^2} = \\int P(x)^2\\ d\\mu_f(x)", block: true)]]

#text("for any polynomial ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(". Also we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|P(f)\\right\\|_{L^\\infty} = \\mu_f-\\sup \\left|P(x)\\right|", block: true)]]

#text("where ")#mi("{\\mu_f-\\sup}")#text(" denotes the ")#mi("{\\mu_f}")#text("-essential supremum. From this and a density argument, we have an ")#mi("{L^\\infty}")#text(" functional calculus: given any bounded Borel function ")#mi("{F: \\text{supp}(\\mu) \\rightarrow {\\bf R}}")#text(", we can find ")#mi("{F(f) \\in L^\\infty}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F(f) \\right\\|_{L^2} = \\int F(x)^2\\ d\\mu_f(x)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F(f)\\right\\|_{L^\\infty} = \\mu_f-\\sup \\left|F(x)\\right|,", block: true)]]

#text("and such that the map ")#mi("{F \\mapsto F(f)}")#text(" is a homomorphism. In particular, if ")#mi("{F}")#text(" is an indicator function, then ")#mi("{F(f)}")#text(" is an idempotent. Approximating the identity function in ")#mi("{L^2(\\mu_f)}")#text(" by a finite combination of indicator functions, we obtain the claim. ")#mi("\\Box")

#text("Now, we can give ")#mi("{{\\mathcal B}}")#text(" the structure of an abstract Boolean algebra by defining intersection")

#align(center)[#tao-fit-display[#mitex("1_{E \\cap F} := 1_E 1_F")]]

#text("and complement")

#align(center)[#tao-fit-display[#mitex("1_{E^c} := 1 - 1_E")]]

#text("and then defining union by de Morgan’s law ")#mi("{E \\cup F := (E^c \\cap F^c)^c}")#text(". One can verify (somewhat tediously) that ")#mi("{{\\mathcal B}}")#text(" obeys the ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("axioms of an abstract Boolean algebra")]#text(", and acquires an ordering ")#mi("{\\subseteq}")#text(" in the usual manner, with minimal element ")#mi("{1_\\emptyset = 0}")#text(" and maximal element ")#mi("{1_X = 1}")#text(". If ")#mi("{E \\subset F}")#text(", then a short computation shows that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_E - 1_F \\right\\|_{L^2}^2 = \\tau(1_E) - \\tau(1_F).", block: true)]]

#text("In particular, if ")#mi("{E_1 \\supset E_2 \\supset \\dots}")#text(" is a decreasing sequence in ")#mi("{{\\mathcal B}}")#text(", then the ")#mi("{1_{E_n}}")#text(" are Cauchy in ")#mi("{L^2}")#text(", and thus converge to another idempotent ")#mi("{1_E}")#text("; we write ")#mi("{E := \\bigcap_{n=1}^\\infty E_n}")#text(", and observe that this is the greatest lower bound of the ")#mi("{E_n}")#text(". Similarly, any increasing sequence ")#mi("{E_1 \\subset E_2 \\subset \\dots}")#text(" has a least upper bound ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(".")

#text("Now we consider the Boolean homomorphisms ")#mi("{\\delta_x: {\\mathcal B} \\rightarrow \\{0,1\\}}")#text(" from ")#mi("{{\\mathcal B}}")#text(" to the two-element Boolean algebra, or equivalently the space of finitely additive Boolean measures on ")#mi("{{\\mathcal B}}")#text(". We index this space by ")#mi("{X}")#text(", thus ")#mi("{\\{ \\delta_x: x \\in X \\}}")#text(" is the space of Boolean homomorphisms. From Lemma ")#link(<tao-b43aae102b191a96b0ee>)[#text("2")]#text(", every such Boolean homomorphism ")#mi("{\\delta_x: {\\mathcal B} \\rightarrow \\{0,1\\}}")#text(" uniquely determines a algebra homomorphism ")#mi("{\\iota_x: L^\\infty \\rightarrow {\\bf R}}")#text(", and conversely every homomorphism comes from exactly one such homomorphism, thus ")#mi("{\\{ \\iota_x: x \\in X\\}}")#text(" is the space of algebra homomorphisms from ")#mi("{L^\\infty}")#text(" to ")#mi("{{\\bf R}}")#text(".")

#text("One can identify ")#mi("{X}")#text(" with a closed subspace of the product space ")#mi("{\\{0,1\\}^{\\mathcal B}}")#text(", and so by Tychonoff’s theorem ")#mi("{X}")#text(" is a compact space. Every element ")#mi("{E \\in {\\mathcal B}}")#text(" of the abstract Boolean algebra ")#mi("{{\\mathcal B}}")#text(" induces a subset ")#mi("{\\overline{E}}")#text(" of ")#mi("{X}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\overline{E} := \\{ x \\in X: \\delta_x(E) = 1 \\} = \\{ x \\in X: \\iota_x( 1_E ) = 1 \\}.")]]

#text("The map ")#mi("{E \\mapsto \\overline{E}}")#text(" is easily seen to be a Boolean homomorphism. Let ")#mi("{{\\mathcal X}}")#text(" be the ")#mi("{\\sigma}")#text("-algebra generated by the sets ")#mi("{\\overline{\\mathcal B} := \\{ \\overline{E}: E \\in {\\mathcal B} \\}}")#text(". Define a ")#emph[#text("basic null set")]#text(" to be a subset of ")#mi("{X}")#text(" of the form ")#mi("{\\bigcap_{n=1}^\\infty \\overline{E_n}}")#text(" with ")#mi("{E_1 \\supset E_2 \\supset \\dots}")#text(" in ")#mi("{{\\mathcal B}}")#text(" such that ")#mi("{\\bigcap_{n=1}^\\infty E_n = \\emptyset}")#text(", and let ")#mi("{{\\mathcal N}}")#text(" be the collection of countable unions of basic null sets. This is a ")#mi("{\\sigma}")#text("-ideal of ")#mi("{{\\mathcal B}}")#text(", so we may form the quotient ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal B}/{\\mathcal N}}")#text(". The map ")#mi("{E \\mapsto \\overline{E} \\text{ mod } {\\mathcal N}}")#text(" can be easily verified to be a ")#mi("{\\sigma}")#text("-algebra homomorphism (not just a boolean algebra homomorphism). We claim that this homomorphism is bijective (and thus an isomorphism). Surjectivity is clear from construction. For injectivity, suppose for contradiction that there was ")#mi("{E \\in {\\mathcal B}}")#text(" with ")#mi("{E \\neq \\emptyset}")#text(" such that ")#mi("{\\overline{E}}")#text(" was in ")#mi("{{\\mathcal N}}")#text(", that is to say that ")#mi("{\\overline{E}}")#text(" could be covered by a countable sequence of intersections ")#mi("{\\bigcap_{n=1}^\\infty \\overline{E_{n,m}}}")#text(" with ")#mi("{E_{1,m} \\supset E_{2,m} \\subset \\dots}")#text(" and ")#mi("{\\bigcap_{n=1}^\\infty E_{n,m} = \\emptyset}")#text(".")

#text("By induction, we may find ")#mi("{n_1, n_2, \\dots}")#text(" such that ")#mi("{\\overline{E}}")#text(" is not covered by ")#mi("{\\overline{E_{n_1,1}} \\cup \\dots \\cup \\overline{E_{n_m,m}}}")#text(" for each ")#mi("{m}")#text(". If we let ")#mi("{E^{\\prime}_m := E \\backslash \\bigcup_{i=1}^m E_{n_i,i}}")#text(", we thus see that ")#mi("{E^{\\prime}_1 \\supset E^{\\prime}_2 \\supset \\dots}")#text(" with each ")#mi("{E^{\\prime}_m \\neq \\emptyset}")#text(", but ")#mi("{\\bigcap_{m=1}^\\infty \\overline{E^{\\prime}_m}}")#text(" non-empty for all ")#mi("{m}")#text(". But from the ")#link("http://en.wikipedia.org/wiki/Ultrafilter_lemma#The_ultrafilter_lemma")[#text("ultrafilter lemma")]#text(", ")#mi("{\\overline{E^{\\prime}_m}}")#text(" is non-empty for each ")#mi("{m}")#text(", and ")#mi("{\\overline{E^{\\prime}_m}}")#text(" is also closed, so we obtain a contradiction from compactness.")

#text("From the above isomorphism, we see that every element ")#mi("{A}")#text(" of ")#mi("{{\\mathcal X}}")#text(" differs (up to an element of ")#mi("{{\\mathcal N}}")#text(") by a unique set ")#mi("{\\overline{E}}")#text(" in ")#mi("{\\overline{\\mathcal B}}")#text(". We then define the measure ")#mi("{\\mu(A)}")#text(" of ")#mi("{A}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\mu(A) := \\tau(1_E).")]]

#text("One can check that this gives a countably additive probability measure. We may now associate to each finite linear combination ")#mi("{f}")#text(" of idempotents, an element ")#mi("{\\overline{f}}")#text(" of ")#mi("{L^\\infty(X,{\\mathcal X}, \\mu)}")#text(" in such a way that the map ")#mi("{f \\mapsto \\overline{f}}")#text(" is an algebra homomorphism with")

#align(center)[#tao-fit-display[#mitex("\\tau(f) = \\int_X \\overline{f}\\ d\\mu")]]

#text("which implies that ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty}}", block: false)#text(" is the essential supremum of ")#mi("{\\overline{f}}")#text(", and ")#tao-math("{\\left\\|f\\right\\|_{L^2}}", block: false)#text(" is the ")#mi("{L^2(X, {\\mathcal X}, \\mu)}")#text(" norm of ")#mi("{\\overline{f}}")#text(". This and Lemma ")#link(<tao-b43aae102b191a96b0ee>)[#text("2")]#text(" allow us to define maps from ")#mi("{L^\\infty}")#text(" to ")#mi("{L^\\infty(X, {\\mathcal X}, \\mu)}")#text(" and ")#mi("{L^2}")#text(" to ")#mi("{L^2( X, {\\mathcal X}, \\mu)}")#text(", which one easily verifies to be isomorphisms of Banach algebras and Hilbert spaces respectively.")

#text("We have now constructed the action of the functor ")#mi("{G}")#text(" on algebraic probability spaces. To finish the construction of ")#mi("{G}")#text(", we have to describe the classical probability morphism ")#mi("{G(\\phi): (X_1, {\\mathcal X}_1, \\mu_1) \\rightarrow (X_2, {\\mathcal X}_2, \\mu_2)}")#text(" associated to an algebraic probability space morphism ")#mi("{\\phi: ({\\mathcal A}_1,\\tau_1) \\rightarrow ({\\mathcal A}_2,\\tau_2)}")#text(". The pullback map ")#mi("{\\phi^*: {\\mathcal A}_2 \\rightarrow {\\mathcal A}_1}")#text(" preserves the ")#mi("{L^2}")#text(" norm and spectral radius, and thus also extends to a Hilbert space isometry ")#mi("{\\phi^*: L^2({\\mathcal A}_2,\\tau_2) \\rightarrow L^2({\\mathcal A}_1, \\tau_1)}")#text(" and a Banach algebra isometry ")#mi("{\\phi^*: L^\\infty({\\mathcal A}_2, \\tau_2) \\rightarrow L^\\infty({\\mathcal A}_1, \\tau_1)}")#text(". As a consequence, we also have a ")#mi("{\\sigma}")#text("-algebra homomorphism ")#mi("{\\phi^*: {\\mathcal B}_2 \\rightarrow {\\mathcal B}_1}")#text(". We then define ")#mi("{G(\\phi) \\in X_2}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\delta_{G(\\phi)(x_1)}( E_2 ) = \\delta_{x_1}( \\phi^*(E_2) )")]]

#text("for all ")#mi("{x_1 \\in X_1}")#text(" and ")#mi("{E_2 \\in {\\mathcal B}_2}")#text("; one verifies that this indeed defines ")#mi("{G(\\phi)}")#text(" as an element of ")#mi("{X_2}")#text(" (i.e., ")#mi("{\\delta_{G(\\phi)(x_1)}: {\\mathcal B}_2 \\rightarrow \\{0,1\\}}")#text(" is a Boolean algebra homomorphism. It is then a routine but tedious matter to check that ")#mi("{G(\\phi)}")#text(" is a classical probability morphism and that ")#mi("{G}")#text(" is a functor.")

#text("Finally, the homomorphism ")#mi("{\\iota: {\\mathcal A} \\rightarrow L^\\infty({\\mathcal A}, \\tau)}")#text(" can viewed as a morphism from the abstract probability space ")#mi("{(L^\\infty({\\mathcal A}, \\tau), \\tau) = F \\circ G( {\\mathcal A}, \\tau )}")#text(" to ")#mi("{({\\mathcal A}, \\tau)}")#text(". Given a morphism ")#mi("{\\phi: ({\\mathcal A}_1,\\tau_1) \\rightarrow ({\\mathcal A}_2,\\tau_2)}")#text(", the pullback maps ")#mi("{\\phi^*: {\\mathcal A}_2 \\rightarrow {\\mathcal A}_1}")#text(" and ")#mi("{\\phi^*: L^\\infty({\\mathcal A}_2, \\tau_2) \\rightarrow L^\\infty({\\mathcal A}_1, \\tau_1)}")#text(" are intertwined by these morphisms, so we have a natural transformation from ")#mi("{F \\circ G}")#text(" to the identity functor, as claimed.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-381802")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("Once you quotient out by the null sets, are these adjoint functors?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-382106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("There does seem to be some relationship of this form (although to state it properly, one would need an intermediate category between ")#mi("\\textbf{Prb}")#text(" and ")#mi("\\textbf{AlgPrb}")#text(", consisting of measure algebras in which the null sets have been quotiented out). Given a classical probability space ")#mi("X")#text(" and an algebraic probability space ")#mi("{\\mathcal A}")#text(", a morphism from ")#mi("F(X)")#text(" to ")#mi("{\\mathcal A}")#text(" is essentially a representation of ")#mi("{\\mathcal A}")#text(" in ")#mi("L^\\infty(X)")#text(". One can then represent ")#mi("L^2({\\mathcal A})")#text(" in ")#mi("L^2(X)")#text(", and thence ")#mi("L^\\infty({\\mathcal A})")#text(" in ")#mi("L^\\infty(X)")#text(", which one can use to write ")#mi("G({\\mathcal A})")#text(" as a factor of ")#mi("X")#text(" on the level of measure algebras (i.e. after quotienting by null sets). These steps are all reversible, and I’m pretty sure they’re natural. So it looks like one can identify ")#mi("\\textup{Hom}(F(X),{\\mathcal A})")#text(" with ")#mi("\\textup{Hom}(X, G({\\mathcal A}))")#text(" if we apply the appropriate forgetful functors for quotienting out null sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df4843c4c946a39726dd088b3386536f09fc8b5848ce64244922b054ddd8d2f2-ddaead6b81bc87a43b762e9077fd0c83b2b71af3a3db6d4ce3d41a60942192d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-382714")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2014")])]

#text("In Definition 1, what do you mean by a *-homomorphism? I do not see any involution… Isn’t a unital algebra morphism enough? Thanks.")

#emph[#text("[Oops, this is a leftover from a previous iteration of the post; corrected now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e66e512e2f36780ebdb36940a19c4f01d9a8dec0233e51c82bf2e479f7f0c54c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amy Huang")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-383263")[#strong[#text("Amy Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2014")])]

#text("Why the morphis needs to be trace-preserving?")

#emph[#text("[By definition – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81c7ee47219767de6af71eb6b5313e9894d7c3914be6d57431ae7e1b00c157a1-a1e079dc8e5844fbe1b13fa79adf07f02d1892bfbe1b6c1e95a39cc933de0cdd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vznvzn")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-384612")[#strong[#text("vznvzn")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#link("http://www.nytimes.com/2014/06/23/us/the-multimillion-dollar-minds-of-5-mathematical-masters.html?_r=0")[#strong[#emph[#text("congratulations!")]]]#text(" :idea: :!:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-385290")[#strong[#text("$3M Breakthrough Prizes now awarded in mathematics! | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2014")]

#text("[…] CONGRATULATIONS! :idea: :!: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-389386")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2014")])]

#text("There is an extra space in “Somewh at less obviously”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00d936c34a46d5386f3c76de32f3df11d4a95831c6771f45e876c1ecb1034a10-c292ff54ea98bf8df8613a2c2f72e4782d6f5c5606813590cf75cc9234421217.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jb")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-389591")[#strong[#text("jb")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Thank you so much for writing this. I’d heard about the random variable / probability space divide in probability theory, and I had always assumed it was parallel to the ring / variety dichotomy in algebraic geometry. So it’s nice to see it all laid out. So would you say then that working probabilists think in terms of algebraic probablility spaces rather than (usual) probability space? Or that algebraic probability spaces are the true objects of study in probability theory? Or am I missing the point?")

#text("I’m really looking forward to the follow-up posts. I’d be particularly interested to hear more about the boundedness axiom in your definition of algebraic probability space. You say you need it only for technical reasons. So is there any chance of removing it or replacing it with something more palatable from the algebraic or category theoretic perspective while maintaining the ability to ‘do probability theory’ on such a thing?")

#text("A second question: In algebraic geometry, a ring/scheme is not much more general than a nilpotent-free ring/variety. This is because all rings with nilpotents can be obtained by intersecting varieties together, as long as you do it in the algebraically natural manner, i.e. just tensor coordinate rings together and don’t follow that by modding out by nilpotents (=ignore tangency information when intersecting). Further, infinitely generated rings can be obtained as limits of finitely generated rings. So finitely generated rings without nilpotents, the objects of classical algebraic geometry, reassuringly determine the whole scheme-theoretic story as long as you take a suitably enlightened point of view. Is there any counterpart to this in the world of probability spaces? Is there some sense in which every algebraic probability space can be built out usual ones by applying some routine constructions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-389862")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("When working with noncommutative probability (e.g. with quantum probability, or with free probability) then one certainly takes the algebraic perspective (although often with some additional analytic axioms beyond the boundedness axiom here, e.g. that the algebra of random variables forms a von Neumann algebra). Indeed, much as in algebraic geometry, in the noncommutative setting it becomes quite unwieldy to try to work in a classical setting of spaces of points. See ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")]#text(" for more discussion. [Note that in the noncommutative framework, one cannot easily reduce to the consideration of purely real (or more precisely, self-adjoint) random variables, since the space of such random variables is no longer closed under multiplication, and must instead work in a *-algebra of random variables rather than a real algebra, with a trace that is now complex-linear instead of real-linear. So the axiomatisation in the noncommutative case is a little different from the one given in this post.]")

#text("With more traditional probability, the philosophy is indeed largely to suppress the precise nature of the sample space and to work primarily with concepts flowing from the algebra of random variables, e.g. expectation, variance, correlation, and independence. See ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")]#text(" for more discussion. However, for some applications (particularly in ergodic theory) it has traditionally been convenient to impose some additional topological regularity hypotheses on the probability space (e.g. that it is a standard Borel space) in order to use some tools from descriptive set theory and classical analysis (e.g. Riesz representation, disintegration of measures, measurable sections). I believe though that by pursuing a primarily algebraic approach, most of these additional topological assumptions may be dropped, albeit at the cost of making the arguments look rather different (as one has to make everything that is currently based on a classical point-theoretic interpretation of the sample space “pointless” or “point-free”). I hope to give some examples of this in future posts.")

#text("As regards the second question, certainly in many applications (e.g. in the ergodic theory of actions of countable groups) one can often reduce to probability spaces which are separable (countably generated), which is perhaps analogous to the finitely generated rings in the algebraic geometry context. (Nilpotency does not arise as an issue in commutative probability (the spectral theorem eliminates the possibility of nilpotents when one commutes with one’s adjoint), though of course one could consider it in noncommutative contexts. But the dividing line between normal (commuting with one’s adjoint) and non-normal is typically more important than the dividing line between nilpotent and non-nilpotent, at least in the context of free probability which is the subfield of noncommutative probability that I am the most familiar with; I think this flows from the heavy reliance on the trace in algebraic probability theory, which does not have much of an analogue in algebraic geometry since one doesn’t do much integration on varieties from a purely algebraic viewpoint, whereas one is always taking expectations of random variables.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real analysis relative to a finite measure space | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-394748")[#strong[#text("Real analysis relative to a finite measure space | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("[…] standard Borel spaces (in fact, I will take them to be algebraic probability spaces, as defined in this previous post), in which case disintegrations are not available. However, it appears that the stochastic analysis […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f8e2da9b56482bc5b0279e3a1babd73e3c192231da94938ae64c34df1ac739b-7283d3c58d4688ddbd737bf8290f3305c0bbd49ffd8b6c6631121456f74c4a52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jingpyi")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-410914")[#strong[#text("jingpyi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Reblogged this on ")#link("http://jingpyi.wordpress.com/2014/08/31/algebraic-probability-spaces/")[#text("jingpyi")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 1: Integration and expectation | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-460065")[#strong[#text("275A, Notes 1: Integration and expectation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2015")])]

#text("[…] the foundations of probability theory on the sample space models as discussed in Notes 0. (See this previous post for one such axiomatic […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-517963")[#strong[#text("Symmetric functions in a fractional number of variables, and the multilinear Kakeya conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2019")])]

#text("[…] commutative von Neumann algebra type structure (or the abstract probability structure discussed in this previous post) and then interpret it as a genuine measure space rather than as a virtual one. (This failure of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c54b4cc0f426d2c5c8cee6ec7f7f47eefd63042043c473cb8262ca8b41d2669d-357f54012e05ba23dd1124165284ad0cc41e976bc3b989426a29832b14ce9e84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/#comment-638453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2021")])]

#text("What is the conditions on \\tau_{\\mu} so the one-to-one relation between the Classical and the Algebraic probability spaces holds? Could any functional other than expectation work?")
]
