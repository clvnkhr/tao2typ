// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:37:35.339367+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 January 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A fundamental and recurring problem in analytic number theory is to demonstrate the presence of ")#emph[#text("cancellation")]#text(" in an oscillating sum, a typical example of which might be a correlation ")#metadata(none) <tao-88069f4e45ea28c2a810>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n} f(n) \\overline{g(n)}")]]

#text("between two arithmetic functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and ")#mi("{g: {\\bf N} \\rightarrow {\\bf C}}")#text(", which to avoid technicalities we will assume to be finitely supported (or that the ")#mi("{n}")#text(" variable is localised to a finite range, such as ")#mi("{\\{ n: n \\leq x \\}}")#text("). A key example to keep in mind for the purposes of this set of notes is the twisted von Mangoldt summatory function ")#metadata(none) <tao-e5b564a7a4059dccb9c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) \\overline{\\chi(n)}")]]

#text("that measures the correlation between the primes and a Dirichlet character ")#mi("{\\chi}")#text(". One can get a “trivial” bound on such sums from the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} f(n) \\overline{g(n)}\\right| \\leq \\sum_{n} \\left|f(n)\\right| \\left|g(n)\\right|;", block: true)]]

#text("for instance, from the triangle inequality and the prime number theorem we have ")#metadata(none) <tao-2f60014f825fa20dbc56>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\sum_{n \\leq x} \\Lambda(n) \\overline{\\chi(n)}\\right| \\leq x + o(x)", block: true)]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". But the triangle inequality is insensitive to the phase oscillations of the summands, and often we expect (e.g. from the probabilistic heuristics from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") to be able to improve upon the trivial triangle inequality bound by a substantial amount; in the best case scenario, one typically expects a “square root cancellation” that gains a factor that is roughly the square root of the number of summands. (For instance, for Dirichlet characters ")#mi("{\\chi}")#text(" of conductor ")#mi("{O(x^{O(1)})}")#text(", it is expected from probabilistic heuristics that the left-hand side of ")#link(<tao-2f60014f825fa20dbc56>)[#text("(3)")]#text(" should in fact be ")#mi("{O_\\varepsilon(x^{1/2+\\varepsilon})}")#text(" for any ")#mi("{\\varepsilon>0}")#text(".)")

#text("It has proven surprisingly difficult, however, to establish significant cancellation in many of the sums of interest in analytic number theory, particularly if the sums do not have a strong amount of algebraic structure (e.g. multiplicative structure) which allow for the deployment of specialised techniques (such as multiplicative number theory techniques). In fact, we are forced to rely (to an embarrassingly large extent) on (many variations of) a single basic tool to capture at least some cancellation, namely the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Schwarz_inequality")[#text("Cauchy-Schwarz inequality")]#text(". In fact, in many cases the classical case ")#metadata(none) <tao-27368d421f0ff4d182b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\sum_n f(n) \\overline{g(n)}\\right| \\leq (\\sum_n \\left|f(n)\\right|^2)^{1/2} (\\sum_n \\left|g(n)\\right|^2)^{1/2},", block: true)]]

#text("considered by Cauchy, where at least one of ")#mi("{f, g: {\\bf N} \\rightarrow {\\bf C}}")#text(" is finitely supported, suffices for applications. Roughly speaking, the Cauchy-Schwarz inequality replaces the task of estimating a ")#emph[#text("cross-correlation")]#text(" between two different functions ")#mi("{f,g}")#text(", to that of measuring ")#emph[#text("self-correlations")]#text(" between ")#mi("{f}")#text(" and itself, or ")#mi("{g}")#text(" and itself, which are usually easier to compute (albeit at the cost of capturing less cancellation). Note that the Cauchy-Schwarz inequality requires almost no hypotheses on the functions ")#mi("{f}")#text(" or ")#mi("{g}")#text(", making it a very widely applicable tool.")

#text("There is however some skill required to decide exactly how to deploy the Cauchy-Schwarz inequality (and in particular, how to select ")#mi("{f}")#text(" and ")#mi("{g}")#text("); if applied blindly, one loses all cancellation and can even end up with a worse estimate than the trivial bound. For instance, if one tries to bound ")#link(<tao-e5b564a7a4059dccb9c2>)[#text("(2)")]#text(" directly by applying Cauchy-Schwarz with the functions ")#mi("{\\Lambda}")#text(" and ")#mi("{\\chi}")#text(", one obtains the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\leq x} \\Lambda(n) \\overline{\\chi(n)}\\right| \\leq (\\sum_{n \\leq x} \\Lambda(n)^2)^{1/2} (\\sum_{n \\leq x} \\left|\\chi(n)\\right|^2)^{1/2}.", block: true)]]

#text("The right-hand side may be bounded by ")#mi("{\\ll x \\log^{1/2} x}")#text(", but this is worse than the trivial bound ")#link(<tao-2f60014f825fa20dbc56>)[#text("(3)")]#text(" by a logarithmic factor. This can be “blamed” on the fact that ")#mi("{\\Lambda}")#text(" and ")#mi("{\\chi}")#text(" are concentrated on rather different sets (")#mi("{\\Lambda}")#text(" is concentrated on primes, while ")#mi("{\\chi}")#text(" is more or less uniformly distributed amongst the natural numbers); but even if one corrects for this (e.g. by weighting Cauchy-Schwarz with some suitable “sieve weight” that is more concentrated on primes), one still does not do any better than ")#link(<tao-2f60014f825fa20dbc56>)[#text("(3)")]#text(". Indeed, the Cauchy-Schwarz inequality suffers from the same key weakness as the triangle inequality: it is insensitive to the phase oscillation of the factors ")#mi("{f, g}")#text(".")

#text("While the Cauchy-Schwarz inequality can be poor at estimating a single correlation such as ")#link(<tao-88069f4e45ea28c2a810>)[#text("(1)")]#text(", its power improves when considering an average (or sum, or square sum) of ")#emph[#text("multiple")]#text(" correlations. In this set of notes, we will focus on one such situation of this type, namely that of trying to estimate a square sum ")#metadata(none) <tao-4ba3e8e3765f2970eb37>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("(\\sum_{j=1}^J \\left|\\sum_{n} f(n) \\overline{g_j(n)}\\right|^2)^{1/2}", block: true)]]

#text("that measures the correlations of a single function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" with multiple other functions ")#mi("{g_j: {\\bf N} \\rightarrow {\\bf C}}")#text(". One should think of the situation in which ")#mi("{f}")#text(" is a “complicated” function, such as the von Mangoldt function ")#mi("{\\Lambda}")#text(", but the ")#mi("{g_j}")#text(" are relatively “simple” functions, such as Dirichlet characters. In the case when the ")#mi("{g_j}")#text(" are orthonormal functions, we of course have the classical ")#link("http://en.wikipedia.org/wiki/Bessel%27s_inequality")[#text("Bessel inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Bessel inequality)")]#text(" ")#metadata(none) <tao-372178d1c7b4f6de4a81>#text(" Let ")#mi("{g_1,\\dots,g_J: {\\bf N} \\rightarrow {\\bf C}}")#text(" be finitely supported functions obeying the orthonormality relationship")

#align(center)[#tao-fit-display[#mitex("\\sum_n g_j(n) \\overline{g_{j^{\\prime}}(n)} = 1_{j=j^{\\prime}}")]]

#text("for all ")#mi("{1 \\leq j,j^{\\prime} \\leq J}")#text(". Then for any function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{j=1}^J \\left|\\sum_{n} f(n) \\overline{g_j(n)}\\right|^2)^{1/2} \\leq (\\sum_n \\left|f(n)\\right|^2)^{1/2}.", block: true)]]
]

#text("For sake of comparison, if one were to apply the Cauchy-Schwarz inequality ")#link(<tao-27368d421f0ff4d182b6>)[#text("(4)")]#text(" separately to each summand in ")#link(<tao-4ba3e8e3765f2970eb37>)[#text("(5)")]#text(", one would obtain the bound of ")#tao-math("{J^{1/2} (\\sum_n \\left|f(n)\\right|^2)^{1/2}}", block: false)#text(", which is significantly inferior to the Bessel bound when ")#mi("{J}")#text(" is large. Geometrically, what is going on is this: the Cauchy-Schwarz inequality ")#link(<tao-27368d421f0ff4d182b6>)[#text("(4)")]#text(" is only close to sharp when ")#mi("{f}")#text(" and ")#mi("{g}")#text(" are close to parallel in the Hilbert space ")#mi("{\\ell^2({\\bf N})}")#text(". But if ")#mi("{g_1,\\dots,g_J}")#text(" are orthonormal, then it is not possible for any other vector ")#mi("{f}")#text(" to be simultaneously close to parallel to too many of these orthonormal vectors, and so the inner products of ")#mi("{f}")#text(" with most of the ")#mi("{g_j}")#text(" should be small. (See ")#link("https://terrytao.wordpress.com/2014/06/05/when-is-correlation-transitive/")[#text("this previous blog post")]#text(" for more discussion of this principle.) One can view the Bessel inequality as formalising a repulsion principle: if ")#mi("{f}")#text(" correlates too much with some of the ")#mi("{g_j}")#text(", then it does not have enough “energy” to have large correlation with the rest of the ")#mi("{g_j}")#text(".")

#text("In analytic number theory applications, it is useful to generalise the Bessel inequality to the situation in which the ")#mi("{g_j}")#text(" are not necessarily orthonormal. This can be accomplished via the Cauchy-Schwarz inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Generalised Bessel inequality)")]#text(" ")#metadata(none) <tao-e97e09ea1ab94998c5de>#text(" Let ")#mi("{g_1,\\dots,g_J: {\\bf N} \\rightarrow {\\bf C}}")#text(" be finitely supported functions, and let ")#mi("{\\nu: {\\bf N} \\rightarrow {\\bf R}^+}")#text(" be a non-negative function. Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be such that ")#mi("{f}")#text(" vanishes whenever ")#mi("{\\nu}")#text(" vanishes, we have ")#metadata(none) <tao-a9f615c4e7d33cf9a6a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("(\\sum_{j=1}^J \\left|\\sum_{n} f(n) \\overline{g_j(n)}\\right|^2)^{1/2} \\leq (\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times ( \\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)} )^{1/2}")]]

#text("for some sequence ")#mi("{c_1,\\dots,c_J}")#text(" of complex numbers with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(", with the convention that ")#tao-math("{\\left|f(n)\\right|^2/\\nu(n)}", block: false)#text(" vanishes whenever ")#mi("{f(n), \\nu(n)}")#text(" both vanish.")
]

#text("Note by relabeling that we may replace the domain ")#mi("{{\\bf N}}")#text(" here by any other at most countable set, such as the integers ")#mi("{{\\bf Z}}")#text(". (Indeed, one can give an analogue of this lemma on arbitrary measure spaces, but we will not do so here.) This result first appears in ")#link("http://www.ams.org/mathscinet-getitem?mr=3848")[#text("this paper of Boas")]#text(".")

#emph[#text("Proof:")]#text(" We use the ")#emph[#text("method of duality")]#text(" to replace the role of the function ")#mi("{f}")#text(" by a dual sequence ")#mi("{c_1,\\dots,c_J}")#text(". By the converse to Cauchy-Schwarz, we may write the left-hand side of ")#link(<tao-a9f615c4e7d33cf9a6a2>)[#text("(6)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^J \\overline{c_j} \\sum_{n} f(n) \\overline{g_j(n)}")]]

#text("for some complex numbers ")#mi("{c_1,\\dots,c_J}")#text(" with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(". Indeed, if all of the ")#mi("{\\sum_{n} f(n) \\overline{g_j(n)}}")#text(" vanish, we can set the ")#mi("{c_j}")#text(" arbitrarily, otherwise we set ")#mi("{(c_1,\\dots,c_J)}")#text(" to be the unit vector formed by dividing ")#mi("{(\\sum_{n} f(n) \\overline{g_j(n)})_{j=1}^J}")#text(" by its length. We can then rearrange this expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) \\overline{\\sum_{j=1}^J c_j g_j(n)}.")]]

#text("Applying Cauchy-Schwarz (dividing the first factor by ")#mi("{\\nu(n)^{1/2}}")#text(" and multiplying the second by ")#mi("{\\nu(n)^{1/2}}")#text(", after first removing those ")#mi("{n}")#text(" for which ")#mi("{\\nu(n)}")#text(" vanish), this is bounded by")

#align(center)[#tao-fit-display[#tao-math("(\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2} (\\sum_n \\nu(n) \\left|\\sum_{j=1}^J c_j g_j(n)\\right|^2)^{1/2},", block: true)]]

#text("and the claim follows by expanding out the second factor. ")#mi("\\Box")

#text("Observe that Lemma ")#link(<tao-372178d1c7b4f6de4a81>)[#text("1")]#text(" is a special case of Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" when ")#mi("{\\nu=1}")#text(" and the ")#mi("{g_j}")#text(" are orthonormal. In general, one can expect Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" to be useful when the ")#mi("{g_j}")#text(" are ")#emph[#text("almost orthogonal")]#text(" relative to ")#mi("{\\nu}")#text(", in that the correlations ")#mi("{\\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)}}")#text(" tend to be small when ")#mi("{j,j^{\\prime}}")#text(" are distinct. In that case, one can hope for the diagonal term ")#mi("{j=j^{\\prime}}")#text(" in the right-hand side of ")#link(<tao-a9f615c4e7d33cf9a6a2>)[#text("(6)")]#text(" to dominate, in which case one can obtain estimates of comparable strength to the classical Bessel inequality. The flexibility to choose different weights ")#mi("{\\nu}")#text(" in the above proposition has some technical advantages; for instance, if ")#mi("{f}")#text(" is concentrated in a sparse set (such as the primes), it is sometimes useful to tailor ")#mi("{\\nu}")#text(" to a comparable set (e.g. the almost primes) in order not to lose too much in the first factor ")#tao-math("{\\sum_n \\left|f(n)\\right|^2 / \\nu(n)}", block: false)#text(". Also, it can be useful to choose a fairly “smooth” weight ")#mi("{\\nu}")#text(", in order to make the weighted correlations ")#mi("{\\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)}}")#text(" small.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In harmonic analysis, the use of tools such as Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" is known as the ")#emph[#text("method of almost orthogonality")]#text(", or the ")#emph[#mi("{TT^*}")#text(" method")]#text(". The explanation for the latter name is as follows. For sake of exposition, suppose that ")#mi("{\\nu}")#text(" is never zero (or we remove all ")#mi("{n}")#text(" from the domain for which ")#mi("{\\nu(n)}")#text(" vanishes). Given a family of finitely supported functions ")#mi("{g_1,\\dots,g_J: {\\bf N} \\rightarrow {\\bf C}}")#text(", consider the linear operator ")#mi("{T: \\ell^2(\\nu^{-1}) \\rightarrow \\ell^2(\\{1,\\dots,J\\})}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("T f := ( \\sum_{n} f(n) \\overline{g_j(n)} )_{j=1}^J.")]]

#text("This is a bounded linear operator, and the left-hand side of ")#link(<tao-a9f615c4e7d33cf9a6a2>)[#text("(6)")]#text(" is nothing other than the ")#mi("{\\ell^2(\\{1,\\dots,J\\})}")#text(" norm of ")#mi("{Tf}")#text(". Without any further information on the function ")#mi("{f}")#text(" other than its ")#mi("{\\ell^2(\\nu^{-1})}")#text(" norm ")#tao-math("{(\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2}}", block: false)#text(", the best estimate one can obtain on ")#link(<tao-a9f615c4e7d33cf9a6a2>)[#text("(6)")]#text(" here is clearly")

#align(center)[#tao-fit-display[#tao-math("(\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2} \\times \\left\\|T\\right\\|_{op},", block: true)]]

#text("where ")#tao-math("{\\left\\|T\\right\\|_{op}}", block: false)#text(" denotes the operator norm of ")#mi("{T}")#text(".")

#text("The adjoint ")#mi("{T^*: \\ell^2(\\{1,\\dots,J\\}) \\rightarrow \\ell^2(\\nu^{-1})}")#text(" is easily computed to be")

#align(center)[#tao-fit-display[#mitex("T^* (c_j)_{j=1}^J := (\\sum_{j=1}^J c_j \\nu(n) g_j(n) )_{n \\in {\\bf N}}.")]]

#text("The composition ")#mi("{TT^*: \\ell^2(\\{1,\\dots,J\\}) \\rightarrow \\ell^2(\\{1,\\dots,J\\})}")#text(" of ")#mi("{T}")#text(" and its adjoint is then given by")

#align(center)[#tao-fit-display[#mitex("TT^* (c_j)_{j=1}^J := (\\sum_{j=1}^J c_j \\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}}(n) )_{j=1}^J.")]]

#text("From the spectral theorem (or singular value decomposition), one sees that the operator norms of ")#mi("{T}")#text(" and ")#mi("{TT^*}")#text(" are related by the identity")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T\\right\\|_{op} = \\left\\|TT^*\\right\\|_{op}^{1/2},", block: true)]]

#text("and as ")#mi("{TT^*}")#text(" is a self-adjoint, positive semi-definite operator, the operator norm ")#tao-math("{\\left\\|TT^*\\right\\|_{op}}", block: false)#text(" is also the supremum of the quantity")

#align(center)[#tao-fit-display[#mitex("\\langle TT^* (c_j)_{j=1}^J, (c_j)_{j=1}^J \\rangle_{\\ell^2(\\{1,\\dots,J\\})} = \\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)}")]]

#text("where ")#mi("{(c_j)_{j=1}^J}")#text(" ranges over unit vectors in ")#mi("{\\ell^2(\\{1,\\dots,J\\})}")#text(". Putting these facts together, we obtain Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text("; furthermore, we see from this analysis that the bound here is essentially optimal if the only information one is allowed to use about ")#mi("{f}")#text(" is its ")#mi("{\\ell^2(\\nu^{-1})}")#text(" norm.")

#text("For further discussion of almost orthogonality methods from a harmonic analysis perspective, see Chapter VII of ")#link("http://www.ams.org/mathscinet-getitem?mr=1232192")[#text("this text of Stein")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Under the same hypotheses as Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\sum_{n} f(n) \\overline{g_j(n)}\\right| \\leq (\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times ( \\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J \\left|\\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)}\\right| )^{1/2}", block: true)]]

#text("as well as the variant inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^J \\sum_{n} f(n) \\overline{g_j(n)}\\right| \\leq (\\sum_n \\left|f(n)\\right|^2 / \\nu(n))^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\times \\left| \\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J \\sum_n \\nu(n) g_j(n) \\overline{g_{j^{\\prime}}(n)}\\right|^{1/2}.", block: true)]]
]

#text("Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" has many applications in analytic number theory; for instance, we will use it in later notes to control the large value of Dirichlet series such as the Riemann zeta function. One of the key benefits is that it largely eliminates the need to consider further correlations of the function ")#mi("{f}")#text(" (other than its self-correlation ")#tao-math("{\\sum_n \\left|f(n)\\right|^2 / \\nu(n)}", block: false)#text(" relative to ")#mi("{\\nu^{-1}}")#text(", which is usually fairly easy to compute or estimate as ")#mi("{\\nu}")#text(" is usually chosen to be relatively simple); this is particularly useful if ")#mi("{f}")#text(" is a function which is significantly more complicated to analyse than the functions ")#mi("{g_j}")#text(". Of course, the tradeoff for this is that one now has to deal with the coefficients ")#mi("{c_j}")#text(", which if anything are even less understood than ")#mi("{f}")#text(", since literally the only thing we know about these coefficients is their square sum ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2}", block: false)#text(". However, as long as there is enough almost orthogonality between the ")#mi("{g_j}")#text(", one can estimate the ")#mi("{c_j}")#text(" by fairly crude estimates (e.g. triangle inequality or Cauchy-Schwarz) and still get reasonably good estimates.")

#text("In this set of notes, we will use Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" to prove some versions of the ")#emph[#text("large sieve inequality")]#text(", which controls a square-sum of correlations")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) e( -\\xi_j n )")]]

#text("of an arbitrary finitely supported function ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" with various additive characters ")#mi("{n \\mapsto e( \\xi_j n)}")#text(" (where ")#mi("{e(x) := e^{2\\pi i x}}")#text("), or alternatively a square-sum of correlations")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) \\overline{\\chi_j(n)}")]]

#text("of ")#mi("{f}")#text(" with various primitive Dirichlet characters ")#mi("{\\chi_j}")#text("; it turns out that one can prove a (slightly sub-optimal) version of this inequality quite quickly from Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" if one first prepares the sum by inserting a smooth cutoff with well-behaved Fourier transform. The large sieve inequality has many applications (as the name suggests, it has particular utility within ")#emph[#text("sieve theory")]#text("). For the purposes of this set of notes, though, the main application we will need it for is the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(", which in a very rough sense gives a prime number theorem in arithmetic progressions, which, “on average”, is of strength comparable to the results provided by the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("Generalised Riemann Hypothesis")]#text(" (GRH), but has the great advantage of being unconditional (it does not require any unproven hypotheses such as GRH); it can be viewed as a significant extension of the ")#link("http://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(" from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(". As we shall see in later notes, the Bombieri-Vinogradov theorem is a very useful ingredient in sieve-theoretic problems involving the primes.")

#text("There is however one additional important trick, beyond the large sieve, which we will need in order to establish the Bombieri-Vinogradov theorem. As it turns out, after some basic manipulations (and the deployment of some multiplicative number theory, and specifically the Siegel-Walfisz theorem), the task of proving the Bombieri-Vinogradov theorem is reduced to that of getting a good estimate on sums that are roughly of the form ")#metadata(none) <tao-8844588a4c9a51fca145>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{j=1}^J \\left|\\sum_n \\Lambda(n) \\overline{\\chi_j}(n)\\right|", block: true)]]

#text("for some primitive Dirichlet characters ")#mi("{\\chi_j}")#text(". This looks like the type of sum that can be controlled by the large sieve (or by Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text("), except that this is an ordinary sum rather than a square sum (i.e., an ")#mi("{\\ell^1}")#text(" norm rather than an ")#mi("{\\ell^2}")#text(" norm). One could of course try to control such a sum in terms of the associated square-sum through the Cauchy-Schwarz inequality, but this turns out to be very wasteful (it loses a factor of about ")#mi("{J^{1/2}}")#text("). Instead, one should try to exploit the special structure of the von Mangoldt function ")#mi("{\\Lambda}")#text(", in particular the fact that it can be expressible as a Dirichlet convolution ")#mi("{\\alpha * \\beta}")#text(" of two further arithmetic sequences ")#mi("{\\alpha,\\beta}")#text(" (or as a finite linear combination of such Dirichlet convolutions). The reason for introducing this convolution structure is through the basic identity ")#metadata(none) <tao-ba7816bf8f01cfea4141>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(\\sum_n \\alpha*\\beta(n) \\overline{\\chi_j}(n)) = (\\sum_n \\alpha(n) \\overline{\\chi_j}(n)) (\\sum_n \\beta(n) \\overline{\\chi_j}(n))")]]

#text("for any finitely supported sequences ")#mi("{\\alpha,\\beta: {\\bf N} \\rightarrow {\\bf C}}")#text(", as can be easily seen by multiplying everything out and using the completely multiplicative nature of ")#mi("{\\chi_j}")#text(". (This is the multiplicative analogue of the well-known relationship ")#mi("{\\widehat{f*g}(\\xi) = \\hat f(\\xi) \\hat g(\\xi)}")#text(" between ordinary convolution and Fourier coefficients.) This factorisation, together with yet another application of the Cauchy-Schwarz inequality, lets one control ")#link(<tao-8844588a4c9a51fca145>)[#text("(7)")]#text(" by square-sums of the sort that can be handled by the large sieve inequality.")

#text("As we have seen in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", the von Mangoldt function ")#mi("{\\Lambda}")#text(" does indeed admit several factorisations into Dirichlet convolution type, such as the factorisation ")#mi("{\\Lambda = \\mu * L}")#text(". One can try directly inserting this factorisation into the above strategy; it almost works, however there turns out to be a problem when considering the contribution of the portion of ")#mi("{\\mu}")#text(" or ")#mi("{L}")#text(" that is supported at very small natural numbers, as the large sieve loses any gain over the trivial bound in such settings. Because of this, there is a need for a more sophisticated decomposition of ")#mi("{\\Lambda}")#text(" into Dirichlet convolutions ")#mi("{\\alpha * \\beta}")#text(" which are non-degenerate in the sense that ")#mi("{\\alpha,\\beta}")#text(" are supported away from small values. (As a non-example, the trivial factorisation ")#mi("{\\Lambda = \\Lambda * \\delta}")#text(" would be a totally inappropriate factorisation for this purpose.) Fortunately, it turns out that through some elementary combinatorial manipulations, some satisfactory decompositions of this type are available, such as the ")#link("http://en.wikipedia.org/wiki/Vaughan%27s_identity")[#text("Vaughan identity")]#text(" and the Heath-Brown identity. By using one of these identities we will be able to complete the proof of the Bombieri-Vinogradov theorem. (These identities are also useful for other applications in which one wishes to control correlations between the von Mangoldt function ")#mi("{\\Lambda}")#text(" and some other sequence; we will see some examples of this in later notes.)")

#text("For further reading on these topics, including a significantly larger number of examples of the large sieve inequality, see Chapters 7 and 17 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec and Kowalski")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" We caution that the presentation given in this set of notes is highly ahistorical; we are using modern streamlined proofs of results that were first obtained by more complicated arguments.")
]

#metadata(none) <tao-ce5a730c76fab13f2742>

#heading(level: 1)[#strong[#text(" — 1. The large sieve inequality — ")]]

#text("We begin with a (slightly weakened) form of the large sieve inequality for additive characters, also known as the ")#emph[#text("analytic large sieve inequality")]#text(", first extracted explicitly ")#link("http://www.ams.org/mathscinet-getitem?mr=197427")[#text("by Davenport and Halberstam")]#text(" from previous work on the large sieve, and then refined further by many authors (see Remark ")#link(<tao-b073b96993d194296e92>)[#text("7")]#text(" below).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Analytic large sieve inequality)")]#text(" ")#metadata(none) <tao-ee7637bd419d4a0008d8>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function supported on an interval ")#mi("{[M,M+N]}")#text(" for some ")#mi("{M \\in {\\bf R}}")#text(" and ")#mi("{N > 0}")#text(", and let ")#mi("{\\xi_1,\\dots,\\xi_J \\in {\\bf R}/{\\bf Z}}")#text(" be ")#mi("{\\delta}")#text("-separated (thus ")#tao-math("{\\left\\|\\xi_i - \\xi_j\\right\\|_{{\\bf R}/{\\bf Z}} \\ge \\delta}", block: false)#text(" for all ")#mi("{1 \\leq i < j \\leq J}")#text(" and some ")#mi("{\\delta>0}")#text(", where ")#tao-math("{\\left\\|\\xi\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance from ")#mi("{\\xi}")#text(" to the nearest integer. Then ")#metadata(none) <tao-1d286cdd6208c38c767f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\sum_{j=1}^J \\left|\\sum_n f(n) e( - \\xi_j n )\\right|^2 \\ll (N + \\frac{1}{\\delta}) \\sum_n \\left|f(n)\\right|^2.", block: true)]]
]

#text("One can view this proposition as a variant of the Plancherel identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^N \\left|\\sum_{n=1}^N f(n) e( - jn / N )\\right|^2 = N \\sum_{n=1}^N \\left|f(n)\\right|^2", block: true)]]

#text("associated to the Fourier transform on a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". This identity also shows that apart from the implied constant, the bound ")#link(<tao-1d286cdd6208c38c767f>)[#text("(9)")]#text(" is essentially best possible.")

#emph[#text("Proof:")]#text(" By increasing ")#mi("{N}")#text(" (if ")#mi("{N < 1/\\delta}")#text(") or decreasing ")#mi("{\\delta}")#text(" (if ")#mi("{1/\\delta < N}")#text("), we can reduce to the case ")#mi("{N = \\frac{1}{\\delta}}")#text(" without making the hypotheses any stronger. Thus the ")#mi("{\\xi_j}")#text(" are now ")#mi("{1/N}")#text("-separated, and our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\sum_n f(n) e( - \\xi_j n )\\right|^2 \\ll N \\sum_n \\left|f(n)\\right|^2.", block: true)]]

#text("We now wish to apply Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" (with ")#mi("{{\\bf N}}")#text(" relabeled by ")#mi("{{\\bf Z}}")#text("), but we need to choose a suitable weight function ")#mi("{\\nu: {\\bf Z} \\rightarrow {\\bf R}^+}")#text(". It turns out that it is advantageous for technical reasons to select a weight that has good Fourier-analytic properties.")

#text("Fix a smooth non-negative function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" supported on ")#mi("{[-1/4,1/4]}")#text(" and not identically zero; we allow implied constants to depend on ")#mi("{\\psi}")#text(". (Actually, the smoothness of ")#mi("{\\psi}")#text(" is not absolutely necessary for this argument; one could take ")#mi("{\\psi = 1_{[-1/4,1/4]}}")#text(" below if desired.) Consider the weight ")#mi("{\\nu: {\\bf R} \\rightarrow {\\bf R}^+}")#text(" defined by")

#align(center)[#tao-fit-display[#tao-math("\\nu(n) := \\left|\\int_{\\bf R} \\psi( x ) e( x \\frac{n-M}{N} )\\ dx\\right|^2.", block: true)]]

#text("Observe that ")#mi("{\\nu \\gg 1}")#text(" for all ")#mi("{n \\in [M,M+N]}")#text(". Thus, by Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" with this choice of ")#mi("{\\nu}")#text(", we reduce to showing that ")#metadata(none) <tao-c278ec5a69c34aace427>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\sum_{j=1}^J \\sum_{j^{\\prime}=1}^J c_j \\overline{c_{j^{\\prime}}} \\sum_n \\nu(n) e( (\\xi_j - \\xi_{j^{\\prime}}) n ) \\ll N")]]

#text("whenever ")#mi("{c_1,\\dots,c_J}")#text(" are complex numbers with ")#tao-math("{\\sum_{j=1}^J \\left|c_j\\right|^2 = 1}", block: false)#text(".")

#text("We first consider the diagonal contribution ")#mi("{j=j^{\\prime}}")#text(". We can write ")#mi("{\\nu}")#text(" in terms of the Fourier transform ")#mi("{\\hat \\psi(\\xi) := \\int_{\\bf R} \\psi(x) e^{i x\\xi}\\ dx}")#text(" of ")#mi("{\\psi}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\nu(t) = \\left|\\hat \\psi( 2\\pi (t-M) / N )\\right|^2,", block: true)]]

#text("and hence by Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(", we have the bounds ")#metadata(none) <tao-e66f9e6444b4e6b13f86>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\nu(n) \\ll \\frac{1}{(1 + (n-M)/N)^2}")]]

#text("(say) and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) \\ll N.")]]

#text("Thus the diagonal contribution ")#mi("{j=j^{\\prime}}")#text(" of ")#link(<tao-c278ec5a69c34aace427>)[#text("(10)")]#text(" is acceptable.")

#text("Now we consider an off-diagonal term ")#mi("{\\sum_n \\nu(n) e( (\\xi_j - \\xi_{j^{\\prime}}) n )}")#text(" with ")#mi("{j \\neq j^{\\prime}}")#text(". By the Poisson summation formula (Theorem 34 from ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text("), we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\hat \\nu( 2\\pi (m + \\xi_j - \\xi_{j^{\\prime}}) ).")]]

#text("Now from the Fourier inversion formula, the function ")#mi("{\\hat \\psi}")#text(" has Fourier transform supported on ")#mi("{[-1/4,1/4]}")#text(", and so ")#mi("{\\nu}")#text(" has Fourier transform supported in ")#mi("{[-\\frac{\\pi}{N}, \\frac{\\pi}{N}]}")#text(". Since ")#mi("{\\xi_j - \\xi_{j^{\\prime}}}")#text(" is at least ")#mi("{1/N}")#text(" from the nearest integer, we conclude that ")#mi("{\\hat \\nu( 2\\pi (m + \\xi_j - \\xi_{j^{\\prime}}) )=0}")#text(" for all integers ")#mi("{m}")#text(", and hence all the off-diagonal terms in fact vanish! The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-b073b96993d194296e92>#text(" If ")#mi("{M,N}")#text(" are integers, one can in fact obtain the sharper bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\sum_n f(n) e( - \\xi_j n )\\right|^2 \\leq (N + \\frac{1}{\\delta}) \\sum_n \\left|f(n)\\right|^2,", block: true)]]

#text("a ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("result of Montgomery and Vaughan")]#text(" (with ")#mi("{N}")#text(" replaced by ")#mi("{N+1}")#text(", although it was observed subsequently subsequently by Paul Cohen that the additional ")#mi("{+1}")#text(" term could be deleted by an amplification trick similar to those discussed in ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("this previous post")]#text("). See ")#link("http://www.ams.org/mathscinet-getitem?mr=466048")[#text("this survey of Montgomery")]#text(" for these results and on the (somewhat complicated) evolution of the large sieve, starting with the pioneering ")#link("http://www.ams.org/mathscinet-getitem?mr=4266")[#text("work of Linnik")]#text(". However, in our applications the cruder form of the analytic large sieve inequality given by Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(" will suffice.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a function supported on an interval ")#mi("{[M,M+N]}")#text(". Show that for any ")#mi("{A \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n f(n) e( - \\xi n)\\right| \\leq A (\\sum_n \\left|f(n)\\right|^2)^{1/2}", block: true)]]

#text("for all ")#mi("{\\xi \\in {\\bf R}/{\\bf Z}}")#text(" outside of the union of ")#mi("{O( \\frac{N}{A^2} )}")#text(" intervals (or arcs) of length ")#mi("{1/N}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n f(n) e( - \\xi n)\\right| \\ll \\sqrt{N} (\\sum_n \\left|f(n)\\right|^2)^{1/2}", block: true)]]

#text("for ")#emph[#text("all")]#text(" ")#mi("{\\xi \\in {\\bf R}/{\\bf Z}}")#text(", and the significantly superior estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n f(n) e( - \\xi n)\\right| \\ll (\\sum_n \\left|f(n)\\right|^2)^{1/2}", block: true)]]

#text("for ")#emph[#text("most")]#text(" ")#mi("{\\xi \\in {\\bf R}/{\\bf Z}}")#text(" (outside of at most (say) ")#mi("{N/2}")#text(" intervals of length ")#mi("{1/N}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Continuous large sieve inequality)")]#text(" Let ")#mi("{[M,M+N]}")#text(" be an interval for some ")#mi("{M \\in {\\bf R}}")#text(" and ")#mi("{N > 0}")#text(", and let ")#mi("{\\xi_1,\\dots,\\xi_J \\in {\\bf R}}")#text(" be ")#mi("{\\delta}")#text("-separated.")

#list(
[#text("(i) For any complex numbers ")#mi("{c_1,\\dots,c_J}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\int_M^{M+N} \\left|\\sum_{j=1}^J c_j e( \\xi_j t )\\right|^2\\ dt \\ll (N + \\frac{1}{\\delta}) \\sum_{j=1}^J \\left|c_j\\right|^2.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" replace the restriction of ")#mi("{t}")#text(" to ")#mi("{[M,M+N]}")#text(" with the weight ")#mi("{\\nu(t)}")#text(" used to prove Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(".)")],
[#text("(ii) For any continuous ")#mi("{f: [M,M+N] \\rightarrow {\\bf C}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^J \\left|\\int_M^{M+N} f(t) e( - \\xi_j t )\\ dt\\right|^2 \\ll (N + \\frac{1}{\\delta}) \\int_M^{M+N} \\left|f(t)\\right|^2\\ dt.", block: true)]]]
)
]

#text("Now we establish a variant of the analytic large sieve inequality, involving Dirichlet characters, ")#link("http://www.ams.org/mathscinet-getitem?mr=260703")[#text("due to Bombieri and Davenport")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Large sieve inequality for characters)")]#text(" ")#metadata(none) <tao-6d80441bcb1fecec4862>#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a function supported on an interval ")#mi("{[M,M+N]}")#text(" for some ")#mi("{M \\in {\\bf R}}")#text(" and ")#mi("{N > 0}")#text(", and let ")#mi("{Q \\geq 1}")#text(". Then ")#metadata(none) <tao-092301a7cce55b56a76a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{q \\leq Q} \\frac{q}{\\phi(q)} \\sum^*_{\\chi\\ (q)} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2 \\ll (N + Q^2) \\sum_n \\left|f(n)\\right|^2,", block: true)]]

#text("where ")#mi("{\\sum^*_{\\chi\\ (q)}}")#text(" denotes the sum over all primitive Dirichlet characters of modulus ")#mi("{q}")#text(".")
]

#emph[#text("Proof:")]#text(" By increasing ")#mi("{N}")#text(" or decreasing ")#mi("{Q}")#text(", we may assume that ")#mi("{N=Q^2}")#text(", so ")#mi("{N \\geq 1}")#text(" and our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq \\sqrt{N}} \\frac{q}{\\phi(q)} \\sum^*_{\\chi\\ (q)} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2 \\ll N \\sum_n \\left|f(n)\\right|^2.", block: true)]]

#text("Let ")#mi("{\\nu}")#text(" be the weight from Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(". By Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" (and some relabeling), using the functions ")#mi("{(\\frac{q}{\\phi(q)})^{1/2} \\chi}")#text(", it suffices to show that ")#metadata(none) <tao-f41447ff91a738ca5c76>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{q,q^{\\prime} \\leq \\sqrt{N}} \\left(\\frac{q}{\\phi(q)}\\right)^{1/2} \\left(\\frac{q^{\\prime}}{\\phi(q^{\\prime})}\\right)^{1/2} \\sum^*_{\\chi\\ (q)} \\sum^*_{\\chi^{\\prime}\\ (q^{\\prime})} c_\\chi \\overline{c_{\\chi^{\\prime}}} \\sum_n \\nu(n) \\chi(n) \\overline{\\chi^{\\prime}(n)}")]]

#align(center)[#tao-fit-display[#mitex("\\ll N")]]

#text("whenever ")#mi("{c_\\chi}")#text(" are complex numbers with ")#metadata(none) <tao-af7961f5d4f758b0626a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{q \\leq \\sqrt{N}} \\sum^*_{\\chi\\ (q)} \\left|c_\\chi\\right|^2 = 1.", block: true)]]

#text("We first establish that the diagonal contribution ")#mi("{(q,\\chi)=(q^{\\prime},\\chi^{\\prime})}")#text(" to ")#link(<tao-f41447ff91a738ca5c76>)[#text("(13)")]#text(" is acceptable, that is to say that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq \\sqrt{N}} \\frac{q}{\\phi(q)} \\sum^*_{\\chi\\ (q)} \\left|c_\\chi\\right|^2 \\sum_n \\nu(n) \\left|\\chi(n)\\right|^2 \\ll N.", block: true)]]

#text("The function ")#tao-math("{\\left|\\chi(n)\\right|^2}", block: false)#text(" is the principal character of modulus ")#mi("{q}")#text("; it is periodic with period ")#mi("{q}")#text(" and has mean value ")#mi("{\\phi(q)/q}")#text(". In particular, since ")#mi("{q \\leq \\sqrt{N} \\leq N}")#text(", we see that ")#tao-math("{\\sum_{M^{\\prime} \\leq n \\leq M^{\\prime}+N} \\left|\\chi(n)\\right|^2 \\ll \\frac{\\phi(q)}{q} N}", block: false)#text(" for any interval ")#mi("{[M^{\\prime},M^{\\prime}+N]}")#text(" of length ")#mi("{N}")#text(". From ")#link(<tao-e66f9e6444b4e6b13f86>)[#text("(11)")]#text(" and a partition into intervals of length ")#mi("{N}")#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\nu(n) \\left|\\chi(n)\\right|^2 \\ll \\frac{\\phi(q)}{q} N", block: true)]]

#text("and the claim then follows from ")#link(<tao-af7961f5d4f758b0626a>)[#text("(14)")]#text(".")

#text("Now consider an off-diagonal term ")#mi("{\\sum_n \\nu(n) \\chi(n) \\overline{\\chi^{\\prime}(n)}}")#text(" with ")#mi("{\\chi \\neq \\chi^{\\prime}}")#text(". As ")#mi("{\\chi,\\chi^{\\prime}}")#text(" are primitive, this implies that ")#mi("{\\chi \\overline{\\chi^{\\prime}}}")#text(" is a non-principal character and thus has mean zero. Let ")#mi("{r}")#text(" be the modulus of this character; by Fourier expansion we may write ")#mi("{\\chi \\overline{\\chi^{\\prime}}}")#text(" as a linear combination of the additive characters ")#mi("{n \\mapsto e( k n / r )}")#text(" for ")#mi("{1 \\leq k < r}")#text(". (We can obtain explicit coefficients from this expansion by invoking Lemma 48 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(", but we will not need those coefficients here.) Thus ")#mi("{\\sum_n \\nu(n) \\chi(n) \\overline{\\chi^{\\prime}(n)}}")#text(" is a linear combination of the quantities ")#mi("{\\sum_n \\nu(n) e( kn/r)}")#text(" for ")#mi("{1 \\leq k < r}")#text(". But the modulus ")#mi("{r}")#text(" is the least common multiple of the moduli of ")#mi("{\\chi,\\chi^{\\prime}}")#text(", so in particular ")#mi("{r \\leq N}")#text(", while as observed in the proof of Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(", we have ")#mi("{\\sum_n \\nu(n) e( \\theta n ) = 0}")#text(" whenever ")#tao-math("{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}} \\geq 1/2N}", block: false)#text(". So the off-diagonal terms all vanish, and the claim follows. ")#mi("\\Box")

#text("One can also derive Proposition ")#link(<tao-6d80441bcb1fecec4862>)[#text("10")]#text(" from Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{f: {\\bf Z} \\rightarrow {\\bf C}}")#text(" be a finitely supported sequence.")

#list(
[#text("(i) For any natural number ")#mi("{q}")#text(", establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_n f(n) e(an/q)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q)} \\left|\\sum_n f(n) \\sum_{a \\in {\\bf Z}/q{\\bf Z}} \\chi(a) e(an/q)\\right|^2", block: true)]]

#text("where ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(" is the set of congruence classes ")#mi("{a\\ (q)}")#text(" coprime to ")#mi("{q}")#text(", and ")#mi("{\\sum_{\\chi\\ (q)}}")#text(" is the sum over all characters (not necessarily primitive) of modulus ")#mi("{q}")#text(".")],
[#text("(ii) For any natural number ")#mi("{q}")#text(", establish the inequality")

#align(center)[#tao-fit-display[#tao-math("\\frac{q}{\\phi(q)} \\sum^*_{\\chi\\ (q)} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2 \\leq \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_n f(n) e(an/q)\\right|^2", block: true)]]

#text("and use this and Proposition ")#link(<tao-ee7637bd419d4a0008d8>)[#text("6")]#text(" to derive Proposition ")#link(<tao-6d80441bcb1fecec4862>)[#text("10")]#text(". (")#emph[#text("Hint:")]#text(" use Lemma 48 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" By combining the arguments in the above exercise with the results in Remark ")#link(<tao-b073b96993d194296e92>)[#text("7")]#text(", one can sharpen Proposition ")#link(<tao-6d80441bcb1fecec4862>)[#text("10")]#text(" to")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\frac{q}{\\phi(q)} \\sum^*_{\\chi\\ (q)} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2 \\leq (N + Q^2) \\sum_n \\left|f(n)\\right|^2,", block: true)]]

#text("that is to say one can delete the implied constant. See ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("this paper of Montgomery and Vaughan")]#text(" for some further refinements of this inequality.")
]

#heading(level: 1)[#strong[#text(" — 2. The Barban-Davenport-Halberstam theorem — ")]]

#text("We now apply the large sieve inequality for characters to obtain an analogous inequality for arithmetic progressions, due independently ")#link("http://www.ams.org/mathscinet-getitem?mr=199171")[#text("to Barban")]#text(", and to ")#link("http://www.ams.org/mathscinet-getitem?mr=200257")[#text("Davenport and Halberstam")]#text("; we state a slightly weakened form of that theorem here. For any finitely supported arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and any primitive residue class ")#mi("{a\\ (q)}")#text(", we introduce the ")#emph[#text("discrepancy")]

#align(center)[#tao-fit-display[#mitex("\\Delta(f; a\\ (q)) := \\sum_{n: n = a\\ (q)} f(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} f(n).")]]

#text("This quantity measures the extent to which ")#mi("{f}")#text(" is well distributed among the primitive residue classes modulo ")#mi("{n}")#text(". From multiplicative Fourier inversion (see Theorem 69 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") we have the identity ")#metadata(none) <tao-6bf99799d0ef91be6c25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\Delta(f; a\\ (q)) = \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q): \\chi \\neq \\chi_0} \\chi(a) \\sum_n f(n) \\overline{\\chi(n)}")]]

#text("where the sum is over non-principal characters ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Barban-Davenport-Halberstam)")]#text(" Let ")#mi("{x > 2}")#text(", and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a function supported on ")#mi("{[1,x]}")#text(" with the property that ")#metadata(none) <tao-55ea4297a9fef0c87427>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\sum_n \\left|f(n)\\right|^2 \\ll x \\log^{O(1)} x", block: true)]]

#text("and obeying the ")#emph[#text("Siegel-Walfisz property")]#text(" ")#metadata(none) <tao-149903638179655b2b8f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\Delta(f 1_{(\\cdot,s)=1}; a\\ (r)) \\ll_A x \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(", any primitive residue class ")#mi("{a\\ (r)}")#text(", and any ")#mi("{1 \\leq s \\leq x}")#text(". Then one has ")#metadata(none) <tao-560c987e35675251567b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(f; a\\ (q))\\right|^2 \\ll_A x^2 \\log^{-A} x", block: true)]]

#text("for any ")#mi("{A > 0}")#text(", provided that ")#mi("{Q \\leq x \\log^{-B} x}")#text(" for some sufficiently large ")#mi("{B = B(A)}")#text(" depending only on ")#mi("{A}")#text(".")
]

#text("Informally, ")#link(<tao-560c987e35675251567b>)[#text("(18)")]#text(" is asserting that")

#align(center)[#tao-fit-display[#mitex("\\Delta(f; a\\ (q)) \\ll_A \\frac{x}{\\phi(q)} \\log^{-A} x")]]

#text("for “most” primitive residue classes ")#mi("{a\\ (q)}")#text(" with ")#mi("{q}")#text(" much smaller than ")#mi("{x}")#text("; in most applications, the trivial bounds on ")#mi("{\\Delta(f; a\\ (q))}")#text(" are of the type ")#mi("{O( \\frac{x}{\\phi(q)} \\log^{O(1)} x )}")#text(", so this represents a savings of an arbitrary power of a logarithm on the average. Note that a direct application of ")#link(<tao-149903638179655b2b8f>)[#text("(17)")]#text(" only gives ")#link(<tao-560c987e35675251567b>)[#text("(18)")]#text(" for ")#mi("{Q}")#text(" of size ")#mi("{\\log^{O(1)} x}")#text("; it is the large sieve which allows for the significant enlargement of ")#mi("{Q}")#text(".")

#emph[#text("Proof:")]#text(" Let ")#mi("{x, f, Q, A}")#text(" be as above, with ")#mi("{Q \\leq x \\log^{-B} x}")#text(" for some large ")#mi("{B}")#text(" to be chosen later. From ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(15)")]#text(" and the Plancherel identity one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(f; a\\ (q))\\right|^2 = \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q): \\chi \\neq \\chi_0} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2", block: true)]]

#text("so our task is to show that ")#metadata(none) <tao-0ebb429fa86d481c2630>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_{q \\leq Q} \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q): \\chi \\neq \\chi_0} \\left|\\sum_n f(n) \\overline{\\chi(n)}\\right|^2 \\ll_A x^2 \\log^{-A} x.", block: true)]]

#text("We cannot apply the large sieve inequality yet, because the characters ")#mi("{\\chi}")#text(" here are not necessarily primitive. But we may express any non-principal character ")#mi("{\\chi(n)}")#text(" as ")#mi("{\\tilde \\chi(n) 1_{(n,s)=1}}")#text(" for some primitive character ")#mi("{\\tilde \\chi}")#text(" of conductor ")#mi("{r>1}")#text(", where ")#mi("{r,s,t}")#text(" are natural numbers with ")#mi("{rst = q}")#text(". In particular, ")#mi("{r,s,t \\leq Q}")#text(" and ")#mi("{\\frac{1}{\\phi(q)} \\leq \\frac{1}{\\phi(s)} \\frac{1}{\\phi(r)} \\frac{1}{\\phi(t)}}")#text(". Thus we may (somewhat crudely) upper bound the left-hand side of ")#link(<tao-0ebb429fa86d481c2630>)[#text("(19)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{t \\leq Q} \\frac{1}{\\phi(t)} \\sum_{s \\leq Q} \\frac{1}{\\phi(s)} \\sum_{1 < r \\leq Q} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2.", block: true)]]

#text("From Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" we have ")#mi("{\\sum_{s \\leq Q} \\frac{1}{\\phi(s)} \\ll \\log x}")#text(", so we may bound the above by")

#align(center)[#tao-fit-display[#tao-math("(\\log x)^2 \\sup_{s \\leq Q} \\sum_{1 < r \\leq Q} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2.", block: true)]]

#text("By dyadic decomposition (and adjusting ")#mi("{A}")#text(" slightly), it thus suffices to show that ")#metadata(none) <tao-6a581ee901185606598b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\sum_{R < r \\leq 2R} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2 \\ll_A x^2 \\log^{-A} x", block: true)]]

#text("for any ")#mi("{1 \\leq R \\leq Q}")#text(" and ")#mi("{s \\leq Q}")#text(".")

#text("From Proposition ")#link(<tao-6d80441bcb1fecec4862>)[#text("10")]#text(" and ")#link(<tao-55ea4297a9fef0c87427>)[#text("(16)")]#text(", we may bound the left-hand side of ")#link(<tao-6a581ee901185606598b>)[#text("(20)")]#text(" by ")#mi("{\\frac{1}{R} (x + R^2) x \\log^{O(1)} x}")#text(". If ")#mi("{R \\geq \\log^B x}")#text(" and ")#mi("{R \\leq Q \\leq x \\log^{-B} x}")#text(", then we obtain ")#link(<tao-6a581ee901185606598b>)[#text("(20)")]#text(" if ")#mi("{B}")#text(" is sufficiently large depending on ")#mi("{A}")#text(". The only remaining case to consider is when ")#mi("{R < log^B x}")#text(". But from the Siegel-Walfisz hypothesis ")#link(<tao-149903638179655b2b8f>)[#text("(17)")]#text(" we easily see that")

#align(center)[#tao-fit-display[#mitex("\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)} \\ll_{A^{\\prime}} R x \\log^{-A^{\\prime}} x")]]

#text("for any ")#mi("{A^{\\prime} > 0}")#text(" and any primitive character ")#mi("{\\tilde \\chi}")#text(" of conductor ")#mi("{R < r \\leq 2R}")#text(". Since the total number of primitive characters appearing in ")#link(<tao-6a581ee901185606598b>)[#text("(20)")]#text(" is ")#mi("{O(R^2) = O( \\log^{2B} x)}")#text(", the claim follows by taking ")#mi("{A^{\\prime}}")#text(" large enough. ")#mi("\\Box")

#text("One can specialise this to the von Mangoldt function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" ")#metadata(none) <tao-34aef458a17fddb8f7ca>#text(" Use the Barban-Davenport-Halberstam theorem and the Siegel-Walfisz theorem (Exercise 64 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") to conclude that ")#metadata(none) <tao-24f353e0da1ced9f24b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{q \\leq Q} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right|^2 \\ll_A x^2 \\log^{-A} x", block: true)]]

#text("for any ")#mi("{A > 0}")#text(", provided that ")#mi("{Q \\leq x \\log^{-B} x}")#text(" for some sufficiently large ")#mi("{B = B(A)}")#text(" depending only on ")#mi("{A}")#text(". Obtain a similar claim with ")#mi("{\\Lambda}")#text(" replaced by the Möbius function.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" Recall that the implied constants in the Siegel-Walfisz theorem depended on ")#mi("{A}")#text(" in an ineffective fashion. As such, the implied constants in ")#link(<tao-24f353e0da1ced9f24b1>)[#text("(21)")]#text(" also depend ineffectively on ")#mi("{A}")#text(". However, if one replaces Siegel’s theorem by an effective substitute such as Tatuzawa’s theorem (see Theorem 62 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") or the Landau-Page theorem (Theorem 53 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), one can obtain an effective version of the Siegel-Walfisz theorem for all moduli ")#mi("{q}")#text(" that are not multiples of a single exceptional modulus ")#mi("{q_*}")#text(". One can then obtain an effective version of ")#link(<tao-24f353e0da1ced9f24b1>)[#text("(21)")]#text(" if one restricts to moduli ")#mi("{q}")#text(" that are not multiples of ")#mi("{q_*}")#text(". Similarly for the Bombieri-Vinogradov theorem in the next section. Such variants of the Barban-Davenport-Halberstam theorem or Bombieri-Vinogradov theorem can be used as a substitute in some applications to remove any ineffective dependence of constants, at the cost of making the argument slightly more convoluted.")
]

#heading(level: 1)[#strong[#text(" — 3. The Bombieri-Vinogradov theorem — ")]]

#text("The Barban-Davenport-Halberstam theorem controls the discrepancy ")#mi("{\\Delta(f; a\\ (q))}")#text(" after averaging in both the modulus ")#mi("{q}")#text(" and the residue class ")#mi("{a}")#text(". For many problems in sieve theory, it turns out to be more important to control the discrepancy with an averaging only in the modulus ")#mi("{q}")#text(", with the residue class ")#mi("{a}")#text(" being allowed to vary in ")#mi("{q}")#text(" in the “worst-case” fashion. Specifically, one often wishes to control expressions of the form ")#metadata(none) <tao-66e6eed42917b8a0dd2a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(f; a\\ (q))\\right|.", block: true)]]

#text("for some finitely supported ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and ")#mi("{Q>1}")#text(". This expression is difficult to control for arbitrary ")#mi("{f}")#text(", but it turns out that one can obtain a good bound if ")#mi("{f}")#text(" is expressible as a Dirichlet convolution ")#mi("{f = \\alpha*\\beta}")#text(" for some suitably “non-degenerate” sequences ")#mi("{\\alpha,\\beta}")#text(". More precisely, we have the following general form of the Bombieri-Vinogradov theorem, first articulated ")#link("http://www.ams.org/mathscinet-getitem?mr=422179")[#text("by Motohashi")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (General Bombieri-Vinogradov theorem)")]#text(" ")#metadata(none) <tao-0cd856b24b9ffe6d3b3a>#text(" Let ")#mi("{x > 2}")#text(", let ")#mi("{M,N \\geq 1}")#text(" be such that ")#mi("{MN \\ll x}")#text(", and let ")#mi("{\\alpha,\\beta: {\\bf N} \\rightarrow {\\bf C}}")#text(" be arithmetic functions supported on ")#mi("{[1,M]}")#text(", ")#mi("{[1,N]}")#text(" respectively, with ")#metadata(none) <tao-b84f6a9ecdd162400da2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\sum_m \\left|\\alpha(m)\\right|^2 \\ll M \\log^{O(1)} x", block: true)]]

#text("and ")#metadata(none) <tao-740d1e168c8b3cc259a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\sum_n \\left|\\beta(n)\\right|^2 \\ll N \\log^{O(1)} x.", block: true)]]

#text("Suppose that ")#mi("{\\beta}")#text(" obeys the ")#emph[#text("Siegel-Walfisz property")]#text(" ")#metadata(none) <tao-b9b56feef5a8871646ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\Delta(\\beta 1_{(\\cdot,s)=1}; a\\ (r)) \\ll_A N \\log^{-A} x")]]

#text("for all ")#mi("{A > 0}")#text(", all primitive residue classes ")#mi("{a\\ (r)}")#text(", and all ")#mi("{1 \\leq s \\leq x}")#text(". Then one has ")#metadata(none) <tao-efda1c925291a74c51bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha * \\beta; a\\ (q))\\right| \\ll_{A} x \\log^{-A} x", block: true)]]

#text("for any ")#mi("{A > 0}")#text(", provided that ")#mi("{Q \\leq x^{1/2} \\log^{-B} x}")#text(" and ")#mi("{M,N \\geq \\log^B x}")#text(" for some sufficiently large ")#mi("{B = B(A)}")#text(" depending on ")#mi("{A}")#text(".")
]

#emph[#text("Proof:")]#text(" We adapt the arguments of the previous section. From ")#link(<tao-6bf99799d0ef91be6c25>)[#text("(15)")]#text(" and the triangle inequality, we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha*\\beta; a\\ (q))\\right| \\leq \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q): \\chi \\neq \\chi_0} \\left|\\sum_n \\alpha*\\beta(n) \\overline{\\chi(n)}\\right|", block: true)]]

#text("and so we can upper bound the left-hand side of ")#link(<tao-efda1c925291a74c51bb>)[#text("(26)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\leq Q} \\frac{1}{\\phi(q)} \\sum_{\\chi\\ (q): \\chi \\neq \\chi_0} |\\sum_n \\alpha*\\beta(n) \\overline{\\chi(n)}|.")]]

#text("As in the previous section, we may reduce ")#mi("{\\chi}")#text(" to primitive characters and bound this expression by")

#align(center)[#tao-fit-display[#mitex("\\ll (\\log x)^2 \\sup_{s \\leq Q} \\sum_{1 < r \\leq Q} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* |\\sum_n \\alpha*\\beta(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}|.")]]

#text("By dyadic decomposition (and adjusting ")#mi("{A}")#text(" slightly), it thus suffices to show that ")#metadata(none) <tao-46ef921f224e814b835d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\sum_{R < r \\leq 2R} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n \\alpha*\\beta(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right| \\ll_A x \\log^{-A} x", block: true)]]

#text("for all ")#mi("{1 \\leq R \\leq Q}")#text(" and ")#mi("{s \\leq Q}")#text(", and any ")#mi("{A>1}")#text(", assuming ")#mi("{Q \\leq x^{1/2} \\log^{-B} x}")#text(" and ")#mi("{M,N \\geq \\log^B x}")#text(" with ")#mi("{B}")#text(" sufficiently large depending on ")#mi("{A}")#text(".")

#text("We cannot yet easily apply the large sieve inequality, because the character sums here are not squared. But we now crucially exploit the Dirichlet convolution structure using the identity ")#link(<tao-ba7816bf8f01cfea4141>)[#text("(8)")]#text(", to factor ")#mi("{\\sum_n \\alpha*\\beta(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}}")#text(" as the product of ")#mi("{\\sum_m \\alpha(m) 1_{(m,s)=1} \\overline{\\tilde \\chi(m)}}")#text(" and ")#mi("{\\sum_n \\beta(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}}")#text(". From the Cauchy-Schwarz inequality, we may thus bound ")#link(<tao-46ef921f224e814b835d>)[#text("(27)")]#text(" by the geometric mean of ")#metadata(none) <tao-e99f531e30cc72632070>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\sum_{R < r \\leq 2R} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_m \\alpha(m) 1_{(m,s)=1} \\overline{\\tilde \\chi(m)}\\right|^2", block: true)]]

#text("and ")#metadata(none) <tao-2cb9fb9c4e45b149f658>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\sum_{R < r \\leq 2R} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n \\beta(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2.", block: true)]]

#text("Now we have the all-important square needed in the large sieve inequality. From ")#link(<tao-b84f6a9ecdd162400da2>)[#text("(23)")]#text(", ")#link(<tao-740d1e168c8b3cc259a1>)[#text("(24)")]#text(" and Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(", we may bound ")#link(<tao-e99f531e30cc72632070>)[#text("(28)")]#text(" by ")#metadata(none) <tao-7dd04b0145ffa5646536>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\ll \\frac{1}{R} (M + R^2) M \\log^{O(1)} x")]]

#text("and ")#link(<tao-2cb9fb9c4e45b149f658>)[#text("(29)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{1}{R} (N + R^2) N \\log^{O(1)} x")]]

#text("and so ")#link(<tao-46ef921f224e814b835d>)[#text("(27)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll ( \\frac{MN}{R} + M N^{1/2} + M^{1/2} N + R (MN)^{1/2} ) \\log^{O(1)} x.")]]

#text("Since ")#mi("{MN \\leq x}")#text(", we can write this as")

#align(center)[#tao-fit-display[#mitex("\\ll ( \\frac{1}{R} + \\frac{1}{N^{1/2}} + \\frac{1}{M^{1/2}} + \\frac{R}{x^{1/2}} ) x \\log^{O(1)} x.")]]

#text("Since ")#mi("{N,M \\geq \\log^B x}")#text(" and ")#mi("{R \\leq Q \\leq x^{1/2} \\log^{-B} x}")#text(", we obtain ")#link(<tao-46ef921f224e814b835d>)[#text("(27)")]#text(" if ")#mi("{R \\geq \\log^B x}")#text(" and ")#mi("{B}")#text(" is sufficiently large depending on ")#mi("{A}")#text(". The only remaining case to handle is when ")#mi("{R \\leq \\log^B x}")#text(". In this case, we can use the Siegel-Walfisz hypothesis ")#link(<tao-b9b56feef5a8871646ed>)[#text("(25)")]#text(" as in the previous section to bound ")#link(<tao-2cb9fb9c4e45b149f658>)[#text("(29)")]#text(" by ")#mi("{O_{A^{\\prime}}( N^2 \\log^{-A^{\\prime}} x)}")#text(" for any ")#mi("{A^{\\prime}>0}")#text(". Meanwhile, from ")#link(<tao-7dd04b0145ffa5646536>)[#text("(30)")]#text(", ")#link(<tao-e99f531e30cc72632070>)[#text("(28)")]#text(" is bounded by ")#mi("{O( M^2 \\log^{O(B+1)} x )}")#text(". By taking ")#mi("{A^{\\prime}}")#text(" sufficiently large, we conclude ")#link(<tao-46ef921f224e814b835d>)[#text("(27)")]#text(" in this case also. ")#mi("\\Box")

#text("In analogy with Exercise ")#link(<tao-34aef458a17fddb8f7ca>)[#text("14")]#text(", we would like to apply this general result to specific arithmetic functions, such as the von Mangoldt function ")#mi("{\\Lambda}")#text(" or the Möbius function ")#mi("{\\mu}")#text(", and in particular to prove the following famous result of ")#link("http://www.ams.org/mathscinet-getitem?mr=371840")[#text("Bombieri")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=197414")[#text("of A. I. Vinogradov")]#text(" (not to be confused with the more well known number theorist ")#link("http://en.wikipedia.org/wiki/Ivan_Matveyevich_Vinogradov")[#text("I. M. Vinogradov")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Bombieri-Vinogradov theorem)")]#text(" ")#metadata(none) <tao-0c69135deca1e682d588>#text(" Let ")#mi("{x \\geq 2}")#text(". Then one has ")#metadata(none) <tao-3eca4424d164d0e02850>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll_{A} x \\log^{-A} x", block: true)]]

#text("for any ")#mi("{A > 0}")#text(", provided that ")#mi("{Q \\leq x^{1/2} \\log^{-B} x}")#text(" for some sufficiently large ")#mi("{B = B(A)}")#text(" depending on ")#mi("{A}")#text(".")
]

#text("Informally speaking, the Bombieri-Vinogradov theorem asserts that for “almost all” moduli ")#mi("{q}")#text(" that are significantly less than ")#mi("{x^{1/2}}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll_A \\frac{x}{\\phi(q)} \\log^{-A} x", block: true)]]

#text("for ")#emph[#text("all")]#text(" primitive residue classes ")#mi("{a\\ (q)}")#text(" to this modulus. This should be compared with the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("Generalised Riemann Hypothesis")]#text(" (GRH), which gives the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll x^{1/2} \\log^2 x", block: true)]]

#text("for ")#emph[#text("all")]#text(" ")#mi("{q \\leq x^{1/2}}")#text("; see Exercise 48 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(". Thus one can view the Bombieri-Vinogradov theorem as an assertion that the GRH holds (with a slightly weaker error term) “on average”, at least insofar as the impact of GRH on the prime number theorem in arithmetic progressions is concerned.")

#text("The initial arguments of Bombieri and Vinogradov were somewhat complicated, in particular involving the explicit formula for ")#mi("{L}")#text("-functions (Exercise 45 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("); the modern proof of the Bombieri-Vinogradov theorem avoids this and proceeds instead through Theorem ")#link(<tao-0cd856b24b9ffe6d3b3a>)[#text("16")]#text(" (or a close cousin thereof). Note that this theorem generalises the Siegel-Walfisz theorem (Exercise 64 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), which is equivalent to the special case of Theorem ")#link(<tao-0c69135deca1e682d588>)[#text("17")]#text(" when ")#mi("{Q = \\log^{O(1)} x}")#text(".")

#text("The obvious thing to try when proving Theorem ")#link(<tao-0c69135deca1e682d588>)[#text("17")]#text(" using Theorem ")#link(<tao-0cd856b24b9ffe6d3b3a>)[#text("16")]#text(" is to use one of the basic factorisations of such functions into Dirichlet convolutions, e.g. ")#mi("{\\Lambda = \\mu * L}")#text(", and then to decompose that convolution into pieces ")#mi("{\\alpha*\\beta}")#text(" of the form required in Theorem ")#link(<tao-0cd856b24b9ffe6d3b3a>)[#text("16")]#text("; we will refer to such convolutions as ")#emph[#text("Type II convolutions")]#text(", loosely following the terminology ")#link("http://www.ams.org/mathscinet-getitem?mr=598869")[#text("of Vaughan")]#text(". However, one runs into a problem coming from the components of the factors ")#mi("{\\mu, L}")#text(" supported at small numbers (of size ")#mi("{n = O(\\log^{O(1)} x)}")#text("), as the parameters ")#mi("{M,N}")#text(" associated to those parameters cannot obey the conditions ")#mi("{MN \\ll x}")#text(", ")#mi("{M, N \\geq \\log^B x}")#text(". Indeed, observe that any Type II convolution ")#mi("{\\alpha * \\beta}")#text(" will necessarily vanish at primes of size comparable to ")#mi("{x}")#text(", and so one cannot possibly represent functions such as ")#mi("{\\Lambda}")#text(" or ")#mi("{\\mu}")#text(" purely in terms of such Type II convolutions.")

#text("However, it turns out that we can still decompose functions such as ")#mi("{\\Lambda,\\mu}")#text(" into ")#emph[#text("two")]#text(" types of convolutions: not just the Type II convolutions considered above, but also a further class of ")#emph[#text("Type I convolutions")]#text(" ")#mi("{\\alpha * \\beta}")#text(", in which one of the factors, say ")#mi("{\\beta}")#text(", is very slowly varying (or “smooth”) and supported on a very long interval, e.g. ")#mi("{\\beta = 1_{[N,2N]}}")#text(" for some large ")#mi("{N}")#text("; with these sums ")#mi("{\\alpha}")#text(" is permitted to be concentrated arbitrarily close to ")#mi("{n=1}")#text(", and in particular the Type I convolution can be non-zero on primes comparable to ")#mi("{x}")#text(". It turns out that bounding the discrepancy of Type I convolutions is relatively easy, and leads to a proof of Theorem ")#link(<tao-0c69135deca1e682d588>)[#text("17")]#text(".")

#text("We turn to the details. There are a number of decompositions of ")#mi("{\\Lambda}")#text(" or ")#mi("{\\mu}")#text(" that one could use to accomplish the desired task. One popular choice of decomposition is the ")#link("http://en.wikipedia.org/wiki/Vaughan%27s_identity")[#text("Vaughan identity")]#text(", which may be compared with the decompositions appearing in the Dirichlet hyperbola method (see Section 3 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Vaughan identity)")]#text(" For any ")#mi("{U,V > 1}")#text(", one has ")#metadata(none) <tao-689f6a627384c7dcb2dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\Lambda = \\Lambda_{\\leq V} + \\mu_{\\leq U} * L - \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1 + \\mu_{>U} * \\Lambda_{>V} * 1")]]

#text("where ")#mi("{\\Lambda_{\\leq V}(n) :=\\Lambda(n) 1_{n \\leq V}}")#text(", ")#mi("{\\Lambda_{> V}(n) :=\\Lambda(n) 1_{n > V}}")#text(", ")#mi("{\\mu_{\\leq V}(n) :=\\mu(n) 1_{n \\leq U}}")#text(", and ")#mi("{\\mu_{> V}(n) :=\\mu(n) 1_{n > U}}")#text(".")
]

#text("In this decomposition, ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are typically two small powers of ")#mi("{x}")#text(" (e.g. ")#mi("{U=V=x^{1/5}}")#text("), although the exact choice of ")#mi("{U,V}")#text(" is often not of critical importance. The terms ")#mi("{\\mu_{\\leq U} * L}")#text(" and ")#mi("{\\mu_{\\leq U} * \\Lambda_{\\leq V} * 1}")#text(" are “Type I” convolutions, the terms ")#mi("{\\mu_{>U} * \\Lambda_{>V} * 1}")#text(" should be considered as “Type II” convolutions. The term ")#mi("{\\Lambda_{\\leq V}}")#text(" is a lower order error that is usually disposed of quite quickly. The Vaughan identity is already strong enough for many applications, but in some more advanced applications (particularly those in which one exploits the structure of triple or higher convolutions) it becomes convenient to use more sophisticated identities such as the ")#emph[#text("Heath-Brown identity")]#text(", which we will discuss in later notes.")

#emph[#text("Proof:")]#text(" Since ")#mi("{\\mu = \\mu_{\\leq U} + \\mu_{> U}}")#text(" and ")#mi("{\\Lambda = \\Lambda_{\\leq V} + \\Lambda_{>V}}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mu * \\Lambda = \\mu * \\Lambda_{\\leq V} + \\mu_{\\leq U} * \\Lambda - \\mu_{\\leq U} * \\Lambda_{\\leq V} + \\mu_{>U}* \\Lambda_{>V}.")]]

#text("Convolving both sides by ")#mi("{1}")#text(" and using the identities ")#mi("{\\mu*1 =\\delta}")#text(" and ")#mi("{\\Lambda*1=L}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Armed with this identity and Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" we may now finish off the proof of the Bombieri-Vinogradov theorem. We may assume that ")#mi("{x}")#text(" is large (depending on ")#mi("{A}")#text(") as the claim is trivial otherwise. We apply the Vaughan identity ")#link(<tao-689f6a627384c7dcb2dc>)[#text("(32)")]#text(" with ")#mi("{U=V=x^{1/5}}")#text(" (actually for our argument below, any choice of ")#mi("{U,V}")#text(" with ")#mi("{U,V \\geq \\log^B x}")#text(" and ")#mi("{UV \\leq x^{1/2} \\log^{-B} x}")#text(" would have sufficed). By the triangle inequality, it now suffices to establish ")#link(<tao-3eca4424d164d0e02850>)[#text("(31)")]#text(" with ")#mi("{\\Lambda}")#text(" replaced by ")#mi("{\\Lambda_{\\leq V}}")#text(", ")#mi("{\\mu_{\\leq U} * L}")#text(", ")#mi("{\\mu_{\\leq U} * \\Lambda_{\\leq V}*1}")#text(", and ")#mi("{\\mu_{>U}*\\Lambda_{>V}*1}")#text(".")

#text("The term ")#mi("{\\Lambda_{\\leq V}}")#text(" is easily disposed of: from the triangle inequality (and crudely bounding ")#mi("{\\Lambda_{\\leq V}}")#text(" by ")#mi("{\\log x 1_{\\leq V}}")#text(") we see that")

#align(center)[#tao-fit-display[#mitex("\\Delta( \\Lambda_{\\leq V} 1_{[1,x]}; a\\ (q)) \\ll \\frac{V}{\\phi(q)} \\log x")]]

#text("and the claim follows since ")#mi("{\\sum_{q \\leq Q} \\frac{1}{\\phi(q)} \\ll \\log x}")#text(" and ")#mi("{V = x^{1/5}}")#text(".")

#text("Next, we deal with the Type II convolution ")#mi("{\\mu_{>U} *\\Lambda_{>V}*1}")#text(". The presence of the ")#mi("{1_{[1,x]}}")#text(" cutoff is slightly annoying (it prevents one from directly applying Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text("), but we will deal with this by using the following finer-than-dyadic decomposition trick, originally ")#link("http://www.ams.org/mathscinet-getitem?mr=741055")[#text("due to Fouvry")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=719249")[#text("to Fouvry-Iwaniec")]#text(". We may replace ")#mi("{\\mu_{>U} * 1}")#text(" by ")#mi("{(\\mu_{>U}*1) 1_{(U,x]}}")#text(", since the portion of ")#mi("{\\mu_{>U}*1}")#text(" on ")#mi("{(x,\\infty)}")#text(" has no contribution. We may similarly replace ")#mi("{\\Lambda_{>V}}")#text(" by ")#mi("{\\Lambda 1_{(V,x]}}")#text(". Next, we set ")#mi("{\\lambda := 1 + \\log^{-A-100} x}")#text(", and decompose ")#mi("{(\\mu_{>U}*1) 1_{(U,x]}}")#text(" into ")#mi("{O(\\log^{A+101} x)}")#text(" components ")#mi("{\\alpha}")#text(", each of which is supported in an interval ")#mi("{[M, \\lambda M]}")#text(" and bounded in magnitude by ")#mi("{\\tau}")#text(" for some ")#mi("{M \\geq U}")#text(". We similarly decompose ")#mi("{\\Lambda 1_{(V,x]}}")#text(" into ")#mi("{O(\\log^{A+101} x)}")#text(" components ")#mi("{\\beta}")#text(" supported in an interval ")#mi("{[N, \\lambda N]}")#text(" and bounded in magnitude by ")#mi("{\\log x}")#text(" for some ")#mi("{N \\geq V}")#text(". Thus ")#mi("{(\\mu_{>U} * \\Lambda_{>V} * 1) 1_{[1,x]}}")#text(" can be decomposed into ")#mi("{O( \\log^{2A+202} x )}")#text(" terms of the form ")#mi("{(\\alpha*\\beta)1_{[1,x]}}")#text(" for various ")#mi("{\\alpha,\\beta}")#text(" that are components of ")#mi("{\\mu_{>U}*1}")#text(" and ")#mi("{\\Lambda_{>V}}")#text(" respectively.")

#text("If ")#mi("{MN > x}")#text(" then ")#mi("{(\\alpha*\\beta)1_{[1,x]}}")#text(" vanishes, so we may assume that ")#mi("{MN \\leq x}")#text(". By construction we also have ")#mi("{M,N \\geq x^{1/5}}")#text(", so in particular ")#mi("{M,N \\geq \\log^B x}")#text(" if ")#mi("{B}")#text(" depends only on ")#mi("{A}")#text(" (recall we are assuming ")#mi("{x}")#text(" to be large). If ")#mi("{MN < \\lambda^{-2} x}")#text(", then ")#mi("{(\\alpha*\\beta)1_{[1,x]} = \\alpha*\\beta}")#text(". The bounds ")#link(<tao-b84f6a9ecdd162400da2>)[#text("(23)")]#text(", ")#link(<tao-740d1e168c8b3cc259a1>)[#text("(24)")]#text(" are clear (bounding ")#mi("{\\mu_{>U}*1}")#text(" in magnitude by ")#mi("{\\tau}")#text("), and from the Siegel-Walfisz theorem we see that the ")#mi("{\\beta}")#text(" components obey the hypothesis ")#link(<tao-b9b56feef5a8871646ed>)[#text("(25)")]#text(". Thus by applying Proposition ")#link(<tao-e97e09ea1ab94998c5de>)[#text("2")]#text(" (with ")#mi("{A}")#text(" replaced by ")#mi("{3A+202}")#text(") we see that the total contribution of all the ")#mi("{\\alpha*\\beta}")#text(" terms with ")#mi("{MN < \\lambda^{-2} x}")#text(" is acceptable.")

#text("It remains to control the total contribution of the ")#mi("{\\alpha*\\beta}")#text(" terms with ")#mi("{\\lambda^{-2} x \\leq MN \\leq x}")#text(". Note that for each ")#mi("{\\alpha}")#text(" there are only ")#mi("{O(1)}")#text(" choices of ")#mi("{\\beta}")#text(" that are in this range, so there are only ")#mi("{O( \\log^{A+101} x )}")#text(" such terms ")#mi("{\\alpha*\\beta}")#text(" to deal with. We then crudely bound")

#tao-aligned(keep: true)[


#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\Delta( \\alpha*\\beta 1_{[1,x]}; a\\ (q) )  & \\ll \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\sum_{n = a\\ (q)} \\left|\\alpha\\right| * \\left|\\beta\\right|(n)", block: true)



#tao-math(" & \\ll (\\log x) \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\sum_{M \\leq m \\leq \\lambda M, N \\leq n \\leq \\lambda N: mn = a\\ (q)} \\tau(m).", block: true)
]

#text("Since ")#mi("{MN \\geq \\lambda^{-2} x}")#text(" and ")#mi("{q \\leq x^{1/2}}")#text(", one has either ")#mi("{M \\gg q}")#text(" or ")#mi("{N \\gg q}")#text(". If ")#mi("{N \\gg q}")#text(", we observe that for each fixed ")#mi("{m}")#text(" in the above sum, there are ")#mi("{O( \\frac{N}{q} \\log^{-A-100} x )}")#text(" choices of ")#mi("{n}")#text(" that contribute, so the double sum is ")#mi("{O( \\frac{MN}{q} \\log^{-2A-199} x ) = O( \\frac{x}{q} \\log^{-2A-199} x )}")#text(" (using the mean value bounds for ")#mi("{\\tau}")#text("). Thus we see that the total contribution of this case is at most")

#align(center)[#tao-fit-display[#mitex("\\ll \\log^{A+101} x \\times \\log x \\times \\log^{-2A-199} x \\times \\sum_{q \\leq Q} \\frac{x}{q}")]]

#text("which is acceptable.")

#text("Now we consider the case when ")#mi("{M \\gg q}")#text(". For fixed ")#mi("{n}")#text(" in the above sum, the sum in ")#mi("{m}")#text(" can be bounded by ")#mi("{\\log^{65} x \\times \\frac{M}{q} \\log^{-A-100} x}")#text(", thanks to Corollary ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("26")]#text(" below (taking, say, ")#mi("{c_1 =1/2}")#text(" and ")#mi("{c_2 = 5/6}")#text("). The total contribution of this sum is then")

#align(center)[#tao-fit-display[#mitex("\\ll \\log^{A+101} x \\times \\log x \\times \\log^{65} x \\times \\log^{-A-100} x \\times \\log^{-A-100} x \\times \\sum_{q \\leq Q} \\frac{x}{q}")]]

#text("which is also acceptable.")

#text("Now let us consider a Type I term ")#mi("{\\mu_{\\leq U}*L}")#text(". From the triangle inequality have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta((\\mu_{\\leq U} * L) 1_{[1,x]}; a\\ (q))\\right| \\leq \\sum_{d: (d,q)=1} \\left|\\mu_{\\leq U}(d)\\right| \\left|\\Delta( L 1_{[1,x/d]}; a/d\\ (q) )\\right|.", block: true)]]

#text("We exploit the monotonicity of ")#mi("{L}")#text(" via the following simple fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{f: [y,x] \\rightarrow {\\bf R}}")#text(" be a monotone function. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta( f 1_{[y,x]}; a\\ (q) )\\right| \\ll \\left|f(y)\\right| + \\left|f(x)\\right|", block: true)]]

#text("for all primitive residue classes ")#mi("{a\\ (q)}")#text(". (")#emph[#text("Hint:")]#text(" use Lemma 2 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory")[#text("Notes 1")]#text(" and a change of variables.)")
]

#text("Applying this exercise, we see that the contribution of this term to ")#link(<tao-3eca4424d164d0e02850>)[#text("(31)")]#text(" is ")#mi("{O( \\sum_{q \\leq Q} \\sum_d |\\mu_{\\leq U}(d)| \\log x ) = O( Q U \\log x )}")#text(", which is acceptable since ")#mi("{Q \\leq x^{1/2}}")#text(" and ")#mi("{U = x^{1/5}}")#text(".")

#text("A similar argument for the Type I term ")#mi("{\\mu_{\\leq U} * \\Lambda_{\\leq V} * 1}")#text(" term (with ")#mi("{\\mu_{\\leq U} * \\Lambda_{\\leq V}}")#text(" and ")#mi("{1}")#text(" replacing ")#mi("{\\mu_{\\leq U}}")#text(" and ")#mi("{L}")#text(") gives a contribution to ")#link(<tao-3eca4424d164d0e02850>)[#text("(31)")]#text(" of")

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\sum_{q \\leq Q} \\sum_d |\\mu_{\\leq U} * \\Lambda_{\\leq V}|(d)", block: true)



#tao-math(" & \\ll Q \\left(\\sum_d |\\mu_{\\leq U}|(d)\\right) \\left(\\sum_m \\Lambda_{\\leq V}(m)\\right)", block: true)



#tao-math(" & \\ll Q U V", block: true)
]

#text("which is also acceptable since ")#mi("{Q \\leq x^{1/2}}")#text(" and ")#mi("{U=V=x^{1/5}}")#text(". This concludes the proof of Theorem ")#link(<tao-0c69135deca1e682d588>)[#text("17")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Strengthen the Bombieri-Vinogradov theorem by showing that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\sup_{y \\leq x} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[1,y]}; a\\ (q))\\right| \\ll_{A} x \\log^{-A} x", block: true)]]

#text("for all ")#mi("{x \\geq 2}")#text(" and ")#mi("{A>0}")#text(", if ")#mi("{Q \\leq x^{1/2} \\log^{-B} x}")#text(" for some sufficiently large ")#mi("{B}")#text(" depending on ")#mi("{A}")#text(". (")#emph[#text("Hint:")]#text(" at present ")#mi("{y}")#text(" ranges over an uncountable number of values, but if one can round ")#mi("{y}")#text(" to the nearest multiple of (say) ")#mi("{x \\log^{-A-10} x}")#text(" then there are only ")#mi("{O(\\log^{A+10} x)}")#text(" values of ")#mi("{y}")#text(" in the supremum that need to be considered. Then use the original Bombieri-Vinogradov theorem as a black box.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" For any ")#mi("{U, V > 1}")#text(", establish the Vaughan-type identity")

#align(center)[#tao-fit-display[#mitex("\\mu = \\mu_{\\leq V} + \\mu_{\\leq U} - \\mu_{\\leq U} * \\mu_{\\leq V} * 1 + \\mu_{>U} * \\mu_{>V} * 1")]]

#text("and use this to show that the Bombieri-Vinogradov theorem continues to hold when ")#mi("{\\Lambda}")#text(" is replaced by ")#mi("{\\mu}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let us say that ")#mi("{0 < \\theta < 1}")#text(" is a ")#emph[#text("level of distribution")]#text(" for the von Mangoldt function ")#mi("{\\Lambda}")#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll_{A,\\theta} x \\log^{-A} x", block: true)]]

#text("whenever ")#mi("{A>0}")#text(" and ")#mi("{Q \\leq x^\\theta}")#text("; thus, for instance, the Bombieri-Vinogradov theorem implies that every ")#mi("{0 < \\theta < 1/2}")#text(" is a level of distribution for ")#mi("{\\Lambda}")#text(". Use the Cramér random model (see Section 1 of ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") to predict that every ")#mi("{0 < \\theta < 1}")#text(" is a level of distribution for ")#mi("{\\Lambda}")#text("; this claim is known as the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(", and would have a number of consequences in sieve theory. Unfortunately, no level of distribution above ")#mi("{1/2}")#text(" (or even at ")#mi("{1/2}")#text(") is currently known, however there are weaker versions of the Elliott-Halberstam conjecture known with levels above ")#mi("{1/2}")#text(" which do have some interesting number-theoretic consequences; we will return to this point in later notes. For now, we will just remark that ")#mi("{1/2}")#text(" appears to be the limit of what one can do by using the large sieve and Dirichlet character methods in this set of notes, and all the advances beyond ")#mi("{1/2}")#text(" have had to rely on other tools (such as exponential sum estimates), although the Cauchy-Schwarz inequality remains an indispensable tool in all of these results.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Strengthen the Bombieri-Vinogradov theorem by showing that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\tau(q)^C \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll_{A,C} x \\log^{-A} x", block: true)]]

#text("for all ")#mi("{x \\geq 2}")#text(", ")#mi("{C \\geq 1}")#text(", and ")#mi("{A>0}")#text(", if ")#mi("{Q \\leq x^{1/2} \\log^{-B} x}")#text(" for some sufficiently large ")#mi("{B}")#text(" depending on ")#mi("{A,C}")#text(". (")#emph[#text("Hint:")]#text(" use the Cauchy-Schwarz inequality and the trivial bound ")#tao-math("{\\left|\\Delta(\\Lambda 1_{[1,x]}; a\\ (q))\\right| \\ll \\frac{x}{q} \\log x}", block: false)#text(", together with elementary estimates on such sums as ")#mi("{\\sum_{q \\leq Q} \\frac{\\tau(q)^{2C}}{q}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Show that the Bombieri-Vinogradov theorem continues to hold if the von Mangoldt function ")#mi("{\\Lambda}")#text(" is replaced by the indicator function ")#mi("{{\\mathcal P}}")#text(" of the primes.")
]

#heading(level: 1)[#strong[#text(" — 4. Appendix: the divisor function in arithmetic progressions — ")]]

#text("We begin with a ")#link("http://www.ams.org/mathscinet-getitem?mr=998633")[#text("lemma of Landreau")]#text(" that controls the divisor function by a short divisor sum.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 25")]#text(" ")#metadata(none) <tao-90eae63487cae2df5b79>#text(" For any ")#mi("{\\theta > 0}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq 2^{2/\\theta} \\sum_{d|n: d \\leq n^\\theta} \\tau(d)^{2/\\theta}")]]

#text("for all natural numbers ")#mi("{n}")#text(".")
]

#emph[#text("Proof:")]#text(" We write ")#mi("{n = qm}")#text(", where ")#mi("{q}")#text(" is the product of all the prime factors of ")#mi("{n}")#text(" that are greater than or equal to ")#mi("{n^{\\theta/2}}")#text(", and ")#mi("{m}")#text(" is the product of all the prime factors of ")#mi("{n}")#text(" that are less than ")#mi("{n^{\\theta/2}}")#text(", counting multiplicity of course. By a greedy algorithm, we can repeatedly pull out factors of ")#mi("{m}")#text(" of size between ")#mi("{n^{\\theta/2}}")#text(" and ")#mi("{n^\\theta}")#text(" until the remaining portion of ")#mi("{m}")#text(" falls below ")#mi("{n^\\theta}")#text(", yielding a factorisation of the form ")#mi("{m = n_1 \\dots n_r}")#text(" where ")#mi("{n_1,\\dots,n_{r-1}}")#text(" lie between ")#mi("{n^{\\theta/2}}")#text(" and ")#mi("{n^\\theta}")#text(", ")#mi("{n_r}")#text(" is at most ")#mi("{n^\\theta}")#text(", and (if ")#mi("{r>1}")#text(") ")#mi("{n_{r-1} n_r}")#text(" is at least ")#mi("{n^\\theta}")#text(". The lower bounds on ")#mi("{n_1,\\dots,n_{r-2}}")#text(" and ")#mi("{n_{r-1} n_r}")#text(" imply that ")#mi("{r \\leq 2/\\theta}")#text(". By the trivial inequality ")#mi("{\\tau(ab) \\leq \\tau(a) \\tau(b)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq \\tau(q) \\tau(m) \\leq 2^{2/\\theta} \\tau(n_1) \\ldots \\tau(n_r)")]]

#text("and thus by the pigeonhole principle one has")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq 2^{2/\\theta} \\tau(n_j)^r")]]

#text("for some ")#mi("{j}")#text(". Since ")#mi("{n_j}")#text(" is a factor of ")#mi("{n}")#text(" that is at most ")#mi("{n^\\theta}")#text(", this gives the claim as long as ")#mi("{r \\leq 2/\\theta}")#text(". If ")#mi("{r > 2/\\theta}")#text(", then as each of the ")#mi("{n_1,\\dots,n_{r-1}}")#text(" are at least ")#mi("{n^{\\theta/2}}")#text(", we see that ")#mi("{r-1 \\leq 2/\\theta}")#text(" and ")#mi("{n_{r-1} n_r}")#text(" cannot exceed ")#mi("{n^\\theta}")#text(". If we now use the inequality")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\leq 2^{2/\\theta} \\tau(n_1) \\dots \\tau(n_{r-2}) \\tau(n_{r-1} n_r)")]]

#text("and repeat the pigeonholing argument, we again obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 26")]#text(" ")#metadata(none) <tao-0551ffc77d5f3a5d68f2>#text(" Let ")#mi("{0 < c_1 < c_2 < 1}")#text(", let ")#mi("{x \\geq 1}")#text(", let ")#mi("{x^{c_2} \\leq y \\leq x}")#text(", and let ")#mi("{a\\ (q)}")#text(" be a primitive residue class with ")#mi("{q \\leq x^{c_1}}")#text(". Then ")#metadata(none) <tao-ec4f2dbb3b140095550c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("\\sum_{x \\leq n\\leq x+y: n=a\\ (q)} \\tau(n) \\ll_{c_1,c_2} \\frac{y}{q} \\log^{2^{\\frac{2}{c_2-c_1}}+1} x.")]]
]

#text("One can lower the exponent of the logarithm here to ")#mi("{\\log x}")#text(" (consistent with the heuristic that the average value of ")#mi("{\\tau(n)}")#text(" for ")#mi("{n=O(x)}")#text(" is ")#mi("{O(\\log x)}")#text("), but this requires additional arguments; see for instance ")#link("https://terrytao.wordpress.com/2011/07/23/erdos-divisor-bound/")[#text("this previous blog post")]#text(". In contrast, the divisor bound ")#mi("{\\tau(n)=O(n^{o(1)})}")#text(" only gives an upper bound of ")#mi("{x^{o(1)} \\frac{y}{q}}")#text(" here.")

#emph[#text("Proof:")]#text(" We allow implied constants to depend on ")#mi("{c_1,c_2}")#text(". Set ")#mi("{\\theta := c_2-c_1}")#text(". Using Lemma ")#link(<tao-90eae63487cae2df5b79>)[#text("25")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\tau(n) \\ll \\sum_{d|n: d \\leq (x+y)^\\theta} \\tau(d)^{2/\\theta}")]]

#text("for all ")#mi("{n \\leq x+y}")#text(", and so the left-hand side of ")#link(<tao-ec4f2dbb3b140095550c>)[#text("(33)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{d \\leq (x+y)^\\theta} \\tau(d)^{2/\\theta} \\sum_{x \\leq n\\leq x+y: n=a\\ (q); d|n} 1.")]]

#text("The conditions ")#mi("{n=a\\ (q)}")#text(", ")#mi("{d|n}")#text(" constrain ")#mi("{n}")#text(" to either the empty set, or an arithmetic progression of modulus ")#mi("{qd \\leq x^{c_1} (x+y)^\\theta \\ll y}")#text(", so the inner sum is ")#mi("{O(\\frac{y}{qd})}")#text(". On the other hand, from Theorem 27 (or Exercise 29) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq (x+y)^\\theta} \\frac{\\tau(d)^{2/\\theta}}{d} \\ll \\log^{2^{2/\\theta} + 1} x,")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Under the same assumptions as in Corollary ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("26")]#text(", establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n\\leq x+y: n=a\\ (q)} \\tau^k(n) \\ll_{c_1,c_2,k} \\frac{y}{q} \\log^{O_{c_1,c_2,k}(1)} x")]]

#text("for any ")#mi("{k \\geq 1}")#text(".")
]

#heading(level: 1)[#text("Comments (25)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-449565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2015")])]

#text("These methodologies are too complicated to reach the problems for which they are devised. It detracts attention from the fundamental underlying structure of the integers and primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc8f2bd6833710d3bee6492e693a8b7f1b28779edcbdca970143958e84657103-554bd621dc1353cd5b93bee41252af741d19821f6624efaa50af80c4f70ee5a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sayan Chattopadhyay")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450119")[#strong[#text("Sayan Chattopadhyay")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2015")])]

#text("Sir can u please tell me that has the Riemann Hypothesis been proven by someone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("It seems that in order to apply proposition 2, the almost orthogonality condition on the functions ")#mi("g_j(n)")#text(" is quite restrictive (e.g. to be exponentials or characters – for which the non-diagonal contribution can be efficiently estimated.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("Yes, the ")#mi("g_j")#text(" in practice have to be somewhat structured, but this still gives quite a wide range of applicability since ")#mi("f")#text(" remains completely arbitrary. For instance, if one takes ")#mi("g_j(n) = n^{it_j}")#text(" then one will be able to bound the number of places where Dirichlet series (with arbitrary coefficients) are large, which, among other things, can be used to establish zero density estimates for the zeta function; similarly if one takes ")#mi("g_j(n) = \\chi_j(n) n^{it_j}")#text(" then one can obtain zero density estimates for Dirichlet L-functions. (This will be discussed in later notes.) There are also more sophisticated structured functions than exponential phases or Dirichlet characters that one can compute correlations of using more advanced methods; for instance, “trace weights” that arise from traces of Frobenius on a suitable sheaf can be controlled using Deligne’s work on the Riemann hypothesis for varieties and sheaves, which allows one to take ")#mi("g_j")#text(" to be an exponential sum such as a Kloosterman sum. (Automorphic forms and homogeneous dynamics are two other sources of non-trivial cancellation that can be exploited in some number-theoretic situations.)")

#text("One can also interpret Linnik’s dispersion method as a type of application of Proposition 2 in which the functions ")#mi("g_j")#text(" are not so completely structured that their correlations can be read off right away, but their correlations are at least simpler to estimate than the original correlations ")#mi("\\sum_n f(n) \\overline{g_j(n)}")#text(", and one may need to perform some further application of Cauchy-Schwarz or similar tools to get enough control on the former correlations to arrive at control of the latter. (The proof of the equidistribution estimates Zhang used to establish bounded gaps between primes is a good example of this sort of technique.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450192")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("I am slightly confused about the treatment of the Type II convolution in the proof of Bombieri-Vinogradov. From Vaughan’s identity we have ")#mi("\\mu_{>U}*\\Lambda_{>V}*1")#text(", but you wrote ")#mi("\\mu_{>U}*\\Lambda_{>V}")#text(". Is this just a typo, or is there an easy way to deal with the ")#mi("*1")#text("?")

#emph[#text("[Oops, this was indeed a typo; I’ve folded the 1 into the Mobius factor now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b4a12a0183347a10694bf644012cb085398f319008e1e244acb711eeda49e2-4ca59f8fc5fb76f8cd1d0b15f4314a937f4af7584256d47f25f8e093320cc297.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike_Miller")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450195")[#strong[#text("Mike_Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("Dear Professor Tao. Forgive me but this doesn’t make sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450216")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2015")])]

#text("Is it possible to increase the exponent ")#mi("1/2")#text(" in theorem 17 by taking the supremun in (31) over “typical ")#mi("a")#text("” or “almost every ")#mi("a")#text("” in some sense?")

#emph[#text("[Yes; see Theorem 13. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2108f61ac4b72751222a3ca4c0a3c94cdf7a7a4533ade03a483f2f0830a83f54-736b5d7e61507ab6e071a037b6570fba88784f8f0294a1aa67d272ccd9f87cbb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450476")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2015")])]

#text("I think there is an error in the equation after “We then crudely bound…” The second ")#mi("\\ll")#text(" seems to rely on the assumption that ")#tao-math("\\left|\\alpha\\right| \\leq 1", block: false)#text(". This is not true since (as is pointed out in the paragraph before the problematic equation) ")#mi("\\alpha = \\mu_{> U} * 1")#text(", so really ")#mi("\\alpha")#text(" is bounded in magnitude by ")#mi("\\tau")#text(". I haven’t checked carefully, but this probably just adds some extra logs to the final result, and these will be harmless.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-450545")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2015")])]

#text("I am struggling to follow your FAQ on the primes, but I notice you don’t say much about van Mangoldt until the very very end.")

#text("It seems fair to say Bombieri-Vinogradov is a step towards the Generalized Riemann hypothesis, giving very detailed information about the distribution of primes on arithmetic sequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-451885")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] for Dirichlet series. Our approach to these theorems will follow the same sort of methods used in Notes 3, in particular relying on the generalised Bessel inequality from those […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Some sieve theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-452121")[#strong[#text("254A, Notes 4: Some sieve theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("[…] von Mangoldt function ), then estimates such as the Bombieri-Vinogradov theorem, Theorem 17 from Notes 3, turn out to be particularly useful in this regard; in other contexts, the required […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-452286")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] use the generalised Bessel inequality (Proposition 2 from Notes 3) with to conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-453611")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] that in the proof of the Bombieri-Vinogradov theorem (see Notes 3), sums such as or were handled by using combinatorial identities such as Vaughan’s identity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-454003")[#strong[#text("254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("[…] is the multiplicative function with and for . From the Bombieri-Vinogradov theorem (Theorem 17 of Notes 3) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Roth | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-461983")[#strong[#text("Klaus Roth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("[…] the clean and general almost orthogonality principle that we have today (discussed for instance in these lecture notes of mine). The paper of Roth that had the most impact on my own personal work was his three-page paper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spacing of Quadratic Fractions | George Shakan")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-510340")[#strong[#text("Spacing of Quadratic Fractions | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")])]

#text("[…] is the Von Mongoldt function. They use Vaughan’s identity on to decompose (3) into Type I and Type II sums for the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-517646")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2019")])]

#text("Dear Prof. Tao,")

#text("in the proof of the large sieve inequality, you talk about “increasing N or decreasing Q”. That’s a little informal, and this kind of language continues to itch underneath my fingernails.")

#text("I should be most pleased if this could be changed.")

#text("By the way: Will these notes be transformed into a book? It would be much appreciated!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-517648")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2019")])]

#text("That is barely informal. If *that* bothers you so much, you shouldn’t be reading these notes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-528575")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] To get a feel for this inequality, suppose for sake of discussion that and all have unit variance and , but that the are pairwise uncorrelated. Then the right-hand side is equal to , and the left-hand side is the sum of squares of the correlations between and each of the . Any individual correlation is then still permitted to be as large as , but it is not possible for multiple correlations to be this large simultaneously. This is geometrically intuitive if one views the random variables as vectors in a Hilbert space (and correlation as a rough proxy for the angle between such vectors). This lemma also shares many commonalities with the large sieve inequality, discussed in this set of notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9 – second moment and entropy methods | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-528576")[#strong[#text("254A, Notes 9 – second moment and entropy methods | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2019")])]

#text("[…] To get a feel for this inequality, suppose for sake of discussion that and all have unit variance and , but that the are pairwise uncorrelated. Then the right-hand side is equal to , and the left-hand side is the sum of squares of the correlations between and each of the . Any individual correlation is then still permitted to be as large as , but it is not possible for multiple correlations to be this large simultaneously. This is geometrically intuitive if one views the random variables as vectors in a Hilbert space (and correlation as a rough proxy for the angle between such vectors). This lemma also shares many commonalities with the large sieve inequality, discussed in this set of notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c5130734f2f8bc09aac0f9115210c9a4cee17cf3554038f14a42ee0bffa61e1-07268bd7fc4bbd3654c812bdf00f3f715d9910b04fb3e44848c35f58a4633071.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noam")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-601823")[#strong[#text("Noam")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2020")])]

#text("I think that the bound on the LHS in the first inequality of exercise 4 is not optimal, if I’m not wrong using cauchy’s inequality term wise yields a better result (leaving only diagonal terms terms j=j’).")

#emph[#text("[This is incorrect. Note there is no ")#mi("j")#text(" summation in the first factor on the RHS. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-641735")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("Dear professor Tao,")#linebreak()#text(" I did try an attempt of proving Analytic large sieve inequality by myself and found out that it seems that the choice for ")#mi("\\nu (x) = 1")#text(" or a constant would satisfy all the conditions in the Generalized Bessel’s inequality though the attempt is only valid for ")#mi("N, M \\in \\mathbb{N}")#text(" by using ")#mi("\\frac{2}{\\pi} x \\leq \\sin x, x \\in [0, \\pi / 2 ]")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-641737")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("I also do have one more inquiry in the proof of BDH theorem, so the same as in displayed proof, we will start at:")#linebreak()#text(" ")#tao-math("\\displaystyle (\\log x)^2 \\sup_{s \\leq Q} \\sum_{1 \\leq r \\leq Q} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2", block: false)#linebreak()#text(" and indeed, one needs to show that:")

#tao-math("\\displaystyle \\sum_{1 \\leq r \\leq Q} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2", block: false)#linebreak()#text(" for all ")#mi("1 \\leq s \\leq x")#text(". Due to the following decomposition, the right handside is actually less than:")

#tao-math("\\displaystyle \\text{LHS} =  \\sum_{n\\geq  0} \\sum_{a_{n+1} \\leq r \\leq a_{n}} \\frac{1}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^* \\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2", block: false)

#tao-math("\\displaystyle \\leq \\sum_{n\\geq  0} \\frac{1}{a_{n+1}} \\sum_{a_{n+1} \\leq r \\leq a_n} \\frac{r}{\\phi(r)} \\sum_{\\tilde \\chi\\ (r)}^*\\left|\\sum_n f(n) 1_{(n,s)=1} \\overline{\\tilde \\chi(n)}\\right|^2", block: false)

#text("where ")#mi("a_k = 2^{-k} Q")#text(". Then since the function ")#mi("g(n) = f(n) 1_{(n,s) = 1}")#text(" is supported on ")#mi("[1,x]")#text(", and so by Large sieve inequality for characters, one obtains:")

#tao-math("\\displaystyle \\text{LHS} \\ll (x+Q^2) \\sum_{n\\geq  0} \\frac{1}{a_{n+1}}\\sum_n \\left| f(n) 1_{(n,s) = 1} \\right|^2 << x \\log^{-B_A }x \\cdot x \\log ^{O(1)} x", block: false)

#text("which holds for all ")#mi("1 \\leq s \\leq x= x^2 \\log^{-A} x")#text(" where ")#mi("B_A")#text(" depends on ")#mi("A")#text(". My apology if it's an obvious error but the attempt does not show the use of the Siegel-Walfisz property so there is something wrong obviously and also for the equations which are not shown perfectly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-641740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2022")])]

#text("There are simple counterexamples to the Bombieri-Davenport-Halberstam inequality when the Siegel-Walfisz property is omitted, for instance if one takes ")#mi("f")#text(" to be the indicator function of the congruence class ")#mi("1 \\text{ mod } 3")#text(" then the Siegel-Walfisz property is highly false at ")#mi("r=3")#text(", and the conclusion (18) also fails as can be seen by inspecting the ")#mi("q=3")#text(" contribution. I would recommend as an instructive exercise to trace through your proposed argument with this example (trying to calculate the left and right hand sides of every expression you are using to the best of your ability) to locate the problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Can Chat-GPT Do Math? | George Shakan")]], [#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/#comment-671355")[#strong[#text("Can Chat-GPT Do Math? | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("[…] give a more precise meaning the the last paragraph. One can see this first few paragraphs of this blog post of Terence Tao to see an explanation from one of the world’s leading mathematicians. Also, here is a math […]")
]
