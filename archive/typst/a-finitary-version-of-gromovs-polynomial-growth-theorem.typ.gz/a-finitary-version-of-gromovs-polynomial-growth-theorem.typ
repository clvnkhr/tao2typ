// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:55.375742+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A finitary version of Gromov’s polynomial growth theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A finitary version of Gromov’s polynomial growth theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#link("http://www.math.ucla.edu/people/pages/shalom.shtml")[#text("Yehuda Shalom")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0910.4148")[#text("A finitary version of Gromov’s polynomial growth theorem")]#text("“, to be submitted to ")#link("http://www.springerlink.com/content/101196/")[#text("Geom. Func. Anal.")]#text(". The purpose of this paper is to establish a quantitative version of ")#link("http://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s polynomial growth theorem")]#text(" which, among other things, is meaningful for finite groups. Here is a statement of Gromov’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Gromov’s theorem.")]#text(" Let ")#mi("G")#text(" be a group generated by a finite (symmetric) set ")#mi("S")#text(", and suppose that one has the polynomial growth condition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|B_S(R)\\right| \\leq R^d", block: true)]]

#text("for all sufficiently large ")#mi("R")#text(" and some fixed ")#mi("d")#text(", where ")#mi("B_S(R)")#text(" is the ball of radius ")#mi("R")#text(" generated by ")#mi("S")#text(" (i.e. the set of all words in ")#mi("S")#text(" of length at most ")#mi("d")#text(", evaluated in ")#mi("G")#text("). Then ")#mi("G")#text(" is ")#link("http://en.wikipedia.org/wiki/Virtually_nilpotent#Virtually_nilpotent")[#text("virtually nilpotent")]#text(", i.e. it has a finite index subgroup ")#mi("H")#text(" which is nilpotent of some finite step ")#mi("s")#text(".")
]

#text("As currently stated, Gromov’s theorem is qualitative rather than quantitative; it does not specify any relationship between the input data (the growth exponent ")#mi("d")#text(" and the range of scales ")#mi("R")#text(" for which one has (1)), and the output parameters (in particular, the index ")#tao-math("\\left|G/H\\right|", block: false)#text(" of the nilpotent subgroup ")#mi("H")#text(" of ")#mi("G")#text(", and the step ")#mi("s")#text(" of that subgroup). However, a compactness argument (sketched in ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this previous blog post")]#text(") shows that some such relationship must exist; indeed, if one has (1) for all ")#mi("R_0 \\leq R \\leq C( R_0, d )")#text(" for some sufficiently large ")#mi("C(R_0,d)")#text(", then one can ensure ")#mi("H")#text(" has index at most ")#mi("C^{\\prime}(R_0,d)")#text(" and step at most ")#mi("C^{\\prime\\prime}(R_0,d)")#text(" for some quantities ")#mi("C^{\\prime}(R_0,d)")#text(", ")#mi("C^{\\prime\\prime}(R_0,d)")#text("; thus Gromov’s theorem is inherently a “local” result which only requires one to multiply the generator set ")#mi("S")#text(" a finite number ")#mi("C(R_0,d)")#text(" of times before one sees the virtual nilpotency of the group. However, the compactness argument does not give an explicit value to the quantities ")#mi("C(R_0,d), C^{\\prime}(R_0,d), C^{\\prime\\prime}(R_0,d)")#text(", and the nature of Gromov’s proof (using, in particular, the deep Montgomery-Zippin-Yamabe theory on ")#link("http://en.wikipedia.org/wiki/Hilbert's_fifth_problem")[#text("Hilbert’s fifth problem")]#text(") does not easily allow such an explicit value to be extracted.")

#text("Another point is that the original formulation of Gromov’s theorem required the polynomial bound (1) at ")#emph[#text("all")]#text(" sufficiently large scales ")#mi("R")#text(". A later proof of this theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=751150")[#text("by van den Dries and Wilkie")]#text(" relaxed this hypothesis to requiring (1) just for infinitely many scales ")#mi("R")#text("; the later ")#link("http://arxiv.org/abs/0710.4593")[#text("proof by Kleiner")]#text(" (which ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("I blogged about here")]#text(") also has this relaxed hypothesis.")

#text("Our main result reduces the hypothesis (1) to a single large scale, and makes most of the qualitative dependencies in the theorem quantitative:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" If (1) holds for some ")#mi("R > \\exp(\\exp(C d^C))")#text(" for some sufficiently large absolute constant ")#mi("C")#text(", then ")#mi("G")#text(" contains a finite index subgroup ")#mi("H")#text(" which is nilpotent of step at most ")#mi("C^d")#text(".")
]

#text("The argument does in principle provide a bound on the index of ")#mi("H")#text(" in ")#mi("G")#text(", but it is very poor (of Ackermann type). If instead one is willing to relax “nilpotent” to “")#link("http://en.wikipedia.org/wiki/Polycyclic_group")[#text("polycyclic")]#text("“, the bounds on the index are somewhat better (of tower exponential type), though still far from ideal.")

#text("There is a related finitary analogue of Gromov’s theorem ")#link("http://arxiv.org/abs/0806.1745v2")[#text("by Makarychev and Lee")]#text(", which asserts that any finite group of uniformly polynomial growth has a subgroup with a large abelianisation. The quantitative bounds in that result are quite strong, but on the other hand the hypothesis is also strong (it requires upper and lower bounds of the form (1) at all scales) and the conclusion is a bit weaker than virtual nilpotency. The argument is based on a modification of Kleiner’s proof.")

#text("Our argument also proceeds by modifying Kleiner’s proof of Gromov’s theorem (a significant fraction of which was already quantitative), and carefully removing all of the steps which require one to take an asymptotic limit. To ease this task, we look for the most elementary arguments available for each step of the proof (thus consciously avoiding powerful tools such as the ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text("). A key technical issue is that because there is only a single scale ")#mi("R")#text(" for which one has polynomial growth, one has to work at scales significantly less than ")#mi("R")#text(" in order to have any chance of keeping control of the various groups and other objects being generated.")

#text("Below the fold, I discuss a stripped down version of Kleiner’s argument, and then how we convert it to a fully finitary argument.")

#heading(level: 1)[#metadata(none) <tao-f52e803b0a837e6a1a19>#text("— A modification of Kleiner’s argument —")]

#text("Here is a variant of Kleiner’s argument, suitable for finitisation. The starting point is to study the scalar Lipschitz harmonic functions on ")#mi("G")#text(", defined as those functions ")#mi("f: G \\to {\\Bbb R}")#text(" which obey the harmonicity condition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("f(g) = \\frac{1}{\\left|S\\right|} \\sum_{s \\in S} f(gs)", block: true)]]

#text("for all ")#mi("g \\in G")#text(", as well as the Lipschitz condition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sup_{g \\in G, s \\in S} \\left|f(gs) - f(g)\\right| < \\infty.", block: true)]]

#text("The space ")#mi("V")#text(" of Lipschitz harmonic functions is a vector space which contains the constant functions. If ")#mi("G")#text(" is finite, a simple application of the ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" shows that the constant functions are the only harmonic functions. However, for infinite ")#mi("G")#text(", non-constant harmonic functions exist:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" If ")#mi("G")#text(" is infinite and generated by ")#mi("S")#text(", then there exists a non-constant Lipschitz harmonic function.")
]

#strong[#text("Proof")]#text(" (informal sketch only). We give a proof which is more susceptible to finitisation than some of the more traditional proofs (e.g. the argument of Mok for the non-amenable case, and the argument of Lyons and Sullivan in the amenable case). What we will do is find some Lipschitz ")#emph[#text("almost-harmonic functions")]#text(" (in which (2) holds approximately rather than exactly) ")#mi("f")#text(" which are uniformly non-constant near the identity; taking a limit of such functions we will obtain the claim.")

#text("There are two cases: the “non-amenable” case in which the Laplacian has a spectral gap (i.e. a Poincaré inequality), and the amenable case in which no spectral gap exists. In the amenable case, one has non-trivial low-frequency functions, and one can use these to generate the desired non-constant Lipschitz harmonic function. For instance, if ")#mi("G = {\\Bbb Z}")#text(" with generators ")#mi("S = \\{-1,+1\\}")#text(", one can use the low-frequency function ")#mi("\\sin (2\\pi x / N )")#text(" to create the non-constant Lipschitz almost harmonic function ")#mi("N \\sin(2\\pi x/N)")#text(", which in the limit ")#mi("N \\to \\infty")#text(" yields the non-constant Lipschitz harmonic function ")#mi("2 \\pi x")#text(".")

#text("In the non-amenable case, one takes a long random walk on ")#mi("G")#text(" using ")#mi("S")#text(" as the steps (and using, say, an exponential distribution for the length of the walk). By construction, the probability distribution of this walk will have a small Laplacian; but by the spectral gap, it will have a large derivative. Manipulating this function a bit (using convolution and normalisation) one can again obtain a non-constant Lipschitz almost harmonic function. ")#mi("\\Box")

#text("The next result is the heart of Kleiner’s argument, and is based on an earlier argument by Colding and Minicozzi:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" If ")#mi("G")#text(" has polynomial growth, then ")#mi("V")#text(" is finite dimensional.")
]

#strong[#text("Proof. ")]#text("See my ")#link("https://terrytao.wordpress.com/2008/02/14/kleiners-proof-of-gromovs-theorem/")[#text("previous blog post")]#text("; the main tool is a certain local Poincaré inequality exploiting the polynomial growth hypothesis which asserts, roughly speaking, that harmonic functions on a large ball do not fluctuate much on smaller balls. The argument gives an explicit upper bound ")#mi("D")#text(" on the dimension of ")#mi("V")#text(" in terms of the growth order ")#mi("d")#text(". When one is assuming only polynomial growth at a single scale ")#mi("R")#text(", the argument yields that any ")#mi("D+1")#text(" Lipschitz harmonic (or almost harmonic) functions will have a “determinant” which is extremely small, where the determinant is taken with respect to a suitable quadratic form on ")#mi("V")#text(" (defined using a scale slightly smaller than ")#mi("R")#text("). ")#mi("\\Box")

#text("The group ")#mi("G")#text(" acts on ")#mi("V")#text(" by left translations, in a manner which preserves the Lipschitz norm, which becomes a genuine norm on the finite-dimensional space ")#mi("V")#text(" after quotienting out the constants. From Lemma 1 and Proposition 2, one thus obtains a non-trivial finite-dimensional isometric representation of ")#mi("G")#text(". (The precise formulation of “non-trivial” is “infinite image”, which comes from the basic fact that non-constant harmonic functions must have infinite image, thanks to the maximum principle.) Since ")#mi("G")#text(" has polynomial growth, the image of ")#mi("G")#text(" in the isometry group also has polynomial growth.")

#text("At this point one could apply the Tits alternative and conclude that the image of ")#mi("G")#text(" is virtually solvable, but we wish to avoid the use of this alternative. Instead, we use the basic observation (also used, for instance, in the proof of the Solovay-Kitaev theorem) that if two linear transformations are very close to the identity, then their commutator is even closer still to the identity. If we take a few transformations in the image of ")#mi("G")#text(" that are close to the identity and take a few commutators, we either end up at the identity, or we end up with a lot of transformations at widely differing distances from the identity. The latter case contradicts the polynomial growth hypothesis, so we can conclude that the transformations near the identity form a solvable group. Since the isometry group of a finite-dimensional space is compact, this implies that the image is virtually solvable. Since the image is also infinite, we conclude that the image has a finite index subgroup with an infinite abelianisation, and thus ")#mi("G")#text(" has a finite index subgroup with an infinite abelianisation.")

#text("An elementary splitting argument of Gromov then tells us that the kernel of that abelianisation has one order less growth (at least) than ")#mi("G")#text(" itself. Applying Gromov’s theorem as an induction hypothesis, this kernel is itself virtually nilpotent. After passing to a finite index subgroup to get rid of the “virtually” adjective, we conclude that G contains a finite index subgroup whose kernel of the abelianisation is nilpotent; in particular, G is virtually solvable.")

#text("To conclude, one uses an elementary result of Milnor and Wolf that establishes Gromov’s theorem in the solvable case. (Ultimately, things boil down to showing that the only linear transformations on the lattice ")#mi("{\\Bbb Z}^d")#text(" which exhibit polynomial growth are virtually unipotent; this in turn boils down to a classical result of Kronecker that the only algebraic integers whose Galois conjugates all lie on the unit circle are the roots of unity.) This completes the proof sketch of Gromov’s theorem.")

#text("It turns out that all of the above steps can be finitised. Instead of working with Lipschitz harmonic functions on infinite groups, one works instead with Lipschitz almost harmonic functions on very large groups. One is then not working with a finite dimensional vector space ")#mi("V")#text(", but instead with a class of functions which is closely approximated by a finite-dimensional space. Applying a Gram-Schmidt type procedure, we now get an approximate finite-dimensional representation of the group ")#mi("G")#text(" (in which the homomorphism property contains small errors), but the elementary Solovay-Kitaev type argument can handle this sort of noise, and one soon finds that the image of ")#mi("G")#text(" in this representation behaves as if it is virtually solvable; unpacking what this means, it implies that approximately Lipschitz harmonic functions on ")#mi("G")#text(" are approximately constant in some iterated commutator of a subgroup of ")#mi("G")#text(". (It is instructive to work this type of phenomenon out by hand for, say, the Heisenberg group.) One can then quotient out this direction to reduce the order of growth. The only remaining task is to finitise the Milnor-Wolf theory, but this is relatively straightforward (for instance, instead of Kronecker’s theorem, one uses lower bounds on Mahler measure, such as the bound due to Dobrowolski).")

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-41987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2009")])]

#text("Missing a paper tag? ")#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-42003")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2009")])]

#text("This is nice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultralimit analysis, and quantitative algebraic geometry « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-43427")[#strong[#text("Ultralimit analysis, and quantitative algebraic geometry « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2010")])]

#text("[…] gives no effective bound on . Obtaining such an effective bound is in fact rather non-trivial; see this paper of Yehuda Shalom and myself for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A proof of Gromov’s theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-43665")[#strong[#text("A proof of Gromov’s theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2010")])]

#text("[…] Yehuda Shalom and I established a quantitative version of Gromov’s theorem by making every component of Kleiner’s argument finitary. Technically, this provides a fully […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-49769")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] role in Gromov’s proof of his theorem on groups of polynomial growth (discussed previously on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed previously). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-70865")[#strong[#text("254A, Notes 0 – Hilbert’s fifth problem and related topics « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2011")])]

#text("[…] and Minicozzi on harmonic functions of polynomial growth. (This latter proof is discussed in these previous blog posts.) The proof we will give in these notes is more recent, based on an . We remark that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-104884")[#strong[#text("254A, Notes 9: Applications of the structural theory of approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2011")])]

#text("[…] set . (A previous result in this direction, which obtained (a) but not (b), was established by myself and Yehuda Shalom, by a rather different argument based on this paper of Kleiner. The original proof of Gromov of his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverse theorems for sets and measures of polynomial growth | What's new")]], [#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/#comment-457047")[#strong[#text("Inverse theorems for sets and measures of polynomial growth | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("[…] This theorem has been strengthened a number of times over the years. For instance, a few years ago, I proved with Shalom that the condition that grew polynomially in could be replaced by for a single , as long as was […]")
]
