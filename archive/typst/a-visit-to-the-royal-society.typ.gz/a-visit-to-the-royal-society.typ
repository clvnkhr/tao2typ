// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/
// Converted to Typst by tao2typ: "2026-10-14T15:16:26.009509+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A visit to the Royal Society", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A visit to the Royal Society")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/")[#text("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This week I was in London, attending the New Fellows Seminar at the ")#link("http://en.wikipedia.org/wiki/Royal_Society")[#text("Royal Society")]#text(". This was a fairly low-key event preceding the formal admissions ceremony; for instance, it is not publicised on ")#link("http://www.royalsoc.ac.uk/")[#text("their web site")]#text(". The format was very interesting: they had each of the ")#link("http://www.royalsoc.ac.uk/page.asp?tip=1&id=6616")[#text("new Fellows")]#text(" of the Society give a brief (15 minute) presentation of their work in quick succession, in a manner which would be accessible to a diverse audience in the physical and life sciences. The result was a wonderful two-day seminar on the state of the art in many areas of physics, chemistry, engineering, biology, medicine, and mathematics. For instance, I learnt")

#list(
[#text("How the ")#link("http://en.wikipedia.org/wiki/Solar_neutrino_problem")[#text("solar neutrino problem")]#text(" was resolved by the discovery that the neutrino had mass, which did not commute with ")#link("http://en.wikipedia.org/wiki/Flavor_%28particle_physics%29")[#text("flavour ")]#text("and hence caused ")#link("http://en.wikipedia.org/wiki/Neutrino_oscillation")[#text("neutrino oscillations")]#text(", which have since been detected experimentally;")],
[#text("Why modern aircraft (such as the ")#link("http://en.wikipedia.org/wiki/Dreamliner")[#text("Dreamliner")]#text(" and ")#link("http://en.wikipedia.org/wiki/Airbus_A380")[#text("A380")]#text(") are now assembled using (incredibly tough and waterproofed) adhesives instead of bolts or welds, and how adhesion has been enhanced by ")#link("http://en.wikipedia.org/wiki/Nanoparticle")[#text("nanoparticles")]#text(";")],
[#text("How the bacterium ")#link("http://en.wikipedia.org/wiki/Helicobacter_pylori")[#text("Helicobacter pylori")]#text(" was recently demonstrated (by ")#link("http://en.wikipedia.org/wiki/Robin_Warren")[#text("two")]#text(" ")#link("http://en.wikipedia.org/wiki/Barry_Marshall")[#text("Aussies")]#text(" :-) ) to be a major cause of ")#link("http://en.wikipedia.org/wiki/Peptic_ulcer")[#text("peptic ulcers")]#text(" (though the exact mechanism is not fully understood), but has also been proposed (somewhat paradoxically) to also have a preventative effect against ")#link("http://en.wikipedia.org/wiki/Esophageal_cancer")[#text("esophageal cancer")]#text(" (cf. the ")#link("http://en.wikipedia.org/wiki/Hygiene_hypothesis")[#text("hygiene hypothesis")]#text(");")],
[#text("How recent advances in ")#link("http://en.wikipedia.org/wiki/Machine_learning")[#text("machine learning")]#text(" and ")#link("http://en.wikipedia.org/wiki/Image_segmentation")[#text("image segmentation")]#text(" (including ")#link("http://en.wikipedia.org/wiki/Cut_(graph_theory)")[#text("graph cut")]#text(" methods!) now allow computers to identify and track many general classes of objects (e.g. people, cars, animals) simultaneously in real-world images and video, though not quite in real-time yet;")],
[#text("How ")#link("http://en.wikipedia.org/wiki/Large-scale_structure_of_the_cosmos")[#text("large-scale structure")]#text(" maps of the universe (such as the ")#link("http://en.wikipedia.org/wiki/2dF_Galaxy_Redshift_Survey")[#text("2dF Galaxy Redshift Survey")]#text(") combine with measurements of the ")#link("http://en.wikipedia.org/wiki/Cosmic_background_radiation")[#text("cosmic background radiation")]#text(" (e.g. from ")#link("http://en.wikipedia.org/wiki/WMAP")[#text("WMAP")]#text(") to demonstrate the existence of both ")#link("http://en.wikipedia.org/wiki/Dark_matter")[#text("dark matter")]#text(" and ")#link("http://en.wikipedia.org/wiki/Dark_energy")[#text("dark energy")]#text(" (they have different impacts on the evolution of the curvature of the universe and on the current distribution of visible matter);")],
[#text("… and 42 other topics like this. (One strongly recurrent theme in the life science talks was just how much recent ")#link("http://en.wikipedia.org/wiki/Genomics")[#text("genomic ")]#text("technologies, such as the ")#link("http://en.wikipedia.org/wiki/Genome_projects")[#text("genome projects")]#text(" of various key species, have accelerated (by ")#emph[#text("several")]#text(" orders of magnitude!) the ability to identify the genes, proteins, and mechanisms that underlie any given biological function or disease. To paraphrase one speaker, a modern genomics lab could now produce the equivalent of one 1970s PhD thesis in the subject every ")#emph[#text("minute")]#text(".)")]
)

#metadata(none) <tao-0b6d79e9cbe71ac23df4>

#text("I myself gave a presentation on “")#link("http://www.math.ucla.edu/%7Etao/preprints/Structure%20and%20Randomness%20in%20the%20prime%20numbers.ppt")[#text("structure and randomness in the prime numbers")]#text("” – basically, a highly abridged (and more colourful) version of my ")#link("http://www.calendar.ucla.edu/event_detail.cfm?MeetingID=123080")[#text("UCLA talk on the same subject")]#text(" (")#link("http://www.math.ucla.edu/~tao/preprints/Slides/primes.pdf")[#text("slides")]#text(" and ")#link("http://164.67.141.39:8080/ramgen/specialevents/math/tao/tao-20070117.smil")[#text("video")]#text(" of which are available here). It’s the second time I’ve used Powerpoint (")#link("https://terrytao.wordpress.com/2007/05/31/the-cosmic-distance-ladder/")[#text("this is the first")]#text("); I myself am most comfortable with good old-fashioned chalk and blackboard, but now that I see how the other disciplines (in particular the life sciences) use computer slides, I have to concede that there are some useful features of this medium, particularly for very short, high-level, general-audience presentations.")

#text("Now that I have participated in my first interdisciplinary conference, I can strongly recommend the experience. Unfortunately, such conferences seem to be extremely rare; the only other examples I know of are the annual conferences for ")#link("http://www.packard.org/home.aspx")[#text("Packard Foundation")]#text(" fellows (which I now greatly regret not attending while I was supported by them). The Royal Society is talking about webcasting the New Fellows Seminar for 2008, though.")

#heading(level: 1)[#text("Comments (17)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 558")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4251")[#strong[#text("558")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2007")])]

#text("Hey Terry,")

#text("Do you have the video of your UCLA in a different format like .avi or .mov?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6dbb388caee534c33f914b537280eb600bbe6bf21d396ce07e221e1b561073b-05efbf875afb17d0655237cf1a1b3f84cfccf6f11ed708175023bd13d505cce8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4289")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2007")])]

#text("There’s the ")#link("http://www.aaas.org/meetings/")[#text("annual meeting")]#text(" of the American Association for the Advancement of Science. Not too much math at the last one, apparently, but there was a session on Prime Numbers: New Developments on Ancient Problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4300")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2007")])]

#text("The slides of your otherwise delicious UCLA talk misspell “reductio ad absurdum”.")

#text("Feel free to delete this comment, since it makes me look like a nitpicker! :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2007")])]

#text("Nitpick duly noted and corrected. :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marc")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4386")[#strong[#text("Marc")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2007")])]

#text("Dear Terry, it is very nice to see you enjoy the wider world of Science (some other mathematicians can be rather narrowly-focussed). Have you ever considered solving a specific scientific yet non-mathematical problem (e.g. in biology), either in your youth or at a later stage of your career (perhaps with well-chosen experimentalists coauthors)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/342cf862c3e360caa66e776c60eebacc03f35cce5f309a7a5bd43b04e2d54b8c-ecddf47f98989304003103b3c2d4608e529c40d58747c5d76b267559309a9191.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raj")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4402")[#strong[#text("Raj")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2007")])]

#text("Congrats on becoming one of the new Fellows in the very prestigious society..cheers")#linebreak()#text(" raj")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96d72c9b9688c0f00dc7ae1515894c7522740ba3a14127559a8dad62b439d11d-aa588601f7db21928757eb0a2ea65694f2a27a2ebab80985d8bb9d62931325bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dod")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4504")[#strong[#text("dod")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("On the same day, I transferred from MPhil to PhD :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2007")])]

#text("Dear Marc,")

#text("Perhaps when I encounter the right collaborator with the right problem, I may consider doing something outside of mathematics; but at present I do not have any such plans. (The record of mathematicians, even accomplished ones, going to work on other fields seems to be somewhat mixed; in many cases the mathematical ")#emph[#text("Weltanschauung")]#text(" [lit. “world-view”] is not quite the right one for the problem at hand.) Nevertheless, I still like to keep informed of developments in other fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4625")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2007")])]

#text("Dear Terry,")

#text("I just saw your video of your talk. You mention that there is no pattern in the error term (i.e. random noise). Do you find that the prime numbers behave like any stochastic system? Can you use information theory and signal processing/generation to predict sequences of primes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2007")])]

#text("Dear Tom,")

#text("There are certainly some random models of the primes which do appear to be highly accurate for computing asymptotic statistics, though of course they do not generate the set of primes exactly. For instance, Cramer’s random model for the primes gives predictions for statistics of various prime patterns (e.g. twin primes) which agrees very well with numerics. On the other hand, for very rarely occurring patterns (such as very large prime gaps), it appears that Cramers’ model has to be tweaked slightly in order to give the right results; there are some papers by Granville and Soundararajan (and perhaps others) investigating this.")

#text("Also, and perhaps more interestingly, the “spectrum” of the prime number counting function is given by the zeroes of the Riemann zeta function, and the distribution of these were observed to match rather closely (both numerically by the work of Odlyzko, and via certain moment computations by Montgomery and others) with the distribution of the “spectrum” (eigenvalues) of large random (or more precisely, GUE) matrices. It is still not completely clear what this signifies; the most obvious guess is that the zeroes of the zeta function are somehow the spectrum of some interesting pseudorandom operator, but the GUE spectral patterns also arise in many other contexts than random matrices, so the connection may be rather different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darwin’s finches and introgressive hybridisation « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4703")[#strong[#text("Darwin’s finches and introgressive hybridisation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("[…] July 19th, 2007 in non-technical, talk Last week, as mentioned previously, I attended a very inspiring interdisciplinary meeting at the Royal Society. It would be impossible […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/738ab60216ef7fa7236252e2fc8735d2d932ef86f401304ced2003146f8cbb3b-19c8b885b0b640855e01a645756ffc73d41450328a2b0a3a6acf76132a9f424a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zerocold")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4740")[#strong[#text("zerocold")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2007")])]

#text("“How recent advances in machine learning and image segmentation (including graph cut methods!) now allow computers to identify and track many general classes of objects (e.g. people, cars, animals) simultaneously in real-world images and video, though not quite in real-time yet;”")

#text("Could you be more specific by linking to the professor or to some papers link?")

#text("thanks")#linebreak()#text(" zero")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4753")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2007")])]

#text("Dear Zerocold,")

#text("The talk was by Andrew Zisserman,")

#link("http://www.robots.ox.ac.uk/~az/")[#text("http://www.robots.ox.ac.uk/~az/")]

#text("I can’t find the precise slides he used there (which, among other things, prominently featured a clip from “Run Lola Run”), but the following slides discuss essentially the same material (i.e. motion segmentation of video via machine learning):")

#link("http://www.robots.ox.ac.uk/~vgg/presentations/moseg_pres.zip")[#text("http://www.robots.ox.ac.uk/~vgg/presentations/moseg_pres.zip")]

#text("(this file has to be unzipped and then run on Windows to view the slides.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4797")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2007")])]

#text("“Now that I have participated in my first interdisciplinary conference, I can strongly recommend the experience. Unfortunately, such conferences seem to be extremely rare…”")

#text("Would you like a formal invitation from me, as a member of the Executive Committee? Or from the Chair himself (Dr. Yaneer Bar-Yam) for the very interdisciplinary:")

#link("http://www.necsi.org/events/iccs7/")[#text("7th International Conference on Complex Systems")]

#text("Marriott Boston Quincy, Boston, MA, USA")#linebreak()#text(" October 28-November 2, 2007")

#text("* Networks & Structural Themes")#linebreak()#text(" * Systems biology")#linebreak()#text(" * Socio-economic systems")#linebreak()#text(" * Engineering systems")#linebreak()#text(" * Evolution and Ecology / Population change")#linebreak()#text(" * Nonlinear dynamics and Pattern formation")#linebreak()#text(" * Physical systems, Quantum and Classical")#linebreak()#text(" * Learning / Neural, Psychological and Psycho-Social Systems")#linebreak()#text(" * Concepts, Formalisms, Methods and Tools")#linebreak()#text(" * Analysis and Expression in the Arts and Humanities")

#text("Special Conference Sessions:")

#text("* Networks")#linebreak()#text(" * Systems Biology")#linebreak()#text(" * Modelinlg Social Systems")#linebreak()#text(" * Complex Systems Engineering")#linebreak()#text(" * Evolution and Ecology")#linebreak()#text(" * Patterns and Pattern Formation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harry's")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-4920")[#strong[#text("Harry's")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2007")])]

#text("Hello,Terence.I’m a chinese people.I want to be your students and your friend.I believe myself can do this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6338e502c24a8c4e3f5361546834629e8d19ee151210975ccaa49678746d213f-c266945096abef53ec896a82cb9c579761c0b5db1737948bc373e1e4340b8f48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DR.KATHRINE MARTIGNONI")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-8466")[#strong[#text("DR.KATHRINE MARTIGNONI")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2007")])]

#text("I HAVE ONLY 3 SIMPLE QUESTIONS FOR YOU:")#linebreak()#text(" -WHAT DO YOU THINK OF THE SUPPOSED DEMONSTRATION OF THE RIEMANN HYPOTHESIS PRESENTD IN 2004 BY PROF. LOUIS DE BRANGES?")#linebreak()#text(" -DO YOU KNOW IF ANYBODY IS VERIFYING THIS SUPPOSED DEMONSTRATION OF DE BRANGES ON THE RH?")#linebreak()#text(" -HAVE YOU READ THIS SUPPOSED DEMONSTRATION?")#linebreak()#text(" BEST,")#linebreak()#text(" DR.KATHRINE MARTIGNONI-ZURICH-")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Structure and randomness in the prime numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/#comment-25643")[#strong[#text("Structure and randomness in the prime numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("[…] and randomness in the prime numbers“. My slides here are a merge between my slides for a Royal Society meeting and the slides I gave for the UCLA Science Colloquium; now that I figured out to use Powerpoint a […]")
]
