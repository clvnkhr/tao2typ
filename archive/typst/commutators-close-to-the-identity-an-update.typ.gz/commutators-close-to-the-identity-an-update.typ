// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/
// Converted to Typst by tao2typ: "2026-10-14T15:20:06.280749+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Commutators close to the identity – an update", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Commutators close to the identity – an update")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 May 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/")[#text("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1805.11131")[#text("Commutators close to the identity")]#text("“, submitted to the ")#link("https://www.theta.ro/jot.html")[#text("Journal of Operator Theory")]#text(". This paper resulted from some progress I made on the problem discussed in this ")#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/")[#text("previous post")]#text(". Recall in that post the following result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=685464")[#text("of Popa")]#text(": if ")#mi("{D,X \\in B(H)}")#text(" are bounded operators on a Hilbert space ")#mi("{H}")#text(" whose commutator ")#mi("{[D,X] := DX-XD}")#text(" is close to the identity in the sense that ")#metadata(none) <tao-7f90578ab425b170fe6d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| [D,X] - I \\right\\|_{op} \\leq \\varepsilon", block: true)]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(", then one has the lower bound ")#metadata(none) <tao-68d8aca2273362336704>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| X \\right\\|_{op} \\left\\|D \\right\\|_{op} \\geq \\frac{1}{2} \\log \\frac{1}{\\varepsilon}.", block: true)]]

#text("In the other direction, for any ")#mi("{0 < \\varepsilon < 1}")#text(", there are examples of operators ")#mi("{D,X \\in B(H)}")#text(" obeying ")#link(<tao-7f90578ab425b170fe6d>)[#text("(1)")]#text(" such that ")#metadata(none) <tao-8cf2283ad6ef0a326605>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| X \\right\\|_{op} \\left\\|D \\right\\|_{op} \\ll \\varepsilon^{-2}.", block: true)]]

#text("In this paper we improve the upper bound to come closer to the lower bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" For any ")#mi("{0 < \\varepsilon < 1/2}")#text(", and any infinite-dimensional ")#mi("{H}")#text(", there exist operators ")#mi("{D,X \\in B(H)}")#text(" obeying ")#link(<tao-7f90578ab425b170fe6d>)[#text("(1)")]#text(" such that ")#metadata(none) <tao-ad72630b5c0a2223e7a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| X \\right\\|_{op} \\left\\|D \\right\\|_{op} \\ll \\log^{16} \\frac{1}{\\varepsilon}.", block: true)]]
]

#text("One can probably improve the exponent ")#mi("{16}")#text(" somewhat by a modification of the methods, though it does not seem likely that one can lower it all the way to ")#mi("{1}")#text(" without a substantially new idea. Nevertheless I believe it plausible that the lower bound ")#link(<tao-68d8aca2273362336704>)[#text("(2)")]#text(" is close to optimal.")

#text("We now sketch the methods of proof. The construction giving ")#link(<tao-8cf2283ad6ef0a326605>)[#text("(3)")]#text(" proceeded by first identifying ")#mi("{B(H)}")#text(" with the algebra ")#mi("{M_2(B(H))}")#text(" of ")#mi("{2 \\times 2}")#text(" matrices that have entries in ")#mi("{B(H)}")#text(". It is then possible to find two matrices ")#mi("{D, X \\in M_2(B(H))}")#text(" whose commutator takes the form")

#align(center)[#tao-fit-display[#mitex("[D,X] = \\begin{pmatrix} I & u \\\\ 0 & I \\end{pmatrix}")]]

#text("for some bounded operator ")#mi("{u \\in B(H)}")#text(" (for instance one can take ")#mi("{u}")#text(" to be an isometry). If one then conjugates ")#mi("{D, X}")#text(" by the diagonal operator ")#mi("{\\mathrm{diag}(\\varepsilon,1)}")#text(", one can eusure that ")#link(<tao-7f90578ab425b170fe6d>)[#text("(1)")]#text(" and ")#link(<tao-8cf2283ad6ef0a326605>)[#text("(3)")]#text(" both hold.")

#text("It is natural to adapt this strategy to ")#mi("{n \\times n}")#text(" matrices ")#mi("{D,X \\in M_n(B(H))}")#text(" rather than ")#mi("{2 \\times 2}")#text(" matrices, where ")#mi("{n}")#text(" is a parameter at one’s disposal. If one can find matrices ")#mi("{D,X \\in M_n(B(H))}")#text(" that are almost upper triangular (in that only the entries on or above the lower diagonal are non-zero), whose commutator ")#mi("{[D,X]}")#text(" only differs from the identity in the top right corner, thus")

#align(center)[#tao-fit-display[#mitex("[D, X] = \\begin{pmatrix} I & 0 & 0 & \\dots & 0 & S \\\\ 0 & I & 0 & \\dots & 0 & 0 \\\\ 0 & 0 & I & \\dots & 0 & 0 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots & \\vdots \\\\ 0 & 0 & 0 & \\dots & I & 0 \\\\ 0 & 0 & 0 & \\dots & 0 & I \\end{pmatrix}.")]]

#text("for some ")#mi("{S}")#text(", then by conjugating by a diagonal matrix such as ")#mi("{\\mathrm{diag}( \\mu^{n-1}, \\mu^{n-2}, \\dots, 1)}")#text(" for some ")#mi("{\\mu}")#text(" and optimising in ")#mi("{\\mu}")#text(", one can improve the bound ")#mi("{\\varepsilon^{-2}}")#text(" in ")#link(<tao-8cf2283ad6ef0a326605>)[#text("(3)")]#text(" to ")#mi("{O_n( \\varepsilon^{-\\frac{2}{n-1}} )}")#text("; if the bounds in the implied constant in the ")#mi("{O_n(1)}")#text(" are polynomial in ")#mi("{n}")#text(", one can then optimise in ")#mi("{n}")#text(" to obtain a bound of the form ")#link(<tao-ad72630b5c0a2223e7a3>)[#text("(4)")]#text(" (perhaps with the exponent ")#mi("{16}")#text(" replaced by a different constant).")

#text("The task is then to find almost upper triangular matrices ")#mi("{D, X}")#text(" whose commutator takes the required form. The lower diagonals of ")#mi("{D,X}")#text(" must then commute; it took me a while to realise then that one could (usually) conjugate one of the matrices, say ")#mi("{X}")#text(" by a suitable diagonal matrix, so that the lower diagonal consisted entirely of the identity operator, which would make the other lower diagonal consist of a single operator, say ")#mi("{u}")#text(". After a lot of further lengthy experimentation, I eventually realised that one could conjugate ")#mi("{X}")#text(" further by unipotent upper triangular matrices so that all remaining entries other than those on the far right column vanished. Thus, without too much loss of generality, one can assume that ")#mi("{X}")#text(" takes the normal form")

#tao-aligned(keep: true)[


#tao-math("X  & := \\begin{pmatrix} 0 & 0 & 0 & \\dots & 0 & b_1 \\\\ I & 0 & 0 & \\dots & 0 & b_2 \\\\ 0 & I & 0 & \\dots & 0 & b_3 \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots & \\vdots \\\\ 0 & 0 & 0 & \\dots & 0 & b_{n-1} \\\\ 0 & 0 & 0 & \\dots & I & b_n \\end{pmatrix}.", block: true)



#tao-math("D  & := \\begin{pmatrix} v & I & 0 & \\dots & 0 & b_1 u \\\\ u & v & 2 I & \\dots & 0 & b_2 u \\\\ 0 & u & v & \\dots & 0 & b_3 u \\\\ \\vdots & \\vdots & \\vdots & \\ddots & \\vdots & \\vdots \\\\ 0 & 0 & 0 & \\dots & v & (n-1) I + b_{n-1} u \\\\ 0 & 0 & 0 & \\dots & u & v + b_n u \\end{pmatrix}", block: true)
]

#text("for some ")#mi("{u,v \\in B(H)}")#text(", solving the system of equations ")#metadata(none) <tao-6e2dd21b0b011f100426>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("[v, b_i] + [u, b_{i-1}] + i b_{i+1} + b_i [u, b_n] = 0")]]

#text("for ")#mi("{i=2,\\dots,n-1}")#text(", and also ")#metadata(none) <tao-ecf42f7b44602efd28e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("[v, b_n] + [u, b_{n-1}] + b_n [u, b_n] = n \\cdot 1_{B(H)}.")]]

#text("It turns out to be possible to solve this system of equations by a contraction mapping argument if one takes ")#mi("{u,v}")#text(" to be a “Hilbert’s hotel” pair of isometries as in the ")#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/")[#text("previous post")]#text(", though the contraction is very slight, leading to polynomial losses in ")#mi("{n}")#text(" in the implied constant.")

#text("There is a further question raised in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=685464")[#text("Popa’s paper")]#text(" which I was unable to resolve. As a special case of one of the main theorems (Theorem 2.1) of that paper, the following result was shown: if ")#mi("{A \\in B(H)}")#text(" obeys the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A \\right\\| = O(1)", block: true)]]

#text("and ")#metadata(none) <tao-5e85370e555e95d27df6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| A \\right\\| = O( \\mathrm{dist}( A, {\\bf C} + K(H) )^{2/3} )", block: true)]]

#text("(where ")#mi("{{\\bf C} + K(H)}")#text(" denotes the space of all operators of the form ")#mi("{\\lambda I + T}")#text(" with ")#mi("{\\lambda \\in {\\bf C}}")#text(" and ")#mi("{T}")#text(" compact), then there exist operators ")#mi("{D,X \\in B(H)}")#text(" with ")#tao-math("{\\left\\|D\\right\\|, \\left\\|X\\right\\| = O(1)}", block: false)#text(" such that ")#mi("{A = [D,X]}")#text(". (In fact, Popa’s result covers a more general situation in which one is working in a properly infinite ")#mi("{W^*}")#text(" algebra with non-trivial centre.) We sketch a proof of this result as follows. Suppose that ")#mi("{\\mathrm{dist}(A, {\\bf C} + K(H)) = \\varepsilon}")#text(" and ")#tao-math("{\\left\\|A\\right\\| = O( \\varepsilon^{2/3})}", block: false)#text(" for some ")#mi("{0 < \\varepsilon \\ll 1}")#text(". A standard greedy algorithm argument (see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=178354")[#text("this paper of Brown and Pearcy")]#text(") allows one to find orthonormal vectors ")#mi("{e_n, f_n, g_n}")#text(" for ")#mi("{n=1,2,\\dots}")#text(" such that for each ")#mi("{n}")#text(", one has ")#mi("{A e_n = \\varepsilon_n f_n + v_n}")#text(" for some ")#mi("{\\varepsilon_n}")#text(" comparable to ")#mi("{\\varepsilon}")#text(", and some ")#mi("{v_n}")#text(" orthogonal to all of the ")#mi("{e_n,f_n,g_n}")#text(". After some conjugation (and a suitable identification of ")#mi("{B(H)}")#text(" with ")#mi("{M_2(B(H))}")#text(", one can thus place ")#mi("{A}")#text(" in a normal form")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} \\varepsilon^{2/3} x & \\varepsilon v^* \\\\ \\varepsilon^{2/3} y & \\varepsilon^{2/3} z \\end{pmatrix}")]]

#text("where ")#mi("{v \\in B(H)}")#text(" is a isometry with infinite deficiency, and ")#mi("{x,y,z \\in B(H)}")#text(" have norm ")#mi("{O(1)}")#text(". Setting ")#mi("{\\varepsilon^{\\prime} := \\varepsilon^{1/3}}")#text(", it then suffices to solve the commutator equation")

#align(center)[#tao-fit-display[#mitex("[D,X] = \\begin{pmatrix} x & \\varepsilon^{\\prime} v^* \\\\ y & z \\end{pmatrix}")]]

#text("with ")#tao-math("{\\left\\|D\\right\\|_{op} \\left\\|X\\right\\|_{op} \\ll (\\varepsilon^{\\prime})^{-2}}", block: false)#text("; note the similarity with ")#link(<tao-8cf2283ad6ef0a326605>)[#text("(3)")]#text(".")

#text("By the usual Hilbert’s hotel construction, one can complement ")#mi("{v}")#text(" with another isometry ")#mi("{u}")#text(" obeying the “Hilbert’s hotel” identity")

#align(center)[#tao-fit-display[#mitex("uu^* + vv^* = I")]]

#text("and also ")#mi("{u^* u = v^* v = I}")#text(", ")#mi("{u^* v = v^* u = 0}")#text(". Proceeding as in the ")#link("https://terrytao.wordpress.com/2018/04/11/commutators-close-to-the-identity/")[#text("previous post")]#text(", we can try the ansatz")

#align(center)[#tao-fit-display[#mitex("D = \\begin{pmatrix} \\frac{1}{2} u^* & 0 \\\\ a & \\frac{1}{2} u^* - v^* \\end{pmatrix}, X = \\begin{pmatrix} b & \\varepsilon^{\\prime} I \\\\ c & d \\end{pmatrix}")]]

#text("for some operators ")#mi("{a,b,c,d \\in B(H)}")#text(", leading to the system of equations")

#tao-aligned(keep: true)[


#tao-math("[\\frac{1}{2} u^*, b] + [\\frac{1}{2} u^* - v^*, c]  & = x+z", block: true)



#tao-math("\\varepsilon^{\\prime} a  & = [\\frac{1}{2} u^*, b] - x", block: true)



#tao-math("\\frac{1}{2} u^* c + c (\\frac{1}{2} u^* - v^*) + ab-da  & = y.", block: true)
]

#text("Using the first equation to solve for ")#mi("{b,c}")#text(", the second to then solve for ")#mi("{a}")#text(", and the third to then solve for ")#mi("{c}")#text(", one can obtain matrices ")#mi("{D,X}")#text(" with the required properties.")

#text("Thus far, my attempts to extend this construction to larger matrices with good bounds on ")#mi("{D,X}")#text(" have been unsuccessful. A model problem would be to express")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} I & 0 & \\varepsilon v^* \\\\ 0 & I & 0 \\\\ 0 & 0 & I \\end{pmatrix}")]]

#text("as a commutator ")#mi("{[D,X]}")#text(" with ")#tao-math("{\\left\\|D\\right\\| \\left\\|X\\right\\|}", block: false)#text(" significantly smaller than ")#mi("{O(\\varepsilon^{-2})}")#text(". The construction in my paper achieves something like this, but with ")#mi("{v^*}")#text(" replaced by a more complicated operator. One would also need variants of this result in which one is allowed to perturb the above operator by an arbitrary finite rank operator of bounded operator norm.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-500430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("Can the implied constant in (4) be made explicit ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-500456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("Yes, it is something like ")#mi("10^4")#text(" or so if one works through all the computations, though I did not attempt to optimise it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3325237e7c2a080b1e837defd134b8cb3544d63ee964d6a0b7414592ebfab61-603da00de67d18bdf9bcb07908cb7a5934e6e469c62af98cbb783ee909932cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Tobler")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-500462")[#strong[#text("Peter Tobler")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2018")])]

#text("“Nevertheless I believe it plausible that the lower bound (2) is close to” seems like an unfinished sentence. Just wondering what should follow ‘to’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c509546c5312b8388119b71c770ef79c3261f152d5b36591b3c44d18beaac5-712ea3cee1a4e9a38803559a57f7a5d0d72d633adb33f667edf30419fb2c3a3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andriy")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-500794")[#strong[#text("Andriy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2018")])]

#text("1). “exponent {16} replaced by a different constant”.")#linebreak()#text(" I offer to replace it by “17”.")

#text("2). Tao, if you can’t find the solution of this problem, don’t ask other people to find it, because nobody is smarter (nowadays) than you. This task may led some mathematician to the mental hospital.")

#text("3). For shure, if I ask about those matrix my former college math teacher, I will take a revenge for sheering me in front of a class.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-501311")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("Dear Terence Tao! SLE- this knot of all problems. Here evident show two roads.1.We agree with given situation,and get back at previous positon.2.Vice versa,we find methods of motion ahead. What you larger prefer? I am consider, what hexagonal percolation and loop-erased-this no going out from position. Be in existence some”weaving machine”,which have”mechanism”of retrieval and loop-reconstruction. Barely essentially to make choice: Schramm SLE, Smirnov,or”weaver”? Thanks. Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/30/commutators-close-to-the-identity-an-update/#comment-693434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("Prof. Tao, GPT-5.6 Sol with a beautiful observation quickly improved log^5 to log^4. It also formalized this in lean. I expect that we can use AI to push it even further, maybe even to the main conjecture O(log).")

#text("Details are here: ")#link("https://bilichboris.github.io/blog/2026/gpt-5-6-sol-improved-tao-bound/")[#text("https://bilichboris.github.io/blog/2026/gpt-5-6-sol-improved-tao-bound/")]
]
