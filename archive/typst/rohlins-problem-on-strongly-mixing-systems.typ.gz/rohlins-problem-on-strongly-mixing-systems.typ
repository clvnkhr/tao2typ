// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/
// Converted to Typst by tao2typ: "2026-10-14T09:06:40.658018+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Rohlin’s problem on strongly mixing systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Rohlin’s problem on strongly mixing systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/")[#text("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G = (G,+)}")#text(" be an abelian countable discrete group. A measure-preserving ")#mi("{G}")#text("-system ")#mi("{X = (X, {\\mathcal X}, \\mu, (T_g)_{g \\in G})}")#text(" (or ")#emph[#mi("{G}")#text("-system for short")]#text(") is a probability space ")#mi("{(X, {\\mathcal X}, \\mu)}")#text(", equipped with a measure-preserving action ")#mi("{T_g: X \\rightarrow X}")#text(" of the group ")#mi("{G}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu( T_g(E) ) = \\mu(E)")]]

#text("for all ")#mi("{E \\in {\\mathcal X}}")#text(" and ")#mi("{g \\in G}")#text(", and")

#align(center)[#tao-fit-display[#mitex("T_g T_h = T_{g+h}")]]

#text("for all ")#mi("{g, h \\in G}")#text(", with ")#mi("{T_0}")#text(" equal to the identity map. Classically, ergodic theory has focused on the cyclic case ")#mi("{G={\\bf Z}}")#text(" (in which the ")#mi("{T_g}")#text(" are iterates of a single map ")#mi("{T = T_1}")#text(", with elements of ")#mi("{G}")#text(" being interpreted as a time parameter), but one can certainly consider actions of other groups ")#mi("{G}")#text(" also (including continuous or non-abelian groups).")

#text("A ")#mi("{G}")#text("-system is said to be ")#emph[#text("strongly ")#mi("{2}")#text("-mixing")]#text(", or ")#link("http://en.wikipedia.org/wiki/Mixing_system")[#text("strongly mixing")]#text(" for short, if one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{g \\rightarrow \\infty} \\mu( A \\cap T_g B ) = \\mu(A) \\mu(B)")]]

#text("for all ")#mi("{A, B \\in {\\mathcal X}}")#text(", where the convergence is with respect to the one-point compactification of ")#mi("{G}")#text(" (thus, for every ")#mi("{\\epsilon > 0}")#text(", there exists a compact (hence finite) subset ")#mi("{K}")#text(" of ")#mi("{G}")#text(" such that ")#tao-math("{\\left|\\mu(A \\cap T_g B) - \\mu(A)\\mu(B)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{g \\not \\in K}")#text(").")

#text("Similarly, we say that a ")#mi("{G}")#text("-system is ")#emph[#text("strongly ")#mi("{3}")#text("-mixing")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{g,h,h-g \\rightarrow \\infty} \\mu( A \\cap T_g B \\cap T_h C ) = \\mu(A) \\mu(B) \\mu(C)")]]

#text("for all ")#mi("{A,B,C \\in {\\mathcal X}}")#text(", thus for every ")#mi("{\\epsilon > 0}")#text(", there exists a finite subset ")#mi("{K}")#text(" of ")#mi("{G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mu( A \\cap T_g B \\cap T_h C ) - \\mu(A) \\mu(B) \\mu(C)\\right| \\leq \\epsilon", block: true)]]

#text("whenever ")#mi("{g, h, h-g}")#text(" all lie outside ")#mi("{K}")#text(".")

#text("It is obvious that a strongly ")#mi("{3}")#text("-mixing system is necessarily strong ")#mi("{2}")#text("-mixing. In the case of ")#mi("{{\\bf Z}}")#text("-systems, it has been an open problem for some time, ")#link("http://www.ams.org/mathscinet-getitem?mr=30709")[#text("due to Rohlin")]#text(", whether the converse is true:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1 (Rohlin’s problem)")]#text(" Is every strongly mixing ")#mi("{{\\bf Z}}")#text("-system necessarily strongly ")#mi("{3}")#text("-mixing?")
]

#text("This is a surprisingly difficult problem. In the positive direction, a routine application of the Cauchy-Schwarz inequality (via van der Corput’s inequality) shows that every strongly mixing system is ")#emph[#text("weakly ")#mi("{3}")#text("-mixing")]#text(", which roughly speaking means that ")#mi("{\\mu(A \\cap T_g B \\cap T_h C)}")#text(" converges to ")#mi("{\\mu(A) \\mu(B) \\mu(C)}")#text(" for ")#emph[#text("most")]#text(" ")#mi("{g, h \\in {\\bf Z}}")#text(". Indeed, every weakly mixing system is in fact weakly mixing of all orders; see for instance ")#link("http://matheuscmss.wordpress.com/2010/03/02/ert9-weak-mixing-implies-weak-mixing-of-all-orders/")[#text("this blog post of Carlos Matheus")]#text(", or ")#link("https://terrytao.wordpress.com/2008/02/21/254a-lecture-12-weakly-mixing-systems/")[#text("these lecture notes of myself")]#text(". So the problem is to exclude the possibility of correlation between ")#mi("{A}")#text(", ")#mi("{T_g B}")#text(", and ")#mi("{T_h C}")#text(" for a small but non-trivial number of pairs ")#mi("{(g,h)}")#text(".")

#text("It is also known that the answer to Rohlin’s problem is affirmative for rank one transformations (a ")#link("http://www.ams.org/mathscinet-getitem?mr=766104")[#text("result of Kalikow")]#text(") and for shifts with purely singular continuous spectrum (a ")#link("http://www.ams.org/mathscinet-getitem?mr=1177346")[#text("result of Host")]#text("; note that strongly mixing systems cannot have any non-trivial point spectrum). Indeed, any counterexample to the problem, if it exists, is likely to be highly pathological.")

#text("In the other direction, Rohlin’s problem is known to have a negative answer for ")#mi("{{\\bf Z}^2}")#text("-systems, by a well-known ")#link("http://www.ams.org/mathscinet-getitem?mr=512106")[#text("counterexample of Ledrappier")]#text(" which can be described as follows. One can view a ")#mi("{{\\bf Z}^2}")#text("-system as being essentially equivalent to a ")#link("http://en.wikipedia.org/wiki/Stationary_process")[#text("stationary process")]#text(" ")#mi("{(x_{n,m})_{(n,m) \\in {\\bf Z}^2}}")#text(" of random variables ")#mi("{x_{n,m}}")#text(" in some range space ")#mi("{\\Omega}")#text(" indexed by ")#mi("{{\\bf Z}^2}")#text(", with ")#mi("{X}")#text(" being ")#mi("{\\Omega^{{\\bf Z}^2}}")#text(" with the obvious shift map")

#align(center)[#tao-fit-display[#mitex("T_{(g,h)} (x_{n,m})_{(n,m) \\in {\\bf Z}^2} := (x_{n-g,m-h})_{(n,m) \\in {\\bf Z}^2}.")]]

#text("In Ledrappier’s example, the ")#mi("{x_{n,m}}")#text(" take values in the finite field ")#mi("{{\\bf F}_2}")#text(" of two elements, and are selected at uniformly random subject to the “Pascal’s triangle” linear constraints")

#align(center)[#tao-fit-display[#mitex("x_{n,m} = x_{n-1,m} + x_{n,m-1}.")]]

#text("A routine application of the ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("Kolmogorov extension theorem")]#text(" allows one to build such a process. The point is that due to the properties of Pascal’s triangle modulo ")#mi("{2}")#text(" (known as ")#link("http://en.wikipedia.org/wiki/Sierpinski_triangle")[#text("Sierpinski’s triangle")]#text("), one has")

#align(center)[#tao-fit-display[#mitex("x_{n,m} = x_{n-2^k,m} + x_{n,m-2^k}")]]

#text("for all powers of two ")#mi("{2^k}")#text(". This is enough to destroy strong ")#mi("{3}")#text("-mixing, because it shows a strong correlation between ")#mi("{x}")#text(", ")#mi("{T_{(2^k,0)} x}")#text(", and ")#mi("{T_{(0,2^k)} x}")#text(" for arbitrarily large ")#mi("{k}")#text(" and randomly chosen ")#mi("{x \\in X}")#text(". On the other hand, one can still show that ")#mi("{x}")#text(" and ")#mi("{T_g x}")#text(" are asymptotically uncorrelated for large ")#mi("{g}")#text(", giving strong ")#mi("{2}")#text("-mixing. Unfortunately, there are significant obstructions to converting Ledrappier’s example from a ")#mi("{{\\bf Z}^2}")#text("-system to a ")#mi("{{\\bf Z}}")#text("-system, as pointed out by ")#link("http://www.ams.org/mathscinet-getitem?mr=2284884")[#text("de la Rue")]#text(".")

#text("In this post, I would like to record a “finite field” variant of Ledrappier’s construction, in which ")#mi("{{\\bf Z}^2}")#text(" is replaced by the function field ring ")#mi("{{\\bf F}_3[t]}")#text(", which is a “dyadic” (or more precisely, “triadic”) model for the integers (cf. ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("this earlier blog post of mine")]#text("). In other words:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" There exists a ")#mi("{{\\bf F}_3[t]}")#text("-system that is strongly ")#mi("{2}")#text("-mixing but not strongly ")#mi("{3}")#text("-mixing.")
]

#text("The idea is much the same as that of Ledrappier; one builds a stationary ")#mi("{{\\bf F}_3[t]}")#text("-process ")#mi("{(x_n)_{n \\in {\\bf F}_3[t]}}")#text(" in which ")#mi("{x_n \\in {\\bf F}_3}")#text(" are chosen uniformly at random subject to the constraints ")#metadata(none) <tao-94f9eef78a3815cb435f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("x_n + x_{n + t^k} + x_{n + 2t^k} = 0")]]

#text("for all ")#mi("{n \\in {\\bf F}_3[t]}")#text(" and all ")#mi("{k \\geq 0}")#text(". Again, this system is manifestly not strongly ")#mi("{3}")#text("-mixing, but can be shown to be strongly ")#mi("{2}")#text("-mixing; I give details below the fold.")

#text("As I ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("discussed in this previous post")]#text(", in many cases the dyadic model serves as a good guide for the non-dyadic model. However, in this case there is a curious rigidity phenomenon that seems to prevent Ledrappier-type examples from being transferable to the one-dimensional non-dyadic setting; once one restores the Archimedean nature of the underlying group, the constraints ")#link(<tao-94f9eef78a3815cb435f>)[#text("(1)")]#text(" not only reinforce each other strongly, but also force so much linearity on the system that one loses the strong mixing property.")

#metadata(none) <tao-e0d87b4dc27cafb25c22>

#heading(level: 1)[#strong[#text(" — 1. The example — ")]]

#text("Let ")#mi("{B}")#text(" be any ball in ")#mi("{{\\bf F}_3[t]}")#text(", i.e. any set of the form ")#mi("{\\{ n \\in {\\bf F}_3[t]: \\text{deg}(n-n_0) \\leq K \\}}")#text(" for some ")#mi("{n_0 \\in {\\bf F}_3[t]}")#text(" and ")#mi("{K \\geq 0}")#text(". One can then create a process ")#mi("{x_B = (x_n)_{n \\in B}}")#text(" adapted to this ball, by declaring ")#mi("{(x_n)_{n \\in B}}")#text(" to be uniformly distributed in the vector space ")#mi("{V_B \\leq {\\bf F}_3^B}")#text(" of all tuples with coefficients in ")#mi("{{\\bf F}_3}")#text(" that obey ")#link(<tao-94f9eef78a3815cb435f>)[#text("(1)")]#text(" for all ")#mi("{n \\in B}")#text(" and ")#mi("{k \\leq K}")#text(". Because any translate of a line ")#mi("{(n,n+t^k,n+t^{2k})}")#text(" is still a line, we see that this process is stationary with respect to all shifts ")#mi("{n \\mapsto n+g}")#text(" of degree ")#mi("{\\text{deg}(g)}")#text(" at most ")#mi("{K}")#text(". Also, if ")#mi("{B \\subset B^{\\prime}}")#text(" are nested balls, we see that the vector space ")#mi("{V_{B^{\\prime}}}")#text(" projects surjectively via the restriction map to ")#mi("{V_B}")#text(" (since any tuple obeying ")#link(<tao-94f9eef78a3815cb435f>)[#text("(1)")]#text(" in ")#mi("{B}")#text(" can be extended periodically to one obeying ")#link(<tao-94f9eef78a3815cb435f>)[#text("(1)")]#text(" in ")#mi("{B^{\\prime}}")#text("). As such, we see that the process ")#mi("{x_B}")#text(" is equivalent in distribution to the restriction ")#mi("{x_{B^{\\prime}}\\downharpoonright_B}")#text(" of ")#mi("{x_{B^{\\prime}}}")#text(" to ")#mi("{B}")#text(". Applying ")#link("http://en.wikipedia.org/wiki/Kolmogorov_extension_theorem")[#text("the Kolmogorov extension theorem")]#text(", we conclude that there exists an infinite process ")#mi("{x = (x_n)_{n \\in {\\bf F}_3[t]}}")#text(" whose restriction ")#mi("{x \\downharpoonright_B}")#text(" to any ball ")#mi("{B}")#text(" has the distribution of ")#mi("{x_B}")#text(". As each ")#mi("{x_B}")#text(" was stationary with respect to translations that preserved ")#mi("{B}")#text(", we see that the full process ")#mi("{x}")#text(" is stationary with respect to the entire group ")#mi("{{\\bf F}_3[t]}")#text(".")

#text("Now let ")#mi("{B}")#text(" be a ball")

#align(center)[#tao-fit-display[#mitex("B := \\{ n \\in {\\bf F}_3[t]: \\text{deg}(n-n_0) \\leq K \\},")]]

#text("which we divide into three equally sized sub-balls ")#mi("{B_0, B_1, B_2}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("B_i := \\{ n \\in {\\bf F}_3[t]: \\text{deg}(n-(n_0+it^K)) \\leq K-1 \\}.")]]

#text("By construction, we see that")

#align(center)[#tao-fit-display[#mitex("V_B = \\{ ( x_{B_0}, x_{B_1}, x_{B_2} ): x_{B_0}, x_{B_1}, x_{B_2} \\in V_{B_0}; x_{B_0}+x_{B_1}+x_{B_2} = 0 \\}")]]

#text("where we use translation by ")#mi("{t^K}")#text(" to identify ")#mi("{V_{B_0}}")#text(", ")#mi("{V_{B_1}}")#text(", and ")#mi("{V_{B_2}}")#text(" together. As a consequence, we see that the projection map ")#mi("{(x_{B_0}, x_{B_1}, x_{B_2}) \\rightarrow (x_{B_0}, x_{B_1})}")#text(" from ")#mi("{V_B}")#text(" to ")#mi("{V_{B_0} \\times V_{B_0}}")#text(" is surjective, and this implies that the random variables ")#mi("{x\\downharpoonright_{B_0}, x\\downharpoonright_{B_1}}")#text(" are independent. More generally, this argument implies that for any disjoint balls ")#mi("{B, B^{\\prime}}")#text(", the random variables ")#mi("{x\\downharpoonright_B}")#text(" and ")#mi("{x\\downharpoonright_{B^{\\prime}}}")#text(" are independent.")

#text("Now we can prove strong ")#mi("{2}")#text("-mixing. Given any measurable event ")#mi("{A}")#text(" and any ")#mi("{\\epsilon > 0}")#text(", one can find a ball ")#mi("{B}")#text(" and a set ")#mi("{A^{\\prime}}")#text(" depending only on ")#mi("{x\\downharpoonright_B}")#text(" such that ")#mi("{A}")#text(" and ")#mi("{A^{\\prime}}")#text(" differ by at most ")#mi("{\\epsilon}")#text(" in measure. On the other hand, for ")#mi("{g}")#text(" outside of ")#mi("{B-B}")#text(", ")#mi("{A^{\\prime}}")#text(" and ")#mi("{T_g A^{\\prime}}")#text(" are determined by the restrictions of ")#mi("{x}")#text(" to disjoint balls and are thus independent. In particular,")

#align(center)[#tao-fit-display[#mitex("\\mu( A^{\\prime} \\cap T_g A^{\\prime} ) = \\mu(A^{\\prime})^2")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\mu( A \\cap T_g A ) = \\mu(A)^2 + O(\\epsilon)")]]

#text("which gives strong ")#mi("{2}")#text("-mixing.")

#text("On the other hand, we have ")#mi("{x_0 + x_{t^k} + x_{2t^k} = 0}")#text(" almost surely, while each ")#mi("{x_0, x_{t^k}, x_{2t^k}}")#text(" are uniformly distributed in ")#mi("{{\\bf F}_3}")#text(" and pairwise independent. In particular, if ")#mi("{E}")#text(" is the event that ")#mi("{x_0=0}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\mu( E ) = 1/3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mu( E \\cap T_{t^k} E \\cap T_{t^{2k}} E ) = 1/9")]]

#text("showing that strong ")#mi("{3}")#text("-mixing fails.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In the Archimedean case ")#mi("{G = {\\bf Z}}")#text(", a constraint such as ")#mi("{x_n + x_{n+1} + x_{n+2} = 0}")#text(" propagates itself to force complete linearity of ")#mi("{x_n}")#text(", which is highly incompatible with strong mixing; in contrast, in the non-Archimedean case ")#mi("{G = {\\bf F}_3}")#text(", such a constraint does not propagate very far. It is then tempting to relax this constraint, for instance by adopting an ")#link("http://en.wikipedia.org/wiki/Ising_model")[#text("Ising-type model")]#text(" which penalises a configuration whenever quantities such as ")#mi("{x_n + x_{n+1} + x_{n+2}}")#text(" deviates from zero. However, to destroy strong ")#mi("{3}")#text("-mixing, one needs infinitely many such penalisation terms, which roughly corresponds to an Ising model in an infinite-dimensional lattice. In such models, it seems difficult to find a way to set the “temperature” parameters in such a way that one has meaningful ")#mi("{3}")#text("-correlations, without the system “freezing up” so much that ")#mi("{2}")#text("-mixing fails. It is also tempting to try to truncate the constraints such as ")#link(<tao-94f9eef78a3815cb435f>)[#text("(1)")]#text(" to prevent their propagation, but it seems that any naive attempt to perform a truncation either breaks stationarity, or introduces enough periodicity into the system that ")#mi("{2}")#text("-mixing breaks down. My tentative opinion on this problem is that a ")#mi("{{\\bf Z}}")#text("-counterexample is constructible, but one would have to use a very delicate and finely tuned construction to achieve it.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-50657")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")])]

#text("Dear Terry,")

#text("Essentially the problem is whether a strongly mixing ")#mi("\\textbf{Z}")#text("-system is strongly 3-mixing. If the answer to this is “yes”, then can we generalize and say that every $\\textbf{Z}$-system is strongly $n$-mixing (e.g. using induction).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-50658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")])]

#text("As far as I know there is no easy way to bootstrap the claim that strong 2-mixing implies strong 3-mixing, to the stronger claim that strong 2-mixing implies (say) strong 4-mixing. Indeed, to my knowledge, for any ")#mi("n < m")#text(", the claim that strong n-mixing implies strong m-mixing for ")#mi("{\\bf Z}")#text("-systems remains open (and no implications between these claims are known, other than the trivial ones).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353db294574b77d85998015b42185b48eccfc964603d2dc00d32795d9e9e8a0a-a6511a8a49674f21017f17e09816198beff00bef720eb01660b6c7e1ccd82265.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A College Level Problem on Jensen’s Inequality | Gaurav Happy Tiwari")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-50698")[#strong[#text("A College Level Problem on Jensen’s Inequality | Gaurav Happy Tiwari")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2011")])]

#text("[…] Rohlin’s problem on strongly mixing systems […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-93411")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2011")])]

#text("Hi Terry, perhaps Rohlin’s conjecture and the approach toward negative solution based on Ledrappier’s constructions and the further ideas in the post can become the starting point of a nice polymath project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-93507")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2011")])]

#text("Well, if there is sufficient interest and ideas to get started, I could certainly consider this. But the above blog post basically represents the extent of my own progress on the problem; one would need new ideas in order to advance further. So at this stage I’m happy to just use this comment thread to discuss the problem, unless there is a significant new development.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-93597")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2011")])]

#text("I see, I thought remark 1 suggested some (perhaps vague) idea on how an example will look which involves some hypothetical probabilistic models similar to models coming from statistical physics with some fine properties. (But the remark was not detailed enough for me to understand what properties are needed.) I did not know how much further Remark 1 was persued. ( I am fairly ignorant about the poblem beside knowing a number of people who tried.) In any case, the problem looks of the right nature for a massive collective ‘head hitting against the wall’ activity, but I agree a strong start is needed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/03/09/rohlins-problem-on-strongly-mixing-systems/#comment-214791")[#strong[#text("Nivat’s conjecture after Cyr-Kra « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2013")]

#text("[…] 3-dots systems. This dynamical system has several interesting properties (see, e.g, this blog post of Terence Tao for the relationship between this example and Rokhlin’s mixing problem), but, for the sake of […]")
]
