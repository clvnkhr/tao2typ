// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/
// Converted to Typst by tao2typ: "2026-10-14T11:27:56.129880+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "WordPress LaTeX bug collection drive", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("WordPress LaTeX bug collection drive")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/")[#text("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("By and large, I am quite happy with the LaTeX support provided by wordpress, which hosts my blog (and many other maths blogs out there); it is certainly superior to the maths support of most other off-the-shelf blog formats I have looked at. But it does have some annoying bugs and quirks; a lot of perfectly good LaTeX gets converted into “Formula does not parse”.")

#text("It occurred to me that maybe one should start a page that collects all the known bugs so that they can be sent at some point to the wordpress programmers to fix. So, here is my initial list of known bugs: any other wordpress users out there are very welcome to contribute their own.")

#text("Convention: I will drop the “latex” when I want to show a fragment of LaTeX source code without making it compile, e.g.")

#align(center)[#text("$\\int_{-\\infty}^\\infty e^{-\\pi x^2}\\ dx = 1$ becomes ")#mi("\\int_{-\\infty}^\\infty e^{-\\pi x^2}\\ dx = 1")#text(".")]

#text("[")#emph[#text("Update")]#text(", Feb 14: The bugs have now been fixed; see comments below.]")

#metadata(none) <tao-9957c105260201d11a67>

#heading(level: 2)[#text("— The brackets bug —")]

#text("This one comes up quite a lot: any LaTeX string that begins with a bracket [ automatically does not parse. For instance,")

#align(center)[#text("$[a,b]$ becomes ")#mi("[a,b]")#text(".")]

#text("A workaround here is to put some filler in front of the bracket, e.g.")

#align(center)[#text("${}[a,b]$ becomes ")#mi("{}[a,b]")#text(".")]

#align(center)[#text("$\\null [a,b]$ becomes ")#mi("{} [a,b]")#text(".")]

#heading(level: 2)[#text("— The trivial LaTeX bug —")]

#text("When applying LaTeX to a single character, the parser sometimes gives up:")

#align(center)[#text("$ $ becomes $latex $.")]

#align(center)[#text("$0$ becomes ")#mi("0")#text(".")]

#text("This can of course be worked around by using filler:")

#align(center)[#text("${} 0$ becomes ")#mi("{}0")#text(".")]

#heading(level: 2)[#text("— The double spacing bug —")]

#text("Most LaTeX strings that involve a double space seem to choke, e.g.")

#align(center)[#text("$x y$ becomes ")#mi("x    y")#text(".")]

#align(center)[#text("$a f$ becomes ")#mi("a  f")#text(".")]

#text("The workaround is, of course, not to use double spaces:")

#align(center)[#text("$x y$ becomes ")#mi("x y")#text(".")]

#heading(level: 2)[#text("— The nested brackets bug —")]

#text("If latex code contains brackets and is in turn contained in brackets, strange things can happen (and I don’t have a workaround for this, other than not to do it), in particular terminating the post prematurely:")

#align(center)[#text("$[[a,b]]$ becomes ")#mi("[[a,b]]")#text(".")]

#text("This sentence is not displayed.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (72)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09ded0a2181ca303ac919771df9468a22de65131a87b304cbadd66f2dba34fab-f05da8bca8be869db4a849cf1451972fcc7ae6cf3cc6fd6a64fa66c0f157a2aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vilyanur Chandra")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-43644")[#strong[#text("Vilyanur Chandra")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Nice. Thanks for the bugs.")#linebreak()#text(" I am a newbie for Latex and it will help me to understand Latex more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-49332")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("I cal also see that wordpress’es WYSIWYG editor sometimes automatically deletes blank space and other characters which also causes on latex formulas rendering.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/476fc664e9dc5ad4fc03fd04ec17bf3dd0088c054cc684768284fd127da9101d-1d4cb72b940839e610e9d54655388b82b42de320ee6b80067235b7bb3af83bb7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of converterpassion")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-49950")[#strong[#text("converterpassion")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")])]

#text("Terry, thanks a lot for this initiative, and quantblog thanks for the Codecogs LaTeX editor tip. I was just about to start putting a lot of maths expressions on my blog, and here I found precisely what I needed to get started. Again, thanks a lot both of you.")

#text("As another newbie here, my experience so far is that writing the post – or at least the LaTeX – in HTML mode prevents the WP engine from doing something “smart” (i.e. unwanted) that inserts weird stuff into the latex code string. I also noted that the Codecogs editor is far more forgiving than the WP parser, so you need to train yourself before it gets right most of the time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68f4bd3e0a365743e2c97eca1713365fc6db863971c939607548cabe756facc8-6a5b17ad3328e02cb51389b39a4b2f1b937dab98bd7c2410e887062b5adfb91b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pankaj Jyoti Mahanta")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-51562")[#strong[#text("Pankaj Jyoti Mahanta")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("is it correct- $[a,b]$ ? how can we write a to the power 4?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41f0198c7edb5ab20f3395121eaff7eef32027a9dea10dbc1bb863719c8d3af4-85c0ab92581d76427b4d93ae3cc4e2d4a667cf7e17bc0e7b049c6bf470140194.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen F. Siegel")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-60013")[#strong[#text("Stephen F. Siegel")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2011")])]

#text("I have a very basic problem. On my blog, all of my inlined latex formulas render with a very low vertical alignment, as if the center of the latex formula were aligned with the baseline of the surrounding text. For example, when I write ")#mi("x=0")#text(", the middle of the x is aligned with the baseline just under the “e”. Do I have a problem with some setting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4c67c287c5a97b91f8367cbab76459127c6c3e694199c10239525d6629daef5-21a7d42a9dd3f52a804edb0786867d2bf44ad591d3165c84ab81cccee440324c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerardo Beightol")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-126852")[#strong[#text("Gerardo Beightol")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2012")])]

#text("When will you update this with more information?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-158613")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("It also doesn’t like spaces before brackets:")#linebreak()#text(" “x )” ")#mi("x )")#linebreak()#text(" “x \\}” ")#mi("x \\}")

#text("The workaround is not to use spaces there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-158614")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("And it also likes your blog much more than mine, since it seems to behave differently on the same input! Wow!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5d712ad6f5a78a749b10dcdbda5168b68f6d5ff12e664d7855e70552b1c0a71-59b6006e9bb2847d088bda33144700abbac588df66fab6affdfe638646317ddf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shamov")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-158615")[#strong[#text("Alexander Shamov")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("No, I’m sorry, it’s just the difference between comments and posts. Anyway, it’s funny…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-158768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2012")])]

#text("With a bit configuration here:")#link("http://holdenweb.blogspot.com/2011/11/blogging-mathematics.html")[#text("http://holdenweb.blogspot.com/2011/11/blogging-mathematics.html")]#text(" ,Blogger can support LaTex too,using Mathjax.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-257299")[#strong[#text("On some diophantine equations | Mathematical Exposition")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")]

#text("[…] Please feel free to point out errors. A few may have inadvertently crept in due to the heavy editing involved(there were several LaTex issues- if you are having problems with typesetting math on wordpress, this webpage can be helpful: https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b1452692f7ca05ac5f6d374f49c573042822c19a71d93c5145bc1e12c21879da-28aaaa38e8bf1b2c82d7b41139f0cc4a7fb187dc9bde9e4b0730572f9d25757c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Murali")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-259156")[#strong[#text("Murali")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2013")])]

#text("$\\Latex$")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-259177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2013")])]

#text("Of course; “\\Latex” is not a command! It is “$\\LaTeX$”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A sporadic image resizing bug in WordPress LaTeX | What's new")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-261229")[#strong[#text("A sporadic image resizing bug in WordPress LaTeX | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("[…] the problem is coming from and how one might mitigate it. (If nothing else, I can add it to the bug collection post, once it can be reliably […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f7483e823f5f9157ecef8724096cf90cc70d2c3849b4030ea8058357af7ed16-c33f6b1c59949569c38ebbc224c44ec3c6254cb71abd09dd1812da70a48fcfe8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amarvashishth")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-277818")[#strong[#text("amarvashishth")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2014")])]

#text("it may not seem to work when preview under the Visual tab but works well when “Preview Changes” button is used.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2067f777fe1abbd727f43fb6e19b217e8bae79a584ff34b84673e6556b2eb74c-692b479f212fb26e6153de789d1620a8df7bd0cbbb620b419a2b81f1307ccbf4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JOYDEEP DUTTA")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-460114")[#strong[#text("JOYDEEP DUTTA")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2015")])]

#text("I am from India. I have just started a wordpress mathblog : convexityblog.wordpress.com")

#text("I just typed : $\\latex0\\in\\partial f(x)$ but it is not giving me the symbolic output when I am saving the file. I would be happy if you kindly help me. When do I see the final output.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-488296")[#strong[#text("¡Funciona! LaTeX en WordPress | General | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")]

#text("[…] “What’s new” y me encuentro con que un bug me ha resuelto la pregunta: “WordPress LaTeX bug collection drive“: $ latex <comandos> $, por […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e62ce70d1ccd281fbdc7b62187d23b5adef7cc31638f5226ad9137965d1661d-e75d4b3a000dad26124128199fc0b94fb96c790be211a91cd05f6f413377d9dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yaj Yaj")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-617553")[#strong[#text("Yaj Yaj")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2021")])]

#text("Reblogged this on ")#link("https://hicelacuenta.wordpress.com/2021/01/13/wordpress-latex-bug-collection-drive/")[#text("Hice Las Cuentas")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d897004026fe5f623670b08da15afc51b90aafe6feb064ef3089e93ee29be6e-0bbbfc63c562783b1f65ae6e1e2cfa370fde0c973335ffa915c5e6de27caf452.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michaelmross")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-617559")[#strong[#text("michaelmross")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2021")])]

#text("Why is it rendered so faint? I’ve not seen that elsewhere. Seems like the default grayscale is wrong.")

#emph[#text("[Wordpress’s LaTeX does not incorporate the CSS style. My blog uses a black text colour instead of grey, but I have to explicitly change the text colour in LaTeX to match (usually through an external script that convertex LaTeX to wordpress format). In this particular post I did not do this. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-643126")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2022")])]

#text("In google chrome all the latex look like really vague and pixelated pictures, in firefox they are sharp and nice and just as you would expect them to look. Does anyone else experience this difference? Is there an easy explanation (e.g. I am unknowingly using an outdated version of chrome and should download a new one) or is this just one of those weird facts of modern life?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-2/#comment-684518")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2024")])]

#text("I think I found something that might be added to wordpress.com while it is not a bug per se. The packages that we have access to are: amsmath, amsfonts and amssymb. But sometimes we need to write closed surface integrals and the code is $ latex oiint _S \\vec{u}\\cdot \\vec{n} dS$. But \\oiint is only available with \\usepackage{wasysym}. Hence the correct code just doesn’t parse: ")#mi("oiint _S \\vec{u}\\cdot \\vec{n} dS")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35667")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("Hi,")

#text("Something I’ve noticed is that sometimes (more often than one would like) I get an error (Formula does not parse). I then rewrite the exact same thing, and the error disappears. Sometimes, writing in the HTML rather than VISUAL mode reveals the problem, for example some invisible piece of code (ending italics mode, or stuff like that) got inside the dollar signs.")#linebreak()#text(" Sometimes, I do not see any reason for the error, and the rewrite makes it go away.")

#text("Andres")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35668")[#strong[#text("WordPress LaTeX Bug List | WPLover")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")]

#text("[…] WordPress LaTeX Bug List […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tmr")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35669")[#strong[#text("tmr")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("I noticed that brackets error, but did not know about the double space problem. checking out in HTML mode is neat though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/078d3596b24d2216bf967988a88f1f84dad64cd855618649bbf3c7b105383cde-70ccb4912bbc5f27ee3ef505d755fdd87e883fcc834616f2f771f381822d34ee.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quantblog")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35673")[#strong[#text("quantblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("I am new to latex embedded in WordPress – I agree its great but also frustrating.")

#text("I could never get multiple lines to parse, where they have &= .")#linebreak()#text(" So I just did them line by line, in chunks, ouch.")

#text("Im a linux user, fairly nw to LaTex. Not really a Lyx fan so far…")

#text("I found my best work-flow currently while I’m learning is to use one of the Latex online web based editors, namely codecogs – ")#link("http://www.codecogs.com/components/equationeditor/equationeditor.php")[#text("http://www.codecogs.com/components/equationeditor/equationeditor.php")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35675")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#text("This is extremely useful, Terry,")#linebreak()#text(" (Who could imagine that it was the double space that made so much troubles…) I noticed that quite a few times in order to have a formula work I have to retype it from scratch. I found it hard to identify systematically what is going wrong. One thing I noted is that when I edit a formula and change the first symbol after “latex” the edited formula does not work (still did not find a way around it).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e8a9e0fe5fd0b851235246a370623cdf9946df7d267d123ae59778369ac09d7-09cfc678ee1925aadce403f100d5e579ff979a502131b0de156dee0fff681057.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nhanttruong")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-54719")[#strong[#text("nhanttruong")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2011")])]

#text("I have a similar problem with retyping the formula from scratch.")

#text("I think it has something to do with copy and pasting latex: e.g. you get lazy typing ")#mi("A \\trianglelefteq A \\trianglelefteq A \\trianglelefteq A")#text(", so you first write A \\trianglelefteq and copy and paste it 3 times. WordPress doesn’t like this, so it gives a Formula does not parse.")

#text("One thing I’ve found to work is to finish your code as usual, then copy the entire block and paste it to some other editor (e.g. the search bar in your browser) and finally copy and paste it back.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35676")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2009")])]

#link("http://codex.wordpress.org/Reporting_Bugs")[#text("http://codex.wordpress.org/Reporting_Bugs")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/737d33f390a33b275eb1eb1bfab0ea16df7f1fcdca32e70c939506a6bbef7e0e-691be204aed9ea2ff22b07fe48af470ac9e19492137c7f8cf9578a40d8e93263.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anstei")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35677")[#strong[#text("anstei")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("The last bug is very strange indeed, since the resulting error is even different in the RSS feed: My reader printed")

#text("[${}[a,b]$] becomes [")#mi("{}<")#text(" img src=’http://l.wordpress.com/latex.php?latex=%7B%7D%5Ba%2Cb%5D&bg=ffffff&fg=545454&s=0′ alt='{}[a,b]‘ title=’{}[a,b]‘ class=’latex’ /")#mi("{}>")#text("].")

#text("instead of displaying and parsing the img tag correctly, even in if the HTML-tags seem to be perfectly well. Also, “This sentence is not displayed.” is in fact displayed!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35679")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#strong[#text("Brackets.")]#text(" To get for instance ")#mi("\\lbrack -\\pi ,\\pi\\rbrack")#text(" sometimes I write")

#text("$\\lbrack -\\pi ,\\pi\\rbrack $,")

#text("instead of $[-\\pi,\\pi]$")

#strong[#text("Spaces. ")]#text("Usually I have to delete the blank space before a \\ or before and after an =")

#text("In most cases this solves the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35682")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#strong[#text("Horizontal spacing.")]#text(" To have a thick space I write $x\\;y$, that parses as ")#mi("x\\;y")

#text("and $x\\,y$ for a thin space ")#mi("x\\,y")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35683")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#strong[#text("Nested brackets. ")]#text(" $\\left[ \\left[ a,b\\right] \\right] $ parses as ")#mi("\\left[ \\left[ a,b\\right] \\right]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35686")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("If I could ask wordpress.com programmers to do one more thing, it would be to implement a PREVIEW button for comments. Its absence isn’t a latex bug, but it makes latex bugs particularly painful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("The WordPress LaTeX plugin, by the way, is located here:")

#link("http://wordpress.org/extend/plugins/wp-latex/")[#text("http://wordpress.org/extend/plugins/wp-latex/")]

#text("I don’t see a place to report bugs for it, other than via the general link mentioned in an earlier comment (although that seems to be for “core” wordpress issues rather than for plugins).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jay")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35688")[#strong[#text("jay")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("Kevin: there’s no comment preview on wordpress.com blogs due to ")#link("http://en.forums.wordpress.com/topic/formatting-and-previews-for-comments")[#text("security reasons")]#text(".")

#text("The easiest work-around I guess is to get a wordpress account: even if not blogging yourself you’ll be able to use your account’s blog to preview your message and its LaTeX, and then simply copy and paste to whatever post you want to comment on when you’re ready.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35696")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2009")])]

#text("Ah, excellent idea. I didn’t notice the bracket bug, because I did my commutator expressions using a macro package I’d made for typing up my class notes — if you set it up with \\renewcommand so that \\comm{A}{B} gives ")#mi("{}[A,B]")#text(", the parser works. (Having macros for these things paid off, at least for me, when the expressions inside the commutator got big, so that I didn’t have to bother with \\left and \\right commands all the time.) Using one’s own style files with the LaTeXRender plugin requires tweaking the template it sticks TeX commands into, so I’m not sure it can be done on blogs hosted on wordpress.com.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35713")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#strong[#text("Comment preview.")]#text(" I agree with jay’s advice. For those with a WordPress blog that is quite natural. To edit my previous comments I just used my blog. Actually I did it in an auxiliary blog I created mainly for editing purposes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of john")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35726")[#strong[#text("john")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("Dear Terry,")

#text("I have always wondered…..do you write your blog posts on emacs/notepad first and then transfer them to wordpress? Perhaps some bugs could be attributed to this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88a871bdc186870400a78a5b25565205a0a761606de5f2df282450bee3d92f5b-b49c4500374d23af1382f3ece563613c77bd7a4953370ad6c60b41652d67fe0c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35734")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2009")])]

#text("Thanks for collating all these. Keep them coming and we’ll do us best to fix them up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35772")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("There is one more unpleasant bug of a different nature – improper handling of draft/autosaved posts. Recovering from an autosaved draft leads to all the backslashes being lost.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dweebydoofus")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35779")[#strong[#text("dweebydoofus")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("Dima also made a good point. One time I had to resort to the autosave option and the fact that I lost all \\ really was troublesome.")

#text("As for inputing equations in comments I think that another method could be to use the online LateX equation editors that are around. For example: ")#link("http://www.codecogs.com/components/equationeditor/equationeditor.php")[#text("http://www.codecogs.com/components/equationeditor/equationeditor.php")]#text(" you create your equation and then copy and paste the LateX code into the LateX tags.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35796")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2009")])]

#text("$REPEAT$ becomes ")#mi("REPEAT")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b00457ceb621f5f178576b293b843ec675833bce1f69ddba1f36f6804e3c0bb-4bbff5f974c75d7216116b7ecd5bdddde86471bbee19a7c487adb78aff8fc2b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hailin Wu")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35813")[#strong[#text("Hailin Wu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Hi Professor Tao,")

#text("Thank you for collecting the bugs and I’m happy to tell you that all of the LaTeX problems you mentioned in your post are fixed. Now WordPress should handle LaTeX math much better. Please let me know if you encounter any additional issue.")

#text("$ $ gives ‘no formula provided’, this is expected, as there IS no formula.")

#text("Luca: REPEAT is not allowed in our LaTeX package.")

#text("PS: I love abstract math (field theory in particular)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35814")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2009")])]

#text("Dear Hailin,")

#text("Thank you very much for the prompt fixes to the code!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35880")[#strong[#text("Writers block « Shores of the Dirac Sea")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2009")]

#text("[…] Terrence Tao is compiling a Latex for WordPress bug collection. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4a486d550cad911976d7e3d151762edf2d6f7a38d828fbd81acc75835115d0-5a827d159d829661f4c59a850efc9c1613d82fceeeb827723bc5e12eaa9e954e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35919")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("@Hailin Wu:")#linebreak()#text(" It used to be possible to copy Latex-images from the posts and comments into the your own comments (at least in firefox), but this doesn’t work anymore. This feature has saved me a lot of time. Could you please try to fix it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35922")[#strong[#text("¡Funciona! LaTeX en WordPress « Francis (th)E mule Science’s News")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")]

#text("[…] su blog “What’s new” y me encuentro con que un bug me ha resuelto la pregunta: “WordPress LaTeX bug collection drive“: $ latex <comandos> $, por […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b00457ceb621f5f178576b293b843ec675833bce1f69ddba1f36f6804e3c0bb-4bbff5f974c75d7216116b7ecd5bdddde86471bbee19a7c487adb78aff8fc2b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hailin")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35944")[#strong[#text("Hailin")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("Firefox changed it’s image copying mechanism. It’s a FF bug.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-35988")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2009")])]

#text("Dear Hailin,")

#text("A related issue: it seems that there does not seem to be any ALT-text attached to the LaTeX images now, whether in Firefox or in other browsers. (I have used this feature in the past to be able to paste LaTeX images into plain-text, which was also very useful.) If the ALT-text could be restored that would be very convenient.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b00457ceb621f5f178576b293b843ec675833bce1f69ddba1f36f6804e3c0bb-4bbff5f974c75d7216116b7ecd5bdddde86471bbee19a7c487adb78aff8fc2b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hailin")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36007")[#strong[#text("Hailin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("Dear Professor Tao,")

#text("Restored.")

#text("Just a note, now you can put nested brackets around expressions, and it will parse just fine. Ex:")

#text("$[[p, q]]$ becomes ")#mi("[[p, q]]")#linebreak()#text(" $[[[x, y]]]$ becomes ")#mi("[[[x, y]]]")

#text("Certainly the old way still works, but it is not as easy as the one above:")#linebreak()#text(" $ \\left[ \\left[ a,b\\right] \\right] $ becomes ")#mi("\\left[ \\left[ a,b\\right] \\right]")

#text("I’d avoid putting bracket directly outside of the whole latex expression, because […] is treated as shortcode and can cause side effects.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2009")])]

#text("Thanks again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("“open” seems to be some sort of reserved word, e.g. $\\hbox{open}$ becomes ")#mi("\\text{open}")#text(". The workaround is to insert some random braces, e.g. $hbox{op{}en}$ becomes ")#mi("\\text{op{}en}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b00457ceb621f5f178576b293b843ec675833bce1f69ddba1f36f6804e3c0bb-4bbff5f974c75d7216116b7ecd5bdddde86471bbee19a7c487adb78aff8fc2b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hailin")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36284")[#strong[#text("Hailin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("Right, the full list of reserved words are:")#linebreak()#text(" ‘afterassignment’,")#linebreak()#text(" ‘aftergroup’,")#linebreak()#text(" ‘batchmode’,")#linebreak()#text(" ‘catcode’,")#linebreak()#text(" ‘closein’,")#linebreak()#text(" ‘closeout’,")#linebreak()#text(" ‘command’,")#linebreak()#text(" ‘csname’,")#linebreak()#text(" ‘document’,")#linebreak()#text(" ‘def’,")#linebreak()#text(" ‘errhelp’,")#linebreak()#text(" ‘errcontextlines’,")#linebreak()#text(" ‘errorstopmode’,")#linebreak()#text(" ‘every’,")#linebreak()#text(" ‘expandafter’,")#linebreak()#text(" ‘immediate’,")#linebreak()#text(" ‘include’,")#linebreak()#text(" ‘input’,")#linebreak()#text(" ‘jobname’,")#linebreak()#text(" ‘loop’,")#linebreak()#text(" ‘lowercase’,")#linebreak()#text(" ‘makeat’,")#linebreak()#text(" ‘meaning’,")#linebreak()#text(" ‘message’,")#linebreak()#text(" ‘name’,")#linebreak()#text(" ‘newhelp’,")#linebreak()#text(" ‘noexpand’,")#linebreak()#text(" ‘nonstopmode’,")#linebreak()#text(" ‘open’,")#linebreak()#text(" ‘output’,")#linebreak()#text(" ‘pagestyle’,")#linebreak()#text(" ‘package’,")#linebreak()#text(" ‘pathname’,")#linebreak()#text(" ‘read’,")#linebreak()#text(" ‘relax’,")#linebreak()#text(" ‘repeat’,")#linebreak()#text(" ‘shipout’,")#linebreak()#text(" ‘show’,")#linebreak()#text(" ‘scrollmode’,")#linebreak()#text(" ‘special’,")#linebreak()#text(" ‘syscall’,")#linebreak()#text(" ‘toks’,")#linebreak()#text(" ‘tracing’,")#linebreak()#text(" ‘typeout’,")#linebreak()#text(" ‘typein’,")#linebreak()#text(" ‘uppercase’,")#linebreak()#text(" ‘write’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b00457ceb621f5f178576b293b843ec675833bce1f69ddba1f36f6804e3c0bb-4bbff5f974c75d7216116b7ecd5bdddde86471bbee19a7c487adb78aff8fc2b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hailin")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36285")[#strong[#text("Hailin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2009")])]

#text("One advice: your blog has a lot of comments, turning on comment threading is useful (Settings => Discussion).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-36889")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("I apologize if this question is somewhat out of topic.")#linebreak()#text(" I find the “framed theorems” used in this blog visually very effective, but I don’t understand how to realize this feature: is this latex or wordpress code?")

#text("Thanks,")#linebreak()#text(" c.c.")

#text("PS: from the source view, it looks it is the WP quotation but, even with the same theme (Tarski), I did not succeed in the task (but I’m a beginner).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-37837")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("This is not a WordPress LaTeX error ")#emph[#text("per se")]#text(", but it does tend to show up whenever LaTeX is used in comments: the inequality signs <, >, when occurring together, are parsed as HTML and so often all the text between such signs (when used in the mathematical sense) are simply lost.")

#text("The workaround here is to use &lt; and &gt; instead of < and >. Of course, one doesn’t want to break the HTML compatibility in order to save the mathematical symbols, but perhaps one compromise would be to not parse as HTML any expression between inequality signs which does not make sense as HTML, instead treating it as plaintext.")

#text("p.s. ccarminat, I’m using a modified version of the Tarski theme, with a slightly different CSS. The relevant code is")

#text("blockquote {")#linebreak()#text(" border-top:1px solid #000;")#linebreak()#text(" border-bottom:1px solid #000;")#linebreak()#text(" border-left:1px solid #000;")#linebreak()#text(" border-right:1px solid #000;")#linebreak()#text(" background:#FFFFFF;")#linebreak()#text(" color:#000;")#linebreak()#text(" margin:25px 25px 15px;")#linebreak()#text(" padding:5px 10px 0;")#linebreak()#text(" }")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bc3ca449c2ebc83a53332b20e9736b24e10e2a0cfbf189423336e5e695473b5-8df4d657c1dba3ec50191b7c242866c5f037feb2f5bb0fa2baf2846042f64873.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ccarminat")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-38189")[#strong[#text("ccarminat")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("Thanks!")

#text("It looks your css code for quotation works with K2-light as well.")

#text("But, to fix the change one has to use Custom CSS Upgrade:")#linebreak()#text(" am I right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-38769")[#strong[#text("Latex testing « Alanzed’s Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")]

#text("[…] how to deal with LaTeX in WordPress. They claim it is baked in, and Terrence Tao is starting a minor bug list, but I can’t get it to work without a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-38867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2009")])]

#text("${\\lambda}&fg=000000$ becomes ")#mi("{\\lambda}")#text(". In contrast, ${\\mu}&fg=000000$ becomes ")#mi("{\\mu}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-39253")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2009")])]

#text("$|\\psi \\rangle_{AB} = \\sum_{i,j} c_{ij}|i \\rangle_{A} \\otimes |j \\rangle_{B}$ becomes ")#tao-math("\\left|\\psi \\rangle_{AB}  = \\sum_{i,j} c_{ij}\\right|i \\rangle_{A} \\otimes |j \\rangle_{B}", block: false)#text(".")

#text("How would I fix this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-39254")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2009")])]

#text("It seems to work on the comments but not on my blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-41778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Something very strange: the double-spaces bug is fixed in comments but not in posts. For instance, $a f$ parses correctly in comments as ")#mi("a  f")#text(", but not in posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7119e5987dbd64087c250a78808aea6ce066d92ee7b0f49175b1c95c657d5a1c-186ac3e5f9f17ac48a4bac4c102ba6ffa53934b168596e0c780ab437f8e84ec5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lingpipe")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-41826")[#strong[#text("lingpipe")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("I’m finding that $\\big{$ fails, producing ")#mi("\\big{")#text(" (not parsing, as of 14 October 2009). But $\\big|$ produces ")#mi("\\big|")#text(". So I’m thinking it’s a bracket-matching parsing bug.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-41827")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2009")])]

#text("lingpipe: | isn’t required to match. Consider, for instance, its use as an “evaluation bar”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7119e5987dbd64087c250a78808aea6ce066d92ee7b0f49175b1c95c657d5a1c-186ac3e5f9f17ac48a4bac4c102ba6ffa53934b168596e0c780ab437f8e84ec5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lingpipe")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-41886")[#strong[#text("lingpipe")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("@John Armstrong")

#text("1. Using $\\big{$ isn’t supposed to invoke matching in LaTeX. It works just fine by itself outside of the context of WordPress’s plugin. Also, $\\big{ f(x) \\big}$ also fails to parse in the plugin.")

#text("2. The matching form of variable size parens would be invoked with $\\left{ f(x) \\right}$, but that also doesn’t work in the plugin. Also, the matching just requires count matching, not bracket matching — you can use $\\right.$ (note the final period) to match any old left without displaying anything.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-41888")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2009")])]

#text("@lingpipe Maybe it’s supposed to be $\\big\\{$ ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29dd055d7dcb23a067f090845602f5e807b8e1e91b8041fc14e27661108f2f95-83c8f54fed447878c1e98a2678466477b23f2297584f9e7b7b9a88bdb66a7d6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kim Kirkpatrick")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42815")[#strong[#text("Kim Kirkpatrick")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("@Terrence 8 Oct:")#linebreak()#text(" In WordPress posts, a double space becomes a space followed by & nbsp; (HTML entity space). The LaTeX parser should scan for such entities first.")#linebreak()#text(" Comments are filtered differently than posts; at least on my site, I can’t get double spaces in a comment. (That is, the spaces are in the text, show up again when editing, but HTML treats multiple spaces as one.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2146983175a2c82250205699f4d06cf3b2447ba6bb100bf07dd4f066d10d729-6096e4842e949358423777dc17ac749445c8f386ff679e9433f0882a2b95748f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Graham Wheeler")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42872")[#strong[#text("Graham Wheeler")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("I’m having a lot of difficulty with WP and LaTeX. For example, I am having problems with simple arithmetic equalities involving just integers, parentheses, plus minus and \\times.")

#text("It seems nondeterministic. For example, I took one expression and started replicating it piece by piece to see where the failure first occurred. Eventually I replicated the entire expression, with the newly entered one parsing but the original one still failing to parse, even though they were now exactly identical!")

#text("An example of the things that fail for me (maybe they would work if I went through the replication process above but that is too tedious to be practical):")

#mi("1=4\\times 10–3\\times 13=4\\times(36–2\\times 13)–3\\times 13=4\\times 36–11\\times 13")

#text("I’ve tried various combinations of whitespace to no avail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42873")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("Graham, I’m looking at your source code, and it seems you’re using some weird character instead of a keyboard hyphen as your minus sign. Replacing it with a standard keyboard hyphen, I test:")

#mi("1=4\\times 10-3\\times 13=4\\times(36-2\\times 13)-3\\times 13=4\\times 36-11\\times 13")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2146983175a2c82250205699f4d06cf3b2447ba6bb100bf07dd4f066d10d729-6096e4842e949358423777dc17ac749445c8f386ff679e9433f0882a2b95748f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Magi")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42874")[#strong[#text("Magi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("Thanks John, let me check that. I’m using Windows Live Writer as my editor and perhaps it is transforming the character as I am just typing in a keyboard hyphen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e2146983175a2c82250205699f4d06cf3b2447ba6bb100bf07dd4f066d10d729-6096e4842e949358423777dc17ac749445c8f386ff679e9433f0882a2b95748f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Magi")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42875")[#strong[#text("Magi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("You’re right – that is the problem. I’m not sure why WLW would transform the character inconsistently – when I re-entered the one line as I described above I was still using WLW so in some cases the hyphen is getting transformed and in others it is not. Very strange but at least I now I know how to fix it. Thanks very much!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/comment-page-1/#comment-42876")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2009")])]

#text("WLW likely does some preprocessing. In fact, WordPress might do the same. Try copying the character ‘-‘ as it appears on the website (not in the input box) and see what happens. I know that it replaces a double-hyphen with an en-dash, and a triple one with an em-dash (‘–‘ and ‘—‘, respectively), and androgynous (keyboard) single and double quotes with opening and closing quotes. Try typing some of those combinations into WLW and watch closely what happens.")
]
