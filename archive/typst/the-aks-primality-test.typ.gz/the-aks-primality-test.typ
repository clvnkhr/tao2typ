// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/
// Converted to Typst by tao2typ: "2026-10-14T15:17:25.166713+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The AKS primality test", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The AKS primality test")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")[#text("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/AKS_primality_test")[#text("Agrawal-Kayal-Saxena (AKS) primality test")]#text(", discovered in 2002, is the first provably deterministic algorithm to determine the primality of a given number with a run time which is guaranteed to be polynomial in the number of digits, thus, given a large number ")#mi("{n}")#text(", the algorithm will correctly determine whether that number is prime or not in time ")#mi("{O(\\log^{O(1)} n)}")#text(". (Many previous primality testing algorithms existed, but they were either probabilistic in nature, had a running time slower than polynomial, or the correctness could not be guaranteed without additional hypotheses such as GRH.)")

#text("The AKS test is of some relevance to the polymath project “")#link("http://michaelnielsen.org/polymath1/index.php?title=Finding_primes")[#text("Finding primes")]#text("“, so I thought I would sketch the details of the test (and the proof that it works) here. (Of course, full details can be found in the ")#link("http://www.cse.iitk.ac.in/users/manindra/algebra/primality_v6.pdf")[#text("original paper")]#text(", which is nine pages in length and almost entirely elementary in nature.) It relies on polynomial identities that are true modulo ")#mi("{n}")#text(" when ")#mi("{n}")#text(" is prime, but cannot hold for ")#mi("{n}")#text(" non-prime as they would generate a large number of additional polynomial identities, eventually violating the ")#link("http://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" (which asserts that a polynomial identity of degree at most ")#mi("{d}")#text(" can be obeyed by at most ")#mi("{d}")#text(" values of the unknown).")

#metadata(none) <tao-9c2d8a8e4831ca5238e4>

#text("Our starting point is ")#link("http://en.wikipedia.org/wiki/Fermat%27s_little_theorem")[#text("Fermat’s little theorem")]#text(", which asserts that ")#metadata(none) <tao-966369b1419838f0a43e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("a^p = a \\text{ mod } p")]]



#text(" for every prime ")#mi("{p}")#text(" and every ")#mi("{a}")#text(". This theorem suggests an obvious primality test: to test whether a number ")#mi("{n}")#text(" is prime, pick a few values of ")#mi("{a}")#text(" and see whether ")#mi("{a^n = a \\text{ mod } n}")#text(". (Note that ")#mi("{a^n}")#text(" can be computed in time ")#mi("{O(\\log^{O(1)} n)}")#text(" for any fixed ")#mi("{a}")#text(" by expressing ")#mi("{n}")#text(" in binary, and repeatedly squaring ")#mi("{a}")#text(".) If the statement ")#mi("{a^n = a \\text{ mod } n}")#text(" fails for some ")#mi("{a}")#text(", then ")#mi("{n}")#text(" would be composite. Unfortunately, the converse is not true: there exist non-prime numbers ")#mi("{n}")#text(", known as ")#link("http://en.wikipedia.org/wiki/Carmichael_number")[#text("Carmichael numbers")]#text(", for which ")#mi("{a^n = a \\text{ mod } n}")#text(" for all ")#mi("{a}")#text(" coprime to ")#mi("{n}")#text(" (")#mi("{561}")#text(" is the first example). So Fermat’s little theorem cannot be used, by itself, to establish primality for general ")#mi("{n}")#text(", because it is too weak to eliminate all non-prime numbers. (The situation improves though for more special types of ")#mi("{n}")#text(", such as Mersenne numbers; see ")#link("https://terrytao.wordpress.com/2008/10/02/the-lucas-lehmer-test-for-mersenne-primes/")[#text("my earlier post on the Lucas-Lehmer test")]#text(" for more discussion.)")

#text("However, there is a stronger version of Fermat’s little theorem which does eliminate all non-prime numbers. Specifically, if ")#mi("{p}")#text(" is prime and ")#mi("{a}")#text(" is arbitrary, then one has the polynomial identity ")#metadata(none) <tao-84d7e81aba90260b01e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(X+a)^p = X^p + a \\text{ mod } p")]]



#text(" where ")#mi("{X}")#text(" is an indeterminate variable. (More formally, we have the identity ")#mi("{(X+a)^p=X^p+a}")#text(" in the ring ")#mi("{F_p[X]}")#text(" of polynomials of one variable ")#mi("{X}")#text(" over the finite field ")#mi("{F_p}")#text(" of ")#mi("{p}")#text(" elements.) This identity (a manifestation of the ")#link("http://en.wikipedia.org/wiki/Frobenius_endomorphism")[#text("Frobenius endomorphism")]#text(") clearly implies ")#link(<tao-966369b1419838f0a43e>)[#text("(1)")]#text(" by setting ")#mi("{X=0}")#text("; conversely, one can easily deduce ")#link(<tao-84d7e81aba90260b01e3>)[#text("(2)")]#text(" from ")#link(<tao-966369b1419838f0a43e>)[#text("(1)")]#text(" by expanding out ")#mi("{(X+a)^p}")#text(" using the ")#link("http://en.wikipedia.org/wiki/Binomial_theorem")[#text("binomial theorem")]#text(" and the observation that the binomial coefficients ")#mi("{\\binom{p}{i} = \\frac{p \\cdot \\ldots \\cdot (p-i+1)}{i!}}")#text(" are divisible by ")#mi("{p}")#text(" for all ")#mi("{1 \\leq i < p}")#text(". Conversely, if ")#metadata(none) <tao-6ab175ec4222f247bce6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(X+a)^n = X^n + a \\text{ mod } n")]]



#text(" (i.e. ")#mi("{(X+a)^n = X^n+a}")#text(" in ")#mi("{({\\mathbb Z}/n{\\mathbb Z})[X]}")#text(") for some ")#mi("{a}")#text(" coprime to ")#mi("{n}")#text(", then by comparing coefficients using the binomial theorem we see that ")#mi("{\\binom{n}{i}}")#text(" is divisible by ")#mi("{n}")#text(" for all ")#mi("{1 \\leq i < n}")#text(". But if ")#mi("{n}")#text(" is divisible by some smaller prime ")#mi("{p}")#text(", then by setting ")#mi("{i}")#text(" equal to the largest power of ")#mi("{p}")#text(" that divides ")#mi("{n}")#text(", one sees that ")#mi("{\\binom{n}{i}}")#text(" is not divisible by enough powers of ")#mi("{p}")#text(" to be divisible by ")#mi("{n}")#text(", a contradiction. Thus one can use ")#link(<tao-6ab175ec4222f247bce6>)[#text("(3)")]#text(" (for a single value of ")#mi("{a}")#text(" coprime to ")#mi("{n}")#text(") to decide whether ")#mi("{n}")#text(" is prime or not.")

#text("Unfortunately, this algorithm, while deterministic, is not polynomial-time, because the polynomial ")#mi("{(X+a)^n}")#text(" has ")#mi("{n+1}")#text(" coefficients and will therefore take at least ")#mi("{O(n)}")#text(" time to compute. However, one can speed up the process by descending to a quotient ring of ")#mi("{({\\mathbb Z}/n{\\mathbb Z})[X]}")#text(", such as ")#mi("{{\\mathbb Z}/n{\\mathbb Z}[X]/(X^r-1)}")#text(" for some ")#mi("{r}")#text(". Clearly, if the identity ")#mi("{(X+a)^n=X^n+a}")#text(" holds in ")#mi("{({\\mathbb Z}/n{\\mathbb Z})[X]}")#text(", then it will also hold in ")#mi("{({\\mathbb Z}/n{\\mathbb Z})[X]/(X^r-1)}")#text(", thus ")#metadata(none) <tao-3a7914e95d26ff2e2d85>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(X+a)^n = X^n + a \\text{ mod } n, X^r-1.")]]



#text(" The point of doing this is that (if ")#mi("{r}")#text(" is not too large) the left-hand side of ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" can now be computed quickly (again by expanding ")#mi("{n}")#text(" in binary and performing repeated squaring), because all polynomials can be reduced to be of degree less than ")#mi("{r}")#text(", rather than being as large as ")#mi("{n}")#text(". Indeed, if ")#mi("{r = O( \\log^{O(1)} n )}")#text(", then one can test ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" in time ")#mi("{O(\\log^{O(1)} n)}")#text(".")

#text("We are not done yet, because it could happen that ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" holds but ")#link(<tao-6ab175ec4222f247bce6>)[#text("(3)")]#text(" fails. But we have the following key theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (AKS theorem)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Suppose that for all ")#mi("{1 \\leq a, r \\leq O( \\log^{O(1)} n)}")#text(", ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" holds, and ")#mi("{a}")#text(" is coprime to ")#mi("{n}")#text(". Then ")#mi("{n}")#text(" is either a prime, or a power of a prime.")
]

#text("Of course, coprimality of ")#mi("{a}")#text(" and ")#mi("{n}")#text(" can be quickly tested using the ")#link("http://en.wikipedia.org/wiki/Euclidean_algorithm")[#text("Euclidean algorithm")]#text(", and if coprimality fails then ")#mi("{n}")#text(" is of course composite. Also, it is easy to quickly test for the property that ")#mi("{n}")#text(" is a power of an integer (just compute the roots ")#mi("{n^{1/k}}")#text(" for ")#mi("{1 \\leq k \\leq \\log_2 n}")#text("), and such powers are clearly composite. From all this (and ")#link(<tao-84d7e81aba90260b01e3>)[#text("(2)")]#text(", one soon sees that theorem gives rise to a deterministic polynomial-time test for primality. One can optimise the powers of ")#mi("{\\log n}")#text(" in the bounds for ")#mi("{a,r}")#text(" (as is done in the ")#link("http://www.cse.iitk.ac.in/users/manindra/algebra/primality\\_v6.pdf")[#text("original paper")]#text("), but we will not do so here to keep the exposition uncluttered.")

#text("Actually, we don’t need ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" satisfied for all that many exponents ")#mi("{r}")#text(" to make the theorem work; just one well-chosen ")#mi("{r}")#text(" will do. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (AKS theorem, key step)")]#text(" ")#metadata(none) <tao-2c70e12b7a0646f92279>#text(" Let ")#mi("{r}")#text(" be coprime to ")#mi("{n}")#text(", and such that ")#mi("{n}")#text(" has order greater than ")#mi("{\\log^2_2 n}")#text(" in the multiplicative group ")#mi("{({\\mathbb Z}/r{\\mathbb Z})^\\times}")#text(" (i.e. the residues ")#mi("{n^i \\text{ mod } r}")#text(" for ")#mi("{1 \\leq i \\leq \\log^2 n}")#text(" are distinct). Suppose that for all ")#mi("{1 \\leq a \\leq O( r \\log^{O(1)} n)}")#text(", ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(" holds, and ")#mi("{a}")#text(" is coprime to ")#mi("{n}")#text(". Then ")#mi("{n}")#text(" is either a prime, or a power of a prime.")
]

#text("To find an ")#mi("{r}")#text(" with the above properties we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Existence of good ")#mi("{r}")#text(")")]#text(" ")#metadata(none) <tao-770e607624d689265ca6>#text(" There exists ")#mi("{r = O(\\log^{O(1)} n)}")#text(" coprime to ")#mi("{n}")#text(", such that ")#mi("{n}")#text(" has order greater than ")#mi("{\\log^2_2 n}")#text(" in ")#mi("{({\\mathbb Z}/r{\\mathbb Z})^\\times}")#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{1 \\leq i \\leq \\log^2_2 n}")#text(", the number ")#mi("{n^i - 1}")#text(" has at most ")#mi("{O( \\log^{O(1)} n)}")#text(" prime divisors (by the fundamental theorem of arithmetic). If one picks ")#mi("{r}")#text(" to be the first prime not equal to any of these prime divisors, one obtains the claim. (One can use a crude version of the prime number theorem to get the upper bound on ")#mi("{r}")#text(".) ")#mi("\\Box")

#text("It is clear that Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" follows from Theorem ")#link(<tao-2c70e12b7a0646f92279>)[#text("2")]#text(" and Lemma ")#link(<tao-770e607624d689265ca6>)[#text("3")]#text(", so it suffices now to prove Theorem ")#link(<tao-2c70e12b7a0646f92279>)[#text("2")]#text(".")

#text("Suppose for contradiction that Theorem ")#link(<tao-2c70e12b7a0646f92279>)[#text("2")]#text(" fails. Then ")#mi("{n}")#text(" is divisible by some smaller prime ")#mi("{p}")#text(", but is not a power of ")#mi("{p}")#text(". Since ")#mi("{n}")#text(" is coprime to all numbers of size ")#mi("{O(\\log^{O(1)} n)}")#text(" we know that ")#mi("{p}")#text(" is not of polylogarithmic size, thus we may assume ")#mi("{p \\geq \\log^C n}")#text(" for any fixed ")#mi("{C}")#text(". As ")#mi("{r}")#text(" is coprime to ")#mi("{n}")#text(", we see that ")#mi("{r}")#text(" is not a multiple of ")#mi("{p}")#text(" (indeed, one should view ")#mi("{p}")#text(" as being much larger than ")#mi("{r}")#text(").")

#text("Let ")#mi("{F}")#text(" be a field extension of ")#mi("{F_p}")#text(" by a primitive ")#mi("{r^{th}}")#text(" root of unity ")#mi("{X}")#text(", thus ")#mi("{F = F_p[X]/h(X)}")#text(" for some factor ")#mi("{h(X)}")#text(" (in ")#mi("{F_p[X]}")#text(") of the ")#mi("{r^{th}}")#text(" ")#link("http://en.wikipedia.org/wiki/Cyclotomic_polynomial")[#text("cyclotomic polynomial")]#text(" ")#mi("{\\Phi_r(X)}")#text(". From the hypothesis ")#link(<tao-3a7914e95d26ff2e2d85>)[#text("(4)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("(X+a)^n = X^n + a")]]

#text("in ")#mi("{F}")#text(" for all ")#mi("{1 \\leq a \\leq A}")#text(", where ")#mi("{A = O(r \\log^{O(1)} n)}")#text(". Note that ")#mi("{n}")#text(" is coprime to every integer less than ")#mi("{A}")#text(", and thus ")#mi("{A < p}")#text(".")

#text("Meanwhile, from ")#link(<tao-84d7e81aba90260b01e3>)[#text("(2)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("(X+a)^p = X^p + a")]]

#text("in ")#mi("{F}")#text(" for all such ")#mi("{a}")#text(". The two equations give")

#align(center)[#tao-fit-display[#mitex("(X^p+a)^{n/p} = (X^p)^{n/p} + a.")]]

#text("Note that the ")#mi("{p^{th}}")#text(" power ")#mi("{X^p}")#text(" of a primitive ")#mi("{r^{th}}")#text(" root of unity ")#mi("{X}")#text(" is again a primitive ")#mi("{r^{th}}")#text(" root of unity (and conversely, every primitive ")#mi("{r^{th}}")#text(" root arises in this fashion) and hence we also have")

#align(center)[#tao-fit-display[#mitex("(X+a)^{n/p} = X^{n/p} + a")]]

#text("in ")#mi("{F}")#text(" for all ")#mi("{1 \\leq a \\leq A}")#text(".")

#text("Inspired by this, we define a key concept: a positive integer ")#mi("{m}")#text(" coprime to ")#mi("{r}")#text(" is said to be ")#emph[#text("introspective")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("(X+a)^m = X^m + a")]]

#text("in ")#mi("{F}")#text(" for all ")#mi("{1 \\leq a \\leq A}")#text(", or equivalently if ")#mi("{(X+a)^m=\\phi_m(X+a)}")#text(", where ")#mi("{\\phi_m: F \\rightarrow F}")#text(" is the ring homomorphism that sends ")#mi("{X}")#text(" to ")#mi("{X^m}")#text(".")

#text("We have just shown that ")#mi("{p, n, n/p}")#text(" are all introspective; ")#mi("{1}")#text(" is also trivially introspective. Furthermore, if ")#mi("{m}")#text(" and ")#mi("{m^{\\prime}}")#text(" are introspective, it is not hard to see that ")#mi("{mm^{\\prime}}")#text(" is also introspective. Thus we in fact have a lot of introspective integers: any number of the form ")#mi("{p^i (n/p)^j}")#text(" for ")#mi("{i,j \\geq 0}")#text(" is introspective.")

#text("It turns out in fact that it is not possible to create so many different introspective numbers, basically the presence of so many polynomial identities in the field would eventually violate the ")#link("http://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(". To see this, let ")#mi("{{\\mathcal G} \\subset F^\\times}")#text(" be the multiplicative group generated by the quantities ")#mi("{X+a}")#text(" for ")#mi("{1 \\leq a \\leq A}")#text(". Observe that ")#mi("{z^m = \\phi_m(z)}")#text(" for all ")#mi("{z \\in {\\mathcal G}}")#text(". We now show that this places incompatible lower and upper bounds on ")#mi("{{\\mathcal G}}")#text(". We begin with the lower bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Lower bound on ")#mi("{{\\mathcal G}}")#text(")")]#text(" ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>#text(" ")#tao-math("{\\left|{\\mathcal G}\\right| \\geq 2^t}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{P(X)}")#text(" be a product of less than ")#mi("{t}")#text(" of the quantities ")#mi("{X+1,\\ldots,X+A}")#text(" (allowing repetitions), then ")#mi("{P(X)}")#text(" lies in ")#mi("{{\\mathcal G}}")#text(". Since ")#mi("{A \\geq 2r \\geq 2t}")#text(", there are certainly at least ")#mi("{2^t}")#text(" ways to pick such a product. So to establish the proposition it suffices to show that all these products are distinct.")

#text("Suppose for contradiction that ")#mi("{P(X)=Q(X)}")#text(", where ")#mi("{P,Q}")#text(" are different products of less than ")#mi("{t}")#text(" of the ")#mi("{X+1,\\ldots,X+A}")#text(". Then, for every introspective ")#mi("{m}")#text(", ")#mi("{P(X^m)=Q(X^m)}")#text(" as well (note that ")#mi("{P(X^m) = \\phi_m(P(X))}")#text("). In particular, this shows that ")#mi("{X^{m_1},\\ldots,X^{m_t}}")#text(" are all roots of the polynomial ")#mi("{P-Q}")#text(". But this polynomial has degree less than ")#mi("{t}")#text(", and the ")#mi("{X^{m_1},\\ldots,X^{m_t}}")#text(" are distinct by hypothesis, and we obtain the desired contradiction by the factor theorem. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Upper bound on ")#mi("{{\\mathcal G}}")#text(")")]#text(" ")#metadata(none) <tao-aee610558292023758a4>#text(" Suppose that there are exactly ")#mi("{t}")#text(" residue classes modulo ")#mi("{r}")#text(" of the form ")#mi("{p^i (n/p)^j \\text{ mod } r}")#text(" for ")#mi("{i,j \\geq 0}")#text(". Then ")#tao-math("{\\left|{\\mathcal G}\\right| \\leq n^{\\sqrt{t}}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" By the pigeonhole principle, we must have a collision")

#align(center)[#tao-fit-display[#mitex("p^i (n/p)^j = p^{i^{\\prime}} (n/p)^{j^{\\prime}} \\text{ mod } r")]]

#text("for some ")#mi("{0 \\leq i,j,i^{\\prime},j^{\\prime} \\leq \\sqrt{t}}")#text(" with ")#mi("{(i,j) \\neq (i^{\\prime},j^{\\prime})}")#text(". Setting ")#mi("{m := p^i (n/p)^j}")#text(" and ")#mi("{m^{\\prime} := p^{i^{\\prime}} (n/p)^{j^{\\prime}}}")#text(", we thus see that there are two distinct introspective numbers ")#mi("{m,m^{\\prime}}")#text(" of size most ")#mi("{n^{\\sqrt{t}}}")#text(" which are equal modulo ")#mi("{r}")#text(". (To ensure that ")#mi("{m,m^{\\prime}}")#text(" are distinct, we use the hypothesis that ")#mi("{n}")#text(" is not a power of ")#mi("{p}")#text(".) This implies that ")#mi("{\\phi_m = \\phi_{m^{\\prime}}}")#text(", and thus ")#mi("{z^m = z^{m^{\\prime}}}")#text(" for all ")#mi("{z \\in {\\mathcal G}}")#text(". But the polynomial ")#mi("{z^m - z^{m^{\\prime}}}")#text(" has degree at most ")#mi("{n^{\\sqrt{t}}}")#text(", and the claim now follows from the factor theorem. ")#mi("\\Box")

#text("Since ")#mi("{n}")#text(" has order greater than ")#mi("{\\log^2 n}")#text(" in ")#mi("{({\\mathbb Z}/r{\\mathbb Z})^\\times}")#text(", we see that the number ")#mi("{t}")#text(" of residue classes ")#mi("{r}")#text(" of the form ")#mi("{p^i (n/p)^j}")#text(" is at least ")#mi("{\\log^2 n}")#text(". But then ")#mi("{2^t > n^{\\sqrt{t}}}")#text(", and so Propositions ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("4")]#text(", ")#link(<tao-aee610558292023758a4>)[#text("5")]#text(" are incompatible.")

#emph[#text("Update, Aug 12")]#text(": A thorough discussion of the AKS algorithm by Andrew Granville for Bull. Amer. Math. Soc. can be found ")#link("http://www.dms.umontreal.ca/~andrew/PDF/Bulletin04.pdf")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40969")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("I like that this proof illustrates how fast (i.e. polynomial) computability fails to be analogous to general computability. If one has an “elementary” proof that a witness with some computably checkable property exists, the proof can generally be turned into a computation of that witness. (This can be made formal: if the proof can be formulated, even in a theory like full second order arithmetic, it can be converted to a computation of the witness.)")

#text("Yet, when given a composite number, the AKS primality test gives a fairly simple demonstration, in polynomial time, that there is some factor, but no way to quickly find what that factor is. Interestingly, the test does give a witness to ")#emph[#text("something")]#text(", and it’s the task of converting that witness into a factor which cannot be carried out quickly (in polynomial time).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40970")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("In the parenthetical at the end of the first paragraph, it seems like ‘faster’ should read ‘slower’. ")#emph[#text("[Fixed, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of windfarmmusic")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40971")[#strong[#text("windfarmmusic")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Never mind!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1d85674e0ee0043611852ed68faac47f6bf72d610c710a7df34d1bc2469523b-1587102e0a738dfd0dec499c7ea3d02ce79ce4e0c8ba9d598a386a66dda803d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of theoreticalminimum")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40975")[#strong[#text("theoreticalminimum")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Note: The url to the AKS paper has a backward slash after “primality” which has to be removed to get the correct url. ")#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5081ad23ddccf1ac24b1ad4e1de118c7e68f19bdfdd0ed364b444562d2ccfc90-960565e53bae01984d214570cff0c0c565c883285dad8eaed9c6d9b5c594eacb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cipher3d")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40988")[#strong[#text("cipher3d")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Thanks for this excellent explanatory post, Terry. Why is it, though, that number theoretic algorithms complexity is always done in terms of the logarithm of the number sizes? That is, the complexity of AKS on input n is polylogarithmic in n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anoymous")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-40993")[#strong[#text("anoymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("I guess because you want to have a running time polynomial in the input size, i.e., the number of bits you need to write down the input. For a single number it is ")#mi("O(\\log (n))")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leandro")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-41000")[#strong[#text("Leandro")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Just a minor typo: right after equation (1), it says:")#linebreak()#text(" “..pick a few values of and see..”. I think you mean:")#linebreak()#text(" “..pick a few values of $n$ and see..”.")

#emph[#text("[Actually, I meant ")#mi("a")#text(" here, but thanks for the correction. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-41001")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("“Why is it, though, that number theoretic algorithms complexity is always done in terms of the logarithm of the number sizes?”")

#text("Anonymous’s answer, that this is the size of the input, is good. One should also note that it is the efficiency of the “easy” operations: addition, multiplication, division with remainder, GCD and so forth. Since these are the building blocks of our algorithms, it makes sense to study those algorithms which are not much worse than the pieces they are built from.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-41003")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Dear Terry,")

#text("probably, the main question that one needs to solve is the following:")

#text("suppose that we have all the set of a’s that violate (4) and thus gurantee that p is a composite and not a prime power. What do you think: can we somehow use this set to obtain a factor of p?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04d9122a4f5a65fbc4c97e1913c8923ff4e487fec00e589d1e9ba63d2b711419-069869cb30be63e27c55cab11e831649bc80ef4161d99462da03503b399c2fe4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny Easwaran")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-41009")[#strong[#text("Kenny Easwaran")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Very nice explanation of the results! I started to get a bit confused about half way through with the big-O notations. For instance, you state Theorem 1 as:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Theorem 1 (AKS theorem) Suppose that for all ")#mi("{1 \\leq a, r \\leq O( \\log^{O(1)} n)}")#text(", (4) holds, and ")#mi("{a}")#text(" is coprime to ")#mi("{n}")#text(". Then ")#mi("{n}")#text(" is either a prime, or a power of a prime.")
]

#text("The first sentence looks like it can be true for all ")#mi("n")#text(" while of course the second isn’t. After all, there is some constant such that (4) holds for all ")#mi("a,r")#text(" less than that constant times ")#mi("\\log n")#text(", namely 0.")

#text("I suppose the right way to understand this is that the big-O expressions are all taken to introduce existential quantifiers over constants somewhere early on, with scope over the entire theorem, rather than just scope over the specific equation the big-O statement is in. And you’re also supposed to understand the scope of this quantifier with respect to various other quantifiers appropriately too. Thus, the more formal statement of Theorem 1 must say")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#mi("\\exists k\\forall n \\textrm{If }\\forall 1\\leq a, r\\leq k(\\log^k n)")#text(" (4) holds, then ")#mi("{n}")#text(" is either a prime, or a power of a prime.")
]

#text("Switching the initial existential and universal quantifiers yields a statement that is trivially true (just choose ")#mi("k=0")#text(" if ")#mi("n")#text(" is prime or a power of a prime and ")#mi("k=n")#text(" otherwise).")

#text("Perhaps the fact that this existential quantifier gets widest scope is implicit in the fact that it’s called a constant, but it gets more unclear when you cross sentence boundaries. Because there are other examples with the same format as the statement of Theorem 1 here where the quantifier clearly isn’t meant to have wide scope over both sentences. For instance")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Suppose one can factor ")#mi("n")#text(" in ")#mi("n^{O(1)}")#text(" time. Then standard cryptography is weak.")
]

#text("This doesn’t mean that there is some exponent on the polynomial that would mean cryptography is weak – rather it means that ")#emph[#text("any")]#text(" exponent on the polynomial would work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-41032")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2009")])]

#text("Thank you for the clarity in showing that PRIME is in P. Now, is SEMIPRIME in P? By definition, a semiprime is a product of exactly two primes, not necessarily distinct. They matter because of an important class of cryptosystems, in a multibillion dollar industry. The complication: there exist specific semiprimes in the literature that have been proven to be semiprimes, without any prime factorization know. We don’t know the complexity class for prime factorization. So what is the complexity class for determining if a given integer is or is not a semiprime? Several experts in number theory and quantum computing have told me that mine is an interesting question, but probably very difficult. I mention quantum computing because SEMIPRIME might be in a qc complexity class of interest. What do you think?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-42716")[#strong[#text("Four Derandomization Problems « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")]

#text("[…] about primality certificate. and the AKS deterministic algorithm for primality is described in this post by Terry Tao (among other places). It was a beautiful combination of number theoretic ideas and derandomization […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-47965")[#strong[#text("Manindra Agrawal and Carlos Gustavo (Gugu) Moreira share 2010 TWAS prize in Mathematics « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")]

#text("[…] algorithm to decide primality of natural numbers (for a nice exposition on this subject see this post by Terence Tao), and the works of Gugu (Annales de l’IHP, 1996), and Gugu and J.-C. Yoccoz (Annals of Math. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f281ffbcc1d9e3af3837ef70b4abcbfb76d13d6202dcd80a39b0a5c049eee14-34c5ed697992b7d3d4bc0ac3b0dae95692c7fce03c7f381dc4add3382e0b46ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ricardo Menares")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-50416")[#strong[#text("Ricardo Menares")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2011")])]

#text("Small typo: in the paragraph above (4) it should be (Z/NZ[x])/(X^r-1) instead of F_p[x]/(X^r-1)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-85691")[#strong[#text("amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("Hello I think that binomial test is also suitable for factoring.")

#text("binomial test – phrase used from pdf in chapter 11")

#link("http://www.scottaaronson.com/writings/prime.pdf")[#text("Click to access prime.pdf")]

#text("Just see next links and you will understand:")

#text("1. key : -sieve of eratosthenes connected to triangles line N, and thus giving factors for that line N, for either composite number (or prime)")#linebreak()

#text("2-key :–sieve of eratosthenes connected to remainders of binomial coefficients in pascal triangle by modulo n. (compare triangle from video and pascal triangle in mod N)")#linebreak()#text(" ")#link("http://img6.imagebanana.com/img/w0izp9xa/desktop1_010.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img6.imagebanana.com/img/w0izp9xa/desktop1_010.png")[Original image]]]]

#text("Finally you will see that every midterm binomial coeficients, which are not divisible by N, correlate to factor of number N by its position and its value.")

#text("So bolded statement in next jpg is wrong")#linebreak()#text(" ")#link("http://img59.imageshack.us/img59/2070/desktop1025.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img59.imageshack.us/img59/2070/desktop1025.png")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-86963")[#strong[#text("amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("There is one more think that is of interest (for me). Aditional way of checking factors of explicit number N (for example 341 )is that you calculate mod 341 while building pascal triangle to line 341.")

#text("You will se that numbers 11 and 31 have midterm values that are divisble by 341 so mod 341 is 0.")

#link("http://img6.imagebanana.com/img/4zidh538/desktop1_012.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img6.imagebanana.com/img/4zidh538/desktop1_012.png")[Original image]]]]

#text("Line 341 also gives interesting results")#linebreak()#text(" ")#link("http://img6.imagebanana.com/img/gep2hw2r/desktop1_013.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img6.imagebanana.com/img/gep2hw2r/desktop1_013.png")[Original image]]]]

#text("The only problem finding factors of 341 this way is that mod 341 doesnt take its full function for smaller numbers (lines) and these factors my be “fake” for 341 (see again first picture: fake factor 2,3,5,7)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-88409")[#strong[#text("amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2011")])]

#text("“You will se that numbers 11 and 31 have midterm values that are divisible by 341 so mod 341 is 0.”")

#text("Wrongly put")

#text("“You will se that lines 11 and 31 have midterm values that are divisible by 11 or 31 in pascal triangle mod 341.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/808ebe104f1e053c31a8a3fb32a9e8fe6e064792f62ea8f5eb838518b5ea8c8e-4965acb79594930deed2d152f60ddedb2fab9dae8d9fd60710acca8738f77a36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gabriel b")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-98959")[#strong[#text("gabriel b")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2011")])]

#text("this is so complex that i can’t understand anything. anyway i’ve made a simple program to find prime numbers by ‘brute force dividing’ that is pretty fast and completely foolproof, it would be good to use a program based on this AKS primality test that i see so much fuss about on the internet to compare the speed difference between this approach and my simple one.")#linebreak()#text(" i saw some project on sourceforge about this where you could download")

#text("the program and i did but i can’t see any working executable there, nor any indications, so maybe it isn’t ”the real thing”, anyway if someone knows about one executable implementation of this AKS method of discovering primes please respond to this question saying something because i’m going to be notified by e-mail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-109797")[#strong[#text("Number Theory: Lecture 22 « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")]

#text("[…] (The Higher Arithmetic) both have material on pseudoprimes and primality testing. Terry Tao has a blog post about the AKS primality test, with various links to further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bojan vasiljevic")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-109830")[#strong[#text("amateur bojan vasiljevic")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("How to find factors of 2 almost primes?")#linebreak()#text(" N=a*b")

#text("We know that digit sum of N = digit sum of a * digit sum of b")#linebreak()#text(" digit sum arithmetic: ")#link("http://www.applet-magic.com/Digitsum.htm")[#text("http://www.applet-magic.com/Digitsum.htm")]

#text("example: digit sum 341 = digit sum (3+4+1) = 8")#linebreak()#text(" = digit sum (31) * digit sum (11) =4*2=8")

#text("As it shown in the next picture if there exists such N that there is N=a*b (not including that a or b might be 1 and N) than a remainder of mod N with the respect to its position equals N")

#text("see picture and last line of pascal triangle in mod 341 where cell of value 31 is showed in 11s position. 31*11=431")#linebreak()#text(" ")#link("http://img6.imagebanana.com/img/gep2hw2r/desktop1_013.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img6.imagebanana.com/img/gep2hw2r/desktop1_013.png")[Original image]]]]

#text("so the algorithm for finding factors is very similiar to aks")

#text("We have mod N. Diferrence here is that aditional mod (in aks is mod (x to the power of r) -1 ) is mod 9 (digit sum equivalence). So binomial quoeficent in mod N and then (mod N * position) mod 9")

#text("And at last we check those cells with the respect of their position.")

#text("Example")#linebreak()#text(" For 341 we check all the cells where (value*position) mod 9=8 ( because digit sum(341)=8)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bv")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-109922")[#strong[#text("amateur bv")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("Here is the case picture for number 341 where pascal triangle is in mod 341, so we look at line 341 all cells where (cell value * cell position) mod 9 = 8.")

#link("http://img6.imagebanana.com/img/l3vwotir/desktop1_026.png")[#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://i0.wp.com/img6.imagebanana.com/img/l3vwotir/desktop1_026.png")[Original image]]]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bv")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-109978")[#strong[#text("bv")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2011")])]

#text("Now im interested in digt sum for binomial coefficients…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63af298ee7fbd18323a0badc3cafc52d6820b69f76fd20c9eb80327c165661b1-02e7e836f799b1304855789f9aae798a443bbdb56a6247a4bc3bf527eb34eda3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amateur bv")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-130819")[#strong[#text("amateur bv")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2012")])]

#text("An Algorithm For Factoring Integers that uses method very similar to AKS.")

#text("They say asymptotic computational complexity of their method is unknown!?…..")

#link("http://www.google.si/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=0CBsQFjAA&url=http%3A%2F%2Feprint.iacr.org%2F2012%2F097.pdf&ei=laFOT77KLIresgbXh7C7Dw&usg=AFQjCNGIlesJ5E6NVf3Bu2wyOYErxB-lAA")[#text("http://www.google.si/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&ved=0CBsQFjAA&url=http%3A%2F%2Feprint.iacr.org%2F2012%2F097.pdf&ei=laFOT77KLIresgbXh7C7Dw&usg=AFQjCNGIlesJ5E6NVf3Bu2wyOYErxB-lAA")]

#text("An Algorithm For Factoring Integers")#linebreak()#text(" Yingpu Deng and Yanbin Pan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-254002")[#strong[#text("Number Theory: Lecture 22 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2013")]

#text("[…] (The Higher Arithmetic) both have material on pseudoprimes and primality testing. Terry Tao has a blog post about the AKS primality test, with various links to further reading. Andrew Granville wrote an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-472428")[#strong[#text("Blog 2 – Algorithms – Site Title")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2016")]

#text("[…] Tao, Terence. “The AKS Primality Test.” Whtats New. WordPress, 23 Feb. 2011. Web. 19 Sept. 2016. ")#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")[#text("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-474374")[#strong[#text("Blog 6-Mathematics and Computer Science – Site Title")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")]

#text("[…] Tao, Terence. “The AKS Primality Test.” Whtats New. WordPress, 23 Feb. 2011. Web. 19 Sept. 2016. ")#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")[#text("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbf8ff20e321b0ea5594951899e6481733afcdeb08d64d0905f7e887757332fa-51181b2afaf9e39f31151ec8c7465aa9958ccac25cfa81feee59397da0f83359.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonowski")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-550835")[#strong[#text("anonowski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("“[…] where {\\phi_m: F \\rightarrow F} is the ring homomorphism that sends {X} to {X^m}.”")#linebreak()#text(" How do we know that this gives a well defined ring homomorphism?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-550874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2020")])]

#text("Ah, one needs to specify that ")#mi("m")#text(" is coprime to ")#mi("r")#text(", so that ")#mi("X^m")#text(" is also a primitive ")#mi("r^{th}")#text(" root of unity. I’ve added this to the post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8255d30e5d521db7b37c9b38ffef353179a52cf43092ae6184a4433805d7375b-a1c14b386e28f74012138a384c2d583e4e52e8407a6a4419680adebfddeeeb65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-554045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2020")])]

#text("Can we tell primality of (x+1)(x+2)-x when x is an integer?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-640400")[#strong[#text("Gautam Tripathi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2022")]

#text("Regarding this comment…")

#text("“But if {n} is divisible by some smaller prime {p}, then by setting {i} equal to the largest power of {p} that divides {n}, one sees that {\\binom{n}{i}} is not divisible by enough powers of {p} to be divisible by {n}, a contradiction.”")

#text("Isn’t setting {i} to any prime factor of {n} sufficient to show that {\\binom{n}{i}} is not divisible by {n}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/11/the-aks-primality-test/#comment-682324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2023")])]

#text("I think so too, since ")#mi("{n \\choose p}")#text(" is nonzero modulo ")#mi("n")#text(": if you set ")#mi("i")#text(" equal to ")#mi("p")#text(", then the binomial fraction ")#mi("{n \\choose p}")#text(" is divisible by at most ")#mi("p^{j-1}")#text(", where ")#mi("j")#text(" is the largest exponent of ")#mi("p")#text(" in the factorisation of ")#mi("n")
]
]
