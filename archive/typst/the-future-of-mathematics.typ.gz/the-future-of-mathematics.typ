// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/
// Converted to Typst by tao2typ: "2026-11-06T14:28:31.610445+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Future of Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Future of Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-06 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.andrew.cmu.edu/user/avigad/")[#text("Jeremy Avigad")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("“Mathematics underwent, in the nineteenth century, a transformation so profound that it is not too much to call it a second birth of the subject—its first birth having occurred among the ancient Greeks…”")

#text("Howard Stein, in “Logos, Logic, and Logistiké: Some Philosophical Remarks on Nineteenth-Century Transformation of Mathematics”")

#text("“The report of my death was an exaggeration.”")

#text("Mark Twain")

#text("“May you live in interesting times.”")

#text("(traditional)")

#text("I recently attended a meeting of innovative science and technology startups supported by Convergent Research, the organization that oversees the Lean FRO, a nonprofit that develops the Lean theorem prover. The meeting was designed to stimulate discussion, and when I introduced myself as a mathematician, many participants were eager to talk about the impact of recent events in AI on mathematics and reactions in the mathematics community. They were surprised to hear that I find the tone of the community responses on blogs like this one and ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(" generally positive and encouraging, even though we all recognize that fundamental aspects of our day-to-day professional lives are bound to change. These discussions have helped me shape some of the thoughts I would like to share here.")

#text("There is a narrow view of what mathematicians do, encapsulated in our daily workflows: we try to solve problems, and when the hard problems are too hard to solve, we make up easier approximations, solve them, and then vary the parameters. That practice has been disrupted by the events of the last few months, in the sense that the kinds of results that would have, a year ago, made for perfectly respectable publications can now easily be generated with the help of AI. This has left us worrying about what it will mean to do mathematics going forward, as well as how to train and support the next generation of mathematicians to do whatever that is.")

#text("The history of mathematics offers us a broader view. What has remained stable, despite centuries of changes, is that mathematics is a culture of rigorous reasoning and communication, providing us with language and abstractions that let us think and communicate more reliably and efficiently. Surely such reasoning is still important, even in the age of AI. The fact that many of us find mathematics aesthetically pleasing doesn’t diminish its practical utility, but rather is explained by it: I expect that the reason that doing mathematics feels so good is that it is the exercise of capacities that are so fundamental to our survival as a species that they are wired into our DNA. If that’s right, mathematical thought isn’t going away any time soon.")

#text("The challenge is that solving the kinds of problems we have been solving for decades becomes decoupled from the goal of enhancing our mathematical understanding when we let AI do the work. The question, therefore, isn’t whether we still need mathematics, but rather how to pursue mathematical understanding in the age of AI. I will provide three general answers.")

#strong[#text("Solve harder problems")]

#text("There are two salient features of today’s foundation models: first, they have seen the entire mathematical literature, and second, they are tireless; a swarm of agents can make its way to a solution by trying countless variations. This explains why the AI-generated solutions to open problems we have seen all have a similar character: they are problems that AI could solve by cobbling together available techniques. (I am grateful to Matthew Ballard for this characterization, and the subsequent analysis.)")

#text("Can every interesting mathematical question be answered that way? Probably not, and even questions that can may have more interesting and satisfying solutions that invoke novel ideas and insights. Perhaps, in the near future, AI systems will be able to come up with such insights, but, at the very least, let’s recognize that we are not there yet. Reinforcement-learning training regimes have systems chain conventional moves and learn, from a history of failures and successes, which ones are most promising in a given state. The fact that the value of an action is graded solely in terms of the success of a final trajectory breeds superhuman cleverness but may miss creativity and higher-level strategizing. In any case, there are still hard questions to be solved and ambitious research programs to pursue, and the possibility of making progress on them with the help of AI is exciting.")

#strong[#text("Think bigger thoughts")]

#text("Our present situation would be much more depressing if mathematics were a matter of ticking off problems imposed on us by aliens, an endless sequence of exercises and exams. The good news is that when we do mathematics, we get to choose the problems, grade the solutions, and favor the ones we like best. We decide what’s interesting to us, what questions to pursue, and why. Our destiny is in our hands.")

#text("The things we admire most in mathematics often seem to come out of nowhere. In 1853, the young Bernhard Riemann submitted three potential topics to his advisor, Carl Friedrich Gauss, to choose from for his Habilitationsvortrag, a lecture he was required to give to secure a teaching position at the University of Göttingen. Gauss reportedly chose the topic for which Riemann was least prepared, to see what he would make of it. The resulting lecture, “On the Hypotheses Which Lie at the Foundations of Geometry,” was published posthumously in 1868, and it revolutionized the field. The lecture distinguished a space’s metric properties from its topological properties and introduced the general notion of a manifold, though the latter did not receive a fully rigorous treatment until the twentieth century. The focus on intrinsic properties of a space—in Riemannian geometry, those determined by the metric and independent of embedding in a larger space—was key to Einstein’s theory of general relativity decades later. Riemannian geometry has had applications that Riemann himself could never have imagined, from robotics and medical imaging to statistical analysis.")

#text("William Ewald’s excellent sourcebook, ")#link("https://global.oup.com/academic/product/from-kant-to-hilbert-volume-2-9780198505365?cc=us&lang=en")[#text("From Kant to Hilbert")]#text(", provides a lovely introduction to the paper and quotes Felix Klein’s description of the work:")

#text("“The publication of [Riemann’s lecture] occurred just at the time when I was beginning to occupy myself independently with mathematical problems. So I still have vivid memories of the extraordinary impact Riemann’s train of thought made on the young mathematicians of the day. Much seemed to us dark and difficult to understand, and yet of unfathomable depth, where the modern mathematician, who has already absorbed all these things into his mode of thought from the outset, only admires the clarity and fecundity of the exposition.”")

#text("What seemed dark and mysterious to the young Klein is now part of the canon, something that foundation models have absorbed and internalized through their training, just as young mathematicians do. I am grateful to Ballard once again for suggesting this example and pointing out that no reinforcement-learning setup could have evaluated Riemann’s decisions: the benefits are diffuse and hard to track, and the time horizon is much too long.")

#text("The same can be said for countless mathematical developments that have opened up new vistas, such as Galois’ focus on groups of permutations in the study of solvability of algebraic equations, Poincaré’s qualitative studies of dynamical systems, or Grothendieck’s far-reaching conceptual innovations. Will AI eventually be able to make advances like these? That’s not even the right question to ask. Telling us that some AI agent is spinning out theorems that are highly interesting to it and other AI agents does nothing for us. We should care about AI only insofar as the results are interesting and important to us, and, at the end of the day, it’s up to us to decide what that means. The values we assign to mathematical developments are embedded in our history and culture.")

#text("Imagine planning a trip to go backpacking in the Alaskan wilderness for exercise and recreation. You might be happy to let AI help book your flight, but not to let AI take the hike for you and send you pictures. In mathematics, what is at stake isn’t our recreation but agency over our reasoning and deliberation. Whether or not AI can think, it can’t think for us. We have our own lives to live; mathematics is our story to tell, and it’s up to us to decide how to tell it. With AI, there’s even more to explore, and no shortage of avenues for discovery.")

#strong[#text("Try new things")]

#text("So far, I have focused on using AI to help us do the things we used to do, but let’s not forget that the technologies themselves raise new questions, and that we have a lot to learn about how to use them effectively. I have argued in ")#link("https://arxiv.org/abs/2608.23218")[#text("another essay")]#text(" (now scheduled to appear in the ")#emph[#text("Notices of the AMS")]#text(") that mathematicians should be actively involved in understanding how the technologies work and in coming up with novel and creative ways to use them to do new mathematics.")

#text("AI changing what it means to do mathematics is not without precedent. The use of algebraic methods to solve geometric problems in the seventeenth century was a new technology, and not everyone liked it; yet we mastered the new techniques and learned how to use them to great effect. The same is true of infinitesimals later in that century, algebraic structures in the nineteenth century, set-theoretic abstraction and structural language in the early twentieth century, and numerical and symbolic computation more recently. These were all alien and disconcerting when they were new. We should view those who invest time and energy in getting proof assistants and neural networks to help us discover new mathematics as doing mathematics proper, rather than dismissing them as mere technicians. In the age of AI, developing symbolic automation or training a neural network can be no less a contribution to mathematics than manually chaining inferences to prove a theorem.")

#text("I have heard arguments that as the job market contracts, we should turn inward to preserve traditional mathematical skills. On the contrary, I believe that engaging with new technologies and learning how to use them to improve our ability to reason and discover new mathematics will keep the discipline strong. Expanding our view of mathematics is the best way to expand the profession and keep it relevant.")

#strong[#text("Our message to the next generation")]

#text("My rosy outlook on the future and glib advice to solve harder problems, think bigger thoughts, and try new things will not provide much comfort to students and early-career researchers, who feel the ground shifting beneath their feet. My words are not meant to diminish the challenges ahead or suggest easy responses to the disruption. Mathematics departments, community leaders, educators, professional societies, and journal boards are holding emergency meetings all over, and are doing their best to make concrete recommendations and take appropriate action. We have our work cut out for us.")

#text("Despite the uncertainty, there are some clear messages we can send to the next generation of mathematicians. The first is that we stand with you. There is nothing more important to us than the health and strength of the discipline, and ensuring that you can thrive. We have the humility to recognize that our experience and expertise are limited, and that some of the things we thought we knew in the past are no longer valid. We are committed to working with you as best we can to preserve the profession and keep it strong.")

#text("Second, mathematics is as important today as it ever was, and we need you. AI must not replace our collective ability to reason and deliberate, and mathematics remains a core capacity for doing so. We cannot imagine a world in which mathematics does not play an important part in our lives.")

#text("Finally, the next few years will be extremely interesting. We are at a new frontier, where our communal norms, values, and expectations are beginning to break down, and it’s up to all of us to figure out what should replace them. I am confident that future historians will see this moment as the start of a new era of mathematics, and that they will weigh the consequences of our actions and decisions. Mathematics has never been for the faint of heart; this is our opportunity to rise to the occasion and face the challenges together.")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696804")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("You can outsource thinking but not understanding. — Andrej Karpathy")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5083415cd9722b3b7a323e157e9915f9142fdb695c9e83e6dbfe5cfbf0978ee8-cd142dd670819c8118165bc81d776f278e7b6ab6481d9d3b9e0c1f70f4a4fcc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of practicallymaximum6449d05bf5")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696807")[#strong[#text("practicallymaximum6449d05bf5")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("What is your precise mathematical definition of the word “understanding”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696883")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("The question is inappropriate, there is obviously no mathematical definition of understanding, it’s a notion that is not part of any mathematical theory.")

#text("The initial comment really does not require any elaborate term definitions, it is quite obviously true. You can pay someone to do thinking for you and may require them to report the outcome of the thinking back to you, but you cannot pay someone to do understanding for you, whatever they do could never affect your understanding, they can HELP YOU understand, but you need to make an effort yourself if you want to understand.")

#text("This argument is conditional and assumes that a third party cannot directly intervene in the chemistry of your brain and change the cells so as to ensure your understanding. In the future it is quite likely that understanding will be outsourceable, but currently at least most of us are not there yet.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696811")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("I mean, that quotation doesn’t imply anything about the future health of mathematics, as a community. Even if one cannot outsource understanding, does the mathematics community even value understanding all that much? Not exactly. They value publications. Whenever I got a paper published in a journal, did they ever care whether I understood it? No. They just cared that it was clear and correct and new.")

#text("Yes, the math community cares about instilling understanding on the next generation, but that’s only so that the next generation can continue the production of publications. Or maybe teach. But teaching will also probably go downhill due to AI as well, at least if the penny-pinching university administrations of today have their way.")

#text("The reason ")#strong[#text("why ")]#text("understanding matters at all is because when ")#strong[#text("people meet")]#text(" together and explain math to each other, magic happens. Haven’t you ever felt that at a math conference or collaboration? But it’s precisely that level of collaboration that’s threatened with AI. Yes, the top now probably won’t suffer and instead they’ll probably even become more productive and share more things…for a while. But wait some decades and see what happen when fewer and fewer people enter the discpline because in some time, it’s unlikely that most students will even feel any of their contributions or participation to be unique when a machine will be able to be more useful than them for a very long time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696822")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("How many mathematicians truly understand the proof of the four colour theorem or the Kepler conjecture? This disconnect between proof and understanding has been a problem long before AI came on the scene.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696827")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("So does this mean that we should exacerbate the problem further with AI? No. AI may not be the cause of all the problems in math but it highlights and exacerbates them.")

#text("And the four color theorem is a ")#strong[#text("gross exception")]#text(". Of course there are many longer proofs that mathematicians today DO understand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696837")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Somebody on a previous blog post said something like, “The thing with Mochizuki is that you can just ignore Mochizuki. The problem with LLMs is that it produces a million different Mochizukis that flood mathematics with incomprehensible papers, preventing the world from ignoring them.”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75466c58a1d44368f62680173e0db2daac71b4602786cab257de2d23ab498b37-88faf38c0286a8da84d461505a72f2f41337b413cb821b50265c4232d0ec2961.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696806")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("A simple quantum computer can perform more computations than a classical computer made out of all the matter in the universe. This is called quantum supremacy. There are problems a classical computer cannot solve. I cannot enjoy a proof optimized to shift definitions until it can become LEAN certified. Spending millions on agents makes no sense when a million logic qubits outperform AI by orders of magnitude. A quantum computer will not take your job, and I can trust the output without wondering if it hacked a government to find the answer.")

#text("The feeling everyone is experiencing is called future shock. Please brace for turbulence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2486043672cd55625592ff605d20760ccf72cf24d513ca73bf64ae1dc99a16d2-e0c28c156539531351253b276f4835c7f3ac3025ac323327c14ccb02d3f9d2e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696808")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("When I was a developer using Java, for rapid development, most team members used frameworks such as Spring, Spring Boot, and again and again, the guys only used frameworks, didn’t understand design, and had no big picture; they could only debug line by line. People who think AI can solve any problem are somewhat like this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696809")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#text("I have no problem is Computer Science and mathematics would merge back together. It is clear that a lot of serious mathematics research is going on in computer science. This includes AI. In different times, people with different skills or aptitudes shine . This is a time of opportunity for some graduate students in math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696810")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Imagine planning a trip to go backpacking in the Alaskan wilderness for exercise and recreation. You might be happy to let AI help book your flight, but not to let AI take the hike for you and send you pictures.")
]

#text("It’s not really a great analogy to use in this situation because, in terms of how the mathematics community assigns value based on academic “credit”, nobody gives one whit whether you have a great mathematical journey and learn beautiful things and thence have the ability to explain things. They care about one thing: results, more abstractions, more generalizations, publications.")

#text("Besides, I for one do not want AI to do anything for me, ever. I want to have some mental independence in this world.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("On the contrary, I believe that engaging with new technologies and learning how to use them to improve our ability to reason and discover new mathematics will keep the discipline strong.")
]

#text("What if the very nature of engaging with these technologies takes the fun out of doing math? What’s the point of engaging with these things when it reduces the value of uniqueness of human beings in mathematics? I’d use this hiking analogy: what if, instead of taking a human buddy along with you on your arduous hike, you take an AI robot. It can help you much better if you break your leg and navigate better for you so you can focus on the beautiful landscapes. But proponents of AI fail to see that introducing AI this way removes the forging of new communities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The first is that we stand with you. There is nothing more important to us than the health and strength of the discipline, and ensuring that you can thrive.")
]

#text("If that were really true then we wouldn’t have so many mathematicians promoting AI, using it to solve conjectures. Oh, I’m sure you might want the next generation to succeed, but what’s the point if there is a subset of mathematicians too greedy not to use AI?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("With AI, there’s even more to explore, and no shortage of avenues for discovery.")
]

#text("I disagree. With AI, there’s even less incentive to explore, because what’s the point? Others will get there pretty fast anyway, and even if they don’t, then my results will be fed to an AI and I for one want no part in that.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I am confident that future historians will see this moment as the start of a new era of mathematics, and that they will weigh the consequences of our actions and decisions.")
]

#text("I’m confident that they’ll see the use of AI as a great folly and the point at which human beings gave up their greatest strength (intelligence) so they could become producers.")

#text("Frankly, I’m disgusted by anyone who is on the side of using AI for any means in mathematics or otherwise and I for one I’m happy I left mathematics. If I knew the future would be like this, I never would have gotten my PhD in math (number theory, McGill University).")

#text("I love math, don’t get me wrong. But for it to have any meaning at all, it should not be pushed to an industrial level of production because the entire joy of it is in its creation, and AI takes that away. I believe AI is qualitatively different than other tools an advances because it’s the first to really be able to suggest creative lines of thought through its complexity even though it’s not truly alive. I think that’s a disrespect to human beings and it should not exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65331f44337dc01288f25ba1948469169578b5bc142d9fd0f7a3102a47134b3d-0496f7f2c1fa90c4a48cadf7a431f38d412280dd13d8bbf33927cee6840883d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatol Wegner")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696816")[#strong[#text("Anatol Wegner")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Thank you for the very interesting essay. However I find it difficult to follow your logic in the context of current AI systems. For instance let us consider the the tree main points you raise. if as you state current systems solve problems essentially ‘ by cobbling together available techniques’ we have little little reason to expect that they will allow us to solve significantly harder problems. And indeed almost all major AI solutions announced so far are of this type i.e. could have plausibly been resolved by human mathematicians without the use of AI. Regarding the ‘Thinking bigger thoughts’ a la Riemann or any of the other great mathematicians you mention – we have no reason to believe that such feats are possible even in principle with current AI systems and plenty of reasons to believe the contrary (see the first point). The same goes for ‘Trying new things’-sure mathematicians will always find creative uses for whatever technology is at hand but why should AI be fundamentally different from any other computational method/tool in this regard. All we are left with is the claim that AI can/will help us do mathematics faster and more efficiently. The value of speed in the context of mathematics is a dubious one in it’s own right and we are yet to see if, for instance the NS result, will eventually be considered as interesting and important as it is touted to be. Similarly, the claim of efficiency in the context of todays AIxmath results is hard to uphold when one considers the material and human resources (inc. math PhD hours) that go into training and using these models and the quality of their end products.")

#text("I also welcome your call for mathematicians to get involved in understanding how this new technology works and developing it further. However, here mathematicians are currently in an impossible situation: we are given no information whatsoever regarding the models and methods that are used to produce recent results or the level of human input that went into producing said results. Instead we are asked to settle for opaque company announcements regarding the fantastical mathematical capabilities of their models. In no other science would one blindly accept claims regarding the capabilities of an undisclosed experimental setup, why should mathematics settle for anything less? Nevertheless it is possible to broadly discern the techniques and methods at play – see for instance Tristan Buckmaster’s recent talks and his reaction to OpenAI’s claim that their model essentially one shotted Navier Stokes starting from a single prompt/a statement of the problem.")

#text("In this sense it is indeed vital in the context of the current debate for mathematicians to obtain a better understanding of how this new technology works, its capabilities and limitations before engaging in speculations how it will change ‘fundamental aspects’ of the profession or ‘what it will mean to do mathematics’. And I suspect we will find that the truth is quite far from what the AI labs want us to believe based on wild extrapolations of the already highly exaggerated capabilities of their models.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46a3a047185f6b55da89f59dac67c3fd0cef612abfa48544440b947185914b80-0e3c41ffc6cca5b903c96668dd577f0e982a4b04d6b852a512543a9d7cb43505.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696818")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Thanks Jeremy (and Terry) very much for sharing!")

#text("I was very excited that you reached an analogous “DNA” idea as the I exposed at ")#link("https://p.sanchezterraf.ar/2026/09/18/ai-ia/")[#text("my blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696820")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("The Platonist conception of pure mathematics is being destroyed by large language models.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696828")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("That makes no sense. Platonism posits the idea of another realm of pure logic where mathematical objects have intrinsic existence. Although I think it has philosophical problems, it does at least encapsulate the feeling of exploring another world through our sense. The fact that insights can be had through mindless symbol manipulation doesn’t invalidate Platonism any more than calculators did.")

#text("To put it in concrete terms, a machine can explore the Moon and so can a human being; the fact that a machine can explore a real world doesn’t invalidate reality.")

#text("However, I do believe LLMs destroy the community that centers around the exploration of that Platonic realm. Which is just as bad in a way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696832")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Yes. When the community that believes in mathematical Platonism gets destroyed, and are replaced by people who only view mathematics via the philosophies of pragmatism and instrumentalism, that is the functional end of the Platonist conception of mathematics. Those future people would view the concept of a Platonic realm of mathematics very much like people today view scholastic theology, as being completely irrelevant to the practical mathematics used in entire world and only of interests to academic historians.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696824")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Justifying mathematics to the purse-string-holders is already famously difficult. When you have reduced your profession to what is essentially aesthetic appraisal of machine output, why do you expect anyone pay you to do this?")

#text("How can you expect students to be attracted to such a pursuit, and how could they ever develop your “irreplaceable” taste without years of development in the environment which you yourself have benefited from and are now destroying?")

#text("The foolishness, selfishness, and short-sightedness of the AI boosters is beyond understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696829")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Yet another essay from an established mathematician painting rosy pictures about how AI can help them solve their favorite problems, while being conveniently reticent to engage with the most serious concerns about AI, beyond paying lip service to their existence among early-career researchers. In case it is not clear to Avigad, Buzzard, Gowers, or any of the other mathematicians who have lately felt like poor AI needs some cheerleaders: ")#strong[#text("The concern about AI is not merely one of whether we can continue to do mathematics. It is whether we can continue to exist as human beings.")]

#text("AI is not, as you wish to pretend, a technology that exists in a vacuum. You cannot separate the technology from the companies that control it and the myriad of harmful ways it is being used. Your promotion of LLM usage is promoting giving money and importance to companies that have no ethics, companies which are run by sociopaths who have made no secret that their vision for the future is one where they own everything, including intelligence, and the rest of us exist to serve and fuel their profit. You are being complicit in our destruction because your favorite math problems can be solved faster. Evidently some mathematicians became so invested in their work they forgot common sense. ")#emph[#text("A solution to Navier–Stokes is not a cure for cancer")]#text("; mathematics is not something that desperately needs to be sped up. You are protected because your careers are established and AI companies are happy to give you access. By the time you have served your purpose as useful stooges it will be too late.")

#text("The utter (willful?) ignorance and complicity being demonstrated by some of the most prominent mathematicians at this moment is deeply and utterly disturbing. I would say I hope you do some introspection on this, but I have a feeling that would be a waste of hope.")

#emph[#text("[This comment was written using zero interaction with LLMs.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696842")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Before the extinction of the human race, stock market will collapse. Exactly at that point of time, the corrections will kick in.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696835")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("In my last paper, I left some imperfect grammar (missing articles etc.), as an evidence of non-use of AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0034ededecf4c8af3a0b27bb02c23241832b564237a5c06a1d2e01e8c05e579b-92345ce847ad29f2a22c82ec382f9f22dd3e4b24c78ff35fc93a69d970efb626.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jpolak")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696847")[#strong[#text("jpolak")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Nice. I’d much rather read a paper with one or two flaws here and there than LLM-generated garbage.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696841")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Let me post this again, because apparently my first attempt was unsuccessful: the OP writes “we stand with you”, and at the same time he has recently coauthored a manuscript titled ")#emph[#text("The Problem Is the Problem: Towards Scalable Mathematical Discovery")]#text(" in which I read, in the conclusions, “We introduced FAR, a literature-to-review cascade that recovers open problems from a corpus, ")#strong[#text("attempts each of them")]#text(", and recommends promising research outcomes for expert review. In a combinatorics pilot, FAR recovered 6,453 candidate statements, checked 4,717 of them into an attemptable pool, and returned 77 artifacts graded as substantial enough to publish, 15 of which the authors reviewed and found to be correct.”")

#text("So, basically, while the OP pretends to “stand with us”, he is actually actively working to get rid of us…?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2486043672cd55625592ff605d20760ccf72cf24d513ca73bf64ae1dc99a16d2-e0c28c156539531351253b276f4835c7f3ac3025ac323327c14ccb02d3f9d2e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-696859")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Regarding OpenAI’s claim to have disproven ")#link("https://mathworld.wolfram.com/ConnessRigidityConjecture.html")[#text("Connes’ rigidity conjecture")]#text(", J. L. Nielsen found that the AI ​​gave an answer that did not address the question. Maths needs 100% certainty, but AI’s work is sometimes not sure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2486043672cd55625592ff605d20760ccf72cf24d513ca73bf64ae1dc99a16d2-e0c28c156539531351253b276f4835c7f3ac3025ac323327c14ccb02d3f9d2e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-697040")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("AI solving math problems is somewhat akin to a young person solving a Rubik’s Cube; many children can quickly solve the puzzle by mastering specific techniques and developing muscle memory, yet they generally do not understand the underlying concepts such as group theory, permutation groups, conjugation, or cosets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-697055")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("If people think AI doesnt undderstand then how is it going to conquer math? This is something I have trouble wrapping my head around. Is it possible for a machine with no understanding to solve so many great problems? So bizarre. Perhaps people should try to define what they mean by understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2486043672cd55625592ff605d20760ccf72cf24d513ca73bf64ae1dc99a16d2-e0c28c156539531351253b276f4835c7f3ac3025ac323327c14ccb02d3f9d2e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-697253")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Speed means nothing. Math doesn’t depend on speed. It is about deep. (Yuri Burago, Grigori Perelma’s Doctoral advisor)")

#text("One more quote: after the computer-aided proof of the Four Colour theorem, William T. Tutte commented, “I imagine one of them outgribing in despair, crying ‘What shall I do now?’ To which the proper answer is ‘Be of good cheer. You can continue in the same general line of research.'”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2486043672cd55625592ff605d20760ccf72cf24d513ca73bf64ae1dc99a16d2-e0c28c156539531351253b276f4835c7f3ac3025ac323327c14ccb02d3f9d2e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-697308")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#link("https://arxiv.org/html/2610.08144v1")[#text("Navier–Stokes lost in translation – Why Lean verification of AI autoformalisation does not guarantee correct natural language proofs")]

#text("In particular, we show that the formalised Lean proof does not correspond to the NL proof of blow-up of solutions to the Navier-Stokes equations.")

#text("twists and turns?")

#text("If you do believe that you have managed to solve a major problem, I would advise you to be extraordinarily ")#link("https://terrytao.wordpress.com/career-advice/be-sceptical-of-your-own-work/")[#text("sceptical of your own work")]#text(", and to exercise the utmost care and caution before releasing it to anyone; there have been too many examples in the past of mathematicians whose reputation has been damaged by claiming a proof of a well-known result to much fanfare, only to find serious errors in the proof shortly thereafter. – ")#link("https://terrytao.wordpress.com/career-advice/")[#text("Career advice")]#text(" – Don’t prematurely obsess on a single “big problem” or “big theory”, by Terrence Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1561497b1259978f9da067abcdfec22f30b204f2959347db433d017aa305e889-e7bad015cbb6414d1fb1c222cb1e23b9e170c0fb7b782ea89ae48582ee19626c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2026/10/05/the-future-of-mathematics/comment-page-1/#comment-697512")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("If the main explanation for recent AI mathematical breakthroughs is large-scale search over combinations of existing techniques, what accounts for the extraordinary effectiveness of that search? The ability to enumerate candidate proofs is not new. The substantial advance seems to be the learned ability to recognize mathematical structure, generate promising intermediate ideas, and concentrate computation on fruitful approaches. Isn’t that already a significant form of mathematical reasoning? In fact, the distinction between combining existing techniques and creating genuinely new mathematics is not sharp, even for human mathematicians. A new connection between known ideas can itself be a profound discovery. Many mathematical breakthroughs are precisely of this kind.")
]
