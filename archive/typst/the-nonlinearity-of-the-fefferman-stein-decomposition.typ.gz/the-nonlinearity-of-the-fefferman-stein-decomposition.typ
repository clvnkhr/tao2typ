// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/
// Converted to Typst by tao2typ: "2026-10-14T10:49:14.563896+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The nonlinearity of the Fefferman-Stein decomposition", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The nonlinearity of the Fefferman-Stein decomposition")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/")[#text("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=447953")[#text("decomposition theorem of Fefferman and Stein")]#text(" shows that every function ")#mi("{f \\in \\mathrm{BMO}({\\bf R}^n)}")#text(" of ")#link("https://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(" can be decomposed in the form ")#metadata(none) <tao-4379c213eecddd8b2d89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("f = f_0 + \\sum_{i=1}^n R_i f_i")]]



#text(" modulo constants, for some ")#mi("{f_0,f_1,\\dots,f_n \\in L^\\infty({\\bf R}^n)}")#text(", where ")#tao-math("{R_i := \\left|\\nabla\\right|^{-1} \\partial_i}", block: false)#text(" are the ")#link("https://en.wikipedia.org/wiki/Riesz_transform")[#text("Riesz transforms")]#text(". A technical note here a function in BMO is defined only up to constants (as well as up to the usual almost everywhere equivalence); related to this, if ")#mi("{f_i}")#text(" is an ")#mi("{L^\\infty({\\bf R}^n)}")#text(" function, then the Riesz transform ")#mi("{R_i f_i}")#text(" is well defined as an element of ")#mi("{\\mathrm{BMO}({\\bf R}^n)}")#text(", but is also only defined up to constants and almost everywhere equivalence.")

#text("The original proof of Fefferman and Stein was indirect (relying for instance on the Hahn-Banach theorem). A constructive proof was later given ")#link("http://www.ams.org/mathscinet-getitem?mr=666111")[#text("by Uchiyama")]#text(", and was in fact the topic of ")#link("https://terrytao.wordpress.com/2007/02/23/uchiyamas-constructive-proof-of-the-fefferman-stein-decomposition/")[#text("the second post on this blog")]#text(". A notable feature of Uchiyama’s argument is that the construction is quite nonlinear; the vector-valued function ")#mi("{(f_0,f_1,\\dots,f_n)}")#text(" is defined to take values on a sphere, and the iterative construction to build these functions from ")#mi("{f}")#text(" involves repeatedly projecting a potential approximant to this function to the sphere (also, the high-frequency components of this approximant are constructed in a manner that depends nonlinearly on the low-frequency components, which is a type of technique that has become increasingly common in analysis and PDE in recent years).")

#text("It is natural to ask whether the Fefferman-Stein decomposition ")#link(<tao-4379c213eecddd8b2d89>)[#text("(1)")]#text(" can be made linear in ")#mi("{f}")#text(", in the sense that each of the ")#mi("{f_i, i=0,\\dots,n}")#text(" depend linearly on ")#mi("{f}")#text(". Strictly speaking this is easily accomplished using the axiom of choice: take a ")#link("https://en.wikipedia.org/wiki/Basis_(linear_algebra)#Hamel_basis")[#text("Hamel basis")]#text(" of ")#mi("{\\mathrm{BMO}({\\bf R}^n)}")#text(", choose a decomposition ")#link(<tao-4379c213eecddd8b2d89>)[#text("(1)")]#text(" for each element of this basis, and then extend linearly to all finite linear combinations of these basis functions, which then cover ")#mi("{\\mathrm{BMO}({\\bf R}^n)}")#text(" by definition of Hamel basis. But these linear operations have no reason to be continuous as a map from ")#mi("{\\mathrm{BMO}({\\bf R}^n)}")#text(" to ")#mi("{L^\\infty({\\bf R}^n)}")#text(". So the correct question is whether the decomposition can be made ")#emph[#text("continuously linear")]#text(" (or equivalently, boundedly linear) in ")#mi("{f}")#text(", that is to say whether there exist continuous linear transformations ")#mi("{T_i: \\mathrm{BMO}({\\bf R}^n) \\rightarrow L^\\infty({\\bf R}^n)}")#text(" such that ")#metadata(none) <tao-95fdb78e45be9e36e7fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("f = T_0 f + \\sum_{i=1}^n R_i T_i f")]]



#text(" modulo constants for all ")#mi("{f \\in \\mathrm{BMO}({\\bf R}^n)}")#text(". Note from the open mapping theorem that one can choose the functions ")#mi("{f_0,\\dots,f_n}")#text(" to depend in a bounded fashion on ")#mi("{f}")#text(" (thus ")#tao-math("{\\left\\|f_i\\right\\|_{L^\\infty} \\leq C \\left\\|f\\right\\|_{BMO}}", block: false)#text(" for some constant ")#mi("{C}")#text(", however the open mapping theorem does not guarantee linearity. Using a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=47910")[#text("result of Bartle and Graves")]#text(" one can also make the ")#mi("{f_i}")#text(" depend continuously on ")#mi("{f}")#text(", but again the dependence is not guaranteed to be linear.")

#text("It is generally accepted folklore that continuous linear dependence is known to be impossible, but I had difficulty recently tracking down an explicit proof of this assertion in the literature (if anyone knows of a reference, I would be glad to know of it). The closest I found was a proof of a similar statement in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1949165")[#text("this paper of Bourgain and Brezis")]#text(", which I was able to adapt to establish the current claim. The basic idea is to average over the symmetries of the decomposition, which in the case of ")#link(<tao-4379c213eecddd8b2d89>)[#text("(1)")]#text(" are translation invariance, rotation invariance, and dilation invariance. This effectively makes the operators ")#mi("{T_0,T_1,\\dots,T_n}")#text(" invariant under all these symmetries, which forces them to themselves be linear combinations of the identity and Riesz transform operators; however, no such non-trivial linear combination maps ")#mi("{\\mathrm{BMO}}")#text(" to ")#mi("{L^\\infty}")#text(", and the claim follows. Formal details of this argument (which we phrase in a dual form in order to avoid some technicalities) appear below the fold.")

#metadata(none) <tao-526aab3c9bda7e57bcc0>

#heading(level: 1)[#strong[#text(" — 1. Formal argument — ")]]

#text("Suppose for contradiction that we have bounded linear maps ")#mi("{T_0,T_1,\\dots,T_n: \\mathrm{BMO}({\\bf R}^n) \\rightarrow L^\\infty({\\bf R}^n)}")#text(" such that ")#link(<tao-95fdb78e45be9e36e7fd>)[#text("(2)")]#text(" holds for all ")#mi("{f \\in \\mathrm{BMO}({\\bf R}^n)}")#text(". We convert this to an assertion about bilinear forms. Let ")#mi("{\\mathcal{S}({\\bf R}^n)}")#text(" be the space of Schwartz functions, and let ")#mi("{\\mathcal{S}({\\bf R}^n)_0}")#text(" be codimension one subspace of Schwarz functions of integral zero. We define the bilinear forms")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0: \\mathcal{S}({\\bf R}^n) \\times \\mathcal{S}({\\bf R}^n) \\rightarrow {\\bf R}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1: \\mathcal{S}({\\bf R}^n) \\times \\mathcal{S}({\\bf R}^n)^n_0 \\rightarrow {\\bf R}")]]

#text("by the formulae")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0( f, g_0 ) := \\int_{{\\bf R}^n} (T_0 f) g_0\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1( f, (g_1,\\dots,g_n) ) := \\sum_{i=1}^n \\int_{{\\bf R}^n} (T_i f) g_i\\ dx.")]]

#text("From ")#link(<tao-95fdb78e45be9e36e7fd>)[#text("(2)")]#text(" and integration by parts we have the identity ")#metadata(none) <tao-4790f26c96f097d31e26>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\Lambda_0(f, g) - \\Lambda_1(f, Rg) = \\int_{{\\bf R}^n} f g\\ dx")]]



#text(" for all ")#mi("{f,g \\in \\mathcal{S}({\\bf R}^n)}")#text(" with ")#mi("{\\hat g}")#text(" vanishing near the origin (so that ")#mi("{Rg}")#text(" is also Schwartz), where ")#tao-math("{Rg := (R_1 g, \\dots, R_n g) = \\left|\\nabla\\right|^{-1} \\nabla g}", block: false)#text(" is the vector Riesz transform. Meanwhile, from the boundedness of ")#mi("{T_0,T_1,\\dots,T_n}")#text(" and Hölder’s inequality we have the bounds ")#metadata(none) <tao-871fac543aade029764e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|\\Lambda_0(f,g_0)\\right| \\lesssim \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^n)} \\left\\|g_0\\right\\|_{L^1({\\bf R}^n)}", block: true)]]



#text(" and ")#metadata(none) <tao-7b5951eb094812064306>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\Lambda_1(f,\\vec g)\\right| \\lesssim \\left\\|f\\right\\|_{\\mathrm{BMO}({\\bf R}^n)} \\left\\|R \\cdot \\vec g\\right\\|_{L^1({\\bf R}^n)}", block: true)]]



#text(" for any ")#mi("{f, g_0 \\in \\mathcal{S}({\\bf R}^n)}")#text(" and ")#mi("{\\vec g \\in \\mathcal{S}({\\bf R}^n)^n_0}")#text(", where ")#mi("{R \\cdot (g_1,\\dots, g_n) := R_1 g_1 + \\dots + R_n g_n}")#text(" is the covector Riesz transform, thus ")#tao-math("{R \\cdot \\vec g = \\left|\\nabla\\right|^{-1} \\nabla \\cdot g}", block: false)#text(". (Note that ")#mi("{R \\cdot \\vec g}")#text(" is indeed in ")#mi("{L^1}")#text(" due to the hypothesis that ")#mi("{\\vec g}")#text(" has integral zero.")

#text("We will show that there are no bilinear forms ")#mi("{\\Lambda_0, \\Lambda_1}")#text(" obeying the identity ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(" (for the indicated range of ")#mi("{f,g}")#text(") and the bounds ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(" (for the indicated range of ")#mi("{f,g_0, \\vec g}")#text("), which will give the claim.")

#text("Now we exploit symmetries of the hypotheses ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(". For any ")#mi("{h \\in {\\bf R}^n}")#text(", let ")#mi("{\\tau_h: \\mathcal{S}({\\bf R}^n) \\rightarrow \\mathcal{S}({\\bf R}^n)}")#text(" be the translation operator")

#align(center)[#tao-fit-display[#mitex("\\tau_h f(x) := f(x-h).")]]

#text("This operator also acts on vector-valued functions ")#mi("{\\mathcal{S}({\\bf R}^n)^n}")#text(" by acting on each component separately. The translation operators are uniformly bounded on ")#mi("{\\mathrm{BMO}}")#text(" and ")#mi("{L^1}")#text(", and commute with Riesz transforms and preserve Lebesgue measure ")#mi("{dx}")#text(". As a consequence, if the forms ")#mi("{\\Lambda_0,\\Lambda_1}")#text(" obey the hypotheses ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(", then so do the translated forms")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0^h(f,g_0) := \\Lambda_0( \\tau_h f, \\tau_h g_0)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1^h(f,\\vec g) := \\Lambda_1( \\tau_h f, \\tau_h \\vec g)")]]

#text("with implied constants in ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(" uniform in ")#mi("{h}")#text(".")

#text("On the other hand, ")#mi("{{\\bf R}^n}")#text(", being abelian, is an ")#link("https://en.wikipedia.org/wiki/Amenable_group")[#text("amenable group")]#text(". Thus, if ")#mi("{\\Lambda_0}")#text(", ")#mi("{\\Lambda_1}")#text(" obey the hypotheses ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(", then so do the means")

#align(center)[#tao-fit-display[#mitex("\\overline{\\Lambda_0}(f,g_0) := \\mu( (\\Lambda_0( \\tau_h f, \\tau_h g_0))_{h \\in {\\bf R}^d} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\overline{\\Lambda_1}(f,\\vec g) := \\mu( (\\Lambda_1( \\tau_h f, \\tau_h \\vec g) )_{h \\in {\\bf R}^d} )")]]

#text("where ")#mi("{\\mu: L^\\infty({\\bf R}^d) \\rightarrow {\\bf R}}")#text(" is an invariant mean of ")#mi("{{\\bf R}^d}")#text(". (Note from ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(" that the quantities ")#mi("{\\Lambda_0( \\tau_h f, \\tau_h g_0)}")#text(", ")#mi("{\\Lambda_1( \\tau_h f, \\tau_h \\vec g)}")#text(" depend continuously on ")#mi("{h}")#text(".) By construction, these new bilinear forms are translation-invariant in the sense that ")#metadata(none) <tao-2b25b7eb660b45d65866>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\Lambda_0(\\tau_h f, \\tau_h g_0) = \\Lambda_0(f, g_0); \\quad \\Lambda_0(\\tau_h f, \\tau_h \\vec g) = \\Lambda_1(f, \\vec g)")]]



#text(" for all ")#mi("{f, g \\in \\mathcal{S}({\\bf R}^n)}")#text(", ")#mi("{\\vec g \\in \\mathcal{S}({\\bf R}^n)^n_0}")#text(", and ")#mi("{h \\in {\\bf R}^n}")#text(". Thus, to show the non-existence of bilinear forms obeying ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(", we may assume without loss of generality that the forms also obey the translation invariance ")#link(<tao-2b25b7eb660b45d65866>)[#text("(6)")]#text(".")

#text("We can argue similarly to assume rotational invariance, provided we apply the rotation correctly to the vector field ")#mi("{\\vec g}")#text(". More precisely, if ")#mi("{U \\in O(n)}")#text(" is any orthogonal matrix (a rotation or reflection), and ")#mi("{\\Lambda_0,\\Lambda_1}")#text(" obey ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(", ")#link(<tao-2b25b7eb660b45d65866>)[#text("(6)")]#text(", then one can check that the rotated forms")

#tao-aligned(keep: true)[


#tao-math("\\Lambda_0^U(f,g_0)  & := \\Lambda_0( f \\circ U^{-1}, g_0 \\circ U^{-1})", block: true)



#tao-math("\\Lambda_1^U(f,\\vec g)  & := \\Lambda_1( f \\circ U^{-1}, U( \\vec g \\circ U^{-1}) )", block: true)
]

#text("also obey these hypotheses (with implied constants uniform in ")#mi("{U}")#text("), a key point being the identity")

#align(center)[#tao-fit-display[#mitex("R \\cdot (U( \\vec g \\circ U^{-1}) ) = (R \\cdot \\vec g) \\cdot U^{-1}")]]

#text("which follows from the chain rule. Being compact, ")#mi("{O(n)}")#text(" is also amenable (indeed one can simply integrate against the probability Haar measure on ")#mi("{O(n)}")#text("), and so by arguing as before we may assume without loss of generality that the bilinear forms ")#mi("{\\Lambda_0,\\Lambda_1}")#text(" obey the rotational invariance ")#metadata(none) <tao-3d776d43c13fba45e1cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Lambda_0( f \\circ U^{-1}, g_0 \\circ U^{-1}) = \\Lambda_0(f,g); \\quad \\Lambda_1( f \\circ U^{-1}, U( \\vec g \\circ U^{-1}) ) = \\Lambda_1(f, \\vec g)")]]



#text(" for all ")#mi("{f, g \\in \\mathcal{S}({\\bf R}^n)}")#text(", ")#mi("{\\vec g \\in \\mathcal{S}({\\bf R}^n)^n_0}")#text(", and ")#mi("{h \\in {\\bf R}^n}")#text(".")

#text("Finally, we impose dilation invariance. For any ")#mi("{\\lambda}")#text(" in the positive real line ")#mi("{{\\bf R}^+ = (0,+\\infty)}")#text(", we define the dilation operator ")#mi("{\\delta_\\lambda: \\mathcal{S}({\\bf R}^n) \\rightarrow \\mathcal{S}({\\bf R}^n)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\delta_\\lambda f(x) := f(x / \\lambda).")]]

#text("The operator ")#mi("{\\delta_\\lambda}")#text(" preserves ")#mi("{\\mathrm{BMO}}")#text(", while ")#mi("{\\lambda^{-n} \\delta_\\lambda}")#text(" preserves ")#mi("{L^1}")#text(". As a consequence, if ")#mi("{\\Lambda_0, \\Lambda_1}")#text(" obey ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(", ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(", ")#link(<tao-7b5951eb094812064306>)[#text("(5)")]#text(", ")#link(<tao-2b25b7eb660b45d65866>)[#text("(6)")]#text(", ")#link(<tao-3d776d43c13fba45e1cf>)[#text("(7)")]#text(", then so do the dilated forms")

#tao-aligned(keep: true)[


#tao-math("\\Lambda_0^\\lambda(f,g_0)  & := \\lambda^{-n} \\Lambda_0( \\delta_\\lambda f, \\delta_\\lambda g_0)", block: true)



#tao-math("\\Lambda_1^U(f,\\vec g)  & := \\lambda^{-n} \\Lambda_1( \\delta_\\lambda f, \\delta_\\lambda \\vec g ),", block: true)
]

#text("with constants uniform in ")#mi("{\\lambda}")#text(". As ")#mi("{{\\bf R}^+}")#text(" is also amenable, we may thus assume without loss of generality that the bilinear forms ")#mi("{\\Lambda_0,\\Lambda_1}")#text(" obey the dilation invariance ")#metadata(none) <tao-7bed15d1f45ebb1a9afb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\lambda^{-n} \\Lambda_0( \\delta_\\lambda f, \\delta_\\lambda g_0) = \\Lambda_0( f, g_0); \\quad \\lambda^{-n} \\Lambda_1( \\delta_\\lambda f, \\delta_\\lambda \\vec g ) = \\Lambda_1( f, \\vec g )")]]



#text(" for all ")#mi("{f, g \\in \\mathcal{S}({\\bf R}^n)}")#text(", ")#mi("{\\vec g \\in \\mathcal{S}({\\bf R}^n)^n_0}")#text(", and ")#mi("{\\lambda > 0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One could have combined the translation invariance, rotational invariance, and dilation invariance steps into a single step by considering the action of the group of similarity transformations generated by translations, rotations, and dilations, which is also amenable, but I found it conceptually easier to consider the three invariances separately.")
]

#text("Now we use all these invariances to almost completely determine the operators ")#mi("{\\Lambda_0, \\Lambda_1}")#text(". We begin with the analysis of ")#mi("{\\Lambda_0}")#text(", which is slightly simpler. First observe from the ")#link("https://en.wikipedia.org/wiki/Schwartz_kernel_theorem")[#text("Schwartz kernel theorem")]#text(" that there is a (tempered) distribution ")#mi("{K_0}")#text(" on ")#mi("{{\\bf R}^n \\times {\\bf R}^n}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0(f, g) = \\int_{{\\bf R}^n \\times {\\bf R}^n} f(x) g(y) K_0(x,y)\\ dx dy")]]

#text("for all ")#mi("{f, g \\in \\mathcal{S}({\\bf R}^n)}")#text(", where by abuse of notation the right-hand side denotes the action of the distribution ")#mi("{K_0}")#text(" on the tensor product of ")#mi("{f}")#text(" and ")#mi("{g}")#text(". The translation invariance ")#link(<tao-2b25b7eb660b45d65866>)[#text("(6)")]#text(" then asserts that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} f(x) g(y) K_0(x,y)\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{{\\bf R}^n \\times {\\bf R}^n} f(x-h) g(y-h) K_0(x,y)\\ dx dy")]]

#text("for all ")#mi("{f,g \\in \\mathcal{S}({\\bf R}^n)}")#text(" and ")#mi("{h \\in {\\bf R}^n}")#text(". Since Schwartz functions in ")#mi("{{\\bf R}^n \\times {\\bf R}^n}")#text(" can be approximated (in Schwartz seminorms) by linear combinations of Schwartz functions in ")#mi("{{\\bf R}^n}")#text(" (as can be done for instance using dyadic partitions of unity and Fourier series), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy = \\int_{{\\bf R}^n \\times {\\bf R}^n} F(x-h,y-h) K_0(x,y)\\ dx dy")]]

#text("for any Schwartz ")#mi("{F \\in \\mathcal{S}({\\bf R}^n \\times {\\bf R}^n)}")#text(".")

#text("Morally, this means that ")#mi("{K_0(x+h,y_h)=K_0(x,y)}")#text(", that is to say ")#mi("{K_0(x,y)}")#text(" is really just a function of ")#mi("{x-y}")#text(". To justify this at the level of distributions, we argue as follows. Now suppose that ")#mi("{F \\in C^\\infty_c({\\bf R}^n \\times {\\bf R}^n)}")#text(" is such that ")#mi("{\\int_{{\\bf R}^n} F(x-h,y-h)\\ dh = 0}")#text(" for all ")#mi("{x,y}")#text(". If we let ")#mi("{\\phi}")#text(" be a bump function supported on ")#mi("{B(0,1)}")#text(" of total mass one, and ")#mi("{R}")#text(" is sufficiently large, then we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("= R^{-n} \\int_{{\\bf R}^n \\times {\\bf R}^n} \\int_{{\\bf R}^n} F(x-h,y-h) \\phi(\\frac{h}{R})\\ dh K_0(x,y)\\ dx dy")]]

#text("(from translation invariance and averaging),")

#align(center)[#tao-fit-display[#tao-math("= R^{-n} \\int_{\\left|h^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n \\times {\\bf R}^n} \\int_{{\\bf R}^n} F(x-h,y-h) \\phi(\\frac{h}{R}) \\phi(x-h^{\\prime})\\ dh", block: true)]]

#align(center)[#tao-fit-display[#mitex("K_0(x,y)\\ dx dy dh^{\\prime}")]]

#text("(because ")#mi("{F(x-h,y-h) \\phi(h/R) \\phi(x-h^{\\prime})}")#text(" vanishes unless ")#tao-math("{\\left|h^{\\prime}\\right| \\leq 2R}", block: false)#text(", and because ")#mi("{\\int _{{\\bf R}^d} \\phi(x-h^{\\prime})\\ dh^{\\prime}= 1}")#text("),")

#align(center)[#tao-fit-display[#tao-math("= R^{-n} \\int_{\\left|h^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n \\times {\\bf R}^n} \\int_{{\\bf R}^n} F(x-h+h^{\\prime},y-h+h^{\\prime}) \\phi(\\frac{h}{R}) \\phi(x)\\ dh", block: true)]]

#align(center)[#tao-fit-display[#mitex("K_0(x,y)\\ dx dy dh^{\\prime}")]]

#text("(by translating ")#mi("{x}")#text(" by ")#mi("{h^{\\prime}}")#text("),")

#align(center)[#tao-fit-display[#tao-math("= R^{-n} \\int_{\\left|h^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n \\times {\\bf R}^n} \\int_{{\\bf R}^n} F(x-h,y-h) \\phi(\\frac{h+h^{\\prime}}{R}) \\phi(x)\\ dh", block: true)]]

#align(center)[#tao-fit-display[#mitex("K_0(x,y)\\ dx dy dh^{\\prime}")]]

#text("(by translating ")#mi("{h}")#text(" by ")#mi("{h^{\\prime}}")#text("),")

#align(center)[#tao-fit-display[#tao-math("= R^{-n} \\int_{\\left|h^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n \\times {\\bf R}^n} \\int_{{\\bf R}^n} F(x-h,y-h) (\\phi(\\frac{h+h^{\\prime}}{R}) - \\phi(\\frac{h^{\\prime}}{R})) \\phi(x)\\ dh", block: true)]]

#align(center)[#tao-fit-display[#mitex("K_0(x,y)\\ dx dy dh^{\\prime}")]]

#text("(because ")#mi("{\\int_{{\\bf R}^n} F(x-h,y-h)\\ dh = 0}")#text("). On the other hand, the integrand ")#mi("{F(x-h,y-h) (\\phi(h+h^{\\prime}/R) - \\phi(h^{\\prime}/R)) \\phi(x)}")#text(" can be seen to be non-vanishing only when ")#mi("{h = O(1)}")#text(", and has uniform compact support in ")#mi("{x,y}")#text(", with all ")#mi("{C^k}")#text(" norms ")#mi("{O_k(1/R)}")#text(". From this and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy\\right| \\lesssim R^{-1}", block: true)]]

#text("and thus on sending ")#mi("{R \\rightarrow \\infty}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy = 0")]]

#text("whenever ")#mi("{F \\in C^\\infty_c({\\bf R}^n \\times {\\bf R}^n)}")#text(" is such that ")#mi("{\\int_{\\bf R} F(x-h,y-h)\\ dh = 0}")#text(", or equivalently whenever ")#mi("{\\int_{\\bf R} F(x+h,h)\\ dh = 0}")#text(". Thus the expression ")#mi("{\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy}")#text(" only depends on the function ")#mi("{\\int_{\\bf R} F(x+h,h)\\ dh}")#text(", so there exists a distribution ")#mi("{K^{\\prime}_0}")#text(" on ")#mi("{{\\bf R}^n}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) K_0(x,y)\\ dx dy = \\int_{{\\bf R}^n} (\\int_{\\bf R} F(x+h,h)\\ dh) K^{\\prime}_0(x)\\ dx.")]]

#text("We then have the convolution representation")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0(f,g) = \\int_{{\\bf R}^n} f*\\tilde g(x) K^{\\prime}_0(x)\\ dx")]]

#text("for all ")#mi("{f,g \\in C^\\infty_c({\\bf R}^n)}")#text(", where ")#mi("{\\tilde g(x) := g(-x)}")#text(" is the reflection of ")#mi("{g}")#text(". By a limiting argument one can allow ")#mi("{f,g}")#text(" to be in the Schwartz space rather than ")#mi("{C^\\infty_c}")#text(". The rotation and dilation invariances of ")#mi("{\\Lambda_0}")#text(" then imply that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f(U^{-1} x) K^{\\prime}_0(x)\\ dx = \\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx")]]

#text("and ")#metadata(none) <tao-9d342244e93851e7f870>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_{{\\bf R}^n} f(x/\\lambda) K^{\\prime}_0(x)\\ dx = \\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx")]]



#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(", ")#mi("{U \\in O(n)}")#text(", and ")#mi("{\\lambda > 0}")#text(".")

#text("The rotation invariance and an averaging argument implies that ")#metadata(none) <tao-dbf1151ae5e38f0a43cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx = \\int_{{\\bf R}^n} \\overline{f}(x) K^{\\prime}_0(x)\\ dx")]]



#text(" whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\overline{f}(x) := \\int_{O(n)} f(U^{-1} x)\\ dU")]]

#text("is the spherically symmetric component of ")#mi("{f}")#text(", and ")#mi("{dU}")#text(" denotes probability Haar measure on ")#mi("{O(n)}")#text(". Next, if ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" vanishes near the origin and is such that ")#mi("{\\int_0^\\infty f(\\lambda x)\\ \\frac{d\\lambda}{\\lambda} = 0}")#text(" for all ")#mi("{x}")#text(", and ")#mi("{\\phi}")#text(" is a bump function supported on ")#mi("{[-1,1]}")#text(" of total mass one, then (similarly to the translation invariance analysis) we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx")]]

#tao-aligned(keep: true)[


#tao-math(" & = R^{-1} \\int_{{\\bf R}^n} \\int_0^\\infty f(\\frac{x}{\\lambda}) \\phi(\\frac{\\log \\lambda}{R})\\ \\frac{d\\lambda}{\\lambda} K^{\\prime}_0(x)\\ dx", block: true)



#tao-math(" & = R^{-1} \\int_{\\left|\\log \\lambda^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n} \\int_0^\\infty f(\\frac{x}{\\lambda}) \\phi(\\frac{\\log \\lambda}{R}) \\phi(\\log \\left|x\\right| - \\lambda^{\\prime})\\ \\frac{d\\lambda}{\\lambda}", block: true)
]

#align(center)[#tao-fit-display[#mitex("K^{\\prime}_0(x)\\ dx \\frac{d\\lambda^{\\prime}}{\\lambda^{\\prime}}")]]

#align(center)[#tao-fit-display[#tao-math("= R^{-1} \\int_{\\left|\\log \\lambda^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n} \\int_0^\\infty f(\\frac{\\lambda^{\\prime}x}{\\lambda}) \\phi(\\frac{\\log \\lambda}{R}) \\phi(\\log \\left|x\\right|)\\ \\frac{d\\lambda}{\\lambda}", block: true)]]

#align(center)[#tao-fit-display[#mitex("K^{\\prime}_0(x)\\ dx \\frac{d\\lambda^{\\prime}}{\\lambda^{\\prime}}")]]

#align(center)[#tao-fit-display[#tao-math("= R^{-1} \\int_{\\left|\\log \\lambda^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n} \\int_0^\\infty f(\\frac{x}{\\lambda}) \\phi(\\frac{\\log \\lambda + \\log \\lambda^{\\prime}}{R}) \\phi(\\log \\left|x\\right| - \\lambda^{\\prime})\\ \\frac{d\\lambda}{\\lambda}", block: true)]]

#align(center)[#tao-fit-display[#mitex("K^{\\prime}_0(x)\\ dx \\frac{d\\lambda^{\\prime}}{\\lambda^{\\prime}}")]]

#align(center)[#tao-fit-display[#tao-math("= R^{-1} \\int_{\\left|\\log \\lambda^{\\prime}\\right| \\leq 2R} \\int_{{\\bf R}^n} \\int_0^\\infty f(\\frac{x}{\\lambda}) (\\phi(\\frac{\\log \\lambda + \\log \\lambda^{\\prime}}{R}) - \\phi(\\frac{\\log \\lambda^{\\prime}}{R})", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\phi(\\log \\left|x\\right| - \\lambda^{\\prime})\\ \\frac{d\\lambda}{\\lambda} K^{\\prime}_0(x)\\ dx \\frac{d\\lambda^{\\prime}}{\\lambda^{\\prime}}", block: true)]]

#text("for ")#mi("{R}")#text(" large enough. But the integrand ")#tao-math("{f(x/\\lambda) (\\phi((\\log \\lambda + \\log \\lambda^{\\prime})/R) - \\phi((\\log \\lambda^{\\prime})/R)) \\phi(\\log \\left|x\\right| - \\lambda^{\\prime})}", block: false)#text(" is non-vanishing only when ")#mi("{\\lambda}")#text(" is comaparable to ")#mi("{1}")#text(", and has uniform compact support in ")#mi("{x}")#text(" with all ")#mi("{C^k}")#text(" norms ")#mi("{O_k(1/R)}")#text(". From this and the triangle inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx\\right| \\lesssim 1/R", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx = 0")]]

#text("whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" vanishes near the origin with ")#mi("{\\int_0^\\infty f(\\lambda x)\\ \\frac{d\\lambda}{\\lambda} = 0}")#text(" for all ")#mi("{x}")#text(". In the case when ")#mi("{f}")#text(" is radial, ")#tao-math("{f(x) = f(\\left|x\\right|)}", block: false)#text(", the latter condition simplifies to ")#mi("{\\int_0^\\infty f(r)\\ \\frac{dr}{r} = 0}")#text(". We conclude that there is a constant ")#mi("{C}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx = C \\int_0^\\infty f(r)\\ \\frac{dr}{r}")]]

#text("whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" is spherically symmetric vanishes near the origin. On the other hand, if ")#mi("{f}")#text(" is a spherically symmetric bump function equal to one near the origin and is decreasing, then ")#mi("{\\int_0^\\infty (f(r/2) - f(r))\\ \\frac{dr}{r}}")#text(" is strictly positive, while from ")#link(<tao-9d342244e93851e7f870>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} (f(x)-f(x/2)) K^{\\prime}_0(x)\\ dx = 0.")]]

#text("We conclude that ")#mi("{C=0}")#text(", thus ")#mi("{\\int_{{\\bf R}^n} f(x) K^{\\prime}_0(x)\\ dx}")#text(" vanishes whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" is spherically symmetric and vanishes near ")#mi("{0}")#text(". From ")#link(<tao-dbf1151ae5e38f0a43cc>)[#text("(10)")]#text(" the same is true without the spherical symmetry hypothesis; thus the distribution ")#mi("{K^{\\prime}_0}")#text(" is supported at the origin, and hence is a linear combination of the Dirac delta function and its derivatives. To be consistent with the dilation invariance ")#link(<tao-9d342244e93851e7f870>)[#text("(9)")]#text(", it can in fact only be a constant multiple of the Dirac delta; thus")

#align(center)[#tao-fit-display[#mitex("\\Lambda_0(f,g) = C^{\\prime} \\int_{{\\bf R}^d} f(x) g(x)\\ dx")]]

#text("for some ")#mi("{C^{\\prime}}")#text(". But this is only consistent with ")#link(<tao-871fac543aade029764e>)[#text("(4)")]#text(" if ")#mi("{C^{\\prime}=0}")#text(" (one can take for instance ")#mi("{f}")#text(" to be a smoothed out version of ")#tao-math("{\\min(\\max(R + \\log \\left|x\\right|, 0),R)}", block: false)#text(" for some large ")#mi("{R}")#text(", which has a bounded BMO norm, and ")#mi("{g}")#text(" to be a bump function supported near the origin, to obtain a contradiction for non-zero ")#mi("{C^{\\prime}}")#text("). Thus ")#mi("{\\Lambda_0}")#text(" must vanish identically.")

#text("We now apply a similar (but slightly more complicated) argument for ")#mi("{\\Lambda_1}")#text(". The Schwartz kernel theorem (and the Hahn-Banach theorem) shows that there exists a vector-valued distribution ")#mi("{K_1}")#text(" on ")#mi("{{\\bf R}^n \\times{\\bf R}^n}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1(f, \\vec g) = \\int_{{\\bf R}^n \\times {\\bf R}^n} f(x) \\vec g(y) \\cdot K_1(x,y)\\ dx dy")]]

#text("whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" and ")#mi("{\\vec g \\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(". Translation invariance then gives")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) \\cdot K_1(x,y)\\ dx dy")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{{\\bf R}^n \\times {\\bf R}^n} F(x-h,y-h) \\cdot K_1(x,y)\\ dx dy")]]

#text("whenever ")#mi("{F \\in {\\mathcal S}({\\bf R}^n\\times {\\bf R}^n)^n}")#text(" is such that ")#mi("{\\int_{{\\bf R}^n} F(x,y)\\ dy = 0}")#text(" for all ")#mi("{x}")#text(". The translation averaging argument then shows that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) \\cdot K_1(x,y)\\ dx dy = 0")]]

#text("whenever ")#mi("{F \\in {\\mathcal S}({\\bf R}^n\\times {\\bf R}^n)^n}")#text(" is such that ")#mi("{\\int_{{\\bf R}^n} F(x,y)\\ dy = 0}")#text(" for all ")#mi("{x}")#text(" and ")#mi("{\\int_{{\\bf R}^n} F(x-h,y-h)\\ dh = 0}")#text(" for all ")#mi("{x,y}")#text("; this implies the existence of a vector-valued distribution ")#mi("{K^{\\prime}_1}")#text(" on ")#mi("{{\\bf R}^n}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n \\times {\\bf R}^n} F(x,y) \\cdot K_1(x,y)\\ dx dy = \\int_{{\\bf R}^n} (\\int_{\\bf R} F(x+h,h)\\ dh) \\cdot K^{\\prime}_1(x)\\ dx.")]]

#text("whenever ")#mi("{F \\in {\\mathcal S}({\\bf R}^n\\times {\\bf R}^n)^n}")#text(" is such that ")#mi("{\\int_{{\\bf R}^n} F(x,y)\\ dy = 0}")#text(" for all ")#mi("{x}")#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1(f,\\vec g) = \\int_{{\\bf R}^n} f*\\tilde \\vec g(x) \\cdot K^{\\prime}_1(x)\\ dx")]]

#text("whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(" and ")#mi("{\\vec g \\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(". The rotation and dilation invariances of ")#mi("{\\Lambda_1}")#text(" then imply that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} U \\vec f(U^{-1} x) \\cdot K^{\\prime}_1(x)\\ dx = \\int_{{\\bf R}^n} \\vec f(x) K^{\\prime}_1(x)\\ dx")]]

#text("and ")#metadata(none) <tao-0f8879cecb29f21b6670>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_{{\\bf R}^n} \\vec f(x/\\lambda) \\cdot K^{\\prime}_1(x)\\ dx = \\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx")]]



#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(", ")#mi("{U \\in O(n)}")#text(", and ")#mi("{\\lambda > 0}")#text(".")

#text("The rotation invariance implies that ")#metadata(none) <tao-0fc192de0a5090f04730>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx = \\int_{{\\bf R}^n} \\overline{\\vec f}(x) \\cdot K^{\\prime}_1(x)\\ dx")]]



#text(" whenever ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\overline{\\vec f}(x) := \\int_{O(n)} U \\vec f(U^{-1} x)\\ dU")]]

#text("is the equivariant version of ")#mi("{\\vec f}")#text(" (in particular one has ")#mi("{\\overline{\\vec f}(Ux) = U \\overline{\\vec f}(x)}")#text(" for all ")#mi("{x \\in {\\bf R}^n}")#text(" and ")#mi("{U \\in O(n)}")#text(". From dilation invariance as before we have")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx = 0")]]

#text("whenever ")#mi("{\\vec f \\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(" vanishes near the origin with ")#mi("{\\int_0^\\infty \\vec f(\\lambda x)\\ \\frac{d\\lambda}{\\lambda} = 0}")#text(" for all ")#mi("{x}")#text(". For equivariant ")#mi("{\\vec f}")#text(", this latter condition is equivalent to ")#mi("{\\int_0^\\infty e_1 \\cdot \\vec f(\\lambda e_1)\\ \\frac{d\\lambda}{\\lambda} = 0}")#text(". In particular, there is a constant ")#mi("{C^{\\prime\\prime}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx = C^{\\prime\\prime} \\int_0^\\infty e_1 \\cdot \\vec f(\\lambda e_1)\\ \\frac{d\\lambda}{\\lambda}")]]

#text("whenever ")#mi("{\\vec f\\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(" is equivariant and vanishes near the origin Combining this with ")#link(<tao-0fc192de0a5090f04730>)[#text("(12)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx = C^{\\prime\\prime} \\int_0^\\infty e_1 \\cdot \\overline{\\vec f}(\\lambda e_1)\\ \\frac{d\\lambda}{\\lambda}")]]

#text("whenever ")#mi("{\\vec f\\in {\\mathcal S}({\\bf R}^n)^n_0}")#text(" vanishes near the origin. Using polar coordinates, the right-hand side can also be expressed as")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^n} \\vec f(x) \\cdot K^{\\prime}_1(x)\\ dx = C^{\\prime\\prime\\prime} \\int_{{\\bf R}^n} \\frac{x \\cdot \\vec f(x)}{\\left|x\\right|^{n+1}}\\ dx", block: true)]]

#text("for another constant ")#mi("{C^{\\prime\\prime\\prime}}")#text(" (")#mi("{C^{\\prime\\prime}}")#text(" divided by the surface area of the unit sphere). Thus, ")#mi("{K^{\\prime}_1}")#text(" is equal to the distribution ")#tao-math("{p.v. C^{\\prime\\prime\\prime} \\frac{x}{\\left|x\\right|^{n+1}}}", block: false)#text(" away from the origin, and thus differs from that distribution by a (vector-valued) linear combination of Dirac delta functions and its derivatives. By dilation invariance there cannot actually be any derivative terms, and from rotation invariance there cannot be any delta function terms either. Hence we have")

#align(center)[#tao-fit-display[#tao-math("K^{\\prime}_1 = p.v. C^{\\prime\\prime\\prime} \\frac{x}{\\left|x\\right|^{n+1}}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\Lambda_1(f, \\vec g) = C^{\\prime\\prime\\prime\\prime} \\int f R \\cdot \\vec g")]]

#text("for some absolute constant ")#mi("{C^{\\prime\\prime\\prime\\prime}}")#text("; comparing this with ")#link(<tao-4790f26c96f097d31e26>)[#text("(3)")]#text(" we see that ")#mi("{C^{\\prime\\prime\\prime\\prime}=-1}")#text(". We conclude that for ")#mi("{f \\in {\\mathcal S}({\\bf R}^n)}")#text(", we have ")#mi("{T_i f = R_i f}")#text(" for ")#mi("{i=1,\\dots,n}")#text("; but one can easily show that ")#mi("{R_i}")#text(" fails to be bounded from ")#mi("{\\mathrm{BMO}}")#text(" to ")#mi("{L^\\infty}")#text(" (even when restricted to Schwartz functions), and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2018")])]

#text("formatting issue: \\eqerf{decomp} does not show equation")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2018")])]

#text("Is it possible to characterize the class of functions ")#mi("f")#text(" for which the decomposition (1) can be made linear? (thereby identifying the precise “obstruction for linearity” in (1))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("I’m not sure any particular class of functions can be “blamed” for lack of bounded linear decomposition. After all, since by the axiom of choice a linear decomposition is always possible, for any finite-dimensional class of functions one can obtain a bounded linear decomposition. One could try to investigate things more quantitatively though, for instance by restricting attention to the span of some finite number of elements of some standard basis of functions (e.g. a wavelet basis) and see how the optimal constant of a linear decomposition grows with the number of elements. The averaging argument in the post is not written in such a way as to easily extract a lower bound on the growth (as it uses infinitary concepts such as invariant means on amenable groups) but it should be possible to rework the argument more finitarily (e.g. using averages over large Folner sets as a substitute for invariant means) to obtain some (rather weak) lower bound of this type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ho")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507506")[#strong[#text("Ho")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2018")])]

#text("Thank you Dr. Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507699")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2018")])]

#text("Hello Terrence, i like to know your opinion about this proposition :")

#text("Let ")#mi("p_i")#text(" the i-th prime number : ")#mi("p_1=2, \\, p_2=3, \\, p_3=5,\\,\\cdots")#text(".")#linebreak()#text(" Prouve that if ")#mi("n \\in \\mathbb{N}")#text(" and ")#mi("n \\wedge \\prod_{i=1}^{m} p_i = 1")#text(" (")#mi("m \\geq 2")#text(") then ")#mi("\\exists k \\in \\{1,2,\\cdots,p_m\\} \\,\\,\\, (n + 2k) \\wedge \\prod_{i=1}^{m} p_i = 1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("This claim would imply that the ")#link("https://oeis.org/wiki/Jacobsthal_function")[#text("Jacobsthal function")]#text(" ")#mi("h(m) = j(\\prod_{i=1}^m p_i)")#text(" cannot exceed ")#mi("2p_m+1 \\sim 2m \\log m")#text(". This is likely to be false, but this has not yet been proven; the best known bounds currently are")

#mi("\\displaystyle \\frac{m \\log m \\log\\log\\log m}{\\log\\log m} \\ll h(m) \\ll m^2 \\log^2 m")

#text("(the right-hand bound is ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=499895")[#text("due to Iwaniec")]#text("; the left-hand side ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3718451")[#text("to Ford, Green, Konyagin, Maynard, and myself")]#text("). The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=972703")[#text("conjectures of Maier and Pomerance")]#text(" suggest ")#mi("h(m)")#text(" should in fact grow like ")#mi("m \\log^{2+o(1)} m")#text(", which would imply that the proposition is false. It may be possible to investigate things numerically for small values of ")#mi("m")#text(" (for instance using the values in ")#link("http://oeis.org/A048670")[#text("OEIS A048670")]#text("), and perhaps even locate a counterexample. (Also, since you are only using shifts of the form ")#mi("2p_i")#text(", as opposed to all shifts between ")#mi("1")#text(" and ")#mi("2p_m")#text(", it may be possible to adapt the methods in my paper with Ford et al., or earlier and simpler arguments using the Erdos-Rankin method, to obtain an analytic disproof.)")

#text("Incidentally, it would be preferable if one could post mathematical questions as comments to blog posts whose topic is at least somewhat related to the content of the question (one can use the various search and categorisation options on the left sidebar to locate a suitable post, e.g., ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("this one")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507827")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2018")])]

#text("Thanks a lot Mr Terence for your valuable ansere")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd7e684aba2062c523c6dab1fcd4a19534c135da165ee259d78d186bf96a79da-3ba4fd5f71c841811deacce2f64a6c6d9d6077c9dbb77f3cb26be7d88c383976.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amir Sagiv")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507703")[#strong[#text("Amir Sagiv")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2018")])]

#text("Has anyone ever attempted to carry out Uchiyama’s proof into an actual algorithm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507737")[#strong[#text("Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("[…] The isometric embedding problem also has the key obstacle that naive attempts to solve the equation iteratively can lead to an undesirable “loss of derivatives” that prevents one from iterating indefinitely. This obstacle was famously resolved by the Nash-Moser iteration scheme in which one alternates between perturbatively adjusting an approximate solution to improve the residual error term, and mollifying the resulting perturbation to counteract the loss of derivatives. The current equation (1) differs in some key respects from the isometric embedding equation , in particular being linear in the unknown field rather than quadratic; nevertheless the key obstacle is the same, namely that naive attempts to solve either equation lose derivatives. Our approach to solving (1) was inspired by the Nash-Moser scheme; in retrospect, I also found similarities with Uchiyama’s constructive proof of the Fefferman-Stein decomposition theorem, discussed in this previous post (and in this recent one). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f056306be7888f5be6aa29d0bff84282f637e41199c02aad37b3f6deb463fe7-0a38a4f54167f436840bde300b8242e2aaa72097fe78c004064ecf40ce967dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of almaz")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507803")[#strong[#text("almaz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2018")])]

#text("It seems that on the torus it was established by Bonami. That is how it is cited in the paper of E. Amar “Représentation des fonctions de BMO et solutions de l’équation…” 1979. (see Theorem 3.2 there)")

#text("I hope it is relevant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-507811")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2018")])]

#text("Thanks for this! It seems that the argument starts similarly in that it reduces to the translation invariant case (but does not try to impose rotation or dilation invariance), so that ")#mi("T_0, T_i")#text(" are Fourier multipliers . Then by inspection of the BMO and ")#mi("L^\\infty")#text(" norms of lacunary type Fourier series they show that the multipliers associated to ")#mi("T_0, T_i")#text(" cannot have an infinite number of elements of large magnitude (e.g. larger than ")#mi("1/(d+1)")#text("), and this is incompatible with (2).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b75530ff217a8c2df2cc7c319f7e9dee74f73d1177a36d0c7fe498dafdf9ef5e-727aaa15b84e2515362ae943fb2eaacb047614a307071a554e99be37ac15fbf0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CHRIST AMBASSADOR")]], [#link("https://terrytao.wordpress.com/2018/11/21/the-nonlinearity-of-the-fefferman-stein-decomposition/#comment-508957")[#strong[#text("CHRIST AMBASSADOR")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2018")])]

#text("Morning professor Tao, I need your assistance sir, am a student of Lagos state university ojo Nigeria,studying mathematics. am a big fan of yours sir. My main reason for texting you is that I have passion for mathematics sir and I need you to help me sir, I want to be a professor like you sir. But I find it hard to see materials that will help me in my field of study. please sir if you can help me I will be forever indebted to you")#linebreak()#text(" Yours faithfully")#linebreak()#text(" Salau ayobami")
]
]
]
