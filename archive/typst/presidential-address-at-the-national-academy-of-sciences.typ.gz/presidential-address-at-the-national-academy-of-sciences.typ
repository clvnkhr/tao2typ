// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/
// Converted to Typst by tao2typ: "2026-10-14T15:17:12.623596+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Presidential address at the National Academy of Sciences", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Presidential address at the National Academy of Sciences")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/")[#text("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This weekend I was in Washington, D.C., for the annual meeting of the ")#link("http://www.nasonline.org/site/PageServer")[#text("National Academy of Sciences")]#text(". Among the various events at this meeting was an ")#link("http://www8.nationalacademies.org/onpinews/newsitem.aspx?RecordID=20090427")[#text("address to the Academy by President Obama")]#text(" this morning on several major science and education policy initiatives, including some already announced in the economic stimulus package and draft federal budget, and some carried over from the previous administration. (I myself missed the address, though, as I had to return back to LA to teach.) Among the initiatives stated were the creation of an Advanced Research Projects Agency for Energy (ARPA-E), modeled on DARPA (and recommended by the NAS); a significant increase in funding to the NSF and related agencies (which was committed to by the Bush administration, but not yet implemented; this is distinct from the one-time funding from the stimulus package discussed in ")#link("https://terrytao.wordpress.com/2009/02/06/proposed-stimulus-amendment-eliminates-14-billion-in-nsf-funding/")[#text("this previous post")]#text("), leading in particular to a tripling in the number of NSF graduate research fellowships; and a “race to the top” fund administered by the Department of Education to provide incentives for states to improve their quality of maths and science education, among other goals. Some of these initiatives may not survive the budgetary process, of course, but it does seem that there is both symbolic and substantive support for science and education at the federal level.")

#text("Here are the ")#link("http://edg1.vcall.com/video/nas/launch.asp")[#text("video")]#text(", ")#link("http://nationalacademies.org/podcast/20090427.mp3")[#text("audio")]#text(", and ")#link("http://www.whitehouse.gov/the_press_office/Remarks-by-the-President-at-the-National-Academy-of-Sciences-Annual-Meeting/")[#text("transcript")]#text(" of the talk.")

#text("[")#emph[#text("Update")]#text(", Apr 28: Another event at the meeting is the announcement of the new ")#link("http://www8.nationalacademies.org/onpinews/newsitem.aspx?RecordID=04282009")[#text("membership of the Academy for 2009")]#text(". In mathematics, the new members include Alice Chang, Percy Deift, John Morgan, and Gilbert Strang; congratulations to all four, of course.]")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a88124dcfb4b4ab7b6b5954a4057c18dfbd308a80d0245dd295e3ae134282d82-b9e4f45bf9efe8309aecca589c2f43794c90156a931121fe32720575239b0152.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38398")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("I realize most here are very excited about this,so I’m probably don’t have anyone else here who would agree with me. Could someone point out the clause in the Constitution that gives the government the power to take money from the people and fund scientific research? Keeping in mind that under our system the Constitution enumerates what the government CAN do. Anything not enumerated therein it is not supposed to be able to do. I realize that most of the readers of this blog live by the public teat for research funding, but it sure would be nice if your research stood on its own or was worthy enough to get private funding rather than have the government take it under threat of violence from the rest of us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38399")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dave,")

#text("I think that most constitutional lawyers believe that the general welfare clause in Section 8 authorizes congress to appropriate funds for science and mathematics.")

#text("I’m excited about the promise this has for math funding. I hope that this trend will increase the total pool of tenured positions in the country in the next few years!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dear Dave,")

#text("I am not a constitutional scholar, but my understanding is that the General Welfare Clause in Article I of the Constitution is invoked for a wide range of federal government spending, from the NSF to Social Security. (The latter, incidentally, has about 100 times the budget of the former.)")

#text("Pure research tends to have too long of a lag time to attract much private funding. For instance, the early infrastructure of the internet was built in the 1960s by ARPA (the predecessor to DARPA, mentioned in the post), about 25 years before it had any significant commercial value, or indeed much obvious benefit to anyone other than academics and the military; I am not sure how it would have developed in the absence of government support.")

#text("Also, part of the nature of such research is that its potential applications can be quite unpredictable. For instance, in my own research (about half of which is supported by the NSF), I would have considered the work of myself and others on uncertainty principles in Fourier analysis to be of primarily academic interest until they turned out to play a key role in compressed sensing, which is now used for instance to speed up MRI scans and other types of data acquisition. But I would think it unlikely that, prior to such connections being made, that one could attract much research support from, say, the R&D department of a typical tech company (although there are some exceptions, for instance Microsoft Research does support a significant amount of pure mathematics).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c99be9b51ffeaba0488ac5a820c66cff4fdd345c5530de317391471ca037a7-29d397b384d569338a539952d844eefa912edd9b18155a8cd25717ef3d5cce86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Successful Researcher")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38407")[#strong[#text("Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Many thanks for the interesting info and links!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/403fa5501fb9da45d61efe0e15f666313bbacdf8c6200b709def0e92bf59434d-b2794a92e1e2efa68496ac46189f52f7ca633bf84ba3c2855ed48180de5cc05b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles A")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38408")[#strong[#text("Charles A")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text(">(although there are some exceptions, for instance Microsoft Research does support a significant amount of pure mathematics)")

#text("Unfortunately, the exceptions are almost always monopolies like Microsoft (e.g. AT&T’s Bell Labs). The tragedy of the commons problem inherent in basic research goes away if you *are* the commons =P (actually I guess it is the “freerider” problem, not the tragedy of the commons problem; anyway, freeriders are not such a problem if you have a monopoly hold on market).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a935b4b93036f4f8b57fd09702896b3dee68bef7d2703c663d4af72f9cf04b61-2b4e640a2d0ba3336bc1de6c7fd07024995c03a49ccbbdf358d6f402a794f218.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lyn")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38427")[#strong[#text("Lyn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("There is not substantive support for science at the White House level. Whatever money Obama is pledging – and it’s been reported as high as 3% of US GDP – that money is not real money.")

#text("Science and innovation are going to have to wait. That’s all there is to it. I would have thought the research community would have been more skeptical of politicians by now. Apparently science is still a field for idealists.")

#text("If the economy improves then maybe business will spur more research and development spending. Don’t believe in Obama’s claims or promises.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38430")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#emph[#text("Pure research tends to have too long of a lag time to attract much private funding. For instance, the early infrastructure of the internet was built in the 1960s by ARPA (the predecessor to DARPA, mentioned in the post), about 25 years before it had any significant commercial value, or indeed much obvious benefit to anyone other than academics and the military; I am not sure how it would have developed in the absence of government support.")]

#text("While I certainly agree with your larger point, I only half-agree with your argument for it, and I think that the example serves to show its weakness. CompuServe and UUCP are two other computer networks that were founded rather earlier than 25 years after the Internet/ARPANet, and I think that to perceptive industry figures they made it quite obvious how such networks could have commercial value. More generally, many companies make serious plans 20 or 30 years into the future — and the government is not always all that patient in practice either.")

#text("Moreover, private industry does fund vast amounts of research of various kinds. To some extent it fails to fund “pure” research only in a tautological sense: Research can be called pure exactly when it isn’t privately funded.")

#text("Certainly there is a lot of worthwhile research that isn’t funded by companies and the question remains why not. I believe the “lighthouse” argument. A company could pay us to prove theorems, but our research wouldn’t be all that useful to anyone if it were kept secret. Other people elsewhere need to read the research results and add their own results. But if a company does not keep its research secret, then it gains no competitive advantage from funding that research. Most technology companies make free use everyone else’s research, from government-funded research to Microsoft-funded research. Some of this research is recent and some of it is not at all recent, but it is such a vast edifice that there is no point in a small company funding similar research on any time scale. In fact, the overall edifice is so vast that all companies are “small”. (But again, some of them are anything but short-sighted. For instance IBM is twice as old as the NSF!)")

#text("I’m sure that the main reason that the Internet evolved from ARPANet and not from CompuServe is that it was too open and collective for the business plans of any one company, and not that it took too long to prove useful.")

#text("There are also indirect reasons that some companies might and do fund basic research. First, it can be a beneficial form of public relations. Second, a company could partially compensate some of its researchers with partial intellectual freedom. Third, publishing research isn’t a full mind meld, so a company may retain some competitive advantage by employing the people who understand a research topic the best. IBM, Microsoft, Google, etc., all fund some basic research for all of these reasons.")

#text("But we can agree that isn’t enough funding. I make an analogy to another case of lighthouse economics, movies vs television. Producers have to give away traditional television signals, and they can still make earn revenue from advertising. But not as much revenue as movies. Movies have always had much more production money than television shows, even though most people watch television more than they watch movies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6762af7bb4bd1eb3d2976c67be5071fcfcc752df0ee86bb1087a00020ea2b366-916fba26aea554ab86bab7955ce2378fc6a4037efdeebd1a464b3efad92577f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of familyforest")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38437")[#strong[#text("familyforest")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Then President Obama should step up to the challenge himself and")#linebreak()#text(" help out those who are creative and innovative and would like his endorsement of their “National Treasure”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://familyforest.wordpress.com/2008/09/26/national-treasure/")[#text("National Treasure")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38438")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2009")])]

#text("Greg,")

#text("You said “Moreover, private industry does fund vast amounts of research of various kinds.” Can you show evidence of vast amounts of mathematics research by private industry? Enough evidence to justify the adjective “vast?” It seems to me that that word suggests a quantity that is at least a large fraction of the total body of mathematics.")

#text("My own observation is that much of the research done by private corporations is at least indirectly related to government grants and/or is done in symbiotic relationship with a university which itself receives federal money, and most of the rest is done for strictly selfish purposes. Drug and biotechnology companies do research only if they can expect hefty profits in the near future. I myself am kept alive and functioning by regular IV immune globulin (antibody) infusions. Biotechnology companies would never have done the product research for the relatively small number of patients that need it. Instead, the research was originally done by the NIH, with results later transferred to private industry for free and who are now profiting from it. This is still true. Anyone with a rare medical condition is basically orphaned by private industry in terms of research because they would rather go after the far more profitable common diseases.")

#text("And to continue Terry’s Fourier analysis example, the Fourier and Radon transforms appeared many, many years before one could ever dream of applying them in a practical way to useful problems and data sets, such as as signal and image processing, and to medical imaging in particular. They were certainly useful in a theoretical setting, but the practical applications never arrived until we had computers that could do the extremely tedious calculations for us. I just don’t see private corporations funding that sort of thing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quatra")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38444")[#strong[#text("quatra")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("Charles A,")#linebreak()#text(" Microsoft is good for games – it is a good problem to figure out what went wrong with Apple.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e921d70f6b9d5eae47c502c2d932144891960d6692d21351b61461f37cf2664c-e8d485287e42577e97b9d4507b78344f49c893b8a7c41f6d4ed75fa78136874a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josuah Chamberlain")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38445")[#strong[#text("Josuah Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("What weakness are youu talking about? Even the subsidary technologies that went into creating the internet came out of DARPA programs. If I am not mistaken, lithograhic techniques for chip making came out of a DAPRPA. Generally speaking, the the technological foundations of the whole computer field is a DARPA funded project. That is to say, ordinary American tax payers paid the bill. This is just a fact about the US economic system")

#text("Stem Cell research with high probability will follow the same route. Internet Browser technology came out a University of Illionois DARPA funded program…specifically Netscape.")

#text("Yet the tycoons of Silicon Valley and Redmind Washington strut and have believe that their billions were a direct consequence of their “heroic” struggle in the unadulturated free market. And to top things, off they expect an unlimited suppply of H-1B and L-1B replacement workers. Very ungratefull wouldn’t you say Greg considering all the decades of American tax payer subsidies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38450")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("Richard and Josuah (?),")

#text("First, I agree that “vast” was a somewhat careless adjective in context. In a $14 trillion economy lots of things can be called vast on some absolute scale or tiny on a relative scale. Second, it is true that theorems in mathematics per se are on the pure side of things where the lighthouse argument applies. You can’t make much use of a theorem without giving it away, so it does not usually make economic sense for companies to pay people to prove theorems.")

#text("Third, you have me all wrong if you think that I am an ideological libertarian with uncritical faith in the “free market” (whatever that even means). Certainly I think that mathematicians should be paid to prove theorems — I’m one of them! But I can’t think of good arguments for a private company to pay me to prove theorems. At best, I might earn the privilege to prove theorems as partial compensation for other work for a private company.")

#text("From one side, I agree with Terry’s remark that the problem is time scale. My main objection is that many companies really do not mind waiting decades for a profit, because they can find ways to amortize expected future earnings. The problem is not that the private sector is impatient in general. The relevant time scale, however, is not the intrinsic patience of the private sector, but rather the time scale on which intellectual property can stay secret and yet be valuable. That truly isn’t very long.")

#text("Yes, Fourier transforms and Radon transforms were both defined long before they were profitable. However, this is misleading in various ways. For one reason, you can find patents that refer to Fourier series that were filed before Radon published his transform in 1917.")

#text("Even though I am not at all here to hawk libertarian ideology, I also don’t agree with the accusatory tone of remarks that private companies do research “for selfish purposes” or that they are “ungrateful” for their subsidies. The point of modern economics is to recognize and work with institutional incentives, instead of working against incentives and casting about accusations. In fact, a company is no more than a mosaic of financial objectives; it doesn’t truly “believe” or “disbelieve” anything. Yes, companies make free use of public research — but what’s wrong with that? I respect many theorems in mathematics that have never earned a profit for anyone. But if a theorem does earn a profit for someone, that’s even better!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e921d70f6b9d5eae47c502c2d932144891960d6692d21351b61461f37cf2664c-e8d485287e42577e97b9d4507b78344f49c893b8a7c41f6d4ed75fa78136874a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38452")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2009")])]

#text("Greg")

#text("There is nothing wrong with private companies using the results and technology of Tax payer subsidized research. My family has a deep personal interest in this issue. Stems Cell-regenerative medicine research- can’t move fast enough for my family(Lou Gherigs disease). If some company can pull it off, I would be very happy.")

#text("However, I am deeply bothered when economic growth theorist Paul Romer writes how ordinary Americans should be massively greatfull..to the point of being reverential..to Bill Gates for the technology his comapny puts out to the public. This is what Romer wrote-pretty dam close to what he wrote.")

#text("And what about Craig Venter. If he had his way he would have privatized-patented for corporate profit most if not all of the human genome. I mean this is really scary stuff when basic life processess are owned by corporations. This may be vague. But it maybe behind the thousands of suicides of Indian farmers over the past decade. Vadana Shiva and an Indian journalist named Snaith have written a lot about this.")

#text("By the way, a form of vitamin B-6 that I bought all the time has been pulled of the shelves of health food stores because some corporation has now got a patent on it.")

#text("Yeah, I think there is a lot of extreme greed that goes along with corporations. You may not agree with this, but the nummber one goal of a Corporate CEO is to maximize profit..screw the externalities. If he or she doesn’t do this, the understudy will step right in.")

#text("I’m not trying to beat you over the head with my post. I just want you to think about certain issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38466")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#emph[#text("However, I am deeply bothered when economic growth theorist Paul Romer writes how ordinary Americans should be massively greatfull..to the point of being reverential..to Bill Gates for the technology his comapny puts out to the public. This is what Romer wrote-pretty dam close to what he wrote.")]

#text("No, I don’t agree with this at all. This confuses the science of capitalism — which is as valid as any other social science — with the religion of capitalism. I don’t know whether Paul Romer truly believes this misinterpretation, but certainly many other people (such as Ayn Rand) did or do believe it.")

#text("In the science of capitalism, people use money and ownership to cooperate. It therefore follows that “greed” is rational, because the more money you have, the easier it is (if all else is equal) to attain your goals. But if you’re rich, that doesn’t necessarily mean that you should be revered or denounced; it doesn’t necessarily mean anything other than that you have a lot of money to spend. You might fairly guess that the Bill Gates’ money is only a slice of a much larger pool of widely distributed wealth or value, and you may fairly be grateful that that economic bounty exists. That doesn’t necessarily mean that Gates either created the larger pool of wealth or that he stole from it, only that his fortune is associated with it.")

#text("It could even be logical to admire the capitalist system if you think that it works better than other economic systems. But that is not the same as admiring profit or rich people. The idea that you should revere and emulate rich people just because they are rich is a religious edict. Rationally speaking, you should make money only as a means to other ends.")

#emph[#text("Yeah, I think there is a lot of extreme greed that goes along with corporations.")]

#text("Well yes, the whole point of a company is to maximize profit, at least within the rules. Not only do I agree with it, my point is that it’s a fact of life; you shouldn’t cast it as an accusation. Society shouldn’t expect companies to leave money lying on the table in favor of public concerns. Instead, the government should pursue public concerns as a buyer and seller, or sometimes with regulations or tax incentives.")

#text("And of course, one of those sensible government activities is to fund public research, because pure research such as proving theorems is only valuable when it’s given away.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e921d70f6b9d5eae47c502c2d932144891960d6692d21351b61461f37cf2664c-e8d485287e42577e97b9d4507b78344f49c893b8a7c41f6d4ed75fa78136874a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joshua Chamberlain")]], [#link("https://terrytao.wordpress.com/2009/04/27/presidential-address-at-the-national-academy-of-sciences/#comment-38474")[#strong[#text("Joshua Chamberlain")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("Greg")

#text("I am going by what Romer has written. I too wondered if he was just being silly. I have come to the conclusion that he is deadly serious. All Neoclassical economic growth theorists think either the economy is more fundamental than ecology-envionment or they belive that economy and ecosytems inhabit two seprate universes that do not interact. Paul Romer and the late Juilian Simon are true believers in the view that human ingenuity will save us from the insults to ecosystems due to toxic economic activity and economic growth. From my understanding of Romer’s writings and research, he does not believe that there is an upper bound on human technological ingenuity. He believes something along the lines that technological ingenuity is at the most fundamental level software-formula-combintorial..therefore there is no upper bound on technoligical ingenuity therefore we will get ourselves out of the self-inflicted messess and catastrophes. This is pretty much the extetent of Romer’s argument-proof.")

#text("I on the other hand, have very little confidence that humans will be clever enough to revive the mid-Atlantic conveyor belt should it collapase due to melting glaciers.")
]
