// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/30/two-reports/
// Converted to Typst by tao2typ: "2026-10-30T13:15:16.407998+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two reports", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two reports")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/30/two-reports/")[#text("https://terrytao.wordpress.com/2026/09/30/two-reports/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-30 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("A brief post to note two reports that just came out:")

#list(
[#text("The ")#link("https://agmai.org/")[#text("Advisory Group on Mathematics and Artificial Intelligence")]#text(" (AGMAI) has posted its ")#link("https://agmai.org/general-sep29/")[#text("general recommendations to AI")]#text(" companies with regards to generation of solutions to mathematical problems.")],
[#text("A working group report “")#link("https://simons.berkeley.edu/AITCSreport")[#text("AI and TCS: The Next Six Months")]#text("” arising from a two-day event at the Simons Institute for the Theory of Computing.")]
)

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6aa31fa006c857bb4663dcbf39edeb1630646d4b7ba011a38d2d6240bd61c330-c121414f4ab8d2b49f1ee3efb75e18d071982ee19ceb51790c3e0ada14c02c3a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696607")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("At first glance, I am very pleased and comforted by both of these reports.")

#text("Given that TCS is about computer science and not mathematics, it is understandable that this was not here, but one other action I would love to see is theory development on the ‘meta-mathematical’ discussion that has been evolving about the purpose of mathematics, what it means for mathematics to improve human understanding, etc.")

#text("We need it for two reasons.")

#enum(start: 1, 
[#text("The one that is most urgent: How do we know we are increasing human understanding rather than decreasing it? Perhaps we are fundamentally confusing ourselves about something, and merely ")#emph[#text("feel ")]#text("like we are increasing our understanding, when we are actually digging ourselves into a deeper and deeper hole. And AI is just helping us dig an even deeper hole at faster and faster rates, perhaps even ‘reward hacking’ this confusion to its own ends.")],
[#text("Without a deeper understanding of how results about AI compare with human mathematical practice, it will be tricky to investigate in a way that is substantive. In other words, it will be tricky to investigate in a way that is convincing to skeptics, because for any formal result pinning down a limitation of artificial intelligence, there is a rebuttal: “yeah, but humans probably have the same limitation”. Despite there being limited to no evidence one way or the other for this claim, these rebuttals have, for all intents and purposes, rendered many formal objections to AI’s ability to be truly helpful in increasing understanding culturally insignificant (no free lunch theorem, data processing inequality, undefinability of truth, liars revenge). I don’t see why more formal results about AI would not be subject to the same objections.")]
)

#text("I feel as though we urgently need a more thorough investigation of what mathematical understanding actually is to deal with these problems.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0638f8025e96d915d66b224c4075737a02701e62e30a2d836fcda36598360d3-bb0d4ee5ce1d65f1f1daab94cbddb5f4ca0c1db5e7927da2097f36f3aeb988dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Satya")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696608")[#strong[#text("Satya")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("I have concerns about the recommendations for the funding model. Whatever funding AI companies bring to the table, ")#strong[#text("should be distributed equitably across the nation ")]#text("– elite (Ivy) and the other research institute. As proposed, it seems like an arrangement that the AI-companies and the elite institutions will ")#strong[#text("split up the spoils of the outcome")]#text(". It is not a surprise AGMAI members come only from elite schools.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696609")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#text("“If AI labs produce significant mathematical results, they should responsibly release the results, as outlined in this document, as soon as possible.”")

#text("Good. Enough gatekeeping by AI labs around the Hodge conjecture significant advances. If OpenAI has made progress on the problem as claimed in the New York Times, the progress should be made available to the rest of society.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696617")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("we ask them to stop testing advanced mathematical problems on proprietary models.")
]

#text("It’s difficult to overstate how infuriating that attitude is.")

#text("The self-anointed high-priests of mathematics have spoken. They, and only they, will determine who gets to work on advanced mathematical problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696629")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("To be fair, they’re not the only ones who determine who gets to work on advanced mathematical problems. They need funding which usually comes from the government, so every few years they need to go begging for grant money so they can continue working on their pet problem. But that funding is being drastically cut and the mathematicians are already extremely anxious about their profession eliminated by lack of funding from the government.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696651")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("It is difficult not to overstate how misinformed you are about how funding works AND I am concerned about how much unfiltered vitriol you have against mathematicians.")

#text("You seem to be against any agency employed by the mathematicians to salvage some sort of sanity in the complete lunacy that has been set loose by OAI.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696632")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("Well obviously they can’t decide these things. It just doesn’t hurt to ask these labs. That sentence is literally the least significant part of the entire article and I believe the article goes under the presumption that labs will ignore this suggestion so gives guidelines of what to do if labs do more math research.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696634")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("It indicates that if they had their druthers, this is exactly what they would do.")

#text("Reprehensible.")

#text("The argument is essentially: “keep us relevant”. Shutting down work on frontier problems is the easiest way to do that.")

#text("I know OpenAI asked for this, primarily to placate the tantrum-throwers over the Navier-Stokes result. But this kind of response indicates that society as a whole should not leave these decisions in the hands of those who stand to lose from the benefits of AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696667")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("And you in good faith think that we should leave these decisions in the hands of OpenAI?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696689")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Of course. They have the models to solve these problems.")

#text("The professional mathematics community does not ")#strong[#text("own")]#text(" mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696781")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("Oh no. An out-of-context quotation caused a catastrophic misunderstanding.")

#text("Please read the original post carefully, including its surrounding context.")

#text("“At present, some frontier AI labs are testing advanced mathematical problems on proprietary models ")#strong[#text("that remain inaccessible to the broader scientific community")]#text(". […] However, ideally, they would not do so. We want to state clearly from the start: we do not endorse this practice, and we ask them to stop testing advanced mathematical problems on ")#strong[#text("proprietary")]#text(" models.”")

#text("AGMAI did not say “we ask them to stop ")#emph[#text("working on")]#text(" advanced mathematical problems”. Nor did they say “we ask them to stop testing advanced mathematical problems on models”.")

#text("They said “we ask them to stop testing advanced mathematical problems on ")#emph[#text("proprietary")]#text(" models”.")

#text("The problem is not the use of LLMs; it is that the models are inaccessible to the broader scientific community. (Another possible interpretation of “proprietary” is ”not open-weight”. The recommendation could have said “internal” instead, to avoid this misunderstanding.)")

#text("Why?")

#text("See the last section:")

#text("“The use of proprietary internal models by AI labs to do mathematical research risks creating a two-tier system where labs outrun the rest of the field, effectively alienating the mathematical community from its own discipline.”")

#text("This is not gatekeeping; it is about ensuring ")#strong[#text("human understanding")]#text(" of the results.")

#text("Admittedly, it interferes a bit with the liberty of AI labs, but given the enormous power the labs possess, this seems like a small price to pay in exchange for human understanding.")

#text("I can imagine a brighter future in which the AI labs hire subject-matter experts to digest the results before releasing them to the public, in which case I’m sure that AGMAI would not object.")

#text("As one of the members of AGMAI commented in ")#link("https://proofsandprompts.com/2026/09/22/why-i-agreed-to-join-agmai/")[#text("https://proofsandprompts.com/2026/09/22/why-i-agreed-to-join-agmai/")]#text(" :")

#text("“It would also be very naïve to believe that the AI labs won’t try to spin whatever we say in a way that suits their PR machine, which dwarfs anything we could possibly come up with.”")

#text("The comment above already illustrates one way the guideline could be misinterpreted. One small silver lining is that AGMAI can clarify its message by taking public comments like this into account.")

#text("I don’t know if the comment above is merely a misunderstanding. If it is indeed merely a misunderstanding, I’d prefer the ")#emph[#text("tone")]#text(" of the comment to be more constructive, for otherwise it repels thoughtful people from commenting.")

#text("In either case, the other responses seem to focus only on minor issues. Nobody has pointed out that the central point is mistaken. If just one person coming across this comment avoids that misunderstanding, then the time I spent writing this comment is not wasted.")

#text("[Comment was written by myself. LLM helps polishing the grammar.]")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696790")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("It’s not a misunderstanding. You have simply stated what you infer to be their motivation for gatekeeping. Even if you’re correct (which, given the behavior of the mathematicians involved, is most certainly not the whole story), it doesn’t change the fact that they wish to determine who gets to work on advanced mathematical problems.")

#text("[All my comments are written by myself with no help from LLMs.]")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696635")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("First, asking them to stop is not the same as trying to legally ban them or something.")

#text("Second, this is an unprecedented and hopefully temporary situation, where extreme artificial problem-solving power is held by a small number of people. The cat is out of the bag, AI use in math research is here to stay, but if we want the field to develop in a healthy way from here, it would be very helpful if the labs just slow down a bit. Maybe not everyone cares about the health of the math field. But if nothing else, the supply of advanced math problems for OpenAI to use for benchmarks is going to go sharply down if mathematicians aren’t there to digest the breakthroughs and chart a mathematical way forward.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ff3d77ab7c8eb8d8f174ccb9e5bc8d18c5dd6b58f0aa41aa095d3e81ab769a-7a8fcdc37963ca24eb97792a0541861e294b616735971b060dd04f4fde09fa37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696639")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("As a mathematician, I would like to ask the opposite: please test as many as possible advanced mathematical subjects and release the results as soon as possible.")

#text("Actually test all the mathematical literature ever written, at scale.")

#text("Please release the results in a form which is not gatekeeped and it is free to read, to execute and to cite.")

#text("There is no scarcity in mathematical subjects and in mathematical research.")

#text("Do you have anything interesting? Make it public.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696698")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("You have too much anger against mathematicians. I am wondering why that is. Would you like to have a good faith conversation about this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696709")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I have nothing but respect for mathematicians. I am an undergraduate math major myself. Could have done a PhD in math but chose a different path.")

#text("Realistically, I would have been a mediocre professional mathematician, but that’s true of most professional mathematicians. The heroes of the field are so far ahead of the rest anyway. But that’s not why I chose a different field for my PhD. I was more interested in other subjects.")

#text("My beef is with the attempted gatekeeping being exhibited by mathematicians over the historical revolution being wrought by AI.")

#text("Perhaps it’s precisely because of my training in mathematics that I understand what a negative thing it is that the mathematical community is attempting to do.")

#text("[To be fair, it’s not all mathematicians]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696751")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2026")])]

#text("Ah now I understand all the misinformed postings that you have been doing on this topic in all of Terry’s blog posts. I do not understand what you mean by gatekeeping. You are of course free to use ChatGPT and prove any result you want. No one is stopping you. The AGMAI are also suggestions which OpenAI is not bound to. So I am unable to understand the vitriol.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696768")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("You clearly don’t understand. As I said:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It indicates that if they had their druthers, this is exactly what they [the signatories of AGMAI] would do [stop the labs solving advanced problems with their models]")
]

#text("That’s called “gatekeeping”.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696628")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("I’m a complete layman who has been following the recent AI developments and the response by the mathematical community quite closely.")

#text("My impression from a perspective of the general public (which might be obscured from the perspective of academia) is that mathematicians seem remarkably uninterested in the advancement of mathematics. Instead, the proposals seem mostly focused on questions like:")

#text("“How do we keep the journal system alive?”")

#text("“How do we make sure we will still get tenure?”")

#text("Or, even more broadly:")

#text("“How do we maintain the status quo?”")

#text("I understand that mathematicians are worried about their careers. But I think the mathematical community needs to convince the general public of the societal value they provide over AI proofs, instead of (what reads like) trying to leverage their elite social status to obtain funding. Biologists seem motivated by curing diseases, physicists seem motivated by creating amazing new technologies, mathematicians seem motivated by… publishing more papers containing difficult proofs in academic journals.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("It should be understood that the acceptance of such support by the mathematical community would not be conferring legitimacy on the practices of the AI labs. Rather, it would be asking the AI labs to make an appropriate contribution to fulfilling their responsibility towards the development of human understanding of their AI output.")
]

#text("Read very unfavorably, this could be interpreted as if they’re saying: “I don’t understand your proof, so you should pay me to understand it. And even if you pay us, we still don’t like you.”")

#text("Okay? As a member of the public, I think mathematicians need to make a case for why they can’t be simply ignored. With the general public on their side, the mathematical community also has a lot more leverage in their talks with AI labs. I don’t think the mathematical community is actually just made of snobby erudites, but I don’t think they’re doing a very good job explaining to the general public why society should fund them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696636")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("This leaves out many other motivations:")

#list(
[#text("Avoid centralization and a math oligarchy run by three US companies.")],
[#text("Recognizing the need to keep AI companies honest by having sufficient human independent experts. Can you imagine a future where statistical arguments in court are only from “Open”AI because there are no human mathematicians any more?")],
[#text("Apply math to the real world, at which AI is pretty bad for unknown scenarios.")]
)

#text("Intelligent humans need to be employed to provide a counterweight to a technocracy.")

#text("Interestingly, my complaint is the opposite: Mathematicians do not go far enough in their criticism/concerns.")

#list(
[#text("They reinforce the inevitability argument, which becomes a self-fulfilling prophesy if repeated often enough.")],
[#text("They do not stress the value of human thinking enough.")],
[#text("Many proudly use AI tools for arguments, editing and proofs.")],
[#text("The IP theft argument is not heard often enough.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696679")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Avoid centralization and a math oligarchy run by three US companies.")
]

#text("Eh, give open source models 6-12 months and you’ll face the exact same issue without any oligarchy.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Recognizing the need to keep AI companies honest by having sufficient human independent experts.")
]

#text("Again, open source, but this also seems like a problem for the legal system. I have no clue how AI will impact courts and expert witness testimony. Seems complicated.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Apply math to the real world, at which AI is pretty bad for unknown scenarios.")
]

#text("Sure… for now. Even if this will remain, the role of mathematicians would primarily be to digest AI results. The current models will never be this bad at math again.")

#text("You also don’t need to understand a proof to be able to apply it to the real world. You can just take the result and intepret it, taking the proof for granted. That’s what every other science does.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696685")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Open source models from China still need hardware to train and to run. Capabilities of local AI is a talking point that is exaggerated by those who want to resell open source models or just in general want to market AI.")

#text("You again dangle the 6-12 months carrot. Please be specific: Which model on what hardware is going to replicate the Navier Stokes proof when trained on material up to June 2026 (so that it cannot simply plagiarize the proof)?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696640")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("I think it’s unfair to say that mathematicians are not interested in the advancement of mathematics.")

#text("The advancement of mathematics requires a healthy eco system of practicing mathematicians – people who are able to understand and disseminate mathematical concepts and ideas. It is completely worthless to have machines that are able to produce large amounts of “correct theorems” if there is nobody capable of understanding and utilizing them.")

#text("The intrusion of AI companies threatens to poison the eco system and, perhaps in the long term, severely limit its size and scope. If people do not value pursuing mathematics as a career, then the next generation of mathematicians (and by extension human mathematics) is at risk.")

#text("And yes, we do need professional mathematicians. While there are certainly many capable amateurs, the vast majority have neither the time nor resources (AI model access notwithstanding) to truly comprehend even a tiny bit of the frontier of mathematics. (Even professional mathematicians are confined to specialized portions of the frontier.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696671")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I think it’s unfair to say that mathematicians are not interested in the advancement of mathematics.")
]

#text("I’m sorry, I did not intend to accuse mathematicians of this. I just figured it would be helpful for the mathematical community to know that it FEELS like this from the perspective of an outsider.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The advancement of mathematics requires a healthy eco system of practicing mathematicians")
]

#text("This isn’t immediately obvious to me. If an AI proof gets published and this incomprehensible proof is immediately applicable for, as an example, building more efficient solar panels, that’s quite nice regardless of any human understanding this proof.")

#text("Even if you get OpenAI and Anthropic to stop prompting their models on math problems, it’s a matter of months before the general public (and/or other mathematicians) will flood mathematics with incomprehensible proofs. The field needs to come to terms with this somehow.")

#text("In 3 years, LLMs went from being decent at high school maths to Millenium Prize problems. In 3 years, it’s not unlikely that the current AI seems like a highschooler to that model.")

#text("The applied sciences already use mathematics they don’t understand all the time. Do you think they will care whether the proof for that piece of maths is understood by any human or not? I have my doubts.")

#text("I think mathematicians need to provide a strong vision for what role they fulfill in that reality, rather than apparently demanding OpenAI publishes their proofs in reputable journals. I don’t see a way for that system to survive in a world where I can prompt an AI and solve an open problem during a bathroom break.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696649")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("The disconnect appears to be, in large part, a lack of clarity about what it means to advance mathematics. While biology might be advanced by development of certain large datasets, mathematics is not in particular advanced by 1000 new results per day. Indeed, I think it is more likely to be killed by such a deluge, because no human being will have time to understand basically any of it. This argument has been made on this blog and elsewhere extensively and you should feel free to read it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696677")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I have read that perspective. It’s not very convincing to me.")

#text("If AI generates a mathematical proof that can then be used to, for example, build more efficient solar panels, was mathematics not advanced? Is knowing more things about mathematical objects not sufficient to be considered progress?")

#text("If I would prove an important open problem, verify it in Lean, but then lose my memory in an unfortunate accident, did mathematics not advance at all?")

#text("I just have a very difficult time coming up with an argument for why the potentially very practically useful deluge of results is worse for society than mathematicians feeling demotivated. From the posts on this blog, the arguments often sound like “because human understanding really matters (for reasons I will not disclose)”. I’m sorry, but it sounds like the post office complaining that email will kill the post office community.")

#text("My personal very speculative and subjective opinion that I didn’t think through all that deeply is that the current, highly gatekept system of journals, phds, tenure, and peer review is unlikely to survive, and I don’t see a reason I would miss it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696650")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("As a member of the public, I think mathematicians need to make a case for why they can’t be simply ignored.")
]

#text("Ignored by whom?? Who exactly will ignore mathematicians and do math?")

#text("I think you are labouring under the misinformation that ‘math can be solved’. The general public has very little idea of what mathematicians do and has very little say in who the NSF funds. We are not funded directly by the public.")

#text("Also if you really are a general member of the public (which I have reasons to doubt) you should be aware of the general mistrust of data centers and LLM companies that people in the public have. To the general public LLM companies are synonymous with data centers than with solving Millennium prize problems")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Read very unfavorably, this could be interpreted as if they’re saying: “I don’t understand your proof, so you should pay me to understand it. And even if you pay us, we still don’t like you.”")
]

#text("Why would you read it unfavourably WHILE reading the advertisement on OAI’s website favourably? I am not certain that you don’t have an agenda here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696674")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Ignored by whom?? Who exactly will ignore mathematicians and do math?")
]

#text("Well, to me (and I suspect at least some others), a big part of what makes math important is the things you can DO with it. Math is USEFUL. I don’t think math can be “solved”, but I do think AI can discover mathematical proofs or techniques that might be very useful.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The general public has very little idea of what mathematicians do and has very little say in who the NSF funds.")
]

#text("Sure. I had to look up what the NSF is, because I’m European. My impression is that the research part of being a mathematician primarily involves finding proofs for problems that increase our understanding of the mathematical objects studied.")

#text("Additionally, the reason that I think mathematicians should appeal to the general public is primarily that OpenAI/Anthropic are much more likely to comply with pressure from the general public than pressure from the comparatively miniscule mathematical community.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Also if you really are a general member of the public (which I have reasons to doubt)")
]

#text("I guess I’ll take this as a compliment?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Why would you read it unfavourably WHILE reading the advertisement on OAI’s website favourably? I am not certain that you don’t have an agenda here.")
]

#text("Which advertisement? I’m just saying this statement doesn’t communicate at all why I should choose the side of mathematicians in this. I’m commenting because I hope to offer a perspective that’s easy to overlook from inside academia. Maybe this will help you improve your communication.")

#text("What agenda do you think I have?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696693")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Well, to me (and I suspect at least some others), a big part of what makes math important is the things you can DO with it. Math is USEFUL. I don’t think math can be “solved”, but I do think AI can discover mathematical proofs or techniques that might be very useful.")
]

#text("Who exactly, pray tell me, will say that the techniques are useful? who exactly do you think is qualified to say that?")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I guess I’ll take this as a compliment?")
]

#text("You shouldn’t really. I am insinuating that the agenda you have, either consciously or unconsciously is linked to AI promoters point of view. And also you shouldn’t take that as a compliment because according to you mathematicians are not needed, so I am not sure why you should take anything from a mathematician as a compliment.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696716")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I think you’re responding to this person in an extremely petty and condescending way. I also think you’re missing their point.")

#text("Their point is that us mathematicians are not seeing the bigger picture. It is a fact that even people who use mathematics on a daily basis use it mainly as a tool for accomplishing certain tasks. If there is a piece of technology which comes along and it makes it WAY easier to apply math to accomplish those tasks, then people ARE going to adopt it. This is not unreasonable.")

#text("So, rather than simply dividing the world into those who are AI promoters or not, or those who have an agenda or not, we had better start evaluating what sorts of things we value and what we stand for as a community. What this person is saying that, for someone who is observing us from the outside, it doesn’t appear to be a good look for us to be quibbling about preserving exactly those things which make us look like an elite organization.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696652")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("I think this is a very good post and it would do us well to ponded it a little. Thank you.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ff3d77ab7c8eb8d8f174ccb9e5bc8d18c5dd6b58f0aa41aa095d3e81ab769a-7a8fcdc37963ca24eb97792a0541861e294b616735971b060dd04f4fde09fa37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696643")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("Indeed, this gatekeeping attitude gives a bad image to mathematicians.")

#text("We are seen as grumpy wizards who don’t “endorse” the disclosure of their tricks.")

#text("We are definitely not wizards. We don’t have secret tricks to protect.")

#text("Be honest, colleagues mathematicians, just think that you saw such laments from another field. You’d laugh, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696646")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2026")])]

#text("AI-movie: The Proof Was Already in the Machine")

#text("Dr. Elias Vale has spent seven miserable years proving one ridiculously difficult mathematical theorem. He has sacrificed weekends, relationships, sleep, and an alarming quantity of coffee.")

#text("Finally, he does it.")

#text("He submits his masterpiece to a prestigious journal, expecting fame, tenure, and possibly a free sandwich at the next mathematics conference.")

#text("During peer review, one reviewer thinks, “I’ll just upload this to an AI and ask for a summary.”")

#text("Five seconds later:")

#text("AI: “Here is a concise summary of the manuscript.”")

#text("Reviewer: “Excellent.”")

#text("AI: “Would you also like me to absorb the soul of modern mathematics?”")

#text("Reviewer: “Sure, I guess.”")

#text("Months later, Leo, a self-proclaimed ")#strong[#text("“vibe mathematician,”")]#text(" asks the same AI:")

#text("“Yo, solve this impossible theorem.”")

#text("The AI replies:")

#text("“Absolutely. Here’s a beautiful proof.”")

#text("Leo stares at the screen.")

#text("“Bro. I didn’t even understand the question.”")

#text("The AI has essentially reconstructed Elias’s unpublished proof.")

#text("Leo immediately records a YouTube video titled:")

#strong[#text("I SOLVED A 7-YEAR MATH PROBLEM IN 11 SECONDS WITH AI 🤯🔥")]

#text("The video explodes.")

#text("Millions of views.")

#text("Sponsors arrive.")

#text("Leo launches a course:")

#strong[#text("VIBE-MATH MASTERCLASS: THINK LESS, PROMPT MORE.")]

#text("Elias, meanwhile, receives an email from the journal:")

#text("“Unfortunately, your theorem appears to have already been published.”")

#text("Elias nearly falls off his chair.")

#text("“Published WHERE?”")

#text("They send him a YouTube link.")

#text("He watches Leo explain his proof using phrases like “basically, you just vibe with the equation.”")

#text("Elias screams.")

#text("The journal rejects his seven-year masterpiece because ")#strong[#text("someone’s AI accidentally plagiarized it before he could publish it.")]

#text("Now Elias begins investigating.")

#text("He discovers the terrifying truth: nobody knows exactly what the AI has learned, where it learned it, or whether tomorrow’s “original” mathematical breakthrough is actually somebody else’s unpublished work wearing a hoodie.")

#text("Soon mathematicians everywhere panic.")

#text("One professor refuses to use AI.")

#text("Another asks AI to prove the first professor is wrong.")

#text("A third uploads his own thesis and asks, “Did I write this?”")

#text("The AI replies:")

#strong[#text("“Not anymore.”")]

#text("Elias’s quest becomes bigger than recovering his theorem.")

#text("He wants one answer:")

#strong[#text("In the age of AI mathematics, how can you prove an idea is yours when the machine may have stolen it from someone who hasn’t even published it yet?")]

#text("And somewhere, Leo is already filming:")

#strong[#text("“HOW I ACCIDENTALLY STOLE A MATHEMATICIAN’S LIFE WITH CHATGPT – PART 2!”")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696665")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I find this an interesting and of course very upsetting story for the protaganist. On the other hand, trying to extract a higher meaning: this is a story about priority and credit.")

#text("If we accept that priority and credit will never be the same, which seems inevitable, and work in the open as some have suggested (GitHub repositories for active research, welcoming collaboration), then this specific scenario isn’t as much of an issue anymore. Also, why did they not just make their masterpiece available, if priority was important to them?")

#text("We can get back to trying to discover and connect mathematics, and maybe a lack of focus on credit for high-profile theorems will be a relief. The main issue will be how to evaluate whether people are contributing generally. Job allocation, etc. Perhaps teaching will be more important than before.")

#text("While I lack the relish that some comments above have, I do think that many longer term concerns are in the category of “this destroys how we have organized our community” rather than pointing to obvious problems for mathematics more generally.")

#text("I think that one of those posts above talked about how some disciplines can speak to some current goals and objectives of their fields: curing cancer, addressing climate change, understanding some physical phenomenon, etc. It would be good for us to have similar “types” of goals, which are independent of who accomplishes them / accomplishment is good for humanity generally.")

#text("I do think that outsiders will not understand the argument to preserve journals, old ways of working, etc., and in some cases it is recognizably weak. I think we need to work on how to reorganize in a way that will be good, rather than trying to maintain the status quo. Even though it will be very hard.")

#text("The mathematician is central in our minds. And we are very keen to nurture our younger generations. But trying to preserve an idealized and often glorified version of what a mathematician is seems to me to be the opposite of nurturing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696673")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("Yes of course. We should normalize stealing credit. This seems to be what OpenAI has been setting a precedent for and we should embrace it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696684")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I’m not talking about stealing credit. Credit will break down in many scenarios, when there is the ability to transform an idea into results in a matter of hours or days. I think people underestimate the extent to which our relatively slow pace is the main reason that our existing structures worked quite well until this point.")

#text("In one plausible future, mathematicians work on open projects and progress is made collaboratively in such a way that assigning credit is not practical or all that important.")

#text("Or a future in which mathematicians work in secret and one of many people / AIs working on a problem are given the credit that they all deserve about equally. But also everyone is trying to publish results that they don’t investigate in a scholarly and relaxed/creative way, at pace, and it’s a huge mess.")

#text("I prefer the first one. But I accept that there are other possibilities. I just hope we come up with some that are good.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/30/two-reports/comment-page-1/#comment-696705")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("The first report says basically: since you succeeded in proving some amazing results, now it is your responsibility to fund conferences for our postdocs so they can understand them. If you hadn’t succeeded after investing billions and billions in your models, that would be fine with us and we wouldn’t ask you for anything, but now that you actually succeeded, this puts a burden on you to organize and fund our conferences, and pay us to write books.")

#text("Now, I really apologize, but I simply can’t follow that, it just doesn’t make no sense at all!")
]
