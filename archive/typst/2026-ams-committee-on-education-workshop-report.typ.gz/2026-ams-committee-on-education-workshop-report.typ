// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/
// Converted to Typst by tao2typ: "2026-11-14T13:42:35.662715+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "2026 AMS Committee on Education Workshop Report", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("2026 AMS Committee on Education Workshop Report")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/")[#text("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This is somewhat belated, but: on October 2, the American Mathematical Society ")#link("https://www.ams.org/about-us/governance/committees/2026CoEWorkshop")[#text("released a report")]#text(" based on a recent workshop it organized on the topic of graduate education in the mathematical sciences.")

#text("(If there have been other such reports that have appeared recently that were not already mentioned on the blog, please feel free to drop links to them in the comments.)")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/338736fac548406cd729f7a90f220d2223f212b1d725fd8bee6ed7d415b83576-e0c108d8d8dcdd24c63172abfce0c3dbcec4b3069428ec72500a01cb95b780a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of intruigued")]], [#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/#comment-697939")[#strong[#text("intruigued")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("“")#strong[#text("Pursue avenues for department-wide access to the AI tools that accelerate discoveries in mathematics")]#text(". Departments can advocate for institutional agreements with companies that produce frontier AI models so that they can be incorporated into research workflows with explicit privacy and security expectations” Privacy and security currently are not enforceable currently with companies. It is a core problem for mathematical research. As well as perhaps a blockchain type record of progress made by researchers. There is urgency to set this up and I wish there was a clearer road emerging towards this goal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/#comment-697953")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2026")])]

#text("I don’t think this is a long-term concern because eventually AI companies will stop releasing solutions to math problems. They’ve made their point. They’ll just give them to the public.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/190268591ae4a7fac282bb96148508de056a0342a79145160fbc63b4ad199571-4e19111cc23ecc80e1e16fde502e25d31ecc16012f67ef50f842a093e2eb3531.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/#comment-698087")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("Even if you were right. The damage is permanent.")

#text("Pre-AI legends (Gauss, Riemann, Grothendieck, Wiles, Perelman, Tao, etc) will forever remain the “Old Gods.” Their achievements are historically unassailable because the technology did not exist when they worked.")

#strong[#text("For all future generations, individual glory is permanently compromised.")]#text(" Because an intellectual negative cannot be proven, every future human breakthrough will arrive with an unspoken asterisk: ")#emph[#text("“Did a model suggest that key step?”")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f448afe442202445794dd733035cd0d78e932fc3a442ffa5ee3adc2e28852d8f-d5c6c038d65ac0e7844d36c370d5acae9e00eee7c4b9cf0f5af7d62351e879e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Una")]], [#link("https://terrytao.wordpress.com/2026/10/13/2026-ams-committee-on-education-workshop-report/#comment-698100")[#strong[#text("Una")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("In the 20th century, ")#link("https://www.google.com/search?kgmid=%2Fm%2F06k9jc&q=Bobby+Fischer")[#text("Bobby Fischer")]#text(" was seen as a ")#strong[#text("superhuman, mythical genius")]#text(". Today, no matter how brilliant a player like ")#strong[]#strong[]#strong[#link("https://www.google.com/search?kgmid=%2Fm%2F0291j3&q=Magnus+Carlsen")[#text("Magnus Carlsen")]]#text(" or ")#strong[]#strong[]#strong[#link("https://www.google.com/search?kgmid=%2Fm%2F02svzm&q=Hikaru+Nakamura")[#text("Hikaru Nakamura")]]#text(" is, the public rarely looks at them with that same sense of awe.")
]
