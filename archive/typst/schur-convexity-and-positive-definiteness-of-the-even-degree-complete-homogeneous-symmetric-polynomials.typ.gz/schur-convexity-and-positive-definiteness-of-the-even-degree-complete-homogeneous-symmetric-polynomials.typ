// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/
// Converted to Typst by tao2typ: "2026-10-14T10:42:27.656950+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Schur convexity and positive definiteness of the even degree complete homogeneous symmetric polynomials", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Schur convexity and positive definiteness of the even degree complete homogeneous symmetric polynomials")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 August 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/")[#text("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Complete_homogeneous_symmetric_polynomial")[#text("complete homogeneous symmetric polynomial")]#text(" ")#mi("{h_d(x_1,\\dots,x_n)}")#text(" of ")#mi("{n}")#text(" variables ")#mi("{x_1,\\dots,x_n}")#text(" and degree ")#mi("{d}")#text(" can be defined as")

#align(center)[#tao-fit-display[#mitex("h_d(x_1,\\dots,x_n) := \\sum_{1 \\leq i_1 \\leq \\dots \\leq i_d \\leq n} x_{i_1} \\dots x_{i_d},")]]

#text("thus for instance")

#tao-aligned(keep: true)[


#tao-math("h_0(x_1,\\dots,x_n)  & = 0,", block: true)



#tao-math("h_1(x_1,\\dots,x_n)  & = x_1 + \\dots + x_n,", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("h_2(x_1,\\dots,x_n) = x_1^2 + \\dots + x_n^2 + \\sum_{1 \\leq i < j \\leq n} x_i x_j.")]]

#text("One can also define all the complete homogeneous symmetric polynomials of ")#mi("{n}")#text(" variables simultaneously by means of the generating function ")#metadata(none) <tao-3b6a765ede676559e0f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{d=0}^\\infty h_d(x_1,\\dots,x_n) t^d = \\frac{1}{(1-t x_1) \\dots (1-tx_n)}.")]]

#text("We will think of the variables ")#mi("{x_1,\\dots,x_n}")#text(" as taking values in the real numbers. When one does so, one might observe that the degree two polynomial ")#mi("{h_2}")#text(" is a positive definite quadratic form, since it has the sum of squares representation")

#align(center)[#tao-fit-display[#mitex("h_2(x_1,\\dots,x_n) = \\frac{1}{2} \\sum_{i=1}^n x_i^2 + \\frac{1}{2} (x_1+\\dots+x_n)^2.")]]

#text("In particular, ")#mi("{h_2(x_1,\\dots,x_n) > 0}")#text(" unless ")#mi("{x_1=\\dots=x_n=0}")#text(". This can be compared against the superficially similar quadratic form")

#align(center)[#tao-fit-display[#mitex("x_1^2 + \\dots + x_n^2 + \\sum_{1 \\leq i < j \\leq n} \\epsilon_{ij} x_i x_j")]]

#text("where ")#mi("{\\epsilon_{ij} = \\pm 1}")#text(" are independent randomly chosen signs. The ")#emph[#text("Wigner semicircle law")]#text(" says that for large ")#mi("{n}")#text(", the eigenvalues of this form will be mostly distributed in the interval ")#mi("{[-\\sqrt{n}, \\sqrt{n}]}")#text(" using the semicircle distribution, so in particular the form is quite far from being positive definite despite the presence of the first ")#mi("{n}")#text(" positive terms. Thus the positive definiteness is coming from the finer algebraic structure of ")#mi("{h_2}")#text(", and not just from the magnitudes of its coefficients.")

#text("One could ask whether the same positivity holds for other degrees ")#mi("{d}")#text(" than two. For odd degrees, the answer is clearly no, since ")#mi("{h_d(-x_1,\\dots,-x_n) = -h_d(x_1,\\dots,x_n)}")#text(" in that case. But one could hope for instance that")

#align(center)[#tao-fit-display[#mitex("h_4(x_1,\\dots,x_n) = \\sum_{1 \\leq i \\leq j \\leq k \\leq l \\leq n} x_i x_j x_k x_l")]]

#text("also has a sum of squares representation that demonstrates positive definiteness. This turns out to be true, but is remarkably tedious to establish directly. Nevertheless, we have a nice ")#link("http://www.ams.org/mathscinet-getitem?mr=450079")[#text("result of Hunter")]#text(" that gives positive definiteness for all even degrees ")#mi("{d}")#text(". In fact, a modification of his argument gives a little bit more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{n \\geq 1}")#text(", let ")#mi("{d \\geq 0}")#text(" be even, and let ")#mi("{x_1,\\dots,x_n}")#text(" be reals.")

#list(
[#text("(i) (Positive definiteness) One has ")#mi("{h_d(x_1,\\dots,x_n) \\geq 0}")#text(", with strict inequality unless ")#mi("{x_1=\\dots=x_n=0}")#text(".")],
[#text("(ii) (")#link("https://en.wikipedia.org/wiki/Complete_homogeneous_symmetric_polynomial")[#text("Schur convexity")]#text(") One has ")#mi("{h_d(x_1,\\dots,x_n) \\geq h_d(y_1,\\dots,y_n)}")#text(" whenever ")#mi("{(x_1,\\dots,x_n)}")#text(" ")#link("https://en.wikipedia.org/wiki/Majorization")[#text("majorises")]#text(" ")#mi("{(y_1,\\dots,y_n)}")#text(", with equality if and only if ")#mi("{(y_1,\\dots,y_n)}")#text(" is a permutation of ")#mi("{(x_1,\\dots,x_n)}")#text(".")],
[#text("(iii) (Schur-Ostrowski criterion for Schur convexity) For any ")#mi("{1 \\leq i < j \\leq n}")#text(", one has ")#mi("{(x_i - x_j) (\\frac{\\partial}{\\partial x_i} - \\frac{\\partial}{\\partial x_j}) h_d(x_1,\\dots,x_n) \\geq 0}")#text(", with strict inequality unless ")#mi("{x_i=x_j}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{d}")#text(" (allowing ")#mi("{n}")#text(" to be arbitrary). The claim is trivially true for ")#mi("{d=0}")#text(", and easily verified for ")#mi("{d=2}")#text(", so suppose that ")#mi("{d \\geq 4}")#text(" and the claims (i), (ii), (iii) have already been proven for ")#mi("{d-2}")#text(" (and for arbitrary ")#mi("{n}")#text(").")

#text("If we apply the differential operator ")#mi("{(x_i - x_j) (\\frac{\\partial}{\\partial x_i} - \\frac{\\partial}{\\partial x_j})}")#text(" to ")#mi("{\\frac{1}{(1-t x_1) \\dots (1-tx_n)}}")#text(" using the product rule, one obtains after a brief calculation")

#align(center)[#tao-fit-display[#mitex("\\frac{(x_i-x_j)^2 t^2}{(1-t x_1) \\dots (1-tx_n) (1-t x_i) (1-t x_j)}.")]]

#text("Using ")#link(<tao-3b6a765ede676559e0f2>)[#text("(1)")]#text(" and extracting the ")#mi("{t^d}")#text(" coefficient, we obtain the identity")

#align(center)[#tao-fit-display[#mitex("(x_i - x_j) (\\frac{\\partial}{\\partial x_i} - \\frac{\\partial}{\\partial x_j}) h_d(x_1,\\dots,x_n)")]]

#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("= (x_i-x_j)^2 h_{d-2}( x_1,\\dots,x_n,x_i,x_j).")]]

#text("The claim (iii) then follows from (i) and the induction hypothesis.")

#text("To obtain (ii), we use the more general statement (known as the ")#emph[#text("Schur-Ostrowski criterion")]#text(") that (ii) is implied from (iii) if we replace ")#mi("{h_d}")#text(" by an arbitrary symmetric, continuously differentiable function. To establish this criterion, we induct on ")#mi("{n}")#text(" (this argument can be made independently of the existing induction on ")#mi("{d}")#text("). If ")#mi("{(y_1,\\dots,y_n)}")#text(" is majorised by ")#mi("{(x_1,\\dots,x_n)}")#text(", it lies in the ")#link("https://en.wikipedia.org/wiki/Permutohedron")[#text("permutahedron")]#text(" of ")#mi("{(x_1,\\dots,x_n)}")#text(". If ")#mi("{(y_1,\\dots,y_n)}")#text(" lies on a face of this permutahedron, then after permuting both the ")#mi("{x_i}")#text(" and ")#mi("{y_j}")#text(" we may assume that ")#mi("{(y_1,\\dots,y_m)}")#text(" is majorised by ")#mi("{(x_1,\\dots,x_m)}")#text(", and ")#mi("{(y_{m+1},\\dots,y_n)}")#text(" is majorised by ")#mi("{(x_{m+1},\\dots,x_n)}")#text(" for some ")#mi("{1 \\leq m < n}")#text(", and the claim then follows from two applications of the induction hypothesis. If instead ")#mi("{(y_1,\\dots,y_n)}")#text(" lies in the interior of the permutahedron, one can follow it to the boundary by using one of the vector fields ")#mi("{(x_i - x_j) (\\frac{\\partial}{\\partial x_i} - \\frac{\\partial}{\\partial x_j})}")#text(", and the claim follows from the boundary case.")

#text("Finally, to obtain (i), we observe that ")#mi("{(x_1,\\dots,x_n)}")#text(" majorises ")#mi("{(x,\\dots,x)}")#text(", where ")#mi("{x}")#text(" is the arithmetic mean of ")#mi("{x_1,\\dots,x_n}")#text(". But ")#mi("{h_d(x,\\dots,x)}")#text(" is clearly a positive multiple of ")#mi("{x^d}")#text(", and the claim now follows from (ii). ")#mi("\\Box")

#text("If the variables ")#mi("{x_1,\\dots,x_n}")#text(" are restricted to be nonnegative, the same argument gives Schur convexity for odd degrees also.")

#text("The proof ")#link("http://www.ams.org/mathscinet-getitem?mr=450079")[#text("in Hunter")]#text(" of positive definiteness is arranged a little differently than the one above, but still relies ultimately on the identity ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(2)")]#text(". I wonder if there is a genuinely different way to establish positive definiteness that does not go through this identity.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/724a5f80344d8c833d5f96098156b6474d7241d0645221f832a2cf430c495e55-d0c51b33bad4c6bd68b860e2c692845dc25308fcf7971962b7e0162cc488bbfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of unowatblog")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484709")[#strong[#text("unowatblog")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2017")])]

#text("There is a typo in the definition of $h_d$: the last index is $i_d$ rather than $i_n$.")

#text("Aside, since Schur convexity seems to me a natural solution – would you consider sum of squares type identity a different solution?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2017")])]

#text("Thanks for the correction!")

#text("One could convert the Schur convexity proof into a (rather artificial looking) sum of squares proof, but if there was a nice looking sum of squares representation analogous to that for ")#mi("h_2")#text(" then I would consider that to be a different proof.")

#text("Here is one small observation that might help towards a different proof: if one already knows the non-negativity of ")#mi("h_d(x_1,\\dots,x_n)")#text(" for even ")#mi("d")#text(", then this implies the non-negativity of ")#mi("h_d(x_1,\\dots,x_n,y,-y)")#text(" for any ")#mi("y")#text(" and even ")#mi("d")#text(". This is because the generating function ")#mi("\\sum_{d=0}^\\infty h_d(x_1,\\dots,x_n,y,-y) t^d")#text(" is equal to the generating function of ")#mi("\\sum_{d=0}^\\infty h_d(x_1,\\dots,x_n) t^d")#text(" times ")#mi("\\frac{1}{(1-yt)(1+yt)} = 1 + y^2 t^2 + y^4 t^4 + \\dots")#text("; the latter has only even powers and non-negative coefficients, hence the claim. So one can “cancel” any pair ")#mi("y,-y")#text(" that occurs in ")#mi("x_1,\\dots,x_n")#text(", which for instance demonstrates non-negativity of ")#mi("h_d(x_1,\\dots,x_n)")#text(" whenever the ")#mi("x_1,\\dots,x_n")#text(" all have the same magnitude. I wasn’t able to convert this argument into a proof of the general case though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484713")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2017")])]

#text("At least on my screen the tag (2) is not visible. (I found it by looking at the TeX code of the displayed identity.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eecd66a337c2a4e86e826a83728d9e8eafa931528e06c8e39a12720fd9c72ab9-a2f288599044367771d0e441dea02b25f62c0a5c58b10e26624a15bcdd990a33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr Shalit")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484719")[#strong[#text("Orr Shalit")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2017")])]

#text("It might be better to start the induction with d=2 (to obtain the condition for strict inequality).")

#emph[#text("[Suggestion implemented, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db2092993fb6ff152ff35d1bfbcd5b748dbb7a1e45a25789dd8466550a5a273f-3cb5a710d8e45b1a24b5d97ac559bb43710580ff3437b203ae613a0628a943e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2017")])]

#text("Maybe this works. Let ")#mi("Z_1,\\dots,Z_n")#text(" be i.i.d exponentially distributed with parameter 1. Let ")#mi("S=(\\sum_{i=1}^n x_i Z_i)^d/d!")#text(". The coefficient of a monomial ")#mi("\\prod_i x_i^{d_i}")#text(" in ")#mi("S")#text(" is ")#mi("\\prod_i Z_i^{d_i}/d_i!")#text(" whose expected value is ")#mi("1")#text(" because the ")#mi("d_i")#text("‘th moment of ")#mi("Z_i")#text(" is ")#mi("d_i!")#text(". So ")#mi("h_d(x_1,\\dots,x_n)")#text(" is the expected value of ")#mi("S")#text(", clearly non-negative for even ")#mi("d")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e1e22ba22bb8e7519de62e3e79590634cb7c127c0f6ea624ed69c047db54363-2bad83a8e97c6063183327a3966e81c4661e6b05885b26049e2b30fd1fdf1e0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Synia")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484726")[#strong[#text("Synia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2017")])]

#text("Really nice ! Another way of seeing that ")#mi("h_d(x_1, \\dots, x_n) = \\mathbb{E}\\left( \\frac{1}{d!}  ( \\sum_{j = 1}^n x_j Z_j )^d  \\right)")#text(" is by writing ")#mi("h_d(x_1, \\dots, x_n) = [t^d] \\prod_{j = 1}^n \\frac{1}{1 - x_j t} =[t^d] \\prod_{j = 1}^n \\mathbb{E}\\left( e^{t x_j Z_j} \\right)")

#mi("=  [t^d] \\mathbb{E}\\left( e^{t \\sum_{j = 1}^n x_j Z_j} \\right)")#text(" where ")#mi("[t^d] f(t)")#text(" is the ")#mi("d")#text("-th Fourier coefficient (here, we suppose ")#tao-math("\\left|t x_j \\right| < 1", block: false)#text(" for all ")#mi("j")#text(" for the convergence).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2017")])]

#text("Very nice! I was hunting for a probabilistic interpretation of ")#mi("h_d")#text(" (this being another major way to prove positivity results, besides sum of squares methods and induction methods) but did not see this very neat moment interpretation. I think this is a good demonstration of the power of the probabilistic method.")

#text("(It now makes me wonder more generally if ")#link("https://en.wikipedia.org/wiki/Schur_polynomial")[#text("Schur polynomials")]#text(" have a similarly nice probabilistic interpretation. Of course, one can simply plug in the probabilistic interpretation of ")#mi("h_d")#text(" into the first Jacobi-Trudi formula, but I’m hoping for something more than this…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-634145")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("In fact Hunter’s result says that ")#tao-math("h_{2r}(x_1,....,x_n) \\ge \\frac{\\left|\\left|x\\right|\\right|^{2r}}{2^rr!};", block: false)#text(" I strongly believe that this probabilistic argument can be amplified to deduce Hunter’s original inequality too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484756")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("Very nice indeed!")

#text("I would say that this is morally a “sum of squares” argument; you have expressed $h_d$ as an integral of a $d$-th power. I imagine that, by replacing the integral by a suitable average over finitely many values, you could obtain a literal sum of squares expression.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("True; indeed it looks like all one needs to do is to replace the exponential random variable ")#mi("Z")#text(" by a discrete random variable which matches moments with the continuous one up to ")#mi("d^{th}")#text(" order and one would get a discrete representation. (The existence of such a discrete random variable follows from ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem_(convex_hull)")[#text("Caratheodory’s theorem")]#text(".)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48bb462aaff9e7e8d9fe5e4c65f239f3b78cc273fbe8621b5260960e35d67f7a-257395cd2b87a6b2137c0d06fac5df78ff612d7f2fc9b5d3d077c969347fd3b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arash B")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484759")[#strong[#text("Arash B")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("“To establish this criterion, we again induct on $d$ “; Isn’t it induction on $n$?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484769")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2017")])]

#text("You might already know this, but there is a positivity property for Schur polynomials: If ")#mi("\\lambda")#text(" is a partition with all even parts, then ")#mi("s_{\\lambda}(x_1, \\ldots, x_n)")#text(" is nonnegative for any real inputs. (And, I think, positive unless the inputs are all zero, but I’m not sure.)")

#text("By symmetry and continuity, it is enough to show that ")#mi("s_{\\lambda}(x_1, \\ldots, x_n) > 0")#text(" when ")#mi("x_1 > x_2 > \\cdots x_n")#text(". We recall the ratio of alternants formula: ")#mi("s_{\\lambda}(x_1, \\ldots, x_n) = \\det(x_i^{\\lambda_j + n -j})/\\det(x_i^{n-j})")#text(". So it is enough to show that ")#mi("\\det(x_i^{\\lambda_j + n -j}) > 0")#text(" when ")#mi("x_1 > x_2 > \\cdots x_n")#text(" and all the ")#mi("\\lambda_i")#text(" are even. By continuity, it is enough to show that ")#mi("\\det(x_i^{\\lambda_j + n -j}) \\neq 0")#text(" under these conditions.")

#text("Suppose to the contrary that ")#mi("\\det(x_i^{\\lambda_j + n -j}) = 0")#text(". Then there is a linear relation ")#mi("\\sum_j c_j x_i^{\\lambda_j+n-j} = 0")#text(". In other words, the polynomial ")#mi("\\sum c_j x^{\\lambda_j+n-j}")#text(" has ")#mi("n")#text(" distinct real roots. But the condition that the parts of ")#mi("\\lambda")#text(" are even means that that the exponents ")#mi("\\lambda_j+n-j")#text(" alternate in parity, which means Descartes’ Rule of Signs will permit only ")#mi("n-1")#text(" real roots, a contradiction. ")#mi("\\square")

#text("If we wanted to show strict positivity, we’d need to show that ")#mi("x_i-x_j")#text(" only divided ")#mi("\\det(x_i^{\\lambda_j + n -j}) \\neq 0")#text(" once; we’ve shown strict positivity off the locus where two of the ")#mi("x_i")#text(" are equal already.")

#text("I believe this was an exercise in Barvinok’s convexity textbook, but I don’t have it at hand to check.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e1e22ba22bb8e7519de62e3e79590634cb7c127c0f6ea624ed69c047db54363-2bad83a8e97c6063183327a3966e81c4661e6b05885b26049e2b30fd1fdf1e0b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Synia")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484795")[#strong[#text("Synia")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("This gives an alternative proof for the positivity of ")#mi("h_{2n}")#text(" since ")#mi("h_n = s_{(n)}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("Nice! (I knew one could use the rule of signs to prove that the Schur polynomials were positive when the inputs ")#mi("x_1,\\dots,x_n")#text(" were positive, but this was already obvious from the Young tableau expansion.)")

#text("Unfortunately most Schor polynomials can vanish outside of the origin; indeed, by testing a Schur polynomial ")#mi("s_\\lambda")#text(" on a basis vector ")#mi("(1,0,\\dots,0)")#text(" using the Young tableau expansion, one gets zero unless ")#mi("\\lambda")#text(" has only one non-zero part. So the only strictly positive definite Schur polynomials are the ")#mi("h_{2n}")#text(". (Apoorva Khare and I have an upcoming paper where we had a theorem that worked for all strictly positive definite Schur polynomials, so it was a bit disappointing to realise how few of them there were.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74047085658311e5349c7bf261644db4cc531258f2fcd249b1b8dc6d1e7d7727-125bc6d853a4d9ac63b30cfa6bb40418c92c0989247e29826386128e35db20cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-484832")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2017")])]

#text("Oh wow, I should have noticed that about ")#mi("s_{\\lambda}(1,0,0,\\ldots,0)=0")#text(". Huh, I wonder what the real points where ")#mi("s_{\\lambda}")#text(" vanishes, when all parts of ")#mi("\\lambda")#text(" are even, look like.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db2092993fb6ff152ff35d1bfbcd5b748dbb7a1e45a25789dd8466550a5a273f-3cb5a710d8e45b1a24b5d97ac559bb43710580ff3437b203ae613a0628a943e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-485233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2017")])]

#text("Theorem 1(i) is easy if all the reals have the same sign. Otherwise, without loss of generality, ")#mi("x_1")#text(" is positive and ")#mi("x_2")#text(" is negative. The identity")

#mi("\\displaystyle \\frac{1}{1-tx_1} \\frac{1}{1-tx_2} = \\frac{x_1}{x_1+(-x_2)} \\frac{1}{1-tx_1} + \\frac{(-x_2)}{x_1+(-x_2)} \\frac{1}{1-tx_2},")

#text("shows that ")#mi("h_d(x_1,x_2,\\dots,x_n)")#text(" is a convex combination of ")#mi("h_d(x_1,0,\\dots,x_n)")#text(" and ")#mi("h_d(0,x_2,\\dots,x_n)")#text(". These are each strictly positive for even ")#mi("d")#text(" by induction on the number of non-zero components.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db2092993fb6ff152ff35d1bfbcd5b748dbb7a1e45a25789dd8466550a5a273f-3cb5a710d8e45b1a24b5d97ac559bb43710580ff3437b203ae613a0628a943e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-485286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("Here is a proof of strict positivity, using log-convexity.")#linebreak()#text(" This approach gives Hunter’s bound")#linebreak()#text(" ")#mi("h_{2r}\\geq (\\sum x_i^2)^r/2^r r!")#text(", which I don’t see a way to get just using moment generating functions.")

#text("Define ")#mi("\\mathcal C")#text(" to be the set of exponential generating functions of log-convex sequences.")#linebreak()#text(" The Davenport-Pólya theorem says that ")#mi("\\mathcal C")#text(" is closed under products.")

#text("I will use the following lemma. If ")#mi("f,g\\in\\mathcal C")#text(" then the even coefficients of ")#mi("f(t)g(-t)")#text(" are non-negative.")#linebreak()#text(" Proof: the coefficient of ")#mi("t^n")#text(" is ")#mi("\\sum_{i} \\binom{n}{i} (-1)^i f_i g_{n-i}")#text(".")#linebreak()#text(" The sequence ")#mi("f_0g_n,f_1g_{n-1},\\dots,f_ng_0")#text(" is log-convex, which implies it is convex.")#linebreak()#text(" But a sum of the form ")#mi("\\sum_{i} \\binom{n}{i} (-1)^i c_i")#text(" is non-negative if ")#mi("n")#text(" is even and ")#mi("c_0,\\dots,c_n")#text(" is convex. QED.")

#text("Assume ")#mi("x_1,\\dots,x_m > 0")#text(" and ")#mi("0 > x_{m+1},\\dots,x_n")#text(". By abuse of notation, write ")#mi("h_d=h_d(x_1,\\dots,x_n)")#text(", and ")#mi("h_d^+=h_d(x_1,\\dots,x_m)")#text(", and ")#mi("h_d^-=h_d(-x_{m+1},\\dots,-x_n)")#text(". We have the identity ")#mi("\\sum_{d\\geq 0} h_d t^d = (\\sum_{d\\geq 0} h_d^+ t^d) (\\sum_{d\\geq 0} h_d^- (-t)^d).")#text(" Note ")#mi("\\mathcal C")#text(" contains all functions of the form ")#mi("1/(1-tx)")#text(" for ")#mi("x>0")#text(", and so contains ")#mi("\\sum_{d\\geq 0} h_d^+ t^d")#text(" and ")#mi("\\sum_{d\\geq 0} h_d^- t^d")#text(" by the formula (1) in the main post. By the lemma above, ")#mi("h_d\\geq 0")#text(" for even ")#mi("d")#text(".")

#text("To get a bound in terms of ")#mi("\\sum x_i^2")#text(", note that ")#mi("\\exp(-x^2t^2)/(1-tx)")#text(" is")#linebreak()#text(" in ")#mi("\\mathcal C")#text(" for ")#mi("x>0")#text(":")#linebreak()#text(" the first few coefficients of ")#mi("(tx)^k/k!")#text(" are")#linebreak()#text(" [A000266](")#link("https://oeis.org/A000266")[#text("https://oeis.org/A000266")]#text("), and they tend quickly to ")#mi("k!e^{-1/2}(1+o(1))")#text(" which is log-convex.")#linebreak()#text(" By the same argument as before, the even coefficients of")#linebreak()#text(" ")#mi("\\exp(-\\sum x_i^2t^2/2)\\sum_{d\\geq 0} h_d t^d")#linebreak()#text(" are non-negative. Multiplying by ")#mi("\\exp(\\sum x_i^2t^2/2)")#linebreak()#text(" gives the bound ")#mi("h_{2r}\\geq (\\sum x_i^2)^r/2^r r!")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db2092993fb6ff152ff35d1bfbcd5b748dbb7a1e45a25789dd8466550a5a273f-3cb5a710d8e45b1a24b5d97ac559bb43710580ff3437b203ae613a0628a943e1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-485295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("Sorry, I realised that proof doesn’t work – convexity by itself isn’t strong enough to guarantee those even coefficients are non-negative in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/173cb275362442e0a259d5738cb4799f6f558b4b4799adeacda1f93e2e095745-780999f884c678d5c0b1f84272c4349b8336408f6053fe1c3e698147516facfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Silouanos_Brazitikos")]], [#link("https://terrytao.wordpress.com/2017/08/06/schur-convexity-and-positive-definiteness-of-the-even-degree-complete-homogeneous-symmetric-polynomials/#comment-691567")[#strong[#text("Silouanos_Brazitikos")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2026")])]

#text("Dear Terry,")#linebreak()#text("Here is a recent sharp lower bound for (CHP), confirming Hunter’s conjecture.")#linebreak()#link("https://arxiv.org/abs/2512.12254")[#text("https://arxiv.org/abs/2512.12254")]
]
