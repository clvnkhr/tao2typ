// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/
// Converted to Typst by tao2typ: "2026-10-14T16:34:59.287453+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The cubic nonlinear Schrödinger equation in two dimensions with radial data", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The cubic nonlinear Schrödinger equation in two dimensions with radial data")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/")[#text("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0707.3188")[#text("The cubic nonlinear Schrödinger equation in two dimensions with radial data")]#text("“, joint with ")#link("http://www.math.ucla.edu/~killip/")[#text("Rowan Killip")]#text(" and ")#link("http://www.math.ias.edu/~mvisan/")[#text("Monica Visan")]#text(", and submitted to the ")#link("http://annals.princeton.edu/")[#text("Annals of Mathematics")]#text(". This is a sequel of sorts to my paper with Monica and Xiaoyi Zhang, in which we established global ")#link("http://tosio.math.toronto.edu/wiki/index.php/Well-posedness")[#text("well-posedness")]#text(" and ")#link("http://tosio.math.toronto.edu/wiki/index.php/Scattering")[#text("scattering")]#text(" for the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Defocusing")[#text("defocusing ")]#text("mass-critical nonlinear Schrödinger equation (NLS) ")#tao-math("iu_t + \\Delta u = \\left|u\\right|^{4/d} u", block: false)#text(" in three and higher dimensions ")#mi("d \\geq 3")#text(" assuming spherically symmetric data. (This is another example of the recently active field of critical dispersive equations, in which both coarse and fine scales are (just barely) nonlinearly active, and propagate at different speeds, leading to significant technical difficulties.)")

#text("In this paper we obtain the same result for the defocusing ")#link("http://tosio.math.toronto.edu/wiki/index.php/Cubic_NLS_on_R2")[#text("two-dimensional mass-critical NLS")]#text(" ")#tao-math("iu_t + \\Delta u= \\left|u\\right|^2 u", block: false)#text(", as well as in the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Focusing")[#text("focusing")]#text(" case ")#tao-math("iu_t + \\Delta u= -\\left|u\\right|^2 u", block: false)#text(" under the additional assumption that the mass of the initial data is strictly less than the mass of the ground state. (When mass equals that of the ground state, there is an explicit example, built using the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Pseudoconformal_transformation")[#text("pseudoconformal transformation")]#text(", which shows that solutions can blow up in finite time.) In fact we can show a slightly stronger statement: for spherically symmetric focusing solutions with arbitrary mass, we can show that the first singularity that forms concentrates at least as much mass as the ground state.")

#metadata(none) <tao-a68f576c53270f633dcd>#linebreak()#text(" Like the higher-dimensional paper, the first step is to use the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Concentration-compactness")[#text("concentration-compactness")]#text(" theory of NLS to reduce matters to studying solutions which are almost periodic modulo the symmetries of the NLS. At this point, though, we have to take a slightly different tack. In higher dimensions we have the luxury (at least in principle) of using ")#link("http://tosio.math.toronto.edu/wiki/index.php/Morawetz_inequality")[#text("Morawetz estimates")]#text(", although some truncation in space and frequency is needed before these estimates are applicable in the available regularity for these solutions (which is ")#mi("L^2")#text("). In one and two dimensions, these estimates cease to be coercive and are essentially useless for us; furthermore, even in higher dimensions, the Morawetz inequality is not well suited for the focusing problem when the mass gets too close to that of the ground state. The natural substitute for these inequalities is the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Virial_identity")[#text("virial identity")]#text(", which works in all dimensions and still has good coercivity properties in the focusing case when the mass gets close to that of the ground state. However, it turns out that the virial identity does not give particularly useful results if applied immediately. Instead, we give a combinatorial argument (which works in all dimensions, both for focusing and defocusing, and does not use spherical symmetry) which allows us to reduce even further, from almost periodic solutions to three special “enemy” solutions, namely a soliton-like solution, a self-similar solution, and a solution with a double high-low frequency cascade. We then eliminate each of these enemies by regularity arguments based on ")#link("http://tosio.math.toronto.edu/wiki/index.php/Duhamel's_formula")[#text("Duhamel’s formula")]#text(". For instance, in the self-similar case one can use Duhamel’s formula to show that these solutions have finite energy, at which point the self-similar blowup is inconsistent with energy conservation. A somewhat similar situation occurs with the double high-low frequency cascade. Finally, for the soliton-like solution, Duhamel’s formula (together with an incoming/outgoing radiation decomposition from harmonic analysis, based ultimately on ")#link("http://en.wikipedia.org/wiki/Hankel_function")[#text("Hankel functions")]#text(") one also obtains finite energy, which turns out to be enough, together with the virial identity, to be inconsistent with soliton-like behavior.")

#text("The arguments in this paper seem to suggest that a reasonable strategy to establish critical global well-posedness and scattering is to pass to very special almost-periodic solutions, use Duhamel’s formula to establish as much regularity as one can, and then use all the conservation laws and monotonicity formulae that are available to derive a contradiction. It continues to be a challenge to make these arguments work in the non-radial case, when translation (and ")#link("http://tosio.math.toronto.edu/wiki/index.php/Galilean")[#text("Galilean")]#text(") symmetries become a significant problem.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-5005")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2007")]

#text("[…] The cubic nonlinear Schrödinger equation in two dimensions with radial data I’ve just uploaded to the arXiv the paper “The cubic nonlinear Schrödinger equation in two dimensions with […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weakly turbulent solutions for the cubic defocusing nonlinear Schr”odinger equation « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-32031")[#strong[#text("Weakly turbulent solutions for the cubic defocusing nonlinear Schr”odinger equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2008")])]

#text("[…] is conjectured to disperse to a linear solution (i.e. to scatter) from any finite mass data (see this earlier post for the current status of that conjecture). Thus our theorem can be viewed as evidence that the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-39286")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Dear Professor Tao:")

#text("I read your “A Pseudoconformal Compactification of the Nonlinear Schrodinger Equation and Applications” as preparation to reading “The cubic nonlinear Schrödinger equation in two dimensions with radial data” and found the Lens Transform very interesting; I am completely new to Schrodinger Equation itself.")

#text("I have just one general question; that is, is there any application of this Transform to other PDEs, in particular, to parabolic PDEs such as Nonlinear Heat or Navier-Stokes and in what kind of situations would it become helpful? Any elaboration would be appreciated.")

#text("Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-39294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Dear Student,")

#text("I don’t know about the lens transform, but the pseudoconformal transform, at least, has a Wick rotated counterpart for the heat equation: if ")#mi("u_t = \\Delta u")#text(", then the transformed function")

#tao-math("v(t,x) = \\left|t\\right|^{-d/2} u( -1/t, x/t ) e^{-\\left|x\\right|^2/2t}", block: false)

#text("also solves the heat equation (if I did my calculations correctly). This may possibly extend nicely to the nonlinear heat equation, particularly with the conformal nonlinearity |u|^{4/n} u, though I haven’t checked this. My guess is that Navier-Stokes will become a bit strange under this transformation, though. In principle this transform connects asymptotic behavior of the equation to local behavior, but the presence of the exponential weight is likely to cause some problems when inverting the transform (in particular, one will not stay in Sobolev spaces when doing so).")

#text("For the lens transform it appears (though I may have made a sign error here) that one may have to complexify either space or time to push it through for heat equations, which does not look promising…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-453470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2015")])]

#text("Dear Professor Tao,")#linebreak()#text(" it came to my attention recently that the L2 critical Schrodinger-Debye System does not blow up in dimension N=2, even in the focusing case. This strikes me as very odd. Do you have some insight on this phenomena? Thank you so much for your help!")

#text("Best regards,")#linebreak()#text(" John Tosh")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-453497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2015")])]

#text("I believe this is due to the delayed effects of the nonlinearity in Schrodigner-Debye, making the equation subcritical rather than critical. In NLS, a solution that is concentrating its mass at a spatial scale ")#mi("\\sim 1/N")#text(" will exhibit significant self-interaction over timescales ")#mi("\\sim 1/N^2")#text(", but in Schrodinger-Debye the same level of self-interaction only occurs after a time delay of ")#mi("\\sim 1")#text(". This significantly reduces the scope for blowup. (On the other hand, the conservation laws are less favourable for Schrodinger-Debye, so it still takes some effort to exclude blowup over long periods of time.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cafed11789aff9bab8095bdbe79c5dc2bd8ccfa4034744c408158f4c7e11b1d-6760e5caf122a76321fb2b1d7a86897c712303c5b1f04fa3743301de52e92414.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Семен Верховцев")]], [#link("https://terrytao.wordpress.com/2007/07/23/the-cubic-nonlinear-schrodinger-equation-in-two-dimensions-with-radial-data/#comment-637965")[#strong[#text("Семен Верховцев")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2021")])]

#text("There is a small typo:")#linebreak()#text(" “…At this point, though, we have to take a slightly different tack (task).”")

#emph[#text("[See ")#link("https://dictionary.cambridge.org/dictionary/english/change-your-tack")[#text("https://dictionary.cambridge.org/dictionary/english/change-your-tack")]#text(" -T]")]
]
