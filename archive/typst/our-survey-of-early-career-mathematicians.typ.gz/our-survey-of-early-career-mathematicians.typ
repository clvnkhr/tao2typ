// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/
// Converted to Typst by tao2typ: "2026-11-12T01:30:54.497031+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Our Survey of Early Career Mathematicians", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Our Survey of Early Career Mathematicians")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/")[#text("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-12 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://abrandenberger.github.io")[#text("Anna Brandenberger")]#text(", ")#link("https://math.mit.edu/~hannamul/")[#text("Hanna Mularczyk")]#text(", and ")#link("https://dorawoodruff.com/")[#text("Dora Woodruff")]#text(" (MIT). This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("In late September and early October, we distributed a survey of early career mathematicians. Our goals were to take a “temperature check” of the community, and to give early career mathematicians a centralized, targeted platform to share their views on AI (the survey was ")#emph[#text("not")]#text(" a rigorous data analysis effort). The personal stakes are highest for grad students and postdocs, who face job insecurity and funding instability, so it’s important that our voices are taken into account. We worry that our concerns will be deprioritized, or even misrepresented, without collective resources like this survey.")

#metadata(none) <tao-75ab8e371cc7e0215b9d>

#text("On October 29th, we posted the results of this survey to the ")#link("https://arxiv.org/abs/2610.40584")[#text("arXiv")]#text(" (history and overview). In the end, over 260 mathematicians filled out the survey, representing around 60 institutions and at least 5 countries. Many of them left free responses in addition to answering the multiple choice questions.")

#text("This blog post is an invitation to take a look at the survey results. Some of the results surprised and/or dismayed us: in particular, Question 3.2, Question 3.3, Question 5.2, and Question 6.1, which concern career outlook and research motivation. It’s also important to point out that nearly all of the responses were collected before October 6th, capturing a sample of thoughts from a specific context: we nervously wonder how different this data would look today. As journals, hiring committees, and faculty members make decisions about the future, we urge them to take these survey results into account — and to continue fostering discussions between senior and junior mathematicians.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/#comment-699300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("I’m curious what the effect the October 6 drop had. For me, as a junior mathematician in the midst of deciding their future, the October 6 drop is doing a pretty good job trying to convince me to stay in mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/#comment-699303")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("That seems like a radical view. May I ask why?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/#comment-699307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("Thank you for the survey! I would like to push back on the claim that “the personal stakes are highest for grad students and postdocs”. The job market will not change in the next several years, as there is too much inertia in the system. In the foreseeable future grad students and postdocs will still be needed to teach. The universities simply cannot function without them. If one takes the doomer view that mathematical profession will collapse in a few years, which I don’t believe for a second, then the stakes are highest for the mid career mathematicians (which isn’t my situation, by the way). Young people are on average the most adaptable. In the worst case they can drop everything and find another occupation, and indeed, it has always been true that most math Ph.D.s eventually leave academia. The mid career mathematicians have invested too many years into the profession, and it will be hard for them to start afresh. Those closer to retirement can simply retire, but the mid career ones cannot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/#comment-699310")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2026")])]

#text("I mean, mid-career mathematicians can simply go on leave for a few years and keep their jobs…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/11/09/our-survey-of-early-career-mathematicians/#comment-699319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2026")])]

#text("You are misinformed. There is no such a thing as “go on leave for a few years and keep your job”. There may be some exceptional cases, for really big shots, not certainly not for a regular tenured professor. Besides, even if the leave is granted, it will be unpaid. How would you sustain yourself?")
]
]
]
