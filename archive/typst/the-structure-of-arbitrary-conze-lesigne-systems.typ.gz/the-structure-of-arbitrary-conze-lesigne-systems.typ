// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/
// Converted to Typst by tao2typ: "2026-10-14T15:20:42.091728+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The structure of arbitrary Conze-Lesigne systems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The structure of arbitrary Conze-Lesigne systems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 December 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/")[#text("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://asgarjam.wixsite.com/home")[#text("Asgar Jamneshan")]#text(", ")#link("http://www.math.huji.ac.il/~orshalom/")[#text("Or Shalom")]#text(", and myself have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2112.02056")[#text("The structure of arbitrary Conze–Lesigne systems")]#text("“. As the title suggests, this paper is devoted to the structural classification of Conze-Lesigne systems, which are a type of measure-preserving system that are “quadratic” or of “complexity two” in a certain technical sense, and are of importance in the theory of multiple recurrence. There are multiple ways to define such systems; here is one. Take a countable abelian group ")#mi("{\\Gamma}")#text(" acting in a measure-preserving fashion on a probability space ")#mi("{(X,\\mu)}")#text(", thus each group element ")#mi("{\\gamma \\in \\Gamma}")#text(" gives rise to a measure-preserving map ")#mi("{T^\\gamma: X \\rightarrow X}")#text(". Define the ")#emph[#text("third Gowers-Host-Kra seminorm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{U^3(X)}}", block: false)#text(" of a function ")#mi("{f \\in L^\\infty(X)}")#text(" via the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^3(X)}^8 := \\lim_{n \\rightarrow \\infty} {\\bf E}_{h_1,h_2,h_3 \\in \\Phi_n} \\int_X \\prod_{\\omega_1,\\omega_2,\\omega_3 \\in \\{0,1\\}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("{\\mathcal C}^{\\omega_1+\\omega_2+\\omega_3} f(T^{\\omega_1 h_1 + \\omega_2 h_2 + \\omega_3 h_3} x)\\ d\\mu(x)")]]

#text("where ")#mi("{\\Phi_n}")#text(" is a Folner sequence for ")#mi("{\\Gamma}")#text(" and ")#mi("{{\\mathcal C}: z \\mapsto \\overline{z}}")#text(" is the complex conjugation map. One can show that this limit exists and is independent of the choice of Folner sequence, and that the ")#mi("{\\| \\|_{U^3(X)}}")#text(" seminorm is indeed a seminorm. A Conze-Lesigne system is an ergodic measure-preserving system in which the ")#mi("{U^3(X)}")#text(" seminorm is in fact a norm, thus ")#tao-math("{\\left\\|f\\right\\|_{U^3(X)}>0}", block: false)#text(" whenever ")#mi("{f \\in L^\\infty(X)}")#text(" is non-zero. Informally, this means that when one considers a generic parallelepiped in a Conze–Lesigne system ")#mi("{X}")#text(", the location of any vertex of that parallelepiped is more or less determined by the location of the other seven vertices. These are the important systems to understand in order to study “complexity two” patterns, such as arithmetic progressions of length four. While not all systems ")#mi("{X}")#text(" are Conze-Lesigne systems, it turns out that they always have a maximal factor ")#mi("{Z^2(X)}")#text(" that is a Conze-Lesigne system, known as the ")#emph[#text("Conze-Lesigne factor")]#text(" or the ")#emph[#text("second Host-Kra-Ziegler factor")]#text(" of the system, and this factor controls all the complexity two recurrence properties of the system.")

#text("The analogous theory in complexity one is well understood. Here, one replaces the ")#mi("{U^3(X)}")#text(" norm by the ")#mi("{U^2(X)}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{U^2(X)}^4 := \\lim_{n \\rightarrow \\infty} {\\bf E}_{h_1,h_2 \\in \\Phi_n} \\int_X \\prod_{\\omega_1,\\omega_2 \\in \\{0,1\\}} {\\mathcal C}^{\\omega_1+\\omega_2} f(T^{\\omega_1 h_1 + \\omega_2 h_2} x)\\ d\\mu(x)", block: true)]]

#text("and the ergodic systems for which ")#mi("{U^2}")#text(" is a norm are called ")#emph[#text("Kronecker systems")]#text(". These systems are completely classified: a system is Kronecker if and only if it arises from a compact abelian group ")#mi("{Z}")#text(" equipped with Haar probability measure and a translation action ")#mi("{T^\\gamma \\colon z \\mapsto z + \\phi(\\gamma)}")#text(" for some homomorphism ")#mi("{\\phi: \\Gamma \\rightarrow Z}")#text(" with dense image. Such systems can then be analyzed quite efficiently using the Fourier transform, and this can then be used to satisfactory analyze “complexity one” patterns, such as length three progressions, in arbitrary systems (or, when translated back to combinatorial settings, in arbitrary dense sets of abelian groups).")

#text("We return now to the complexity two setting. The most famous examples of Conze-Lesigne systems are (order two) ")#emph[#text("nilsystems")]#text(", in which the space ")#mi("{X}")#text(" is a quotient ")#mi("{G/\\Lambda}")#text(" of a two-step nilpotent Lie group ")#mi("{G}")#text(" by a lattice ")#mi("{\\Lambda}")#text(" (equipped with Haar probability measure), and the action is given by a translation ")#mi("{T^\\gamma x = \\phi(\\gamma) x}")#text(" for some group homomorphism ")#mi("{\\phi: \\Gamma \\rightarrow G}")#text(". For instance, the Heisenberg ")#mi("{{\\bf Z}}")#text("-nilsystem")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} 1 & {\\bf R} & {\\bf R} \\\\ 0 & 1 & {\\bf R} \\\\ 0 & 0 & 1 \\end{pmatrix} / \\begin{pmatrix} 1 & {\\bf Z} & {\\bf Z} \\\\ 0 & 1 & {\\bf Z} \\\\ 0 & 0 & 1 \\end{pmatrix}")]]

#text("with a shift of the form")

#align(center)[#tao-fit-display[#mitex("Tx = \\begin{pmatrix} 1 & \\alpha & 0 \\\\ 0 & 1 & \\beta \\\\ 0 & 0 & 1 \\end{pmatrix} x")]]

#text("for ")#mi("{\\alpha,\\beta}")#text(" two real numbers with ")#mi("{1,\\alpha,\\beta}")#text(" linearly independent over ")#mi("{{\\bf Q}}")#text(", is a Conze-Lesigne system. As the base case of a well known ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2150389")[#text("result of Host and Kra")]#text(", it is shown in fact that all Conze-Lesigne ")#mi("{{\\bf Z}}")#text("-systems are inverse limits of nilsystems (previous results in this direction were obtained by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=989141")[#text("Conze-Lesigne")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1412607")[#text("Furstenberg-Weiss")]#text(", and others). Similar results are known for ")#mi("{\\Gamma}")#text("-systems when ")#mi("{\\Gamma}")#text(" is finitely generated, thanks to the ")#link("https://etd.ohiolink.edu/apexprod/rws_olink/r/1501/10?clear=10&p10_accession_num=osu1243973834")[#text("thesis work of Griesmer")]#text(" (with further proofs by ")#link("https://arxiv.org/abs/1909.11349")[#text("Gutman-Lian")]#text(" and ")#link("https://arxiv.org/abs/1803.08758")[#text("Candela-Szegedy")]#text("). However, this is not the case once ")#mi("{\\Gamma}")#text(" is not finitely generated; as a recent ")#link("https://arxiv.org/abs/2105.00446")[#text("example of Shalom shows")]#text(", Conze-Lesigne systems need not be the inverse limit of nilsystems in this case.")

#text("Our main result is that even in the infinitely generated case, Conze-Lesigne systems are still inverse limits of a slight generalisation of the nilsystem concept, in which ")#mi("{G}")#text(" is a locally compact Polish group rather than a Lie group:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Classification of Conze-Lesigne systems)")]#text(" Let ")#mi("{\\Gamma}")#text(" be a countable abelian group, and ")#mi("{X}")#text(" an ergodic measure-preserving ")#mi("{\\Gamma}")#text("-system. Then ")#mi("{X}")#text(" is a Conze-Lesigne system if and only if it is the inverse limit of translational systems ")#mi("{G/\\Lambda}")#text(", where ")#mi("{G}")#text(" is a nilpotent locally compact Polish group of nilpotency class two, and ")#mi("{\\Lambda}")#text(" is a lattice in ")#mi("{G}")#text(" (and also a lattice in the commutator group ")#mi("{[G,G]}")#text("), with ")#mi("{G/\\Lambda}")#text(" equipped with the Haar probability measure and a translation action ")#mi("{T^\\gamma x = \\phi(\\gamma) x}")#text(" for some homomorphism ")#mi("{\\phi: \\Gamma \\rightarrow G}")#text(".")
]

#text("In a forthcoming companion paper to this one, Asgar Jamneshan and I will use this theorem to derive an inverse theorem for the Gowers norm ")#mi("{U^3(G)}")#text(" for an arbitrary finite abelian group ")#mi("{G}")#text(" (with no restrictions on the order of ")#mi("{G}")#text(", in particular our result handles the case of even and odd ")#tao-math("{\\left|G\\right|}", block: false)#text(" in a unified fashion). In principle, having a higher order version of this theorem will similarly allow us to derive inverse theorems for ")#mi("{U^{s+1}(G)}")#text(" norms for arbitrary ")#mi("{s}")#text(" and finite abelian ")#mi("{G}")#text("; we hope to investigate this further in future work.")

#text("We sketch some of the main ideas used to prove the theorem. The existing machinery developed by Conze-Lesigne, Furstenberg-Weiss, Host-Kra, and others allows one to describe an arbitrary Conze-Lesigne system as a group extension ")#mi("{Z \\rtimes_\\rho K}")#text(", where ")#mi("{Z}")#text(" is a Kronecker system (a rotational system on a compact abelian group ")#mi("{Z = (Z,+)}")#text(" and translation action ")#mi("{\\phi: \\Gamma \\rightarrow Z}")#text("), ")#mi("{K = (K,+)}")#text(" is another compact abelian group, and the cocycle ")#mi("{\\rho = (\\rho_\\gamma)_{\\gamma \\in \\Gamma}}")#text(" is a collection of measurable maps ")#mi("{\\rho_\\gamma: Z \\rightarrow K}")#text(" obeying the cocycle equation ")#metadata(none) <tao-a8a6d7b00a53746047da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho_{\\gamma_1+\\gamma_2}(x) = \\rho_{\\gamma_1}(T^{\\gamma_2} x) + \\rho_{\\gamma_2}(x)")]]

#text(" ")#text(" for almost all ")#mi("{x \\in Z}")#text(". Furthermore, ")#mi("{\\rho}")#text(" is of “type two”, which means in this concrete setting that it obeys an additional equation")

#metadata(none) <tao-87a7dd22045e295f62db>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\rho_\\gamma(x + z_1 + z_2) - \\rho_\\gamma(x+z_1) - \\rho_\\gamma(x+z_2) + \\rho_\\gamma(x)")]]

#align(center)[#tao-fit-display[#mitex("= F(x + \\phi(\\gamma), z_1, z_2) - F(x,z_1,z_2)")]]

#text("for all ")#mi("{\\gamma \\in \\Gamma}")#text(" and almost all ")#mi("{x,z_1,z_2 \\in Z}")#text(", and some measurable function ")#mi("{F: Z^3 \\rightarrow K}")#text("; roughly speaking this asserts that ")#mi("{\\phi_\\gamma}")#text(" is “linear up to coboundaries”. For technical reasons it is also convenient to reduce to the case where ")#mi("{Z}")#text(" is separable. The problem is that the equation ")#link(<tao-87a7dd22045e295f62db>)[#text("(2)")]#text(" is unwieldy to work with. In the model case when the target group ")#mi("{K}")#text(" is a circle ")#mi("{{\\bf T} = {\\bf R}/{\\bf Z}}")#text(", one can use some Fourier analysis to convert ")#link(<tao-87a7dd22045e295f62db>)[#text("(2)")]#text(" into the more tractable ")#emph[#text("Conze-Lesigne equation")]

#metadata(none) <tao-d192375885ec7d50df12>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\rho_\\gamma(x+z) - \\rho_\\gamma(x) = F_z(x+\\phi(\\gamma)) - F_z(x) + c_z(\\gamma)")]]

#text("for all ")#mi("{\\gamma \\in \\Gamma}")#text(", all ")#mi("{z \\in Z}")#text(", and almost all ")#mi("{x \\in Z}")#text(", where for each ")#mi("{z}")#text(", ")#mi("{F_z: Z \\rightarrow K}")#text(" is a measurable function, and ")#mi("{c_z: \\Gamma \\rightarrow K}")#text(" is a homomorphism. (For technical reasons it is often also convenient to enforce that ")#mi("{F_z, c_z}")#text(" depend in a measurable fashion on ")#mi("{z}")#text("; this can always be achieved, at least when the Conze-Lesigne system is separable, but actually verifying that this is possible actually requires a certain amount of effort, which we devote an appendix to in our paper.) It is not difficult to see that ")#link(<tao-d192375885ec7d50df12>)[#text("(3)")]#text(" implies ")#link(<tao-87a7dd22045e295f62db>)[#text("(2)")]#text(" for any group ")#mi("{K}")#text(" (as long as one has the measurability in ")#mi("{z}")#text(" mentioned previously), but the converse turns out to fail for some groups ")#mi("{K}")#text(", such as ")#link("https://en.wikipedia.org/wiki/Solenoid_(mathematics)")[#text("solenoid groups")]#text(" (e.g., inverse limits of ")#mi("{{\\bf R}/2^n{\\bf Z}}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text("), as was essentially shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1325712")[#text("by Rudolph")]#text(". However, in our paper we were able to find a separate argument that also derived the Conze-Lesigne equation in the case of a cyclic group ")#mi("{K = \\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(". Putting together the ")#mi("{K={\\bf T}}")#text(" and ")#mi("{K = \\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(" cases, one can then derive the Conze-Lesigne equation for arbitrary compact abelian ")#emph[#text("Lie")]#text(" groups ")#mi("{K}")#text(" (as such groups are isomorphic to direct products of finitely many tori and cyclic groups). As has been known for some time (see e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2150389")[#text("this paper of Host and Kra")]#text("), once one has a Conze-Lesigne equation, one can more or less describe the system ")#mi("{X}")#text(" as a translational system ")#mi("{G/\\Lambda}")#text(", where the ")#emph[#text("Host-Kra group")]#text(" ")#mi("{G}")#text(" is the set of all pairs ")#mi("{(z, F_z)}")#text(" that solve an equation of the form ")#link(<tao-d192375885ec7d50df12>)[#text("(3)")]#text(" (with these pairs acting on ")#mi("{X \\equiv Z \\rtimes_\\rho K}")#text(" by the law ")#mi("{(z,F_z) \\cdot (x,k) := (x+z, k+F_z(x))}")#text("), and ")#mi("{\\Lambda}")#text(" is the stabiliser of a point in this system. This then establishes the theorem in the case when ")#mi("{K}")#text(" is a Lie group, and the general case basically comes from the fact (from Fourier analysis or the ")#link("https://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(") that an arbitrary compact abelian group is an inverse limit of Lie groups. (There is a technical issue here in that one has to check that the space of translational system factors of ")#mi("{X}")#text(" form a ")#link("https://en.wikipedia.org/wiki/Directed_set")[#text("directed set")]#text(" in order to have a genuine inverse limit, but this can be dealt with by modifications of the tools mentioned here.)")

#text("There is an additional technical issue worth pointing out here (which unfortunately was glossed over in some previous work in the area). Because the cocycle equation ")#link(<tao-a8a6d7b00a53746047da>)[#text("(1)")]#text(" and the Conze-Lesigne equation ")#link(<tao-d192375885ec7d50df12>)[#text("(3)")]#text(" are only valid almost everywhere instead of everywhere, the action of ")#mi("{G}")#text(" on ")#mi("{X}")#text(" is technically only a ")#emph[#text("near-action")]#text(" rather than a genuine action, and as such one cannot directly define ")#mi("{\\Lambda}")#text(" to be the stabiliser of a point without running into multiple problems. To fix this, one has to pass to a ")#emph[#text("topological model")]#text(" of ")#mi("{X}")#text(" in which the action becomes continuous, and the stabilizer becomes well defined, although one then has to work a little more to check that the action is still transitive. This can be done via Gelfand duality; we proceed using a mixture of a construction from ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3839640")[#text("this book of Host and Kra")]#text(", and the machinery in ")#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/")[#text("this recent paper of Asgar and myself")]#text(".")

#text("Now we discuss how to establish the Conze-Lesigne equation ")#link(<tao-d192375885ec7d50df12>)[#text("(3)")]#text(" in the cyclic group case ")#mi("{K = \\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(". As this group embeds into the torus ")#mi("{{\\bf T}}")#text(", it is easy to use existing methods obtain ")#link(<tao-d192375885ec7d50df12>)[#text("(3)")]#text(" but with the homomorphism ")#mi("{c_z}")#text(" and the function ")#mi("{F_z}")#text(" taking values in ")#mi("{{\\bf R}/{\\bf Z}}")#text(" rather than in ")#mi("{\\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(". The main task is then to fix up the homomorphism ")#mi("{c_z}")#text(" so that it takes values in ")#mi("{\\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(", that is to say that ")#mi("{Nc_z}")#text(" vanishes. This only needs to be done locally near the origin, because the claim is easy when ")#mi("{z}")#text(" lies in the dense subgroup ")#mi("{\\phi(\\Gamma)}")#text(" of ")#mi("{Z}")#text(", and also because the claim can be shown to be additive in ")#mi("{z}")#text(". Near the origin one can leverage the ")#link("https://en.wikipedia.org/wiki/Steinhaus_theorem")[#text("Steinhaus lemma")]#text(" to make ")#mi("{c_z}")#text(" depend linearly (or more precisely, homomorphically) on ")#mi("{z}")#text(", and because the cocycle ")#mi("{\\rho}")#text(" already takes values in ")#mi("{\\frac{1}{N}{\\bf Z}/{\\bf Z}}")#text(", ")#mi("{N\\rho}")#text(" vanishes and ")#mi("{Nc_z}")#text(" must be an eigenvalue of the system ")#mi("{Z}")#text(". But as ")#mi("{Z}")#text(" was assumed to be separable, there are only countably many eigenvalues, and by another application of Steinhaus and linearity one can then make ")#mi("{Nc_z}")#text(" vanish on an open neighborhood of the identity, giving the claim.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2021")])]

#text("A closing parenthesis is missing in the first displayed formula (and also in (2))")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helen")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638038")[#strong[#text("Helen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2021")])]

#text("thanks for your sharing~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638133")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2021")])]

#text("Is there an ultimate goal behind this machinery with (inverse) Gowers norms? Like, can it lead to solving Erdős–Turán conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2021")])]

#text("This is one direction to move towards, yes, though this current project is not really about the improvements to the quantitative bounds needed for the Erdos conjecture. This project is aimed instead towards enlarging the scope of the inverse Gowers theory beyond the two most intensively studied cases – cyclic groups and vector spaces over finite fields – to arbitrary finite abelian groups (and perhaps beyond that to other locally compact abelian, or even nilpotent, groups). This should presumably lead to the ability to count various additive patterns in dense subsets of such groups. I’m also hoping to find some conceptual unifications between the ergodic theoretic approaches of Host-Kra and others, the higher order Fourier analytic approach of Gowers etc., and the nilspace approach of Candela-Szegedy etc.; they are all partially related to each other right now but I feel like the connections should be tighter.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638157")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2021")])]

#text("You mentioned a few times on this blog your longer term project with Asgar Jamneshan to develop uncountable ergodic theory, with the hope of applying it to additive combinatorics. How far would you say you’ve gone in this project till now, and what would be a dream end goal ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638413")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2021")])]

#text("At this point we have uncountable versions of many of the basic ergodic theory results in the subject – Moore-Schmidt, Mackey-Zimmer, Furstenberg-Zimmer. What surprised us a bit though in our most recent project is that to get the combinatorial applications one did not directly need the uncountable setup; by using a suitable correspondence principle one could work instead with a separable system with the action of an (infinitely generated) countable group, and this separability conveyed some technical advantages. On the other hand, the uncountable theory still came in handy in the paper mentioned in this post, because at one point we needed to use Gelfand duality to generate a topological model of a (separable) measure-preserving system and ")#emph[#text("a priori")]#text(" this model could be inseparable (though once one established enough structural classification of these systems one could ")#emph[#text("a posteriori")]#text(" show that this was not in fact the case). Because we had already set up enough of the theory to work in the inseparable case, though, this turned out to not be a substantial difficulty though. (In contrast, a similar issue came up in the book of Host and Kra which was set up solely in the separable setting and to deal with this issue required a multi-page erratum in which separability of the topological model was established.) So the uncountable theory was not quite as decisive as we had initially thought but still came in handy in a supporting role.")

#text("It may still be though that the conceptually correct thing to do is to work out all the arguments in uncountable settings throughout and also in a “relative” or “conditional” framework (somewhat analogous to Grothendieck’s relative point of view) in which one is always working relative to some base factor, to which one may occasionally apply a base change operation. (In particular, it should be possible to set up the entire theory without the hypothesis of ergodicity, since a non-ergodic system is always ergodic relative to the invariant factor.) At present though it may be more trouble to set up this machinery properly than it is worth, since the applications we had in mind (inverse theorems for Gowers norms and Host-Kra seminorms) seem to have a shortcut that allows us to avoid needing the full machinery. So we’ll have to see what develops as the research continues…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8b2e751c941899671368185e840a640c16d6548e1a1a2e7cbfa7cc6c543761d-f4999ed38d5dd1f20b6f5e9a7903e9416caba6c25a72bc2cbf308b3fc2abc388.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Townsend")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638242")[#strong[#text("Richard Townsend")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2021")])]

#text("I think there’s a spurious w3 in the second formula")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse theorem for the U^3 Gowers uniformity norm on arbitrary finite abelian groups: Fourier-analytic and ergodic approaches | What's new")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-638722")[#strong[#text("The inverse theorem for the U^3 Gowers uniformity norm on arbitrary finite abelian groups: Fourier-analytic and ergodic approaches | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2021")])]

#text("[…] abelian groups: Fourier-analytic and ergodic approaches“. This paper, which is a companion to another recent paper of ourselves and Or Shalom, studies the inverse theory for the third Gowers uniformity […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc26cc79543045992c47a5f4e53dc1a99c4469f03200f26a438d42b728c5fc05-c7b1beaafc977fbbfb21f79631154065d7230f61c96e8ff92df40bf75d9fd353.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gopal Thorburn")]], [#link("https://terrytao.wordpress.com/2021/12/06/the-structure-of-arbitrary-conze-lesigne-systems/#comment-639977")[#strong[#text("Gopal Thorburn")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2022")])]

#text("Hi Terry,")#linebreak()#text(" I have some insights into why Bernoulli’s equation doesn’t add up quite perfectly and having a name like Tao this seems the perfect equation for you to solve. One of the “forces” acting on a fluid (it could just as easily be called the Tao of the water) hasn’t been taken into account in either the navier/stokes or Bernoulli’s equations. It’s a small force that is almost nothing, but has profound effects and should describe turbulence and cavitation. My written math level isn’t quite up to the point that I could write down the math that I can see in my experenents, I can only write the effects down in words. School doesn’t teach us how to write equations so I’m at a loss to figure out how to write down the value of this force. I’m wondering, if it would interest you, could we work on it together on it? It’s simple and really very elegant. In the words of Richard Feynman “the solution is usually far simpler than we expect” in this case I would say that is true. I don’t expect it would take us much time and it’d be a lot of fun, plus it’s one of the big equations that need solving. PM me if your interested.")#linebreak()#text(" Kindest regards")#linebreak()#text(" Gopal")#linebreak()#text(" I made my discoveries designing stationary waves and artificial surfing reefs. This is a hobby I have in my spare time.")
]
