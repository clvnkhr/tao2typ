// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/
// Converted to Typst by tao2typ: "2026-10-14T11:07:01.499896+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "ICM and IMU award ceremony begins tomorrow", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("ICM and IMU award ceremony begins tomorrow")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 July 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/")[#text("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m currently in Helsinki, Finland for the General Assembly meeting of the International Mathematical Union (IMU), which runs the International Congress of Mathematicians (ICM) as well as several other events and initiatives. In particular the assembly voted on the location of the 2026 ICM; it will be held in Philadelphia, USA (with the general assembly being held in New York, USA).")

#text("Tomorrow the IMU award ceremony will take place, where the recipients of the various IMU awards (such as the Fields medal) will be revealed and honored. Event information can be found at this ")#link("https://www.facebook.com/events/549374890193742")[#text("Facebook Event page")]#text(", and will also be streamed at ")#link("https://www.youtube.com/watch?v=6I0siVD7RBI&ab_channel=InternationalMathematicalUnion")[#text("this Youtube page")]#text("; participants who have registered at the ")#link("https://www.mathunion.org/icm/virtual-icm-2022")[#text("virtual ICM")]#text(" can also view it from the web page links they would have received in email in the last few days. (Due to high demand, registration for the virtual ICM has unfortunately reached the capacity of the live platform; but lectures will be made available on the ")#link("https://www.youtube.com/c/InternationalMathematicalUnion")[#text("IMU Youtube channel")]#text(" a few hours after they are given. The ")#link("https://www.mathunion.org/icm/icm-2022/virtual-icm-2022-program-sections")[#text("virtual ICM program")]#text(" will begin the day after the award ceremony, beginning with the lectures of the prize laureates.")

#text("We have an unofficial ")#link("https://discord.gg/T72dTkfSzF")[#text("ICM Discord server")]#text(" set up to follow the virtual ICM as it happens, with events set up for the prize ceremony and individual days of the congress, as well as for individual sections, as well as more recreational channels, such as a speculation page for the IMU prize winners. There are also a number of ")#link("https://www.hairer.org/ICMSCG/")[#text("other virtual ICM satellite events")]#text(" that are being held either simultaneously with, or close to, the virtual ICM; I would like to draw particular attention to the satellite public lectures by ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Geordie-Williamson-%28Sydney%29")[#text("Williamson (July 8)")]#text(", ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Eleni-Giorgi-Colombia")[#text("Giorgi (July 11)")]#text(", and ")#link("https://www.lms.ac.uk/events/vICM-Satellite-Event-Public-Lecture-by-Tadashi-Tokieda-Stanford")[#text("Tokieda (July 13)")]#text(", which was also highlighted in ")#link("https://terrytao.wordpress.com/2022/06/02/registration-for-the-virtual-icm-is-now-open/")[#text("my previous blog post")]#text(". (EDIT: I would also like to mention the now-live poster room for the short communic")

#text("After the virtual ICM concludes, I will solicit feedback on this blog (in my capacity as chair of the ")#link("https://www.mathunion.org/icm/icm-2022")[#text("IMU Structure Committee")]#text(") on all aspects of that congress, as well as suggestions for future congresses; but I am not formally requesting such feedback at this present time.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (53)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f673ee9ff0f0d1d27bdf4cc297a9bc3a2fd0207a7cfd198fd99e61a4afa9d54-ad6101021a91e137392ea91cf1092afbc56070f2b358fbf04b6aa2fc6a10e0a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhengbo ZHOU")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645895")[#strong[#text("Zhengbo ZHOU")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Hi Professor Tao, I am confused about the time.")#linebreak()#text(" On the opade website, the agenda says the opening of ICM and the fields metal award ceremony will be on 6th of July (GMT+1), however the youtube channel says the International Mathematical Union IMU Award Ceremony (Announcement of the Fields Medalists) will begin on 5th of July (GMT+1).")#linebreak()#text(" Which one is correct? Am I making some silly mistake?")

#text("References")#linebreak()#text(" ICM Agenda: ")#link("https://virtualicm2022.opade.digital/agenda")[#text("https://virtualicm2022.opade.digital/agenda")]#linebreak()#text(" Youtube: ")#link("https://www.youtube.com/watch?v=6I0siVD7RBI")[#text("https://www.youtube.com/watch?v=6I0siVD7RBI")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("The prizes will be awarded (and laudatios given) on July 5, but the lectures of the laureates will be given the day after on July 6.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645903")[#strong[#text("ICM 2022 | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")]

#text("[…] Update: Antoine Chambert-Loir claims “serious information” that Viazovska will get the Fields Medal (at least that’s who he seems to be referring to). It looks like press access is going to more organizations than Quanta this time, see this from Nature. Terry Tao has a blog post with some more ICM information. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Hey Professor Tao, is there any chance to get an autograph and a picture with you tomorrow? I’m a uni student here in Helsinki and will be attending tomorrow to follow the ceremony.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("Did you succeed in taking a photo with Tao?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1702986415b7589878a41c847ba16a309592775018f110be9e4b6c12f6d90e1-d27e6bc55d9c2d388bb0f4f594cd5d1a5543ed742dc3d8597b3e2941b6f436ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hua")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645911")[#strong[#text("Hua")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Hi,professor Tao,I am from china,the link is unavariable for me,I can’t interview IMU Youtube channel in my computer,where I can see them instead.If you give my some suggestion,I will be appreciated")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Go abroad for a week. :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Are all the presentations of the “virtual ICM” be posted on Youtube at a later time? I wonder if there are any differences between attending the events at the virtual ICM, or just view them later on Youtube. Since questions are not allowed during the virtual ICM, there is really no advantage in attending the events in real time, other than being able to view them sooner. Is this a correct perception?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645921")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("Personal interaction is diminished in this virtual format. The OPADE system which is used by vICM registrants has a chat feature, but that is most likely for OPADE support. The Satellite Coordination Group has set up a Discord server (shout out to Martin Hairer) so that some chat interaction can occur. If you are on Discord at the same time as someone willing to interact with you, you may have some satisfactory discussions in real time. So I would modify your perception: the sooner you view a lecture, the sooner you can chat with someone about it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6f39d6c08cecd79f223cf3342f4b2e6193657d286c4bce56403755f120effd-21736ab9949c5921ec0afd6b58d3268776b137114be6b6b81c4203c38bf7446f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Ruina")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645923")[#strong[#text("Andy Ruina")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2022")])]

#text("I’m hoping you jump on.")

#text("Andy Ruina, ")#link("mailto:ruina@cornell.edu")[#text("ruina@cornell.edu")]#text(" or andy.ruina@cornell. edu 607 327 0013 ")#link("http://ruina.org")[#text("http://ruina.org")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf288d46844fbef0364bcd087b4456c9d3ad462a57b8a780b2761c9a63639142-592e17df35dac890e27e26b293727ea411e387e48a0c01e0d38fe8cce17ed63b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beppe Metere")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645947")[#strong[#text("Beppe Metere")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2022")])]

#text("Hi, would like to share a question. Do you think it is fair that Fields medals cannot be awarded to mature mathematicians?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2022")])]

#text("Good question. Fields medals are equivalent to Nobel prizes. Nobel prizes don’t have age limit. Putting age limit discourages older mathematicians from trying to do the best they can, although the goal in doing math is not to win prizes. Age limit also favours someone who had good upbringing: good parents/teachers/environment…Can’t imagine someone who immigrated from Rwanda to a first world country, then wants to be a mathematician, and wins a Fields medal before 40. Age limit should be removed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("IMU Statutes added a new Article 3: opposing any discrimination on basis of such factors as ethnic origin, religion,…, and AGE. However, the Fields medal selection criterion is clearly discriminating against age. If the IMU wants to encourage young people to do good work, it could set up an award specifically for people under 40, but it shouldn’t be the Fields medal. The most prestigious award – Fields Medal, should be open to everyone, regardless of age.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2022")])]

#text("There is the Abel prize which has so far usually been given to late-career mathematicians, kind of a lifetime achievement award. It is more like the Nobels in that 1) it recognizes even achievements from the distant past, and 2) it carries a large monetary prize. The Fields Medal was intended to recognize and boost relatively fresh talent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2022")])]

#text("But putting age limit acts against late starters in mathematics, and especially women. Maybe a more reasonable criterion for selecting fresh talent will be counting the date since their PhD. say within 15 years.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645969")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2022")])]

#text("There is an article in quantum magazine about the fields medal winner – June Huh. It mentions that he was a high school drop out, couldn’t get into a good PhD. program,… All are unusual indeed.")

#text("One thing seems rather shocking. It says that the University of Michigan first rejected his application, but then recruited him after he proved a theorem while enrolled in a PhD. program at another university.")#linebreak()#text(" Is this ethical? On the student side, one don’t usually change graduate schools in the middle of the program unless the supervisor moves. On the institution side, why would/should a university do this? Stealing promising students from other universities while not willing to provide initial support to seemingly ill-qualified students at the first place.")

#text("How should one make sense of this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2022")])]

#text("Yeah I noticed that too, and also wondered what to make of it. UIUC is a perfectly respectable school too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645996")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2022")])]

#text("Dear Terry,")

#text("I registered to attend the ICM virtually, but I can not do it. Can you help me in this matter?")

#text("Many thanks, Radu")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2022")])]

#text("Is Dr Tao your friend? If not, please be respectful and call him in a right way as Dr Tao and not Terry.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dorin Cheptea")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-645998")[#strong[#text("Dorin Cheptea")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("The OPADE system, with all due respect, is a shame. It doesn’t work. We cannot log in, are repeatedly being bounced off. Why not stream all the congress lectures (all sections) on the IMU youtube channel? Make it simple, but make it work. Add extra features, like chat, etc, ONLY IF they do not worsen the situation. With all due respect, but I think OPADE was a scam.")

#link("https://www.youtube.com/channel/UCMHLun6jd-cMPnXhc2JqWPw")[#text("https://www.youtube.com/channel/UCMHLun6jd-cMPnXhc2JqWPw")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/603505b292346ae1305df9c97d9a0e34d768b9030c8ed17c0957e25dff5bea0b-f0cd52799bf419e1dc7f80a0e99e8d15e426066320e28b04bc97e9ada7e183da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adrian Fellhauer")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646000")[#strong[#text("Adrian Fellhauer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("I would very much like to congratulate Donald Trump on his Fields medal for outstanding contributions to number theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649456")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2022")])]

#text("How about his family? Good luck to the path you have chosen.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dorin Cheptea")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646004")[#strong[#text("Dorin Cheptea")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Take this with a huge doze of humor, please. :)")

#text("The local ICM 2022 organizers announce the talks in Helsinki time. The IMU website announces the talks in Berlin time, shifted by 1 hour. None of them bother to add an easy-to-notice footnote indicating which time they use.")

#text("The opade system let’s you pick your own time, but the webpage designer of “settings” forgot to take account of the summer time shift, while the webpage designer of the captions under the videos did. So, you pick, for example, your time incorrectly as GMT+1, but it is shown correctly as GMT+2.")

#text("The result is that people deal with 4 times. For those in Europe, 1 or 2 of these times superimpose, which makes harder to guess which one it is. It’s very easy to get lost.")

#text("Why don’t you set an accepted standard, as in airline industry: all times are local.")

#text("You should have posted everything, on all websites, in Helsinki time, and let everybody calculate their own time. After 2+ years of covid lockdown, :) we can add and substract a fixed number between 0 and 12, which everybody only needs to calculate only once, rather than click many times all sort of “settings” in every webpage. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13adaff32d54f3bdf4caf53abe3d7d7661f47307b45be7dfe4a21eeb122bc96c-30478c564e1d0b5eb16035de2a3eae50d90ef7462ef80bb9d6ab9ae482bb19a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radu Zaharopol")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646011")[#strong[#text("Radu Zaharopol")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("I would like to add a few more details to my message today. On July 2 I received an invitation to participate in the ICM; the invitation had a button to use to connect to the Conference. Naturally the invitation was sent to my inbox, and was there on July 2. However, on July 5, when I wanted to connect to the conference, the letter of invitation disappeared from my inbox; consequently, I am unable to attend the Conference.")

#text("Sincerely yours, Radu")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/781f41cf1f418f823dd9b27612a53a59337ee027b13678a472c71834167167d7-c47c5f3dac4cd794189f0d69c834c48eb8a2881d1abad69f29750dffe39206e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646012")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("This was the best day of plenary talks I’ve seen at ICM. Not only the talks were great, but whoever was in charge of Youtube livestream did a really great job. Very professional. Plus a smaller auditorium made it for a more relaxing warm and friendly atmosphere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Dr. Tao:")#linebreak()#text(" How are the members of the program committee determined? One member from each country or only the big countries? Strange that no one represents Canada on the program committee.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0bdf148cca93750101dc23265ed54be609c0be0d7f445643de26cecb411039-97a60200c98e2df985a9bc6487d5cd3b9bd3d9215ce1ff05752f6f6388dc9443.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YM")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646019")[#strong[#text("YM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Will you be writing blog posts describing the work of the winners like you did in 2014 and 2010?")

#text("[")#emph[#text("No, partly due to being much busier these days, partly due to conflicts with my other icm related duties, and partly because the IMU now produces several high quality presentations of the laureates’ work at different levels of detail. – T. ")]#text("]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MY")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646033")[#strong[#text("MY")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Read popular scientific expositions here: ")#link("https://www.mathunion.org/imu-awards/fields-medal/fields-medals-2022")[#text("https://www.mathunion.org/imu-awards/fields-medal/fields-medals-2022")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649149")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2022")])]

#text("And most important because Tao does know neither understand a single word about the high mathematics produce by the winners. Tao only understands silly computations. Overrated mathematician indeed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646021")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("My understanding (based on very limited data from Martin Hairer, so I may be wrong) is that technicians are working to have streams available in OPADE as originally advertised. I will attempt to use these streams to view as many of the lectures as I can. I invite those using OPADE to pool responses (by voting up or down) so that IMU people working with the techs can give them important and useful feedback. We can pool those responses as replies to this comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("It would be nice if comments are allowed on Youtube. Why are they turned off?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646031")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("I imagine because there is not enough IMU personnel to moderate Youtube comments. Also, the blog and Discord server are receiving quite a bit of, uh, commentary already.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646039")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("There is no need to moderate Youtube comments. It is for the public, so everyone can comment. That’s the beauty of it. The general public won’t use the Discord server.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dorin Cheptea")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646047")[#strong[#text("Dorin Cheptea")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Whoever has been working overnight to improve the ICM 2022 experience, please know you did an excellent job!")#linebreak()#text(" – the website ")#link("https://opade.digital/")[#text("https://opade.digital/")]#text(" is now simple and clear, as it should have been from the start,")#linebreak()#text(" – timezones are indicated everywhere,")#linebreak()#text(" – IMU youtube channel will be streaming all rooms.")#linebreak()#text(" All these have improved overnight! Thank you very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MY")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646049")[#strong[#text("MY")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("The quality of Youtube livestreams seems very low today, no HD like yesterday’s plenary talks, can barely see the slides. Is the quality on opade any better?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rafal")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646056")[#strong[#text("Rafal")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("Yeah, Frank Calegari put so much work into his program and they stream it in low definition…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MY")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646064")[#strong[#text("MY")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("His video was so choppy during the livestream. I hope the organizers will upload the original version.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/781f41cf1f418f823dd9b27612a53a59337ee027b13678a472c71834167167d7-c47c5f3dac4cd794189f0d69c834c48eb8a2881d1abad69f29750dffe39206e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646164")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2022")])]

#text("He posted it in HD here: ")#link("https://youtu.be/HDRqU6oW--4")[#text("https://youtu.be/HDRqU6oW–4")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("Let’s talk about the elephant in the room. The latest Fields Medal laureate Maryna Viazovska is a woman from Ukraine. So my question is simple: Did she win the medal because she did extraordinary math or because she is from Ukraine?")

#text("I hope Fields Medal is merit based, not victimhood based. ICM should be a math academy organization, not a political organization, where you trade one thing for another.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suomynona")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646061")[#strong[#text("Suomynona")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("The decision was made before the war started, in January. She is in the top two strongest Fields medalists this year for sure. If somebody won it as a popularity contest, it was not her.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("Maybe it is Donald Trump who won the popularity contest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b71017f3ba0f543c5044556f27512e72972ffa9e69a8bf9184eadd8f7695b8bf-bea05fabd012afb0eff4e8714fccbbf0a0ed5d4690e1d374727fd01c1f9ac003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Ruxton")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646183")[#strong[#text("Michael Ruxton")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2022")])]

#text("Thomas Hales remarked on reading her dimension 8 paper in 2016 that “she’s pulled a Ramanujan”. Her selection was merit based.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646193")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2022")])]

#text("I watched on of her old lectures and a little more about the dimension 8 proof. One cool thing was that was based on what looked like classical harmonic analysis. Results by Viazovska and collaborators that were very recent, but looked like they could have been done 100 years ago. I don’t yet understand the proof but it is very analysis flavoured. That was a bit surprising because the sign on her office door says she works in number theory. I wonder what else she has worked on.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2022")])]

#text("Both harmonic analysis and number theory are well established fields of study in mathematics, and there have been some significant breakthroughs and interactions between number theory and harmonic analysis recently. If one can make the connection across different fields, one can make great progress. Keep studying!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646087")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2022")])]

#text("The Discord server seems quite messy to use. There are too many people and too many comments. Is there a way of knowing when will the speakers be on the server? It would be nice if their “office hour” is specified somewhere.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2022")])]

#text("Could we have the presentation slides in pdf posted on youtube? Also, it would be nice to group the talks into sections on youtube. They are listed in reverse chronological order right now. It is hard to navigate. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646168")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2022")])]

#text("Tao，how is everything going in Helsinki？Take care of yourself~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-646211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2022")])]

#text("Is there a file that lists all speaker’s name alphabetically, followed by their talk abstracts? e.g.")

#text("Terry Tao: The structure of translational tilings")#linebreak()#text(" Abstract: Given ….. in this talk.")

#text("The info provided on ICM website just has names, sections, room etc. One has to basically watch the video to figure out the content, which is very time consuming.")

#emph[#text("[The full program is available at ")#link("https://icm2022.planner.documedias.systems/api/documents/pdf-program")[#text("https://icm2022.planner.documedias.systems/api/documents/pdf-program")]#text(" -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649233")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2022")])]

#text("Dr. Tao:")#linebreak()#text(" Could they order the abstracts by sections and by names? preferably one of each. The full program is in chronological order, which is very hard to use.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2022")])]

#text("Why is Prof. Svetlana Jitomirskaya’s plenary lecture video not available?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649287")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2022")])]

#text("Happy Birthday，Tao～ᵎ(•̀㉨•́)و ̑̑")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Request for comments from the ICM Structure Committee | What's new")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-649307")[#strong[#text("Request for comments from the ICM Structure Committee | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2022")])]

#text("[…] Of course, we do not expect these complex and difficult questions to be resolved within this blog post, and debating these and other issues would likely be a major component of our internal committee discussions. Nevertheless, we would value constructive comments towards the above questions (or on other topics within the scope of our committee) to help inform these subsequent discussions. We therefore welcome and invite such commentary, either as responses to this blog post, or sent privately to one of the members of our committee. We would also be interested in having readers share their personal experiences at past congresses, and how it compares with other major conferences of this type. (But in order to keep the discussion focused and constructive, we request that comments here refrain from discussing topics that are out of the scope of this committee, such as suggesting specific potential speakers for the next congress, which is a task instead for the 2022 ICM Program Committee. Comments that are specific to the recently concluded virtual ICM can be made instead at this blog post.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2022/07/03/icm-and-imu-award-ceremony-begins-tomorrow/#comment-652072")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2022")])]

#text("Hi,")#linebreak()#text(" I know this comment is off topic, but is there someone who knows where i can find a update list of current open conjectures in Mathematics?")
]
