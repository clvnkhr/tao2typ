// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:00.833564+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A proof of Roth’s theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A proof of Roth’s theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 April 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/")[#text("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Roth’s theorem on arithmetic progressions asserts that every subset of the integers ")#mi("{{\\bf Z}}")#text(" of positive upper density contains infinitely many arithmetic progressions of length three. There are many versions and variants of this theorem. Here is one of them:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Roth’s theorem)")]#text(" ")#metadata(none) <tao-a5822a8c8b00deb97c29>#text(" Let ")#mi("{G = (G,+)}")#text(" be a compact abelian group, with Haar probability measure ")#mi("{\\mu}")#text(", which is ")#link("http://en.wikipedia.org/wiki/Divisible_group")[#mi("{2}")#text("-divisible")]#text(" (i.e. the map ")#mi("{x \\mapsto 2x}")#text(" is surjective) and let ")#mi("{A}")#text(" be a measurable subset of ")#mi("{G}")#text(" with ")#mi("{\\mu(A) \\geq \\alpha}")#text(" for some ")#mi("{0 < \\alpha < 1}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G 1_A(x) 1_A(x+r) 1_A(x+2r)\\ d\\mu(x) d\\mu(r) \\gg_\\alpha 1,")]]

#text("where ")#mi("{X \\gg_\\alpha Y}")#text(" denotes the bound ")#mi("{X \\geq c_\\alpha Y}")#text(" for some ")#mi("{c_\\alpha > 0}")#text(" depending only on ")#mi("{\\alpha}")#text(".")
]

#text("This theorem is usually formulated in the case that ")#mi("{G}")#text(" is a finite abelian group of odd order (in which case the result is essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=1335785")[#text("due to Meshulam")]#text(") or more specifically a cyclic group ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(" of odd order (in which case it is essentially due ")#link("http://www.ams.org/mathscinet-getitem?mr=106865")[#text("to Varnavides")]#text("), but is also valid for the more general setting of ")#mi("{2}")#text("-divisible compact abelian groups, as we shall shortly see. One can be more precise about the dependence of the implied constant ")#mi("{c_\\alpha}")#text(" on ")#mi("{\\alpha}")#text(", but to keep the exposition simple we will work at the qualitative level here, without trying at all to get good quantitative bounds. The theorem is also true without the ")#mi("{2}")#text("-divisibility hypothesis, but the proof we will discuss runs into some technical issues due to the degeneracy of the ")#mi("{2r}")#text(" shift in that case.")

#text("We can deduce Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("1")]#text(" from the following more general Khintchine-type statement. Let ")#mi("{\\hat G}")#text(" denote the ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin dual")]#text(" of a compact abelian group ")#mi("{G}")#text(", that is to say the set of all continuous homomorphisms ")#mi("{\\xi: x \\mapsto \\xi \\cdot x}")#text(" from ")#mi("{G}")#text(" to the (additive) unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". Thus ")#mi("{\\hat G}")#text(" is a discrete abelian group, and functions ")#mi("{f \\in L^2(G)}")#text(" have a Fourier transform ")#mi("{\\hat f \\in \\ell^2(\\hat G)}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_G f(x) e^{-2\\pi i \\xi \\cdot x}\\ d\\mu(x).")]]

#text("If ")#mi("{G}")#text(" is ")#mi("{2}")#text("-divisible, then ")#mi("{\\hat G}")#text(" is ")#mi("{2}")#text("-torsion-free in the sense that the map ")#mi("{\\xi \\mapsto 2 \\xi}")#text(" is injective. For any finite set ")#mi("{S \\subset \\hat G}")#text(" and any radius ")#mi("{\\rho>0}")#text(", define the ")#emph[#text("Bohr set")]

#align(center)[#tao-fit-display[#tao-math("B(S,\\rho) := \\{ x \\in G: \\sup_{\\xi \\in S} \\left\\| \\xi \\cdot x \\right\\|_{{\\bf R}/{\\bf Z}} < \\rho \\}", block: true)]]

#text("where ")#tao-math("{\\left\\|\\theta\\right\\|_{{\\bf R}/{\\bf Z}}}", block: false)#text(" denotes the distance of ")#mi("{\\theta}")#text(" to the nearest integer. We refer to the cardinality ")#tao-math("{\\left|S\\right|}", block: false)#text(" of ")#mi("{S}")#text(" as the ")#emph[#text("rank")]#text(" of the Bohr set. We record a simple volume bound on Bohr sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Volume packing bound)")]#text(" ")#metadata(none) <tao-4862f447f2c7f272fa2f>#text(" Let ")#mi("{G}")#text(" be a compact abelian group with Haar probability measure ")#mi("{\\mu}")#text(". For any Bohr set ")#mi("{B(S,\\rho)}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\mu( B( S, \\rho ) ) \\gg_{\\left|S\\right|, \\rho} 1.", block: true)]]
]

#emph[#text("Proof:")]#text(" We can cover the torus ")#mi("{({\\bf R}/{\\bf Z})^S}")#text(" by ")#tao-math("{O_{\\left|S\\right|,\\rho}(1)}", block: false)#text(" translates ")#mi("{\\theta+Q}")#text(" of the cube ")#tao-math("{Q := \\{ (\\theta_\\xi)_{\\xi \\in S} \\in ({\\bf R}/{\\bf Z})^S: \\sup_{\\xi \\in S} \\left\\|\\theta_\\xi\\right\\|_{{\\bf R}/{\\bf Z}} < \\rho/2 \\}}", block: false)#text(". Then the sets ")#mi("{\\{ x \\in G: (\\xi \\cdot x)_{\\xi \\in S} \\in \\theta + Q \\}}")#text(" form an cover of ")#mi("{G}")#text(". But all of these sets lie in a translate of ")#mi("{B(S,\\rho)}")#text(", and the claim then follows from the translation invariance of ")#mi("{\\mu}")#text(". ")#mi("\\Box")

#text("Given any Bohr set ")#mi("{B(S,\\rho)}")#text(", we define a normalised “Lipschitz” cutoff function ")#mi("{\\nu_{B(S,\\rho)}: G \\rightarrow {\\bf R}}")#text(" by the formula ")#metadata(none) <tao-8cb0f0a4842dc2f2af5a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\nu_{B(S,\\rho)}(x) = c_{B(S,\\rho)} (1 - \\frac{1}{\\rho} \\sup_{\\xi \\in S} \\left\\|\\xi \\cdot x\\right\\|_{{\\bf R}/{\\bf Z}})_+", block: true)]]

#text("where ")#mi("{c_{B(S,\\rho)}}")#text(" is the constant such that")

#align(center)[#tao-fit-display[#mitex("\\int_G \\nu_{B(S,\\rho)}\\ d\\mu = 1,")]]

#text("thus")

#align(center)[#tao-fit-display[#tao-math("c_{B(S,\\rho)} = \\left( \\int_{B(S,\\rho)} (1 - \\frac{1}{\\rho} \\sup_{\\xi \\in S} \\left\\|\\xi \\cdot x\\right\\|_{{\\bf R}/{\\bf Z}})\\ d\\mu(x) \\right)^{-1}.", block: true)]]

#text("The function ")#mi("{\\nu_{B(S,\\rho)}}")#text(" should be viewed as an ")#mi("{L^1}")#text("-normalised “tent function” cutoff to ")#mi("{B(S,\\rho)}")#text(". Note from Lemma ")#link(<tao-4862f447f2c7f272fa2f>)[#text("2")]#text(" that ")#metadata(none) <tao-bc32d2bfda48d1429731>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("1 \\ll_{\\left|S\\right|,\\rho} c_{B(S,\\rho)} \\ll_{\\left|S\\right|,\\rho} 1.", block: true)]]

#text("We then have the following sharper version of Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Roth-Khintchine theorem)")]#text(" ")#metadata(none) <tao-61671e8197f047bccc0a>#text(" Let ")#mi("{G = (G,+)}")#text(" be a ")#mi("{2}")#text("-divisible compact abelian group, with Haar probability measure ")#mi("{\\mu}")#text(", and let ")#mi("{\\epsilon>0}")#text(". Then for any measurable function ")#mi("{f: G \\rightarrow [0,1]}")#text(", there exists a Bohr set ")#mi("{B(S,\\rho)}")#text(" with ")#tao-math("{\\left|S\\right| \\ll_\\epsilon 1}", block: false)#text(" and ")#mi("{\\rho \\gg_\\epsilon 1}")#text(" such that ")#metadata(none) <tao-c91e3c18c1b0c2a0a1e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\int_G \\int_G f(x) f(x+r) f(x+2r) \\nu_{B(S,\\rho)}*\\nu_{B(S,\\rho)}(r)\\ d\\mu(x) d\\mu(r)")]]

#align(center)[#tao-fit-display[#mitex("\\geq (\\int_G f\\ d\\mu)^3 - O(\\epsilon)")]]

#text("where ")#mi("{*}")#text(" denotes the convolution operation")

#align(center)[#tao-fit-display[#mitex("f*g(x) := \\int_G f(y) g(x-y)\\ d\\mu(y).")]]
]

#text("A variant of this result (expressed in the language of ergodic theory) appears in ")#link("http://www.ams.org/mathscinet-getitem?mr=2138068")[#text("this paper of Bergelson, Host, and Kra")]#text("; a combinatorial version of the Bergelson-Host-Kra result that is closer to Theorem ")#link(<tao-61671e8197f047bccc0a>)[#text("3")]#text(" subsequently appeared in ")#link("http://www.ams.org/mathscinet-getitem?mr=2815606")[#text("this paper of Ben Green and myself")]#text(", but this theorem arguably appears implicitly in a ")#link("http://www.ams.org/mathscinet-getitem?mr=853455")[#text("much older paper of Bourgain")]#text(". To see why Theorem ")#link(<tao-61671e8197f047bccc0a>)[#text("3")]#text(" implies Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("1")]#text(", we apply the theorem with ")#mi("{f := 1_A}")#text(" and ")#mi("{\\epsilon}")#text(" equal to a small multiple of ")#mi("{\\alpha^3}")#text(" to conclude that there is a Bohr set ")#mi("{B(S,\\rho)}")#text(" with ")#tao-math("{\\left|S\\right| \\ll_\\alpha 1}", block: false)#text(" and ")#mi("{\\rho \\gg_\\alpha 1}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G 1_A(x) 1_A(x+r) 1_A(x+2r) \\nu_{B(S,\\rho)}*\\nu_{B(S,\\rho)}(r)\\ d\\mu(x) d\\mu(r) \\gg \\alpha^3.")]]

#text("But from ")#link(<tao-bc32d2bfda48d1429731>)[#text("(2)")]#text(" we have the pointwise bound ")#mi("{\\nu_{B(S,\\rho)}*\\nu_{B(S,\\rho)} \\ll_\\alpha 1}")#text(", and Theorem ")#link(<tao-a5822a8c8b00deb97c29>)[#text("1")]#text(" follows.")

#text("Below the fold, we give a short proof of Theorem ")#link(<tao-61671e8197f047bccc0a>)[#text("3")]#text(", using an “energy pigeonholing” argument that essentially dates back to the ")#link("http://www.ams.org/mathscinet-getitem?mr=853455")[#text("1986 paper of Bourgain")]#text(" mentioned previously (not to be confused with a ")#link("http://www.ams.org/mathscinet-getitem?mr=1726234")[#text("later 1999 paper of Bourgain")]#text(" on Roth’s theorem that was highly influential, for instance in emphasising the importance of Bohr sets). The idea is to use the pigeonhole principle to choose the Bohr set ")#mi("{B(S,\\rho)}")#text(" to capture all the “large Fourier coefficients” of ")#mi("{f}")#text(", but such that a certain “dilate” of ")#mi("{B(S,\\rho)}")#text(" does not capture much more Fourier energy of ")#mi("{f}")#text(" than ")#mi("{B(S,\\rho)}")#text(" itself. The bound ")#link(<tao-c91e3c18c1b0c2a0a1e6>)[#text("(3)")]#text(" may then be obtained through elementary Fourier analysis, without much need to explicitly compute things like the Fourier transform of an indicator function of a Bohr set. (However, the bound obtained by this argument is going to be quite poor – of tower-exponential type.) To do this we perform a structural decomposition of ")#mi("{f}")#text(" into “structured”, “small”, and “highly pseudorandom” components, as is common in the subject (e.g. in ")#link("https://terrytao.wordpress.com/2012/12/03/the-spectral-proof-of-the-szemeredi-regularity-lemma/")[#text("this previous blog post")]#text("), but even though we crucially need to retain non-negativity of one of the components in this decomposition, we can avoid recourse to conditional expectation with respect to a partition (or “factor”) of the space, using instead convolution with one of the ")#mi("{\\nu_{B(S,\\rho)}}")#text(" considered above to achieve a similar effect.")

#metadata(none) <tao-f04e9ef50d903ab6afc1>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("Fix ")#mi("{G, f, \\epsilon > 0}")#text(". Let ")#mi("{k}")#text(" be a large integer (depending only on ")#mi("{\\epsilon}")#text(") to be chosen later. We will need a sequence")

#align(center)[#tao-fit-display[#mitex("1 = \\delta_0 \\gg \\delta_1 \\gg \\dots \\gg \\delta_{3k-1} > 0")]]

#text("of small parameters, with each ")#mi("{\\delta_i}")#text(" assumed to be sufficiently small depending on all previous ")#mi("{\\delta_0,\\dots,\\delta_{i-1}}")#text(" and on ")#mi("{\\epsilon}")#text(". (One should think of the ")#mi("{\\delta_i}")#text(" as shrinking to zero incredibly fast, e.g. ")#mi("{\\delta_0 = 1}")#text(" and ")#mi("{\\delta_{i+1} = \\exp( - \\epsilon^{-100} \\delta_i^{1/\\epsilon^{100}} )}")#text(" for ")#mi("{0 \\leq i < 3k-1}")#text(".)")

#text("We then define an increasing sequence")

#align(center)[#tao-fit-display[#mitex("\\{0\\} = S_0 \\subset S_1 \\subset \\dots \\subset S_k \\subset \\hat G")]]

#text("of finite sets ")#mi("{S_i}")#text(" of frequencies, as follows.")

#list(
[#text("(i) Initialise ")#mi("{S_0 := \\{0\\}}")#text(".")],
[#text("(ii) Once ")#mi("{S_i}")#text(" has been selected for some ")#mi("{0 \\leq i < k}")#text(", introduce the function")

#metadata(none) <tao-4a7b188df607c3ea6ae6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\nu_i := \\nu_{B(S_i,\\delta_{3i} )}.")]]

#text("Note that this is a square-integrable function, thanks to ")#link(<tao-bc32d2bfda48d1429731>)[#text("(2)")]#text(".")],
[#text("(iii) Define ")#mi("{S_{i+1}}")#text(" to be the set")

#metadata(none) <tao-0755656c8c6f646a9b17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("S_{i+1} := S_i \\cup \\{ \\xi \\in \\hat G: \\left|\\hat f(\\xi)\\right| \\geq \\delta_{3i+2} \\}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\cup \\bigcup_{j=0}^i \\{ \\xi \\in \\hat G: \\left|\\hat \\nu_j(\\xi)\\right| \\geq \\delta_{3i+2} \\}.", block: true)]]

#text("Note from Plancherel’s theorem that this is a finite set.")],
[#text("(iv) If ")#mi("{i < k-1}")#text(", increment ")#mi("{i}")#text(" to ")#mi("{i+1}")#text(" and return to step (ii).")]
)

#text("An easy induction using Plancherel’s theorem and ")#link(<tao-bc32d2bfda48d1429731>)[#text("(2)")]#text(" repeatedly gives the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_i \\right\\|_{L^2(G)} \\ll_{i,\\delta_0,\\dots,\\delta_{3i}} 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|S_i\\right| \\ll_{i,\\delta_0,\\dots,\\delta_{3i-1}} 1", block: true)]]

#text("for all ")#mi("{i=0,\\dots,k-1}")#text(".")

#text("From Plancherel’s theorem we also have ")#metadata(none) <tao-c9b77b179fbd394d2df5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{\\xi \\in \\hat G} \\left|\\hat f(\\xi)\\right|^2 \\ll 1.", block: true)]]

#text("As the ")#mi("{S_i}")#text(" are increasing, we thus see from the pigeonhole principle (if ")#mi("{k}")#text(" is sufficiently large depending on ")#mi("{\\epsilon}")#text(") that there exists ")#mi("{1 \\leq i \\leq k-2}")#text(" such that ")#metadata(none) <tao-cdca5ece79dc4dc618f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{\\xi \\in S_{i+2} \\backslash S_i} \\left|\\hat f(\\xi)\\right|^2 \\ll \\epsilon^2.", block: true)]]

#text("We now decompose")

#align(center)[#tao-fit-display[#mitex("f = f_0 + f_1 + f_2")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("f_0  & := f * \\nu_i", block: true)



#tao-math("f_1  & := f * \\nu_{i+1} - f * \\nu_i", block: true)



#tao-math("f_2  & := f - f*\\nu_{i+1}.", block: true)
]

#text("One can think of ")#mi("{f_0, f_1, f_2}")#text(" as the “low frequency” (or “structured”, or “quasiperiodic”), “medium frequency” (or “small”), and “high frequency” (or “highly pseudorandom”) components of ")#mi("{f}")#text(", where the notion of what it means for a frequency to be high or low is not determined by some preconceived notion of magnitude, but is instead adapted to the function ")#mi("{f}")#text(" itself. We will think of ")#mi("{f_0}")#text(" as the “main” term, and ")#mi("{f_1, f_2}")#text(" as “errors”.")

#text("Since ")#mi("{f}")#text(" is bounded in magnitude by ")#mi("{1}")#text(", and ")#mi("{\\nu_i, \\nu_{i+1}}")#text(" are non-negative with total mass ")#mi("{1}")#text(", we have the ")#mi("{L^\\infty}")#text(" bounds ")#metadata(none) <tao-7a0ea73937fff6e7dc31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|f_0\\right\\|_{L^\\infty(G)}, \\left\\|f_1\\right\\|_{L^\\infty(G)}, \\left\\|f_2\\right\\|_{L^\\infty(G)} \\ll 1.", block: true)]]

#text("Now we give further bounds on ")#mi("{f_0,f_1,f_2}")#text(". We begin with ")#mi("{f_2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (")#mi("{f_2}")#text(" has very small Fourier coefficients)")]#text(" ")#metadata(none) <tao-a56068c3ca60024161a5>#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\hat f_2 \\right\\|_{\\ell^\\infty(\\hat G)} \\ll \\delta_{3i+2}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\xi \\in \\hat G}")#text(". From the definition of ")#mi("{f_2}")#text(" and elementary Fourier analysis we have")

#align(center)[#tao-fit-display[#mitex("\\hat f_2(\\xi) = \\hat f(\\xi) (1 - \\hat \\nu_{i+1}(\\xi)).")]]

#text("If ")#mi("{\\xi \\not \\in S_{i+1}}")#text(", then from ")#link(<tao-0755656c8c6f646a9b17>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq \\delta_{3i+2}", block: true)]]

#text("and the claim follows (since ")#mi("{\\nu_{i+1}}")#text(" has total mass one). Now suppose instead that ")#mi("{\\xi \\in S_{i+1}}")#text(". Then from ")#link(<tao-4a7b188df607c3ea6ae6>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("e^{2\\pi i \\xi \\cdot x} = 1 - O( \\delta_{3i+3} )")]]

#text("for all ")#mi("{x}")#text(" in the support of ")#mi("{\\nu_{i+1}}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\hat \\nu_{i+1}(\\xi) = 1 - O( \\delta_{3i+3} )")]]

#text("and the claim again follows. ")#mi("\\Box")

#text("Now we control ")#mi("{f_1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (")#mi("{f_1}")#text(" small in ")#mi("{L^2}")#text(")")]#text(" ")#metadata(none) <tao-8a1cee436cbac1489a18>#text(" We have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_1 \\right\\|_{L^2(G)} \\ll \\epsilon.", block: true)]]
]

#emph[#text("Proof:")]#text(" From the definition of ")#mi("{f_1}")#text(" and elementary Fourier analysis we have ")#metadata(none) <tao-8c39c63488260c318aea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| f_1 \\right\\|_{L^2(G)}^2 = \\sum_{\\xi \\in\\hat G} \\left|\\hat f(\\xi)\\right|^2 \\left|\\hat \\nu_i(\\xi) - \\hat \\nu_{i+1}(\\xi)\\right|^2.", block: true)]]

#text("We wish to bound this by ")#mi("{O(\\epsilon^2)}")#text(". From ")#link(<tao-cdca5ece79dc4dc618f1>)[#text("(7)")]#text(" we see that the contribution of those ")#mi("{\\xi}")#text(" in ")#mi("{S_{i+2} \\backslash S_i}")#text(" are acceptable. Now let us look at the contribution with ")#mi("{\\xi \\not \\in S_{i+2}}")#text(". From ")#link(<tao-0755656c8c6f646a9b17>)[#text("(5)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat \\nu_i(\\xi)\\right|, \\left|\\hat \\nu_{i+1}(\\xi)\\right| < \\delta_{3i+5}", block: true)]]

#text("for such ")#mi("{\\xi}")#text(", so this contribution to ")#link(<tao-8c39c63488260c318aea>)[#text("(9)")]#text(" is certainly acceptable thanks to ")#link(<tao-c9b77b179fbd394d2df5>)[#text("(6)")]#text(". Now suppose that ")#mi("{\\xi \\in S_i}")#text(". The argument in the proof of Lemma ")#link(<tao-a56068c3ca60024161a5>)[#text("4")]#text(" shows that ")#mi("{\\hat \\nu_{i+1}(\\xi) = 1-O( \\delta_{3i+3} )}")#text(" and ")#mi("{\\hat \\nu_i(\\xi) = 1-O( \\delta_{3i} )}")#text(", and so this contribution is again acceptable thanks to ")#link(<tao-c9b77b179fbd394d2df5>)[#text("(6)")]#text(". ")#mi("\\Box")

#text("Finally, we record the key properties of ")#mi("{f_0}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (")#mi("{f_0}")#text(" continuous)")]#text(" ")#metadata(none) <tao-164080c6c096dcc54829>#text(" ")#mi("{f_0}")#text(" is non-negative, has mean ")#mi("{\\int_G f_0\\ d\\mu = \\int_G f\\ d\\mu}")#text(", and obeys the bound")

#align(center)[#tao-fit-display[#mitex("f_0(x+r) = f_0(x) + O(\\epsilon)")]]

#text("whenever ")#mi("{x \\in G}")#text(" and ")#mi("{r \\in B( S_i, \\delta_{3i+1} )}")#text(".")
]

#emph[#text("Proof:")]#text(" The first two properties are obvious, so we turn to the third. Since ")#mi("{f_0 = f * \\nu_i}")#text(" and ")#mi("{f}")#text(" is bounded, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\nu_i(x+r) = \\nu_i(x) + O(\\epsilon)")]]

#text("whenever ")#mi("{x \\in G}")#text(" and ")#mi("{r \\in B( S_i, \\delta_{3i+1} )}")#text(". But from ")#link(<tao-8cb0f0a4842dc2f2af5a>)[#text("(1)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\nu_i(x+r) - \\nu_i(x)\\right| \\leq c_{B(S_i,\\delta_{3i})} \\frac{\\delta_{3i+1}}{\\delta_{3i}}", block: true)]]

#text("for such ")#mi("{x,r}")#text(", and the claim follows from ")#link(<tao-bc32d2bfda48d1429731>)[#text("(2)")]#text(". ")#mi("\\Box")

#text("Now we can prove Theorem ")#link(<tao-61671e8197f047bccc0a>)[#text("3")]#text(" with ")#mi("{B(S,\\rho) = B(S_i,\\delta_{3i+1})}")#text(". Splitting ")#mi("{f=f_0+f_1+f_2}")#text(" as above, we can decompose the left-hand side of ")#link(<tao-c91e3c18c1b0c2a0a1e6>)[#text("(3)")]#text(" into ")#mi("{3^3=27}")#text(" terms, each of the form")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f_a(x) f_b(x+r) f_c(x+2r) \\nu_{B(S_i,\\delta_{3i+1})}*\\nu_{B(S_i,\\delta_{3i+1})}(r)\\ d\\mu(x) d\\mu(r)")]]

#text("for some ")#mi("{a,b,c \\in \\{0,1,2\\}}")#text(".")

#text("Let us consider a term for which ")#mi("{a=1}")#text(". We can bound this term by")

#align(center)[#tao-fit-display[#mitex("O( \\int_G |f_1(x)| \\nu_{B(S_i,\\delta_{3i+1})}*\\nu_{B(S_i,\\delta_{3i+1})}(r)\\ d\\mu(x) d\\mu(r) )")]]

#align(center)[#tao-fit-display[#mitex("= O( \\int_G |f_1(x)|\\ d\\mu(x) )")]]

#text("which is ")#mi("{O(\\epsilon)}")#text(" thanks to Lemma ")#link(<tao-8a1cee436cbac1489a18>)[#text("5")]#text(". Similar arguments hold for terms with ")#mi("{b=1}")#text(" or ")#mi("{c=1}")#text(", after shifting ")#mi("{x}")#text(" by ")#mi("{r}")#text(" or ")#mi("{2r}")#text(".")

#text("Now let us consider a term for which ")#mi("{a=2}")#text(", that is to say")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f_2(x) f_b(x+r) f_c(x+2r) \\nu_{B(S_i,\\delta_{3i+1})}*\\nu_{B(S_i,\\delta_{3i+1})}(r)\\ d\\mu(x) d\\mu(r).")]]

#text("A short Fourier-analytic calculation reveals that this integral may be written as a sum")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi_1,\\xi_2,\\xi_3 \\in \\hat G: \\xi_1+\\xi_2+\\xi_3 = 0} \\hat f_2(\\xi_1) \\hat f_b(\\xi_2) \\hat f_c(\\xi_3) \\left|\\hat \\nu_{B(S_i,\\delta_{3i+1})}(-\\xi_2 - 2 \\xi_3 )\\right|^2.", block: true)]]

#text("From ")#link(<tao-bc32d2bfda48d1429731>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_G \\left|\\nu_{B(S_i,\\delta_{3i+1})}\\right|^2\\ d\\mu \\ll_{i,\\delta_0,\\dots,\\delta_{3i+1}} 1", block: true)]]

#text("and thus by Plancherel")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in \\hat G} \\left|\\nu_{B(S_i,\\delta_{3i+1})}(\\xi)\\right|^2\\ d\\mu \\ll_{i,\\delta_0,\\dots,\\delta_{3i+1}} 1.", block: true)]]

#text("Similarly, from ")#link(<tao-c9b77b179fbd394d2df5>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in \\hat G} \\left|\\hat f_b(\\xi)\\right|^2 \\ll 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in \\hat G} \\left|\\hat f_c(\\xi)\\right|^2 \\ll 1,", block: true)]]

#text("and hence by Cauchy-Schwarz and the ")#mi("{2}")#text("-torsion-free nature of ")#mi("{\\hat G}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi_2,\\xi_3 \\in\\hat G: -\\xi_2-2\\xi_3 = \\xi} \\left|\\hat f_b(\\xi_2)\\right| \\left|\\hat f_c(\\xi_3)\\right| \\ll 1", block: true)]]

#text("for all ")#mi("{\\xi \\in \\hat G}")#text(". Combining these estimates with Lemma ")#link(<tao-a56068c3ca60024161a5>)[#text("4")]#text(", we conclude that this contribution to ")#link(<tao-c91e3c18c1b0c2a0a1e6>)[#text("(3)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("O_{i,\\delta_0,\\dots,\\delta_{3i+1}}( \\delta_{3i+2} ) = O( \\epsilon ).")]]

#text("Similar arguments dispose of the terms for which ")#mi("{b=2}")#text(" or ")#mi("{c=2}")#text(".")

#text("The only remaining term is when ")#mi("{a=b=c=0}")#text(", that is to say")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G f_0(x) f_0(x+r) f_0(x+2r) \\nu_{B(S_i,\\delta_{3i+1})}*\\nu_{B(S_i,\\delta_{3i+1})}(r)\\ d\\mu(x) d\\mu(r).")]]

#text("From several applications of Lemma ")#link(<tao-164080c6c096dcc54829>)[#text("6")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("f_0(x+r), f_0(x+2r) = f_0(x) + O(\\epsilon)")]]

#text("for ")#mi("{(x,r)}")#text(" in the support of this integrand. Thus this term may be written as")

#align(center)[#tao-fit-display[#mitex("\\int_G \\int_G (f_0(x)^3 + O(\\epsilon)) \\nu_{B(S_i,\\delta_{3i+1})}*\\nu_{B(S_i,\\delta_{3i+1})}(r)\\ d\\mu(x) d\\mu(r),")]]

#text("which on evaluating the ")#mi("{r}")#text(" integral simplifies to")

#align(center)[#tao-fit-display[#mitex("\\int_G (f_0(x)^3 + O(\\epsilon))\\ d\\mu(x),")]]

#text("but by the non-negativity of ")#mi("{f_0}")#text(" and Hölder’s inequality, this is at least")

#align(center)[#tao-fit-display[#mitex("(\\int_G f_0\\ d\\mu)^3 - O(\\epsilon) = (\\int_G f\\ d\\mu)^3 - O(\\epsilon)")]]

#text("and the claim follows.")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mpetrache")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-316444")[#strong[#text("mpetrache")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Hello! I would like to ask a question: what fails to work for the estimates if one tries to get a result on lenght n>3 arithmetic progressions similar to this version of Roth-Kintchin theorem?")#linebreak()#text(" Also (probably this is a bit irrelevant) I guess in (5) there should be some “j” in the last term, right?")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-316789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("Thanks for the correction!")

#text("With patterns of complexity greater than 1 (such as arithmetic progressions of length four and greater), what happens is that the Fourier pseudorandomness in Lemma 4 is no longer strong enough to control the contribution of ")#mi("f_2")#text(" (this is discussed extensively in Gowers’ paper on Szemeredi’s theorem for length four progressions). For k=4, it is possible to salvage this argument, but with all appearances of linear Fourier analysis arguments replaced by their quadratic Fourier analysis counterparts; this is done in my paper with Ben on the arithmetic regularity lemma that was linked to above. However, just as the k=3 argument relied on an analytic inequality, namely Holder’s inequality ")#mi("\\int f_0^3 \\geq (\\int f_0)^3")#text(", the k=4 argument relies on an analytic inequality (roughly speaking, that ")#mi("\\int_{x_0-3x_1+3x_2-x_3=0} f(x_0) f(x_1) f(x_2) f(x_3) \\geq (\\int f)^4")#text(" when ")#mi("f")#text(" takes values in a compact abelian group with Haar probability measure) which does not have an analogue for k=5 and higher, and the Khintchine type theorem is in fact false in that case, as was essentially demonstrated by Ruzsa in an appendix to the paper of Bergelson, Host, and Kra linked to above. (Of course, Szemeredi’s theorem for k>=5 can be established by other means.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-317311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2014")])]

#text("I think the displayed equation (9) looks a little funny…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-317874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("Is there a reason why $f_0,f_1,f_2$ are defined using double convolutions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-317948")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("The double comvolution ")#mi("\\nu * \\nu")#text(" obeys good ")#mi("\\ell^1")#text(" bounds on the Fourier transform (i.e. Wiener algebra bounds), while ")#mi("\\nu")#text(" only obeys good ")#mi("\\ell^2")#text(" bounds on the Fourier transform. For the Fourier-analytic treatment of the ")#mi("f_2")#text(" terms, ")#mi("\\ell^1")#text(" control of the Fourier transform becomes essential.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-317986")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("I was curious about using the double convolution in the definition of the functions $f_0,f_1,f_2$.")#linebreak()#text(" It seems to me that $f_0$ is still sufficiently smooth with a single convolution, $f_1$ still has small $L^2$ norm, and $f_2$ still has small Fourier coefficients.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-318001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2014")])]

#text("Hmm, you’re right, the double convolution is not needed here, even though it is needed to constrain the ")#mi("r")#text(" shift. I’ve edited the text appropriately to reflect this simplification to the argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-466799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2016")])]

#text("Hi Professor Tao, I have trouble seeing how, in the proof of Lemma 2, the sets forming an open cover of G are translates of B(S,𝜌). Am I missing something?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-466801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2016")])]

#text("They are each contained in translates of ")#mi("B(S,\\rho)")#text(" (more specifically, they are contained in ")#mi("x + B(S,\\rho)")#text(" for any element ")#mi("x")#text(" of that set), but are not necessarily ")#emph[#text("equal")]#text(" to such translates.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-466802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2016")])]

#text("Pardon me for my sloppy question — I actually meant “contained in translates of ")#tao-fit-display[#mitex("B(S,\\rho)")]#text("”. This I had trouble seeing, unless I assumed that each ")#tao-fit-display[#mitex("\\theta")]#text(" used for the translation was of the form ")#tao-fit-display[#mitex("(\\xi \\cdot y)_{\\xi \\in S}")]#text(" for some ")#tao-fit-display[#mitex("y \\in G")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/04/24/a-proof-of-roths-theorem/#comment-466806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2016")])]

#text("Let ")#mi("A")#text(" be a set of the form ")#mi("A = \\{ x \\in G: (\\xi \\cdot x)_{\\xi \\in S} \\in \\theta + Q \\}")#text(". If ")#mi("A")#text(" is empty then we are done, so suppose ")#mi("A")#text(" contains an element ")#mi("x_0")#text(". Then for any other ")#mi("x \\in A")#text(", ")#mi("(\\xi \\cdot (x-x_0))_{\\xi \\in S} \\in (\\theta+Q)-(\\theta+Q)=Q-Q")#text(", which implies that ")#mi("x - x_0 \\in B(S,\\rho)")#text(", so ")#mi("A")#text(" lies in the translate ")#mi("x_0+B(S,\\rho)")#text(" of ")#mi("B(S,\\rho)")#text(",")
]
]
]
]
