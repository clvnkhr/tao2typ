// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/11/05/futures-of-maths-launch/
// Converted to Typst by tao2typ: "2026-11-06T14:28:07.474982+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Futures of Maths Launch", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Futures of Maths Launch")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/11/05/futures-of-maths-launch/")[#text("https://terrytao.wordpress.com/2026/11/05/futures-of-maths-launch/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-06 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by Francesco Fournier-Facio, Yara Kyrychenko, Jon Roozenbeek, and Julian Wykowski, cross-posted from the ")#link("https://proofsandprompts.com/2026/11/05/futures-of-maths-launch/")[#text("Proofs and Prompts blog")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Today we launch ")#link("https://community.futuresofmaths.com")[#text("Futures of Maths")]#text(", a new, living platform that asks active research mathematicians about the most pressing questions around maths and AI. A string of solutions to famous maths problems, found with the help of AI, has provoked a great deal of discussion among research mathematicians. We built Futures of Maths to understand how mathematicians are dealing with this change in their research and teaching, and where they see the field heading.")

#emph[#strong[#text("How it works.")]]#text(" The platform shows you short statements about maths and AI. You rate each one from “strongly disagree” to “strongly agree”, or skip it, and you can mark the ones you find exceptionally important. Once you have answered, you see how everyone has rated the statement so far. You don’t have to finish in one go: you can leave and come back at any time. Most importantly, you can post your own statements. A moderator checks each one, and then everyone else can rate it, so the set of statements keeps evolving with the community’s input.")

#emph[#strong[#text("Results.")]]#text(" Once we have collected enough responses, we will publish the results and make them available to the community. We will post again on ")#link("https://proofsandprompts.com/")[#text("Proofs and Prompts")]#text(" when this happens.")

#emph[#strong[#text("Who can participate.")]]#text(" You can take part if you are 18 or older and have at least one article published in the last 5 years in a mathematics journal, meaning one indexed by zbMATH Open (recently accepted articles also count). The quickest way in is to sign in with ORCID. The article must be on your public ORCID record, added by Crossref. Articles you enter yourself don’t count. If it isn’t there, accept Crossref’s permission request in your ORCID inbox and make the work public. If that doesn’t work, for example because your article is accepted but not yet published, you can request a manual review from your institutional email address. We review these case by case.")#linebreak()#text(" We appreciate that this is only an approximation of what an active research mathematician is, but we chose it for its ")#emph[#text("simplicity")]#text(", ")#emph[#text("objectivity ")]#text("and ")#emph[#text("efficient verifiability")]#text(". We welcome proposals of alternative criteria that cover a more representative sample, and have these same three qualities, they could be implemented in future iterations.")

#emph[#strong[#text("Privacy.")]]#text(" The survey is anonymous. Verification happens on a separate website, and the survey itself never learns your name, email address or ORCID iD. When you first register, you receive a personal link that lets you return as often as you like as the consultation evolves. Please save this link. We can’t look it up or resend it, because that is what keeps you anonymous. Questions about yourself are optional, under “My session”, and you can withdraw your answers at any time.")

#emph[#strong[#text("Inviting wide participation.")]]#text(" The results will only be meaningful if a large and diverse group of people takes part, both proposing statements and rating them. Please share this widely, and especially with people whose point of view you feel is underrepresented in the discussion on maths and AI.")

#text("If you have any suggestions or feature requests, please leave them in the comments!")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/11/05/futures-of-maths-launch/comment-page-1/#comment-699228")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2026")])]

#text("You should allow graduate students (read: PhD students who have started the research part of their degree) to participate as well. Or do their opinions on their own future not actually matter to you?")
]
