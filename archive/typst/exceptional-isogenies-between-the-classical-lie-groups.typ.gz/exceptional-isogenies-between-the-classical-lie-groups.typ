// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/
// Converted to Typst by tao2typ: "2026-10-14T09:06:43.329297+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Exceptional isogenies between the classical Lie groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Exceptional isogenies between the classical Lie groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/")[#text("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For sake of concreteness we will work here over the complex numbers ")#mi("{{\\bf C}}")#text(", although most of this discussion is valid for arbitrary algebraically closed fields (but some care needs to be taken in characteristic ")#mi("{2}")#text(", as always, particularly when defining the orthogonal and symplectic groups). Then one has the following four infinite families of ")#link("http://en.wikipedia.org/wiki/Classical_Lie_group")[#text("classical Lie groups")]#text(" for ")#mi("{n \\geq 1}")#text(":")

#enum(start: 1, 
[#text("(Type ")#mi("{A_n}")#text(") The ")#link("http://en.wikipedia.org/wiki/Special_linear_group")[#text("special linear group")]#text(" ")#mi("{SL_{n+1}({\\bf C})}")#text(" of volume-preserving linear maps ")#mi("{T: {\\bf C}^{n+1} \\rightarrow {\\bf C}^{n+1}}")#text(".")],
[#text("(Type ")#mi("{B_n}")#text(") The ")#link("http://en.wikipedia.org/wiki/Special_orthogonal_group")[#text("special orthogonal group")]#text(" ")#mi("{SO_{2n+1}({\\bf C})}")#text(" of (orientation preserving) linear maps ")#mi("{T: {\\bf C}^{2n+1} \\rightarrow {\\bf C}^{2n+1}}")#text(" preserving a non-degenerate symmetric form ")#mi("{\\langle, \\rangle: {\\bf C}^{2n+1} \\times {\\bf C}^{2n+1} \\rightarrow {\\bf C}}")#text(", such as the standard symmetric form")

#align(center)[#tao-fit-display[#mitex("\\langle (z_1,\\ldots,z_{2n+1}), (w_1,\\ldots,w_{2n+1}) \\rangle := z_1 w_1 + \\ldots + z_{2n+1} w_{2n+1}.")]]

#text("(this is the complexification of the more familiar ")#emph[#text("real special orthogonal group")]#text(" ")#mi("{SO_{2n+1}({\\bf R})}")#text(").")],
[#text("(Type ")#mi("{C_n}")#text(") The ")#link("http://en.wikipedia.org/wiki/Symplectic_group")[#text("symplectic group")]#text(" ")#mi("{Sp_{2n}({\\bf C})}")#text(" of linear maps ")#mi("{T: {\\bf C}^{2n} \\rightarrow {\\bf C}^{2n}}")#text(" preserving a non-degenerate antisymmetric form ")#mi("{\\omega: {\\bf C}^{2n} \\times {\\bf C}^{2n} \\rightarrow {\\bf C}}")#text(", such as the standard symplectic form")

#align(center)[#tao-fit-display[#mitex("\\omega((z_1,\\ldots,z_{2n}), (w_1,\\ldots,w_{2n})) := \\sum_{j=1}^n z_j w_{n+j} - z_{n+j} w_j.")]]],
[#text("(Type ")#mi("{D_n}")#text(") The special orthogonal group ")#mi("{SO_{2n}({\\bf C})}")#text(" of (orientation preserving) linear maps ")#mi("{{\\bf C}^{2n} \\rightarrow {\\bf C}^{2n}}")#text(" preserving a non-degenerate symmetric form ")#mi("{\\langle,\\rangle: {\\bf C}^{2n} \\times {\\bf C}^{2n} \\rightarrow {\\bf C}}")#text(" (such as the standard symmetric form).")]
)

#text("For this post I will abuse notation somewhat and identify ")#mi("{A_n}")#text(" with ")#mi("{SL_{n+1}({\\bf C})}")#text(", ")#mi("{B_n}")#text(" with ")#mi("{SO_{2n+1}({\\bf C})}")#text(", etc., although it is more accurate to say that ")#mi("{SL_{n+1}({\\bf C})}")#text(" is a Lie group of ")#emph[#text("type")]#text(" ")#mi("{A_n}")#text(", etc., as there are other forms of the Lie algebras associated to ")#mi("{A_n, B_n, C_n, D_n}")#text(" over various fields. Over a non-algebraically closed field, such as ")#mi("{{\\bf R}}")#text(", the list of Lie groups associated with a given type can in fact get quite complicated; see for instance ")#link("http://en.wikipedia.org/wiki/List_of_simple_Lie_groups")[#text("this list")]#text(". One can also view the double covers ")#mi("{Spin_{2n+1}({\\bf C})}")#text(" and ")#mi("{Spin_{2n}({\\bf C})}")#text(" of ")#mi("{SO_{2n+1}({\\bf C})}")#text(", ")#mi("{SO_{2n}({\\bf C})}")#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Spin_group")[#text("spin groups")]#text(") as being of type ")#mi("{B_n, D_n}")#text(" respectively; however, I find the spin groups less intuitive to work with than the orthogonal groups and will therefore focus more on the orthogonal model.")

#text("The reason for this subscripting is that each of the classical groups ")#mi("{A_n, B_n, C_n, D_n}")#text(" has ")#link("http://en.wikipedia.org/wiki/Rank_of_a_Lie_group")[#text("rank")]#text(" ")#mi("{n}")#text(", i.e. the dimension of any maximal connected abelian subgroup of simultaneously diagonalisable elements (also known as a ")#link("http://en.wikipedia.org/wiki/Cartan_subgroup")[#text("Cartan subgroup")]#text(") is ")#mi("{n}")#text(". For instance:")

#enum(start: 1, 
[#text("(Type ")#mi("{A_n}")#text(") In ")#mi("{SL_{n+1}({\\bf C})}")#text(", one Cartan subgroup is the diagonal matrices in ")#mi("{SL_{n+1}({\\bf C})}")#text(", which has dimension ")#mi("{n}")#text(".")],
[#text("(Type ")#mi("{B_n}")#text(") In ")#mi("{SO_{2n+1}({\\bf C})}")#text(", all Cartan subgroups are isomorphic to ")#mi("{SO_2({\\bf C})^n \\times SO_1({\\bf C})}")#text(", which has dimension ")#mi("{n}")#text(".")],
[#text("(Type ")#mi("{C_n}")#text(") In ")#mi("{Sp_{2n}({\\bf C})}")#text(", all Cartan subgroups are isomorphic to ")#mi("{SO_2({\\bf C})^n \\leq Sp_2({\\bf C})^n \\leq Sp_{2n}({\\bf C})}")#text(", which has dimension ")#mi("{n}")#text(".")],
[#text("(Type ")#mi("{D_n}")#text(") in ")#mi("{SO_{2n}({\\bf C})}")#text(", all Cartan subgroups are isomorphic to ")#mi("{SO_2({\\bf C})^n}")#text(", which has dimension ")#mi("{n}")#text(".")]
)

#text("(This same convention also underlies the notation for the ")#link("http://en.wikipedia.org/wiki/Exceptional_Lie_group#Exceptional_cases")[#text("exceptional simple Lie groups")]#text(" ")#mi("{G_2, F_4, E_6, E_7, E_8}")#text(", which we will not discuss further here.)")

#text("With two exceptions, the classical Lie groups ")#mi("{A_n,B_n,C_n,D_n}")#text(" are all ")#link("http://en.wikipedia.org/wiki/Simple_Lie_group")[#text("simple")]#text(", i.e. their Lie algebras are non-abelian and not expressible as the direct sum of smaller Lie algebras. The two exceptions are ")#mi("{D_1 = SO_2({\\bf C})}")#text(", which is abelian (isomorphic to ")#mi("{{\\bf C}^\\times}")#text(", in fact) and thus not considered simple, and ")#mi("{D_2 = SO_4({\\bf C})}")#text(", which turns out to “essentially” split as ")#mi("{A_1 \\times A_1 = SL_2({\\bf C}) \\times SL_2({\\bf C})}")#text(", in the sense that the former group is double covered by the latter (and in particular, there is an ")#link("http://en.wikipedia.org/wiki/Isogeny")[#text("isogeny")]#text(" from the latter to the former, and the Lie algebras are isomorphic).")

#text("The ")#link("http://en.wikipedia.org/wiki/Adjoint_representation_of_a_Lie_group")[#text("adjoint action")]#text(" of a Cartan subgroup of a Lie group ")#mi("{G}")#text(" on the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" splits that algebra into ")#link("http://en.wikipedia.org/wiki/Weight_space#Weight_space_of_a_representation")[#text("weight spaces")]#text("; in the case of a simple Lie group, the associated weights are organised by a ")#link("http://en.wikipedia.org/wiki/Dynkin_diagram")[#text("Dynkin diagram")]#text(". The Dynkin diagrams for ")#mi("{A_n, B_n, C_n, D_n}")#text(" are of course well known, and can be found for instance ")#link("http://en.wikipedia.org/wiki/File:Finite_Dynkin_diagrams.svg")[#text("here")]#text(".")

#text("For small ")#mi("{n}")#text(", some of these Dynkin diagrams are isomorphic; this is a classic instance of the tongue-in-cheek ")#link("http://en.wikipedia.org/wiki/Strong_Law_of_Small_Numbers")[#text("strong law of small numbers")]#text(", though in this case “strong law of small diagrams” would be more appropriate. These accidental isomorphisms then give rise to the ")#link("http://en.wikipedia.org/wiki/Exceptional_isomorphism")[#text("exceptional isomorphisms")]#text(" between Lie algebras (and thence to ")#emph[#text("exceptional isogenies")]#text(" between Lie groups). Excluding those isomorphisms involving the exceptional Lie algebras ")#mi("{E_n}")#text(" for ")#mi("{n=3,4,5}")#text(", these isomorphisms are")

#enum(start: 1, 
[#mi("{A_1 = B_1 = C_1}")#text(";")],
[#mi("{B_2 = C_2}")#text(";")],
[#mi("{D_2 = A_1 \\times A_1}")#text(";")],
[#mi("{D_3 = A_3}")#text(".")]
)

#text("There is also a pair of exceptional isomorphisms from (the ")#mi("{Spin_8}")#text(" form of) ")#mi("{D_4}")#text(" to itself, a ")#link("http://en.wikipedia.org/wiki/Triality")[#text("phenomenon known as triality")]#text(".")

#text("These isomorphisms are most easily seen via algebraic and combinatorial tools, such as an inspection of the Dynkin diagrams (see e.g. ")#link("http://upload.wikimedia.org/wikipedia/commons/0/03/Dynkin_Diagram_Isomorphisms.svg")[#text("this Wikipedia image")]#text("). However, the isomorphisms listed above can also be seen by more “geometric” means, using the basic representations of the classical Lie groups on their natural vector spaces (")#mi("{{\\bf C}^{n+1}, {\\bf C}^{2n+1}, {\\bf C}^{2n}, {\\bf C}^{2n}}")#text(" for ")#mi("{A_n, B_n, C_n, D_n}")#text(" respectively) and combinations thereof (such as ")#link("http://en.wikipedia.org/wiki/Exterior_algebra")[#text("exterior powers")]#text("). (However, I don’t know of a simple way to interpret triality geometrically; the descriptions I have seen tend to involve some algebraic manipulation of the octonions or of a Clifford algebra, in a manner that tended to obscure the geometry somewhat.) These isomorphisms are quite standard (I found them, for instance, in this ")#link("http://www.ams.org/mathscinet-getitem?mr=2265844")[#text("book of Procesi")]#text("), but it was instructive for me to work through them (as I have only recently needed to start studying algebraic group theory in earnest), and I am recording them here in case anyone else is interested.")

#metadata(none) <tao-c9fc0023ae46937127ee>

#heading(level: 1)[#strong[#text(" — 1. ")#mi("{A_1=C_1}")#text(" — ")]]

#text("This is the simplest correspondence. ")#mi("{A_1 = SL_2({\\bf C})}")#text(" is the group of transformations ")#mi("{T: {\\bf C}^2 \\rightarrow {\\bf C}^2}")#text(" that preserve the volume form; ")#mi("{C_1 = Sp_2({\\bf C})}")#text(" is the group of transformations ")#mi("{T: {\\bf C}^2 \\rightarrow {\\bf C}^2}")#text(" that preserve the symplectic form. But in two dimensions, the volume form and the symplectic form are the same.")

#heading(level: 1)[#strong[#text(" — 2. ")#mi("{A_1=B_1}")#text(" — ")]]

#text("The group ")#mi("{A_1 = SL_2({\\bf C})}")#text(" naturally acts on ")#mi("{{\\bf C}^2}")#text(". But it also has an obvious three-dimensional action, namely the adjoint action ")#mi("{g: X \\mapsto gXg^{-1}}")#text(" on the Lie algebra ")#mi("{\\mathfrak{sl}_2({\\bf C})}")#text(" of ")#mi("{2 \\times 2}")#text(" complex matrices of trace zero. This action preserves the Killing form")

#align(center)[#tao-fit-display[#mitex("\\langle X, Y \\rangle_{\\mathfrak{sl}_2({\\bf C})} := \\text{tr}(XY)")]]

#text("due to the cyclic nature of the trace. The Killing form is symmetric and non-degenerate (this reflects the simple nature of ")#mi("{A_1}")#text("), and so we see that each element of ")#mi("{SL_2({\\bf C})}")#text(" has been mapped to an element of")

#align(center)[#tao-fit-display[#mitex("SO( \\mathfrak{sl}_2({\\bf C}) ) \\equiv SO_3({\\bf C}) = B_1,")]]

#text("thus giving a homomorphism from ")#mi("{A_1}")#text(" to ")#mi("{B_1}")#text(". The group ")#mi("{A_1}")#text(" has dimension ")#mi("{2^2-1=3}")#text(", and ")#mi("{B_1}")#text(" has dimension ")#mi("{3(3-1)/2 = 3}")#text(", so ")#mi("{A_1}")#text(" and ")#mi("{B_1}")#text(" have the same dimension. The kernel of the map is easily seen to be the centre ")#mi("{\\{ +1, -1 \\}}")#text(" of ")#mi("{A_1}")#text(", and so this is a double cover of ")#mi("{B_1}")#text(" by ")#mi("{A_1}")#text(" (thus interpreting ")#mi("{A_1 = SL_2({\\bf C})}")#text(" as the spin group ")#mi("{Spin_3({\\bf C})}")#text(").")

#text("A slightly different interpretation of this correspondence, using quaternions, was discussed in ")#link("https://terrytao.wordpress.com/2011/03/05/lines-in-the-euclidean-group-se2/")[#text("this recent blog post")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. ")#mi("{A_3 = D_3}")#text(" — ")]]

#text("The group ")#mi("{A_3 = SL_4({\\bf C})}")#text(" naturally acts on ")#mi("{{\\bf C}^4}")#text(". Like ")#mi("{A_1}")#text(", it has an adjoint action (on the ")#mi("{15}")#text("-dimensional Lie algebra ")#mi("{\\mathfrak{sl}_4({\\bf C})}")#text("), but this is not the action we will use for the ")#mi("{A_3=D_3}")#text(" correspondence. Instead, we will look at the action on the ")#mi("{\\binom{4}{2} = 6}")#text("-dimensional ")#link("http://en.wikipedia.org/wiki/Exterior_algebra")[#text("exterior power")]#text(" ")#mi("{\\bigwedge^2 {\\bf C}^4}")#text(" of ")#mi("{{\\bf C}^4}")#text(", given by the usual formula")

#align(center)[#tao-fit-display[#mitex("g( v \\wedge w ) := (gv) \\wedge (gw).")]]

#text("Since ")#mi("{2+2=4}")#text(", the volume form on ")#mi("{{\\bf C}^4}")#text(" induces a bilinear form ")#mi("{\\langle, \\rangle}")#text(" on ")#mi("{\\bigwedge^2 {\\bf C}^2}")#text("; since ")#mi("{2}")#text(" is even, this form is symmetric rather than anti-symmetric, and it is also non-degenerate. An element of ")#mi("{SL_4({\\bf C})}")#text(" preserves the volume form and thus preserves the bilinear form, giving a map from ")#mi("{SL_4({\\bf C})}")#text(" to")

#align(center)[#tao-fit-display[#mitex("SO( \\bigwedge^2 {\\bf C}^4 ) \\equiv SO_6({\\bf C}) = D_3.")]]

#text("This is a homomorphism from ")#mi("{A_3}")#text(" to ")#mi("{D_3}")#text(". The group ")#mi("{A_3}")#text(" has dimension ")#mi("{4^2-1 = 15}")#text(", and ")#mi("{D_3}")#text(" has dimension ")#mi("{6(6-1)/2 = 15}")#text(", so ")#mi("{A_3}")#text(" and ")#mi("{D_3}")#text(" have the same dimension. As before, the kernel is seen to be ")#mi("{\\{+1,-1\\}}")#text(", so this is a double cover of ")#mi("{D_3}")#text(" by ")#mi("{A_3}")#text(" (thus interpreting ")#mi("{A_3 = SL_4({\\bf C})}")#text(" as the spin group ")#mi("{Spin_6({\\bf C})}")#text(").")

#heading(level: 1)[#strong[#text(" — 4. ")#mi("{B_2 = C_2}")#text(" — ")]]

#text("This is basically a restriction of the ")#mi("{A_3=D_3}")#text(" correspondence. Namely, the group ")#mi("{C_2 = Sp_4({\\bf C})}")#text(" acts on ")#mi("{{\\bf C}^4}")#text(" in a manner that preserves the symplectic form ")#mi("{\\omega}")#text(", and hence (on taking a wedge product) the volume form also. Thus ")#mi("{C_2}")#text(" is a subgroup of ")#mi("{SL_4({\\bf C}) = A_3}")#text(", and as discussed above, thus acts orthogonally on the six-dimensional space ")#mi("{\\bigwedge^2 {\\bf C}^4}")#text(". On the other hand, the symplectic form ")#mi("{\\omega}")#text(" can itself be thought of as an element of ")#mi("{\\bigwedge^2 {\\bf C}^4}")#text(", and is clearly fixed by all of ")#mi("{C_2}")#text("; thus ")#mi("{C_2}")#text(" also stabilises the five-dimensional orthogonal complement ")#mi("{\\omega^\\perp}")#text(" of ")#mi("{\\omega}")#text(" inside ")#mi("{\\bigwedge^2 {\\bf C}^4}")#text(". Note that ")#mi("{\\omega}")#text(" is non-degenerate (here we crucially use the fact that the characteristic is not two!) and so ")#mi("{\\omega^\\perp}")#text(" is also non-degenerate. We have thus mapped ")#mi("{C_2}")#text(" to")

#align(center)[#tao-fit-display[#mitex("SO( \\omega^\\perp ) \\equiv SO_5({\\bf C}) = B_2.")]]

#text("This is a homomorphism from ")#mi("{C_2}")#text(" to ")#mi("{B_2}")#text(". The group ")#mi("{C_2}")#text(" has dimension ")#mi("{2(4+1) = 10}")#text(", while ")#mi("{B_2}")#text(" has dimension ")#mi("{5(5-1)/2 = 10}")#text(", so ")#mi("{B_2}")#text(" and ")#mi("{C_2}")#text(" have the same dimension. Once again, one can verify that the kernel is ")#mi("{\\{+1,-1\\}}")#text(", so this is a double cover of ")#mi("{B_2}")#text(" by ")#mi("{C_2}")#text(" (thus interpreting ")#mi("{C_2 = Sp_4({\\bf C})}")#text(" as the spin group ")#mi("{Spin_5({\\bf C})}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In characteristic two, the above map from ")#mi("{C_2}")#text(" to ")#mi("{B_2}")#text(" disappears, but there is a somewhat different identification between ")#mi("{B_n = SO_{2n+1}(k)}")#text(" and ")#mi("{C_n = Sp_{2n}(k)}")#text(" for any ")#mi("{n}")#text(" in this case. Namely, in characteristic two, inside ")#mi("{k^{2n+1}}")#text(" with a non-degenerate symmetric form ")#mi("{\\langle,\\rangle}")#text(", the set of null vectors (vectors ")#mi("{x}")#text(" with ")#mi("{\\langle x, x \\rangle = 0}")#text(") forms a ")#mi("{2n}")#text("-dimensional hyperplane, and the restriction of the symmetric form to that hyperplane becomes a symplectic form (which, in characteristic two, is defined to be an anti-symmetric form ")#mi("{\\omega}")#text(" with ")#mi("{\\omega(x,x)=0}")#text(" for all ")#mi("{x}")#text("). This provides the claimed identification between ")#mi("{B_n}")#text(" and ")#mi("{C_n}")#text(".")
]

#heading(level: 1)[#strong[#text(" — 5. ")#mi("{D_2 = A_1 \\times A_1}")#text(" — ")]]

#text("The group ")#mi("{A_1 \\times A_1 = SL_2({\\bf C}) \\times SL_2({\\bf C})}")#text(" acts on ")#mi("{{\\bf C}^2 \\otimes {\\bf C}^2}")#text(" by tensor product:")

#align(center)[#tao-fit-display[#mitex("(g,h) (v \\otimes w) := (gv) \\otimes (hw).")]]

#text("Each individual factor ")#mi("{g, h}")#text(" preserves the symplectic form ")#mi("{\\omega}")#text(" on ")#mi("{{\\bf C}^2}")#text(", and so the pair ")#mi("{(g,h)}")#text(" preserves the tensor product ")#mi("{\\omega \\otimes \\omega}")#text(", which is the bilinear form on ")#mi("{{\\bf C}^2 \\otimes {\\bf C}^2}")#text(" defined as")

#align(center)[#tao-fit-display[#mitex("\\omega \\otimes \\omega( (v\\otimes w), (v^{\\prime} \\otimes w^{\\prime}) ) := \\omega(v,v^{\\prime}) \\omega(w,w^{\\prime}).")]]

#text("As each factor ")#mi("{\\omega}")#text(" is anti-symmetric and non-degenerate, the tensor product ")#mi("{\\omega \\otimes \\omega}")#text(" is symmetric and non-degenerate. Thus we have mapped ")#mi("{A_1 \\times A_1}")#text(" into")

#align(center)[#tao-fit-display[#mitex("SO( {\\bf C}^2 \\otimes {\\bf C}^2 ) = SO_4({\\bf C}) = D_2.")]]

#text("The group ")#mi("{A_1 \\times A_1}")#text(" has dimension ")#mi("{(2^2-1) + (2^2-1)=6}")#text(", and ")#mi("{D_2}")#text(" has dimension ")#mi("{4(4-1)/2=6}")#text(", so ")#mi("{A_1 \\times A_1}")#text(" and ")#mi("{D_2}")#text(" have the same dimension. As before, the kernel can be verified to be ")#mi("{\\{ (+1,+1), (-1,-1) \\}}")#text(", and so this is a double cover of ")#mi("{D_2}")#text(" by ")#mi("{A_1 \\times A_1}")#text(" (thus interpreting ")#mi("{A_1 \\times A_1 = SL_2({\\bf C}) \\times SL_2({\\bf C})}")#text(" as the spin group ")#mi("{Spin_4({\\bf C})}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" All of these exceptional isomorphisms can be treated algebraically in a unified manner using the machinery of ")#link("http://en.wikipedia.org/wiki/Clifford_algebra")[#text("Clifford algebras")]#text(" and ")#link("http://en.wikipedia.org/wiki/Spinor")[#text("spinors")]#text("; however, I find the more ")#emph[#text("ad hoc")]#text(" geometric approach given here to be easier to visualise.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In the above discussion, we relied heavily on matching dimensions to ensure that various homomorphisms were in fact isogenies. There are some other exceptional homomorphisms in low dimension which are not isogenies due to mismatching dimensions, but are still of interest. For instance, there is a way to embed the six-dimensional space ")#mi("{D_2 = A_1 \\times A_1 = C_1 \\times B_1 = Sp_2({\\bf C}) \\times SO_3({\\bf C})}")#text(" into the ")#mi("{21}")#text("-dimensional space ")#mi("{C_3 = Sp_6({\\bf C})}")#text(", by letting ")#mi("{Sp_2({\\bf C})}")#text(" act on ")#mi("{{\\bf C}^2}")#text(" and ")#mi("{SO_3({\\bf C})}")#text(" act on ")#mi("{{\\bf C}^3}")#text(", so that ")#mi("{Sp_2({\\bf C}) \\times SO_3({\\bf C})}")#text(" acts on the six-dimensional tensor product ")#mi("{{\\bf C}^2 \\otimes {\\bf C}^3}")#text(" in the obvious manner; this preserves the tensor product of the symplectic form on ")#mi("{{\\bf C}^2}")#text(" and the symmetric form on ")#mi("{{\\bf C}^3}")#text(", which is a non-degenerate symplectic form on ")#mi("{{\\bf C}^2 \\otimes {\\bf C}^3 \\equiv {\\bf C}^6}")#text(", giving the homomorphism (with the kernel once again being ")#mi("{\\{(+1,+1),(-1,-1)\\}}")#text("). These sorts of embeddings were useful in ")#link("https://terrytao.wordpress.com/2010/10/21/strongly-dense-free-subgroups-of-semisimple-algebraic-groups/")[#text("a recent paper of Breuillard, Green, Guralnick, and myself")]#text(", as they gave examples of semisimple groups that could be easily separated from other semisimple groups (such as ")#mi("{C_1 \\times C_2}")#text(" inside ")#mi("{C_3}")#text(") due to their irreducible action on various natural vector spaces (i.e. they did not stabilise any non-trivial space).")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-50684")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2011")])]

#text("You claim D_1 = C, but it’s actually C^x. ")#emph[#text("[Ha! Good catch – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353db294574b77d85998015b42185b48eccfc964603d2dc00d32795d9e9e8a0a-a6511a8a49674f21017f17e09816198beff00bef720eb01660b6c7e1ccd82265.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Three Dimensional Algebraic Curves | Gaurav Happy Tiwari")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-50687")[#strong[#text("Three Dimensional Algebraic Curves | Gaurav Happy Tiwari")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2011")])]

#text("[…] Exceptional isogenies between the classical Lie groups (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c60fb002fac958ac61874654f834513f8ad2e79a220118feb88e48e16dcdbf14-72de779f47ae137c9e2b8759a76762c685f9a30b0f71ca71c1fbff6d491caf95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Wieland")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-50774")[#strong[#text("Ben Wieland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2011")])]

#text("A Cartan is not “any maximal connected abelian subgroup.” That works in a compact group, where every abelian subgroup is a subgroup of a Cartan. In a linear algebraic group there are not only diagonalizable elements, but also unipotent elements and subgroups of them. Cartans in algebraic groups are not contained in larger abelian subgroups, but there are unipotent subgroups that are not contained in them and which have much larger dimension. I think people usually define them as maximal tori, that is, as (abelian subgroups) consisting only of diagonalizable elements, but Cartan had a different definition involving self-normalization.")

#text("typos: the natural representation of A_n is C^n+1, not C^n; in the last line outside a remark, a “times” should be a “\\times”")

#emph[#text("[Ah, that was a subtlety I was not aware of! Thanks for the corrections – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An erratum to “Strongly dense free subgroups of semisimple Lie groups” « What’s new")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-51083")[#strong[#text("An erratum to “Strongly dense free subgroups of semisimple Lie groups” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("[…] that is double-covered by this group) in characteristic . This group (which has Dynkin diagram , as discussed in this previous post) has one maximal rank proper semisimple subgroup up to conjugacy, namely , which is the stabiliser […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-156159")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2012")])]

#text("Sorry for the silly question, but what are you doing exactly when you do those dimension counts? You have nice homomorphisms between complex Lie groups of the same dimension with discrete kernel. These are clearly locally isomorphisms near the identity but I am not sure why it follows that they are surjective. Are you using a general fact about complex Lie groups? Complex manifolds? Varieties?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-156160")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2012")])]

#text("Oh, I see; it follows that the maps are open, and all of these groups are connected.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the classification of complex Lie algebras | What's new")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-226585")[#strong[#text("Notes on the classification of complex Lie algebras | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2013")])]

#text("[…] resulting algebras are either isomorphic to other algebras on this list, or cease to be simple; see this previous post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa08d5d675e478446ad5e01463c87ef9842630fd1645f768734d8df77a1d24e5-379f8de41c486be5f5109084da2d5a450b65b35fdf96f7b0c344516b4ea4bedd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Po Lam Yung")]], [#link("https://terrytao.wordpress.com/2011/03/11/exceptional-isogenies-between-the-classical-lie-groups/#comment-250392")[#strong[#text("Po Lam Yung")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("In the proof of the isomorphism between ")#mi("D_2")#text(" and ")#mi("A_1 \\times A_1")#text(", the form ")#mi("\\omega \\otimes \\omega")#text(" constructed there (see the second display equation in section 5) doesn’t seem to be bilinear. e.g. if one scales ")#mi("(v,w)")#text(" by 2, the right hand side of the equation mentioned above seem to scale by 4. Did I overlook something?")

#emph[#text("[Oops, I should have taken tensor product instead of direct sum here. Corrected, thanks – T.]")]
]
