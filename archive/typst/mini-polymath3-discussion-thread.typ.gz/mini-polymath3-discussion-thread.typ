// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/
// Converted to Typst by tao2typ: "2026-10-14T16:36:34.208860+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath3 discussion thread", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath3 discussion thread")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 July 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/")[#text("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just opened the ")#link("http://polymathprojects.org/2011/07/19/minipolymath3-project-2011-imo/")[#text("research thread")]#text(" for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2011")[#text("mini-polymath3 project")]#text(" over at the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text(". I decided to use Q2 of this year’s IMO, in part to see how the polymath format copes with a geometric problem. (The full list of questions for this year is ")#link("http://official.imo2011.nl/problems.aspx")[#text("available here")]#text(".)")

#text("This post will serve as the discussion thread of the project, intended to focus all the non-research aspects of the project such as organisational matters or commentary on the progress of the project. The third component of the project is the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2011")[#text("wiki page")]#text(", which is intended to summarise the progress made so far on the problem.")

#text("As with ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("mini-polymath1")]#text(" and ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("mini-polymath2")]#text(", I myself will be serving primarily as a moderator, and hope other participants will take the lead in the research and in keeping the wiki up-to-date.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Minipolymath3 project: 2011 IMO « The polymath blog")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58420")[#strong[#text("Minipolymath3 project: 2011 IMO « The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("[…] especially if) they are only partially conclusive. Participants are also encouraged to visit the discussion thread for this project, and also to visit and work on the wiki page to organise the progress made so […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58425")[#strong[#text("International Maths Olympiad 2011 « viXra log")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")]

#text("[…] a Fields medalist and expert solver of IMO type problems has been running a mini-polymath feature on his blog each year and the third one starts today, in case you want to join in the fun. He will choose the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59142279b7943198109b9d9eb1352afa1157c2f03cafb180ec62c110b3b84d9c-5b78cbfb11de0682c490b2b49bc2f0ac7c9dff2319de07802fd9b55997a00c9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CLH")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58433")[#strong[#text("CLH")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("I struck down the wrong path almost instantly. The following discussion has little to do with planar geometry, so it is in effect worthless. But for what it is worth:")

#text("Seems to me that a ‘pivot’ is a mapping from a point P in S to a point Q in S, e.g. f_p(P) = Q. This could be the edge, for instance, of a directed graph. Then what we need to show is that there’s always some element P* and integer k such that:")

#text("S = {f_p(P*)} U {f_p(f_p(P*))} U {f^3_p(P^*)} U … U {f^k_p(P^*)}")

#text("and f^k_p(P^*) = P^*.")

#text("In other words P^* generates all of S under f_p, and also generates itself.")

#text("We could map P to a directed multigraph by labeling each node by Q in S, and each edge by sequence (P,Q_1,…,Q_k) of nodes passed through to reach Q from P, ceasing to label at the first occurrence of (P,…,Q_i,P,…,Q_i,P) as this is in some sense the fundamental cycle. This graph will always be a cycle, but may include orphan nodes. Denote this multigraph by G(P). Then the statement is G(P*) has no orphan nodes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18e67721d634cf8ac62ce730a3e30aa5ac62518a3fb9ca52ad15a9d657a2a407-c851d4be83ebf11e7b2e29c67a944d7d266835661d6def8a6ff78610893f161d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miro")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58434")[#strong[#text("Miro")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("I started a chat for the Minipolymath3 at the following address:")

#link("http://numbersruletheuniverse.com/room/agyca8y3")[#text("http://numbersruletheuniverse.com/room/agyca8y3")]

#text("LaTex formulas should be enclosed between dollar signs in the chat. The site has a whiteboard as well. Internet Explorer support is somewhat limited, but other browsers should work well.")

#text("Disclaimer: I am the owner of the site, and I use it for personal tutoring. I thought it could be useful for polymath projects too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EPL")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58445")[#strong[#text("EPL")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("Does analyzing starting configurations which don’t work help us? Let’s assume the points aren’t in convex position (o/w it’s trivial). One that springs to mind quickest is if we start with a point on the convex hull of S with a line which doesn’t intersect the hull. Another one would be if we have lets say 20")#linebreak()#text(" points in S evenly spread around the unit circle centered at the origin and the")#linebreak()#text(" rest of S close to the origin. Starting with a line joining two close points on the circle we can never get at the center points. Any more interesting examples?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41c5fd66153f27d0d329c88a3c986a701e168765526c01cd6e0528385adaedf1-f858b3eccd39c67487321b6debfc244cae3a8d86e152ab370eecc2a697a1c57d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kerry")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58449")[#strong[#text("Kerry")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("Dear Terry,")

#text("Do you already know a solution to this problem? How long did it take you to solve it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58454")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("The first confirmed solution to the problem ")#link("http://polymathprojects.org/2011/07/19/minipolymath3-project-2011-imo/#comment-3380")[#text("has now appeared")]#text(" (74 minutes after the project started), though some expansion of the argument would be needed to turn it into a complete solution. (For comparison, mini-polymath2 was solved in 148 minutes, and mini-polymath1 ran on for about two days. Of course, this may be due in large part to the relative difficulty of the selected problems.)")

#text("This time around, I deliberately refrained from participating (beyond updating the wiki and other administrative tasks), to see whether the discussion would self-organise. (Also, I accidentally ran across an online solution to the problem while setting up the project.) It seems that there was barely enough organisation to be able to follow the threads, although as with the other polymath projects, the discussion did move at an impressively fast rate (over 80 comments in two hours), and it is not clear whether even perfect organisation would really make much of a difference.")

#text("It seems to me that the geometric nature of the problem did not really slow down discussion too much – people seemed to be able to communicate with each other even without the ability to draw pictures or wave hands.")

#text("I would be interested to hear the impressions of other participants or observers on the project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas H")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58456")[#strong[#text("Thomas H")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("I found it enjoyable. I believe it does some time to explain (and read) geometric examples, even when a picture makes something clear in a second. A sketchpad might be useful.")

#text("I think the key observation was really that the number of points on the right of the line is constant. After this, it really is not such a big step to find the solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0381197000a6e4b23da9dd7f1198d7d2842973862e3cc4185909a688aca171a0-2316a18ca20d8df87d785c702d764d80da5612264e0f8faeb30e0444f7637775.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gal")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58457")[#strong[#text("Gal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("First of all, thank you! This was really fun and I would be very interested in participating in more sessions like this one.")

#text("1. I think this was so much fun precisely because the request not to work in isolation. This contributed to a very relaxed atmosphere, where we could just swap ideas. The encouragement to make “trivial” observation also removed barriers and fears. All in all, I think it has captured the quintessence of the collaborative spirit, and it is great fun to do math collaboratively.")

#text("2. Organizationally, I think things were fine as long as we could develop comments into threads via their replies. I believe at some point it would have become unruly, but it didn’t happen here.")

#text("3. The wiki was really helpful; I personally used it to read summaries and overviews. It was mainly constructed by quoting the comments, which is great – and I think it would have been even better if there were links to the quoted comments (so that people could find it easily and reply directly).")

#text("As I said, I would love to participate again (with IMO questions, Putnam, IMC, etc.). Thanks a lot for organizing this!")

#text("Gal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ae459f2ffd1724ccb62fd8edf60bc192a22caefc1ea8a4fd7d463f2b45202b7-0979fc1b4fbe24ccd74ceee9c5de4e9c686ac6b1a24784b65df701612c4cef06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haggai Nuchi")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58566")[#strong[#text("Haggai Nuchi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")])]

#text("This was the first polymath I participated in, and I have mixed feelings about whether I feel it was successful.")

#text("On the one hand, if the only metric for success is how fast the problem is solved, then 74 minutes is nothing to sneeze at. On the other hand, I find that my expectations for what it would be like to be a part of a mass-mind solution were not met.")

#text("Let me explain: part of what I enjoy about doing math collaboratively is being able to see the effect my ideas have on other people. Seeing someone else complete a solution that has my idea hidden inside provides a neat thrill.")

#text("The solution that was found was too simple for me to clearly see the influence of other ideas on it. I’m not suggesting that the solution is trivial or easy to find — it involves a very nice idea which is not immediately obvious. I’m also not suggesting that the previous contributors’ ideas had no effect on producing this solution. I’m just saying that the solution didn’t *obviously* depend on previous comments, and hence makes it a little bit less fun for all those previous contributors.")

#text("Of course, it’s impossible to predict whether this will happen in advance when one does not already know what a solution will look like. Maybe this is a feature of contest problems? I don’t know how many of them are designed to be solved with just a single trick.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ad3f1dea8472011cc6dda2a0de9415c2ff8e61ad5a85819c5f078e6a3443667-169cf59b63af2cef40004b36efa665e4bcb11cfe05d3bf25e321e2ff4046849e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Srivatsan Narayanan")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58888")[#strong[#text("Srivatsan Narayanan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("I too am slightly disappointed that the solution ended up using just one or two neat observations. At the same time, I also enjoyed seeing so many other ideas that still seem not quite useful to solve the problem. To me, this shows how solving a problem typically requires pursuing multiple approaches, only a few of which will eventually succeed.")

#text("Terry, I have a question about *your* experience while organizing Minimath 3. What factors made you pick this particular question out a pool of 6 apparently-equally-good ones? Note that even restricting oneself to geometry problems, there was still an alternative (Q6).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58906")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("To be honest, I felt Q2 was the least bad option for the mini-polymath this time around. Q6 could conceivably be solved by a brute force approach (e.g. using a symbolic computation package, such as Maple), and the inability to easily communicate diagrams to each other would have been rather annoying. For Q4 one could use, say, the OEIS to find the right guess for the answer, and then presumably it would be a routine induction. The other three questions were relatively easy and would have fallen very quickly to a polymath approach, I think. Q2 did indeed rely mostly on one or two neat observations, but it did have the advantage of having a very elementary and appealing formulation, which I thought might make for a more entertaining (albeit briefer) experience than, say, Q6.")

#text("Another issue (which fortunately didn’t spoil the project) was that by the time the project started, solutions to all six questions were already available online, which I had not expected to happen quite as rapidly as it did. It made me wonder if for future mini-polymath projects, one would have to select a more obscure problem than an IMO problem from the most recent Olympiad. (But perhaps that would take some of the fun out of it.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c6262112424c0265c5b7a0ca9c807c75fb92880451485851e67159a5beb93e4-528cd358603681216d9589c7c3b784fdc08c97b557ab4671353a6494cd80acb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-64214")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2011")])]

#text("What about Q1? Specifically, is the answer known for the general $n$-tuples of distinct positive integers with sums of $m$ numbers out of $n$?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c9ab91ed4909914d2ee2c779cb73a2590a46b83c2ade544c82e201567589bd2-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seungly Oh")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58846")[#strong[#text("Seungly Oh")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")])]

#text("This was a very fun and unique experience! Thank you for taking your time to organize it. It really provided a refreshing break from work.")

#text("The biggest challenge for me during this event was trying to follow multiple threads, while working on the problem myself. It would be nice if I could hire a secretary who could keep me up to date while I work otherwise undisturbed on my board. I realize that one eventually needs to pick a thread and go with it. If only I could know in advance which thread would be the winning one. I know that you have mentioned that this should not be a race, but for all intents and purposes, it was a race, however a collaborative one. And that particularly made it more enjoyable for me, reminding of math competitions during high school years.")

#text("I hope this sort of event continues either here or elsewhere, and I will gladly take a break from my work each time!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58467")[#strong[#text("Mini-polymath3 « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2011")]

#text("[…] The mini-polymath3 was today. Here is the research thread. The wiki is here. There is a discussion thread here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-58702")[#strong[#text("Mini Polymath « OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2011")]

#text("[…] of the IMO problems. It started yesterday at 2pm Oklahoma time and already has 130+ comments! If you’re interested in joining in, go here. This year’s question is geometric: Problem 2. Let be a finite set of at least two […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Damien Thomine (Garf)")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-59392")[#strong[#text("Damien Thomine (Garf)")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2011")])]

#text("It was quite a fun experience. I think the collaboration worked pretty well, and allowed people to get out of some dead end (instead of getting stuck in, for instance, approaches via graphs). A few comments :")

#text("* There was no (or at least I didn’t find) option to see the “last comments”. That would be helpful, especially when there are about 15 threads to follow. The wiki provided some relief, though.")

#text("* I would like to see how this medium would cope with “more geometrical” problems. For instance, if one has to introduce some new points, I wonder what would happen if different notations appeared. I also think problems such as (IMO 1996, Problem 1) and (IMO 2004, problem 3) would be quite challenging without pictures.")

#text("Anyway, that was really nice. Thank you !")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/032817fcf3a9a390cbe5993324983d97e9b27d22d059d804721637971b4e1f24-0b95c4630c0048614cd5801d9f0ac4fe06ade7b30dde54b2f0b16dbae45e4b14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mstudent")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-59731")[#strong[#text("mstudent")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2011")])]

#text("Aside comment: the actual IMO results are now out ")#link("http://official.imo2011.nl/year_individual_r.aspx?year=2011")[#text("http://official.imo2011.nl/year_individual_r.aspx?year=2011")]#text(" The stats show that Q2 was the second most difficult one after Q6 ")#link("http://official.imo2011.nl/year_statistics.aspx?year=2011")[#text("http://official.imo2011.nl/year_statistics.aspx?year=2011")]

#text("As for the winners, there’s one perfect score, and also a 13 year-old peruvian contestant who won gold after having won bronze and silver already, so he’s nearly matched Terry’s IMO achievements! It’s great and I hope all those talented students will be well looked after academically speaking so as to develop into profound mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9d0afd7e80741d26c154be7fedf447a7cfac032e95209918c45d1ef5845352d-a7b7c0c3acee4e3027e89a8cb40753685810505c56a7ce9fbe7830ff1f3be127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 3D windmill")]], [#link("https://terrytao.wordpress.com/2011/07/19/mini-polymath3-discussion-thread/#comment-519387")[#strong[#text("3D windmill")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2019")])]

#text("A generalization of the windmill problem to three dimensions:")#linebreak()#text(" Consider a set S of points in 3D, no four of which are coplanar. A 3D windmill is the following process: A plane, containing a ray Q which originates at some point q in S, starts rotating about Q (Q defines the direction of rotation by the right hand rule). If the rotating plane’s next intersection with S is at point r, then the plane “pivots” to r: the plane now starts rotating about a ray R, originating at r, that lies in the plane. The process continues indefinitely, with the pivoting always happening whenever the plane intersects S.")#linebreak()#text(" Prove that one can choose the initial point q and a line L such that a 3D windmill, starting at q, passes through each point in S infinitely often even if all the rotation-defining rays are constrained to be parallel to L.")

#text("The solution rests on a reduction to the solution of the 2D windmill:")#linebreak()#text(" There exists a plane P* such that no three points in S have collinear projections in P* (which implies that the projections to P* are distinct points). Choose q to be the point dictated by the 2D windmill solution to the problem in P*. Choose L to be the line passing through q and its projection in P*. The plane for the 3D windmill’s solution is determined by the line in the 2D windmill’s solution in P* and the line passing through the pivot point and its projection in P*.")#linebreak()#text(" Proving the existence of P* proceeds from assuming the contrary:")#linebreak()#text(" Consider the infinitely many distinct planes that pass through some point p in 3D (p doesn’t need to be a point of S). If each of them have three (or more) collinear projections of the (finite number of) points in S, then at least one triplet of points in S has collinear projections in infinitely many distinct planes passing through p. This implies that the triplet is collinear, which implies that any fourth point in S will be coplanar with this triplet, which contradicts the hypothesis.")
]
