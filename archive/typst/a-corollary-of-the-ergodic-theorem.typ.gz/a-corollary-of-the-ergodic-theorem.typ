// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/
// Converted to Typst by tao2typ: "2026-10-14T10:45:55.510136+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A corollary of the ergodic theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A corollary of the ergodic theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 July 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/")[#text("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{(X,T,\\mu)}")#text(" be a measure-preserving system – a probability space ")#mi("{(X,\\mu)}")#text(" equipped with a measure-preserving translation ")#mi("{T}")#text(" (which for simplicity of discussion we shall assume to be invertible). We will informally think of two points ")#mi("{x,y}")#text(" in this space as being “close” if ")#mi("{y = T^n x}")#text(" for some ")#mi("{n}")#text(" that is not too large; this allows one to distinguish between “local” structure at a point ")#mi("{x}")#text(" (in which one only looks at nearby points ")#mi("{T^n x}")#text(" for moderately large ")#mi("{n}")#text(") and “global” structure (in which one looks at the entire space ")#mi("{X}")#text("). The local/global distinction is also known as the time-averaged/space-averaged distinction in ergodic theory.")

#text("A measure-preserving system is said to be ")#link("https://en.wikipedia.org/wiki/Ergodicity")[#text("ergodic")]#text(" if all the invariant sets are either zero measure or full measure. An equivalent form of this statement is that any measurable function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" which is ")#emph[#text("locally essentially constant")]#text(" in the sense that ")#mi("{f(Tx) = f(x)}")#text(" for ")#mi("{\\mu}")#text("-almost every ")#mi("{x}")#text(", is necessarily ")#emph[#text("globally essentially constant")]#text(" in the sense that there is a constant ")#mi("{c}")#text(" such that ")#mi("{f(x) = c}")#text(" for ")#mi("{\\mu}")#text("-almost every ")#mi("{x}")#text(". A basic consequence of ergodicity is the ")#link("https://en.wikipedia.org/wiki/Ergodic_theory#Mean_ergodic_theorem")[#text("mean ergodic theorem")]#text(": if ")#mi("{f \\in L^2(X,\\mu)}")#text(", then the averages ")#mi("{x \\mapsto \\frac{1}{N} \\sum_{n=1}^N f(T^n x)}")#text(" converge in ")#mi("{L^2}")#text(" norm to the mean ")#mi("{\\int_X f\\ d\\mu}")#text(". (The mean ergodic theorem also applies to other ")#mi("{L^p}")#text(" spaces with ")#mi("{1 < p < \\infty}")#text(", though it is usually proven first in the Hilbert space ")#mi("{L^2}")#text(".) Informally: in ergodic systems, time averages are asymptotically equal to space averages. Specialising to the case of indicator functions, this implies in particular that ")#mi("{\\frac{1}{N} \\sum_{n=1}^N \\mu( E \\cap T^n E)}")#text(" converges to ")#mi("{\\mu(E)^2}")#text(" for any measurable set ")#mi("{E}")#text(".")

#text("In this short note I would like to use the mean ergodic theorem to show that ergodic systems also have the property that “somewhat locally constant” functions are necessarily “somewhat globally constant”; this is not a deep observation, and probably already in the literature, but I found it a cute statement that I had not previously seen. More precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(" Let ")#mi("{(X,T,\\mu)}")#text(" be an ergodic measure-preserving system, and let ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" be measurable. Suppose that ")#metadata(none) <tao-fab66aa01347d3f11a16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\limsup_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\mu( \\{ x \\in X: f(T^n x) = f(x) \\} ) \\geq \\delta")]]



#text(" for some ")#mi("{0 \\leq \\delta \\leq 1}")#text(". Then there exists a constant ")#mi("{c}")#text(" such that ")#mi("{f(x)=c}")#text(" for ")#mi("{x}")#text(" in a set of measure at least ")#mi("{\\delta}")#text(".")
]

#text("Informally: if ")#mi("{f}")#text(" is locally constant on pairs ")#mi("{x, T^n x}")#text(" at least ")#mi("{\\delta}")#text(" of the time, then ")#mi("{f}")#text(" is globally constant at least ")#mi("{\\delta}")#text(" of the time. Of course the claim fails if the ergodicity hypothesis is dropped, as one can simply take ")#mi("{f}")#text(" to be an invariant function that is not essentially constant, such as the indicator function of an invariant set of intermediate measure. This corollary can be viewed as a manifestation of the general principle that ergodic systems have the same “global” (or “space-averaged”) behaviour as “local” (or “time-averaged”) behaviour, in contrast to non-ergodic systems in which local properties do not automatically transfer over to their global counterparts.")

#emph[#text("Proof:")]#text(" By composing ")#mi("{f}")#text(" with (say) the arctangent function, we may assume without loss of generality that ")#mi("{f}")#text(" is bounded. Let ")#mi("{k>0}")#text(", and partition ")#mi("{X}")#text(" as ")#mi("{\\bigcup_{m \\in {\\bf Z}} E_{m,k}}")#text(", where ")#mi("{E_{m,k}}")#text(" is the level set")

#align(center)[#tao-fit-display[#mitex("E_{m,k} := \\{ x \\in X: m 2^{-k} \\leq f(x) < (m+1) 2^{-k} \\}.")]]

#text("For each ")#mi("{k}")#text(", only finitely many of the ")#mi("{E_{m,k}}")#text(" are non-empty. By ")#link(<tao-fab66aa01347d3f11a16>)[#text("(1)")]#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\limsup_{N \\rightarrow \\infty} \\sum_m \\frac{1}{N} \\sum_{n=1}^N \\mu( E_{m,k} \\cap T^n E_{m,k} ) \\geq \\delta.")]]

#text("Using the ergodic theorem, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\mu( E_{m,k} )^2 \\geq \\delta.")]]

#text("On the other hand, ")#mi("{\\sum_m \\mu(E_{m,k}) = 1}")#text(". Thus there exists ")#mi("{m_k}")#text(" such that ")#mi("{\\mu(E_{m_k,k}) \\geq \\delta}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ x \\in X: m_k 2^{-k} \\leq f(x) < (m_k+1) 2^{-k} \\} ) \\geq \\delta.")]]

#text("By the Bolzano-Weierstrass theorem, we may pass to a subsequence where ")#mi("{m_k 2^{-k}}")#text(" converges to a limit ")#mi("{c}")#text(", then we have")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ x \\in X: c-2^{-k} \\leq f(x) \\leq c+2^{-k} \\}) \\geq \\delta")]]

#text("for infinitely many ")#mi("{k}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ x \\in X: f(x) = c \\}) \\geq \\delta.")]]

#text("The claim follows. ")#mi("\\Box")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9da476ef2d21a65ecc964880916e0691211a5956e85ef8c9efb8214d8fa091fa-5d63066447d1a8757be4ba634351c9c2f5adf05b9e736aa24a3c620d144aaafd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of burrobert")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503090")[#strong[#text("burrobert")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("Thanks Terry. Short and sweet. Nice result and demonstration of some basic analysis. The $\\varepsilon$ and $2^{-k}$ correspond to the same object. I think $c – 2^{-k}$ in the second last equation could be replaced by $c$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/341c133653f61e5a4ef6fdfb5c0aa4659af29a209c233db0c4d318289620585b-fd56eed046234e950c4b3fd0c7aa98bbdbca8973e15d977545cd8fef37fb4e48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aritra Bhattacharya")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503097")[#strong[#text("Aritra Bhattacharya")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2018")])]

#text("In the first line of proof, do you mean ")#mi("tan(f(x))")#text(" will be bounded?")

#emph[#text("[Corrected to arctangent – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503288")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("Dear Prof. Tao,")

#text("I think only finitely many of the sets ")#mi("E_{n,\\epsilon}")#text(" have nonzero measure; we may put in points with zero measure without changing anything.")

#text("Did you ever intend to put all your ergodic lectures somehow in one file, so that it’s easily printable??? I’d be VERY interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503289")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("I’d be able to extract the code by a clever S&R program if the math weren’t images, hence the need…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503300")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("I take the correction back, we do have boundedness.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503301")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2018")])]

#text("But still, it’s the ")#mi("E_{m, \\epsilon}")#text(" and not the ")#mi("E_{m,k}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503296")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2018")])]

#text("Ah it’s in the Poincaré legacies book.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-503315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2018")])]

#text("It seems that ergodicity (similarly to analyticity or even convexity) has the potential to “propagate” certain local properties into global ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c26f0315cfad3587dfc501754697db37f9f564cd97d5838243638aa8ba5798a-8aa9f769fdd27b5f12508cfbafa4ead5b70b23ed8ee71a85228df2d8c75ce653.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rogier Brussee")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-504254")[#strong[#text("Rogier Brussee")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("I think you want to compose with the arctangent rather than the tangent function.")

#emph[#text("[Huh, I thought I had fixed that already. In any case, fixed again – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-508359")[#strong[#text("Fourier uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2018")])]

#text("[…] that ths quantity is essentially constant in (cf. the application of the ergodic theorem in this previous blog post), thus we now […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba47469313497327de3de34efa15122c0b7b7351949fd77046cd325c79354966-3499be251a3e5f87ef149fc193557ab0bd43ccb934695cb53c5677db06058e9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of majdoddin")]], [#link("https://terrytao.wordpress.com/2018/07/17/a-corollary-of-the-ergodic-theorem/#comment-517706")[#strong[#text("majdoddin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2019")])]

#text("It seems to me that Corollary 1 can be stated more generally:")

#text("Let ")#mi("(X,T,\\mu)")#text(" be an ergodic measure-preserving system, and let ")#mi("f: X \\rightarrow {\\bf R}")#text(" be measurable. Suppose that")

#tao-math("\\displaystyle \\limsup_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N \\mu( \\{ x \\in X: \\left|f(T^n x) - f(x)\\right| \\le \\epsilon \\} ) \\geq \\delta \\ \\ \\ \\ \\ (1)", block: false)

#text("for some ")#mi("0 \\leq \\epsilon, \\delta \\leq 1")#text(". Then there exists a set ")#mi("E \\subseteq X")#text(" of measure at least ")#mi("\\delta")#text(" such that ")#mi("\\displaystyle \\max_{x \\in E} f(x) - \\min_{x \\in E} f(x) \\le \\epsilon")#text(".")

#text("With Corollary 1 as a special case, and a very similar proof.")
]
