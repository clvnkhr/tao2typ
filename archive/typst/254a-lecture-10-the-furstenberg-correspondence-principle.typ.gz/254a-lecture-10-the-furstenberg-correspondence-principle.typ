// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:16:39.041373+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 10: The Furstenberg correspondence principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 10: The Furstenberg correspondence principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")[#text("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In this lecture, we describe the simple but fundamental ")#emph[#text("Furstenberg correspondence principle")]#text(" which connects the “")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("soft analysis")]#text("” subject of ergodic theory (in particular, recurrence theorems) with the “")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("hard analysis")]#text("” subject of combinatorial number theory (or more generally with results of “density Ramsey theory” type). Rather than try to set up the most general and abstract version of this principle, we shall instead study the canonical example of this principle in action, namely the equating of the ")#emph[#text("Furstenberg multiple recurrence theorem")]#text(" with Szemerédi’s theorem on arithmetic progressions.")#linebreak()#text(" ")#metadata(none) <tao-ada09b0b185e2badb47b>

#text("In 1975, ")#link("http://www.ams.org/mathscinet-getitem?mr=369312")[#text("Szemerédi established")]#text(" the following theorem, which had been conjectured in 1936 by Erdős and Turán:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (")#link("http://www.scholarpedia.org/article/Szemer%C3%A9di%27s_Theorem")[#text("Szemerédi’s theorem")]#text(") Let ")#mi("k \\geq 1")#text(" be an integer, and let A be a set of integers of positive upper density, thus ")#tao-math("\\limsup_{N \\to \\infty} \\frac{1}{2N+1} \\left|A \\cap \\{-N,\\ldots,N\\}\\right| > 0", block: false)#text(". Then A contains a non-trivial arithmetic progression ")#mi("n, n+r, \\ldots, n+(k-1) r")#text(" of length k. (By “non-trivial” we mean that ")#mi("r \\neq 0")#text(".) [More succinctly: every set of integers of positive upper density contains arbitrarily long arithmetic progressions.]")
]

#text("This theorem is trivial for k=1 and k=2. The first non-trivial case is k=3, which was proven ")#link("http://www.ams.org/mathscinet-getitem?mr=51853")[#text("by Roth")]#text(" in 1953 and will be discussed in a later lecture. The k=4 case was also established ")#link("http://www.ams.org/mathscinet-getitem?mr=245555")[#text("by Szemerédi")]#text(" in 1969.")

#text("In 1977, ")#link("http://www.ams.org/mathscinet-getitem?mr=498471")[#text("Furstenberg gave")]#text(" another proof of Szemerédi’s theorem, by establishing the following equivalent statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Furstenberg multiple recurrence theorem) Let ")#mi("k \\geq 1")#text(" be an integer, let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let E be a set of positive measure. Then there exists ")#mi("r > 0")#text(" such that ")#mi("E \\cap T^{-r} E \\cap \\ldots \\cap T^{-(k-1) r} E")#text(" is non-empty.")
]

#strong[#text("Remark 1.")]#text(" The negative signs here can be easily removed because T is invertible, but I have placed them here for consistency with some later results involving non-invertible transformations, in which the negative sign becomes important. ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" Prove that Theorem 2 is equivalent to the apparently stronger theorem in which “is non-empty” is replaced by “has positive measure”, and “there exists ")#mi("r > 0")#text("” is replaced by “there exist infinitely many ")#mi("r > 0")#text("“. ")#mi("\\diamond")

#text("Note that the k=1 case of Theorem 2 is trivial, while the k=2 case follows from the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_recurrence_theorem")[#text("Poincaré recurrence theorem")]#text(" (Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("Lecture 8")]#text("). We will prove the higher k cases of this theorem in later lectures. In this one, we will explain why, for any fixed k, Theorem 1 and Theorem 2 are equivalent.")

#text("Let us first give the easy implication that Theorem 1 implies Theorem 2. This follows immediately from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" be a measure-preserving system, and let E be a set of positive measure. Then there exists a point x in X such that the recurrence set ")#mi("\\{ n \\in {\\Bbb Z}: T^n x \\in E \\}")#text(" has positive upper density.")
]

#text("Indeed, from Lemma 1 and Theorem 1, we obtain a point x for which the set ")#mi("\\{ n \\in {\\Bbb Z}: T^n x \\in E \\}")#text(" contains an arithmetic progression of length k and some step r, which implies that ")#mi("E \\cap T^r E \\cap \\ldots \\cap T^{(k-1) r} E")#text(" is non-empty.")

#strong[#text("Proof of Lemma 1.")]#text(" Observe (from the shift-invariance of ")#mi("\\mu")#text(") that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_X \\frac{1}{2N+1} \\sum_{n=-N}^N 1_{T^n E}\\ d\\mu = \\mu(E).")]]

#text("On the other hand, the integrand is at most 1. We conclude that for each N, the set ")#mi("A_N := \\{ x: \\frac{1}{2N+1} \\sum_{n=-N}^N 1_{T^n E}(x) \\geq \\mu(E)/2 \\}")#text(" must have measure at least ")#mi("\\mu(E)/2")#text(". This implies that the function ")#mi("\\sum_N 1_{A_N}")#text(" is not absolutely integrable even after excluding an arbitrary set of measure up to ")#mi("\\mu(E)/4")#text(", which implies that ")#mi("\\sum_N 1_{A_N}")#text(" is not finite a.e., and the claim follows (cf. the proof of the ")#link("http://en.wikipedia.org/wiki/Borel-Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text("). ")#mi("\\diamond")

#text("Now we show how Theorem 2 implies Theorem 1. If we could pretend that “upper density” was a probability measure on the integers, then this implication would be immediate by applying Theorem 2 to the dynamical system ")#mi("({\\Bbb Z}, n \\mapsto n+1)")#text(". Of course, we know that the integers do not admit a shift-invariant probability measure (and upper density is not even additive, let alone a probability measure). So this does not work directly. Instead, we need to first lift from the integers to a more abstract universal space and use a standard “compactness and contradiction” argument in order to be able to build the desired probability measure properly.")

#text("More precisely, let A be as in Theorem 1. Consider the topological boolean Bernoulli dynamical system ")#mi("2^{\\Bbb Z}")#text(" with the product topology and the shift ")#mi("T: B \\mapsto B+1")#text(". The set A can be viewed as a point in this system, and the orbit closure ")#mi("X := \\overline{\\{ A+n: n \\in {\\Bbb Z} \\}}")#text(" of that point becomes a subsystem of that Bernoulli system, with the relative topology.")

#text("Suppose for contradiction that A contains no non-trivial progressions of length k, thus ")#mi("A \\cap A+r \\cap \\ldots \\cap A+(k-1)r = \\emptyset")#text(" for all ")#mi("r > 0")#text(". Then, if we define the ")#link("http://en.wikipedia.org/wiki/Cylinder_set")[#text("cylinder set")]#text(" ")#mi("E := \\{ B \\in X: 0 \\in B \\}")#text(" to be the collection of all points in X which (viewed as sets of integers) contain 0, we see (after unpacking all the definitions) that ")#mi("E \\cap T^r E \\cap \\ldots T^{(k-1)r} E = \\emptyset")#text(" for all ")#mi("r > 0")#text(".")

#text("In order to apply Theorem 2 and obtain the desired contradiction, we need to find a shift-invariant Borel probability measure ")#mi("\\mu")#text(" on X which assigns a positive measure to E.")

#text("For each integer N, consider the measure ")#mi("\\mu_N")#text(" which assigns a mass of ")#mi("\\frac{1}{2N+1}")#text(" to the points ")#mi("T^{-n} A")#text(" in X for ")#mi("-N \\leq n \\leq N")#text(", and no mass to the rest of X. Then we see that ")#tao-math("\\mu_N(E) = \\frac{1}{2N+1} \\left|A \\cap \\{-N,\\ldots,N\\}\\right|", block: false)#text(". Thus, since A has positive upper density, there exists some sequence ")#mi("N_j")#text(" going to infinity such that ")#mi("\\liminf_{j \\to \\infty} \\mu_{N_j}(E) > 0")#text(". On the other hand, by vague sequential compactness (Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text(") we know that some subsequence of ")#mi("\\mu_{N_j}")#text(" converges in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(" to a probability measure ")#mi("\\mu")#text(", which then assigns a positive measure to the (clopen) set E. As the ")#mi("\\mu_{N_j}")#text(" are asymptotically shift invariant, we see that ")#mi("\\mu")#text(" is invariant also (as in the proof of Corollary 1 of ")#link("https://terrytao.wordpress.com/2008/01/28/254a-lecture-7-structural-theory-of-topological-dynamical-systems/")[#text("Lecture 7")]#text("). As ")#mi("\\mu")#text(" now has all the required properties, we have completed the deduction of Theorem 1 from Theorem 2.")

#strong[#text("Exercise 2. ")]#text("Show that Theorem 2 in fact implies a seemingly stronger version of Theorem 1, in which the conclusion becomes the assertion that the set ")#mi("\\{ n: n, n+r, \\ldots, n+(k-1) r \\in A \\}")#text(" has positive upper density for infinitely many r. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Show that Theorem 1 in fact implies a seemingly stronger version of Theorem 2: If ")#mi("E_1, E_2, E_3, \\ldots")#text(" are sets in a probability space with uniformly positive measure (i.e. ")#mi("\\inf_n \\mu(E_n) > 0")#text("), then for any k there exists positive integers n, r such that ")#mi("\\mu( E_n \\cap E_{n+r} \\cap \\ldots \\cap E_{n+(k-1)r} ) > 0")#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Varnavides type theorems —")]

#text("A similar “compactness and contradiction” argument (combined with a preliminary averaging-over-dilations trick ")#link("http://www.ams.org/mathscinet-getitem?mr=106865")[#text("of Varnavides")]#text(") allows us to use Theorem 2 to imply the following apparently stronger statement (observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1784213")[#text("by Bergelson, Host, McCutcheon, and Parreau")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (Uniform Furstenberg multiple recurrence theorem) Let ")#mi("k \\geq 1")#text(" be an integer and ")#mi("\\delta > 0")#text(". Then for any measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" and any measurable set E with ")#mi("\\mu(E) \\geq \\delta")#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{N} \\sum_{r=0}^{N-1} \\mu( E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E) \\geq c(k,\\delta)")]]

#text("for all ")#mi("N \\geq 1")#text(", where ")#mi("c(k,\\delta) > 0")#text(" is a positive quantity which depends only on k and ")#mi("\\delta")#text(" (i.e. it is uniform over all choices of system and of the set E with measure at least ")#mi("\\delta")#text(").")
]

#strong[#text("Exercise 4. ")]#text("Assuming Theorem 3, show that if N is sufficiently large depending on k and ")#mi("\\delta")#text(", then any subset of ")#mi("\\{1,\\ldots,N\\}")#text(" with cardinality at least ")#mi("\\delta N")#text(" will contain at least ")#mi("c^{\\prime}(k,\\delta) N^2")#text(" non-trivial arithmetic progressions of length k, for some ")#mi("c^{\\prime}(k,\\delta) > 0")#text(". (This result for k=3 was first established by Varnavides via an averaging argument from Roth’s theorem.) Conclude in particular that Theorem 3 implies Theorem 1. ")#mi("\\diamond")

#text("It is clear that Theorem 3 implies Theorem 2; let us now establish the converse. We first use an averaging argument of Varnavides to reduce Theorem 3 to a weaker statement, in which the conclusion (2) is not asserted to hold for all N, but instead one asserts that")

#align(center)[#mi("\\displaystyle \\frac{1}{N_0} \\sum_{r=1}^{N_0-1} \\mu( E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E) \\geq c(k,\\delta)")#text(" (2′)")]

#text("is true for some ")#mi("N_0 = N_0(k,\\delta) > 0")#text(" depending only on k and ")#mi("\\delta")#text(" (note that the r=0 term in (2′) has been dropped, otherwise the claim is trivial). To see why one can recover (2) from (2′), observe by replacing the shift T with a power ")#mi("T^a")#text(" that we can amplify (2′) to")

#align(center)[#mi("\\displaystyle \\frac{1}{N_0} \\sum_{r=1}^{N_0-1} \\mu( E \\cap T^{ar} E \\cap \\ldots \\cap T^{(k-1)ar} E) \\geq c(k,\\delta)")#text(" (2”)")]

#text("for all a. Averaging (2”) over ")#mi("1 \\leq a \\leq N/N_0")#text(" we easily conclude (2).")

#text("It remains to prove that (2”) holds under the hypotheses of Theorem 3. Our next reduction is to observe that for it suffices to perform this task for the boolean Bernoulli system ")#mi("X_0 := 2^{\\Bbb Z}")#text(" with the cylinder set ")#mi("E_0 := \\{ B \\in X_0: 0 \\in B\\}")#text(" as before. To see this, recall from Example 5 of ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("Lecture 2")]#text(" that there is a morphism ")#mi("\\phi: X \\to X_0")#text(" from any measure-preserving system ")#mi("(X, {\\mathcal X}, \\mu, T)")#text(" with a distinguished set E to the system ")#mi("X_0")#text(" with the product ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal X}_0")#text(", the usual shift ")#mi("T_0")#text(", and the set ")#mi("E_0")#text(", and with the push-forward measure ")#mi("\\mu_0 := \\phi_\\# \\mu")#text(". Specifically, ")#mi("\\phi")#text(" sends any point x in X to its recurrence set ")#mi("\\phi(x) := \\{ n \\in {\\Bbb Z}: T^n x \\in E \\}")#text(". Using this morphism it is not difficult to show that the claim (2) for ")#mi("(X, {\\mathcal X},\\mu,T)")#text(" and E would follow from the same claim for ")#mi("(X_0, {\\mathcal X}_0,\\mu_0,T_0)")#text(" and ")#mi("E_0")#text(".")

#text("We still need to prove (2”) for the boolean system. The point is that by lifting to this universal setting, the dynamical system ")#mi("(X, {\\mathcal X}, T)")#text(" and the set E have been canonically fixed; the only remaining parameter is the probability measure ")#mi("\\mu")#text(". But now we can exploit vague sequential compactness again as follows.")

#text("Suppose for contradiction that Theorem 3 failed for the boolean system. Then by carefully negating all the quantifiers, we can find ")#mi("\\delta > 0")#text(" such that for any ")#mi("N_0")#text(" there is a sequence of shift-invariant probability measures ")#mi("\\mu_j")#text(" on X with ")#mi("\\mu_j(E) \\geq \\delta")#text(",")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{N_0} \\sum_{r=1}^{N_0-1} \\mu_j( E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E) \\to 0")]]

#text("as ")#mi("j \\to \\infty")#text(". Note that if (3) holds for one value of ")#mi("N_0")#text(", then it also holds for all smaller values of ")#mi("N_0")#text(". A standard diagonalisation argument then allows us to build a sequence ")#mi("\\mu_j")#text(" as above, but which obeys (3) for ")#emph[#text("all")]#text(" ")#mi("N_0 \\geq 1")#text(".")

#text("Now we are finally in a good position to apply vague sequential compactness. By passing to a subsequence if necessary, we may assume that ")#mi("\\mu_j")#text(" converges vaguely to a limit ")#mi("\\mu")#text(", which is a shift-invariant probability measure. In particular we have ")#mi("\\mu(E) \\geq \\delta > 0")#text(", while from (3) we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{N_0} \\sum_{r=1}^{N_0-1} \\mu( E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E) = 0")]]

#text("for all ")#mi("N_0 \\geq 1")#text("; thus the sets ")#mi("E \\cap T^r E \\cap \\ldots \\cap T^{(k-1)r} E")#text(" all have zero measure for ")#mi("r > 0")#text(". But this contradicts Theorem 2 (and Exercise 1). This completes the deduction of Theorem 3 from Theorem 2.")

#heading(level: 1)[#text("— Other recurrence theorems and their combinatorial counterparts —")]

#text("The Furstenberg correspondence principle can be extended to relate several other recurrence theorems to their combinatorial analogues. We give some representative examples here (without proofs). Firstly, there is a multidimensional version of Szemerédi’s theorem (compare with Exercise 7 from ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" (Multidimensional Szemerédi theorem) Let ")#mi("d \\geq 1")#text(", let ")#mi("v_1,\\ldots,v_k \\in {\\Bbb Z}^d")#text(", and let ")#mi("A \\subset {\\Bbb Z}^d")#text(" be a set of positive upper Banach density (which means that ")#tao-math("\\limsup_{N \\to \\infty} \\left|A \\cap B_N\\right|/\\left|B_N\\right| > 0", block: false)#text(", where ")#mi("B_N := \\{-N,\\ldots,N\\}^d")#text("). Then A contains a pattern of the form ")#mi("n+rv_1,\\ldots,n+rv_k")#text(" for some ")#mi("n \\in {\\Bbb Z}^d")#text(" and ")#mi("r > 0")#text(".")
]

#text("Note that Theorem 1 corresponds to the special case when ")#mi("d=1")#text(" and ")#mi("v_i = i-1")#text(".")

#text("This theorem was first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=531279")[#text("by Furstenberg and Katznelson")]#text(", who deduced it via the correspondence principle from the following generalisation of Theorem 2:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(" (Recurrence for multiple commuting shifts) Let ")#mi("k \\geq 1")#text(" be an integer, let ")#mi("(X, {\\mathcal X}, \\mu)")#text(" be a probability space, let ")#mi("T_1,\\ldots,T_k: X \\to X")#text(" be measure-preserving bimeasurable maps which commute with each other, and let E be a set of positive measure. Then there exists ")#mi("r > 0")#text(" such that ")#mi("T_1^r E \\cap T_2^r E \\cap \\ldots \\cap T_k^{ r} E")#text(" is non-empty.")
]

#strong[#text("Exercise 5. ")]#text("Show that Theorem 4 and Theorem 5 are equivalent. ")#mi("\\diamond")

#strong[#text("Exercise 6. ")]#text("State an analogue of Theorem 3 for multiple commuting shifts, and prove that it is equivalent to Theorem 5. ")#mi("\\diamond")

#text("There is also a polynomial version of these theorems (cf. Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text("), which we will also state in general dimension:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(" (Multidimensional polynomial Szemerédi theorem) Let ")#mi("d \\geq 1")#text(", let ")#mi("P_1, \\ldots, P_k: {\\Bbb Z} \\to {\\Bbb Z}^d")#text(" be polynomials with ")#mi("P_1(0)=\\ldots=P_k(0)=0")#text(", and let ")#mi("A \\subset {\\Bbb Z}^d")#text(" be a set of positive upper Banach density. Then A contains a pattern of the form ")#mi("n+P_1(r),\\ldots,n+P_k(r)")#text(" for some ")#mi("n \\in {\\Bbb Z}^d")#text(" and ")#mi("r > 0")#text(".")
]

#text("This theorem was established ")#link("http://www.ams.org/mathscinet-getitem?mr=1325795")[#text("by Bergelson and Leibman")]#text(", who deduced it from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7")]#text(" (Polynomial recurrence for multiple commuting shifts) Let k, ")#mi("(X, {\\mathcal X}, \\mu)")#text(", ")#mi("T_1,\\ldots,T_k: X \\to X")#text(", E be as in Theorem 5, and let ")#mi("P_1,\\ldots,P_k")#text(" be as in Theorem 6. Then there exists ")#mi("r > 0")#text(" such that ")#mi("T^{-P_1(r)} E \\cap T^{-P_2(r)} E \\cap \\ldots \\cap T^{-P_k(r)} E")#text(" is non-empty, where we adopt the convention ")#mi("T^{(a_1,\\ldots,a_k)} := T_1^{a_1} \\ldots T_k^{a_k}")#text(" (thus we are making the action of ")#mi("{\\Bbb Z}^d")#text(" on X explicit).")
]

#strong[#text("Exercise 7.")]#text(" Show that Theorem 6 and Theorem 7 are equivalent. ")#mi("\\diamond")

#strong[#text("Exercise 8. ")]#text("State an analogue of Theorem 3 for polynomial recurrence for multiple commuting shifts, and prove that it is equivalent to Theorem 7. (Hint: first establish this in the case that each of the ")#mi("P_j")#text(" are monomials, in which case there is enough dilation symmetry to use the Varnavides averaging trick. Interestingly, if one only restricts attention to one-dimensional systems k=1, it does not seem possible to deduce the uniform polynomial recurrence theorem from the non-uniform polynomial recurrence theorem, thus indicating that the averaging trick is less universal in its applicability than the correspondence principle.) ")#mi("\\diamond")

#text("In the above theorems, the underlying action was given by either the integer group ")#mi("{\\Bbb Z}")#text(" or the lattice group ")#mi("{\\Bbb Z}^d")#text(". It is not too difficult to generalise these results to the semigroups ")#mi("{\\Bbb N}")#text(" and ")#mi("{\\Bbb N}^d")#text(" (thus dropping the assumption that the shift maps are invertible), by using a trick similar to that used in Exercise 9 of ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text(", or by using the correspondence principle back and forth a few times. A bit more surprisingly, it is possible to extend these results to even weaker objects than semigroups. To describe this we need some more notation.")

#text("Define a ")#emph[#text("partial semigroup")]#text(" ")#mi("(G, \\cdot)")#text(" to be a set G together with a partially defined multiplication operation ")#mi("\\cdot: \\Omega \\to G")#text(" for some subset ")#mi("\\Omega \\subset G \\times G")#text(", which is associative in the sense that whenever ")#mi("(a \\cdot b) \\cdot c")#text(" is defined, then ")#mi("a \\cdot (b \\cdot c)")#text(" is defined and equal to ")#mi("(a \\cdot b) \\cdot c")#text(", and vice versa. A good example of a partial semigroup is the finite subsets ")#tao-math("\\binom{S}{<\\omega} := \\{ A \\subset S: \\left|A\\right| < \\infty \\}", block: false)#text(" of a fixed set S, where the multiplication operation ")#mi("A \\cdot B")#text(" is disjoint union, or more precisely ")#mi("A \\cdot B := A \\cup B")#text(" when A and B are disjoint, and ")#mi("A \\cdot B")#text(" is undefined otherwise.")

#strong[#text("Remark 2.")]#text(" One can extend a partial semigroup to be a genuine semigroup by adjoining a new element ")#mi("\\text{err}")#text(" to G, and redefining multiplication ")#mi("a \\cdot b")#text(" to equal ")#mi("\\text{err}")#text(" if it was previously undefined (or if one of a or b was already equal to ")#mi("\\text{err}")#text("). However, we will avoid using this trick here, as it tends to complicate the notation a little. ")#mi("\\diamond")

#text("One can take Cartesian products of partial semigroups in the obvious manner to obtain more partial semigroups. In particular, we have the partial semigroup ")#mi("\\binom{{\\Bbb N}}{<\\omega}^d")#text(" for any ")#mi("d \\geq 1")#text(", defined as the collection of d-tuples ")#mi("(A_1,\\ldots,A_d)")#text(" of finite sets of natural numbers (not necessarily disjoint), with the partial semigroup law ")#mi("(A_1,\\ldots,A_d) \\cdot (B_1,\\ldots,B_d) := (A_1 \\cup B_1, \\ldots,A_d \\cup B_d)")#text(" whenever ")#mi("A_i")#text(" and ")#mi("B_i")#text(" are disjoint for each ")#mi("1 \\leq i \\leq d")#text(".")

#text("If ")#mi("(X, {\\mathcal X},\\mu)")#text(" is a probability space and ")#mi("(G,\\cdot)")#text(" is a partial semigroup, we define a ")#emph[#text("measure-preserving action")]#text(" of G on X to be an assignment of a measure-preserving transformation ")#mi("T^g: X \\to X")#text(" (not necessarily invertible) to each ")#mi("g \\in G")#text(", such that ")#mi("T^{g \\cdot h} = T^g T^h")#text(" whenever ")#mi("g \\cdot h")#text(" is defined.")

#text("An action T of ")#mi("\\binom{\\Bbb N}{<\\omega}")#text(" on X is known as an ")#emph[#text("IP system")]#text(" on X; it is generated by a countable number ")#mi("T_1, T_2, \\ldots")#text(" of commuting measure-preserving transformations, with ")#mi("T^A := \\prod_{i \\in A} T^i")#text(". (Admittedly, it is possible that the action of the empty set is not necessarily the identity, but this turns out to have a negligible impact on matters.) An action T of ")#mi("\\binom{\\Bbb N}{<\\omega}^d")#text(" is then a collection of d simultaneously commuting IP systems.")

#link("http://www.ams.org/mathscinet-getitem?mr=833409")[#text("Furstenberg and Katznelson")]#text(" showed the following generalisation of Theorem 5:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8")]#text(" (IP multiple recurrence theorem) Let T be an action of ")#mi("\\binom{\\Bbb N}{<\\omega}^d")#text(" on a probability space ")#mi("(X, {\\mathcal X},\\mu)")#text(". Then there exists a non-empty set ")#mi("A \\in \\binom{\\Bbb N}{<\\omega}")#text(" such that ")#mi("E \\cap (T^{A_1})^{-1}(E) \\cap \\ldots \\cap (T^{A_d})^{-1}(E)")#text(" is non-empty, where ")#mi("A_i := (\\emptyset, \\ldots, \\emptyset, A, \\emptyset, \\ldots, \\emptyset)")#text(" is the group element which equals A in the ")#mi("i^{th}")#text(" position and is the empty set otherwise.")
]

#text("It has a number of combinatorial consequences, such as the following strengthening of Szemerédi’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9.")]#text(" (IP Szemerédi theorem) Let A be a set of integers of positive upper density, let ")#mi("k \\geq 1")#text(", and let ")#mi("B \\subset {\\Bbb N}")#text(" be infinite. Then A contains an arithmetic progression ")#mi("n, n+r, \\ldots, n+(k-1)r")#text(" of length k in which r lies in FS(B), the set of finite sums of B (cf. Hindman’s theorem from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text(").")
]

#text("(There is also a multidimensional version of this theorem, but it requires a fair amount of notation to state properly.)")

#strong[#text("Exercise 9. ")]#text("Deduce Theorem 9 from Theorem 8. ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" Using Theorem 9, show that for any k, and any set of integers A of positive upper density, the set of steps r which occur in the arithmetic progressions in A of length k is ")#link("http://en.wikipedia.org/wiki/Syndetic_set")[#text("syndetic")]#text(". ")#mi("\\diamond")

#strong[#text("Exercise 11.")]#text(" Using Theorem 8, show that if ")#mi("{\\Bbb F}")#text(" is a finite field, and ")#mi("{\\Bbb F}^{<\\omega} := \\bigcup_{n=0}^\\infty {\\Bbb F}^n")#text(" is the canonical vector space over ")#mi("{\\Bbb F}")#text(" spanned (in the algebraic sense) by a countably infinite number of basis vectors, show that any subset A of ")#mi("{\\Bbb F}^{<\\omega}")#text(" of positive upper Banach density (which means that ")#tao-math("\\limsup_{n \\to \\infty} \\left|A \\cap {\\Bbb F}^n\\right|/\\left|{\\Bbb F}^n\\right| > 0", block: false)#text(" contains affine subspaces of arbitrarily high dimension. ")#mi("\\diamond")

#text("The IP recurrence theorem is already very powerful, but even stronger theorems are known. For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=1191743")[#text("Furstenberg and Katznelson established")]#text(" the following deep strengthening of the ")#link("http://en.wikipedia.org/wiki/Hales-Jewett_theorem")[#text("Hales-Jewett theorem")]#text(" (Theorem 8 from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text("), as well as of Exercise 11 above:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10")]#text(" (Density Hales-Jewett theorem) Let A be a finite alphabet. If E is a subset of ")#mi("A^{<\\omega}")#text(" of positive upper Banach density, then E contains a combinatorial line.")
]

#text("This theorem was deduced (via an advanced form of the correspondence principle) by a somewhat complicated recurrence theorem which we will not state here; rather than the action of a group, semigroup, or partial semigroup, one instead works with an ensemble of sets (as in Exercise 3), and furthermore one regularises the system of the probability space and set ensemble (which can collectively be viewed as a random process) to be what Furstenberg and Katznelson call a ")#emph[#text("strongly stationary process")]#text(", which (very) roughly means that the statistics of this process look “the same” when restricted to any combinatorial subspace of a fixed dimension.")

#strong[#text("Remark 3.")]#text(" Similar correspondence principles can be established connecting property testing results for graphs and hypergraphs to the measure theory of exchangeable measures: see this paper of myself, and ")#link("https://terrytao.wordpress.com/2008/01/16/on-the-testability-and-repair-of-hereditary-hypergraph-properties/")[#text("of myself and Austin")]#text(", for details. There is also a correspondence principle connecting ergodic convergence theorems with a (rather complicated looking) finitary analogue; see the papers of ")#link("http://arxiv.org/abs/0706.1512")[#text("Avigad-Gerhardy-Towsner")]#text(" and ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("of myself")]#text(" on this subject. Finally, we have implicitly been using a similar correspondence principle between topological dynamics and colouring Ramsey theorems in our previous lectures (in particular ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(", ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text(", and ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text("). ")#mi("\\diamond")

#strong[#text("Remark 4")]#text(". The Furstenberg correspondence principle also comes tantalisingly close to deducing my theorem with Ben that the primes contain arbitrarily long arithmetic progressions from Szemerédi’s theorem. More precisely, they show that any subset A of a ")#emph[#text("genuinely ")]#text("random set of integers with logarithmic-type density B, with A having positive ")#emph[#text("relative ")]#text("upper density with respect to B, contains arbitrarily long arithmetic progressions; see ")#link("https://www.math.ucla.edu/~tao/preprints/Expository/limiting.pdf")[#text("this unpublished note of myself")]#text(". Unfortunately, the almost primes are not known to quite obey enough “correlation conditions” to behave sufficiently pseudorandomly that these arguments apply to the primes, though perhaps there is still a “softer” way to prove our theorem than the way we did it (there is for instance some recent work by Trevisan, Tulsiani, and Vadhan in this direction). ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (26)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-26014")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("[…] and the next few will be to give a proof of the Furstenberg recurrence theorem (Theorem 2 from the previous lecture). Along the way we will develop a structural theory for measure-preserving […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-26524")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("[…] can then immediately establish the k=3 case of Furstenberg’s theorem (Theorem 2 from Lecture 10) by combining the above result with the ergodic decomposition (Proposition 4 from Lecture 9). The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-26808")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2008")])]

#text("[…] those spaces X which are regular, though an inspection of the Furstenberg correspondence principle (Lecture 10) shows that this is in fact automatic for the purposes of such tasks as proving Szemerédi’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-26809")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2008")])]

#text("[…] those spaces X which are regular, though an inspection of the Furstenberg correspondence principle (Lecture 10) shows that this is in fact automatic for the purposes of such tasks as proving Szemerédi’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-30718")[#strong[#text("Szemeredi’s theorem « Abner’s Postgraduate Days")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")]

#text("[…] 254A, Lecture 10: The Furstenberg correspondence principle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-33698")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("dear Professor Tao:")

#text("I have several questions(or corrections).")

#text("1, In the proof of Lemma 1, I didn’t get how the Borel-Cantelli lemma are used. I only tried to prove it from definition of upper limit of sets.")

#text("2, In exercise 4, I think ")#mi("c^{\\prime}(k,\\delta) N^2")#text(" is too large for the lemma to be correct. Anyway, I can only do it with ")#mi("c^{\\prime}(k,\\delta) N")#text(".")

#text("3,In the proof of Theorem 3, the first sentences of two paragraphs after (2”), it should be “It remains to prove that (2”) holds” and “We still need to prove (2”) for”, not (2)")

#text("4,In both the statement of theorem 4 and theorem 6, A should be a set of positive upper Banach density, “positive” missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-33701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("Dear liuxiaochuan,")

#text("Thanks for the corrections! It’s true that Lemma 1 doesn’t directly use the Borel-Cantelli lemma, but the method of proof is similar (one analyses the sum of indicator functions of the sets involved).")

#text("For exercise 4, the trick is to take advantage of both the translation invariance and dilation invariance in the space of arithmetic progressions: using only one of these symmetries will only give the bound of ")#mi("c(k,\\delta) N")#text(", but you need both to get ")#mi("c^{\\prime}(k,\\delta) N^2")#text(". For this purpose it can be convenient to to embed ")#mi("\\{1,\\ldots,N\\}")#text(" into a slightly larger cyclic group, e.g. one of prime order, although this is not strictly necessary (e.g. Varnavides’ original argument did not do this).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-33705")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2008")])]

#text("Dear Professor Tao:")

#text("About 4, I think I finally get it. Thanks.")

#text("By the way, in theorem 6, A is a set of positive upper Banach density, “positive” still missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-41704")[#strong[#text("Ergodic Ramsey Theory (by Yuri Lima) « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")]

#text("[…] 3. Furstenberg’s Correspondence Principle. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-42804")[#strong[#text("ERT4: Multiple Ergodic Averages « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")]

#text("[…] we’ll see in forecoming posts, this actually proves Szemerédi’s Theorem, via a correspondence principle between sets of integers of positive density and measure-preserving systems. One year after, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-44019")[#strong[#text("Theorem 22: Szemeredi’s theorem « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2010")]

#text("[…] to have nothing to do with a combinatorial problem). In particular, he developed the Furstenberg correspondence principle, and this and related ideas have led to many proofs of other results, including some that seemed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory: Lecture ten « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-45106")[#strong[#text("Solutions to Ergodic Theory: Lecture ten « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2010")])]

#text("[…] Note: Professor Terence Tao Began posting his lecture notes about the course “ergodic theory” early in 2008. I try doing all the exercises. This is the eleven exercises in lecture two. Here is the the page of this course，and here is the page of this lecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1e58625db1953eee19c28de26f4a69a7dd562d02ceee0f8561ae9ddcd150dd60-57da48480f6f130d3dc480a1825db6c69366f40f876ac44af00168b231707a8b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yiannis")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-46201")[#strong[#text("Yiannis")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2010")])]

#text("hi — small typo (?) in the statement of Lemma 1: do you want $x\\in E$ instead of $x\\in X$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-49772")[#strong[#text("The Peter-Weyl theorem, and non-abelian Fourier analysis on compact groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2011")])]

#text("[…] I’ve recently become interested in the theory around Hilbert’s fifth problem, due to the existence of a correspondence principle between locally compact groups and approximate groups, which play a fundamental role in arithmetic combinatorics. I hope to elaborate upon this correspondence in a subsequent post, but I will mention that versions of this principle play a crucial role in Gromov’s proof of his theorem on groups of polynomial growth (discussed previously on this blog), and in a more recent paper of Hrushovski on approximate groups (also discussed previously). It is also analogous in many ways to the more well-known Furstenberg correspondence principle between ergodic theory and combinatorics (also discussed previously). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-53437")[#strong[#text("The Furstenberg multiple recurrence theorem and finite extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2011")])]

#text("[…] As is well known, the Furstenberg multiple recurrence theorem is equivalent to Szemerédi’s theorem, thanks to the Furstenberg correspondence principle; see for instance these lecture notes of mine. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-110224")[#strong[#text("P (@mathe_magician)")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2011")]

#text("I just encountered this post and I was wondering how restrictive is your shift invariance assumption?If i’m correct, a measure preserving system is always shift invariant by your definition.")#linebreak()#text(" Does lemma 1 hold if the shift invariance assumption is dropped?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-110233")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2011")])]

#text("Very little can be said if there is no shift-invariance (or something resembling shift-invariance) assumed. For instance, consider the circle shift ")#mi("X := {\\bf R}/{\\bf Z}")#text(", ")#mi("Tx := x + \\alpha")#text(" for some real ")#mi("\\alpha")#text(", let ")#mi("\\mu")#text(" be the (highly non-invariant) Dirac mass at 0, and let ")#mi("E = \\{0\\}")#text(". Then Lemma 1 completely fails. (Of course, this is not anywhere close to a measure-preserving system.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An informal version of the Furstenberg correspondence principle | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-221340")[#strong[#text("An informal version of the Furstenberg correspondence principle | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2013")])]

#text("[…] to the string , and leads to the Furstenberg correspondence principle, discussed for instance in these previous blog posts. Such principles allow one to rigorously pass back and forth between the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-457533")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] to an averaging argument of Varnavides; see for instance Chapter 11 of my book with Van Vu or this previous blog post for a discussion. We have removed the cases as they are trivial and somewhat […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-478880")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] a function on the natural numbers taking values in , one can invoke the Furstenberg correspondence principle to locate a measure preserving system – a probability space together with a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-479816")[#strong[#text("254A, Lecture 15: The Furstenberg-Zimmer structure theorem and the Furstenberg recurrence theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("[…] are needed for other recurrence results involving IP systems or Hales-Jewett type results; see Lecture 10 for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel K. Goh")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-606639")[#strong[#text("Marcel K. Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2020")])]

#text("Hi Prof. Tao, I am wondering exactly how averaging (2”) over all ")#mi("1\\leq a\\leq N")#text(" gives (2). I tried interchanging the sums but I’m not sure how that removes the ")#mi("a")#text(" from the exponents of T. Is the ")#mi("c(k,\\delta)")#text(" in (2), (2′), and (2”) the same constant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-606767")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("The various ")#mi("c(k,\\delta)")#text(" are not the same (the bound obtained in (2) will be about ")#mi("N_0")#text(" times smaller than the one in (2”)). Actually one should average (2”) over those ")#mi("1 \\leq a \\leq N/N_0")#text("; the point being that every ")#mi("r = 1,\\dots,N")#text(" has at most ")#mi("N_0")#text(" representations of the form ")#mi("r = ar^{\\prime}")#text(" with ")#mi("1 \\leq a \\leq N/N_0")#text(" and ")#mi("1 \\leq r^{\\prime} \\leq N_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel K. Goh")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-606784")[#strong[#text("Marcel K. Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2020")])]

#text("Thanks, Prof. Tao! That cleared it up for me.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-682902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2024")])]

#text("Hi Prof. Tao.")#linebreak()#text(" It appears that the link for your unpublished note your refer to in Remark 4 is dead.")

#emph[#text("[Link updated – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb67f6012863715a0f02baa4e096ec3188bd15cde79a5c841b3f157252e5ceff-a51421a23636883eeee42b249e3cdf17d7e50c8609c01523670f2dea5419c305.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T Retsu")]], [#link("https://terrytao.wordpress.com/2008/02/10/254a-lecture-10-the-furstenberg-correspondence-principle/#comment-682904")[#strong[#text("T Retsu")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2024")])]

#text("He has converted the note to pdf:")

#raw("https://www.math.ucla.edu/~tao/preprints/Expository/limiting.pdf")
]
]
