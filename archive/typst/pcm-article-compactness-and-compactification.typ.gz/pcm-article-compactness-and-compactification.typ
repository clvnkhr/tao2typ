// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/
// Converted to Typst by tao2typ: "2026-10-14T15:16:32.448124+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Compactness and compactification", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Compactness and compactification")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/")[#text("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" with my ")#link("http://www.math.ucla.edu/~tao/preprints/compactness.pdf")[#text("article on compactness and compactification")]#text(". This is a fairly recent article for the PCM, which is now at the stage in which most of the specialised articles have been written, and now it is the general articles on topics such as compactness which are being finished up. The topic of this article is self-explanatory; it is a brief and non-technical introduction as to the incredibly useful concept of ")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("compactness")]#text(" in topology, analysis, geometry, and other areas mathematics, and the closely related concept of a ")#link("http://en.wikipedia.org/wiki/Compactification_%28mathematics%29")[#text("compactification")]#text(", which allows one to rigorously take limits of what would otherwise be divergent sequences.")

#text("The PCM has an extremely broad scope, covering not just mathematics itself, but the context that mathematics is placed in. To illustrate this, I will mention ")#link("http://www.institut.math.jussieu.fr/~harris/")[#text("Michael Harris")]#text("‘s essay for the Companion, “")#link("http://www.institut.math.jussieu.fr/%7Eharris/PCM.pdf")[#text("“Why mathematics?”, you may ask")]#text("“.")

#heading(level: 1)[#text("Comments (23)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-15923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("Small typo: in the second line “each the” should be “each of the” .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a35417a517516b6e7a4709c07c50474622b4baa87edc2e1d133d4516c8fbd21-aa61c43606c14d14543429dd0eeb8ba22e374c142fc42b2bdc8a9d5fbddb8e54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonio")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-15925")[#strong[#text("Antonio")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("Looks like a great article, as usual.")

#text("Small error: p. 3, 6th line of paragraph 3: “any compact space has a number of compactifications”. A compact space is already compact. :) Not sure what’s a nice pedagogical way of saying which spaces admit compactifications, without bringing in local compactness so soon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-15933")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2007")])]

#text("Thanks for emphasizing the very powerful ultrafilter construction of the Stone-Cech compactification. Correct me if I’m wrong, but I believe that this particular compactification was originally conceived using an approach other than ultrafilters. If so, whose idea was it to use ultrafilters? The earliest use of ultrafilters in this context that I’m aware of was by Robert Ellis in Lectures on Topological Dynamics (1969). (There the focus was on compactifications of discrete groups.) I’ve asked a now retired topologist — someone who has been around for a long time — and they did not know.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-15961")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2007")])]

#text("Here’s a typo on the last page line -9 : “in a certain compactifications…”; I’m not sure if the ‘a’ or the ‘s’ at the end of compactification should go…")#linebreak()#text(" Also I find interesting that you describe distribution spaces as compactifications; wouldn’t it be more natural to speak of completions here? (Of course there’s a lot of relations between the two concepts).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-15997")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2007")])]

#text("Is then the physical Lorentz weak L^2 also a compactification")#linebreak()#text(" (it predicts vortices in phenomena nonlocal in time)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7deef4c1e798cb8b1d94a042f2fc38af082574d10c3cf765a78c73bbc6f3dd1d-865fa1504c9c6b25d6f3db66e5fcd5466692e85b5f59c73065061e021605183c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fremlin")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-41401")[#strong[#text("David Fremlin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2009")])]

#text("Since he was writing primarily for mathematicians he could well have omitted most of the references to bad philosophy, which we can easily find for ourselves. But the actual content of his article, if you take the trouble to dig for it, is worth considering. In particular, he is on strong ground in maintaining that the concept of “set” (as used by mathematicians) is more fruitful than the concept of “essence” (as used by philosophers).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d71a6d0601276710dd565ca27ebb7dec39d98a514988a1dc745dbb6a8a5ec7b0-683aa6ee001ccca895c1f778b6464788aa266245ca9242ca426e998b467580f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Le fantôme de Descartes.")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16121")[#strong[#text("Le fantôme de Descartes.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2007")])]

#text("Michael Harris’s unvolutarily hilarious article chock-full of references to post-modernists like Derrida, Foucault and Lyotard looks like a cross between Sokal’s hoax and an article written by the mischievous random generator of social science texts:")#linebreak()#text(" ")#link("http://www.elsewhere.org/pomo/")[#text("http://www.elsewhere.org/pomo/")]

#text("Here is a sample of Harris’s prose:")#linebreak()#text(" “I would like to argue that the nothing")#linebreak()#text(" designated by “set” is somehow different, and more fruitful, than the nothing designated by “essence.” ”")

#text("As we say in France: le ridicule ne tue pas , which explains Harris’s survival.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2007")])]

#text("Thanks for all the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused student")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16209")[#strong[#text("Confused student")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2007")])]

#text("Dear Terence,")#linebreak()#text(" your Princeton article explaining compactness as extended finiteness is fantastically illuminating.")#linebreak()#text(" Although your birational correspondence between the x-axis and the circle with origin deleted is completely correct, I don’t see how (i.e. from what point on the circle) it is a stereographic projection. Sorry to waste your time with such trivialities.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8266701e032ace9dc4310277b0ebeb7a9e11f13ac2c40d3d04e7c20b1ad2ff3-4e71f90e0551e51505764ccaed4ed00daf95b1a268b543bb7960a38f5390263c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoit Jubin")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16323")[#strong[#text("Benoit Jubin")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2007")])]

#text("Confused student: the formula for the stereographic projection should be ")#mi("(\\frac{x}{1+x^2}, \\frac{x^2}{1+x^2})")#text(", and the projection is then from the north pole (0,1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused student")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16503")[#strong[#text("Confused student")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("Benoit: what you say is indeed correct, but then the north pole should be removed from the circle, not the origin.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-16506")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("Dear confused student and Benoit:")

#text("Sorry for the confusion (I had shifted the real line up by one unit in order to take the projection at the origin). I’ve implemented Benoit’s fix (and replaced the origin with (0,1)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4fcb1794c2fcbd52d1d2529d98df3ae2a3c4f7ad0301927517be289e2b04398-a248d0101e0dac1d765ab15b45ee6160ca79d23c4d2632015084dd822e6b135f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Harris")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-24257")[#strong[#text("Michael Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("The comment of the colleague hiding beneath the modest pseudonym")#linebreak()#text(" “Le fantôme de Descartes” seemed to have no ambition other than to")#linebreak()#text(" be offensive, but it does suggest it might be useful to clarify the purposes")#linebreak()#text(" of my PCM article, in order to avoid misunderstandings. This has been")#linebreak()#text(" done here:")

#link("http://www.institut.math.jussieu.fr/~harris/onPCM.htm")[#text("http://www.institut.math.jussieu.fr/~harris/onPCM.htm")]

#text("The point of the quotation chosen to illustrate my style should be")#linebreak()#text(" reasonably clear in the context of my article, but I spell it out")#linebreak()#text(" in the above link.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b80ed17b0a9ca583b1105e476b6af80dd8f244fcc9a23ade804810bf73d37f0b-01a28f9cc6b908126320c63a0dcd0e26b95be19c987a15b8c7f6a7991f3abce6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Corfield")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-32787")[#strong[#text("David Corfield")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2008")])]

#text("Regarding Le fantôme de Descartes’s comment, a remark Michael Harris’ makes on my work in this piece (or at least the draft I saw) is one of the most perceptive I have ever received. And the tasks with which he charges philosophers, are precisely correct:")

#text("‘They also have a duty, it seems to me, to account for terms like “idea” and “intution” – and “conceptual” for that matter – used by human mathematicians (at least) to express their value judgments.’")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness and the profile decomposition « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-33407")[#strong[#text("Concentration compactness and the profile decomposition « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2008")])]

#text("[…] important topological concepts in analysis is that of compactness (as discussed for instance in my Companion article on this topic). There are various flavours of this concept, but let us focus on sequential compactness: a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f46355445e7f9735ecc9e92b43fa52dfb3742ea27ef04cf06f3ab636dd79948-5437b5c3afa2e4f083c9f7e713bde462f38622e4262ea2c3fc50b851c227aac0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-33628")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("A belated answer to Richard (20 nov, 2007): the use of ultrafilters in the construction of compactifications dates back to Wallman’s work but was made explicit in Gilman and Jerison’s ")#emph[#text("Rings of continuous functions")]#text(": the Cech-Stone compactification is the space of zero-set ultrafilters. See ")#link("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/d17-betaX.pdf.pdf")[#text("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/d17-betaX.pdf.pdf")]#text(" and ")#link("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/d18-betaN-and-betaR.pdf")[#text("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/d18-betaN-and-betaR.pdf")]#text(" for more information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-33636")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2008")])]

#text("K. P. Hart,")

#text("Thanks much for the information! It’s a shame when the origin of ideas gets lost over time, so I’m very happy to hear this. The name Wallman rings a bell, and I now have a vague recollection of something that may have been called a “Wallman compactification”, so I’m going to look into that. Ages ago, when in graduate school, a professor recommended that I read Rings of Continuous Functions. Maybe it’s time that I finally follow up on that recommendation!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f46355445e7f9735ecc9e92b43fa52dfb3742ea27ef04cf06f3ab636dd79948-5437b5c3afa2e4f083c9f7e713bde462f38622e4262ea2c3fc50b851c227aac0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-33646")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2008")])]

#text("Richard: you’re most welcome.")#linebreak()#text(" For those who got redirected to room 404: here is the correct link to the article on ")#link("http://dutiaw37.twi.tudelft.nl/~kp/publications/the_papers/ency/d17-betaX.pdf")[#text("betaX")]#text(". It’s from the ")#link("http://www.elsevier.com/inca/publications/store/6/7/2/8/5/9/index.htt")[#text(" Encyclopedia of General Topology")]#text(", which also contains an article on Wallman compactifications.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-47946")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("Dear Prof. Tao")

#text("I have read this helpful article. In the last paragragh you mentioned a idea that one can view a straight line in the plane as the limit of increasingly large circles. I don’t understand why. Can you give me some hints for that? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-47949")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("Intuitively, one can see the convergence by placing, for each large radius R, a circle of that radius in the plane centred at (0,R). This circle (which is given by the equation ")#mi("y = \\frac{x^2+y^2}{2R}")#text(") will converge to the x-axis ")#mi("y=0")#text(" in the limit as R tends to infinity.")

#text("A formalisation of this convergence is given by the notion of ")#link("http://en.wikipedia.org/wiki/Gromov%E2%80%93Hausdorff_convergence")[#text("Gromov-Hausdorff convergence")]#text(" (and several other related notions of convergence would apply here too).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-47960")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" Thanks for the reply. But I can not understand the example that ")#mi("\\frac{x^2+y^2}{2R}\\to 0")#text(" when ")#mi("R\\to +\\infty")#text(". I can imagine a process that a circle is being pressed vertically, its major axis is getting larger and the minor axis is getting smaller at the same time. Obviously, the limit of the process is a line. However, I don’t think the process is what you wanted to discribe. Can you give me some further explanation? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-47962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Here is a picture that depicts the process:")

#link("http://etc.usf.edu/clipart/42900/42929/circle-35_42929.htm")[#text("http://etc.usf.edu/clipart/42900/42929/circle-35_42929.htm")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/#comment-47982")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2010")])]

#text("Yes. I get it. A circle of infinite radius is just a line. It can be explained by curvature. The curvature of a circle is 1/R. When ")#mi("R\\to+\\infty")#text(", the curvature tends to 0 everywhere. That means a straight line. Thanks for taking me new knowledge.")
]
]
]
]
]
