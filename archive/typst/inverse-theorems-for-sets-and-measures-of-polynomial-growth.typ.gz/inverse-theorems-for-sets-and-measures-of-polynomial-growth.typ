// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/
// Converted to Typst by tao2typ: "2026-10-14T10:25:22.328832+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Inverse theorems for sets and measures of polynomial growth", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Inverse theorems for sets and measures of polynomial growth")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/")[#text("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1507.01276")[#text("Inverse theorems for sets and measures of polynomial growth")]#text("“. This paper was motivated by two related questions. The first question was to obtain a qualitatively precise description of the sets of polynomial growth that arise in ")#link("https://en.wikipedia.org/wiki/Gromov's_theorem_on_groups_of_polynomial_growth")[#text("Gromov’s theorem")]#text(", in much the same way that ")#link("https://en.wikipedia.org/wiki/Freiman%27s_theorem")[#text("Freiman’s theorem")]#text(" (and its generalisations) provide a qualitatively precise description of sets of small doubling. The other question was to obtain a non-abelian analogue of inverse Littlewood-Offord theory.")

#text("Let me discuss the former question first. Gromov’s theorem tells us that if a finite subset ")#mi("{A}")#text(" of a group ")#mi("{G}")#text(" exhibits polynomial growth in the sense that ")#tao-math("{\\left|A^n\\right|}", block: false)#text(" grows polynomially in ")#mi("{n}")#text(", then the group generated by ")#mi("{A}")#text(" is virtually nilpotent (the converse direction also true, and is relatively easy to establish). This theorem has been strengthened a number of times over the years. For instance, a few years ago, ")#link("https://terrytao.wordpress.com/2009/10/23/a-finitary-version-of-gromovs-polynomial-growth-theorem/")[#text("I proved with Shalom")]#text(" that the condition that ")#tao-math("{\\left|A^n\\right|}", block: false)#text(" grew polynomially in ")#mi("{n}")#text(" could be replaced by ")#tao-math("{\\left|A^n\\right| \\leq C n^d}", block: false)#text(" for a ")#emph[#text("single")]#text(" ")#mi("{n}")#text(", as long as ")#mi("{n}")#text(" was sufficiently large depending on ")#mi("{C,d}")#text(" (in fact we gave a fairly explicit quantitative bound on how large ")#mi("{n}")#text(" needed to be). A little more recently, ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("with Breuillard and Green")]#text(", the condition ")#tao-math("{\\left|A^n\\right| \\leq C n^d}", block: false)#text(" was weakened to ")#tao-math("{\\left|A^n\\right| \\leq n^d \\left|A\\right|}", block: false)#text(", that is to say it sufficed to have polynomial ")#emph[#text("relative")]#text(" growth at a finite scale. In fact, the latter paper gave more information on ")#mi("{A}")#text(" in this case, roughly speaking it showed (at least in the case when ")#mi("{A}")#text(" was a symmetric neighbourhood of the identity) that ")#mi("{A^n}")#text(" was “commensurate” with a very structured object known as a ")#emph[#text("coset nilprogression")]#text(". This can then be used to establish further control on ")#mi("{A}")#text(". For instance, it was recently ")#link("http://arxiv.org/abs/1506.00886")[#text("shown by Breuillard and Tointon")]#text(" (again in the symmetric case) that if ")#tao-math("{\\left|A^n\\right| \\leq n^d \\left|A\\right|}", block: false)#text(" for a single ")#mi("{n}")#text(" that was sufficiently large depending on ")#mi("{d}")#text(", then all the ")#mi("{A^{n^{\\prime}}}")#text(" for ")#mi("{n^{\\prime} \\geq n}")#text(" have a doubling constant bounded by a bound ")#mi("{C_d}")#text(" depending only on ")#mi("{d}")#text(", thus ")#tao-math("{\\left|A^{2n^{\\prime}}\\right| \\leq C_d \\left|A^{n^{\\prime}}\\right|}", block: false)#text(" for all ")#mi("{n^{\\prime} \\geq n}")#text(".")

#text("In this paper we are able to refine this analysis a bit further; under the same hypotheses, we can show an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|A^{n^{\\prime}}\\right| = \\log \\left|A^n\\right| + f( \\log n^{\\prime} - \\log n ) + O_d(1)", block: true)]]

#text("for all ")#mi("{n^{\\prime} \\geq n}")#text(" and some piecewise linear, continuous, non-decreasing function ")#mi("{f: [0,+\\infty) \\rightarrow [0,+\\infty)}")#text(" with ")#mi("{f(0)=0}")#text(", where the error ")#mi("{O_d(1)}")#text(" is bounded by a constant depending only on ")#mi("{d}")#text(", and where ")#mi("{f}")#text(" has at most ")#mi("{O_d(1)}")#text(" pieces, each of which has a slope that is a natural number of size ")#mi("{O_d(1)}")#text(". To put it another way, the function ")#tao-math("{n^{\\prime} \\mapsto \\left|A^{n^{\\prime}}\\right|}", block: false)#text(" for ")#mi("{n^{\\prime} \\geq n}")#text(" behaves (up to multiplicative constants) like a piecewise polynomial function, where the degree of the function and number of pieces is bounded by a constant depending on ")#mi("{d}")#text(".")

#text("One could ask whether the function ")#mi("{f}")#text(" has any convexity or concavity properties. It turns out that it can exhibit either convex or concave behaviour (or a combination of both). For instance, if ")#mi("{A}")#text(" is contained in a large finite group, then ")#tao-math("{n \\mapsto \\left|A^n\\right|}", block: false)#text(" will eventually plateau to a constant, exhibiting concave behaviour. On the other hand, in nilpotent groups one can see convex behaviour; for instance, in the Heisenberg group ")#mi("{\\begin{pmatrix}{} {1} {\\mathbf Z} {\\mathbf Z} \\\\ {0} {1} {\\mathbf Z} \\\\ {0} {1} \\end{pmatrix}}")#text(", if one sets ")#mi("{A}")#text(" to be a set of matrices of the form ")#mi("{\\begin{pmatrix} 1 & O(N) & O(N^3) \\\\ 0 & 1 & O(N) \\\\ 0 & 0 & 1 \\end{pmatrix}}")#text(" for some large ")#mi("{N}")#text(" (abusing the ")#mi("{O()}")#text(" notation somewhat), then ")#mi("{n \\mapsto A^n}")#text(" grows cubically for ")#mi("{n \\leq N}")#text(" but then grows quartically for ")#mi("{n > N}")#text(".")

#text("To prove this proposition, it turns out (after using a somewhat difficult inverse theorem proven previously ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("by Breuillard, Green, and myself")]#text(") that one has to analyse the volume growth ")#tao-math("{n \\mapsto \\left|P^n\\right|}", block: false)#text(" of nilprogressions ")#mi("{P}")#text(". In the “infinitely proper” case where there are no unexpected relations between the generators of the nilprogression, one can lift everything to a simply connected Lie group (where one can take logarithms and exploit the Baker-Campbell-Hausdorff formula heavily), eventually describing ")#mi("{P^n}")#text(" with fair accuracy by a certain convex polytope with vertices depending polynomially on ")#mi("{n}")#text(", which implies that ")#tao-math("{\\left|P^n\\right|}", block: false)#text(" depends polynomially on ")#mi("{n}")#text(" up to constants. If one is not in the “infinitely proper” case, then at some point ")#mi("{n_0}")#text(" the nilprogression ")#mi("{P^{n_0}}")#text(" develops a “collision”, but then one can use this collision to show (after some work) that the dimension of the “Lie model” of ")#mi("{P^{n_0}}")#text(" has dropped by at least one from the dimension of ")#mi("{P}")#text(" (the notion of a Lie model being developed in the previously mentioned paper of Breuillard, Greenm, and myself), so that this sort of collision can only occur a bounded number of times, with essentially polynomial volume growth behaviour between these collisions.")

#text("The arguments also give a precise description of the location of a set ")#mi("{A}")#text(" for which ")#mi("{A^n}")#text(" grows polynomially in ")#mi("{n}")#text(". In the symmetric case, what ends up happening is that ")#mi("{A^n}")#text(" becomes commensurate to a “coset nilprogression” ")#mi("{HP}")#text(" of bounded rank and nilpotency class, whilst ")#mi("{A}")#text(" is “virtually” contained in a scaled down version ")#mi("{HP^{1/n}}")#text(" of that nilprogression. What “virtually” means is a little complicated; roughly speaking, it means that there is a set ")#mi("{X}")#text(" of bounded cardinality such that ")#mi("{aXHP^{1/n} \\approx XHP^{1/n}}")#text(" for all ")#mi("{a \\in A}")#text(". Conversely, if ")#mi("{A}")#text(" is virtually contained in ")#mi("{HP^{1/n}}")#text(", then ")#mi("{A^n}")#text(" is commensurate to ")#mi("{HP}")#text(" (and more generally, ")#mi("{A^{mn}}")#text(" is commensurate to ")#mi("{HP^m}")#text(" for any natural number ")#mi("{m}")#text("), giving quite a (qualitatively) precise description of ")#mi("{A}")#text(" in terms of coset nilprogressions.")

#text("The main tool used to prove these results is the structure theorem for approximate groups ")#link("https://terrytao.wordpress.com/2011/10/24/the-structure-of-approximate-groups/")[#text("established by Breuillard, Green, and myself")]#text(", which roughly speaking asserts that approximate groups are always commensurate with coset nilprogressions. A key additional trick is a ")#link("http://www.ams.org/mathscinet-getitem?mr=2727067")[#text("pigeonholing argument of Sanders")]#text(", which in this context is the assertion that if ")#mi("{A^n}")#text(" is comparable to ")#mi("{A^{2n}}")#text(", then there is an ")#mi("{n^{\\prime}}")#text(" between ")#mi("{n}")#text(" and ")#mi("{2n}")#text(" such that ")#mi("{A \\cdot A^{n^{\\prime}}}")#text(" is very close in size to ")#mi("{A^{n^{\\prime}}}")#text(" (up to a relative error of ")#mi("{1/n}")#text("). It is this fact, together with the comparability of ")#mi("{A^{n^{\\prime}}}")#text(" to a coset nilprogression ")#mi("{HP}")#text(", that allows us (after some combinatorial argument) to virtually place ")#mi("{A}")#text(" inside ")#mi("{HP^{1/n}}")#text(".")

#text("Similar arguments apply when discussing iterated convolutions ")#mi("{\\mu^{*n}}")#text(" of (symmetric) probability measures on a (discrete) group ")#mi("{G}")#text(", rather than combinatorial powers ")#mi("{A^n}")#text(" of a finite set. Here, the analogue of volume ")#mi("{A^n}")#text(" is given by the negative power ")#tao-math("{\\left\\| \\mu^{*n} \\right\\|_{\\ell^2}^{-2}}", block: false)#text(" of the ")#mi("{\\ell^2}")#text(" norm of ")#mi("{\\mu^{*n}}")#text(" (thought of as a non-negative function on ")#mi("{G}")#text(" of total mass 1). One can also work with other norms here than ")#mi("{\\ell^2}")#text(", but this norm has some minor technical conveniences (and other measures of the “spread” of ")#mi("{\\mu^{*n}}")#text(" end up being more or less equivalent for our purposes). There is an analogous structure theorem that asserts that if ")#mi("{\\mu^{*n}}")#text(" spreads at most polynomially in ")#mi("{n}")#text(", then ")#mi("{\\mu^{*n}}")#text(" is “commensurate” with the uniform probability distribution on a coset progression ")#mi("{HP}")#text(", and ")#mi("{\\mu}")#text(" itself is largely concentrated near ")#mi("{HP^{1/\\sqrt{n}}}")#text(". The factor of ")#mi("{\\sqrt{n}}")#text(" here is the familiar scaling factor in random walks that arises for instance in the central limit theorem. The proof of (the precise version of) this statement proceeds similarly to the combinatorial case, using pigeonholing to locate a scale ")#mi("{n^{\\prime}}")#text(" where ")#mi("{\\mu *\\mu^{n^{\\prime}}}")#text(" has almost the same ")#mi("{\\ell^2}")#text(" norm as ")#mi("{\\mu^{n^{\\prime}}}")#text(".")

#text("A special case of this theory occurs when ")#mi("{\\mu}")#text(" is the uniform probability measure on ")#mi("{n}")#text(" elements ")#mi("{v_1,\\dots,v_n}")#text(" of ")#mi("{G}")#text(" and their inverses. The probability measure ")#mi("{\\mu^{*n}}")#text(" is then the distribution of a random product ")#mi("{w_1 \\dots w_n}")#text(", where each ")#mi("{w_i}")#text(" is equal to one of ")#mi("{v_{j_i}}")#text(" or its inverse ")#mi("{v_{j_i}^{-1}}")#text(", selected at random with ")#mi("{j_i}")#text(" drawn uniformly from ")#mi("{\\{1,\\dots,n\\}}")#text(" with replacement. This is very close to the Littlewood-Offord situation of random products ")#mi("{u_1 \\dots u_n}")#text(" where each ")#mi("{u_i}")#text(" is equal to ")#mi("{v_i}")#text(" or ")#mi("{v_i^{-1}}")#text(" selected independently at random (thus ")#mi("{j_i}")#text(" is now fixed to equal ")#mi("{i}")#text(" rather than being randomly drawn from ")#mi("{\\{1,\\dots,n\\}}")#text(". In the case when ")#mi("{G}")#text(" is abelian, it turns out that a little bit of Fourier analysis shows that these two random walks have “comparable” distributions in a certain ")#mi("{\\ell^2}")#text(" sense. As a consequence, the results in this paper can be used to recover an essentially optimal abelian inverse Littlewood-Offord theorem ")#link("http://www.ams.org/mathscinet-getitem?mr=2775902")[#text("of Nguyen and Vu")]#text(". In the nonabelian case, the only Littlewood-Offord theorem I am aware of is a ")#link("http://arxiv.org/abs/1506.01958")[#text("recent result of Tiep and Vu")]#text(" for matrix groups, but in this case I do not know how to relate the above two random walks to each other, and so we can only obtain an analogue of the Tiep-Vu results for the symmetrised random walk ")#mi("{w_1 \\dots w_n}")#text(" instead of the ordered random walk ")#mi("{u_1 \\dots u_n}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/#comment-457051")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2015")])]

#text("In reference [11], should “103147” be “103–147”?")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/#comment-457070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2015")])]

#text("Dear Terry,I’m a math teacher.But now,I’m 80 years old.I’d like to express my thoughts.There are many good mathematicians in the world.They are beautiful flowers.But I don’t compare who is the best.I only say that Terry,you are the very special flower among them.Before,I stop breathing,I want to")#linebreak()#text(" see your greatest work.Whether I have enough luck to enjoy it.If this happens")#linebreak()#text(" soon,bag of gold is not meaningful to me")

#text("soon,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ee5cf8f7ef8d6c2b29ee85db8025a57a1d01b4a560091626f0e76cb19b8af3c-6f156c289c8eb9bd003ababc76579539105071ad2f6137c85edd0f6635633bda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haha")]], [#link("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/#comment-457072")[#strong[#text("haha")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2015")])]

#text("The 4th last line, it should be “but” instead of “btut”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2015/07/07/inverse-theorems-for-sets-and-measures-of-polynomial-growth/#comment-479886")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2017")])]

#text("I just noticed that Liouville’s theorem is an inverse theorem!")
]
