// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/
// Converted to Typst by tao2typ: "2026-10-14T07:22:50.399037+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Global regularity of wave maps VI.  Abstract theory of minimal-energy blowup solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Global regularity of wave maps VI.  Abstract theory of minimal-energy blowup solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/")[#text("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0906.2833")[#text("Global regularity of wave maps VI. Abstract theory of minimal-energy blowup solutions")]#text("“, to be submitted with the rest of the “heatwave” project to establish global regularity (and scattering) for energy-critical wave maps into hyperbolic space. Initially, this paper was intended to cap off the project by showing that if global regularity failed, then a special ")#emph[#text("minimal energy blowup solution")]#text(" must exist, which enjoys a certain ")#emph[#text("almost periodicity")]#text(" property modulo the symmetries of the equation. However, the argument was more technical than I anticipated, and so I am splitting the paper into a relatively short high-level paper (this one) that reduces the problem to four smaller propositions, and a much longer technical paper which establishes those propositions, by developing a substantial amount of perturbation theory for wave maps. I am pretty sure though that this process will not iterate any further, and paper VII will be my final paper in this series (and which I hope to finish by the end of this summer). It is also worth noting that a number of papers establishing similar results (though with slightly different hypotheses and conclusions) will shortly appear by Sterbenz-Tataru and Krieger-Schlag.")

#text("Almost periodic minimal energy blowup solutions have been constructed for a variety of critical equations, such as the nonlinear Schrodinger equation (NLS) and the nonlinear wave equation (NLW). The formal definition of almost periodicity is that the orbit of the solution ")#mi("u")#text(" stays in a precompact subset of the energy space once one quotients out by the non-compact symmetries of the equation (namely, translation and dilation). Another (more informal) way of saying this is that for every time ")#mi("t")#text(", there exists a position ")#mi("x(t)")#text(" and a frequency ")#mi("N(t)")#text(" such that the solution ")#mi("u(t)")#text(" is localised in space in the region ")#mi("\\{ x: x = x(t) + O(N(t)^{-1}) \\}")#text(" and in frequency in the region ")#tao-math("\\{ \\xi: \\left|\\xi\\right| \\sim N(t) \\}", block: false)#text(", with the solution decaying in energy away from these regions of space and frequency. Model examples of almost periodic solutions include traveling waves (in which N(t) is fixed, and x(t) moves at constant velocity) and self-similar solutions (in which x(t) is fixed, and N(t) blows up in finite time at some power law rate).")

#text("Intuitively, the reason almost periodic minimal energy blowup solutions ought to exist in the absence of global regularity is as follows. It is known (for any of the equations mentioned above) that global regularity (and scattering) holds at sufficiently small energies. Thus, if global regularity fails at high energies, there must exist a critical energy ")#mi("E_{crit}")#text(", below which solutions exist globally (and obey scattering bounds), and above which solutions can blow up.")

#text("Now consider a solution ")#mi("u")#text(" at the critical energy which blows up (actually, for technical reasons, we instead consider a sequence of solutions approaching this critical energy which come increasingly close to blowing up, but let’s ignore this for now). We claim that this solution must be localised in both space and frequency at every time, thus giving the desired almost periodic minimal energy blowup solution. Indeed, suppose ")#mi("u(t)")#text(" is not localised in frequency at some time t; then one can decompose ")#mi("u(t)")#text(" into a high frequency component ")#mi("u_{hi}(t)")#text(" and a low frequency component ")#mi("u_{lo}(t)")#text(", both of which have strictly smaller energy than ")#mi("E_{crit}")#text(", and which are widely separated from each other in frequency space. By hypothesis, each of ")#mi("u_{hi}")#text(" and ")#mi("u_{lo}")#text(" can then be extended to global solutions, which should remain widely separated in frequency (because the linear analogues of these equations are constant-coefficient and thus preserve frequency support). Assuming that interactions between very high and very low frequencies are negligible, this implies that the superposition ")#mi("u_{hi}+u_{lo}")#text(" approximately obeys the nonlinear equation; with a suitable perturbation theory, this implies that ")#mi("u_{hi}+u_{lo}")#text(" is close to ")#mi("u")#text(". But then ")#mi("u")#text(" is not blowing up, a contradiction. The situation with spatial localisation is similar, but is somewhat more complicated due to the fact that spatial support, in contrast to frequency support, is not preserved by the linear evolution, let alone the nonlinear evolution.")

#text("As mentioned before, this type of scheme has been successfully implemented on a number of equations such as NLS and NLW. However, there are two main obstacles in establishing it for wave maps. The first is that the wave maps equation is not a scalar equation: the unknown field takes values in a target manifold (specifically, in a hyperbolic space) rather than in a Euclidean space. As a consequence, it is not obvious how one would perform operations such as “decompose the solution into low frequency and high frequency components”, or the inverse operation “superimpose the low frequency and high frequency components to reconstitute the solution”. Another way of viewing the problem is that the various component fields of the solution have to obey a number of important compatibility conditions which can be disrupted by an overly simple-minded approach to decomposition or reconstitution of solutions.")

#text("The second problem is that the interaction between very high and very low frequencies for wave maps turns out to not be entirely negligible: the high frequencies do have a negligible impact on the evolution of the low frequencies, but the low frequencies can “rotate” the high frequencies by acting as a sort of magnetic field (or more precisely, a connection) for the evolution of those high frequencies. So the combined evolution of the high and low frequencies is not well approximated by a naive superposition of the separate evolutions of these frequency components.")

#metadata(none) <tao-2a9fbf1c79149c69f3fb>#text("There are a number of ways to resolve the first problem. One way, which has been pursued in a very recent paper by Sterbenz and Tataru (and also in an earlier paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2130618")[#text("of Tataru")]#text(", and ")#link("http://arxiv.org/abs/math/0010068")[#text("of myself")]#text(" in the case of spherical targets), is to embed the target manifold into Euclidean space and perform various operations (e.g. Littlewood-Paley projections) on the solution in that ambient space, thus creating new fields which lie outside the target. This does not work directly with the hyperbolic space target because this is not efficiently embeddable into Euclidean space (although it was recently pointed out to me by Jacob Sterbenz that one can proceed – at least for the narrow question of establishing global regularity rather than scattering – by passing from hyperbolic space to a compact quotient). Another approach, introduced by Krieger, is that of ")#emph[#text("dynamic separation")]#text(" – to isolate a “dynamic” scalar field which is unconstrained, controls all the other components of the evolution (as “static” functions of the dynamic field), and then manipulate the dynamic field directly. It is this latter approach which we will pursue in the sequel to this paper; the dynamic field we will use is the tension field ")#mi("\\psi_s")#text(" of the harmonic map heat flow.")

#text("For the second problem, we will use a variant of the “frequency truncation method” of Bourgain, constructing the solution iteratively, in a sequence of time intervals in which the low frequency solution is small in a certain spacetime norm sense. On each such time interval, the impact of the low frequencies on the high ones is small enough that one can basically ignore the low frequencies, and evolve the high frequencies using the hypothesis that solutions with energy less than ")#mi("E_{crit}")#text(" have global solutions. But then one has to appeal to the hypothesis again at every time interval, otherwise the cumulative effect of the low frequencies on the high frequencies will become uncontrollable. This is not a problem unless the energy of the high frequencies increases significantly after every time interval. But one can use the energy conservation of the low frequencies and of the entire solution to prevent this from occuring.")

#text("All of these things will be detailed in the sequel to the current paper. What the current paper does is to perform the abstract argument that constructs minimal-energy blowup solutions, assuming four black-box results which will be proven in the sequel:")

#enum(start: 1, 
[#text("A perturbation theory for wave maps which enjoys a certain ")#emph[#text("fungibility")]#text(" property, which is technical to state but roughly asserts that any large wave map on a long time interval can be subdivided into a controlled number of shorter time intervals in which the evolution behaves like the linear equation;")],
[#text("A means of synthesising solutions from frequency-delocalised data from solutions at strictly lower energies;")],
[#text("A means of synthesising solutions from spatially-dispersed data from solutions at strictly lower energies;")],
[#text("A means of synthesising solutions from spatially-delocalised data from solutions at strictly lower energies.")]
)

#text("(Here, “spatially dispersed” means, roughly, that the energy density does not accumulate at any point, while “spatially delocalised” means that there is a location where the energy density accumulates, but a significant amount of energy is also present at a large distance from this accumulation point. These two scenarios complement the scenario we actually want, which is spatial localisation – where the energy density accumulates at one point and decays away from that point.)")

#text("The abstract component of the argument is in fact quite similar to that used for the energy-critical NLS by Colliander, Keel, Staffilani, Takaoka, and myself. There are also some more concrete components to the argument in this paper, though, namely the use of the harmonic map heat flow as a kind of nonlinear Littlewood-Paley resolution in order to formally define frequency delocalisation and set up its basic properties, and also a Rellich-type compactness lemma which asserts that solutions which are localised in space and frequency are indeed almost precompact, and which is also proven using the harmonic map heat flow.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39557")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2009")])]

#text("Dear Prof. Tao,")

#text("I am planning to read your papers on wave maps but I would like to learn the necessary background to understand these papers.")

#text("Are graduate real analysis, sobolev spaces and distribution theory enough to understand them or do I need to know more technical stuffs like Littlewood-Paley theory, singular integrals, Calderon-Zymund theory?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39558")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2009")])]

#text("A certain amount of Littlewood-Paley theory and singular integral theory is definitely useful. My PDE book has most of the material needed (and not coincidentally, the final chapter of that book is devoted to wave maps).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student_1")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39570")[#strong[#text("student_1")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear Professor Tao,")

#text("This is not really a comment to the topic above but more of a general question and I hope that it is ok that I post it here. I noticed that a lot of world-class mathematicians used to compete in mathematics competitions when they were younger. Do you think it is necessary to practise and get really good at solving competition problems to become a good mathematician ? How many percent of the top mathematicians in the world have competed in these kind of competitions(a rough esitmate)? The reason for asking is that I am doing self-studies in mathematics at the moment while I am doing a masters degree in engineering, but I really would like to focus on pure mathematics after my masters degree.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear student_1,")

#text("Please see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/career-advice/advice-on-mathematics-competitions/")[#text("Advice on mathematics competitions")]
]

#text("for my thoughts on these sorts of issues.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb90daa64155d4ee3fd88c6cd3887d2f83efcc2280f947f7267f3faca7c81315-22ca1e22a004312ca65eeecb2ea872c9c1499c14ce0e9be54a95b9a65c2e50b9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dale B. Ritter, B.A.")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39711")[#strong[#text("Dale B. Ritter, B.A.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2009")])]

#text("Thanks for the timely discussion of the “heatwave” project. The wave equation for electromagnetic waves of infrared frequency implies a function for the topological wavemap on a defined space. The discrete photon’s localization with radial decay does have a solution, a consequence of the atomic waveparticle function named the GT integral.")#linebreak()#text(" That fits Terence Tao’s roadmap for a wavemap that behaves like a linear equation defining the spatial localization and radial dispersion of energy density. This is achieved by writing a particle function for space/time boundaries, with gravity the force binding space to the atom, a relative quantum topological function named the RQT psifunc. Since the differential equation for the nuclear emissions of force is constrained by the quantum and relative rules the electrons appear as overtones of the process of nuclear mass transform to forcons with valid joule values. That [e=m(c^2)] mechanism may be mapped with quantum symmetry numbers to project the 3D animated interactive video atomic model.")#linebreak()#text(" Next, your spatial map for energy particle topology will be resolved by use of the psi’s internal momentum function. When that is rearranged to give the photon gain rule and integrated for GT boundaries the result is a series of 26 functions which each define the energy for one of the 5/2 kT J internal heat capacity particles. That picoyoctometric achievement intersects the values of and yields topologies for: {h, h-bar, delta, nuclear magneton, beta magneton}. It defines a spectrum of five classes of energy particles crystallized from the diluted radial force fields: {positrons, workons, thermons, electromagnetons, magnemedons}.")#linebreak()#text(" Now the topologies of electromagnetic waves may be solved, since they originate in the spin of electromagnetons. Fortunately your interest in any particle’s locality is answered, since their symmetry quantum numbers are intrinsic to the GT integral and it’s symmetopol intermedon topofuncs. Data point maps for the h-bar, and the other energy waveparticles appear as images at ")#link("http://www.symmecon.com")[#text("http://www.symmecon.com")]#text(", along with discussions, essays, and calculations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39753")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2009")])]

#text("Dear Prof Tao,")

#text("is the solution of heat equation analytic for ")#mi("all \\ t>0,")#text(" whatever the initial data are?")

#text("one more thing, I could not find your papers on wave map number 1,2 on archieve. could you please put a link for them?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("My PDE papers (including wave maps I and II) can be found at")

#link("http://www.math.ucla.edu/~tao/preprints/pde.html")[#text("http://www.math.ucla.edu/~tao/preprints/pde.html")]

#text("The fundamental solution for the heat equation is (uniformly) analytic for ")#mi("t>0")#text(", so it is not hard to show the same is true for more general solutions to the heat equation, provided that the initial data is reasonable (e.g. absolutely integrable), and one imposes some mild growth condition at infinity on the solution (e.g. tempered distribution in space).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/17/global-regularity-of-wave-maps-vi-abstract-theory-of-minimal-energy-blowup-solutions/#comment-39768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2009")])]

#text("Dear Prof. Tao,")

#text("Excuse me, i am writing my question here because i could not find an appropriate place.")

#text("in Stein&Shakarchi complex analysis book, they say that a function is holomorphic at a point if it is differentiable there and they use the term ”holomorphic” and ”analytic” have the same meaning.")

#text("it is a little confusing for me because for example ")#tao-math("f(z)=\\left|z\\right|^2", block: false)#text(" is differentiable at ")#mi("z=0")#text(" but nowhere analytic.")

#text("do you think that there is a typo in the book?")

#text("thanks")
]
