// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:17:11.399971+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 April 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/")[#text("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0904.2880")[#text("An inverse theorem for the bilinear $L^2$ Strichartz estimate for the wave equation")]#text("“. This paper is another technical component of my “")#link("https://terrytao.wordpress.com/tag/project-heatwave/")[#text("heatwave project")]#text("“, which aims to establish the global regularity conjecture for energy-critical wave maps into hyperbolic space. I have been in the process of writing the final paper of that project, in which I will show that the only way singularities can form is if a special type of solution, known as an “almost periodic blowup solution”, exists. However, I recently discovered that the existing function space estimates that I was relying on for the large energy perturbation theory were not quite adequate, and in particular I needed a certain “inverse theorem” for a standard bilinear estimate which was not quite in the literature. The purpose of this paper is to establish that inverse theorem, which may also have some application to other nonlinear wave equations.")

#metadata(none) <tao-15566c2ccdc97cff956c>#text("To explain the inverse theorem, let me first discuss the bilinear estimate that it inverts. Define a ")#emph[#text("wave")]#text(" to be a solution to the free wave equation ")#mi("-\\phi_{tt} + \\Delta \\phi = 0")#text(". If the wave has a finite amount of energy, then one expects the wave to disperse as time goes to infinity; this is captured by the ")#emph[#text("Strichartz estimates")]#text(", which establish various spacetime ")#mi("L^p")#text(" bounds on such waves in terms of the energy (or related quantities, such as Sobolev norms of the initial data). These estimates are fundamental to the local and global theory of nonlinear wave equations, as they can be used to control the effect of the nonlinearity.")

#text("In some cases (especially in low dimensions and/or low regularities, and with equations whose nonlinear terms contain derivatives), Strichartz estimates are too weak to control nonlinearities; roughly speaking, this is because waves decay too slowly in low dimensions. (For instance, one-dimensional waves ")#mi("\\phi(t,x) = f(x+t)+g(x-t)")#text(" do not decay at all.) However, it has been understood for some time that if the nonlinearity has a special ")#emph[#text("null structure")]#text(", which roughly means that it consists only of interactions between transverse waves rather than parallel waves, then there is more decay that one can exploit. For instance, while one-dimensional waves do not decay in time, the product between a left-propagating wave ")#mi("f(x+t)")#text(" and a right-propagating wave ")#mi("g(x-t)")#text(" ")#emph[#text("does")]#text(" decay in time. In particular, if f and g are bounded in ")#mi("L^2({\\Bbb R})")#text(", then this product is bounded in spacetime ")#mi("L^2_{t,x}({\\Bbb R})")#text(", thanks to the Fubini-Tonelli theorem.")

#text("There is a similar “bilinear ")#mi("L^2")#text("” estimate for products of transverse waves in higher dimensions. This estimate is the basic building block for the ")#emph[#text("bilinear ")#mi("X^{s,b}")#text(" estimates")]#text(" and their variants as developed by Bourgain, Klainerman-Machedon, Kenig-Ponce-Vega, Tataru, and others, and which are the tool of choice for establishing local and global control on nonlinear wave equations, particularly at low dimensions and at critical regularities. In particular, these estimates (or more precisely, a complicated variant of these estimates in sophisticated function spaces, due to Tataru and myself), are used in the theory of the energy-critical wave map equation. [These bilinear (and trilinear) estimates are not, by themselves, enough to handle this equation; one also needs an additional gauge fixing procedure before the equation is sufficiently close to linear in behaviour that these estimates become effective. But I do not wish to discuss the (significant) gauge fixing issue here.]")

#text("To cut a (very) long story short, these estimates, when combined with a suitable perturbative theory, allow one to control energy-critical wave maps as long as the energy is small. However, the whole point of the “heatwave” project is to control the non-perturbative setting when the energy is large (but finite), and one wants to control the solution for long periods of time.")

#text("In my ")#link("https://terrytao.wordpress.com/2008/08/06/global-regularity-of-wave-maps-v-large-data-local-wellposedness-in-the-energy-class/")[#text("previous “heatwave” paper")]#text(", in which I established large data local well-posedness for this equation, I finessed this issue by localising time to very short intervals, which made certain spacetime norms small enough for the perturbation theory to apply. This sufficed for the ")#emph[#text("local")]#text(" well-posedness theory, but is not good enough for the ")#emph[#text("global ")]#text("perturbative theory, because the number of very short intervals needed to cover the entire time axis becomes unbounded. For that, one needs the ability to make certain norms or estimates “small” by only chopping up time into a ")#emph[#text("bounded")]#text(" number of intervals. I refer to this property as ")#emph[#text("divisibility")]#text(" (I used to refer to it, somewhat incorrectly, as ")#emph[#text("fungibility")]#text(").")

#text("In the case of ")#emph[#text("semilinear")]#text(" wave (or Schrödinger equations), in which Strichartz estimates are already sufficient to obtain a satisfactory perturbative theory, divisibility is well-understood, and boils down to the following simple observation: if a function ")#mi("\\phi: {\\Bbb R} \\times {\\Bbb R}^n \\to {\\Bbb C}")#text(" obeys a global spacetime integrability bound such as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\Bbb R} \\int_{\\Bbb R}^n \\left|\\phi(t,x)\\right|^p\\ dx dt \\leq M", block: true)]]

#text("for some finite exponent p and some finite bound M, then one can partition ")#mi("{\\Bbb R}")#text(" into intervals I on which")

#align(center)[#tao-fit-display[#tao-math("\\int_I \\int_{\\Bbb R}^n \\left|\\phi(t,x)\\right|^p\\ dx dt \\leq \\varepsilon", block: true)]]

#text("for some ")#mi("\\varepsilon > 0")#text(" at one’s disposal to select. Indeed the number of such intervals is bounded by ")#mi("M/\\varepsilon")#text(", and the intervals can be selected by a simple “greedy algorithm” argument. This divisibility property of ")#mi("L^p")#text("-type spacetime norms allows one to easily generalise the small-data perturbation theory to the large-data setting, and is relied upon heavily in the modern theory of the critical nonlinear wave and Schrödinger equations; see for instance ")#link("http://www.math.uchicago.edu/~mvisan/ClayLectureNotes.pdf")[#text("this survey of Killip and Visan")]#text(".")

#text("Unfortunately, the function spaces used in wave maps are not easily divisible in this manner (very roughly speaking, this is because the function space norms contain too many ")#mi("L^\\infty_t")#text(" type norms within them). So one cannot rely purely on refining the function space; one must also work on refining the bilinear (and trilinear) estimates on these spaces. The standard way to do this is to strengthen the ")#mi("L^p")#text(" exponents in these estimates, and for the basic bilinear ")#mi("L^2")#text(" estimate this has indeed been done (in work ")#link("http://www.ams.org/mathscinet-getitem?mr=1836285")[#text("of Wolff")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1865417")[#text("myself")]#text("). This suffices for “equal-frequency” interactions, in which one is multiplying two transverse waves of the same frequency, but turns out to be inadequate for “imbalanced-frequency” interactions, when one is multiplying a low-frequency wave by a high-frequency transverse wave. For this, I rely instead on establishing an ")#emph[#text("inverse theorem")]#text(" for the estimate.")

#text("Generally speaking, whenever one is faced with an estimate, e.g. a linear estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_Y \\leq C \\left\\|f\\right\\|_X,", block: true)]]

#text("one can pose the ")#emph[#text("inverse problem")]#text(" of trying to classify the functions f for which the estimate is tight in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_Y \\geq \\delta \\left\\|f\\right\\|_X", block: true)]]

#text("for some ")#mi("\\delta > 0")#text(" which is not too small. Such inverse theorems are a current area of study in additive combinatorics, and have recently begun making an appearance in PDE as well. For instance:")

#list(
[#text("Young’s inequality ")#tao-math("\\left\\|f*g\\right\\|_{L^r} \\leq \\left\\|f\\right\\|_{L^p} \\left\\|g\\right\\|_{L^r}", block: false)#text(" or the Hausdorff-Young inequality ")#tao-math("\\left\\|\\hat f\\right\\|_{L^{p^{\\prime}}} \\leq \\left\\|f\\right\\|_{L^p}", block: false)#text(", is only tight (for non-endpoint p,q,r) when f, g are concentrated on balls, arithmetic progressions, or Bohr sets (this is a consequence of several basic theorems in additive combinatorics, including Freiman’s theorem and the Balog-Szemeredi-Gowers theorem);")],
[#text("The trivial inequality ")#tao-math("\\left\\|f\\right\\|_{U^k} \\leq \\left\\|f\\right\\|_{L^\\infty}", block: false)#text(" for the Gowers uniformity norms is only expected to be tight when f correlates with a highly algebraic object, such as a polynomial phase or nilsequence (this is the inverse conjecture for the Gowers norm, which is partially proven so far);")],
[#text("The Sobolev embedding ")#tao-math("\\left\\| f \\right\\|_{L^q} \\leq C \\left\\|f\\right\\|_{W^{s,r}}", block: false)#text(" is only tight when f is concentrated on a unit ball (for non-endpoint estimates) or a ball of arbitrary radius (for endpoint estimates);")],
[#text("Strichartz estimates are only tight when f is concentrated on a ball (for non-endpoint estimates) or a tube (for endpoint estimates).")]
)

#text("Inverse theorems for such estimates as Sobolev inequalities and Strichartz estimates are also closely related to the theory of concentration compactness and profile decompositions; see this ")#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")[#text("previous blog post of mine")]#text(" for a discussion.")

#text("I can now state informally, the main result of this paper:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" (informal statement). A bilinear ")#mi("L^2")#text(" estimate between two waves of different frequency is only tight when the waves are concentrated on a small number of light rays. Outside of these rays, the ")#mi("L^2")#text(" norm is small.")
]

#text("This leads to a corollary which will be used in my final heatwave paper:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" (informal statement). Any large-energy wave ")#mi("\\phi")#text(" can have its time axis subdivided into a bounded number of intervals, such that on each interval the bilinear estimates for that wave (when interacted against any high-frequency transverse wave) behave “as if” ")#mi("\\phi")#text(" was small-energy rather than large energy.")
]

#text("The method of proof relies on a ")#link("http://www.ams.org/mathscinet-getitem?mr=1865417")[#text("paper of mine ")]#text("from several years ago on bilinear ")#mi("L^p")#text(" estimates for the wave equation, which in turn is based on a celebrated ")#link("http://www.ams.org/mathscinet-getitem?mr=1836285")[#text("paper of Wolff")]#text(". Roughly speaking, the idea is to use wave packet decompositions and the combinatorics of light rays to isolate the regions of spacetime where the waves are concentrating, cover these regions by tubular neighbourhoods of light rays, then remove the light rays to reduce the energy (or mass) of the solution and iterate. The wave packet analysis is moderately complicated, but fortunately I can use a proposition on this topic from my paper as a black box, leaving only the other components of the argument to write out in detail.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben green")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38320")[#strong[#text("ben green")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Terry, one small comment: the inverse theorem for the Hausdorff-Young inequality is not just Freiman’s theorem, it is Freiman plus the Balog-Szemeredi-Gowers theorem. And in fact it is slightly more than that, as both of those additive-combinatorial theorems apply to sets and not to arbitrary functions. I don’t believe it is particularly hard to deal with arbitrary functions by foliating into approximate (dyadic) level sets, but I do not actually know of a place in the literature where this is done explicitly. A paper of Bourgain (Multilinear exponential sums in prime fields under optimal entropy condition on the")#linebreak()#text(" sources) does something very much in this spirit in the course of one of the arguments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Dear Ben, You’re right, of course; I’ve adjusted the text accordingly.")

#text("One way to pass from functions back to sets is to use the Marcinkiewicz interpolation theorem, which ties strong L^p estimates to restricted weak-type L^p estimates, which roughly speaking are the specialisation of the strong L^p etimates to the case of indicator functions. If an estimate is tight for an interpolated L^p estimate then it must also be tight for the restricted weak-type variant, which basically means that the functions that were tight for the original inequality must already behave like indicator functions to some extent.")

#text("On the other hand, for “endpoint” estimates that cannot be obtained from Marcinkiewicz interpolation, it is quite possible for functions that are tight for the estimate to not behave at all like indicator functions, instead being a superposition of such functions of widely different heights and widths. The inverse theory for endpoints is usually rather subtle (and in many cases, hopeless: for instance, there is no inverse theorem for the p=2 endpoint of Hausdorff-Young, since the inequality is an equality in that case (Plancherel’s theorem))!")

#text("The papers of Reingold, Tulsiani, Trevisan, Vadhan on the dense model theorem also have some nice ways to convert functions back into sets by averaging.")

#text("Incidentally, there is a stub of a Tricki article on this point at")

#link("http://www.tricki.org/article/Control_level_sets")[#text("http://www.tricki.org/article/Control_level_sets")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuanglin Shao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38322")[#strong[#text("Shuanglin Shao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("An excellent post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38324")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Could you give a reference for the inverse theorem for the Sobolev embedding and Strichartz estimates?")

#text("thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Dear anonymous,")

#text("I’m not sure where the Sobolev inverse theorem first originates; it is implicit in the concentration-compactness work of Lions and others, but I don’t know of a specific reference there. For nonlinear wave equations, the earliest reference I know of is by Bahouri and Gerard in an 1999 AJM paper. It is also to some extent implicit in the large body of work in the ’80s on Besov and Triebel-Lizorkin spaces, connections to wavelets, etc.")

#text("For Strichartz, a paper of Begout and Vargas from 2007 (see also Shao’s recent paper at ")#link("http://arxiv.org/abs/0809.0153")[#text("http://arxiv.org/abs/0809.0153")]#text(" ) contains some explicit inverse theorems of this type, although arguably such theorems are already implicit to some extent in Bourgain’s 1991 paper on the restriction problem (and in many subsequent works also), generally going under such names as “improved Strichartz estimates”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38327")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("Thank you for the response. I guess my question is what do these inverse theorems really look like? Shao’s result appears to be that maximizers to the Strichartz and Soblev-Strichartz inequalities exist, at least in non-endpoint cases. In establishing the later he works out a profile decomposition for the Soblev-Strichartz norms. I see that maximizers to a Strichartz inequaity are functions of the form that are identified by the inverse theorem (more specifically, in the cases where the maximizers have been classified, they are in fact Gaussians, which is consistent with the inverse statement of being “localized to a ball”). However, the inverse theorem seems much stronger, that if a function isn’t localized to a ball, then its Strichartz norm should be very small compared to the L^2 norm of the initial data. From your reply, I’m guessing that the inverse theorem is somehow implied by profile decomposition / concentration compactness results, but this doesn’t seem to be clear. Sorry to be dense, and thanks again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-38328")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("An explicit example of an inverse Sobolev theorem can be found for instance in Lemma 3.1 of my paper")

#link("http://arxiv.org/abs/math.AP/0601164")[#text("http://arxiv.org/abs/math.AP/0601164")]

#text("The Begout-Vargas paper also has some statements of inverse Strichartz type.")

#text("One can use the profile decomposition to deduce inverse theorems (though usually the order of implications goes the other way). Indeed, if the inverse theorem failed for (say) Sobolev, then one could find a sequence of examples which were tight for the Sobolev inequality but became increasingly dispersed in the sense that they were not localised to any ball. Applying the profile decomposition to such a sequence (normalising the Sobolev norm to be bounded), one would obtain a contradiction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39300")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("I admit I am very new to this, but I am having a hard time seeing how one can use Freiman’s theorem and the Balog-Szemeredi-Gowers theorem, to prove an inverse young and Hausdorff-Young theorem.")

#text("If this is done anywhere in the literature could you point me to it? If not, would you be willing to provide a very brief sketch of how the argument should work? In view of Ben Green’s comments (and your reply) I am happy to assume that f=1_A and G=1_B. I am guessing that the argument is something like: (a) apply BSG at endpoints, (b) interpolate, and (c) somehow plug the conclusion of BSG into Freiman’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39301")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Dear anonymous, for Young’s inequality for characteristic functions ")#mi("f=1_A, g=1_B")#text(", say on the integers, one can look at the cardinality of the level sets ")#mi("\\{ 1_A * 1_B \\geq \\lambda \\}")#text(". On the one hand this quantity is zero if ")#tao-math("\\lambda > \\min(\\left|A\\right|, \\left|B\\right|)", block: false)#text("; on the other hand, by Markov’s inequality there is a lower bound of ")#tao-math("\\left|A\\right| \\left|B\\right|/\\lambda", block: false)#text(". If Young’s inequality ")#tao-math("\\left\\| 1_A * 1_B \\right\\|_r \\leq \\left\\|1_A\\right\\|_p \\left\\|1_B\\right\\|_q", block: false)#text(" is close to sharp for some non-endpoint choices of p,q,r, then a computation using the distributional bounds implies that ")#tao-math("\\left|A\\right|, \\left|B\\right|", block: false)#text(" are comparable, and that ")#mi("\\{ 1_A * 1_B \\geq \\lambda \\}")#text(" has size comparable to ")#tao-math("\\left|A\\right|", block: false)#text(" for some ")#mi("\\lambda")#text(" comparable to ")#tao-math("\\left|A\\right|", block: false)#text(". This is basically the situation to which BSG, and then Freiman, would apply.")

#text("For Hausdorff-Young, one can use interpolation to reduce to analysing the particular inequality ")#tao-math("\\left\\|\\hat f \\right\\|_{L^4} \\leq \\left\\|f\\right\\|_{L^{4/3}}", block: false)#text(", which by Plancherel’s theorem is equivalent to the Young inequality ")#tao-math("\\left\\|f*f\\right\\|_{L^2} \\leq \\left\\|f\\right\\|_{L^{4/3}} \\left\\|f\\right\\|_{L^{4/3}}", block: false)#text(" which can be handled by the preceding argument.")

#text("I think these results do not appear explicitly in the literature, though they seem to be folklore (Michael Christ, for instance, has some unpublished computations establishing these sorts of things, as part of his work on quasi-extremisers of Radon transforms).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39303")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Thanks for the reply. When I asked the question, I had in mind the circle, T. In fact, it seems that this is what we need to assume if we plan to deduce from it the inverse theorem for the (usual) Hausdorff-Young inequality.")

#text("In the case of T, we still may assume that f=1_A and g=1_B (for A, B \\subset T) and deduce similar distributional estimates. However, it seems that the additive combinatorics won’t be the same in this setting (unless at some point we pass to the dual group, Z).")

#text("In fact, I’m not now sure what the inverse result should be. Are we trying to show that if young’s inequality is nearly sharp then f is localized to a small ball? What I (probably mistakenly) assumed/hoped when I read the result is that in the case of near equality for f \\in L^p(T), we’d have that \\hat{f}(n) is supported on frequencies in nearly an AP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39308")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("For a general, the inverse theorem for Young’s inequality should assert that if ")#tao-math("\\left\\|f*g\\right\\|_{L^r} \\leq \\left\\|f\\right\\|_p \\left\\|g\\right\\|_q", block: false)#text(" is close to being satisfied with equality, then f and g should be concentrated on translates of the same set of small doubling. On the torus, the sets of small doubling are essentially the sums of balls and generalised arithmetic progressions; see ")#link("http://front.math.ucdavis.edu/math.CO/0601431")[#text("this paper of mine")]#text(" for a precise statement. Similarly for the Hausdorff-Young inequality.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YIQ")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39783")[#strong[#text("YIQ")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("Dear Terry,")

#text("I have a final question about the final step of applying Balog-Szemeredi-Gowers and Freiman in deriving the young’s inquality inverse theorem in the thread above.")

#text("I have a final question about the final step of applying Balog-Szemeredi-Gowers and Freiman. Let’s stick to the integers, ")#mi("\\mathbb{Z}")#text(". Using the statements in your and Vu’s combinatorics book, BSG roughly states that if the additive energy ")#tao-math("E(A,B) \\geq \\frac{\\left|A\\right|^{1/2} \\left|B\\right|^{2/3}}{k}", block: false)#text(" then there exists subsets ")#mi("A^{\\prime} \\subset A")#text(" and ")#mi("B^{\\prime} \\subset B")#text(" such that ")#tao-math("\\left|A+B\\right| \\leq k^{c} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}", block: false)#text(".")

#text("I understand that heuristically this shows that ")#mi("A")#text(" and ")#mi("B")#text(" have small doubling, and thus Freiman’s theorem should imply that these are ‘almost’ generalized AP’s. However, every formulation of Freiman’s theorem that I am familiar with (such as Theorem 5.32 in your book) works with only a single set (i.e. has a hypothesis such as ")#tao-math("\\left|A+A\\right| < k \\left|A\\right|", block: false)#text("). Is there a more general version of this theorem, or can we somehow use Freiman's theorem in this form?")

#text("Moreover, even if we didn't care to be as general, and started with ")#mi("B=A")#text(", then it still seems like we fall a bit short of being able to apply Freiman's theorem, because the subsets ")#mi("A^{\\prime}")#text(" and ")#mi("B^{\\prime}")#text(" we get from applying BSG aren't necessarily the same.")

#text("Thanks again!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/04/21/an-inverse-theorem-for-the-bilinear-l2-strichartz-estimate-for-the-wave-equation/#comment-39786")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2009")])]

#text("Dear YIQ,")

#text("One can use sumset theory to essentially make the A’ and B’ components the same (up to translations), see e.g. Theorem 2.31(v) of my book with Van.")
]
]
