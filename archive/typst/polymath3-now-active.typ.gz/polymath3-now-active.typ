// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/
// Converted to Typst by tao2typ: "2026-10-14T16:36:18.326820+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath3 now active", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath3 now active")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/")[#text("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("Gil Kalai has officially started the ")#link("http://michaelnielsen.org/polymath1/index.php?title=The_polynomial_Hirsch_conjecture")[#text("Polymath3 project")]#text(" (Polynomial Hirsch conjecture) with a ")#link("http://gilkalai.wordpress.com/2010/09/29/polymath-3-polynomial-hirsch-conjecture/")[#text("research thread at his blog")]#text(".")

#text("The original aim of this project is to prove the polynomial Hirsch conjecture, which is a conjecture in the combinatorial geometry of polytopes. However, there is a reduction due to Eisenbrand, Hahnle, Razborov, and Rothvoss that would deduce this conjecture from a purely combinatorial conjecture, which can be stated as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Combinatorial polynomial Hirsch conjecture.")]#text(" Let ")#mi("{\\mathcal F}_1,\\ldots,{\\mathcal F}_t")#text(" be non-empty collections of subsets of ")#mi("\\{1,\\ldots,n\\}")#text(" with the following properties:")

#enum(start: 1, 
[#text("(Disjointness) ")#mi("{\\mathcal F}_i \\cap {\\mathcal F}_j = \\emptyset")#text(" for every ")#mi("i \\neq j")#text(".")],
[#text("(Connectedness) If ")#mi("1 \\leq i < j < k \\leq t")#text(" and ")#mi("A \\in {\\mathcal F}_i, B \\in {\\mathcal F}_ k")#text(", there exists ")#mi("C \\in {\\mathcal F}_j")#text(" such that ")#mi("A \\cap B \\subset C")#text(".")]
)

#text("Then t is of polynomial size in n (i.e. ")#mi("t = O(n^{O(1)})")#text(").")
]

#text("For instance, when n=3, one can obtain such a family with t=6, e.g.")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal F}_1  & = \\{ \\emptyset\\}, {\\mathcal F}_2 = \\{ \\{1\\}\\}, {\\mathcal F}_3 = \\{\\{1,2\\}\\}, {\\mathcal F}_4 = \\{\\{1,2,3\\}\\},", block: true)



#tao-math("{\\mathcal F}_5  & = \\{\\{2,3\\}\\}, {\\mathcal F}_6 = \\{\\{3\\}\\};", block: true)
]

#text("one can show that this is the best possible value of t for this choice of n. The best possible value of t for n=4 is still not worked out; it is between 8 and 11.")

#text("One appealing thing about this problem is that there is a simple elementary argument that gives the bound ")#mi("t \\leq n^{\\log_2 n + 1}")#text(" for all ")#mi("n \\geq 2")#text("; and so in some sense one is “only a logarithm away” from proving the conjecture. Anyway, the project is just starting, and does not require any particularly specialised background, so anyone who may be interested in this problem one may want to take a look at ")#link("http://gilkalai.wordpress.com/2010/09/29/polymath-3-polynomial-hirsch-conjecture/")[#text("the research thread")]#text(".")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47348")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Typo: missing ‘latex’ in $A \\cap B \\subset C$, ")#mi("A\\cap B\\subset C")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e396c717cc965ba115210aad7cd970a71f23745189d7b63686a7a2f9a784060-ca382c71a4853bc47f6c43efb0288e0c6a91a63e848b7e5589611f3fa2197879.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Carnahan")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47349")[#strong[#text("Scott Carnahan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("I think the Disjointness axiom needs an empty set. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47362")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("There is one bracket too much in the definition of F_5. ")#emph[#text("[Not sure I see this… – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("I think you’ve got one too many bracket also, should be F_5 = {{2,3},{3}}, rather than {{2,3}},{{3}}")

#emph[#text("[Ah, I see the problem now: F_6 had run off beyond the column width of the blog and so was not visible. Fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/992fa71042ed37df4ab27de1de48f48c274a2a72d1a434cdf0e6314d1754c726-ba58d5187ecfe093fa29070570e91eae9d0d8a98aca2cf6ce452f53fa4647938.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Hansen")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47374")[#strong[#text("David Hansen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("Should “polytops” be “polytopes”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c7f6e7ecea6e7a68823ef375ddd159b421b3089f98d2a8a9be4f64467aaa49-0d7d0ebb479f5bf06f4db0f2dc4b4440c90a1b826bc0308e6cfdb6ded0cc9f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47567")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("Why is")#linebreak()#text(" {\\mathcal F}_1 = \\{ \\emptyset\\}, {\\mathcal F}_2 = \\{ \\{1\\}\\}, {\\mathcal F}_3 = \\{\\{1,2\\}\\}, {\\mathcal F}_4 = \\{\\{1,2,3\\}\\}, {\\mathcal F}_5 = \\{\\{2,3\\}\\}, {\\mathcal F}_6 = \\{\\{3\\}\\};")

#text("optimal?")#linebreak()#text(" Why cant I shove in {{2}} to get")

#text("{\\mathcal F}_1 = \\{ \\emptyset\\}, {\\mathcal F}_2 = \\{ \\{1\\}\\}, {\\mathcal F}_3 = \\{\\{2\\}\\}, {\\mathcal F}_4 = \\{\\{1,2\\}\\}, {\\mathcal F}_5 = \\{\\{1,2,3\\}\\}, {\\mathcal F}_6 = \\{\\{2,3\\}\\}, {\\mathcal F}_7 = \\{\\{3\\}\\};")

#text("(I may be making a silly error, but I cannot see it)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c7f6e7ecea6e7a68823ef375ddd159b421b3089f98d2a8a9be4f64467aaa49-0d7d0ebb479f5bf06f4db0f2dc4b4440c90a1b826bc0308e6cfdb6ded0cc9f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2010/09/30/polymath3-now-active/#comment-47568")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("Nevermind!! Please ignore my post, I see that {1}\\cap {1,2,3}={1} not subset of {2}. I should think about things more before posting next time.")
]
