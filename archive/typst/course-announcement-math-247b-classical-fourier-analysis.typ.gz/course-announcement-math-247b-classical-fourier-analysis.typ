// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:38:43.339272+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Course announcement: Math 247B, Classical Fourier Analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Course announcement: Math 247B, Classical Fourier Analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/")[#text("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Next quarter, starting March 30, I will be teaching “")#link("https://ccle.ucla.edu/mod/page/view.php?id=2840550")[#text("Math 247B: Classical Fourier Analysis")]#text("” here at UCLA. (The course should more accurately be named “Modern real-variable harmonic analysis”, but we have not gotten around to implementing such a name change.) This class (a continuation of ")#link("https://ccle.ucla.edu/course/view/20W-MATH247A-1")[#text("Math 247A from previous quarter")]#text(", taught by my colleague, ")#link("https://www.math.ucla.edu/~visan/")[#text("Monica Visan")]#text(") will cover the following topics:")

#list(
[#text("Restriction theory and Strichartz estimates")],
[#text("Decoupling estimates and applications")],
[#text("Paraproducts; time frequency analysis; Carleson’s theorem")]
)

#text("As usual, lecture notes will be made available ")#link("https://terrytao.wordpress.com/category/teaching/247b-classical-fourier-analysis/")[#text("on this blog")]#text(".")

#text("Unlike previous courses, this one will be given online as part of UCLA’s social distancing efforts. In particular, the course will be open to anyone with an internet connection (no UCLA affiliation is required), though non-UCLA participants will not have full access to all aspects of the course, and there is the possibility that some restrictions on participation may be imposed if there are significant disruptions to class activity. For more information, see the ")#link("https://ccle.ucla.edu/mod/page/view.php?id=2840550")[#text("course description")]#text(". ")#strong[#text("UPDATE")]#text(": due to time limitations, I will not be able to respond to personal email inquiries about this class from non-UCLA participants in the course. Please use the comment thread to this blog post for such inquiries. I will also update the ")#link("https://ccle.ucla.edu/mod/page/view.php?id=2840550")[#text("course description")]#text(" throughout the course to reflect the latest information about the course, both for UCLA students enrolled in the course and for non-UCLA participants.")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ddb2932f75fce714a4ee7d91dae89a8bd85d72e3a60b5795d6a2434f5e71af-a788db6748036dabecc6eaea2fb41740c9f05215f2630ece0f1a46929cc5c196.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JosephSugar")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545624")[#strong[#text("JosephSugar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2020")])]

#text("Should participants register for the class, or its open university style?")#linebreak()#text(" Given the current announcement from UCLA that teaching is transferring to online through the winter quarter, will it be possible to access other math classes also online? I don’t see why not. Hardly any other university can offer such quality mathematics content as UCLA, and this unfortunate pandemic could be the beginning of a new era of mathematics education.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("At present, UCLA does not have plans to permanently transition to an online education model; for the spring quarter all classes will be given online, but it is up to each instructor whether to open their course beyond their enrolled UCLA students. In particular there is currently no way for participants not affiliated with UCLA to formally enroll in the course, and some course components (e.g., homework grading) will be restricted to UCLA students enrolled in the course. By the end of the spring quarter there may be more clarity (both with regards to the efficacy of online teaching, and on the state of the coronavirus pandemic) as to how UCLA is to proceed going forward, but at this point there is far too much uncertainty to make any predictions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9584d6e0d068926369e242597965bb75e882b385fe4a867f899f1a6e91c879c1-4de78ed05d13a12db50d7d185c3ff1056f229494e2b693d30e92011836621d9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of physicslight")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545667")[#strong[#text("physicslight")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("Mr. Tao,")#linebreak()#text(" Thank you for sharing this open")#linebreak()#text(" It helps in these days to exercise the mind.")#linebreak()#text(" Best,")#linebreak()#text(" marco")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545703")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("a quick library search turns up this expository article about the Waring problem.")#linebreak()#text(" ")#link("https://arxiv.org/abs/1707.00119")[#text("https://arxiv.org/abs/1707.00119")]

#text("There are also some nice – rather technical – articles by Jean Bourgain.")#linebreak()#text(" ")#link("https://arxiv.org/abs/1604.06032")[#text("https://arxiv.org/abs/1604.06032")]

#text("How do we pass between discrete statements over ")#mi("\\mathbb{Z}")#text(" to statements over ")#mi("\\mathbb{R}")#text(" ? Any time we used symbols like “")#mi("\\int")#text("” or ")#mi("e^{in\\theta}")#text(" these were certainly limits of some other process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aab5711b8826b740e6bce9802da106773e71329abf8bd1aa680e609224963cf0-9b8f7a2dbf72c1fc0bacfc37192c7c751a1dfda39686c314275d5a0461d1cadb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinwu Yang")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545713")[#strong[#text("Xinwu Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("Dear Prof. Tao,")

#text("I haven’t studied too much about the topics in the prerequisite (i.e. M247A); I did some graduate real analysis before, and we finished Chapter 1-7 in Folland and a bit of distribution theory. I am afraid that they are not enough. Could you help suggest some notes/book/reading for me to get more preparation for M247B? I searched online and found that you also wrote some notes for M247A (")#link("https://www.math.ucla.edu/~tao/247a.1.06f/")[#text("https://www.math.ucla.edu/~tao/247a.1.06f/")]#text("), is it enough for your M247B?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d6bdf2bd78b8c450d3b378107f5fa776b3893266ce17c517381ad5c40b9d028-169a3ebe6597a0076317c90f4e09b8e2c4f15cbb755b5af13abcb29212c876e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zane")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545725")[#strong[#text("Zane")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("FYI this was the class page for last quarter’s 247A taught by Professor Visan.")

#link("https://www.math.ucla.edu/~visan/Math247A_W20/")[#text("https://www.math.ucla.edu/~visan/Math247A_W20/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("I guess one can say that Monica’s “The lectures are most strongly influenced by the following” list of references in Zane’s link covers almost ALL primary texts in “introductory” harmonic analysis. (I mean, of course, the lecture would/should be strongly influenced by those books. What could else books be?) One may feel lost…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("That course covered a slightly different set of topics than last quarter’s 247A (that set is now listed in the course description), but either course should be sufficient preparation for 247B (in particular, familiarity with interpolation, Fourier analysis, and estimation of oscillatory integrals (e.g., by the method of stationary phase) will be helpful.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545733")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("This 247B seems to be quite different from the one you offered before: ")#link("https://www.math.ucla.edu/~tao/247b.1.07w/")[#text("https://www.math.ucla.edu/~tao/247b.1.07w/")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bad1a4dbdd4ab720d092d486139704b612d8bbe6c152c1962dd7d1b05c643d4-6ec939d28dd8567790f23be4ba0d368befc3d4cdccffd1cd5ff381fe8d9a6299.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("Will you put the video online after class? Like youtube")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-546326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("I have decided not to do this; it may negatively impact class participation, and there are also some non-trivial issues regarding consent and privacy on the part of the students. It is possible these issues are solvable, but the transition to remote teaching is going to be chaotic enough as it is, so I do not want to make things even more disruptive this quarter. However this may be a possibility for future courses for which there is more time available to prepare for such issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-546376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("Do you expect that the participants may exceed the capacity of Zoom?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-546497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2020")])]

#text("I believe the capacity of our Zoom meeting rooms is 300. I do not anticipate exceeding this limit, but if this becomes the case I will limit attendance to UCLA affiliated participants once one gets close to this limit. (It should be pointed out that this course is a continuation of a previous graduate course at UCLA and may not necessarily be suitable for external participants that do not have the appropriate prerequisites.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-546743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2020")])]

#text("Due to your popularity (see also ")#link("https://zhuanlan.zhihu.com/p/113528952")[#text("https://zhuanlan.zhihu.com/p/113528952")]#text("), I would not be surprised if the number of participants significantly exceeds the limit, even there may be a lot who don’t know much real analysis. On the other hand, serious students who do want to learn would benefit tremendously from being able to sit in the Zoom room or have access to some recordings without compromising the privacy of UCLA students.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545794")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("—–")#linebreak()#text(" * Restriction theory and Strichartz estimates")

#text("* Decoupling estimates and applications")

#text("* Paraproducts; time frequency analysis; Carleson’s theorem")#linebreak()#text(" —–")

#text("In my ignorance of what all these specifically are about, my reaction is that these topics sound a great deal more like a workshop for researchers than a course for graduate students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c290dd23455aabaccb4ed960c74e05431b83723b2d2863508ecf89ab9bb54d61-2d8d83b239bf1793e22e0af5131e760e317513120de01df7b3d94d5119a36acc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maitland Bowen")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-545806")[#strong[#text("Maitland Bowen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2020")])]

#text("Thank you. I am interested. Please include me on any applicable lists.")#linebreak()#text(" Regards, Maitland Bowen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-548139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("Dear Prof. Tao,")

#text("May I ask how can I attend the Zoom lectures?")#linebreak()#text(" Is there any kind of registration?")

#text("Many thanks,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83425f28fdec1522977c30dfa2499bbfb2cfe67b484f20685722629105a58c67-2c6c36f027d18ccbc168dad606adaf140078dad1bcc5d4b083675e39825f0f19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Classical Fourier Analysis by Terence Tao (online lecture) – Ghent Analysis & PDEs")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-548600")[#strong[#text("Classical Fourier Analysis by Terence Tao (online lecture) – Ghent Analysis & PDEs")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2020")])]

#text("[…] will be permitted to attend the Zoom lectures and to post comments on the blog (one can use this post in particular for general questions about the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-549206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("Dear Prof Tao,")

#text("I think that as the host, you can mute audio(and video) of every participant except your UCLA students. Thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9463afbe3bdb90d656adfbe2d7b44526be6ab94f393bcfc2754a49f6fded9c48-508fed56a7a530221c1e4c8c2bf31f1814744e2a60dc1aaad8013f8a382eda66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinjie Zhang")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-549258")[#strong[#text("Xinjie Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2020")])]

#text("how can we find the replay ? as timezoon difference. we can not attend the online class . please see where can we find the record session .thanks a lot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-549278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2020")])]

#text("For reasons of privacy, UCLA policy forbids video recordings to be available except to the students enrolled in the class.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-549697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Could you post your notes in .pdf format on line? They don’t need to be the final version. It is easier for students to download and take notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-549717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("If you print a blog page to PDF you will get a readable PDF file (with the header, sidebar, etc. stripped)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-615832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2021")])]

#text("It is also easy to export the file into notes using an iPad. So convenient to go paperless!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-564231")[#strong[#text("MATH 247B: Modern Real-Variable Harmonic Analysis – Countable Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")]

#text("[…] Spring 2020, I took MATH 247B at UCLA, with Professor Terence Tao. The class covered the following […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-615814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2021")])]

#text("Would it violate the UCLA policy if you upload your notebook (which contains lots of useful pictures you drew in class) somewhere on your webpage?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-684599")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2024")])]

#text("It really hurts knowing these lectures were available before and I have missed studying from Terry Tao!")#linebreak()#text("I wished you reconsider making these lectures available, despite I completely understand your reasonable reasons for not sharing the videos(like privacy of students), you are also depriving many eager students from learning directly from you.")#linebreak()#text("I just ask you reconsider this subject once more:)")#linebreak()#text("Thanks dear Terry Tao.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/14/course-announcement-math-247b-classical-fourier-analysis/#comment-684600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2024")])]

#text("Videos are deleted after 2 years.")
]
]
