// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/13/a-multi-dimensional-szemeredi-theorem-for-the-primes-via-a-correspondence-principle/
// Converted to Typst by tao2typ: "2026-10-14T15:18:39.725465+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A multi-dimensional Szemer\\’edi theorem for the primes via a correspondence principle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A multi-dimensional Szemer\\’edi theorem for the primes via a correspondence principle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/13/a-multi-dimensional-szemeredi-theorem-for-the-primes-via-a-correspondence-principle/")[#text("https://terrytao.wordpress.com/2013/06/13/a-multi-dimensional-szemeredi-theorem-for-the-primes-via-a-correspondence-principle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1306.2886")[#text("A multi-dimensional Szemerédi theorem for the primes via a correspondence principle")]#text("“. This paper is related to an ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("earlier result of Ben Green and mine")]#text(" in which we established that the primes contain arbitrarily long arithmetic progressions. Actually, in that paper we proved a more general result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Szemerédi’s theorem in the primes)")]#text(" ")#metadata(none) <tao-60b5e1ba0e12773f48e6>#text(" Let ")#mi("{A}")#text(" be a subset of the primes ")#mi("{{\\mathcal P}}")#text(" of positive relative density, thus ")#tao-math("{\\limsup_{N \\rightarrow \\infty} \\frac{\\left|A \\cap [N]\\right|}{\\left|{\\mathcal P} \\cap [N]\\right|} > 0}", block: false)#text(". Then ")#mi("{A}")#text(" contains arbitrarily long arithmetic progressions.")
]

#text("This result was based in part on an ")#link("http://www.ams.org/mathscinet-getitem?mr=2180408")[#text("earlier paper of Green")]#text(" that handled the case of progressions of length three. With the primes replaced by the integers, this is of course the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("famous theorem of Szemerédi")]#text(".")

#text("Szemerédi’s theorem has now been generalised in many different directions. One of these is the multidimensional Szemerédi theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=531279")[#text("Furstenberg and Katznelson")]#text(", who used ergodic-theoretic techniques to show that any dense subset of ")#mi("{{\\bf Z}^d}")#text(" necessarily contained infinitely many constellations of any prescribed shape. Our main result is to relativise that theorem to the primes as well:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Multidimensional Szemerédi theorem in the primes)")]#text(" ")#metadata(none) <tao-013a7ea6701d31611e3f>#text(" Let ")#mi("{d \\geq 1}")#text(", and let ")#mi("{A}")#text(" be a subset of the ")#mi("{d^{th}}")#text(" Cartesian power ")#mi("{{\\mathcal P}^d}")#text(" of the primes of positive relative density, thus")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\frac{\\left|A \\cap [N]^d\\right|}{\\left|{\\mathcal P}^d \\cap [N]^d\\right|} > 0.", block: true)]]

#text("Then for any ")#mi("{v_1,\\ldots,v_k \\in {\\bf Z}^d}")#text(", ")#mi("{A}")#text(" contains infinitely many “constellations” of the form ")#mi("{a+r v_1, \\ldots, a + rv_k}")#text(" with ")#mi("{a \\in {\\bf Z}^k}")#text(" and ")#mi("{r}")#text(" a positive integer.")
]

#text("In the case when ")#mi("{A}")#text(" is itself a Cartesian product of one-dimensional sets (in particular, if ")#mi("{A}")#text(" is all of ")#mi("{{\\mathcal P}^d}")#text("), this result already follows from Theorem ")#link(<tao-60b5e1ba0e12773f48e6>)[#text("1")]#text(", but there does not seem to be a similarly easy argument to deduce the general case of Theorem ")#link(<tao-013a7ea6701d31611e3f>)[#text("2")]#text(" from previous results. Simultaneously with this paper, an independent proof of Theorem ")#link(<tao-013a7ea6701d31611e3f>)[#text("2")]#text(" using a somewhat different method has been established ")#link("http://arxiv.org/abs/1306.3025")[#text("by Cook, Maygar, and Titichetrakun")]#text(".")

#text("The result is reminiscent of an ")#link("http://www.ams.org/mathscinet-getitem?mr=2279549")[#text("earlier result of mine")]#text(" on finding constellations in the Gaussian primes (or dense subsets thereof). That paper followed closely the arguments of my original paper with Ben Green, namely it first enclosed (a W-tricked version of) the primes or Gaussian primes (in a sieve theoretic-sense) by a slightly larger set (or more precisely, a weight function ")#mi("{\\nu}")#text(") of ")#emph[#text("almost primes")]#text(" or ")#emph[#text("almost Gaussian primes")]#text(", which one could then verify (using methods closely related to the sieve-theoretic methods in the ongoing ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(") to obey certain pseudorandomness conditions, known as the ")#emph[#text("linear forms condition")]#text(" and the ")#emph[#text("correlation condition")]#text(". Very roughly speaking, these conditions assert statements of the following form: if ")#mi("{n}")#text(" is a randomly selected integer, then the events of ")#mi("{n+h_1,\\ldots,n+h_k}")#text(" simultaneously being an almost prime (or almost Gaussian prime) are approximately independent for most choices of ")#mi("{h_1,\\ldots,h_k}")#text(". Once these conditions are satisfied, one can then run a ")#emph[#text("transference argument")]#text(" (initially based on ergodic-theory methods, but nowadays there are simpler transference results based on the Hahn-Banach theorem, due to ")#link("http://www.ams.org/mathscinet-getitem?mr=2669681")[#text("Gowers")]#text(" and ")#link("http://arxiv.org/abs/0806.0381")[#text("Reingold-Trevisan-Tulsiani-Vadhan")]#text(") to obtain relative Szemerédi-type theorems from their absolute counterparts.")

#text("However, when one tries to adapt these arguments to sets such as ")#mi("{{\\mathcal P}^2}")#text(", a new difficulty occurs: the natural analogue of the almost primes would be the Cartesian square ")#mi("{{\\mathcal A}^2}")#text(" of the almost primes – pairs ")#mi("{(n,m)}")#text(" whose entries are both almost primes. (Actually, for technical reasons, one does not work directly with a set of almost primes, but would instead work with a weight function such as ")#mi("{\\nu(n) \\nu(m)}")#text(" that is concentrated on a set such as ")#mi("{{\\mathcal A}^2}")#text(", but let me ignore this distinction for now.) However, this set ")#mi("{{\\mathcal A}^2}")#text(" does ")#emph[#text("not")]#text(" enjoy as many pseudorandomness conditions as one would need for a direct application of the transference strategy to work. More specifically, given any fixed ")#mi("{h, k}")#text(", and random ")#mi("{(n,m)}")#text(", the four events")

#tao-aligned(keep: true)[


#tao-math("(n,m)  & \\in {\\mathcal A}^2", block: true)



#tao-math("(n+h,m)  & \\in {\\mathcal A}^2", block: true)



#tao-math("(n,m+k)  & \\in {\\mathcal A}^2", block: true)



#tao-math("(n+h,m+k)  & \\in {\\mathcal A}^2", block: true)
]

#text("do ")#emph[#text("not")]#text(" behave independently (as they would if ")#mi("{{\\mathcal A}^2}")#text(" were replaced for instance by the Gaussian almost primes), because any three of these events imply the fourth. This blocks the transference strategy for constellations which contain some right-angles to them (e.g. constellations of the form ")#mi("{(n,m), (n+r,m), (n,m+r)}")#text(") as such constellations soon turn into rectangles such as the one above after applying Cauchy-Schwarz a few times. (But a few years ago, ")#link("http://arxiv.org/abs/1010.5805")[#text("Cook and Magyar showed")]#text(" that if one restricted attention to constellations which were in general position in the sense that any coordinate hyperplane contained at most one element in the constellation, then this obstruction does not occur and one can establish Theorem ")#link(<tao-013a7ea6701d31611e3f>)[#text("2")]#text(" in this case through the transference argument.) It’s worth noting that very recently, ")#link("http://arxiv.org/abs/1305.5440")[#text("Conlon, Fox, and Zhao have succeeded")]#text(" in removing of the pseudorandomness conditions (namely the correlation condition) from the transference principle, leaving only the linear forms condition as the remaining pseudorandomness condition to be verified, but unfortunately this does not completely solve the above problem because the linear forms condition also fails for ")#mi("{{\\mathcal A}^2}")#text(" (or for weights concentrated on ")#mi("{{\\mathcal A}^2}")#text(") when applied to rectangular patterns.")

#text("There are now two ways known to get around this problem and establish Theorem ")#link(<tao-013a7ea6701d31611e3f>)[#text("2")]#text(" in full generality. The approach of ")#link("http://arxiv.org/abs/1306.3025")[#text("Cook, Magyar, and Titichetrakun")]#text(" proceeds by starting with one of the known proofs of the multidimensional Szemerédi theorem – namely, the proof that proceeds through hypergraph regularity and hypergraph removal – and attach pseudorandom weights directly within the proof itself, rather than trying to add the weights to the ")#emph[#text("result")]#text(" of that proof through a transference argument. (A key technical issue is that weights have to be added to all the levels of the hypergraph – not just the vertices and top-order edges – in order to circumvent the failure of naive pseudorandomness.) As one has to modify the entire proof of the multidimensional Szemerédi theorem, rather than use that theorem as a black box, the ")#link("http://arxiv.org/abs/1306.3025")[#text("Cook-Magyar-Titichetrakun argument")]#text(" is lengthier than ours; on the other hand, it is more general and does not rely on some difficult theorems about primes that are used in our paper.")

#text("In our approach, we continue to use the multidimensional Szemerédi theorem (or more precisely, the equivalent theorem of Furstenberg and Katznelson concerning multiple recurrence for commuting shifts) as a black box. The difference is that instead of using a transference principle to connect the relative multidimensional Szemerédi theorem we need to the multiple recurrence theorem, we instead proceed by a version of the Furstenberg correspondence principle, similar to the one that connects the absolute multidimensional Szemerédi theorem to the multiple recurrence theorem. I had discovered this approach many years ago in ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/limiting.dvi")[#text("an unpublished note")]#text(", but had abandoned it because it required an ")#emph[#text("infinite")]#text(" number of linear forms conditions (in contrast to the transference technique, which only needed a finite number of linear forms conditions and (until the recent work of Conlon-Fox-Zhao) a correlation condition). The reason for this infinite number of conditions is that the correspondence principle has to build a probability measure on an entire ")#mi("{\\sigma}")#text("-algebra; for this, it is not enough to specify the measure ")#mi("{\\mu(A)}")#text(" of a single set such as ")#mi("{A}")#text(", but one also has to specify the measure ")#mi("{\\mu( T^{n_1} A \\cap \\ldots \\cap T^{n_m} A)}")#text(" of “cylinder sets” such as ")#mi("{T^{n_1} A \\cap \\ldots \\cap T^{n_m} A}")#text(" where ")#mi("{m}")#text(" could be arbitrarily large. The larger ")#mi("{m}")#text(" gets, the more linear forms conditions one needs to keep the correspondence under control.")

#text("With the sieve weights ")#mi("{\\nu}")#text(" we were using at the time, standard sieve theory methods could indeed provide a finite number of linear forms conditions, but not an infinite number, so my idea was abandoned. However, with my later work with Green and Ziegler on ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("linear equations in primes")]#text(" (and related ")#link("http://www.ams.org/mathscinet-getitem?mr=2877066")[#text("work on the Mobius-nilsequences conjecture")]#text(" and the ")#link("http://www.ams.org/mathscinet-getitem?mr=2950773")[#text("inverse conjecture on the Gowers norm")]#text("), Tamar and I realised that the primes themselves obey an infinite number of linear forms conditions, so one can basically use the primes (or a proxy for the primes, such as the von Mangoldt function ")#mi("{\\Lambda}")#text(") as the enveloping sieve weight, rather than a classical sieve. Thus my old idea of using the Furstenberg correspondence principle to transfer Szemerédi-type theorems to the primes could actually be realised. In the one-dimensional case, this simply produces a much more complicated proof of Theorem ")#link(<tao-60b5e1ba0e12773f48e6>)[#text("1")]#text(" than the existing one; but it turns out that the argument works as well in higher dimensions and yields Theorem ")#link(<tao-013a7ea6701d31611e3f>)[#text("2")]#text(" relatively painlessly, except for the fact that it needs the results on linear equations in primes, the known proofs of which are extremely lengthy (and also require some of the transference machinery mentioned earlier). The problem of correlations in rectangles is avoided in the correspondence principle approach because one can compensate for such correlations by performing a suitable weighted limit to compute the measure ")#mi("{\\mu( T^{n_1} A \\cap \\ldots \\cap T^{n_m} A)}")#text(" of cylinder sets, with each ")#mi("{m}")#text(" requiring a different weighted correction. (This may be related to the ")#link("http://arxiv.org/abs/1306.3025")[#text("Cook-Magyar-Titichetrakun")]#text(" strategy of weighting all of the facets of the hypergraph in order to recover pseudorandomness, although our contexts are rather different.)")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dorian")]], [#link("https://terrytao.wordpress.com/2013/06/13/a-multi-dimensional-szemeredi-theorem-for-the-primes-via-a-correspondence-principle/#comment-234511")[#strong[#text("Dorian")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("For the four events that you specified should the last one be ( n + h , m + k ) ?")

#emph[#text("[Corrected, thanks – T.]")]
]
