// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/
// Converted to Typst by tao2typ: "2026-10-14T16:36:53.467465+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Definable subsets over (nonstandard) finite fields, and almost quantifier elimination", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Definable subsets over (nonstandard) finite fields, and almost quantifier elimination")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/")[#text("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Much as group theory is the study of groups, or graph theory is the study of graphs, ")#link("http://en.wikipedia.org/wiki/Model_theory")[#text("model theory")]#text(" is the study of ")#emph[#text("models")]#text(" (also known as ")#link("http://en.wikipedia.org/wiki/Structure_(mathematical_logic)")[#text("structures")]#text(") of some ")#link("http://en.wikipedia.org/wiki/Formal_language")[#text("language")]#text(" ")#mi("{{\\mathcal L}}")#text(" (which, in this post, will always be a single-sorted, ")#link("http://en.wikipedia.org/wiki/First-order_logic")[#text("first-order")]#text(" language). A structure is a set ")#mi("{X}")#text(", equipped with one or more operations, constants, and relations. This is of course an extremely general type of mathematical object, but (quite remarkably) one can still say a substantial number of interesting things about very broad classes of structures.")

#text("We will observe the common abuse of notation of using the set ")#mi("{X}")#text(" as a ")#link("http://en.wikipedia.org/wiki/Metonymy")[#text("metonym")]#text(" for the entire structure, much as we usually refer to a group ")#mi("{(G,1,\\cdot,()^{-1})}")#text(" simply as ")#mi("{G}")#text(", a vector space ")#mi("{(V, 0, +, \\cdot)}")#text(" simply as ")#mi("{V}")#text(", and so forth. Following another common bending of the rules, we also allow some operations on structures (such as the multiplicative inverse operation on a group or field) to only be partially defined, and we allow use of the usual simplifying conventions for mathematical formulas (e.g. writing ")#mi("{a+b+c}")#text(" instead of ")#mi("{(a+b)+c}")#text(" or ")#mi("{a+(b+c)}")#text(", in cases where associativity is known). We will also deviate slightly from the usual practice in logic by emphasising individual structures, rather than the theory of general classes of structures; for instance, we will talk about the theory of a single field such as ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(", rather than the theory of all fields of a certain type (e.g. real closed fields or algebraically closed fields).")

#text("Once one has a structure ")#mi("{X}")#text(", one can introduce the notion of a ")#link("http://en.wikipedia.org/wiki/Definable_set")[#text("definable subset")]#text(" of ")#mi("{X}")#text(", or more generally of a Cartesian power ")#mi("{X^n}")#text(" of ")#mi("{X}")#text(", defined as a set ")#mi("{E \\subset X^n}")#text(" of the form ")#metadata(none) <tao-e419c8766613f8ae5fa9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("E = \\{ (x_1,\\ldots,x_n): P(x_1,\\ldots,x_n) \\text{ true} \\}")]]

#text("for some ")#link("http://en.wikipedia.org/wiki/Well-formed_formula")[#text("formula")]#text(" ")#mi("{P}")#text(" in the language ")#mi("{{\\mathcal L}}")#text(" with ")#mi("{n}")#text(" free variables and any number of constants from ")#mi("{X}")#text(" (that is, ")#mi("{P(x_1,\\ldots,x_n)}")#text(" is a well-formed formula built up from a finite number of constants ")#mi("{c_1,\\ldots,c_m}")#text(" in ")#mi("{X}")#text(", the relations and operations on ")#mi("{X}")#text(", logical connectives such as ")#mi("{\\neg}")#text(", ")#mi("{\\wedge}")#text(", ")#mi("{\\implies}")#text(", and the quantifiers ")#mi("{\\forall, \\exists}")#text("). Thus, for instance, in the theory of the arithmetic of the natural numbers ")#mi("{{\\bf N} = ({\\bf N}, 0, 1, +, \\times)}")#text(", the set of primes ")#mi("{{\\mathcal P}}")#text(" is a definable set, since we have")

#align(center)[#tao-fit-display[#mitex("{\\mathcal P} = \\{ x \\in {\\bf N}: (\\exists y: x=y+2) \\wedge \\neg (\\exists z,w: x = (z+2)(w+2)) \\}.")]]

#text("In the theory of the field of reals ")#mi("{{\\bf R} = ({\\bf R}, 0, 1, +, -, \\times, ()^{-1})}")#text(", the unit circle ")#mi("{S^1}")#text(" is an example of a definable set,")

#align(center)[#tao-fit-display[#mitex("S^1 = \\{ (x,y) \\in {\\bf R}^2: x^2+y^2 = 1 \\},")]]

#text("but so is the the complement of the circle,")

#align(center)[#tao-fit-display[#mitex("{\\bf R}^2 \\backslash S^1 = \\{ (x,y) \\in {\\bf R}^2: \\neg(x^2+y^2 = 1) \\}")]]

#text("and the interval ")#mi("{[-1,1]}")#text(":")

#align(center)[#tao-fit-display[#mitex("[-1,1] = \\{ x \\in {\\bf R}: \\exists y: x^2+y^2 = 1\\}.")]]

#text("Due to the unlimited use of constants, any finite subset of a power ")#mi("{X^n}")#text(" of any structure ")#mi("{X}")#text(" is, by our conventions, definable in that structure. (One can of course also consider definability without parameters (also known as ")#mi("{0}")#text("-definability), in which arbitrary constants are not permitted, but we will not do so here.)")

#text("We can isolate some special subclasses of definable sets:")

#list(
[#text("An ")#emph[#text("atomic definable set")]#text(" is a set of the form ")#link(<tao-e419c8766613f8ae5fa9>)[#text("(1)")]#text(" in which ")#mi("{P()}")#text(" is an atomic formula (i.e. it does not contain any logical connectives or quantifiers).")],
[#text("A ")#emph[#text("quantifier-free definable set")]#text(" is a set of the form ")#link(<tao-e419c8766613f8ae5fa9>)[#text("(1)")]#text(" in which ")#mi("{P()}")#text(" is quantifier-free (i.e. it can contain logical connectives, but does not contain the quantifiers ")#mi("{\\forall, \\exists}")#text(").")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" In the theory of a field such as ")#mi("{{\\bf R}}")#text(", an atomic definable set is the same thing as an ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("affine algebraic set")]#text(" (also known as an ")#emph[#text("affine algebraic variety")]#text(", with the understanding that varieties are not necessarily assumed to be irreducible), and a quantifier-free definable set is known as a ")#emph[#text("constructible set")]#text("; thus we see that algebraic geometry can be viewed in some sense as a special case of model theory. (Conversely, it can in fact be quite profitable to think of model theory as an abstraction of algebraic geometry; for instance, the concepts of ")#link("http://en.wikipedia.org/wiki/Morley_rank")[#text("Morley rank and Morley degree")]#text(" in model theory (discussed in ")#link("https://terrytao.wordpress.com/2009/11/20/reading-seminar-5-stable-group-theory-and-approximate-subgroups-by-ehud-hrushovsk/")[#text("this previous blog post")]#text(") directly generalises the concepts of dimension and degree in algebraic geometry.) Over ")#mi("{{\\bf R}}")#text(", the interval ")#mi("{[-1,1]}")#text(" is a definable set, but not a quantifier-free definable set (and certainly not an atomic definable set); and similarly for the primes over ")#mi("{{\\bf N}}")#text(".")
]

#text("A quantifier-free definable set in ")#mi("{X^n}")#text(" is nothing more than a finite boolean combination of atomic definable sets; in other words, the class of quantifier-free definable sets over ")#mi("{X}")#text(" is the smallest class that contains the atomic definable sets and is closed under boolean operations such as complementation and union (which generate all the other boolean operations). Similarly, the class of definable sets over ")#mi("{X}")#text(" is the smallest class that contains the quantifier-free definable sets, and is also closed under the operation of ")#emph[#text("projection")]#text(" ")#mi("{\\pi_n: E \\mapsto \\pi_n(E)}")#text(" from ")#mi("{X^{n+1}}")#text(" to ")#mi("{X^n}")#text(" for every natural number ")#mi("{n}")#text(", where ")#mi("{\\pi_n: X^{n+1} \\rightarrow X^n}")#text(" is the map ")#mi("{\\pi_n(x_1,\\ldots,x_n,x_{n+1}) := (x_1,\\ldots,x_n)}")#text(".")

#text("Some structures have the property of enjoying ")#link("http://en.wikipedia.org/wiki/Quantifier_elimination")[#text("quantifier elimination")]#text(", which means that every definable set is in fact a quantifier-free definable set, or equivalently that the projection of a quantifier-free definable set is again quantifier-free. For instance, an algebraically closed field ")#mi("{k}")#text(" (with the field operations) has quantifier elimination (i.e. the projection of a constructible set is again constructible); this fact can be proven by the classical tool of ")#link("http://en.wikipedia.org/wiki/Resultant")[#text("resultants")]#text(", and among other things can be used to give a proof of ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_Nullstellensatz")[#text("Hilbert’s nullstellensatz")]#text(". (Note though that projection does not necessary preserve the property of being atomic; for instance, the projection of the atomic set ")#mi("{\\{ (x,y) \\in k^2: xy=1 \\}}")#text(" is the non-atomic, but still quantifier-free definable, set ")#mi("{\\{ x \\in k: \\neg (k=0) \\}}")#text(".) In the converse direction, it is not difficult to use the nullstellensatz to deduce quantifier elimination. For theory of the real field ")#mi("{{\\bf R}}")#text(", which is not algebraically closed, one does not have quantifier elimination, as one can see from the example of the unit circle (which is a quantifier-free definable set) projecting down to the interval ")#mi("{[-1,1]}")#text(" (which is definable, but not quantifer-free definable). However, if one adds the additional operation of order ")#mi("{<}")#text(" to the reals, giving it the language of an ordered field rather than just a field, then quantifier elimination is recovered (the class of quantifier-free definable sets now enlarges to match the class of definable sets, which in this case is also the class of ")#link("http://en.wikipedia.org/wiki/Semialgebraic_set")[#text("semi-algebraic sets")]#text("); this is the famous ")#link("http://en.wikipedia.org/wiki/Tarski-Seidenberg_theorem")[#text("Tarski-Seidenberg theorem")]#text(".")

#text("On the other hand, many important structures do not have quantifier elimination; typically, the projection of a quantifier-free definable set is not, in general, quantifier-free definable. This failure of the projection property also shows up in many contexts outside of model theory; for instance, Lebesgue famously made the error of thinking that the projection of a Borel measurable set remained Borel measurable (it is merely an ")#link("http://en.wikipedia.org/wiki/Analytic_set")[#text("analytic set")]#text(" instead). ")#link("http://en.wikipedia.org/wiki/Turing%27s_halting_theorem")[#text("Turing’s halting theorem")]#text(" can be viewed as an assertion that the projection of a ")#link("http://en.wikipedia.org/wiki/Recursive_set")[#text("decidable set")]#text(" (also known as a ")#emph[#text("computable")]#text(" or ")#emph[#text("recursive")]#text(" set) is not necessarily decidable (it is merely ")#emph[#text("semi-decidable")]#text(" (or ")#emph[#text("recursively enumerable")]#text(") instead). The notorious ")#link("http://en.wikipedia.org/wiki/P%3DNP_problem")[#text("P=NP problem")]#text(" can also be essentially viewed in this spirit; roughly speaking (and glossing over the placement of some quantifiers), it asks whether the projection of a polynomial-time decidable set is again polynomial-time decidable. And so forth. (See ")#link("http://rjlipton.wordpress.com/2010/08/19/projections-can-be-tricky/")[#text("this blog post")]#text(" of Dick Lipton for further discussion of the subtleties of projections.)")

#text("Now we consider the status of quantifier elimination for the theory of a finite field ")#mi("{F}")#text(". If interpreted naively, quantifier elimination is trivial for a finite field ")#mi("{F}")#text(", since every subset of ")#mi("{F^n}")#text(" is finite and thus quantifier-free definable. However, we can recover an interesting question in one of two (essentially equivalent) ways. One is to work in the asymptotic regime in which the field ")#mi("{F}")#text(" is large, but the length of the formulae used to construct one’s definable sets stays bounded uniformly in the size of ")#mi("{F}")#text(" (where we view any constant in ")#mi("{F}")#text(" as contributing a unit amount to the length of a formula, no matter how large ")#mi("{F}")#text(" is). A simple counting argument then shows that only a small number of subsets of ")#mi("{F^n}")#text(" become definable in the asymptotic limit ")#tao-math("{\\left|F\\right| \\rightarrow \\infty}", block: false)#text(", since the number of definable sets clearly grows at most polynomially in ")#tao-math("{\\left|F\\right|}", block: false)#text(" for any fixed bound on the formula length, while the number of all subsets of ")#tao-math("{\\left|F\\right|^n}", block: false)#text(" grows exponentially in ")#mi("{n}")#text(".")

#text("Another way to proceed is to work not with a single finite field ")#mi("{F}")#text(", or even with a sequence ")#mi("{F_m}")#text(" of finite fields, but with the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{F = \\prod_{m \\rightarrow p} F_m}")#text(" of a sequence of finite fields, and to study the properties of definable sets over this ultraproduct. (We will be using the notation of ultraproducts and ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(" from ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("this previous blog post")]#text(".) This approach is equivalent to the more finitary approach mentioned in the previous paragraph, at least if one does not care to track of the exact bounds on the length of the formulae involved. Indeed, thanks to ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(", a definable subset ")#mi("{E}")#text(" of ")#mi("{F^n}")#text(" is nothing more than the ultraproduct ")#mi("{E = \\prod_{m \\rightarrow p} E_m}")#text(" of definable subsets ")#mi("{E_m}")#text(" of ")#mi("{F_m^n}")#text(" for all ")#mi("{m}")#text(" sufficiently close to ")#mi("{p}")#text(", with the length of the formulae used to define ")#mi("{E_m}")#text(" uniformly bounded in ")#mi("{m}")#text(". In the language of nonstandard analysis, one can view ")#mi("{F}")#text(" as a nonstandard finite field.")

#text("The ultraproduct ")#mi("{F}")#text(" of finite fields is an important example of a ")#emph[#text("pseudo-finite field")]#text(" – a field that obeys all the sentences in the languages of fields that finite fields do, but is not necessarily itself a finite field. The model theory of pseudo-finite fields was first studied systematically ")#link("http://www.ams.org/mathscinet-getitem?mr=229613")[#text("by Ax")]#text(" (in the same paper where ")#link("http://en.wikipedia.org/wiki/Ax%E2%80%93Grothendieck_theorem")[#text("the Ax-Grothendieck theorem")]#text(", discussed ")#link("https://terrytao.wordpress.com/2009/03/07/infinite-fields-finite-fields-and-the-ax-grothendieck-theorem/")[#text("previously on this blog")]#text(", was established), with important further contributions ")#link("http://www.ams.org/mathscinet-getitem?mr=422281")[#text("by Kiefe")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=491477")[#text("by Fried-Sacerdote")]#text(", by ")#link("http://www.ams.org/mathscinet-getitem?mr=1162433")[#text("two papers of")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=590820")[#text("Chatzidakis-van den Dries-Macintyre")]#text(", and many other authors.")

#text("As mentioned before, quantifier elimination trivially holds for finite fields. But for infinite pseudo-finite fields, such as the ultraproduct ")#mi("{F = \\prod_{m \\rightarrow p} F_m}")#text(" of finite fields with ")#tao-math("{\\left|F_m\\right|}", block: false)#text(" going to infinity, quantifier elimination fails. For instance, in a finite field ")#mi("{F_m}")#text(", the set ")#mi("{E_m := \\{ x \\in F_m: \\exists y \\in F_m: x=y^2 \\}}")#text(" of quadratic residues is a definable set, with a bounded formula length, and so in the ultraproduct ")#mi("{F =\\prod_{m \\rightarrow p} F_m}")#text(", the set ")#mi("{E := \\prod_{m\\rightarrow p} E_m}")#text(" of nonstandard quadratic residues is also a definable set. However, in one dimension, we see from the factor theorem that the only atomic definable sets are either finite or the whole field ")#mi("{F}")#text(", and so the only constructible sets (i.e. the only quantifier-free definable sets) are either finite or cofinite in ")#mi("{F}")#text(". Since the quadratic residues have asymptotic density ")#mi("{1/2}")#text(" in a large finite field, they cannot form a quantifier-free definable set, despite being definable.")

#text("Nevertheless, there is a very nice ")#emph[#text("almost quantifier elimination")]#text(" result for these fields, in characteristic zero at least, which we phrase here as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Almost quantifier elimination)")]#text(" ")#metadata(none) <tao-8adf139a3aab4602ce7b>#text(" Let ")#mi("{F}")#text(" be a nonstandard finite field of characteristic zero, and let ")#mi("{E \\subset F^n}")#text(" be a definable set over ")#mi("{F}")#text(". Then ")#mi("{E}")#text(" is the union of finitely many sets of the form ")#metadata(none) <tao-a7e7e2f59b128bdb0aa6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("E = \\{ x \\in V(F): \\exists t \\in F: P(x,t) = 0 \\}")]]

#text("where ")#mi("{V(F)}")#text(" is an atomic definable subset of ")#mi("{F^n}")#text(" (i.e. the ")#mi("{F}")#text("-points of an algebraic variety ")#mi("{V}")#text(" defined over ")#mi("{F}")#text(" in ")#mi("{F^n}")#text(") and ")#mi("{P: F^{n+1} \\rightarrow F}")#text(" is a polynomial.")
]

#text("Results of this type were first obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=422281")[#text("essentially due to Catarina Kiefe")]#text(", although the formulation here is closer to that ")#link("http://www.ams.org/mathscinet-getitem?mr=1162433")[#text("of Chatzidakis-van den Dries-Macintyre")]#text(".")

#text("Informally, this theorem says that while we cannot quite eliminate ")#emph[#text("all")]#text(" quantifiers from a definable set over a nonstandard finite field, we can eliminate all but one existential quantifier. Note that negation has also been eliminated in this theorem; for instance, the definable set ")#mi("{F \\backslash \\{0\\} = \\{ x \\in F: \\neg(x=0) \\}}")#text(" uses a negation, but can also be described using a single existential quantifier as ")#mi("{\\{ x \\in F: \\exists t: xt = 1 \\}}")#text(".) I believe that there are more complicated analogues of this result in positive characteristic, but I have not studied this case in detail (Kiefe’s result does not assume characteristic zero, but her conclusion is slightly different from the one given here). In the one-dimensional case ")#mi("{n=1}")#text(", the only varieties ")#mi("{V}")#text(" are the affine line and finite sets, and we can simplify the above statement, namely that any definable subset of ")#mi("{F}")#text(" takes the form ")#mi("{\\{ x\\in F: \\exists t \\in F: P(x,t) = 0 \\}}")#text(" for some polynomial ")#mi("{P}")#text(" (i.e. definable sets in ")#mi("{F}")#text(" are nothing more than the projections of the ")#mi("{F}")#text("-points of a plane curve).")

#text("There is an equivalent formulation of this theorem for standard finite fields, namely that if ")#mi("{F}")#text(" is a finite field and ")#mi("{E \\subset F^n}")#text(" is definable using a formula of length at most ")#mi("{M}")#text(", then ")#mi("{E}")#text(" can be expressed in the form ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("(2)")]#text(" with the degree of ")#mi("{P}")#text(" bounded by some quantity ")#mi("{C_{M,n}}")#text(" depending on ")#mi("{M}")#text(" and ")#mi("{n}")#text(", assuming that the characteristic of ")#mi("{F}")#text(" is sufficiently large depending on ")#mi("{M, n}")#text(".")

#text("The theorem gives quite a satisfactory description of definable sets in either standard or nonstandard finite fields (at least if one does not care about effective bounds in some of the constants, and if one is willing to exclude the small characteristic case); for instance, in conjunction with the Lang-Weil bound discussed in ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this recent blog post")]#text(", it shows that any non-empty definable subset of a nonstandard finite field has a nonstandard cardinality of ")#tao-math("{(\\alpha + O(\\left|F\\right|^{-1/2})) \\left|F\\right|^d}", block: false)#text(" for some positive standard rational ")#mi("{\\alpha}")#text(" and integer ")#mi("{d}")#text(". Equivalently, any non-empty definable subset of ")#mi("{F^n}")#text(" for some standard finite field ")#mi("{F}")#text(" using a formula of length at most ")#mi("{M}")#text(" has a standard cardinality of ")#tao-math("{(\\alpha + O_{M,n}(\\left|F\\right|^{-1/2})) \\left|F\\right|^d}", block: false)#text(" for some positive rational of height ")#mi("{O_{M,n}(1)}")#text(" and some natural number ")#mi("{d}")#text(" between ")#mi("{0}")#text(" and ")#mi("{n}")#text(". (For instance, in the example of the quadratic residues given above, ")#mi("{d}")#text(" is equal to ")#mi("{1}")#text(" and ")#mi("{\\alpha}")#text(" equal to ")#mi("{1/2}")#text(".) There is a more precise statement to this effect, namely that the Poincaré series of a definable set is rational; see ")#link("http://www.ams.org/mathscinet-getitem?mr=422281")[#text("Kiefe’s paper")]#text(" for details.")

#text("Below the fold I give a proof of Theorem ")#link(<tao-8adf139a3aab4602ce7b>)[#text("1")]#text(", which relies primarily on the Lang-Weil bound mentioned above.")

#metadata(none) <tao-f7aaccdb615469acb88d>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("Fix a nonstandard finite field ")#mi("{F = \\prod_{m \\rightarrow p} F_m}")#text(" of characteristic zero. Let us temporarily define a ")#emph[#text("basic set")]#text(" to be a set ")#link(<tao-a7e7e2f59b128bdb0aa6>)[#text("(2)")]#text(" for some atomic definable set ")#mi("{V}")#text(" and some polynomial ")#mi("{P}")#text(", and a ")#emph[#text("good set")]#text(" to be a finite union of basic sets in some vector space ")#mi("{F^n}")#text(". Our objective is thus to show that all definable sets are good.")

#text("Clearly, every atomic definable set is already a basic set, and is thus certainly good. Given the relationship between atomic definable sets and all definable sets, it thus suffices to show that the class of good sets are closed under boolean operations (e.g. union, intersection, negation) and projection. Closure under unions is automatic by definition; the interesting and difficult closure properties are projection and negation. (Closure under intersection is, strictly speaking, a consequence of closure under unions and negations, thanks to ")#link("http://en.wikipedia.org/wiki/De_Morgan's_laws")[#text("de Morgan’s laws")]#text("; but it turns out to be convenient to obtain closure under intersection first as a stepping stone to closure under negation.)")

#text("We first observe that we may place good sets in a suitable “normal form”. Let ")#mi("{\\overline{F}}")#text(" be the algebraic closure of ")#mi("{F}")#text(". This is an algebraically closed field that has a nonstandard Frobenius endomorphism ")#mi("{Frob: \\overline{F} \\rightarrow \\overline{F}}")#text(", defined as the ultralimit of the Frobenius maps ")#tao-math("{x \\mapsto x^{\\left|F_m\\right|}}", block: false)#text(" on each of the finite fields ")#mi("{F_m}")#text(". This is a nonstandard automorphism of ")#mi("{\\overline{F}}")#text(" whose fixed points are precisely ")#mi("{F}")#text(". An atomic definable set over ")#mi("{F}")#text(" is the same thing as the ")#mi("{F}")#text("-points ")#mi("{V(F)}")#text(" of an variety ")#mi("{V}")#text(" over ")#mi("{\\overline{F}}")#text(" which is invariant with resspect to the Frobenius automorphism (this can be established for instance by inspecting a reduced Grobner basis for the associated ideal). Such a variety can be decomposed over ")#mi("{\\overline{F}}")#text(" into ")#link("http://en.wikipedia.org/wiki/Absolutely_irreducible")[#text("absolutely irreducible")]#text(" components. Some of these components may remain Frobenius-invariant and will thus continue to be defined over ")#mi("{F}")#text(". If a component is not Frobenius invariant, we may intersect it with all of its Frobenius conjugates without losing any of its ")#mi("{F}")#text("-points; by the ")#link("http://en.wikipedia.org/wiki/Noetherian_ring")[#text("Noetherian property")]#text(", this will reduce that component to an absolutely irreducible variety defined over ")#mi("{F}")#text(". Thus, every variety defined over ")#mi("{F}")#text(" can be replaced with a union of finitely many absolutely irreducible varieties defined over ")#mi("{F}")#text(", without losing or gaining any ")#mi("{F}")#text("-points. From this, we see that any good set can be placed in a form in which all of the varieties involved are absolutely irreducible.")

#text("Now consider a basic set of the form")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): \\exists t \\in F: P(x,t) = 0 \\}")]]

#text("with ")#mi("{V}")#text(" absolutely irreducible. We consider the constant term ")#mi("{P_0(x) := P(x,0)}")#text(" of ")#mi("{P}")#text(". If this term vanishes identically on ")#mi("{V}")#text(", then this basic set is all of ")#mi("{V(F)}")#text(". Otherwise, observe that we may factorise")

#align(center)[#tao-fit-display[#mitex("P(x,P_0(x)t) = P_0(x) Q(x,t)")]]

#text("for some polynomial ")#mi("{Q(x,t)}")#text(" with ")#mi("{Q(x,0) \\equiv 1}")#text(", and then")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): \\exists t \\in F: P(x,t) = 0 \\} = \\{ x \\in V(F): P_0(x) = 0 \\} \\cup \\{ x \\in V(F): \\exists t \\in F: Q(x,t) = 0 \\}.")]]

#text("From this, we see that any good set can be expressed as the union of the ")#mi("{F}")#text("-points of a variety (i.e. an atomic definable set) and finitely many basic sets which have ")#emph[#text("unit constant term")]#text(" in the sense that they have the form")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): \\exists t \\in F: P(x,t) = 0 \\}")]]

#text("with ")#mi("{V}")#text(" absolutely irreducible and ")#mi("{P(x,0) \\equiv 1}")#text(".")

#text("This leads us to the following useful lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Hypersurface removal)")]#text(" ")#metadata(none) <tao-91e235e3f8168853b4d9>#text(" Let ")#mi("{E}")#text(" be a good set in ")#mi("{F^n}")#text(", and let ")#mi("{Q: \\overline{F}^n \\rightarrow \\overline{F}}")#text(" be a polynomial. Then ")#mi("{\\{ x \\in E: Q(x) \\neq 0 \\}}")#text(" is also good.")
]

#emph[#text("Proof:")]#text(" By replacing ")#mi("{Q}")#text(" with its norm over the polynomials over ")#mi("{F}")#text(", we may assume that ")#mi("{Q}")#text(" takes coefficients in ")#mi("{F}")#text(". By the preceding discussion, it suffices to establish this in the case when ")#mi("{E}")#text(" is either the ")#mi("{F}")#text("-points ")#mi("{V(F)}")#text(" an irreducible variety ")#mi("{V}")#text(", or a basic set on such a variety with unit constant term. In the former case, we simply note that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): Q(x) \\neq 0 \\} = \\{ x \\in V(F): \\exists t: Q(x) t - 1 = 0 \\}.")]]

#text("In the latter case, we observe that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): (\\exists t \\in F: P(x,t)=0) \\wedge Q(x) \\neq 0 \\} = \\{ x \\in V(F): \\exists t: P(x,Q(x) t)=0 \\}")]]

#text("whenever ")#mi("{P}")#text(" has unit constant term. ")#mi("\\Box")

#text("This allows us to generalise ")#mi("{V}")#text(" to be constructible rather than algebraic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" ")#metadata(none) <tao-2edc49b4fe3226c45c8b>#text(" Any set of the form ")#mi("{\\{ x \\in V(F): \\exists t \\in F: P(x,t)=0\\}}")#text(", where ")#mi("{V(F)}")#text(" is a quantifier-free definable set (i.e. the ")#mi("{F}")#text("-points of a constructible set), and ")#mi("{P}")#text(" is a polynomial from ")#mi("{\\overline{F}^{n+1}}")#text(" to ")#mi("{\\overline{F}}")#text(", is good.")
]

#emph[#text("Proof:")]#text(" Again, we may assume ")#mi("{P}")#text(" takes coefficients in ")#mi("{F}")#text(". A constructible set can be expressed as the union of finitely many ")#link("http://en.wikipedia.org/wiki/Quasiprojective_variety")[#text("quasiprojective varieties")]#text(" (i.e. the set-theoretic difference of two affine varieties). A quasiprojective variety ")#mi("{V \\backslash W}")#text(" can be written as the finite union of sets of the form ")#mi("{\\{ x \\in V: Q(x) \\neq 0\\}}")#text(" for various polynomials ")#mi("{Q}")#text(", and the claim then follows from the preceding lemma. ")#mi("\\Box")

#text("Now we can handle images of constructible sets with ")#mi("{0}")#text("-dimensional fibres:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-6199aecf23aba7e87b2d>#text(" Let ")#mi("{V, W}")#text(" be constructible sets defined over ")#mi("{F}")#text(" with irreducible Zariski closures, and let ")#mi("{\\phi: V \\rightarrow W}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Regular_map_(algebraic_geometry)")[#text("regular map")]#text(", also defined over ")#mi("{F}")#text(", with the property that all fibres ")#mi("{\\phi^{-1}(\\{w\\})}")#text(", ")#mi("{w \\in W}")#text(" are zero-dimensional. Then ")#mi("{\\phi(V(F)) = \\{ \\phi(v): v \\in V(F) \\}}")#text(" is good. (In particular, the set of ")#mi("{F}")#text("-points of any constructible set is a good set.)")
]

#emph[#text("Proof:")]#text(" By restricting ")#mi("{V}")#text(" if necessary, we may assume that ")#mi("{\\phi}")#text(" is ")#link("http://en.wikipedia.org/wiki/Dominant_morphism")[#text("dominant")]#text(". The field ")#mi("{F(V)}")#text(" of ")#mi("{F}")#text("-valued rational functions on ")#mi("{V}")#text(" can then be viewed as a field extension of ")#mi("{F(W)}")#text(" (using the pullback map by ")#mi("{\\phi}")#text("); as the fibres are zero-dimensional, this extension has transcendence degree zero, i.e. it is algebraic. By the ")#link("http://en.wikipedia.org/wiki/Primitive_element_theorem")[#text("primitive element theorem")]#text(" (and it is here that we are using our hypothesis that ")#mi("{F}")#text(" has characteristic zero, to ensure that the field extension is separable), ")#mi("{F(V)}")#text(" is generated by ")#mi("{F(W)}")#text(" and a rational function ")#mi("{f}")#text(" on ")#mi("{V}")#text(", which by clearing denominators one can assume to be integral with respect to the polynomial ring ")#mi("{F[W]}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("R( f(x), \\phi(x) ) = 0")]]

#text("for some polynomial ")#mi("{R}")#text(" with coefficients in ")#mi("{F}")#text(" with ")#mi("{R}")#text(" monic as a polynomial over ")#mi("{F[W]}")#text(". Each of the coordinate functions ")#mi("{x_1,\\ldots,x_n}")#text(" on the affine variety ")#mi("{V}")#text(" can then be viewed (again after clearing denominators) as a polynomial (over ")#mi("{F[W]}")#text(") in ")#mi("{f}")#text(", divided by some non-trivial polynomial ")#mi("{Q \\in F[W]}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("x_i = P_i( f(x), \\phi(x) ) / Q(\\phi(x)).")]]

#text("for all ")#mi("{i=1,\\ldots,n}")#text(" and all ")#mi("{x = (x_1,\\ldots,x_n)}")#text(" in ")#mi("{V}")#text(", and some polynomials ")#mi("{P_i}")#text(" with coefficients in ")#mi("{F}")#text(". From this, we see that for any ")#mi("{w \\in W(F)}")#text(" with ")#mi("{Q(w) \\neq 0}")#text(", ")#mi("{\\phi^{-1}( \\{w\\})}")#text(" has an ")#mi("{F}")#text("-point if and only if ")#mi("{R(\\cdot,w)}")#text(" has a root in ")#mi("{F}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\phi(V(F)) = \\{ w \\in W(F): Q(w) \\neq 0; \\exists t: R(t,w) = 0 \\} \\cup (\\phi(V(F)) \\cap \\{ Q = 0 \\}).")]]

#text("Using Corollary ")#link(<tao-2edc49b4fe3226c45c8b>)[#text("3")]#text(" and an induction hypothesis on the dimension of ")#mi("{W}")#text(" to deal with the residual term ")#mi("{\\phi(V(F)) \\cap \\{ Q = 0 \\}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Next, we record an important property of infinite pseudofinite fields, known as the ")#link("http://en.wikipedia.org/wiki/Pseudo_algebraically_closed_field")[#text("pseudo algebraically closed (PAC) axiom")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (PAC axiom)")]#text(" ")#metadata(none) <tao-eade1e1268e28e35a4b7>#text(" Let ")#mi("{V}")#text(" be an absolutely irreducible variety defined over ")#mi("{F}")#text(". Then ")#mi("{V(F)}")#text(" is non-empty. Furthermore, for any Zariski-dense constructible subset ")#mi("{W}")#text(" of ")#mi("{V}")#text(", ")#mi("{W(F)}")#text(" is non-empty also.")
]

#emph[#text("Proof:")]#text(" We write ")#mi("{V}")#text(" as an ultralimit of varieties ")#mi("{V_m}")#text(" defined over ")#mi("{F_m}")#text(". As ")#mi("{V}")#text(" is absolutely irreducible, we have ")#mi("{V_m}")#text(" absolutely irreducible with dimension ")#mi("{\\text{dim}(V)}")#text(" for ")#mi("{m}")#text(" close to ")#mi("{p}")#text(" (see Lemma 3 and Lemma 8 of ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text("), and so by the Lang-Weil bound (see ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous blog post")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\left|V_m(F_m)\\right| = (1 + O(\\left|F_m\\right|^{-1/2})) \\left|F_m\\right|^{\\text{dim}(V)}.", block: true)]]

#text("Since ")#tao-math("{\\left|F_m\\right|}", block: false)#text(" goes to infinity as ")#mi("{m \\rightarrow p}")#text(", we conclude that ")#mi("{V_m(F_m)}")#text(" is non-empty for ")#mi("{m}")#text(" sufficiently close to ")#mi("{p}")#text(", and so ")#mi("{V(F)}")#text(" is non-empty also by Los’s theorem. The same argument works for ")#mi("{W(F)}")#text(", using the Schwarz-Zippel bound from the previous post to handle the set removed from ")#mi("{V}")#text(" to form ")#mi("{W}")#text(". ")#mi("\\Box")

#text("We can now establish closure with respect to projection:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-5694d08a2e53ffcae0c3>#text(" If ")#mi("{E \\subset F^{n+1}}")#text(" is good, then ")#mi("{\\pi_n(E) \\subset F^n}")#text(" is also good.")
]

#emph[#text("Proof:")]#text(" It suffices to establish that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in F^n: \\exists s,t \\in F: (x,s,t) \\in V(F) \\}")]]

#text("is a good set whenever ")#mi("{V(F)}")#text(" is a constructible subset of ")#mi("{F^{n+2}}")#text(". Let ")#mi("{\\pi}")#text(" be the projection map from ")#mi("{V}")#text(" to ")#mi("{\\overline{F}^n}")#text(", so our task is to show that ")#mi("{\\pi(V(F))}")#text(" is good. By decomposing ")#mi("{V}")#text(", we may assume that ")#mi("{V}")#text(" has irreducible closure, and that all the fibres of ")#mi("{\\pi}")#text(" in ")#mi("{\\pi(V)}")#text(" have the same dimension, which is either ")#mi("{0}")#text(", ")#mi("{1}")#text(", or ")#mi("{2}")#text(". If the fibres have dimension ")#mi("{2}")#text(", then by the PAC axiom ")#mi("{\\pi(V(F)) = \\pi(V)(F)}")#text(", and the claim follows from Corollary ")#link(<tao-2edc49b4fe3226c45c8b>)[#text("3")]#text(". If the fibres have dimension ")#mi("{0}")#text(", the claim follows instead from Proposition ")#link(<tao-6199aecf23aba7e87b2d>)[#text("4")]#text(". So the only remaining case is when the fibres are one-dimensional curves.")

#text("We can work generically in ")#mi("{V}")#text(", since the contribution of any subvariety of ")#mi("{V}")#text(" of strictly smaller dimension can be handled by an induction hypothesis. Generically, the fibre over a point ")#mi("{x \\in V}")#text(" is then given by a curve ")#mi("{\\{ (s,t): P(x,s,t) = 0 \\}}")#text(" for some polynomial ")#mi("{P}")#text(" defined over ")#mi("{F}")#text(". If ")#mi("{x}")#text(" is an ")#mi("{F}")#text("-point of ")#mi("{V}")#text(", then by the PAC axiom, this curve contains an ")#mi("{F}")#text("-point in the plane ")#mi("{F^2}")#text(" if and only if ")#mi("{P(x,\\cdot,\\cdot)}")#text(", viewed as a polynomial of two variables, contains an absolutely irreducible factor defined over ")#mi("{F}")#text(". If one fixes the degree ")#mi("{d}")#text(" of this factor, this is a definable constraint on ")#mi("{d+1}")#text(" coefficients, and by Proposition ")#link(<tao-6199aecf23aba7e87b2d>)[#text("4")]#text(", the set of ")#mi("{x \\in V(F)}")#text(" for which this constraint is obeyed is a good set. Letting ")#mi("{d}")#text(" vary from ")#mi("{1}")#text(" to ")#mi("{\\text{deg}(P)}")#text(" and taking unions, we obtain the claim. ")#mi("\\Box")

#text("From closure under projection, we can deduce closure under intersection:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7")]#text(" ")#metadata(none) <tao-c84c8016356014e02b04>#text(" The intersection of two good sets in ")#mi("{F^n}")#text(" is again a good sets in ")#mi("{F^n}")#text(".")
]

#emph[#text("Proof:")]#text(" It suffices to show that the intersection of two basic sets")

#align(center)[#tao-fit-display[#mitex("E = \\{ x \\in V(F): \\exists t: P(x,t) = 0 \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("E^{\\prime} = \\{ x \\in V^{\\prime}(F): \\exists t^{\\prime}: P^{\\prime}(x,t^{\\prime}) = 0 \\}")]]

#text("in ")#mi("{F^n}")#text(" is good. But observe that ")#mi("{E \\cap E^{\\prime}}")#text(" can be obtained from the atomic definable (and hence basic) set ")#mi("{\\{ (x,t,t^{\\prime}) \\in F^{n+2}: x \\in V \\cap V^{\\prime}; P(x,t)=P^{\\prime}(x,t^{\\prime})=0 \\}}")#text(" by applying two projections, so the claim follows from two applications of Corollary ")#link(<tao-5694d08a2e53ffcae0c3>)[#text("6")]#text(". ")#mi("\\Box")

#text("The only remaining task is to show closure under negation. To get a hint of how to proceed on this, consider again the example of the quadratic residues in ")#mi("{F}")#text(": ")#metadata(none) <tao-8b5cc4df7eec7d32a781>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("E := \\{ x \\in F: \\exists t \\in F: x = t^2 \\}.")]]

#text("One can almost describe the complement of this set by selecting a non-quadratic residue ")#mi("{\\epsilon}")#text(" of ")#mi("{F}")#text(" and using the set ")#metadata(none) <tao-ac0f09c0f8bf5e7a4b06>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\{ x \\in F: \\exists t \\in F: x = \\epsilon t^2 \\},")]]

#text("though this is not quite the complement of ")#mi("{E}")#text(" and one has to delete the origin, for instance by using Lemma ")#link(<tao-91e235e3f8168853b4d9>)[#text("2")]#text(". Applying the algorithm implicit in the proof of that lemma, one ends up with")

#align(center)[#tao-fit-display[#mitex("F \\backslash E = \\{ x \\in F: \\exists t \\in F: 1 = \\epsilon x t^2 \\}")]]

#text("as an explicit representation of the non-quadratic residues as a basic set.")

#text("The selection of an arbitrary non-quadratic residue ")#mi("{\\epsilon}")#text(" may seem like a rather ")#emph[#text("ad hoc")]#text(" step to take in the above example, which does not initially bode well for generalisation to other definable sets. However, one can make the argument a bit more “canonical” by a bit of Galois theory. Note that while an arbitrary element ")#mi("{x}")#text(" of ")#mi("{F}")#text(" need not necessarily have a square root ")#mi("{t}")#text(" in ")#mi("{F}")#text(", it always has a square root ")#mi("{t}")#text(" in the (unique) quadratic extension ")#mi("{F_{(2)}}")#text(" of ")#mi("{F}")#text(". Of course, ")#mi("{-t}")#text(" will also be a square root. Letting ")#mi("{\\sigma}")#text(" be the Galois conjugation of ")#mi("{F_{(2)}}")#text(" over ")#mi("{F}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\sigma(t)^2 = \\sigma(t^2) = \\sigma(x) = x = t^2")]]

#text("and so ")#mi("{\\sigma(t)}")#text(" is equal to either ")#mi("{t}")#text(" or ")#mi("{-t}")#text(". In the former case, ")#mi("{x}")#text(" is a quadratic residue; otherwise, it is a non-quadratic residue. (Let us ignore the situation when ")#mi("{x=0}")#text(", as Lemma ")#link(<tao-91e235e3f8168853b4d9>)[#text("2")]#text(" and Corollary ")#link(<tao-c84c8016356014e02b04>)[#text("7")]#text(" give us enough tools to deal with what is going on exceptional sets of lower-dimensional varieties.) Thus, outside of the point ")#mi("{\\{0\\}}")#text(", we can express ")#mi("{E}")#text(" as the set of ")#mi("{x}")#text(" for which one has ")#mi("{\\sigma(t)=t}")#text(" for the two square roots ")#mi("{\\{t \\in \\overline{F}: x=t^2\\}}")#text(", and the complement as the set of ")#mi("{x}")#text(" for which ")#mi("{\\sigma(t)=-t}")#text(" (extending ")#mi("{\\sigma}")#text(" from ")#mi("{F_{(2)}}")#text(" to ")#mi("{\\overline{F}}")#text(" in some arbitrary manner if desired). The descriptions of ")#mi("{E}")#text(" and its (near-)complement in ")#link(<tao-8b5cc4df7eec7d32a781>)[#text("(3)")]#text(", ")#link(<tao-ac0f09c0f8bf5e7a4b06>)[#text("(4)")]#text(" can be viewed as (shadows of) “norms” of the above assertions ")#mi("{\\sigma(t)=t}")#text(", ")#mi("{\\sigma(t)=-t}")#text(" in some sense. This suggests that more generally, given a basic set ")#mi("{E}")#text(" on a variety ")#mi("{V}")#text(", one can use Galois theory to naturally partition ")#mi("{V(F)}")#text(" (outside of some exceptional set of smaller dimension) into disjoint components, one of which is ")#mi("{E}")#text(", and all of which can be described as unions of basic sets, which would lead to the desired closure property with respect to negation. (Not coincidentally, a very similar trick was used in Bombieri’s version of Stepanov’s proof of the Hasse-Weil bound discussed in ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous post")]#text(", in which an upper bound on ")#mi("{V(F)}")#text(" for curves ")#mi("{V}")#text(" was converted into a matching lower bound.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" The complement of a good set in ")#mi("{F^n}")#text(" is again a good set.")
]

#emph[#text("Proof:")]#text(" In view of Corollary ")#link(<tao-c84c8016356014e02b04>)[#text("7")]#text(" and de Morgan’s laws, it suffices to show that the complement of a basic set ")#mi("{\\{ x \\in V(F): \\exists t \\in F: P(x,t) = 0 \\}}")#text(" in ")#mi("{F^n}")#text(" is a good set, whenever ")#mi("{V}")#text(" is absolutely irreducible and defined over ")#mi("{F}")#text(". From Proposition ")#link(<tao-6199aecf23aba7e87b2d>)[#text("4")]#text(", we already know that ")#mi("{F^n \\backslash V(F)}")#text(" is a good set, so it suffices to show that the set")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V(F): \\not \\exists t \\in F: P(x,t) = 0 \\}")]]

#text("is good. By an induction on the dimension of ")#mi("{V}")#text(", we may freely delete any lower-dimensional component of ")#mi("{V}")#text(", thus it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in V^{\\prime}(F): \\not \\exists t \\in F: P(x,t) = 0 \\}")]]

#text("is good for some generic subset ")#mi("{V^{\\prime}}")#text(" of ")#mi("{V}")#text(".")

#text("By an induction on the degree of ")#mi("{P}")#text(", and Corollary ")#link(<tao-c84c8016356014e02b04>)[#text("7")]#text(", we may assume that ")#mi("{P}")#text(" is absolutely irreducible on ")#mi("{V \\times \\overline{F}}")#text(". In particular, ")#mi("{P}")#text(" and ")#mi("{\\partial_t P}")#text(" have no common factor (here we are again implicitly using the characteristic zero hypothesis), and so for generic ")#mi("{x \\in V}")#text(", ")#mi("{P(x,\\cdot)}")#text(" and ")#mi("{\\partial_t P(x,\\cdot)}")#text(" have no common zero (otherwise their resultant would vanish generically, leading to a common factor). If we write")

#align(center)[#tao-fit-display[#mitex("P(x,t) = P_d(x) t^d + \\ldots + P_0(x)")]]

#text("for some polynomials ")#mi("{P_0,\\ldots,P_d}")#text(" on ")#mi("{V}")#text(" with ")#mi("{P_d}")#text(" generically non-zero on ")#mi("{V}")#text(", we thus see that for generic ")#mi("{x \\in V(F)}")#text(", ")#mi("{P(x,\\cdot)}")#text(" has ")#mi("{d}")#text(" distinct zeroes in ")#mi("{\\overline{F}}")#text(". Indeed, recalling that any finite field ")#mi("{F_m}")#text(" has a unique extension ")#mi("{F_{m,(d)}}")#text(" of degree ")#mi("{d}")#text(", ")#mi("{F}")#text(" has a unique extension ")#mi("{F_{(d)}}")#text(" of degree ")#mi("{d}")#text(", and all the ")#mi("{d}")#text(" zeroes of ")#mi("{P(x,\\cdot)}")#text(" lie in this extension.")

#text("It is a standard fact from Galois theory that ")#mi("{F_{m,(d)}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Galois_extension")[#text("Galois extension")]#text(" of ")#mi("{F_m}")#text(", with the Galois group isomorphic to ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(" and generated by the Frobenius endomorphism ")#tao-math("{Frob_{F_m}: x \\mapsto x^{\\left|F_m\\right|}}", block: false)#text("; taking ultralimits, we see that ")#mi("{F_{(d)}}")#text(" is also a Galois extension of ")#mi("{F}")#text(", with Galois group again isomorphic to ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(" and generated by the ultralimit ")#mi("{Frob_F}")#text(" of the standard Frobenius endomorphisms ")#mi("{Frob_{F_m}}")#text(". For any generic ")#mi("{x \\in V(F)}")#text(", the ")#mi("{d}")#text(" distinct zeroes ")#mi("{t_1,\\ldots,t_d}")#text(" of ")#mi("{P(x,\\cdot)}")#text(" are acted upon by the Frobenius map. Thus, there exists a permutation ")#mi("{\\sigma:\\{1,\\ldots,d\\} \\rightarrow \\{1,\\ldots,d\\}}")#text(" such that ")#mi("{Frob_F(t_i) = t_{\\sigma(i)}}")#text(" for all ")#mi("{i=1,\\ldots,d}")#text(".")

#text("Observe that for generic ")#mi("{x \\in V(F)}")#text(" the statement ")#mi("{\\exists t \\in F: P(x,t) = 0}")#text(" holds precisely when ")#mi("{\\sigma}")#text(" has no fixed points. Thus, it suffices to show that for each permutation ")#mi("{\\sigma}")#text(", the set of generic ")#mi("{x \\in V(F)}")#text(" for which one can enumerate the zeroes of ")#mi("{P(x,\\cdot)}")#text(" as ")#mi("{t_1,\\ldots,t_d}")#text(" with the property that ")#mi("{Frob_F(t_i) = t_{\\sigma(i)}}")#text(" for all ")#mi("{i=1,\\ldots,d}")#text(", is a good set. But by viewing ")#mi("{F_{(d)}}")#text(" as a ")#mi("{d}")#text("-dimensional linear vector space over ")#mi("{F}")#text(" and expanding in terms of some arbitrarily chosen basis (cf. the factor ")#mi("{\\epsilon}")#text(" in the quadratic residue discussion), and noting that the Frobenius map is a linear transformation of this vector space, we see that this set is of the form covered by Proposition ")#link(<tao-6199aecf23aba7e87b2d>)[#text("4")]#text(", and the claim follows. (One could also avoid the use of an arbitrarily chosen basis here by working with a more abstract version of Proposition ")#link(<tao-6199aecf23aba7e87b2d>)[#text("4")]#text(", if desired.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A closer inspection of the above arguments show that there were really only two properties of the nonstandard finite field ")#mi("{F}")#text(" that were really used (besides the fact that ")#mi("{F}")#text(" was a characteristic zero field). The first was the PAC axiom (Lemma ")#link(<tao-eade1e1268e28e35a4b7>)[#text("5")]#text("). The second was the properties of the Galois group ")#mi("{Gal(\\overline{F}/F)}")#text(", namely that this group is isomorphic to the ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite integers")]#text(" ")#mi("{\\hat {\\bf Z}}")#text(" (or equivalently, that ")#mi("{F}")#text(" has precisely one field extension of each degree). It turns out that these properties in fact completely characterise infinite pseudo-finite fields, which is the main result of ")#link("http://www.ams.org/mathscinet-getitem?mr=229613")[#text("the paper of Ax")]#text(" cited previously.")
]

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-169876")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2012")])]

#text("“andrelations” -> “and relations”")#linebreak()#text(" “carindality” -> “cardinality”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomsim")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-170200")[#strong[#text("tomsim")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2012")])]

#text("The first occurence of “metoynm” looks funny, even to this mathematical layman.")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7c2955805633facd808a8fecafde7a3d9cae4beab02b1d5abf816d9089ebd78-6a396f494dc66743dcce4f94bc6ac6588f45f73fff06c1c0d3b6e427aa4ee16c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rlss")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-170203")[#strong[#text("rlss")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2012")])]

#text("R^2 should be R in definition of [1,-1]. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f47f2cb032b022b997ff56ca8bc1668cfba65e8f9abe38659d552a59a7ed092-0a803b3b109e9b423c6bf7d56632de51f65a7f8654ffd60ef188ed0d9a372f87.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neat Post Related to Formal Systems « Let Us Figure This Out")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-170360")[#strong[#text("Neat Post Related to Formal Systems « Let Us Figure This Out")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2012")])]

#text("[…] Definable subsets over (nonstandard) finite fields, and almost quantifier elimination Share this:FacebookStumbleUponRedditLike this:LikeBe the first to like this. This entry was posted in Uncategorized. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/315a1c7fbc7435212f948a53436c5876e1c01679ec9794cf04f41d52c770fdd8-0e296c7a0e5078b259560fd081cad1077e9d3e1e37ced5afff5c4250017d013d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uri Andrews")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-171275")[#strong[#text("Uri Andrews")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2012")])]

#text("Quick note: A quantifier-free definable set is not also known as a 0-definable set. 0-definable simply means definable without parameters.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba7fa688719cd72455de381de2d44008840f945b1b5b9e1d33cd27209edb1727-8d5cff39d1ed9f43f11465cbd683cf9fc41fb87560b0ea64944b7843739385fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Newman")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-171492")[#strong[#text("William Newman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2012")])]

#text("another trivial typo: ‘cosntructible’")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-172950")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")])]

#text("You mention “Cherlin-van den Dries-Macintyre”, but the paper you link to is the one by Chatzidakis, van den Dries and Macintyre…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-177727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("what you mean by( the length of the formula is uniformaly bounded in m)…")#linebreak()#text(" Which definition of uniformaly bounded did you use here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-177781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("“uniformly bounded in m” means “bounded by some quantity C that does not depend on m”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-192674")[#strong[#text("Expanding polynomials over finite fields of large characteristic, and a regularity lemma for definable sets « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2012")])]

#text("[…] out that one can essentially write all definable sets as an intersection of sets of this form; see this previous blog post for more discussion.) To regularise the set , it is convenient to square the adjacency matrix, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4bfbe02f010b00aea33cf35e2d33d55a0aeb6d3fd87dd2f26391ef65864d4f79-8ff11ea466373a7cab9d5b4be2c54cee2a832a19a19670dd80bf8c843500cd47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hgutahw")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-211541")[#strong[#text("hgutahw")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2012")])]

#text("In “a good set to be a finite union of good sets in some vector space”, the second occurrence of “good” should be replaced by “basic”.")

#emph[#text("[corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A spectral theory proof of the algebraic regularity lemma | What's new")]], [#link("https://terrytao.wordpress.com/2012/09/12/definable-subsets-over-nonstandard-finite-fields-and-almost-quantifier-elimination/#comment-249426")[#strong[#text("A spectral theory proof of the algebraic regularity lemma | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2013")])]

#text("[…] be obtained by combining the description of definable sets over pseudofinite fields (discussed in this previous post) with the Lang-Weil bound (discussed in this previous post). (The former fact is phrased using […]")
]
