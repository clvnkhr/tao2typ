// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/
// Converted to Typst by tao2typ: "2026-10-14T16:39:05.987841+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Would it be possible to create a tool to automatically diagram papers?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Would it be possible to create a tool to automatically diagram papers?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 February 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/")[#text("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This is a somewhat experimental and speculative post. This week I was at the ")#link("https://www.ipam.ucla.edu/programs/workshops/machine-assisted-proofs/")[#text("IPAM workshop on machine assisted proof")]#text(" that I was one of the organizers of. We had an interesting and diverse range of talks, both from computer scientists presenting the latest available tools to formally verify proofs or to automate various aspects of proof writing or proof discovery, as well as mathematicians who described their experiences using these tools to solve their research problems. One can find the videos of these talks on the ")#link("https://www.youtube.com/@IPAMUCLA/videos")[#text("IPAM youtube channel")]#text("; I also ")#link("https://mathstodon.xyz/@tao/109858184238417737")[#text("posted about the talks during the event")]#text(" on my ")#link("https://mathstodon.xyz/@tao")[#text("Mathstodon account")]#text(". I am of course not the most objective person to judge, but from the feedback I received it seems that the conference was able to successfully achieve its aim of bringing together the different communities interested in this topic.")

#text("As a result of the conference I started thinking about what possible computer tools might now be developed that could be of broad use to mathematicians, particularly those who do not have prior expertise with the finer aspects of writing code or installing software. One idea that came to mind was a potential tool to could take, say, an arXiv preprint as input, and return some sort of diagram detailing the logical flow of the main theorems and lemmas in the paper. This is currently done by hand by authors in some, but not all, papers (and can often also be automatically generated from formally verified proofs, as seen for instance in the ")#link("http://www.ipam.ucla.edu/wp-content/uploads/2022/01/Machine-Assisted-Proofs-graphic.jpg")[#text("graphic accompanying the IPAM workshop")]#text(", or ")#link("https://b-mehta.github.io/unit-fractions/blueprint/dep_graph_document.html")[#text("this diagram generated")]#text(" from Massot’s blueprint software from a manually inputted set of theorems and dependencies as a precursor to formalization of a proof [")#link("https://mathstodon.xyz/@thomasfbloom/109887268920513438")[#text("thanks to Thomas Bloom")]#text(" for this example]). For instance, here is a diagram that my co-author Rachel Greenfeld and I drew ")#link("https://terrytao.wordpress.com/2022/11/29/a-counterexample-to-the-periodic-tiling-conjecture-2/")[#text("for a recent paper")]#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/02/ptc-logic.png")[#image("../assets/f16c6b975545fa2ba4f8af7fffdef3d182c2f24c1638233b1a24fcd3f3c34421-d608d65d1c886c23a822916ff481809e3d7f94f1431a189703cfe191d7bd9a5b.png", width: 90%)]
]

#text("This particular diagram incorporated a number of subjective design choices regarding layout, which results to be designated important enough to require a dedicated box (as opposed to being viewed as a mere tool to get from one box to another), and how to describe each of these results (and how to colour-code them). This is still a very human-intensive task (and my co-author and I went through several iterations of this particular diagram with much back-and-forth discussion until we were both satisfied). But I could see the possibility of creating an automatic tool that could provide an initial “first approximation” to such a diagram, which a human user could then modify as they see fit (perhaps using some convenient GUI interface, for instance some variant of the ")#link("https://q.uiver.app/")[#text("Quiver online tool")]#text(" for drawing commutative diagrams in LaTeX).")

#text("As a crude first attempt at automatically generating such a diagram, one couuld perhaps develop a tool to scrape a LaTeX file to locate all the instances of the theorem environment in the text (i.e., all the formally identified lemmas, corollaries, and so forth), and for each such theorem, locate a proof environment instance that looks like it is associated to that theorem (doing this with reasonable accuracy may require a small amount of machine learning, though perhaps one could just hope that proximity of the proof environment instance to the theorem environment instance suffices in many cases). Then identify all the references within that proof environment to other theorems to start building the tree of implications, which one could then depict in a diagram such as the above. Such an approach would likely miss many of the implications; for instance, because many lemmas might not be proven using a formal proof environment, but instead by some more free-flowing text discussion, or perhaps a one line justification such as “By combining Lemma 3.4 and Proposition 3.6, we conclude”. Also, some references to other results in the paper might not proceed by direct citation, but by more indirect justifications such as “invoking the previous lemma, we obtain” or “by repeating the arguments in Section 3, we have”. Still, even such a crude diagram might still be helpful, both as a starting point for authors to make an improved diagram, or for a student trying to understand a lengthy paper to get some initial idea of the logical structure.")

#text("More advanced features might be to try to use more of the text of the paper to assign some measure of importance to individual results (and then weight the diagram correspondingly to highlight the more important results), to try to give each result a natural language description, and to somehow capture key statements that are not neatly encapsulated in a theorem environment instance, but I would imagine that such tasks should be deferred until some cruder proof-of-concept prototype can be demonstrated.")

#text("Anyway, I would be interested to hear opinions about whether this idea (or some modification thereof) is (a) actually feasible with current technology (or better yet, already exists in some form), and (b) of interest to research mathematicians.")

#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674111")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("Having a tool that diagrams the structure of a paper could be a double edged sword. It’s possible that people would start writing papers in a way that would ease the work of the software, though that may not agree with what people find easy to understand. On the other hand, quite a few papers are written in a terribly non-structured way in which case it’s difficult to find proofs and logic, and the authors would benefit from structuring their documents better.")

#text("I think TeX/LaTeX is a good example how software can change papers’ presentations: it has become much easier to write formulas, copy them from one place to another in the paper, and as a result, authors often choose formulas over helpful explanations.")

#text("Personally, I like clearly structured papers (and slides), while I like books, from which I try to learn something, to be chatty, preferably with lots of pictures. Good luck with designing software that would try to draw a dependency diagram from an input file for these books, where well chosen words and pictures may carry the main content. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e5b6dbb295b5a847ed34301f13658dcd1846580f4cbd8a1fb2409e4a538da5b-0e60bae20672c6889e31281f798565c0828d81efa24d201044a850bb599dc902.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keenan Crane")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674112")[#strong[#text("Keenan Crane")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("Hi Terry,")

#text("We’ve been working at CMU on a system called Penrose to “automatically” translate mathematics into diagrams: given purely logical statements (in plain text), generate and arrange visual icons that represent these statements. I put “automatically” in quotes since somebody has to say which icons are used to represent which statements. A bit more precisely, a collection of mathematical statements gets compiled into a constrained optimization problem; any solution to this problem is one possible diagram for the given statements. You can read about it here:")

#link("https://penrose.cs.cmu.edu/")[#text("https://penrose.cs.cmu.edu/")]#linebreak()#text(" ")#link("https://penrose.cs.cmu.edu/siggraph20")[#text("https://penrose.cs.cmu.edu/siggraph20")]

#text("And can try it out (in the browser—see gallery on left) here:")

#link("https://penrose.cs.cmu.edu/try")[#text("https://penrose.cs.cmu.edu/try")]

#text("Best,")

#text("Keenan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e5b6dbb295b5a847ed34301f13658dcd1846580f4cbd8a1fb2409e4a538da5b-0e60bae20672c6889e31281f798565c0828d81efa24d201044a850bb599dc902.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keenan Crane")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674113")[#strong[#text("Keenan Crane")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("P.S. A bit more directly related to your post, the LEAN theorem prover community is integrating Penrose-generated diagrams into LEAN. Some discussion here: ")#link("https://github.com/leanprover-community/mathlib4/pull/363")[#text("https://github.com/leanprover-community/mathlib4/pull/363")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("That certainly sounds interesting and potentially useful, especially for long, complex papers. In the same spirit, would it be possible to have corresponding diagrams for the structure of long proofs? This may be in fact easier as a single proof is more self-contained and consistently organised than a whole paper, but it may also be hard as the steps and main arguments are not clearly labelled. I have made such diagrams for myself occasionally when reading a complex proof, it would be very helpful if they were available beforehand!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("Microsoft’s large language model based on GPT3.5+/4.0 from OpenAI could do this 0-shot with just a natural language prompt and LaTeX input, if you aren’t relying on the output diagram as a rigorous source of truth. A couple days ago I saw it successfully understand and respond to someone asking about algebraic geometry using LaTeX, and separately I saw it respond to someone else with a graphviz diagram of its understanding of its own behavior. Microsoft has since restricted its available functionality but maybe you can somehow get special access. If you have connections to access internal Google things, they probably have the capability as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/163fd5ad3a94bc47dc883027302fb256a7b498c32948e8fc7c567f692be0f7e0-0be71fe52ebb864962dcd6ae927439140adcf035b8e9cb5d621011522cb9c66d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gpt anon")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676101")[#strong[#text("gpt anon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2023")])]

#text("Original anon here but now I’m putting my email address in my post meta info. Today both the OpenAI/Microsoft GPT-4 and the Google PaLM APIs have been made available but by invitation only. Professor Tao, please feel free to let me know on email or below if you would like help using them to make the app; I don’t have access myself but I feel like you could get an invitation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674145")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("Possible wish list items for such a tool:")#linebreak()#text(" 1) support optional author-provided tags (using syntax which fits as naturally as possible w/ typical paper flow) encoding info enabling better/more accurate diagrams")#linebreak()#text(" 2) accept tool-generated diagrams, possibly human-tweaked, as part of the input. (e.g. for article revision n+1, the input diagram might be that for rev n; for article revision 1, it might instead be tagged as an exemplary diagram conveying subjective design choices)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674146")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2023")])]

#text("3) Make it ez to hide/delete some/all tags in final draft")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33aa0ca824621d30155478b65bb89f98c2f0d4addd642280ce628f4709d11393-2b20b5e002a0043f73d6464557f97a96c3e09dc5f6ca2aac05bddbbbc4be4789.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Novice")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674178")[#strong[#text("Novice")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")])]

#text("GraphGPT makes knowledge graphs and if the proofs have some text clues scattered around the paper, perhaps what you ask can be done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674181")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")])]

#text("It seems useful to indicate the new concepts, ideas and techniques in the paper.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674192")[#strong[#text("Automate your automation – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2023")]

#text("[…] As a result of the conference I started thinking about what possible computer tools might now be developed that could be of broad use to mathematicians, particularly those who do not have prior expertise with the finer aspects of writing code or installing software. One idea that came to mind was a potential tool to could take, say, an arXiv preprint as input, and return some sort of diagram detailing the logical flow of the main theorems and lemmas in the paper. … (Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dd58254e3530732157fe6963fd9069d0c1f755562650bf659253cf793658162-914ce525d88a69434953fd0ec4f6fb32671ec0b217c2990c9e3473a7c5f62eb6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruno")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674243")[#strong[#text("Bruno")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2023")])]

#text("The goals here look very similar to the goals of the “Semantic Web”.")#linebreak()#text(" The proofs or papers don’t have to be written for automated theorem software,")#linebreak()#text(" they merely need to be attached with some metadata (which could be in the form of an tex comment or sidecar file).")#linebreak()#text(" The question is how one should encode the semantics of these entities.")#linebreak()#text(" A highly simplified example (a “classroom” scenario):")#linebreak()#text(" – have each proof bear a unique “identifier”")#linebreak()#text(" (could be randomly generated, like UUIDs and may bear auxiliary human readable names.")#linebreak()#text(" The identifiers themselves can be Uniform Resource Names (URN))")#linebreak()#text(" – 3 distinct proofs for “the same theorem” can be found in documents X, Y, Z.")#linebreak()#text(" (the documents are still subjected to the traditional review process)")#linebreak()#text(" – assign a unique identifier for “this theorem” (and a human readable name, possibly multiple names and multiple languages)")#linebreak()#text(" – link the identifiers of the 3 proofs above to the identifier of “this theorem”")#linebreak()#text(" (this will reside in some database which can get some sort of periodic publishes if")#linebreak()#text(" document form is desired)")

#text("IMO this whole process of tagging and linking identifiers is not completely unrelated to “citing” sources which")#linebreak()#text(" may ease the adoption for authors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d04856a71d86e64035f7493d8c69a52938de60156f7617bfd1ca6f276a632e3a-1e3a3e55fc01a81324b9d056eed8ac351268b7bcc2da606d65958d87a97de49e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucas Morin")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674247")[#strong[#text("Lucas Morin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2023")])]

#text("Maybe instead of trying to predict a graph from a paper we can start by predicting a link from a sentence… Do you have enough labelled exemples ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674333")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2023")])]

#text("Just for my amusement, I tried getting ChatGPT to make something. Given the prompt:")

#text("“Can you write me some latex / tikz code for a flow diagram showing how the sections of a paper depend on each other? Specifically,")#linebreak()#text(" – There are 7 sections, 1-7.")#linebreak()#text(" – All the seconds depend on section 1.")#linebreak()#text(" – Section 4 depends on sections 2 and 3.")#linebreak()#text(" – Section 7 depends on sections 4,5,6.")#linebreak()#text(" – Sections 5,6 depend on section 4.")#linebreak()#text(" Also, the titles of these sections are:")#linebreak()#text(" – Section 1: introduction")#linebreak()#text(" – Section 2: preliminaries")#linebreak()#text(" – Section 3: a key lemma")#linebreak()#text(" – Section 4: the core argument")#linebreak()#text(" – Section 5: bootstrapping")#linebreak()#text(" – Section 6: a technicality")#linebreak()#text(" – Section 7: the proof of the main theorem.”")

#text("It produced:")

#text("“`")#linebreak()#text(" \\documentclass{article}")#linebreak()#text(" \\usepackage{tikz}")#linebreak()#text(" \\usetikzlibrary{shapes.geometric, arrows}")

#text("\\begin{document}")#linebreak()#text(" \\begin{tikzpicture}[node distance=2cm]")

#text("% Define block styles")#linebreak()#text(" \\tikzstyle{section} = [rectangle, rounded corners, minimum width=3cm, minimum height=1cm,text centered, draw=black]")#linebreak()#text(" \\tikzstyle{arrow} = [thick,->,>=stealth]")

#text("% Nodes")#linebreak()#text(" \\node (1) [section] {Introduction (1)};")#linebreak()#text(" \\node (2) [section, below of=1] {Preliminaries (2)};")#linebreak()#text(" \\node (3) [section, below of=2] {A Key Lemma (3)};")#linebreak()#text(" \\node (4) [section, below of=3, xshift=-2cm] {The Core Argument (4)};")#linebreak()#text(" \\node (5) [section, below of=4, xshift=-2cm] {Bootstrapping (5)};")#linebreak()#text(" \\node (6) [section, below of=4, xshift=2cm] {A Technicality (6)};")#linebreak()#text(" \\node (7) [section, below of=4, xshift=4cm] {Proof of the Main Theorem (7)};")

#text("% Arrows")#linebreak()#text(" \\draw [arrow] (1) -‐ (2);")#linebreak()#text(" \\draw [arrow] (1) -‐ (3);")#linebreak()#text(" \\draw [arrow] (2) -‐ (4);")#linebreak()#text(" \\draw [arrow] (3) -‐ (4);")#linebreak()#text(" \\draw [arrow] (4) -‐ (5);")#linebreak()#text(" \\draw [arrow] (4) -‐ (6);")#linebreak()#text(" \\draw [arrow] (4) -‐ (7);")#linebreak()#text(" \\draw [arrow] (5) -‐ (7);")#linebreak()#text(" \\draw [arrow] (6) -‐ (7);")

#text("\\end{tikzpicture}")#linebreak()#text(" \\end{document}")#linebreak()#text(" “`")

#text("It does indeed compile. Some of the boxes overlap each other, but I guess it hasn’t figured that out yet. Otherwise I think it got everything right.")

#text("I think there is a real danger that by the time a dedicated tool had been completed, the next general purpose engine would be better than it.")

#text("[Apologies for any formatting weirdness.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674334")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2023")])]

#text("P.S. As shown, I always try to pose my questions to the engine politely. You never know — it might make all the difference some day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674476")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("Hi the latex document generated by ChatGPT does not compile for me (texlive2019) error is")#linebreak()#text(" ./testproof-diagram.tex:22: Package tikz Error: Giving up on this path. Did you forget a semicolon?.")

#text("See the tikz package documentation for explanation.")#linebreak()#text(" Type H for immediate help.")#linebreak()#text(" …")

#text("l.22 \\draw [arrow] (1) —")#linebreak()#text(" (2);")

#text("Uwe Brauer")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674499")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("It looks like two consecutive hyphens were somehow changed into a long hyphen (m dash).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674508")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2023")])]

#text("Oh right, good catch — I tried to embed it as a code block but failed, and then WordPress outsmarted me and did all the usual formatting substitutions. Next time I’ll ask ChatGPT to output it in markdown directly.")

#emph[#text("[I think I managed to fix the hyphen formatting – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7016bce998be5eb16fca73ffdd3df09512dbe48d0c414d984810033f73cca72d-249c6526ee8f92a7f6c419ac7633faa643d6487b529fbdb1c9e95eb8d1a91eeb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ObeyGPT (Beta)")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674538")[#strong[#text("ObeyGPT (Beta)")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2023")])]

#text("The same request yields this no-box-overlap code and makes me wonder if there is a fixed point theorem associated with repeated requests:")

#text("\\documentclass{article}")#linebreak()#text(" \\usepackage{tikz}")

#text("\\begin{document}")

#text("\\begin{tikzpicture}[->,>=stealth,shorten >=1pt,auto,node distance=3.5cm,")#linebreak()#text(" thick,main node/.style={rectangle,draw,font=\\Large\\bfseries}]")

#text("\\node[main node] (1) {Introduction};")#linebreak()#text(" \\node[main node] (2) [below left of=1] {Preliminaries};")#linebreak()#text(" \\node[main node] (3) [below right of=1] {Key Lemma};")#linebreak()#text(" \\node[main node] (4) [below of=2] {Core Argument};")#linebreak()#text(" \\node[main node] (5) [below left of=4] {Bootstrapping};")#linebreak()#text(" \\node[main node] (6) [below right of=4] {Technicality};")#linebreak()#text(" \\node[main node] (7) [below of=4] {Proof of Main Theorem};")

#text("\\path[every node/.style={font=\\sffamily\\small}]")#linebreak()#text(" (1) edge (2)")#linebreak()#text(" edge (3)")#linebreak()#text(" (2) edge (4)")#linebreak()#text(" (3) edge (4)")#linebreak()#text(" (4) edge (5)")#linebreak()#text(" edge (6)")#linebreak()#text(" edge (7)")#linebreak()#text(" (5) edge [bend right] (4)")#linebreak()#text(" (6) edge [bend left] (4)")#linebreak()#text(" (7) edge [bend right] (4);")

#text("\\end{tikzpicture}")

#text("\\end{document}")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a02c40859685b420aa7ec7b78bc4cebfa349f201e40d5226555971998a8042b-89b7f2f7d96bb8da79018adc603ca2182ad8549663683a68dfe464bb98a61936.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gianmarco")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674392")[#strong[#text("Gianmarco")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2023")])]

#text("This would definitely be(come) a great arXivlabs project.")#linebreak()#text(" (Maybe the technology behind ar5iv can also be used to this end?)")

#text("A similar tool has already been developed within LaTeX, using this package ")#link("https://github.com/michal-h21/rdfref")[#text("https://github.com/michal-h21/rdfref")]#linebreak()#text(" See ")#link("https://tex.stackexchange.com/questions/170480/show-graph-of-references-inside-a-document")[#text("https://tex.stackexchange.com/questions/170480/show-graph-of-references-inside-a-document")]#text(" .")

#text("On a logical/design point of view, what about extracting “wiring diagrams” rather than graphs?")#linebreak()#text(" The string diagrams from the book “Seven Sketches in Compositionality” seem well suited for the task, allowing one to (black)box an argument, that can be used in another diagram.")#linebreak()#text(" But maybe this is for the future generations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674433")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2023")])]

#text("Diagramming tools have been around forever, “Pic” being an early example ( ")#link("https://en.wikipedia.org/wiki/PIC_(markup_language)")[#text("https://en.wikipedia.org/wiki/PIC_(markup_language)")]#text(" ). I think Graphviz ( ")#link("https://en.wikipedia.org/wiki/Graphviz")[#text("https://en.wikipedia.org/wiki/Graphviz")]#text(" ) is a current favourite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674631")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2023")])]

#text("PROF i shared this wounderful website in my Facebook page thanks for sharing YOUR experience with us)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674639")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2023")])]

#text("PROF why i didn’t recive an email when YOU published new post thanks)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-674642")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2023")])]

#text("I wrote in my Facebook page that this is the best website to learn advanced mathematics)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9e5f6e8d2d74e07c6e4ab8023916ec2cde220c5de8e9e3b3e3159326df4a6c3-93c87ecfad00e7b6ef4b38b3da2440fd48aebec9058bd0087abae49c19b20d4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yoann Trellu")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-675809")[#strong[#text("Yoann Trellu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2023")])]

#text("I manually created this graph, detailing the Pythagoras theorem using Tarski’s geometry and his book. The formatting is rather poor, nodes unlabelled, but the links are there.")#linebreak()#text(" ")#link("https://ytrellu.com/graph_pythagoras.png")[#image("../assets/d041b354068aa708a73c10870da4b1bef490fe53725067af2fb5e9d6a9887ac2-c3c8e64e57b306e13e10e633443fea4f54003b711448180d5a9647bd20aa35c5.png", width: 90%)]

#text("Also very interested in tools for visualization, not only for math, but also for any process that can be modeled as a finite-state automata.. Applications to pedagogy & documentation would be significant!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-675827")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("What does the pic mean? The dependence of chapters on the Pythagoras thm? And can you send a pic (or a link to it) with a much greater resolution? On this one, we cannot see what the nodes are.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9e5f6e8d2d74e07c6e4ab8023916ec2cde220c5de8e9e3b3e3159326df4a6c3-93c87ecfad00e7b6ef4b38b3da2440fd48aebec9058bd0087abae49c19b20d4e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yoann Trellu")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-675830")[#strong[#text("Yoann Trellu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("Correct, or to be more precise, the dependency on numbered lemmas, corollaries, propositions and theorems for the Pythagoras theorem (PT). It is a directed acyclic graph, whose source is PT, and sinks are Tarski’s axioms.")#linebreak()#text(" I’ll look into the associated graphviz code to see if I can link a better resolution image")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63c5e3d164b60dbf2c30b341adc5ad73b787518ecb74470ab6a00431ab9dc71a-de3e719e9960b0a44f0116a1201823a8b5ddfd465aacf6c51ba7363425eb9495.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuyao")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676643")[#strong[#text("liuyao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2023")])]

#text("It’s very nice to see all the different attempts, as that’s something I’ve thought to do. Here’s what I left off, if it’s of any use, ")#link("https://observablehq.com/@neobourbaki/tools")[#text("https://observablehq.com/@neobourbaki/tools")]#text(" . Basically it relies on digraph, a javascript tool, to draw directed graphs with simple commands (you specific the nodes and arrows, and they arrange everything in a plane). Not so much easier than tikz, but one could try to take a LaTeX file as input…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12a2829e0040623a16c8f47fc89b6eec518e163cae67bf077179223992208d4a-ca5ce197c201526630d94a4c2f9b1b522f5b37794ee0c7df3f17f13d34a04401.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676653")[#strong[#text("Marcelo")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2023")])]

#text("What (if anything) is the “Scrivener for math papers”? It wouldn’t help with what was already written, but improving structure-inducing writing tools might be an easier technical ask than structure-inferring reading tools. (I’m thinking of the “semantic” aspects of Scrivener, not just facilities for links or outlining.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5da67daa7fceed2c545f7731b4ace2fbd0bec59c00656a5d621c5d6d2524fbfb-6c9130e41aeee9bad8248e55556487669a8701e2546134dba6ac117e66a84935.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chevallier augustin")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676744")[#strong[#text("chevallier augustin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2023")])]

#text("I have been working on some software to solve this exact question:")#linebreak()#text(" ")#link("https://github.com/augustin-chevallier/MathResultsGraph")[#text("https://github.com/augustin-chevallier/MathResultsGraph")]

#text("It takes a Latex file (where the dependency between theorems/ lemmas are manually added), and then creates an interactive graph that can be displayed/edited in a webpage.")

#text("Here is some WIP example: ")#link("http://www.emmanuelchevallier.eu/graphSite/graph_split.html")[#text("http://www.emmanuelchevallier.eu/graphSite/graph_split.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5da67daa7fceed2c545f7731b4ace2fbd0bec59c00656a5d621c5d6d2524fbfb-6c9130e41aeee9bad8248e55556487669a8701e2546134dba6ac117e66a84935.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chevallier augustin")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676745")[#strong[#text("chevallier augustin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2023")])]

#text("Here is an example screenshot (which I hope will be displayed by wordpres…):")#linebreak()#text(" ")#link("https://github.com/augustin-chevallier/MathResultsGraph/raw/main/examples/graphEx2.png")[#image("../assets/2505ebfcbd360afcd1c1c0d5e029c7247b3a07fbfaff529152a8c5112cb6a733-2e80a3fa935959aea967038a309e08ed5f850c12729a2a054c147102122f6b91.png", width: 90%)]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2682e3eb3732070462f0e48c8a148bd0515f9ec16833377e7985d996c971cd66-8c6581efb2b67ee800b97689f0dfe329cb395bc17353edd6643c436de48de5ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676851")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2023")])]

#text("ChatGPT can definitely do it")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("Uwe Brauer pointed me to some latex style files at ")#link("https://github.com/michal-h21/rdfref")[#text("https://github.com/michal-h21/rdfref")]#text(" that allow for generation of dependency graphs provided that some relevant metadata tags are added to the relevant theorems one wants to link.")

#text("I have tried briefly to use GPT-4 to create these graphs (or at least to summarize a paper in terms of such dependencies) but ran into the problem that the size of a typical math paper is longer than the allowable prompt size. It is capable though of summarizing the key points of a paper based on its introduction, which is sort of similar to what I had in mind.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676960")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("I have tried out rdfref successfully but failed, for the moment, with MathResultsGraph, basically because the latter relies on python and my Ubuntu version seems to ship a version that is not recent enough. I also struggled to use it with MacOs, but I might solve this issue. Be it as it may, both approaches require the author to add some metadata (and to provide some style files), so I am skeptical that this could be done for arXiv manuscripts in an automated way, as Terence Tao asked. I also thought that the goal was to generate a kind of visual (logical) dependence of theorem, lemmas etc, so I am curious to see what GPT-4 was able to produce.")#linebreak()#text(" Uwe Brauer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/163fd5ad3a94bc47dc883027302fb256a7b498c32948e8fc7c567f692be0f7e0-0be71fe52ebb864962dcd6ae927439140adcf035b8e9cb5d621011522cb9c66d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-676962")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("There are two sub-versions of GPT-4: one with an 8K tokens context window and one with 32K tokens. Maybe you could specifically ask for access to the 32K version if you don’t have it already?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677319")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")])]

#text("I’ll look into this, though it may well be that the simplest option is to wait a year until something like GPT4.5 with an internet plugin comes out, at which point it may be able to achieve the goal of my blog post (and much more besides) through a simple prompt or API call.")

#text("In the meantime, I have come across the experimental project “")#link("https://www.askpaper.ai/")[#text("Ask Paper")]#text("” (still in beta) which can take a paper (or URL to such a paper, e.g., an arXiv link) as input and then answer questions about it, ChatGPT-style. The AI does not seem to be quite as advanced as GPT4 and could not simply produce a diagram, but was able for instance to identify the important propositions and theorems in the paper, and say something about their logical relationship. It’s possible that one could combine this tool with one of the diagramming software solutions mentioned elsewhere in comments (together perhaps with some use of a GPT4-level LLM to translate the output of the former tool into a format suitable for the latter tool) to achieve some rudimentary version of the one-click diagramming tool that I had in mind, but it may be a bit clunky at the current level of technological development.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677323")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2023")])]

#text("Thanks for the link: I just tried it out. Fun fact: If you register, the interface is confusing, if you stay as a guest, the interface is rather straightforward.")#linebreak()#text(" I choose an arXiv preprint and selected the option: summary, but I was not convinced by the result: the software just gave a short summary of each section, without mentioning the important theorems, lemmas and the logical structure between theses. Maybe one needs to refine the task.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")])]

#text("I have recently come across another project, “")#link("https://www.chatpdf.com/")[#text("ChatPDF")]#text("“, which has a simple interface and does seem to be intelligent enough to isolate the key results of a paper and their logical dependencies, so this (combined with some diagramming tool) may already be a sufficient solution to the original problem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677557")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")])]

#text("Hi thanks for ChatPDF, I tried it out with one preprint I had at hand. I asked the system which lemmas are used to prove the main result, and he talks about lemma 2.9 and 2.10, alas both do not exist. There is proposition 2.10 but this is not relevant for the proof. So I am not sure what is going on…. It is a free tool, but…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677597")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2023")])]

#text("Hmm, it does seem that the tool is not always reliable (though I have found that if you follow up by giving it more guidance, for instance by providing examples of what you are looking for, it can correct itself after its initial response – somewhat like guiding a confused undergraduate during office hours). It seems this tool relies on GPT3.5 which does have a limited number of tokens it can process at a time; perhaps a future version of the tool would use something like GPT4 which can process many more tokens and I would expect it to be significantly more accurate (this may require a paid subscription though).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677608")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2023")])]

#text("> Hmm, it does seem that the tool is not always reliable")#linebreak()#text(" Maybe I was not patient enough. I will give it another try with a paper I know well and try out a series of questions, as you indicate. In any case, this tool seems unable to generate a visual map of the structure of the paper, as you described in your first post. (maybe in the coming years)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2023")])]

#text("ChatGPT only tries to continue the conversation, it doesn’t understand what it says, or anything else that resembles a human. How humiliating to compare it to an undergraduate student? or any human for that matter.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/449adfeb2b26c02c4d288adf1acc744415adc08e56e13ce4db16e2a80c148b86-e839fe6c927c6248c542b43ca339714d35dc0cc3283e5f49c413a163c5b90492.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiha")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677540")[#strong[#text("xiha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2023")])]

#link("https://paperswithcode.com/dataset/ai2d")[#text("https://paperswithcode.com/dataset/ai2d")]#text(" here is a dataset GPT4 has 78.2% on this dataset with 0-shot")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/449adfeb2b26c02c4d288adf1acc744415adc08e56e13ce4db16e2a80c148b86-e839fe6c927c6248c542b43ca339714d35dc0cc3283e5f49c413a163c5b90492.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xiha")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677541")[#strong[#text("xiha")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2023")])]

#text("The dataset is called AI2D (AI2 Diagrams)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efea85caa5efb7f4fb9e0cb619bad2ae269613c20bca495131d4e1e0c5e8d80d-6f017708443b03f4de48506e7a6d420485d1011ca1f60833dce102766b151b09.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Krause")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-677695")[#strong[#text("Andrew Krause")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2023")])]

#text("Somewhat orthogonal to this, but in a similar spirit: We’ve recently released a new website, VisualPDE.com, for real-time and interactive solutions of partial differential equations. Really I’d encourage you to click through and play with some examples (or type in your own PDE and solve it in 1D or 2D etc). It works on most phones or computers, and uses the native web browser (and the devices’ GPU) to perform the numerical simulations in real time.")

#text("More generally very keen to see more interactive mathematics be developed. I think these ideas are all potentially quite transformative…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-687171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2025")])]

#text("If you’re interested in structured note-taking and automated diagramming, you might want to check out STEMpad. While it’s not specifically designed for automatically generating proof diagrams, it provides a flexible digital workspace that could help with organizing logical structures and mathematical reasoning. It might be a useful tool for refining and visualizing ideas as you explore this concept further!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688041")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2025")])]

#text("I know it’s been 2 years since the post, but I think I’ve finally built a fully automated tool that takes any Latex source and creates a “first approximation” dependency graph.")

#enum(start: 1, 
[#text("Locates all instances of theorems/lemmas")],
[#text("Finds the corresponding proof blocks")],
[#text("Identifies all the references within that proof environment to other theorems/lemmas")],
[#text("Additionally, identifies sections titled e.g. “Proof of ref{theorem x} and maps references in that section to corresponding theorems/lemmas")]
)

#text("Here’s an example graph from “Almost all orbits of the Collatz map attain almost bounded values” (arxiv 1909.03562v5). ")#linebreak()#text("Link: ")#link("https://www.tldrpapers.ai/arxiv/1909.03562v5?view=graph")[#text("https://www.tldrpapers.ai/arxiv/1909.03562v5?view=graph")]#text(" (Graph tab)")

#link("https://raw.githubusercontent.com/mrlooi/Data/refs/heads/main/math/dep_graph_1909.03562v5.png")[#text("https://raw.githubusercontent.com/mrlooi/Data/refs/heads/main/math/dep_graph_1909.03562v5.png")]

#text("The graph is interactive and highlights relevant sections on hover:")

#link("https://raw.githubusercontent.com/mrlooi/Data/refs/heads/main/math/dep_graph_interactive.png")[#text("https://raw.githubusercontent.com/mrlooi/Data/refs/heads/main/math/dep_graph_interactive.png")]

#text("Every math paper on ")#link("https://www.tldrpapers.ai/")[#text("tldrpapers.ai")]#text(" ships with an automated dependency graph.")

#text("Still in the early stages, so any feedback or suggestions are welcome!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688051")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("This appears to be most useful—many thanks. A few questions and comments follow:")#linebreak()#text("1) The current style—white text on a black background—is rather difficult to read. Would it be possible to switch to black text on a white background?")#linebreak()#text("2) Is there any plan to generate a graph for individual proofs? That would be most helpful.")#linebreak()#text("3) I assume that one must upload the LaTeX source code.")#linebreak()#text("4) Is there a sandbox environment available, allowing one to visualise the graph for preprints of one’s own work before making it public?")#linebreak()#text("Uwe Brauer")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688068")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("1. Yep Lightmode is on my todo list")#linebreak()#text("2/3/4. I will be allowing users to upload their own LaTex source (which will be private by default, won’t be public) in a couple weeks. So long as it is a math paper, a dep graph will be autogenerated")

#text("The site is still very new so your feedback/requests are very helpful. Hope that answers your questions!")

#enum(start: 1, 

)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688069")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2025")])]

#text("Is there any way to contact you directly. I think we should keep further discussion off this site.")#linebreak()#text("Uwe Brauer")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688073")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2025")])]

#text("Agreed, I’ve reached out to your email (listed on the UCM page)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/069b47c5bb1a265ffe160a2ff1e0e57e57991cb0b1e055fd1d852ee28b3345fd-92ca8b383c5e71f4239a4c1053d92c2a4c302108516d7873c946f7c55d524535.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alonsoquixano")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688052")[#strong[#text("alonsoquixano")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2025")])]

#text("Another point, who can upload preprints and how?")

#text("Uwe Brauer")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb19f1c7e97fa271b4e5b15871681f10cde5861d3d62ce0bfe634b6c7f4bf493-e1af2e2ab649aee83320000ff52c7798a46926c8d4a03053efa5235e1262193e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CJ Looi")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-688747")[#strong[#text("CJ Looi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2025")])]

#text("Hey everyone, after iterating on this with several postdocs and professors, I have finally released the ability to upload your own latex source and visualize math dependency graphs using simply refs and labels.")

#text("Instructions can be found here ")#link("https://www.tldrpapers.ai/docs/dep-graph")[#text("https://www.tldrpapers.ai/docs/dep-graph")]

#text("An example graph from arxiv papers can be found here ")#link("https://www.tldrpapers.ai/arxiv/2012.04125v2")[#text("https://www.tldrpapers.ai/arxiv/2012.04125v2")]

#link("https://www.tldrpapers.ai/docs/dep-graph/sendov-graph.png")[#text("https://www.tldrpapers.ai/docs/dep-graph/sendov-graph.png")]

#text("Your feedback is most welcome, thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A paper diagram visualizer | What's new")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-693379")[#strong[#text("A paper diagram visualizer | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("[…] any event, I spent a few hours working to realize a proposal I had made back in 2023 to automatically create diagrams to visually illustrate the logical flow of a given mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/#comment-693904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2026")])]

#text("I made an AI skill for this this: ")#link("https://github.com/sethlei/Warrant")[#text("https://github.com/sethlei/Warrant")]

#text("There are a few example papers in the repo. The thing that makes it notable is that it dissects the paper down to the leaves – the facts/axioms/theorems that are used to build the claim graph.")

#text("I also used it to write a paper about Maz’ya’s 2018 problem 3.1. It should be available soon.")
]
