// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/01/27/ipam-begins-search-for-new-director/
// Converted to Typst by tao2typ: "2026-10-14T16:37:52.634958+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IPAM begins search for new director", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IPAM begins search for new director")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 January 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/01/27/ipam-begins-search-for-new-director/")[#text("https://terrytao.wordpress.com/2016/01/27/ipam-begins-search-for-new-director/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("http://www.ipam.ucla.edu/")[#text("Institute for Pure and Applied Mathematics")]#text(" (IPAM) here at UCLA is ")#link("http://www.ipam.ucla.edu/press-releases/ipam-begins-search-for-new-director/")[#text("seeking applications for its new director")]#text(" in 2017 or 2018, to replace ")#link("http://www.math.ucla.edu/~caflisch/")[#text("Russ Caflisch")]#text(", who is nearing the end of his five-year term as IPAM director. The previous directors of IPAM (Tony Chan, Mark Green, and Russ Caflisch) were also from the mathematics department here at UCLA, but the position is open to all qualified applicants with extensive scientific and administrative experience in mathematics, computer science, or statistics. Applications will be reviewed on June 1, 2016 (though ")#link("https://recruit.apo.ucla.edu/apply/JPF01891")[#text("the applications process")]#text(" will remain open through to Dec 1, 2016).")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f19639dd8785d0b1c752bc1f197d426a6daeb25b283db5e69edc6be9e5f10f9b-a44eb620efea0e9620e6ee2257020cd279c086cb82935c09e82b1a0776b81433.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nipuna_upeksha")]], [#link("https://terrytao.wordpress.com/2016/01/27/ipam-begins-search-for-new-director/#comment-465754")[#strong[#text("nipuna_upeksha")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2016")])]

#text("Good luck finding a good director..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e980e9b0cb0ae5fc6a6e60beecb43dd2a4974a538ff7825d144a2e211a025843-e5e1514459b9b43fbb4ca2ec40a0d6c0cd78b2728f014163bd459ef482d18800.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B.")]], [#link("https://terrytao.wordpress.com/2016/01/27/ipam-begins-search-for-new-director/#comment-465757")[#strong[#text("B.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2016")])]

#text("Are you applying?")
]
