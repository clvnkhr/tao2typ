// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/
// Converted to Typst by tao2typ: "2026-10-14T15:17:06.615381+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, Notes 13: Compactification and metrisation (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, Notes 13: Compactification and metrisation (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/")[#text("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("One way to study a general class of mathematical objects is to embed them into a more structured class of mathematical objects; for instance, one could study manifolds by embedding them into Euclidean spaces. In these (optional) notes we study two (related) embedding theorems for topological spaces:")

#list(
[#text("The ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(", which embeds locally compact Hausdorff spaces into compact Hausdorff spaces in a “universal” fashion; and")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Urysohn_metrization_theorem")[#text("Urysohn metrization theorem")]#text(", that shows that every ")#link("http://en.wikipedia.org/wiki/Second-countable")[#text("second-countable")]#text(" ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal")]#text(" ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff space")]#text(" is metrizable.")]
)

#metadata(none) <tao-75e8179de8facbc39e2b>

#heading(level: 1)[#strong[#text(" — 1. The Stone-Čech compactification — ")]]

#text("Observe that any dense open subset of a compact Hausdorff space is automatically a locally compact Hausdorff space. We now study the reverse concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" A ")#link("http://en.wikipedia.org/wiki/Compactification_(mathematics)")[#text("compactification")]#text(" of a locally compact Hausdorff space ")#mi("{X}")#text(" is an embedding ")#mi("{\\iota: X \\rightarrow \\overline{X}}")#text(" (i.e. a homeomorphism between ")#mi("{X}")#text(" and ")#mi("{\\iota(X)}")#text(") into a compact Hausdorff space ")#mi("{\\overline{X}}")#text(" such that the image ")#mi("{\\iota(X)}")#text(" of ")#mi("{X}")#text(" is an open dense subset of ")#mi("{\\overline{X}}")#text(". We will often abuse notation and refer to ")#mi("{\\overline{X}}")#text(" as the compactification rather than the embedding ")#mi("{\\iota: X \\rightarrow \\overline{X}}")#text(", when the embedding is obvious from context.")

#text("One compactification ")#mi("{\\iota: X \\rightarrow \\overline{X}}")#text(" is ")#emph[#text("finer")]#text(" than another ")#mi("{\\iota^{\\prime}: X \\rightarrow \\overline{X}^{\\prime}}")#text(" (or ")#mi("{\\iota^{\\prime}: X \\rightarrow \\overline{X}^{\\prime}}")#text(" is ")#emph[#text("coarser")]#text(" than ")#mi("{\\iota: X \\rightarrow \\overline{X}}")#text(") if there exists a continuous map ")#mi("{\\pi: \\overline{X} \\rightarrow \\overline{X}^{\\prime}}")#text(" such that ")#mi("{\\iota^{\\prime} = \\pi \\circ \\iota}")#text("; notice that this map must be surjective and unique, by the open dense nature of ")#mi("{\\iota(X)}")#text(". Two compactifications are ")#emph[#text("equivalent")]#text(" if they are both finer than each other.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Any compact set can be its own compactification. The real line ")#mi("{{\\mathbb R}}")#text(" can be compactified into ")#mi("{[-\\pi/2,\\pi/2]}")#text(" by using the arctan function as the embedding, or (equivalently) by embedding it into the extended real line ")#mi("{[-\\infty,\\infty]}")#text(". It can also be compactified into the unit circle ")#mi("{\\{ (x,y) \\in {\\mathbb R}^2: x^2 + y^2 = 1 \\}}")#text(" by using the ")#link("http://en.wikipedia.org/wiki/Stereographic_projection")[#text("stereographic projection")]#text(" ")#mi("{x \\mapsto (\\frac{2x}{1+x^2}, \\frac{x^2-1}{1+x^2})}")#text(". Notice that the former embedding is finer than the latter. The plane ")#mi("{{\\mathbb R}^2}")#text(" can similarly be compactified into the unit sphere ")#mi("{\\{ (x,y,z) \\in {\\mathbb R}^2: x^2 + y^2 +z^2 = 1 \\}}")#text(" by the stereographic projection ")#mi("{(x,y) \\mapsto (\\frac{2x}{1+x^2+y^2}, \\frac{2y}{1+x^2+y^2}, \\frac{x^2+y^2-1}{1+x^2+y^2})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space ")#mi("{X}")#text(" that is not compact. Define the ")#link("http://en.wikipedia.org/wiki/One-point_compactification")[#text("one-point compactification")]#text(" ")#mi("{X \\cup \\{\\infty\\}}")#text(" by adjoining one point ")#mi("{\\infty}")#text(" to ")#mi("{X}")#text(", with the topology generated by the open sets of ")#mi("{X}")#text(", and the complement (in ")#mi("{X \\cup \\{\\infty\\}}")#text(") of the compact sets in ")#mi("{X}")#text(". Show that ")#mi("{X \\cup \\{\\infty\\}}")#text(" (with the obvious embedding map) is a compactification of ")#mi("{X}")#text(". Show that the one-point compactification is coarser than any other compactification of ")#mi("{X}")#text(".")
]

#text("We now consider the opposite extreme to the one-point compactification:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space. A ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactification")]#text(" ")#mi("{\\beta X}")#text(" of ")#mi("{X}")#text(" is defined as the finest compactification of ")#mi("{X}")#text(", i.e. the compactification of ")#mi("{X}")#text(" which is finer than every other compactification of ")#mi("{X}")#text(".")
]

#text("It is clear that the Stone-Čech compactification, if it exists, is unique up to isomorphism, and so one often abuses notation by referring to ")#emph[#text("the")]#text(" Stone-Čech compactification. The existence of the compactification can be established by Zorn’s lemma (see ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("these lecture notes of mine from last year")]#text("). We shall shortly give several other constructions of the compactification. (All constructions, however, rely at some point on the axiom of choice, or a related axiom.)")

#text("The Stone-Čech compactification obeys a useful ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functorial")]#text(" property:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-1a8e5a6f3a2e791aba58>#text(" Let ")#mi("{X, Y}")#text(" be locally compact Hausdorff spaces, with Stone-Čech compactifications ")#mi("{\\beta X, \\beta Y}")#text(". Show that every continuous map ")#mi("{f: X \\rightarrow Y}")#text(" has a unique continuous extension ")#mi("{\\beta f: \\beta X \\rightarrow \\beta Y}")#text(". (Hint: uniqueness is easy; for existence, look at the closure of the graph ")#mi("{\\{ (x,f(x)): x \\in X \\}}")#text(" in ")#mi("{\\beta X \\times \\beta Y}")#text(", which compactifies ")#mi("{X}")#text(" and thus cannot be strictly finer than ")#mi("{\\beta X}")#text(".) In the converse direction, if ")#mi("{\\overline{X}}")#text(" is a compactification of ")#mi("{X}")#text(" such that every continuous map ")#mi("{f: X \\rightarrow K}")#text(" into a compact space can be extended continuously to ")#mi("{\\overline{X}}")#text(", show that ")#mi("{\\overline{X}}")#text(" is the Stone-Čech compactification.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" From the above exercise, we can define limits ")#mi("{\\lim_{x \\rightarrow p} f(x) := \\beta f(p)}")#text(" for any bounded continuous function on ")#mi("{X}")#text(" and any ")#mi("{p \\in \\beta X}")#text(". But one for coarser compactifications, one can only take limits for special types of bounded continuous functions; for instance, using the one-point compactification of ")#mi("{{\\mathbb R}}")#text(", ")#mi("{\\lim_{x \\rightarrow \\infty} f(x)}")#text(" need not exist for a bounded continuous function ")#mi("{f: {\\mathbb R} \\rightarrow {\\mathbb R}}")#text(", e.g. ")#mi("{\\lim_{x \\rightarrow \\infty} \\sin(x)}")#text(" or ")#mi("{\\lim_{x \\rightarrow \\infty} \\arctan(x)}")#text(" do not exist. The finer the compactification, the more limits can be defined; for instance the two point compactification ")#mi("{[-\\infty,+\\infty]}")#text(" of ")#mi("{{\\mathbb R}}")#text(" allows one to define the limits ")#mi("{\\lim_{x \\rightarrow +\\infty} f(x)}")#text(" and ")#mi("{\\lim_{x \\rightarrow -\\infty} f(x)}")#text(" for some additional functions ")#mi("{f}")#text(" (e.g. ")#mi("{\\lim_{x \\rightarrow \\pm \\infty} \\arctan(x)}")#text(" is well-defined); and the Stone-Čech compactification is the only compactification which allows one to take limits for ")#emph[#text("any")]#text(" bounded continuous function (e.g. ")#mi("{\\lim_{x \\rightarrow p} \\sin(x)}")#text(" is well-defined for all ")#mi("{p \\in \\beta {\\mathbb R}}")#text(").")
]

#text("Now we turn to the issue of actually constructing the Stone-Čech compactifications.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-d52c60f0d7e856384663>#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space. Let ")#mi("{C(X \\rightarrow [0,1])}")#text(" be the space of continuous functions from ")#mi("{X}")#text(" to the unit interval, let ")#mi("{Q := [0,1]^{C(X \\rightarrow [0,1])}}")#text(" be the space of tuples ")#mi("{(y_f)_{f \\in C(X \\rightarrow [0,1])}}")#text(" taking values in the unit interval, with the product topology, and let ")#mi("{\\iota: X \\rightarrow Q}")#text(" be the Gelfand transform ")#mi("{\\iota(x) := (f(x))_{f \\in C(X \\rightarrow [0,1])}}")#text(", and let ")#mi("{\\beta X}")#text(" be the closure of ")#mi("{\\iota X}")#text(" in ")#mi("{Q}")#text(".")

#list(
[#text("Show that ")#mi("{\\beta X}")#text(" is a compactification of ")#mi("{X}")#text(". ({\\emph Hint}: Use ")#link("http://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text(" and ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(".)")],
[#text("Show that ")#mi("{\\beta X}")#text(" is the Stone-Čech compactification of ")#mi("{X}")#text(". ({\\emph Hint}: If ")#mi("{\\overline{X}}")#text(" is any other compactification of ")#mi("{X}")#text(", we can identify ")#mi("{C(\\overline{X} \\rightarrow [0,1])}")#text(" as a subset of ")#mi("{C(X \\rightarrow [0,1])}")#text(", and then project ")#mi("{Q}")#text(" to ")#mi("{[0,1]^{C(\\overline{X} \\rightarrow [0,1])}}")#text(". Meanwhile, we can embed ")#mi("{\\overline{X}}")#text(" inside ")#mi("{[0,1]^{C(\\overline{X} \\rightarrow [0,1])}}")#text(" by the Gelfand transform.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{X}")#text(" be a discrete topological space, let ")#mi("{2^X}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("Boolean algebra")]#text(" of all subsets of ")#mi("{X}")#text(". By ")#link("http://en.wikipedia.org/wiki/Stone%27s_representation_theorem_for_Boolean_algebras")[#text("Stone’s representation theorem")]#text(" (Theorem 1 from ")#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Notes 1")]#text("), ")#mi("{2^X}")#text(" is isomorphic to the clopen algebra of a Stone space ")#mi("{\\beta X}")#text(".")

#list(
[#text("Show that ")#mi("{\\beta X}")#text(" is a compactification of ")#mi("{X}")#text(".")],
[#text("Show that ")#mi("{\\beta X}")#text(" is the Stone-Čech compactification of ")#mi("{X}")#text(".")],
[#text("Identify ")#mi("{\\beta X}")#text(" with the space of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" on ")#mi("{X}")#text(". (See ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this post")]#text(" for further discussion of ultrafilters, and ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("this post")]#text(" for further discussion of the relationship of ultrafilters to the Stone-Čech compactification.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space, and let ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(" be the space of bounded continuous complex-valued functions on ")#mi("{X}")#text(".")

#list(
[#text("Show that ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(" is a ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#text("unital commutative ")#mi("{C^*}")#text("-algebra")]#text(" (see Section 4 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("Notes 12")]#text(").")],
[#text("By the commutative ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark_theorem")[#text("Gelfand-Naimark theorem")]#text(" (Theorem 14 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("Notes 12")]#text("), ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(" is isomorphic as a unital ")#mi("{C^*}")#text("-algebra to ")#mi("{C(\\beta X \\rightarrow {\\mathbb C})}")#text(" for some compact Hausdorff space ")#mi("{\\beta X}")#text(" (which is in fact the spectrum of ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(". Show that ")#mi("{\\beta X}")#text(" is the Stone-Čech compactification of ")#mi("{X}")#text(".")],
[#text("More generally, show that given any other compactification ")#mi("{\\overline{X}}")#text(" of ")#mi("{X}")#text(", that ")#mi("{C(\\overline{X} \\rightarrow {\\mathbb C})}")#text(" is isomorphic as a unital ")#mi("{C^*}")#text("-algebra to a subalgebra of ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(" that contains ")#mi("{{\\mathbb C} \\oplus C_0(X \\rightarrow {\\mathbb C})}")#text(" (the space of continuous functions from ")#mi("{X}")#text(" to ")#mi("{{\\mathbb C}}")#text(" that converge to a limit at ")#mi("{\\infty}")#text("), with ")#mi("{\\overline{X}}")#text(" as the spectrum of this algebra; thus we have a canonical identification between compactifications and ")#mi("{C^*}")#text("-algebras between ")#mi("{BC(X \\rightarrow {\\mathbb C})}")#text(" and ")#mi("{{\\mathbb C} \\oplus C_0(X \\rightarrow {\\mathbb C})}")#text(", which correspond to the Stone-Čech compactification and one-point compactification respectively.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{X}")#text(" be a locally compact Hausdorff space. Show that the dual ")#mi("{BC(X \\rightarrow {\\mathbb R})^*}")#text(" of ")#mi("{BC(X \\rightarrow {\\mathbb R})}")#text(" is isomorphic as a Banach space to the space ")#mi("{M(\\beta X)}")#text(" of real signed Radon measures on the Stone-Čech compactification ")#mi("{\\beta X}")#text(", and similarly in the complex case. In particular, conclude that ")#mi("{\\ell^\\infty({\\mathbb N})^* \\equiv M(\\beta {\\mathbb N})}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The Stone-Čech compactification can be extended from locally compact Hausdorff spaces to the slightly larger class of ")#link("http://en.wikipedia.org/wiki/Tychonoff_space")[#text("Tychonoff spaces")]#text(", which are those Hausdorff spaces ")#mi("{X}")#text(" with the property that any closed set ")#mi("{K \\subset X}")#text(" and point ")#mi("{x}")#text(" not in ")#mi("{K}")#text(" can be separated by a continuous function ")#mi("{f \\in C(X \\rightarrow {\\mathbb R})}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{K}")#text(" and zero on ")#mi("{x}")#text(". This compactification can be constructed by a modification of the argument used to establish Exercise ")#link(<tao-d52c60f0d7e856384663>)[#text("3")]#text(". However, in this case the space ")#mi("{X}")#text(" is merely dense in its compactification ")#mi("{\\beta X}")#text(", rather than open and dense.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" A cautionary note: in general, the Stone-Čech compactification is almost never ")#emph[#text("sequentially")]#text(" compact. For instance, it is not hard to show that ")#mi("{{\\mathbb N}}")#text(" is sequentially closed in ")#mi("{\\beta {\\mathbb N}}")#text(". In particular, these compactifications are usually not metrisable.")
]

#heading(level: 1)[#strong[#text(" — 2. Urysohn’s metrisation theorem — ")]]

#text("Recall that a topological space is ")#emph[#text("metrisable")]#text(" if there exists a metric on that space which generates the topology. There are various necessary conditions for metrisability. For instance, we have seen that metric spaces must be ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal")]#text(" and Hausdorff. In the converse direction, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Urysohn’s metrisation theorem)")]#text(" Let ")#mi("{X}")#text(" be a normal Hausdorff space which is ")#link("http://en.wikipedia.org/wiki/Second-countable")[#text("second countable")]#text(". Then ")#mi("{X}")#text(" is metrisable.")
]

#emph[#text("Proof:")]#text(" (Sketch) This will be a variant of the argument in Exercise ")#link(<tao-d52c60f0d7e856384663>)[#text("3")]#text(", but with a countable family of continuous functions in place of ")#mi("{C(X \\rightarrow [0,1])}")#text(".")

#text("Let ")#mi("{U_1, U_2, \\ldots}")#text(" be a countable base for ")#mi("{X}")#text(". If ")#mi("{U_i, U_j}")#text(" are in this base with ")#mi("{\\overline{U_i} \\subset U_j}")#text(", we can apply Urysohn’s lemma and find a continuous function ")#mi("{f_{ij}: X \\rightarrow [0,1]}")#text(" which equals ")#mi("{1}")#text(" on ")#mi("{\\overline{U_i}}")#text(" and vanishes outside of ")#mi("{U_j}")#text(". Let ")#mi("{{\\mathcal F}}")#text(" be the collection of all such functions; this is a countable family. We can then embed ")#mi("{X}")#text(" in ")#mi("{[0,1]^{{\\mathcal F}}}")#text(" using the Gelfand transform ")#mi("{x \\mapsto (f(x))_{f \\in {\\mathcal F}}}")#text(". By modifying the proof of Exercise ")#link(<tao-d52c60f0d7e856384663>)[#text("3")]#text(" one can show that this is an embedding. On the other hand, ")#mi("{[0,1]^{{\\mathcal F}}}")#text(" is a countable product of metric spaces and is thus metrisable (e.g. by enumerating ")#mi("{{\\mathcal F}}")#text(" as ")#mi("{f_1, f_2, \\ldots}")#text(" and using the metric ")#tao-math("{d( (x_n)_{f_n \\in {\\mathcal F}}, (y_n)_{f_n \\in {\\mathcal F}} ) := \\sum_{n=1}^\\infty 2^{-n} \\left|x_n-y_n\\right|}", block: false)#text("). Since a subspace of a metrisable space is clearly also metrisable, the claim follows. ")#mi("\\Box")

#text("Recalling that compact metric spaces are second countable (Lemma 4 of ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text("), thus we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4")]#text(" A compact Hausdorff space is metrisable if and only if it is second countable.")
]

#text("Of course, non-metrisable compact Hausdorff spaces exist; ")#mi("{\\beta {\\mathbb N}}")#text(" is a standard example. Uncountable products of non-trivial compact metric spaces, such as ")#mi("{\\{0,1\\}}")#text(", are always non-metrisable. Indeed, we already saw in ")#link("https://terrytao.wordpress.com/2009/02/09/245b-notes-10-compactness-in-topological-spaces/")[#text("Notes 10")]#text(" that ")#mi("{\\{0,1\\}^X}")#text(" is compact but not sequentially compact (and thus not metrisable) when ")#mi("{X}")#text(" has the cardinality of the continuum; one can use the first uncountable ordinal to achieve a similar result for any uncountable ")#mi("{X}")#text(", and then by embedding one can obtain non-metrisability for any uncountable product of non-trivial compact metric spaces, thus complementing the metrisability of countable products of such spaces. Conversely, there also exist metrisable spaces which are not second countable (e.g. uncountable discrete spaces). So Urysohn’s metrisation theorem does not completely classify the metrisable spaces, however it already covers a large number of interesting cases.")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e53c4ac7d02bccdd25276f925a947179e848a39e78fb7ddfe7c4bde712cf7cf-16def73d5f76ac66e840a7368d02798091d0974795266c02f4ae95b2a2cc8f62.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of javier")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36971")[#strong[#text("javier")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("With respect to Exercise 5, the algebra of functions of the Stone-Čech compactification admits a concrete realization by means of the original algebra of functions alone. The algebra of functions on ")#mi("\\beta X")#text(" corresponds to the so-called “multiplier algebra” of the algebra of functions on ")#mi("X")#text(". From an algebraic point of view, for any algebra ")#mi("A")#text(" the multiplier algebra ")#mi("M(A)")#text(" is characterized as the biggest unital algebra containing ")#mi("A")#text(" as an essential ideal.")

#text("There is a brief explanation about the construction of the multiplier algebra and its relation with compactification in the old ARTS blog:")#linebreak()#text(" ")#link("http://www.neverendingbooks.org/ARTS/?p=28")[#text("http://www.neverendingbooks.org/ARTS/?p=28")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36977")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("To refine Remark 2 a bit, Stone-Cech compactifications (of completely regular spaces) are never metrizable unless the space you started with was already compact and metrizable. In particular, let X be any noncompact metrizable space. Then X is not sequentially compact, so there is some sequence ")#mi("(a_n)")#text(" in X with no accumulation point. Thus ")#mi("S=\\{a_n\\}")#text(" is closed in X and discrete, so by Tietze extension every bounded continuous function on S extends to X. It follows that the induced map ")#mi("\\beta S\\to\\beta X")#text(" is an embedding, which implies ")#mi("\\beta X")#text(" is not metrizable (or even sequentially compact) because ")#mi("\\beta S \\cong\\beta\\mathbb N")#text(" is not metrizable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36979")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("The html for the initial mention of the Urysohn metrization theorem is a bit garbled. ")#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36989")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("I don’t understand why the one-point compactification is the coarsest. If we take X = reals, then there is no continuous map X u {oo} = S^1 -> [-1,1] coinciding with the inclusion of X. But there is a unique map the other way round (sent all points in the complement of X in \\bar{X} to infinity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("Could you clarify example 2 by some specific examples?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("Dear Prof. Tao,")

#text("I am planning to work in the field of PDE. For being a good researcher in this field, which of the following courses you think that a Ph. D. student should take")

#text("1-differential geometry")#linebreak()#text(" 2-operator theory")#linebreak()#text(" 3-topology")#linebreak()#text(" 4-fourier analysis")#linebreak()#text(" 5-harmonic analysis")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7b3e5d904932dcca1708db23de32f91876c5d738e9e38a82a3c4b079977be62-3c9b7fbd63c57ffdda02f638e1891c854749eed000a4484c3f40eb7843c3c9db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Emerton")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-36999")[#strong[#text("Matthew Emerton")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("Dear anon,")

#text("“Coarsest” means that all other compactifications map to the one point compactification. So the fact that [-1,1] maps to S^1 exactly shows that")#linebreak()#text(" S^1 is coarser than [-1,1] (as it should be).")

#text("You can think that giving a compactification means that you complete your space by adding a set of possible “directions at infinity”. In the one point compactification, you add just one point at infinity. (So whichever way you move off to infinity in the space, you always end up at the same point.) The compactification [-1,1] of R has two directions at infinity (one lying at the positive end of the real line, the other at the negative end). In the Stone-Cech compactification, you add all possible directions (in some precise sense).")

#text("With this heuristic, “coarse” means there are not many directions at infinity, while “fine” means that there are many. So the one-point compactification is the coarsest, and the Stone-Cech compactification is the finest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37004")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2009")])]

#text("That’s what I suspected, but isn’t coarser/finer stated exactly the other way round in Definition 1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2009")])]

#text("Oops, that was reversed; I fixed it now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84ebae8431b67df69f9d45ead28ea0b3441ce04376910fa5a99eb664ae9d2bf2-774269c70d9b8a0619e8dd012e86f90583bc0063892dcbda0d77b1f6a08a8b25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Compactification and Metrisation « memoirs on a rainy day")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37096")[#strong[#text("Compactification and Metrisation « memoirs on a rainy day")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("[…] Compactification and Metrisation Published March 21, 2009 mathematics Tags: Analysis, bolzano weiestrass, compact, compact spaces, mathematics, metric spaces, metrics, terence tao Some great notes from Dr. Terence Tao’s lecture on compacity and metric spaces. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37122")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2009")])]

#text("Thanks for the course notes. In Exercise 3, shouldn’t it say:")

#text("… let $\\beta X$ be the closure of $\\iota X$ in $Q$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab0cd50e81332655db6b3f2e939cc7830561dcf352a3c24ccb1125c8295f9c1f-d1133fda8930800c53eced9ca2308e6a37b0a1b22edfcffebf5957235c63bd7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pete L. Clark")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37167")[#strong[#text("Pete L. Clark")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2009")])]

#text("“Uncountable products of compact metric spaces, such as…are usually non-metrisable also.”")

#text("Why not give the precise result?")

#text("If {X_i}_{i in I} is a family of nonempty metric spaces, then the product \\Pi_i X_i is metrizable if and only if {i in I | # X_i > 1} is a countable set.")

#text("(Indeed, if the hypothesis holds, then the space is homeomorphic to a countable product of metrizable spaces so is easy to metrize with an explicit metric. If the hypothesis does not hold, then the product space is not even first countable: Problem 16A, Willard’s _General Topology_.) ")#emph[#text("[Incorporated, thanks, – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37194")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("In exercise 3, I believe it should say that ")#mi("\\beta X")#text(" is the closure of ")#mi("i(X)")#text(" in ")#mi("Q")#text(". ")#emph[#text("[Corrected, thanks, T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The discussion of real analysis: 0 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37503")[#strong[#text("The discussion of real analysis: 0 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("[…] would like start our first disscusion about this post, with the title ‘Compactification and metrisation (optional)’, which is also the last post of another […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37648")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("Dear Professor Tao:")

#text("In exercise 3, how to prove the fact that X is open in ")#mi("\\beta X")#text(" and the situation in Remark 1 is different, I can’t work it out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("Dear liuxiaochuan,")

#text("If x is in X, and X is LCH, then there exists a compactly supported ")#mi("f: X \\to [0,1]")#text(" which is equal to 1 at x. Now look at the open neighbourhood of x in ")#mi("\\beta X")#text(" consisting of those y for which ")#mi("y_f > 1/2")#text(" (say). One can show that this neighbourhood is contained entirely inside the compact support of f, and in particular lies in X.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37888")[#strong[#text("245B, Notes 13: Compactification and Metrisation « Less Incompetence")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")]

#text("[…] 245B, Notes 13: Compactification and Metrisation Here are some partial solutions to the problems formulated in Notes 13 that can be found here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92f1228272953f345d03a05d0e93fd1965c0d42c46db72585086e5be929239f5-7321f0321a762d29957d00eaf87c956bcfb368c0b47e8ee9fb03ebe623a45f9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maxbaroi")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-37889")[#strong[#text("maxbaroi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("I just noticed that this doesn’t appear in the 245B category. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seminar „Funktionalanalysis“ « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-43308")[#strong[#text("Seminar „Funktionalanalysis“ « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("[…] Stone-Čech-Kompaktifizierung (T. Tao, Compactification and metrisation, Blognotes zur Vorlesung 245B; N. Carothers, l.c. Chap […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ce450a7cd47c2c3885683690b291ae7fbf12dfaab9584e7bdf60e11bd8de873-7db7d5770e152467e2dbd1a88d4acdf6096afa9c644439147485dbd42b7117d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yangtse")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-43873")[#strong[#text("yangtse")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("Dear Professor Tao:")

#text("In Folland’s Real Analysis 2nd ed. page145, he says that if X is an LCH space, then F={all f in C(X,[0,1]) with compact support} separates points")#linebreak()#text(" and closed sets by Urysohn’s lemma. A GLANCE AT the construction of the compactification (Y, e) associated to this F shows that Y consists of e(X) together with the single point of [0,1]^F all of whose coordinates are zero.")

#text("How to deduce this conclusion? I mean, how can you show that the closure of e(X) in [0,1]^F has only one point(say, the point of [0,1]^F all of whose coordinates are zero) more than e(X)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-43881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("This is a good exercise in understanding the weak topology. Start with a point p in [0,1]^F that is not identically zero and not in e(X), and show that (a) there exists a function f in F that separates p from all but a compact set in X, and (b) for every x in that compact set, there exists f in F that separates p from an open neighbourhood of x. Then use compactness.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a novice")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-43875")[#strong[#text("a novice")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("Dear Prof. Tao,")

#text("It seems that there is a mistake in the following argument I could not see it.Could you please help me out?")

#text("Let ")#mi("x_n=\\frac{-1}{n}.")#text(" Since it is convergent we know that ")#mi("limsup_{n \\rightarrow \\infty}x_n=0.")

#text("Since ")#mi("x=limsup_{n \\rightarrow \\infty}x_n=inf_{k \\geq 1}sup_{n \\geq k}x_n,")#text(" for every ")#mi("k \\geq 1,")#text(" there exists an ")#mi("n_k \\geq k")#text(" such that ")#mi("x_{n_k}\\geq x.")

#text("now, for the above sequence, we should have ")#mi("\\frac{-1}{n_k} \\geq 0")#text(" but that is not correct.")

#text("Where is my mistake?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-43879")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("The statement ")#mi("\\sup_n x_n \\geq x")#text(" does not mean that there exists n such that ")#mi("x_n \\geq x")#text(". Instead, it means that for every ")#mi("\\varepsilon > 0")#text(", there exists n such that ")#mi("x_n \\geq x-\\varepsilon")#text(". Thus for instance ")#mi("\\sup_n \\frac{-1}{n} = 0")#text(". Similarly for ")#mi("\\inf")#text(", ")#mi("\\lim \\sup")#text(", etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f45ac1e57b0cc191d57d12bd76ab2471fd643988ce5db3661ca7d2d57d7bb9e-b719f8ee7693f457b32a4ac9fe0540d1c40c44b8ef3a9e6e8b591ac7f1a43668.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crosslegged")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-44450")[#strong[#text("crosslegged")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2010")])]

#text("I’ve been searching in the literature for an example of a topological space whose Alexandroff compactification is (homeomorphic to) the Stone-Čech compactification — my prof. says he has seen it somewhere, but can’t remember where — do you have any such memory, or ideas?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-93083")[#strong[#text("254A, Notes 6: Ultraproducts as a bridge between hard analysis and soft analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2011")])]

#text("[…] to the space . Remark 4 More discussion on the Stone-Cech compactification can be found in this previous blog post. The compact space can also be endowed with an interesting semigroup structure, which is of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-237440")[#strong[#text("What does Kadison-Singer have to do with Quantum Mechanics? | tcs math - some mathematics of theoretical computer science")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")]

#text("[…] Indeed, for every partition , a pure -measure can only put non-zero weight on projections involving coordinates of exactly one of or . Furthermore, if then . In other words, for every set of projections, the measure takes only values 0 or 1. Such finitely-additive measures are exactly given by ultrafilters on . The finitely-additive pure -measures are in one-to-one corresponds with such ultrafilters, the set of which can be identified with , the Stone-Cech compactification of the naturals. See Terry Tao’s notes on ultafilters and Stone-Cech compactification. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d8a0049a253560a8c5ec09985e3a16a5ba9efed2477e85e3506113fa985d689-6654c14eed8b5e451478326ac435779ba33f248bffa1eab63ff9f60c26bc735e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthias Hübner")]], [#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-453999")[#strong[#text("Matthias Hübner")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2015")])]

#text("Dear Prof. Tao,")

#text("in Definition 1 right after “One compactification … is finer … if there exists a continuous map …” the arrow should be reversed, or rather domain and codomain swapped. Finer compactifications project/surject onto coarser ones.")

#text("And in the following “… such that … notice that this map …” i should be replaced by i’ and vice versa: coarser embedding i’ equals finer embedding i followed by projection pi.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/18/245b-notes-13-compactification-and-metrisation-optional/#comment-527454")[#strong[#text("The Stone-Čech Compactification – Part 3 – Maths to Share")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2019")]

#text("[…] Wikipedia page on the Stone-Čech compactification and these notes by Terrence Tao were where I first learned of the Stone-Čech compactification. I learnt about […]")
]
