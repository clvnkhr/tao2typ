// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/
// Converted to Typst by tao2typ: "2026-10-14T09:26:15.917659+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Two polymath projects", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Two polymath projects")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 June 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/")[#text("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Two polymath related items for this post. Firstly, ")#link("http://polymathprojects.org/2012/06/03/polymath-proposal-the-hot-spots-conjecture-for-acute-triangles/")[#text("there is a new polymath proposal over at the polymath blog")]#text(", proposing to attack the “hot spots conjecture” (concerning a maximum principle for a heat equation) in the case when the domain is an acute-angled triangle (the case of the right and obtuse-angled triangles already being solved). Please feel free to comment on the proposal blog post if you are interested in participating.")

#text("Secondly, it is once again time to set up the annual “mini-polymath” project to collaboratively solve one of this year’s International Mathematical Olympiad problems. This year, the Olympiad is being ")#link("http://www.oma.org.ar/imo2012/")[#text("held in Argentina")]#text(", with the problems given out on July 10-11. As usual, there will be a ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2012")[#text("wiki page")]#text(", discussion thread, and research thread for the project. As in previous years, the first thing to resolve is the starting date and time, so I am setting up a poll here to fix a time (and also to get a preliminary indication of interest in the project). (I am using 24-hour ")#link("http://en.wikipedia.org/wiki/Coordinated_Universal_Time")[#text("Coordinated Universal Time")]#text(" (UTC) for these times. ")#link("http://www.timeanddate.com/worldclock/fixedtime.html?iso=20120712T06")[#text("Here is a link")]#text(" that converts the first time given in the poll (Thu Jul 12 2012 UTC 6:00) into other time zones.) Given that the last three mini-polymaths were reasonably successful, I am not planning any changes to the format, but of course if there are any suggestions for changes, I’d be happy to hear them in the comments.")

#metadata(none) <tao-9f066e2f1908b8391d5f>

#metadata(none) <tao-1e0ac2e662deb0a99974>

#metadata(none) <tao-be8b0bc99a441de8ae4b>

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-145850")[#strong[#text("Studenti, problemi di Matematica, Fisica e programmi scolastici - Linee di scienza - di Francesca Magni - Matematica e fisica")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2012")]

#text("[…] e di “sfide” come succede nel mondo reale della ricerca. A proposito: vi segnalo due nuovi Polymath problem, che sono dei progetti collettivi on line aperti a tutti. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-146053")[#strong[#text("Polymath Projects « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2012")]

#text("[…] is also a mini-polymath coming up. See this <a> href=”")#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/“post</a&gt")[#text("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/“post</a&gt")]#text(";. Like this:LikeBe the first to like this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-147158")[#strong[#text("Three number theory bits: One elementary, the 3-Goldbach, and the ABC conjecture « mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2012")]

#text("[…] as announced at Terry Tao’s Blog, two new polymath items are on the horizon. There is a new polymath proposal at the polymath […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Updates on the two polymath projects « What’s new")]], [#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-147209")[#strong[#text("Updates on the two polymath projects « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2012")])]

#text("[…] quick updates with regards to polymath projects. Firstly, given the poll on starting the mini-polymath3 project, I will start the project at Thu July 12 2012 UTC […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-271628")[#strong[#text("Three number theory bits: One elementary, the 3-Goldbach, and the ABC conjecture » mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2014")]

#text("[…] as announced at Terry Tao’s Blog, two new polymath items are on the horizon. There is a new polymath proposal at the polymath blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28113d0210e739d8664d03bcecfa975e7ac326938d63e1555264705984fded0f-9786df7dc22d576ffc7d95ad81cffd95165350cb07556f00045c737147b89eb3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zankaon")]], [#link("https://terrytao.wordpress.com/2012/06/04/two-polymath-projects/#comment-297709")[#strong[#text("zankaon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#link("http://zankaon.wordpress.com/2013/10/08/nature-of-time-analytical-and-exponentially-changing-cosmic-time")[#text("http://zankaon.wordpress.com/2013/10/08/nature-of-time-analytical-and-exponentially-changing-cosmic-time")]#text("; integers analytical?")#linebreak()#text(" Perhaps of interest. Also ")#link("https://sites.google.com/site/zankaon")[#text("https://sites.google.com/site/zankaon")]
]
