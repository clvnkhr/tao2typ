// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/
// Converted to Typst by tao2typ: "2026-10-14T08:54:17.688761+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An epsilon of room: pages from year three of a mathematical blog", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An epsilon of room: pages from year three of a mathematical blog")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I have just finished the ")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/02/epsilon.pdf")[#text("first draft")]#text(" of my blog book for 2009, under the title of “")#link("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("An epsilon of room: pages from year three of a mathematical blog")]#text("“. It largely follows the format of my previous two blog books, “")#link("https://terrytao.wordpress.com/books/whats-new-2007/")[#text("Structure and Randomness")]#text("” and “")#link("https://terrytao.wordpress.com/books/poincares-legacies-course-notes-expository-articles-and-lecture-series-from-a-mathematical-blog/")[#text("Poincaré’s legacies")]#text("“.")

#text("There is still some amount of work to be done on the texts; for instance, I need to create an index (which I had neglected to do in the previous two books in the series), and will probably end up splitting the book into two volumes (as was done for “Poincaré’s legacies”).")

#text("As always, any feedback or comments are very welcome.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of math_reader")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43527")[#strong[#text("math_reader")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("Great book again, thanks!")

#text("A typographical remark: sometimes the text seems to be centered when not intended. The first such page seems 379, then pages 382-390, then starts again second paragraph of page 392, stops top of 393, starts a little middle of 393, stops again then a long run 395-416, then again 418-… It’s very strange.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43529")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("Terry,")

#text("Looks great, though shouldn’t there be three volumes this time?")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31a3f814b4ce3f9613fc9bf695a79a6f792c2f0629bc7e14d11d5840d3f7d743-309dee0d642fa87941549982d0b477a0c57d3958a1e8a9a3153402f98d832952.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of other")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43531")[#strong[#text("other")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("somewhere in the middle everything got center aligned")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43535")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("Check p. 351, the quotation from Jerry Bona: “The Axiom of Choice is obviously true, the well-ordering principle obviously false, and who can tell about Zorn’s Lemma?” The quotation is centred, but the centring doesn’t stop afterwards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43537")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("The table in section 2.7, “Create an epsilon of room”, is going off the right-hand edge.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43538")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("As is the one on p. 441, following the line, “For instance, here is how the data set tracks with Benford’s law (rounded to three significant figures)”. The table on p. 443 has extraneous quotation marks in the second column.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43539")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("In equation 3.32 (p. 445, following the text, “Observe (through telescoping series) that Benford’s law implies that”), the words “for some integer” are run together, maybe from using \\rm with unescaped spaces.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("Professor Tao: Thank you very much for giving us this compilation (as well as the other two). I’m just very happy to have these blogs in one place where I can quickly search for things I want to read. Wonderful!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43533")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("It’s not really an “error”, but it might be nice to add “equidecomposable” to the LaTeX hyphenation dictionary, as it sticks out into the margin several times (I’m looking at the Banach–Tarski paradox article, pp. 318 ff.). The same thing happens with URLs, e.g., the “terrytao.wordpress.com/2009/01/08” at the end of that section. The url package provides a \\url command which might help (if you’re using pdflatex, otherwise I think ")#link("http://www.ctan.org/tex-archive/macros/latex/contrib/breakurl/")[#text("breakurl")]#text(" is necessary).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43534")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("The footnote on p. 348, in the sentence which begins, “For instance, once one can demonstrate the existence of an uncountable ordinal”, refers to the “axion of choice”. Dark matter physics is hard enough without adding Banach–Tarski to the mix. . . :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("Thanks for all the corrections! I managed to fix most of them. For some reason \\hyphenate{equi-de-com-pos-abil-ity} does not do anything about the compound word $G$-equidecomposablity; I don’t know how to fix that. Also, \\usepackage{hyperref} caused a huge number of compilation errors so I was not able to take advantage of \\url. But in any event the publisher will presumably have professional typesetting to deal with these issues in a better way than I can…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5092b8739bf05a84d9f8b0e23194fca7617674d2a608cde0882090a6aa2f6fd1-89571a3e733ea7dff364fda8ce57d29b1a041801bfe38839b08e90b454f6aad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonis")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43544")[#strong[#text("Antonis")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("I think the problem lies with $G$- and not with equidecomposablity. You could try to “manualy” hyphenate the word with \\- at the appropriate place.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43545")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2010")])]

#text("There might be some quirky “feature” deep within TeX which doesn’t like having two hyphens in the same word. ")#strong[#text("Antonis")]#text("‘ suggestion with regard to a discretionary hyphen sounds as good as any.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("But in any event the publisher will presumably have professional typesetting to deal with these issues in a better way than I can…")
]

#text("Ah, yes, having an actual publisher probably makes a difference! I’ve been doing an awful lot of LaTeX work lately for various print-on-demand niche publications, so I tend to forget about things like that. (-:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43583")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2010")])]

#text("Try $G$\\nobreakdash-\\hspace{0pt}equidecomposability. Then latex will break decomposability as it usually does (or as overrided with \\hyphenate{}). Generally, hyperref should be the last package, but it does not work nicely with some other packages, for example with the cite package.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43586")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2010")])]

#text("Ah, that worked, thanks! It will appear in the next round of revisions of the ms.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43546")[#strong[#text("An Epsilon of Room « Information Flow")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2010")]

#text("[…] I’ve put my paper-reading obsession on hold for a second after discovering Tao’s “An Epsilon of Room“, chronicling the third year of his incredible […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("Minor remark for log-convexity of L_p norms (Lemma 1.11.5): the algebra is a bit different in the last (complex interpolation) proof on p. 184, revise “specialising to s:=\\theta”.")

#emph[#text("[Corrected, thanks – this will appear in the next revision. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43595")[#strong[#text("Return to LaTeX | neverendingbooks")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")]

#text("[…] better than Terry Tao to teach me a more proficient way of blogging? A few days ago, Terry announced he will soon have his 5th (!!) book out, after three years of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ca9b21ed639971fe0dd8f127397a44d17587342eb081208f5908fdd6567e0-67b88326b3417e4cea1a4c861181ac9944d6b619a7c5e33a6a75bcd67c609bf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomer")]], [#link("https://terrytao.wordpress.com/2010/02/07/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/#comment-43597")[#strong[#text("tomer")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("“Mathematical blog” – now that’s an expression you don’t hear everyday.")#linebreak()#text(" good work")
]
