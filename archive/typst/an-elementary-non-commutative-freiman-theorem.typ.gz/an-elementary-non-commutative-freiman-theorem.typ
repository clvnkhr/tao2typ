// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:56.822502+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An elementary non-commutative Freiman theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An elementary non-commutative Freiman theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")[#text("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Let ")#mi("{X}")#text(" be a finite subset of a non-commutative group ")#mi("{G}")#text(". As mentioned ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("previously on this blog")]#text(" (as well as in the current ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("logic reading seminar")]#text("), there is some interest in classifying those ")#mi("{X}")#text(" which obey ")#emph[#text("small doubling")]#text(" conditions such as ")#tao-math("{\\left|X \\cdot X\\right| = O(\\left|X\\right|)}", block: false)#text(" or ")#tao-math("{\\left|X \\cdot X^{-1}\\right| = O(\\left|X\\right|)}", block: false)#text(". A full classification here has still not been established. However, I wanted to record here an elementary argument (based on Exercise 2.6.5 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text(", which in turn is based on ")#link("http://www.ams.org/mathscinet-getitem?mr=1840101")[#text("this paper of Izabella Laba")]#text(") that handles the case when ")#tao-math("{\\left|X \\cdot X\\right|}", block: false)#text(" is very close to ")#tao-math("{\\left|X\\right|}", block: false)#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" ")#metadata(none) <tao-e835d0bf51a4ea9360cc>#text(" If ")#tao-math("{\\left|X^{-1} \\cdot X\\right| < \\frac{3}{2} \\left|X\\right|}", block: false)#text(", then ")#mi("{X \\cdot X^{-1}}")#text(" and ")#mi("{X^{-1} \\cdot X}")#text(" are both finite groups, which are conjugate to each other. In particular, ")#mi("{X}")#text(" is contained in the right-coset (or left-coset) of a group of order less than ")#tao-math("{\\frac{3}{2} \\left|X\\right|}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#metadata(none) <tao-8fbd42ad079a6ceeaf6c>#text(" The constant ")#mi("{\\frac{3}{2}}")#text(" is completely sharp; consider the case when ")#mi("{X = \\{e, x\\}}")#text(" where ")#mi("{e}")#text(" is the identity and ")#mi("{x}")#text(" is an element of order larger than ")#mi("{2}")#text(". This is a small example, but one can make it as large as one pleases by taking the direct product of ")#mi("{X}")#text(" and ")#mi("{G}")#text(" with any finite group. In the converse direction, we see that whenever ")#mi("{X}")#text(" is contained in the right-coset ")#mi("{S \\cdot x}")#text(" (resp. left-coset ")#mi("{x \\cdot S}")#text(") of a group of order less than ")#tao-math("{2\\left|X\\right|}", block: false)#text(", then ")#mi("{X \\cdot X^{-1}}")#text(" (resp. ")#mi("{X^{-1} \\cdot X}")#text(") is necessarily equal to all of ")#mi("{S}")#text(", by the inclusion-exclusion principle (see the proof below for a related argument).")
]

#emph[#text("Proof:")]#text(" We begin by showing that ")#mi("{S := X \\cdot X^{-1}}")#text(" is a group. As ")#mi("{S}")#text(" is symmetric and contains the identity, it suffices to show that this set is closed under addition.")

#text("Let ")#mi("{a, b \\in S}")#text(". Then we can write ")#mi("{a=xy^{-1}}")#text(" and ")#mi("{b=zw^{-1}}")#text(" for ")#mi("{x,y,z,w \\in X}")#text(". If ")#mi("{y}")#text(" were equal to ")#mi("{z}")#text(", then ")#mi("{ab = xw^{-1} \\in X \\cdot X^{-1}}")#text(" and we would be done. Of course, there is no reason why ")#mi("{y}")#text(" should equal ")#mi("{z}")#text("; but we can use the hypothesis ")#tao-math("{\\left|X^{-1} \\cdot X\\right| < \\frac{3}{2}\\left|X\\right|}", block: false)#text(" to boost this as follows. Observe that ")#mi("{x^{-1} \\cdot X}")#text(" and ")#mi("{y^{-1} \\cdot X}")#text(" both have cardinality ")#tao-math("{\\left|X\\right|}", block: false)#text(" and lie inside ")#mi("{X^{-1} \\cdot X}")#text(", which has cardinality strictly less than ")#tao-math("{\\frac{3}{2} \\left|X\\right|}", block: false)#text(". By the inclusion-exclusion principle, this forces ")#mi("{x^{-1} \\cdot X \\cap y^{-1} \\cdot X}")#text(" to have cardinality greater than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(". In other words, there exist more than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(" pairs ")#mi("{x^{\\prime},y^{\\prime} \\in X}")#text(" such that ")#mi("{x^{-1} x^{\\prime} = y^{-1} y^{\\prime}}")#text(", which implies that ")#mi("{a = x^{\\prime} (y^{\\prime})^{-1}}")#text(". Thus there are more than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(" elements ")#mi("{y^{\\prime} \\in X}")#text(" such that ")#mi("{a = x^{\\prime} (y^{\\prime})^{-1}}")#text(" for some ")#mi("{x^{\\prime}\\in X}")#text(" (since ")#mi("{x^{\\prime}}")#text(" is uniquely determined by ")#mi("{y^{\\prime}}")#text("); similarly, there exists more than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(" elements ")#mi("{z^{\\prime} \\in X}")#text(" such that ")#mi("{b = z^{\\prime} (w^{\\prime})^{-1}}")#text(" for some ")#mi("{w^{\\prime} \\in X}")#text(". Again by inclusion-exclusion, we can thus find ")#mi("{y^{\\prime}=z^{\\prime}}")#text(" in ")#mi("{X}")#text(" for which one has simultaneous representations ")#mi("{a = x^{\\prime} (y^{\\prime})^{-1}}")#text(" and ")#mi("{b = y^{\\prime} (z^{\\prime})^{-1}}")#text(", and so ")#mi("{ab = x^{\\prime}(z^{\\prime})^{-1} \\in X \\cdot X^{-1}}")#text(", and the claim follows.")

#text("In the course of the above argument we showed that every element of the group ")#mi("{S}")#text(" has more than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(" representations of the form ")#mi("{xy^{-1}}")#text(" for ")#mi("{x,y \\in X}")#text(". But there are only ")#tao-math("{\\left|X\\right|^2}", block: false)#text(" pairs ")#mi("{(x,y)}")#text(" available, and thus ")#tao-math("{\\left|S\\right| < 2\\left|X\\right|}", block: false)#text(".")

#text("Now let ")#mi("{x}")#text(" be any element of ")#mi("{X}")#text(". Since ")#mi("{X \\cdot x^{-1} \\subset S}")#text(", we have ")#mi("{X \\subset S \\cdot x}")#text(", and so ")#mi("{X^{-1} \\cdot X \\subset x^{-1} \\cdot S \\cdot x}")#text(". Conversely, every element of ")#mi("{x^{-1} \\cdot S \\cdot x}")#text(" has exactly ")#tao-math("{\\left|S\\right|}", block: false)#text(" representations of the form ")#mi("{z^{-1} w}")#text(" where ")#mi("{z, w \\in S \\cdot x}")#text(". Since ")#mi("{X}")#text(" occupies more than half of ")#mi("{S \\cdot x}")#text(", we thus see from the inclusion-exclusion principle, there is thus at least one representation ")#mi("{z^{-1} w}")#text(" for which ")#mi("{z, w}")#text(" both lie in ")#mi("{X}")#text(". In other words, ")#mi("{x^{-1} \\cdot S \\cdot x = X^{-1} \\cdot X}")#text(", and the claim follows. ")#mi("\\Box")

#text("To relate this to the classical doubling constants ")#tao-math("{\\left|X \\cdot X\\right|/\\left|X\\right|}", block: false)#text(", we first make an easy observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-fd45a1e4147319a781bf>#text(" If ")#tao-math("{\\left|X \\cdot X\\right| < 2\\left|X\\right|}", block: false)#text(", then ")#mi("{X \\cdot X^{-1} = X^{-1} \\cdot X}")#text(".")
]

#text("Again, this is sharp; consider ")#mi("{X}")#text(" equal to ")#mi("{\\{x,y\\}}")#text(" where ")#mi("{x,y}")#text(" generate a free group.")

#emph[#text("Proof:")]#text(" Suppose that ")#mi("{xy^{-1}}")#text(" is an element of ")#mi("{X \\cdot X^{-1}}")#text(" for some ")#mi("{x,y \\in X}")#text(". Then the sets ")#mi("{X \\cdot x}")#text(" and ")#mi("{X \\cdot y}")#text(" have cardinality ")#tao-math("{\\left|X\\right|}", block: false)#text(" and lie in ")#mi("{X \\cdot X}")#text(", so by the inclusion-exclusion principle, the two sets intersect. Thus there exist ")#mi("{z,w \\in X}")#text(" such that ")#mi("{zx=wy}")#text(", thus ")#mi("{xy^{-1}=z^{-1}w \\in X^{-1} \\cdot X}")#text(". This shows that ")#mi("{X \\cdot X^{-1}}")#text(" is contained in ")#mi("{X^{-1} \\cdot X}")#text(". The converse inclusion is proven similarly. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(" If ")#tao-math("{\\left|X \\cdot X\\right| < \\frac{3}{2} \\left|X\\right|}", block: false)#text(", then ")#mi("{S := X \\cdot X^{-1}}")#text(" is a finite group of order ")#tao-math("{\\left|X \\cdot X\\right|}", block: false)#text(", and ")#mi("{X \\subset S \\cdot x = x \\cdot S}")#text(" for some ")#mi("{x}")#text(" in the normaliser of ")#mi("{S}")#text(".")
]

#text("The factor ")#mi("{\\frac{3}{2}}")#text(" is sharp, by the same example used to show sharpness of Proposition ")#link(<tao-e835d0bf51a4ea9360cc>)[#text("1")]#text(". However, there seems to be some room for further improvement if one weakens the conclusion a bit; see below the fold.")

#emph[#text("Proof:")]#text(" Let ")#mi("{S = X^{-1} \\cdot X = X \\cdot X^{-1}}")#text(" (the two sets being equal by Lemma ")#link(<tao-fd45a1e4147319a781bf>)[#text("2")]#text("). By the argument used to prove Lemma ")#link(<tao-fd45a1e4147319a781bf>)[#text("2")]#text(", every element of ")#mi("{S}")#text(" has more than ")#tao-math("{\\frac{1}{2}\\left|X\\right|}", block: false)#text(" representations of the form ")#mi("{xy^{-1}}")#text(" for ")#mi("{x,y \\in X}")#text(". By the argument used to prove Proposition ")#link(<tao-e835d0bf51a4ea9360cc>)[#text("1")]#text(", this shows that ")#mi("{S}")#text(" is a group; also, since there are only ")#tao-math("{\\left|X\\right|^2}", block: false)#text(" pairs ")#mi("{(x,y)}")#text(", we also see that ")#tao-math("{\\left|S\\right| < 2\\left|X\\right|}", block: false)#text(".")

#text("Pick any ")#mi("{x \\in X}")#text("; then ")#mi("{x^{-1} \\cdot X, X \\cdot x^{-1} \\subset S}")#text(", and so ")#mi("{X \\subset x\\cdot S, S \\cdot x}")#text(". Because every element of ")#mi("{x \\cdot S \\cdot x}")#text(" has ")#tao-math("{\\left|S\\right|}", block: false)#text(" representations of the form ")#mi("{yz}")#text(" with ")#mi("{y \\in x \\cdot S}")#text(", ")#mi("{z \\in S \\cdot x}")#text(", and ")#mi("{X}")#text(" occupies more than half of ")#mi("{x \\cdot S}")#text(" and of ")#mi("{S \\cdot x}")#text(", we conclude that each element of ")#mi("{x \\cdot S \\cdot x}")#text(" lies in ")#mi("{X \\cdot X}")#text(", and so ")#mi("{X \\cdot X = x \\cdot S \\cdot x}")#text(" and ")#tao-math("{\\left|S\\right| = \\left|X \\cdot X\\right|}", block: false)#text(".")

#text("The intersection of the groups ")#mi("{S}")#text(" and ")#mi("{x \\cdot S \\cdot x^{-1}}")#text(" contains ")#mi("{X \\cdot x^{-1}}")#text(", which is more than half the size of ")#mi("{S}")#text(", and so we must have ")#mi("{S = x \\cdot S \\cdot x^{-1}}")#text(", i.e. ")#mi("{x}")#text(" normalises ")#mi("{S}")#text(", and the proposition follows. ")#mi("\\Box")

#text("Because the arguments here are so elementary, they extend easily to the infinitary setting in which ")#mi("{X}")#text(" is now an infinite set, but has finite measure with respect to some translation-invariant Kiesler measure ")#mi("{\\mu}")#text(". We omit the details. (I am hoping that this observation may help simplify some of the theory in that setting.)")

#metadata(none) <tao-4ddb260e9fe9d395efb8>

#heading(level: 1)[#strong[#text(" — 1. Beyond the ")#mi("{3/2}")#text(" barrier — ")]]

#text("It appears that one can push the arguments a bit beyond the ")#mi("{3/2}")#text(" barrier, though of course one has to weaken the conclusion in view of the counterexample in Remark ")#link(<tao-8fbd42ad079a6ceeaf6c>)[#text("1")]#text(". Here I give a result that increases ")#mi("{3/2=1.5}")#text(" to the golden ratio ")#mi("{\\phi := (1+\\sqrt{5})/2 = 1.618\\ldots}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Weak non-commutative Kneser theorem)")]#text(" If ")#tao-math("{\\left|X^{-1} \\cdot X\\right|, \\left|X \\cdot X^{-1}\\right| \\leq K \\left|X\\right|}", block: false)#text(" for some ")#mi("{1 < K < \\phi}")#text(", then ")#mi("{X \\cdot X^{-1} = H \\cdot Z}")#text(" for some finite subgroup ")#mi("{H}")#text(", and some finite set ")#mi("{Z}")#text(" with ")#tao-math("{\\left|Z\\right| \\leq C(K)}", block: false)#text(" for some ")#mi("{C(K)}")#text(" depending only on ")#mi("{K}")#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{S := X \\cdot X^{-1}}")#text(". Let us say that ")#mi("{h}")#text(" ")#emph[#text("symmetrises")]#text(" ")#mi("{S}")#text(" if ")#mi("{h \\cdot S = S}")#text(", and let ")#mi("{H}")#text(" be the set of all ")#mi("{h}")#text(" that symmetrise ")#mi("{S}")#text(". It is clear that ")#mi("{H}")#text(" is a finite group with ")#mi("{H \\cdot S = S}")#text(" and thus ")#mi("{S \\cdot H = S}")#text(" also.")

#text("For each ")#mi("{z \\in S}")#text(", let ")#mi("{r(z)}")#text(" be the number of representations of ")#mi("{z}")#text(" of the form ")#mi("{z=xy^{-1}}")#text(" with ")#mi("{x,y \\in X}")#text(". Double counting shows that ")#tao-math("{\\sum_{z \\in S} r(z) = \\left|X\\right|^2}", block: false)#text(", while by hypothesis ")#tao-math("{\\left|S\\right| \\leq K\\left|X\\right|}", block: false)#text("; thus the average value of ")#mi("{r(z)}")#text(" is at least ")#tao-math("{\\left|X\\right|/K}", block: false)#text(". Since ")#mi("{1 < K < \\phi}")#text(", ")#mi("{1/K > K-1}")#text(". Since ")#tao-math("{r(z) \\leq \\left|X\\right|}", block: false)#text(" for all ")#mi("{z}")#text(", we conclude that ")#tao-math("{r(z) > (K-1) \\left|X\\right|}", block: false)#text(" for at least ")#tao-math("{c(K) \\left|X\\right|}", block: false)#text(" values of ")#mi("{z \\in S}")#text(", for some explicitly computable ")#mi("{c(K) > 0}")#text(".")

#text("Suppose ")#mi("{z, w \\in S}")#text(" is such that ")#tao-math("{r(z) > (K-1)\\left|X\\right|}", block: false)#text(", thus ")#mi("{z}")#text(" has more than ")#tao-math("{(K-1)\\left|X\\right|}", block: false)#text(" representations of the form ")#mi("{xy^{-1}}")#text(" with ")#mi("{x,y \\in X}")#text(". On the other hand, the argument used to prove Proposition ")#link(<tao-e835d0bf51a4ea9360cc>)[#text("1")]#text(" shows that ")#mi("{w}")#text(" has at least ")#tao-math("{(2-K)\\left|X\\right|}", block: false)#text(" representations of the form ")#mi("{x^{\\prime} (y^{\\prime})^{-1}}")#text(" with ")#mi("{x^{\\prime},y^{\\prime} \\in X}")#text(". By the inclusion-exclusion formula, we can thus find representations for which ")#mi("{y=x^{\\prime}}")#text(", which implies that ")#mi("{zw \\in S}")#text(". Since ")#mi("{w \\in S}")#text(" was arbitrary, this implies that ")#mi("{z \\in H}")#text(". Thus ")#tao-math("{\\left|H\\right| \\geq c(K) \\left|X\\right|}", block: false)#text(". Since ")#mi("{S = H \\cdot S}")#text(" and ")#tao-math("{\\left|S\\right| \\leq K\\left|X\\right|}", block: false)#text(", this implies that ")#mi("{S}")#text(" can be covered by at most ")#mi("{C(K)}")#text(" right-cosets of ")#mi("{S}")#text(" for some ")#mi("{C(K)}")#text(" depending only on ")#mi("{K}")#text(", and the claim follows. ")#mi("\\Box")

#text("It looks like one should be able to get a bit more structural information on ")#mi("{X}")#text(" than is given by the above conclusion, and I doubt the golden ratio is sharp either (the correct threshold should be ")#mi("{2}")#text(", in analogy with the commutative Kneser theorem; after that, the conclusion will fail, as can be seen by taking ")#mi("{X}")#text(" to be a long geometric progression). Readers here are welcome to look for improvements to these results, of course.")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Terry,")

#text("Coincidentally I was just looking into this same issue in connection with some lecture notes I’m writing. I agree that the threshold should be 2.")

#text("The 3/2 result and also golden ratio result you give are actually contained in an admittedly somewhat obscure paper of Freiman from 1962, the main aim of which is to completely classify sets with doubling at most 8/5. Here is the original reference:")

#text("Groups and the inverse problems of additive number theory. (Russian) Number-theoretic studies in the Markov spectrum and in the structural theory of set addition (Russian), pp. 175–183. Kalinin. Gos. Univ., Moscow, 1973.")

#text("It’s in Russian. A Masters student of mine at Bristol, Lloyd Husbands, did a very nice translation-exposition which, if I can get his permission, I will link to.")

#text("I think that in the torsion-free case there is an argument of Kemperman which will take one up to 2.")

#text("Ben")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42363")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Thanks Ben! I had a suspicion that these results must already be in the literature, but did not have the reference (though now that you mention it, the 8/5 result does ring a bell, I think it was referenced in the K=2 paper, which I believe is actually due to ")#link("http://www.ams.org/mathscinet-getitem?mr=1722258")[#text("Hamiduone, Llado and Serra")]#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42347")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Terry,")

#text("Two points pertaining to the previous post, both rather obvious: firstly, it was by me, and secondly, the paper of Freiman is in fact from 1973 and not from 1962.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42349")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("Terry, there is a small typo in the proof of proposition 1. It should read ")#mi("b=(z^\\prime)(w^\\prime)^{-1}")#text(" instead of ")#mi("b-(z^\\prime)(w^\\prime)^{-1}")#text(". Also, the parentheses around ")#mi("z^\\prime")#text(" are redundant.")

#text("Regards,")#linebreak()#text(" Miguel")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d62deff9686ab52546daf3677e19aff4eb3cb3f58884a643c014583ec3c1d1c-21c6ce8fc362d35af8ba8538f5d47b83b82b7a4833aa837472a8d4b86ca5e9b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")])]

#text("I take it that proposition 1 should read “group of order less than ")#tao-math("2\\left|X\\right|", block: false)#text("” instead of “group of order less than ")#tao-math("\\frac32 \\left|X\\right|", block: false)#text("“?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42391")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2009")])]

#text("Well, both are true, but ")#tao-math("\\frac{3}{2} \\left|X\\right|", block: false)#text(" is the sharp bound, since S has cardinality equal to that of ")#mi("X^{-1} \\cdot X")#text(". (The preliminary bound ")#tao-math("\\left|S\\right| < 2 \\left|X\\right|", block: false)#text(" is established in the course of the proof, but is eventually improved upon.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Seva")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42397")[#strong[#text("Seva")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2009")])]

#text("On a historical note, the proof of Proposition 4 is essentially the same as")#linebreak()#text(" that of Theorem 3 in ")#link("http://jlms.oxfordjournals.org/cgi/content/abstract/62/1/27")[#text("my 2000")#linebreak()#text(" paper")]#text(", where it is shown that if ")#mi("A")#text(" is a finite subset of a group")#linebreak()#text(" (written additively, but not assumed to be Abelian) such that its restricted")#linebreak()#text(" sumset ")#mi("A\\dot+A:=\\{a^{\\prime}+a^{\\prime\\prime}\\colon a^{\\prime},a^{\\prime\\prime}\\in A,\\ a^{\\prime}\\ne a^{\\prime\\prime}\\}")#text(" differs from")#linebreak()#text(" the “regular” sumset ")#mi("A+A")#text(", then it is large: ")#tao-math("\\left|A\\dot+A\\right|>\\phi\\left|A\\right|-(L-2)", block: false)#text(" (where ")#mi("L")#text(" is the largest number of elements")#linebreak()#text(" of the group, sharing the same doubling). I also conjectured that, indeed, if")#linebreak()#text(" ")#mi("A\\dot+B\\ne A+B")#text(", then ")#tao-math("\\left|A\\dot+B\\right|>\\left|A\\right|+\\left|B\\right|-(L-2)", block: false)#text(" — at least in")#linebreak()#text(" the case where the underlying group is Abelian.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-commutative Freiman theorems, and model theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-42723")[#strong[#text("Non-commutative Freiman theorems, and model theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("[…] a finite subgroup by an element in the normaliser of . More generally, as we mentioned earlier in this post, it can be shown by elementary means that if , where is the golden ratio, then sets of doubling […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Linear approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-43383")[#strong[#text("Linear approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2010")])]

#text("[…] proving this statement is the noncommutative Freiman theorem problem, discussed in these earlier blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-49608")[#strong[#text("A note on approximate subgroups of GL_n(C) and uniformly nonamenable groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("[…] a new proof of a “noncommutative Freiman” type theorem in linear groups . As discussed in earlier blog posts, a general question in additive (or multiplicative) combinatorics is to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamidoune’s Freiman-Kneser theorem for nonabelian groups « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-50696")[#strong[#text("Hamidoune’s Freiman-Kneser theorem for nonabelian groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2011")])]

#text("[…] Hamidoune had recently died. Hamidoune worked in additive combinatorics, and had recently solved a question on noncommutative Freiman-Kneser theorems posed by myself on this blog last year. Namely, Hamidoune showed Theorem 1 (Noncommutative Freiman-Kneser theorem for small doubling) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamidoune’s Freiman-Kneser theorem for nonabelian groups « IMAGINATION of MATH")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-50999")[#strong[#text("Hamidoune’s Freiman-Kneser theorem for nonabelian groups « IMAGINATION of MATH")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2011")])]

#text("[…] Hamidoune had recently died. Hamidoune worked in additive combinatorics, and had recently solved a question on noncommutative Freiman-Kneser theorems posed by myself on this blog last year. Namely, Hamidoune showed Theorem 1 (Noncommutative Freiman-Kneser theorem for small doubling) Let […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a78cd6fbb48b9d48f2a5210a2fff4c934afec7d23733b8f701a359c5b757025d-147b230ebd514b11bd4e4f67d808022f717ff447d64530127afc7598ec5d76e6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sandeep Murthy")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-230193")[#strong[#text("Sandeep Murthy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2013")])]

#text("Hi, wouldn’t Proposition 1 be true for all finite groups, abelian and non-abelian?")

#emph[#text("[Yes. In this context, “non-commutative” should really be read as “not necessarily commutative”. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-467976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#text("What is the explicit value of C(K) in the proof of Proposition 4")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-467977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2016")])]

#text("The above argument works with ")#mi("c(K) = \\frac{1}{K} - K + 1")#text(" and ")#mi("C(K) = \\frac{K}{c(K)}")#text(". It may be though that one can do better (e.g. using submodularity methods ")#link("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/")[#text("https://terrytao.wordpress.com/2011/03/12/hamidounes-freiman-kneser-theorem-for-nonabelian-groups/")]#text(" ).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/11/10/an-elementary-non-commutative-freiman-theorem/#comment-685781")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2024")])]

#text("Hello,")

#text("Is there a matrix analogy of Freiman’s theorem?")
]
