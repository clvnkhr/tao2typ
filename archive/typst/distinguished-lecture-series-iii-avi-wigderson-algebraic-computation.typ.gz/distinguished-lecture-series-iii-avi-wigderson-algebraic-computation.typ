// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/
// Converted to Typst by tao2typ: "2026-10-14T06:53:06.870907+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Avi Wigderson, “Algebraic computation”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Avi Wigderson, “Algebraic computation”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/")[#text("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Avi_Wigderson")[#text("Avi Wigderson")]#text("‘s final talk in his ")#link("http://www.math.ucla.edu/dls/index.html")[#text("Distinguished Lecture Series")]#text(" on “")#link("http://www.math.ucla.edu/dls/2008/aw.html")[#text("Computational complexity")]#text("” was entitled “")#link("http://www.math.ucla.edu/dls/2008/absaw3.html")[#text("Arithmetic computation")]#text("“; the complexity theory of ")#emph[#text("arithmetic")]#text(" circuits rather than ")#link("http://en.wikipedia.org/wiki/Boolean_circuit")[#text("boolean circuits")]#text(".")

#metadata(none) <tao-564a5ce4fb0d221da010>#text("Arithmetic circuits manipulate inputs and outputs in a given field, such as the complex numbers (or more generally, a field of ")#link("http://en.wikipedia.org/wiki/Characteristic_%28algebra%29")[#text("characteristic")]#text(" 0, to avoid having to deal with arithmetic “shortcuts” coming from identities such as ")#mi("x^2=x")#text(" in ")#mi("{\\Bbb F}_2")#text("). There are many models for such circuits, but one simple one is to create circuits by composing addition ")#link("http://en.wikipedia.org/wiki/Logic_gate")[#text("gates")]#text(" (which take two inputs x and y and return x+y as an output), multiplication gates (which take two inputs x, y and return xy as an output), and scalar multiplication gates (which take one input x and return cx as output, where c is a fixed constant for each such gate). Despite the name, circuits are not allowed to contain loops; gates can only use the outputs provided by earlier gates, although one is definitely allowed to reuse a given output for multiple future gates.")

#text("For simplicity let us view the scalar multiplication gates as being “free” and only count the addition and multiplication gates when counting complexity. Thus, for instance, to perform an ")#link("http://en.wikipedia.org/wiki/Inner_product_space")[#text("inner product")]#text(" computation")

#align(center)[#tao-fit-display[#mitex("(x_1,\\ldots,x_n), (y_1,\\ldots,y_n) \\mapsto x_1 y_1 + \\ldots + x_n y_n")]]

#text("requires 2n-1 gates (n to multiply the pairs ")#mi("x_i")#text(" and ")#mi("y_i")#text(" together, and then n-1 to add together the resulting pairs). It is not difficult to show that this 2n-1 is sharp. More generally, given any polynomial operation p with many inputs ")#mi("x_1,\\ldots,x_n")#text(" and one output, we define the ")#link("http://en.wikipedia.org/wiki/Circuit_complexity")[#text("circuit complexity")]#text(" S(p) of p to be the least number of gates needed to build an arithmetic circuit that can generate p from ")#mi("x_1,\\ldots,x_n")#text("; it is clear that p has to be polynomial in order to be generated by such circuits. We can also treat the complexity ")#mi("S(p_1,\\ldots,p_k)")#text(" of multiple polynomials of some variables ")#mi("x_1,\\ldots,x_n")#text(" by considering the least number of gates required to build a circuit that can generate all outputs from the given inputs. A good example here is ")#link("http://en.wikipedia.org/wiki/Matrix_multiplication")[#text("matrix multiplication")]#text(" ")#mi("A, B \\mapsto AB")#text(" of two ")#mi("n \\times n")#text(" matrices A, B, in which there are ")#mi("2n^2")#text(" inputs (the coefficients of A and B) and ")#mi("n^2")#text(" outputs (the coefficients of AB. The obvious matrix multiplication algorithm requires a circuit of complexity ")#mi("O(n^3)")#text(", thus ")#mi("S(AB) = O(n^3)")#text(". But this is not best possible; the fast matrix multiplication methods ")#link("http://en.wikipedia.org/wiki/Strassen_algorithm")[#text("of Strassen")]#text(" and later authors use clever recursive techniques to reduce the exponent, with the current record being ")#mi("S(AB) = O(n^{2.38\\ldots})")#text(". Conversely, it is clear that S(AB) should be at least ")#mi("n^2")#text(", since each of the inputs must be connected to at least one gate. But the true order of S(AB) is not known.")

#text("More generally, the problem of computing S(p) or ")#mi("S(p_1,\\ldots,p_k)")#text(" for various interesting polynomials is an important one, to which there are still only very partial answers. Even the complexity of a single polynomial p(x) of a single variable x is not easy. If p has degree d, then clearly ")#mi("S(p) = O(d)")#text(", and counting arguments can show that this is sharp for “generic” p, but for many p one can do a lot better; for instance it is not hard to see that ")#mi("S(x^d) = O(\\log d)")#text(" by repeatedly squaring x and then combining some of the iterated squares to form ")#mi("x^d")#text(". On the other hand, it is clear that we have a lower bound ")#mi("S(x^d) \\gg \\log d")#text(", since a circuit of m gates can only generate a polynomial of degree at most ")#mi("2^m")#text(". (Here we see the usefulness of the degree concept in arithmetic circuit complexity; there does not seem to be an analogously useful concept in boolean circuit complexity, thus making the former subject easier than the latter.)")

#text("Avi noted, though, that it was still an open question to find an “natural” polynomial p of degree d for which S(p) grew faster than any power of ")#mi("\\log d")#text(". (One could take a polynomial p whose coefficients are all algebraically independent, but this is “cheating”.) In particular, it is not known if")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("S((x+1) \\ldots (x+d)) \\gg \\log^C d")]]

#text("for every C. But… if this claim failed, then one can show that factoring n-bit numbers can be done in polynomial time! (The reason is that if (1) failed, then one can compute d! mod N quickly for n-bit integers d and N by using a polynomial size circuit modulo N, which basically allows one to determine whether all prime factors of N are less than any given threshold d, from which one can quickly isolate each individual prime factor.) But this already shows how difficult we expect these problems to be in general.")

#text("Here are some other interesting examples of polynomials whose complexity we would like to understand:")

#enum(start: 1, 
[#text("The determinant polynomial ")#mi("A \\mapsto \\det(A)")#text(" on ")#mi("n^2")#text(" variables. It can be shown that ")#mi("S(\\det) = O(n^3)")#text(" by ")#link("http://en.wikipedia.org/wiki/Gaussian_elimination")[#text("Gaussian elimination")]#text(" (admittedly, this procedure uses divisions, but there is a way to rework it so that divisions are avoided – due to Strassen, apparently, though I don’t have the reference), and by using fast matrix multiplication methods one can shave this down to ")#mi("O(n^{2.38\\ldots})")#text(" as before. Conversely, the trivial lower bound on complexity here is ")#mi("\\gg n^2")#text(".")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Permanent")[#text("permanent")]#text(" ")#mi("A \\mapsto \\text{per}(A)")#text(" on ")#mi("n^2")#text(" variables; Avi referred to the permanent as the determinant’s “bad cousin”. Here, the best known upper bound for ")#mi("S(\\text{per})")#text(" is something like ")#mi("2^{O(n)}")#text(". The trivial lower bound is ")#mi("\\gg n^2")#text(". Closing the exponential gap here is a major challenge, which Avi returned to later in the lecture.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Symmetric_polynomial")[#text("symmetric polynomial")]#text(" ")#mi("\\text{Sym}^n_d(x_1,\\ldots,x_n)   := \\sum_{1 \\leq i_1 < \\ldots < i_d \\leq n} x_{i_1} \\ldots x_{i_d}")#text(" of degree d on n variables. By recursively describing the symmetric polynomials of degree up to d in terms of the same polynomials on one fewer variable, one can obtain an upper bound ")#mi("S(  \\text{Sym}^n_d ) = O(nd)")#text(". The trivial lower bound is ")#mi("\\gg n")#text(".")]
)

#text("It is not known whether any of the above upper bounds are sharp. But ")#link("http://www.ams.org/mathscinet-getitem?mr=693063")[#text("Baur and Strassen have shown")]#text(" some logarithmic improvements on some of the lower bounds. For instance:")

#enum(start: 1, 
[#mi("S( \\text{Sym}^n_d ) \\gg n\\log d")#text(";")],
[#mi("S( \\det ) \\gg n^2 \\log n")#text(";")],
[#mi("S( x_1^d + \\ldots + x_n^d ) \\gg n \\log d")#text(".")],
[#mi("S(x_1^d, \\ldots, x_n^d ) \\gg n\\log d")#text(".")]
)

#text("(Note that the bounds in (3) and (4) are tight.)")

#text("Let’s first look at (4). This looks easy: after all; each individual polynomial ")#mi("x_i^d")#text(" requires ")#mi("\\gg \\log d")#text(" gates to compute, and the polynomials are clearly so “independent” that there should be no advantage in sharing computation, leading to a lower bound ")#mi("\\gg n \\log d")#text(". But this naive argument is not valid. To see this, consider the problem of computing a product Ax of a constant ")#mi("n \\times n")#text(" matrix A (with all entries algebraically independent) and a vector")#linebreak()#text(" x of n unknown entries. Because this computation involves ")#mi("n^2")#text(" independent constants, it must require ")#mi("\\gg n^2")#text(" gates. Now if ")#mi("x_1, \\ldots, x_n")#text(" are n vectors of n distinct unknowns each (thus having ")#mi("n^3")#text(" variables in all), the same reasoning as before would suggest that computing ")#mi("A x_1, \\ldots, A x_n")#text(" simultaneously should require ")#mi("\\gg n^3")#text(" gates. But the fast matrix multiplication algorithms imply that we can in fact rely on just ")#mi("O( n^{2.38\\ldots})")#text(" gates instead! So one’s naive intuition on this subject can sometimes be wrong; there can be clever ways to save computation even when no obvious opportunities for such savings exist.")

#text("Due to the central role of polynomials in arithmetic complexity, it is not surprising that algebraic geometry plays an important role in the subject. For instance, the basic concept of the ")#emph[#text("degree")]#text(" of a ")#link("http://en.wikipedia.org/wiki/Algebraic_variety")[#text("variety")]#text(" (or more precisely, an ")#link("http://en.wikipedia.org/wiki/Algebraic_set")[#text("algebraic set")]#text(") ")#mi("V(p_1,\\ldots,p_m) := \\{ p_1 = \\ldots = p_m = 0 \\}")#text(", which can be defined for instance (at least in the case where the underlying field is algebraically closed) as the maximum cardinality that an intersection of that variety with an affine subspace of the complementary dimension can have. Thus for instance a line has degree 1, a conic section has degree 2, an elliptic curve has degree 3, and so forth. A basic result from algebraic geometry (which generalises ")#link("http://en.wikipedia.org/wiki/Bezout%27s_theorem")[#text("Bezout’s theorem")]#text(") is that the degree ")#mi("\\deg(V \\cap W)")#text(" of the intersection of two algebraic sets is bounded by the product ")#mi("\\deg(V) \\deg(W)")#text(" of the individual degrees. Also, the affine projection of an algebraic set of degree at most d, is also an algebraic set of degree at most d. From these facts we see that the set of all possible input and output states of a circuit of complexity m form a variety of degree at most ")#mi("2^m")#text(", since each addition gate determines a variety of degree 1 and each multiplication gate determines a variety of degree 2. On the other hand, one can easily check from the definition that the variety ")#mi("\\{ x_1^d-1 = \\ldots = x_n^d-1 = 0 \\}")#text(" has degree ")#mi("d^n")#text(", giving a proof of (4) (note that the complexity of ")#mi("x_1^d-1,\\ldots,x_n^d-1")#text(" and ")#mi("x_1^d,\\ldots,x_n^d")#text(" clearly differ by at most O(n)).")

#text("The same argument does not directly work for (3), but there is a trick based on the upper bound")

#align(center)[#mi("S( \\frac{\\partial p}{\\partial x_1}, \\ldots, \\frac{\\partial p}{\\partial n} ) \\ll S(p)")#text(" (*)")]

#text("which allows one to deduce (3) from (4). (This is an example of how an upper bound on complexity can be used to deduce lower bounds from other lower bounds, which is a common technique in this business.) To prove (*), what one does is take a circuit that computes p and observe that by recursively working backwards from late outputs of this circuit to early outputs, one can compute all the partial derivatives ")#mi("\\partial p/\\partial y")#text(" of the final output p with respect to the value of any intermediate output y (where we temporarily allow ourselves the ability to vary these intermediate variables at will), while only increasing the number of gates by a multiplicative constant.")

#text("A similar argument gives (2), based on first computing the complexity of the inverse operation ")#mi("A \\mapsto A^{-1}")#text(" (here, of course, one has to allow division), which is closely connected to the derivatives of the determinant (via the ")#link("http://en.wikipedia.org/wiki/Cofactor_%28linear_algebra%29")[#text("cofactor")]#text(" expansion). Avi did not discuss the proof of (1), but I presume that it also uses similar techniques.")

#text("Making further progress on complexity of arbitrary arithmetic circuits like this beyond the logarithmic improvements over the trivial bound seems to be very challenging, so Avi then turned to the problem of circuit complexity of ")#emph[#text("depth-bounded")]#text(" circuits, for which more progress has been made. Here, we allow the addition and multiplication gates to take in an arbitrary number of inputs (and in the case of addition gates, we allow arbitrary scalar multiplications, thus we can take an arbitrary linear combination of inputs in a single gate), but we organise the gates in levels, with the inputs at depth j being used to produce outputs at depth j+1, and limit the total depth to be a small number such as 2 or 3. For instance, with depth 1, one can only create linear combinations or products of inputs. With depth 2, one can create any polynomial output, but it is not hard to see that the complexity is comparable to the number of non-zero terms in that polynomial (unless it is a product of linear polynomials, in which case it is comparable to the number of terms in the product). Depth 3 is the first really interesting case – unless the polynomial p factorises into sparse factors, the most efficient way to use depth 3 circuits is is the linear combination of products of linear polynomials (though occasionally one might want to swap the order of addition and multiplication). Let us use ")#mi("S_3(p)")#text(" to denote the number of gates needed to compute p with a depth 3 circuit.")

#text("One expects to have quite large lower bounds on ")#mi("S_3(p)")#text(" for various interesting values of p. For instance, the depth 3 complexity of the determinant is expected to be exponentially large, though this remains open. But in some cases there are clever tricks to compute polynomials quicker than one might first expect. For instance, Ben-Or proved the bound ")#mi("S_3( \\text{Sym}_n^d ) \\ll n^2")#text(", which is surprising given that ")#mi("\\text{Sym}_n^d")#text(" has exponentially many terms (if d is, say, equal to n/2) and also has no obvious factorisation. Actually, this is quite easy to show: with ")#mi("O(n^2)")#text(" gates in a depth 2 circuit one can already compute the quantities ")#mi("P(t) := \\prod_{j=1}^n (x_j + t)")#text(" for ")#mi("t =0,\\ldots,n")#text(", and then one can recover the symmetric polynomials as the coefficients of P via ")#link("http://en.wikipedia.org/wiki/Polynomial_interpolation")[#text("polynomial interpolation")]#text(". This turns out to be tight in the case when d is comparable to n, as shown ")#link("http://www.ams.org/mathscinet-getitem?mr=1867306")[#text("by Shpilka and Wigderson")]#text(".")

#text("Finally, some exponential-type lower bounds on complexity are known if one restricts one’s circuits to not only have bounded depth, but also be ")#emph[#text("homogeneous")]#text(" – which means all intermediate outputs need to be homogeneous polynomials of the inputs. In particular, if one is computing a degree d output, then all multiplicative gates can have order at most d, thus ruling out the polynomial interpolation trick mentioned above (which requires degree n gates). Indeed, with this additional restriction on depth 3 circuits one can show that ")#mi("\\text{Sym}_n^d")#text(" now requires an exponential number of gates in n, if d is equal to (say) n/4. The idea here is to work not with the polynomial p ")#emph[#text("per se")]#text(", but rather with the linear space ")#mi("V_p")#text(" of polynomials generated by its translations or (equivalently, by ")#link("http://en.wikipedia.org/wiki/Taylor_series")[#text("Taylor expansion")]#text(") by its various derivatives. The dimension ")#mi("\\rho(p) := \\dim(V_p)")#text(" can easily be verified to obey the inequalities ")#mi("\\rho(p+q) \\leq\\rho(p)+\\rho(q)")#text(" and ")#mi("\\rho(pq) \\leq \\rho(p) \\rho(q)")#text(". In particular, if p is generated from a depth 3 circuit as the sum of m products of at most d linear polynomials, one has ")#mi("\\rho(p) \\leq m 2^d")#text(". On the other hand, by inspecting how linearly independent the ")#mi("d/2^{th}")#text(" derivatives of ")#mi("\\text{Sym}_n^d")#text(" are, we have the bound ")#mi("\\rho(\\text{Sym}_n^d) \\geq \\binom{n-d/2}{d/2}")#text(". Combining the two we obtain the exponential lower bound.")

#text("Finally, Avi turned to the permanent. ")#link("http://www.ams.org/mathscinet-getitem?mr=526203")[#text("Valiant observed")]#text(" that the permanent of an ")#mi("n \\times n")#text(" matrix A can be re-expressed as the determinant of an ")#mi("m \\times m")#text(" matrix B that depends linearly on A. Unfortunately, in his construction, m is exponentially large in n, and so the best circuit complexity upper bound on the permanent is similarly exponential. Using some algebraic geometry and some Hessian-type objects, ")#link("http://www.ams.org/mathscinet-getitem?mr=2126826")[#text("Mignon-Ressayre observed")]#text(" that the minimal value of m one could take here had to be at least ")#mi("n^2")#text(". In contrast, Valiant proved that if one could obtain a lower bound of the form ")#mi("m \\gg n^C")#text(" for all C, then one necessarily has (an arithmetic version of) ")#mi("P \\neq NP")#text("! Thus we see that these apparently innocuous arithmetic complexity questions are intimately related to the rest of computational complexity theory.")

#text("[")#emph[#text("Update")]#text(", Jan 16: slight change to the degree argument for lower bounding ")#mi("S( x_1^d,\\ldots,x_n^d)")#text(".]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iftikhar Burhanuddin")]], [#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/#comment-24348")[#strong[#text("Iftikhar Burhanuddin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("I’ve made available the audio recordings and pictures of Avi Wigderson’s DLS series of talks here:")

#link("http://www.math.ucla.edu/~ntg/#seminar")[#text("http://www.math.ucla.edu/~ntg/#seminar")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/#comment-24476")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Hi Terry,")

#text("Can you show in more detail why ")#mi("S(Sym_n^d) = O(nd)")#text("? I am still not clear from your hints that")

#text("“By recursively describing the symmetric polynomials of degree up to d in terms of the same polynomials on one fewer variable, one can obtain an upper bound ")#mi("S(Sym_n^d) = O(nd)")#text("”")

#text("As I see it,")

#mi("Sym_n^d = Sym_{n-1}^d + x_n Sym_{n-1}^{d-1}")#text(".")

#text("but can this recurrence result in an ")#mi("O(nd)")#text(" size circuit?")

#text("Moreover, since I’m computer science major, the notion “algebraic")#linebreak()#text(" geometry” terrifies me. Can you provide any good textbooks about it,")#linebreak()#text(" in particular suitbable for non-math major students?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/#comment-24480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Dear Jason,")

#text("Using the recurrence described above, one can get from ")#mi("\\text{Sym}_{n-1}^0, \\ldots, \\text{Sym}_{n-1}^d")#text(" to ")#mi("\\text{Sym}_n^0, \\ldots, \\text{Sym}_n^d")#text(" using a circuit of complexity O(d). Iterating this n times gives the claim.")

#text("I learned algebraic geometry from a number of texts, from which I found Harris’s text to be the most accessible. But perhaps others will have further suggestions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/#comment-24547")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("“Algebraic complexity theory”, by Buergisser, Clausen, Shokrollahi is a good reference. It contains most of the algebra needed for the degree bound (by the way, the variety {x1^d=…=xn^d=0} has degree 1, since it’s a point)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/13/distinguished-lecture-series-iii-avi-wigderson-algebraic-computation/#comment-24562")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Thanks for the reference and the correction! It’s easy enough to fix, of course, by shifting all the ")#mi("x_j^d")#text(" by 1, which I’ve now done.")
]
