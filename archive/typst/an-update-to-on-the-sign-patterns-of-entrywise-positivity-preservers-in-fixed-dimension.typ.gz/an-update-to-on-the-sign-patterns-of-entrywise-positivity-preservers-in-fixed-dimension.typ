// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/
// Converted to Typst by tao2typ: "2026-10-14T10:43:02.952207+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An update to “On the sign patterns of entrywise positivity preservers in fixed dimension”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An update to “On the sign patterns of entrywise positivity preservers in fixed dimension”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")[#text("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.iisc.ac.in/~khare/")[#text("Apoorva Khare")]#text(" and I have updated our paper “")#link("https://arxiv.org/abs/1708.05197")[#text("On the sign patterns of entrywise positivity preservers in fixed dimension")]#text("“, announced at ")#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/")[#text("this post from last month")]#text(". The quantitative results are now sharpened using a new monotonicity property of ratios ")#mi("{s_{\\lambda}(u)/s_{\\mu}(u)}")#text(" of Schur polynomials, namely that such ratios are monotone non-decreasing in each coordinate of ")#mi("{u}")#text(" if ")#mi("{u}")#text(" is in the positive orthant, and the partition ")#mi("{\\lambda}")#text(" is larger than that of ")#mi("{\\mu}")#text(". (This monotonicity was also independently ")#link("https://terrytao.wordpress.com/2017/08/17/on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-485361")[#text("observed by Rachid Ait-Haddou")]#text(", using the theory of blossoms.) In the revised version of the paper we give two proofs of this monotonicity. The first relies on a deep ")#link("http://www.ams.org/mathscinet-getitem?mr=2369890")[#text("positivity result of Lam, Postnikov, and Pylyavskyy")]#text(", which uses a representation-theoretic ")#link("http://www.ams.org/mathscinet-getitem?mr=1186961")[#text("positivity result of Haiman")]#text(" to show that the polynomial combination ")#metadata(none) <tao-93dbeda203f2a36532ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("s_{(\\lambda \\wedge \\nu) / (\\mu \\wedge \\rho)} s_{(\\lambda \\vee \\nu) / (\\mu \\vee \\rho)} - s_{\\lambda/\\mu} s_{\\nu/\\rho}")]]

#text("of skew-Schur polynomials is Schur-positive for any partitions ")#mi("{\\lambda,\\mu,\\nu,\\rho}")#text(" (using the convention that the skew-Schur polynomial ")#mi("{s_{\\lambda/\\mu}}")#text(" vanishes if ")#mi("{\\mu}")#text(" is not contained in ")#mi("{\\lambda}")#text(", and where ")#mi("{\\lambda \\wedge \\nu}")#text(" and ")#mi("{\\lambda \\vee \\nu}")#text(" denotes the pointwise min and max of ")#mi("{\\lambda}")#text(" and ")#mi("{\\nu}")#text(" respectively). It is fairly easy to derive the monotonicity of ")#mi("{s_\\lambda(u)/s_\\mu(u)}")#text(" from this, by using the expansion")

#align(center)[#tao-fit-display[#mitex("s_\\lambda(u_1,\\dots, u_n) = \\sum_k u_1^k s_{\\lambda/(k)}(u_2,\\dots,u_n)")]]

#text("of Schur polynomials into skew-Schur polynomials (as was done in ")#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")[#text("this previous post")]#text(").")

#text("The second proof of monotonicity avoids representation theory by a more elementary argument establishing the weaker claim that the above expression ")#link(<tao-93dbeda203f2a36532ec>)[#text("(1)")]#text(" is non-negative on the positive orthant. In fact we prove a more general determinantal log-supermodularity claim which may be of independent interest:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{A}")#text(" be any ")#mi("{n \\times n}")#text(" ")#link("https://en.wikipedia.org/wiki/Totally_positive_matrix")[#text("totally positive matrix")]#text(" (thus, every minor has a non-negative determinant). Then for any ")#mi("{k}")#text("-tuples ")#mi("{I_1,I_2,J_1,J_2}")#text(" of increasing elements of ")#mi("{\\{1,\\dots,n\\}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\det( A_{I_1 \\wedge I_2, J_1 \\wedge J_2} ) \\det( A_{I_1 \\vee I_2, J_1 \\vee J_2} ) - \\det(A_{I_1,J_1}) \\det(A_{I_2,J_2}) \\geq 0")]]

#text("where ")#mi("{A_{I,J}}")#text(" denotes the ")#mi("{k \\times k}")#text(" minor formed from the rows in ")#mi("{I}")#text(" and columns in ")#mi("{J}")#text(".")
]

#text("For instance, if ")#mi("{A}")#text(" is the matrix")

#align(center)[#tao-fit-display[#mitex("A = \\begin{pmatrix} a & b & c & d \\\\ e & f & g & h \\\\ i & j & k & l \\\\ m & n & o & p \\end{pmatrix}")]]

#text("for some real numbers ")#mi("{a,\\dots,p}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("a h - de\\geq 0")]]

#text("(corresponding to the case ")#mi("{k=1}")#text(", ")#mi("{I_1 = (1), I_2 = (2), J_1 = (4), J_2 = (1)}")#text("), or")

#align(center)[#tao-fit-display[#mitex("\\det \\begin{pmatrix} a & c \\\\ i & k \\end{pmatrix} \\det \\begin{pmatrix} f & h \\\\ n & p \\end{pmatrix} - \\det \\begin{pmatrix} e & h \\\\ i & l \\end{pmatrix} \\det \\begin{pmatrix} b & c \\\\ n & o \\end{pmatrix} \\geq 0")]]

#text("(corresponding to the case ")#mi("{k=2}")#text(", ")#mi("{I_1 = (2,3)}")#text(", ")#mi("{I_2 = (1,4)}")#text(", ")#mi("{J_1 = (1,4)}")#text(", ")#mi("{J_2 = (2,3)}")#text("). It turns out that this claim can be proven relatively easy by an induction argument, relying on the Dodgson and Karlin identities from ")#link("https://terrytao.wordpress.com/2017/08/28/dodgson-condensation-from-schur-complementation/")[#text("this previous post")]#text("; the difficulties are largely notational in nature. Combining this result with the Jacobi-Trudi identity for skew-Schur polynomials (discussed in ")#link("https://terrytao.wordpress.com/2017/09/05/continuous-analogues-of-the-schur-and-skew-schur-polynomials/")[#text("this previous post")]#text(") gives the non-negativity of ")#link(<tao-93dbeda203f2a36532ec>)[#text("(1)")]#text("; it can also be used to directly establish the monotonicity of ratios ")#mi("{s_\\lambda(u)/s_\\mu(u)}")#text(" by applying the theorem to a generalised Vandermonde matrix.")

#text("(Log-supermodularity also arises as the natural hypothesis for the ")#link("https://en.wikipedia.org/wiki/FKG_inequality")[#text("FKG inequality")]#text(", though I do not know of any interesting application of the FKG inequality in this current setting.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486790")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2017")])]

#text("Formulae preceding “corresponding to the case {k=1}” and")#linebreak()#text(" “corresponding to the case {k=2}” should read ” … >= 0 ” ?")

#text("WFL")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee570862a82600a9ad52ac3969def5f600d50d13370608995d3548e11195405-847281a0a3714b3d3e454718dd57659245720ead6fd26d6d0174b06791d81f8a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Suvrit Sra (@optiML)")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486821")[#strong[#text("Suvrit Sra (@optiML)")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("A minor clarification regarding page 35 of your paper. It says that “the conjecture – as stated in [8] and proved in [34] – has a minor error, namely when ")#mi("\\sum_j m_j > \\sum_j n_j")#text("” — In [34] the conjecture is proved for true majorization, where ")#mi("\\sum_j m_j = \\sum_j n_j")#text(" holds. Or am I missing something? Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486840")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("Thanks for this, it looks like we did not quite quote the CGS conjecture correctly, and will sort this out in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rachid Ait-Haddou")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486824")[#strong[#text("Rachid Ait-Haddou")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("Dear Terence,")#linebreak()#text(" Will it be OK to change my first name to Rachid instead of Rachit :). Many thanks for the mention. Also as Sra just mentioned, what is proved in the paper is slightly different from Cuttler-Greene-Skandera conjecture. The paper proves that if ")#mi("m_{i} \\geq n_{i}")#text(" for all ")#mi("i")#text(" then the inequality between the normalized Schur functions holds. The conjecture states that if ")#mi("\\sum_{k=1}^{j} m_{k} \\geq \\sum_{k=1}^{j} n_{k}, j=1,2,\\ldots,N-2")#text(" and ")#mi("\\sum_{k=1}^{N-1} m_{k} = \\sum_{k=1}^{N-1} n_{k}")#text(" then the inequality between the normalized Schur functions holds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("Sorry for the typo! We’ll correct the attribution to the CGS paper in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rachid Ait-Haddou")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486826")[#strong[#text("Rachid Ait-Haddou")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2017")])]

#text("It is sometimes confusing to go from powers to partitions (when it is done hazily). I would like to correct the statement of the conjecture in terms of the powers. It states that if ")#mi("\\sum_{k=j}^{N-1} m_k \\geq \\sum_{k=j}^{N-1} n_k, j = 1,2,\\ldots,N-1")#text(" and ")#mi("\\sum_{k=0}^{N-1} m_k = \\sum_{k=0}^{N-1} n_k")#text(" then the inequality between the associated normalized Schur functions holds over ")#mi("]0,\\infty[^N")#text(". I hope I got it right this time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-486838")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("How does Theorem 1 say anything about the value of the expression ah-dg? If I understood the definitions correctly, it should probably be ah-de instead.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/058925a63cac4d31aeecbbdb6e8747390288f46da92ab3aaada7fad0cd4c83ca-04a6aa30052526264252128cc43d11f548e69b91a5e82d5bf3096515c6b09bca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A. Barreras")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-487621")[#strong[#text("A. Barreras")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2017")])]

#text("Dear Terence,")#linebreak()#text(" In Linear Algebra literature, there exist two “school of notations”:")#linebreak()#text(" 1: TP: matrices with non-negative minors")#linebreak()#text(" STP: matrices with strictly positive minors")

#text("2: TN: matrices with non-negative minors")#linebreak()#text(" TP: matrices with posive minors")

#text("If I understood correctly, you are using the first one. In this case, in the definition of totally positive (p. 38 of the article, line -3), should be changed formula “det(A_{I,J})>0” by “det(A_{I,J}) \\geq 0”?")

#text("Sorry if this is just my misunderstood.")

#text("1. Allan Pinkus (2009), Totally Positive Matrices, Cambridge University Press, ISBN 9780521194082")#linebreak()#text(" 2. Fallat, S. M., & Johnson, C. R. (2011). Totally nonnegative matrices. Princeton University Press.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/09/30/an-update-to-on-the-sign-patterns-of-entrywise-positivity-preservers-in-fixed-dimension/#comment-487700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("In our paper we’re using total positivity in the strict sense. (A large part of the paper is concerned instead with positive semi-definite matrices, though.)")
]
]
