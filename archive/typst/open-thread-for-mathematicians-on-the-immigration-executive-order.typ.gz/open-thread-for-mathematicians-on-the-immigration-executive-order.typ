// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/
// Converted to Typst by tao2typ: "2026-10-14T16:38:05.899270+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open thread for mathematicians on the immigration executive order", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open thread for mathematicians on the immigration executive order")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 January 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/")[#text("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The self-chosen remit of my blog is “Updates on my research and expository papers, discussion of open problems, and other maths-related topics”. Of the 774 posts on this blog, I estimate that about 99% of the posts indeed relate to mathematics, mathematicians, or the administration of this mathematical blog, and only about 1% are not related to mathematics or the community of mathematicians in any significant fashion.")

#text("This is not one of the 1%.")

#text("Mathematical research is clearly an international activity. But actually a stronger claim is true: mathematical research is a ")#link("https://en.wikipedia.org/wiki/Transnational_organization")[#text("transnational")]#text(" activity, in that the specific nationality of individual members of a research team or research community are (or should be) of no appreciable significance for the purpose of advancing mathematics. For instance, even during the height of the Cold War, there was no movement in (say) the United States to boycott Soviet mathematicians or theorems, or to only use results from Western literature (though the latter did sometimes happen by default, due to the limited avenues of information exchange between East and West, and former did occasionally occur for political reasons, most notably with the Soviet Union preventing Gregory Margulis from traveling to receive his Fields Medal in 1978 EDIT: and also Sergei Novikov in 1970). The national origin of even the most fundamental components of mathematics, whether it be the geometry (γεωμετρία) of the ancient Greeks, the algebra (الجبر) of the Islamic world, or the ")#link("https://en.wikipedia.org/wiki/Arabic_numerals")[#text("Hindu-Arabic numerals")]#text(" ")#mi("0,1,\\dots,9")#text(", are primarily of historical interest, and have only a negligible impact on the worldwide adoption of these mathematical tools. While it is true that individual mathematicians or research teams sometimes compete with each other to be the first to solve some desired problem, and that a citizen could take pride in the mathematical achievements of researchers from their country, one did not see any significant state-sponsored “space races” in which it was deemed in the national interest that a particular result ought to be proven by “our” mathematicians and not “theirs”. Mathematical research ability is highly non-fungible, and the value added by foreign students and faculty to a mathematics department cannot be completely replaced by an equivalent amount of domestic students and faculty, no matter how large and well educated the country (though a state can certainly work at the margins to encourage and support more domestic mathematicians). It is no coincidence that all of the top mathematics department worldwide actively recruit the best mathematicians regardless of national origin, and often retain immigration counsel to assist with situations in which these mathematicians come from a country that is currently politically disfavoured by their own.")

#text("Of course, mathematicians cannot ignore the political realities of the modern international order altogether. Anyone who has organised an international conference or program knows that there will inevitably be visa issues to resolve because the host country makes it particularly difficult for certain nationals to attend the event. I myself, like many other academics working long-term in the United States, have certainly experienced my own share of immigration bureaucracy, starting with various glitches in the renewal or application of my J-1 and O-1 visas, then to the lengthy vetting process for acquiring permanent residency (or “green card”) status, and finally to becoming naturalised as a US citizen (retaining dual citizenship with Australia). Nevertheless, while the process could be slow and frustrating, there was at least an order to it. The rules of the game were complicated, but were known in advance, and did not abruptly change in the middle of playing it (save in truly exceptional situations, such as the days after the September 11 terrorist attacks). One just had to study the relevant visa regulations (or hire an immigration lawyer to do so), fill out the paperwork and submit to the relevant background checks, and remain in good standing until the application was approved in order to study, work, or participate in a mathematical activity held in another country. On rare occasion, some senior university administrator may have had to contact a high-ranking government official to approve some particularly complicated application, but for the most part one could work through normal channels in order to ensure for instance that the majority of participants of a conference could actually be physically present at that conference, or that an excellent mathematician hired by unanimous consent by a mathematics department could in fact legally work in that department.")

#text("With the recent and highly publicised ")#link("https://www.federalregister.gov/documents/2017/02/01/2017-02281/defense-and-national-security-foreign-terrorists-measures-to-prevent-us-entry-eo-13769")[#text("executive order on immigration")]#text(", many of these fundamental assumptions have been seriously damaged, if not destroyed altogether. Even if the order was withdrawn immediately, there is no longer an assurance, even for nationals not initially impacted by that order, that some similar abrupt and major change in the rules for entry to the United States could not occur, for instance for a visitor who has already gone through the lengthy visa application process and background checks, secured the appropriate visa, and is already in flight to the country. This is already affecting upcoming or ongoing mathematical conferences or programs in the US, with many international speakers (including those from countries not directly affected by the order) now cancelling their visit, either in protest or in concern about their ability to freely enter and leave the country. Even some conferences outside the US are affected, as some mathematicians currently in the US with a valid visa or even permanent residency are uncertain if they could ever return back to their place of work if they left the country to attend a meeting. In the slightly longer term, it is likely that the ability of elite US institutions to attract the best students and faculty will be seriously impacted. Again, the losses would be strongest regarding candidates that were nationals of the countries affected by the current executive order, but I fear that many other mathematicians from other countries would now be much more concerned about entering and living in the US than they would have previously.")

#text("It is still possible for this sort of long-term damage to the mathematical community (both within the US and abroad) to be reversed or at least contained, but at present there is a real risk of the damage becoming permanent. To prevent this, it seems insufficient for me for the current order to be rescinded, as desirable as that would be; some further legislative or judicial action would be needed to begin restoring enough trust in the stability of the US immigration and visa system that the international travel that is so necessary to modern mathematical research becomes “just” a bureaucratic headache again.")

#text("Of course, the impact of this executive order is far, far broader than just its effect on mathematicians and mathematical research. But there are countless other venues on the internet and elsewhere to discuss these other aspects (or politics in general). (For instance, discussion of the qualifications, or lack thereof, of the current US president can be carried out at ")#link("https://terrytao.wordpress.com/2016/06/04/it-ought-to-be-common-knowledge-that-donald-trump-is-not-fit-for-the-presidency-of-the-united-states-of-america")[#text("this previous post")]#text(".) I would therefore like to open this post to readers to discuss the effects or potential effects of this order on the mathematical community; I particularly encourage mathematicians who have been personally affected by this order to share their experiences. As per ")#link("https://terrytao.wordpress.com/about/")[#text("the rules of the blog")]#text(", I request that “the discussions are kept constructive, polite, and at least tangentially relevant to the topic at hand”.")

#text("Some relevant links (please feel free to suggest more, either through comments or by email):")

#list(
[#link("http://www.ams.org/news?news_id=3305")[#text("AMS Board of Trustees opposes executive order on immigration")]],
[#link("https://m.box.com/shared_item/https%3A%2F%2Fapp.box.com%2Fv%2Fmaaec-immigration-statement")[#text("MAA Executive Committee Statement on Immigration Ban")]],
[#link("https://sinews.siam.org/Details-Page/siam-responds-to-white-house-executive-order-on-visas-and-immigration-1")[#text("SIAM responds to White House Executive Order on Visas and Immigration")]],
[#link("https://mcmprodaaas.s3.amazonaws.com/s3fs-public/Multisociety%20Letter%20on%20Immigration%201-31-2017.pdf")[#text("Multisociety letter on immigration")]],
[#link("http://www.euro-math-soc.eu/news/17/01/31/ems-president-trumps-executive-order")[#text("EMS President on Trump’s Executive Order")]],
[#link("http://www.icsu.org/news-centre/news/top-news/international-council-for-science-icsu-calls-on-the-government-of-the-united-states-to-rescind-the-executive-order-201cprotecting-the-nation-from-foreign-terrorist-entry-into-the-united-states201d")[#text("International Council for Science (ICSU) calls on the government of the United States to rescind the Executive Order “Protecting the Nation from Foreign Terrorist Entry into the United States”")]],
[#link("http://www.aplu.org/members/councils/strategic-communications/immigration-actions/index.html")[#text("Public Universities Respond to New Immigration Order")]],
[#link("https://www.facebook.com/awmmath/posts/1293562850687366")[#text("Statement from the Association for Women in Mathematics")]],
[#link("https://www.simonsfoundation.org/features/foundation-news/simons-foundation-statement-on-executive-order-on-visas-and-immigration/")[#text("Simons Foundation Statement on Executive Order on Visas and Immigration")]],
[#link("http://blogs.ams.org/mathgradblog/2017/01/31/editorial-statement-executive-order/")[#text("A letter from the editors of the AMS graduate student blog on the Executive Order on Immigration")]],
[#link("http://www.math.toronto.edu/~rafi/statement/index.html")[#text("Statement of inclusiveness")]#text(" (a petition, primarily aimed at mathematicians, created and hosted by Kasra Rafi and Juan Souto)")],
[#link("https://notoimmigrationban.com/")[#text("Academics Against Executive Immigration Order")]#text(" (a petition, aimed at the broader academic community)")],
[#link("http://www.scottaaronson.com/blog/?p=3167")[#text("First they came for the Iranians")]#text(", blog post, Scott Aaronson")],
[#link("https://www.ias.edu/statement-immigration-march2017")[#text("IAS statement on the revised executive order")]],
[#link("https://windowsontheory.org/2017/03/07/the-immigration-ban-is-still-antithetical-to-scientific-progress/")[#text("The immigration ban is still antithetical to scientific progress")]#text(", blog post, Boaz Barak and Omer Reingold")]
)

#heading(level: 1)[#text("Comments (147)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konstantin")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477448")[#strong[#text("Konstantin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("These arguments (as well as your earlier anti-Trump post), although entirely correct, feel remarkably irrelevant. If a person can be convinced by this kind of reasoning, he or she is already very unlikely to support Trump.")

#text("It is a no-win to discuss this topic as if it were a question of policy. The idea that Iranian Ph. D. students, or new mathematical theorems, are more important than “national security” is hard to sell to almost anyone, much less to a Trump supporter who “does feel safer now”.")

#text("Meanwhile, the whole success of Trump shows hinges, in particular, on math-illiteracy of the public. People just cannot perceive the idea that their chances to die in a terror strike are somewhat 100 times lower than to choke on their meal, let alone car accidents and good old firearms violence. Or that Trump’s Carrier deal concerns about 0,5% of the jobs American economy creates and destroys every week.")

#text("Maybe, it is a duty of a mathematician to speak up on these matters? On shows being shows, with largely negligible practical impact on their stated goals (though non-negligible collateral damage)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b44ce8246878d093329b309f43e0a442ca5322be6c84c6b7bf77601890dbf2c-2c3844d1277402ede3abd8a22c2ba4dbb07e39b30d719a9aa2004bb8e00f164b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zar")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477465")[#strong[#text("Zar")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("I think trying to argue the numbers won’t work, since Trump’s appeal is based on emotion. It is true that 50 people die from lightning strikes on a typical year in the US, which since 9/11 is greater than the number from Islamic terrorists on average. Similarly, far more jobs will be lost due to Trump’s federal hiring freeze than the number of new jobs created from Carrier etc. I’ve never heard of anyone being swayed by pointing these things out. I know some Trump supporters and facts are discounted as lies, part of a conspiracy, etc.")

#text("But if you drag out the refugee children from non-Muslim countries and show them on TV living in squalid refugee camps, or point out how many of our ancestors came to the US as refugees from religious persecution, that seems to have more of an impact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477474")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("“I think trying to argue the numbers won’t work, since Trump’s appeal is based on emotion.”")

#text("True, in general: numbers don’t work with the general population. Al Gore is the perfect example, since he had all the correct numbers, but he lost, nevertheless.")

#text("Appropriate framing is the way to go. According Berkeley’s Lakoff, calling Trump the ")#emph[#text("minority president")]#text(" is a good beginning,")

#link("https://georgelakoff.com/2016/11/22/a-minority-president-why-the-polls-failed-and-what-the-majority-can-do/")[#text("https://georgelakoff.com/2016/11/22/a-minority-president-why-the-polls-failed-and-what-the-majority-can-do/")]

#text("There is no reason to underestimate the power of making fun of a politician. For example, many believe, including Ford himself, that Chevy Chase’s portrayal of Ford as a clumsy guy screwed up his reelection.")

#text("So Alec Baldwin’s Trump imitation could do a lot of damage. It does get under his skin,")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a41889b7a0e5ca06b0f62fb9e2c13cca6be766e12b9ed513cf9f03bdba0ade1b-4e9312821d2652d1781d45365cb40335116644f29ee80be47de2cf5b5f8f2ac2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477450")[#strong[#text("Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Interesting sentence in the NYT today:")

#text("“The Australian government has a policy that bars any refugees who attempted to arrive by boat from ever setting foot in the country.”")

#text("Your not commenting on this while criticizing Trump is a bit hypocritical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e822d49659a61efbc514995f9147b7d8d606cb9ad63e838512101ae23dcf07f-6964b7c4f2adaaa4a90c00436abf62076188597c0723c83f9383d8a59fb30b40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lino Vari")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477457")[#strong[#text("Lino Vari")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("How much is a bit? Not too little to notice I guess. In fact Australia’s ban is harsher: the attempt is to deter even those in genuine need from attempting to enter Australia, it’s shameful and embarrassing to all Australians who wish to help those in genuine need.")

#text("Possibly Trump’s xenophobia will eventually lead him that far, maybe further, who knows, but the signs aren’t promising.")

#text("Nevertheless, the topic at hand is Trump’s executive order from the perspective of a current resident of the US and its effect. Australia’s ban is irrelevant to the discussion. I doubt there was any intention to conceal the fact that Australia’s measures are far more draconian as well as cruel, but it’s not relevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f06d4ce994e39906ec9c30fa041e6fb5f6881ddfd9a4bbd4dab90e2abcd24a38-c089f66a53f4b9d81747d6c047ac0349c907c1c769efcd0e8178c9c7d9468c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Caroline")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477619")[#strong[#text("Caroline")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("False equivalence.")

#text("Australia does not stop refugees based on creed or if they have been accepted for resettlement. Thet select them based on need. Most Australian refugees come from Syria, Iraq, Burma, India and Afghanistan. Nor does Australia cancel any permanent residencies, work permit, or valid visas, of students, people who have family overseas, family overseas who have family in Australia, business travellers, flighy crew, international students, or academics going to conferences based on whether a or one of their passports is from a specific country.")

#text("The thing about stopping boats is Australia retains regulated, sustainable, safe, fair intake of refugees that we can take good care of. Beats having them die in the Timor sea and up to a quarter of those arriving not being refugees and sponsoring people traficking.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a41889b7a0e5ca06b0f62fb9e2c13cca6be766e12b9ed513cf9f03bdba0ade1b-4e9312821d2652d1781d45365cb40335116644f29ee80be47de2cf5b5f8f2ac2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477458")[#strong[#text("Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("As long as the salaries in American universities are higher, the best and brightest (including mathematicians) will continue to come to the United States through that beautiful door in the middle of the Trump Wall. Also, do not forget Trump’s promise to simplify and streamline the immigration process for people like Terry Tao. If he keeps that promise, I hope you will not forget to give him credit then.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e40f18514c413565472b6567f526198c910d5abddcd0db9df2208d5cf5eff03-956fda3a505566d47a9e98388f43a3882bc213fd4e96635d2222ba42ba0bd6ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of زهرا خانم")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477463")[#strong[#text("زهرا خانم")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Heartless Bastard criminal top western Masonic mafia governments (USA, UK, France & Germany) and their criminal allies ( zionist israhelli & Wahhabi alle soghoot regimes)")

#text("have always violated the Geneva Convention thousands and thousands of times in every war they have imposed on other nations around the world, and yet they accuse others for the crimes they themselves have committed.")

#text("They have not been prosecuted for their crimes and human right violations (included physical and sexual abuse, torture, rape, sodomy, and murder) all over of the world.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c313f155b91c41583574f2cd666a2a6a594fee645cf243ced3b2e6931dca75-a44ef78698a0649aa7dbf96b54a58a84db6d2967183cdf26d1a694679e8dd844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helge Holden")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477478")[#strong[#text("Helge Holden")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("ICSU – the International Council for Science – has issued a press release regarding the Executive Order, see ")#link("http://www.icsu.org/news-centre/news/top-news/international-council-for-science-icsu-calls-on-the-government-of-the-united-states-to-rescind-the-executive-order-201cprotecting-the-nation-from-foreign-terrorist-entry-into-the-united-states201d")[#text("http://www.icsu.org/news-centre/news/top-news/international-council-for-science-icsu-calls-on-the-government-of-the-united-states-to-rescind-the-executive-order-201cprotecting-the-nation-from-foreign-terrorist-entry-into-the-united-states201d")]

#emph[#text("[Added, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b3741ecf0ec114705b891633eebfb6c7e388c865b4592b487205178701c452e-49bb0d009909652c88b9fc97c1e25794189b1e1efa443b05370ed48a7013f154.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477496")[#strong[#text("Hossein")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("Monte Hancock")

#text("Of course nations have the responsibility to keep their citizens safe. But what if the measures they take are ‘unjust’ and ‘ineffective’ ?")

#text("Here I am not talking about ‘singling out mostly muslim counties’ that people are talking about. After 9/11 attacks the nationals of (as I remember) all muslim countries were supposed to give finger prints and report their whereabouts to immigration officials. As an Iranian, I had no problem with that. Even after I was approached by FBI agents multiple times, I didnt feel particularly threatened.")

#text("I did not feel ‘discriminated’ because those early measures after 9/11 were almost for all muslim countries. But this time the countries that are singled out are those whose citizens pose much less threat to America than the ones that are not in the list: Saudi Arabia, AUE, Kuwait, Egypt, Jordan, Afghanistan, Pakistan, and very interestingly RUSSIA !! Does anybody remember any North Korean terrorist ever? Those poor people cant even get out of their country! How about Sudan? Syria? I havent heard if Sudan or Syria have ever carried out terrorist attacks anywhere (regardless of how bad the regimes are)")

#text("Even if these countries, or Iran have carried out terrorist attacks, those alleged attacks have ALWAYS been done by their proxy, especially if the targets are foreign nationals, and not their own citizens.")

#text("So, what is evident is that the people in this administration, without any experience in security matters, and without consulting the staff who have had the expertise, singled out a few countries as escape goats to implement these policies upon them, only because they are countries that the US has minimum ties with their governments, and therefore the action is safe politically. End of the story !!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f26a2d0289ddde1a4e44394a28e7d9a66f2b65b1eec97dc63a9404b3331dae-e9a8a246cbd2478017fcf1c118a96323fc2115ee572d531e98341d0f700f9eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ndwork")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477525")[#strong[#text("ndwork")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("I am a member of the International Society of Magnetic Resonance in Medicine. Our annual conference this year will be held in Hawaii. I’ve always been struck by how scientists and mathematicians from warring countries come together every year to work together and combat disease. This year, many members will be unable to attend the conference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("We dont speak for other countries")#linebreak()#text(" If people want to cancel it is thie business")#linebreak()#text(" the USA citizens elected him")#linebreak()#text(" His job is to protect them first and foremost")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b422dd7e673a8894fa83423b3a36fc86f8059fcc03e782d4b23ca01f993d4511-da7ae179e8184f16118b1a9028cf14f4c377953be958551cd71c3ce0380b5224.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477561")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("We dont speak for other countries")#linebreak()#text(" If people want to cancel it is thie business")#linebreak()#text(" the USA citizens elected him")#linebreak()#text(" His job is to protect them first and foremost")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477566")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#emph[#text("In one of the strongest blows yet to President Trump’s controversial immigration ban, a federal judge in Seattle on Friday ordered an immediate nationwide halt to enforcement of the order that has caused havoc at airports and sown confusion among thousands of visa holders and refugees.")#linebreak()#text(" ")]#linebreak()#text(" ")#link("http://www.latimes.com/nation/la-na-seattle-immigration-trump-20170203-story.html")[#text("http://www.latimes.com/nation/la-na-seattle-immigration-trump-20170203-story.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec8375733c8e59aebc8b393cfcfcd6ab0a9c22071a03f94bf5401a0b01f8efd1-ba40e9c319ea3e04b92331fe16284269f910042a2bd216b517bceb199939a292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dendisuhubdy")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477587")[#strong[#text("dendisuhubdy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("Reblogged this on ")#link("http://suhubdy.com/blog/?p=1147")[#text("The Secret Guild of Silicon Valley")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b4784691729cd32974b31ce4f497ea6c1a1add6f8621501d34752dc55b1e6572-b075ee006155068c2ff66ed41cd569a8a4ad00455f997881119d743f964f017a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Stacey, Secretary AustMS")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477600")[#strong[#text("Peter Stacey, Secretary AustMS")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("The Council of the Australian Mathematical Society has resolved to post the following statement on this thread.")

#text("Council of the Australian Mathematical Society wishes to express their support for the American Mathematical Society’s recent statement expressing their opposition to the Executive Order signed by President Trump that temporarily suspends immigration benefits to citizens of seven nations (")#link("http://www.ams.org/news?news_id=3305")[#text("http://www.ams.org/news?news_id=3305")]#text(")")

#text("We are concerned in principle about any discrimination that interferes with the free exchange of mathematical ideas across borders. We join the many mathematicians around the world (")#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/#comment-477402")[#text("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/#comment-477402")]#text(") who are expressing their concerns about the restriction on travel that the Executive Order places on academics and students from these seven nations currently based at US universities, and the impact on open exchange of ideas so critical to the international mathematical sciences community. We are also hearing about impacts on academics and students from these nations currently based at Australian universities wishing to travel to the US.")

#text("We stand by our American Mathematical Society colleagues in urging that mathematical exchange across borders be maintained and supported, by all nations. We are keen to hear from any academics and students based at Australian universities who are being adversely affected by travel restrictions to the US, so that we can alert the Australian government to the domestic impact of this foreign policy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54282a8ca4f9ce260d33d96359c217b2eafd72d6100237799db5ffb2f303c02c-44107db411a4c1ef12016605deb5384f273119f20e03477ec225c081cc175b25.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of President VS Mathematician – Math Kitty Blog")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477601")[#strong[#text("President VS Mathematician – Math Kitty Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executiv&#8230")[#text("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executiv&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1af6d5eac91e1ed3b6ea4473eb3b677829dd1d2542a11121737871fbb958c267-e22fb4052e871e9d7487c2d54eb4f0389dc5b9ec0eb4a2bc7e61a7a432235381.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward Ordman")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477603")[#strong[#text("Edward Ordman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("I was drawn to this discussion by the Australian Math Society notice; I’m Prof. Emeritus at the University of Memphis (TN). I’m delighted to see the AMS speaking up for freedom of travel and freedom of communicating ideas. Two recollections from years ago: (1) The debate on moving an annual AMS meeting from Chicago around 1968 – I think what carried the motion was the observation that many mathematicians had beards and would not be safe when near Chicago policemen. (2) Also in the 60’s – I was doing some work for a government agency, which got all worked up when I submitted a very abstract paper on general topology to a math journal edited in Poland, since they felt I was “sending scientific information to a communist country”.")

#text("Governments sometimes don’t get it. I’m glad the AMS does get it this time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477620")[#strong[#text("Import AI: Issue 28: What one quadrillion dollars pays for, research paper archaeology, and AI modules for drones | Mapping Babel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")]

#text("[…] predominantly muslim countries from coming to the US will have significant effects on academia, according to mathematician Terry Tao. “This is already affecting upcoming or ongoing mathematical conferences or programs in the US, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba215f4be98e2a1597efed8b347cc69f7bc3209b675bd8a1036637e9fd555181-ba564fcf7733381eeaf7d10b1dd2a63bfed94389bffea5dd2781adecb13d3c7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karabas")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477636")[#strong[#text("Karabas")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2017")])]

#text("Obviously, 90 day ban would not affect the recruitment of new students (who will come in September) or postdocs and faculty (who will come in July). The real question is: how the system will be revamped after it?")

#text("And there is a hope for the positive development, but for this the scientific community should work with administration, not against it. As I see, the most of complains are due to a single entry visas given to students and impossibility to convert it into multiple entry without leaving USA. The remedy could be simple: after 1––2 years of successful studies (more for undergrads, less for grads, even less for postdocs) there should be a procedure to ask DHS to convert the single entry visa to multiple entry. Indeed, DHS rather than State Department is responsible for security, and DHS would have all the necessary information. In France (at least 25 years ago) police, it was a police responsibility to deliver a Carte de Sejour which allowed to go abroad and return.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477646")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2017")])]

#text("“And there is a hope for the positive development, but for this the scientific community should work with administration, not against it.”")

#text("Which part of the administration’s Muslim made enough sense to consider a compromise?")

#text("Is the judge who ordered the stay of the ban “worked with the administration”?")

#text("Working with the administration means accepting more and more of their program.")

#text("This acceptance is exactly what got us where we are; just consider whom we got as education secretary today.")

#text("University admins are always ready to compromise, and now the majority of profs are nontenured and class sizes doubled in many places . They tell us all the time “We need to play nice, or we won’t get funds.” Typical victim mentality.")

#text("Since we are not politicians, we shouldn’t play their games.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba215f4be98e2a1597efed8b347cc69f7bc3209b675bd8a1036637e9fd555181-ba564fcf7733381eeaf7d10b1dd2a63bfed94389bffea5dd2781adecb13d3c7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Karabas")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477682")[#strong[#text("Karabas")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("Have I suggested to “compromise” or to “play political games”? I proposed to concentrate on what is important: fixing the system broken during many years while you want to oppose the last 90-days ban which has a very little impact on academia")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2017")])]

#text("You suggested working with an administration that tried to implement a religious test for entry into the USA.")

#text("That’s exactly compromise, if not worse.")

#text("Sorry, the rest of us will not play sycophant to a racist coward like Trump.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477765")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Well haven’t we taught him now how to play the system?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-477815")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("I received my first letter from a current US student today (from one of the 7 countries), asking if she could move to work with me in Canada.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-478274")[#strong[#text("Why I will no longer do research sponsored by the Department of Homeland Security | An Ergodic Walk")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")]

#text("[…] Aaronson wrote very eloquently about this issue after the initial ban was announced (see also Terry Tao). My department has seen a dramatic decrease in the number of applicants in general and not just […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-478276")[#strong[#text("Why I will no longer do research sponsored by the Department of Homeland Security | A bunch of data")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")]

#text("[…] Aaronson wrote very eloquently about this issue after the initial ban was announced (see also Terry Tao). My department has seen a dramatic decrease in the number of applicants in general and not just […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gee wiz")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480214")[#strong[#text("Gee wiz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2017")])]

#text("Stop making a fool out of yourself Terry")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2017")])]

#text("Now that was a substantive comment, just filled with thoughtful and well-reasoned content.")

#text("Go somewhere else.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480658")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2017")])]

#text("so sad even some of our so-called brilliant minds fall victim to this msm propaganda.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("Go tell your mommy she wants you, snowflake.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480711")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2017")])]

#text("sure thing, Trigglypuff :D")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Triggered_Mathematicianess")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-480659")[#strong[#text("Triggered_Mathematicianess")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2017")])]

#text("Thank you, Terry Tao for being a powerful ally in the fight against racism, homophobia, misogyny, xenophobia, islamophobia, and sexism. The corrupt fascist orange pig destroying our country must be impeached and we, The Resistance, will NOT back down until he utterly FAILS and is OUT OF OFFICE!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b85f8290a37442b8b8b154c6df07254fe4b6578024078a73eadf513fb75ebf4d-8a648afc8669d777041b13bee29ecfaae908946ae0429e3c9e7c96aef17ed2d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of clarificationneeded")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-484932")[#strong[#text("clarificationneeded")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2017")])]

#text("I think you are hiding a lot in ‘I myself, like many other academics working long-term in the United States, have certainly experienced my own share of immigration bureaucracy, starting with various glitches in the renewal or application of my J-1 and O-1 visas, then to the lengthy vetting process for acquiring permanent residency (or “green card”) status, and finally to becoming naturalised as a US citizen (retaining dual citizenship with Australia)’ either voluntarily or involuntarily.")

#text("If you are a professor at UCLA then I believe UCLA should sponsor you, period. If you are born in Australia the immigration process (even if you are applied at a mediocre category of EB2) after UCLA applies for you will not take more than 6 months and may be a year, period. You never had to apply for O visa since you were over 18 and at 21 you were already a professor at UCLA, period. H1B to greencard seems direct for you.")

#text("See the waitlist for legals from all regions of the world at ")#link("https://travel.state.gov/content/visas/en/law-and-policy/bulletin/2017/visa-bulletin-for-september-2017.html")[#text("https://travel.state.gov/content/visas/en/law-and-policy/bulletin/2017/visa-bulletin-for-september-2017.html")]#text(" and please go to EB category.")

#text("Either UCLA misguided you or you were overpaying a mediocre lawyer or you are providing information in a pretty controlled way that supports your opinion.")

#text("Do you even know the struggle of regular legal immigrants who really are held hostage by illegals?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebff16769fc503951fac1bb8b0422de0ab4cdcce8b3912e1681af8d41a939aff-59a76269e2675cdb805ce6d643db2050cbb8402c48c25f97ce5c124e3a447c0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of daca")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-485969")[#strong[#text("daca")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2017")])]

#text("Any comments on DACA and coming immigration chop?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2586a73e53a6019060df047fa5633ab44d77edcd452098140bbe4f1aca9f8e2a-1b89ea28ce46d083694fb7e7695cc8310fde82c133e1558b1d2c2a0d644e1fa0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Don'tknow")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-501711")[#strong[#text("Don'tknow")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2018")])]

#text("This is the time to fight and not sit back thinking probably no child in border ever will become a mathematician ")#link("https://www.scottaaronson.com/blog/?p=3866")[#text("https://www.scottaaronson.com/blog/?p=3866")]#text(". Might be we see something on this in your blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2586a73e53a6019060df047fa5633ab44d77edcd452098140bbe4f1aca9f8e2a-1b89ea28ce46d083694fb7e7695cc8310fde82c133e1558b1d2c2a0d644e1fa0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Don'tknow")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-501712")[#strong[#text("Don'tknow")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2018")])]

#text("I actually do not believe anything more than 10% of information on this particular page (only this) and I hope you take a position that is broader in scope.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-528338")[#strong[#text("Le notizie di scienza della settimana #5 – Chiara Sabelli")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2019")]

#text("[…] Continuano le iniziative, di società scientifiche o di singoli scienziati, contro il MuslimBan di Trump (ora sospeso). Tra queste spicca quella del matematico Terence Tao, vincitore della Medaglia Fields nel 2006, ha aperto un dialogo sul suo blog riguardo all’impatto che il MuslimBan avrà sulla matematica, un’attività che definisce transnazionale. Già molto numerosi le testimonianze di studenti e post-doc: sarà difficile ricostruire la fiducia [terrytao.wordpress; Terence Tao] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/709238202dd3923a4b53aba632e161a876e6f8d1d13e5284c0be7bbc49044c7e-3d333ff1ebd0b1d046ac091af1a349e8519ee8b237cfb3c68250d159997f571d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael - Habeas Corpus Lawyer in New York")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-2/#comment-687721")[#strong[#text("Michael - Habeas Corpus Lawyer in New York")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2025")])]

#text("Thank you for this insightful post, which sheds light on the impact of immigration policies on the mathematics community. Your emphasis on the contributions of international mathematicians to both research and education is particularly salient and resonates deeply within the global collaborative nature of the field. Building on your observations, it’s important to acknowledge that the effects of strict immigration policies extend beyond just individual mathematicians. They can also alter the landscape of collaboration in research projects, as teams often rely on diverse perspectives and expertise from across the globe. For example, initiatives such as the International Mathematical Olympiad not only showcase young talent globally but also foster cross-cultural partnerships that can lead to significant innovations in mathematical research. Additionally, historical instances, like the migration of scientists during World War II, illustrate how restrictive policies can stifle scientific progress by losing valuable contributions. The influx of refugees, many of whom were key figures in their fields, demonstrates the potential for revitalization that diverse perspectives can bring to mathematics and science. Given these considerations, how do you think the mathematics community can foster stronger ties and advocate for inclusivity, particularly during times of restrictive policies?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477327")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Analysis of the USA 216 presidential election vis-a-vis alternative voting systems:")#linebreak()#text(" ")#link("http://rangevoting.org/USA2016retro.html")[#text("http://rangevoting.org/USA2016retro.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64b6ef98912a0f77417afe0bf810ef0dc3e8dfab695a938e7d7934c7abeb29b2-de08990b7648c0a255b9d4db1d178ac3302400b1489ef75904b5d72513f82c55.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffery Breeding-Allison")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477328")[#strong[#text("Jeffery Breeding-Allison")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("On a somewhat related note, Tufts is running a short summer school for mathematicians who are interested in training to be expert witnesses for gerrymandering/redistricting court cases:")

#link("https://sites.tufts.edu/gerrymandr/")[#text("https://sites.tufts.edu/gerrymandr/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fd94939fb4ac9401e3da6f92fdbd0fabea012a89753caf3b5dcc54d6105e739-d419ee917d7544582d6d6d92f74fdeccc89d8bfd4352e1f17402b4c6847f3df2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of djbruce")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477329")[#strong[#text("djbruce")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("The editors of the AMS Grad Blog, including myself, posted a statement expressing our concerns and condemnation of the recent executive order.")

#link("http://blogs.ams.org/mathgradblog/2017/01/31/editorial-statement-executive-order/")[#text("http://blogs.ams.org/mathgradblog/2017/01/31/editorial-statement-executive-order/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/383cd5b9e8532b548891b393add9262d6cdd17e55f84a6ea8e2ba5b9b7480579-c9033f3449858433288f122094de4ac2455823a919196a6e81b1b0e95685e00e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nobody in particular")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-479451")[#strong[#text("Nobody in particular")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2017")])]

#text("It is unfortunate that the election of Donald Trump may work against the personal interests of some international scholars. However, the American people and their government have no obligations to the interests of non citizens, especially concerning matters of national security. It may be worth considering immigration and nationalization arrangements in your own home countries in order to be able to put this matter into the proper perspective.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-479493")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("We are not talking about the interest of “international scholars” but about US citizens who work and study at US universities. It’s an American reality that in many areas (especially in math), the vast majority of profs are not from the US. In my department, only 10% of the profs are US born.")

#text("Hitler was a good example for a leader who thought, he could afford to drive away scientists from his country. You know well, which country received those who were driven away from Germany.")

#text("No, the Ivory tower is not as isolated as our fearless leader and his followers would like to believe.")

#text("Figuring out economic impact of a particular executive order to a country, it’s outright dangerous to think about only those who seem to be directly involved in money making. Just think about the fate of the North Carolina bathroom bill. Just couple of days ago, it got reversed since NC lawmakers didn’t consider its possible economic impact to their state. They just thought “how can our bill have any consequences? We are talking about a minuscule portion of the population, namely the transgenders, who’ll be impacted.”")

#text("The same can be said about the national security impact of various Trump proposals. Instead of increasing national security, they very much could increase national insecurity.")

#text("We can safely say, Trump and his followers are short sided, and price will paid.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13d30fdc7457d10189a182cc0e42afb70d24df1daae62b499a262a156a291569-052ec41376c7bf69b9f19ffa5a02b6ed3a978510c6ea244af0ff00ae0d2944cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of H.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477330")[#strong[#text("H.")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I’d like to thank you for your precise comments on this issue. I am an Iranian student pursuing PhD in U.S.")

#text("Even before this discriminatory measure, I could not return to see my father with metastasic cancer back home, since most probably I couldn’t receive a new visa to come back here. I took me a while to handle my feelings and to become able to cope with the everyday pain for that. Now, this has made it intolerable for me, and many other researchers who came here to pursue their education and career. Feeling insecure everywhere every place every moment, searching for a way to escape this man-made hell!")

#text("And I should add to your thoughts: I believe those who are affected by this measure in long term are not us, we will eventually get settled somewhere else, and this is the U.S. that already has lost thousands of us. Maybe our bodies are now here, but most of us think of leaving this insultive atmosphere as soon as possible.")

#text("As you said, the walls of trust between the Iranian scientific society and the U.S. has got destroyed overnight, and I doubt that any measure can remedy the pain now we suffer, at least in my life span!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13d30fdc7457d10189a182cc0e42afb70d24df1daae62b499a262a156a291569-052ec41376c7bf69b9f19ffa5a02b6ed3a978510c6ea244af0ff00ae0d2944cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sayyed2007")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477468")[#strong[#text("sayyed2007")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("I found that my father had passed away on Saturday two days before I wrote this comment and I wasn’t told… Yes, this is the ugly face of politics!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477331")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Thanks for posting this. Typo: “…there is no longer an assurance, even *for* nationals…could *not* occur…”")#linebreak()#text(" PS. I like the banner photo. Someone should annotate a copy of that plaque consistent with the Executive Order and ship it to the WH.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477332")[#strong[#text("Fascism and the Current National Emergency | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")]

#text("[…] Terry Tao has a blog entry about this, emphasizing the damage to the math […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5566b2a28bef5ecc9d977349f4c9392ba5b95bf973c9b8031e7cbb8b2ab19bab-6d3dbbef448bffefd4a559bc96f88c9107e858118c0dac4fbae18076db94262e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nestor")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477333")[#strong[#text("Nestor")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Thank you for this thread Terry. I hope it leads to some constructive discussion.")

#text("I know personally at least a dozen colleagues who have been affected by the executive order. Be it by them having their travel severely restrained, or their relatives. Many of them are US citizens with family in the affected countries, or permanent residents. At least two UMass students were detained at Logan airport and I do not know if they have been allowed in.")

#text("I have also known of several cases of postdocs in the United States with double nationality who were in the market for tenure track positions and have become defacto unhirable because they cannot get a work visa anymore. As someone who knows the stresses of the job market, those people have my strongest sympathy right now.")

#text("Last but not least, I know of permanent residents in the US who are not affected by the current EO, who are nervous of going to conferences abroad out of fear of being caught outside if a similar EO is enacted that affects them due to their origin. I was originally dubious that these fears were too justified, by after various conversations it no longer seems to me beyond the realm of possibility that such a ban could happen, say, in the not too distant future, that affects people like myself with a Venezuelan passport.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6a2478aee4b113c4e989c844e288251c9067fba50383513b0885042ca2ae8d4-d27bcc1bfc6505edd81daf80f48b8bd01a3be45ae36ea8bd7d0ebeaf0e68b4df.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marie Lau")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477334")[#strong[#text("Marie Lau")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Dear Prof Tao,")

#text("Thank you for speaking up for international scholars. May I also point out sth you might have overlooked.")

#text("Many people have assumed that the immigration system before Trump was merely tedious but still do-able. That is not true. First, the queue for a faculty position has become longer, and hence visa term limits affect the chance of an international scholars to stay in academia. Not staying in academia also means not staying in US, because going to the industry requires getting a visa thru lottery. Second, while mathematics is not a sensitive discipline, many academic STEM positions place restrictions on foreign nationals of different origins.")

#text("These things rarely get addressed, because our visa comes with the condition of not showing immigration intent, and confronting authorities would mar our record in this country. So we rely on citizens to speak up for us. Not only reverting to how things used to be before Trump, but also streamlining the visa and immigration system.")

#text("Respectfully,")#linebreak()#text(" Marie")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-479500")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2017")])]

#text("Become illegal and work in the farms that is what dems like about their only class of favorite immigrants. Trump is making it explicit what has always been a scam. You come here pay 10’s of 1000s of dollars to study work your butt off all in servitude for a right to live freely (isn’t that ironic? but still better than where I came from I guess).")

#text("I don’t even see why this article is taken seriously. He is talking of ‘Nevertheless, while the process could be slow and frustrating, there was at least an order to it’ and connects to the larger framework of immigration ban. A logically coherent article whose big picture is at best mute, He is talking of his own experiences which I bet does not apply to 99.99999% human beings ever born. And even the experiences of people of his caliber has been tough. If asked he is showing a joke statement that the math community or ams has posted as legitimate stand of advocacy in their open letter about immigrant students (")#link("http://www.ams.org/about-us/governance/policy-statements/sec-immigration")[#text("http://www.ams.org/about-us/governance/policy-statements/sec-immigration")]#text(").")

#text("You are talking of a lottery for H1B (in fact in all practicality if the system is run properly you do not need it unless you are from China and India or just a person with BS). You know all these tech companies have these publicity stunt about hiring minorities and girls and which faculty and the broad community highlight as a good way. Why cant they do the same thing about applying for Green cards instead of H1Bs? It is a simple truth that people from anywhere outside India and China do not need a H1B if they have a MS degree since the time for these people to a get a green card is about 9 months which they can get while waiting on their OPT or even right from the offer of employment. Why don’t faculty like Tao take concrete steps in advertising these things which can be legitimately done within the current system rather than try to get a magical icecream milked from a mystical cow in the sky? I am sure things like these will get noticed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2138a9ca6e9a0b5eeced601879ad7bc507b2b5c7962d4454e4a86cebf1f99cd2-2c530ebede40877849e41961f9c29a42f3fd7455c5cf58292146f90533a68482.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477336")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I am a Canadian-Iranian mathematician currently doing a postdoc in Canada. My research is on combinatorial algebraic geometry and its applications in physics. I might be affected by the ban, since I applied for jobs in US but I have not heard back from any of those universities and I suspect that it won’t happen (considering the current situation).")

#text("I still cannot believe it! As you mentioned, an individual (regardless of their social status and political power) should not be able to influence others’ lives and their families overnight (and the worse part is for a reason that is beyond our control, namely the place of birth).")

#text("Anyways, thank you Professor Tao for providing this opportunity for us to share our problems within our scientific community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Perhaps some telepresence technologies (e.g. telerobotics, teleconferencing) may help somewhat.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ecb79b7aa837433526668fd379e483d22663d2e7a8e093c3d1f96477d891ba5-58ef039206bf515937bd49c2772c6e9acd1766f2f3b5f62af3da79465679fb4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pipilu")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477340")[#strong[#text("pipilu")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("“please feel free to suggest more, either through comments or by email”, well, how about the direct link to the executive order? It’s like writing “Perelman’s proof of the Poincaré conjecture: a nonlinear PDE perspective” without citing “The entropy formula for the Ricci flow and its geometric applications”.")

#emph[#text("[Link added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b4fc4c16b46e3ee1f249cbfd95c074aaf7330e521d4084ec3ebf4b6209032eb-4d299a6ee0d8f46fef2870f6ff3044a941365e60e551f97cbd72ceec85fc8394.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Māris Ozols")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477341")[#strong[#text("Māris Ozols")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Scott Aaronson has spoken out about how this has affected his students: ")#link("http://www.scottaaronson.com/blog/?p=3167")[#text("http://www.scottaaronson.com/blog/?p=3167")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ff664971b25540626e27f9c139a43285ea6c932c2bd8d8e2e9f37a04d99f057-0e54dc275b89ae0df1fd60cd2aa63ccbdad0731e2bfd4c50e9026a17a4556951.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477342")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I agree with everything that is said so far. I think there are several other negative impacts. Visibility is an important factor in the life of a junior mathematician. This new ban will certainly affect the invitation to conferences. Some of affected people are going to cancel their upcoming trips, which will create a negative image, and will make some conference organizers more hesitant to invite these people in the future. People who are affected by this ban will suffer, most importantly because they can’t continue their research programs and need to look for new connections and collaborators, but also the sparse list of conference presentations in their cv could affect their tenure files and their grant applications negatively.")

#text("I should add that some us have been already experiencing these sort of exclusions, just because of lack of long connection in american academic system. But unfortunately, the new ban will worsen the situation by limiting our international travels.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ff664971b25540626e27f9c139a43285ea6c932c2bd8d8e2e9f37a04d99f057-0e54dc275b89ae0df1fd60cd2aa63ccbdad0731e2bfd4c50e9026a17a4556951.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of S")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477344")[#strong[#text("S")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I am mostly talking about faculty members who have a job in the US, and will not travel to protect their career, which will be damaged.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477346")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I was looking for your post regarding the Obama 2011 order that suspended immigration from Iraq for six months. I am sure that you felt equally appalled that innocent Iraqi *children / mathematicians* were unable to access the fast food drive-through lanes that are the hallmark of our advanced civilization. I feel your pain at the idea mathematicians may have to facetime their dissertations or, heaven forbid, use a service such as lanl.gov to present preprints to fellow academicians. The delay (in nanoseconds) resulting from sending an email might lead to the “collaborative community” equivalent of gimbal lock as pertains to advancing yet another theory of prime distributions.")

#text("I await a link to that article with *bated* breath.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477350")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I am sure you already know the differences between the current executive order and the one from 2011, but just in case:")

#list(
[#text("The 2011 order did not affect permanent residents, holders of a valid visa, or refugees who had already been vetted.")],
[#text("It was in response to a specific failure of the refugee vetting system, in which two Iraqi terrorists managed to gain admission to the US as refugees despite their fingerprints being in a known database. The ban was lifted once this failure was addressed.")],
[#text("At no point in this process was there any suggestion that this type of order could be broadened beyond its initial scope.")]
)

#text("See for instance ")#link("http://heavy.com/news/2017/01/barack-obama-ban-refugees-did-iraq-iraqi-muslim-trump-jimmy-carter-iran-iranian-immigration/")[#text("this article")]#text(" for a good summary of the differences. In short, the 2011 order sought to solve a very specific problem while causing the minimal disruption possible. Some disruption still inevitably occurred, of course, but nowhere near the scale of what the current order has had, which by all appearances seems to have been drafted with almost no thought as to potential unintended consequences. The difference is analogous to the difference between a firefighter kicking down a door in order to put out a fire, versus a “firefighter” who is kicking down all the doors in a building that is not actually on fire.")

#text("I am not sure how familiar you are with the actual working of mathematical research, but at present there are several key activities which simply cannot be replicated by current telepresence technology. For instance, right now I am at ")#link("http://www.msri.org/")[#text("MSRI")]#text(", together with about a hundred other mathematicians, for semester-long programs ")#link("http://www.msri.org/programs/297")[#text("in Analytic Number Theory")]#text(" and ")#link("http://www.msri.org/programs/300")[#text("in Harmonic Analysis")]#text(". In addition to formally scheduled events such as workshops and seminars, there has been a vast amount of valuable informal and spontaneous interaction in the common areas or in the various offices; particularly precious has been the interaction with mathematicians from overseas that one would rarely have chance to interact with in persion. I myself have only been here two weeks and managed to solve one problem with a pair of existing collaborators, another one with colleagues that I had not previously been thinking of working with, and provided guidance to a half-dozen other mathematicians; I doubt I could sustain even one tenth of this level of activity purely through remote interactions over the internet. I am in email contact with mathematicians whom for various reasons (such as medical reasons) were not able to attend the program, and they were quite envious of not being able to participate directly in all of the activities; they could view some of the seminars and talks by video over the internet, of course, but this is only a small fraction of what these sorts of programs offer. It was already a painful decision for us as organisers to turn away many qualified applicants due to lack of space; in the future the problem will be exacerbated by applicants being unable or unwilling to attend due to travel uncertainties that did not previously exist. I myself started my career by participating in a ")#link("http://www.msri.org/programs/300")[#text("similar MSRI program in 1997 in harmonic analysis")]#text(" in which I met many of my future long-time collaborators and learned of many problems and techniques which I would otherwise would have been unable to easily obtain, or even hear about. Such opportunities may now be denied to many promising young mathematicians, simply by accident of their country of origin.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477351")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("We tolerate (dare I say celebrate?) that Obama suspended immigration from Iraq due to the fact terrorists successfully entered our country with the intent of causing harm. Obviously there was a desire to review the process and ensure that essential requirements were not going to be overlooked in the future.")

#text("Your post assumes that President Trump does not have any information that would allow him to reach similar conclusions regarding our immigration policies and practices. Despite the fact Congress passed (and Obama signed) the “Visa Waiver Program Improvement and Terrorist Travel Prevention Act of 2011” that Trump is using as justification for the scope of his Executive Order, your post states “many of these fundamental assumptions (regarding American values and mathematical collaboration across borders) have been seriously damaged, if not destroyed altogether.” How was creating and signing the bill less harmful to those values than implementing it? Where is the post highlighting the dangers of the 2011 bill? I guess you were not paying attention back then.")

#text("No one wants to see scientific thought be stifled (haha, tip of the hat to Elsevier and the Copyright Clearance Center). Academic thought has been stifled by a lack of (inexpensive) access to research materials for decades. Of course those with large research budgets and political connections would find such roadblocks little more than pebbles on the path to success. As we all know *real* science is paywalled.")

#text("The Trump wall is very similar to the wall academicians and researchers have grown to tolerate (and perhaps even love in a Stockholm-syndrome sort of way). Peer review is the ultimate vanity; why not apply it to immigration? Note: We do and that is why coming to America feels like winning the lottery.")

#text("Anyway, my larger point is that you are being hyperbolic in your assertion that “at present there is a real risk of the damage becoming permanent.” Knowledge is organic; one can delay, but never stop, the march toward truer truths. And as we established in your last post on Trump, the voters are incapable of understanding the job of the President, hence Trump is the President. Right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477354")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("“How was creating and signing the bill less harmful to those values than implementing it? ”")

#text("Huh. What is the difference between theory and practice, between understanding nuclear fusion/fission and dropping the bomb?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477356")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("That is why I paraphrased Oppenheimer and the idea of “organic necessity.”")

#text("“But when you come right down to it, the reason that we did this job is because it was an organic necessity. If you are a scientist you cannot stop such a thing. If you are a scientist you believe that it is good to find out how the world works; that it is good to find out what the realities are; that it is good to turn over to mankind at large the greatest possible power to control the world and to deal with it according to its lights and values.”")

#text("Science gets a free pass to build the bomb, the politicians get a free pass to write the bill, the soldier gets spit on for following orders, the academicians cry crocodile tears into their Starbucks coffee. Again, how was giving the bomb to a political body less suspect than the political body using it?")

#text("America dropped 26,171 bombs in 2016 (for you stats lovers, that is three bombs every hour, 24 hours a day, 7 days a week, no break for Christmas). Where was the post decrying that? Oh, it didn’t hurt mathematicians access to collaboration so, well, obviously why would anyone care? That isn’t *embarrassing* enough to warrant a post.")

#text("“Sad.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477392")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("“the academicians cry crocodile tears into their Starbucks coffee.”")

#text("Is this supposed to be a convincing argument for the Muslim travel ban?")

#text("While trying to bring in what they call ")#emph[#text("false equivalences")]#text(" between the Muslim travel ban and other mostly irrelevant events, you claim that the disruption of scientists’s work and lives is a small price to pay for the greater good the executive order accomplishes.")

#text("In contrast, the vast majority here and elsewhere claim, there is no greater good in the executive order (in fact, there is a greater bad in it), hence there is no reason to disrupt scientific research and people’s lives.")

#text("So I do not see what can be accomplished with a lonely voice here. Why does one repeat a toothless insult on academic work and people in writing over and over, when it can be simply reread to friends in the club as many times as the audience requires?")

#text("But even if you can’t resist endlessly echoing your tired observations on Academia, please keep in mind that yours is just a small, minority voice from the camp of a minority president.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477357")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("1. The Visa Waiver Program Improvement and Terrorist Travel Prevention Act ")#link("https://www.congress.gov/bill/114th-congress/house-bill/158/text")[#text("is from 2015")]#text(", not from 2011.")

#text("2. As the name suggests, what it does is restrict access to the visa waiver program to residents of certain countries – that is to say, such residents now need to apply for a visa in order to enter the United States.")

#text("3. The current executive order is not “implementing” this restriction of the visa waiver program, which had already been implemented in 2015; the only connection is that it uses the same list of countries as the previous bill, in order to impose a far stricter, and more draconian set of restrictions.")

#text("4. I think it is indeed reasonable to infer that the current President did not have access to the best information available in crafting this order, as there was essentially no consultation with Congress, DHS, DOJ, etc. before this order was issued. This, by the way, is highly unprecedented. Another indication of this is in the administration’s subsequent admission that it was an error to extend this order to cover permanent residents.")

#text("5. I also have ")#link("https://terrytao.wordpress.com/2012/02/08/a-statement-on-the-cost-of-knowledge-declaration/")[#text("voiced objections")]#text(" to the journal pricing policies of Elsevier and other publishers in the past, but I fail to see how this is relevant to the current discussion.")

#text("6. Delay ")#strong[#text("is")]#text(" damage. If someone burns down a rainforest, can one plausibly argue that no real damage was done because the rainforest was “organic” and one can “delay, but never stop” its regrowth? At any rate, even if the mathematics itself eventually is discovered (albeit at a slower rate), the damage to mathematic")#strong[#text("ians")]#text(" is quite real.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477358")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("1) True, the scope of time is such that travel going back to 2011 could trigger the provisions of the bill.")

#text("2) Delay is damage, just not in this instance.")

#text("3) Draconian is perhaps not the best word to use here. Dropping atomic bombs to advertise a threat to the Russians is draconian. Stopping immigration for up to 180 days is not that bad. Refer to the Russian commentary below.")

#text("4) Reasonable to infer, but unreasonable to assert as a fact.")

#text("5) Relevant because “delay is damage.”")

#text("6) Actually, delay is not damage. Damage to what? Some of teh people killed by the 26,000+ bombs America dropped on people last year?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477362")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Most of Jeffrey Helkenberg’s comments are mostly not logically related to the discussion here. (The only related one is the 2011 order he mentioned above.) He keeps making unsound statements without understanding what Terry is really saying.")

#text("“Actually, delay is not damage.” Actually what? Would you just honestly say “Actually, delay is not damage to me.”?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b15b5ecf029b48dfc61b9093caaa05e2d7c16800f55419122d6b255ef98e9c6-3760df237cff43b64cbcc8d5447ad14fff2307fa1360873c9942036186e387a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of smrnda")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477363")[#strong[#text("smrnda")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("You seem to be expressing generic hostility towards the scientific establishment as a means of trivializing the issue. That seems a bit like the fallacy of relative privation. As long as mathematicians are not dying in the streets, how can they complain? It also seems a bit out of place with regard to mathematics. Unlike the physical sciences or engineering, the actual materials needed to do mathematics are quite modest. The best way for people to contribute and cultivate their talents are through collaboration. It’s the more open system which has allowed mathematicians from all over the globe to collaborate, enrich their own skills, and often bring them back to their nations of origin or new nations. A number of departments find ways to bring together people from all over the world, often offering financing, so that talent can be cultivated.")

#text("Also, peer review is not vanity. I know that many people outside of the sciences believe we all just pat ourselves on the back for reaching the ‘right’ conclusions but it is a very rigorous process. Paywalls exist because it costs money to run academic journals. If you want free access, support government money being spent towards that purpose.")

#text("Perhaps in the long view, setbacks are only temporary, but as someone once said, in the long run we’ll all be dead.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477369")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I am not being hostile toward science or mathematicians as members of a subculture of science. However, it is intellectually dishonest to argue that what Trump has done in any way jeopardizes our relationship with the world when dropping 26,000+ bombs on foreign soil has not been corrosive.")

#text("“In President Obama’s last year in office, the United States dropped 26,172 bombs in seven countries. This estimate is undoubtedly low, considering reliable data is only available for airstrikes in Pakistan, Yemen, Somalia, and Libya, and a single “strike,” according to the Pentagon’s definition, can involve multiple bombs or munitions. In 2016, the United States dropped 3,028 more bombs—and in one more country, Libya—than in 2015.”")

#text("A scientist (or a layperson for that matter) might conclude that countries we have been bombing relentlessly for a decade *might* harbor some resentment toward the US. Trump did not order munitions dropped on Libya, Syria, Iraq, Yemen, Somalia, etc. Trump did not work to create the hostilities that are simmering in places where people don’t go outside when it is sunny (for fear of being blown up by killer robots). Get a grip on reality, see that there are *far, far, far worse* atrocities involving human life than restricting travel. Let’s start with addressing the fact the previous administration had a penchant for death by drones. This is not like throwing dice where each roll is disconnected form the previous throw(s). The reason we are concerned about travel from certain countries is that we have spent a lot of time (under liberal government) bombing them and killing a lot of people in the process. The probability of rolling snake eyes (wrt terrorists targeting our country) is in this instance tied to the fact we have been throwing bombs at these nations for a long time.")

#text("It is a sad state of affairs when the most brilliant minds remain silent in the face of real atrocity and then all join as a chorus when some of their ilk are denied entry into the USA. “Boo hoo,” Where is the investigation into what led us into our current predicament on the part of the poster? The last administration did everything one could possibly do to anger and alienate the citizens of the “Bad 7”. Own some of that for a *change*.")

#text("Also, since when do peer reviewers get paid? Do you even know what you are talking about?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I guess he is only trying to remind people that the american recent nobel peace prize has been doing for years something quite more atrocious than preventing people from moving to and from the US… unless we consider a plus the freedom of dead people’s souls to move around the globe")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477410")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("“I know that many people outside of the sciences believe we all just pat ourselves on the back for reaching the ‘right’ conclusions but it is a very rigorous process”")

#text("(slightly off-topic) I am not convinced by this; my experience with the reviewing process is that common reviewers spend 90% of their time into ‘correcting’ language, notation, relative frequency of certain letters used, page numbers in the bibliography and so on, indeed I have the impression that no theorem of me was ever seriously checked by any reviewer (indeed I made partly substantial errors that I DID correct during the process without that the reviewers even noticed them). Given these experiences, partly with the best journals in the field (mathem. physics, global analysis), I decided to either refrain from this elusive process at all or at least to extremely de-prioritize the process of reviewing. It is an illusion that real understanding in mathematics or any other ‘hard’ (in the sense of deep) science could be ‘formalized’, the best reviewers of one’s papers are people who understand and extend/creatively are inspired by one’s results, it is very seldom, but only in this way science works.")

#text("To connect this to Trump&co: distinctions in the sense of formal elites that are (or used to be) neccessary and sufficient for certain ‘immigration rewards’ are often (apart from their often racist and sexist bias) from the category of the elusive reviewing process, no serious person thus would create a coordinate system of scientific (or in fact, any kind of) depth on this set of data; but mathematicians (at least generically) AND (indirectly) immigration authorities via the system of economic distinction use these data exclusively. Just as an illustration: I have artist friends who published with the best Jazz labels worldwide and who still can hardly pay their rent, they would never get a green card anywhere. Mathematicians often live in a strange parallel world, they do not realize that the world does not consist of formal qualifications but of hard won insight in the course of lives at the edges of reality. In this sense, a little bit of ‘hardship’ I would wish any of these mainly white and male mathematicians here who are suddenly so concerned that society turns (or even just could turn) against themselves and their peer group.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-479550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2017")])]

#text("Do you have anything besides irrational tu coque arguments to try to make?")

#text("You illogic is breathtaking.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477352")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Despite Bill Gates’s suggestion to the contrary, technology cannot replace flesh and blood collaboration or teaching. In terms of numbers: a MOOC course’s completion rate is 1% while a brick and mortar course’s completion rate is typically over 60%.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("The “I feel your pain…” stated in a disgusting deliberate sarcasm-way is largely irrelevant to the discussion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477349")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Thanks Terry, for speaking up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477353")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I should mention here that I have not the impression Trump is effectively targeting (at least not in the long run) scientific i.e. mathematical elites, not only would be the costs of such an endeavour too great economically, it is also not compatible with Trump’s own (albeit not openly stated) elitist social background and viewpoint. What I am missing here a bit as in Mark Zuckerberg’s very similar statements is that certain (‘functional’) elites do not reflect on the great similarity their viewpoints on questions of immigration have with radical populist views that now lead in turn to a seeming damage of the mathematical or scientific community. Having said this I also mention that the mathematical achievement is based historically on abilities of ‘social dropouts’ and outsiders who would not be included in any ‘immigration or green card’ program today (cf. Galois). To be a little more clear I am calling here for a certain self-criticism within the mathematical community wrt the question which mechanisms well inherent and accepted in their own circles ‘went nuts and radical’ within the current mainstream american or western society. Throughout europe, not mathematical elites are targeted wrt immigration, but very normal people, refugees, people who are searching for a better life. Achievement and positive contribution, even mathematical achievement and contribution, but in more broad terms any human achievement, cannot be measured, neither in monetary nor other terms, it is something mathematicians often seem to forget.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("In addition to Galois achievements (while being ‘social dropout’) you may add Newton, Einstein (during his patent office days) and Ramanujan.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd500aabd56b81f6643b31f074d92d701784e77b43ef82f0e830e7297b64a1a-c88b1a2ad26c3a5f6335fb15e3fcfc1701468232fcf2f1505acdc89f12c66e49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of victorivrii")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477355")[#strong[#text("victorivrii")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I really wish that the executive order of POTUS was more nuanced and I am really sorry for my esteemed colleagues who are affected by it. I really hope that 90 days later this temporary ban will expire and the restrictions will be lifted.")

#text("Still I should mention that those restrictions are really mild in comparison with the restrictions I and my colleagues in Soviet Union experienced. From 1973 to 1988 due to restrictions imposed by Soviet authorities missed tens of invitations to visit universities abroad, including to invited ICM talks; I was allowed just 1 conference trip to Eastern Germany. At that time there was no www, email and even preprints sent to me not always passed through, making preprints of my own and sending them without authorization (getting it would take months without guaranteed success) would be a felony (nevertheless I did a couple of times, including ICM @Berkeley). And not many Western colleagues were visiting USSR at that time.")

#text("From 1996 to 1997 I could not travel from Canada to anywhere except USA because there was no free pages in my old Soviet passport and there was no way to get a new one, only when I became a Canadian citizen I was able to travel.")

#text("And I know many the finest mathematicians who were affected much more. Those of them who immigrated to Israel after years of waiting permissions from Soviet authorities (and being jobless) could not meet their loved ones for decades since they were not permitted to USSR and their parents or siblings were not allowed abroad.")

#text("Today there are several countries which would not allow me in because I have Israeli stamps in my Canadian passport. There are crowds of loons in the USA, Canada, other countries, demanding boycott of Israeli universities and academics working there. I think it is a much large obstacle to scientific exchange than 90 days ban, which actually allows exceptions.")

#text("Still again: I really wish that the executive order of POTUS was more nuanced and I am really sorry for my esteemed colleagues who are affected by it. I really hope that 90 days later this temporary ban will expire and the restrictions will be lifted.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d023b6103f452d1cb4c75e18b22d23ea27cf0f759aacc414a653f64d27400748-e75cf5f8afcf9f5de1ae693196ccbf657b124f97d7987b1ab54691c9c4e2c411.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tcgrubb")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477359")[#strong[#text("tcgrubb")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Great post. I have heard talk of a “March for Science” coming up in the near(ish) future, see for instance ")#link("https://www.facebook.com/marchforscience/")[#text("https://www.facebook.com/marchforscience/")]#text(" . I hope that we may have a solid representation of mathematicians in the mix.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24e9a415ec706b67abd58f2ab15573996f7656cc2529710c2c1049d17e1defa5-11534d08dcbc857ec6ae807a702bd143ed2d90388b439ddc4d632429acd758a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of statsinthewild")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477361")[#strong[#text("statsinthewild")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Reblogged this on ")#link("http://statsinthewild.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/")[#text("Stats in the Wild")]#text(" and commented:")#linebreak()#text(" Terry Tao is smarter than you. You should listen to him. ")#link("https://en.wikipedia.org/wiki/Terence_Tao")[#text("https://en.wikipedia.org/wiki/Terence_Tao")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477364")[#strong[#text("Shtetl-Optimized » Blog Archive » First they came for the Iranians")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")]

#text("[…] Update (Jan. 31): See also this post by Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64b6ef98912a0f77417afe0bf810ef0dc3e8dfab695a938e7d7934c7abeb29b2-de08990b7648c0a255b9d4db1d178ac3302400b1489ef75904b5d72513f82c55.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffery Breeding-Allison")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477365")[#strong[#text("Jeffery Breeding-Allison")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Science Will Suffer Under Trump’s Travel Ban, Researchers Say")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02bac94babd1f10a61d6a34c6fef3ef21d52a84b8debdc2e02f5b15b3c10d5ae-2f8ff17e1311f739c91aab6a821816a2c8e48a73c1cf867d0451ddcd5379cdd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kaave")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477367")[#strong[#text("kaave")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("I’m Iranian and am a 4th year PhD student doing CS theory in the U.S.")#linebreak()#text(" I just want to emphasize that most Iranian students, including me, are given single entry visa from the very beginning. That means our visa will expire as soon as we leave US, and to be able to come back we have to go through the application and clearance check, etc. which on average takes three months. This issue has made the concept of attending international conferences not just “slow and frustrating” but practically impossible. I’ve had many friends who took the risk, attended a conference outside the U.S. to present their work, but were stuck in that country or had to go back to Iran waiting for their new US visa to be issued. Most of them took over three months to get their visa and come back to the States.")

#text("I’ve personally passed on attending many important conferences/events for this reason. Have not been able to go back and visit my family for about four years now. And of course the EO now has made it impossible for them to come visit me.")

#text("Other than those, and the emotional and academic cost attached to them, I have personally not been affected in other ways.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477374")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Actually what kaave says is true and it is true for Iran in the sense that it is followed explicitly however it is also followed implicitly for indian students (in many cases) and professionals (in almost every case). And a lot of livelihood have been broken by this.")

#text("Also I am wondering where were people like yourselves when the US literally makes people from India to wait 20 years to get a green card while people from your country (australia) can get in 6 months. Your statement of saying ‘at least there was a path to a green card’ is a joke. You had a path because you were among the very best. If you apply that rule that applied to you in general you would at best get 20 green cards for every country (rather than the still pathetic 7000 allocated to any given country including vatican city for (in general approximate sense) immigrating on merit through H1B).")

#text("The executive order is a tragedy however your community’s butt kiss to Obama’s support for illegal at the expense of legals was also a tragedy. Without Obama there would not have been a Trump (at least not in the current form).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("It is good to know that you are minimally affected by this, but how about other Iranian students who want to apply for a visa to study master/Ph.D. programs in the US in the near future?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02bac94babd1f10a61d6a34c6fef3ef21d52a84b8debdc2e02f5b15b3c10d5ae-2f8ff17e1311f739c91aab6a821816a2c8e48a73c1cf867d0451ddcd5379cdd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kaave")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477422")[#strong[#text("kaave")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I just wanted to explain what the effect is on me personally. Didn’t want to imply that this is the average case. All I wanted to say was doing math and science as an Iranian in the US has always been extremely hard and unfair. I hope others will share their personal experience about this.")

#text("It of course messes up the admission process of all these great students. Most of them only applied to US, and already have offers, but will probably have to defer their admission to next year or lose their offers.")

#text("I know people who are stuck right now outside the US. I know friends who are worried about losing their job offers, because are not able to change their visa status. And many other cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477464")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("there is a clear tendency here in the remarks of US mathematicians to downplay the previous restrictions (and in fact, chicanes) and visa regulations for non-US mathematicians, i.e. of countries now included in the muslim ban and to focus on the further (of course, more obviously nuts) restrictions established by the Trump administration. Sorry to have to tell this to anybody and for these comparisons, but: Hitler has not come overnight to Germany, the Nuernberg race laws were NOT invented by ‘Hitler’s surrounding’ but went back to a tradition of racism in Germany that was at least 130 years old (beginning with the german early romantics) and can be traced possibly, in the case of antijudaism, back to Martin Luther. The US tradition (‘pragmatism’) was that of an extreme utalitrism in the immigration question which was nearly ONLY based on economy or related formal requirements, which led even artists in all western cultures to the neccessity to carry ‘CVs’ with them that ressemble the kind of formal ‘CV’ invented essentially by the military industrial complex. The deformation only the US immigration system left on science and the arts in the west at least cannot be underestimated; the western immigration system thus was and is based on the requirements of the military industrial complex and in Trump’s and aforemost, in Bannon’s eyes, the requirements of the military industrial complex in our current situation ‘forbid’ very apparently not only ‘immigration of terrorists’ but to share scientific results or concepts related to it quite in general with scientists of the countries whom one considers ‘enemy’. At least in the worldview of Steve Bannon, a complete ban of scientific exchange between western and predominantly muslim countries is ‘required’. What I want to say is that we still are centred on the ‘requirements of the military industrial complex’, of course to attract the best scientists to the US had always a military motivation and to ‘block’ scientists from ‘enemy states’ is thus in the same logic. The fundamental logic of the military industrial complex and its deep involvement with the immigration system and authorities never changed, our reality changed, mathematicians are part of this ‘war’ that Bannon and Trump and many others want to steer the world into. Mathematicians will be part of it as long as they do not openly resist, and they were part of it before. Having said this, I do not believe, as I already remarked, that the Trump administration will uphold the current ban as long as it potentially damages the US military industrial complex, cf. mathematics, Bannon called for a ban of H1B visas, Trump opposed it, for obvious reasons. There is no moral or ‘humanity’ in any of these decisions, it is cold calculation within a deadly circle of ideas.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477466")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("..utilitarianism..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477475")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("“there is a clear tendency here in the remarks of US mathematicians to downplay the previous restrictions (and in fact, chicanes) and visa regulations for non-US mathematicians,”")

#text("I do not think anybody downplays anything. Terry simply made the observation that with Trump, things turned worse, and probably much more will come in an accelerated pace.")

#text("For me, the green card took 15 years and the citizenship took 20 years, so the story of Indian mathematicians is not unique or new.")

#text("I think, the Ivory tower label is also misused here. At US colleges, the vast majority of the grad students in math are foreigners, so profs are very much aware of the problems students have: visa, travel, insurance, TA salaries, job insecurities.")

#text("In the last 30 or so years (starting with Reagan, so before Trump), funds for higher ed have dramatically decreased. As a result, the number of grad students in math went down by 40% or more. For example, at Ohio State, there were 160 math grad students in my time, now their number is under 100. The number of tenured profs has decreased by similar rates.")

#text("So we have been alarmed by the status of grad students and the more general problems in higher ed. But it seems, the rate of decay would not only get greater but we can also expect changes in quality in Trump’s empire. Just think of Trump university.")

#text("What can profs do? Historically, they don’t like to organize themselves unless there is an imminent threat to academia. They may do something this time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477481")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("“Historically, they don’t like to organize themselves unless there is an imminent threat to academia. They may do something this time”")

#text("your description is correct, but you give no reason for this ‘historical fact’. I am always a little, one could say moved, by the ability of mathematicians and physicists to ‘objectively’ describe reality and still do not see what is going on. No US mathematician in this thread criticised the previous regulations wrt Iran or other ‘suspicious nations’, that is the definition of downplaying. They did never organize themselves because they are part of the, I repeat, military industrial complex, even its (by far) most important part and financially depend on its functionning and state guidance. It is the first time since, maybe since the Vietnam war, now that the military industrial complex not encourages their work but is entitled to delay it or even to destroy it. It is true, Steve Bannon alone could do more damage to the mathematical culture in the US than any single person ever before. But just as the german mathematicians and physicists who were not jewish mostly aligned behind Hitler also the white, non-muslim US mathematicians will arrange with the situation. Nobody can wash his or her hand in innocence, we always worked for a system that suddenly turns against us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477510")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("“…they are part of the, I repeat, military industrial complex,… german mathematicians and physicists who were not jewish mostly aligned behind Hitler also the white, non-Muslim US mathematicians will arrange with the situation. ”")

#text("So I guess, according to your logic, those Muslim grad students and profs who want to come to the US, want to be part of the military-industrial complex, and those who stay in Iran support radical Islam and terrorists.")

#text("Isn’t this the same logic and blanket labeling that drive the Muslim ban?")

#text("Let’s not equate people in a country with its politics.")

#text("And in case you further want to analyze US mathematicians’ historical behavior, please take into consideration that US profs have been taking care of grad students from Muslim countries for decades.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477578")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("Actually, the American Mathematical Society has adopted a pro-immigration policy since 1997: ")#link("http://www.ams.org/about-us/governance/policy-statements/sec-immigration")[#text("http://www.ams.org/about-us/governance/policy-statements/sec-immigration")]

#text("Traditionally, though, academic societies prefer to try to add their policy input by other means than public pronouncements. The National Academy of Sciences, for instance, is in fact routinely commissioned by Congress to report on various issues in the public interest (e.g. immigration, climate change, cybersecurity, etc.). It did manage to ")#link("https://www.nytimes.com/2016/09/29/opinion/campaign-stops/what-does-immigration-actually-cost-us.html?_r=0")[#text("insert itself in a minor way into the presidential campaign")]#text(" with a ")#link("https://www.nap.edu/catalog/23550/the-economic-and-fiscal-consequences-of-immigration")[#text("Sep 2016 report on immigration")]#text(" weighing the pros and cons of immigration (see also ")#link("https://www.nap.edu/catalog/21746/the-integration-of-immigrants-into-american-society")[#text("this report one year earlier on the integration of immigrants into the US")]#text("). Such reports might not be routinely read (apart from executive summaries) by lawmakers themselves, but would typically be read by the lawmaker’s staff, or advisors such as the Science Advisor to the US president. Though I am not entirely sure that the advisors to the current US president would continue to read them…")

#text("See also the 2007 NAS report “Rising above the Gathering Storm” (available for instance ")#link("https://www.utsystem.edu/competitive/files/RAGS-fullreport.pdf")[#text("here")]#text("), which did receive quite a bit of attention in political circles, and definitely did advocate against the tighter visa controls etc. that emerged after the September 11 attacks. The 2013 report “The Mathematical Sciences in 2025” by the National Research Council and National Academies, available for instance ")#link("http://www.eu-maths-in.eu/EUMATHSIN/wp-content/uploads/2016/02/2013-USA_report_mathematics_2025.pdf")[#text("here")]#text(", also made similar points in its recommendations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477545")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("‘For me, the green card took 15 years and the citizenship took 20 years, so the story of Indian mathematicians is not unique or new’")

#text("Yeah right one isolated white dude example versus a million non-white dude example. great comparison keep up the good work for the sake of moral authority")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477563")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("“Yeah right one isolated white dude example”")

#text("At the time, every white dude from the ex communist block had the same difficulty as I did, and this meant thousands of profs and grad students. I just asked my Indian colleagues, and they got their citizenship faster than me at the time.")

#text("Every time I left the US, I had to reapply for a visa, and I was never sure, I’d get it, but seeing my family, friends back home was and is mandatory for me. Once, 28 years ago, I had this conversation with an official at the US embassy in Budapest")

#text("“Do you work with computers?”")

#text("“No.”")

#text("“Why didn’t you then make a note of that on your F1 visa application?”")

#text("“Well, I don’t play the piano either. Should I report all those things I won’t do? We’d be here all day”")

#text("“Well, you’ll be here longer than that.”")

#text("This attempt at joking cost me almost 3 months and missed half of a quarter at Ohio State, as a result.")

#text("Once my (now ex) wife got detained coming back to the US. She already had her PhD and her green card, but for unknown reason they didn’t trust her: “Where did you get your green card” they asked, and apparently she gave a suspicious answer.")

#text("So yeah, things were not great, but the Muslim ban indicates that much worse, much more open and systematic attacks are coming to immigrants, Academia, and education, in general.")

#text("I feel your pain, man. Foreign students are all around us: Indians, Iranians, Nigerians—from all over. A basic recommendation to y’all is not to take these political issues personally, because it consumes you. When thinking about individual unfair treatment, I like to think about Schrödinger, who didn’t get a position at the Institute of Advanced Studies, despite his Nobel Prize and Einstein’s recommendation and personal push.")

#text("Scientists try to do their stuff, but if a country prevents them from doing so, the country loses. What would have happened if Hitler hadn’t driven away all those who formed the core of the Manhattan project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477555")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("I am sorry that I might have made look at your struggles seem little. However that is not my main point. You have followed the rules. However for most folks the legal path is more or less a joke.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477556")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("I am sorry that I might have made seem that your struggles seem little. However that is not my main point. You have followed the rules. However for most folks the legal path is more or less a joke. Even for the people who are among the best (for whom a path exists without being at the mercy of someone’s or some organization’s whim) – just look at what craziness one needs to go through.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477569")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("‘I just asked my Indian colleagues, and they got their citizenship faster than me at the time.’")

#text("That is where you are making the mistake. Universities sponsor green card without qualms in the extraordinary category (usually consisiting of say 100 people max per country). For these people GC is a cake walk compared to mortals. You are living in an ivory tower. Also universities have people who are among the best (or that is how the thinking goes) and for them either way there is always a path (like Tao’s O1 or category through Extraordinary abilities). Corporations do not do that. They suck your blood and they will not sponsor since they know if I get a green card I am a free man (yes a free man).")

#text("For instance did you know that except for Chinese and Indian students the H1B is unnecessary? If a corporation wants it they can get any other student their green card process done in 6-9 months and get their green cards while on their OPTs. They do not do that. Why do corporations want to expand H1B rather than giving green cards to international students?")

#text("There are lots and lots I can write. But the previous administration’s suck up to illegals at the expense of legals and citizens was the cost that gave us the current version of Trump. Who funds the illegals at a public university? Why is there a correlation between rise of illegals at undergrads and rise of international students at undergrads and rise of non-resident tuition? I do not know the answer but I suspect there is a connection. Where is your community’s moral stand on these questions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477570")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("‘any other student’ should be ‘any other grad student’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477593")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("(Mate wrote) “So I guess, according to your logic, those Muslim grad students and profs who want to come to the US, want to be part of the military-industrial complex, and those who stay in Iran support radical Islam and terrorists”")

#text("they are already part of a certain military industrial complex when they apply; it is in the logic of the (US, western) military and the institutions supporting them to give a sequence of incentives that function on an individual level to attract international expertise and have few to do with politics. That is, an Iranian physicist immigrating within certain privileges warranted by the military industrial complex can still oppose the US military interventions in the middle east or Afghanistan, but he/she will still support the US military industrial complex. Bannon and Trump exactly ideologize a certain highly productive utilitarian system with potential severe downsides for the US economy and innovation in defense. This is in the end the same mechanism that (thank god) prevented the germans in the 1940s from developping something similar to the Manhattan project, they didn’t have the expertise anymore.")

#text("(Terry wrote) “which did receive quite a bit of attention in political circles, and definitely did advocate against the tighter visa controls etc. that emerged after the September 11 attacks”")

#text("without knowing the reports you linked and more or less by definition, the recommendations in these petitions will predominantly (‘Panel on the Economic and Fiscal Consequences of Immigration’) refer to the (mostly negative) impact on scientific expertise, economics and (elite) research induced by (certain) immigration restrictions and still thus again do not leave the narrow margin of (scientific, economic, military) ‘neccessity’. The idea of the EU, just as an example, was an idea that was beyond neccesssity, at least in its latest version, and exactly on these grounds it is attacked today: to let in EU-immigrants who have near-zero economic power or no exceptional formal education is for any given EU country based on principles which couldn’t be farther from ‘neccessity’ and still they were applied, because immigration, at least within the EU, was given a quality beyond, I repeat, the logic of economics, state budgets or the military industrial complex, of course on the background of the european history. I contend, and sorry if I have to repeat this again and again, that mathematicians in their political lobbying never left the ‘logic of neccessity’ of their own subject (and slightly extended areas) and thus, while apparently denying to even be part of it, never left the logic of the military industrial complex. Immigration bans of the Trump type are developed within a certain (ideologized) logic of neccessity and these affect not only a thin ‘elite’ of researchers, but potentially millions for whom such decisions can be decisions on life and death. It is a grotesque fail of western media alone to again and again emphasize the ‘elite university exams’ of certain individuals affected by the Trump ban, these people with ‘elite exams’, as I claim, were never aimed at to be affected in the long run. Xenophobic discourses work with a ‘shock and awe’ tactics that gradually shrinkens the areas of ‘taboo’ within ‘normality’ by using discontinuous restraint techniques that are often *a posteriori* relaxed to present certain restrictions on fundamental rights as warranted. In this sense, a refugee ban may rest in place, while economy-damaging restrictions on research cooperations may be lifted and I do not see that any National Science academies would object.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477617")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("” “Do current policies and practices facilitate their integration?” …these discourses are in itself problematic, ill-defined and questionable ”")

#text("This remark and the rest are of the kind")

#text("“Let me in and my friends into your screwed up home, you SOBs”")

#text("and")

#text("“Once you let me in into your home, I want to set my own rules.”")

#text("Shouldn’t there be some discourse on mutual respect between host and guests?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477594")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2017")])]

#text("(from the ")#link("https://www.nap.edu/catalog/21746/the-integration-of-immigrants-into-american-society")[#text(" NAS report")]#text(" on immigration linked by Terry above) “Whether they are successfully integrating is therefore a pressing and important question. Are new immigrants and their children being well integrated into American society, within and across generations? Do current policies and practices facilitate their integration?”")

#text("these discourses are in itself problematic, ill-defined and questionable and many immigrant communities in Germany (as an example) campaign since years and decades against this paternalization inherent in defining ‘the good [integrated] immigrant’ and the ‘bad [non-integrated] immigrant’. These discourses go in europe back to the ‘the good jew-the bad jew’ discourses in Germany in the 19th century and the inability of wide circles of the population to decide which kind of jew was actually more dangerous: the assimilated, thus invisible jew or the non-assimilated, thus visible, jew, it can be all read in Hannah Arendt’s ‘The origins of totalitarianism’, a book that apparently noone in the US NAS ever read, and i.e. no mathematician. There is a well-known german racist, Thilo Sarrazin, who published one of the best-sold racist hate speeches of the last 20 years in Germany, his favourite sentence [mostly addressed to muslim immigrants] is: ‘vee vant you too intecrate’, exactly with this kind of english pronunciation. Hannah Arendt wrote in her famous essay ")#link("https://www-leland.stanford.edu/dept/DLCL/files/pdf/hannah_arendt_we_refugees.pdf")[#text("We refugees")]#text(" that for her as a refugee in the US it was of uttermost importance to remain critical, also in a sense distanced and exactly not to embrace the same identification with the same societal elites that turned out to be so catastrophic for the european jews, this stance couldn’t be further from this sticky and glibberish “embracing an American identity and citizenship, protecting our country through service in our military” formulated in the above cited report summary. Being ‘successfully integrated’ is by no means the rule for the autochtonic population in any western country, to the contrary a certain particularian (op)position is in general encouraged by most western countries (not by Trump of course) after the catastrophic degenerations of democracy in the 20th century became apparent, but the above NAA article washes these ‘subtleties’ away as if they never existed or were relevant.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c305bb3ef68ea5e9459269d7a8395a296517a015c2ea71cf76933da342b2c147-2d10cca577c88c9d1d5be74b70d221493178cfbf02af0073b15800b72c3716c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477571")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("Also why is an illegal who is doing a sociology or women’s studies or marketing degree highlighted on NY times (when in case the funding might be possibly is supported by a legal undergrad (who pays non-resident tuition at a rate par with fees at Stanford or MIT) while hardworking at an engineering or math program who has to fight to survive here)? If he/she misses a mark on immigration papers his/her life could be ruined while the sociology major is hailed as a hero.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8deb824feb5ced91c224c79166dd96d28f44206f66695dc955e2a9ca861b6121-ce43188033867af05da33f0e22883b3f4a0e353bcb2fd7ca43ec3d66135ceafc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477368")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Let me muddy the waters with this article. ")#link("http://www.economist.com/news/science-and-technology/21715639-effects-foreign-competition-professors-mathematics-mediocre-academic")[#text("http://www.economist.com/news/science-and-technology/21715639-effects-foreign-competition-professors-mathematics-mediocre-academic")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19299569f429e9a942d583c25cae967e49a3ac3ebcd691952ca6e74aabb8dc80-5032ebdaf18299e3eeb136f38d2259dd323865902d56b096733d8399530c30f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keith McClary")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477435")[#strong[#text("Keith McClary")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("It occurs to me that these visa and immigration restrictions may also be part of the Republicans’ “bring back our jobs” plan.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477439")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("there is no way to bring jobs back without causing an eventual WWIII. period.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22559fbc2bcf58624f7af2493fd811d8dcb4a5301e832d5dc57c3edf055ad22d-62533e95f3a5cf953113cd07e86d901460d2f62fa9d2e3421b20aaa3b4370fc2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477370")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Rather than transforming President Trump’s nuanced economic and security arguments into emotional goop, we could start by clearly identifying the sections of 13769 people are objecting to or interpreting hyperbolically.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/33ca53ec44803def6f6024a878a0f9e79449de53e3d4da9c3cdb6a7c0b085eb1-a99b8dced355be4e1ced9d1a008b74d2fb9f1034dc8962ad21020fc738445f8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The female mathematician down the hallway")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477371")[#strong[#text("The female mathematician down the hallway")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("Agree with everything you say about trump and the sorry state of the nation. For a woman of color like myself, color and gender has always been centermost in how my esteemed math colleagues perceive me. It’s truly awful the way my research group behaves and the abusive mysoginistic behavior I’ve experienced. Trump is making large numbers of people experience the crap that I experience. Welcome to my world folks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477375")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2017")])]

#text("There’s a reddit thread that contains a lot of letters sent out by university presidents opposing the order and offering help to affected people:")

#link("https://redd.it/5qpnpo")[#text("https://redd.it/5qpnpo")]

#text("It’s a big comment thread so there’s all kinds of other stuff (good and not-so-good) there as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477377")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("As an opponent of Trump I actually feel glad he’s doing this crazy crap so early in his term, since it means his presidency will collapse quickly, court decisions will stop the exec order, he’ll be treated like a buffoon by the Congress and the press who have afforded him much too much credibility til now, etc. But, maybe I’m overoptimistic. It could all go sideways quite badly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477379")[#strong[#text("Open thread for mathematicians on the immigration executive order")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")]

#text("[…] The self-chosen remit of my blog is “Updates on my research and expository papers, discussion of open problems, and other maths-related topics”. Of the 774 posts on this blog, I estima… – Read full story at Hacker News […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b1b8cbce576a4fb5887e60c5073b9f8c4aa3828cef5365bf620a76b0968a693-136cadf387cbe1b6064e7bbe14e3e20393fccedca384e0921fc2ac6ca734f16e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richardelwes")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477381")[#strong[#text("richardelwes")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("The President of the European Mathematical Society has issued a statement:")

#link("http://www.euro-math-soc.eu/news/17/01/31/ems-president-trumps-executive-order")[#text("http://www.euro-math-soc.eu/news/17/01/31/ems-president-trumps-executive-order")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96b296a65baa000a9b3d86746b6f6bf97e6b04a8cb0ba2c7974c009e9648685a-cf444f34139523566652e214b6c0941d838fa2017da7cc07b2a870d88aedbde8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu Raghavan")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477383")[#strong[#text("Raghu Raghavan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I am not a mathematician, but if I may comment, such an effort on behalf of mathematicians alone seems doomed to failure. One has to join forces “for the greater good” and the theme must be “patriotic”, i.e. benefiting the U.S., not mathematics (alone). For example, can anything be more obscene than Jerry Falwell Jr heading the education task force to reform education in the U.S.? In my opinion, that is the fight to join in within the general theme of education and learning. There may be others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477388")[#strong[#text("US Bans Travelers from Certain Muslim Countries | Page 3 | Physics Forums - The Fusion of Science and Community")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")]

#text("[…] case someone wants to read what Terence Tao has to say about it: ")#link("https://terrytao.wordpress.com/2017")[#text("https://terrytao.wordpress.com/2017")]#text("…maticians-on-the-immigration-executive-order/ fresh_42, Feb 1, 2017 at 7:47 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477389")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("The effectiveness of mathematics comes from the different points of view that have had mathematicians during human history.")#linebreak()#text(" It is an activity of the mind and in this sense we need the diversity of humans to enrich it, clarify it, and make it evolve.")#linebreak()#text(" The miraculous science that is mathematics in the sense that it turns out to be at the same time beautiful, true and applicable outside of itself is a part of")#linebreak()#text(" the human civilization.")

#text("Nevertheless, science, including mathematics, must remain independent of the political, geopolitical and societal context as much as possible. This is necessary for the sustainability of its activity. The school system varies from country to country and is far from being adapted to the personality and way of thinking of each person.It is far from being optimal but there is positive. What I mean by this example is that scientists have a moral obligation. There is the success of some in a given context but also the failure of others equally capable placed in another context. And this failure is sometimes")#linebreak()#text(" attributable to society such as opposing immigration, excluding sick people, conveying racism or stigmatizing the woman.")

#text("There is a dual nature of science in the sense that it is a collective adventure whose motor is the individual mind. And it is this union of minds, a union which I dare to describe as transcendent since it involves the individual factor as we have been able to see throughout history, which is the force of science. We should not prevented the brilliant minds from meeting. There are people who are capable of producing immortal works but the environment is a decisive factor.")

#text("The world is going badly. The collective neurosis in which we all live makes us lose the simplest questions but also the most essentials. I think that humanity needs to find simple questions. By simple, I do not mean decadence")#linebreak()#text(" or decay but rather a path to truth. And it is by taking this path, which is barred to us by societal obstacles, that we will move in the right direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4bb7b173e23057d49abb4639853476f18a744d744a60704ea4ddf5a769d52e5-0a3792c1ac974e967c69dcaa4fb62f43ee96986cb3da21cc4e3daba5cc6deb48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477391")[#strong[#text("Carl")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text(">It is no coincidence that all of the top mathematics department worldwide")

#text("Which mathematics department would you say are at the top?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477393")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("“Your statement of saying ‘at least there was a path to a green card’ is a joke. You had a path because you were the best. ”")

#text("Instead of picking on particulars why not grasp the essence of the post: the anti Muslim executive order effects even scientists like Terry and universities like UCLA. Then draw the conclusion how much worse it is going to get at lesser universities. Will there be graduate programs which won’t survive without students from Muslim countries? If a graduate program doesn’t survive, will the profs be able to do research with a 16 hr/week teaching load?")

#text("The more general prospects are scary too. For example, Duncan was a terrible secretary of education. But with DeVos, Trump appointed enemy number one of public education to lead public education. Low level public universities suffered a great deal under Duncan. Under DeVos, even high level public universities will struggle. Where will fresh PhDs get jobs?")

#text("Same can be said about most other Trump appointments, like EPA.")

#text("How can we even remotely compare the promise of Trump’s world with its Trump University model with what we had before?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477400")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("If you don’t see the tragedy in ‘at least there was a path to a green card’ or ‘have to wait 20 years if you are Indian versus 6 months literally any other country to immigrate on merit’ or ‘the effect of the rule that is applied to Iranians is also morally endured by Indians (but not the rule is applied itself)’ and your community’s apathy to these and more but hypocritically taking the moral high ground here there is really no point to conversing with you. You are another typical chauvinstic democrat.")

#text("If Obama had not sucked up to illegals at the expense of legals and citizens the current tragedy of Trump would not have happened.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a41889b7a0e5ca06b0f62fb9e2c13cca6be766e12b9ed513cf9f03bdba0ade1b-4e9312821d2652d1781d45365cb40335116644f29ee80be47de2cf5b5f8f2ac2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477394")[#strong[#text("Marco")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Hi Terry,")

#text("Have you considered moving to Australia, given current environment in the US?")

#text("What do you think about Australia passing Muslim veil ban recently?")

#text("What do you think about the fact that Japan accepted only 27 refugees last year?")

#text("What do you think about the fact that you can never become a citizen of Israel?")

#text("I am only curious about the first question but would appreciate if you feel like answering any of them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f06d4ce994e39906ec9c30fa041e6fb5f6881ddfd9a4bbd4dab90e2abcd24a38-c089f66a53f4b9d81747d6c047ac0349c907c1c769efcd0e8178c9c7d9468c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Caroline")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477618")[#strong[#text("Caroline")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2017")])]

#text("Australia has not passed a ‘Muslim veil ban’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Perhaps Trumps goal is in fact to cripple academia, as well as other “enemy” elements of society and culture, as part of a deliberate program of Gleichschaltung.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/106ed6c36169fb7c755c0e4fddfde16485049b53ffcca41f5e7b3e4349defdb4-caec155acaa8a4dc690d64227f3d5bb285d6f5c00d14a6a63bf5ab35e5d52f2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Yarbles")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477401")[#strong[#text("Paul Yarbles")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("President Trump believes that the good of the ban — making America safer — outweighs the bad. Terry Tao does not.")

#text("Terry Tao presents some of the bad with respect to mathematics and mathematicians. Even assuming his parochial argument here is 100% accurate, let’s not pretend he has proved that rescinding the current order is desirable. Mathematics is but a tiny part of the picture.")

#text("The conclusion that the ban is misguided is based more on feelings than rationality. Ask yourselves did you have a ‘gut reaction’ to the ban when you first heard of it? Especially given that it was Trump who issued the order. How many of you have changed your minds after your first reaction?")

#text("I know I have not. I didn’t even try hard to analyze it objectively. Did you?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477402")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Hey Yarbles let all countries ban one another for 6 months and lets see how goes the world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Stanidge")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477405")[#strong[#text("Jason Stanidge")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Is there a ban on immigration from Turkey into the US, despite it being a 96.5% majority Muslim country? nope… because Turkey is on the same side as the US in fighting Islamic sponsored terrorism.")

#text("I find it interesting the way academics with no background in political science and completely out of their depth, appear to be distorting the facts of the “muslim” immigration ban. it’s not a ban against muslims, but against those countries that pose the greatest threat in exporting Islamic sponsored terrorism to the US. The US is entitled to ensure the safety of its citizens via discrimination, just as the UCLA looks into the background of all their mathematicians to ensure they pose no threat to the students there, and to discriminate if necessary.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("“I find it interesting the way academics with no background in political science and completely out of their depth, appear to be distorting the facts of the “muslim” immigration ban.”")

#text("I find it pathetic the way a non-academic who presents zero knowledge about the claimed “facts” of the immigration ban tries to criticize a mathematician without even understanding one single sentence of his well-established statements in this post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477419")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("” find it interesting the way academics with no background in political science and completely out of their depth, appear to be distorting the facts of the “muslim” immigration ban.”")

#text("“Muslim ban” is just a brief reference of the ban, not a concept backed by a definition, but it well represents Trump’s and friends’ original intentions. To add the missing depth and objectivity to the discussion, here is an evaluation by Trump’s national security adviser")

#text("The senselessness of the ban is very well signified by the fact that its enforcement is based on passport checks. The vast majority of the 9/11 terrorist had a Saudi passport, but that country has not been listed as a terrorist threat—neither 15 years ago nor now.")

#text("All signs indicate, the ban was well planned, vetted, and carefully executed by experts, so America is already safer, though we are only 10 days into the minority rule.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477456")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("“it’s not a ban against muslims, but against those countries that pose the greatest threat in exporting Islamic sponsored terrorism to the US.”")

#text("If it were really that, then banning people from France, Belgium and Saudi Arabia, to give just three examples, would be a higher priority than banning people from Iran.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b29724acfcf4c09d871df48f4799e00cf956619ca983024185c51067d261cf9b-f60a81d83b8fc6ce8cb4048f3672370e1bede35ff9879cf0da448d805d4d73ad.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Máté Wierdl")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477467")[#strong[#text("Máté Wierdl")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Now that we are talking about which countries’ citizens we should ban from entering the US to make it safer, let me share my research on American safety with y’all.")

#text("In summary, we should ban us, Americans. That way, we could prevent 11K murders each year which is 10,998 more than the murders committed by Muslim terrorists from foreign countries.")

#text("The basis of my research is the following database by huffpost.")

#link("http://images.huffingtonpost.com/2016-09-01-1472759565-493250-extreme_extreme_vetting.jpg")[#image("../assets/f4e7ce01be611f5c266e1d4bca6b060a5ce8b39679e2b4976172ece978da0b9c-74e3a904fd80003114b7450693e4cfda6d61274eea0616c860cb375b1a4b6c83.jpg", width: 90%)]

#text("According to the stats, our government need to ban lightning and bus drivers since they kill much more civilians each year than Muslim jihadists sneaking in from abroad. Right wingers and and home grown jihadists (proud US passport owners) are also more likely to kill Americans—not to mention the danger of toddlers, though I have no idea how to ban them since they usually do not have a passport.")

#text("Clearly, the safest thing to do is just to ban ")#emph[#text("all")]#text(" Americans, regardless of race, sex, religious affiliation, original birth country or passport ownership.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477676")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2017")])]

#text("You’re the one out of your depth. There are already heavy background checks, and as statistics show, it’s dumb right-wing Americans who have posed the greatest internal threat to other Americans.")

#text("Please point to your equivalent semi-hysterical fear-mongering about right-wing terrorists, who are the real threats.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c073ab73f8708c49b6b62cf546453186434ad3f2ac822a8edc7e6dec31f616f8-2f580c9bca93019a9a12ed3e7258c4cdddc47a11caf22d72a4f90157c1cbdeb2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Mullin")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477413")[#strong[#text("Mark Mullin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I’m a dilettante in machine learning, but you can’t throw a rock in this space without hitting some cartesian product of mathematicians – I’ve been watching this go on with quiet horror over the last several years as what was a polygot community of researchers migrated, first with those that had that felt they must, and then others because they wanted to go play with their friends. Europe is rising, for the moment, Canada is way up there, and here, well hell, DARPA has to fund core vision research with 3/4 Chinese nationals (not knocking them, I liked the paper) – this seems more like the death rattle than day zero to me")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ba3736a9aef9b0ad2685f6c0b2a08529f21eb2df2464ae21c32cad378105d08-a5f485a54c60577d63f6ce740aad3f278b41470c65ae315aa714462bc6aa59c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaclyn Lang")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477414")[#strong[#text("Jaclyn Lang")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("The media coverage of this issue generally seems to assume that academics and students were not the intended target of this order and that they got caught up in it because the order was thrown together haphazardly, without careful consideration for its wide ranging ramifications. I think it is worth considering the possibility that, for some people in power (e.g. Bannon), it was “a feature and not a bug” that this ban undermines students and researchers. For instance, this article cites Bannon’s (and possibly Trump’s by extension) opposition to the H-1B visa program and to international students at U.S. universities: ")#link("https://www.washingtonpost.com/politics/bannon-explained-his-worldview-well-before-it-became-official-us-policy/2017/01/31/2f4102ac-e7ca-11e6-80c2-30e57e57e05d_story.html?utm_term=.ba53bf0f89bb&wpisrc=nl_most-draw16&wpmm=1")[#text("https://www.washingtonpost.com/politics/bannon-explained-his-worldview-well-before-it-became-official-us-policy/2017/01/31/2f4102ac-e7ca-11e6-80c2-30e57e57e05d_story.html?utm_term=.ba53bf0f89bb&wpisrc=nl_most-draw16&wpmm=1")]

#text("It is worth fighting not only the devastating impact of the current order, but being vigilant against its expansion in the future.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477420")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Good point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/238ee1d9da8ca3ab25eae81d3aa3599068e23fbed8a22a811722fdb0b83a4260-1a9364bf62fba8adbded36a283de2b887c05430a19bd40074afc7d7e23062258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Cutler")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477417")[#strong[#text("Anthony Cutler")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("A timely account of how similar political impulses changed the mathematical world from Germany to America eighty years ago.")#linebreak()#text(" ")#link("http://undark.org/article/math-lesson-hitlers-germany/")[#text("http://undark.org/article/math-lesson-hitlers-germany/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3b319d242fb17a5ec6471fc28be9a160df0dd1f57a7a906797c4413a898e5e2-5cbfc2cc02695126524f86c7a4d884cceea618181a474429bc0723ca5cc243cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Riley Hoogendoorn")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477418")[#strong[#text("Riley Hoogendoorn")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I would write a long comment, but this article will summarize. ")#link("https://theanimalprojectblog.wordpress.com/2017/02/01/trump-immigration/")[#text("https://theanimalprojectblog.wordpress.com/2017/02/01/trump-immigration/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477423")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Well, this shows once more the simple thing many people missed: The Republicans are a bad party, actively working for evil. People NEED to vote Democrat in the mid-term elections. Otherwise, your nation is in big ****.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hamed Hatami")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477424")[#strong[#text("Hamed Hatami")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Thanks for starting this thread.")

#text("As Kaave also pointed out attending conferences has always been an issue for students from certain countries such as Iran. This is particularly a big problem in theoretical computer science because in this field, unlike the other areas of mathematics, the most prestigious publication venues are conferences, and these are the places where graduate students present their work, talk to other people and establish themselves as new researchers. Before this order, at least there was a way (though not very easy) for students outside US to attend these conferences, but now it seems that all doors are shut.")

#text("I don’t know what can be done about it though. There has always been a discussion in the community about moving the major conferences to outside US so that everybody can attend them, but this actually hurts a larger number of students as many of the stronger ones attend the top universities in states and only have single entry visas. Maybe alternating between states and outside states would be a practical solution.")

#text("The reason I mentioned the issue of the conferences first is not because I think it is the most important one, but it is something that I think maybe as the scientific community we can find a solution for it.")

#text("I think the instability and damaging the trust is a more important one. I have a Chinese friend who is accepted a postdoc in the states, and he is planning to move there next year, but even he was worried that some arbitrary executive orders or laws might affect him in the future. There events of the past few days sound like something from a V.S. Naipaul novel about an unstable African country: As an outsider you know that you must be ready to pack and leave at any minute.")

#text("Because of my background obviously I know many academics that are affected by this ban. I know a couple where the husband studies in the US, and the wife is a permanent resident in Canada. She cannot go to the US to visit him, and he cannot go to Canada to visit her because if he leaves he cannot go back and finish his studies. I have heard about another student who was travelling to do some field work, and now he cannot return to the US, and the crazy thing about his case is that because he was politically active in Iran and participated in certain protests there, he might be arrested if he goes back to Iran. (It would be ironic if they prosecute him for working for the American government to overthrow the Iranian regime, an allegation that they routinely use against political activists). There are so many other upsetting stories about people who are affected by this.")

#text("On the positive side, the support from American people and American institutions, and the oppositions to this madness has been really encouraging. As a dual citizen of Canada, I’m not directly affected by the ban, but I have friends and family members who are going through a hard time because of this. It is moving to see how many Americans are generously volunteering to help and standing up against this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98573df78f21738ee208f46fda080b63615a41ce5430e3c317e3486a824e3f31-80e52398808cb1c9751e2014daffca486d9666169325f07daef7e4b24e348b5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eren Mehmet Kiral")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477425")[#strong[#text("Eren Mehmet Kiral")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("It is very true that this ban affects people on visas outside those 7 countries as well. I am from Turkey and currently on H1B status (work visa). I do not have a visa sticker on my passport because I did not leave the country since I changed my status. Now I wouldn’t risk getting out of the country for giving a talk in Europe (or even Canada) because it does not even require a ban to make it hard for me to get the visa sticker. It is the embassy’s prerogative to give me a hard time, even without any new law or executive order. It can easily take 1-3 months, and then I would be missing out on the current MSRI program I am in.")

#text("I am at a juncture in my career, I am looking for a position. Combined with today’s news about H1B visa holders needing to make at least 130K/year, it is unlikely that there will be a company/university willing to hire me amidst such uncertainty. I am a person who is likely to join the talented workforce of another developed country. I am unsure on how far this will go, if I have the choice I will most likely opt for a more stable developed country.")

#text("(By the way the Iranians already had it tough, they only got a single entry visa whenever they did! I know many Iranians completing their Ph.D. without once leaving for Iran, in the fear that they wouldn’t be able to renew their visas.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0100bf93a62154960c15552b8cf28a077f97a2e7a218ac0c999743459ce4fc2-4fa5cf2f287e8e770c4c61c3939d9d7ee35ef9c673e2262cdcd12cde2c1bb1a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of monodromie")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477427")[#strong[#text("monodromie")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("your and many others’ experiences show how deep and general the problem is and how far beyond the current travel ban, the Trump administration and Steve Bannon it is. I still cannot quite ignore my suspicion that (white, western) mathematicians never protested against the previous regulations because one thought to be still on the ‘winner side’ or even profited from exploiting young researchers under difficult visa conditions. Recently died sociologist Zygmunt Bauman wrote about this phenomenon of the silence of the scientists in (missing) opposition to the state as being inherently dependent on the state; it is by no means a new phneomenon. Thus if one could call this thread here resistance: better late than never, but the problems run deep since a long time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477471")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("My advice without stamp dont leave the country. I did the mistake. They almost destroyed my life. For Turkey it is easy to get green card. 6 months max. Ask your company to apply green card and say you will sign an agreement to work 3-4 years and surrender much of pay if you leave. H1B is in my honest opinion useful only for Indian and Chinese people while for other countries companies (if they want but rarely do) get green card in 6 months.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c7edef83ef104611889317d5461c6b77840ef992d8daf6b77f4ff16c8ccf28e-1b575aa064053fab640e446669c37f727302a223ebe3e90cec3fa58c7553537c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kat.")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477472")[#strong[#text("kat.")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Profs like these (however nobel they may take their goals to be) still only live in ivory towers and do not even realize the reality they are witnessing has been consistently around them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b3741ecf0ec114705b891633eebfb6c7e388c865b4592b487205178701c452e-49bb0d009909652c88b9fc97c1e25794189b1e1efa443b05370ed48a7013f154.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477492")[#strong[#text("Hossein")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Dear Eren, I assume the 130K /year requirement, if implemented, is only for non-academic jobs. Of course, the new administration, has little to no experience and knowledge regarding these matters, so I will not be surprised to see a lot of contradictory statements.")

#text("Any ways, I hope the best for you. Living has never been easy. I couldn’t see my family for 11 years, until I got my green card. It wasn’t pleasant, but wasn’t the worst thing that could happen either. At least I was able to talk to my family on the phone whenever I wanted. Our professors who came to the US in the 60’s, or before, didn’t have this luxury either!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e40f18514c413565472b6567f526198c910d5abddcd0db9df2208d5cf5eff03-956fda3a505566d47a9e98388f43a3882bc213fd4e96635d2222ba42ba0bd6ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of زهرا خانم")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477430")[#strong[#text("زهرا خانم")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("hello dear trrence , i want to tell you all of these games is for one reason :")#linebreak()#text(" america (usa) and western governments are satanists in cover of christianity. they fight against arrivals of Jesus Christ and twelve imam in cover of helping to jesus (fake jesus) to arrive.")

#text("worst government in all of history in fact is USA america .")

#text("iran and iranian peoples and mullahs wants to help reall jesus and twelve imam to arrive but satanists (But usa and westerns ) dont want any sign of god so they want to run war against iran ( jesus and tewlve imam)")

#text("just it.everything else is Backtrack and lie.")

#text("i recommend to you to read about muslim-shia and twelve mam but not in the western books or medias but in iranian websites and books.")

#text("i recommend to you to learn persian and read those really nice books and stories about twelve imam and jesus.")

#text("thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e40f18514c413565472b6567f526198c910d5abddcd0db9df2208d5cf5eff03-956fda3a505566d47a9e98388f43a3882bc213fd4e96635d2222ba42ba0bd6ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of زهرا خانم")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477459")[#strong[#text("زهرا خانم")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("yes absolutely! he gave us internet to spy us ! to make us westernized !")#linebreak()#text(" to enter his motherfucker (very young and bad ) culture to our country!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b3741ecf0ec114705b891633eebfb6c7e388c865b4592b487205178701c452e-49bb0d009909652c88b9fc97c1e25794189b1e1efa443b05370ed48a7013f154.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477494")[#strong[#text("Hossein")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")])]

#text("Oh my… you have such a bad mouth!! Not good for a GOD-FEARING, OBEDIENT, LADY like YOU.")

#text("After receiving my PhD in Mathematics and working as a mathematician for several years, I recently discovered that I haven’t been a good servant for God, so I have decided to join Wall Street in order to bring even a harder blow to this system than the one in 2008. God willing, this time we will be successful, and who knows, maybe even we could pray together right behind the hidden 12th Imam and the Real Jesus in Manhattan.")

#text("Amen!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477498")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2017")])]

#text("This “polite” comment seems to be against the rules of this blog.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477437")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("Professor there was a comment which said ‘will you move to Australia?’. You have family and stuff. However you have achieved pretty much everything you could except for a millennium prize. If you still take the step and move to Australia 1) that will raise profile and awareness of the issue 2) if they really intend to keep the educated the administration will try to keep you as an example and bring the calamity to a stop 3) if they do want to treat immigrants as they are treating and intending to treat then 3a) you had made the right step 3b) if they don’t even treat you with dignity that will raise awareness among younger skilled immigrants who will be wise before coming here.")

#text("You have nothing to lose. I think you should influence the entire math community on this (at least privately).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b44ce8246878d093329b309f43e0a442ca5322be6c84c6b7bf77601890dbf2c-2c3844d1277402ede3abd8a22c2ba4dbb07e39b30d719a9aa2004bb8e00f164b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zar")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477443")[#strong[#text("Zar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("I think that blog posts like this one are a waste of time. The Trump supporters are well aware that the America first policy will lower the overall quality of our scientific institutions; they simply believe prioritizing Americans make it worthwhile. Seriously, do you think that expounding on the globalist point of view in the case at hand will change anyone’s mind? The people in charge are ardent about their views and are also not the type to pay heed to online petitions and statements. A Trump supporter would just view Terry Tao as an entitled foreigner who thinks that foreigners have the right to American resources. Any argument about how immigrants have helped build our institutions will likely be discounted.")

#text("By the way, the latest developments are most definitely a form of the Muslim ban; Rudy Giuliani described how it was devised as such on national TV. And over time there will likely be further developments of this kind.")

#text("My personal opinion on how to fight this is focus on the humanitarian aspects… the refugees who won’t be able to come and the families that are being torn apart. Also individual stories of respectable people like doctors, scientists, and so on, whose stories make it clear their presence helps the US. Discussion of collaboration opportunities for mathematicians proving abstract theorems probably won’t sway too many minds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c92e30433b0efd0417f79396502dfe49723bef56311a1fc5595ab19406d1772-f232ad78c384a40ee517d8ea10f3581ec2981976ff77a2aaf2eae12ead53fab1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Monte Hancock")]], [#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477445")[#strong[#text("Monte Hancock")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2017")])]

#text("State sponsored terrorism is an unfortunate reality… but it is a reality nonetheless. The citizens of criminal nations are the foremost victims of their lawless leaders. Again, unfortunate.")

#text("Nations that abide by the rule of law have, not just a right, but an obligation to protect the lives and livelihoods of their own citizens from from foreign threats. Failure to perform this basic function of government in the service of a dubious ethical trade would be malfeasance of the worst sort.")

#text("Further, no proper interest is served by criticizing sovereign nations for fulfilling their fundamental responsibility. The suggestion that law-abiding nations have some sort of moral responsibility to put their citizens at risk by ignoring the reality created by rogue states is an absurdity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/01/31/open-thread-for-mathematicians-on-the-immigration-executive-order/comment-page-1/#comment-477447")[#strong[#text("Edmund Landau and the Early Days of the Hebrew University of Jerusalem | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2017")]

#text("[…] of the Landau Center for Research in Mathematical Analysis, Jerusalem, Feb. 28th, 1989). A recent post on Tao’s blog related to mathematics, science, scientific relations and […]")
]
