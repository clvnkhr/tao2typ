// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/
// Converted to Typst by tao2typ: "2026-10-14T10:56:40.517633+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 10 – mean values of nonpretentious multiplicative functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")[#text("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let us call an arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" ")#emph[#mi("{1}")#text("-bounded")]#text(" if we have ")#tao-math("{\\left|f(n)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{n \\in {\\bf N}}")#text(". In this section we focus on the asymptotic behaviour of ")#mi("{1}")#text("-bounded multiplicative functions. Some key examples of such functions include:")

#list(
[#text("The ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu}")#text(";")],
[#text("The ")#link("https://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda}")#text(";")],
[#text("“")#link("https://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean")]#text("” characters ")#mi("{n \\mapsto n^{it}}")#text(" (which I call Archimedean because they are pullbacks of a Fourier character ")#mi("{x \\mapsto x^{it}}")#text(" on the multiplicative group ")#mi("{{\\bf R}^+}")#text(", which has the Archimedean property);")],
[#link("https://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet characters")]#text(" (or “non-Archimedean” characters) ")#mi("{\\chi}")#text(" (which are essentially pullbacks of Fourier characters on a multiplicative cyclic group ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(" with the discrete (")#link("https://en.wikipedia.org/wiki/Ultrametric_space")[#text("non-Archimedean")]#text(") metric);")],
[#text("Hybrid characters ")#mi("{n \\mapsto \\chi(n) n^{it}}")#text(".")]
)

#text("The space of ")#mi("{1}")#text("-bounded multiplicative functions is also closed under multiplication and complex conjugation.")#linebreak()#text(" Given a multiplicative function ")#mi("{f}")#text(", we are often interested in the asymptotics of long averages such as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n)")]]

#text("for large values of ")#mi("{X}")#text(", as well as short sums")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)")]]

#text("where ")#mi("{H}")#text(" and ")#mi("{x}")#text(" are both large, but ")#mi("{H}")#text(" is significantly smaller than ")#mi("{x}")#text(". (Throughout these notes we will try to normalise most of the sums and integrals appearing here as averages that are trivially bounded by ")#mi("{O(1)}")#text("; note that other normalisations are preferred in some of the literature cited here.) For instance, as we established in Theorem 58 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", the prime number theorem is equivalent to the assertion that ")#metadata(none) <tao-2d2d2290b22d940a173d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\mu(n) = o(1)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(". The Liouville function behaves almost identically to the Möbius function, in that estimates for one function almost always imply analogous estimates for the other:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-ef2bee7868007cd42452>#text(" Without using the prime number theorem, show that ")#link(<tao-2d2d2290b22d940a173d>)[#text("(1)")]#text(" is also equivalent to ")#metadata(none) <tao-eaffd1cb0ed6883b0e7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\lambda(n) = o(1)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(". (Hint: use the identities ")#mi("{\\lambda(n) = \\sum_{d^2|n} \\mu(n/d^2)}")#text(" and ")#mi("{\\mu(n) = \\sum_{d^2|n} \\mu(d) \\lambda(n/d^2)}")#text(".)")
]

#text("Henceforth we shall focus our discussion more on the Liouville function, and turn our attention to averages on shorter intervals. From ")#link(<tao-eaffd1cb0ed6883b0e7b>)[#text("(2)")]#text(" one has ")#metadata(none) <tao-50e29e6c39ab7a4f8f31>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n) = o(1)")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(" if ")#mi("{H = H(x)}")#text(" is such that ")#mi("{H \\geq \\varepsilon x}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(". However it is significantly more difficult to understand what happens when ")#mi("{H}")#text(" grows much slower than this. By using the techniques based on zero density estimates discussed in ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(", it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=424726")[#text("by Motohashi")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=424723")[#text(" that one can also establish \\eqref")]#text(". On the Riemann Hypothesis ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2496499")[#text("Maier and Montgomery lowered")]#text(" the threshold to ")#mi("{H \\geq x^{1/2} \\log^C x}")#text(" for an absolute constant ")#mi("{C}")#text(" (the bound ")#mi("{H \\geq x^{1/2+\\varepsilon}}")#text(" is more classical, following from Exercise 33 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). On the other hand, the randomness heuristics from ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(" suggest that ")#mi("{H}")#text(" should be able to be taken as small as ")#mi("{x^\\varepsilon}")#text(", and perhaps even ")#mi("{\\log^{1+\\varepsilon} x}")#text(" if one is particularly optimistic about the accuracy of these probabilistic models. On the other hand, the Chowla conjecture (mentioned for instance in ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Supplement 4")]#text(") predicts that ")#mi("{H}")#text(" cannot be taken arbitrarily slowly growing in ")#mi("{x}")#text(", due to the conjectured existence of arbitrarily long strings of consecutive numbers where the Liouville function does not change sign (and in fact one can already show from the known partial results towards the Chowla conjecture that ")#link(<tao-50e29e6c39ab7a4f8f31>)[#text("(3)")]#text(" fails for some sequence ")#mi("{x \\rightarrow \\infty}")#text(" and some sufficiently slowly growing ")#mi("{H = H(x)}")#text(", by modifying the arguments in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("these papers of mine")]#text(").")#linebreak()#text(" The situation is better when one asks to understand the mean value on ")#emph[#text("almost all")]#text(" short intervals, rather than all intervals. There are several equivalent ways to formulate this question:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{H = H(X)}")#text(" be a function of ")#mi("{X}")#text(" such that ")#mi("{H \\rightarrow \\infty}")#text(" and ")#mi("{H = o(X)}")#text(" as ")#mi("{X \\rightarrow \\infty}")#text(". Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a ")#mi("{1}")#text("-bounded function. Show that the following assertions are equivalent:")

#list(
[#text("(i) One has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n) = o(1)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(", uniformly for all ")#mi("{x \\in [X,2X]}")#text(" outside of a set of measure ")#mi("{o(X)}")#text(".")],
[#text("(ii) One has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\int_X^{2X} |\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)|\\ dx = o(1)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(".")],
[#text("(iii) One has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)\\right|^2\\ dx = o(1)", block: true)]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(".")]
)
]

#text("As it turns out the second moment formulation in (iii) will be the most convenient for us to work with in this set of notes, as it is well suited to Fourier-analytic techniques (and in particular the Plancherel theorem).")#linebreak()#text(" Using zero density methods, for instance, it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=424723")[#text("by Ramachandra")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n)\\right|^2\\ dx \\ll_{A,\\varepsilon} \\log^{-A} X", block: true)]]

#text("whenever ")#mi("{X^{1/6+\\varepsilon} \\leq H \\leq X}")#text(" and ")#mi("{\\varepsilon>0}")#text(". With this quality of bound (saving arbitrary powers of ")#mi("{\\log X}")#text(" over the trivial bound of ")#mi("{O(1)}")#text("), this is still the lowest value of ")#mi("{H}")#text(" one can reach unconditionally. However, in a striking recent breakthrough, it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("by Matomaki and Radziwill")]#text(" that as long as one is willing to settle for weaker bounds (saving a small power of ")#mi("{\\log X}")#text(" or ")#mi("{\\log H}")#text(", or just a qualitative decay of ")#mi("{o(1)}")#text("), one can obtain non-trivial estimates on far shorter intervals. For instance, they show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Matomaki-Radziwill theorem for Liouville)")]#text(" ")#metadata(none) <tao-355b1bbfc96725cdce8f>#text(" For any ")#mi("{2 \\leq H \\leq X}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n)\\right|^2\\ dx \\ll \\log^{-c} H", block: true)]]

#text("for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("In fact they prove a slightly more precise result: see Theorem 1 of that paper. In particular, they obtain the asymptotic ")#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#hx2")[#text("(4)")]#text(" for ")#emph[#text("any")]#text(" function ")#mi("{H = H(X)}")#text(" that goes to infinity as ")#mi("{X \\rightarrow \\infty}")#text(", no matter how slowly! This ability to let ")#mi("{H}")#text(" grow slowly with ")#mi("{X}")#text(" is important for several applications; for instance, in order to combine this type of result with the entropy decrement methods from ")#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("Notes 9")]#text(", it is essential that ")#mi("{H}")#text(" be allowed to grow more slowly than ")#mi("{\\log X}")#text(". See also ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3666035")[#text("this survey of Soundararajan")]#text(" for further discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" In this exercise you may use Theorem ")#link(<tao-355b1bbfc96725cdce8f>)[#text("3")]#text(" freely.")

#list(
[#text("(i) Establish the upper bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\lambda(n)\\lambda(n+1) < 1-c")]]

#text("for some absolute constant ")#mi("{c>0}")#text(" and all sufficiently large ")#mi("{X}")#text(". (")#emph[#text("Hint:")]#text(" if this bound failed, then ")#mi("{\\lambda(n)=\\lambda(n+1)}")#text(" would hold for almost all ")#mi("{n}")#text("; use this to create many intervals ")#mi("{[x,x+H]}")#text(" for which ")#mi("{\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} \\lambda(n)}")#text(" is extremely large.)")],
[#text("(ii) Show that Theorem ")#link(<tao-355b1bbfc96725cdce8f>)[#text("3")]#text(" also holds with ")#mi("{\\lambda(n)}")#text(" replaced by ")#mi("{\\chi_2 \\lambda(n)}")#text(", where ")#mi("{\\chi_2}")#text(" is the principal character of period ")#mi("{2}")#text(". (Use the fact that ")#mi("{\\lambda(2n)=-\\lambda(n)}")#text(" for all ")#mi("{n}")#text(".) Use this to establish the corresponding lower bound")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\lambda(n)\\lambda(n+1) > -1+c")]]

#text("to (i).")]
)

#text("(There is a curious asymmetry to the difficulty level of these bounds; the upper bound in (ii) was established much earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=886032")[#text("by Harman, Pintz, and Wolke")]#text(", but the lower bound in (i) was only established in the Matomaki-Radziwill paper.)")
]

#text("The techniques discussed previously were highly complex-analytic in nature, relying in particular on the fact that functions such as ")#mi("{\\mu}")#text(" or ")#mi("{\\lambda}")#text(" have Dirichlet series ")#mi("{{\\mathcal D} \\mu(s) = \\frac{1}{\\zeta(s)}}")#text(", ")#mi("{{\\mathcal D} \\lambda(s) = \\frac{\\zeta(2s)}{\\zeta(s)}}")#text(" that extend meromorphically into the critical strip. In contrast, the Matomaki-Radziwill theorem does ")#emph[#text("not")]#text(" rely on such meromorphic continuations, and in fact holds for more general classes of ")#mi("{1}")#text("-bounded multiplicative functions ")#mi("{f}")#text(", for which one typically does not expect any meromorphic continuation into the strip. Instead, one can view the Matomaki-Radziwill theory as following the philosophy of a slightly different approach to multiplicative number theory, namely the ")#emph[#text("pretentious multiplicative number theory")]#text(" of Granville and Soundarajan (as presented for instance in ")#link("https://dms.umontreal.ca/~andrew/PDF/Book.To2.5.pdf")[#text("their draft monograph")]#text("). A basic notion here is the ")#emph[#text("pretentious distance")]#text(" between two ")#mi("{1}")#text("-bounded multiplicative functions ")#mi("{f,g}")#text(" (at a given scale ")#mi("{X}")#text("), which informally measures the extent to which ")#mi("{f}")#text(" “pretends” to be like ")#mi("{g}")#text(" (or vice versa). The precise definition is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Pretentious distance)")]#text(" ")#metadata(none) <tao-5702d27eb943bcff6ff5>#text(" Given two ")#mi("{1}")#text("-bounded multiplicative functions ")#mi("{f,g}")#text(", and a threshold ")#mi("{X>0}")#text(", the ")#emph[#text("pretentious distance")]#text(" ")#mi("{\\mathbb{D}(f,g;X)}")#text(" between ")#mi("{f}")#text(" and ")#mi("{g}")#text(" up to scale ")#mi("{X}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(f,g;X) := \\left( \\sum_{p \\leq X} \\frac{1 - \\mathrm{Re}(f(p) \\overline{g(p)})}{p} \\right)^{1/2}")]]
]

#text("Note that one can also define an infinite version ")#mi("{\\mathbb{D}(f,g;\\infty)}")#text(" of this distance by removing the constraint ")#mi("{p \\leq X}")#text(", though in such cases the pretentious distance may then be infinite. The pretentious distance is not quite a metric (because ")#mi("{\\mathbb{D}(f,f;X)}")#text(" can be non-zero, and furthermore ")#mi("{\\mathbb{D}(f,g;X)}")#text(" can vanish without ")#mi("{f,g}")#text(" being equal), but it is still quite close to behaving like a metric, in particular it obeys the triangle inequality; see Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("16")]#text(" below. The philosophy of pretentious multiplicative number theory is that two ")#mi("{1}")#text("-bounded multiplicative functions ")#mi("{f,g}")#text(" will exhibit similar behaviour at scale ")#mi("{X}")#text(" if their pretentious distance ")#mi("{\\mathbb{D}(f,g;X)}")#text(" is bounded, but will become uncorrelated from each other if this distance becomes large. A simple example of this philosophy is given by the following “weak Halasz theorem”, proven in Section ")#link(<tao-a0f76ba8a030700a65e9>)[#text("2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Logarithmically averaged version of Halasz)")]#text(" ")#metadata(none) <tao-bef908679d087c23e277>#text(" Let ")#mi("{X}")#text(" be sufficiently large. Then for any ")#mi("{1}")#text("-bounded multiplicative functions ")#mi("{f,g}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n) \\overline{g(n)}}{n} \\ll \\exp( - c \\mathbb{D}(f, g;X)^2 )")]]

#text("for an absolute constant ")#mi("{c>0}")#text(".")
]

#text("In particular, if ")#mi("{f}")#text(" does not pretend to be ")#mi("{1}")#text(", then the logarithmic average ")#mi("{\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n}}")#text(" will be small. This condition is basically necessary, since of course ")#mi("{\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{1}{n} = 1 + o(1)}")#text(".")#linebreak()#text(" If one works with non-logarithmic averages ")#mi("{\\frac{1}{X} \\sum_{n \\leq X} f(n)}")#text(", then not pretending to be ")#mi("{1}")#text(" is insufficient to establish decay, as was already observed in Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(": if ")#mi("{f}")#text(" is an Archimedean character ")#mi("{f(n) = n^{it}}")#text(" for some non-zero real ")#mi("{t}")#text(", then ")#mi("{\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n}}")#text(" goes to zero as ")#mi("{X \\rightarrow \\infty}")#text(" (which is consistent with Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text("), but ")#mi("{\\frac{1}{X} \\sum_{n \\leq X} f(n)}")#text(" does not go to zero. However, this is in some sense the “only” obstruction to these averages decaying to zero, as quantified by the following basic result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Halasz’s theorem)")]#text(" ")#metadata(none) <tao-9295b33c5f057cf9414c>#text(" Let ")#mi("{X}")#text(" be sufficiently large. Then for any ")#mi("{1}")#text("-bounded multiplicative function ")#mi("{f}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll \\exp( - c \\min_{\\left|t\\right| \\leq T} \\mathbb{D}(f, n \\mapsto n^{it};X)^2 ) + \\frac{1}{T}", block: true)]]

#text("for an absolute constant ")#mi("{c>0}")#text(" and any ")#mi("{T > 0}")#text(".")
]

#text("Informally, we refer to a ")#mi("{1}")#text("-bounded multiplicative function as “pretentious’; if it pretends to be a character such as ")#mi("{n^{it}}")#text(", and “non-pretentious” otherwise. The precise distinction is rather malleable, as the precise class of characters that one views as “obstructions” varies from situation to situation. For instance, in Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text(" it is just the trivial character ")#mi("{1}")#text(" which needs to be considered, but in Theorem ")#link(<tao-9295b33c5f057cf9414c>)[#text("7")]#text(" it is the characters ")#mi("{n \\mapsto n^{it}}")#text(" with ")#tao-math("{\\left|t\\right| \\leq T}", block: false)#text(". In other contexts one may also need to add Dirichlet characters ")#mi("{\\chi(n)}")#text(" or hybrid characters such as ")#mi("{\\chi(n) n^{it}}")#text(" to the list of characters that one might pretend to be. The division into pretentious and non-pretentious functions in multiplicative number theory is faintly analogous to the division into major and minor arcs in the circle method applied to additive number theory problems; see ")#link("https://terrytao.wordpress.com/2015/03/30/254a-notes-8-the-hardy-littlewood-circle-method-and-vinogradovs-theorem/")[#text("Notes 8")]#text(". The Möbius and Liouville functions are model examples of non-pretentious functions; see Exercise ")#link(<tao-aa33996d60e89311b4d1>)[#text("24")]#text(".")#linebreak()#text(" In the contrapositive, Halasz’ theorem can be formulated as the assertion that if one has a large mean")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{X} \\sum_{n \\leq X} f(n)\\right| \\geq \\eta", block: true)]]

#text("for some ")#mi("{\\eta > 0}")#text(", then one has the pretentious property")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( f, n \\mapsto n^{it}; X ) \\ll \\sqrt{\\log(1/\\eta)}")]]

#text("for some ")#mi("{t \\ll \\eta^{-1}}")#text(". This has the flavour of an “inverse theorem”, of the type often found in arithmetic combinatorics.")#linebreak()#text(" Among other things, Halasz’s theorem gives yet another proof of the prime number theorem ")#link(<tao-2d2d2290b22d940a173d>)[#text("(1)")]#text("; see Section ")#link(<tao-a0f76ba8a030700a65e9>)[#text("2")]#text(".")#linebreak()#text(" We now give a version of the Matomaki-Radziwill theorem for general (non-pretentious) multiplicative functions that is formulated in a similar contrapositive (or “inverse theorem”) fashion, though to simplify the presentation we only state a qualitative version that does not give explicit bounds.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 ((Qualitative) Matomaki-Radziwill theorem)")]#text(" ")#metadata(none) <tao-79032b8a85663acddd60>#text(" Let ")#mi("{\\eta>0}")#text(", and let ")#mi("{1 \\leq H \\leq X}")#text(", with ")#mi("{H}")#text(" sufficiently large depending on ")#mi("{\\eta}")#text(". Suppose that ")#mi("{f}")#text(" is a ")#mi("{1}")#text("-bounded multiplicative function such that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)\\right|^2\\ dx \\geq \\eta^2.", block: true)]]

#text("Then one has")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(f, n \\mapsto n^{it};X) \\ll_\\eta 1")]]

#text("for some ")#mi("{t \\ll_\\eta \\frac{X}{H}}")#text(".")
]

#text("The condition ")#mi("{t \\ll_\\eta \\frac{X}{H}}")#text(" is basically optimal, as the following example shows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{\\varepsilon>0}")#text(" be a sufficiently small constant, and let ")#mi("{1 \\leq H \\leq X}")#text(" be such that ")#mi("{\\frac{1}{\\varepsilon} \\leq H \\leq \\varepsilon X}")#text(". Let ")#mi("{f}")#text(" be the Archimedean character ")#mi("{f(n) = n^{it}}")#text(" for some ")#tao-math("{\\left|t\\right| \\leq \\varepsilon \\frac{X}{H}}", block: false)#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)\\right|^2\\ dx \\asymp 1.", block: true)]]
]

#text("Combining Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(" with standard non-pretentiousness facts about the Liouville function (see Exercise ")#link(<tao-aa33996d60e89311b4d1>)[#text("24")]#text("), we recover Theorem ")#link(<tao-355b1bbfc96725cdce8f>)[#text("3")]#text(" (but with a decay rate of only ")#mi("{o(1)}")#text(" rather than ")#mi("{\\log^{-c} H}")#text("). We refer the reader to the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3488742")[#text("original paper of Matomaki-Radziwill")]#text(" (as well as ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3435814")[#text("this followup paper with myself")]#text(") for the quantitative version of Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(" that is strong enough to recover the full version of Theorem ")#link(<tao-355b1bbfc96725cdce8f>)[#text("3")]#text(", and which can also handle real-valued pretentious functions.")#linebreak()#text(" With our current state of knowledge, the only arguments that can establish the full strength of Halasz and Matomaki-Radziwill theorems are Fourier analytic in nature, relating sums involving an arithmetic function ")#mi("{f}")#text(" with its Dirichlet series")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D} f(s) := \\sum_{n=1}^\\infty \\frac{f(n)}{n^s}")]]

#text("which one can view as a discrete Fourier transform of ")#mi("{f}")#text(" (or more precisely of the measure ")#mi("{\\sum_{n=1}^\\infty \\frac{f(n)}{n} \\delta_{\\log n}}")#text(", if one evaluates the Dirichlet series on the right edge ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(" of the critical strip). In this aspect, the techniques resemble the complex-analytic methods from Notes 2, but with the key difference that no analytic or meromorphic continuation into the strip is assumed. The key identity that allows us to pass to Dirichlet series is the following variant of Proposition 7 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Parseval type identity)")]#text(" ")#metadata(none) <tao-37b34777de2848437d83>#text(" Let ")#mi("{f,g: {\\bf N} \\rightarrow {\\bf C}}")#text(" be finitely supported arithmetic functions, and let ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a Schwartz function. Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\sum_{m=1}^\\infty \\frac{f(n)}{n} \\frac{\\overline{g(m)}}{m} \\psi(\\log n - \\log m) = \\frac{1}{2\\pi} \\int_{\\bf R} {\\mathcal D} f(1+it) \\overline{{\\mathcal D} g(1+it)} \\hat \\psi(t)\\ dt")]]

#text("where ")#mi("{\\hat \\psi(t) := \\int_{\\bf R} \\psi(u) e^{itu}\\ du}")#text(" is the Fourier transform of ")#mi("{\\psi}")#text(". (Note that the finite support of ")#mi("{f,g}")#text(" and the Schwartz nature of ")#mi("{\\psi,\\hat \\psi}")#text(" ensure that both sides of the identity are absolutely convergent.)")
]

#text("The restriction that ")#mi("{f,g}")#text(" be finitely supported will be slightly annoying in places, since most multiplicative functions will fail to be finitely supported, but this technicality can usually be overcome by suitably truncating the multiplicative function, and taking limits if necessary.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" By expanding out the Dirichlet series, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\psi(\\log n - \\log m) = \\frac{1}{2\\pi} \\int_{\\bf R} \\frac{1}{n^{it}} \\frac{1}{m^{-it}} \\hat \\psi(t)\\ dt")]]

#text("for any natural numbers ")#mi("{n,m}")#text(". But this follows from the Fourier inversion formula ")#mi("{\\psi(u) = \\frac{1}{2\\pi} \\int_{\\bf R} e^{-itu} \\hat \\psi(t)\\ dt}")#text(" applied at ")#mi("{u = \\log n - \\log m}")#text(". ")#mi("\\Box")#linebreak()#text(" For applications to Halasz type theorems, one sets ")#mi("{g(n)}")#text(" equal to the Kronecker delta ")#mi("{\\delta_{n=1}}")#text(", producing weighted integrals of ")#mi("{{\\mathcal D} f(1+it)}")#text(" of “")#mi("{L^1}")#text("” type. For applications to Matomaki-Radziwill theorems, one instead sets ")#mi("{f=g}")#text(", and more precisely uses the following corollary of the above proposition, to obtain weighted integrals of ")#tao-math("{\\left|{\\mathcal D} f(1+it)\\right|^2}", block: false)#text(" of “")#mi("{L^2}")#text("” type:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Plancherel type identity)")]#text(" ")#metadata(none) <tao-944be4b0ac4d685844cd>#text(" If ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" is finitely supported, and ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a Schwartz function, establish the identity")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\left|\\sum_{n=1}^\\infty \\frac{f(n)}{n} \\varphi(\\log n - \\log y)\\right|^2 \\frac{dy}{y} = \\frac{1}{2\\pi} \\int_{\\bf R} \\left|{\\mathcal D} f(1+it)\\right|^2 \\left|\\hat \\varphi(t)\\right|^2\\ dt.", block: true)]]
]

#text("In contrast, information about the non-pretentious nature of a multiplicative function ")#mi("{f}")#text(" will give “pointwise” or “")#mi("{L^\\infty}")#text("” type control on the Dirichlet series ")#mi("{{\\mathcal D} f(1+it)}")#text(", as is suggested from the Euler product factorisation of ")#mi("{{\\mathcal D} f}")#text(".")#linebreak()#text(" It will be convenient to formalise the notion of ")#mi("{L^1}")#text(", ")#mi("{L^2}")#text(", and ")#mi("{L^\\infty}")#text(" control of the Dirichlet series ")#mi("{{\\mathcal D} f}")#text(", which as previously mentioned can be viewed as a sort of “Fourier transform” of ")#mi("{f}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12 (Fourier norms)")]#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be finitely supported, and let ")#mi("{\\Omega \\subset {\\bf R}}")#text(" be a bounded measurable set. We define the ")#emph[#text("Fourier ")#mi("{L^\\infty}")#text(" norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{FL^\\infty(\\Omega)} := \\sup_{t \\in \\Omega} \\left|{\\mathcal D} f(1+it)\\right|,", block: true)]]

#text("the ")#emph[#text("Fourier ")#mi("{L^2}")#text(" norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{FL^2(\\Omega)} := \\left(\\int_\\Omega \\left|{\\mathcal D} f(1+it)\\right|^2\\ dt\\right)^{1/2},", block: true)]]

#text("and the ")#emph[#text("Fourier ")#mi("{L^1}")#text(" norm")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{FL^1(\\Omega)} := \\int_\\Omega |{\\mathcal D} f(1+it)|\\ dt.", block: true)]]
]

#text("One could more generally define ")#mi("{FL^p}")#text(" norms for other exponents ")#mi("{p}")#text(", but we will only need the exponents ")#mi("{p=1,2,\\infty}")#text(" in this current set of notes. It is clear that all the above norms are in fact (semi-)norms on the space of finitely supported arithmetic functions.")#linebreak()#text(" As mentioned above, Halasz’s theorem gives good control on the Fourier ")#mi("{L^\\infty}")#text(" norm for restrictions of non-pretentious functions to intervals:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Fourier ")#mi("{L^\\infty}")#text(" control via Halasz)")]#text(" ")#metadata(none) <tao-b3484e21eafaa3595438>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a ")#mi("{1}")#text("-bounded multiplicative function, let ")#mi("{I}")#text(" be an interval in ")#mi("{[C^{-1} X, CX]}")#text(" for some ")#mi("{X \\geq C \\geq 1}")#text(", let ")#mi("{R \\geq 1}")#text(", and let ")#mi("{\\Omega \\subset {\\bf R}}")#text(" be a bounded measurable set. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f 1_I \\right\\|_{FL^\\infty(\\Omega)} \\ll_C \\exp( - c \\min_{t: \\mathrm{dist}(t,\\Omega) \\leq R} \\mathbb{D}(f, n \\mapsto n^{it};X)^2 ) + \\frac{1}{R}.", block: true)]]

#text("(Hint: you will need to use summation by parts (or an equivalent device) to deal with a ")#mi("{\\frac{1}{n}}")#text(" weight.)")
]

#text("Meanwhile, the Plancherel identity in Exercise ")#link(<tao-944be4b0ac4d685844cd>)[#text("11")]#text(" gives good control on the Fourier ")#mi("{L^2}")#text(" norm for functions on long intervals (compare with Exercise 2 from ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (")#mi("{L^2}")#text(" mean value theorem)")]#text(" ")#metadata(none) <tao-227d9436da2bdfb1044a>#text(" Let ")#mi("{T \\geq 1}")#text(", and let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be finitely supported. Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{FL^2([-T,T])}^2 \\ll \\sum_n \\frac{1}{n} (\\frac{T}{n} \\sum_{m: \\left|n-m\\right| \\leq n/T} \\left|f(m)\\right|)^2.", block: true)]]

#text("Conclude in particular that if ")#mi("{f}")#text(" is supported in ")#mi("{[C^{-1} N, C N]}")#text(" for some ")#mi("{C \\geq 1}")#text(" and ")#mi("{N \\gg T}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{FL^2([-T,T])}^2 \\ll C^{O(1)} \\frac{1}{N} \\sum_n \\left|f(n)\\right|^2.", block: true)]]
]

#text("In the simplest case of the logarithmically averaged Halasz theorem (Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text("), Fourier ")#mi("{L^\\infty}")#text(" estimates are already sufficient to obtain decent control on the (weighted) Fourier ")#mi("{L^1}")#text(" type expressions that show up. However, these estimates are not enough by themselves to establish the full Halasz theorem or the Matomaki-Radziwill theorem. To get from Fourier ")#mi("{L^\\infty}")#text(" control to Fourier ")#mi("{L^1}")#text(" or ")#mi("{L^2}")#text(" control more efficiently, the key trick is use Hölder’s inequality, which when combined with the basic Dirichlet series identity")

#align(center)[#tao-fit-display[#mitex("{\\mathcal D}(f*g) = ({\\mathcal D} f) ({\\mathcal D} g)")]]

#text("gives the inequalities ")#metadata(none) <tao-ea15eb998cc7f7e7516c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| f*g \\right\\|_{FL^1(\\Omega)} \\leq \\left\\|f\\right\\|_{FL^2(\\Omega)} \\left\\|g\\right\\|_{FL^2(\\Omega)}", block: true)]]

#text("and ")#metadata(none) <tao-7f78754beaccd7f7d625>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| f*g \\right\\|_{FL^2(\\Omega)} \\leq \\left\\|f\\right\\|_{FL^2(\\Omega)} \\left\\|g\\right\\|_{FL^\\infty(\\Omega)}", block: true)]]

#text("The strategy is then to factor (or approximately factor) the original function ")#mi("{f}")#text(" as a Dirichlet convolution (or average of convolutions) of various components, each of which enjoys reasonably good Fourier ")#mi("{L^2}")#text(" or ")#mi("{L^\\infty}")#text(" estimates on various regions ")#mi("{\\Omega}")#text(", and then combine them using the Hölder inequalities ")#link(<tao-ea15eb998cc7f7e7516c>)[#text("(5)")]#text(", ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(" and the triangle inequality. For instance, to prove Halasz’s theorem, we will split ")#mi("{f}")#text(" into the Dirichlet convolution of three factors, one of which will be estimated in ")#mi("{FL^\\infty}")#text(" using the non-pretentiousness hypothesis, and the other two being estimated in ")#mi("{FL^2}")#text(" using Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(". For the Matomaki-Radziwill theorem, one uses a significantly more complicated decomposition of ")#mi("{f}")#text(" into a variety of Dirichlet convolutions of factors, and also splits up the Fourier domain ")#mi("{[-T,T]}")#text(" into several subregions depending on whether the Dirichlet series associated to some of these components are large or small. In each region and for each component of these decompositions, all but one of the factors will be estimated in ")#mi("{FL^\\infty}")#text(", and the other in ")#mi("{FL^2}")#text("; but the precise way in which this is done will vary from component to component. For instance, in some regions a key factor will be small in ")#mi("{FL^\\infty}")#text(" by construction of the region; in other places, the ")#mi("{FL^\\infty}")#text(" control will come from Exercise ")#link(<tao-b3484e21eafaa3595438>)[#text("13")]#text(". Similarly, in some regions, satisfactory ")#mi("{FL^2}")#text(" control is provided by Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(", but in other regions one must instead use “large value” theorems (in the spirit of Proposition 9 from ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text("), or amplify the power of the standard ")#mi("{L^2}")#text(" mean value theorems by combining the Dirichlet series with other Dirichlet series that are known to be large in this region.")#linebreak()#text(" There are several ways to achieve the desired factorisation. In the case of Halasz’s theorem, we can simply work with a crude version of the Euler product factorisation, dividing the primes into three categories (“small”, “medium”, and “large” primes) and expressing ")#mi("{f}")#text(" as a triple Dirichlet convolution accordingly. For the Matomaki-Radziwill theorem, one instead exploits the Turan-Kubilius phenomenon (Section 5 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", or Lemma 2 of ")#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("Notes 9")]#text(")) that for various moderately wide ranges ")#mi("{[P,Q]}")#text(" of primes, the number of prime divisors of a large number ")#mi("{n}")#text(" in the range ")#mi("{[P,Q]}")#text(" is almost always close to ")#mi("{\\log\\log Q - \\log\\log P}")#text(". Thus, if we introduce the arithmetic functions ")#metadata(none) <tao-fd3b3bd1a61d5b6b9f96>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("w_{[P,Q]}(n) = \\frac{1}{\\log\\log Q - \\log\\log P} \\sum_{P \\leq p \\leq Q} 1_{n=p}")]]

#text("then we have")

#align(center)[#tao-fit-display[#mitex("1 \\approx 1 * w_{[P,Q]}")]]

#text("and more generally we have a twisted approximation")

#align(center)[#tao-fit-display[#mitex("f \\approx f * fw_{[P,Q]}")]]

#text("for multiplicative functions ")#mi("{f}")#text(". (Actually, for technical reasons it will be convenient to work with a smoothed out version of these functions; see Section ")#link(<tao-0987cf4a2a50e74e959c>)[#text("3")]#text(".) Informally, these formulas suggest that the “")#mi("{FL^2}")#text(" energy” of a multiplicative function ")#mi("{f}")#text(" is concentrated in those regions where ")#mi("{f w_{[P,Q]}}")#text(" is extremely large in a ")#mi("{FL^\\infty}")#text(" sense. Iterations of this formula (or variants of this formula, such as an identity due to Ramaré) will then give the desired (approximate) factorisation of ")#mi("{{\\mathcal D} f}")#text(".")#linebreak()#text(" ")#metadata(none) <tao-4940a95c0984b1bd14bd>

#heading(level: 1)[#strong[#text(" — 1. Pretentious distance — ")]]

#text("In this section we explore the notion of pretentious distance. The following Hilbert space lemma will be useful for establishing the triangle inequality for this distance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15 (Triangle inequality)")]#text(" ")#metadata(none) <tao-0a3f13c673af2389ecb9>#text(" Let ")#mi("{u,v,w}")#text(" be vectors in a real Hilbert space ")#mi("{H}")#text(" with ")#tao-math("{\\left\\|u\\right\\|, \\left\\|v\\right\\|, \\left\\|w\\right\\| \\leq 1}", block: false)#text(". Then")

#align(center)[#tao-fit-display[#mitex("(1-\\langle u,w \\rangle)^{1/2} \\leq (1-\\langle u,v \\rangle)^{1/2} + (1-\\langle v,w \\rangle)^{1/2}.")]]
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{u,v,w}")#text(" are unit vectors: ")#tao-math("{\\left\\|u\\right\\|=\\left\\|v\\right\\|=\\left\\|w\\right\\|=1}", block: false)#text(". Then by the cosine rule ")#tao-math("{(1-\\langle u,v\\rangle)^{1/2} = 2^{-1/2} \\left\\|u-v\\right\\|}", block: false)#text(", and similarly for ")#mi("{(1-\\langle v,w \\rangle)^{1/2}}")#text(" and ")#mi("{(1-\\langle u,w \\rangle)^{1/2}}")#text(". The claim now follows from the usual triangle inequality ")#tao-math("{\\left\\|u-w\\right\\| \\leq \\left\\|u-v\\right\\| + \\left\\|v-w\\right\\|}", block: false)#text(".")#linebreak()#text(" Now suppose we are in the general case when ")#tao-math("{\\left\\|u\\right\\|,\\left\\|v\\right\\|,\\left\\|w\\right\\| \\leq 1}", block: false)#text(". In this case we extend ")#mi("{u,v,w}")#text(" to unit vectors by working in the product ")#mi("{H \\times {\\bf R}^3}")#text(" of ")#mi("{H}")#text(" with the Euclidean space ")#mi("{{\\bf R}^3}")#text(" and applying the previous inequality to the extended unit vectors")

#tao-aligned(keep: true)[


#tao-math("\\tilde u  & := (u, (1-\\left\\|u\\right\\|^2)^{1/2},0,0)", block: true)



#tao-math("\\tilde v  & := (v,0,(1-\\left\\|v\\right\\|^2)^{1/2},0)", block: true)



#tao-math("\\tilde w  & := (w,0,0,(1-\\left\\|w\\right\\|^2)^{1/2}),", block: true)
]

#text("observing that the extensions have the same inner products as the original vectors. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Basic properties of pretentious distance)")]#text(" ")#metadata(none) <tao-fbb7b5bf4ca348eeeebf>#text(" Let ")#mi("{f,g,h,k}")#text(" be ")#mi("{1}")#text("-bounded multiplicative functions, and let ")#mi("{X,Y \\geq 2}")#text(".")

#list(
[#text("(i) (Metric type properties) Show that ")#mi("{\\mathbb{D}(f,g;X) \\geq 0}")#text(", with equality if and only if ")#mi("{f=g}")#text(" and ")#tao-math("{\\left|f(p)\\right|=1}", block: false)#text(" for all primes ")#mi("{p}")#text(". Furthermore, show that ")#mi("{\\mathbb{D}(f,g;X) = \\mathbb{D}(g,f;X)}")#text(" and ")#mi("{\\mathbb{D}(f,h;X) \\leq \\mathbb{D}(f,g;X) + \\mathbb{D}(g,h;X)}")#text(". (Hint: for the last property, apply Lemma ")#link(<tao-0a3f13c673af2389ecb9>)[#text("15")]#text(" to a suitable Hilbert space ")#mi("{H}")#text(".)")],
[#text("(ii) (Alternate triangle inequality) Show that ")#mi("{\\mathbb{D}(fh, gk;X) \\leq \\mathbb{D}(f,g;X) + \\mathbb{D}(h,k;X)}")#text(".")],
[#text("(iii) (Bounds) One has")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\mathbb{D}(f,g;X)^2 \\leq \\log\\log X + O(1)")]]

#text("and if ")#mi("{X \\leq Y}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(f,g;X)^2 \\leq \\mathbb{D}(f,g;Y)^2 \\leq \\mathbb{D}(f,g;X)^2 + \\log\\frac{\\log Y}{\\log X} + O(1).")]]],
[#text("(iv) (Invariance) One has ")#mi("{\\mathbb{D}(\\overline{f},\\overline{g};X) = \\mathbb{D}(f,g;X)}")#text(", ")#mi("{\\mathbb{D}(fh,g;X) = \\mathbb{D}(f,g\\overline{h};X)}")#text(" and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mathbb{D}(fh,gh;X)^2 - \\mathbb{D}(f,g;X)^2\\right| \\leq \\mathbb{D}(h,h;X)^2.", block: true)]]

#text("In particular, if ")#tao-math("{\\left|h(p)\\right|=1}", block: false)#text(" for all ")#mi("{p}")#text(", then ")#mi("{\\mathbb{D}(fh,gh;X) = \\mathbb{D}(f,g;X)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" If ")#mi("{\\chi, \\chi^{\\prime}}")#text(" are Dirichlet characters of periods ")#mi("{q,q^{\\prime}}")#text(" respectively induced from the same primitive character, and ")#mi("{X \\geq 2}")#text(", show that ")#mi("{\\mathbb{D}(\\chi,\\chi^{\\prime};X) \\ll \\log\\log\\log(C+qq^{\\prime})}")#text(" for some absolute constant ")#mi("{C>0}")#text(" (the only purpose of which is to keep the triple logarithm ")#mi("{\\log\\log\\log(C+qq^{\\prime})}")#text(" positive). (")#emph[#text("Hint:")]#text(" control the contributions of the primes ")#mi("{p}")#text(" in each dyadic block ")#mi("{2^k \\leq p < 2^{k+1}}")#text(" separately for ")#mi("{\\log qq^{\\prime} \\ll 2^k \\ll qq^{\\prime}}")#text(".)")
]

#text("Next, we relate pretentious distance to the value of Dirichlet series just to the right of the critical strip. There is an annoying minor technicality that the prime ")#mi("{2}")#text(" has to be treated separately, but this will not cause too much trouble.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 18 (Dirichlet series and pretentious distance)")]#text(" ")#metadata(none) <tao-2f907a6de331cc77376c>#text(" Let ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" be a ")#mi("{1}")#text("-bounded multiplicative function, ")#mi("{X \\geq 10}")#text(", and ")#mi("{t \\in {\\bf R}}")#text(". Then ")#metadata(none) <tao-dd1b3c312cf7d8161303>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\frac{1}{\\log X} |{\\mathcal D} f(1+\\frac{1}{\\log X}+it)| \\asymp \\left|\\sum_{j=0}^\\infty \\frac{f(2^j)}{2^{(1+\\frac{1}{\\log X}+it)j}}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( - {\\mathbb D}(f,n \\mapsto n^{it};X)^2 ).")]]

#text("In particular, we always have the upper bound ")#metadata(none) <tao-85e68636f86170aeb7b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{1}{\\log X} {\\mathcal D} f(1+\\frac{1}{\\log X}+it) \\ll \\exp( - {\\mathbb D}(f,n \\mapsto n^{it};X)^2 ),")]]

#text("and if one imposes the technical condition that either ")#mi("{f(2^j) = f(2)^j}")#text(" for all ")#mi("{j}")#text(" or ")#mi("{f(2^j) = 0}")#text(" for all ")#mi("{j > 1}")#text(", then ")#metadata(none) <tao-f70b42e9a77ca5193889>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{1}{\\log X} |{\\mathcal D} f(1+\\frac{1}{\\log X}+it)| \\asymp \\exp( -{\\mathbb D}(f,n \\mapsto n^{it};X)^2 ).")]]

#text("If ")#mi("{f(p^j) = 0}")#text(" for all ")#mi("{p > X}")#text(" and ")#mi("{j \\geq 1}")#text(", then we may delete the ")#mi("{\\frac{1}{\\log X}}")#text(" terms in the above claims.")
]

#emph[#text("Proof:")]#text(" By replacing ")#mi("{f}")#text(" with ")#mi("{n \\mapsto f(n) n^{-it}}")#text(" we may assume without loss of generality that ")#mi("{t=0}")#text(". We begin with the first claim ")#link(<tao-dd1b3c312cf7d8161303>)[#text("(8)")]#text(". By expanding out the Euler product, the left-hand side of ")#link(<tao-dd1b3c312cf7d8161303>)[#text("(8)")]#text(" is equal to")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\log X} \\prod_p \\left|\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{(1+\\frac{1}{\\log X})j}}\\right|", block: true)]]

#text("and from Definition ")#link(<tao-5702d27eb943bcff6ff5>)[#text("5")]#text(" and Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("{\\mathbb D}(f,1;X)^2 = \\log\\log X - \\sum_{p \\leq X} \\frac{\\mathrm{Re} f(p)}{p} + O(1)")]]

#text("and so it will suffice on canceling the ")#mi("{p=2}")#text(" factor and taking logarithms to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p>2} \\log \\left|\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{(1+\\frac{1}{\\log X})j}}\\right| = \\sum_{p \\leq X} \\frac{\\mathrm{Re} f(p)}{p} + O(1).", block: true)]]

#text("For ")#mi("{p>2}")#text(", the quantity ")#mi("{\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{(1+\\frac{1}{\\log X})j}}}")#text(" differs from ")#mi("{1}")#text(" by at most ")#mi("{\\sum_{j=1}^\\infty \\frac{1}{p^j} \\leq \\frac{1}{2}}")#text(". Also we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{(1+\\frac{1}{\\log X})j}} = 1 + \\frac{f(p)}{p^{1+\\frac{1}{\\log X}}} + O(\\frac{1}{p^2})")]]

#text("and hence by Taylor expansion")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|\\sum_{j=0}^\\infty \\frac{f(p^j)}{p^{(1+\\frac{1}{\\log X})j}}\\right| = \\frac{\\mathrm{Re} f(p)}{p^{1+\\frac{1}{\\log X}}} + O(\\frac{1}{p^2}).", block: true)]]

#text("By the triangle inequality, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X} \\frac{1}{p} - \\frac{1}{p^{1+\\frac{1}{\\log X}}}, \\sum_{p>X} \\frac{1}{p^{1+\\frac{1}{\\log X}}} \\ll 1.")]]

#text("But the first bound follows from the mean value estimate ")#mi("{\\frac{1}{p} - \\frac{1}{p^{1+\\frac{1}{\\log X}}} \\ll \\frac{\\log p}{p \\log X}}")#text(" and Mertens’ theorems, while the second bound follows from summing the bounds")

#align(center)[#tao-fit-display[#mitex("\\sum_{X^{2^j} < p \\leq X^{2^{j+1}}} \\frac{1}{p^{1+\\frac{1}{\\log X}}} \\ll 2^{-2^j}")]]

#text("that also arise from Mertens’ theorems.")#linebreak()#text(" The quantity ")#mi("{\\sum_{j=0}^\\infty \\frac{f(2^j)}{2^{(1+\\frac{1}{\\log X}+it)j}}}")#text(" is bounded in magnitude by ")#mi("{\\sum_{j=0}^\\infty \\frac{1}{2^j} = 2}")#text(", giving ")#link(<tao-85e68636f86170aeb7b0>)[#text("(9)")]#text(". Under either of the two technical conditions listed, this quantity is equal to either ")#mi("{\\frac{1}{1-f(2)/2^{1+\\frac{1}{\\log X}}}}")#text(" or ")#mi("{1 + \\frac{f(2)}{2^{1+\\frac{1}{\\log X}}}}")#text(", and in either case it is comparable in magnitude to ")#mi("{1}")#text(", giving ")#link(<tao-f70b42e9a77ca5193889>)[#text("(10)")]#text(".")#linebreak()#text(" If ")#mi("{f(p^j)=0}")#text(" for ")#mi("{p>X}")#text(" and ")#mi("{j \\geq 1}")#text(", we may repeat the above arguments with the ")#mi("{\\frac{1}{\\log X}}")#text(" terms deleted, since we no longer need to control the tail contribution ")#mi("{\\sum_{p>X}}")#text(". ")#mi("\\Box")#linebreak()#text(" Now we explore the geometry of the Archimedean characters ")#mi("{n \\mapsto n^{it}}")#text(" with respect to pretentious distance.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19")]#text(" ")#metadata(none) <tao-f65333c6ec13688796da>#text(" If ")#mi("{X}")#text(" is sufficiently large, then")

#align(center)[#tao-fit-display[#tao-math("\\mathbb{D}(1, n \\mapsto n^{it}; X) \\asymp \\sqrt{\\log(1 + (\\min(\\left|t\\right|,1) \\log X)^2)}", block: true)]]

#text("for ")#tao-math("{\\left|t\\right| \\ll \\exp( \\log^{1.4} X ) )}", block: false)#text(". In particular one has")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(1, n \\mapsto n^{it}; X) \\asymp \\sqrt{\\log\\log X}")]]

#text("for ")#tao-math("{1 \\ll \\left|t\\right| \\ll \\exp( \\log^{1.4} X ) )}", block: false)#text(".")
]

#text("The precise exponent ")#mi("{1.4}")#text(" here is not of particular significance; any constant between ")#mi("{1}")#text(" and ")#mi("{1.5}")#text(" would work for our application to the Matomaki-Radziwill theorem, with the most important feature being that ")#mi("{\\exp(\\log^{1.4} X)}")#text(" grows significantly faster than any fixed power ")#mi("{X^C}")#text(" of ")#mi("{X}")#text(". The ability to raise the exponent beyond ")#mi("{1}")#text(" will be provided by the Vinogradov estimates for the zeta function. (For Halasz’s theorem one only needs these bounds in the easier range ")#tao-math("{\\left|t\\right| \\leq X}", block: false)#text(", which does not require the Vinogradov estimates.) As a particular corollary of this proposition and Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("16")]#text("(iii), we see that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(n \\mapsto n^{it}, n \\mapsto n^{it^{\\prime}}; X) \\asymp \\sqrt{\\log\\log X}")]]

#text("whenever ")#tao-math("{1 \\ll \\left|t-t^{\\prime}\\right| \\ll \\exp( \\log^{1.4} X )}", block: false)#text("; thus the Archimedean characters ")#mi("{n \\mapsto n^{it}}")#text(" do not pretend to be like each other at all once the ")#mi("{t}")#text(" parameter is changed by at least a unit distance (but not changed by an enormous amount).")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" By Definition ")#link(<tao-5702d27eb943bcff6ff5>)[#text("5")]#text(", our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq X} \\frac{1 - \\mathrm{Re} p^{it}}{p} \\asymp \\log(1 + (\\min(\\left|t\\right|,1) \\log X)^2).", block: true)]]

#text("We begin with the upper bound. For ")#tao-math("{\\left|t\\right| \\gg 1}", block: false)#text(", the claim follows from Mertens’ theorems and the triangle inequality. For ")#tao-math("{\\left|t\\right| \\ll \\frac{1}{\\log X}}", block: false)#text(", we bound")

#align(center)[#tao-fit-display[#tao-math("1 - \\mathrm{Re} p^{it} = 1 - \\cos(t \\log p) \\ll (t \\log p)^2 \\ll \\left|t\\right|^2 \\log X \\log p", block: true)]]

#text("and the claim again follows from Mertens’ theorems (note that ")#tao-math("{\\log(1 + \\min(\\left|t\\right|,1) \\log X) \\asymp |t| \\log X}", block: false)#text(" in this case). For ")#tao-math("{\\frac{1}{\\log X} \\ll \\left|t\\right| \\ll 1}", block: false)#text(", we bound ")#mi("{1-\\cos(t\\log p)}")#text(" by ")#mi("{O( t \\log p )}")#text(" for ")#tao-math("{\\log p \\leq \\frac{1}{\\left|t\\right|}}", block: false)#text(" and by ")#mi("{O(1)}")#text(" for ")#tao-math("{\\frac{1}{\\left|t\\right|} \\leq \\log p \\leq \\log X}", block: false)#text(", and the claim once again follows from Mertens’ theorems.")#linebreak()#text(" Now we establish the lower bound. We first work in the range ")#tao-math("{\\left|t\\right| \\leq \\frac{100}{\\log X}}", block: false)#text(". In this case we have a matching lower bound")

#align(center)[#tao-fit-display[#mitex("1 - \\mathrm{Re} p^{it} = 1 - \\cos(t \\log p) \\gg (t \\log p)^2")]]

#text("for ")#mi("{p \\leq X^c}")#text(" and some small absolute constant ")#mi("{c>0}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq X^c} \\frac{1 - \\mathrm{Re} p^{it}}{p} \\gg_c \\left|t\\right|^2 \\sum_{X^{c/2} \\leq p \\leq X^c} \\frac{\\log^2 X}{p} \\gg_c \\left|t\\right|^2 \\log^2 X", block: true)]]

#text("giving the lower bound. Now suppose that ")#tao-math("{\\frac{100}{\\log X} \\leq \\left|t\\right| \\leq 100}", block: false)#text(". Applying Lemma ")#link(<tao-2f907a6de331cc77376c>)[#text("18")]#text(" with ")#mi("{f=1}")#text(" and ")#mi("{X}")#text(" replaced by some ")#mi("{y>10}")#text(", we have ")#metadata(none) <tao-ec6aded56b9556c0fac4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{1}{\\log y} |\\zeta(1+\\frac{1}{\\log y}+it)| \\asymp \\exp( -{\\mathbb D}(1,n \\mapsto n^{it};y)^2 );")]]

#text("for ")#mi("{t \\leq 100}")#text(" and ")#tao-math("{\\log y \\gg 1/\\left|t\\right|}", block: false)#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\zeta(1+\\frac{1}{\\log y}+it)\\right| \\asymp \\frac{1}{\\left|t\\right|}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("{\\mathbb D}(1,n \\mapsto n^{it};y)^2 = \\log\\log y - \\log \\frac{1}{\\left|t\\right|} + O(1)", block: true)]]

#text("or equivalently by Mertens’ theorem")

#align(center)[#tao-fit-display[#tao-math("\\sum_{p \\leq y} \\frac{\\mathrm{Re} p^{it}}{p} = \\log \\frac{1}{\\left|t\\right|} + O(1).", block: true)]]

#text("Applying this bound with ")#mi("{y}")#text(" replaced by ")#tao-math("{\\exp(1/\\left|t\\right|)}", block: false)#text(" and by ")#mi("{X}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\exp(1/\\left|t\\right|) \\leq p \\leq X} \\frac{\\mathrm{Re} p^{it}}{p} \\ll 1", block: true)]]

#text("and hence by Mertens’ theorem and the triangle inequality (for ")#mi("{c}")#text(" small enough)")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\exp(1/\\left|t\\right|) \\leq p \\leq X} \\frac{1 - \\mathrm{Re} p^{it}}{p} \\gg \\log( \\left|t\\right|\\log X),", block: true)]]

#text("giving the claim.")#linebreak()#text(" Finally, assume that ")#tao-math("{100 \\leq \\left|t\\right| \\ll \\exp(\\log^{1.4} X)}", block: false)#text(". From Mertens’ theorems we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\exp(\\log^{0.99} X) \\leq p \\leq X} \\frac{1}{p} \\gg \\log\\log X")]]

#text("so by the triangle inequality it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\exp(\\log^{0.99} X) \\leq p \\leq X} \\frac{1}{p^{1+it}} \\ll 1.")]]

#text("Taking logarithms in ")#link(<tao-ec6aded56b9556c0fac4>)[#text("(11)")]#text(" for ")#mi("{y = X, \\exp(\\log^{0.99} X)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq X} \\frac{1}{p^{1+it}} = \\log \\zeta(1+\\frac{1}{\\log X} + it) + O(1)")]]

#text("and also")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq \\exp(\\log^{0.99} X)} \\frac{1}{p^{1+it}} = \\log \\zeta(1+\\frac{1}{\\log^{0.99} X} + it) + O(1)")]]

#text("hence by the fundamental theorem of calculus")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\exp(\\log^{0.99} X) \\leq p \\leq X} \\frac{1}{p^{1+it}} \\ll \\frac{1}{\\log^{0.99} X} \\left|\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it)\\right| + 1", block: true)]]

#text("for some ")#mi("{1+\\frac{1}{\\log X} \\leq \\sigma \\leq 1+\\frac{1}{\\log^{0.99} X}}")#text(". However, from the Vinogradov-Korobov estimates (Exercise 43 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\zeta^{\\prime}}{\\zeta}(\\sigma+it) \\ll \\log^{2/3+o(1)} \\left|t\\right|", block: true)]]

#text("whenever ")#mi("{\\sigma > 1}")#text("; since we are assuming ")#tao-math("{\\log \\left|t\\right| \\ll \\log^{1.4} X}", block: false)#text(", the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Assume the Riemann hypothesis. Establish a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{P} \\sum_{n \\leq P} \\Lambda(n) n^{-it} \\ll \\frac{1}{1+\\left|t\\right|} + P^{-c}", block: true)]]

#text("for some absolute constant ")#mi("{c>0}")#text(" whenever ")#tao-math("{P \\geq \\log^C(2+\\left|t\\right|)}", block: false)#text(" for a sufficiently large absolute constant ")#mi("{C}")#text(". (")#emph[#text("Hint:")]#text(" use Perron’s formula and shift the contour to within ")#mi("{\\frac{1}{\\log P}}")#text(" of the critical line.) Use this to conclude that the upper bound ")#tao-math("{\\left|t\\right| \\ll \\exp(\\log^{1.4} X)}", block: false)#text(" in Proposition ")#link(<tao-f65333c6ec13688796da>)[#text("19")]#text(" can be relaxed (assuming RH) to ")#tao-math("{\\left|t\\right| \\ll \\exp(\\exp(\\log^{0.9} X))}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{f}")#text(" be a ")#mi("{1}")#text("-bounded multiplicative function with ")#tao-math("{\\left|f(p)\\right|=1}", block: false)#text(" for all ")#mi("{p}")#text(". For any ")#mi("{X \\geq 2}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\lim\\inf_{t \\rightarrow \\infty} \\mathbb{D}(f, n \\mapsto n^{it}; X) = 0.")]]

#text("Thus some sort of upper bound on ")#mi("{t}")#text(" in Proposition ")#link(<tao-f65333c6ec13688796da>)[#text("19")]#text(" is necessary.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{\\chi}")#text(" be a non-principal character of modulus ")#mi("{q}")#text(", and let ")#mi("{X}")#text(" be sufficiently large depending on ")#mi("{q}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(1, n \\mapsto \\chi(n) n^{it}; X) \\asymp \\sqrt{\\log\\log X}")]]

#text("for all ")#mi("{t = O( \\exp( \\log^{1.4} X ) )}")#text(". (One will need to adapt the Vinogradov-Korobov theory to Dirichet ")#mi("{L}")#text("-functions.)")
]

#text("Proposition ")#link(<tao-f65333c6ec13688796da>)[#text("19")]#text(" measures how close the function ")#mi("{1}")#text(" lies to the Archimedean characters ")#mi("{n \\mapsto n^{it}}")#text(". Using the triangle inequality, one can then lower bound the distance of any other ")#mi("{1}")#text("-bounded multiplicative function to these characters:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23")]#text(" Let ")#mi("{X}")#text(" be sufficiently large. Then for any ")#mi("{1}")#text("-bounded multiplicative function ")#mi("{f}")#text(", there exists a real number ")#mi("{t_0}")#text(" with ")#tao-math("{\\left|t_0\\right| \\leq \\exp(\\log^{1.4} X)}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\mathbb{D}( f, n \\mapsto n^{it}; X ) \\gg \\sqrt{\\log(1 + (\\min(\\left|t-t_0\\right|,1) \\log X)^2)}", block: true)]]

#text("whenever ")#tao-math("{\\left|t\\right| \\leq \\exp(\\log^{1.4} X)}", block: false)#text(". In particular we have")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( f, n \\mapsto n^{it}; X ) \\asymp \\sqrt{\\log\\log X}")]]

#text("if ")#tao-math("{\\left|t\\right| \\leq \\exp(\\log^{1.4} X)}", block: false)#text(" and ")#tao-math("{\\left|t-t_0\\right| \\geq 1}", block: false)#text(". If ")#mi("{f}")#text(" is real-valued, one can take ")#mi("{t_0=0}")#text(".")
]

#emph[#text("Proof:")]#text(" For the first claim, choose ")#mi("{t_0}")#text(" to minimize ")#mi("{\\mathbb{D}( f, n \\mapsto n^{it_0}; X )}")#text(" among all real numbers with ")#tao-math("{\\left|t_0\\right| \\leq \\exp(\\log^{1.4} X)}", block: false)#text(". Then for any other ")#mi("{t}")#text(", we see from the triangle inequality that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( n \\mapsto n^{it}, n \\mapsto n^{it_0}; X) \\leq \\mathbb{D}( f, n \\mapsto n^{it}; X ) + \\mathbb{D}( f, n \\mapsto n^{it_0}; X ) \\leq 2 \\mathbb{D}( f, n \\mapsto n^{it}; X ).")]]

#text("But from Proposition ")#link(<tao-f65333c6ec13688796da>)[#text("19")]#text(" we have")

#tao-aligned(keep: true)[


#tao-math("\\mathbb{D}( n \\mapsto n^{it}, n \\mapsto n^{it_0}; X)  & = \\mathbb{D}( 1, n \\mapsto n^{i(t-t_0)}; X)", block: true)



#tao-math(" & \\gg \\sqrt{\\log(1 + (\\min(\\left|t-t_0\\right|,1) \\log X)^2)},", block: true)
]

#text("giving the first claim. When ")#mi("{f}")#text(" is real valued, we can similarly use the triangle inequality to bound")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( n \\mapsto n^{it}, n \\mapsto n^{-it}; X)")]]

#tao-aligned(keep: true)[


#tao-math(" & \\leq \\mathbb{D}( f, n \\mapsto n^{it}; X ) + \\mathbb{D}( f, n \\mapsto n^{-it}; X )", block: true)



#tao-math(" & = 2 \\mathbb{D}( f, n \\mapsto n^{it}; X )", block: true)
]

#text("which gives")

#align(center)[#tao-fit-display[#tao-math("\\mathbb{D}( f, n \\mapsto n^{it}; X ) \\gg \\sqrt{\\log(1 + (\\min(\\left|t\\right|,1) \\log X)^2)}", block: true)]]

#text("giving the second claim. ")#mi("\\Box")#linebreak()#text(" We can now quantify the non-pretentious nature of the Möbius and Liouville functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" ")#metadata(none) <tao-aa33996d60e89311b4d1>

#list(
[#text("(i) If ")#mi("{X}")#text(" is sufficiently large, and ")#mi("{f}")#text(" is a real-valued ")#mi("{1}")#text("-bounded multiplicative function, show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( f, n \\mapsto n^{it}; X) \\gg \\mathbb{D}(f, 1; X)")]]

#text("whenever ")#mi("{t \\ll \\exp(\\log^{1.4} X)}")#text(".")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( \\mu, n \\mapsto n^{it}; X) = \\mathbb{D}( \\lambda, n \\mapsto n^{it}; X) \\gg \\sqrt{\\log\\log X}")]]

#text("whenever ")#mi("{t \\ll \\exp(\\log^{1.4} X)}")#text(" and ")#mi("{X}")#text(" is sufficiently large.")],
[#text("(iii) If ")#mi("{\\chi}")#text(" is a Dirichlet character of some period ")#mi("{q}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}( \\mu, n \\mapsto n^{it}; X) = \\mathbb{D}( \\lambda, n \\mapsto n^{it}; X) \\gg \\sqrt{\\log\\log X}")]]

#text("whenever ")#mi("{t \\ll \\exp(\\log^{1.4} X)}")#text(" and ")#mi("{X}")#text(" is sufficiently large depending on ")#mi("{q}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 2. Halasz’s inequality — ")]]

#metadata(none) <tao-a0f76ba8a030700a65e9>#linebreak()#text(" We now prove Halasz’s inequality. As a warm up, we prove Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text(":")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Proof of Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text(") By Exercise ")#link(<tao-fbb7b5bf4ca348eeeebf>)[#text("16")]#text("(iv) we may normalise ")#mi("{g=1}")#text(". We may assume that ")#mi("{f(p^j)=0}")#text(" when ")#mi("{p>X}")#text(", since the value of ")#mi("{f}")#text(" on these primes has no impact on the sum ")#mi("{\\sum_{n \\leq X} \\frac{f(n)}{n}}")#text(" or on ")#mi("{\\mathbb{D}(f,1;X)}")#text(". In particular, from Euler products we now have the absolute convergence ")#tao-math("{\\sum_{n=1}^\\infty \\frac{\\left|f(n)\\right|}{n} < \\infty}", block: false)#text(". Let ")#mi("{0 < \\varepsilon < 1}")#text(" be a small quantity to be optimized later, and ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be smooth compactly supported function on ")#mi("{[-1,1]}")#text(" that equals one on ")#mi("{[-1+\\varepsilon,1+\\varepsilon]}")#text(" with the derivative bounds ")#mi("{\\psi^{(j)}(u) \\ll_j \\varepsilon^{-j}}")#text(", on ")#mi("{[-1,1] \\backslash [-1+\\varepsilon,1+\\varepsilon]}")#text(", so on integration by parts we see that the Fourier transform ")#mi("{\\hat \\psi(t) = \\int_{\\bf R} \\psi(u) e^{itu}}")#text(" obeys the bounds")

#align(center)[#tao-fit-display[#tao-math("\\hat \\psi(t) \\ll_j \\min( 1, \\frac{1}{\\left|t\\right|}, \\frac{1}{\\varepsilon^{j-1} \\left|t\\right|^j} )", block: true)]]

#text("for any ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{j \\geq 2}")#text(". From the triangle inequality have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} = \\frac{1}{\\log X} \\sum_{n=1}^\\infty \\frac{f(n)}{n} \\psi(\\frac{\\log n}{\\log X}) + O( \\varepsilon ).")]]

#text("Applying Proposition ")#link(<tao-37b34777de2848437d83>)[#text("10")]#text(" applied to a finite truncation of ")#mi("{f}")#text(", and then using the absolute convergence of ")#tao-math("{\\sum_{n=1}^\\infty \\frac{\\left|f(n)\\right|}{n}}", block: false)#text(" and dominated convergence to eliminate the truncation (or by using Proposition 7 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" and then shifting the contour), we can write the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} {\\mathcal D} f(1+it) \\hat \\psi( t \\log X )\\ dt + O(\\varepsilon)")]]

#text("which after rescaling by ")#mi("{\\log X}")#text(" gives ")#metadata(none) <tao-cbbb2b64949871442de2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll_j \\int_{\\bf R} \\frac{1}{\\log X} |{\\mathcal D} f(1+\\frac{it}{\\log X})| \\min( 1, \\frac{1}{\\left|t\\right|}, \\frac{1}{\\varepsilon^{j-1} \\left|t\\right|^j} )\\ dt + \\varepsilon.", block: true)]]

#text("Now from Lemma ")#link(<tao-2f907a6de331cc77376c>)[#text("18")]#text(" one has ")#metadata(none) <tao-04695fa805d662a7ca81>

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{\\log X} {\\mathcal D} f(1+\\frac{it}{\\log X})  & \\ll \\exp( \\mathbb{D}( f, n \\mapsto n^{-it/\\log X}; X)^2 )", block: true, numbering: n => [#text("(13)")])



#tao-math(" & \\ll \\exp( -\\frac{M}{2} + O(\\log(1 + (\\min(\\left|t/\\log X\\right|,1) \\log X)^2)) )", block: true)



#tao-math(" & \\leq e^{-M/2} (1 + \\left|t\\right|)^{O(1)},", block: true)
]

#text("where ")#mi("{M := \\mathbb{D}(f,1;X)^2}")#text(", and thus we can bound ")#link(<tao-cbbb2b64949871442de2>)[#text("(12)")]#text(" by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll_j e^{-M/2} \\int_{\\bf R} (1+\\left|t\\right|)^{O(1)} \\min( 1, \\frac{1}{\\left|t\\right|}, \\frac{1}{\\varepsilon^{j-1} \\left|t\\right|^j} ) + \\varepsilon", block: true)



#tao-math(" & \\ll e^{-M/2} \\varepsilon^{-O(1)} + \\varepsilon", block: true)
]

#text("if ")#mi("{j}")#text(" is chosen to be a sufficiently large absolute constant. The claim then follows by optimising in ")#mi("{\\varepsilon}")#text(". ")#mi("\\Box")#linebreak()#text(" We remark that an elementary proof of Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text(" with ")#mi("{c=1/2}")#text(" was given in Proposition 1.2.6 of ")#link("https://dms.umontreal.ca/~andrew/PDF/Book.To2.5.pdf")[#text("this monograph of Granville and Soundararajan")]#text(". Also, in ")#link("https://arxiv.org/abs/1701.01042")[#text("this paper of Lanzouri and Mangerel")]#text(" the variant estimate")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll \\exp( - \\sup_{\\left|t\\right| \\leq T} \\mathbb{D}(f, n \\mapsto n^{it};X)^2 ) + \\frac{1}{T \\log X}", block: true)]]

#text("is proven for any ")#mi("{0 < T \\leq 1}")#text(". (Thanks to Andrew Granville for these references.)")#linebreak()#text(" It was observed ")#link("http://arxiv.org/abs/1205.0413")[#text("by Granville, Koukoulopoulos, and Matomaki")]#text(" that we can also sharpen Proposition ")#link(<tao-bef908679d087c23e277>)[#text("6")]#text(" when ")#mi("{f}")#text(" is non-negative by purely elementary methods:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 25")]#text(" Let ")#mi("{X \\geq 10}")#text(", and suppose that ")#mi("{f: {\\bf N} \\rightarrow [0,1]}")#text(" is multiplicative, ")#mi("{1}")#text("-bounded, and non-negative. Then")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\asymp \\exp( -{\\mathbb D}(f,1;X)^2 ).")]]
]

#emph[#text("Proof:")]#text(" From Definition ")#link(<tao-5702d27eb943bcff6ff5>)[#text("5")]#text(" and Mertens’ theorems the estimate is equivalent to")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{f(n)}{n} \\asymp \\exp( \\sum_{p \\leq X} \\frac{f(p)}{p} ).")]]

#text("For the upper bound, we may assume that ")#mi("{f(p^j)}")#text(" vanishes for ")#mi("{p>X}")#text(" since these primes make no contribution to either side. We can then bound")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n \\leq X} \\frac{f(n)}{n}  & \\leq \\sum_{n=1}^\\infty \\frac{f(n)}{n}", block: true)



#tao-math(" & = \\prod_{p \\leq X} \\sum_{j=0}^\\infty \\frac{f(p^j)}{p^j}", block: true)



#tao-math(" & = \\prod_{p \\leq X} \\exp( \\frac{f(p)}{p} + O(\\frac{1}{p^2}) )", block: true)



#tao-math(" & \\ll \\exp( \\sum_{p \\leq X} \\frac{f(p)}{p} ).", block: true)
]

#text("For the lower bound, we let ")#mi("{g(n)}")#text(" be the ")#mi("{1}")#text("-bounded multiplicative function with ")#mi("{g(p) := 1-f(p)}")#text(" and ")#mi("{g(p^j) = 1}")#text(" for ")#mi("{j > 1}")#text(" and all primes ")#mi("{p}")#text(". Then we observe the pointwise bound ")#mi("{f*g(n) \\geq 1}")#text(" for all ")#mi("{n}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{f(n)}{n} \\sum_{n \\leq X} \\frac{g(n)}{n} \\geq \\sum_{n \\leq X} \\frac{1}{n} \\gg \\log X.")]]

#text("By the upper bound just obtained and Mertens’ theorems, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\frac{g(n)}{n} \\ll \\exp( \\sum_{p \\leq X} \\frac{g(p)}{p} ) \\ll \\log X \\exp( -\\sum_{p \\leq X} \\frac{f(p)}{p} )")]]

#text("and the claim follows. ")#mi("\\Box")#linebreak()#text(" Now we can prove Theorem ")#link(<tao-9295b33c5f057cf9414c>)[#text("7")]#text(".")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" (Proof of Theorem ")#link(<tao-9295b33c5f057cf9414c>)[#text("7")]#text(") We may assume that ")#mi("{T \\geq 10}")#text(", since the claim is trivial otherwise. On the other hand, for ")#mi("{T > \\log^C X}")#text(" for a sufficiently large ")#mi("{C}")#text(", the second term on the right-hand side is dominated by the first, so the estimate does not become any stronger as one increases ")#mi("{T}")#text(" beyond ")#mi("{\\log^C X}")#text(", and hence we may assume without loss of generality that ")#mi("{T \\leq \\log^{O(1)} X}")#text(".")#linebreak()#text(" We abbreviate ")#tao-math("{M := \\min_{\\left|t\\right| \\leq T} \\mathbb{D}(f, n \\mapsto n^{it};X)^2}", block: false)#text(", thus we wish to show that ")#metadata(none) <tao-360f84035942243c6a36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll \\exp( - c M ) + \\frac{1}{T}.")]]

#text("It is convenient to remove some exceptional values of ")#mi("{n}")#text(". Let ")#mi("{0 < \\varepsilon < \\frac{1}{10}}")#text(" be a small quantity to be chosen later, subject to the restriction ")#metadata(none) <tao-8c31359b027e77d1a884>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("X^{\\varepsilon^3} \\geq T^{10}.")]]

#text("From standard sieves (e.g., Theorem 32 from ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("Notes 4")]#text("), we see that the proportion of numbers in ")#mi("{[X/2,X]}")#text(" that do not have a “large” prime factor in ")#mi("{[X^\\varepsilon,X]}")#text(", or do not have a “medium” prime factor in ")#mi("{[X^{\\varepsilon^2},X^\\varepsilon)}")#text(", is ")#mi("{O(\\varepsilon)}")#text(". Thus by paying an error of ")#mi("{\\varepsilon}")#text(", we may restrict to numbers that have at least one “large” prime factor in ")#mi("{[X^\\varepsilon,X]}")#text(" and at least one “medium” prime factor in ")#mi("{[X^{\\varepsilon^2},X^\\varepsilon)}")#text(" (and no prime factor larger than ")#mi("{X}")#text("). This is the same as replacing ")#mi("{f}")#text(" with the Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("\\tilde f := f_1 * f_2 * f_3")]]

#text("where ")#mi("{f_1}")#text(" is the restriction of ")#mi("{f}")#text(" to numbers with all prime factors in the “small” range ")#mi("{[1,X^{\\varepsilon^2})}")#text(", ")#mi("{f_2}")#text(" is the restriction of ")#mi("{f}")#text(" to numbers in ")#mi("{[2,X]}")#text(" with all prime factors in the “medium” range ")#mi("{[X^{\\varepsilon^2},X^\\varepsilon)}")#text(", and ")#mi("{f_3}")#text(" is the restriction of ")#mi("{f}")#text(" to numbers in ")#mi("{[2,X]}")#text(" with all prime factors in the “large” range ")#mi("{[X^\\varepsilon,X]}")#text(". We can thus write")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n) = \\frac{1}{X} \\sum_{n \\leq X} \\tilde f(n) + O(\\varepsilon).")]]

#text("This we can write in turn as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\tilde f(n)}{n} \\psi(\\log n - \\log X) + O(\\varepsilon)")]]

#text("where ")#mi("{\\psi(u) := 1_{[-\\infty, 0]} e^u}")#text(". It is not advantageous to immediately apply Proposition ")#link(<tao-37b34777de2848437d83>)[#text("10")]#text(" due to the rough nature of ")#mi("{\\psi}")#text(" (which is not even Schwartz). But if we let ")#mi("{\\varphi}")#text(" be a Schwartz function of total mass ")#mi("{1}")#text(" whose Fourier transform is supported on ")#mi("{[-1,1]}")#text(", and define the mollified function")

#align(center)[#tao-fit-display[#mitex("\\tilde \\psi(u) := \\int_{\\bf R} \\psi(u - \\frac{v}{T}) \\varphi(v)\\ dv")]]

#text("then one easily checks that")

#align(center)[#tao-fit-display[#tao-math("\\psi(u) - \\tilde \\psi(u) \\ll (1 + T \\left|u\\right|)^{-10}", block: true)]]

#text("which from the triangle inequality soon gives the bounds")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{\\tilde f(n)}{n} (\\psi-\\tilde \\psi)(\\log n - \\log X) \\ll \\frac{1}{T}.")]]

#text("Hence we may write")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{X/2 \\leq n \\leq X} f(n) = \\sum_{n=1}^\\infty \\frac{\\tilde f(n)}{n} \\tilde \\psi(\\log n - \\log X) + O(\\varepsilon) + O(\\frac{1}{T}).")]]

#text("Now we apply Proposition ")#link(<tao-37b34777de2848437d83>)[#text("10")]#text(" and the triangle inequality to bound this by")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left|{\\mathcal D} \\tilde f(1 + it)\\right| \\left|\\hat{\\tilde \\psi}(t)\\right|\\ dt + \\varepsilon + \\frac{1}{T}.", block: true)]]

#text("But we may factor")

#align(center)[#tao-fit-display[#mitex("\\hat{\\tilde \\psi}(t) = \\hat \\psi(t) \\varphi(t/T)")]]

#text("and we may rather crudely bound ")#mi("{\\hat \\psi(t) = O(1)}")#text(", hence we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll \\left\\| \\tilde f \\right\\|_{FL^1([-T,T])} + \\varepsilon + \\frac{1}{T}.", block: true)]]

#text("Using the Hölder inequalities ")#link(<tao-ea15eb998cc7f7e7516c>)[#text("(5)")]#text(", ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde f \\right\\|_{FL^1([-T,T])} \\leq \\left\\| f_1 \\right\\|_{FL^\\infty([-T,T])} \\left\\| f_2 \\right\\|_{FL^2([-T,T])} \\left\\| f_3 \\right\\|_{FL^2([-T,T])}.", block: true)]]

#text("From Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_2 \\right\\|_{FL^2([-T,T])}^2 \\ll \\sum_n \\frac{1}{n} (\\frac{T}{n} \\sum_{m: \\left|n-m\\right| \\leq n/T} \\left|f_2(m)\\right|)^2.", block: true)]]

#text("Note that ")#mi("{f_2}")#text(" is supported on ")#mi("{[X^{\\varepsilon^2}, X]}")#text(" and hence ")#mi("{n}")#text(" is effectively also restricted to the range ")#mi("{X^{\\varepsilon^2} \\ll n \\ll X}")#text(". From standard sieves (using ")#link(<tao-8c31359b027e77d1a884>)[#text("(15)")]#text("), we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{T}{n} \\sum_{m: \\left|n-m\\right| \\leq n/T} \\left|f_2(m)\\right| \\ll \\frac{\\varepsilon^{-O(1)}}{\\log X}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_2 \\right\\|_{FL^2([-T,T])}^2 \\ll \\frac{\\varepsilon^{-O(1)}}{\\log X}.", block: true)]]

#text("Similarly")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_3 \\right\\|_{FL^2([-T,T])}^2 \\ll \\frac{\\varepsilon^{-O(1)}}{\\log X}.", block: true)]]

#text("Finally, from Lemma ")#link(<tao-2f907a6de331cc77376c>)[#text("18")]#text(" one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\| f_1 \\right\\|_{FL^\\infty([-T,T])}  & \\ll \\log X^{\\varepsilon^2} \\exp( - \\inf_{\\left|t\\right| \\leq T} \\mathbb{D}( f, n \\mapsto n^{-it}; X^{\\varepsilon^2})^2 )", block: true)



#tao-math(" & \\ll \\log X \\exp( - \\inf_{\\left|t\\right| \\leq T} \\mathbb{D}( f, n \\mapsto n^{-it}; X)^2)", block: true)



#tao-math(" & = e^{-M} \\log X.", block: true)
]

#text("Putting all this together, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n) = \\varepsilon^{-O(1)} e^{-M} + \\varepsilon + \\frac{1}{T}.")]]

#text("Setting ")#mi("{\\varepsilon := e^{-cM}}")#text(" for some sufficiently small constant ")#mi("{c>0}")#text(" (which in particular will ensure ")#link(<tao-8c31359b027e77d1a884>)[#text("(15)")]#text(" since ")#mi("{M \\ll \\log\\log X + O(1)}")#text("), we obtain the claim. ")#mi("\\Box")#linebreak()#text(" One can optimise this argument to make the constant ")#mi("{c}")#text(" in Theorem ")#link(<tao-9295b33c5f057cf9414c>)[#text("7")]#text(" arbitrarily close to ")#mi("{1/2}")#text("; see ")#link("https://terrytao.wordpress.com/2015/11/23/a-cheap-version-of-halaszs-inequality/")[#text("this previous post")]#text(". With an even more refined argument, one can prove the sharper estimate")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll (1+M) e^{-M} + \\frac{1}{T}")]]

#text("with ")#tao-math("{M := \\min_{\\left|t\\right| \\leq T} \\mathbb{D}(f, n \\mapsto n^{it};X)^2 )}", block: false)#text(", a result initially due ")#link("http://www.ams.org/mathscinet-getitem?mr=1342300")[#text("to Montgomery and Tenenbaum")]#text("; see Theorem 2.3.1 of ")#link("https://dms.umontreal.ca/~andrew/PDF/Book.To2.5.pdf")[#text("this text of Granville and Soundararajan")]#text(". In the case of non-negative ")#mi("{f}")#text(", an elementary argument gives the stronger bound ")#mi("{\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll \\exp( - \\mathbb{D}(f;1,X)^2)}")#text("; see Corollary 1.2.3 of ")#link("https://dms.umontreal.ca/~andrew/PDF/Book.To2.5.pdf")[#text(". However, the slightly weaker estimates in Theorem \\ref")]#metadata(none) <tao-7f314df9ac6502dbcfbe>#text(" Let ")#mi("{X}")#text(" be sufficiently large. Then for any real-valued ")#mi("{1}")#text("-bounded multiplicative function ")#mi("{f}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{X} \\sum_{n \\leq X} f(n) \\ll \\exp( - c \\mathbb{D}(f, 1;X)^2 ).")]]

#text("for an absolute constant ")#mi("{c>0}")#text(".")#linebreak()#text(" Thus for instance, setting ")#mi("{f = \\mu}")#text(", we can use Wirsing’s theorem and Exercise ")#link(<tao-aa33996d60e89311b4d1>)[#text("24")]#text(" (or Mertens’ theorem) to recover a form of the prime number theorem with a modestly decaying error term, in that ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\frac{1}{X} \\sum_{n \\leq X} \\mu(n) \\ll \\log^{-c} X")]]

#text("for all large ")#mi("{X}")#text(" and some absolute constant ")#mi("{c>0}")#text(". (Admittedly, we did use the far stronger Vinogradov-Korobov estimates earlier in this set of notes; but a careful inspection reveals that those estimates were not used in the proof of ")#link(<tao-a160524700113ddd3205>)[#text("(16)")]#text(", so this is a non-circular proof of the prime number theorem.)")

#heading(level: 1)[#strong[#text(" — 3. The Matomaki-Radziwill theorem — ")]]

#metadata(none) <tao-0987cf4a2a50e74e959c>#linebreak()#text(" We now give the proof of the Matomaki-Radziwill theorem, though we will leave several of the details to exercises. We first make a small but convenient reduction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Show that to prove Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(", it suffices to do so for functions ")#mi("{f}")#text(" that are completely multiplicative. (This is similar to Exercise ")#link(<tao-ef2bee7868007cd42452>)[#text("1")]#text(".)")
]

#text("Now we use Exercise ")#link(<tao-944be4b0ac4d685844cd>)[#text("11")]#text(" to phrase the theorem in an equivalent Fourier form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Matomaki-Radziwill theorem, Fourier form)")]#text(" ")#metadata(none) <tao-37a5e5794487c8e42e69>#text(" Let ")#mi("{\\eta>0}")#text(", and let ")#mi("{1 \\leq T \\leq X}")#text(", with ")#mi("{X/T}")#text(" sufficiently large depending on ")#mi("{\\eta}")#text(". Let ")#mi("{\\psi:{\\bf R} \\rightarrow {\\bf R}}")#text(" be a fixed smooth compactly supported function, and set ")#mi("{\\psi_X(n) := \\psi(\\log n - \\log X)}")#text(". Suppose that ")#mi("{f}")#text(" is a ")#mi("{1}")#text("-bounded completely multiplicative function such that ")#metadata(none) <tao-32a1b4c6b835baea6a0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| f \\psi_X \\right\\|_{FL^2([-T,T])} \\gg \\eta.", block: true)]]

#text("Then one has")

#align(center)[#tao-fit-display[#mitex("\\mathbb{D}(f, n \\mapsto n^{it};X) \\ll_\\eta 1")]]

#text("for some ")#mi("{t \\ll_\\eta T}")#text(".")
]

#text("Let us assume Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" for the moment and see how it implies Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(". In the latter theorem we may assume without loss of generality that ")#mi("{\\eta}")#text(" is small. We may assume that ")#mi("{H \\leq \\eta^2 X}")#text(", since the case ")#mi("{\\eta^2 X \\leq H \\leq X}")#text(" follows easily from Theorem \\reF{halasz}.")#linebreak()#text(" Let ")#mi("{\\psi}")#text(" be a smooth compactly supported function with ")#mi("{\\psi(u) = e^u}")#text(" on ")#mi("{[-10,10]}")#text(". By hypothesis, we have ")#metadata(none) <tao-06efe37f5e983469e860>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{X}{H} \\sum_{x \\leq n \\leq x+H} \\frac{f \\psi_X(n)}{n}\\right|^2\\ dx \\gg \\eta^2.", block: true)]]

#text("Let ")#mi("{\\varphi}")#text(" be a Schwartz function of mean ")#mi("{1}")#text(" whose Fourier transform is supported on ")#mi("{[-1,1]}")#text(". For any ")#mi("{x\\in [X,2X]}")#text(", we consider the expression ")#metadata(none) <tao-07397d633f25a7101990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\frac{X}{H} \\int_x^{x+H} \\frac{X}{\\eta^2 H} \\sum_n \\frac{f\\psi_X(n)}{n} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\ \\frac{dy}{y}.")]]

#text("A routine calculation using the rapid decrease of ")#mi("{\\varphi}")#text(" shows that")

#tao-aligned(keep: true)[


#tao-math("\\frac{X}{\\eta^2 H} \\int_x^{x+H} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\ \\frac{dy}{y}  & = 1_{[x,x+H]}(n)", block: true)



#tao-math(" & + (1 + \\frac{\\left|\\log n - \\log x\\right|}{\\eta^2 H/X})^{-10} + (1 + \\frac{\\left|\\log n - \\log(x+H)\\right|}{\\eta^2 H/X})^{-10}", block: true)
]

#text("and thus the expression ")#link(<tao-07397d633f25a7101990>)[#text("(19)")]#text(" can be estimated as")

#align(center)[#tao-fit-display[#mitex("\\frac{X}{H} \\sum_{x \\leq n \\leq x+H} \\frac{f\\psi_X(n)}{n} + O(\\eta^2).")]]

#text("By Cauchy-Schwarz we then have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{X}{H} \\sum_{x \\leq n \\leq x+H} \\frac{f\\psi_X(n)}{n}\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{X}{H} \\int_x^{x+H} \\left|\\frac{X}{\\eta^2 H} \\sum_n \\frac{f\\psi_X(n)}{n} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\right|^2\\ \\frac{dy}{y} + \\eta^4.", block: true)]]

#text("Averaging this for ")#mi("{x \\in [X,2X]}")#text(" and using Fubini’s theorem, we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{X}{H} \\sum_{x \\leq n \\leq x+H} \\frac{f\\psi_X(n)}{n}\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\int_0^\\infty \\left|\\frac{X}{\\eta^2 H} \\sum_n \\frac{f\\psi_X(n)}{n} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\right|^2\\ \\frac{dy}{y} + \\eta^4", block: true)]]

#text("and thus from ")#link(<tao-06efe37f5e983469e860>)[#text("(18)")]#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\left|\\frac{X}{\\eta^2 H} \\sum_n \\frac{f\\psi_X(n)}{n} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\right|^2\\ \\frac{dy}{y} \\gg \\eta^2.", block: true)]]

#text("On the other hand, from Exercise ")#link(<tao-944be4b0ac4d685844cd>)[#text("11")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\left|\\frac{X}{\\eta^2 H} \\sum_n \\frac{f\\psi_X(n)}{n} \\varphi( \\frac{X}{\\eta^2 H} (\\log n - \\log y) )\\right|^2\\ \\frac{dy}{y} \\ll \\left\\| f \\psi_X \\right\\|_{FL^2([-T,T])}^2.", block: true)]]

#text("Applying Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" (with a slightly smaller value of ")#mi("{H}")#text(" and ")#mi("{\\eta}")#text("), we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" In the converse direction, show that Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" is a consequence of Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" Let ")#mi("{f}")#text(" be supported on ")#mi("{[X,3X]}")#text(", and let ")#mi("{1 \\leq H \\leq X}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\frac{1}{H/X} \\int_{H/X}^{3H/X} \\int_0^\\infty \\left|\\frac{X}{H} \\sum_{x \\leq n \\leq (1+\\theta)x} \\frac{f(n)}{n}\\right|^2\\ \\frac{dx}{x} d\\theta.", block: true)]]

#text("(Hint: use summation by parts to express ")#mi("{\\sum_{x \\leq n \\leq x+H} f(n)}")#text(" as a suitable linear combination of sums ")#mi("{\\sum_{x \\leq n \\leq (1+\\theta)x} \\frac{f(n)}{n}}")#text(" and ")#mi("{\\sum_{(x+H) \\leq n \\leq (1+\\theta)(x+H)} \\frac{f(n)}{n}}")#text(", then use the Cauchy-Schwarz inequality and the Fubini-Tonelli theorem.) Conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\int_X^{2X} \\left|\\frac{1}{H} \\sum_{x \\leq n \\leq x+H} f(n)\\right|^2\\ dx", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll \\int_{\\bf R} \\left|{\\mathcal D} f(1+it)\\right|^2 (1 + \\frac{\\left|t\\right|}{T})^{-2}\\ dt", block: true)]]

#text("where ")#mi("{T := X/H}")#text(". (This argument is due to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=480388")[#text("Saffari and Vaughan")]#text(".)")
]

#text("It remains to establish Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(". As before we may assume that ")#mi("{\\eta}")#text(" is small. Let us call a finitely supported arithmetic function ")#mi("{g}")#text(" ")#emph[#text("large")]#text(" on some subset ")#mi("{\\Omega}")#text(" of ")#mi("{[-X,X]}")#text(" if")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{FL^2(\\Omega)} \\gg \\eta,", block: true)]]

#text("and ")#emph[#text("small")]#text(" on ")#mi("{\\Omega}")#text(" if")

#align(center)[#tao-fit-display[#tao-math("\\left\\| g \\right\\|_{FL^2(\\Omega)} \\ll \\eta^2.", block: true)]]

#text("Note that a function cannot be simultaneously large and small on the same set ")#mi("{\\Omega}")#text("; and if a function is large on some subset ")#mi("{\\Omega}")#text(", then it remains large on ")#mi("{\\Omega}")#text(" after modifying by any small error (assuming ")#mi("{\\eta}")#text(" is small enough, and adjusting the implied constants appropriately). From the hypothesis ")#link(<tao-32a1b4c6b835baea6a0c>)[#text("(17)")]#text(" we know that ")#mi("{f \\psi_X}")#text(" is large on ")#mi("{[-T,T]}")#text(". As discussed in the introduction, the strategy is now to decompose ")#mi("{[-T,T]}")#text(" into various regions, and on each of these regions split ")#mi("{f \\psi_X}")#text(" (up to small errors) as an average of Dirichlet convolutions of other factors which enjoy either good ")#mi("{FL^\\infty}")#text(" estimates or good ")#mi("{FL^2}")#text(" estimates on the given region.")#linebreak()#text(" We will need the following ranges:")

#list(
[#text("(i) ")#mi("{[P_0,Q_0]}")#text(" is the interval")

#align(center)[#tao-fit-display[#mitex("[P_0,Q_0] := [\\exp( \\log^{0.9} X ), \\exp( \\log^{0.95} X )].")]]],
[#text("(ii) ")#mi("{[P_1,Q_1]}")#text(" is the interval")

#align(center)[#tao-fit-display[#mitex("[P_1,Q_1] := [\\exp( (\\log\\log X)^2 ), \\exp( (\\log\\log X)^3 )].")]]],
[#text("(iii) ")#mi("{[P_2,Q_2]}")#text(" is the interval")

#align(center)[#tao-fit-display[#mitex("[P_2,Q_2] := [\\exp( (\\log\\log\\log X)^2 ), \\exp( (\\log\\log\\log X)^3 )].")]]]
)

#text("We will be able to cover the range ")#mi("{T \\leq X/Q_0}")#text(" just using arguments involving the zeroth interval ")#mi("{[P_0,Q_0]}")#text("; the range ")#mi("{T \\leq X/Q_1}")#text(" can be covered using arguments involving the zeroth interval ")#mi("{[P_0,Q_0]}")#text(" and the first interval ")#mi("{[P_1,Q_1]}")#text("; and the range ")#mi("{T \\leq X/Q_2}")#text(" can be covered using arguments involving all three intervals ")#mi("{[P_0,Q_0], [P_1,Q_1], [P_2,Q_2]}")#text(". Coverage of the remaining ranges of ")#mi("{T}")#text(" can be done by an extension of the methods given here and will be left to the exercises at the end of the notes.")#linebreak()#text(" We introduce some weight functions and some exceptional sets. For any ")#mi("{P > 10}")#text(", let ")#mi("{\\phi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a bump function on ")#mi("{[-1,1]}")#text(" of total mass ")#mi("{1}")#text(", and let ")#mi("{w_P}")#text(" denote the arithmetic function")

#align(center)[#tao-fit-display[#mitex("w_P(n) := \\frac{\\log P}{P \\eta^4} \\sum_{p} \\phi( \\frac{\\log p - \\log P}{\\eta^4} ) 1_{n=p}")]]

#text("supported on the primes ")#mi("{p = (1+O(\\eta^4)) P}")#text(". We then define the following subsets of ")#mi("{[-X,X]}")#text(":")

#list(
[#text("(i) ")#mi("{\\Omega_0}")#text(" is the set of those ")#mi("{t \\in [-X,X]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal D}(fw_P)(1+it)\\right| \\geq \\frac{1}{\\log^{10} X}", block: true)]]

#text("for some dyadic ")#mi("{P \\in [P_0,Q_0]}")#text(" (i.e., ")#mi("{P}")#text(" is restricted to be a power of ")#mi("{2}")#text(").")],
[#text("(ii) ")#mi("{\\Omega_1}")#text(" is the set of those ")#mi("{t \\in [-X,X]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal D}(fw_P)(1+it)\\right| \\geq P^{-1/20}", block: true)]]

#text("for some dyadic ")#mi("{P \\in [P_1,Q_1]}")#text(".")],
[#text("(iii) ")#mi("{\\Omega_2}")#text(" is the set of those ")#mi("{t \\in [-X,X]}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal D}(fw_P)(1+it)\\right| \\geq P^{-1/30}", block: true)]]

#text("for some dyadic ")#mi("{P \\in [P_2,Q_2]}")#text(".")]
)

#text("We will establish the following claims:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 30")]#text(" ")#metadata(none) <tao-a61808fe40feb8b34337>

#list(
[#text("(i) If ")#mi("{T \\leq X/Q_i}")#text(" for some ")#mi("{i=0,1,2}")#text(", then ")#mi("{f \\psi_X}")#text(" is small on ")#mi("{[-T,T] \\backslash \\Omega_i}")#text(".")],
[#text("(ii) ")#mi("{f \\psi_X}")#text(" is small on ")#mi("{\\Omega_1 \\backslash \\Omega_0}")#text(".")],
[#text("(iii) ")#mi("{f \\psi_X}")#text(" is small on ")#mi("{\\Omega_2 \\backslash \\Omega_1}")#text(".")],
[#text("(iv) If ")#mi("{f \\psi_X}")#text(" is large on ")#mi("{[-T,T] \\cap \\Omega_0}")#text(", then one has ")#mi("{\\mathbb{D}(f, n \\mapsto n^{it};X) \\ll_\\eta 1}")#text(" for some ")#mi("{t \\ll_\\eta T}")#text(".")]
)
]

#text("Note that parts (i) (with ")#mi("{i=0}")#text(") and (iv) of the claims are already enough to treat the case ")#mi("{T \\leq X/Q_0}")#text("; parts (i) (with ")#mi("{i=1}")#text("), (ii), and (iv) are enough to treat the case ")#mi("{T \\leq X/Q_1}")#text("; and parts (i) (with ")#mi("{i=2}")#text("), (ii), (iii), and (iv) are enough to treat the case ")#mi("{T \\leq X/Q_2}")#text(".")#linebreak()#text(" We first prove (i). For ")#mi("{i=0,1,2}")#text(", let ")#mi("{\\tilde w_{[P_i,Q_i]}}")#text(" denote the function ")#metadata(none) <tao-31a32f3c159676fcd70c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\tilde w_{[P_i,Q_i]} := \\frac{1}{\\log \\frac{\\log Q_i}{\\log P_i}} \\sum_{P \\in [P_i,Q_i]} \\frac{1}{\\log P} w_P.")]]

#text("This function is a variant of the function ")#mi("{w_{[P_i,Q_i]}}")#text(" introduced in ")#link(<tao-fd3b3bd1a61d5b6b9f96>)[#text("(7)")]#text(". A key point is that the convolutions ")#mi("{1 * w_{[P_i,Q_i]}}")#text(" stay close to ")#mi("{1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31 (Turan-Kubilius inequalities)")]#text(" ")#metadata(none) <tao-e556ee5e40bedf24954a>#text(" For ")#mi("{i=0,1,2}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{X} \\sum_{X/2 \\leq n \\leq 4X} \\left|1*\\tilde w_{[P_i,Q_i]}(n) - 1\\right|^2 \\ll \\eta^4.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" use the second moment method, as in the proof of Lemma 2 of ")#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("Notes 9")]#text(".)")
]

#text("Let ")#mi("{i=0,1,2}")#text(". Inserting the bounded factor ")#tao-math("{\\left|f \\psi_X(n)\\right|^2}", block: false)#text(" in the above estimates, and applying Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(", we conclude in particular that the expression")

#align(center)[#tao-fit-display[#mitex("f \\psi_X (1 * \\tilde w_{[P_i,Q_i]}) - f \\psi_X")]]

#text("is small on ")#mi("{[-X,X]}")#text(". Since ")#mi("{f}")#text(" is completely multiplicative, we can write this expression as")

#align(center)[#tao-fit-display[#mitex("(f * (f\\tilde w_{[P_i,Q_i]})) \\psi_X - f \\psi_X")]]

#text("We now perform some technical manipulations to move the cutoff ")#mi("{\\psi_X}")#text(" to a more convenient location. From ")#link(<tao-31a32f3c159676fcd70c>)[#text("(20)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("(f * (f \\tilde w_{[P_i,Q_i]})) \\psi_X = \\frac{1}{\\log\\frac{\\log Q_i}{\\log P_i}} \\sum_{P \\in [P_i,Q_i]} \\frac{1}{\\log P} (f * (f w_{P})) \\psi_X.")]]

#text("We would like to approximate ")#mi("{(f*(f w_{P})) \\psi_X}")#text(" by ")#mi("{(f \\psi_{X/P}) * (fw_{P})}")#text(". A brief triangle inequality calculation using the smoothness of ")#mi("{\\psi}")#text(", the ")#mi("{1}")#text("-boundedness of ")#mi("{f}")#text(", and the narrow support of ")#mi("{w_{P^{\\prime}}}")#text(" shows that")

#align(center)[#tao-fit-display[#mitex("(f * (f w_{P})) \\psi_X = (f \\psi_{X/P}) * (fw_{P}) + O( \\eta^4 (1 * w_{P}) \\tilde \\psi_X )")]]

#text("where ")#mi("{\\tilde \\psi_X}")#text(" is defined similarly to ")#mi("{\\psi_X}")#text(" but with a slightly larger choice of initial cutoff ")#mi("{\\tilde \\psi}")#text(". Integrating this we conclude that")

#align(center)[#tao-fit-display[#mitex("(f * (f \\tilde w_{[P_i,Q_i]})) \\psi_X")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\frac{1}{\\log\\frac{\\log Q_i}{\\log P_i}} \\sum_{P \\in [P_i,Q_i]} \\frac{1}{\\log P} ((f\\psi_{X/P}) * (f w_{P}))", block: true)



#tao-math(" & + O( \\eta^4 (1 * \\tilde w_{[P_i,Q_i]}) \\tilde \\psi_X ).", block: true)
]

#text("Using Exercise ")#link(<tao-e556ee5e40bedf24954a>)[#text("31")]#text(" and Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(", the error term is small on ")#mi("{[-X,X]}")#text(". Thus we conclude that ")#metadata(none) <tao-fcf1e63d0a7ce3991ff8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\frac{1}{\\log\\frac{\\log Q_i}{\\log P_i}} \\sum_{P \\in [P_i,Q_i]} \\frac{1}{\\log P_i} ((f\\psi_{X/P}) * (f w_{P})) - f \\psi_X")]]

#text("is small on ")#mi("{[-X,X]}")#text(", and hence also on ")#mi("{[-T,T] \\backslash \\Omega_i}")#text(". Thus by the triangle inequality, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("(f\\psi_{X/P}) * (f w_{P})")]]

#text("is small on ")#mi("{[-T,T] \\backslash \\Omega_i}")#text(" for each ")#mi("{P \\in [P_i,Q_i]}")#text(". But by construction we definitely have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|fw_P \\right\\|_{FL^\\infty([-T,T] \\backslash \\Omega_i)} \\ll \\eta^4", block: true)]]

#text("while from Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(" and the hypothesis ")#mi("{T \\leq X/Q_i \\leq X/P}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f \\psi_{X/P} \\right\\|_{FL^2([-T,T] \\backslash \\Omega_i)} \\ll 1", block: true)]]

#text("and the claim (i) now follows from ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(".")#linebreak()#text(" We now jump to (iv). The first observation is that the set ")#mi("{\\Omega_0}")#text(" is quite small. To quantify this we use the following bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 32 (Large values of ")#mi("{{\\mathcal D} w_P(1+it)}")#text(")")]#text(" ")#metadata(none) <tao-626cf6d4f7ea4f20b105>#text(" Let ")#mi("{X}")#text(" be sufficiently large depending on ")#mi("{\\eta}")#text(", and let ")#mi("{2 \\leq P \\leq X^{1/2}}")#text(". Then for any ")#mi("{\\sigma > 0}")#text(", the set")

#align(center)[#tao-fit-display[#tao-math("\\Omega := \\{ t \\in [-X,X]: \\left|{\\mathcal D} w_P(1+it)\\right| \\geq \\sigma \\}", block: true)]]

#text("has measure at most ")#mi("{\\exp( (\\frac{\\log X}{\\log P} +1) (1 + \\log \\frac{\\log X}{\\sigma \\log P} ) )}")#text(".")
]

#emph[#text("Proof:")]#text(" We use the high moment method. Let ")#mi("{k}")#text(" be a natural number to be optimised in later, and let ")#mi("{w_P^{*k}}")#text(" be the convolution of ")#mi("{k}")#text(" copies of ")#mi("{w_P}")#text(". Then on ")#mi("{\\Omega}")#text(" we have ")#tao-math("{\\left|{\\mathcal D} w_P^{*k}(1+it)\\right| \\geq \\sigma^k}", block: false)#text(". Thus by Markov’s inequality, the measure of ")#mi("{\\Omega}")#text(" is at most")

#align(center)[#tao-fit-display[#tao-math("\\sigma^{-2k} \\left\\| w_P^{*k} \\right\\|_{FL^2([-X,X])}^2.", block: true)]]

#text("To bound this we use Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(". If we choose ")#mi("{k}")#text(" to be the first integer for which ")#mi("{P^k \\geq X}")#text(", then this exercise gives us the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| w_P^{*k} \\right\\|_{FL^2([-X,X])}^2 \\ll O_\\eta(1)^{O(k)} \\frac{1}{P^k} \\sum_n w_P^{*k}(n)^2.", block: true)]]

#text("From the fundamental theorem of arithmetic we see that ")#mi("{w_P^{*k}(n) \\ll k^k}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("\\sum_n w_P^{*k}(n)^2 \\ll k^k \\sum_n w_P^{*k}(n) = k^k (\\sum_n w_P(n))^k.")]]

#text("From the prime number theorem we have ")#mi("{\\sum_n w_P(n) \\ll_\\eta P}")#text(". Putting all this together, we conclude that the measure of ")#mi("{\\Omega}")#text(" is at most")

#align(center)[#tao-fit-display[#mitex("O_\\eta( \\frac{k}{\\sigma^2} )^{k}.")]]

#text("Since ")#mi("{k \\leq \\frac{\\log X}{\\log P} + 1}")#text(", we obtain the claim. ")#mi("\\Box")#linebreak()#text(" Applying this proposition with ")#mi("{P}")#text(" ranging between ")#mi("{P_0}")#text(" and ")#mi("{Q_0}")#text(" and ")#mi("{\\sigma = \\frac{1}{\\log^{10} X}}")#text(", and applying the union bound, the we see that the measure of ")#mi("{\\Omega_0}")#text(" is at most ")#mi("{\\exp(\\log^{0.2} X)}")#text(". To exploit this, we will need some bounds of Vinogradov-Korobov type:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Vinogradov bounds)")]#text(" ")#metadata(none) <tao-8a2539e2b69d9daf9d58>#text(" For ")#mi("{P \\geq 10}")#text(", establish the bound")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal D} w_P( 1+it )  & \\ll_{\\eta,\\varepsilon} \\frac{1}{(1+\\left|t\\right|)^2}", block: true)



#tao-math(" & + \\log^{O(1)}(2+\\left|t\\right|) \\exp( - \\frac{\\log P}{\\log^{2/3+\\varepsilon}(2+\\left|t\\right|)} )", block: true)
]

#text("for any ")#mi("{t \\in {\\bf R}}")#text(" and ")#mi("{\\varepsilon>0}")#text(". (")#emph[#text("Hint:")]#text(" replace ")#mi("{w_P}")#text(" with a weighted version of the von Mangoldt function, apply Proposition 7 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", and shift the contour, using the zero free region from Exercise 43 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(".)")
]

#text("Now we can establish we use the following variant of the Montgomery-Halasz large values theorem (cf. Proposition 9 from ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 34 (Montgomery-Halasz for primes)")]#text(" ")#metadata(none) <tao-327abdc665a0f5f4609d>#text(" Let ")#mi("{X \\geq 10}")#text(", let ")#mi("{P \\in [P_0,Q_0]}")#text(", and ")#mi("{\\Omega \\subset [-X,X]}")#text(" have measure ")#mi("{O(\\exp(\\log^{0.2} X))}")#text(". Then for any ")#mi("{1}")#text("-bounded function ")#mi("{f}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f w_P \\right\\|_{FL^2(\\Omega)} \\ll_{\\eta} 1.", block: true)]]
]

#emph[#text("Proof:")]#text(" By duality, we may write")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f w_P \\right\\|_{FL^2(\\Omega)} = \\int_\\Omega {\\mathcal D} fw_P(1+it) G(t)\\ dt", block: true)]]

#text("for some measurable function ")#mi("{G}")#text(" with ")#tao-math("{\\int_\\Omega \\left|G(t)\\right|^2\\ dt = 1}", block: false)#text(". We can rearrange the right-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\frac{w_P(p)}{p} f(p) \\int_\\Omega G(t) p^{-it}\\ dt")]]

#text("which by Cauchy-Schwarz is boudned in magnitude by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\sum_p \\frac{w_P(p)}{p} \\left|\\int_\\Omega G(t) p^{-it}\\ dt\\right|^2.", block: true)]]

#text("We can rearrange this as")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\int_\\Omega G(t) \\overline{G(t^{\\prime})} {\\mathcal D} w_P(1 + i(t-t^{\\prime}))\\ dt dt^{\\prime},")]]

#text("which by the elementary inequality ")#tao-math("{G(t) \\overline{G(t^{\\prime})} \\ll \\left|G(t)\\right|^2 + \\left|G(t^{\\prime})\\right|^2}", block: false)#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sup_{t^{\\prime} \\in \\Omega} \\int_\\Omega |{\\mathcal D} w_P(1 + i(t-t^{\\prime}))|\\ dt")]]

#text("(cf. Lemma 6 from ")#link("https://terrytao.wordpress.com/2019/11/12/254a-notes-9-second-moment-and-entropy-methods/")[#text("Notes 9")]#text("). By Exercise ")#link(<tao-8a2539e2b69d9daf9d58>)[#text("33")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal D} w_P( 1+i(t-t^{\\prime}) ) \\ll_{\\eta,\\varepsilon} \\frac{1}{(1+\\left|t\\right|)^2} + \\exp( - \\log^{0.2} X ).", block: true)]]

#text("The claim follows. ")#mi("\\Box")#linebreak()#text(" Now we can prove (iv). By hypothesis, ")#mi("{f \\chi_X}")#text(" is large on ")#mi("{[-T,T] \\cap \\Omega_0}")#text(". On the other hand, the function ")#link(<tao-fcf1e63d0a7ce3991ff8>)[#text("(21)")]#text(" (with ")#mi("{i=0}")#text(") is small on ")#mi("{[-T,T] \\cap \\Omega_0}")#text(". By the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log\\frac{\\log Q_0}{\\log P_0}} \\sum_{P \\in [P_0,Q_0]} \\frac{1}{\\log P_0} ((f\\psi_{X/P}) * (f w_{P}))")]]

#text("is large on ")#mi("{[-T,T] \\cap \\Omega_0}")#text(", hence by the pigeonhole principle, there exists ")#mi("{P \\in [P_0,Q_0]}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("(f\\psi_{X/P}) * (f w_{P})")]]

#text("is large on ")#mi("{[-T,T] \\cap \\Omega_0}")#text(". On the other hand, from Proposition ")#link(<tao-626cf6d4f7ea4f20b105>)[#text("32")]#text(" and Prosition ")#link(<tao-327abdc665a0f5f4609d>)[#text("34")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f w_P \\right\\|_{FL^2([-T,T] \\cap \\Omega_0)} \\ll_{\\eta} 1,", block: true)]]

#text("hence by ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\psi_{X/P} \\right\\|_{FL^\\infty([-T,T] \\cap \\Omega_0)} \\gg_\\eta 1.", block: true)]]

#text("By the pigeonhole principle, this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f 1_I \\right\\|_{FL^\\infty([-T,T] \\cap \\Omega_0)} \\gg_\\eta 1.", block: true)]]

#text("for some interval ")#mi("{I \\subset [X/10P, 10X/P]}")#text(". The claim (iv) now follows from Exercise ")#link(<tao-b3484e21eafaa3595438>)[#text("13")]#text(". Note that this already concludes the argument in the range ")#mi("{T \\geq X/Q_0}")#text(".")#linebreak()#text(" Now we establish (ii). Here the set ")#mi("{\\Omega_1}")#text(" is not as well controlled in size as ")#mi("{\\Omega_0}")#text(", but is still quite small. Indeed, from applying Proposition ")#link(<tao-626cf6d4f7ea4f20b105>)[#text("32")]#text(" with ")#mi("{P}")#text(" ranging between ")#mi("{P_1}")#text(" and ")#mi("{Q_1}")#text(" and ")#mi("{\\sigma = P^{-1/20}}")#text(", and applying the union bound, the we see that the measure of ")#mi("{\\Omega_1}")#text(" is at most ")#mi("{X^{0.1}}")#text(". This is too large of a bound to apply Proposition ")#link(<tao-327abdc665a0f5f4609d>)[#text("34")]#text(", but we may instead apply a different bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Montgomery-Halasz for integers)")]#text(" ")#metadata(none) <tao-072a2b22d19c16622fd1>#text(" Let ")#mi("{X \\geq 10}")#text(", and let ")#mi("{\\Omega \\subset [-X,X]}")#text(" have measure ")#mi("{O(X^{0.1})}")#text(". For any ")#mi("{1}")#text("-bounded function ")#mi("{f}")#text(" supported on ")#mi("{[X^{0.8},2X]}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{FL^2(\\Omega)} \\ll \\log X.", block: true)]]

#text("(It is possible to remove the logarithmic loss here by being careful, but this loss will be acceptable for our arguments. One can either repeat the arguments used to prove Proposition ")#link(<tao-327abdc665a0f5f4609d>)[#text("34")]#text(", or else appeal to Proposition 9 from ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("Notes 6")]#text(".)")
]

#text("The point here is that we can get good bounds even when the function ")#mi("{f}")#text(" is supported at narrower scales (such as ")#mi("{X^{0.8}}")#text(") than the Fourier interval under consideration (such as ")#mi("{[-X,X]}")#text(" or ")#mi("{[-T,T]}")#text("). In particular, this exercise will serve as a replacement for Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(", which will not give good estimates in this case.")#linebreak()#text(" As before, the function ")#link(<tao-fcf1e63d0a7ce3991ff8>)[#text("(21)")]#text(" is small on ")#mi("{\\Omega_1 \\backslash \\Omega_0}")#text(", so it will suffice by the triangle inequality to show that")

#align(center)[#tao-fit-display[#mitex("(f\\psi_{X/P}) * (f w_{P})")]]

#text("is small on ")#mi("{\\Omega_1 \\backslash \\Omega_0}")#text(" for all ")#mi("{P \\in [P_0,Q_0]}")#text(". From Exercise ")#link(<tao-072a2b22d19c16622fd1>)[#text("35")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_1 \\backslash \\Omega_0)} \\ll \\log X", block: true)]]

#text("while from definition of ")#mi("{\\Omega_0}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f w_P \\right\\|_{FL^\\infty(\\Omega_1 \\backslash \\Omega_0)} \\leq \\log^{-10} X", block: true)]]

#text("and the claim now follows from ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(". Note that this already concludes the argument in the range ")#mi("{T \\leq X/Q_1}")#text(".")#linebreak()#text(" Finally, we establish (iii). The function ")#link(<tao-fcf1e63d0a7ce3991ff8>)[#text("(21)")]#text(" (with ")#mi("{i=1}")#text(") is small on ")#mi("{\\Omega_2 \\backslash \\Omega_1}")#text(", so by the triangle inequality as before it suffices to show that")

#align(center)[#tao-fit-display[#mitex("(f\\psi_{X/P}) * (f w_{P})")]]

#text("is small on ")#mi("{\\Omega_2 \\backslash \\Omega_1}")#text(" for all ")#mi("{P \\in [P_1,Q_1]}")#text(". On the one hand, the definition of ")#mi("{\\Omega_1}")#text(" gives a good ")#mi("{FL^\\infty}")#text(" bound on ")#mi("{f w_P}")#text(": ")#metadata(none) <tao-e9520208411015b4cfc5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\| fw_P \\right\\|_{FL^\\infty(\\Omega_2 \\backslash \\Omega_1)} \\ll P^{-1/20}.", block: true)]]

#text("To conclude using ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(" we now need a good bound for ")#tao-math("{\\left\\|f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_2 \\backslash \\Omega_1)}}", block: false)#text(". Unfortunately, the function ")#mi("{f \\psi_{X/P}}")#text(" is now supported on too short of an interval for Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(" to give good estimates, and ")#mi("{\\Omega_2}")#text(" is too large for Exercise ")#link(<tao-072a2b22d19c16622fd1>)[#text("35")]#text(" to be applicable either.")#linebreak()#text(" But from definition we see that for ")#mi("{t \\in \\Omega_2}")#text(", we have ")#metadata(none) <tao-8d1a978e876ce55710d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("{\\mathcal D}(f w_{P^{\\prime}})(1+it)| \\geq (P^{\\prime})^{-1/30}")]]

#text("for at least one ")#mi("{P^{\\prime} \\in [P_2,Q_2]}")#text(". We can use this to amplify the power of Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 36 (Amplified ")#mi("{L^2}")#text(" mean value estimate)")]#text(" ")#metadata(none) <tao-44c1ca33495ec83d707f>#text(" One has ")#tao-math("{\\left\\| f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_2)} \\ll P^{1/25}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{P^{\\prime} \\in [P_2,Q_2]}")#text(", let ")#mi("{\\Omega_{2,P^{\\prime}}}")#text(" denote the set of ")#mi("{t \\in [-X,X]}")#text(" where ")#link(<tao-8d1a978e876ce55710d5>)[#text("(23)")]#text(" holds. Since there are ")#mi("{O((\\log\\log\\log X)^3)}")#text(" values of ")#mi("{P^{\\prime}}")#text(", and ")#mi("{P \\geq P_1 = \\exp((\\log\\log X)^2)}")#text(", it suffices by the union bound to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_{2,P^{\\prime}})} \\ll P^{1/26}", block: true)]]

#text("(say) for each ")#mi("{P^{\\prime}}")#text(". Let ")#mi("{k}")#text(" be the first integer for which the quantity ")#mi("{(P^{\\prime})^k \\geq P}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("k \\leq \\frac{\\log P}{\\log P^{\\prime}} + 1.")]]

#text("From ")#link(<tao-8d1a978e876ce55710d5>)[#text("(23)")]#text(" we have the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\mathcal D}( f \\psi_{X/P})(1+it)\\right| \\leq (P^{\\prime})^{k/30} \\left|{\\mathcal D}( (f \\psi_{X/P}) * (f w_{P^{\\prime}})^{*k} )(1+it)\\right|", block: true)]]

#text("and hence by Exercise ")#link(<tao-227d9436da2bdfb1044a>)[#text("14")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_{2,P^{\\prime}})}^2 \\ll \\eta^{-O(k)} (P^{\\prime})^{2k/30} \\frac{1}{Y} \\sum_{n} \\left|(f \\psi_{X/P}) * (f w_{P^{\\prime}})^{*k}(n)\\right|^2", block: true)]]

#text("where ")#mi("{Y := (P^{\\prime})^k X/P \\geq X}")#text(". As ")#mi("{f}")#text(" is ")#mi("{1}")#text("-bounded, and the summand only vanishes when ")#mi("{n = \\exp(O(k)) Y}")#text(", we can bound the right-hand side by")

#align(center)[#tao-fit-display[#tao-math("\\ll (\\eta^{-O(1)} (P^{\\prime})^{2/30} \\log P^{\\prime})^k \\frac{1}{Y} \\sum_{n = \\exp(O(k)) Y} \\left|1 * 1_A^{*k}(n)\\right|^2", block: true)]]

#text("where ")#mi("{A}")#text(" denotes the set of primes in the interval ")#mi("{[P^{\\prime}/2, 2P^{\\prime}]}")#text(".")#linebreak()#text(" Suppose ")#mi("{n}")#text(" has ")#mi("{l}")#text(" prime factors in this interval (counting multiplicity). Then ")#mi("{1 * 1_A^{*k}(n)}")#text(" vanishes unless ")#mi("{l \\geq k}")#text(", in which case we can bound")

#align(center)[#tao-fit-display[#mitex("1 * 1_A^{*k}(n) \\ll l^k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("1 * 1_A^{*l}(n) \\geq 1.")]]

#text("Thus we may bound the above sum by")

#align(center)[#tao-fit-display[#mitex("\\ll (\\eta^{-O(1)} (P^{\\prime})^{2/30} \\log P^{\\prime})^k \\frac{1}{Y} \\sum_{l \\geq k} l^k \\sum_{n = \\exp(O(k)) Y} 1 * 1_A^{*l}(n).")]]

#text("By the prime number theorem, ")#mi("{A}")#text(" has ")#mi("{O(P^{\\prime}/\\log P^{\\prime})}")#text(" elements, so by double counting we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n = \\exp(O(k)) Y} 1 * 1_A^{*l}(n) \\ll O(P^{\\prime}/\\log P^{\\prime})^l \\exp(O(k)) Y / (P^{\\prime})^l")]]

#text("and thus the previous bound becomes")

#align(center)[#tao-fit-display[#mitex("\\ll (\\eta^{-O(1)} (P^{\\prime})^{2/30})^k \\sum_{l \\geq k} l^k O(\\frac{1}{\\log P^{\\prime}})^{l-k}")]]

#text("which sums to")

#align(center)[#tao-fit-display[#mitex("\\ll (k \\eta^{-O(1)} (P^{\\prime})^{2/30})^k.")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("(P^{\\prime})^k \\leq P P^{\\prime}")]]

#text("we thus have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| f \\psi_{X/P} \\right\\|_{FL^2(\\Omega_{2,P^{\\prime}})}  & \\ll (PP^{\\prime})^{1/30} \\exp( O( k \\log( k/\\eta ) ) );", block: true)



#tao-math("k  & \\ll \\frac{\\log P}{\\log P_2} \\ll (\\log\\log\\log X)^{-2} \\log P \\ll (\\log\\log X)^3", block: true)
]

#text("so that ")#mi("{\\log(k/\\eta) \\ll \\log\\log\\log X}")#text(", we obtain the claim. ")#mi("\\Box")#linebreak()#text(" Combining this proposition with ")#link(<tao-e9520208411015b4cfc5>)[#text("(22)")]#text(" and ")#link(<tao-7f78754beaccd7f7d625>)[#text("(6)")]#text(", we conclude part (iii) of Proposition ")#link(<tao-a61808fe40feb8b34337>)[#text("30")]#text(". This establishes Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" up to the range ")#mi("{X \\leq T/Q_2}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Show that for any fixed ")#mi("{k \\geq 2}")#text(", Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" holds in the range")

#align(center)[#tao-fit-display[#mitex("T \\leq X \\exp( - (\\log_{k} X)^2 )")]]

#text("where ")#mi("{\\log_k X = \\log \\dots \\log X}")#text(" denotes the ")#mi("{k}")#text("-fold iterated logarithm of ")#mi("{X}")#text(". (")#emph[#text("Hint:")]#text(" this is already accomplished for ")#mi("{k=3}")#text(". For higher ")#mi("{k}")#text(", one has to introduce additional exceptional intervals ")#mi("{\\Omega_3,\\dots,\\Omega_{k-1}}")#text(" and extend Proposition ")#link(<tao-a61808fe40feb8b34337>)[#text("30")]#text(" appropriately.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Establish Theorem ")#link(<tao-37a5e5794487c8e42e69>)[#text("27")]#text(" (and hence Theorem ")#link(<tao-79032b8a85663acddd60>)[#text("8")]#text(") in full generality. (This is the preceding exercise, but now with ")#mi("{k}")#text(" potentially as large as ")#mi("{O(\\log_* X)}")#text(", where the inverse tower exponential function ")#mi("{\\log_* X}")#text(" is defined as the least ")#mi("{k}")#text(" for which ")#mi("{\\log_k X \\leq 2}")#text(". Now one has to start tracking dependence on ")#mi("{k}")#text(" of all the arguments in the above analysis; in particular, the convenient notation of arithmetic functions being “large” or “small” needs to be replaced with something more precise.)")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-532962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("What is the current best value for the constant ")#mi("c")#text(" in proposition 6 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-532964")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("For non-negative functions, the Granville-Koukoulopoulos-Matomaki result given as in Proposition 25 in this blog lets one take ")#mi("c=1")#text(", so it is reasonable to conjecture at least that one can take ")#mi("c=1")#text(" in general (which would be broadly consistent with the situation with the non-logarithmically averaged Halasz conjecture, though in that case there is a lower order factor of ")#mi("M")#text(" that is necessarily lost). But I don’t know of a place where this appears in the literature. Perhaps one just has to refine the methods that are already present in this post to get the sharp constant.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-533029")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2019")])]

#text("Actually, after doing some calculations it seems that the optimal constant ")#mi("c")#text(" should be strictly less than 1 if ")#mi("f")#text(" is not real. Basically, if one has")

#mi("\\displaystyle \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll \\exp( - c {\\mathbb D}( f, 1; X )^2 )")

#text("for all ")#mi("X")#text(", then by summation by parts we should also have")

#tao-math("\\displaystyle \\frac{1}{\\log X} \\sum_n \\frac{f(n)}{n^{1+(1+it)/\\log X}} \\ll (1+\\left|t\\right|) \\exp( - c {\\mathbb D}( f, 1; X )^2 )", block: false)

#text("which after taking logarithms (using Lemma 18, and assuming one of the technical conditions of that lemma) becomes")

#tao-math("\\displaystyle -\\sum_{p \\leq X} \\mathrm{Re} \\frac{1 - f(p) p^{it/\\log X}}{p} \\leq \\log(1+\\left|t\\right|) - c \\sum_{p \\leq X} \\mathrm{Re} \\frac{1 - f(p)}{p}  + O(1).", block: false)

#text("If we assume ")#mi("f(p)=1")#text(" for ")#mi("p \\leq X^{1/t}")#text(", this becomes")

#tao-math("\\displaystyle -\\sum_{X^{1/t} \\leq p \\leq X} \\mathrm{Re} \\frac{f(p) (c-p^{it/\\log X})}{p} \\leq (2-c) \\log(1+\\left|t\\right|) + O(1)", block: false)#text(".")

#text("If one chooses ")#mi("f(p)")#text(" to be a unit complex number canceling the phase of ")#mi("c-p^{it/\\log X}")#text(", then this implies (after using Mertens’ theorems) that")

#mi("\\displaystyle\\frac{1}{2\\pi} \\int_0^{2\\pi} |c - e^{i\\theta}|\\ d\\theta \\leq 2-c")

#text("which is not true for ")#mi("c=1")#text(" (the LHS is ")#mi("\\frac{4}{\\pi}")#text(" and the RHS is ")#mi("1")#text(") so forces ")#mi("c")#text(" to be strictly less than 1 (I have not calculated the precise upper bound on ")#mi("c")#text(" this constraint forces). This may even provide the optimal value of ")#mi("c")#text(", but I have not carefully checked this. However for ")#mi("f")#text(" real this argument does not seem to prevent ")#mi("c=1")#text(", which is of course consistent with the Granville-Koukoulopolous-Matomaki result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-533133")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2019")])]

#text("After doing further calculations and also talking with Andrew Granville it does seem that the optimal exponent for complex-valued ")#mi("f")#text(" is indeed the unique real number ")#mi("c_0 = 0.8221693\\dots")#text(" solving the equation")

#mi("\\displaystyle c_0 + \\int_0^1 |c_0 - e^{2\\pi i \\theta}|\\ d\\theta = 2")

#text("(note the LHS is strictly increasing in ")#mi("c_0")#text(") and more precisely I can show the inequality")

#mi("\\displaystyle \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll_\\varepsilon \\exp( -(c_0-\\varepsilon) {\\mathbb D}(f,1;X)^2 ) + \\frac{1}{\\log^{1/3-\\varepsilon} X}")

#text("for any ")#mi("\\varepsilon > 0")#text(". The secondary error ")#mi("\\frac{1}{\\log^{1/3-\\varepsilon} X}")#text(" is due to the reliance on Vinogradov-Korobov type estimates and I think it can be deleted if one assumes RH. Thanks to Andrew for calculating ")#mi("c_0")#text(" and also pointing out that the ")#mi("c=1/2")#text(" case of the bound was established by elementary means in his book with Sound. The argument sketched in the previous comment shows that ")#mi("c_0")#text(" is optimal, though it is still possible that the epsilon loss could be removed or replaced with some explicit lower order term.")

#text("Sketch of proof: by smoothing out the sum on the LHS (as in the lecture notes, with ")#mi("\\varepsilon")#text(" replaced by ")#mi("\\frac{1}{\\log^{1/3-\\varepsilon} X}")#text(") the left-hand side can be bounded up to acceptable errors by")

#tao-math("\\displaystyle \\int_{\\left|t\\right| \\leq \\log^{1/3-\\varepsilon} X} \\frac{1}{\\log X} |{\\mathcal D} f( 1 + \\frac{it}{\\log X} )| \\frac{dt}{1+\\left|t\\right|}", block: false)

#text("(assuming that ")#mi("f(p)=0")#text(" for ")#mi("p>X")#text(", otherwise replace ")#mi("it")#text(" by ")#mi("1+it")#text(" here) so by dyadic decomposition it suffices to show that")

#tao-math("\\displaystyle \\int_{\\left|t\\right| \\sim t_0} \\frac{1}{\\log X} |{\\mathcal D} f( 1 + \\frac{it}{\\log X} )|\\ dt \\ll_\\varepsilon t_0^{1-\\delta} \\exp( -(c_0-\\varepsilon) {\\mathbb D}(f,1;X)^2 )", block: false)

#text("for every ")#mi("2 \\leq t_0 \\leq \\log^{1/3-\\varepsilon} X")#text(" (the contribution of ")#mi("t=O(1)")#text(" can be easily handled) and some ")#mi("\\delta>0")#text(" depending only on ")#mi("\\varepsilon")#text(". Using Lemma 18 this can be reduced as")

#tao-math("\\displaystyle \\int_{\\left|t\\right| \\sim t_0} \\exp( \\sum_{p \\leq X} \\frac{1 - \\mathrm{Re} f(p) p^{-it/\\log X}}{p})\\ dt \\ll_\\varepsilon t_0^{1-\\delta} \\exp( -(c_0-\\varepsilon) \\sum_{p \\leq X} \\frac{1-\\mathrm{Re} f(p)}{p} ).", block: false)

#text("The contributions of ")#mi("p \\leq X^{1/t_0}")#text(" can be cancelled out without much difficulty using Mertens’ theorems, leaving one with")

#tao-math("\\displaystyle \\int_{\\left|t\\right| \\sim t_0} \\exp( \\sum_{X^{1/t_0} \\leq p \\leq X} \\frac{\\mathrm{Re} f(p) (c_0-\\varepsilon-p^{-it/\\log X})}{p})\\ dt \\ll_\\varepsilon t_0^{2-c_0+\\varepsilon-\\delta}.", block: false)

#text("Using a Halasz type theorem for the primes in the regime ")#mi("t_0 \\leq \\log^{1/3-\\varepsilon} X")#text(" one can show that ")#mi("\\sum_{X^{1/t_0} \\leq p \\leq X} \\frac{f(p) p^{-it/\\log X}}{p} \\leq \\varepsilon \\log t_0")#text(" for all ")#mi("t")#text(" outside of ")#mi("O_\\varepsilon(1)")#text(" unit intervals. This gives an acceptable contribution outside of these intervals (because of the gap between ")#mi("c_0")#text(" and ")#mi("2-c_0")#text(") so it remains to establish the pointwise bound")#linebreak()#text(" ")#mi("\\displaystyle \\exp( \\sum_{X^{1/t_0} \\leq p \\leq X} \\frac{\\mathrm{Re} f(p) (c_0-\\varepsilon-p^{-it/\\log X})}{p}) \\ll_\\varepsilon t_0^{2-c_0+\\varepsilon-\\delta}")

#text("so on taking logarithms and using the triangle inequality it suffices to show that")

#tao-math("\\displaystyle \\sum_{X^{1/t_0} \\leq p \\leq X} \\frac{\\left|c_0-\\varepsilon-p^{-it/\\log X}\\right|}{p} \\leq  (2-c_0+\\varepsilon-\\delta) \\log t_0 + O_\\varepsilon(1).", block: false)

#text("But by the prime number theorem, and summation by parts the left-hand side is")

#mi("\\displaystyle (\\int_0^1 |c_0-\\varepsilon-e^{2\\pi i \\theta}|\\ d\\theta) \\log t_0 + O_\\varepsilon(1)")

#text("and the claim now follows from the construction of ")#mi("c_0")#text(".")

#text("In the case when ")#mi("f")#text(" is real, one replaces ")#tao-math("\\left|c_0-e^{2\\pi i \\theta}\\right|", block: false)#text(" by ")#tao-math("\\left|\\mathrm{Re}(c_0-e^{2\\pi i \\theta})\\right|", block: false)#text(", and it seems the same argument now allows one to replace ")#mi("c_0")#text(" with ")#mi("1")#text(". I haven’t thought about whether the epsilon losses in the above argument can be removed in this case.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087168091627ebdd898f2fa8ef7e9d0035f136d76e6511386e1bdeb8a71236a6-073a253da0b1caf9b5124b952755a0a7424aecd87292abc3efc6d100d2dca283.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Smangerel")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-533698")[#strong[#text("Smangerel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2019")])]

#text("When ")#mi("f")#text(" is real-valued and 1-bounded the (unconditional) inequality you gave can be sharpened to")

#mi("\\displaystyle \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll \\exp\\left(-\\mathbb{D}(f,1;X)^2\\right) + \\frac{1}{\\log X},")

#text("in particular with ")#mi("c = 1")#text(", at least when ")#mi("f")#text(" does not behave too much like the M\\”{o}bius function.")#linebreak()#text(" To see this, it is convenient first to observe that ")#mi("f")#text(" can be assumed completely multiplicative without changing the order of magnitude in logarithmic averages (this can be shown as follows: define ")#mi("\\tilde{f}")#text(" to denote the completely multiplicative function defined on primes with ")#mi("\\tilde{f}(p) = f(p)")#text(" then, writing ")#mi("\\tilde{f} = h \\ast f")#text(", ")#mi("h")#text(" is supported on squarefulls. Then use the hyperbola method.).")#linebreak()#text(" With ")#mi("f")#text(" completely multiplicative, one easily sees that ")#mi("g := 1\\ast f")#text(" is non-negative and multiplicative, and moreover that")

#mi("\\displaystyle \\frac{1}{X} \\sum_{n \\leq X} g(n) = \\frac{1}{X} \\sum_{n \\leq X} f(n)\\left\\lfloor \\frac{X}{n}\\right\\rfloor = \\sum_{n \\leq X} \\frac{f(n)}{n} + O(1),")

#text("and since ")#mi("g")#text(" is divisor bounded one can use e.g., Shiu’s theorem to establish that")

#mi("\\frac{1}{X} \\sum_{n \\leq X} g(n) \\ll \\exp\\left(\\sum_{p \\leq X} \\frac{g(p)-1}{p}\\right) \\ll \\frac{1}{\\log X} \\exp\\left(-\\mathbb{D}(f,1;X)^2\\right),")

#text("as required.")#linebreak()#text(" By handling the term with fractional parts in the estimate for the mean value of ")#mi("g")#text(", one can improve the ")#mi("1/\\log X")#text(" slightly, as is done in Proposition 3.1 of ")#link("https://arxiv.org/pdf/math/0508361v1.pdf")[#text("https://arxiv.org/pdf/math/0508361v1.pdf")]#text("; to remove it entirely one would need to replace ")#mi("1/\\log X")#text(" by ")#mi("1/(\\log X)^2")#text(" which seems quite hard.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-533713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2019")])]

#text("Very slick! It’s nice to know that elementary methods are competitive with (and in this case, slightly superior to) the Fourier analytic/complex analytic methods sometimes :)")

#text("Andrew Granville also pointed out to me the bound")

#tao-math("\\displaystyle \\frac{1}{\\log X} \\sum_{n \\leq X} \\frac{f(n)}{n} \\ll \\exp( - \\inf_{\\left|t\\right| \\leq T} {\\mathbb D}(f, n \\mapsto n^{it}; X)^2 ) + \\frac{1}{T \\log X}", block: false)

#text("for any complex ")#mi("1")#text("-bounded ")#mi("f")#text(" and ")#mi("0 < T \\leq 1")#text(", established as Theorem 1.4 of ")#link("https://arxiv.org/pdf/1701.01042.pdf")[#text("your paper with Lamzouri")]#text(". He suggested that the ")#mi("c_0=0.822\\dots")#text(" inequality could be deduced from this one, though I wasn’t able to see a direct way to do this.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-532980")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("“…shown by Motohashi that one can also establish (4) as long as…”")

#text("that (4) links to (3), which I suspect the text should reflect.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-533895")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2019")])]

#text("In line 7, it seems that “multiplicative group ")#mi("\\mathbb R^+")#text("”")#linebreak()#text(" should be “additive group ")#mi("\\mathbb R^+")#text("”")

#emph[#text("[Actually, I do mean the multiplicative group ")#mi("\\mathbb R^+ = (\\mathbb R^+, \\cdot)")#text(" here; the positive reals ")#mi("\\mathbb R^+ = (0,+\\infty)")#text(" form a group under multiplication, but are merely a monoid under addition.)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-578369")[#strong[#text("Higher uniformity of bounded multiplicative functions in short intervals on average | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("[…] which was proven (for arbitrarily slowly growing ) in a landmark paper of Matomäki and Radziwill, discussed for instance in this blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A announcement: Analytic prime number theory | What's new")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-595078")[#strong[#text("254A announcement: Analytic prime number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2020")])]

#text("[…] Halasz’s theorem and the Matomaki-Radziwill theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-643426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2022")])]

#text("In exercise 4, I think you might have the hints swapped. Sorry if I’m missing something obvious.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rory")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-643654")[#strong[#text("Rory")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2022")])]

#text("Typo in the proof of Proposition 19: “Now suppose that ")#tao-math("\\left|t\\right| \\geq \\frac{100}{\\log X} \\leq \\left|t\\right| \\leq 100", block: false)#text(".”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-643758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2022")])]

#text("In Exercise 21, there seems to be a typo. You define a function ")#mi("f")#text(" which you do not use in the exercise itself.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-660165")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2022")])]

#text("Dear prof. Tao,")#linebreak()#text(" On the left of “However, from the Vinogradov-Korobov”, I think it should be ")#mi("1 +\\frac{1}{\\log^{0.99} X}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]

#text("In Exercise 20 the second part, if one assumes Riemann Hypothesis, then from the bound ")#tao-math("\\left| \\zeta(\\sigma+it)\\right|  \\ll \\log^{O(1)}\\left| t \\right|", block: false)#text(" and the Log-truncated formula, one already obtains ")#tao-math("\\frac{\\zeta^{\\prime}}{\\zeta}(s) \\ll \\log \\log \\left| t \\right|", block: false)#text(" which is sufficient to establish the bound ")#tao-math("\\left| t \\right| \\exp(\\exp(\\log^{0.99} X))", block: false)#text(" without the needs to use the first part of Exercise 20.")

#emph[#text("[I am afraid I do not see how to get a double logarithmic bound on ")#mi("\\zeta^{\\prime}/\\zeta(s)")#text(", which would require ")#mi("s")#text(" to stay a distance ")#tao-math("\\gg 1/\\log \\log \\left|t\\right|", block: false)#text(" away from any zeroes. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-669322")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2022")])]

#text("Dear prof. Tao,")#linebreak()#text(" The function in the integrand in equation below “On the other hand, from Exercise 11 we have” should have been \\varphi( \\frac{X}{\\eta^2 H} (\\log n – \\log y) )?")#linebreak()#text(" And in the RHS of the second equations of Exercise 29 should have been in terms of ")#tao-fit-display[#mitex("dt")]#text(".")#linebreak()#text(" Also, I think the RHS of the first equation of Exercise 29, the factor before the integral should be 1/(H/X)? Cause If one tries with f(n) = 1 supported in [X, 3X] then the inequality turns out to be false.")#linebreak()#text(" Thank you for your time.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-678769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("FYI – there seems to be some issue with wordpress where the post that was previously here has been replaced with the most recent blog post for some reason, at least on my end.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0071c5503c4fb88b4c53152b9ea1a78a0826281448827e2a6f15161b620a1bfc-f421b3ac8b1e2310c90ba85e4cd3e6b890c69b102b7dedfbcfa6f8574466c7ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-679700")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2023")])]

#text("Is there a factor of ")#mi("1/P")#text(" missing from either the definition of ")#mi("w_P")#text(" or ")#mi("\\tilde{w}")#text(" (in Section 3 around where the bullet points are)? I’m not getting that the expectation of ")#mi("1 * \\tilde{w}")#text(" is roughly 1, and so Exercise 31 seems to not hold as currently written? However, if you introduce a factor of ")#mi("1/P")#text(" in ")#mi("w_P")#text(", then the expectation of ")#mi("1 * \\tilde{w}")#text(" does appear to be roughly ")#mi("1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0071c5503c4fb88b4c53152b9ea1a78a0826281448827e2a6f15161b620a1bfc-f421b3ac8b1e2310c90ba85e4cd3e6b890c69b102b7dedfbcfa6f8574466c7ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-679827")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2023")])]

#text("But if you put the $1/P$ in the definition of $w_P$, then I’m not sure that $(fw_P) * (f\\psi_{X/P})$ is small implies that (21) is small. Should the $1/P$ go in the definition of $\\tilde{w}$ instead of $w/P$ (so that you have a $\\log\\log$ average)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0071c5503c4fb88b4c53152b9ea1a78a0826281448827e2a6f15161b620a1bfc-f421b3ac8b1e2310c90ba85e4cd3e6b890c69b102b7dedfbcfa6f8574466c7ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2019/12/17/254a-notes-10-mean-values-of-nonpretentious-multiplicative-functions/#comment-679891")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2023")])]

#text("In the proof of Proposition 32, why is it true that $w^{*k}_P(n) \\ll k^k$? I’m getting that $w^{*k}_P(n) \\ll k! \\frac{\\log(P)^k}{\\eta^{4k}}$ by the old definition of $w_P$ (with the newer definition, it appears the entire proposition would need to be reworked a bit, such as the appeal to the prime number theorem).")
]
