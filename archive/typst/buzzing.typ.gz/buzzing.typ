// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/12/buzzing/
// Converted to Typst by tao2typ: "2026-10-14T16:36:04.906196+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Buzzing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Buzzing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/12/buzzing/")[#text("https://terrytao.wordpress.com/2010/02/12/buzzing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("As an experiment, I’ve recently ")#link("http://www.google.com/profiles/114134834346472219368")[#text("started using Google Buzz")]#text(" as an outlet for various things I wanted to say or share, but which were too insubstantial to merit a mention on this blog. (In turn, one of the reasons of starting this blog was to share various bits of mathematics which were too insubstantial for a published paper. Presumably the ")#link("http://www.youtube.com/watch?v=BeLZCy-_m3s")[#text("process becomes degenerate")]#text(" if iterated any further…) I don’t know how frequently I will be updating, though.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ac636b899a7573f354a7f9bf849964dd10a1d7a53d859d0e4a1efb307a818b1-3e4126103c4fbae2c8a94e53bd59456c2f0d163a314467d52ffa7b6d01fb478a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luckytoilet")]], [#link("https://terrytao.wordpress.com/2010/02/12/buzzing/#comment-43598")[#strong[#text("luckytoilet")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("That’s interesting; but don’t you have to add someone in order to read their posts on Buzz?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff111f533161801b5574769b285239e39d403deaf07c86f4b65d5b26da30cf76-681eac6d5d32a05b1a44771491b73d0b32b7df05a20ce8ccd3bbcc6ff69fd1c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luckywhat?")]], [#link("https://terrytao.wordpress.com/2010/02/12/buzzing/#comment-43612")[#strong[#text("luckywhat?")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("No. Google adds your top contacts automatically to Buzz. Its really annoying and not so easy to disable. You have to actively ‘block’ people that were added, potentially hurting their feelings… :(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/12/buzzing/#comment-43655")[#strong[#text("Career advice from the Fields medalists and some other mathematicians « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2010")]

#text("[…] 3: a recent interview with Terence Tao, his Google buzz page and his post on […]")
]
