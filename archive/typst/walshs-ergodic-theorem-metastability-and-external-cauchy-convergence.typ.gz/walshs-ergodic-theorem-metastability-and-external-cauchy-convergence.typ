// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/
// Converted to Typst by tao2typ: "2026-10-14T09:28:22.858164+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Walsh’s ergodic theorem, metastability, and external Cauchy convergence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/")[#text("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Two weeks ago I was at Oberwolfach, for the ")#link("http://www.mfo.de/occasion/1241/www_view")[#text("Arbeitsgemeinschaft in Ergodic Theory and Combinatorial Number Theory")]#text(" that I was one of the organisers for. At this workshop, I learned the details of a very nice ")#link("http://arxiv.org/abs/1109.2922")[#text("recent convergence result")]#text(" of ")#link("http://cms.dm.uba.ar/Members/mwalsh/")[#text("Miguel Walsh")]#text(" (who, incidentally, is an informal grandstudent of mine, as his advisor, ")#link("http://www.umpa.ens-lyon.fr/labo.php?login=rsasyk")[#text("Roman Sasyk")]#text(", was my informal student), which considerably strengthens and generalises a number of previous convergence results in ergodic theory (including ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("one of my own")]#text("), with a remarkably simple proof. Walsh’s argument is phrased in a finitary language (somewhat similar, in fact, to the approach used in my paper mentioned previously), and (among other things) relies on the concept of ")#link("http://en.wikipedia.org/wiki/Metastable")[#text("metastability")]#text(" of sequences, a variant of the notion of convergence which is useful in situations in which one does not expect a uniform convergence rate; see ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this previous blog post")]#text(" for some discussion of metastability. When interpreted in a finitary setting, this concept requires a fair amount of “epsilon management” to manipulate; also, Walsh’s argument uses some other epsilon-intensive finitary arguments, such as a ")#link("http://arxiv.org/abs/0811.3103")[#text("decomposition lemma of Gowers")]#text(" based on the Hahn-Banach theorem. As such, I was tempted to try to rewrite Walsh’s argument in the language of nonstandard analysis to see the extent to which these sorts of issues could be managed. As it turns out, the argument gets cleaned up rather nicely, with the notion of metastability being replaced with the simpler notion of ")#emph[#text("external Cauchy convergence")]#text(" (which we will define below the fold).")

#text("Let’s first state Walsh’s theorem. This theorem is a norm convergence theorem in ergodic theory, and can be viewed as a substantial generalisation of one of the most fundamental theorems of this type, namely the ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Mean_ergodic_theorem")[#text("mean ergodic theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Mean ergodic theorem)")]#text(" Let ")#mi("{(X,\\mu,T)}")#text(" be a measure-preserving system (a probability space ")#mi("{(X,\\mu)}")#text(" with an invertible measure-preserving transformation ")#mi("{T}")#text("). Then for any ")#mi("{f \\in L^2(X,\\mu)}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N T^n f}")#text(" converge in ")#mi("{L^2(X,\\mu)}")#text(" norm as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{T^n f(x) := f(T^{-n} x)}")#text(".")
]

#text("In this post, all functions in ")#mi("{L^2(X,\\mu)}")#text(" and similar spaces will be taken to be real instead of complex-valued for simplicity, though the extension to the complex setting is routine.")

#text("Actually, we have a precise description of the limit of these averages, namely the orthogonal projection of ")#mi("{f}")#text(" to the ")#mi("{T}")#text("-invariant factors. (See for instance my ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("lecture notes on this theorem")]#text(".) While this theorem ostensibly involves measure theory, it can be abstracted to the more general setting of unitary operators on a Hilbert space:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (von Neumann mean ergodic theorem)")]#text(" ")#metadata(none) <tao-02844e96939fa2ca9bf4>#text(" Let ")#mi("{H}")#text(" be a Hilbert space, and let ")#mi("{U: H \\rightarrow H}")#text(" be a unitary operator on ")#mi("{H}")#text(". Then for any ")#mi("{f \\in H}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N U^n f}")#text(" converge strongly in ")#mi("{H}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#text("Again, see ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("my lecture notes")]#text(" (or just about any text in ergodic theory) for a proof.")

#text("Now we turn to Walsh’s theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Walsh’s convergence theorem)")]#text(" ")#metadata(none) <tao-c20d77a59fc6abfae8f2>#text(" Let ")#mi("{(X,\\mu)}")#text(" be a measure space with a measure-preserving action of a nilpotent group ")#mi("{G}")#text(". Let ")#mi("{g_1,\\ldots,g_k: {\\bf Z} \\rightarrow G}")#text(" be polynomial sequences in ")#mi("{G}")#text(" (i.e. each ")#mi("{g_i}")#text(" takes the form ")#mi("{g_i(n) = a_{i,1}^{p_{i,1}(n)} \\ldots a_{i,j}^{p_{i,j}(n)}}")#text(" for some ")#mi("{a_{i,1},\\ldots,a_{i,j} \\in G}")#text(" and polynomials ")#mi("{p_{i,1},\\ldots,p_{i,j}: {\\bf Z} \\rightarrow {\\bf Z}}")#text("). Then for any ")#mi("{f_1,\\ldots,f_k \\in L^\\infty(X,\\mu)}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(" converge in ")#mi("{L^2(X,\\mu)}")#text(" norm as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{g(n) f(x) := f(g(n)^{-1} x)}")#text(".")
]

#text("It turns out that this theorem can also be abstracted to some extent, although due to the multiplication in the summand ")#mi("{(g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(", one cannot work purely with Hilbert spaces as in the von Neumann mean ergodic theorem, but must also work with something like the Banach algebra ")#mi("{L^\\infty(X,\\mu)}")#text(". There are a number of ways to formulate this abstraction (which will be of some minor convenience to us, as it will allow us to reduce the need to invoke the nonstandard measure theory of Loeb, discussed for instance in ")#link("https://terrytao.wordpress.com/2010/11/29/concentration-compactness-via-nonstandard-analysis/")[#text("this blog post")]#text("); we will use the notion of a (real) ")#emph[#text("commutative probability space")]#text(" ")#mi("{({\\mathcal A},\\tau)}")#text(", which for us will be a commutative unital ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" ")#mi("{{\\mathcal A}}")#text(" over the reals together with a linear functional ")#mi("{\\tau: {\\mathcal A} \\rightarrow {\\bf R}}")#text(" which maps ")#mi("{1}")#text(" to ")#mi("{1}")#text(" and obeys the non-negativity axiom ")#mi("{\\tau(f^2) \\ge 0}")#text(" for all ")#mi("{f}")#text(". The key example to keep in mind here is ")#mi("{{\\mathcal A} = L^\\infty(X,\\mu)}")#text(" of essentially bounded real-valued measurable functions with the supremum norm, and with the trace ")#mi("{\\tau(f) := \\int_X f\\ d\\mu}")#text(". We will also assume in our definition of commutative probability spaces that all elements ")#mi("{f}")#text(" of ")#mi("{{\\mathcal A}}")#text(" are ")#emph[#text("bounded")]#text(" in the sense that the ")#emph[#text("spectral radius")]#text(" ")#mi("{\\rho(f) := \\lim_{k \\rightarrow \\infty} \\tau(f^{2k})^{1/2k}}")#text(" is finite. (In the concrete case of ")#mi("{L^\\infty(X,\\mu)}")#text(", the spectral radius is just the ")#mi("{L^\\infty}")#text(" norm.)")

#text("Given a commutative probability space, we can form an inner product ")#mi("{\\langle, \\rangle_{L^2(\\tau)}}")#text(" on it by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f, g \\rangle_{L^2(\\tau)} := \\tau(fg).")]]

#text("This is a positive semi-definite form, and gives a (possibly degenerate) inner product structure on ")#mi("{{\\mathcal A}}")#text(". We could complete this structure into a Hilbert space ")#mi("{L^2(\\tau)}")#text(" (after quotienting out the elements of zero norm), but we will not do so here, instead just viewing ")#mi("{L^2(\\tau)}")#text(" as providing a semi-metric on ")#mi("{{\\mathcal A}}")#text(". For future reference we record the inequalities")

#tao-aligned(keep: true)[


#tao-math("\\rho(fg)  & \\leq \\rho(f) \\rho(g)", block: true)



#tao-math("\\rho(f+g)  & \\leq \\rho(f) + \\rho(g)", block: true)



#tao-math("\\left\\| fg\\right\\|_{L^2(\\tau)}  & \\leq \\left\\|f\\right\\|_{L^2(\\tau)} \\rho(g)", block: true)
]

#text("for any ")#mi("{f,g}")#text(", which we will use in the sequel without further comment; see e.g. ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("these previous blog notes")]#text(" for proofs. (Actually, for the purposes of proving Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(", one can specialise to the ")#mi("{L^\\infty(X,\\mu)}")#text(" case (and ultraproducts thereof), in which case these inequalities are just the triangle and Hölder inequalities.)")

#text("The abstract version of Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(" is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Walsh’s theorem, abstract version)")]#text(" ")#metadata(none) <tao-c61530c9251ac6d247f9>#text(" Let ")#mi("{({\\mathcal A},\\tau)}")#text(" be a commutative probability space, and let ")#mi("{G}")#text(" be a nilpotent group acting on ")#mi("{{\\mathcal A}}")#text(" by isomorphisms (preserving the algebra, conjugation, and trace structure, and thus also preserving the spectral radius and ")#mi("{L^2(\\tau)}")#text(" norm). Let ")#mi("{g_1,\\ldots,g_k: {\\bf Z} \\rightarrow G}")#text(" be polynomial sequences. Then for any ")#mi("{f_1,\\ldots,f_k \\in {\\mathcal A}}")#text(", the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(" form a Cauchy sequence in ")#mi("{L^2(\\tau)}")#text(" (semi-)norm as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#text("It is easy to see that this theorem generalises Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(". Conversely, one can use the commutative ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark_theorem")[#text("Gelfand-Naimark theorem")]#text(" to deduce Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" from Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(", although we will not need this implication. Note how we are abandoning all attempts to discern what the limit of the sequence actually is, instead contenting ourselves with demonstrating that it is merely a Cauchy sequence. With this phrasing, it is tempting to ask whether there is any analogue of Walsh’s theorem for noncommutative probability spaces, but unfortunately the answer to that question is negative for all but the simplest of averages, as was worked out in ")#link("https://terrytao.wordpress.com/2009/12/29/nonconventional-ergodic-averages-and-multiple-recurrence-for-von-neumann-dynamical-systems/")[#text("this paper of Austin, Eisner, and myself")]#text(".")

#text("Our proof of Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" will proceed as follows. Firstly, in order to avoid the epsilon management alluded to earlier, we will take an ultraproduct to rephrase the theorem in the language of nonstandard analysis; for reasons that will be clearer later, we will also convert the convergence problem to a problem of obtaining metastability (external Cauchy convergence). Then, we observe that (the nonstandard counterpart of) the expression ")#tao-math("{\\left\\|\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)\\right\\|_{L^2(\\tau)}^2}", block: false)#text(" can be viewed as the inner product of (say) ")#mi("{f_k}")#text(" with a certain type of expression, which we call a ")#emph[#text("dual function")]#text(". By performing an orthogonal projection to the span of the dual functions, we can split ")#mi("{f_k}")#text(" into the sum of an expression orthogonal to all dual functions (the “pseudorandom” component), and a function that can be well approximated by finite linear combinations of dual functions (the “structured” component). The contribution of the pseudorandom component is asymptotically negligible, so we can reduce to consideration of the structured component. But by a little bit of rearrangement, this can be viewed as an average of expressions similar to the initial average ")#mi("{\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(", except with the polynomials ")#mi("{g_1,\\ldots,g_k}")#text(" replaced by a “lower complexity” set of such polynomials, which can be greater in number, but which have slightly lower degrees in some sense. One can iterate this (using “PET induction”) until all the polynomials become trivial, at which point the claim follows.")

#metadata(none) <tao-e0ddce8263b8c3939aaf>

#heading(level: 1)[#strong[#text(" — 1. Nonstandard analysis and metastability — ")]]

#text("We will assume some familiarity with ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(", as covered for instance in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2011/10/15/254a-notes-6-ultraproducts-as-a-bridge-between-hard-analysis-and-soft-analysis/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("blog posts")]#text(".")

#text("As is common practice in nonstandard analysis, we will need to select a non-principal ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" ")#mi("{p \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(". Using this ultrafilter, we can now form the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{\\prod_{{\\bf n} \\rightarrow p} X_{\\bf n}}")#text(" of any sequence ")#mi("{X_{\\bf n}}")#text(" of (standard) spaces, defined as the space of all ultralimits ")#mi("{\\lim_{{\\bf n} \\rightarrow p} x_{\\bf n}}")#text(" of sequences ")#mi("{x_{\\bf n}\\in X_{\\bf n}}")#text(" defined for ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{p}")#text(", with two sequences considered to have the same ultralimit iff they agree sufficiently close to ")#mi("{p}")#text(". Any operation or relation on the standard spaces ")#mi("{X_{\\bf n}}")#text(" can then be defined on the nonstandard space ")#mi("{X = \\prod_{{\\bf n} \\rightarrow p} X_{\\bf n}}")#text(" in a natural fashion. For instance, given a sequence of standard functions ")#mi("{f_{\\bf n}: X_{\\bf n} \\rightarrow Y_{\\bf n}}")#text(", one can form their ultralimit ")#mi("{f = \\lim_{{\\bf n} \\rightarrow p} f_{\\bf n}}")#text(" from the nonstandard space ")#mi("{X = \\prod_{{\\bf n} \\rightarrow p} X_{\\bf n}}")#text(" to the nonstandard space ")#mi("{Y = \\prod_{{\\bf n} \\rightarrow p} Y_{\\bf n}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("f( \\lim_{{\\bf n} \\rightarrow p} x_{\\bf n} ) := \\lim_{{\\bf n} \\rightarrow p} f( x_{\\bf n}).")]]

#text("As usual, we call a nonstandard real ")#mi("{x \\in {}^* {\\bf R}}")#text(" ")#emph[#text("bounded")]#text(" if we have ")#tao-math("{\\left|x\\right| \\leq C}", block: false)#text(" for some standard ")#mi("{C}")#text(", and ")#emph[#text("infinitesimal")]#text(" if we have ")#tao-math("{\\left|x\\right| \\leq \\epsilon}", block: false)#text(" for every standard ")#mi("{\\epsilon>0}")#text(", and in the latter case we also write ")#mi("{x=o(1)}")#text(". Every bounded nonstandard real ")#mi("{x}")#text(" is infinitesimally close to a unique standard real, called the ")#emph[#text("standard part")]#text(" ")#mi("{\\text{st}(x)}")#text(" of ")#mi("{x}")#text(".")

#text("We will need the following fundamental properties about nonstandard analysis:")

#list(
[#text("(")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("Transfer")]#text(" / Los’s theorem) If for each ")#mi("{i=1,\\ldots,k}")#text(", ")#mi("{x_{i,{\\bf n}}}")#text(" is a sequence of mathematical objects, spaces, or functions, with ultralimit or ultraproduct ")#mi("{x_i}")#text(", then for any first-order predicate ")#mi("{P( y_1,\\ldots,y_k)}")#text(" involving ")#mi("{k}")#text(" mathematical objects of the appropriate type, the claim ")#mi("{P(x_1,\\ldots,x_k)}")#text(" is true if and only if ")#mi("{P(x_1,\\ldots,x_{k,{\\bf n}})}")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Overspill")[#text("Overspill")]#text(") If an internal set ")#mi("{E}")#text(" (an ultraproduct of standard sets, also known as a ")#emph[#text("nonstandard set")]#text(") of nonstandard numbers contains all unbounded natural numbers, then there exists a standard natural number ")#mi("{N}")#text(" such that ")#mi("{E}")#text(" contains all nonstandard numbers larger than ")#mi("{N}")#text(".")],
[#text("(")#link("http://en.wikipedia.org/wiki/Loeb_space")[#text("Loeb measure")]#text(", hyperfinite case) If ")#mi("{A}")#text(" is a non-empty nonstandard finite set (i.e. the ultraproduct ")#mi("{A = \\prod_{{\\bf n} \\rightarrow p} A_{\\bf n}}")#text(" of standard finite sets, also known as a ")#link("http://en.wikipedia.org/wiki/Hyperfinite_set")[#text("hyperfinite set")]#text("), and the ")#emph[#text("Loeb ")#mi("{\\sigma}")#text("-algebra")]#text(" is defined as the ")#mi("{\\sigma}")#text("-algebra generated by the internal subsets of ")#mi("{A}")#text(", then there exists a unique countably additive probability measure ")#mi("{\\mu_A}")#text(" on the Loeb ")#mi("{\\sigma}")#text("-algebra, called ")#emph[#text("Loeb measure")]#text(", such that for any internal subset ")#mi("{E =\\prod_{{\\bf n} \\rightarrow p} E_{\\bf n}}")#text(" of ")#mi("{A}")#text(", one has ")#tao-math("{\\mu_A(E) = \\text{st} \\lim_{{\\bf n} \\rightarrow p} \\left|E_{\\bf n}\\right|/\\left|A_{\\bf n}\\right|}", block: false)#text(". See e.g. ")#link("https://terrytao.wordpress.com/2010/11/27/nonstandard-analysis-as-a-completion-of-standard-analysis/")[#text("this previous blog post")]#text(" for the details of the construction.")]
)

#text("To motivate the discussion that follows, let us recall some equivalent formulations of a Cauchy sequence in a ")#link("http://en.wikipedia.org/wiki/Metric_(mathematics)#Pseudometrics")[#text("pseudometric space")]#text(" (i.e. a generalisation of a metric space in which some distances are allowed to vanish).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-92c7ffa88382f73bbf32>#text(" Let ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" be a sequence in a pseudometric space ")#mi("{(X,d)}")#text(" (not necessarily complete). Let ")#mi("{(x_n)_{n \\in {}^* {\\bf N}}}")#text(" be the nonstandard extension of ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(", taking values in the nonstandard metric space ")#mi("{({}^* X, {}^* d)}")#text(". Then the following are equivalent:")

#enum(start: 1, 
[#text("(standard Cauchy sequence) For every standard ")#mi("{\\epsilon > 0}")#text(", there exists a standard ")#mi("{N > 0}")#text(" such that ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all standard ")#mi("{n,m \\geq N}")#text(".")],
[#text("(nonstandard Cauchy sequence) For every nonstandard ")#mi("{\\epsilon > 0}")#text(", there exists a nonstandard ")#mi("{N > 0}")#text(" such that ")#mi("{{}^* d(x_n,x_m) \\leq \\epsilon}")#text(" for all nonstandard ")#mi("{n,m \\geq N}")#text(".")],
[#text("(standard metastability) For every standard function ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" and standard ")#mi("{\\epsilon>0}")#text(", there exists a standard ")#mi("{N>0}")#text(" such that ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all standard ")#mi("{N \\leq n,m \\leq N+F(N)}")#text(".")],
[#text("(nonstandard metastability) For every nonstandard function ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" and nonstandard ")#mi("{\\epsilon>0}")#text(", there exists a nonstandard ")#mi("{N>0}")#text(" such that ")#mi("{{}^* d(x_n,x_m) \\leq \\epsilon}")#text(" for all nonstandard ")#mi("{N \\leq n,m \\leq N+F(N)}")#text(".")],
[#text("(asymptotic stability) One has ")#mi("{{}^* d(x_n,x_m) = o(1)}")#text(" for all unbounded ")#mi("{n,m}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The equivalence of 1 and 2 follows from the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" (or Los’s theorem), as does the equivalence of 3 and 4. The implication of 3 from 1 is also clear. Finally, suppose that 1 failed, then there is an ")#mi("{\\epsilon>0}")#text(" such that for every standard ")#mi("{N>0}")#text(" we can find a larger number ")#mi("{N^{\\prime} > N}")#text(" such that ")#mi("{d(x_N,x_{N^{\\prime}}) > \\epsilon}")#text(". Setting ")#mi("{F(N) := N^{\\prime}-N}")#text(", we see that 3 fails also.")

#text("If 1 holds, then from transfer we see that for any unbounded ")#mi("{n,m}")#text(", one has ")#mi("{{}^* d(x_n,x_m) \\leq \\epsilon}")#text(" for every standard ")#mi("{\\epsilon}")#text(", giving 5. Conversely, if 1 fails, then letting ")#mi("{F(N)}")#text(" be as before, we see from transfer that ")#mi("{{}^* d(x_N, x_{N+F(N)}) > \\epsilon}")#text(" for every nonstandard ")#mi("{N}")#text(", contradicting 5. ")#mi("\\Box")

#text("Now we consider more general sequences, in which the above notions of convergence begin to diverge:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6")]#text(" Let ")#mi("{(X,d)}")#text(" be a nonstandard pseudometric space (i.e. the ultraproduct of standard pseudometric spaces ")#mi("{(X_{\\bf n},d_{\\bf n})}")#text("; in particular, ")#mi("{d}")#text(" takes values in ")#mi("{{}^* {\\bf R}^+}")#text(" rather than ")#mi("{{\\bf R}^+}")#text("), and let ")#mi("{x: n \\mapsto x_n}")#text(" be an nonstandard sequence (or ")#emph[#text("internal sequence")]#text(") in ")#mi("{X}")#text(", that is to say a nonstandard map (or ")#emph[#text("internal map")]#text(") from ")#mi("{{}^* {\\bf N}}")#text(" to ")#mi("{X}")#text(" (and thus an ultralimit of maps from ")#mi("{{\\bf N}}")#text(" to ")#mi("{X_{\\bf n}}")#text(").")

#list(
[#text("We say that the sequence ")#mi("{x}")#text(" is ")#emph[#text("internally Cauchy")]#text(" if for every nonstandard ")#mi("{\\epsilon>0}")#text(", there exists a nonstandard ")#mi("{N>0}")#text(" such that ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all nonstandard ")#mi("{n,m \\geq N}")#text(".")],
[#text("We say that the sequence ")#mi("{x}")#text(" is ")#emph[#text("externally Cauchy")]#text(" or ")#emph[#text("metastable")]#text(" if for every standard ")#mi("{\\epsilon>0}")#text(", there exists a standard ")#mi("{N>0}")#text(" such that ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all standard ")#mi("{n,m \\geq N}")#text(".")],
[#text("We say that the sequence ")#mi("{x}")#text(" is ")#emph[#text("asymptotically stable")]#text(" if ")#mi("{d(x_n,x_m)=o(1)}")#text(" whenever ")#mi("{n,m}")#text(" are unbounded.")]
)
]

#text("These three notions are now distinct, even for a simple nonstandard metric space such as the ultrapower ")#mi("{{}^*[-1,1]}")#text(" of the unit interval with the usual metric, as the following examples demonstrate:")

#enum(start: 1, 
[#text("If ")#mi("{N}")#text(" is an unbounded natural number, then the nonstandard sequence ")#mi("{x_n := (-1)^n \\exp(-n/N)}")#text(" is internally Cauchy, but not externally Cauchy or asymptotically stable.")],
[#text("If ")#mi("{N}")#text(" is an unbounded natural number, then the nonstandard sequence ")#mi("{x_n := 1_{n > N}}")#text(" is internally and externally Cauchy, but not asymptotically stable.")],
[#text("If ")#mi("{N}")#text(" is an unbounded natural number, then the nonstandard sequence ")#mi("{x_n := (-1)^n 1_{n > N}}")#text(" is externally Cauchy, but not internally Cauchy or asymptotically stable.")],
[#text("If ")#mi("{N}")#text(" is an unbounded natural number, then the nonstandard sequence ")#mi("{x_n := (-1)^n/N}")#text(" is asymptotically stable and externally Cauchy, but not internally Cauchy.")],
[#text("Any monotone bounded nonstandard sequence of nonstandard reals is automatically both externally Cauchy and internally Cauchy, but is not necessarily asymptotically stable, as the example ")#mi("{1_{n>N}}")#text(" above shows.")],
[#text("The property of being externally Cauchy is only dependent on an initial segment of the sequence: if ")#mi("{x_n}")#text(" is externally Cauchy, and one modifies ")#mi("{x_n}")#text(" arbitrarily for ")#mi("{n \\geq N}")#text(" and some fixed unbounded ")#mi("{N}")#text(", then the modified sequence ")#mi("{x^{\\prime}_n}")#text(" will still be externally Cauchy. The same claim is certainly not true for the notions of internally Cauchy or asymptotically stable, as can be seen by considering examples such as ")#mi("{0}")#text(", ")#mi("{1_{n > N}}")#text(" and ")#mi("{(-1)^n 1_{n>N}}")#text(".")],
[#text("The property of being externally Cauchy is closed under (external) uniform limits; if ")#mi("{x_n}")#text(" is a nonstandard sequence such that for every standard ")#mi("{\\epsilon>0}")#text(" one can find an externally Cauchy sequence ")#mi("{x^{\\prime}_n}")#text(" with ")#mi("{d(x_n,x^{\\prime}_n) \\leq \\epsilon}")#text(" for all ")#mi("{n}")#text(", then ")#mi("{x_n}")#text(" is itself externally Cauchy. The same claim holds as well for asymptotically stability, but not for the internal Cauchy property (unless one allows ")#mi("{\\epsilon}")#text(" to be nonstandard).")]
)

#text("One can equate these three nonstandard notions of convergence with standard notions as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" Let ")#mi("{(X,d)}")#text(" be a nonstandard pseudometric space (the ultraproduct of standard pseudometric spaces ")#mi("{(X_{\\bf n},d_{\\bf n})}")#text("), and let the nonstandard sequence ")#mi("{x: {}^* {\\bf N} \\rightarrow X}")#text(" be the ultralimit of standard sequences ")#mi("{x_{\\bf n}: {\\bf N} \\rightarrow X_{\\bf n}}")#text(".")

#enum(start: 1, 
[#text("The nonstandard sequence ")#mi("{x}")#text(" is internally Cauchy if and only if the standard sequences ")#mi("{x_{\\bf n}}")#text(" are Cauchy for all ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{p}")#text(".")],
[#text("The nonstandard sequence ")#mi("{x}")#text(" is externally Cauchy if and only if for every standard ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(" and standard ")#mi("{\\epsilon>0}")#text(" , there exists a standard ")#mi("{N}")#text(" such that ")#mi("{d_{\\bf n}(x_n,x_m) \\leq \\epsilon}")#text(" for all ")#mi("{N \\leq n,m\\leq N+F(N)}")#text(" and all ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{p}")#text(".")],
[#text("The nonstandard sequence ")#mi("{x}")#text(" is asymptotically stable if and only if for every standard ")#mi("{\\epsilon>0}")#text(", there exists a standard ")#mi("{N}")#text(" such that one has ")#mi("{d_{\\bf n}(x_n,x_m) \\leq \\epsilon}")#text(" for all standard ")#mi("{n,m \\geq N}")#text(" and all ")#mi("{{\\bf n}}")#text(" sufficiently close to ")#mi("{p}")#text(".")],
[#text("The nonstandard sequence ")#mi("{x}")#text(" is externally Cauchy if and only if there exists an unbounded ")#mi("{N_0}")#text(" such that ")#mi("{x}")#text(" is asymptotically stable up to ")#mi("{N_0}")#text(", in the sense that ")#mi("{d(x_n,x_m)=o(1)}")#text(" for all unbounded ")#mi("{n,m \\leq N_0}")#text(".")]
)
]

#text("Informally: internally Cauchy sequences are ultralimits of sequences that are Cauchy; externally Cauchy sequences are ultralimits of sequences that are uniformly metastable for an asymptotically infinite period of time; and asymptotically stable sequences are ultralimits of sequences that converge at a uniform rate for an asymptotically infinite period of time.")

#emph[#text("Proof:")]#text(" The claim 1 follows directly from the transfer principle. Claim 2 follows from the equivalences of parts 1 and 3 of Proposition ")#link(<tao-92c7ffa88382f73bbf32>)[#text("5")]#text(" applied to the standard portion ")#mi("{(x_n)_{n \\in{\\bf N}}}")#text(" of the sequence (replacing the nonstandard metric by its standard part). Finally, we verify claim 3. If ")#mi("{x}")#text(" is asymptotically stable, then for every standard ")#mi("{\\epsilon>0}")#text(", we have ")#mi("{d(x_n,x_m) < \\epsilon}")#text(" for all unbounded ")#mi("{n,m}")#text(", and so by the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill principle")]#text(", there is a standard ")#mi("{N}")#text(" such that ")#mi("{d(x_n,x_m) < \\epsilon}")#text(" for all ")#mi("{n,m \\geq N}")#text(", which by transfer gives the “only if” portion of Claim 3. Reversing these steps gives the “if” direction.")

#text("To show Claim 4, observe that if ")#mi("{x}")#text(" is externally Cauchy, then for every standard ")#mi("{\\epsilon > 0}")#text(", one has ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all sufficiently large standard ")#mi("{n,m}")#text(", and thus by overspill there is an unbounded ")#mi("{N_\\epsilon}")#text(" such that ")#mi("{d(x_n,x_m) \\leq \\epsilon}")#text(" for all unbounded ")#mi("{n,m \\leq N_\\epsilon}")#text(". By overspill (or countable saturation) one can find an unbounded ")#mi("{N_0}")#text(" such that ")#mi("{N_0 \\leq N_\\epsilon}")#text(" for every standard ")#mi("{\\epsilon>0}")#text(", giving the “only if” direction. The “if” implication follows by reversing the steps. ")#mi("\\Box")

#text("From these equivalences one sees that asymptotic stability implies externally Cauchy, but as the above counterexamples show, there are no other implications between the three concepts.")

#text("Of the three notions of convergence for nonstandard sequences, we will focus almost exclusively on the notion of external Cauchy convergence, which at the finitary level corresponds to uniform metastability bounds (as opposed to qualitative convergence, or convergence at a uniform rate). In particular, we will deduce Walsh’s theorem from the following nonstandard version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Walsh’s theorem, nonstandard version)")]#text(" ")#metadata(none) <tao-5f44cacdb7e2c1316694>#text(" Let ")#mi("{({\\mathcal A},\\tau)}")#text(" be a nonstandard commutative probability space (i.e. the ultraproduct of standard commutative probability spaces), and let ")#mi("{G}")#text(" be a nilpotent nonstandard group acting on ")#mi("{{\\mathcal A}}")#text(" by isomorphisms. Let ")#mi("{g_1,\\ldots,g_k: {}^* {\\bf Z} \\rightarrow {}^* G}")#text(" be polynomial nonstandard functions (i.e. each ")#mi("{g_i}")#text(" takes the form ")#mi("{g_i(n) = a_{i,1}^{p_{i,1}(n)} \\ldots a_{i,j}^{p_{i,j}(n)}}")#text(" for some standard ")#mi("{j}")#text(", some ")#mi("{a_{i,1},\\ldots,a_{i,j} \\in G}")#text(" and some standard polynomials ")#mi("{p_{i,1},\\ldots,p_{i,j}: {\\bf Z} \\rightarrow {\\bf Z}}")#text("). Then for any elements ")#mi("{f_1,\\ldots,f_k \\in {\\mathcal A}}")#text(" which are bounded (in the sense that ")#mi("{\\rho(f_1),\\ldots,\\rho(f_k)}")#text(" are bounded), the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(" form an externally Cauchy sequence with respect to the (non-standard) ")#mi("{L^2(\\tau)}")#text(" pseudometric.")
]

#text("From Proposition ")#link(<tao-92c7ffa88382f73bbf32>)[#text("5")]#text(", Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" implies Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" and thus Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(". But it is actually somewhat stronger, in that it gives a uniform metastability on the averages occuring in those latter two theorems. (This uniform metastability was already derived in Walsh’s original paper, and ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("I did something similar")]#text(" in the special case of linear commuting averages.) This uniformity ultimately comes from the fact that in the above theorem, the polynomial sequences ")#mi("{g_1,\\ldots,g_k}")#text(" are allowed to have nonstandard coefficients, rather than just standard ones (and the space ")#mi("{({\\mathcal A},\\tau)}")#text(" is a general nonstandard space, rather than an ultrapower).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Since the original appearance of this post, it was essentially observed in ")#link("http://arxiv.org/abs/1301.3063")[#text("this preprint of Avigad and Iovino")]#text(" that the original result in Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" implies the special case of Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" in the case when the polynomials ")#mi("{g_1,\\ldots,g_k}")#text(" have standard coefficients, as one can use the standard part construction to project the nonstandard commutative probability space to a standard commutative probability space. As such, Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" automatically implies a metastable version of itself, in which the metastability bound is allowed to depend on the coefficients of the polynomials as well as the degree. The result in Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" is then apparently stronger because the metastability bound obtained in the finitary setting is also uniform in the choice of coefficients of the polynomials; however, by lifting the group ")#mi("{G}")#text(" to a higher rank nilpotent group, one can replace the action of any finite number of polynomials with unbounded coefficients with lifted polynomials with bounded coefficients (this trick dates back to the ")#link("http://www.ams.org/mathscinet-getitem?mr=603625")[#text("book of Furstenberg")]#text(") and so it turns out that Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" is ultimately equivalent to Theorem ")#link(<tao-c61530c9251ac6d247f9>)[#text("4")]#text(" (and also Theorem ")#link(<tao-c20d77a59fc6abfae8f2>)[#text("3")]#text(", using the structural theory of commutative probability spaces).")
]

#text("From the definition of external Cauchy convergence, it is clear that if ")#mi("{(x_n)_{n \\in {}^* {\\bf N}}}")#text(", ")#mi("{(y_n)_{n \\in {}^* {\\bf N}}}")#text(" are two externally Cauchy convergent sequences of (nonstandard) reals, then their sum is also externally Cauchy convergent, and more generally any (standard) finite linear combination (with standard real coefficients) of externally Cauchy convergent sequences of nonstandard reals is also externally Cauchy convergent. A key property for us is that external Cauchy convergence is also preserved by ")#emph[#text("hyperfinite")]#text(" averages involving a nonstandardly finite number of sequences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Metastable dominated convergence theorem)")]#text(" ")#metadata(none) <tao-38a897c7315f8a83c63e>#text(" Let ")#mi("{A}")#text(" be a non-empty nonstandard finite set (i.e. the ultraproduct of standard finite sets), and let ")#mi("{( x_{n,\\alpha} )_{n \\in {}^* {\\bf N}; \\alpha \\in A}}")#text(" be an internal family of internal sequences ")#mi("{(x_{n,\\alpha})_{n \\in {}^* {\\bf N}}}")#text(" of bounded elements of a nonstandard normed vector space. If the sequences ")#mi("{(x_{n,\\alpha})_{n \\in {}^* {\\bf N}}}")#text(" are externally Cauchy convergent for each ")#mi("{\\alpha \\in A}")#text(", then the (nonstandardly) averaged sequence ")#mi("{( \\mathop{\\bf E}_{\\alpha \\in A} x_{n,\\alpha} )_{n \\in {}^* {\\bf N}}}")#text(" is also externally Cauchy convergent.")
]

#text("This is an infinitary version of the finitary metastable dominated convergence theorem that first appeared in ")#link("https://terrytao.wordpress.com/2007/07/10/norm-convergence-of-multiple-ergodic-averages-for-commuting-transformations/")[#text("this paper of mine")]#text(", which roughly speaking claims that the average of uniformly metastable bounded sequences is again metastable. The proof was infinitary (deducing it from the Lebesgue dominated convergence theorem), and we will take a similar approach here. The argument was eventually finitised (and strengthened) in ")#link("http://arxiv.org/abs/1108.4400")[#text("this paper of Avigad, Dean, and Rute")]#text(", but the finitary argument is surprisingly non-trivial.")

#emph[#text("Proof:")]#text(" As each ")#mi("{x_{n,\\alpha}}")#text(" is individually bounded (i.e. smaller in norm than any unbounded natural number), and depends internally on ")#mi("{n,\\alpha}")#text(", we see from overspill that there is a uniform bound ")#tao-math("{\\left\\|x_{n,\\alpha}\\right\\| \\leq C}", block: false)#text(" for some ")#emph[#text("standard")]#text(" natural number ")#mi("{C}")#text(".")

#text("For each standard ")#mi("{\\epsilon>0}")#text(" and standard natural number ")#mi("{N}")#text(", let ")#mi("{E_{\\epsilon,N}}")#text(" denote the subset of ")#mi("{A}")#text(" given by the formula")

#align(center)[#tao-fit-display[#tao-math("E_{\\epsilon,N} := \\{ \\alpha \\in A: \\left\\|x_{n,\\alpha}-x_{m,\\alpha}\\right\\| \\leq \\epsilon \\text{ for all } n,m \\geq N \\}.", block: true)]]

#text("These sets are not internal subsets of ")#mi("{A}")#text(", but are instead ")#mi("{\\bigwedge}")#text("-internal (i.e. countable intersections of internal sets). In particular, they are still ")#emph[#text("Loeb measurable")]#text(" subsets of ")#mi("{A}")#text(" and thus have a well-defined Loeb measure ")#mi("{\\mu_A(E_{\\epsilon,N})}")#text(".")

#text("By hypothesis, we see that for any fixed ")#mi("{\\epsilon}")#text(", the ")#mi("{E_{\\epsilon,N}}")#text(" increase to ")#mi("{A}")#text(" in the sense that ")#mi("{E_{\\epsilon,N} \\subset E_{\\epsilon,N+1}}")#text(" and ")#mi("{A = \\bigcup_N E_{\\epsilon,N}}")#text(". By monotone convergence, we conclude that there exists a standard ")#mi("{N}")#text(" such that ")#mi("{\\mu_A(E_{\\epsilon,N}) \\geq 1-\\epsilon}")#text(". We then have for ")#mi("{n,m \\geq N}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\left\\|\\mathop{\\bf E}_{\\alpha \\in A} x_{n,\\alpha} - \\mathop{\\bf E}_{\\alpha \\in A} x_{m,\\alpha}\\right\\|  & \\leq \\mathop{\\bf E}_{\\alpha \\in A} \\left\\| x_{n,\\alpha} - x_{m,\\alpha} \\right\\|", block: true)



#tao-math(" & = \\int_A \\text{st} \\|x_{n,\\alpha} - x_{m,\\alpha}\\|\\ d\\mu_A(\\alpha)", block: true)



#tao-math(" & \\leq \\int_{E_{\\epsilon,N}} \\epsilon\\ d\\mu_A(\\alpha) + \\int_{A \\backslash E_{\\epsilon,N}} 2C\\ d\\mu_A(\\alpha)", block: true)



#tao-math(" & \\leq (2C+1) \\epsilon.", block: true)
]

#text("As ")#mi("{\\epsilon}")#text(" can be arbitrarily small, this gives the external Cauchy convergence of ")#mi("{\\mathop{\\bf E}_{\\alpha \\in A} x_{n,\\alpha}}")#text(" as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" This proof is significantly shorter than the finitary proof of Avigad, Dean, and Rute, but the complexity has been concealed in the construction of Loeb measure and the monotone convergence theorem. This is typically how nonstandard analysis arguments work; they are unable to magically make the “hard” component of an argument disappear entirely, but they are often able to efficiently conceal such components in fundamental building blocks which are of independent interest, and which can be usefully applied as a black box to a wide spectrum of problems. (In contrast, a hard argument in a finitary argument often needs to be reworked each time one wishes to apply it to a new problem.)")
]

#heading(level: 1)[#strong[#text(" — 2. A simple case: the von Neumann ergodic theorem — ")]]

#text("Before we prove Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(", let us first warm up by establishing an easy case, namely the nonstandard version of the von Neumann ergodic theorem (Theorem ")#link(<tao-02844e96939fa2ca9bf4>)[#text("2")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Nonstandard von Neumann mean ergodic theorem)")]#text(" ")#metadata(none) <tao-aebb1e91eed56ecc8109>#text(" Let ")#mi("{H}")#text(" be a nonstandard inner product space (i.e. the ultraproduct of standard inner product spaces), and let ")#mi("{U: H \\rightarrow H}")#text(" be a be a nonstandard unitary operator on ")#mi("{H}")#text(". Then for any bounded ")#mi("{f \\in H}")#text(", the averages ")#mi("{A_N(f) := \\frac{1}{N} \\sum_{n=1}^N U^n f}")#text(" are externally Cauchy in ")#mi("{N}")#text(".")
]

#text("We first observe that if one takes the bounded elements of ")#mi("{H}")#text(" and forms the Hilbert space completion using the standard norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{\\text{st}(H)} := \\text{st} \\left\\|f\\right\\|_H,", block: true)]]

#text("one obtains a Hilbert space ")#mi("{\\overline{H}}")#text(". Thanks to the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A_N(f) \\right\\|_{\\text{st}(H)} \\leq \\left\\|f \\right\\|_{\\text{st}(H)}", block: true)]]

#text("for all bounded ")#mi("{f}")#text(" in ")#mi("{H}")#text(", we see that these ergodic averages can be defined in ")#mi("{\\text{st}(H)}")#text(", and so it suffices to show that the averages ")#mi("{A_N(f)}")#text(" are externally Cauchy in ")#mi("{\\text{st}(H)}")#text(" for all ")#mi("{f \\in \\text{st}(H)}")#text(".")

#text("Let us first investigate a condition that would force ")#mi("{A_{N}(f)}")#text(" to be ")#emph[#text("asymptotically stable")]#text(" in ")#mi("{\\text{st}(H)}")#text(". We expand out")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A_{N}(f)\\right\\|_{\\text{st}(H)}^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\text{st} \\langle \\frac{1}{N} \\sum_{n=1}^N A_N(f), U^n f \\rangle_H")]]

#text("(where all expressions have been extended to nonstandard values of ")#mi("{n}")#text(" or ")#mi("{N}")#text(" in the usual fashion, and operations are extended from the bounded elements of ")#mi("{H}")#text(" to ")#mi("{\\text{st}(H)}")#text(" by continuity). With a little bit of rearrangement, this expression can be rewritten as ")#mi("{\\langle f, D_N(A_N(f)) \\rangle_{\\text{st} H}}")#text(", where the ")#emph[#text("dual function")]#text(" ")#mi("{D_N(f_0) = D_{N,f}(f_0) \\in \\overline{L^2(\\tau)}}")#text(" for any ")#mi("{f_0 \\in \\text{st}(H)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("D_N(f_0) := \\frac{1}{N} \\sum_{n=1}^N U^{-n} f_0.")]]

#text("(The terminology of dual functions originates from ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("this paper of Ben Green and myself")]#text(".) Thus, if we let ")#mi("{Z}")#text(" be the linear span in ")#mi("{\\text{st}(H)}")#text(" of all functions of the form ")#mi("{D_N(f_0)}")#text(" with ")#mi("{N}")#text(" unbounded and ")#mi("{f_0 \\in \\text{st}(H)}")#text(", and ")#mi("{f}")#text(" is orthogonal to ")#mi("{Z}")#text(", then ")#mi("{A_N(f)}")#text(" vanishes in ")#mi("{\\text{st}(H)}")#text(" for any unbounded ")#mi("{N}")#text(". This makes ")#mi("{A_{N}(f)}")#text(" asymptotically stable, and thus externally Cauchy, in ")#mi("{\\text{st}(H)}")#text(" norm.")

#text("In view of this fact, the existence of an orthogonal projection to the closure of ")#mi("{Z}")#text(", and the linearity of ")#mi("{A_{N}(f)}")#text(" in ")#mi("{f}")#text(", it suffices to show that for any ")#mi("{f}")#text(" in the closure of ")#mi("{Z}")#text(" in ")#mi("{\\text{st}(H)}")#text(", the expression ")#mi("{A_N(f)}")#text(" is eventually Cauchy in ")#mi("{\\text{st}(H)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" This step used the existence of orthogonal projections from a Hilbert space to a closed subspace, and is closely related to an analogous use of such projections in the textbook proof of Theorem ")#link(<tao-02844e96939fa2ca9bf4>)[#text("2")]#text(" (see e.g. the proof of Theorem 2 in ")#link("https://terrytao.wordpress.com/2008/01/30/254a-lecture-8-the-mean-ergodic-theorem/")[#text("these blog notes")]#text("). In the finitary argument of Walsh, one uses instead a decomposition ")#link("http://arxiv.org/abs/0811.3103")[#text("established by Gowers")]#text(" using the Hahn-Banach theorem as a substitute for orthogonal projections. See also the “Hilbert space finite convergence principle” from ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("this blog post")]#text(" for a closely related link between orthogonal projections and quantitative decompositions.")
]

#text("Having eliminated the “pseudorandom case” when ")#mi("{f}")#text(" is orthogonal to ")#mi("{Z}")#text(", we have now reduced to the “structured case” when ")#mi("{f}")#text(" lies in the closure of ")#mi("{Z}")#text(". By linearity and an approximation argument, we may reduce to the case when ")#mi("{f}")#text(" is just a projection ")#mi("{f = D_{N_0}(f_0)}")#text(" of a single dual function ")#mi("{D_{N_0}(f_0)}")#text(" for some ")#mi("{f_0 \\in \\text{st}(H)}")#text(" and unbounded ")#mi("{N_0}")#text(", and by a further density and approximation argument we can assume that ")#mi("{f_0}")#text(" is a bounded element of ")#mi("{H}")#text(", rather than a general element of ")#mi("{\\text{st}(H)}")#text(". (Incidentally, the non-standard analysis formalism is painlessly skipping over a certain amount of epsilon management here which is much more visible in the finitary version of the argument.) Thus, our task is now to show that the expression ")#mi("{A_{N}(D_{N_0}(f_0))}")#text(" is externally Cauchy in ")#mi("{H}")#text(".")

#text("We expand")

#align(center)[#tao-fit-display[#mitex("A_N( D_{N_0}(f_0) ) = \\frac{1}{N} \\sum_{n=1}^N \\frac{1}{N_0} \\sum_{n^{\\prime}=1}^{N_0} U^{n-n^{\\prime}} f_0.")]]

#text("Fixing ")#mi("{N_0}")#text(", we now restrict to the regime ")#mi("{N=o(N_0)}")#text(", thus ")#mi("{N \\leq \\epsilon N_0}")#text(" for all standard ")#mi("{\\epsilon>0}")#text(". Then ")#mi("{n = o(N_0)}")#text(" as well. We can then shift the range ")#mi("{\\{1,\\ldots,N_0\\}}")#text(" by ")#mi("{n}")#text(" by making a substitution ")#mi("{n^{\\prime} := n+m}")#text(". If we then return ")#mi("{m}")#text(" to the range ")#mi("{\\{1,\\ldots,N_0\\}}")#text(", this creates an error of ")#mi("{\\text{st}(H)}")#text(" norm ")#mi("{\\text{st} O( n / N_0 ) = 0}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("A_N( D_{N_0}(f_0) ) = \\frac{1}{N} \\sum_{n=1}^N \\frac{1}{N_0} \\sum_{m=1}^{N_0} U^{-m} f_0 = D_{N_0}(f_0)")]]

#text("in ")#mi("{\\text{st}(H)}")#text(" for all ")#mi("{N = o(N_0)}")#text(". In particular, ")#mi("{A_N( D_{N_0}(f_0) )}")#text(" is asymptotically stable up to ")#mi("{o(N_0)}")#text(", and thus externally Cauchy as required.")

#heading(level: 1)[#strong[#text(" — 3. Descent — ")]]

#text("Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" is proven by an induction on the “complexity” of the ")#mi("{g_1,\\ldots,g_k}")#text(". Fix ")#mi("{({\\mathcal A},\\tau)}")#text(" and the action of the nilpotent nonstandard group ")#mi("{G}")#text(". Given any finite tuple ")#mi("{\\vec g := (g_1,\\ldots,g_k)}")#text(" of internal functions from ")#mi("{{}^* {\\bf Z}}")#text(" to ")#mi("{G}")#text(" (not necessarily polynomials), let us say that ")#mi("{\\vec g}")#text(" is ")#emph[#text("good")]#text(" if the conclusion of Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" holds, thus the averages ")#mi("{\\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)}")#text(" form an external Cauchy sequence in ")#mi("{L^2(\\tau)}")#text(" for all bounded ")#mi("{f_1,\\ldots,f_k \\in {\\mathcal A}}")#text(". Trivially, any permutation of a good tuple is good, and any tuple that consists entirely of copies of the constant function ")#mi("{1_G}")#text(" mapping ")#mi("{{\\bf Z}}")#text(" to the group identity ")#mi("{1_G}")#text(" of ")#mi("{G}")#text(" is good. Furthermore, if ")#mi("{\\vec g}")#text(" is a finite tuple, and ")#mi("{\\vec g^{\\prime}}")#text(" is obtained from ")#mi("{\\vec g}")#text(" by removing duplicate functions (e.g. converting ")#mi("{(g_1,g_2,g_1,g_2,g_3)}")#text(" into ")#mi("{(g_1,g_2,g_3)}")#text(") and also removing all copies of ")#mi("{1_G}")#text(", then ")#mi("{\\vec g}")#text(" is good if and only if ")#mi("{\\vec g^{\\prime}}")#text(" is good.")

#text("If the tuple ")#mi("{\\vec g = (g_1,\\ldots,g_k)}")#text(" is non-empty (i.e. ")#mi("{k \\geq 1}")#text("), then for any standard integer ")#mi("{m}")#text(", we define the ")#emph[#mi("{m}")#text("-reduction")]#text(" ")#mi("{\\vec g^*_m}")#text(" of ")#mi("{\\vec g}")#text(" to be the tuple consisting of the functions ")#mi("{g_1,\\ldots,g_{k-1}}")#text(", together with the function")

#align(center)[#tao-fit-display[#mitex("n \\mapsto g_k(n) g_k(n+m)^{-1}")]]

#text("and the functions")

#align(center)[#tao-fit-display[#mitex("n \\mapsto g_k(n) g_k(n+m)^{-1} g_i(n+m)")]]

#text("for ")#mi("{i=1,\\ldots,k-1}")#text(". (We will see why these particular functions arise in the argument shortly.) The key step in proving Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" is then the following result, reminiscent of the van der Corput lemma in ergodic theory (see e.g. ")#link("https://terrytao.wordpress.com/2008/06/14/the-van-der-corputs-trick-and-equidistribution-on-nilmanifolds/")[#text("this blog post")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Descent)")]#text(" ")#metadata(none) <tao-7b24c1ad239d4a6b2c73>#text(" Let ")#mi("{({\\mathcal A},\\tau)}")#text(" be a nonstandard commutative probability space, and let ")#mi("{G}")#text(" be a nonstandard group acting on ")#mi("{{\\mathcal A}}")#text(" by isomorphisms. Let ")#mi("{\\vec g}")#text(" be a non-empty finite tuple of internal functions from ")#mi("{{}^* {\\bf Z}}")#text(" to ")#mi("{G}")#text(". If ")#mi("{\\vec g^*_m}")#text(" is good for every nonstandard integer ")#mi("{m}")#text(", then ")#mi("{\\vec g}")#text(" is good.")
]

#text("Once one has this proposition, Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" will be an immediate consequence of the following combinatorial claim (and the remarks made at the beginning of this section).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (PET induction)")]#text(" ")#metadata(none) <tao-bbba57318f71911354fd>#text(" Let ")#mi("{G}")#text(" be a nilpotent nonstandard group. Then there exists a well-ordered set ")#mi("{W}")#text(" and a way to assign to each finite tuple ")#mi("{\\vec g}")#text(" of polynomial nonstandard functions from ")#mi("{{}^* {\\bf Z}}")#text(" to a nilpotent nonstandard group ")#mi("{G}")#text(" a tuple ")#mi("{\\tilde \\vec g}")#text(" which is a permutation of ")#mi("{\\vec g}")#text(" after all duplicates and copies of ")#mi("{1_G}")#text(" have been removed, and a ")#emph[#text("weight")]#text(" ")#mi("{w(\\vec g)}")#text(" in ")#mi("{W}")#text(", with the following property: if ")#mi("{\\tilde \\vec g}")#text(" is non-empty, and ")#mi("{m}")#text(" is an nonstandard integer, then there is a permutation of ")#mi("{(\\tilde \\vec g)^*_m}")#text(" which has a strictly smaller weight than that of ")#mi("{\\vec g}")#text(".")
]

#text("Indeed, once one has this proposition and Proposition ")#link(<tao-7b24c1ad239d4a6b2c73>)[#text("11")]#text(", Theorem ")#link(<tao-5f44cacdb7e2c1316694>)[#text("8")]#text(" follows by strong induction on the weight ")#mi("{w(\\vec g)}")#text(".")

#text("We prove Proposition ")#link(<tao-7b24c1ad239d4a6b2c73>)[#text("11")]#text(" in this section, and Proposition ")#link(<tao-bbba57318f71911354fd>)[#text("12")]#text(" in the next section.")

#text("The proof of Proposition ")#link(<tao-7b24c1ad239d4a6b2c73>)[#text("11")]#text(" closely mimics the proof of Theorem ")#link(<tao-aebb1e91eed56ecc8109>)[#text("10")]#text(". Fix ")#mi("{({\\mathcal A},\\tau)}")#text(", ")#mi("{G}")#text(", the tuple ")#mi("{\\vec g = (g_1,\\ldots,g_k)}")#text(", and bounded elements ")#mi("{f_1,\\ldots,f_k \\in {\\mathcal A}}")#text(", and assume that ")#mi("{\\vec g^*_m}")#text(" is good for all standard integers ")#mi("{m}")#text(". We consider the averages ")#metadata(none) <tao-30804615d55e104f9790>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A_{\\vec g,N}(f_1,\\ldots,f_k) := \\frac{1}{N} \\sum_{n=1}^N (g_1(n) f_1) \\ldots (g_k(n) f_k)")]]

#text("and our task is to show that the ")#mi("{A_N(f_1,\\ldots,f_k)}")#text(" form an external Cauchy sequence in ")#mi("{L^2(\\tau)}")#text(".")

#text("We fix bounded elements ")#mi("{f_1,\\ldots,f_{k-1} \\in {\\mathcal A}}")#text(", and largely work with manipulation of ")#mi("{f_k}")#text(". The map ")#mi("{f_k \\mapsto A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" is then an operator from ")#mi("{{\\mathcal A}}")#text(" to ")#mi("{{\\mathcal A}}")#text(". We have the easily verified bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A_{\\vec g,N}(f_1,\\ldots,f_k)\\right\\|_{L^2(\\tau)} \\leq \\rho(f_1) \\ldots \\rho(f_{k-1}) \\left\\|f_k\\right\\|_{L^2(\\tau)}.", block: true)]]

#text("Because of this, the linear operator ")#mi("{f_k \\mapsto A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" can be uniquely continuously extended to a linear operator from ")#mi("{\\text{st} L^2(\\tau)}")#text(" to ")#mi("{\\text{st} L^2(\\tau)}")#text(", where ")#mi("{\\text{st} L^2(\\tau)}")#text(" is defined as the Hilbert space completion of the bounded elements of ")#mi("{{\\mathcal A}}")#text(" under the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\text{st} L^2(\\tau)} := \\text{st} \\left\\|f\\right\\|_{L^2(\\tau)} = \\text{st} \\tau( ff^* )^{1/2}.", block: true)]]

#text("In particular ")#mi("{\\text{st} L^2(\\tau)}")#text(" quotients out all the elements of infinitesimal norm. In this Hilbertian formalism, the problem can now be viewed as one of establishing a weighted variant of Theorem ")#link(<tao-aebb1e91eed56ecc8109>)[#text("10")]#text(".")

#text("Let us first investigate a condition that would force ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" to be be asymptotically stable in ")#mi("{\\text{st} L^2(\\tau)}")#text(". We expand out")

#align(center)[#tao-fit-display[#tao-math("\\left\\|A_{\\vec g,N}(f_1,\\ldots,f_k)\\right\\|_{\\text{st} L^2(\\tau)}^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("= \\text{st} \\tau( \\frac{1}{N} \\sum_{n=1}^N A_{\\vec g,N}(f_1,\\ldots,f_k) (g_1(n) f_1) \\ldots (g_k(n) f_k) )")]]

#text("(where all expressions have been extended to nonstandard values of ")#mi("{n}")#text(" or ")#mi("{N}")#text(" in the usual fashion, and operations are extended from the bounded elements of ")#mi("{{\\mathcal A}}")#text(" to ")#mi("{\\text{st} L^2(\\tau)}")#text(" by continuity). With a little bit of rearrangement, this expression can be rewritten as ")#mi("{\\langle f_k, D_N(A_{\\vec g,N}(f_1,\\ldots,f_k)) \\rangle_{\\text{st} L^2(\\tau)}}")#text(", where the ")#emph[#text("dual function")]#text(" ")#mi("{D_N(f_0) = D_{N,f_1,\\ldots,f_{k-1},\\vec g}(f_0) \\in \\overline{L^2(\\tau)}}")#text(" for any ")#mi("{f_0 \\in \\text{st} L^2(\\tau)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("D_N(f_0) := \\frac{1}{N} \\sum_{n=1}^N (g_k(n)^{-1} f_0) (g_k(n)^{-1} g_1(n) f_1) \\ldots (g_k(n)^{-1} g_{k-1}(n) f_{k-1}).")]]

#text("Thus, if we let ")#mi("{Z}")#text(" be the linear span in ")#mi("{\\text{st} L^2(\\tau)}")#text(" of all functions of the form ")#mi("{D_N(f_0)}")#text(" with ")#mi("{N}")#text(" unbounded and ")#mi("{f_0 \\in \\text{st} L^2(\\tau)}")#text(", and ")#mi("{f_k}")#text(" is orthogonal to ")#mi("{Z}")#text(", then ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" vanishes in ")#mi("{\\text{st} L^2(\\tau)}")#text(" for any unbounded ")#mi("{N}")#text(". This makes ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" asymptotically stable, and thus externally Cauchy, in ")#mi("{L^2(\\tau)}")#text(" norm.")

#text("In view of this fact, the existence of an orthogonal projection to the closure of ")#mi("{Z}")#text(", and the linearity of ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" in ")#mi("{f_k}")#text(", it suffices to show that for any ")#mi("{f_k}")#text(" in the closure of ")#mi("{Z}")#text(" in ")#mi("{\\text{st} L^2(\\tau)}")#text(", the expression ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_k)}")#text(" is eventually Cauchy in ")#mi("{L^2(\\tau)}")#text(".")

#text("Having eliminated the “pseudorandom case” when ")#mi("{f_k}")#text(" is orthogonal to ")#mi("{Z}")#text(", we have now reduced to the “structured case” when ")#mi("{f_k}")#text(" lies in the closure of ")#mi("{Z}")#text(". By linearity and an approximation argument, we may reduce to the case when ")#mi("{f_k}")#text(" is just a projection ")#mi("{f_k = D_{N_0}(f_0)}")#text(" of a single dual function ")#mi("{D_{N_0}(f_0)}")#text(" for some ")#mi("{f_0 \\in \\text{st} L^2(\\tau)}")#text(" and unbounded ")#mi("{N_0}")#text(", and by a further density and approximation argument we can assume that ")#mi("{f_0}")#text(" is a bounded element of ")#mi("{{\\mathcal A}}")#text(", rather than a general element of ")#mi("{\\text{st} L^2(\\tau)}")#text(".")

#text("Inspecting the definition ")#link(<tao-30804615d55e104f9790>)[#text("(1)")]#text(" of ")#mi("{A_{\\vec g,N}}")#text(", we see that we need to understand the shifts ")#mi("{g_k(n) D_{N_0}(f_0)}")#text(" for ")#mi("{1 \\leq n \\leq N}")#text(". It is here that we perform the “van der Corput” or “Weyl differencing” calculation that is pervasive in multiple recurrence theory. Namely, we expand")

#align(center)[#tao-fit-display[#mitex("g_k(n) D_{N_0}(f_0) = \\frac{1}{N_0} \\sum_{n^{\\prime}=1}^{N_0} (g_k(n) g_k(n^{\\prime})^{-1} f_0) (g_k(n) g_k(n^{\\prime})^{-1} g_1(n^{\\prime}) f_1) \\ldots")]]

#align(center)[#tao-fit-display[#mitex("\\ldots (g_k(n) g_k(n^{\\prime})^{-1} g_{k-1}(n^{\\prime}) f_{k-1}).")]]

#text("Fixing ")#mi("{N_0}")#text(", we now restrict to the regime ")#mi("{N=o(N_0)}")#text(", thus ")#mi("{N \\leq \\epsilon N_0}")#text(" for all standard ")#mi("{\\epsilon>0}")#text(". Then ")#mi("{n = o(N_0)}")#text(" as well. We can then shift the range ")#mi("{\\{1,\\ldots,N_0\\}}")#text(" by ")#mi("{n}")#text(" by making a substitution ")#mi("{n^{\\prime} := n+m}")#text(". If we then return ")#mi("{m}")#text(" to the range ")#mi("{\\{1,\\ldots,N_0\\}}")#text(", this creates an error of ")#mi("{\\text{st} L^2(\\tau)}")#text(" norm ")#mi("{\\text{st} O( n / N_0 ) = 0}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("g_k(n) D_{N_0}(f_0) = \\frac{1}{N_0} \\sum_{m=1}^{N_0} (g_k(n) g_k(n+m)^{-1} f_0)")]]

#align(center)[#tao-fit-display[#mitex("(g_k(n) g_k(n+m)^{-1} g_1(n+m) f_1) \\ldots")]]

#align(center)[#tao-fit-display[#mitex("\\ldots (g_k(n) g_k(n+m)^{-1} g_{k-1}(n+m) f_{k-1})")]]

#text("(with both sides being interpreted in ")#mi("{\\text{st} L^2(\\tau)}")#text("). (In the language of Walsh’s paper, this identity asserts that dual functions are ")#emph[#text("reducible")]#text(".) Substituting this into ")#link(<tao-30804615d55e104f9790>)[#text("(1)")]#text(", and recalling the definition of the tuples ")#mi("{\\vec g^*_k}")#text(", we thus obtain the “Weyl differencing identity” ")#metadata(none) <tao-998bbe0079ba3b05f99b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A_{\\vec g,N}(f_1,\\ldots,f_{k-1},D_{N_0}(f_0))")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{N_0} \\sum_{m=1}^{N_0} A_{\\vec g^*_m,N}( f_1,\\ldots,f_{k-1}, f_0, f_1, \\ldots, f_{k-1} )")]]

#text("in ")#mi("{\\text{st} L^2(\\tau)}")#text(" whenever ")#mi("{N = o(N_0)}")#text(". In particular, since the property of being externally Cauchy is unaffected by truncation to ")#mi("{n<N_1}")#text(" for any unbounded ")#mi("{N_1}")#text(" (and in particular to an unbounded ")#mi("{N_1=o(N_0)}")#text("), we see that the left-hand side of ")#link(<tao-998bbe0079ba3b05f99b>)[#text("(2)")]#text(" is externally Cauchy in ")#mi("{L^2(\\tau)}")#text(" if and only if the right-hand side is. But by the induction hypothesis, each of the sequences ")#mi("{A_{\\vec g^*_m,N}( f_1,\\ldots,f_{k-1}, f_0, f_1, \\ldots, f_{k-1} )}")#text(" is externally Cauchy in ")#mi("{L^2(\\tau)}")#text(", and from Proposition ")#link(<tao-38a897c7315f8a83c63e>)[#text("9")]#text(" we see that ")#mi("{A_{\\vec g,N}(f_1,\\ldots,f_{k-1},D_{N_0}(f_0))}")#text(" is externally Cauchy in ")#mi("{L^2(\\tau)}")#text(", and Proposition ")#link(<tao-7b24c1ad239d4a6b2c73>)[#text("11")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 4. PET induction — ")]]

#text("Now we prove Proposition ")#link(<tao-bbba57318f71911354fd>)[#text("12")]#text(", which will follow the general PET induction method first introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=912373")[#text("by Bergelson")]#text(". We prove the claim first for abelian groups (where there is an obvious notion of the “degree” of a polynomial sequence), and indicate at the end of the section how to modify the argument to handle nilpotent groups.")

#text("Henceforth the nonstandard abelian group ")#mi("{G}")#text(" is fixed. In the abelian case, we can take ")#mi("{W}")#text(" to be the well-ordered set ")#mi("{\\omega^\\omega}")#text(" of tuples ")#mi("{(a_0,a_1,\\ldots)}")#text(" of standard non-negative integers with only finitely many of the ")#mi("{a_i}")#text(" non-zero, with the reverse lexicographical ordering, thus ")#mi("{(a_0,a_1,\\ldots) < (b_0,b_1,\\ldots)}")#text(" if there exists ")#mi("{n}")#text(" such that ")#mi("{a_n<b_n}")#text(" and ")#mi("{a_m=b_m}")#text(" for all ")#mi("{m>n}")#text(".")

#text("It is easy to see that any polynomial nonstandard function ")#mi("{g: {}^* {\\bf Z} \\rightarrow G}")#text(" can be uniquely expressed in the discrete Taylor expansion form")

#align(center)[#tao-fit-display[#mitex("g(n) = g_0 g_1^n g_2^{\\binom{n}{2}} \\ldots g_d^{\\binom{n}{d}}")]]

#text("for some finite number of group elements ")#mi("{g_0,\\ldots,g_d}")#text(" with ")#mi("{g_d}")#text(" non-trivial (or with ")#mi("{d=-\\infty}")#text(" if ")#mi("{g}")#text(" is trivial). We call ")#mi("{d}")#text(" the ")#emph[#text("degree")]#text(" of ")#mi("{g}")#text("; in the case that ")#mi("{G}")#text(" is the nonstandard integers ")#mi("{{}^* {\\bf N}}")#text(" with the additive group operation, this corresponds to the usual notion of the degree of a polynomial.")

#text("We observe the ultratriangle inequality ")#metadata(none) <tao-8a2e8c703f4e87042862>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{deg}(g_1 g_2) \\leq \\max( \\text{deg}(g_1), \\text{deg}(g_2) )")]]

#text("with the inequality being equality if ")#mi("{g_1,g_2}")#text(" have different degree; we also have the symmetry property ")#metadata(none) <tao-0599b22abfb1eb4db9c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\text{deg}(g^{-1}) = \\text{deg}(g).")]]

#text("Also, we observe the key fact that if ")#mi("{g}")#text(" is a non-trivial polynomial sequence, then for any ")#mi("{h \\in {}^* {\\bf Z}}")#text(", the derivative ")#mi("{\\partial_h g: {}^* {\\bf Z} \\rightarrow G}")#text(" defined by ")#mi("{\\partial_h g(n) := g(n) g(n+h)^{-1}}")#text(" is a polynomial sequence of strictly smaller degree.")

#text("We can now place an ")#link("http://en.wikipedia.org/wiki/Ultrametric_space")[#text("ultrametric")]#text(" on ")#mi("{{\\mathcal P}}")#text(", with the distance between two polynomials ")#mi("{g_1,g_2}")#text(" defined as ")#metadata(none) <tao-2b76f5da400249b3c1ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("d(g_1,g_2) := 2^{\\text{deg}(g_1^{-1} g_2)},")]]

#text("with the convention that ")#mi("{2^{-\\infty} = 0}")#text(". One easily verifies that the ultrametric axioms are obeyed.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-324bb56ef283edb7fa79>#text(" If ")#mi("{G={}^* {\\bf Z}}")#text(", and we consider the four polynomials ")#mi("{g_0(n) := 0}")#text(", ")#mi("{g_1(n) := 1}")#text(", ")#mi("{g_2(n) := n}")#text(", ")#mi("{g_3(n) := n^2}")#text(", then ")#mi("{g_3}")#text(" is separated from ")#mi("{g_0,g_1,g_2}")#text(" by a distance of ")#mi("{4}")#text(", ")#mi("{g_2}")#text(" is separated from ")#mi("{g_0,g_1}")#text(" by a distance of ")#mi("{2}")#text(", and ")#mi("{g_0,g_1}")#text(" are separated from each other by a distance of ")#mi("{1}")#text(".")
]

#text("Now let ")#mi("{(g_0,g_1,g_2,\\ldots,g_k)}")#text(" be a finite tuple of polynomials in ")#mi("{{\\mathcal P}}")#text(" for some ")#mi("{k \\geq 0}")#text(". Selecting a reference polynomial ")#mi("{g_*}")#text(" (not necessarily in the tuple), we say that two polynomials ")#mi("{g_a,g_b}")#text(" are ")#emph[#text("equivalent")]#text(" relative to ")#mi("{g_*}")#text(" if ")#mi("{d(g_a,g_b) \\leq d(g_a,g_*)/2}")#text(". From the ultrametric property we see that this is an equivalence relation, and each equivalence class is a constant distance from ")#mi("{g_*}")#text(". We can then define the ")#emph[#text("weight function")]#text(" ")#mi("{w = w_{g_0,\\ldots,g_k; g_*} \\in W}")#text(" of the tuple ")#mi("{(g_0,\\ldots,g_k)}")#text(" relative to ")#mi("{g_*}")#text(" to equal ")#mi("{(a_0,a_1,\\ldots)}")#text(", where ")#mi("{a_d}")#text(" is the number of equivalence classes that have distance exactly ")#mi("{2^d}")#text(" from ")#mi("{g_i}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Let ")#mi("{g_0,g_1,g_2,g_3}")#text(" be as in Example ")#link(<tao-324bb56ef283edb7fa79>)[#text("1")]#text(". Relative to ")#mi("{g_3}")#text(", ")#mi("{g_0,g_1,g_2}")#text(" are all equivalent and at distance ")#mi("{4}")#text(" from ")#mi("{g_3}")#text(", so the weight function here is ")#mi("{(0,0,1,0,\\ldots)}")#text(". Relative instead to ")#mi("{g_0}")#text(", none of the ")#mi("{g_1,g_2,g_3}")#text(" are equivalent, and at are distances ")#mi("{1,2,4}")#text(" from ")#mi("{g_0}")#text(", so the weight function here is ")#mi("{(1,1,1,0,\\ldots)}")#text(". For the tuple ")#mi("{0,n^2,2n^2}")#text(", the weight function relative to any one of these three polynomials is ")#mi("{(0,0,1,0,\\ldots)}")#text(".")
]

#text("Now let ")#mi("{\\vec g = (g_1,\\ldots,g_k)}")#text(" be a non-empty tuple of nonstandard polynomials. We form ")#mi("{\\tilde \\vec g = (\\tilde g_1,\\ldots,\\tilde g_{\\tilde k})}")#text(" by removing all duplicates and copies of ")#mi("{1_G}")#text(" from ")#mi("{\\vec g}")#text("(starting from the left and moving right), and if ")#mi("{\\tilde g_{\\tilde k}}")#text(" does not already have maximal degree amongst all the ")#mi("{\\tilde g_i}")#text(", permute the tuple ")#mi("{\\tilde \\vec g}")#text(" in some arbitrary fashion to make this the case. We define the weight ")#mi("{w(\\vec g)}")#text(" of ")#mi("{\\vec g}")#text(" to be the weight of the augmented tuple ")#mi("{(1_G, \\tilde g_1,\\ldots,\\tilde g_{\\tilde k})}")#text(" relative to the final element ")#mi("{\\tilde g_{\\tilde k}}")#text(" of the tuple:")

#align(center)[#tao-fit-display[#mitex("w(\\vec g) := w_{1_G,\\tilde g_1,\\ldots,\\tilde g_{\\tilde k}; \\tilde g_{\\tilde k}}.")]]

#text("Suppose ")#mi("{w(\\vec g) = (a_0,a_1,\\ldots)}")#text(", thus there are ")#mi("{a_d}")#text(" equivalence classes intersecting ")#mi("{1_G,\\tilde g_1,\\ldots,\\tilde g_{\\tilde k-1}}")#text(" that are at a distance exactly ")#mi("{2^d}")#text(" from ")#mi("{\\tilde g_{\\tilde k}}")#text(". We set ")#mi("{\\tilde g_0 := 1_G}")#text(".")

#text("Now let ")#mi("{m}")#text(" be a nonstandard integer, and consider the ")#mi("{m}")#text("-reduction")

#align(center)[#tao-fit-display[#mitex("\\vec \\tilde g^*_m = (\\tilde g_1,\\ldots,\\tilde g_{\\tilde k-1},g^{\\prime}_0,\\ldots,g^{\\prime}_{\\tilde k-1}),")]]

#text("where ")#mi("{g^{\\prime}_i(n) := \\tilde g_{\\tilde k}(n) \\tilde g_{\\tilde k}(n+m)^{-1} \\tilde g_i(n+m)}")#text(". We first consider the weight of the augmented tuple ")#metadata(none) <tao-0cf67fc72b3c86c7a454>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("(1_G, \\vec \\tilde g^*_m) = (\\tilde g_0,\\tilde g_1,\\ldots,\\tilde g_{\\tilde k-1},g^{\\prime}_0,\\ldots,g^{\\prime}_{\\tilde k-1})")]]

#text("relative to ")#mi("{\\tilde g_{\\tilde k}}")#text(". Observe that for any ")#mi("{j=0,\\ldots,\\tilde k-1}")#text(", one has")

#tao-aligned(keep: true)[


#tao-math("d(\\tilde g_j,g^{\\prime}_j)  & = 2^{\\text{deg}( \\tilde g_j(\\cdot)^{-1} \\tilde g_{\\tilde k}(\\cdot) \\tilde g_{\\tilde k}(\\cdot+m)^{-1} \\tilde g_j(\\cdot+m) )}", block: true)



#tao-math(" & = 2^{\\text{deg}( \\partial_m ( \\tilde g_j^{-1} \\tilde g_{\\tilde k} ) )}", block: true)



#tao-math(" & < 2^{\\text{deg}( \\tilde g_j^{-1} \\tilde g_{\\tilde k})}", block: true)



#tao-math(" & = d( \\tilde g_j, \\tilde g_{\\tilde k} );", block: true)
]

#text("thus, relative to ")#mi("{\\tilde g_{\\tilde k}}")#text(", ")#mi("{\\tilde g_j}")#text(" and ")#mi("{g_j}")#text(" are in the same equivalence class. As such, we see that the weight of the tuple ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(6)")]#text(" relative to ")#mi("{\\tilde g_{\\tilde k}}")#text(" is equal to ")#mi("{w(\\vec g)}")#text(", thus there are still ")#mi("{a_d}")#text(" equivalence classes intersecting the tuple ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(6)")]#text(" that are distance exactly ")#mi("{2^d}")#text(" from ")#mi("{\\tilde g_{\\tilde k}}")#text(". We remark for future reference that the abelian nature of ")#mi("{G}")#text(" was ")#emph[#text("not")]#text(" directly used in the above calculation.")

#text("Now let ")#mi("{g_*}")#text(" be the element of the tuple ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(6)")]#text(" which has the minimal distance ")#mi("{2^{d_*} = d(g_*,\\tilde g_{\\tilde k})}")#text(" to ")#mi("{\\tilde g_{\\tilde k}}")#text(", and has maximal degree. The two requirements are compatible, as any element of the tuple has degree less than that of ")#mi("{\\tilde g_{\\tilde k}}")#text(" (which has the maximal degree by construction) necessarily has the maximal distance to ")#mi("{\\tilde g_{\\tilde k}}")#text(". The weight of ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(6)")]#text(" relative to ")#mi("{g_*}")#text(" is then strictly smaller than the weight of ")#link(<tao-0cf67fc72b3c86c7a454>)[#text("(6)")]#text(" relative to ")#mi("{\\tilde g_{\\tilde k}}")#text(", because the weight function ")#mi("{a_{d_*}}")#text(" at ")#mi("{d_*}")#text(" is decreased by one, while the weight function at all values strictly greater than ")#mi("{d_*}")#text(" are unchanged. (The weight function at values less than ")#mi("{d_*}")#text(" can increase dramatically, but with the lexicographical ordering this does not change the validity of the previous assertion.) Because of this, if we then permute ")#mi("{\\vec \\tilde g^*_m}")#text(" to place ")#mi("{g_*}")#text(" at the end, then we see that ")#mi("{w(\\vec \\tilde g^*_m) < w(\\vec g)}")#text(" (note that removing duplicates and copies of ")#mi("{1_G}")#text(" from ")#mi("{\\vec \\tilde g^*_m}")#text(" only serves to decrease the weight vector, not to increase it), and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Suppose we start with the tuple ")#mi("{(n^2,2n^2)}")#text(", whose weight vector is ")#mi("{(0,0,2,0,\\ldots)}")#text(". Performing an ")#mi("{1}")#text("-reduction, we obtain")

#align(center)[#tao-fit-display[#mitex("(n^2, -4n-2, n^2-2n-1),")]]

#text("with a weight vector now reduced to ")#mi("{(0,1,1,0,\\ldots)}")#text(". Note that ")#mi("{n^2-2n-1}")#text(" already has maximal degree and has minimal distance to ")#mi("{2n^2}")#text(", so no additional permutation is needed at this stage. Performing another ")#mi("{1}")#text("-reduction, we obtain")

#align(center)[#tao-fit-display[#mitex("(n^2, -4n-2, -2n+1, n^2+2, -6n-5)")]]

#text("but now we need to permute to move ")#mi("{n^2+2}")#text(" (which has maximal degree and minimal distance to ")#mi("{n^2-2n-1}")#text(") to the end, giving")

#align(center)[#tao-fit-display[#mitex("(n^2, -4n-2, -2n+1, -6n-5, n^2+2)")]]

#text("with a weight vector now of ")#mi("{(1,0,1,0,\\ldots)}")#text(". Performing another ")#mi("{1}")#text("-reduction, we obtain")

#align(center)[#tao-fit-display[#mitex("(n^2, -4n-2, -2n+1, -6n-5, -2n-1, n^2, -6n-5, -4n-2)")]]

#text("which after eliminating duplicates and moving ")#mi("{n^2}")#text(" (which has maximal degree and minimal distance to ")#mi("{n^2+2}")#text(") to the end, gives")

#align(center)[#tao-fit-display[#mitex("(-4n-2, -2n+1, -6n-5, -2n-1, n^2)")]]

#text("with a weight vector of ")#mi("{(0,0,1,0,\\ldots)}")#text(". Another ")#mi("{1}")#text("-reduction then gives")

#align(center)[#tao-fit-display[#mitex("(-4n-2, -2n+1, -6n-5, -2n-1,")]]

#align(center)[#tao-fit-display[#mitex("-2n-1, -6n-5, -4n-2, -8n-12)")]]

#text("(note the elimination of all quadratic terms) which after eliminating duplicates becomes")

#align(center)[#tao-fit-display[#mitex("(-4n-2, -2n+1, -6n-5, -8n-12)")]]

#text("with a weight vector of ")#mi("{(0,4,0,\\ldots)}")#text(". Performing yet another ")#mi("{1}")#text("-reduction gives")

#align(center)[#tao-fit-display[#mitex("(-4n-2, -2n+1, -6n-5, -8, -4n-14, -2n-9, -6n-19)")]]

#text("with a weight vector of ")#mi("{(1,3,0,\\ldots)}")#text(". Continuing this process, we will see that the linear terms will eventually all be eliminated, leaving only the constant terms, which can then be eliminated one at a time using further reduction until only the empty tuple remains. See also ")#link("http://arxiv.org/abs/1109.2922")[#text("Walsh’s paper")]#text(" for several further examples of this reduction process, as well as some commentary on how the process can be speeded up somewhat if one observes that one can eliminate not only duplicate polynomials, but also polynomials which differ from an existing polynomial by a constant.")
]

#text("Finally, we address the case of a nilpotent group ")#mi("{G}")#text(", which will be a modification of the previous argument. The main issue is how to define degree properly. If ")#mi("{g: {}^* {\\bf Z} \\rightarrow G}")#text(" is a polynomial nonstandard sequence, then by many applications of (discrete analogues of) Baker-Campbell-Hausdorff formula, we can (as before) place ")#mi("{g}")#text(" uniquely in the Taylor expansion form ")#metadata(none) <tao-e08bc1b6a298dbd66d86>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("g(n) = g_0 g_1^n g_2^{\\binom{n}{2}} \\ldots g_d^{\\binom{n}{d}}")]]

#text("for some (standard) finite number ")#mi("{g_0,\\ldots,g_d}")#text(" of group elements of ")#mi("{G}")#text("; see e.g. Exercise 11 of ")#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/")[#text("this previous blog post")]#text(". In the abelian case, we used the largest ")#mi("{d}")#text(" for which ")#mi("{g_d}")#text(" was non-trivial as the degree of ")#mi("{g}")#text(". This turns out to not be a good choice in the nilpotent case, because the crucial ultratriangle property ")#link(<tao-8a2e8c703f4e87042862>)[#text("(3)")]#text(" does not hold for this concept of degree. For instance, if ")#mi("{G}")#text(" is a two-step nilpotent group, and ")#mi("{g,h}")#text(" are non-commuting elements of ")#mi("{G}")#text(", then the sequences ")#mi("{n \\mapsto g^n, n \\mapsto h^n}")#text(" would ostensibly have degree ")#mi("{1}")#text(" with this definition, but the product")

#align(center)[#tao-fit-display[#mitex("g^n h^n = (gh)^n [g,h]^{-\\binom{n}{2}}")]]

#text("where ")#mi("{[g,h] := g^{-1}h^{-1} gh}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("commutator")]#text(" of ")#mi("{g}")#text(" and ")#mi("{h}")#text(", would then have degree ")#mi("{2}")#text(", thus contradicting ")#link(<tao-8a2e8c703f4e87042862>)[#text("(3)")]#text(". (The symmetry property ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("(4)")]#text(" can also be shown to break down.)")

#text("Fortunately, the theory of polynomial sequences in nilpotent groups has been understood since the ")#link("http://www.ams.org/mathscinet-getitem?mr=1608723")[#text("work of Leibman")]#text(". The trick is not to view the coefficients ")#mi("{g_0,\\ldots,g_d}")#text(" appearing above as roaming unrestrictedly in the whole ")#mi("{s}")#text("-step nilpotent group ")#mi("{G}")#text(", but to restrict some or all of these coefficients to subgroups in the ")#link("http://en.wikipedia.org/wiki/Lower_central_series#Lower_central_series")[#text("lower central series")]#text(" ")#mi("{G = G_1 \\geq G_2 \\geq \\ldots \\geq G_s}")#text(", defined by setting ")#mi("{G_1 := G}")#text(" and ")#mi("{G_{i+1} := [G,G_i]}")#text(" for all ")#mi("{i \\geq 1}")#text(". Given natural numbers ")#mi("{d_1,\\ldots,d_s}")#text(", we then say that a sequence ")#mi("{g(n)}")#text(" has ")#emph[#text("filtered degree at most")]#text(" ")#mi("{(d_1,\\ldots,d_s)}")#text(" if, when using the Taylor expansion ")#link(<tao-e08bc1b6a298dbd66d86>)[#text("(7)")]#text(", we have ")#mi("{g_k \\in G_i}")#text(" whenever ")#mi("{k > d_i}")#text(". Thus, for instance, if ")#mi("{s=2}")#text(", ")#mi("{g_1 \\in G_1}")#text(" and ")#mi("{g_2 \\in G_2}")#text(", then the sequence ")#mi("{n \\mapsto g_1^n g_2^{\\binom{n}{2}}}")#text(" has filtered degree at most ")#mi("{(1,2)}")#text(". A fundamental result of Leibman (proven for instance in ")#link("https://terrytao.wordpress.com/2010/05/29/254b-notes-6-the-inverse-conjecture-for-the-gowers-norm-ii-the-integer-case/")[#text("this previous post")]#text(") asserts that if the sequence ")#mi("{(d_1,\\ldots,d_s)}")#text(" is ")#emph[#text("superadditive")]#text(" in the sense that ")#mi("{d_{i+j} \\geq d_i+d_j}")#text(" whenever ")#mi("{i+j \\leq s}")#text(", then the collection of polynomial sequences of filtered degree at most ")#mi("{(d_1,\\ldots,d_s)}")#text(" form a group. A related fact is that if a sequence ")#mi("{g}")#text(" has filtered degree at most ")#mi("{(d_1,\\ldots,d_s)}")#text(" for some superadditive ")#mi("{(d_1,\\ldots,d_s)}")#text(", then any derivative ")#mi("{\\partial_m g}")#text(" of ")#mi("{g}")#text(" has filtered degree at most ")#mi("{((d_1-1)_+,\\ldots,(d_s-1)_+)}")#text(" (which is still superadditive).")

#text("If we let ")#mi("{S}")#text(" be the set of all superadditive degree sequences, we can order such sequences lexicographically by declaring ")#mi("{(d_1,\\ldots,d_s) < (d^{\\prime}_1,\\ldots,d^{\\prime}_s)}")#text(" if there is an ")#mi("{i}")#text(" with ")#mi("{d_i < d^{\\prime}_i}")#text(" and ")#mi("{d_j=d^{\\prime}_j}")#text(" for all ")#mi("{j<i}")#text(". This makes ")#mi("{S}")#text(" a well-ordered set, and then we can define the filtered degree ")#mi("{\\text{deg}(g)}")#text(" of a polynomial sequence ")#mi("{g}")#text(" to be the minimal ")#mi("{(d_1,\\ldots,d_s)}")#text(" in ")#mi("{S}")#text(" for which ")#mi("{g}")#text(" has filtered degree at at most ")#mi("{(d_1,\\ldots,d_s)}")#text(". Thus, for instance, in an ")#mi("{s}")#text("-step nilpotent group, a sequence ")#mi("{n \\mapsto g^n}")#text(" with ")#mi("{g}")#text(" non-trivial would have filtered degree ")#mi("{(1,2,\\ldots,s)}")#text(". From Leibman’s results we then have the key properties ")#link(<tao-8a2e8c703f4e87042862>)[#text("(3)")]#text(", ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("(4)")]#text(", and also that any derivative ")#mi("{\\partial_h g}")#text(" of ")#mi("{g}")#text(" has strictly smaller filtered degree.")

#text("Unfortunately, as filtered degrees are not numbers, we cannot define an ultrametric taking values in ")#mi("{{\\bf R}^+}")#text(" in the using the formula ")#link(<tao-2b76f5da400249b3c1ec>)[#text("(5)")]#text(", but this is not a real difficulty; we simply declare an “ultrametric” taking values in ")#mi("{\\{0\\} \\cup S}")#text(" instead of ")#mi("{{\\bf R}^+}")#text(", by declaring ")#mi("{d(g_1,g_2) := \\text{deg}(g_1^{-1},g_2)}")#text(" if ")#mi("{g_1,g_2}")#text(" are distinct, and ")#mi("{d(g_1,g_2)=0}")#text(" otherwise. If we view ")#mi("{0}")#text(" as being smaller than any element of ")#mi("{S}")#text(", we see that the ultrametric axioms are still obeyed, and one can still run the argument more or less exactly as given above; we leave the details to the interested reader.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/#comment-186213")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2012")])]

#text("What a nice surprise: a link to a picture of my (former) teacher Prof. Nagel on your blog.")

#text("My browser (Firefox) stretches some formulas and keeps making black bars instead of latex.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Avigad")]], [#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/#comment-186769")[#strong[#text("Jeremy Avigad")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2012")])]

#text("Dear Terry,")

#text("Jason Rute and I recently noticed that in the case of the mean ergodic theorem, one has something even stronger than a uniform metastability result. Saying that a sequence is Cauchy is equivalent to saying that, for every ")#mi("\\epsilon > 0")#text(", there are at most finitely many “fluctuations” (or “jumps”) by more than ")#mi("\\epsilon")#text(". In the Hilbert space setting, a very elegant variational inequality due to ")#link("http://dx.doi.org/10.1017/S0143385700008816")[#text("Jones, Ostrovskii, Rosenblatt")]#text(" implies that a sequence of ergodic averages ")#mi("(A_n f)")#text(" has at most ")#tao-math("625 \\left\\| f \\right\\|^2 / \\epsilon^2", block: false)#text(" many ")#mi("\\epsilon")#text("-fluctuations. The JOR inequality and this corollary provide is a remarkably clean and uniform quantitative formulation of the MET.")

#text("Before learning of the JOR result, Jason and I had discovered a uniform bound on the number of ")#mi("\\epsilon")#text("-fluctuations that works in the more general setting of a uniformly convex Banach space. Our result is not sharp when specialized to the case of a Hilbert space, however, and we were unable to strengthen it to anything like the JOR inequality. This state of affairs is described in a paper, “")#link("http://arxiv.org/abs/1203.4124")[#text("Oscillation and the mean ergodic theorem")]#text(",” that we recently posted to arXiv.")

#text("We are curious to know how far this quantitative uniformity extends. In particular, in your norm convergence result and Walsh’s more recent result, is there a uniform bound on the number of ")#mi("\\epsilon")#text("-fluctuations? Does anything like the JOR square function inequality carry over?")

#text("Incidentally, we took the term “")#mi("\\epsilon")#text("-fluctuations” from a ")#link("http://dx.doi.org/10.1070/RM1996v051n04ABEH002964")[#text("1996 paper")]#text(" by Kachurovskii (which we cite). In an appendix he also considers nonstandard formulations of such uniformities. So maybe your nonstandard argument can be adapted to yield the stronger result?")

#text("Jeremy")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/#comment-186799")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2012")])]

#text("Hmm. There are variational inequalities for some pointwise ergodic theorems (such as Bourgain’s pointwise ergodic theorem from 1988 for averages along polynomials or primes), but I don’t think they have been established yet for norm convergence for multiple averages. The techniques used to prove these estimates are rather different (based on harmonic analysis rather than on regularity/metastability arguments, or on characteristic factors). I don’t think the metastability arguments (or the nonstandard variant given in this post) can easily give variational estimates, because one would then need to control fluctuations for very large unbounded times, and the arguments here are optimised instead to only control all times up to a relatively small unbounded time, which is all that one needs for metastability. But it is certainly a good question…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/#comment-186990")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("Update: Christoph Thiele pointed me towards ")#link("http://arxiv.org/abs/1203.5135")[#text("this recent paper of Do, Oberlin, and Palsson")]#text(" which establishes such a variational result for a dyadic version of a double average such as ")#mi("\\frac{1}{N} \\sum_{n=1}^N T^n f_1 T^{2n} f_2")#text(". In practice, these dyadic harmonic analysis arguments can often be adapted to the non-dyadic case, though the details can get messier in the process. The arguments are quite different from those in the ergodic theory literature, though, relying on the same sort of time-frequency analysis used to control operators such as the bilinear Hilbert transform or Carleson’s maximal operator. It may be that one actually needs such “hard analysis” tools to get such a quantitative result, and that the softer tools used to prove, say, Walsh’s theorem, might not be suitable for variational estimates.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/25/walshs-ergodic-theorem-metastability-and-external-cauchy-convergence/#comment-186991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2012")])]

#text("A typo: Arbeitsgemeinshaft -> Arbeitsgemeinschaft")

#text("[")#emph[#text("Korrigiert, danke – T.")]#text("]")
]
