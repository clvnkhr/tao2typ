// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/
// Converted to Typst by tao2typ: "2026-10-14T15:20:57.564151+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Formalizing the proof of PFR in Lean4 using Blueprint: a short tour", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Formalizing the proof of PFR in Lean4 using Blueprint: a short tour")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 November 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("Since the release of ")#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")[#text("my preprint with Tim, Ben, and Freddie")]#text(" proving the Polynomial Freiman-Ruzsa (PFR) conjecture over ")#mi("{\\mathbb F}_2")#text(", I (together with ")#link("https://github.com/YaelDillies")[#text("Yael Dillies")]#text(" and ")#link("https://github.com/b-mehta")[#text("Bhavik Mehta")]#text(") have started a ")#link("https://teorth.github.io/pfr/")[#text("collaborative project")]#text(" to formalize this argument in the proof assistant language ")#link("https://en.wikipedia.org/wiki/Lean_(proof_assistant)")[#text("Lean4")]#text(". It has been less than a week since the project was launched, but it is proceeding quite well, with a significant fraction of the paper already either fully or partially formalized. The project has been greatly assisted by the ")#link("https://github.com/PatrickMassot/leanblueprint")[#text("Blueprint tool")]#text(" of ")#link("https://www.imo.universite-paris-saclay.fr/~patrick.massot/en/")[#text("Patrick Massot")]#text(", which allows one to write a human-readable “blueprint” of the proof that is linked to the Lean formalization; similar blueprints have been ")#link("https://leanprover-community.github.io/liquid/")[#text("used for other projects")]#text(", such as Scholze’s ")#link("https://github.com/leanprover-community/lean-liquid")[#text("liquid tensor experiment")]#text(". For the PFR project, the blueprint can be found ")#link("https://teorth.github.io/pfr/blueprint/")[#text("here")]#text(". One feature of the blueprint that I find particularly appealing is the dependency graph that is automatically generated from the blueprint, and can provide a rough snapshot of how far along the formalization has advanced. For PFR, the latest state of the dependency graph can be found ")#link("https://teorth.github.io/pfr/blueprint/dep_graph_document.html")[#text("here")]#text(". At the current time of writing, the graph looks like this:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image.png")[#image("../assets/4ae31da6cc350ee44b7a6da9e3e1e2a84b8e2350e48aab934c2a6b5708cb84e7-38f5a5c242067c5e86f94af76d970c4c3ae99499d8b67491dd6ce0dfe46a8b2f.png", width: 90%)]
]

#text("The color coding of the various bubbles (for lemmas) and rectangles (for definitions) is explained in the legend to ")#link("https://teorth.github.io/pfr/blueprint/dep_graph_document.html")[#text("the dependency graph")]#text(", but roughly speaking the green bubbles/rectangles represent lemmas or definitions that have been fully formalized, and the blue ones represent lemmas or definitions which are ready to be formalized (their statements, but not proofs, have already been formalized, as well as those of all prerequisite lemmas and proofs). The goal is to get all the bubbles leading up to and including the “")#link("https://teorth.github.io/pfr/blueprint/sect0007.html#pfr")[#text("pfr")]#text("” bubble at the bottom colored in green.")

#text("In this post I would like to give a quick “tour” of the project, to give a sense of how it operates. If one clicks on the “")#link("https://teorth.github.io/pfr/blueprint/sect0007.html#pfr")[#text("pfr")]#text("” bubble at the bottom of the dependency graph, we get the following:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-1.png")[#image("../assets/46a248d6e5876d8d39ecd52769460b18ccac44d2894ef5233350c84e50de5d6c-5719c4296f65e07a172afb633f67bf4674117ba08faba816c0068b81947890d6.png", width: 90%)]
]

#text("Here, Blueprint is displaying a human-readable form of the PFR statement. This is coming from the ")#link("https://teorth.github.io/pfr/blueprint/sect0007.html#pfr")[#text("corresponding portion of the blueprint")]#text(", which also comes with a human-readable proof of this statement that relies on other statements in the project:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-2.png")[#image("../assets/c4d6880d328be7cfc6172cfeb66bdb3bbfa495dd9fe95eb0fa9430065a239e55-3ef7a50fdd58edb8ae925da5a7f3f9c099b779a5ab976bf3825466889d5b88ce.png", width: 90%)]
]

#text("(I have cropped out the second half of the proof here, as it is not relevant to the discussion.)")

#text("Observe that the “")#link("https://teorth.github.io/pfr/blueprint/sect0007.html#pfr")[#text("pfr")]#text("” bubble is white, but has a green border. This means that the statement of PFR has been formalized in Lean, but not the proof; and the proof itself is not ready to be formalized, because some of the prerequisites (in particular, “")#link("https://teorth.github.io/pfr/blueprint/sect0006.html#entropy-pfr")[#text("entropy-pfr")]#text("” (Theorem 6.16)) do not even have their statements formalized yet. If we click on the “Lean” link below the description of PFR in the dependency graph, we are lead to the (auto-generated) ")#link("https://teorth.github.io/pfr/docs/PFR/main.html#PFR_conjecture")[#text("Lean documentation for this assertion")]#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-3.png")[#image("../assets/f755fda9fedade0e3af8e886b9170610fb34f47b8cf4b02af7ed9db17df5a33f-cd0e3780c746390c382bdaba3788346b6393f673841d4758c00c9f9c59331821.png", width: 90%)]
]

#text("This is what a typical theorem in Lean looks like (after a procedure known as “pretty printing”). There are a number of hypotheses stated before the colon, for instance that ")#mi("G")#text(" is a finite elementary abelian group of order ")#mi("2")#text(" (this is how we have chosen to formalize the finite field vector spaces ")#mi("{\\bf F}_2^n")#text("), that ")#mi("A")#text(" is a non-empty subset of ")#mi("G")#text(" (the hypothesis that ")#mi("A")#text(" is non-empty was not stated in the LaTeX version of the conjecture, but we realized it was necessary in the formalization, and will update the LaTeX blueprint shortly to reflect this) with the cardinality of ")#mi("A+A")#text(" less than ")#mi("K")#text(" times the cardinality of ")#mi("A")#text(", and the statement after the colon is the conclusion: that ")#mi("A")#text(" can be contained in the sum ")#mi("c+H")#text(" of a subgroup ")#mi("H")#text(" of ")#mi("G")#text(" and a set ")#mi("c")#text(" of cardinality at most ")#mi("2K^{12}")#text(".")

#text("The astute reader may notice that the above theorem seems to be missing one or two details, for instance it does not explicitly assert that ")#mi("H")#text(" is a subgroup. This is because the “pretty printing” suppresses some of the information in the actual statement of the theorem, which can be seen by clicking on the “")#link("https://github.com/teorth/pfr/blob/6b2c357dc922ff00dec5dd6873b841925b0e22ef//PFR/main.lean#L17-L21")[#text("Source")]#text("” link:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-4.png")[#image("../assets/522ee82beaaf0b6bb7d8e79d5e750f3a641d12769e3a237deef69c95836b621c-02a8fbc7c038681f65721447268f3b601e21a56e3d416e469e1bee0af28df271.png", width: 90%)]
]

#text("Here we see that ")#mi("H")#text(" is required to have the “type” of an additive subgroup of ")#mi("G")#text(". (Lean’s language revolves very strongly around ")#link("https://en.wikipedia.org/wiki/Type_theory")[#text("types")]#text(", but for this tour we will not go into detail into what a type is exactly.) The prominent “sorry” at the bottom of this theorem asserts that a proof is not yet provided for this theorem, but the intention of course is to replace this “sorry” with an actual proof eventually.")

#text("Filling in this “sorry” is too hard to do right now, so let’s look for a simpler task to accomplish instead. Here is a simple intermediate lemma “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-nonneg")[#text("ruzsa-nonneg")]#text("” that shows up in the proof:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-5.png")[#image("../assets/b0f4dc84aa591d3d80a5ea07cd22f8df77b6a2ef5864492d1f543c721e620ceb-2ebedae1bb0c0a3e07312452bf5eac5d61f447dfeade8d5957160041a2a25709.png", width: 90%)]
]

#text("The expression ")#mi("d[X; Y]")#text(" refers to something called the entropic Ruzsa distance between ")#mi("X")#text(" and ")#mi("Y")#text(", which is something that is defined ")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruz-dist-def")[#text("elsewhere in the project")]#text(", but for the current discussion it is not important to know its precise definition, other than that it is a real number. The bubble is blue with a green border, which means that the statement has been formalized, and the proof is ready to be formalized also. The blueprint dependency graph indicates that this lemma can be deduced from just one preceding lemma, called “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-diff")[#text("ruzsa-diff")]#text("“:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-6.png")[#image("../assets/443739ab8e091072ae369cf352628920c7b89685542bb0b14cd9c3321845bda3-580898ae059e9704eae73155790cad09b6d7df6152460c7e493e096e325fd3d3.png", width: 90%)]
]

#text("“")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-diff")[#text("ruzsa-diff")]#text("” is also blue and bordered in green, so it has the same current status as “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-nonneg")[#text("ruzsa-nonneg")]#text("“: the statement is formalized, and the proof is ready to be formalized also, but the proof has not been written in Lean yet. The quantity ")#mi("H[X]")#text(", by the way, refers to the ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" of ")#mi("X")#text(", defined ")#link("https://teorth.github.io/pfr/blueprint/sect0002.html#entropy-def")[#text("elsewhere in the project")]#text(", but for this discussion we do not need to know its definition, other than to know that it is a real number.")

#text("Looking at Lemma 3.11 and Lemma 3.13 it is clear how the former will imply the latter: the quantity ")#tao-math("\\left|H[X] - H[Y]\\right|", block: false)#text(" is clearly non-negative! (There is a factor of ")#mi("2")#text(" present in Lemma 3.11, but it can be easily canceled out.) So it should be an easy task to fill in the proof of Lemma 3.13 assuming Lemma 3.11, even if we still don’t know how to prove Lemma 3.11 yet. Let’s first look at the Lean code for each lemma. Lemma 3.11 is formalized ")#link("https://github.com/teorth/pfr/blob/6b2c357dc922ff00dec5dd6873b841925b0e22ef//PFR/ruzsa_distance.lean#L118-L118")[#text("as follows")]#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-7.png")[#image("../assets/b4e5990e7693974d158400cddb9630d67e31d6d756f8b6445c6575474adb9fcd-5d9cffb81636efe550ba8dfe58053ec89ab4e1494930a26fba545ee6332c2083.png", width: 90%)]
]

#text("Again we have a “sorry” to indicate that this lemma does not currently have a proof. The Lean notation (as well as the name of the lemma) differs a little from the LaTeX version for technical reasons that we will not go into here. (Also, the variables ")#mi("X, \\mu, Y, \\mu^{\\prime}")#text(" are introduced at an earlier stage in the Lean file; again, we will ignore this point for the ensuing discussion.) Meanwhile, Lemma 3.13 is ")#link("https://github.com/teorth/pfr/blob/6b2c357dc922ff00dec5dd6873b841925b0e22ef//PFR/ruzsa_distance.lean#L127-L128")[#text("currently formalized as")]

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-8.png")[#image("../assets/d2090261fbe6977160423599b64b62485e7411828d1a882e6bb37a4bde6aa9d3-4df5946478454835f461f62f66b83dd467da2e76b1194aa629ce71acb0835397.png", width: 90%)]
]

#text("OK, I’m now going to try to fill in the latter “sorry”. In my local copy of the ")#link("https://github.com/teorth/pfr")[#text("PFR github repository")]#text(", I open up the ")#link("https://github.com/teorth/pfr/blob/master/PFR/ruzsa_distance.lean")[#text("relevant Lean file")]#text(" in my editor (")#link("https://code.visualstudio.com/")[#text("Visual Studio Code")]#text(", with the ")#link("https://github.com/leanprover/vscode-lean4")[#text("lean4 extension")]#text(") and navigate to the “sorry” of “rdist_nonneg”. The accompanying “Lean infoview” then shows the current state of the Lean proof:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-9.png")[#image("../assets/3edb25b3298fc00f59f644d49030232f7c4f7cc4aef43257cb12db566c8d09c2-e3f70c362e0ef91ab9935ad5c4cb99dc38f5efafdc1ffc372fb626d06b7803a5.png", width: 90%)]
]

#text("Here we see a number of ambient hypotheses (e.g., that ")#mi("G")#text(" is an additive commutative group, that ")#mi("X")#text(" is a map from ")#mi("\\Omega")#text(" to ")#mi("G")#text(", and so forth; many of these hypotheses are not actually relevant for this particular lemma), and at the bottom we see the goal we wish to prove.")

#text("OK, so now I’ll try to prove the claim. This is accomplished by applying a series of “tactics” to transform the goal and/or hypotheses. The first step I’ll do is to put in the factor of ")#mi("2")#text(" that is needed to apply Lemma 3.11. This I will do with the “suffices” tactic, writing in the proof")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-10.png")[#image("../assets/69bee49d86401213c8c6b86af786d266ebd2915ccdef649747be71821b06dacc-f358169aabae1cea2da54a987a5052106e8fa11303cad0122ab7a068ac820f71.png", width: 90%)]
]

#text("I now have two goals (and two “sorries”): one to show that ")#mi("0 \\leq 2 d[X;Y]")#text(" implies ")#mi("0 \\leq d[X,Y]")#text(", and the other to show that ")#mi("0 \\leq 2 d[X;Y]")#text(". (The yellow squiggly underline indicates that this lemma has not been fully proven yet due to the presence of “sorry”s. The dot “.” is a syntactic marker that is useful to separate the two goals from each other, but you can ignore it for this tour.) The Lean tactic “suffices” corresponds, roughly speaking, to the phrase “It suffices to show that …” (or more precisely, “It suffices to show that … . To see this, … . It remains to verify the claim …”) in Mathematical English. For my own education, I wrote a “Lean phrasebook” of further correspondences between lines of Lean code and sentences or phrases in Mathematical English, which can be found ")#link("https://docs.google.com/spreadsheets/d/1Gsn5al4hlpNc_xKoXdU6XGmMyLiX4q-LFesFVsMlANo/edit#gid=0")[#text("here")]#text(".")

#text("Let’s fill in the first “sorry”. The tactic state now looks like this (cropping out some irrelevant hypotheses):")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-11.png")[#image("../assets/b85878c6d400611880f3dcebfce5427a9215ae4dd7bcb9bf0e6d4b4732091d5c-bcb4a32bf10e67563a8f462913db368f74cf35c66546eb01371fa95eaa1362d8.png", width: 90%)]
]

#text("Here I can use a handy tactic “")#link("https://leanprover-community.github.io/mathlib_docs/tactics.html#linarith")[#text("linarith")]#text("“, which solves any goal that can be derived by linear arithmetic from existing hypotheses:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-12.png")[#image("../assets/0d24e498a7f0971bcfec9d559739deaec41dc4ca8084d3b92e6bb6283a1260e6-dcac4bc7b2b6a1f1f29e7facf72300d2ff69927563ada1a3dd24ce1eccd62518.png", width: 90%)]
]

#text("This works, and now the tactic state reports no goals left to prove on this branch, so we move on to the remaining sorry, in which the goal is now to prove ")#mi("0 \\leq 2 d[X;Y]")#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-13.png")[#image("../assets/4b272518b83449c4694b0dd332a150e58f844e8766c50b067bd607c71202adee-a5ea1951e17e4761e4b75213106544fb8cd7ac37b4c611477ce77ddde00f1c04.png", width: 90%)]
]

#text("Here we will try to invoke Lemma 3.11. I add the following lines of code:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-14.png")[#image("../assets/ead6861c8eb6b37df6ad06333cb1cefce693d6d607427a86086d4d60a131538e-0cc195a31fc5971af64af5461d2090468ceaa822cb405cf578d5f6d75c918667.png", width: 90%)]
]

#text("The Lean tactic “")#link("https://leanprover-community.github.io/mathlib_docs/tactics.html#have")[#text("have")]#text("” roughly corresponds to the Mathematical English phrase “We have the statement…” or “We claim the statement…”; like “suffices”, it splits a goal into two subgoals, though in the reversed order to “suffices”.")

#text("I again have two subgoals, one to prove the bound ")#tao-math("\\left|H[X]-H[Y]\\right| \\leq 2 d[X;Y]", block: false)#text(" (which I will call “h”), and then to deduce the previous goal ")#mi("0 \\leq 2 d[X;Y]")#text(" from ")#mi("h")#text(". For the first, I know I should invoke the lemma “diff_ent_le_rdist” that is encoding Lemma 3.11. One way to do this is to try the tactic “exact?”, which will automatically search to see if the goal can already be deduced immediately from an existing lemma. It reports:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-15.png")[#image("../assets/9ea70142ccf932bed463c164b3b3030594b8ce45cc1108e75e032e388ee3e8db-e269c34750dfcc31b9036fbed4212ef3c61232f69b6835475113f2a456b58639.png", width: 90%)]
]

#text("So I try this (by clicking on the suggested code, which automatically pastes it into the right location), and it works, leaving me with the final “sorry”:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-16.png")[#image("../assets/d1a4820bfc2dd866e9a737f16e94be2f260f891749a7b71517b9bf3687620c39-8c38558a6492cc7229891928cbdd1847217329e94f433882f5c3164d7d33f0c6.png", width: 90%)]
]

#text("The lean tactic “")#link("https://leanprover-community.github.io/mathlib_docs/tactics.html#exact")[#text("exact")]#text("” corresponds, roughly speaking, to the Mathematical English phrase “But this is exactly …”.")

#text("At this point I should mention that I also have the ")#link("https://github.com/features/copilot")[#text("Github Copilot")]#text(" extension to Visual Studio Code installed. This is an AI which acts as an advanced autocomplete that can suggest possible lines of code as one types. In this case, it offered a suggestion which was almost correct (the second line is what we need, whereas the first is not necessary, and in fact does not even compile in Lean):")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-25.png")[#image("../assets/e9d080ed582460d84d316b2d8d3aa1d16837171787a7366db94a2bc4e9c1a583-1b86ff9258259c6e3b277fc1d29bd434476c4cb254e884f2d4a171242f62abd9.png", width: 90%)]
]

#text("In any event, “exact?” worked in this case, so I can ignore the suggestion of Copilot this time (it has been very useful in other cases though). I apply the “exact?” tactic a second time and follow its suggestion to establish the matching bound ")#tao-math("0 \\leq \\left|H[X] - H[Y]\\right|", block: false)#text(":")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-17.png")[#image("../assets/9afda9dbd967d7efac10a20f6877bf028466ae6268d528a5610af30c8c13e168-18ed2569b9eee4c1dd9fe65de18d4c062a2d4c418cbc40c212183ec80b085a0a.png", width: 90%)]
]

#text("(One can find documention for the “abs_nonneg” method ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Algebra/Order/Group/Abs.html#abs_nonneg")[#text("here")]#text(". Copilot, by the way, was also able to resolve this step, albeit with a slightly different syntax; there are also several other search engines available to locate this method as well, such as ")#link("https://moogle-morphlabs.vercel.app/search/raw?q=absolute%20value%20is%20nonnegative")[#text("Moogle")]#text(". One of the main purposes of the ")#link("https://leanprover-community.github.io/contribute/naming.html")[#text("Lean naming conventions for lemmas")]#text(", by the way, is to facilitate the location of methods such as “abs_nonneg”, which is easier figure out how to search for than a method named (say) “Lemma 1.2.1”.) To fill in the final “sorry”, I try “exact?” one last time, to figure out how to combine ")#mi("h")#text(" and ")#mi("h^{\\prime}")#text(" to give the desired goal, and it works!")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-18.png")[#image("../assets/31ff725f5e5d494445eacb6ac64642b719a4ab9664f633d51f77f3745ff31a4a-c8aaf31e3c4756b9f65a11cb1cfcf1ecfc6eca7d827b73b8b2fb18a22efd3f27.png", width: 90%)]
]

#text("Note that all the squiggly underlines have disappeared, indicating that Lean has accepted this as a valid proof. The documentation for “ge_trans” may be found ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Init/Order/Defs.html#ge_trans")[#text("here")]#text(". The reader may observe that this method uses the ")#mi("\\geq")#text(" relation rather than the ")#mi("\\leq")#text(" relation, but in Lean the assertions ")#mi("X \\geq Y")#text(" and ")#mi("Y \\leq X")#text(" are “")#link("https://www.ma.imperial.ac.uk/~buzzard/xena/formalising-mathematics-2022/Part_B/equality.html#:~:text=Definitional%20equality,-Definitional%20equality%20is&text=In%20Lean%2C%20%C2%ACP%20is,equal%2C%20they%20are%20definitionally%20equal.")[#text("definitionally equal")]#text("“, allowing tactics such as “exact” to use them interchangeably. “exact ")#link("https://leanprover-community.github.io/mathlib4_docs/Mathlib/Init/Order/Defs.html#le_trans")[#text("le_trans")]#text(" h’ h” would also have worked in this instance.")

#text("It is possible to compactify this proof quite a bit by cutting out several intermediate steps (a procedure sometimes known as “")#link("https://en.wikipedia.org/wiki/Code_golf")[#text("code golf")]#text("“):")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-19.png")[#image("../assets/72eeaba3cd6bc205c72cf841f27ec8a9d03f041870b25e57369f9d6be0f66581-909612b3405c78e5f64746ea746fefc4fac0f7c83f9c0f35d050cb76d2c83cda.png", width: 90%)]
]

#text("And now the proof is done! In the end, it was literally a “one-line proof”, which makes sense given how close Lemma 3.11 and Lemma 3.13 were to each other.")

#text("The current version of Blueprint does not automatically verify the proof (even though it does compile in Lean), so we have to manually update the blueprint as well. The LaTeX for Lemma 3.13 ")#link("https://github.com/teorth/pfr/blob/master/blueprint/src/chapter/distance.tex")[#text("currently looks like this:")]

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-20.png")[#image("../assets/4228a7dfa5c24b28d8eebd735ba1785d7200c2188cb6b51bc91bb9476b131fdb-c99dfb0acb80beac3a97168bac2c22401add09c1dcbdd2fd55ab30515174a8b6.png", width: 90%)]
]

#text("I add the “\\leanok” macro to the proof, to flag that the proof has now been formalized:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-22.png")[#image("../assets/748a98ea3fea6e948a5eb39a71276bec7ec3b3a5a82ba82372e6b7ef48e5a604-e19d7601cf0a13fcd332bb9b63d168e5eeb1d655ebed84ef8a3740550c4273f8.png", width: 90%)]
]

#text("I then push everything back up to the master Github repository. The blueprint will take quite some time (about half an hour) to rebuild, but eventually it does, and the dependency graph (which Blueprint has for some reason decided to rearrange a bit) now shows “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-nonneg")[#text("ruzsa-nonneg")]#text("” in green:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2023/11/image-23.png")[#image("../assets/d7048a96262c6109a5d39055681eb1103f89c82e9e5d1bb5e554d3e544193eca-8919b434482f2b0a7b283c1f3c150ed647db76578e8f78761074bc38f608c80f.png", width: 90%)]
]

#text("And so the formalization of PFR moves a little bit closer to completion. (Of course, this was a particularly easy lemma to formalize, that I chose to illustrate the process; one can imagine that most other lemmas will take a bit more work.) Note that while “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-nonneg")[#text("ruzsa-nonneg")]#text("” is now colored in green, we don’t yet have a full proof of this result, because the lemma “")#link("https://teorth.github.io/pfr/blueprint/sect0003.html#ruzsa-diff")[#text("ruzsa-diff")]#text("” that it relies on is not green. Nevertheless, the proof is ")#emph[#text("locally")]#text(" complete at this point; hopefully at some point in the future, the predecessor results will also be locally proven, at which point this result will be completely proven. Note how this blueprint structure allows one to work on different parts of the proof asynchronously; it is not necessary to wait for earlier stages of the argument to be fully formalized to start working on later stages, although I anticipate a small amount of interaction between different components as we iron out any bugs or slight inaccuracies in the blueprint. (For instance, I am suspecting that we may need to add some measurability hypotheses on the random variables ")#mi("X, Y")#text(" in the above two lemmas to make them completely true, but this is something that should emerge organically as the formalization process continues.)")

#text("That concludes the brief tour! If you are interested in learning more about the project, you can follow the ")#link("https://leanprover.zulipchat.com/#narrow/stream/412902-Polynomial-Freiman-Ruzsa-conjecture")[#text("Zulip chat stream")]#text("; you can also ")#link("https://leanprover-community.github.io/get_started.html")[#text("download Lean")]#text(" and ")#link("https://leanprover-community.github.io/install/project.html")[#text("work on the PFR project yourself")]#text(", using a local copy of the Github repository and sending pull requests to the master copy if you have managed to fill in one or more of the “sorry”s in the current version (but if you plan to work on anything more large scale than filling in a small lemma, it is good to announce your intention on the Zulip chat to avoid duplication of effort) . (One key advantage of working with a project based around a proof assistant language such as Lean is that it makes large-scale mathematical collaboration possible without necessarily having a pre-established level of trust amongst the collaborators; my fellow repository maintainers and I have already approved several pull requests from contributors that had not previously met, as the code was verified to be correct and we could see that it advanced the project. Conversely, as the above example should hopefully demonstrate, it is possible for a contributor to work on one small corner of the project without necessarily needing to understand all the mathematics that goes into the project as a whole.)")

#text("If one just wants to experiment with Lean without going to the effort of downloading it, you can playing try the “")#link("https://adam.math.hhu.de/")[#text("Natural Number Game")]#text("” for a gentle introduction to the language, or the ")#link("https://live.lean-lang.org/")[#text("Lean4 playground")]#text(" for an online Lean server. Further resources to learn Lean4 may be found ")#link("https://leanprover-community.github.io/learn.html")[#text("here")]#text(".")

#heading(level: 1)[#text("Comments (49)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("Wow! Although I don’t understand a word you are saying, it looks very exciting!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("Congratulations! This is an extremely important event: A top ranked pure mathematician, in a very short time, has mastered the Lean 4 automated proof checker and applied it to a new result. This is an existence proof for pure mathematicians to routinely codify their proofs in verifiable way, as a part of daily methodology, in the same sense that writing equations in LaTeX has become a standard practice.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("This tour brought me a lot of joy. Bright days are ahead")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2023")])]

#text("Thank you so much for writing so well this tour! A lot of this seems natural and one can see how undergraduates can contribute without mastering all the math yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682300")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("Lean syntax was made flexible to accept people coming over from different programming languages, but it still weirds me out seeing python-esque style with meaningful tabulation over c-style with {brackets}")

#text("it always seems so much more convinient to know when one goal has ended and another begins – just find “}”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("same for when definition is over and proof begins – just skip to the “{“")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682322")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2023")])]

#text("Haskell-esque, you mean :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682302")[#strong[#text("Formalizations in LEAN – SPP 2026")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")]

#text("[…] edit (Nov. 19th): Terence Tao is now also formalizing his recent proof of the Polynomial Freiman-Ruzsa conjecture over F_2: Link. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("The blueprint tool was designed and implemented by Patrick Massot. It’s a tremendous contribution; it played an essential role in the sphere eversion project as well as the LTE.")

#emph[#text("[Reference to Patrick now added to the post, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("Your example with the `rdist_nonneg` lemma was really didactic. Not only it provides a simple case to understand how the reasoning can be translated to the Lean 4 syntax, but also showcase how the formalization may be rewritten in a more ‘succinct’ manner.")

#text("I have mixed feelings. Although I understand the pros of being able to “script” the proof efficiently (here, in the sense of using less keystrokes), I also feel that a formalization that can be mapped more easily to the original argument would be preferable. On the other hand, if the goal of any formalization is to simply have a digitally verifiable version of the proof, then we should maybe leave the steps of our thought process to the realm of natural language only. Honestly, I don’t actually know were I currently stand in this discussion.")

#text("Anyway, thanks for the post. It’s always a joy!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("It’s a tradeoff. One one hand shorter proofs take less space in the source, making it easier to read the statements and definitions, and can improve checking time.")

#text("On the other hand short proofs can be harder to understand for humans.")

#text("There are caveats to both. There’s tooling to get readable documentation that hides the proofs, and the utility of human understanding of individual proofs in a proof assistant is limited.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682316")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("For what it is worth, the compactified proof still translates into Mathematical English in a straightforward, though somewhat ungainly, fashion: “The non-negativity of ")#mi("d[X; Y]")#text(" follows by linear arithmetic from the outcome of transitivity of ")#mi("\\geq")#text(" applied to Lemma 3.11 and the non-negativity of the absolute value of ")#mi("H[X]-H[Y]")#text("“. In the future I would imagine that the proof would instead look something like `immediate diff_ent_le_dist”, as a translation of “The non-negativity of ")#mi("d[X;Y]")#text(" is immediate from Lemma 3.11″, although Lean doesn’t quite have the “immediate” tactic coded yet :). [But it is getting there; see for instance the ")#link("https://github.com/leanprover-community/aesop")[#text("aesop tactic")]#text(".]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682317")[#strong[#text("Formalizing the proof of PFR in Lean4 using Blueprint | John's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")]

#text("[…] in my feed today: Formalizing the proof of PFR in Lean4 using Blueprint: a short tour by Terence Tao. I would like to learn […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("This looks very interesting. However there appears to be no documentation fro blueprint. How did you learn to use it? Did Patrick have to guide you?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2023")])]

#text("It’s mostly Yael Dillies who (rather heroically) got blueprint up and running within the first 48 hours of the project (I believe they may have had some prior experience with an earlier version of the software). It is still in development (I think the correct term may be “beta release”?) but I assume at some point a stable documented version of the software will be available. In the meantime one basically has to ask around on the ")#link("https://leanprover.zulipchat.com/")[#text("Lean Zulip")]#text(" for technical support for the software (we reported one minor bug already, so are sort of functioning as “beta testers” for this software).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682372")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2023")])]

#text("Hello Terence! This is my first comment here. Sorry for doing it anonymously.")

#text("I admire the breadth of your mathematical interests. I wonder how it is possible to acquire so much knowledge. I think it would be wonderful if you wrote a post about your personal method of study. Do you prefer to thoroughly read one good book on some subject or cursorily read several books on it? Do you read a book once or reread it? Do you always enter every proof or just read statements for the majority of theorems? Or maybe you skip the proofs on the first reading and examine them later?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682320")[#strong[#text("Marton’s “Polynomial Freiman-Ruzsa” Conjecture was Settled by Tim Gowers, Ben Green, Freddie Manners and Terry Tao | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")]

#text("[…] of the proof see this post in Terry Tao’s blog. A subsequent post on Terry Tao’s blog describes a project for formalizing the proof using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682321")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2023")])]

#text("mathstodon is full of bloggy bits")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682371")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2023")])]

#text("Is it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2023")])]

#text("Yes, it’s very bloggy.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df39a7e82fa0547daacacec84f2e90901368a671738016a89f59b3ee9780cd96-b50ccd47325e53d5c81d2863f7a400cec297ea6a16ada5968bbd18ef979e0b02.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ppalme")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682323")[#strong[#text("ppalme")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2023")])]

#text("Continuous improvement and advancement at it finest. What a wonderful way to plan and document the connections and status of the arguments of a proof. I assume this will be as well applied in hindsight to all the existing proofs or counter-examples in mathematics. Thank you so much for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8b673b0f5f8fd68741b472717dc8bbd250b58bfba25e6acdfd89140ba4da454-0162e84387e99bc2ff7bac0941538a04a75718fb34ec614fb02a7375dece8626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CPK")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682333")[#strong[#text("CPK")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2023")])]

#text("Hey Terry, this will be an unrelated question but i was just wondering if you were considering getting into AI research? It looks like we are very close to produce extremely strong AI and the humanity can use your help in handling this challenge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2023")])]

#text("Interesting. I really like the spirit of the project. It seems that lot of aspects could be improved technically, and the most tempting one is to have AI (LLM) write the blueprint pretty much automatically. For this, it needs to come up with a good name for each lemma (they are great at this) , and to understand the dependencies. The real goal is that AI would do the translation to lean, but it is much more challenging.")

#text("About the graph, I saw that it uses pygraphviz . I have a feeling the look of this graph could be improved, maybe by using python-igraph.")

#text("Eyal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682395")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("The project has now completed its primary goals; the entire dependency graph is now green. More discussion at ")#link("https://leanprover.zulipchat.com/#narrow/stream/412902-Polynomial-Freiman-Ruzsa-conjecture/topic/Project.20completed")[#text("https://leanprover.zulipchat.com/#narrow/stream/412902-Polynomial-Freiman-Ruzsa-conjecture/topic/Project.20completed")]#text("!.20.20Thoughts.20and.20reflections.3F")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682412")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("So happy to sea this")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A slightly longer Lean 4 proof tour | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682415")[#strong[#text("A slightly longer Lean 4 proof tour | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2023")])]

#text("[…] my previous post, I walked through the task of formally deducing one lemma from another in Lean 4. The deduction was […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682420")[#strong[#text("AI颠覆数学研究！陶哲轩借AI破解数学猜想，形式化成功惊呆数学圈 – 比特币中国")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")]

#text("[…] Formalizing the proof of PFR in Lean4 using Blueprint: a short tour […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682422")[#strong[#text("Quanta Magazine - Hill News")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")]

#text("[…] a mathematician at Paris-Saclay University, to organize the efforts to translate from what Tao called “Mathematical English” into computer code. Blueprint can, among other things, create a chart […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c791a2e2807f98638f149d80769f1a5af49fc7e5ceae89f37407406af0797aa-ddcf4e753e4b745cb3770643160180712a8a6e482edf7e96e9db0ca3c2a231ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of F r i e d e r")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682426")[#strong[#text("F r i e d e r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2023")])]

#text("I’m surprised no one has mentioned how big of a leap this is compared to the vision from 2017 of Thomas Hales of including _fabstract_s in research papers (")#link("https://formalabstracts.github.io")[#text("https://formalabstracts.github.io")]#text(") which seemed very ambitious at the time. For longer research papers that is still a viable option though, and hopefully may get more traction in the future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682449")[#strong[#text("A a miniature longer Lean 4 proof tour – I NEWS ps")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2023")]

#text("[…] my earlier submit, I walked by the responsibility of formally deducing one lemma from one different in Lean 4. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2023")])]

#text("I’m curious: how much did this formalization process increase your confidence in the correctness of the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682456")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2023")])]

#text("Well, in this particular case my three coauthors and I proofread the argument multiple times, and in fact also rewrote it multiple times during a process of optimizing the constants, so we already had an unusually high amount of confidence in the argument, and also the argument has a “robust” feel to it, in that even if there was a serious error in one step, this might cause the constants in our final arguments to degrade a bit, but not destroy the result entirely. I guess it did increase to 100% the confidence that the specific exponent of 12 in our final result is rigorously justified. Now we even have a bit of margin of error here, as the exponent was recently improved to 11, and we plan to formalize that argument also.")

#text("The formalization did pick up one very minor error in our writeup – one of our lemmas had omitted by mistake the hypothesis that the ambient group ")#mi("G")#text(" be ")#mi("2")#text("-torsion – but this error caused no damage to the paper as a whole (all the groups we actually need in our argument are 2-torsion).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2023")])]

#text("A small update to the project. While the primary goal of verifying the PFR conjecture is completed, participants expressed interest in continuing the project to formalize some other related results, including (a) an application of PFR to characterize “Approximate homomorphisms”, (b) an application of PFR to obtain a “Weak PFR over the integers”, and (c) a refinement of the PFR constant from 12 to 11. All of these are currently underway (although there was a technical snag with (b), which was that our theory of entropy that we had formalized was restricted to random variables taking values in finite sets, and now we need to extend the theory to random variables taking values in sets such as the integers). One consequence of this is that the ")#link("https://teorth.github.io/pfr/blueprint/dep_graph_document.html")[#text("blueprint graph")]#text(" may temporarily look a little less than full-green, but one can still check that all the nodes leading up to the original “pfr” bubble are green. And we have an ")#link("https://github.com/teorth/pfr/blob/master/examples.lean")[#text("examples file")]#text(" which, when compiled, verifies that the pfr conjecture was established using only the standard type-theoretic ")#link("https://lean-lang.org/theorem_proving_in_lean/axioms_and_computation.html")[#text("axioms of Lean")]#text(" (the ")#link("https://leanprover-community.github.io/mathlib4_docs/Init/Prelude.html#Classical.choice")[#text("axiom of choice")]#text(", ")#link("https://leanprover-community.github.io/mathlib4_docs/Init/Core.html#propext")[#text("propositional extensionality")]#text(", and the ")#link("https://leanprover-community.github.io/mathlib4_docs/Init/Core.html#Quot.sound")[#text("quotient axiom")]#text(". [My rough understanding is that these axioms are equivalent to ZFC with universes, though I may be slightly inaccurate on this point.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682490")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2023")])]

#text("Hi, Prof. Tao, I am curious what is the particular reason to pick this pfr paper to formalize instead of other papers? Are you going to formalize future published papers or it is just an experiment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Partly it was timing; the paper came out soon after I learned the basics of programming in Lean. Partly it was because the paper was relatively elementary, with the main non-trivial mathematical theory required being the theory of Shannon entropy, which was not already in Mathlib (but thanks to the PFR project, there will be thousands of lines of code of lemmas on entropy lemmas, probability kernels, Ruzsa calculus, and related topics that will be ported to Mathlib over the next few months). I was also interested to see how a large scale formalization project operated; the lessons learned from this medium-scale project could help improve larger-scale formalization projects (such as Buzzard’s five-year plan to formalize the proof of Fermat’s last theorem).")

#text("At the present level of technology, it is not feasible to formalize every single paper in every single field, but I think it may become realistic to strategically formalize some high profile results in fields that are not built on an immense amount of prior mathematical work (besides the core undergraduate mathematics curriculum, which by now has been largely formalized), or to partially formalize portions of papers (e.g., to formally state, but not prove, the main result, or to formalize a key calculation in the result conditionally on accepting all the other lemmas and cited results in the paper as “black boxes”; this could help gain confidence in the correctness of the paper if the black boxes are all “standard” but the key calculation sensitive to sign errors etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e20483ec7aac4cbe9ded454ab133d73134fb53fb9bb35731bdf29c0226bcbfea-1ac3b69236a97f99d36e3d7b866a34e1c869791d8902e34763411f1b390fbe7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of echolocked")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682612")[#strong[#text("echolocked")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Seems Lean provides a way to fill/check the gaps only when given a well structured blue-prints built by human. Am I missing it or Lean actually provides automatic search for proofs from hypothesis to conclusion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2023")])]

#text("Lean is basically a programming language that is particularly well suited to formal verification tasks. It has some automatic search features (with such names as `apply?`, `exact?`, `hint`, `aesop`, and so forth), but only at very granular levels (it can basically help with suggesting the next tactic to try in a")#linebreak()#text(" the next line of code in a formal proof). But there are promising experiments to couple formal verifiers such as Lean with more expressive AI (e.g., GPT), which can propose larger-scale proofs (or proof strategies) which are not guaranteed to work, but which can be tested with the formal verification languages in a feedback loop until a valid proof is obtained. At the current state of technology I think these can handle Lean proofs that require about a dozen lines of code or so, and could perhaps be able to handle problems at the level of an undergraduate math homework problem, but further advances would be needed I think before they can consistently handle something on the level of (say) a Math Olympiad problem, or a graduate math qualifying exam problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2024")])]

#text("In his article “On proof and progress in mathematics”, Thurston said that")

#text("In not too many years, I expect that we will have interactive computer programs that can help people compile signiﬁcant chunks of formally complete and correct mathematics (based on a few perhaps shaky but at least explicit assumptions), and that they will become part of the standard mathematician’s working environment.")

#text("How far is Lean 4 from such a goal?")

#text("Analysis and algebra in the undergraduate curriculum by now have been largely formalized. The “simi-formal” language students are required to used in their homework are in principle translatable to formal code, and more importantly, the formal code can be translated back to the simi-formal language that human can read.")

#text("How about subjects like topology and geometry where even the most “rigorous” arguments often use pictures/figures extensively? Would Lean help in such fields too? Algebraic topology seems to be the only language to go to formalism. Is it feasible to imagine, the formal code could be translated back to the pictorial language that is enlightening for human understanding?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-682806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2024")])]

#text("I am not an expert in topology, but for instance sphere eversion has been formalized in Lean: ")#link("https://leanprover-community.github.io/sphere-eversion/")[#text("https://leanprover-community.github.io/sphere-eversion/")]#text(" . Even though the construction is usually presented pictorially, it can be converted to a purely text-based blueprint, which was then formalized.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-684489")[#strong[#text("A-Team of Math: Unraveling the Critical Link Between Addition and Sets\" - Best books shelves")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2024")]

#text("[…] scientist at Paris-Saclay University, to organize the effort to translate the language Tao described as “Mathematical the language of English” in computer […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-684516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2024")])]

#text("Beautiful work, I have a doubt about this: “Note how this blueprint structure allows one to work on different parts of the proof asynchronously; it is not necessary to wait for earlier stages of the argument to be fully formalized to start working on later stages, although I anticipate a small amount of interaction between different components as we iron out any bugs or slight inaccuracies in the blueprint”. Isn’t it dangerous to prove lemmas that come after without having already proven the lemmas that come before? An error in a previous lemma or in the proof structure that necessitates a different path could make the later proof useless as a different path is needed to achieve the final result.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-684577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("I have found that as long as the blueprint was written with a reasonable amount of care, and one is guided by good intuition (e.g., coming from motivating examples), this sort of major refactoring does not occur (but if it did, it was a sign that the informal proof was actually not as well understood as people thought, which is also a useful outcome of such a project).")

#text("Minor refactoring, on the other hand, has ended up being rather straightforward to achieve in practice – say, adding a hypothesis that some variable has to be non-zero in a lemma (because the proof breaks otherwise), and then making sure that all upstream lemmas then manage to state this non-zero nature. I have found that in Lean, the time taken to refactor an already formalized lemma is significantly faster than the time taken to formalize the lemma in the first place, and in fact in some cases such a formal refactoring was faster than what a human refactoring would be. For instance, there was a point where a constant 12 improved to a constant 11 in one theorem, and hundreds of lines of downstream code then had to be refactored to reflect this update. With a standard LaTeX writeup this would be a rather tedious and error prone process: but with Lean, one can simply replace 12 with 11 in the theorem, and the compiler will then dutifully point out the dozen or so lines that now do not compile properly, which can then be quickly adjusted with a number of spot fixes without having to do any of the tedious line-by-line checking one would do in a human refactoring.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marton’s conjecture in abelian groups with bounded torsion | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-684661")[#strong[#text("Marton’s conjecture in abelian groups with bounded torsion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("[…] still open. The result has been formalized in the proof assistant language Lean, as discussed in this previous blog post. As a consequence of this result, many of the applications of the previous theorem may now be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-684735")[#strong[#text("Theorem Proving using Machine Learning – Lean 4 – A Guide To Mathematical Studies")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2024")]

#text("[…] Formalizing the proof of PFR in Lean4 using Blueprint: a short tour A slightly longer Lean 4 proof tour […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A pilot project in universal algebra to explore new ways to collaborate and use machine assistance? | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-685847")[#strong[#text("A pilot project in universal algebra to explore new ways to collaborate and use machine assistance? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2024")])]

#text("[…] result (such as the formalization of the recent proof of the PFR conjecture of Marton, discussed in this previous blog post) are currently the main examples of such large-scale collaborations that are enabled via proof […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The equational theories project: a brief tour | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-686012")[#strong[#text("The equational theories project: a brief tour | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("[…] two maintainers of the project, Pietro Monticone and Shreyas Srinivas. In contrast to the prior PFR formalization project, the workflow follows standard Github practices and proceeds roughly as follows: if, during the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca10d9e65f1edfbe9a45e9c8487373d2a3959ebb077c9e94b8ff89325e064e24-87c5afd1564d5946abb811ac2c600008634d5743ab18fdf8cf28dd522d8aa926.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vadim Flyagin")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-687162")[#strong[#text("Vadim Flyagin")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2025")])]

#text("Hello, Terence! There are also other Interactive Theorem Provers (ITPs). I guess that you are interested in those ITPs which have good support of mathematical libraries. There are several such ITPs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Before one can formalize cutting-edge results, one has to formalize all the parts of mathematics they depend on, from elementary arithmetic and algebra to undergraduate and graduate-level mathematics and beyond. Although big-name theorems provide useful milestones, the formal libraries that support them are a better measure of progress. The most impressive mathematical libraries today include those of Mizar, Isabelle, HOL Light, Coq, Metamath, and Lean. By now, these cover most undergraduate-level mathematics and a fair amount of graduate-level mathematics as well. [*]")
]

#text("Can you please explain why you chose Lean among ITPs with good support of mathematical libraries?")

#text("[*] Jeremy Avigad, Mathematics and the formal turn, Bull. Amer. Math. Soc. (N.S.) 61 (2024), no. 2, p. 229. ")#link("https://www.ams.org/journals/bull/2024-61-02/S0273-0979-2024-01832-1/S0273-0979-2024-01832-1.pdf")[#text("https://www.ams.org/journals/bull/2024-61-02/S0273-0979-2024-01832-1/S0273-0979-2024-01832-1.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c30b786a45e7e163b278018af293cc947023a8311c4c15c603d2fa3218e2337-3c7a37dc92d0653f53a6aa151fa472c0f50b691cb5bce647ca258d8a2c682dab.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of baikjinx")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-687629")[#strong[#text("baikjinx")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2025")])]

#text("Hi Terence Tao,")

#text("Not sure if this comment will ever reach you but thanks for sharing this article. I always believe that we should work on a collaborative system to allow mathematicians to work in a decentralized manner to prove theorems.")

#text("From my point of view, blockchain can be used to be the backbone to allow mathematicians to access, contribute and eventually be rewarded for their contributions. The benefit of using blockchain is that (immutable) data can be hold and verified in a decentralized manner. Mechanisms can also be implemented to distribute rewards when theorems have been proven. With the advancement of AI models, each trained by different entities, they could also be part of the contributors when proving/formalizing theorems.")

#text("Here are 2 papers that I, together with my collaborators, have written:")

#link("https://ieeexplore.ieee.org/abstract/document/9805513")[#text("https://ieeexplore.ieee.org/abstract/document/9805513")]

#link("https://ieeexplore.ieee.org/abstract/document/9680536")[#text("https://ieeexplore.ieee.org/abstract/document/9680536")]

#text("Both papers described how we can use blockchain for collaborative mathematical research.")

#text("It would be great to hear your opinion on this approach and if you believe that it would work.")

#text("Thank you and hope you have a great week ahead!")

#text("Sincerely,Jin Xing")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics Distillation Challenge – Equational Theories | What's new")]], [#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/#comment-691978")[#strong[#text("Mathematics Distillation Challenge – Equational Theories | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("[…] (such as the one to formalize the Polynomial Freiman–Ruzsa conjecture of Marton, discussed previously on this blog here) became popular in some circles. And in 2024, I launched the Equational Theories Project (ETP) […]")
]
