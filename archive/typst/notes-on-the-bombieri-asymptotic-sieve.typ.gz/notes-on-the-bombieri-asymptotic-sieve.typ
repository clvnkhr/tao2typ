// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/
// Converted to Typst by tao2typ: "2026-10-14T10:35:44.314940+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on the Bombieri asymptotic sieve", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on the Bombieri asymptotic sieve")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 July 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/")[#text("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(", still unsolved, asserts that there are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is also prime. A more precise form of this conjecture is (a special case) of the ")#link("https://en.wikipedia.org/wiki/Twin_prime#First_Hardy.E2.80.93Littlewood_conjecture")[#text("Hardy-Littlewood prime tuples conjecture")]#text(", which asserts that ")#metadata(none) <tao-07123e1f482356c415f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) = (2\\Pi_2+o(1)) x")]]



#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" and ")#mi("{\\Pi_2 = 0.6606\\dots}")#text(" is the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]

#align(center)[#tao-fit-display[#mitex("\\prod_{p>2} (1 - \\frac{1}{(p-1)^2}).")]]

#text("Because ")#mi("{\\Lambda}")#text(" is almost entirely supported on the primes, it is not difficult to see that ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" implies the twin prime conjecture.")

#text("One can give a heuristic justification of the asymptotic ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" (and hence the twin prime conjecture) via sieve theoretic methods. Recall that the von Mangoldt function can be decomposed as a ")#link("https://en.wikipedia.org/wiki/Dirichlet_convolution")[#text("Dirichlet convolution")]

#align(center)[#tao-fit-display[#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log \\frac{n}{d}")]]

#text("where ")#mi("{\\mu}")#text(" is the ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(". Because of this, we can rewrite the left-hand side of ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" as ")#metadata(none) <tao-4b79be6a5c777ed09b7b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{d \\leq x} \\mu(d) \\sum_{n \\leq x: d|n} \\log\\frac{n}{d} \\Lambda(n+2).")]]



#text(" To compute this double sum, it is thus natural to consider sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: d|n} \\log \\frac{n}{d} \\Lambda(n+2)")]]

#text("or (to simplify things by removing the logarithm)")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: d|n} \\Lambda(n+2).")]]

#text("The prime number theorem in arithmetic progressions suggests that one has an asymptotic of the form ")#metadata(none) <tao-a160524700113ddd3205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x: d|n} \\Lambda(n+2) \\approx \\frac{g(d)}{d} x")]]



#text(" where ")#mi("{g}")#text(" is the multiplicative function with ")#mi("{g(d)=0}")#text(" for ")#mi("{d}")#text(" even and")

#align(center)[#tao-fit-display[#mitex("g(d) := \\frac{d}{\\phi(d)} = \\prod_{p|d} (1-\\frac{1}{p})^{-1}")]]

#text("for ")#mi("{d}")#text(" odd. Summing by parts, one then expects")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: d|n} \\Lambda(n+2)\\log \\frac{n}{d}  \\approx \\frac{g(d)}{d} x \\log \\frac{x}{d}")]]

#text("and so we heuristically have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) \\approx x \\sum_{d \\leq x} \\frac{\\mu(d) g(d)}{d} \\log \\frac{x}{d}.")]]

#text("The Dirichlet series")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\mu(n) g(n)}{n^s}")]]

#text("has an ")#link("https://en.wikipedia.org/wiki/Euler_product")[#text("Euler product factorisation")]

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\mu(n) g(n)}{n^s} = \\prod_p (1 - \\frac{g(p)}{p^s})")]]

#text("for ")#mi("{\\text{Re} s > 1}")#text("; comparing this with the Euler product factorisation")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("for the Riemann zeta function, and recalling that ")#mi("{\\zeta}")#text(" has a simple pole of residue ")#mi("{1}")#text(" at ")#mi("{s=1}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\mu(n) g(n)}{n^s} = \\frac{1}{\\zeta(s)} \\prod_p \\frac{1-g(p)/p^s}{1-p^s}")]]

#text("has a simple zero at ")#mi("{s=1}")#text(" with first derivative")

#align(center)[#tao-fit-display[#mitex("\\prod_p \\frac{1 - g(p)/p}{1-1/p} = 2 \\Pi_2.")]]

#text("From this and standard multiplicative number theory manipulations, one can calculate the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\frac{\\mu(d) g(d)}{d} \\log \\frac{x}{d} = 2 \\Pi_2 + o(1)")]]

#text("which concludes the heuristic justification of ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(".")

#text("What prevents us from making the above heuristic argument rigorous, and thus proving ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" and the twin prime conjecture? Note that the variable ")#mi("{d}")#text(" in ")#link(<tao-4b79be6a5c777ed09b7b>)[#text("(2)")]#text(" ranges to be as large as ")#mi("{x}")#text(". On the other hand, the prime number theorem in arithmetic progressions ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" is not expected to hold for ")#mi("{d}")#text(" anywhere that large (for instance, the left-hand side of ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" vanishes as soon as ")#mi("{d}")#text(" exceeds ")#mi("{x}")#text("). The best unconditional result known of the type ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" is the ")#link("https://en.wikipedia.org/wiki/Siegel%E2%80%93Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(", which allows ")#mi("{d}")#text(" to be as large as ")#mi("{\\log^{O(1)} x}")#text(". Even the powerful ")#link("https://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(" (GRH) only lets one prove an estimate of the form ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" for ")#mi("{d}")#text(" up to about ")#mi("{x^{1/2-o(1)}}")#text(".")

#text("However, because of the averaging effect of the summation in ")#mi("{d}")#text(" in ")#link(<tao-4b79be6a5c777ed09b7b>)[#text("(2)")]#text(", we don’t need the asymptotic ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" to be true for ")#emph[#text("all")]#text(" ")#mi("{d}")#text(" in a particular range; having it true for ")#emph[#text("almost all")]#text(" ")#mi("{d}")#text(" in that range would suffice. Here the situation is much better; the celebrated Bombieri-Vinogradov theorem (sometimes known as “GRH on the average”) implies, roughly speaking, that the approximation ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" is valid for ")#emph[#text("almost all")]#text(" ")#mi("{d \\leq x^{1/2-\\varepsilon}}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(". While this is not enough to control ")#link(<tao-4b79be6a5c777ed09b7b>)[#text("(2)")]#text(" or ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(", the Bombieri-Vinogradov theorem can at least be used to control variants of ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} (\\sum_{d|n} \\lambda_d) \\Lambda(n+2)")]]

#text("for various sieve weights ")#mi("{\\lambda_d}")#text(" whose associated divisor function ")#mi("{\\sum_{d|n} \\lambda_d}")#text(" is supposed to approximate the von Mangoldt function ")#mi("{\\Lambda}")#text(", although that theorem only lets one do this when the weights ")#mi("{\\lambda_d}")#text(" are supported on the range ")#mi("{d \\leq x^{1/2-\\varepsilon}}")#text(". This is still enough to obtain some partial results towards ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text("; for instance, by selecting weights according to the ")#link("https://en.wikipedia.org/wiki/Selberg_sieve")[#text("Selberg sieve")]#text(", one can use the Bombieri-Vinogradov theorem to establish the upper bound ")#metadata(none) <tao-1b112ee7d79cd37d93b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) \\leq (4+o(1)) 2 \\Pi_2 x,")]]



#text(" which is off from ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" by a factor of about ")#mi("{4}")#text(". See for instance ")#link("https://terrytao.wordpress.com/category/teaching/254a-analytic-prime-number-theory/")[#text("this blog post")]#text(" for details.")

#text("It has been difficult to improve upon the Bombieri-Vinogradov theorem in its full generality, although there are various improvements to certain restricted versions of the Bombieri-Vinogradov theorem, for instance in the famous work of Zhang on bounded gaps between primes. Nevertheless, it is believed that the ")#link("https://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture (EH)")]#text(" holds, which roughly speaking would mean that ")#link(<tao-a160524700113ddd3205>)[#text("(3)")]#text(" now holds for almost all ")#mi("{d \\leq x^{1-\\varepsilon}}")#text(" for any fixed ")#mi("{\\varepsilon>0}")#text(". (Unfortunately, the ")#mi("{\\varepsilon}")#text(" factor cannot be removed, as investigated in ")#link("http://www.ams.org/mathscinet-getitem?mr=986796")[#text("a")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1080647")[#text("series")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1145606")[#text("of")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1133852")[#text("papers")]#text(" by Friedlander, Granville, and also Hildebrand and Maier.) This comes tantalisingly close to having enough distribution to control all of ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(". Unfortunately, it still falls short. Using this conjecture in place of the Bombieri-Vinogradov theorem leads to various improvements to sieve theoretic bounds; for instance, the factor of ")#mi("{4+o(1)}")#text(" in ")#link(<tao-1b112ee7d79cd37d93b3>)[#text("(4)")]#text(" can now be improved to ")#mi("{2+o(1)}")#text(".")

#text("In ")#link("http://www.ams.org/mathscinet-getitem?mr=396435")[#text("two")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1133852")[#text("papers")]#text(" from the 1970s (which can be found online ")#link("http://matwbn.icm.edu.pl/ksiazki/aa/aa28/aa2828.pdf")[#text("here")]#text(" and ")#link("http://media.accademiaxl.it/memorie/Serie5_V0102.pdf")[#text("here")]#text(" respectively, the latter starting on page 255 of the pdf), Bombieri developed what is now known as the ")#emph[#text("Bombieri asymptotic sieve")]#text(" to clarify the situation more precisely. First, he showed that on the Elliott-Halberstam conjecture, while one still could not establish the asymptotic ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(", one could prove the generalised asymptotic ")#metadata(none) <tao-7e78770ae44265567975>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{n \\leq x} \\Lambda_k(n) \\Lambda(n+2) = (2\\Pi_2+o(1)) k x \\log^{k-1} x")]]



#text(" for all natural numbers ")#mi("{k \\geq 2}")#text(", where the generalised von Mangoldt functions ")#mi("{\\Lambda_k}")#text(" are defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\Lambda_k(n) := \\sum_{d|n} \\mu(d) \\log^k \\frac{n}{d}.")]]

#text("These functions behave like the von Mangoldt function, but are concentrated on ")#mi("{k}")#text("-almost primes (numbers with at most ")#mi("{k}")#text(" prime factors) rather than primes. The right-hand side of ")#link(<tao-7e78770ae44265567975>)[#text("(5)")]#text(" corresponds to what one would expect if one ran the same heuristics used to justify ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(". Sadly, the ")#mi("{k=1}")#text(" case of ")#link(<tao-7e78770ae44265567975>)[#text("(5)")]#text(", which is just ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(", is just barely excluded from Bombieri’s analysis.")

#text("More generally, on the assumption of EH, the Bombieri asymptotic sieve provides the asymptotic ")#metadata(none) <tao-005754e953d955a1e75e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{n \\leq x} \\Lambda_{(k_1,\\dots,k_r)}(n) \\Lambda(n+2)")]]





#align(center)[#tao-fit-display[#mitex("= (2\\Pi_2+o(1)) \\frac{\\prod_{i=1}^r k_i!}{(k_1+\\dots+k_r-1)!} x \\log^{k_1+\\dots+k_r-1} x")]]

#text("for any fixed ")#mi("{r \\geq 1}")#text(" and any tuple ")#mi("{(k_1,\\dots,k_r)}")#text(" of natural numbers other than ")#mi("{(1,\\dots,1)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{(k_1,\\dots,k_r)} := \\Lambda_{k_1} * \\dots * \\Lambda_{k_r}")]]

#text("is a further generalisation of the von Mangoldt function (now concentrated on ")#mi("{k_1+\\dots+k_r}")#text("-almost primes). By combining these asymptotics with some elementary identities involving the ")#mi("{\\Lambda_{(k_1,\\dots,k_r)}}")#text(", together with the Weierstrass approximation theorem, Bombieri was able to control a wide family of sums including ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(", except for one undetermined scalar ")#mi("{\\delta_x \\in [0,2]}")#text(". Namely, he was able to show (again on EH) that for any fixed ")#mi("{r \\geq 1}")#text(" and any continuous function ")#mi("{g_r}")#text(" on the simplex ")#mi("{\\Delta_r := \\{ (t_1,\\dots,t_r) \\in {\\bf R}^r: t_1+\\dots+t_r = 1; 0 \\leq t_1 \\leq \\dots \\leq t_r\\}}")#text(" that had suitable vanishing at the boundary, the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n=p_1 \\dots p_r} g_r( \\frac{\\log p_1}{\\log n}, \\dots, \\frac{\\log p_r}{\\log n} ) \\Lambda(n+2)")]]

#text("was equal to ")#metadata(none) <tao-40bb59dfb2d438c77a19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(\\delta_x+o(1)) \\int_{\\Delta_r} g_r \\frac{x}{\\log x}")]]



#text(" when ")#mi("{r}")#text(" was odd and ")#metadata(none) <tao-7b0d223bb0ad78e990a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("(2-\\delta_x+o(1)) \\int_{\\Delta_r} g_r \\frac{x}{\\log x}")]]



#text(" when ")#mi("{r}")#text(" was even, where the integral on ")#mi("{\\Delta_r}")#text(" is with respect to the measure ")#mi("{\\frac{dt_1 \\dots dt_{r-1}}{t_1 \\dots t_r}}")#text(" (this is Dirac measure in the case ")#mi("{r=1}")#text("). In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) = (\\delta_x + o(1)) 2 \\Pi_2 x")]]

#text("and the twin prime conjecture would be proved if one could show that ")#mi("{\\delta_x}")#text(" is bounded away from zero, while ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" is equivalent to the assertion that ")#mi("{\\delta_x}")#text(" is equal to ")#mi("{1+o(1)}")#text(". Unfortunately, no additional bound beyond the inequalities ")#mi("{0 \\leq \\delta_x \\leq 2}")#text(" provided by the Bombieri asymptotic sieve is known, even if one assumes all other major conjectures in number theory than the prime tuples conjecture and its variants (e.g. GRH, GEH, ")#link("https://en.wikipedia.org/wiki/Montgomery%27s_pair_correlation_conjecture")[#text("GUE")]#text(", ")#link("https://en.wikipedia.org/wiki/Abc_conjecture")[#text("abc")]#text(", Chowla, …).")

#text("To put it another way, the Bombieri asymptotic sieve is able (on EH) to compute asymptotics for sums ")#metadata(none) <tao-14f91bc93dc4f0ff486e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{n \\leq x} f(n) \\Lambda(n+2)")]]



#text(" without needing to know the unknown scalar ")#mi("{\\delta_x}")#text(", when ")#mi("{f}")#text(" is a function supported on almost primes of the form")

#align(center)[#tao-fit-display[#mitex("f(p_1 \\dots p_r) = g_r( \\frac{\\log p_1}{\\log n}, \\dots, \\frac{\\log p_r}{\\log n} )")]]

#text("for ")#mi("{1 \\leq r \\leq r_*}")#text(" and some fixed ")#mi("{r_*}")#text(", with ")#mi("{f}")#text(" vanishing elsewhere and for some continuous (symmetric) functions ")#mi("{g_r: \\Delta_r \\rightarrow {\\bf C}}")#text(" obeying some vanishing at the boundary, so long as the parity condition")

#align(center)[#tao-fit-display[#mitex("\\sum_{r \\text{ odd}} \\int_{\\Delta_r} g_r = \\sum_{r \\text{ even}} \\int_{\\Delta_r} g_r")]]

#text("is obeyed (informally: ")#mi("{f}")#text(" gives the same weight to products of an odd number of primes as to products of an even number of primes, or to put it another way, ")#mi("{f}")#text(" is asymptotically orthogonal to the Möbius function ")#mi("{\\mu}")#text("). But when ")#mi("{f}")#text(" violates the parity condition, the asymptotic involves the unknown ")#mi("{\\delta_x}")#text(". This scalar ")#mi("{\\delta_x}")#text(" thus embodies the “parity problem” for the twin prime conjecture (discussed in ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")[#text("previous")]#text(" ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("blog")]#text(" posts).")

#text("Because the obstruction to the parity problem is only one-dimensional (on EH), one can replace any parity-violating weight (such as ")#mi("{\\Lambda}")#text(") with any other parity-violating weight and obtain a logically equivalent estimate. For instance, to prove the twin prime conjecture on EH, it would suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 p_2 p_3 \\leq x: p_1,p_2,p_3 \\geq x^\\alpha} \\Lambda(p_1 p_2 p_3 + 2) \\gg \\frac{x}{\\log x}")]]

#text("for some fixed ")#mi("{\\alpha>0}")#text(", or equivalently that there are ")#mi("{\\gg \\frac{x}{\\log^2 x}}")#text(" solutions to the equation ")#mi("{p - p_1 p_2 p_3 = 2}")#text(" in primes with ")#mi("{p \\leq x}")#text(" and ")#mi("{p_1,p_2,p_3 \\geq x^\\alpha}")#text(". (In some cases, this sort of reduction can also be made using other sieves than the Bombieri asymptotic sieve, as was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1154043")[#text("by Ng")]#text(".) As another example, the Bombieri asymptotic sieve can be used to show that the asymptotic ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" is equivalent to the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) 1_R(n) \\Lambda(n+2) = o( \\frac{x}{\\log x})")]]

#text("where ")#mi("{R}")#text(" is the set of numbers that are ")#emph[#text("rough")]#text(" in the sense that they have no prime factors less than ")#mi("{x^\\alpha}")#text(" for some fixed ")#mi("{\\alpha>0}")#text(" (the function ")#mi("{\\mu 1_R}")#text(" clearly correlates with ")#mi("{\\mu}")#text(" and so must violate the parity condition). One can replace ")#mi("{1_R}")#text(" with similar sieve weights (e.g. a Selberg sieve) that concentrate on almost primes if desired.")

#text("As it turns out, if one is willing to strengthen the assumption of the Elliott-Halberstam (EH) conjecture to the assumption of the ")#emph[#text("generalised Elliott-Halberstam (GEH) conjecture")]#text(" (as formulated for instance in Claim 2.6 of ")#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")[#text("the Polymath8b paper")]#text("), one can also swap the ")#mi("{\\Lambda(n+2)}")#text(" factor in the above asymptotics with other parity-violating weights and obtain a logically equivalent estimate, as the Bombieri asymptotic sieve also applies to weights such as ")#mi("{\\mu 1_R}")#text(" under the assumption of GEH. For instance, on GEH one can use two such applications of the Bombieri asymptotic sieve to show that the twin prime conjecture would follow if one could show that there are ")#mi("{\\gg \\frac{x}{\\log^2 x}}")#text(" solutions to the equation")

#align(center)[#tao-fit-display[#mitex("p_1 p_2 - p_3 p_4 = 2")]]

#text("in primes with ")#mi("{p_1,p_2,p_3,p_4 \\geq x^\\alpha}")#text(" and ")#mi("{p_1 p_2 \\leq x}")#text(", for some ")#mi("{\\alpha > 0}")#text(". Similarly, on GEH the asymptotic ")#link(<tao-07123e1f482356c415f6>)[#text("(1)")]#text(" is equivalent to the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) 1_R(n) \\mu(n+2) 1_R(n+2) = o( \\frac{x}{\\log^2 x})")]]

#text("for some fixed ")#mi("{\\alpha>0}")#text(", and similarly with ")#mi("{1_R}")#text(" replaced by other sieves. This form of the quantitative twin primes conjecture is appealingly similar to the (special case)")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\mu(n+2) = o(x)")]]

#text("of the Chowla conjecture, for which there has been some recent progress (discussed for instance in ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2016/05/16/equivalence-of-the-logarithmically-averaged-chowla-and-sarnak-conjectures/")[#text("recent")]#text(" ")#link("https://terrytao.wordpress.com/2015/03/17/an-averaged-form-of-chowlas-conjecture/")[#text("posts")]#text("). Informally, the Bombieri asymptotic sieve lets us (on GEH) view the twin prime conjecture as a sort of Chowla conjecture restricted to almost primes. Unfortunately, the recent progress on the Chowla conjecture relies heavily on the multiplicativity of ")#mi("{\\mu}")#text(" at small primes, which is completely destroyed by inserting a weight such as ")#mi("{1_R}")#text(", so this does not yet yield a viable path towards the twin prime conjecture even assuming GEH. Still, the similarity is striking, and one can hope that further ways to attack the Chowla conjecture may emerge that could impact the twin prime conjecture. (Alternatively, if one assumes a sufficiently optimistic version of the GEH, one could perhaps relax the notion of “almost prime” to the extent that one could start usefully using multiplicativity at smallish primes, though this seems rather wishful at present, particularly since the most optimistic versions of GEH are known to be false.)")

#text("The Bombieri asymptotic sieve is already well explained in the original two papers of Bombieri; there is also a slightly different treatment of the sieve ")#link("http://www.ams.org/mathscinet-getitem?mr=1399351")[#text("by Friedlander and Iwaniec")]#text(", as well as a simplified version in the ")#link("http://www.ams.org/mathscinet-getitem?mr=2647984")[#text("book of Friedlander and Iwaniec")]#text(" (in which the distribution hypothesis is strengthened in order to shorten the arguments. I’ve decided though to write up my own notes on the sieve below the fold; this is primarily for my own benefit, but may be useful to some readers also. I largely follow the treatment of Bombieri, with the one idiosyncratic twist of replacing the usual “elementary” Selberg sieve with the “analytic” Selberg sieve used in particular in many of the breakthrough works in small gaps between primes; I prefer working with the latter due to its Fourier-analytic flavour.")

#heading(level: 1)[#strong[#text(" — 1. Controlling generalised von Mangoldt sums — ")]]

#text("To prove ")#link(<tao-7e78770ae44265567975>)[#text("(5)")]#text(", we shall first generalise it, by replacing the sequence ")#mi("{\\Lambda(n+2)}")#text(" by a more general sequence ")#mi("{a_n}")#text(" obeying the following axioms:")

#list(
[#text("(i) (Non-negativity) One has ")#mi("{a_n \\geq 0}")#text(" for all ")#mi("{n}")#text(".")],
[#text("(ii) (Crude size bound) One has ")#mi("{a_n \\ll \\tau(n)^{O(1)} \\log^{O(1)} n}")#text(" for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")],
[#text("(iii) (Size) We have ")#mi("{\\sum_{n \\leq x} a_n = (C+o(1)) x}")#text(" for some constant ")#mi("{C>0}")#text(".")],
[#text("(iv) (Elliott-Halberstam type conjecture) For any ")#mi("{\\varepsilon,A>0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x^{1-\\varepsilon}} \\left|\\sum_{n \\leq x: d|n} a_n - C x \\frac{g(d)}{d}\\right| \\ll_{\\varepsilon,A} x \\log^{-A} x", block: true)]]

#text("where ")#mi("{g}")#text(" is a multiplicative function with ")#mi("{g(p^j) = 1 + O(1/p)}")#text(" for all primes ")#mi("{p}")#text(" and ")#mi("{j \\geq 1}")#text(".")]
)

#text("These axioms are a little bit stronger than what is actually needed to make the Bombieri asymptotic sieve work, but we will not attempt to work with the weakest possible axioms here.")

#text("We introduce the function")

#align(center)[#tao-fit-display[#mitex("G(s) := \\prod_p \\frac{1-g(p)/p^s}{1-1/p^s}")]]

#text("which is analytic for ")#mi("{\\text{Re}(s) > 0}")#text("; in particular it can be evaluated at ")#mi("{s=1}")#text(" to yield")

#align(center)[#tao-fit-display[#mitex("G(1) = \\prod_p \\frac{1-g(p)/p}{1-1/p}.")]]

#text("There are two model examples of data ")#mi("{a_n, C, g}")#text(" to keep in mind. The first, discussed in the introduction, is when ")#mi("{a_n =\\Lambda(n+2)}")#text(", then ")#mi("{C = 2 \\Pi_2}")#text(" and ")#mi("{g}")#text(" is as in the introduction; one of course needs EH to justify axiom (iv) in this case. The other is when ")#mi("{a_n=1}")#text(", in which case ")#mi("{C=1}")#text(" and ")#mi("{g(n)=1}")#text(" for all ")#mi("{n}")#text(". We will later take advantage of the second example to avoid doing some (routine, but messy) main term computations.")

#text("The main result of this section is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" ")#metadata(none) <tao-c353f7dabebea3a68d63>#text(" Let ")#mi("{a_n, g, C, G}")#text(" be as above. Let ")#mi("{\\vec k = (k_1,\\dots,k_r)}")#text(" be a tuple of natural numbers (independent of ")#mi("{x}")#text(") that is not equal to ")#mi("{(1,\\dots,1)}")#text(". Then one has the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} \\Lambda_{\\vec k}(n) a_n = (G(1)+o(1)) \\frac{\\prod_{i=1}^r k_i!}{(\\left|\\vec k\\right|-1)!} C x \\log^{\\left|\\vec k\\right|-1} x", block: true)]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#tao-math("{\\left|\\vec k\\right| := k_1 + \\dots + k_r}", block: false)#text(".")
]

#text("Note that this recovers ")#link(<tao-7e78770ae44265567975>)[#text("(5)")]#text(" (on EH) as a special case.")

#text("We now begin the proof of this theorem. Henceforth we allow implied constants in the ")#mi("{O()}")#text(" or ")#mi("{\\ll}")#text(" notation to depend on ")#mi("{r, \\vec k}")#text(" and ")#mi("{g,G}")#text(".")

#text("It will be convenient to replace the range ")#mi("{n \\leq x}")#text(" by a shorter range by the following standard localisation trick. Let ")#mi("{B}")#text(" be a large quantity depending on ")#mi("{r, \\vec k}")#text(" to be chosen later, and let ")#mi("{I}")#text(" denote the interval ")#mi("{\\{ n: x - x \\log^{-B} x \\leq n \\leq x \\}}")#text(". We will show the estimate ")#metadata(none) <tao-b6cf348bc9b1a71d9db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) a_n = (G(1)+o(1)) \\frac{\\prod_{i=1}^r k_i!}{(\\left|\\vec k\\right|-1)!} C |I| \\log^{\\left|\\vec k\\right|-1} x", block: true)]]



#text(" from which the original claim follows by a routine summation argument. Observe from axiom (iv) and the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x^{1-\\varepsilon}: \\mu^2(d)=1} |\\sum_{n \\in I: d|n} a_n - C |I\\left| \\frac{g(d)}{d}\\right| \\ll_{\\varepsilon,A} x \\log^{-A} x", block: true)]]

#text("for any ")#mi("{\\varepsilon,A > 0}")#text(".")

#text("Write ")#mi("{L}")#text(" for the logarithm function ")#mi("{L(n) := \\log n}")#text(", thus ")#mi("{\\Lambda_k = \\mu * L^k}")#text(" for any ")#mi("{k}")#text(". Without loss of generality we may assume that ")#mi("{k_r > 1}")#text("; we then factor ")#mi("{\\Lambda_{\\vec k} = \\mu_{\\vec k} * L^{k_r}}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\vec k} := \\Lambda_{k_1} * \\dots * \\Lambda_{k_{r-1}} * \\mu.")]]

#text("This function is just ")#mi("{\\mu}")#text(" when ")#mi("{r=1}")#text(". When ")#mi("{r>1}")#text(" the function is more complicated, but we at least have the following crude bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-9b6d3dc089e58963b9d2>#text(" One has the pointwise bound ")#tao-math("{\\left|\\mu_{\\vec k}\\right| \\leq L^{\\left|\\vec k\\right|-k_r}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{r}")#text(". The case ")#mi("{r=1}")#text(" is obvious, so suppose ")#mi("{r>1}")#text(" and the claim has already been proven for ")#mi("{r-1}")#text(". Since ")#mi("{\\mu_{\\vec k} = \\Lambda_{k_1} * \\mu_{(k_2,\\dots,k_r)}}")#text(", we see from induction hypothesis and the triangle inequality that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\mu_{\\vec k}\\right| \\leq \\Lambda_{k_1} * L^{\\left|\\vec k\\right| - k_r - k_1} \\leq L^{\\left|\\vec k\\right| - k_r - k_1} (\\Lambda_{k_1} * 1).", block: true)]]

#text("Since ")#mi("{\\Lambda_{k_1}*1 = L^{k_1}}")#text(" by Möbius inversion, the claim follows. ")#mi("\\Box")

#text("We can write")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\vec k}(n) = \\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{n}{d}.")]]

#text("In the region ")#mi("{n \\in I}")#text(", we have ")#mi("{\\log^{k_r} \\frac{n}{d} = \\log^{k_r} \\frac{x}{d} + O( \\log^{-B+O(1)} x )}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{\\vec k}(n) = \\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} + O( \\tau(x) \\log^{-B+O(1)} x )")]]

#text("for ")#mi("{n \\in I}")#text(". The contribution of the error term to ")#mi("{O( \\tau(x) \\log^{-B+O(1)} x )}")#text(" to ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(10)")]#text(" is easily seen to be negligible if ")#mi("{B}")#text(" is large enough, so we may freely replace ")#mi("{\\Lambda_{\\vec k}(n)}")#text(" with ")#mi("{\\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d}}")#text(" with little difficulty.")

#text("If we insert this replacement directly into the left-hand side of ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(10)")]#text(" and rearrange, we get")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} \\sum_{n \\in I: d|n} a_d.")]]

#text("We can’t quite control this using axiom (iv) because the range of ")#mi("{d}")#text(" is a bit too big, as explained in the introduction. So let us introduce a truncated function ")#metadata(none) <tao-116f54c41d0405dbb10e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\Lambda_{\\vec k,\\varepsilon}(n) := \\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} \\eta_\\varepsilon( \\frac{\\log d}{\\log x} )")]]



#text(" where ")#mi("{\\varepsilon>0}")#text(" is a small quantity to be chosen later, and ")#mi("{\\eta_\\varepsilon: {\\bf R} \\rightarrow [0,1]}")#text(" is a smooth function that equals ")#mi("{1}")#text(" on ")#mi("{(-\\infty,1-4\\varepsilon)}")#text(" and equals ")#mi("{0}")#text(" on ")#mi("{(1-3\\varepsilon,+\\infty)}")#text(". Suppose one could establish the following two estimates for any fixed ")#mi("{\\varepsilon>0}")#text(": ")#metadata(none) <tao-7549d5108f1ab0eb7b2c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) a_n = \\sum_{n \\in I} \\Lambda_{\\vec k,\\varepsilon}(n) a_n + O( (\\varepsilon+o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x )", block: true)]]



#text(" and ")#metadata(none) <tao-cb0ea8eb211e766e7405>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k,\\varepsilon}(n) a_n = C Q_{\\varepsilon,x} G(1) + o( \\left|I\\right| \\log^{\\left|\\vec k\\right|-1} x )", block: true)]]



#text(" where ")#mi("{Q_{\\varepsilon,x}}")#text(" is a quantity that depends on ")#mi("{\\varepsilon, \\eta_\\varepsilon, \\vec k, B, x}")#text(" but not on ")#mi("{C, g,G}")#text(". Then on combining the two estimates we would have ")#metadata(none) <tao-7b1c7d570ea41bf98d50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) a_n = C Q_{\\varepsilon,x} G(1) + (O(\\varepsilon) + o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x.", block: true)]]



#text(" One could in principle compute ")#mi("{Q_{\\varepsilon,x}}")#text(" explicitly from the proof of ")#link(<tao-cb0ea8eb211e766e7405>)[#text("(13)")]#text(", but one can avoid doing so by the following comparison trick. In the special case ")#mi("{a_n=1}")#text(", standard multiplicative number theory (noting that the Dirichlet series ")#mi("{\\sum_n \\frac{\\Lambda_{\\vec k}(n)}{n^s}}")#text(" has a pole of order ")#tao-math("{\\left|\\vec k\\right|}", block: false)#text(" at ")#mi("{s=1}")#text(", with top Laurent coefficient ")#mi("{\\prod_{j=1}^r k_j!}")#text(") gives the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) a_n = \\frac{\\prod_{i=1}^r k_i!}{(\\left|\\vec k\\right|-1)!} + o(1)) |I| \\log^{\\left|\\vec k\\right|-1} x", block: true)]]

#text("which when compared with ")#link(<tao-7b1c7d570ea41bf98d50>)[#text("(14)")]#text(" for ")#mi("{a_n=1}")#text(" (recalling that ")#mi("{G(1)=C=1}")#text(" in this case) gives the formula")

#align(center)[#tao-fit-display[#tao-math("Q_{\\varepsilon,x} = (\\prod_{j=1}^r k_j + O(\\varepsilon)) |I| \\log^{\\left|\\vec k\\right|-1} x.", block: true)]]

#text("Inserting this back into ")#link(<tao-7b1c7d570ea41bf98d50>)[#text("(14)")]#text(" and recalling that ")#mi("{\\varepsilon>0}")#text(" can be made arbitrarily small, we obtain ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(10)")]#text(".")

#text("As it turns out, the estimate ")#link(<tao-cb0ea8eb211e766e7405>)[#text("(13)")]#text(" is easy to establish, but the estimate ")#link(<tao-7549d5108f1ab0eb7b2c>)[#text("(12)")]#text(" is not, roughly speaking because the typical number ")#mi("{n}")#text(" in ")#mi("{I}")#text(" has too many divisors ")#mi("{d}")#text(" in the range ")#mi("{[x^{1-4\\varepsilon},1]}")#text(", each of which gives a contribution to the error term. (In the book of Friedlander and Iwaniec, the estimate ")#link(<tao-cb0ea8eb211e766e7405>)[#text("(13)")]#text(" is established anyway, but only after assuming a stronger version of (iv), roughly speaking in which ")#mi("{d}")#text(" is allowed to be as large as ")#mi("{x \\exp( -\\log^{1/4} x)}")#text(".) To resolve this issue, we will insert a preliminary sieve ")#mi("{\\nu_\\varepsilon}")#text(" that will remove most of the potential divisors ")#mi("{d}")#text(" i the range ")#mi("{[x^{1-4\\varepsilon},1]}")#text(" (leaving only about ")#mi("{O(1)}")#text(" such divisors on the average for typical ")#mi("{n}")#text("), making the analogue of ")#link(<tao-7549d5108f1ab0eb7b2c>)[#text("(12)")]#text(" easier to prove (at the cost of making the analogue of ")#link(<tao-cb0ea8eb211e766e7405>)[#text("(13)")]#text(" more difficult). Namely, if one can find a function ")#mi("{\\nu_\\varepsilon: {\\bf N} \\rightarrow {\\bf R}}")#text(" for which one has the estimates ")#metadata(none) <tao-af13dab7f404890f3e9a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) a_n = \\sum_{n \\in I} \\Lambda_{\\vec k}(n) \\nu_\\varepsilon(n) a_n + O( (\\varepsilon+o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x ),", block: true)]]





#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\Lambda_{\\vec k}(n) \\nu_\\varepsilon(n) a_n")]]

#metadata(none) <tao-91c9d6cb2482b4ea8cef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("= \\sum_{n \\in I} \\Lambda_{\\vec k,\\varepsilon}(n) \\nu_\\varepsilon(n) a_n + O( (\\varepsilon+o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x )", block: true)]]



#text(" and ")#metadata(none) <tao-15a9888c4942fb01aff7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\sum_{n \\in I} \\Lambda_{\\vec k,\\varepsilon}(n) \\nu_\\varepsilon(n) a_n = C Q^{\\prime}_{\\varepsilon,x} G(1) + o( \\left|I\\right| \\log^{\\left|\\vec k\\right|-1} x )", block: true)]]



#text(" for some quantity ")#mi("{Q^{\\prime}_{\\varepsilon,x}}")#text(" that depends on ")#mi("{\\varepsilon, \\eta_\\varepsilon, \\vec k, B, x}")#text(" but not on ")#mi("{C, g, G,}")#text(", then by repeating the previous arguments we will again be able to establish ")#link(<tao-b6cf348bc9b1a71d9db0>)[#text("(10)")]#text(".")

#text("The key estimate is ")#link(<tao-91c9d6cb2482b4ea8cef>)[#text("(16)")]#text(". As we shall see, when comparing ")#mi("{\\Lambda_{\\vec k}(n) \\nu_\\varepsilon(n)}")#text(" with ")#mi("{\\Lambda_{\\vec k,\\varepsilon}(n) \\nu_\\varepsilon(n)}")#text(", the weight ")#mi("{\\nu_\\varepsilon}")#text(" will cost us a factor of ")#mi("{1/\\varepsilon}")#text(", but the ")#mi("{\\log^{k_r} \\frac{x}{d}}")#text(" term in the definitions of ")#mi("{\\Lambda_{\\vec k}}")#text(" and ")#mi("{\\Lambda_{\\vec k,\\varepsilon}}")#text(" will recover a factor of ")#mi("{\\varepsilon^{k_r}}")#text(", which will give the desired bound since we are assuming ")#mi("{k_r > 1}")#text(".")

#text("One has some flexibility in how to select the weight ")#mi("{\\nu_\\varepsilon}")#text(": basically any standard sieve that uses divisors of size at most ")#mi("{x^{2\\varepsilon}}")#text(" to localise (at least approximately) to numbers that are rough in the sense that they have no (or at least very few) factors less than ")#mi("{x^\\varepsilon}")#text(", will do. We will use the analytic Selberg sieve choice ")#metadata(none) <tao-add93659279b4ba737e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\nu_\\varepsilon(n) := (\\sum_{d|n} \\mu(d) \\psi( \\frac{\\log d}{\\varepsilon \\log x} ))^2")]]



#text(" where ")#mi("{\\psi: {\\bf R} \\rightarrow [0,1]}")#text(" is a smooth function supported on ")#mi("{[-1,1]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-1/2,1/2]}")#text(".")

#text("It remains to establish the bounds ")#link(<tao-af13dab7f404890f3e9a>)[#text("(15)")]#text(", ")#link(<tao-91c9d6cb2482b4ea8cef>)[#text("(16)")]#text(", ")#link(<tao-15a9888c4942fb01aff7>)[#text("(17)")]#text(". To warm up and introduce the various methods needed, we begin with the standard bound ")#metadata(none) <tao-32000e140c9ebe9ba782>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_{n \\in I} \\nu_\\varepsilon(n) a_n = \\frac{C\\left|I\\right|}{\\varepsilon \\log x} (\\int_0^1 \\psi^{\\prime}(u)^2\\ du) G(1) + o(1)),", block: true)]]



#text(" where ")#mi("{\\psi^{\\prime}}")#text(" denotes the derivative of ")#mi("{\\psi}")#text(". Note the loss of ")#mi("{1/\\varepsilon}")#text(" that had previously been pointed out. In the arguments that follows I will be a little brief with the details, as they are standard (see e.g. ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("this previous post")]#text(").")

#text("We now prove ")#link(<tao-32000e140c9ebe9ba782>)[#text("(19)")]#text(". The left-hand side can be expanded as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\sum_{n \\in I: [d_1,d_2]|n} a_n")]]

#text("where ")#mi("{[d_1,d_2]}")#text(" denotes the least common multiple of ")#mi("{d_1}")#text(" and ")#mi("{d_2}")#text(". From the support of ")#mi("{\\psi}")#text(" we see that the summand is only non-vanishing when ")#mi("{[d_1,d_2] \\leq x^{2\\varepsilon}}")#text(". We now use axiom (iv) and split the left-hand side into a main term")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\frac{g(d)}{d} C \\left|I\\right|", block: true)]]

#text("and an error term that is at most ")#metadata(none) <tao-67078e8f78a509a170aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("O_\\varepsilon( \\sum_{d \\leq x^{2\\varepsilon}} \\tau(d)^{O(1)} | \\sum_{n \\in I: d|n} a_n - \\frac{g(d)}{d} C |I|| ).")]]



#text(" From axiom (ii) and elementary multiplicative number theory, we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x} \\tau(d)^{O(1)} | \\sum_{n \\in I: d|n} a_n - \\frac{g(d)}{d} C \\left|I\\right| \\ll C |I| \\log^{O(1)} x", block: true)]]

#text("so from axiom (iv) and Cauchy-Schwarz we see that the error term ")#link(<tao-67078e8f78a509a170aa>)[#text("(20)")]#text(" is acceptable. Thus it will suffice to establish the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\frac{g([d_1,d_2])}{[d_1,d_2]}")]]

#metadata(none) <tao-cb37790a8586667fe9d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("= \\frac{1}{\\varepsilon \\log x} (\\int_0^1 \\psi^{\\prime}(u)^2\\ du) G(1) + o(\\frac{1}{\\log x}).")]]



#text(" The summand here is almost, but not quite, multiplicative in ")#mi("{d_1,d_2}")#text(". To make it genuinely multiplicative, we perform a (shifted) Fourier expansion ")#metadata(none) <tao-6d7e04068fa604f0ea60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\psi(u) = \\int_{\\bf R} e^{-(1+it)u} \\Psi(t)\\ dt")]]



#text(" for some rapidly decreasing function ")#mi("{\\Psi}")#text(" (essentially the Fourier transform of ")#mi("{e^u \\psi(u)}")#text("). Thus")

#align(center)[#tao-fit-display[#mitex("\\psi( \\frac{\\log d}{\\varepsilon \\log x} ) = \\int_{\\bf R} \\frac{1}{d^{\\frac{1+it}{\\varepsilon \\log x}}} \\Psi(t)\\ dt,")]]

#text("and so the left-hand side of ")#link(<tao-cb37790a8586667fe9d5>)[#text("(21)")]#text(" can be rearranged using Fubini’s theorem as ")#metadata(none) <tao-a12947dbf7d04ce3a055>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\int_{\\bf R} \\int_{\\bf R} E(\\frac{1+it_1}{\\varepsilon \\log x},\\frac{1+it_2}{\\varepsilon \\log x})\\ \\Psi(t_1) \\Psi(t_2) dt_1 dt_2")]]



#text(" where")

#align(center)[#tao-fit-display[#mitex("E(s_1,s_2) := \\sum_{d_1,d_2} \\frac{\\mu(d_1) \\mu(d_2)}{d_1^{s_1}d_2^{s_2}} \\frac{g([d_1,d_2])}{[d_1,d_2]}.")]]

#text("We can factorise ")#mi("{E(s_1,s_2)}")#text(" as an Euler product:")

#align(center)[#tao-fit-display[#mitex("E(s_1,s_2) = \\prod_p (1 - \\frac{g(p)}{p^{1+s_1}} - \\frac{g(p)}{p^{1+s_2}} + \\frac{g(p)}{p^{1+s_1+s_2}}).")]]

#text("Taking absolute values and using Mertens’ theorem leads to the crude bound")

#align(center)[#tao-fit-display[#mitex("E(\\frac{1+it_1}{\\varepsilon \\log x},\\frac{1+it_2}{\\varepsilon \\log x}) \\ll_\\varepsilon \\log^{O(1)} x")]]

#text("which when combined with the rapid decrease of ")#mi("{\\Psi}")#text(", allows us to restrict the region of integration in ")#link(<tao-a12947dbf7d04ce3a055>)[#text("(23)")]#text(" to the square ")#tao-math("{\\{ \\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log x} \\}}", block: false)#text(" (say) with negligible error. Next, we use the Euler product")

#align(center)[#tao-fit-display[#mitex("\\zeta(s) = \\prod_p (1-\\frac{1}{p^s})^{-1}")]]

#text("for ")#mi("{\\text{Re} s > 1}")#text(" to factorise")

#align(center)[#tao-fit-display[#mitex("E(s_1,s_2) = \\frac{\\zeta(1+s_1+s_2)}{\\zeta(1+s_1) \\zeta(1+s_2)} \\prod_p E_p(s_1,s_2)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("E_p(s_1,s_2) := \\frac{(1 - \\frac{g(p)}{p^{1+s_1}} - \\frac{g(p)}{p^{1+s_2}} + \\frac{g(p)}{p^{1+s_1+s_2}})(1 - \\frac{1}{p^{1+s_1+s_2}})}{(1-\\frac{1}{p^{1+s_1}})(1-\\frac{1}{p^{1+s_2}})}.")]]

#text("For ")#mi("{s_1,s_2=o(1)}")#text(" with nonnegative real part, one has")

#align(center)[#tao-fit-display[#mitex("E_p(s_1,s_2) = 1 + O(1/p^2)")]]

#text("and so by the Weierstrass ")#mi("{M}")#text("-test, ")#mi("{\\prod_p E_p(s_1,s_2)}")#text(" is continuous at ")#mi("{s_1=s_2=0}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(0,0) = G(1)")]]

#text("we thus have")

#align(center)[#tao-fit-display[#mitex("\\prod_p E_p(s_1,s_2) = G(1) + o(1)")]]

#text("Also, since ")#mi("{\\zeta}")#text(" has a pole of order ")#mi("{1}")#text(" at ")#mi("{s=1}")#text(" with residue ")#mi("{1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\zeta(1+s_1+s_2)}{\\zeta(1+s_1) \\zeta(1+s_2)} = (1+o(1)) \\frac{s_1 s_2}{s_1+s_2}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("E(s_1,s_2) = (G(1)+o(1)) \\frac{s_1s_2}{s_1+s_2}.")]]

#text("The quantity ")#link(<tao-a12947dbf7d04ce3a055>)[#text("(23)")]#text(" can thus be written, up to errors of ")#mi("{o(\\frac{1}{\\log x})}")#text(", as")

#align(center)[#tao-fit-display[#tao-math("\\frac{G(1)}{\\varepsilon \\log x} \\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log x}} \\frac{(1+it_1)(1+it_2)}{1+it_1+1+it_2} \\Psi(t_1) \\Psi(t_2)\\ dt_1 dt_2.", block: true)]]

#text("Using the rapid decrease of ")#mi("{\\Psi}")#text(", we may remove the restriction on ")#mi("{t_1,t_2}")#text(", and it will now suffice to prove the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\frac{(1+it_1)(1+it_2)}{1+it_1+1+it_2} \\Psi(t_1) \\Psi(t_2)\\ dt_1 dt_2 = (\\int_0^1 \\psi^{\\prime}(u)^2\\ du)^2.")]]

#text("But on differentiating and then squaring ")#link(<tao-6d7e04068fa604f0ea60>)[#text("(22)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\psi^{\\prime}(u)^2 = \\int_{\\bf R} \\int_{\\bf R} (1+it_1)(1+it_2) e^{-(1+it_1+1+it_2)u}\\Psi(t_1) \\Psi(t_2)\\ dt_1 dt_2")]]

#text("and the claim follows by integrating in ")#mi("{u}")#text(" from zero to infinity (noting that ")#mi("{\\psi^{\\prime}}")#text(" vanishes for ")#mi("{u>1}")#text(").")

#text("We have the following variant of ")#link(<tao-32000e140c9ebe9ba782>)[#text("(19)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-c1299854f2b209632ab2>#text(" For any ")#mi("{d \\leq x^{1-3\\varepsilon}}")#text(", one has ")#metadata(none) <tao-a2446ba00b6683cf875d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("\\sum_{n \\in I: d|n} \\nu_\\varepsilon(n) a_n \\ll \\frac{C\\left|I\\right|}{\\varepsilon \\log x} \\frac{\\prod_{p|d} O( \\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2 )}{d} + R_d", block: true)]]



#text(" where the ")#mi("{R_d}")#text(" are such that ")#metadata(none) <tao-41c6b18b40132c7894c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\sum_{d \\leq x^{1-3\\varepsilon}} R_d \\ll_A |I| \\log^{-A} x")]]



#text(" for any ")#mi("{A>0}")#text(". We also have the variant ")#metadata(none) <tao-81e567235b4f37b154b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\sum_{n \\in I: d|n} \\nu_\\varepsilon(n/d) a_n \\ll \\frac{C\\left|I\\right|}{\\varepsilon \\log x} \\frac{\\prod_{p|d} O(1 ) )}{d} + R_d.", block: true)]]



#text(" If in addition ")#mi("{d}")#text(" has no prime factors less than ")#mi("{x^\\delta}")#text(" for some fixed ")#mi("{\\delta>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I: d|n} \\nu_\\varepsilon(n) a_n")]]

#metadata(none) <tao-f14f6bea368b70ac3ad4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("= \\frac{1+o(1)}{d} \\frac{C\\left|I\\right|}{\\varepsilon \\log x} (\\int_0^1 \\psi^{\\prime}(u)^2\\ du) G(1) + O(R_d).", block: true)]]




]

#text("Roughly speaking, the above estimates assert that ")#mi("{\\nu_\\varepsilon}")#text(" is concentrated on those numbers ")#mi("{n}")#text(" with no prime factors much less than ")#mi("{x^\\varepsilon}")#text(", but factors ")#mi("{d}")#text(" without such small prime divisors occur with about the same relative density as they do in the integers.")

#emph[#text("Proof:")]#text(" The left-hand side of ")#link(<tao-a2446ba00b6683cf875d>)[#text("(24)")]#text(" can be expanded as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\sum_{n \\in I: [d_1,d_2,d]|n} a_n.")]]

#text("If we define")

#align(center)[#tao-fit-display[#mitex("R_d := \\sum_{d^{\\prime} \\leq x^{1-\\varepsilon}: d|d^{\\prime}} \\tau(d^{\\prime})^2 |\\sum_{n \\in I:d^{\\prime}|n} a_n - \\frac{g(d^{\\prime})}{d^{\\prime}} C|I||")]]

#text("then the previous expression can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\frac{g([d_1,d_2,d])}{[d_1,d_2,d]} C\\left|I\\right| + O(R_d),", block: true)]]

#text("while one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^{1-3\\varepsilon}} R_d \\leq \\sum_{d^{\\prime} \\leq x^{1-\\varepsilon}} \\tau(d^{\\prime})^3 |\\sum_{n \\in I:d^{\\prime}|n} a_n - \\frac{g(d^{\\prime})}{d^{\\prime}} C|I||")]]

#text("which gives ")#link(<tao-41c6b18b40132c7894c6>)[#text("(25)")]#text(" from Axiom (iv). To prove ")#link(<tao-a2446ba00b6683cf875d>)[#text("(24)")]#text(", it now suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2} \\mu(d_1) \\mu(d_2) \\psi( \\frac{\\log d_1}{\\varepsilon \\log x} ) \\psi( \\frac{\\log d_2}{\\varepsilon \\log x} ) \\frac{g([d_1,d_2,d])}{[d_1,d_2,d]}")]]

#metadata(none) <tao-ec4f2dbb3b140095550c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\ll \\frac{1}{\\varepsilon \\log x} \\frac{\\prod_{p|d} O( \\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2 )}{d}.")]]



#text(" Arguing as before, the left-hand side is")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} E^{(d)}(\\frac{1+it_1}{\\varepsilon \\log x},\\frac{1+it_2}{\\varepsilon \\log x})\\ \\Psi(t_1) \\Psi(t_2) dt_1 dt_2")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("E^{(d)}(s_1,s_2) := \\sum_{d_1,d_2} \\frac{\\mu(d_1) \\mu(d_2)}{d_1^{s_1}d_2^{s_2}} \\frac{g([d_1,d_2,d])}{[d_1,d_2,d]}.")]]

#text("From Mertens’ theorem we have")

#align(center)[#tao-fit-display[#mitex("E^{(d)}(s_1,s_2) \\ll_\\varepsilon \\frac{\\prod_{p|d} O(1)}{d} \\log^{O(1)} x")]]

#text("when ")#mi("{\\text{Re} s_1, \\text{Re} s_2 = \\frac{1}{\\varepsilon \\log x}}")#text(", so the contribution of the terms where ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\geq \\sqrt{\\log x}}", block: false)#text(" can be absorbed into the ")#mi("{R_d}")#text(" error (after increasing that error slightly). For the remaining contributions, we see that")

#align(center)[#tao-fit-display[#mitex("E^{(d)}(s_1,s_2) = \\frac{\\zeta(1+s_1+s_2)}{\\zeta(1+s_1) \\zeta(1+s_2)} \\prod_p E^{(d)}_p(s_1,s_2)")]]

#text("where ")#mi("{E^{(d)}_p(s_1,s_2) = E_p(s_1,s_2)}")#text(" if ")#mi("{p}")#text(" does not divide ")#mi("{d}")#text(", and")

#align(center)[#tao-fit-display[#mitex("E^{(d)}_p(s_1,s_2) = \\frac{g(p^j)}{p^j} \\frac{(1 - \\frac{1}{p^{s_1}}) (1 - \\frac{1}{p^{s_2}}) (1 - \\frac{1}{p^{1+s_1+s_2}})}{(1-\\frac{1}{p^{1+s_1}})(1-\\frac{1}{p^{1+s_2}})}")]]

#text("if ")#mi("{p}")#text(" divides ")#mi("{d}")#text(" ")#mi("{j}")#text(" times for some ")#mi("{j \\geq 1}")#text(". In the latter case, Taylor expansion gives the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|E^{(d)}_p(\\frac{1+it_1}{\\varepsilon \\log x},\\frac{1+it_2}{\\varepsilon \\log x})\\right| \\lesssim (1+\\left|t_1\\right|+\\left|t_2\\right|)^{O(1)} \\frac{\\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2}{p}", block: true)]]

#text("and the claim ")#link(<tao-ec4f2dbb3b140095550c>)[#text("(28)")]#text(" follows. When ")#mi("{p \\geq x^\\delta}")#text(" and ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log x}}", block: false)#text(" we have")

#align(center)[#tao-fit-display[#mitex("E^{(d)}_p(\\frac{1+it_1}{\\varepsilon \\log x},\\frac{1+it_2}{\\varepsilon \\log x}) = \\frac{1+o(1)}{p^j}")]]

#text("and ")#link(<tao-f14f6bea368b70ac3ad4>)[#text("(27)")]#text(" follows by repeating the previous calculations. Finally, ")#link(<tao-81e567235b4f37b154b0>)[#text("(26)")]#text(" is proven similarly to ")#link(<tao-a2446ba00b6683cf875d>)[#text("(24)")]#text(" (using ")#mi("{d[d_1,d_2]}")#text(" in place of ")#mi("{[d_1,d_2,d]}")#text("). ")#mi("\\Box")

#text("Now we can prove ")#link(<tao-af13dab7f404890f3e9a>)[#text("(15)")]#text(", ")#link(<tao-91c9d6cb2482b4ea8cef>)[#text("(16)")]#text(", ")#link(<tao-15a9888c4942fb01aff7>)[#text("(17)")]#text(". We begin with ")#link(<tao-af13dab7f404890f3e9a>)[#text("(15)")]#text(". Using the Leibniz rule ")#mi("{L(f*g) = (Lf)*g + f*(Lg)}")#text(" applied to the identity ")#mi("{\\mu = \\mu * 1 * \\mu}")#text(" and using ")#mi("{\\Lambda = \\mu*L}")#text(" and Möbius inversion (and the associativity and commutativity of Dirichlet convolution) we see that ")#metadata(none) <tao-2a2da19f99ee0c6c79fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("L\\mu = - \\mu * \\Lambda.")]]



#text(" Next, by applying the Leibniz rule to ")#mi("{\\Lambda_k = \\mu * L^k}")#text(" for some ")#mi("{k \\geq 1}")#text(" and using ")#link(<tao-2a2da19f99ee0c6c79fe>)[#text("(29)")]#text(" we see that")

#tao-aligned(keep: true)[


#tao-math("L \\Lambda_k  & = L \\mu * L^k + \\mu * L^{k+1}", block: true)



#tao-math(" & = - \\mu * \\Lambda * L^k + \\Lambda_{k+1}", block: true)
]

#text("and hence we have the recursive identity ")#metadata(none) <tao-b38f606d1568ce85ab65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\Lambda_{k+1} = L \\Lambda_k + \\Lambda *\\Lambda_k.")]]



#text(" In particular, from induction we see that ")#mi("{\\Lambda_k}")#text(" is supported on numbers with at most ")#mi("{k}")#text(" distinct prime factors, and hence ")#mi("{\\Lambda_{\\vec k}}")#text(" is supported on numbers with at most ")#tao-math("{\\left|\\vec k\\right|}", block: false)#text(" distinct prime factors. In particular, from ")#link(<tao-add93659279b4ba737e2>)[#text("(18)")]#text(" we see that ")#mi("{\\nu_\\varepsilon(n) = O(1)}")#text(" on the support of ")#mi("{\\Lambda_{\\vec k}}")#text(". Thus it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I: \\nu_\\varepsilon(n) \\neq 1} \\Lambda_{\\vec k}(n) a_n \\ll (\\varepsilon+o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x.", block: true)]]

#text("If ")#mi("{\\nu_\\varepsilon(n) \\neq 1}")#text(" and ")#mi("{\\Lambda_{\\vec k}(n) \\neq 0}")#text(", then ")#mi("{n}")#text(" has at most ")#tao-math("{\\left|\\vec k\\right|}", block: false)#text(" distinct prime factors ")#mi("{p_1 < p_2 < \\dots < p_r}")#text(", with ")#mi("{p_1 \\leq x^\\varepsilon}")#text(". If we factor ")#mi("{n = n_1 n_2}")#text(", where ")#mi("{n_1}")#text(" is the contribution of those ")#mi("{p_i}")#text(" with ")#tao-math("{p_i \\leq x^{1/10\\left|\\vec k\\right|}}", block: false)#text(", and ")#mi("{n_2}")#text(" is the contribution of those ")#mi("{p_i}")#text(" with ")#tao-math("{p_i > x^{1/10\\left|\\vec k\\right|}}", block: false)#text(", then at least one of the following two statements hold:")

#list(
[#text("(a) ")#mi("{n_1}")#text(" (and hence ")#mi("{n}")#text(") is divisible by a square number of size at least ")#mi("{x^{1/10}}")#text(".")],
[#text("(b) ")#mi("{n_1 \\leq x^{1/5}}")#text(".")]
)

#text("The contribution of case (a) is easily seen to be acceptable by axiom (ii). For case (b), we observe from ")#link(<tao-b38f606d1568ce85ab65>)[#text("(30)")]#text(" and induction that")

#align(center)[#tao-fit-display[#tao-math("\\Lambda_k(n) \\ll \\log^{\\left|\\vec k\\right|} x \\prod_{j=1}^k \\frac{\\log p_j}{\\log x}", block: true)]]

#text("and so it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1} (\\prod_{p|n_1} \\frac{\\log p}{\\log x}) \\sum_{n \\in I: n_1 | n} 1_R(n/n_1) a_n \\ll (\\varepsilon + o(1)) C |I| \\log^{-1} x")]]

#text("where ")#mi("{n_1}")#text(" ranges over numbers bounded by ")#mi("{x^{1/5}}")#text(" with at most ")#tao-math("{\\left|\\vec k\\right|}", block: false)#text(" distinct prime factors, the smallest of which is at most ")#mi("{x^\\varepsilon}")#text(", and ")#mi("{R}")#text(" consists of those numbers with no prime factor less than or equal to ")#tao-math("{x^{1/10\\left|\\vec k\\right|}}", block: false)#text(". Applying ")#link(<tao-81e567235b4f37b154b0>)[#text("(26)")]#text(" (with ")#mi("{\\varepsilon}")#text(" replaced by ")#tao-math("{1/10\\left|\\vec k\\right|}", block: false)#text(") gives the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I: d|n} 1_R(n/n_1) a_n \\ll \\frac{C\\left|I\\right|}{\\log x} \\frac{1}{n_1} + R_d", block: true)]]

#text("so by ")#link(<tao-41c6b18b40132c7894c6>)[#text("(25)")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1} (\\prod_{p|n_1} \\frac{\\log p}{\\log x}) \\frac{1}{n_1} \\ll \\varepsilon")]]

#text("subject to the same constraints on ")#mi("{n_1}")#text(" as before. The contribution of those ")#mi("{n_1}")#text(" with ")#mi("{r}")#text(" distinct prime factors can be bounded by")

#align(center)[#tao-fit-display[#mitex("O(\\sum_{p_1 \\leq x^\\varepsilon} \\frac{\\log p_1}{p_1 \\log x}) \\times O(\\sum_{p \\leq x^{1/5}} \\frac{\\log p}{p\\log x})^{r-1};")]]

#text("applying Mertens’ theorem and summing over ")#tao-math("{1 \\leq r \\leq \\left|\\vec k\\right|}", block: false)#text(", one obtains the claim.")

#text("Now we show ")#link(<tao-91c9d6cb2482b4ea8cef>)[#text("(16)")]#text(". As discussed previously in this section, we can replace ")#mi("{\\Lambda_{\\vec k}(n)}")#text(" by ")#mi("{\\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d}}")#text(" with negligible error. Comparing this with ")#link(<tao-91c9d6cb2482b4ea8cef>)[#text("(16)")]#text(" and ")#link(<tao-116f54c41d0405dbb10e>)[#text("(11)")]#text(", we see that it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\in I} \\sum_{d|n} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} (1 - \\eta_\\varepsilon(\\frac{\\log d}{\\log x})) \\nu_\\varepsilon(n) a_n \\ll (\\varepsilon+o(1)) C |I| \\log^{\\left|\\vec k\\right|-1} x.", block: true)]]

#text("From the support of ")#mi("{\\eta_\\varepsilon}")#text(", the summand on the left-hand side is only non-zero when ")#mi("{d \\geq x^{1-4\\varepsilon}}")#text(", which makes ")#mi("{\\log^{k_r} \\frac{x}{d} \\ll \\varepsilon^{k_r} \\log^{k_r} x \\leq \\varepsilon^2 \\log^{k_r} x}")#text(", where we use the crucial hypothesis ")#mi("{k_r > 1}")#text(" to gain enough powers of ")#mi("{\\varepsilon}")#text(" to make the argument here work. Applying Lemma ")#link(<tao-9b6d3dc089e58963b9d2>)[#text("2")]#text(", we reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in I} \\sum_{d|n: d \\geq x^{1-4\\varepsilon}} \\nu_\\varepsilon(n) a_n \\ll \\frac{1+o(1)}{\\varepsilon \\log x} C |I|.")]]

#text("We can make the change of variables ")#mi("{d \\mapsto n/d}")#text(" to flip the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{d|n: d \\geq x^{1-4\\varepsilon}} 1 \\leq \\sum_{d|n: d \\leq x^{3\\varepsilon}} 1")]]

#text("and then swap the sums to reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^{4\\varepsilon}} \\sum_{n \\in I} \\nu_\\varepsilon(n) a_n \\ll \\frac{1+o(1)}{\\varepsilon \\log x} C |I|.")]]

#text("By Lemma ")#link(<tao-c1299854f2b209632ab2>)[#text("3")]#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^{4\\varepsilon}} \\frac{\\prod_{p|d} O( \\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2 )}{d} \\ll 1.")]]

#text("To prove this, we use the Rankin trick, bounding the implied weight ")#mi("{1_{d \\leq x^{4\\varepsilon}}}")#text(" by ")#mi("{O( \\frac{1}{d^{1/\\varepsilon \\log x}} )}")#text(". We can then bound the left-hand side by the Euler product")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1 + O( \\frac{\\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2}{p^{1+1/\\varepsilon \\log x}} ))")]]

#text("which can be bounded by")

#align(center)[#tao-fit-display[#mitex("\\exp( O( \\sum_p \\frac{\\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2}{p^{1+1/\\varepsilon \\log x}} ) )")]]

#text("and the claim follows from Mertens’ theorem.")

#text("Finally, we show ")#link(<tao-15a9888c4942fb01aff7>)[#text("(17)")]#text(". By ")#link(<tao-116f54c41d0405dbb10e>)[#text("(11)")]#text(", the left-hand side expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^{1-3\\varepsilon}} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} \\eta_\\varepsilon(\\frac{\\log d}{\\log x}) \\sum_{n \\in I: d|n} \\nu_\\varepsilon(n) a_n.")]]

#text("We let ")#mi("{\\delta>0}")#text(" be a small constant to be chosen later. We divide the outer sum into two ranges, depending on whether ")#mi("{d}")#text(" only has prime factors greater than ")#mi("{x^\\delta}")#text(" or not. In the former case, we can apply ")#link(<tao-f14f6bea368b70ac3ad4>)[#text("(27)")]#text(" to write this contribution as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x^{1-3\\varepsilon}} \\mu_{\\vec k}(d) \\log^{k_r} \\frac{x}{d} \\eta_\\varepsilon(\\frac{\\log d}{\\log x}) \\frac{1+o(1)}{d} \\frac{C\\left|I\\right|}{\\varepsilon \\log x} (\\int_0^1 \\psi^{\\prime}(u)^2\\ du) G(1)", block: true)]]

#text("plus a negligible error, where the ")#mi("{d}")#text(" is implicitly restricted to numbers with all prime factors greater than ")#mi("{x^\\delta}")#text(". The main term is messy, but it is of the required form ")#mi("{C Q^{\\prime}_{\\varepsilon,x} G(1)}")#text(" up to an acceptable error, so there is no need to compute it any further. It remains to consider those ")#mi("{d}")#text(" that have at least one prime factor less than ")#mi("{x^\\delta}")#text(". Here we use ")#link(<tao-a2446ba00b6683cf875d>)[#text("(24)")]#text(" instead of ")#link(<tao-f14f6bea368b70ac3ad4>)[#text("(27)")]#text(" as well as Lemma ")#link(<tao-c1299854f2b209632ab2>)[#text("3")]#text(" to dominate this contribution by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d \\leq x^{1-3\\varepsilon}} O( \\log^{\\left|\\vec k\\right|} x \\frac{C\\left|I\\right|}{\\varepsilon \\log x} \\frac{\\prod_{p|d} O( \\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )^2 )}{d} )", block: true)]]

#text("up to negligible errors, where ")#mi("{d}")#text(" is now restricted to have at least one prime factor less than ")#mi("{x^\\delta}")#text(". This makes at least one of the factors ")#mi("{\\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 )}")#text(" to be at most ")#mi("{O_\\varepsilon(\\delta)}")#text(". A routine application of Rankin’s trick shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq x^{1-3\\varepsilon}} \\frac{\\prod_{p|d} O( \\min( \\frac{\\log p}{\\varepsilon \\log x}, 1 ) )}{d} \\ll_\\varepsilon 1")]]

#text("and so the total contribution of this case is ")#tao-math("{O_\\varepsilon((\\delta+o(1)) |I| \\log^{\\left|\\vec k\\right|-1} x)}", block: false)#text(". Since ")#mi("{\\delta>0}")#text(" can be made arbitrarily small, ")#link(<tao-15a9888c4942fb01aff7>)[#text("(17)")]#text(" follows.")

#heading(level: 1)[#strong[#text(" — 2. Weierstrass approximation — ")]]

#text("Having proved Theorem ")#link(<tao-c353f7dabebea3a68d63>)[#text("1")]#text(", we now take linear combinations of this theorem, combined with the Weierstrass approximation theorem, to give the asymptotics ")#link(<tao-40bb59dfb2d438c77a19>)[#text("(7)")]#text(", ")#link(<tao-7b0d223bb0ad78e990a5>)[#text("(8)")]#text(" described in the introduction.")

#text("Let ")#mi("{a_n}")#text(", ")#mi("{g}")#text(", ")#mi("{C}")#text(", ")#mi("{G}")#text(" be as in that theorem. It will be convenient to normalise the weights ")#mi("{\\Lambda_{\\vec k}}")#text(" by ")#tao-math("{L^{1-\\left|\\vec k\\right|}}", block: false)#text(" to make their mean value comparable to ")#mi("{1}")#text(". From Theorem ")#link(<tao-c353f7dabebea3a68d63>)[#text("1")]#text(" and summation by parts we have ")#metadata(none) <tao-e8e3ee308c7e2d21188b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#tao-math("\\sum_{n \\leq x} L^{1-\\left|\\vec k\\right|} \\Lambda_{\\vec k}(n) a_n = (G(1)+o(1)) \\frac{\\prod_{i=1}^r k_i!}{(\\left|\\vec k\\right|-1)!} C x", block: true)]]



#text(" whenever ")#mi("{\\vec k}")#text(" does not consist entirely of ones.")

#text("We now take a closer look at what happens when ")#mi("{\\vec k}")#text(" does consist entirely of ones. Let ")#mi("{1^r}")#text(" denote the ")#mi("{r}")#text("-tuple ")#mi("{(1,\\dots,1)}")#text(". Convolving the ")#mi("{k=1}")#text(" case of ")#link(<tao-b38f606d1568ce85ab65>)[#text("(30)")]#text(" with ")#mi("{r-1}")#text(" copies of ")#mi("{\\Lambda}")#text(" for some ")#mi("{r \\geq 1}")#text(" and using the Leibniz rule, we see that")

#align(center)[#tao-fit-display[#mitex("\\Lambda_{(1^{r-1}, 2)} = \\frac{1}{r} L \\Lambda_{1^r} + \\Lambda_{1^{r+1}}")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("L^{-r} \\Lambda_{1^{r+1}} = L^{-r} \\Lambda_{(1^{r-1},2)} - \\frac{1}{r} L^{1-r} \\Lambda_{1^r}.")]]

#text("Multiplying by ")#mi("{a_n}")#text(" and summing over ")#mi("{n \\leq x}")#text(", and using ")#link(<tao-e8e3ee308c7e2d21188b>)[#text("(31)")]#text(" to control the ")#mi("{\\Lambda_{(1^{r-1},2)}}")#text(" term, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} L^{-r} \\Lambda_{1^{r+1}}(n) a_n = (G(1)+o(1)) \\frac{2}{r!} - \\frac{1}{r} \\sum_{n \\leq x} L^{1-r} \\Lambda_{1^{r}}(n) a_n.")]]

#text("If we define ")#mi("{\\delta_x}")#text(" (up to an error of ")#mi("{o(1)}")#text(") by the formula")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) a_n = (\\delta_x G(1) + o(1)) C x")]]

#text("then an induction then shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} L^{1-r} \\Lambda_{1^r}(n) a_n = \\frac{1}{(r-1)!} (\\delta_x G(1) + o(1)) C x")]]

#text("for odd ")#mi("{r}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} L^{1-r} \\Lambda_{1^r}(n) a_n = \\frac{1}{(r-1)!} ((2-\\delta_x) G(1) + o(1)) C x")]]

#text("for even ")#mi("{r}")#text(". In particular, after adjusting ")#mi("{\\delta_x}")#text(" by ")#mi("{o(1)}")#text(" if necessary, we have ")#mi("{0 \\leq \\delta_x \\leq 2}")#text(" since the left-hand sides are non-negative.")

#text("If we now define the comparison sequence ")#mi("{b_n := C G(1) (1 + (1-\\delta_x) \\mu(n))}")#text(", standard multiplicative number theory shows that the above estimates also hold when ")#mi("{a_n}")#text(" is replaced by ")#mi("{b_n}")#text("; thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} L^{1-r} \\Lambda_{1^r}(n) a_n = \\sum_{n \\leq x} L^{1-r} \\Lambda_{1^r}(n) b_n + o( x )")]]

#text("for both odd and even ")#mi("{r}")#text(". The bound ")#link(<tao-e8e3ee308c7e2d21188b>)[#text("(31)")]#text(" also holds for ")#mi("{b_n}")#text(" when ")#mi("{\\vec k}")#text(" does not consist entirely of ones, and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n \\leq x} L^{1-\\left|\\vec k\\right|} \\Lambda_{\\vec k}(n) a_n = \\sum_{n \\leq x} L^{1-\\left|\\vec k\\right|} \\Lambda_{\\vec k}(n) b_n + o( x )", block: true)]]

#text("for any fixed ")#mi("{\\vec k}")#text(" (which may or may not consist entirely of ones).")

#text("Next, from induction (on ")#mi("{j_1+\\dots+j_r}")#text("), the Leibniz rule, and ")#link(<tao-b38f606d1568ce85ab65>)[#text("(30)")]#text(", we see that for any ")#mi("{r \\geq 1}")#text(" and ")#mi("{j_1,\\dots,j_r \\geq 0}")#text(", ")#mi("{k_1,\\dots,k_r}")#text(", the function ")#metadata(none) <tao-05a9bf223fedf80a9d0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("L^{1-j_1-\\dots-j_r-\\left|\\vec k\\right|} ((L^{j_1} \\Lambda_{k_1}) * \\dots * (L^{j_r} \\Lambda_{k_r}))", block: true)]]



#text(" is a finite linear combination of functions of the form ")#tao-math("{L^{1-\\left|\\vec k^{\\prime}\\right|} \\Lambda_{\\vec k^{\\prime}}}", block: false)#text(" for tuples ")#mi("{\\vec k^{\\prime}}")#text(" that may possibly consist entirely of ones. We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} f(n) a_n = \\sum_{n \\leq x}f(n) b_n + o( x )")]]

#text("whenever ")#mi("{f}")#text(" is one of these functions ")#link(<tao-05a9bf223fedf80a9d0d>)[#text("(32)")]#text(". Specialising to the case ")#mi("{k_1=\\dots=k_r=1}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1 \\dots n_r \\leq x} a_{n} \\log^{1-r} n \\prod_{i=1}^r (\\log n_i/\\log n)^{j_i} \\Lambda(n_i)")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{n_1 \\dots n_r \\leq x} b_{n} \\log^{1-r} n \\prod_{i=1}^r (\\log n_i/\\log n)^{j_i} \\Lambda(n_i) + o(x )")]]

#text("where ")#mi("{n := n_1 \\dots n_r}")#text(". The contribution of those ")#mi("{n_i}")#text(" that are powers of primes can be easily seen to be negligible, leading to")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\dots p_r \\leq x} a_{n} \\log n \\prod_{i=1}^r (\\log p_i/\\log n)^{j_i+1}")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{p_1 \\dots p_r \\leq x} b_{n} \\prod_{i=1}^r (\\log p_i/\\log n)^{j_i+1} + o(x)")]]

#text("where now ")#mi("{n := p_1 \\dots p_r}")#text(". The contribution of the case where two of the primes ")#mi("{p_i}")#text(" agree can also be seen to be negligible, as can the error when replacing ")#mi("{\\log n}")#text(" with ")#mi("{\\log x}")#text(", and then by symmetry")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} a_{n} \\prod_{i=1}^r (\\log p_i/\\log n)^{j_i+1}")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} b_{n} \\prod_{i=1}^r (\\log p_i/\\log n)^{j_i+1} + o(x / \\log x).")]]

#text("By linearity, this implies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} a_{n} P( \\log p_1/\\log n, \\dots, \\log p_r/\\log n)")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} b_{n} P( \\log p_1/\\log n, \\dots, \\log p_r/\\log n) + o(x / \\log x)")]]

#text("for any polynomial ")#mi("{P(t_1,\\dots,t_r)}")#text(" that vanishes on the coordinate hyperplanes ")#mi("{t_i=0}")#text(". The right-hand side can also be evaluated by Mertens’ theorem as")

#align(center)[#tao-fit-display[#mitex("CG(1) \\delta_x \\int_{\\Delta_r} P x + o(x)")]]

#text("when ")#mi("{r}")#text(" is odd and")

#align(center)[#tao-fit-display[#mitex("CG(1) (2-\\delta_x) \\int_{\\Delta_r} P x + o(x)")]]

#text("when ")#mi("{r}")#text(" is even. Using the Weierstrass approximation theorem, we then have")

#align(center)[#tao-fit-display[#mitex("\\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} a_{n} g_r( \\log p_1/\\log n, \\dots, \\log p_r/\\log n)")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{p_1 \\dots p_r \\leq x: p_1 < \\dots < p_r} b_{n} g_r( \\log p_1/\\log n, \\dots, \\log p_r/\\log n) + o(x / \\log x)")]]

#text("for any continuous function ")#mi("{g_r}")#text(" that is compactly supported in the interior of ")#mi("{\\Delta_r}")#text(". Computing the right-hand side using Mertens’ theorem as before, we obtain the claimed asymptotics ")#link(<tao-40bb59dfb2d438c77a19>)[#text("(7)")]#text(", ")#link(<tao-7b0d223bb0ad78e990a5>)[#text("(8)")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The Bombieri asymptotic sieve has to use the full power of EH (or GEH); there are constructions ")#link("http://www.ams.org/mathscinet-getitem?mr=2115380")[#text("due to Ford")]#text(" that show that if one only has a distributional hypothesis up to ")#mi("{x^{1-c}}")#text(" for some fixed constant ")#mi("{c>0}")#text(", then the asymptotics of sums such as ")#link(<tao-7e78770ae44265567975>)[#text("(5)")]#text(", or more generally ")#link(<tao-14f91bc93dc4f0ff486e>)[#text("(9)")]#text(", are not determined by a single scalar parameter ")#mi("{\\delta_x}")#text(", but can also vary in other ways as well. Thus the Bombieri asymptotic sieve really is asymptotic; in order to get ")#mi("{o(1)}")#text(" type error terms one needs the level ")#mi("{1-\\varepsilon}")#text(" of distribution to be asymptotically equal to ")#mi("{1}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(". Related to this, the quantitative decay of the ")#mi("{o(1)}")#text(" error terms in the Bombieri asymptotic sieve are extremely poor; in particular, they depend on the dependence of implied constant in axiom (iv) on the parameters ")#mi("{\\varepsilon,A}")#text(", for which there is no consensus on what one should conjecturally expect.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470711")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("Would a weakened form of Cramer’s conjecture like $g_{n}=\\log^{O(1)}p_{n}$ be strong enough to imply the twin prime conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470774")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("By the way, this link may give further support to Cramer’s conjecture: ")#link("http://math.stackexchange.com/questions/1859480/growth-of-pinr-0n-pin-r-0n-with-r-0n-inf-r-ge-0-n-r-n?noredirect=1#comment3818092_1859480")[#text("http://math.stackexchange.com/questions/1859480/growth-of-pinr-0n-pin-r-0n-with-r-0n-inf-r-ge-0-n-r-n?noredirect=1#comment3818092_1859480")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470714")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("1. What seems to prevent a non-heuristic determination of the limiting behaviour of prime counting functions is that the usual approximations of ")#mi("\\pi(n)")#text(" for finite values of ")#mi("n")#text(" are apparently derived from real-valued functions which are asymptotic to ")#mi("\\pi(x)")#text(", such as ")#mi("\\frac{x}{log_{e}x}")#text(", ")#mi("Li(x)")#text(" and Riemann’s function ")#mi("R(x) = \\sum_{n=1}^{\\infty}\\frac{\\mu(n)}{(n)}li(x^{1/n})")#text(".")

#text("2. The degree of approximation for finite values of ")#mi("n")#text(" is thus determined only heuristically, by conjecturing upon an error term in the asymptotic relation that can be seen to yield a closer approximation than others to the actual values of ")#mi("\\pi(n)")#text(".")

#text("3. Moreover, currently, conventional approaches to evaluating prime counting functions for finite ")#mi("n")#text(" may also subscribe to the belief:")

#text("(i) either—explicitly (see ")#link("https://rjlipton.wordpress.com/2016/06/29/getting-to-the-roots-of-factoring/")[#emph[#text("here")]]#text(")—that whether or not a prime ")#mi("p")#text(" divides an integer ")#mi("n")#text(" is ")#strong[#emph[#text("not")]]#text(" independent of whether or not a prime ")#mi("q \\neq p")#text(" divides the integer ")#mi("n")#text(";")

#text("(ii) or—implicitly (since the twin-prime problem is yet open)—that a proof to the contrary must imply that if ")#mi("P(n\\ is\\ a\\ prime)")#text(" is the probability that ")#mi("n")#text(" is a prime, then ")#mi("\\sum_{_{i = 1}}^{^{\\infty}} P(i\\ is\\ a\\ prime) = 1")#text(".")

#text("4. If so, then conventional approaches seem to conflate the two probabilities:")

#text("(i) The probability ")#mi("P(a)")#text(" of selecting a number that has the property of being prime from a given set ")#mi("S")#text(" of numbers;")

#emph[#text("Example 1")]#text(": I have a bag containing ")#mi("100")#text(" numbers in which there are twice as many composites as primes. What is the probability that the first number you blindly pick from it is a prime. This is the basis for setting odds in games such as roulette.")

#text("(ii) The probability ")#mi("P(b)")#text(" of determining a proper factor of a given number ")#mi("n")#text(".")

#emph[#text("Example 2")]#text(": I give you a ")#mi("5")#text("-digit combination lock along with a ")#mi("10")#text("-digit number ")#mi("n")#text(". The lock only opens if you set the combination to a proper factor of ")#mi("n")#text(" which is greater than ")#mi("1")#text(". What is the probability that the first combination you try will open the lock. This is the basis for RSA encryption, which provides the cryptosystem used by many banks for securing their communications.")

#text("5. In case 4(i), if the precise proportion of primes to non-primes in ")#mi("S")#text(" is definable, then clearly ")#mi("P(a)")#text(" too is definable.")

#text("However if ")#mi("S")#text(" is the set ")#mi("N")#text(" of all integers, and we cannot define a precise ratio of primes to composites in ")#mi("N")#text(", but only an order of magnitude such as ")#mi("O(\\frac{1}{log_{_{e}}n})")#text(", then equally obviously ")#mi("P(a)")#text(" cannot be defined in ")#mi("N")#text(" (see Chapter 2, p.9, Theorem 2.1, ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.118.4755&rep=rep1&type=pdf")[#emph[#text("here")]]#text(").")

#text("6. In case 4(ii) it follows that ")#mi("P(b) = \\frac{1}{\\pi(\\sqrt{n})}")#text(", since the argument can be used to show that whether or not a prime ")#mi("p")#text(" divides a given integer ")#mi("n")#text(" ")#strong[#emph[#text("is")]]#text(" independent of whether or not a prime ")#mi("q \\neq p")#text(" divides ")#mi("n")#text(".")

#text("7. We thus have that ")#mi("\\pi(n) \\approx n.\\prod_{_{i = 1}}^{^{\\pi(\\sqrt{n})}}(1-\\frac{1}{p_{_{i}}})")#text(", with a binomial standard deviation. Hence, even though we cannot define the probability ")#mi("P(n\\ is\\ a\\ prime)")#text(" of selecting a number from the set ")#mi("N")#text(" of all natural numbers that has the property of being prime, ")#mi("\\prod_{_{i = 1}}^{^{\\pi(\\sqrt{n})}}(1-\\frac{1}{p_{_{i}}})")#text(" can be treated as the de facto probability that a given ")#mi("n")#text(" is prime.")

#text("8. Further, by considering the asymptotic density of the set of all integers that are not divisible by the first ")#mi("\\pi(\\sqrt {n})")#text(" primes ")#mi("p_{_{1}}, p_{_{2}}, \\ldots, p_{_{\\pi(\\sqrt {n})}}")#text(" we can show that, for any ")#mi("n")#text(", the expected number of such integers in any interval of length ")#mi("(p_{_{\\pi(\\sqrt{ n})+1}}^{2} - p_{_{\\pi(\\sqrt {n})}}^{2})")#text(" is ")#mi("(p_{_{\\pi(\\sqrt{ n})+1}}^{2} - p_{_{\\pi(\\sqrt {n})}}^{2})\\prod_{i = 1}^{\\pi(\\sqrt{n})}(1 - \\frac{1}{p_{_{i}}})")#text(".")

#text("9. We can then show that a non-heuristic approximation—with a binomial standard deviation—for the number of primes less than or equal to ")#mi("n")#text(" is given for all ")#mi("n")#text(" by ")#mi("\\pi(n) \\approx \\sum_{j = 1}^{n}\\prod_{i = 1}^{\\pi(\\sqrt{j})}(1 - \\frac{1}{p_{_{i}}}) \\sim a.\\frac{n}{log_{e}n} \\rightarrow \\infty")#text(" for some constant ")#mi("a > 2.e^{-\\gamma} \\approx 1.12292 \\ldots")#text(".")

#text("10. We can show, similarly, that the expected number of Dirichlet and twin primes in the interval (")#mi("p_{_{\\pi(\\sqrt {n})}}^{2},\\ p_{_{\\pi(\\sqrt{ n})+1}}^{2}")#text(") can be estimated similarly; and conclude that the number of such primes ")#mi("\\leq n")#text(" is, in each case, cumulatively approximated non-heuristically by a function that ")#mi("\\rightarrow \\infty")#text(".")

#text("11. The method can, moreover, be generalised to apply to a large class of prime counting functions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471209")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2016")])]

#text("FYI: The Riemann Prime-Counting involving the zeta zeros of the Riemann zeta function is the real deal at determining the distribution of primes (number and placement) along the natural number line.")

#text("Please visiting the following links for all reasons and details:")

#link("https://www.researchgate.net/post/What_is_the_most_efficient_way_of_predicting_prime_numbers_accurately")[#text("https://www.researchgate.net/post/What_is_the_most_efficient_way_of_predicting_prime_numbers_accurately")]

#link("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")[#text("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470734")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("Breaking the parity barrier has usually been the consequence of controlling bilinear sums, done for instance in Friedlander and Iwaniec’s work on primes of the form ")#mi("x^2 + y^4")#text(". From the view point that sieve theory is a linear programming problem, I wonder if one could impose additional linear constraints in order to overcome the parity problem. For instance we could impose the condition ")#mi("\\langle a_n , \\lambda(n) \\rangle_{n \\leq x}")#text(" is small, where ")#mi("\\lambda")#text(" is the Louisville function.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98d192abd70f5311db8ec60dec56a48604f76cb7ff6a4cf4f5df43803680c3ff-cb5dcadf7bcf8b56cb8857c450f2fddd18645e59e478b53d2f6ab76b378a6646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470737")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("Do you have this")

#text("$")#mi("\\sum_{n < x; d  n} \\Lambda(n+2) \\approx \\frac{g(d)}{d}x = x\\prod_{p|d} (1 - \\frac{1}{p})")#text("$")

#text("and also this? I don't know enough to correct you")

#text("$")#mi("\\sum_{n < x; d  n} \\Lambda(n+2) \\approx \\frac{g(d)}{d}x \\, \\log \\frac{x}{d}")#text("$")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470748")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("In the second equation, the summand is missing a factor of ")#mi("\\log\\frac{n}{d}")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("Dear Terry,")#linebreak()#text(" Happy birthday to you")#linebreak()#text(" But the great birthday present is that you solve twin prime conjecture as I expect.That is also a gift for all mathematicians.Time goes by quickly.It never waits everyone.A human becomes older very fast if without doing great thing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("It is still not clear from this post what seems to be the most promising approach for a new advance in the twin prime conjecture. Is a breakthrough in the parity problem really necessary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470751")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("Well, the twin prime sum ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2)")#text(" is certainly parity sensitive (viewing one of the factors as the sequence to be sieved and the other factor as the sieve), so any nontrivial estimate on it has to break the parity barrier one way or another, and this to my mind is one of the major reasons why progress on the twin prime conjecture will be interesting (though of course the accessibility and history of the conjecture is also appealing). It is not quite the weakest point in the parity barrier to breach though – given the recent advances on the Chowla conjecture, I would imagine that that will fall first before the twin prime conjecture does, since one has the additional tool of multiplicativity at small primes at one’s disposal in that case. Since (as discussed in the post above) the twin prime conjecture is basically equivalent (on GEH) to Chowla restricted to almost twin primes, one can hope to approach the twin prime conjecture by first proving Chowla, and then somehow removing, or at least greatly reducing, the reliance on multiplicativity at small prime in that proof. We already have the Chowla conjecture in the log-averaged setting, but that proof is currently extremely reliant on this multiplicativity, but perhaps there will be other proofs in the future that are less reliant.")

#text("It may also be possible that the twin prime conjecture could be proven by non-analytic means, in a way that does not lead to significantly new estimates on the sum ")#mi("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2)")#text(" (though this sum will of course have to go to infinity as ")#mi("x \\to \\infty")#text(" if the twin prime conjecture holds). This is currently the situation in the function field setting, where results of Hall and of Pollack show that there are infinitely many twin irreducible polynomials over any given field of odd order; this relies on some criteria for polynomial irreducibility that are only available to a very sparse set of polynomials, and which are not expected to have analogues in the integer setting. Nevertheless the parity barrier in the function field setting is still very much in effect, and the situation there is not that much better actually than in the integer case (except in the large ")#mi("q")#text(" limit, where much more is known).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470755")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("1. Yes, instead of estimating ")#mi("\\sum_{_{n \\leq x}}\\Lambda(n)\\Lambda(n+2)")#text(" heuristically by analytic considerations, one could also estimate the number ")#mi("\\pi_{_{2}}(x)")#text(" of twin primes ")#mi("\\leq x")#text(" non-heuristically as ")#mi("\\sum_{_{n \\leq x}}P(n).P(n+2)")#text(", where ")#mi("P(n)")#text(" is the de facto probability that a given ")#mi("n")#text(" is prime.")

#text("2. One way of approaching this would be to define an integer ")#mi("n")#text(" as a ")#mi("\\mathbb{TW}(k)")#text(" integer if, and only if, ")#mi("r_{p_{_{i}}}(n) \\neq 0")#text(" and ")#mi("r_{p_{_{i}}}(n) \\neq 2")#text(" for all ")#mi("1 \\leq i \\leq k")#text(", where ")#mi("0 \\leq r_{_{i}}(n) \\leq i-1")#text(" is defined for all ")#mi("i \\geq 0")#text(" by:")

#mi("n + r_{_{i}}(n) \\equiv 0\\ (mod\\ i)")#text(".")

#text("3. Note that if ")#mi("n")#text(" is a ")#mi("\\mathbb{TW}(k)")#text(" integer, then both ")#mi("n")#text(" and ")#mi("n+2")#text(" are not divisible by any of the first ")#mi("k")#text(" primes ")#mi("\\{p_{_{1}}, p_{_{2}}, \\ldots, p_{_{k}}\\}")#text(".")

#text("4. The asymptotic density of ")#mi("\\mathbb{TW}(k)")#text(" integers over the set of natural numbers is then ")#mi("\\mathbb{D}(\\mathbb{TW}(k)) = \\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("5. Further, if ")#mi("p_{_{k}}^{2} \\leq n \\leq p_{_{k+1}}^{2}")#text(" is a ")#mi("\\mathbb{TW}(k)")#text(" integer, then ")#mi("n")#text(" is a prime and either ")#mi("n+2")#text(" is also a prime, or ")#mi("n+2 = p_{_{k +1}}^{2}")#text(".")

#text("6. If we define ")#mi("\\pi_{_{\\mathbb{TW}(k)}}(n)")#text(" as the number of ")#mi("\\mathbb{TW}(k)")#text(" integers ")#mi("\\leq n")#text(", the expected number of ")#mi("\\mathbb{TW}(k)")#text(" integers in any interval ")#mi("(a, b)")#text(" is given—with a binomial standard deviation—by ")#mi("\\pi_{_{\\mathbb{TW}(k)}}(b) - \\pi_{_{\\mathbb{TW}(k)}}(a) \\approx (b-a)\\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("7. Since ")#mi("\\pi_{_{\\mathbb{TW}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{\\mathbb{TW}(k)}}(p_{_{k}}^{2})")#text(" is at most one less than the number of twin-primes in the interval ")#mi("(p_{_{k+1}}^{2} - p_{_{k}}^{2})")#text(", it follows that:")

#mi("\\pi_{_{\\mathbb{TW}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{\\mathbb{TW}(k)}}(p_{_{k}}^{2}) + 1 \\geq \\pi_{_{2}}(p_{_{k+1}}^{2}) - \\pi_{_{2}}(p_{_{k)}}^{2}) \\geq \\pi_{_{\\mathbb{TW}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{\\mathbb{TW}(k)}}(p_{_{k}}^{2})")

#text("8. Now, the expected number of ")#mi("\\mathbb{TW}(k)")#text(" integers in the interval ")#mi("(p_{_{k+1}}^{2} - p_{_{k}}^{2})")#text(" is given by:")

#mi("\\pi_{_{\\mathbb{TW}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{\\mathbb{TW}(k)}}(p_{_{k}}^{2}) \\approx (p_{_{k+1}}^{2} - p_{_{k}}^{2})\\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("9. We conclude that the number ")#mi("\\pi_{_{2}}")#text(" of twin primes ")#mi("\\leq p_{_{k+1}}^{2}")#text(" is given by the cumulative non-heuristic approximation:")

#mi("\\sum_{j=1}^{k} (\\pi_{_{2}}(p_{_{j+1}}^{2}) - \\pi_{_{2}}(p_{_{j}}^{2})) = \\pi_{_{2}}(p_{_{k+1}}^{2}) \\approx \\sum_{j=1}^{k} (p_{_{j+1}}^{2} - p_{_{j}}^{2})\\prod_{i=2}^{j}(1 - \\frac{2}{p_{_{i}}}) \\rightarrow \\infty")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("It seems natural to expect that a combination of sieve methods with the abc conjecture (which is sufficiently strong for many famous problems in additive number theory) should give some progress on the twin prime conjecture. Is it possible? (or perhaps a new version of the abc conjecture is needed for such a progress?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470782")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("The abc conjecture constrains the behaviour of numbers with many repeated prime factors (such as ")#link("https://en.wikipedia.org/wiki/Powerful_number")[#text("powerful numbers")]#text(" or very ")#link("https://en.wikipedia.org/wiki/Smooth_numbers")[#text("smooth numbers")]#text("), since it is those numbers for which the radical is going to be small enough that the abc conjecture carries nontrivial content. This is why that conjecture is useful for problems such as Fermat’s last theorem. The twin prime conjecture, by contrast, seems to relate only to the behaviour of numbers with very few factors (i.e. primes and almost primes). So there does not appear to be any obvious mechanism in which the abc conjecture could be deployed to improve upon the known results on the twin prime conjecture.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471743")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2016")])]

#text("I think in the function field case one can now get many twin primes and not just a few, using symmetry tricks. For fixed $q>104$, there are a large number of pairs of mimic irreducible polynomia of degree $n$ that differ by $1$, for all sufficiently large $n$ relatively prime to $q-1$. The point is that a pair of polynomials that differ by any constant can often by transformed into a pair that differ by $1$, so bounded gaps implies twin primes. See ")#link("http://web.stanford.edu/~rjlo/papers/11-BoundedGaps.pdf")[#text("http://web.stanford.edu/~rjlo/papers/11-BoundedGaps.pdf")]#text(" thm 1.4 which doesn’t state that there are many such pairs, but it follows from the argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471750")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2016")])]

#text("It would be interesting to see if there are also Zhang type (i.e. above ")#mi("1/2")#text(") estimates for levels of distribution for such number (or function) fields and their dependence on some parameters of each particular field.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470784")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("Erratum (repeated): the second displayed equation after equation (3) is missing a factor of ")#mi("\\log\\frac{n}{d}")#text(" in the summand.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470786")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("On the Proof Sketch of the famous Polignac Conjecture (")#link("https://en.wikipedia.org/wiki/Polignac%27s_conjecture")[#text("https://en.wikipedia.org/wiki/Polignac%27s_conjecture")]#text("):")

#text("We should consider three laws which govern the general behaviour of all prime numbers or their distribution (placement and number) along the natural number line:")

#text("Prime Work:")

#text("(1) There are infinitely many more positive integers (even or odd) than there are prime numbers, or prime numbers have a zero density relative to the positive integers according to the Prime Number Theorem (PNT), and")

#text("(2) prime numbers generate the positive even integers so efficiently that gaps between two consecutive prime numbers increase without bound.")

#text("(3) Prime Parity Law (PPL):")

#text("Pi(e = m*g = 1 + p_2n) = 2 * Pi(g = 1 + p_n) = 2n where Pi(*) is the prime counting function, and p_n > 2, p_2n are odd prime numbers; 2 < m ≤ 3;")#linebreak()#text(" and as g goes to infinity, m goes to 2.")

#text("From our understanding of the work of primes, we create an exceptional set, E, of consecutive odd prime numbers, p_n and p_n+1, whose prime gap, |p_n, p_n+1 | is some positive even integer, 2i. And we let P be the set of all odd prime numbers.")

#text("For example we construct the exceptional set, E_i:")

#text("E_i = {p_n, p_n+1 : p_n, p_n+1 ∈ P and |p_n – p_n+1| = 2i for any positive integer, i}.")

#text("And if we assume 0 ≤ |E_i| < ∞, then we must have the following probability calculation:")

#text("Prob( |p_n – p_n+1| = 2i | for all odd primes, p_n, p_n+1 ∉ E_i) = 0.")

#text("If we cannot verify this result, then we have a contradiction! And Polignac conjecture is true! :-) Bonne chance!")

#text("Reference link: ")#link("https://www.researchgate.net/profile/David_Cole24")[#text("https://www.researchgate.net/profile/David_Cole24")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471066")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#text("Updated Link:")#linebreak()#text(" ")#link("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")[#text("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471079")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("(2) Prime numbers generate the positive even integers so efficiently that gaps between two consecutive prime numbers increase without bound if and only if the Goldbach Conjecture and the Polignac Conjecture are true.")

#text("Reference link: ")#link("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")[#text("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471091")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("An update:")

#text("primework123")

#text("(2) Prime numbers generate the positive even integers so efficiently according to the Prime Number Theorem that gaps between two consecutive prime numbers increase without bound if and only if the Goldbach Conjecture and the Polignac Conjecture are true.")

#text("Reference link:")#linebreak()#text(" ")#link("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")[#text("https://www.researchgate.net/post/What_is_the_correct_proof_of_the_famous_and_important_Polignac_Conjecture")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471105")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2016")])]

#text("Hmm. For the sake of more clarity we should have:")

#text("(2) … the gaps between two consecutive prime numbers increase in size without bound …")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f861ae317410d9b67b9c8aa198e0169f19ce22b1824bb5d8833c64ba3d760fc-27591c1ed4e6d070bb4511bd2664acbe1e4a5ead848d49465677dab8ea154c1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-470808")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")])]

#text("Dear Prof. Tao,")

#text("just as an idea: It would be kind of beneficial to a lot of people if the lectures you give would be available via the internet in the form of a video; for, this would allow for consuming mathematics while eating, something which I find rather difficult because I can’t keep my head in a fixed position, making it impossible to read the stuff on the screen (or alternatively, I have to enlarge stuff, but then it looks bad and one has to scroll all the time).")

#text("It would be a great joy to see lectures of yours on topics that I have a chance of understanding!")

#text("w/br")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471712")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2016")])]

#text("A number of Prof. Tao’s lectures are on youtube.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471063")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#text("Apropos the twin prime conjecture, are all the difficulties for showing infinitely many primes of gap two apply for any other *fixed* gap? (In other words, is there a possibility that showing infinitely many pairs of primes of gap 23,101 (precisely) might be somehow easier?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#text("Only even gaps (unlike 23,101) should be considered.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471073")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#text("(pppps, Yes, I meant 23,102)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471099")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2016")])]

#text("“… is there a possibility that showing infinitely many pairs of primes of gap 23,102 (precisely) might be somehow easier?”")

#text("1. On the contrary. Although the reasoning should, prima facie, be similar, estimating the number ")#mi("\\pi_{_{2}}(x)")#text(" of twin(2) primes ")#mi("\\leq x")#text(" non-heuristically as ")#mi("\\sum_{_{n \\leq x}}P(n).P(n+2)")#text("—where ")#mi("P(n)")#text(" is the de facto probability that a given ")#mi("n")#text(" is a prime—is obviously less complicated than estimating the number ")#mi("\\pi_{_{23102}}(x)")#text(" of twin(23,102) primes ")#mi("\\leq x")#text(" non-heuristically as ")#mi("\\sum_{_{n \\leq x}}P(n).C(n+2) \\ldots C(n+23100).P(n+23102)")#text(", where ")#mi("C(n)")#text(" is the de facto probability that a given ")#mi("n")#text(" is composite.")

#text("2. In the case of a twin(2) prime, one would define an integer ")#mi("n")#text(" as a ")#mi("TW_{_{2}}(k)")#text(" integer if, and only if, ")#mi("r_{p_{_{i}}}(n) \\neq 0")#text(" and ")#mi("r_{p_{_{i}}}(n) \\neq 2")#text(" for all ")#mi("1 \\leq i \\leq k")#text(", where ")#mi("0 \\leq r_{_{i}}(n) \\leq i-1")#text(" is defined for all ")#mi("i \\geq 0")#text(" by:")

#mi("n + r_{_{i}}(n) \\equiv 0\\ (mod\\ i)")#text(".")

#text("3. Note that if ")#mi("n")#text(" is a ")#mi("TW_{_{2}}(k)")#text(" integer, then both ")#mi("n")#text(" and ")#mi("n+2")#text(" are not divisible by any of the first ")#mi("k")#text(" primes ")#mi("\\{p_{_{1}}, p_{_{2}}, \\ldots, p_{_{k}}\\}")#text(".")

#text("4. The asymptotic density of ")#mi("TW_{_{2}}(k)")#text(" integers over the set of natural numbers is then ")#mi("D(TW_{_{2}}(k)) = \\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("5. Further, if ")#mi("p_{_{k}}^{2} \\leq n \\leq p_{_{k+1}}^{2}")#text(" is a ")#mi("TW_{_{2}}(k)")#text(" integer, then either both ")#mi("n")#text(" and ")#mi("n+2")#text(" are primes, or ")#mi("n+2 = p_{_{k +1}}^{2}")#text(".")

#text("6. If we define ")#mi("\\pi_{_{TW_{_{2}}(k)}}(n)")#text(" as the number of ")#mi("TW_{_{2}}(k)")#text(" integers ")#mi("\\leq n")#text(", the expected number of ")#mi("TW_{_{2}}(k)")#text(" integers in any interval ")#mi("(a, b)")#text(" is given—with a binomial standard deviation—by ")#mi("\\pi_{_{TW_{_{2}}(k)}}(b) - \\pi_{_{TW_{_{2}}(k)}}(a) \\approx (b-a)\\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("7. Since ")#mi("\\pi_{_{TW_{_{2}}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{TW_{_{2}}(k)}}(p_{_{k}}^{2})")#text(" is at most one less than the number of twin(2) primes in the interval ")#mi("(p_{_{k+1}}^{2} - p_{_{k}}^{2})")#text(", it follows that:")

#mi("\\pi_{_{TW_{_{2}}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{TW_{_{2}}(k)}}(p_{_{k}}^{2}) + 1 \\geq \\pi_{_{2}}(p_{_{k+1}}^{2}) - \\pi_{_{2}}(p_{_{k)}}^{2}) \\geq \\pi_{_{TW_{_{2}}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{TW_{_{2}}(k)}}(p_{_{k}}^{2})")

#text("8. Now, the expected number of ")#mi("TW_{_{2}}(k)")#text(" integers in the interval ")#mi("(p_{_{k+1}}^{2} - p_{_{k}}^{2})")#text(" is given by:")

#mi("\\pi_{_{TW_{_{2}}(k)}}(p_{_{k+1}}^{2}) - \\pi_{_{TW_{_{2}}(k)}}(p_{_{k}}^{2}) \\approx (p_{_{k+1}}^{2} - p_{_{k}}^{2})\\prod_{i=2}^{k}(1 - \\frac{2}{p_{_{i}}})")#text(".")

#text("9. We conclude that the number ")#mi("\\pi_{_{2}}(p_{_{k+1}}^{2})")#text(" of twin(2) primes ")#mi("\\leq p_{_{k+1}}^{2}")#text(" is given by the cumulative non-heuristic approximation:")

#mi("\\sum_{j=1}^{k} (\\pi_{_{2}}(p_{_{j+1}}^{2}) - \\pi_{_{2}}(p_{_{j}}^{2})) = \\pi_{_{2}}(p_{_{k+1}}^{2}) \\approx \\sum_{j=1}^{k} (p_{_{j+1}}^{2} - p_{_{j}}^{2})\\prod_{i=2}^{j}(1 - \\frac{2}{p_{_{i}}}) \\rightarrow \\infty")#text(".")

#text("10. However, in the case of a twin(23,102) prime, in order to argue similarly one would need to define, and consider only, integers ")#mi("n > p_{_{11551}}^{^{2}}")#text(" as ")#mi("TW_{_{23102}}(k)")#text(" integers if, and only if, ")#mi("r_{p_{_{i}}}(n) \\neq 0")#text(" and ")#mi("r_{p_{_{i}}}(n) \\neq 23102")#text(" for all ")#mi("1 \\leq i \\leq k")#text(", but with the added qualification that, for each ")#mi("1 \\leq j < 11551")#text(", we must have ")#mi("r_{p_{_{i}}}(n) =2.j")#text(" for some ")#mi("1 \\leq i \\leq k")#text(", where ")#mi("0 \\leq r_{_{i}}(n) \\leq i-1")#text(" is defined for all ")#mi("i \\geq 0")#text(" by:")

#mi("n + r_{_{i}}(n) \\equiv 0\\ (mod\\ i)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471121")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2016")])]

#text("The parity problem strikes again …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("According to the Wikipedia article on Polignac’s conjecture, the first Hardy-Littlewood conjecture gives (for each even ")#mi("n")#text(") an explicit asymptotic estimate for the number of prime gaps of size ")#mi("n")#text(" below ")#mi("x")#text(".")#linebreak()#text(" This estimate implies that each odd prime factor ")#mi("q")#text(" of ")#mi("n")#text(" increases the conjectured density (of prime gaps of size ")#mi("n")#text(") compared to the density of twin primes by the factor ")#mi("(q-1)/(q-2)")#text(".")#linebreak()#text(" Therefore any prime gap with many distinct odd prime factors seems to be more frequent (and perhaps easier for such a proof).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471080")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("My very vague intuition is also in this direction. So e.g. now that we know that there are infinitely many pairs of gap at most 600 maybe we can prove that there are infinitely many pairs of gap 600! (Here ! is “factorial”) But specifically I wonder also if the infamous obstructions for twin primes apply also for 600! gap.")

#text("Here is another obvious question that maybe is not hopeless now: are there infinitely many consecutive primes p and q such that q-p is between 600 and 600! (Again, ! is factorial!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5feab368df49efed459a79efe1ba9194224791125f1fa78cf45acfb935d3541-78acae02d54265103985d8c560ebbaeda885476b77a53cc8fe38c0cf3fc740d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of poqv")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471081")[#strong[#text("poqv")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2016")])]

#text("Yes the obstruction still applies. The “obstruction” otherwise known as the parity barrier is encapsulated in the following problem: A sieve is not able to show that n (n + 2) is infinitely often a product of two primes, and it’s not able to show that this is infinitely often a product of three primes. Showing either of these statements would break the parity barrier. However sieves can show that n (n + 2) is infinitely often the product of either two or three primes. To break through this barrier you need additional techniques that break the parity barrier (such as analytic input from bilinear forms). Now sieves are also able to show results of the type “at least one of the object in this finite set is prime (or other desirable property)”, but can’t tell you which element exactly, for example there are also results on Artin’s conjecture on primitive roots which say that out of any set of three non-squares at least one satisfies Artin’s conjecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471133")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2016")])]

#text("One way to avoid the ‘parity’ barrier when estimating prime counting functions may be to recognise the following, essentially different, instances that involve defining the probability of an integer:")

#text("(i) The probability ")#mi("P_{_{1}}(p)")#text(" of ")#emph[#text("selecting")]#text(" an integer that has the property ")#mi("p")#text(" from a ")#emph[#text("given")]#text(" set ")#mi("S")#text(" of integers;")

#emph[#text("Example 1")]#text(": If ")#mi("N")#text(" is the set of natural numbers, what is the probability of ")#emph[#text("selecting")]#text(" an integer ")#mi("n \\in N")#text(" that has the property of being a prime?")

#text("Since we cannot define a precise ratio of primes to composites in ")#mi("N")#text(", but only an order of magnitude such as ")#mi("O(\\frac{1}{log_{_{e}}n})")#text(", the probability ")#mi("P_{_{1}}(p) \\equiv P(n \\in N\\ is\\ a\\ prime)")#text(" of ")#emph[#text("selecting")]#text(" an integer that is a prime obviously cannot be defined in ")#mi("N")#text(".")

#text("(ii) The probability ")#mi("P_{_{2}}(p)")#text(" that an integer, in a ")#emph[#text("given")]#text(" set ")#mi("S")#text(" of integers, ")#emph[#text("has")]#text(" the property ")#mi("p")#text(";")

#emph[#text("Example 2")]#text(": If ")#mi("N+")#text(" is the set of positive integers, what is the probability that an integer ")#mi("n \\in N+")#text(" is even? This is the basis for setting odds in games such as roulette; or for determining the probability of the spin state of a particle.")

#text("Since the ratio of odd to even numbers in ")#mi("N+")#text(" is ")#mi("1:1")#text(", the probability ")#mi("P_{_{2}}(p) \\equiv P(n \\in N+\\ is\\ even)")#text(" that an integer ")#mi("n \\in N+")#text(" ")#emph[#text("has")]#text(" the property of being even—which obviously cannot depend upon the probability ")#mi("P_{_{1}}(p) \\equiv P(n \\in N+\\ is\\ even)")#text(" of ")#emph[#text("selecting")]#text(" an integer ")#mi("n \\in N+")#text(" that has the property of being even—must be ")#mi("\\frac{1}{2}")#text(", even though ")#mi("\\sum_{_{i = 1}}^{^{\\infty}}P(i \\in N+\\ is\\ even) \\neq 1")#text(".")

#text("(iii) The probability ")#mi("P_{_{3}}(p)")#text(" of ")#emph[#text("determining")]#text(" that a ")#emph[#text("given")]#text(" integer ")#mi("n")#text(" has the property ")#mi("p")#text(".")

#emph[#text("Example 3")]#text(": I give you a ")#mi("5")#text("-digit combination lock along with a ")#mi("10")#text("-digit integer ")#mi("n")#text(". The lock only opens if you set the combination to a proper factor of ")#mi("n")#text(" which is greater than ")#mi("1")#text(". What is the probability that the first combination you try will open the lock. This is the basis for RSA encryption, which provides the cryptosystem used by many banks for securing their communications.")

#text("By considering the behaviour of ")#mi("0 \\leq r_{_{i}}(n) \\leq i-1")#text(", which is defined for all ")#mi("i \\geq 0")#text(" by:")

#mi("n + r_{_{i}}(n) \\equiv 0\\ (mod\\ i)")#text(",")

#text("appropriately, this example admits that, whether or not a prime ")#mi("p")#text(" divides a ")#emph[#text("given")]#text(" integer ")#mi("n")#text(", ")#emph[#text("is")]#text(" indeed independent of whether or not a prime ")#mi("q \\neq p")#text(" divides ")#mi("n")#text("; whence we have that ")#mi("P_{_{3}}(p) \\equiv P(n\\ is\\ a\\ prime) = \\prod_{_{i = 1}}^{^{\\pi(\\sqrt{n})}}(1-\\frac{1}{p_{_{i}}})")#text(".")

#text("Whilst the ‘parity’ barrier is encountered in the first case, the last appears to circumvent it if we define prime counting functions in terms of the residues ")#mi("r_{_{i}}(n)")#text(", which are best expressed in a 2-dimensional representation of Eratosthenes Sieve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471135")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2016")])]

#text("It seems that like other famous problems (e.g. FLT or the Poincare conjecture) if there is a solution for the twin prime conjecture, it may follow as a particular case of a solution to a more general problem (whose formulation is still unknown!) which allows the use of additional (and perhaps more general) mathematical methods.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa1365f6c950c850c31099c5c7716df071e1cb8a6efce69ef9ae9433d509db6-8ae6ab89d54a8e28245aeacb702ccc10e7706e136c9b30896a01dbb8211ff135.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of primework123")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471177")[#strong[#text("primework123")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2016")])]

#text("FYI: On A Simpler Proof of Fermat’s Last Theorem,")

#link("https://www.researchgate.net/publication/300080369_A_Simpler_Proof_of_Fermat%27s_Last_Theorem")[#text("https://www.researchgate.net/publication/300080369_A_Simpler_Proof_of_Fermat%27s_Last_Theorem")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471179")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2016")])]

#text("Well yes, in the sense that we ")#emph[#text("can")]#text(" define a Generalised Prime Counting Function, ")#mi("\\sum_{j = 1}^{n} \\prod_{i = a}^{\\pi(\\sqrt{j})}(1 - \\frac{b}{p_{_{i}}})")#text(", which estimates the number of integers ")#mi("\\leq n")#text(" such that there are ")#mi("b")#text(" values that cannot occur amongst the residues ")#mi("r_{p_{_{i}}}(n)")#text(" for ")#mi("a \\leq i \\leq \\pi(\\sqrt{j})")#text(", where ")#mi("0 \\leq r_{_{i}}(n) \\leq i-1")#text(" is defined for all ")#mi("i \\geq 0")#text(" by:")

#mi("n + r_{_{i}}(n) \\equiv 0\\ (mod\\ i)")

#text("Thus ")#mi("b = 1")#text(" yields an estimate for the number ")#mi("\\pi(n)")#text(" of primes ")#mi("\\leq n")#text("; and ")#mi("b = 2")#text(" an estimate for the number of ")#mi("TW_{_{2}}")#text(" integers ")#mi("\\leq n")#text(", which approximates the number ")#mi("\\pi_{_{2}}(n)")#text(" of twin primes ")#mi("\\leq n")#text(".")

#text("Note that:")

#mi("\\sum_{j = 1}^{n} \\prod_{i = a}^{\\pi(\\sqrt{j})}(1 - \\frac{b}{p_{_{i}}}) \\rightarrow \\infty")#text(" as ")#mi("n \\rightarrow \\infty")#text(" if ")#mi("p_{_{a}} > b \\geq 1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/16a8967c1e9c778177283e862347313e359f4ec8a94432259f164768abbe4d66-add38f023258e8054c5dd91237a856b3ea53bc730e87d5fe9e3a7ed09b8314e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bhupinder Singh Anand")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471203")[#strong[#text("Bhupinder Singh Anand")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2016")])]

#text("At a slightly deeper level, the ‘general’ result—which admits non-heuristic estimations of prime-counting functions such as ")#mi("\\pi(n)")#text(", ")#mi("\\pi_{_{2}}(n)")#text(", and even of Dirichlet primes in an arithmetical progression—is that the prime divisors of an integer are independent.")

#text("The argument runs as follows:")

#text("(a) The probability ")#mi("P(n+u \\equiv\\ 0\\ (mod\\ i)\\ |\\ n > i > 1;\\ i > u \\geq 0)")#text(" that the spin of an ")#mi("i")#text("-faced cryptex wheel—with faces numbered ")#mi("0, 1, 2, \\ldots, i-1")#text("—will yield the value ")#mi("0 \\leq u \\leq i-1")#text(", is ")#mi("\\frac{1}{i}")#text(" by the probability model for such an event as definable over the probability space ")#mi("(0, 1, 2, \\ldots, i-1)")#text(".")

#text("(b) The probability ")#mi("P(n+u \\equiv\\ 0\\ (mod\\ i);\\ n+v \\equiv\\ 0\\ (mod\\ j))")#text(" that the simultaneous spin of one ")#mi("i")#text("-faced cryptex wheel, and one ")#mi("j")#text("-faced cryptex wheel, will yield the values ")#mi("0 \\leq u \\leq i-1")#text(" and ")#mi("0 \\leq v \\leq j-1")#text(", respectively, is ")#mi("\\frac{1}{i.j}")#text(" by the probability model for such a simultaneous event as defined over the probability space ")#mi("\\{(u, v): i > u \\geq 0,\\ j > v \\geq 0\\}")#text(".")

#text("(c) If ")#mi("i")#text(" and ")#mi("j")#text(" are co-prime, the compound probability ")#mi("P(i\\ divides\\ n;\\ j\\ divides\\ n)")#text(" of correctly determining that ")#mi("i")#text(" divides ")#mi("n")#text(" and ")#mi("j")#text(" divides ")#mi("n")#text(" from the simultaneous spin of one ")#mi("i")#text("-faced cryptex wheel and one ")#mi("j")#text("-faced cryptex wheel, is the product of the probability of correctly determining that ")#mi("i")#text(" divides ")#mi("n")#text(" from the spin of an ")#mi("i")#text("-faced cryptex wheel, and the probability of correctly determining that ")#mi("j")#text(" divides ")#mi("n")#text(" from the spin of a ")#mi("j")#text("-faced cryptex wheel.")

#emph[#text("Reason")]#text(": If ")#mi("i")#text(" and ")#mi("j")#text(" are co-prime, and ")#mi("n + r_{i.j}(n) \\equiv 0\\ (mod\\ i.j)")#text(", then the ")#mi("i.j")#text(" integers ")#mi("r_{j}(n).i + r_{i}(n).j")#text(" are all incongruent and form a complete system of residues. It follows that ")#mi("n = a.i")#text("—whence ")#mi("i")#text(" divides ")#mi("n")#text("—and also ")#mi("n = b.j")#text("—whence ")#mi("j")#text(" divides ")#mi("n")#text("—if, and only if ")#mi("r_{i}(n)  = r_{j}(n) = r_{i.j}(n) = 0")#text(".")

#emph[#text("Note")]#text(": The assumption that ")#mi("i")#text(" and ")#mi("j")#text(" be co-prime is necessary, since the above would not follow if ")#mi("i")#text(" and ")#mi("j")#text(" were not co-prime. For instance, let ")#mi("j=2i")#text(". The probability that the spin of an ")#mi("i")#text("-faced cryptex wheel will then yield ")#mi("0")#text("—and allow us to correctly conclude that ")#mi("i")#text(" divides ")#mi("n")#text("—is ")#mi("\\frac{1}{i}")#text(", and the probability that the spin of a ")#mi("j")#text("-faced cryptex wheel will then yield ")#mi("0")#text("—and allow us to correctly conclude that ")#mi("j")#text(" divides ")#mi("n")#text("—is ")#mi("\\frac{1}{j}")#text("; but the probability of correctly determining both that ")#mi("i")#text(" divides ")#mi("n")#text(", and that ")#mi("j")#text(" divides ")#mi("n")#text(", from a simultaneous spin of the two cryptex wheels is ")#mi("\\frac{1}{j}")#text(", and not ")#mi("\\frac{1}{i.j}")#text(".")

#text("(d) If ")#mi("p")#text(" and ")#mi("q")#text(" are two unequal primes, the probability of determining whether ")#mi("p")#text(" divides ")#mi("n")#text(" is thus independent of the probability of determining whether ")#mi("q")#text(" divides ")#mi("n")#text(".")

#text("The significance of (d) for ")#emph[#text("non-heuristic")]#text(" estimation of prime-counting functions is that;")

#text("(e) The ")#emph[#text("non-heuristic")]#text(" expected number of ‘prime’ combinations—i.e., where a ")#mi("0")#text(" does not appear, and so the combination corresponds 1-1 to a prime ")#mi("\\leq n")#text("—which occur in a set of ")#mi("n")#text(" simultaneous spins of the ")#mi("\\pi(\\sqrt{n})")#text(" cryptex wheels with ")#mi("p_{_{1}},\\ p_{_{2}},\\ \\ldots,\\ p_{_{\\pi(\\sqrt{n})}}")#text(" faces, respectively, is a ")#emph[#text("non-heuristic")]#text(" estimate of the number ")#mi("\\pi(n)")#text(" of primes ")#mi("\\leq n")#text("; whence ")#mi("\\pi(n) \\approx n.\\prod_{_{i = 1}}^{^{\\pi(\\sqrt{n})}}(1-\\frac{1}{p_{_{i}}}) \\rightarrow \\infty")#text(", with a binomial standard deviation.")

#text("Moreover, even though we cannot define the probability ")#mi("P_{_{1}}(p) \\equiv P(n \\in N\\ is\\ a\\ prime)")#text(" of ")#emph[#text("selecting")]#text(" an integer from the set ")#mi("N")#text(" of all natural numbers that has the property of being prime, it follows that:")

#text("(f) The non-heuristic probability that an integer ")#mi("n")#text(" has the property of being a prime is ")#mi("\\prod_{_{i = 1}}^{^{\\pi(\\sqrt{n})}}(1-\\frac{1}{p_{_{i}}})")#text(".")

#text("The wider significance of (d) is that it also allows computing the complexity of Integer Factorisation:")

#text("(g) Since any given integer ")#mi("n")#text(" is a prime if, and only if, it is not divisible by any prime ")#mi("p \\leq \\sqrt{n}")#text(", and since ")#mi("n")#text(" may be the square of a prime, it follows that we necessarily require at least one logical operation for each prime ")#mi("p \\leq \\sqrt{n}")#text(" in order to logically determine whether ")#mi("p")#text(" is a prime divisor of ")#mi("n")#text(".")

#text("(h) Since the number of such primes is of the order ")#mi("O(\\frac{\\sqrt{n}}{log_{e}\\ n})")#text(", and the prime divisors of an integer are mutually independent, the number of computations required by any deterministic algorithm that always computes a prime factor of ")#mi("n")#text(" cannot be polynomial-time—i.e. of order ")#mi("O((log_{e}\\ n)^{c})")#text(" for any ")#mi("c")#text("—in the length of the input ")#mi("n")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2016")])]

#text("If true, this short proof must be from “the book” !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb65d70139ddf562e8dee6ab41b5c5d000dd37448449517dbd9ef8bfa2391b8a-89c2217b24cfdacbe0001281b746fa522ddf0f4adaada2bc8991e3ca06226040.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Hard")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471311")[#strong[#text("Jhon Hard")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2016")])]

#text("It is absolutely true. I hope that the professor Tao he gives us his valuation, as soon as possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7395a5d4ff419ba231408b627550161e8a1bdc480321055fad2e2c50df9cedbc-b07b760a881980f439c46120857edad545ca60d795955adbe9bd5dde7cb6ef8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MDC")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471397")[#strong[#text("MDC")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2016")])]

#text("I was more interested in the sifting density had by ")#link("https://www.dropbox.com/s/ttekpetkc5k8u4g/Final%20Trump.mp4?dl=0")[#text("eye cue balls")]#text(". The parity problem is kind of “odd” but even as well and your “idiosyncratic twist” with a “Fourier-analytic flavour” is predictable but leaves slit tongues in the mouth of my gift stalking horse. While undergraduates pay more and half of empirical studies are getting invalidated because people can’t learn elementary regression diagnostics from the math departments, I guess prime number theory is fine, as long as you keep the discontinuity-challenged away from Wall Street. But seriously, a trillion zeros and I start falling asleep. However, as Gil can attest, you guys are still making more progress than the quantum computer crowd doing exponential computations on a psi-ontic wave function. Zoom, bank, spill… clowns.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471470")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("I would like to suggest that the twin prime problem has been incorrectly addressed, and that to prove there are an infinite number of them requires thinking along different lines. For example, there are 9 classes of twin primes, given by Sloane’s A224855, A224856, A224859, A224854, A224860, A224862, A224864, A224865 and A224857. To prove that A224854 [Numbers n such that 90*n+11 and 90*n+13 are twin prime] contains infinite n one must produce an algorithm capable of reducing a sequence m [0,1,2,3,4,5,6,7,8,9…] to a smaller sequence n [0,1,2,3,5,7,9…] in such a way the algorithm does not contain a state dependency (the algorithm does not rely in any way on terms from the output to generate further results). What I mean is that such an algorithm cannot have an internal reference, as we find with traditional sieves.")

#text("There are 24 sequence generator functions required to produce a list n of twin primes beneath some given limit. I will not attempt to reproduce those generator functions here, rather I will reference you to some code. I am not a mathematician, I am an algorithm designer. As such, I cannot express the content of my algorithms in “your” language. I know that you will instantly see the relationships and will immediately understand the implications of this work.")

#text("There is one other sequence that is germane to this discussion, one that I feel will be far more illustrative that the twin prime sequence. Please refer to A255491 for a better understanding of the sieve referenced in the following link.")

#link("https://github.com/superobserver/elder-sieve")[#text("https://github.com/superobserver/elder-sieve")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471708")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2016")])]

#text("Well done!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471773")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("Imagine listening to Beethoven’s 5th Symphony and then trying to write music for a single instrument to recreate what you heard. I feel that most attempts at making sense of the prime distribution amounts to little more than that, to wit, “That dog won’t hunt.” It is a valid approach to separate the twin prime conjecture into 9 separate problems, as the twin primes demonstrably reduce to 9 separate sequences. And as with reverse-engineering a symphony, it gets a lot easier to make sense of things once you realize there is more than one instrument at work. The same is true of the prime distribution; with Eratosthenes we have sq.rt limit functions necessary to reduce a list of numbers to a list of primes. This tells us nothing about the prime distribution as an object unto itself, rather it tells us about the functions that are “discovered along the way.” Perhaps most importantly the SoE is not a method to generate primes it is a method to generate composites while leaving a residue of primes. Well if you segregate the primes into 24 classes distributing composites becomes trivial. So as not to confuse the issue, let’s remain in base-10 and look at sequence A142312. This sequence is a counterpart to A181732. Obviously, being a list of primes, we can state that it is non-trivial to generate. However, as opposed to SoE, it is “insanely trivial” to produce the list of composites. There is no base-10 composite sequence associated with A142312, but there is a composite sequence for A181732, namely A255491. Below I offer you an alternative sieve method for generating the base-10 equivalent to A255491. Now, I am no mathematician, but I think that this is a radical improvement over SoE in terms of having no internal references and therefore it allows for OoOE (unlike SoE which requires strictly sequential processing). Regarding the python code below you can of course change the limit to suit your curiosity. Note: The 24 classes reduce to digital root and last digit preserving sequences, indicating that simple algebraic relations underpin the allowable p*q relationships.")

#text("limit = 1")#linebreak()#text(" limit2 = 2")

#text("#composites for 19,19")#linebreak()#text(" var_19 = [19 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_19a = [y * (19 + (90*z)) for y in var_19 for z in xrange(0, limit2)]")#linebreak()#text(" print var_19a")

#text("#composites for 91,91")#linebreak()#text(" var_91 = [91 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_91a = [y * (91 + (90*z)) for y in var_91 for z in xrange(0, limit2)]")#linebreak()#text(" print var_91a")

#text("#composites for 37,73")#linebreak()#text(" var_37 = [37 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_73 = [y * (73 + (90*z)) for y in var_37 for z in xrange(0, limit2)]")

#text("var_73a = [73 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_37a = [y * (37 + (90*z)) for y in var_73a for z in xrange(0, limit2)]")

#text("print var_73")#linebreak()#text(" print var_37a")

#text("#composites for 11,41")#linebreak()#text(" var_11 = [11 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_41 = [y * (41 + (90*z)) for y in var_11 for z in xrange(0, limit2)]")

#text("var_41a = [41 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_11a = [y * (11 + (90*z)) for y in var_41a for z in xrange(0, limit2)]")

#text("print var_41")#linebreak()#text(" print var_11a")

#text("#composites for 47,23")#linebreak()#text(" var_47 = [47 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_23 = [y * (23 + (90*z)) for y in var_47 for z in xrange(0, limit2)]")

#text("var_23a = [23 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_47a = [y * (47 + (90*z)) for y in var_23a for z in xrange(0, limit2)]")

#text("print var_23")#linebreak()#text(" print var_47a")

#text("#composites for 83,77")#linebreak()#text(" var_83 = [83 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_77 = [y * (77 + (90*z)) for y in var_83 for z in xrange(0, limit2)]")

#text("var_77a = [77 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_83a = [y * (83 + (90*z)) for y in var_77a for z in xrange(0, limit2)]")

#text("print var_77")#linebreak()#text(" print var_83a")

#text("#composites for 13,7")#linebreak()#text(" var_13 = [13 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_7 = [y * (7 + (90*z)) for y in var_13 for z in xrange(0, limit2)]")

#text("var_7a = [7 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_13a = [y * (13 + (90*z)) for y in var_7a for z in xrange(0, limit2)]")

#text("print var_7")#linebreak()#text(" print var_13a")

#text("#composites for 31,61")#linebreak()#text(" var_31 = [31 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_61 = [y * (61 + (90*z)) for y in var_31 for z in xrange(0, limit2)]")

#text("var_61a = [61 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_31a = [y * (31 + (90*z)) for y in var_61a for z in xrange(0, limit2)]")

#text("print var_61")#linebreak()#text(" print var_31a")

#text("#composites for 49,79")#linebreak()#text(" var_49 = [49 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_79 = [y * (79 + (90*z)) for y in var_49 for z in xrange(0, limit2)]")

#text("var_79a = [79 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_49a = [y * (49 + (90*z)) for y in var_79a for z in xrange(0, limit2)]")

#text("print var_79")#linebreak()#text(" print var_49a")

#text("#composites for 67,43")#linebreak()#text(" var_67 = [67 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_43 = [y * (43 + (90*z)) for y in var_67 for z in xrange(0, limit2)]")

#text("var_43a = [43 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_67a = [y * (67 + (90*z)) for y in var_43a for z in xrange(0, limit2)]")

#text("print var_43")#linebreak()#text(" print var_67a")

#text("#composites for 17,53")#linebreak()#text(" var_17 = [17 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_53 = [y * (53 + (90*z)) for y in var_17 for z in xrange(0, limit2)]")

#text("var_53a = [53 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_17a = [y * (17 + (90*z)) for y in var_53a for z in xrange(0, limit2)]")

#text("print var_53")#linebreak()#text(" print var_17a")

#text("#composites for 71,71")#linebreak()#text(" var_71 = [71 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_71a = [y * (71 + (90*z)) for y in var_71 for z in xrange(0, limit2)]")#linebreak()#text(" print var_71a")

#text("#composites for 89,89")#linebreak()#text(" var_89 = [89 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_89a = [y * (89 + (90*z)) for y in var_89 for z in xrange(0, limit2)]")#linebreak()#text(" print var_89a")

#text("sys.exit(0)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeffrey Helkenberg")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-471873")[#strong[#text("Jeffrey Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("Left one of the functions out. You can add the mergedlist lines at the end of the script to make more sense of the output, in terms of generating a csv output file that can be easily sorted. Captures all the composites provided the ranges are adequate.")

#text("#composites for 29, 59")#linebreak()#text(" var_29 = [29 + (90*x) for x in xrange(0, limit)]")#linebreak()#text(" var_59 = [y * (59 + (90*z)) for y in var_29 for z in xrange (0, limit2)]")#linebreak()#text(" print var_59")

#text("mergedlist = list(set(var_59 + var_29a + var_19a + var_91a + var_73 + var_37a + var_41 + var_11a + var_23 + var_47a + var_77 + var_83a + var_7 + var_13a + var_61 + var_31a + var_79 + var_49a + var_43 + var_67a + var_53 + var_17a + var_71a + var_89a))")

#text("values = mergedlist")#linebreak()#text(" thecsv = csv.writer(open(“composites.csv”, ‘wb’))")#linebreak()#text(" for value in values:")#linebreak()#text(" thecsv.writerow([value])")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-498032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#emph[#text("ie:")]

#mi("(2n - p + p = 2n)")#text(" where ")#mi("2n - p = p_n")

#text("If this is true, the conjecture is true")#linebreak()

#text("Hint: No, no, no.")

#text("Also, read this: ")#link("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")[#text("https://terrytao.wordpress.com/career-advice/dont-prematurely-obsess-on-a-single-big-problem-or-big-theory/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/112d6cf5cf1827858c1cda281ccc060383db7610c694e060d846aaa769ccc7fb-4b1aa8b12df1baadff81d33cf5d2006e54d5f683b154cba2fff0bbffdc4855c6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aldo Pappalepore")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-682821")[#strong[#text("Aldo Pappalepore")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2024")])]

#text("Dear Professor Tao, I would be very grateful for your opinion on this study of Hardy-Littlewood conjectures and the Goldbach: ")#link("https://alpalerweb.altervista.org/Hardy_Littlewood_and_Goldbach_conjecture")[#text("https://alpalerweb.altervista.org/Hardy_Littlewood_and_Goldbach_conjecture")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/07/17/notes-on-the-bombieri-asymptotic-sieve/#comment-692888")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2026")])]

#text("Your discussion here of the singular series and of the parity obstruction — sieves counting almost-primes as readily as primes — prompts three observations from an elementary “sieve-as-landscape” bookkeeping. I’d be grateful for pointers to where any of them are already known.")

#text("The setup: draw each n ≥ 2 as a column of width lpf(n) (least prime factor) and height n/lpf(n), so primes are 1×p columns and width-p “activates” at p², thereafter claiming exactly the integers with lpf(n) = p. It is just the sieve of Eratosthenes drawn as a landscape, but three things come out cleanly.")

#text("(1) Surely folklore, but clean. For an offset set H let v_q = #{ h mod q : h ∈ H } and S_q = (q − v_q)/q (the survivor fraction when width-q activates). For the twin offset {0,2} one has v_2 = 1 and v_q = 2 for q > 2, and")

#text("∏_q S_q/(1 − 1/q)² = 2 · ∏_{q>2} q(q−2)/(q−1)² = 2C₂ = 1.32032…,")

#text("exactly the Hardy–Littlewood twin singular series, with the leading 2 coming from the q = 2 collision. The elementary survivor product and the circle-method constant are literally the same product (it generalizes to any admissible tuple).")

#text("(2) A conjecture I could not find named. Doubling sends the twin-candidate window into (x, 2x]; the expected count E(x) = 2C₂·x/(log x)² exceeds 1 early and grows, and a Poisson miss-probability ≈ exp(−E(x)) makes the total number of dyadic exceptions converge — empirically the last is (5,7) → (11,13). This makes the following natural:")

#text("for x ≥ 11, π₂(2x) − π₂(x) ≥ 1, equivalently consecutive twins satisfy T_{k+1} < 2·T_k.")

#text("Verified to 10¹⁰ (27.4M twins, no exception past 11). It sits strictly between the Zhang–Maynard bounded-gaps theorems and the twin-prime conjecture: immediate under Hardy–Littlewood, open unconditionally. Is it in the literature?")

#text("(3) More speculative, and closest to the parity theme of this post. Let dx(n) = 1 if n is prime and lpf(n) if composite. Empirically H(dx) ≈ 2.483 bits; conditioning on n mod 30 drops this to ≈ 0.783, so the template supplies ≈ 1.700 bits (stable across 10⁴–10⁶). The residual splits into ≈ 0.52 bits (“which large lpf”) and ≈ 0.26 bits of “is this template-open position actually prime?” (peaking near 10⁴) — the part the coverage structure cannot supply. This looks like an information-theoretic shadow of the very parity obstruction discussed here. Is this bit-budget equivalent to a known quantity — a finite-scale parity problem, or the entropy of μ against zero-entropy systems (Sarnak)?")
]
