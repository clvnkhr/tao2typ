// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/
// Converted to Typst by tao2typ: "2026-10-14T11:23:08.940090+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Simons Lecture III: Structure and randomness in PDE", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Simons Lecture III: Structure and randomness in PDE")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/")[#text("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[This lecture is also doubling as this week’s “open problem of the week”, as it (eventually) discusses the ")#emph[#text("soliton resolution conjecture")]#text(".]")

#text("In this third lecture, I will talk about how the dichotomy between structure and randomness pervades the study of two different types of partial differential equations (PDEs):")

#list(
[#emph[#text("Parabolic PDE")]#text(", such as the ")#link("http://en.wikipedia.org/wiki/Heat_equation")[#text("heat equation")]#text(" ")#mi("u_t = \\Delta u")#text(", which turn out to play an important role in the modern study of ")#link("http://en.wikipedia.org/wiki/Geometric_topology_%28mathematical_subject%29")[#text("geometric topology")]#text("; and")],
[#emph[#text("Hamiltonian PDE")]#text(", such as the ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger equation")]#text(" ")#mi("u_t = i \\Delta u")#text(", which are heuristically related (via ")#link("http://en.wikipedia.org/wiki/Liouville's_theorem_(Hamiltonian)")[#text("Liouville’s theorem")]#text(") to measure-preserving actions of the real line (or ")#emph[#text("time axis")]#text(") ")#mi("{\\Bbb R}")#text(", somewhat in analogy to how combinatorial number theory and graph theory were related to measure-preserving actions of ")#mi("{\\Bbb Z}")#text(" and ")#mi("S_\\infty")#text(" respectively, as discussed in the ")#link("https://terrytao.wordpress.com/2007/04/07/simons-lecture-ii-structure-and-randomness-in-ergodic-theory-and-graph-theory/")[#text("previous lecture")]#text(".")]
)

#text("(In physics, one would also insert some physical constants, such as ")#link("http://en.wikipedia.org/wiki/Planck%27s_constant")[#text("Planck’s constant")]#text(" ")#mi("\\hbar")#text(", but for the discussion here it is convenient to normalise away all of these constants.)")

#metadata(none) <tao-bfeb22d5a05fc96c1dcb>#text("Observe that the form of the heat equation and Schrödinger equation differ only by a constant factor of i (in close analogy with ")#link("http://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text("). This makes the ")#emph[#text("algebraic")]#text(" structure of the heat and Schrödinger equations very similar (for instance, their ")#link("http://en.wikipedia.org/wiki/Fundamental_solution")[#text("fundamental solutions")]#text(" also only differ by a couple factors of i), but the ")#emph[#text("analytic")]#text(" behaviour of the two equations turns out to be very different. For instance, in the category of ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz functions")]#text(", the heat equation can be continued forward in time indefinitely, but not backwards in time; in contrast, the Schrödinger equation is time reversible and can be continued indefinitely in both directions. Furthermore, as we shall shortly discuss, parabolic equations tend to ")#emph[#text("dissipate")]#text(" or destroy the pseudorandom components of a state, leaving only the structured components, whereas Hamiltonian equations instead tend to ")#emph[#text("disperse")]#text(" or radiate away the pseudorandom components from the structured components, without destroying them.")

#text("Let us now discuss parabolic PDE in more detail. We begin with a simple example, namely how the heat equation can be used to solve the Dirichlet problem, of constructing a harmonic function ")#mi("\\Delta u_\\infty = 0")#text(" in a nice domain ")#mi("\\Omega")#text(" with some prescribed boundary data. As this is only an informal discussion I will not write down the precise regularity and boundedness hypotheses needed on the domain or data. The harmonic function will play the role here of the “structured” or “geometric” object. From calculus of variations we know that a smooth function ")#mi("u_\\infty: \\Omega \\to {\\Bbb R}")#text(" is harmonic with the specified boundary data if and only if it minimises the ")#emph[#text("Dirichlet energy")]#text(" ")#tao-math("E(u) := \\frac{1}{2} \\int_\\Omega \\left|\\nabla u\\right|^2", block: false)#text(", which is a convex functional on u, with the prescribed boundary data. One way to locate the harmonic minimum ")#mi("u_\\infty")#text(" is to start with an arbitrary smooth initial function ")#mi("u_0: \\Omega \\to {\\Bbb R}")#text(", and then perform gradient flow ")#mi("\\partial_t u = -\\frac{\\delta E}{\\delta u}(u) = \\Delta u")#text(" on this functional, i.e. solve the heat equation with initial data ")#mi("u(0) = u_0")#text(". One can then show (e.g. by spectral theory of the Laplacian) that regardless of what (smooth) data ")#mi("u_0")#text(" one starts with, the solution u(t) to the heat equation exists for all positive time, and converges to the (unique) harmonic function ")#mi("u_\\infty")#text(" on ")#mi("\\Omega")#text(" with the prescribed boundary data in the limit ")#mi("t \\to \\infty")#text(". Thus we see that the heat flow removes the “random” component ")#mi("u_0 - u_\\infty")#text(" of the initial data over time, leaving only the “structured” component ")#mi("u_\\infty")#text(".")

#text("There are many other settings in geometric topology in which one wants to locate a geometrically structured object (e.g. a harmonic map, a constant-curvature manifold, a minimal surface, etc.) within a certain class (e.g. a homotopy class) by minimising an energy-like functional. In some cases one can achieve this by brute force, creating a minimising sequence and then extracting a limiting object by some sort of compactness argument (as is for instance done in the ")#link("http://www.ams.org/mathscinet-getitem?mr=604040")[#text("Sacks-Uhlenbeck theory of minimal 2-spheres")]#text("), but then one often has little control over the resulting structured object that one obtains in this manner. By using a parabolic flow (as for instance done in the ")#link("http://www.ams.org/mathscinet-getitem?mr=164306")[#text("work of Eells-Sampson")]#text(" to obtain harmonic maps in a given homotopy class via harmonic map heat flow) one can often obtain much better estimates and other control on the limit object, especially if certain curvatures in the underlying geometry have a favourable sign.")

#text("The most famous recent example of the use of parabolic flows to establish geometric structure from topological objects is, of course, Perelman’s use of the Ricci flow applied to compact 3-manifolds with arbitrary Riemannian metrics, in order to establish the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_conjecture")[#text("Poincaré conjecture")]#text(" (for the special case of simply connected manifolds) and more generally the ")#link("http://en.wikipedia.org/wiki/Geometrization_conjecture")[#text("geometrisation conjecture")]#text(" (for arbitrary manifolds). [As I understand it, there are some minor but non-trivial technical issues left to clear up with the latter argument, but it seems that these will be resolved soon. The former argument, however, has been checked rather thoroughly.] Perelman’s work showed that Ricci flow, when applied to an arbitrary manifold, will eventually create either extremely geometrically structured, symmetric manifolds (e.g. spheres, hyperbolic spaces, etc.), or singularities which are themselves very geometrically structured (and in particular, their asymptotic behaviour is extremely rigid and can be classified completely). By removing all of the geometric structures that are generated by the flow (via surgery, if necessary) and continuing the flow indefinitely, one can eventually remove all the “pseudorandom” elements of the initial geometry and describe the original manifold in terms of a short list of very special geometric manifolds, precisely as predicted by the geometrisation conjecture. It should be noted that Richard Hamilton had ")#link("http://www.ams.org/mathscinet-getitem?mr=664497")[#text("earlier carried out exactly this program")]#text(" assuming some additional curvature hypotheses on the initial geometry; also, when Ricci flow is instead applied to two-dimensional manifolds (surfaces) rather than three, ")#link("http://www.ams.org/mathscinet-getitem?mr=954419")[#text("he observed")]#text(" that Ricci flow extracts a constant-curvature metric as its structured component of the original metric, giving an independent proof of the ")#link("http://en.wikipedia.org/wiki/Uniformization_theorem")[#text("uniformisation theorem")]#text(" (see ")#link("http://www.ams.org/mathscinet-getitem?mr=2231924")[#text("this recent paper")]#text(" for full details).")

#text("Let us now leave parabolic PDE and geometric topology and now discuss Hamiltonian PDE, specifically those of ")#link("http://tosio.math.toronto.edu/wiki/index.php/Schrodinger_equations")[#text("Schrödinger type")]#text(". (Other classes of Hamiltonian PDE, such as ")#link("http://tosio.math.toronto.edu/wiki/index.php/Wave_equations")[#text("wave")]#text(" or ")#link("http://tosio.math.toronto.edu/wiki/index.php/KdV_equations")[#text("Airy")]#text(" type equations, also exhibit similar features, but we will restrict attention to Schrödinger for sake of concreteness.) These equations formally resemble Hamiltonian ODE, which can be viewed as finite-dimensional measure-preserving dynamical systems with a continuous time parameter ")#mi("t \\in {\\Bbb R}")#text(". However, this resemblance is not rigorous because Hamiltonian PDE have infinitely many degrees of freedom rather than finitely many; at a technical level, this means that the dynamics takes place on a highly non-compact space (e.g. the energy surface), whereas much of the theory of finite-dimensional dynamics implicitly relies on at least local compactness of the domain. Nevertheless, in many dispersive settings (e.g. when the spatial domain is Euclidean) it seems that almost all of the infinitely many degrees of freedom are so “pseudorandom” or “radiative” as to have an essentially trivial (or more precisely, linear and free) impact on the dynamics, leaving only a mysterious “core” of essentially finite-dimensional (or more precisely, compact) dynamics which is still very poorly understood at present.")

#text("To illustrate these rather vague assertions, let us first begin with the free linear Schrödinger equation ")#mi("iu_t + \\Delta u = 0")#text(", where ")#mi("u: {\\Bbb R} \\times {\\Bbb R}^n \\to {\\Bbb C}")#text(" has some specified initial data ")#mi("u(0) = u_0: {\\Bbb R}^n \\to {\\Bbb C}")#text(", which for simplicity we shall place in the Schwartz class. It is not hard to show, using Fourier analysis, that a unique smooth solution, well-behaved at spatial infinity, to this equation exists, and furthermore obeys the ")#mi("L^2({\\Bbb R}^n)")#text(" conservation law")

#align(center)[#tao-math("\\int_{{\\Bbb R}^n} \\left|u(t,x)\\right|^2 dx = \\int_{{\\Bbb R}^n} \\left|u_0(x)\\right|^2\\ dx", block: false)#text(", (*)")]

#text("which can be interpreted physically as the law of conservation of probability. By using the fundamental solution for this equation, one can also obtain the pointwise decay estimate")

#align(center)[#tao-math("\\lim_{t \\to \\infty} \\left|u(t,x)\\right| = 0", block: false)#text(" for all ")#mi("x \\in {\\Bbb R}^n")]

#text("and in a similar spirit, we have the local decay estimate")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[

]

#align(center)[#tao-math("\\lim_{t \\to \\infty} \\int_K \\left|u(t,x)\\right|^2 dx = 0", block: false)#text(" for all compact ")#mi("K \\subset {\\Bbb R}^n")#text(" (**)")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[

]

#text("The two properties (*) and (**) may appear contradictory at first, but what they imply is that the solution is ")#emph[#text("dispersing")]#text(" or ")#emph[#text("radiating")]#text(" its (fixed amount of) ")#mi("L^2")#text(" mass into larger and larger regions of space, so that the amount of mass that any given compact set captures will go to zero as time goes to infinity. This type of dispersion – asymptotic orthogonality to any fixed object – should be compared with the notion of strong mixing discussed in the previous lecture. The analogous notion of weak mixing, by the way, is the slightly weaker statement")

#align(center)[#tao-math("\\lim_{T \\to \\infty} \\frac{1}{T} \\int_0^T \\int_K \\left|u(t,x)\\right|^2 dx dt = 0", block: false)#text(" for all compact ")#mi("K \\subset {\\Bbb R}^n")#text(". (***)")]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[

]

#text("[There is also a very useful and interesting quantitative version of this analysis, known as ")#emph[#text("profile decomposition")]#text(", in which a solution (or sequence of solutions) to the free linear Schrödinger equation can be split into a small number of “structured” components which are localised in spacetime and in frequency, plus a “pseudorandom” term which is dispersed in spacetime, and is small in various useful norms. These decompositions have recently begun to play a major role in this subject, but it would be too much of a digression to discuss them here. See however my ")#link("http://arxiv.org/abs/math.AP/0608293")[#text("CDM lecture notes")]#text(" for more discussion.]")

#text("To summarise so far, for the free linear Schrödinger equation all solutions are radiative or “pseudorandom”. Now let us generalise a little bit by throwing in a (time-independent) potential function ")#mi("V: {\\Bbb R}^n \\to {\\Bbb R}")#text(", which for simplicity we shall also place in the Schwartz class, leading to the familiar linear Schrödinger equation ")#mi("i \\partial_t u + \\Delta u = Vu")#text(". This equation still has unique smooth global solutions, decaying at spatial infinity, for Schwartz data ")#mi("u_0")#text(", and still obeys the ")#mi("L^2")#text(" conservation law (*). What about the dispersion properties (**) or (***)? Here there is a potential obstruction to dispersion (or pseudorandomness), namely that of ")#emph[#text("bound states")]#text(". Indeed, if we can find a solution ")#mi("\\psi \\in L^2({\\Bbb R}^n)")#text(" to the time-independent linear Schrödinger equation ")#mi("-\\Delta \\psi + V\\psi = -E \\psi")#text(" for some E > 0, then one easily verifies that the function ")#mi("u(t,x) := e^{-iEt} \\psi(x)")#text(" is a solution to the time-varying linear Schrödinger equation which refuses to disperse in the sense of (**) or (***); indeed, we have the opposite property that the ")#mi("L^2")#text(" density ")#tao-math("\\left|u(t,x)\\right|^2", block: false)#text(" is static in time. One can then use the principle of superposition to create some more non-dispersing solutions by adding several bound states together, or perhaps adding some bound states to some radiating states.")

#text("The famous RAGE theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=246603")[#text("Ruelle")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=363267")[#text("Amrein-Georgescu")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=523013")[#text("Enss")]#text(" asserts, roughly speaking, that there are no further types of states, and that every state decomposes uniquely into a bound state and a radiating state. For instance, if a solution fails to obey the weak dispersion property (***), then it must necessarily have a non-zero correlation (inner product) with a bound state. (If instead it fails to obey the strong dispersion property (**), the situation is trickier, as there is unfortunately a third type of state, a “singular continuous spectrum” state, which one might correlate with.) More generally, an arbitrary solution will decompose uniquely into the sum of a radiating state obeying (***), and a unconditionally convergent linear combination of bound states. The proof of these facts largely rests on the spectral theorem for the underlying Hamiltonian ")#mi("-\\Delta + V")#text("; the bound states correspond to pure point spectrum, the weak dispersion property (***) corresponds to continuous spectrum, and the strong dispersion property (**) corresponds to absolutely continuous spectrum. Thus the RAGE theorem gives a nice connection between dynamics and spectral theory.")

#text("Let us now turn to nonlinear Schrödinger equations. There are a large number of such equations one could study, but let us restrict attention to a particularly intensively studied case, the ")#emph[#text("cubic nonlinear Schrödinger equation")]#text(" (NLS)")

#align(center)[#tao-fit-display[#tao-math("i u_t + \\Delta u = \\mu \\left|u\\right|^2 u", block: true)]]

#text("where ")#mi("\\mu")#text(" is either equal to +1 (the ")#emph[#text("defocusing")]#text(" case) or -1 (the ")#emph[#text("focusing")]#text(" case). (This particular equation arises often in physics as the leading approximation to a Taylor expansion to more complicated dispersive models, such as those for plasmas, mesons, or Bose-Einstein condensates.) We specify initial data ")#mi("u(0,x) = u_0(x)")#text(" as per usual, and to avoid technicalities we place this initial data in the Schwartz class. Unlike the linear case, it is no longer automatic that smooth solutions exist globally in time, although it is not too hard to at least establish local existence of smooth solutions. There are thus several basic questions:")

#enum(start: 1, 
[#text("(Global existence) Under what conditions do smooth solutions u to NLS exist globally in time?")],
[#text("(Asymptotic behaviour, global existence case) If there is global existence, what is the limiting behaviour of u(t) in the limit as t goes to infinity?")],
[#text("(Asymptotic behaviour, blowup case) If global existence fails, what is the limiting behaviour of u(t) in the limit as t approaches the maximal time of existence?")]
)

#text("For reasons of time and space I will focus only on Questions 1 and 2, although question 3 is very interesting (and very difficult). The answer to these questions is rather complicated (and still unsolved in several cases), depending on the sign ")#mi("\\mu")#text(" of the nonlinearity, the ambient dimension n, and the size of the initial data. Here are some sample results regarding Question 1 (most of which can be found for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=2002047")[#text("Cazenave’s book")]#text(", or ")#link("http://www.ams.org/bookstore-getitem/isbn=0-8218-4143-2")[#text("my own")]#text("):")

#list(
[#text("If n = 1, then one has global smooth solutions for arbitrarily large data and any choice of sign.")],
[#text("For n=2,3,4, one has global smooth solutions for arbitrarily large data in the defocusing case (this is ")#link("http://www.arxiv.org/abs/math.AP/0501462")[#text("particularly tricky in the energy-critical case")]#text(" n=4), and for small data in the focusing case. For large data in the focusing case, finite time blowup is possible.")],
[#text("For ")#mi("n \\geq 5")#text(", one has global smooth solutions for small data with either sign. For large data in the focusing case, finite time blowup is possible. For large data in the defocusing case, the existence of global smooth solutions are unknown even for spherically symmetric data, indeed this problem, being supercritical, is of ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("comparable difficulty to the Navier-Stokes global regularity problem")]#text(".")]
)

#text("Incidentally, the relevance of the sign ")#mi("\\mu")#text(" can be seen by considering the conserved Hamiltonian")

#align(center)[#tao-fit-display[#tao-math("H(u_0) = H(u(t)) := \\int_{{\\Bbb R}^n} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\mu \\frac{1}{4} \\left|u(t,x)\\right|^4\\ dx.", block: true)]]

#text("In the defocusing case the Hamiltonian is positive definite and thus coercive; in the focusing case it is indefinite, though in low dimensions and in conjunction with the ")#mi("L^2")#text(" conservation law one can sometimes recover coercivity.")

#text("Let us now assume henceforth that the solution exists globally (and, to make a technical assumption, also assume that the solution stays bounded in the energy space ")#mi("H^1({\\Bbb R}^n)")#text(") and consider Question 2. As in the linear case, we can see two obvious possible asymptotic behaviours for the solution u(t). Firstly there is the dispersive or radiating scenario in which (**) or (***) occurs. (For technical reasons relating to Galilean invariance, we have to allow the compact set K to be translated in time by an arbitrary time-dependent displacement x(t), unless we make the assumption of spherical symmetry; but let us ignore this technicality.) This scenario is known to take place when the initial data is sufficiently small. (Indeed, it is conjectured to take place whenever the data is “strictly smaller” in some sense than that of the smallest non-trivial bound state, aka the ")#emph[#text("ground state")]#text("; there has been some recent progress on this conjecture ")#link("http://arxiv.org/abs/math/0610801")[#text("by Kenig-Merle")]#text(" and ")#link("http://arxiv.org/abs/math/0703235")[#text("by Holmer-Roudenko")]#text(" in the spherically symmetric case.) In dimensions n=1,3,4, this scenario is also known to be true for large data in the defocusing case (the case n=1 by ")#link("http://www.ams.org/mathscinet-getitem?mr=568535")[#text("inverse scattering considerations")]#text(", the case n=3 ")#link("http://www.ams.org/mathscinet-getitem?mr=839728")[#text("by Morawetz inequalities")]#text(", and the case n=4 by the ")#link("http://arxiv.org/abs/math/0501462")[#text("work of Ryckman-Visan")]#text("; the n=2 case is a major open problem.")

#text("The opposite scenario is that of a ")#emph[#text("nonlinear bound state")]#text(" ")#mi("u(t,x) = e^{-iEt} \\psi(x)")#text(", where E > 0 and ")#mi("\\psi")#text(" solves the time-independent NLS ")#tao-math("-\\Delta \\psi + \\mu \\left|\\psi\\right|^2 \\psi = -E \\psi", block: false)#text(". From the Pohozaev identity or the Morawetz inequality one can show that non-trivial bound states only exist in the focusing case ")#mi("\\mu = -1")#text(", and in this case one can construct such states, for instance by using the ")#link("http://www.ams.org/mathscinet-getitem?mr=578738")[#text("work of Berestycki and Lions")]#text(". Solutions constructed using these nonlinear bound states are known as ")#emph[#text("stationary solitons")]#text(" (or stationary solitary waves). By applying the ")#link("http://tosio.math.toronto.edu/wiki/index.php/Galilean")[#text("Galilean invariance")]#text(" of the NLS equation one can also create ")#emph[#text("travelling solitons")]#text(". With some non-trivial effort one can also combine these solitons with radiation (as was done recently in three dimensions ")#link("http://arxiv.org/abs/math/0701785")[#text("by Beceanu")]#text("), and one should also be able to combine distant solitons with each other to form ")#emph[#text("multisoliton solutions")]#text(" (this has been achieved in one dimension by ")#link("http://www.ams.org/mathscinet-getitem?mr=568535")[#text("inverse scattering methods")]#text(", as well as ")#link("http://arxiv.org/abs/math/0112071")[#text("for the gKdV equation")]#text(" which is similar in many ways to NLS.) Presumably one can also form solutions which are a superposition of multisolitons and radiation.")

#text("The ")#emph[#text("soliton resolution conjecture")]#text(" asserts that for “generic” choices of (arbitrarily large) initial data to an NLS with a global solution, the long-time behaviour of the solution should eventually resolve into a finite number of receding solitons (i.e. a multisoliton solution), plus a radiation component which decays in senses such as of (**) or (***). (For short times, all kinds of things could happen, such as soliton collisons, solitons fragmenting into radiation or into smaller solitons, etc., and indeed this sort of thing is observed numerically.) This conjecture (which is for instance discussed in the 2006 ICM proceedings article by Soffer, or in ")#link("http://www.ams.org/mathscinet-getitem?mr=2091393")[#text("some of")]#text(" ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("my own papers")]#text(") is still far out of reach of current technology, except in the special one-dimensional case n=1 when the equation miraculously becomes ")#link("http://en.wikipedia.org/wiki/Exactly_solvable_model")[#text("completely integrable")]#text(", and the solutions can be computed rather explicitly via inverse scattering methods, as was for instance carried out ")#link("http://www.ams.org/mathscinet-getitem?mr=568535")[#text("by Novoksenov")]#text(". In that case the soliton resolution conjecture was indeed verified for generic data (in which the associated Lax operator had no repeated eigenvalues or resonances), however for exceptional data one could have a number of exotic solutions, such as a pair of solitons receding at a logarithmic rate from each other, or of periodic or quasiperiodic “breather solutions” which are not of soliton form.")

#text("Based on this one-dimensional model case, we expect the soliton resolution conjecture to hold in higher dimensions also, assuming sufficient uniform bounds on the global solution to prevent blowup or “weak turbulence” from causing difficulties. However, the fact that a good resolution into solitons is only expected for “generic” data rather than all data makes the conjecture extremely problematic, as almost all of our tools are based on a worst-case analysis and thus cannot obtain results that are only supposed to be true generically. (This is also a difficulty which seems to obstruct the global solvability of Navier-Stokes, as discussed in an earlier post.) Even in the spherically symmetric case, which should be much simpler (in particular, the solitons must now be stationary and centred at the origin), the problem is wide open.")

#text("Nevertheless, there is some recent work which gives a small amount of progress towards the soliton resolution conjecture. For spherically symmetric energy-bounded global solutions (of arbitrary size) to the focusing cubic NLS in three dimensions, it is")#link("http://www.ams.org/mathscinet-getitem?mr=2091393")[#text(" a result of myself")]#text(" that the solution ultimately decouples into a radiating term obeying (**), plus a “weakly bound state” which is asymptotically orthogonal to all radiating states, is uniformly smooth, and exhibits a weak decay at spatial infinity. If one is willing to move to five and higher dimensions and to weaken the strength of the nonlinearity (e.g. to consider quadratic NLS in five dimensions) then a ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("stronger result is available")]#text(" under similar hypotheses, namely that the weakly bound state is now ")#emph[#text("almost periodic")]#text(", ranging inside of a fixed compact subset of energy space, thus providing a “dispersive compact attractor” for this equation. In principle, this brings us back to the realm of dynamical systems, but we have almost no control on what this attractor is (though it contains all the soliton states and respects the symmetries of the equation), and so it is unclear what the next step should be. (There is a similar result in the non-radial case which is more complicated to state: see ")#link("http://arxiv.org/abs/math.AP/0611402")[#text("my paper")]#text(" for more details.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-384")[#strong[#text("Not Even Wrong » Blog Archive » Math and Physics Roundup")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2007")]

#text("[…] For some more mathematics blogging of the highest possible quality, see Terry Tao’s postings on his Simons lectures at MIT, here, here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad1c023b28d8126e69bad719e6213ce96b3e5d70732d8589f0e86c0080440bfa-84ac88cffd9f3d903376bd16fac53ab8df57f1e98258e26fcdc539df32e99f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stevenm")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-439")[#strong[#text("stevenm")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2007")])]

#text("For parabolic PDE like the heat equation, can one construct entropies to describe these dispersions or flows? In your example, you define the ‘Dirichlet energy’ but is there an entropy that can be constructed and associated with the removal of the random components from the structured components that you described? I think in one of Perelman’s papers he discusses an entropy in connection with the Ricci flow, which seems analogous to heat flow. (Although the details of his papers are beyond my understanding.) A good example of an entropy in Lorentzian (spacetime) geometry would be that associated with black holes and black hole mechanics (leading to Hawking radiation etc.) where an entropy is naturally associated with the area of the horizon, which is a purely geometrical entity.")

#text("The algebraic similarity of the heat/diffusion and Schrodinger equation is also quite interesting I think. On a historical note, Schrodinger in 1931 originally considered diffusion processes or Brownian motions, described by the parabolic diffusion/heat equation, as a basis for quantum mechanics. He attempted to formulate Brownian motions in a symmetric form of time reversal, which (supposedly) helped motivate Kolmogorov to pursue some of his own (now classic) work on stochastic processes. But, as you mention, the diffusion/heat equation is not time symmetric whereas quantum theory is, but Schrodinger still felt that quantum theory must be some kind of diffusion or stochastic theory. Feynman’s path integral or sum over paths does also seem to have a very natural interpretation as a sum over mathematical Brownian motions if you make a Wick rotation. I don’t know what the status of this stochastic interpretation and connection with quantum mechanics is these days though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Dear stevenm,")

#text("That is a good question, and I do not know the answer, though given that entropy and the heat equation both show up in thermodynamics, one would expect there to be some sort of connection; presumably it should be known to experts in probability. Certainly the heat flow has many interesting monotonicity properties, especially for non-negative solutions (which are the ones which have a physical Brownian motion interpretation), and I would not be surprised that an entropy-like expression has some nice monotonicity formulae. Perhaps one has to somehow lift the problem to very high dimension (e.g. taking repeated tensor products of the heat flow solution with itself) to see the connection more clearly, as entropy tends to be associated with various asymptotic statistics in the infinite-dimensional limit.")

#text("Perelman did introduce an entropy to study Ricci flow (indeed he interpreted Ricci flow as a gradient flow for this entropy), and Hamilton had earlier introduced another entropy-like quantity ")#mi("-\\int_M R \\log R")#text(" which also enjoyed a monotonicity property under certain conditions.")

#text("It does seem helpful to think of quantum mechanics as a kind of complexified (i.e. Wick rotated) version of classical Brownian motion, in which paths which increase the Hamiltonian are phase rotated rather than damped. There are also some formal similarities between manipulations of bras and kets, and the laws of conditional probability. But as I said before, these analogies seem well suited for understanding the algebraic structure of quantum mechanics, but not its analytic structure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2007")])]

#text("Actually, now that I think about it, I do know one explicit link between entropy and heat flow: one can interpret the Fisher information of a random variable as the rate of change of the Shannon entropy via heat flow (or more precisely, the Ornstein-Uhlenbeck process, which is basically heat flow renormalised by scaling). I believe this is a useful fact in probability theory, particularly in showing that gaussians are extremisers of various probabilistic quantities, but it is sort of outside my area of expertise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-520")[#strong[#text("As coisinhas interessantes de hoje… at It’s Equal but It’s Different")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2007")]

#text("[…] Simons Lecture III: Structure and randomness in PDE; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-29732")[#strong[#text("A global compact attractor for high-dimensional defocusing non-linear Schrödinger equations with potential « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2008")])]

#text("[…] nonlinear Schrödinger equations (NLS). This conjecture (which I also discussed in my third Simons lecture) asserts, roughly speaking, that any reasonable (e.g. bounded energy) solution to such equations […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-38602")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")])]

#text("On “the cubic nonlinear Schrödinger equation (NLS)")

#text("i u_t + \\Delta u = \\mu |u|^2 u")

#text("where \\mu is either equal to +1 (the defocusing case) or -1 (the focusing case).”")

#text("I am a novice in Physics. What is the physics reason behind the term focusing and defocusing depending on these signs?")

#text("I am also curious to know what you mean by")

#text("“weak turbulence.”")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-38604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2009")])]

#text("Dear Student,")

#text("One can rewrite the NLS as ")#mi("iu_t = (-\\Delta + V) u")#text(", where V is the time-dependent potential ")#tao-math("V = \\mu \\left|u\\right|^2", block: false)#text(", thus the non-linearity can be viewed as a potential energy component of the Schrodinger operator. A negative value of ")#mi("\\mu")#text(" corresponds to a negative ")#mi("V")#text(", i.e. a potential well, which in the linear theory of the Schrodinger equation is known to have an attractive effect. Since V is concentrated where the solution is large, this attractive effect should act to focus the solution. Conversely, a positive value of ")#mi("\\mu")#text(" leads to a repulsive potential concentrated at where the solution is large, leading to a defocusing effect.")

#text("Weak turbulence is not a term with a commonly agreed upon rigorous definition, but for me it refers to the tendency of solutions of certain evolution equations to shift their energy from low frequencies to high frequencies over extended periods of time, which in particular should cause higher Sobolev norms (e.g. the ")#mi("H^2")#text(" norm) to grow polynomially in time. In contrast, the turbulent behaviour of equations such as Navier-Stokes results in a more rapid movement of energy from low frequencies to high frequencies, occurring in a bounded amount of time rather than an asymptotic amount, although after that period of turbulence, the dissipative effects tend to kick in and then remove the high-frequency energy from the system. (Establishing this latter fact rigorously is, of course, the $1 million dollar question.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Moser’s entropy compression argument « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-40871")[#strong[#text("Moser’s entropy compression argument « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("[…] in PDE, does have the same algorithm-terminating flavour as the combinatorial arguments; see this earlier blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a344b99b09ee964b69de4cd5af9e21865814aadcec58ef59073781745f5a87-983888f06b327056e1b9cc626f27e5ed99752535356775da3341b6179c5322b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steffen")]], [#link("https://terrytao.wordpress.com/2007/04/08/simons-lecture-iii-structure-and-randomness-in-pde/#comment-44997")[#strong[#text("Steffen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2010")])]

#text("This was too much of a coincidence for me not to comment:")

#text("It’s interesting that both the heat equation and the Poincaré conjecture made it into the news in the same week that I happened to be browsing this lecture!")

#link("http://www.sciencedaily.com/releases/2010/05/100513162755.htm")[#text("http://www.sciencedaily.com/releases/2010/05/100513162755.htm")]#linebreak()#text(" ")#link("http://www.claymath.org/poincare/")[#text("http://www.claymath.org/poincare/")]

#text("Keep up the good work! I really enjoy reading your posts!")
]
