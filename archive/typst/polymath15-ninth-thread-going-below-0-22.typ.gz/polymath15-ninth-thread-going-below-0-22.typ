// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/
// Converted to Typst by tao2typ: "2026-10-14T16:38:21.719671+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, ninth thread: going below 0.22?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, ninth thread: going below 0.22?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 May 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/")[#text("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is the ninth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("We have now tentatively improved the upper bound of the de Bruijn-Newman constant to ")#mi("{\\Lambda \\leq 0.22}")#text(". Among the technical improvements in our approach, we now are able to use Taylor expansions to efficiently compute the approximation ")#mi("{A+B}")#text(" to ")#mi("{H_t(x+iy)}")#text(" for many values of ")#mi("{x,y}")#text(" in a given region, thus speeding up the computations in the barrier considerably. Also, by using the heuristic that ")#mi("{H_t(x+iy)}")#text(" behaves somewhat like the partial Euler product ")#mi("{\\prod_p (1 - \\frac{1}{p^{\\frac{1+y-ix}{2}}})^{-1}}")#text(", we were able to find a good location to place the barrier in which ")#mi("{H_t(x+iy)}")#text(" is larger than average, hence easier to keep away from zero.")

#text("The main remaining bottleneck is that of computing the Euler mollifier bounds that keep ")#mi("{A+B}")#text(" bounded away from zero for larger values of ")#mi("{x}")#text(" beyond the barrier. In going below ")#mi("{0.22}")#text(" we are beginning to need quite complicated mollifiers with somewhat poor tail behavior; we may be reaching the point where none of our bounds will succeed in keeping ")#mi("{A+B}")#text(" bounded away from zero, so we may be close to the natural limits of our methods.")

#text("Participants are also welcome to add any further summaries of the situation in the comments below.")

#heading(level: 1)[#text("Comments (84)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497741")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("Can the more precise approximation ")#mi("A+B-C")#text(" be helpful in reducing the computational complexity?")#linebreak()#text(" Is it possible (since ")#mi("y_0^2/2 = 0.02")#text(" is much smaller than ")#mi("t_0 = 0.2")#text(") that a better strategy is to try reducing ")#mi("t_0")#text(" (e.g. to 0.15) and allow increasing ")#mi("y_0")#text(" (e.g. to 0.3) to keep reasonable computational complexity?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497759")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2018")])]

#text("These are some of the ongoing numerics threads:")

#text("1) Testing the mollifier approximations at N=69098, y=0.2 t=0.2. The triangle bounds are quite negative, so lemma bounds and its approximations are needed. A prime only mollifier with enough Euler factors (for eg. Euler 41 or Euler 61) seems to come close to the performance of a full mollifier, but due to the larger number of primes needed does not give a speed advantage. The lemma bound is currently being approximated by using the lemma on the first N terms and the triangle bound tail sum for the remaining D*(N-1) terms. This mixed approximation is not as effective as a potential fully lemma based approximation, but the latter doesn’t seem easy to derive. The approximation is almost as fast to compute as a non-mollified bound, but did not turn positive.")

#text("Some sample bound estimates (T: Triangle bound, L: Lemma bound):")

#text("N=69098,y=0.2,t=0.2")

#text("T E5 full_moll : -0.1264")#linebreak()#text(" T E5 full_approx : -0.2155 (current approx is minimum here)")#linebreak()#text(" T E5 prime_moll : -0.2350")#linebreak()#text(" T E5 prime_apprx: -0.2509")#linebreak()#text(" T E13 prime_moll: -0.1798")#linebreak()#text(" T E13 prime_apprx: -0.2208 (current approx is minimum here)")#linebreak()#text(" T E41 prime_moll: -0.1489")

#text("L E5 full_moll : 0.0699")#linebreak()#text(" L E5 full_approx : -0.0460 (current approx is minimum here)")#linebreak()#text(" L E5 prime_moll : -0.0217")#linebreak()#text(" L E5 prime_apprx: -0.0651")#linebreak()#text(" L E7 prime_moll : 0.0006")#linebreak()#text(" L E7 prime_apprx: -0.0550 (current approx is minimum here)")#linebreak()#text(" L E61 prime_moll: 0.0436")

#text("2. Checking for potential gains at lower t or y values at N=69098. There are some incremental gains possible by changing t or y slightly, although targeting a dbn bound of close to 0.21 at this height seems difficult.")

#text("N=69098;y=0.20;t=0.19;")#linebreak()#text(" L E5 full_moll : -0.1567")

#text("N=69098;y=0.15;t=0.2;")#linebreak()#text(" L E5 full_moll : -0.0726")

#text("N=69098;y=0.35;t=0.15;")#linebreak()#text(" L E5 full_moll : -0.7369")

#text("3. Rudolph and I are planning to prove some conditional statements: If RH true for x <= X, dbn <= DBN (starting with X near 10^13 and DBN = 0.18)")

#text("4. I was also checking whether (A+B)/B0 can be computed approximately at an arbitrary height. There were two challenges, 1) computing gamma=A0/B0 which was addressable by computing exp(log(A0)-log(B0)), 2) the error associated with truncating the B and A sums to N0 terms (with N0 around 10^5). This seems to work decently as x, y or t increase and (1+y)/2 + (t/4)log(N) > 1, although the behavior is less certain when y and t are near 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497856")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2018")])]

#text("I edited the second last entry in the results wiki page slightly to 6×10^10+83952−1/2 <= x <= 6×10^10+83952+1/2 (it was offset by 0.5 earlier).")

#text("Also, we were able to compute lower bounds using the recursive approach upto N=30 million in about 15 hours, which suggests N could be taken even higher.")

#text("Also, just wanted to check whether the below conservative approach is necessary and correct while calculating the lemma bounds incrementally.")

#text("Keeping n and the mollifier same,")#linebreak()#text(" ")#tao-math("\\left|b_{n}+a_{n}\\right| = \\left|1+\\left|\\gamma\\right|n^y\\right|\\left|f(n,mollifier)\\right|", block: false)#text(" decreases with increasing N, hence is conservative")#linebreak()#text(" ")#tao-math("\\left|b_{n}-a_{n}\\right| = \\left|1-\\left|\\gamma\\right|n^y\\right|\\left|f(n,mollifier)\\right|", block: false)#text(" increases with increasing N, hence may not be conservative")#linebreak()#text(" ")#tao-math("\\frac{1-a1}{1+a1} = \\frac{1-\\left|\\gamma\\right|}{1+\\left|\\gamma\\right|}", block: false)#text(" increases with increasing N, hence may not be conservative")

#text("Since ")#tao-math("\\left|b_{n}+a_{n}\\right| >= \\left|b_{n}-a_{n}\\right|", block: false)#text(",")#linebreak()#text(" replacing ")#mi("\\frac{1-a1}{1+a1}")#text(" by 1 results in")#linebreak()#text(" ")#tao-math("\\max(\\left|b_{n}-a_{n}\\right|, (factor)\\left|b_{n}+a_{n}\\right|) = \\left|b_{n}+a_{n}\\right|", block: false)#text(", making the lower bounds conservative (and can work if the bound still remains positive enough)")

#text("While verifying the bounds for ")#mi("[N_{min},N_{max}]")#text(",")#linebreak()#text(" we could optimally also replace ")#tao-math("\\frac{1-a1}{1+a1} \\textrm{ by } \\frac{1-\\left|\\gamma\\right|_{N_{max}}}{1+\\left|\\gamma\\right|_{N_{max}}} = c", block: false)#linebreak()#text(" We then want ")#tao-math("\\frac {\\left|1- \\left|\\gamma\\right|n^y\\right|}{\\left|1+\\left|\\gamma\\right|n^y\\right|} <= c", block: false)#linebreak()#text(" Using ")#tao-math("\\left|\\gamma\\right| \\approx \\frac {1}{N^y}", block: false)#linebreak()#text(" we then require ")#mi("n >= N{(\\frac{1-c}{1+c})}^{1/y} = N/N_{max} \\textrm{ and } n <= N{(\\frac{1+c}{1-c})}^{1/y} = N*N_{max}")#linebreak()#text(" Hence for example if ")#mi("dN <= N_{min} N_{max}")#text(", we could also use the optimal replacement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497862")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2018")])]

#text("This broadly looks correct to me, but it may be good to have a longer description of what you are doing… for instance are you able to edit the relevant section of the writeup on github? A sketch of the calculations there would be helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497866")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2018")])]

#text("It seems the section to be edited is the placeholder kept for the claims (ii) and (iii) proof in zerofree.tex. I will start working on it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498035")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("I edited section 8 of the writeup (pg 35 and 36 of the pdf) to include the recursive lower bounds. Some things I realized while rederiving the formulas is that")#linebreak()#text(" 1) if (1-a1)/(1+a1) is replaced with 1, the lemmabound turns into a triangle inequality bound, so this factor has to be kept less than 1,")

#text("2) Also, since there are extra d^y in mollified alpha_n, |bn-an|/|bn+an| is more complex than earlier, so computational verification may be needed to ensure it remains below (1-|gamma_Nmax|)/(1+|gamma_Nmax|)")

#text("3) While moving from N to N+1, the terms n = dN+[1,d] also undergo a change, not only DN+[1,D], so that should be accounted for.")

#text("Some content is still left to be filled, and the formatting could be improved, but I just wanted to confirm on these changes before going forward.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2018")])]

#text("Thanks for this! I will go through this writeup soon (am distracted by some other work at present), but looks good so far.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498318")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2018")])]

#text("I was checking if there is one formula (even if somewhat messy) for the main numerator in the lemma bound which can be turned into a repeatedly callable function, to handle all scenarios automatically and streamline the calculations in this approach. Will something like this work,")

#text("With,")#linebreak()#text(" ")#tao-math("M_{1} = \\frac {1-\\left|\\gamma_{N_{max}}\\right|}{1+\\left|\\gamma_{N_{max}}\\right|} \\left|\\beta_{n} + \\alpha_{n}\\right|,", block: false)#linebreak()#text(" ")#tao-math("M_{2} = \\left|\\beta_{n} - \\alpha_{n}\\right|,", block: false)#linebreak()#text(" ")#tao-math("M_{3} = \\left|\\beta_{n} - \\left|\\frac{\\gamma_{N_{max}}}{\\gamma_{N}}\\right| \\alpha_{n}\\right|", block: false)

#mi("numerator_{n} =")#linebreak()#text(" ")#mi("1_{\\beta_{n}\\alpha_{n} < 0} M_{2}")#linebreak()#text(" ")#tao-math("+ 1_{\\beta_{n}\\alpha_{n} >=0,\\left|\\alpha_{n}\\right|<\\left|\\beta_{n}\\right|}\\max (M_{1},M_{3})", block: false)#linebreak()#text(" ")#tao-math("+ 1_{\\beta_{n}\\alpha_{n} >=0,\\left|\\alpha_{n}\\right|>=\\left|\\beta_{n}\\right|,M_{1}>=M_{2}} \\max (M_{1},M_{2})", block: false)#linebreak()#text(" ")#tao-math("+ 1_{\\beta_{n}\\alpha_{n} >=0,\\left|\\alpha_{n}\\right|>=\\left|\\beta_{n}\\right|,M_{2}>M_{1}} \\max (M_{2},\\left|\\beta_{n}\\right|)", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2018")])]

#text("I’m starting to read through your notes. I am wondering how you get the lower bound on ")#tao-math("\\left|f_{N+1}\\right|", block: false)#text(" in terms of ")#tao-math("\\left|f_N\\right|", block: false)#text(", because the quantities ")#tao-math("\\left|\\alpha_{n,N}\\right|, \\left|\\beta_{n,N}\\right|", block: false)#text(" (and also the denominator ")#mi("\\frac{1}{n^{\\sigma_N}}")#text(" vary with ")#mi("N")#text(". In principle these quantities should be generally decreasing in N, but we can’t say for certain because of the oscillations in the weights ")#mi("\\lambda_d")#text(".")

#text("(Also, strictly speaking all the lower bounds for ")#mi("f_N")#text(" or ")#mi("f_{N+1}")#text(" need to be multiplied by a factor of ")#tao-math("1 / \\left|\\mathrm{moll}\\right|", block: false)#text(", which is not relevant insofar as keeping ")#mi("f_N")#text(" away from zero, but which may have some impact on how one can absorb error terms.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498433")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2018")])]

#text("On the |moll| part, I was wrongly assuming that it will be less than 1, but since it has ")#tao-math("\\left|\\lambda_{d}\\right|", block: false)#text(" terms instead of ")#mi("\\lambda_{d}")#text(", it is greater than 1 and should be divided. I will make that change.")

#text("The way I was thinking about the main terms was that if we calculated the exact lemmabound (eqn 78) for both N and N+1,")#linebreak()#text(" ")#tao-math("\\beta_{n,N} = \\beta_{n,N+1} \\textrm{ and } \\frac{\\alpha_{n,N}}{\\left|\\gamma_{N}\\right|} = \\frac{\\alpha_{n,N+1}}{\\left|\\gamma_{N+1}\\right|}", block: false)#linebreak()#text(" except potentially when n is in [dN+1,dN+d] for all valid d,")#linebreak()#text(" since the dependence on N of the ")#tao-math("\\beta \\textrm{ and } \\frac{\\alpha}{\\left|\\gamma\\right|}", block: false)#text(" terms comes only through the ")#mi("1_{n<=dN}")#text(" factors.")#linebreak()#text(" Also, since ")#mi("\\sigma_{N+1} > \\sigma_{N}, n^{\\sigma_{N+1}} > n^{\\sigma_{N}}")

#text("To account for n in [dN+1,dN+d], we could either subtract from the bound the difference ")#mi("summand_{n,N+1} - summand_{n,N}")#text(" or subtract a larger quantity ")#mi("summand_{n,N+1}")#text(" to keep the calculations simpler.")

#text("Hence, if we choose the right numerators for each n (one of three or four choices), ")#mi("summand_{n,N}")#text(" decreases for a given n and N varying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498545")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("Ah, I see what you are doing now. This seems to work, in theory at least – how does it perform at the current range of parameters (")#mi("t=0.2, y=0.2. N \\geq 69098")#text(", Euler7 mollifier)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498569")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("With t=0.2,y=0.2,N=69098,Euler 7, we get 0.0199 (now dividing by |moll|) which is a bit low if we want to remain above a threshold (eg. 0.02).")

#text("This is although not a bottleneck since Rudolph had recently written an optimized script, that computes the exact lemmabound for each N much faster than earlier and helps resolve the bottleneck till about N=200k or so. Using it to cover N till 1.5 million or when dealing with much higher N would still take significant time.")

#text("If we use that script to handle N=69098 to 80000 and then use this approach, we get")#linebreak()#text(" 80000,0.2,0.2,euler5 -> 0.0345")#linebreak()#text(" 80000,0.2,0.2,euler7 -> 0.0615")#linebreak()#text(" which provides a more comfortable buffer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2018")])]

#text("Hmm, sounds like it’s going to be tough to push beyond ")#mi("t=0.2, y=0.2")#text(" then. Given how complicated the argument has become, maybe it is a good time to “declare victory” on the Polymath project and focus on finalising all the various steps required to fully verify that ")#mi("\\Lambda \\leq 0.22")#text("? It sounds like if we step down from Euler 7 to Euler 5, then Euler 3, then Euler 2, we would have a good chance of covering up to say ")#mi("N = 1.5 \\times 10^6")#text(" in a computationally feasible amount of time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498794")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2018")])]

#text("The file with exact lemmabounds (euler 5 mollifier) for N in [69098,80000] is kept ")#link("https://drive.google.com/open?id=1RWb_7UWMJUwlMJGumdAXih963wwrwcSd")[#text("here")]#text(", and the one with incremental lemmabounds (euler 5 mollifier) between [80000,1.5 mil] is ")#link("https://drive.google.com/open?id=1p_E9JmBBXZutDkYxUKNhokB7TIa4Stly")[#text("here")]#text(" (bounds shown for N=100K). The first one ran in about 6 hours, while the latter took about an hour. Also sharing a ")#link("https://drive.google.com/open?id=1UDmtWTKcINf4P12sgmnCvpmh6yNmz8ht")[#text("plot")]#text(" of how the latter file looks like visually.")

#text("I have also edited section 8 of the writeup accordingly.")

#text("Also, Rudolph and I found that it is possible to push X to something like 10^13 (or maybe higher) using the multiple evaluation algorithm for the barrier strip and the recursive approach for the lower bounds (both would take about a day each at this height). But with RH not verified at this height, the results will be conditional and could be treated as follow-on work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498798")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2018")])]

#text("Also sharing the results of a parallel exercise,")

#link("https://drive.google.com/open?id=1VbEVstgMVCmYrlFMxK573idk8ajRBZOM")[#text("Exact lemmabounds for N=80k to 150k, y=0.2, t=0.2 with Euler 3 mollifier")]

#link("https://drive.google.com/open?id=1aCj4zSE_IQyfyrNnX20ET6ubO9R8Oqcw")[#text("Exact lemmabounds for N=150k to 250k, y=0.2, t=0.2 with Euler 2 mollifier")]

#text("These took around a day each. The second one is currently on hold.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497903")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("In the writeup, third line from the end of page 41, the variation of the argument of ")#mi("H_t")#text(" on the imaginary axis is actually zero (not merely ")#mi("O(1)")#text(") since ")#mi("H_t")#text(" is positive on the imaginary axis (as clearly seen from its defining integral).")#linebreak()#text(" Also in this line, it seems that (in the first portion of the rectangle upper edge) it should be ")#mi("0 \\leq x \\leq C")#text(" (instead of ")#mi("0 \\leq y \\leq C")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-497930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2018")])]

#text("In the results wiki page (zero-free regions), the last two lines should be dated “May 1, 2018” instead of 2017 :) As of today, can we claim “Completes proof of \\Lambda = 0.22” for the last entry should be or are we still stuck with “This should establish \\Lambda = 0.22”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-498470")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("Dear Terence Tao! I take KM signal and count(consider) necessity to express my opinion. Analyse estimates TE41 and LE61,confidently can to say, what this two-sided stair-well(flight), lower part at which wreck condition! For passage at side”+” it is necessary rig up lengthwise girder(s) of Ricci flow. Thanks! Sergei.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2018")])]

#text("Going back and forth from this “denglish” to Russian and back to English with Google translate this is Sergei’s comment in a “normal” language (I don’t understand more anyway):")

#text("Dear Terence Tao! I accept the KM signal and consider (I believe) the need to express my opinion. Analyzing the estimates of TE41 and LE61, we can confidently say that this is a two-way ladder-flight (flight), the lower part, in which there is an emergency condition! To pass from the “+” side, it is necessary to install a longitudinal beam (s) of the Ricci flow. Thanks! Sergei.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499024")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2018")])]

#text("In the write-up paper, there is a typo in Theorem 3.3, point (iii):")#linebreak()#text(" $X\\leq x \\geq X$ should be $X \\leq x \\leq X$.")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2018")])]

#text("Dear Terry,")#linebreak()#text(" If you now return to Twin prime conjecture with the strongest solution to attack over H=246,I think every one is surely amusing.Many night I think Twin prime actually ties the best minds in the world.Twin prime makes every one lots of time.I very annoy this.Terry you quick up!Not it make you very old.If I am an expert mathematician,I break it")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499156")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2018")])]

#text("In the eighth thread there was a discussion (")#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496959")[#text("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496959")]#text(") whether expanding ")#mi("\\exp( (t/4) \\log^2(1+h/n_0))")#text(" in the multi evaluation algorithm for the barrier was beneficial.")

#text("At the time, I had not expanded this term, and calculated the stored sums for each t step separately, since the computation time at x near 6*10^10 was reasonable. However, the stored sum calculation becomes a relative bottleneck at x near 10^13 or higher.")

#text("By incurring a larger overhead at the start where stored sums are calculated for each term in the Taylor expansion of ")#mi("\\exp( (t/4) \\log^2(1+h/n_0))")#text(" (upto a large number of terms like 40 or 50 to maintain the same accuracy as earlier), we do see a significant benefit. Testing near x=6*10^10,y=0.2,t=0.2 resulted in an 8x reduction in time (from 2 hours to about 15 minutes).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2018")])]

#text("Is it possible to reduce the number of terms (while maintaining the required accuracy) by replacing the Taylor series with a suitable truncated series of its Chebyshev polynomial expansion (for a better uniform approximation over appropriate intervals with fewer terms.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499171")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2018")])]

#text("Looks like the barrier part of the argument is now quite tractable!")

#text("I will be rather busy with other things in the next week or two, but plan to return to the writeup and try to clean up Section 8 in particular to try to write down all the different parts of the argument before we forget everything. For instance in the barrier computations we still have to show that the 50-term Taylor expansion actually is as accurate as it looks; I’ll have to think about how best to actually show that rigorously (certainly I don’t want to apply the Leibniz rule 50 times and estimate all the resulting terms!). I am thinking perhaps of using the generalised Cauchy integral formula instead to get a reasonably good estimate (we do have tens of orders of magnitude to spare, so hopefully there should be a relatively painless way to proceed).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501072")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2018")])]

#text("While running the barrier scripts for large X (which were being optimized over the past few weeks), we hit on the above question on how to determine the number of taylorterms to use to ensure a certain approximation accuracy. Just wanted to check if the below argument can work.")

#mi("\\textrm{Firstly recapping the formula being used. With }, H=N, n_{0}=H/2")#linebreak()#text(" ")#mi("\\frac{A+B}{B0}  \\textrm{ approx can be written as a polynomial in w and t.}")#linebreak()#text(" ")#mi("\\frac{B}{B0} \\approx n_{0}^{w-(t/4) \\log (n_{0})} \\sum\\limits_{i=1}^{T_{1}} \\sum\\limits_{j=1}^{T_{2}} b_{i,j} w^i t^j")#linebreak()#text(" ")#mi("\\textrm{where } w = \\pm z \\pm i\\theta - (t/2)(\\alpha(s) - log(n_{0}),")#linebreak()#text(" ")#mi("T_{1} \\textrm{ and } T_{2} \\textrm{ are number of taylor terms in the main expansion and t expansion},")#linebreak()#text(" ")#mi("\\textrm{Through the stored sums, } b_{i,j} = \\sum\\limits_{h=1}^{H} h^{-1-y_{0}+iX} \\frac{\\log^{i}(h/n0)}{i!} \\frac{\\log^{2j}(h/n_{0}))}{4^j j!}")#linebreak()#text(" ")#mi("\\textrm{of which the h=1 summand contributes the largest in magnitude due to the } -\\log(n_{0}) \\textrm{ factor}")#linebreak()#text(" ")#mi("\\textrm{Similarly for the non } \\gamma \\textrm{ part of } \\frac{A}{B0}")

#mi("\\textrm{With X and } y_{0} \\textrm{ both at the center of the barrier}")#linebreak()#text(" ")#tao-math("\\left|w\\right| < \\left|(0.25+(t/2)\\log 2) + i(0.25+(t/2)(\\pi/4))\\right| < 0.5 \\textrm{ for } t <= 0.2,", block: false)#linebreak()#text(" ")#mi("\\Re (w-(t/4) \\log (n_{0})) <= 0.25 \\textrm{ (max at t=0)}")#linebreak()#text(" ")#mi("\\textrm{ With } x_{1}=\\log(n_{0}), \\frac{x_{1}^{i}}{i!} \\textrm{ starts decreasing beyond } i = \\left \\lfloor{x_{1}}\\right \\rfloor")#linebreak()#text(" ")#mi("\\textrm{ and } x_{2}=\\frac{x_{1}^{2}}{4}, \\frac{x_{2}^{j}}{j!} \\textrm{ starts decreasing beyond } j = \\left \\lfloor{x_{2}}\\right \\rfloor")#linebreak()#text(" ")#mi("\\textrm{Replacing } h^{-1-y_{0}+iX} \\textrm{ by 1}")#linebreak()#text(" ")#mi("\\textrm{For d digit accuracy },")#linebreak()#text(" ")#tao-math("\\textrm{if } n_{0}^{0.25}*N*\\max(\\max(\\frac{(x_{1}\\left|w\\right|)^{T_{1}}}{T_{1}!}\\frac{(x_{2}t)^{j}}{j!}),\\max(\\frac{(x_{1}\\left|w\\right|)^{i}}{i!}\\frac{(x_{2}t)^{T_{2}}}{T_{2}!})) < 10^{-d}", block: false)#linebreak()#text(" ")#mi("\\textrm{for some } T_{1} > \\left\\lfloor{x_{1}}\\right\\rfloor \\textrm{ and } T_{2} > \\left\\lfloor{x_{2}}\\right\\rfloor")#linebreak()#text(" ")#mi("\\textrm{Then } T_{1} \\textrm{ and } T_{2} \\textrm{ should work}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501073")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2018")])]

#text("Sorry, a correction in ")#mi("h^{-1-y_{0}+iX}")#text(", which should be ")#mi("h^{(-1-y_{0}+iX)/2}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2018")])]

#text("I’ll take a look at this later today. It looks like you are trying to use some sort of Taylor’s theorem with remainder in two variables, which should be available.")

#text("I’m actually giving a talk on the de Bruijn-Newman constant in a few hours here in Bristol ( ")#link("https://heilbronn.ac.uk/2017/08/08/perspectives-on-the-riemann-hypothesis/")[#text("https://heilbronn.ac.uk/2017/08/08/perspectives-on-the-riemann-hypothesis/")]#text(" ). I’ll mention our tentative bound ")#mi("\\Lambda \\leq 0.22")#text(" and some of the methods used to achieve them.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("Wow. It will be cool to have video recordings of the lectures.")

#emph[#text("[The lectures were filmed and will presumably be made online at some point – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501309")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("Also, I wanted to check about a possibly optimistic approach. Right now the number of summands for the B and A sums in (A+B)/B0 is kept equal at N approx = sqrt(x/4Pi).")#linebreak()#text(" Since the |gamma| factor diminishes the A sum as x goes higher, is it possible to shift more of the summands to the A sum so that N_A > N_B, and could this help in reducing the bound further..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("In principle one could vary the two summation ranges ")#mi("N_A, N_B")#text(" (basically removing some of the terms from one sum and inserting a Poisson summation-transformed version of that sum in the other), but I think the gamma factor ")#mi("\\gamma")#text(" will remain unchanged; in the writeup we bound this quantity by some power of ")#mi("N")#text(", but really we are bounding it by a power of ")#mi("\\sqrt{x/4\\pi}")#text(" and using ")#mi("N")#text(" for convenience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501340")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("Within the barrier multiple evaluation approach, is it possible to use the ‘extra’ work done on a rectangle contour, to have a larger t step size, hence reducing the overall number of rectangles processed?")

#text("While processing a rectangle, since minmesh = min_|(A+B)/B0|_(meshpoints) is not known in advance, the mesh gap is taken to be a safe value, g/ddxbound (eg. g=1), instead of minmesh/ddxbound. Once the rectangle is processed and minmesh as expected comes out to be larger than g, the lower bound of |(A+B)/B0| between mesh points seems to be (2*minmesh – g)/2. However, currently in the scripts we assume the lower bound to be minmesh/2 and increment t as t_next = t_curr + (minmesh/2)/ddtbound, instead of the larger allowed one.")

#text("Near t=0, minmesh is often high, something like 3.x or 4.x (since the barrier strip was chosen accordingly). Due to the ddtbound being also high near t=0, changing the t_next formula results in a nice speedup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501343")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("Yes, this should work, one just has to use the d/dy bound instead of the d/dx bound for the vertical sides of the rectangle (and make sure that the mesh includes all the corners of the rectangle).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501387")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("Just checked the scripts. We have been including the rectangle corners by always starting a side’s mesh from a corner point. Also in lemma 8.2 of the writeup, ddxbound and ddybound are equal, hence no change in the calculations (although will change the name to ddzbound to refer to both).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2018")])]

#text("Ah, right, I had forgotten about the Cauchy-Riemann equations! So there isn’t much additional complication caused by turning a corner in the rectangle mesh.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504101")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2018")])]

#text("Is by any chance a Video of that talk already available? That would be interesting. Thanks! If no, would it be fine to ask the organizers?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("OK, I think I see what you are trying to do here now. One may possibly have to sum over i,j rather than take max over i,j, but other than that, this bound looks more or less correct. I think it’s not essential at this time to have a completely rigorous error bound, as long as it is in the right ballpark; if you can arrange the parameters so that this putative bound is a couple orders of magnitude better than what is needed, then we can probably go back later and write down an analytic bound for the error term that will suffice (possibly sacrificing some of these orders of magnitude in order to shorten the proof of the bound).")

#text("I’ll write some general notes on the wiki soon (after I recover from this very interesting, but exhausting, conference!) on how to estimate multiple sums of the form ")#mi("\\sum_{n=1}^N \\frac{1}{n^{c_j + d_j \\log n}}")#text(" for various pairs ")#mi("c_j,d_j")#text(", which is basically the general form of the problem being considered here. One minor thing is that the precomputed sums ")#mi("b_{i,j}")#text(" can be re-used for both the A/B_0 and B/B_0 expressions.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501374")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("I wrote up some explicit error estimates for Taylor expanding these sorts of sums at the end of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")[#text("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501526")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2018")])]

#text("The wiki approach of using the same precomputed sums for both A/B0 and B/B0 by shifting y outside the precomputations worked. At large X, since the precomputations take majority of the time, it allows a decent time reduction overall.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-499815")[#strong[#text("El proyecto Polymath15 logra reducir la cota superior de la constante de Bruijn-Newman | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2018")]

#text("[…] La cota numérica Λ ≤ 0.48 se confirmó de forma analítica en el sexto hilo [Tao, 18 Mar 2018]. El avance parece parco, pero los proyectos Polymath necesitan un arranque suave para que todos los participantes vayan conociendo las herramientas que se van a usar y vayan aportando ideas relevantes. Todo parecía indicar que se podía ir más allá con el método numérico [Tao, 28 Mar 2018], hasta alcanzar una cota de Λ ≤ 0.28 [Tao, 17 Apr 2018]. El método de la barrera desarrollado para el ataque analítico prometía pequeñas mejoras adicionales, que llegaron hasta Λ ≤ 0.22 [Tao, 04 May 2018]. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501583")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2018")])]

#text("It seems that with a given computational complexity bound ")#mi("N")#text(", it is possible to get ")#mi("\\Lambda \\leq C/ \\log N")#text(" for some absolute constant ")#mi("C")#text(". Is it possible that there is a similar bound ")#mi("N > \\exp(c/ \\Lambda)")#text(" for another absolute constant ")#mi("c")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2018")])]

#text("Well, lower bounds on complexity are notoriously hard to establish, even heuristically, unless the problem is so “universal” that it encodes some standard complexity class (e.g. if the problem is NP-hard, Turing-complete, etc.). Given that one is only working with the zeta function here, it is unlikely that there is any universality (though one could, in principle, imagine that if one were to consider a much more general problem involving more general PDEs applied to more general functions, one could eventually obtain some sort of universality. In addition, if RH is ever proven, then the time complexity of evaluating ")#mi("\\Lambda")#text(" drops to ")#mi("O(1)")#text(". :-)")

#text("Nevertheless, one can informally get a sense of what ")#mi("\\Lambda")#text(" capturing as follows. If a zero is of the form ")#mi("x+iy")#text(" for some ")#mi("0 < y < 1")#text(", ")#mi("x \\gg 1")#text(", then one should heuristically expect it to be attracted towards the real axis by heat flow at speed about ")#mi("\\log x")#text(", because there should be about ")#mi("y \\log x")#text(" zeroes on the real axis at distance ")#mi("\\sim y")#text(" from this zero. As such, it should hit the real axis in time ")#mi("y/\\log x")#text(". As such, ")#mi("\\Lambda")#text(" is roughly speaking the best constant such that the zeroes ")#mi("H_0(x+iy)=0")#text(" lie in the region ")#mi("\\frac{y}{\\log x} \\ll \\Lambda")#text(". This is already known in the regime ")#mi("x \\geq \\exp( C/\\Lambda)")#text(", so establishing an upper bound ")#mi("\\Lambda \\leq \\Lambda_0")#text(" is morally equivalent to establishing a certain zero-free region of diameter about ")#mi("\\exp( C/\\Lambda_0 )")#text(". In the absence of any major breakthrough on RH (or on numerical verifications thereof), it thus seems that the time complexity of doing this will also be of the form ")#mi("\\exp( C^{\\prime}/\\Lambda_0 )")#text("; one could hope to optimise the constant ")#mi("C^{\\prime}")#text(" but I think it is unlikely that we can remove the exponential with current technology.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2018")])]

#text("Prime quadruplet Law of quantity growth")

#text("Natural number /// Prime quadruplet Number /// Ratio of the number to")#linebreak()#text(" the former")

#text("671088649 /// 20557 /// 1.71222722")#linebreak()#text(" 1342177289 /// 35848 /// 1.743834217")#linebreak()#text(" 2684354569 /// 62387 /// 1.740320241")#linebreak()#text(" 5368709129 /// 109113 /// 1.748970138")#linebreak()#text(" 10737418249 /// 191356 /// 1.753741534")#linebreak()#text(" 21474836489 /// 338325 /// 1.768039675")#linebreak()#text(" 42949672969 /// 599598 /// 1.772254489")#linebreak()#text(" 85899345929 /// 1065802 /// 1.77752761")

#text("prime Law of quantity growth")

#text("Natural number /// Prime number /// Ratio of the number to the former")#linebreak()#text(" 671088649 /// 34832025 /// 1.927837377")#linebreak()#text(" 1342177289 /// 67237143 /// 1.930325412")#linebreak()#text(" 2684354569 /// 129949340 /// 1.932701691")#linebreak()#text(" 5368709129 /// 251437996 /// 1.934892443")#linebreak()#text(" 10737418249 /// 487025115 /// 1.936959102")#linebreak()#text(" 21474836489 /// 944293561 /// 1.938901161")#linebreak()#text(" 42949672969 /// 1832604295 /// 1.940714594")#linebreak()#text(" 85899345929 /// 3559707892 /// 1.942431272")

#text("Conclusion:")#linebreak()#text(" With the increase of natural number 1 times, the number of primes has")

#text("increased by nearly 1 times, and the number of primes of four births")

#text("has increased by nearly 1 tim")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2018")])]

#text("It seems that it is possible, with bounded complexity, to approach ")#mi("\\Lambda")#text(" arbitrarily close, not only from above (as we now know) but also from below !")#linebreak()#text(" To see that, we may assume (since ")#mi("\\Lambda \\geq 0")#text(") that ")#mi("\\Lambda > 0")#text(" (i.e. RH is false!), so one may locate (with bounded complexity) a non-real zero of ")#mi("H_0")#text(" with “arriving time to the real axis” arbitrarily close to ")#mi("\\Lambda")#text(", and then follow numerically (with sufficient precision) its “trajectory”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501588")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2018")])]

#text("If RH is true hence $ latex\\Lambda=0 $ this would entail $ latex N>\\infty$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2018")])]

#text("How to explain this kind of imagination:")#linebreak()#text(" The number of primes, the number of twin primes, and the number of four cytoplets in the two intervals are basically equal in the two intervals of the same length in a sufficient number. For example, the number of about 10 billion within the range of 100 million prime number four births, the twin prime prime is basically the same:")#linebreak()#text(" For example, four births in the 99-100 prime billion between 1458 and 1512 in 100-100, billion between.")#linebreak()#text(" There are extreme examples:")#linebreak()#text(" 6500000000-6600000000 1600 four twin primes;")#linebreak()#text(" 6600000000-6700000000 1600 four twin primes;")

#text("22600000000-22700000000 1305 four twin primes;")#linebreak()#text(" 22700000000-22800000000 1305 four twin primes;")

#text("24700000000-24800000000 1271 four twin primes;")#linebreak()#text(" 24800000000-24900000000 1271 four twin primes;")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501879")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2018")])]

#text("I noticed ")#link("https://viterbischool.usc.edu/news/2018/06/mathematician-m-d-solves-one-of-the-greatest-open-problems-in-the-history-of-mathematics/")[#text("https://viterbischool.usc.edu/news/2018/06/mathematician-m-d-solves-one-of-the-greatest-open-problems-in-the-history-of-mathematics/")]#text(" today and thought I should mention here that the Lindelöf hypothesis is claimed to be proved. ")#link("https://arxiv.org/abs/1708.06607")[#text("https://arxiv.org/abs/1708.06607")]#text(" I suspect that a proof of the Lindelöf hypothesis may improve bound proofs related to the De Bruijn-Newman constant as they are both related to the Riemann Zeta function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501896")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2018")])]

#text("The press release notwithstanding, given the very long history of announced proofs of LH or RH that later turned out to be incorrect, I would wait until some professional confirmation occurs (e.g. publication in a reputable journal) before getting too excited. As for this particular manuscript, I notice two things:")

#text("1. The paper you linked to only claims an “approach” to LH, with details to follow in a “companion paper” which is apparently not yet available.")

#text("2. Several of the estimates in the linked paper look suspiciously weak in that the available bounds on error terms are significantly larger than the main terms, see e.g. Theorem 4.1 where sums such as ")#mi("\\sum_{m_1,m_2} \\frac{1}{m_2^{\\overline{s}} m_1^s} (1+o(1))")#text(" appear; the main term ")#mi("\\sum_{m_1,m_2} \\frac{1}{m_2^{\\overline{s}} m_1^s}")#text(" exhibits cancellation but the error term ")#mi("\\sum_{m_1,m_2} \\frac{1}{m_2^{\\overline{s}} m_1^s} o(1)")#text(" need not if the unspecified ")#mi("o(1)")#text(" error has a phase that largely cancels out the phase of ")#mi("\\frac{1}{m_2^{\\overline{s}} m_1^s}")#text(". As such, the main term is swamped by the worst-case bounds on the error term, which are ")#mi("o( \\sum_{m_1,m_2} \\frac{1}{m_2^{\\mathrm{Re} s} m_1^{\\mathrm{Re} s}} )")#text(" if the ")#mi("o(1)")#text(" decay rates are uniform in ")#mi("n")#text(".")#linebreak()#text(" Asymptotic notation such as ")#mi("O()")#text(" and ")#mi("o()")#text(" is a very powerful and convenient tool, but one can make a lot of mistakes if one is not careful. (For instance, it is not true that ")#mi("\\sum_n (a_n \\times o(1)) = (\\sum_n a_n) \\times o(1)")#text(" in general, if the sum ")#mi("\\sum_n a_n")#text(" exhibits cancellation and the ")#mi("o(1)")#text(" terms in the summands vary with ")#mi("n")#text("; this is most visible in the case that the sum ")#mi("\\sum_n a_n")#text(" cancels completely to zero. The best that one can say in general is that ")#tao-math("\\sum_n (a_n \\times o(1)) = o( \\sum_n \\left|a_n\\right| )", block: false)#text(", and even then one needs a little bit of uniformity of the ")#mi("o(1)")#text(" errors in ")#mi("n")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501898")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2018")])]

#text("I am returning (after some hiatus) to trying to finalise the proof of ")#mi("\\Lambda \\leq 0.22")#text(". Here we are erecting a barrier with parameters ")#mi("X = 6 \\times 10^{10} + 83952 -0.5")#text(", ")#mi("t_0 = 0.2")#text(", ")#mi("y_0 = 0.2")#text(", and we need to check the inequality ")#tao-math("\\left|f_t(x+iy)\\right| > e_A + e_B + e_{C,0}", block: false)#text(" both at the barrier and in the asymptotic region ")#mi("t = t_0, y \\geq y_0, x \\geq X+1")#text(".")

#text("In the latest version of the writeup (which should hopefully propagate to the main git repository soon), I computed an upper bound on ")#mi("e_A + e_B + e_{C,0}")#text(", which is ")#mi("1.251 \\times 10^{-3}")#text(" in the barrier region and not much larger than that in the asymptotic region. Hopefully this is well within the margin of error for the barrier computations.")

#text("Next, I will try to finish off the case of very large x in which one should be able to proceed without any Euler mollifiers. I presume for the remaining portion of the asymptotic region we would divide into subregions where one uses Euler 3, Euler 5, Euler 7, and maybe also Euler11 mollification, and possibly also the lemma that gives a little improvement exploiting the fact that the coefficients are real, though I’ve lost track a bit on what the current status of these numerics are.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501965")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2018")])]

#text("The barrier and euler bounds calculations are now being primarily computed using very optimized arb scripts recently built by Rudolph.")#linebreak()#text(" For X near 6*10^10, the barrier part completes in just around a minute, and the timings increase by around 3 times for every order of magnitude change in X. So far we have reached X near 10^18 and the winding numbers have turned out to be zero. For each such run, we first select an optimized region (eg. X=10^18+44592) such that min_mesh|(A+B)/B0| starts between 4 and 5 at t=0 and ends near 1.5 at t=tmax, hence the lower bound of |(A+B)/B0| is staying well above the error bounds.")

#text("For the euler bounds, we have been using the incremental lemmabound computations, as in section 8 of the writeup. For N in [80000,1.5mil] with euler5 mollifier, the computations again complete in around 3 minutes (the remaining part from N=[69098,80000] was verified using the exact formula (eqn.80)). We have also been able to run this for t=0.13,y=0.2 from N=[28209479,700mil], euler5 mollifier thus conditionally verifying dbn <<=0.15 (also similarly dbn<=0.13 is currently being attempted).")

#text("The storedsums for various barrier regions is bing stored ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/storedsums/singlemat")[#text("here")]#text(", the winding number summaries for these regions ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/windingnumbers")[#text("here")]#text(", and the eulerbounds output ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/output/eulerbounds")[#text("here")]#text(".")

#text("While running the eulerbounds for large ranges like N=[28209479,700mil], we also wanted to check whether a analytical triangle bound for large x using mollifiers is possible, as it may significantly reduce the upper end of the verification range, and may help us reach dbn<=0.1 conditionally. For eg. in an approach similar to the Estimating a sum wiki, calculating the mollified triangle bound up to small N0, and bounding the tail sum as")

#tao-math("\\displaystyle \\sum\\limits_{d=1}^{D}\\frac{\\left|\\lambda_{d}\\right| b^{t}_{d}}{d N_{0}^{(t/2)\\log d}}", block: false)#linebreak()#text(" ")#mi("\\displaystyle \\max(N_{0}^{1 - \\sigma -(t/4) \\log (N^{2}/N_{0})}, (dN)^{1 - \\sigma -(t/4) \\log (N^{2}/dN)}) \\log (dN/N_{0})")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501967")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2018")])]

#text("Actually, in the last line could also the term ")#mi("N_{0}^{(t/2)\\log d}")#text(" be removed, and ")#mi("\\sigma")#text(" changed from ")#mi("\\frac{1+y}{2}")#text(" to ")#mi("\\frac{1+y}{2} + (t/2)\\log d")#text(" to get somewhat larger bounds?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-501971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2018")])]

#text("The displayed formula seems to be too long for one line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502183")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2018")])]

#text("I have updated the writeup with a description at the end of section 7 on how candidate shifts can be searched for, with an example of how the 83952 shift near 6*10^10 was found.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2018")])]

#text("Thanks for this! I rewrote it a little bit to try to describe in rather concrete terms how the specific shift of 83952 was found, hopefully it is accurate.")

#text("My tentative plan for the paper is to try to write up a proof of ")#mi("\\Lambda \\leq 0.22")#text(" with enough detail that each step can be replicated fairly easily (it seems now that the total computer time needed is not too onerous), and then to have a final section with some further conditional results, and here perhaps we do not need to provide as many details.")

#text("I’d like to understand the situation with the asymptotic analysis (sticking for now with ")#mi("t= y = 0.2")#text("). In your previous comment you stopped the numerical verification at ")#mi("N = 7 \\times 10^8")#text(", is this because the simplest triangle inequality bound ((79) in the latest version of the writeup) works at this point (and presumably then also at all later points)? It certainly is possible that by inserting mollifiers in the analytic part of the argument one could also cover some of the region ")#mi("N \\leq 7 \\times 10^8")#text(" with a relatively small amount of numerical effort. But I remember Rudolph had some method involving testing some mesh of N first (e.g. multiples of 100) and using some rather crude bounds on the amount of fluctuation between mesh points that seemed to be rather quick here, are you already using this for ")#mi("N")#text(" near ")#mi("7 \\times 10^8")#text("?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502265")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Ah, I think I understand the distinction between ")#mi("1.5 \\times 10^6")#text(" and ")#mi("7 \\times 10^8")#text(" now… it seems that the triangle inequality bound works for ")#mi("N \\geq 1.5 \\times 10^6")#text(" for ")#mi("t=y=0.2")#text(" (I’ve just adjusted the writeup to include this calculation), but you are working now also with smaller values of ")#mi("t")#text(" and the triangle inequality bound is weaker here and is now only available for this much larger value of ")#mi("N")#text(". So for the original purpose of bounding ")#mi("\\Lambda")#text(" by 0.22 we don’t need anything fancier than the triangle bound for the asymptotic analysis, but you would like an improved bound for the asymptotic analysis to go below this value (conditionally on a numerical verification of RH). I’ll take a look to see if there is some reasonably clean estimate analogous to Lemma 1 in “estimating a sum” on the wiki that can handle mollifiers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502355")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2018")])]

#text("I did some calculations how the triangle inequality gets modified under an Euler2 mollifier and actually the calculations are relatively clean, see")

#link("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum#Euler2_mollifier_in_the_toy_model")[#text("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum#Euler2_mollifier_in_the_toy_model")]

#text("This may already reduce the ")#mi("7 \\times 10^8")#text(" threshold significantly for the values of t,y that you are working with currently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502286")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Thanks. Also, just wanted to check that given results by Conrey and others that atleast 40%+ zeta zeroes are on the critical line, is it possible to adapt such results to prove for example that atleast 95% of Ht zeroes are real at t=0.21, and can such probabilistic results help constrain things further?")

#text("Also, in the first thread you had mentioned that analyzing clusters of zeroes may help better control the dynamics of zeroes. Could probabilistic results help here as well, since a large fraction of the total ‘mass’ would be known to be away from the remaining zeroes, especially from the potentially far-off ones closer to y=1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502291")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2018")])]

#text("Sorry, I forgot that at t > 0, the number of complex zeroes is finite, so the fraction will always be 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502462")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2018")])]

#text("Thanks. We were using (t=0.13,y=0.2) and using the modified bound, the threshold reduces by 10 times to 70 million (2-(LHS in criterion) = 0.119 with N0=200k).")

#text("Also, I was trying out symbolic integration of n^(bln(n)-a). While it does not give a closed form expression, we get a formula in terms of the erfi function, which is commonly available in many tools.")#linebreak()#text(" ")#mi("\\int n^{b \\log n - a} = \\frac{\\sqrt \\pi}{2 \\sqrt {b}} \\exp(\\frac{-(a - 1)^2}{4 b}) \\textrm{erfi}(\\frac{2 b \\log n  - a + 1}{2 \\sqrt {b}})")#linebreak()#text(" (verified in wolframalpha ")#link("http://www.wolframalpha.com/input/?i=d%2Fdn+((1%2F2)*sqrt(pi)%2Fsqrt(b)*exp(-(a-1)%5E2%2F(4*b))*erfi((2*b*log(n)-a%2B1)%2F(2*sqrt(b))))")[#text("here")]#text(", which could provide a sharper tail bound. Can this be used to lower the range further?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502493")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2018")])]

#text("Sure, one could try using this bound, say for the un-mollified sum in Lemma 1 of ")#link("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")[#text("http://michaelnielsen.org/polymath1/index.php?title=Estimating_a_sum")]#text(", using the first inequality in the proof of that lemma rather than the lemma itself and using the erfi formula to evaluate that integral exactly, rather than estimating it as was done in the lemma, and see if it gives significantly superior numerical performance. One thing it should do is make the bound rather insensitive to the choice of N_0, as the integral test should be a pretty sharp bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-502533")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2018")])]

#text("Using the exact integral indeed reduces the N0 required significantly. The bound is close to its optimal value even at N0 as low as 100 and the change is marginal after N0 around 1000. The bound for (N=30mil,y=0.2,t=0.13,moll 2) is around 0.0582, so the required N_max has dropped further.")

#text("Also, using the integral for the tail term in the mollifier criterion instead of the majorizing operation at the end leads to a small but still decent impact (the bound above changes to 0.0685).")

#text("To use the ‘spare capacity’ of N=700 mil, (t,y)=(0.11,0.2) can instead be used (bound=0.233)..(although Rudolph recently already covered this (t,y) by running the bounds till N=20 billion, which suggests the capacity available is much higher).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503015")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2018")])]

#text("During the last couple of weeks, KM and I have been progressing the numerical work on the “Barrier approach”. Along the way we did develop and exchange some visual manifestations of the insights we gained. These visuals are now bundled into a single overview deck that can be found here (in pdf and powerpoint):")

#link("https://github.com/km-git-acc/dbn_upper_bound")[#text("Visuals")]

#text("The information is by no means complete and we plan to continuously update it. Hence open to feedback on errors, ommisions or desired improvements.")

#text("As the table at the end of the deck illustrates, we have come as far as verifying the numerics for ")#mi("t_0=0.11, y_0=0.2")#text(", i.e. a potential ")#mi("\\Lambda=0.13")#text(" that is conditional on the RH being verified up to ")#mi("x=10^{18}")#text(". Recently, a bottleneck for computing the Eulerbounds at higher ")#mi("x")#text(" was removed (through a much sharper euler2 version of the Triangle bound) and we are now exploring parallel processing techniques (multi-core threading and/or cloud clustering) to ‘attack’ the required Barrier-computations at ")#mi("x=10^{19}")#text(" and ")#mi("x=10^{20}")#text(".")

#text("In ‘parallel’ to this, we have started work on gathering some statistics on the behaviours of the real and complex zeros below ")#mi("t=0")#text(" (i.e. the ‘gaseous’ state).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503088")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("Thanks for this! The visuals are very nice and we should incorporate some of them into the writeup at some point.")

#text("I am currently on vacation, but will return next week and hope to update the writeup and the wiki to reflect these developments.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2018")])]

#text("A very minor remark: the link to the (pdf version of the) visual guide contained in the linked page (which is to say in the file README.md) is broken and should be updated. Keep up the great work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503973")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2018")])]

#text("We have managed to create a grid computing setup (based on BOINC) for the time consuming steps like stored sums, lemmabounds, etc. at ")#link("http://anthgrid.com/dbnupperbound")[#text("anthgrid.com/dbnupperbound")]#text(". The framework is quite flexible and can also be adapted to newer computational steps that may come up later.")#linebreak()#text(" Instructions on how to install Boinc and run the project’s tasks are kept ")#link("https://github.com/km-git-acc/dbn_upper_bound/tree/master/dbn_upper_bound/boinc")[#text("here")]#text(".")#linebreak()#text(" Currently, we are computing the storedsums matrix for X near 10^19 cell by cell.")#linebreak()#text(" It will be great to understand how we can improve the setup further and also use it for related problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503984")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2018")])]

#text("Wow, that’s impressive! I’m recovering from knee surgery right now, but I’ll try to get around to looking at this more carefully when I can.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-503987")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("The best starting point should be this thread: github.com/km-git-acc/dbn_upper_bound/issues/81")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504028")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("In parallel to the work on speeding up the numerical computations (through multi-threading the scripts and using grid computing), we also explored the behaviour of the zeros at more negative ")#mi("t")#text(". The two tools we currently have available for this domain are the unbounded Ht_integral (eq. 35 in the writeup):")

#mi("H_t(z) =\\int_{-12}^{12} \\frac18\\,\\xi\\left ( \\frac{1+iz}{2} + \\sqrt{tv} \\right )\\,\\frac{1}{\\sqrt{\\pi}}\\,e^{-v^2}\\, dv")

#text("and the well-known effective (A+B-C)/B0 approximation formula.")

#text("For more more negative ")#mi("t")#text(", the trajectories of the real zeros appear to be less chaotic than expected. This is illustrated in the plot below.")

#link("https://drive.google.com/open?id=1fQbCcnhrl7VrBaNMDZSgMt8rPB8pE75J”")[#text("Graph of real zeros up to t=-800")]

#text("Obviously we are keen to explore what happens below ")#mi("t= -800")#text(" and when the ‘real zeros steadily marching south-east’ will collide. The plot was generated using the Ht_integral, however the root finding gets quite unstable at more negative ")#mi("t")#text(" and/or larger ")#mi("x")#text(". What could help here is to have a normaliser similar to ")#mi("B0")#text(". Also, since the bounded version of the Ht_integral is not valid for negative ")#mi("t")#text(", could it be adopted to cover this domain as well (this would give a more predictable outcome)?")

#text("For smaller ")#mi("y")#text(" (up to 1) and ")#mi("t")#text(" (up to -2), both functions work properly and their outcomes are close enough. However, the ABC_eff function starts to quickly deviate from the integral at larger ")#mi("y")#text(" and/or more negative ")#mi("t")#text(" (thereby ruling out the option to use B0 as a normaliser for the Ht_integral). On the other hand, the ABC_eff approximation evaluates very fast compared to the Ht_integral, so is there a viable way to expand its validity towards larger ")#mi("-t")#text(" and ")#mi("y")#text("?")

#text("P.S.")#linebreak()#text(" Also managed to produce a graph on the behaviour of the complex zeros at negative ")#mi("t")#text(". Since it used the ABC_eff formula, the data cannot be trusted. So far, haven’t been able to reproduce this chart with the Ht_integral. I’ll share the graph anyway, since the emerging patterns are still quite interesting (but could of course also be an artefact of the diverging ABC_eff formula).")

#link("https://drive.google.com/open?id=1MELRxZcNPZr1z3uoHHnMI3NxXHufDLT6")[#text("Graph of complex zeros up to x=1000")]

#text("Does theory actually predict a positive relation between ")#mi("x")#text(" and the suprema of ")#mi("y")#text(" at a certain significantly negative ")#mi("t")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504030")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("The link to the first picture seems to be broken. Here it is again:")

#link("https://drive.google.com/open?id=1fQbCcnhrl7VrBaNMDZSgMt8rPB8pE75J")[#text("https://drive.google.com/open?id=1fQbCcnhrl7VrBaNMDZSgMt8rPB8pE75J")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a196dc283e129af2d6b83f144df9002c7f82110018f4164dd9762241734c30e8-d25a490c9fcc5661ce54bbdb21f1f0ec11e0511f48313fe0aa646e550f5c6dd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rudolph01")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504037")[#strong[#text("rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("We encountered two potentially contradicting statements about the validity of the Ht_integral for negative ")#mi("t")#text(". In the derivation of the integral in the write-up, culminating in eq. 35, there is an explicit condition on ")#mi("t")#text(" needing to be positive. However, in this comment from April:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/")[#text("Polymath15, seventh thread: going below 0.48")]
]

#text("it is observed that using negative ")#mi("t")#text(" is also valid (but only in the unbounded version of the third approach integral). The previous post is written assuming the latter interpretation is the correct one, but grateful for a confirmation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504043")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("Yes, this formula is valid for negative t also; this is equation (15) of ")#link("https://arxiv.org/pdf/1801.05914.pdf")[#text("https://arxiv.org/pdf/1801.05914.pdf")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504072")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2018")])]

#text("Very interesting! I am not sure whether one can produce good asymptotics for extremely negative values of t such as -800. One can already see trouble in the ABC approximation when t becomes very negative, in that the tail of the A and B sums start to dominate the main term in the sum, also I think the C term will also become quite large in comparison with say B_0, in contrast with small or positive values of t where C is a relatively small term. It might be interesting to plot things like |C/B_0| or |(A+B+C)/B_0| versus the accuracy of the ABC approximation. If the ABC approximation only starts failing when C/B_0 gets large then what it probably means is that all the lower order terms in the Riemann-Siegel expansion now become important. At which point it seems unlikely that we will get a clean asymptotic…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504071")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2018")])]

#text("This is comments to the references:")

#text("– [1]: “Pages 9951009” –> “995–1009”")#linebreak()#text(" – [3]: “pp. 609–630” –> “609–630”")#linebreak()#text(" – [10]: comma before page numbers")#linebreak()#text(" – [16], [18], [24]: Titles should be in italic")#linebreak()#text(" – [19]: Maybe link to the arXiv version")#linebreak()#text(" – [21]: “pp. 23–41” –> “23–41”")

#emph[#text("[Updated, thanks. I am using the style where only article titles are italicised, with book titles remaining in Roman font. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("Hmmm! Now I can’t find the link to the article anymore. Could you please post the link here?")

#emph[#text("[The most recent version of the writeup is at ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")]#text(" – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2018")])]

#text("Thanks for the link.")

#text("Some more comments to the references:")

#text("– [1]: Remove “Pages”.")#linebreak()#text(" – [3]: Remove “pp.”.")#linebreak()#text(" – [11]: Remove “pp.”.")#linebreak()#text(" – [21] Remove “pp.”.")

#emph[#text("[Changed, thanks -T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504336")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("There is a talk by Terence Tao on the Newman-conjecture, also mentioning this polymath project: ")#link("https://www.youtube.com/watch?v=t908N5gUZA0")[#text("https://www.youtube.com/watch?v=t908N5gUZA0")]#text(" (polymath is mentioned at 47.00 and in the discussion)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ef5e7c93b176a7617e0416f01e04497ff82ab5c2c8a9a015396c34d0d8687f-c34001fba30c1ceff6ba27b0aca55b12eda5633cec557f8295aa918df4469699.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug Stoll")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504383")[#strong[#text("Doug Stoll")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("Would it possible for T to post a link to the presentation for downloading? Great presentation – now I get it – this whole approach.")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2018")])]

#text("I’ve uploaded the slides ")#link("https://terrytao.files.wordpress.com/2018/08/webinar.pdf")[#text("here")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504390")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("In page 19, the first lower bound (by Newman) is from 1976 (not 1950).")

#emph[#text("[Thanks, this will be updated in the next revision of the slides. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f303970ef246eb91d78bcf634bdfa4bb0ce09a54b13eb3964c8843e81ae03d-87b28deb974afb529298238d8103509d47bf1ed6cae2bd59483ed10a7a555a73.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yeisson Alexis Acevedo")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504410")[#strong[#text("Yeisson Alexis Acevedo")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("Question for academic community:")

#text("Best Regard, Tao and community")#linebreak()#text(" Hi!")

#text("I am a Yeisson Acevedo, currently I am")#linebreak()#text(" master student in applied mathematics at the Eafit University (Colombia),")#linebreak()#text(" I am interested in number theory and I would like to ask you a question that has to do with my object of study that I do not know if it is relevant or not to publish a possible paper, and i would like to ask the favor if you give me your opinions about the next questions:")

#text("1) is there a Mersenne Prime such that $M_p = k^2+1$ for some Integer k?")#linebreak()#text(" 2) Is there a Mersenne prime who is at the same time Germain’s prime?")#linebreak()#text(" 3) Is there a Mersenne prime who is at the same time Fermat’s prime?")#linebreak()#text(" 4) Is there a Mersenne prime who is at the same time Wagstaff prime?")#linebreak()#text(" 5) Is there a Mersenne prime who is at the same time Wodall prime?")#linebreak()#text(" 6) Is it possible to estimate if around a Mersenne prime there are close primes? That is to say, is Mp +- 2 a prime number?, is Mp +- 4 a prime number?")

#text("We want to know if they are important or not in the academic field of number theory and please excuse us for making them spend their time. Thank you.")

#text("Pdt: For us, from here in Colombia, the results shared and commented in this blog have been very useful to think about several application problems that go hand in hand with the theory of numbers, although it is not our object of direct study if we use many of your results, so thank you very much for everything.")

#text("Knowledge is built in community.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504415")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2018")])]

#text("It is easy to show that the number 3 is the only solution to your third question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f303970ef246eb91d78bcf634bdfa4bb0ce09a54b13eb3964c8843e81ae03d-87b28deb974afb529298238d8103509d47bf1ed6cae2bd59483ed10a7a555a73.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yeisson Alexis Acevedo")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504433")[#strong[#text("Yeisson Alexis Acevedo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2018")])]

#text("Thank you, you are right … I forgot to write that my questions are for prime numbers greater than or equal to 7 … Thank you")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504427")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2018")])]

#text("This is definitely a wrong place to ask these questions. Why don’t you try for example ")#link("http://mathoverflow.net/")[#text("http://mathoverflow.net/")]#text(" ?")#linebreak()#text(" Btw. first question is equivalent to asking if 2^(m-1)-1 = k^2/2, which is the same as asking if there is a Mersenne prime which is even. The only prime which is even is 2, and that is not a Mersenne prime.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f303970ef246eb91d78bcf634bdfa4bb0ce09a54b13eb3964c8843e81ae03d-87b28deb974afb529298238d8103509d47bf1ed6cae2bd59483ed10a7a555a73.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yeisson Alexis Acevedo")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504432")[#strong[#text("Yeisson Alexis Acevedo")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2018")])]

#text("Thanks for the link, but change 2^p-1 for 2^(m-1)-1 have the problem that “m” must be even but when you solve the system 2^(m-1)-1 = k^2/2 have 2^m-1=k^2+1 which precisely does not refer to a prime number of mersenne since “m” is even….")#linebreak()#text(" Again thank you very much for the link, I will also ask there, but still my question remains open … thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/05/04/polymath15-ninth-thread-going-below-0-22/#comment-504502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("debruijn.tex: There is no need to load the amsmath package; the mathtools package is an extension of amsmath.")
]
