// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/
// Converted to Typst by tao2typ: "2026-10-14T16:38:20.575831+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246C notes 2: Circle packings, conformal maps, and quasiconformal maps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246C notes 2: Circle packings, conformal maps, and quasiconformal maps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 April 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("Notes 1")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2018/05/02/246c-notes-3-univalent-functions-the-loewner-equation-and-the-bieberbach-conjecture/")[#text("Notes 3")]#text(".")

#text("We now leave the topic of Riemann surfaces, and turn now to the (loosely related) topic of ")#link("https://en.wikipedia.org/wiki/Conformal_map")[#text("conformal mapping")]#text(" (and ")#link("https://en.wikipedia.org/wiki/Quasiconformal_mapping")[#text("quasiconformal mapping")]#text("). Recall that a conformal map ")#mi("{f: U \\rightarrow V}")#text(" from an open subset ")#mi("{U}")#text(" of the complex plane to another open set ")#mi("{V}")#text(" is a map that is holomorphic and bijective, which (by Rouché’s theorem) also forces the derivative of ")#mi("{f}")#text(" to be nowhere vanishing. We then say that the two open sets ")#mi("{U,V}")#text(" are conformally equivalent. From the Cauchy-Riemann equations we see that conformal maps are orientation-preserving and angle-preserving; from the Newton approximation ")#tao-math("{f( z_0 + \\Delta z) \\approx f(z_0) + f^{\\prime}(z_0) \\Delta z + O( \\left|\\Delta z\\right|^2)}", block: false)#text(" we see that they almost preserve small circles, indeed for ")#mi("{\\varepsilon}")#text(" small the circle ")#tao-math("{\\{ z: \\left|z-z_0\\right| = \\varepsilon\\}}", block: false)#text(" will approximately map to ")#tao-math("{\\{ w: \\left|w - f(z_0)\\right| = \\left|f^{\\prime}(z_0)\\right| \\varepsilon \\}}", block: false)#text(".")

#text("In previous quarters, we proved a fundamental theorem about this concept, ")#link("https://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("the Riemann mapping theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Riemann mapping theorem)")]#text(" Let ")#mi("{U}")#text(" be a simply connected open subset of ")#mi("{{\\bf C}}")#text(" that is not all of ")#mi("{{\\bf C}}")#text(". Then ")#mi("{U}")#text(" is conformally equivalent to the unit disk ")#mi("{D(0,1)}")#text(".")
]

#text("This theorem was proven in ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("these 246A lecture notes")]#text(", using an argument of Koebe. At a very high level, one can sketch Koebe’s proof of the Riemann mapping theorem as follows: among all the injective holomorphic maps ")#mi("{f: U \\rightarrow D(0,1)}")#text(" from ")#mi("{U}")#text(" to ")#mi("{D(0,1)}")#text(" that map some fixed point ")#mi("{z_0 \\in U}")#text(" to ")#mi("{0}")#text(", pick one that maximises the magnitude ")#tao-math("{\\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" of the derivative (ignoring for this discussion the issue of proving that a maximiser exists). If ")#mi("{f(U)}")#text(" avoids some point in ")#mi("{D(0,1)}")#text(", one can compose ")#mi("{f}")#text(" with various holomorphic maps and use ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz’s lemma")]#text(" and the chain rule to increase ")#tao-math("{\\left|f^{\\prime}(z_0)\\right|}", block: false)#text(" without destroying injectivity; see ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("the previous lecture notes")]#text(" for details. The conformal map ")#mi("{\\phi: U \\rightarrow D(0,1)}")#text(" is unique up to Möbius automorphisms of the disk; one can fix the map by picking two distinct points ")#mi("{z_0,z_1}")#text(" in ")#mi("{U}")#text(", and requiring ")#mi("{\\phi(z_0)}")#text(" to be zero and ")#mi("{\\phi(z_1)}")#text(" to be positive real.")

#text("It is a beautiful observation of Thurston that the concept of a conformal mapping has a discrete counterpart, namely the mapping of one ")#link("https://en.wikipedia.org/wiki/Circle_packing")[#text("circle packing")]#text(" to another. Furthermore, one can run a version of Koebe’s argument (using now a discrete version of ")#link("https://en.wikipedia.org/wiki/Perron_method")[#text("Perron’s method")]#text(") to prove the Riemann mapping theorem through circle packings. In principle, this leads to a mostly elementary approach to conformal geometry, based on extremely classical mathematics that ")#link("https://en.wikipedia.org/wiki/Circles_of_Apollonius")[#text("goes all the way back to Apollonius")]#text(". However, in order to ")#emph[#text("prove")]#text(" the basic existence and uniqueness theorems of circle packing, as well as the convergence to conformal maps in the continuous limit, it seems to be necessary (or at least highly convenient) to use much more modern machinery, including the theory of quasiconformal mapping, and also the Riemann mapping theorem itself (so in particular we are not structuring these notes to provide a completely independent proof of that theorem, though this may well be possible).")

#text("To make the above discussion more precise we need some notation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Circle packing)")]#text(" A (finite) ")#emph[#text("circle packing")]#text(" is a finite collection ")#mi("{(C_j)_{j \\in J}}")#text(" of circles ")#tao-math("{C_j = \\{ z \\in {\\bf C}: \\left|z-z_j\\right| = r_j\\}}", block: false)#text(" in the complex numbers indexed by some finite set ")#mi("{J}")#text(", whose interiors are all disjoint (but which are allowed to be tangent to each other), and whose union is connected. The ")#emph[#text("nerve")]#text(" of a circle packing is the finite ")#link("https://en.wikipedia.org/wiki/Graph_(discrete_mathematics)")[#text("graph")]#text(" whose vertices ")#mi("{\\{z_j: j \\in J \\}}")#text(" are the centres of the circle packing, with two such centres connected by an edge if the circles are tangent. (In these notes all graphs are undirected, finite and simple, unless otherwise specified.)")
]

#text("It is clear that the nerve of a circle packing is connected and ")#link("https://en.wikipedia.org/wiki/Planar_graph")[#text("planar")]#text(", since one can ")#link("https://en.wikipedia.org/wiki/Graph_drawing")[#text("draw")]#text(" the nerve by placing each vertex (tautologically) in its location in the complex plane, and drawing each edge by the line segment between the centres of the circles it connects (this line segment will pass through the point of tangency of the two circles). Later in these notes we will also have to consider some infinite circle packings, most notably the infinite regular hexagonal circle packing.")

#text("The first basic theorem in the subject is the following converse statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Circle packing theorem)")]#text(" ")#metadata(none) <tao-659eee59f002e69bf905>#text(" Every connected planar graph is the nerve of a circle packing.")
]

#text("Among other things, the circle packing theorem thus implies as a corollary ")#link("https://en.wikipedia.org/wiki/F%C3%A1ry%27s_theorem")[#text("Fáry’s theorem")]#text(" that every planar graph can be drawn using straight lines.")

#text("Of course, there can be multiple circle packings associated to a given connected planar graph; indeed, since reflections across a line and ")#link("https://en.wikipedia.org/wiki/M%C3%B6bius_transformation")[#text("Möbius transformations")]#text(" map circles to circles (or lines), they will map circle packings to circle packings (unless one or more of the circles is sent to a line). It turns out that once one adds enough edges to the planar graph, the circle packing is otherwise rigid:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Koebe-Andreev-Thurston theorem)")]#text(" ")#metadata(none) <tao-5455fc3fb94cf1d5cac4>#text(" If a connected planar graph is maximal (i.e., no further edge can be added to it without destroying planarity), then the circle packing given by the above theorem is unique up to reflections and Möbius transformations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-6b83bfdc978000918405>#text(" Let ")#mi("{G}")#text(" be a connected planar graph with ")#mi("{n \\geq 3}")#text(" vertices. Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{G}")#text(" is a maximal planar graph.")],
[#text("(ii) ")#mi("{G}")#text(" has ")#mi("{3n-6}")#text(" edges.")],
[#text("(iii) Every drawing ")#mi("{D}")#text(" of ")#mi("{G}")#text(" divides the plane into faces that have three edges each, and each edge is adjacent to two distinct faces. (This includes one unbounded face.)")],
[#text("(iv) At least one drawing ")#mi("{D}")#text(" of ")#mi("{G}")#text(" divides the plane into faces that have three edges each, and each edge is adjacent to two distinct faces.")]
)

#text("(")#emph[#text("Hint:")]#text(" you may use without proof ")#link("https://en.wikipedia.org/wiki/Planar_graph#Euler's_formula")[#text("Euler’s formula")]#text(" ")#mi("{V-E+F=2}")#text(" for planar graphs, where ")#mi("{F}")#text(" is the number of faces including the unbounded face.)")
]

#text("Thurston conjectured that circle packings can be used to approximate the conformal map arising in the Riemann mapping theorem. Here is an informal statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 6 (Informal Thurston conjecture)")]#text(" ")#metadata(none) <tao-2b6c4f062a063c7b5a78>#text(" Let ")#mi("{U}")#text(" be a simply connected domain, with two distinct points ")#mi("{z_0,z_1}")#text(". Let ")#mi("{\\phi: U \\rightarrow D(0,1)}")#text(" be the conformal map from ")#mi("{U}")#text(" to ")#mi("{D(0,1)}")#text(" that maps ")#mi("{z_0}")#text(" to the origin and ")#mi("{z_1}")#text(" to a positive real. For any small ")#mi("{\\varepsilon>0}")#text(", let ")#mi("{{\\mathcal C}_\\varepsilon}")#text(" be the portion of the regular hexagonal circle packing by circles of radius ")#mi("{\\varepsilon}")#text(" that are contained in ")#mi("{U}")#text(", and let ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" be an circle packing of ")#mi("{D(0,1)}")#text(" with the same nerve (up to isomorphism) as ")#mi("{{\\mathcal C}_\\varepsilon}")#text(", with all “boundary circles” tangent to ")#mi("{D(0,1)}")#text(", giving rise to an “approximate map” ")#mi("{\\phi_\\varepsilon: U_\\varepsilon \\rightarrow D(0,1)}")#text(" defined on the subset ")#mi("{U_\\varepsilon}")#text(" of ")#mi("{U}")#text(" consisting of the circles of ")#mi("{{\\mathcal C}_\\varepsilon}")#text(", their interiors, and the interstitial regions between triples of mutually tangent circles. Normalise this map so that ")#mi("{\\phi_\\varepsilon(z_0)}")#text(" is zero and ")#mi("{\\phi_\\varepsilon(z_1)}")#text(" is a positive real. Then ")#mi("{\\phi_\\varepsilon}")#text(" converges to ")#mi("{\\phi}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(".")
]

#text("A rigorous version of this conjecture was proven ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=906396")[#text("by Rodin and Sullivan")]#text(". Besides some elementary geometric lemmas (regarding the relative sizes of various configurations of tangent circles), the main ingredients are a rigidity result for the regular hexagonal circle packing, and the theory of ")#link("https://en.wikipedia.org/wiki/Quasiconformal_mapping")[#text("quasiconformal maps")]#text(". Quasiconformal maps are what seem on the surface to be a very broad generalisation of the notion of a conformal map. Informally, conformal maps take infinitesimal circles to infinitesimal circles, whereas quasiconformal maps take infinitesimal circles to infinitesimal ellipses of bounded eccentricity. In terms of ")#link("https://en.wikipedia.org/wiki/Wirtinger_derivatives")[#text("Wirtinger derivatives")]#text(", conformal maps obey the Cauchy-Riemann equation ")#mi("{\\frac{\\partial \\phi}{\\partial \\overline{z}} = 0}")#text(", while (sufficiently smooth) quasiconformal maps only obey an inequality ")#tao-math("{\\left|\\frac{\\partial \\phi}{\\partial \\overline{z}}\\right| \\leq \\frac{K-1}{K+1} \\left|\\frac{\\partial \\phi}{\\partial z}\\right|}", block: false)#text(". As such, quasiconformal maps are considerably more plentiful than conformal maps, and in particular it is possible to create piecewise smooth quasiconformal maps by gluing together various simple maps such as affine maps or Möbius transformations; such piecewise maps will naturally arise when trying to rigorously build the map ")#mi("{\\phi_\\varepsilon}")#text(" alluded to in the above conjecture. On the other hand, it turns out that quasiconformal maps still have many vestiges of the rigidity properties enjoyed by conformal maps; for instance, there are quasiconformal analogues of fundamental theorems in conformal mapping such as the ")#link("https://en.wikipedia.org/wiki/Schwarz_reflection_principle")[#text("Schwarz reflection principle")]#text(", ")#link("https://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(", or ")#link("https://en.wikipedia.org/wiki/Hurwitz%27s_theorem_(complex_analysis)")[#text("Hurwitz’s theorem")]#text(". Among other things, these quasiconformal rigidity theorems allow one to create conformal maps from the limit of quasiconformal maps in many circumstances, and this will be how the Thurston conjecture will be proven. A key technical tool in establishing these sorts of rigidity theorems will be the theory of an important quasiconformal (quasi-)invariant, the ")#emph[#text("conformal modulus")]#text(" (or, equivalently, the ")#link("https://en.wikipedia.org/wiki/Extremal_length")[#text("extremal length")]#text(", which is the reciprocal of the modulus).")

#metadata(none) <tao-e4f78145743c44297bab>

#heading(level: 1)[#strong[#text(" — 1. Proof of the circle packing theorem — ")]]

#text("We loosely follow the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1115988")[#text("treatment of Beardon and Stephenson")]#text(". It is slightly more convenient to temporarily work in the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" rather than the complex plane ")#mi("{{\\bf C}}")#text(", in order to more easily use Möbius transformations. (Later we will make another change of venue, working in the Poincaré disk ")#mi("{D(0,1)}")#text(" instead of the Riemann sphere.)")

#text("Define a ")#emph[#text("Riemann sphere circle")]#text(" to be either a circle in ")#mi("{{\\bf C}}")#text(" or a line in ")#mi("{{\\bf C}}")#text(" together with ")#mi("{\\infty}")#text(", together with one of the two components of the complement of this circle or line designated as the “interior”. In the case of a line, this “interior” is just one of the two half-planes on either side of the line; in the case of the circle, this is either the usual interior or the usual exterior plus the point at infinity; in the last case, we refer to the Riemann sphere circle as an ")#emph[#text("exterior circle")]#text(". (One could also equivalently work with an orientation on the circle rather than assigning an interior, since the interior could then be described as the region to (say) the left of the circle as one traverses the circle along the indicated orientation.) Note that Möbius transforms map Riemann sphere circles to Riemann sphere circles. If one views the Riemann sphere as a geometric sphere in Euclidean space ")#mi("{{\\bf R}^3}")#text(", then Riemann sphere circles are just circles on this geometric sphere, which then have a centre on this sphere that lies in the region designated as the interior of the circle. We caution though that this “Riemann sphere” centre does not always correspond to the Euclidean notion of the centre of a circle. For instance, the real line, with the upper half-plane designated as interior, will have ")#mi("{i}")#text(" as its Riemann sphere centre; if instead one designates the lower half-plane as the interior, the Riemann sphere centre will now be ")#mi("{-i}")#text(". We can then define a Riemann sphere circle packing in exact analogy with circle packings in ")#mi("{{\\bf C}}")#text(", namely finite collections of Riemann sphere circles whose interiors are disjoint and whose union is connected; we also define the nerve as before. This is now a graph that can be drawn in the Riemann sphere, using great circle arcs in the Riemann sphere rather than line segments; it is also planar, since one can apply a Möbius transformation to move all the points and edges of the drawing away from infinity.")

#text("By Exercise ")#link(<tao-6b83bfdc978000918405>)[#text("5")]#text(", a maximal planar graph with at least three vertices can be drawn as a ")#link("https://en.wikipedia.org/wiki/Surface_triangulation")[#text("triangulation of the Riemann sphere")]#text(". If there are at least four vertices, then it is easy to see that each vertex has degree at least three (a vertex of degree zero, one or two in a triangulation with simple edges will lead to a connected component of at most three vertices). It is a topological fact, not established here, that any two triangulations of such a graph are homotopic up to reflection (to reverse the orientation). If a Riemann sphere circle packing has the nerve of a maximal planar graph ")#mi("{G}")#text(" of at least four vertices, then we see that this nerve induces an explicit triangulation of the Riemann sphere by connecting the centres of any pair of tangent circles with the great circle arc that passes through the point of tangency. If ")#mi("{G}")#text(" was not maximal, one no longer gets a triangulation this way, but one still obtains a partition of the Riemann sphere into spherical polygons.")

#text("We remark that the triangles in this triangulation can also be described purely from the abstract graph ")#mi("{G}")#text(". Define a ")#emph[#text("triangle")]#text(" in ")#mi("{G}")#text(" to be a triple ")#mi("{w_1,w_2,w_3}")#text(" of vertices in ")#mi("{G}")#text(" which are all adjacent to each other, and such that the removal of these three vertices from ")#mi("{G}")#text(" does not disconnect the graph. One can check that there is a one-to-one correspondence between such triangles in a maximal planar graph ")#mi("{G}")#text(" and the triangles in any Riemann sphere triangulation of this graph.")

#text("Theorems ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(", ")#link(<tao-5455fc3fb94cf1d5cac4>)[#text("4")]#text(" are then a consequence of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Riemann sphere circle packing theorem)")]#text(" ")#metadata(none) <tao-0b9cf00a584ce9ac5bd6>#text(" Let ")#mi("{G}")#text(" be a maximal planar graph with at least four vertices, drawn as a triangulation of the Riemann sphere. Then there exists a Riemann sphere circle packing with nerve ")#mi("{G}")#text(" whose triangulation is homeomorphic (in an orientation preserving fashion) to the given triangulation. Furthermore, this packing is unique up to Möbius transformations.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Deduce Theorems ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(", ")#link(<tao-5455fc3fb94cf1d5cac4>)[#text("4")]#text(" from Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(". (")#emph[#text("Hint:")]#text(" If one has a non-maximal planar graph for Theorem ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(", add a vertex at the interior of each non-triangular face of a drawing of that graph, and connect that vertex to the vertices of the face, to create a maximal planar graph to which Theorem ")#link(<tao-5455fc3fb94cf1d5cac4>)[#text("4")]#text(" or Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(" can be applied. Then delete these “helper vertices” to create a packing of the original planar graph that does not contain any “unwanted” tangencies. You may use without proof the above assertion that any two triangulations of a maximal planar graph are homotopic up to reflection.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-04efaf080f5a3e74e1c2>#text(" Verify Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(" when ")#mi("{G}")#text(" has exactly four vertices. (")#emph[#text("Hint:")]#text(" for the uniqueness, one can use Möbius transformations to move two of the circles to become parallel lines. Here you can assume without proof that any two drawings of a maximal planar graph are homeomorphic.)")
]

#text("To prove this theorem, we will make a reduction with regards to the existence component of Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(". For technical reasons we will need to introduce a notion of non-degeneracy. Let ")#mi("{G}")#text(" be a maximal planar graph with at least five vertices, and let ")#mi("{v}")#text(" be a vertex in ")#mi("{G}")#text(". As discussed above, the degree ")#mi("{d}")#text(" of ")#mi("{v}")#text(" is at least three. Writing the neighbours of ")#mi("{v}")#text(" in clockwise or counterclockwise order (with respect to a triangulation) as ")#mi("{v_1,\\dots,v_d}")#text(" (starting from some arbitrary neighbour), we see that each ")#mi("{v_i}")#text(" is adjacent to ")#mi("{v_{i-1}}")#text(" and ")#mi("{v_{i+1}}")#text(" (with the conventions ")#mi("{v_0=v_d}")#text(" and ")#mi("{v_{d+1}=v_1}")#text("). We say that ")#mi("{v}")#text(" is ")#emph[#text("non-degenerate")]#text(" if there are no further adjacencies between the ")#mi("{v_1,\\dots,v_d}")#text(", and if there is at least one further vertex in ")#mi("{G}")#text(" besides ")#mi("{v,v_1,\\dots,v_d}")#text(". Here is another characterisation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Let ")#mi("{G}")#text(" be a maximal planar graph with at least five vertices, let ")#mi("{v}")#text(" be a vertex in ")#mi("{G}")#text(", and let ")#mi("{v_1,\\dots,v_d}")#text(" be the neighbours of ")#mi("{v}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{v}")#text(" is non-degenerate.")],
[#text("(ii) The graph ")#mi("{G \\backslash \\{ v, v_1, \\dots, v_d \\}}")#text(" is connected and non-empty, and every vertex in ")#mi("{v_1,\\dots,v_d}")#text(" is adjacent to at least one vertex in ")#mi("{G \\backslash \\{ v, v_1, \\dots, v_d \\}}")#text(".")]
)
]

#text("We will then derive Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(" from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Inductive step)")]#text(" ")#metadata(none) <tao-81503e1722865ddd4bfb>#text(" Let ")#mi("{G}")#text(" be a maximal planar graph with at least five vertices ")#mi("{V}")#text(", drawn as a triangulation of the Riemann sphere. Let ")#mi("{v}")#text(" be a non-degenerate vertex of ")#mi("{G}")#text(", and let ")#mi("{G - \\{v\\}}")#text(" be the graph formed by deleting ")#mi("{v}")#text(" (and edges emenating from ")#mi("{v}")#text(") from ")#mi("{G}")#text(". Suppose that there exists a Riemann sphere circle packing ")#mi("{(C_w)_{w \\in V \\backslash \\{v\\}}}")#text(" whose nerve is ")#emph[#text("at least")]#text(" ")#mi("{G - \\{v\\}}")#text(" (that is, ")#mi("{C_w}")#text(" and ")#mi("{C_{w^{\\prime}}}")#text(" are tangent whenever ")#mi("{w,w^{\\prime}}")#text(" are adjacent in ")#mi("{G - \\{v\\}}")#text(", although we also allow additional tangencies), and whose associated subdivision of the Riemann sphere into spherical polygons is homeomorphic (in orientation-preserving fashion) to the given triangulation with ")#mi("{v}")#text(" removed. Then there is a Riemann sphere circle packing ")#mi("{(\\tilde C_w)_{w \\in V}}")#text(" with nerve ")#mi("{G}")#text(" whose triangulation is homeomorphic (in orientation preserving fashion) to the given triangulation. Furthermore this circle packing ")#mi("{(\\tilde C_w)_{w \\in V}}")#text(" is unique up to Möbius transformations.")
]

#text("Let us now see how Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(" follows from Theorem ")#link(<tao-81503e1722865ddd4bfb>)[#text("11")]#text(". Fix ")#mi("{G}")#text(" as in Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(". By Exercise ")#link(<tao-04efaf080f5a3e74e1c2>)[#text("9")]#text(" and induction we may assume that ")#mi("{G}")#text(" has at least five vertices, and that the claim has been proven for any smaller number of vertices.")

#text("First suppose that ")#mi("{G}")#text(" contains a non-degenerate vertex ")#mi("{v}")#text(". Let ")#mi("{v_1,\\dots,v_d}")#text(" be the the neighbours of ")#mi("{v}")#text(". One can then form a new graph ")#mi("{G^{\\prime}}")#text(" with one fewer vertex by deleting ")#mi("{v}")#text(", and then connecting ")#mi("{v_3,\\dots,v_{d-1}}")#text(" to ")#mi("{v_1}")#text(" (one can think of this operation as contracting the edge ")#mi("{\\{v,v_1\\}}")#text(" to a point). One can check that this is still a maximal planar graph that can triangulate the Riemann sphere in a fashion compatible with the original triangulation of ")#mi("{G}")#text(" (in that all the common vertices, edges, and faces are unchanged). By induction hypothesis, ")#mi("{G^{\\prime}}")#text(" is the nerve of a circle packing that is compatible with this triangulation, and hence this circle packing has nerve at least ")#mi("{G - \\{v\\}}")#text(". Applying Theorem ")#link(<tao-81503e1722865ddd4bfb>)[#text("11")]#text(", we then obtain the required claim for ")#mi("{G}")#text(".")

#text("Now suppose that ")#mi("{G}")#text(" contains a degenerate vertex ")#mi("{v}")#text(". Let ")#mi("{v_1,\\dots,v_d}")#text(" be the neighbours of ")#mi("{v}")#text(" traversed in order. By hypothesis, there is an additional adjacency between the ")#mi("{v_1,\\dots,v_d}")#text("; by relabeling we may assume that ")#mi("{v_1}")#text(" is adjacent to ")#mi("{v_k}")#text(" for some ")#mi("{3 \\leq k \\leq d-1}")#text(". The vertices ")#mi("{V}")#text(" in ")#mi("{G}")#text(" can then be partitioned as")

#align(center)[#tao-fit-display[#mitex("V = \\{v\\} \\cup \\{ v_1,\\dots,v_d\\} \\cup V_1 \\cup V_2")]]

#text("where ")#mi("{V_1}")#text(" denotes those vertices in ")#mi("{V \\backslash \\{ v_1,\\dots,v_d\\}}")#text(" that lie in the region enclosed by the loop ")#mi("{v_1,\\dots,v_k, v_1}")#text(" that does not contain ")#mi("{v}")#text(", and ")#mi("{V_2}")#text(" denotes those vertices in ")#mi("{V \\backslash \\{ v_1,\\dots,v_d\\}}")#text(" that lie in the region enclosed by the loop ")#mi("{v_k,\\dots,v_d,v_1, v_k}")#text(" that does not contain ")#mi("{v}")#text(". One can then form two graphs ")#mi("{G_1, G_2}")#text(", formed by restricting ")#mi("{G}")#text(" to the vertices ")#mi("{\\tilde V_1 := \\{v, v_1,\\dots,v_k\\} \\cup V_1}")#text(" and ")#mi("{\\tilde V_2 := \\{ v, v_k, \\dots, v_d, v_1\\} \\cup V_2}")#text(" respectively; furthermore, these graphs are also maximal planar (with triangulations that are compatible with those of ")#mi("{G}")#text("). By induction hypothesis, we can find a circle packing ")#mi("{(C_w)_{w \\in \\tilde V_1}}")#text(" with nerve ")#mi("{G_1}")#text(", and a circle packing ")#mi("{(C^{\\prime}_w)_{w \\in \\tilde V_2}}")#text(" with nerve ")#mi("{G_2}")#text(". Note that the circles ")#mi("{C_v, C_{v_1}, C_{v_k}}")#text(" are mutually tangent, as are ")#mi("{C^{\\prime}_v, C^{\\prime}_{v_1}, C^{\\prime}_{v_k}}")#text(". By applying a Möbius transformation one may assume that these circles agree, thus (cf. Exercise ")#link(<tao-04efaf080f5a3e74e1c2>)[#text("9")]#text(") ")#mi("{C_v = C^{\\prime}_v}")#text(", ")#mi("{C_{v_1} = C^{\\prime}_{v_1}, C_{v_k} = C^{\\prime}_{v_k}}")#text(". The complement of the these three circles (and their interiors) determine two connected “interstitial” regions (that are in the shape of an ")#link("https://en.wikipedia.org/wiki/Arbelos")[#text("arbelos")]#text(", up to Möbius transformation); one can check that the remaining circles in ")#mi("{(C_w)_{w \\in \\tilde V_1}}")#text(" will lie in one of these regions, and the remaining circles in ")#mi("{(C^{\\prime}_w)_{w \\in \\tilde V_2}}")#text(" lie in the other. Hence one can glue these circle packings together to form a single circle packing with nerve ")#mi("{G}")#text(", which is homeomorphic (in orientation-preserving fashion) to the given triangulation. Also, since a Möbius transformation that fixes three mutually tangent circles has to be the identity, the uniqueness of this circle packing up to Möbius transformations follows from the uniqueness for the two component circle packings ")#mi("{(C_w)_{w \\in \\tilde V_1}}")#text(", ")#mi("{(C^{\\prime}_w)_{w \\in \\tilde V_2}}")#text(".")#linebreak()#text(" It remains to prove Theorem ")#link(<tao-81503e1722865ddd4bfb>)[#text("11")]#text(". To help fix the freedom to apply Möbius transformations, we can normalise the target circle packing ")#mi("{(\\tilde C_w)_{w \\in V}}")#text(" so that ")#mi("{\\tilde C_v}")#text(" is the exterior circle ")#tao-math("{\\{ \\left|z\\right|=1\\}}", block: false)#text(", thus all the other circles ")#mi("{\\tilde C_w}")#text(" in the packing will lie in the closed unit disk ")#mi("{\\overline{D(0,1)}}")#text(". Similarly, by applying a suitable Möbius transformation one can assume that ")#mi("{\\infty}")#text(" lies outside of the interior of all the circles ")#mi("{C_w}")#text(" in the original packing, and after a scaling one may then assume that all the circles ")#mi("{C_w}")#text(" lie in the unit disk ")#mi("{D(0,1)}")#text(".")

#text("At this point it becomes convenient to switch from the “elliptic” conformal geometry of the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" to the “hyperbolic” conformal geometry of the unit disk ")#mi("{D(0,1)}")#text(". Recall that the Möbius transformations that preserve the disk ")#mi("{D(0,1)}")#text(" are given by the maps ")#metadata(none) <tao-570522f099ecf81fd255>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("z \\mapsto e^{i\\theta} \\frac{z-\\alpha}{1-\\overline{\\alpha} z}")]]

#linebreak()#text(" for real ")#mi("{\\theta}")#text(" and ")#mi("{\\alpha \\in D(0,1)}")#text(" (see Theorem 19 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("these notes")]#text("). It comes with a natural metric that interacts well with circles:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Define the ")#link("https://en.wikipedia.org/wiki/Poincar%C3%A9_metric")[#text("Poincaré distance")]#text(" ")#mi("{d(z_1,z_2)}")#text(" between two points of ")#mi("{D(0,1)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("d(z_1,z_2) := 2 \\mathrm{arctanh} |\\frac{z_1-z_2}{1-z_1 \\overline{z_2}}|.")]]

#text("Given a measurable subset ")#mi("{E}")#text(" of ")#mi("{D(0,1)}")#text(", define the ")#emph[#text("hyperbolic area")]#text(" of ")#mi("{E}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{area}(E) := \\int_E \\frac{4\\ dx dy}{(1-\\left|z\\right|^2)^2}", block: true)]]

#text("where ")#mi("{dx dy}")#text(" is the Euclidean area element on ")#mi("{D(0,1)}")#text(".")

#list(
[#text("(i) Show that the Poincaré distance is invariant with respect to Möbius automorphisms of ")#mi("{D(0,1)}")#text(", thus ")#mi("{d(Tz_1, Tz_2) = d(z_1,z_2)}")#text(" whenever ")#mi("{T}")#text(" is a transformation of the form ")#link(<tao-570522f099ecf81fd255>)[#text("(1)")]#text(". Similarly show that the hyperbolic area is invariant with respect to such transformations.")],
[#text("(ii) Show that the Poincaré distance defines a metric on ")#mi("{D(0,1)}")#text(". Furthermore, show that any two distinct points ")#mi("{z_1,z_2}")#text(" are connected by a unique ")#link("https://en.wikipedia.org/wiki/Geodesic#Metric_geometry")[#text("geodesic")]#text(", which is a portion of either a line or a circle that meets the unit circle orthogonally at two points. (")#emph[#text("Hint:")]#text(" use the symmetries of (i) to normalise the points one is studying.) Here, by geodesic we mean a curve that can be parameterized as ")#mi("{\\gamma: [a,b] \\rightarrow D(0,1)}")#text(" for some curve ")#mi("{\\gamma}")#text(" for which ")#mi("{d(\\gamma(s),\\gamma(t))}")#text(" is proportional to ")#tao-math("{\\left|s-t\\right|}", block: false)#text(", thus there exists ")#mi("{c>0}")#text(" such that ")#tao-math("{d(\\gamma(s),\\gamma(t)) = c\\left|s-t\\right|}", block: false)#text(" for all ")#mi("{s,t \\in [a,b]}")#text(".")],
[#text("(iii) If ")#mi("{C}")#text(" is a circle in the interior of ")#mi("{D(0,1)}")#text(", show that there exists a point ")#mi("{z_C}")#text(" in ")#mi("{D(0,1)}")#text(" and a positive real number ")#mi("{r_C}")#text(" (which we call the ")#emph[#text("hyperbolic center")]#text(" and ")#emph[#text("hyperbolic radius")]#text(" respectively) such that ")#mi("{C = \\{ z \\in D(0,1): d(z,z_C) = r_C \\}}")#text(". (In general, the hyperbolic center and radius will not quite agree with their familiar Euclidean counterparts.) Conversely, show that for any ")#mi("{z_C \\in D(0,1)}")#text(" and ")#mi("{r_C > 0}")#text(", the set ")#mi("{\\{ z \\in D(0,1): d(z,z_C) = r_C \\}}")#text(" is a circle in ")#mi("{D(0,1)}")#text(".")],
[#text("(iv) If two circles ")#mi("{C_1, C_2}")#text(" in ")#mi("{D(0,1)}")#text(" are externally tangent, show that the geodesic connecting the hyperbolic centers ")#mi("{z_{C_1}, z_{C_2}}")#text(" passes through the point of tangency, orthogonally to the two tangent circles.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Schwarz-Pick theorem)")]#text(" Let ")#mi("{f: D(0,1) \\rightarrow D(0,1)}")#text(" be a holomorphic map. Show that ")#mi("{d(f(z_1),f(z_2)) \\leq d(z_1,z_2)}")#text(" for all ")#mi("{z_1,z_2 \\in D(0,1)}")#text(". If ")#mi("{z_1 \\neq z_2}")#text(", show that equality occurs if and only if ")#mi("{f}")#text(" is a Möbius automorphism ")#link(<tao-570522f099ecf81fd255>)[#text("(1)")]#text(" of ")#mi("{D(0,1)}")#text(". (This result is known as the ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma#Schwarz%E2%80%93Pick_theorem")[#text("Schwarz-Pick theorem")]#text(".)")
]

#text("We will refer to circles that lie in the closure ")#mi("{\\overline{D(0,1)}}")#text(" of the unit disk as ")#emph[#text("hyperbolic circles")]#text(". These can be divided into the finite radius hyperbolic circles, which lie in the interior of the unit disk (as per part (iii) of the above exercise), and the ")#link("https://en.wikipedia.org/wiki/Horocycle")[#text("horocycles")]#text(", which are internally tangent to the unit circle. By convention, we view horocycles as having infinite radius, and having center at their point of tangency to the unit circle; they can be viewed as the limiting case of finite radius hyperbolic circles when the radius goes to infinity and the center goes off to the boundary of the disk (at the same rate as the radius, as measured with respect to the Poincaré distance). We write ")#mi("{C(p,r)}")#text(" for the hyperbolic circle with hyperbolic centre ")#mi("{p}")#text(" and hyperbolic radius ")#mi("{r}")#text(" (thus either ")#mi("{0 < r < \\infty}")#text(" and ")#mi("{p \\in D(0,1)}")#text(", or ")#mi("{r = \\infty}")#text(" and ")#mi("{p}")#text(" is on the unit circle); there is an annoying caveat that when ")#mi("{r=\\infty}")#text(" there is more than one horocycle ")#mi("{C(p,\\infty)}")#text(" with hyperbolic centre ")#mi("{p}")#text(", but we will tolerate this breakdown of functional dependence of ")#mi("{C}")#text(" on ")#mi("{p}")#text(" and ")#mi("{r}")#text(" in order to simplify the notation. A ")#emph[#text("hyperbolic circle packing")]#text(" is a circle packing ")#mi("{(C(p_v,r_v))_{v \\in V}}")#text(" in which all circles are hyperbolic circles.")

#text("We also observe that the geodesic structure extends to the boundary of the unit disk: for any two distinct points ")#mi("{z_1,z_2}")#text(" in ")#mi("{\\overline{D(0,1)}}")#text(", there is a unique geodesic that connects them.")

#text("In view of the above discussion, Theorem ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(" may now be formulated as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Inductive step, hyperbolic formulation)")]#text(" ")#metadata(none) <tao-e282e7f23047a4bf856d>#text(" Let ")#mi("{G}")#text(" be a maximal planar graph with at least four vertices ")#mi("{V}")#text(", let ")#mi("{v}")#text(" be a non-degenerate vertex of ")#mi("{G}")#text(", and let ")#mi("{v_1,\\dots,v_d}")#text(" be the vertices adjacent to ")#mi("{v}")#text(". Suppose that there exists a hyperbolic circle packing ")#mi("{(C(p_w,r_w))_{w \\in V \\backslash \\{v\\}}}")#text(" whose nerve is at least ")#mi("{G - \\{v\\}}")#text(". Then there is a hyperbolic circle packing ")#mi("{(C(\\tilde p_w,\\tilde r_w))_{V \\backslash \\{v\\}}}")#text(" homeomorphic (in orientation-preserving fashion) to ")#mi("{(C(p_w,r_w))_{w \\in V \\backslash \\{v\\}}}")#text(" such that the boundary circles ")#mi("{C(\\tilde p_{v_j}, \\tilde r_{v_j})}")#text(", ")#mi("{j=1,\\dots,d}")#text(" are all horocycles. Furthermore, this packing is unique up to Möbius automorphisms ")#link(<tao-570522f099ecf81fd255>)[#text("(1)")]#text(" of the disk ")#mi("{D(0,1)}")#text(".")
]

#text("Indeed, once one adjoints the exterior unit circle to ")#mi("{(C(p_w,r_w))_{w \\in V \\backslash \\{v\\}}}")#text(", one obtains a Riemann sphere circle packing whose nerve is at least ")#mi("{G}")#text(", and hence equal to ")#mi("{G}")#text(" since ")#mi("{G}")#text(" is maximal.")

#text("To prove this theorem, the intuition is to “inflate” the hyperbolic radius of the circles of ")#mi("{C_w}")#text(" until the boundary circles all become infinite radius (i.e., horocycles). The difficulty is that one cannot just arbitrarily increase the radius of any given circle without destroying the required tangency properties. The resolution to this difficulty given in the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1115988")[#text("work of Beardon and Stephenson")]#text(" that we are following here was inspired by ")#link("https://en.wikipedia.org/wiki/Perron_method")[#text("Perron’s method of subharmonic functions")]#text(", in which one faced an analogous difficulty that one could not easily manipulate a harmonic function without destroying its harmonicity. There, the solution was to work instead with the more flexible class of ")#link("https://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonic functions")]#text("; here we similarly work with the concept of a ")#emph[#text("subpacking")]#text(".")

#text("We will need some preliminaries to define this concept precisely. We first need some hyperbolic trigonometry. We define a ")#link("https://en.wikipedia.org/wiki/Hyperbolic_triangle")[#text("hyperbolic triangle")]#text(" to be the solid (and closed) region in ")#mi("{\\overline{D(0,1)}}")#text(" enclosed by three distinct points ")#mi("{z_1,z_2,z_3}")#text(" in ")#mi("{\\overline{D(0,1)}}")#text(" and the geodesic arcs connecting them. (Note that we allow one or more of the vertices to be on the boundary of the disk, so that the sides of the triangle could have infinite length.) Let ")#mi("{T := (0,+\\infty]^3 \\backslash \\{ (\\infty,\\infty,\\infty)\\}}")#text(" be the space of triples ")#mi("{(r_1,r_2,r_3)}")#text(" with ")#mi("{0 < r_1,r_2,r_3 \\leq \\infty}")#text(" and not all of ")#mi("{r_1,r_2,r_3}")#text(" infinite. We say that a hyperbolic triangle with vertices ")#mi("{p_1,p_2,p_3}")#text(" is a ")#emph[#mi("{(r_1,r_2,r_3)}")#text("-triangle")]#text(" if there are hyperbolic circles ")#mi("{C(p_i,r_1), C(p_2,r_2), C(p_3,r_3)}")#text(" with the indicated hyperbolic centres and hyperbolic radii that are externally tangent to each other; note that this implies that the sidelengths opposite ")#mi("{p_1,p_2,p_3}")#text(" have length ")#mi("{r_2+r_3, r_1+r_3, r_1+r_2}")#text(" respectively (see Figure 3 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1115988")[#text("Beardon and Stephenson")]#text("). It is easy to see that for any ")#mi("{(r_1,r_2,r_3) \\in T}")#text(", there exists a unique ")#mi("{(r_1,r_2,r_3)}")#text("-triangle in ")#mi("{\\overline{D(0,1)}}")#text(" up to reflections and Möbius automorphisms (use Möbius transforms to fix two of the hyperbolic circles, and consider all the circles externally tangent to both of these circles; the case when one or two of the ")#mi("{r_1,r_2,r_3}")#text(" are infinite may need to be treated separately.). As a consequence, there is a well defined angle ")#mi("{\\alpha_i(r_1,r_2,r_3) \\in [0,\\pi)}")#text(" for ")#mi("{i=1,2,3}")#text(" subtended by the vertex ")#mi("{p_i}")#text(" of an ")#mi("{(r_1,r_2,r_3)}")#text(" triangle. We need some basic facts from hyperbolic geometry:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Hyperbolic trigonometry)")]#text(" ")#metadata(none) <tao-91e235e3f8168853b4d9>

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Hyperbolic_law_of_cosines")[#text("Hyperbolic cosine rule")]#text(") For any ")#mi("{0 < r_1,r_2,r_3 < \\infty}")#text(", show that the quantity ")#mi("{\\cos \\alpha_1(r_1,r_2,r_3)}")#text(" is equal to the ratio")

#align(center)[#tao-fit-display[#mitex("\\frac{\\cosh( r_1+r_2) \\cosh(r_1+r_3) - \\cosh(r_2+r_3)}{\\sinh(r_1+r_2) \\sinh(r_1+r_3)}.")]]

#text("Furthermore, establish the limiting angles")

#tao-aligned(keep: true)[


#tao-math("\\alpha_1(\\infty,r_2,r_3)  & = \\alpha_1(\\infty,\\infty,r_3) = \\alpha_1(\\infty,r_2,\\infty) = 0", block: true)



#tao-math("\\cos \\alpha_1(r_1,\\infty,r_3)  & = \\frac{\\cosh(r_1+r_3) - \\exp(r_3-r_1)}{\\sinh(r_1+r_3)}", block: true)



#tao-math("\\cos \\alpha_1(r_1,r_2,\\infty)  & = \\frac{\\cosh(r_1+r_2) - \\exp(r_2-r_1)}{\\sinh(r_1+r_2)}", block: true)



#tao-math("\\cos \\alpha_1(r_1,\\infty,\\infty)  & = 1 - 2\\exp(-2r_1).", block: true)
]

#text("(Hint: to facilitate computations, use a Möbius transform to move the ")#mi("{p_1}")#text(" vertex to the origin when the radius there is finite.) Conclude in particular that ")#mi("{\\alpha_1: T \\rightarrow [0,\\pi)}")#text(" is continuous (using the topology of the extended real line for each component of ")#mi("{T}")#text("). Discuss how this rule relates to the ")#link("https://en.wikipedia.org/wiki/Law_of_cosines")[#text("Euclidean cosine rule")]#text(" in the limit as ")#mi("{r_1,r_2,r_3}")#text(" go to zero. Of course, by relabeling one obtains similar formulae for ")#mi("{\\alpha_2(r_1,r_2,r_3)}")#text(" and ")#mi("{\\alpha_3(r_1,r_2,r_3)}")#text(".")],
[#text("(ii) (Area rule) Show that the area of a hyperbolic triangle is given by ")#mi("{\\pi - \\alpha_1-\\alpha_2-\\alpha_3}")#text(", where ")#mi("{\\alpha_1,\\alpha_2,\\alpha_3}")#text(" are the angles of the hyperbolic triangle. (Hint: there are several ways to proceed. For instance, one can prove this for small hyperbolic triangles (of diameter ")#mi("{O(\\varepsilon)}")#text(") up to errors of size ")#mi("{o(\\varepsilon^2)}")#text(" after normalising as in (ii), and then establish the general case by subdividing a large hyperbolic triangle into many small hyperbolic triangles. This rule is also a special case of the ")#link("https://en.wikipedia.org/wiki/Gauss%E2%80%93Bonnet_theorem")[#text("Gauss-Bonnet theorem")]#text(" in Riemannian geometry. One can also first establish the case when several of the radii are infinite, and use that to derive finite cases.) In particular, the area ")#mi("{\\mathrm{Area}(r_1,r_2,r_3)}")#text(" of a ")#mi("{(r_1,r_2,r_3)}")#text("-triangle is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\pi - \\alpha_1(r_1,r_2,r_3) - \\alpha_2(r_1,r_2,r_3) - \\alpha_3(r_1,r_2,r_3).")]]

#metadata(none) <tao-4a91ee5f0106c2b35c11>],
[#text("(iii) Show that the area of the interior of a hyperbolic circle ")#mi("{C(p,r)}")#text(" with ")#mi("{r<\\infty}")#text(" is equal to ")#mi("{4\\pi \\sinh^2(r/2)}")#text(".")]
)
]

#text("Henceforth we fix ")#mi("{G, v, v_1,\\dots,v_d, {\\mathcal C} = (C(p_w,r_w))_{w \\in V \\backslash \\{v\\}}}")#text(" as in Theorem ")#link(<tao-e282e7f23047a4bf856d>)[#text("14")]#text(". We refer to the vertices ")#mi("{v_1,\\dots,v_d}")#text(" as ")#emph[#text("boundary vertices")]#text(" of ")#mi("{G - \\{v\\}}")#text(" and the remaining vertices as ")#emph[#text("interior vertices")]#text("; edges between boundary vertices are ")#emph[#text("boundary edges")]#text(", all other edges will be called ")#emph[#text("interior edges")]#text(" (including edges that have one vertex on the boundary). Triangles in ")#mi("{G -\\{v\\}}")#text(" that involve two boundary vertices (and thus necessarily one interior vertex) will be called ")#emph[#text("boundary triangles")]#text("; all other triangles (including ones that involve one boundary vertex) will be called ")#emph[#text("interior triangles")]#text(". To any triangle ")#mi("{w_1,w_2,w_3}")#text(" of ")#mi("{G - \\{v\\}}")#text(", we can form the hyperbolic triangle ")#mi("{\\Delta_{\\mathcal C}(w_1,w_2,w_3)}")#text(" with vertices ")#mi("{p_{w_1}, p_{w_2}, p_{w_3}}")#text("; this is an ")#mi("{(r_{w_1}, r_{w_2}, r_{w_3})}")#text("-triangle. Let ")#mi("{\\Sigma}")#text(" denote the collection of such hyperbolic triangles; because ")#mi("{{\\mathcal C}}")#text(" is a packing, we see that these triangles have disjoint interiors. They also fit together in the following way: if ")#mi("{e}")#text(" is a side of a hyperbolic triangle in ")#mi("{\\Sigma}")#text(", then there will be another hyperbolic triangle in ")#mi("{\\Sigma}")#text(" that shares that side precisely when ")#mi("{e}")#text(" is associated to an interior edge of ")#mi("{G - \\{v\\}}")#text(". The union of all these triangles is homeomorphic to the region formed by starting with a triangulation of the Riemann sphere by ")#mi("{G}")#text(" and removing the triangles containing ")#mi("{v}")#text(" as a vertex, and is therefore homeomorphic to a disk. One can think of the collection ")#mi("{\\Sigma}")#text(" of hyperbolic triangles, together with the vertices and edges shared by these triangles, as a two-dimensional (hyperbolic) ")#link("https://en.wikipedia.org/wiki/Simplicial_complex")[#text("simplicial complex")]#text(", though we will not develop the full machinery of such complexes here.")

#text("Our objective is to find another hyperbolic circle packing ")#mi("{\\tilde {\\mathcal C} = (C(\\tilde p_w, \\tilde r_w))_{w \\in V \\backslash \\{v\\}}}")#text(" homeomorphic (in orientation-preserving fashion) to the existing circle packing ")#mi("{{\\mathcal C}}")#text(", such at all the boundary circles (circles centred at boundary vertices) are horocycles. We observe that such a hyperbolic circle packing is completely described (up to Möbius transformations) by the hyperbolic radii ")#mi("{(\\tilde r_w)_{w \\in V \\backslash \\{v\\}}}")#text(" of these circles. Indeed, suppose one knows the values of these hyperbolic radii. Then each hyperbolic triangle ")#mi("{\\Delta_{\\mathcal C}(w_1,w_2,w_3)}")#text(" in ")#mi("{\\Sigma}")#text(" is associated to a hyperbolic triangle ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" whose sides and angles are known from Exercise ")#link(<tao-91e235e3f8168853b4d9>)[#text("15")]#text(". As the orientation of each hyperbolic triangle is fixed, each hyperbolic triangle is determined up to a Möbius automorphism of ")#mi("{D(0,1)}")#text(". Once one fixes one hyperbolic triangle, the adjacent hyperbolic triangles (that share a common side with the first triangle) are then also fixed; continuing in this fashion we see that the entire hyperbolic circle packing ")#mi("{\\tilde {\\mathcal C}}")#text(" is determined.")

#text("On the other hand, not every choice of radii ")#mi("{(\\tilde r_w)_{w \\in V \\backslash \\{v\\}}}")#text(" will lead to a hyperbolic circle packing ")#mi("{\\tilde {\\mathcal C}}")#text(" with the required properties. There are two obvious constraints that need to be satisfied:")

#list(
[#text("(i) (Local constraint) The angles ")#mi("{\\alpha_1( \\tilde r_w, \\tilde r_{w_1}, \\tilde r_{w_2})}")#text(" of all the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w,w_1,w_2)}")#text(" around any given interior vertex ")#mi("{w}")#text(" must sum to exactly ")#mi("{2\\pi}")#text(". (In particular, this forces ")#mi("{\\tilde r_w}")#text(" to be finite, since otherwise all the angles here would vanish.)")],
[#text("(ii) (Boundary constraint) The radii associated to boundary vertices must be infinite.")]
)

#text("There could potentially also be a global constraint, in that one requires the circles of the packing to be disjoint – including circles that are not necessarily adjacent to each other. In general, one can easily create configurations of circles that are local circle packings but not global ones (see e.g., Figure 7 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1115988")[#text("Beardon-Stephenson")]#text("). However, it turns out that one can use the boundary constraint and topological arguments to prevent this from happening. We first need a topological lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Topological lemma)")]#text(" ")#metadata(none) <tao-28720365c5e7476a011e>#text(" Let ")#mi("{U, V}")#text(" be bounded connected open subsets of ")#mi("{{\\bf C}}")#text(" with ")#mi("{V}")#text(" simply connected, and let ")#mi("{f: \\overline{U} \\rightarrow \\overline{V}}")#text(" be a continuous map such that ")#mi("{f(\\partial U) \\subset \\partial V}")#text(" and ")#mi("{f(U) \\subset V}")#text(". Suppose furthermore that the restriction of ")#mi("{f}")#text(" to ")#mi("{U}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Local_homeomorphism")[#text("local homeomorphism")]#text(". Then ")#mi("{f}")#text(" is in fact a global homeomorphism from ")#mi("{U}")#text(" to ")#mi("{V}")#text(".")
]

#text("The requirement that the restriction of ")#mi("{f}")#text(" to ")#mi("{U}")#text(" be a local homeomorphism can in fact be relaxed to local injectivity thanks to the ")#link("https://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain theorem")]#text(". The complex numbers ")#mi("{{\\bf C}}")#text(" can be replaced here by any finite-dimensional manifold.")

#emph[#text("Proof:")]#text(" The preimage ")#mi("{f^{-1}(p)}")#text(" of any point ")#mi("{p}")#text(" in the interior of ")#mi("{V}")#text(" is closed, discrete, and disjoint from ")#mi("{\\partial U}")#text(", and is hence finite. Around each point in the preimage, there is a neighbourhood on which ")#mi("{f}")#text(" is a homeomorphism onto a neighbourhood of ")#mi("{p}")#text(". If one deletes the closure of these neighbourhoods, the image under ")#mi("{f}")#text(" is compact and avoids ")#mi("{p}")#text(", and thus avoids a neighbourhood of ")#mi("{p}")#text(". From this we can show that ")#mi("{f}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Covering_space")[#text("covering map")]#text(" from ")#mi("{U}")#text(" to ")#mi("{V}")#text(". As the base ")#mi("{V}")#text(" is simply connected, it is its own ")#link("https://en.wikipedia.org/wiki/Universal_cover")[#text("universal cover")]#text(", and hence (by the connectedness of ")#mi("{U}")#text(") ")#mi("{f}")#text(" must be a homeomorphism as claimed. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17")]#text(" Suppose we assign a radius ")#mi("{\\tilde r_w \\in (0,+\\infty]}")#text(" to each ")#mi("{w \\in V \\backslash \\{v\\}}")#text(" that obeys the local constraint (i) and the boundary constraint (ii). Then there is a hyperbolic circle packing ")#mi("{(C(\\tilde p_w, \\tilde r_w))_{w \\in V \\backslash \\{v\\}}}")#text(" with nerve ")#mi("{G - \\{v\\}}")#text(" and the indicated radii.")
]

#emph[#text("Proof:")]#text(" We first create the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" associated with the required hyperbolic circle packing, and then verify that this indeed arises from a circle packing.")

#text("Start with a single triangle ")#mi("{(w^0_1,w^0_2,w^0_3)}")#text(" in ")#mi("{G - \\{v\\}}")#text(", and arbitrarily select a ")#mi("{(\\tilde r_{w^0_1}, \\tilde r_{w^0_2}, \\tilde r_{w^0_3})}")#text("-triangle ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w^0_1,w^0_2,w^0_3)}")#text(" with the same orientation as ")#mi("{\\Delta_{{\\mathcal C}}(w_1,w_2,w_3)}")#text(". By Exercise ")#link(<tao-91e235e3f8168853b4d9>)[#text("15")]#text("(i), such a triangle exists (and is unique up to Möbius automorphisms of the disk). If a hyperbolic triangle ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" has been fixed, and ")#mi("{(w_2,w_3,w_4)}")#text(" (say) is an adjacent triangle in ")#mi("{G - \\{v\\}}")#text(", we can select ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_2,w_3,w_4)}")#text(" to be the unique ")#mi("{(r_{w_2}, r_{w_3}, r_{w_4})}")#text("-triangle with the same orientation as ")#mi("{\\Delta_{{\\mathcal C}}(w_2,w_3,w_4)}")#text(" that shares the ")#mi("{w_2,w_3}")#text(" side in common with ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" (with the ")#mi("{w_2}")#text(" and ")#mi("{w_3}")#text(" vertices agreeing). Similarly for other permutations of the labels. As ")#mi("{G}")#text(" is a maximal planar graph with ")#mi("{v}")#text(" non-degenerate (so in particular the set of internal vertices is connected), we can continue this construction to eventually fix every triangle in ")#mi("{G - \\{v\\}}")#text(". There is the potential issue that a given triangle ")#mi("{\\Delta_{{\\mathcal C}}(w_1,w_2,w_3)}")#text(" may depend on the order in which one arrives at that triangle starting from ")#mi("{(w^0_1,w^0_2,w^0_3)}")#text(", but one can check from a monodromy argument (in the spirit of the ")#link("https://en.wikipedia.org/wiki/Monodromy_theorem")[#text("monodromy theorem")]#text(") using the local constraint (i) and the simply connected nature of the triangulation associated to ")#mi("{{\\mathcal C}}")#text(" that there is in fact no dependence on the order. (The process resembles that of laying down jigsaw pieces in the shape of hyperbolic triangles together, with the local constraint ensuring that there is always a flush fit locally.)")

#text("Now we show that the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" have disjoint interiors inside the disk ")#mi("{D(0,1)}")#text(". Let ")#mi("{X}")#text(" denote the topological space formed by taking the disjoint union of the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" (now viewed as abstract topological spaces rather than subsets of the disk) and then gluing together all common edges, e.g. identifying the ")#mi("{\\{w_2,w_3\\}}")#text(" edge of ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" with the same edge of ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_2,w_3,w_4)}")#text(" if ")#mi("{(w_1,w_2,w_3)}")#text(" and ")#mi("{(w_2,w_3,w_4)}")#text(" are adjacent triangles in ")#mi("{G - \\{v\\}}")#text(". This space is homeomorphic to the union of the original hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(", and is thus homeomorphic to the closed unit disk. There is an obvious projection map ")#mi("{\\pi}")#text(" from ")#mi("{X}")#text(" to the union of the ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(", which maps the abstract copy in ")#mi("{X}")#text(" of a given hyperbolic triangle ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" to its concrete counterpart in ")#mi("{\\overline{D(0,1)}}")#text(" in the obvious fashion. This map is continuous. It does not quite cover the full closed disk, mainly because (by the boundary condition (ii)) the boundary hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(v_i,v_{i+1},w)}")#text(" touch the boundary of the disk at the vertices associated to ")#mi("{v_i}")#text(" and ")#mi("{v_{i+1}}")#text(" but do not follow the boundary arc connecting these vertices, being bounded instead by the geodesic from the ")#mi("{v_i}")#text(" vertex to the ")#mi("{v_{i+1}}")#text(" vertex; the missing region is a ")#link("https://en.wikipedia.org/wiki/Lens_(geometry)")[#text("lens")]#text("-shaped region bounded by two circular arcs. However, by applying another homeomorphism (that does not alter the edges from ")#mi("{v_i}")#text(" to ")#mi("{w}")#text(" or ")#mi("{v_{i+1}}")#text(" to ")#mi("{w}")#text("), one can “push out” the ")#mi("{\\{v_i,v_{i+1}\\}}")#text(" edge of this hyperbolic triangle across the lens to become the boundary arc from ")#mi("{v_i}")#text(" to ")#mi("{v_{i+1}}")#text(". If one performs this modification for each boundary triangle, one arrives at a modified continuous map ")#mi("{\\tilde \\pi}")#text(" from ")#mi("{X}")#text(" to ")#mi("{\\overline{D(0,1)}}")#text(", which now has the property that the boundary of ")#mi("{X}")#text(" maps to the boundary of the disk, and the interior of ")#mi("{X}")#text(" maps to the interior of the disk. Also one can check that this map is a local homeomorphism. By Lemma ")#link(<tao-28720365c5e7476a011e>)[#text("16")]#text(", ")#mi("{\\tilde \\pi}")#text(" is injective. (One can view ")#mi("{X}")#text(" as a closed and bounded subset of a surface.) Thus the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" have disjoint interiors, andfor each boundary triangle ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(v_i,v_{i+1},w)}")#text(", the lens-shaped regions between the boundary arc between the vertices associated to ")#mi("{v_i, v_{i+1}}")#text(" and the corresponding edge of the boundary triangle are also disjoint from the hyperbolic triangles and from each other. Each vertex ")#mi("{w}")#text(" in ")#mi("{G - \\{v\\}}")#text(" is associated with a vertex ")#mi("{\\tilde p_w}")#text(" in ")#mi("{X}")#text(" (or in ")#mi("{D(0,1)}")#text("), and we can associate a unique circle ")#mi("{C(\\tilde p_w,\\tilde r_w)}")#text(" with the specified radius which obeys the required tangencies. This is obvious for interior vertices ")#mi("{w}")#text(" where the radius is finite; for boundary vertices ")#mi("{w}")#text(", we see that for every triangle ")#mi("{ww_1w_2}")#text(" containing ")#mi("{w}")#text(" there is a unique candidate for the horocycle ")#mi("{C(\\tilde p_w, \\infty)}")#text(" that is tangent to the circles from ")#mi("{w_1,w_2}")#text(" (recall that at least one of ")#mi("{w_1,w_2}")#text(" must be interior), and by comparing adjacent triangles we see that the associated candidate horocycles must match, so there is a well defined horocycle to attach to each boundary vertex. All of the hyperbolic circles ")#mi("{C(\\tilde p_w, \\tilde r_w)}")#text(" and their interiors are contained in the union of the hyperbolic triangles ")#mi("{\\Delta_{\\tilde {\\mathcal C}}(w_1,w_2,w_3)}")#text(" and the lens-shaped regions, with each hyperbolic triangle containing portions only of the hyperbolic circles with hyperbolic centres at the vertices of the triangle, and similarly for the lens-shaped regions. From this one can verify that the interiors of the hyperbolic circles are all disjoint from each other, and give a hyperbolic circle packing with the required properties. ")#mi("\\Box")

#text("In view of the above proposition, the only remaining task is to find an assignment of radii ")#mi("{(\\tilde r_w)_{w \\in V \\backslash \\{v\\}}}")#text(" obeying both the local condition (i) and the boundary condition (ii). This is analogous to finding a harmonic function with specified boundary data. To do this, we perform the following analogue of Perron’s method. Define a ")#emph[#text("subpacking")]#text(" to be an assignment ")#mi("{(\\tilde r_w)_{w \\in V \\backslash \\{v\\}}}")#text(" of radii ")#mi("{\\tilde r_w \\in (0,+\\infty]}")#text(" obeying the following")

#list(
[#text("(i’) (Local sub-condition) The angles ")#mi("{\\alpha_1( \\tilde r_w, \\tilde r_{w_1}, \\tilde r_{w_2})}")#text(" around any given interior vertex ")#mi("{w}")#text(" sum to at least ")#mi("{2\\pi}")#text(".")]
)

#text("This can be compared with the definition of a (smooth) ")#link("https://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonic function")]#text(" as one where the Laplacian is always at least zero. Note that we always have at least one subpacking, namely the one provided by the radii of the original hyperbolic circle packing ")#mi("{{\\mathcal C}}")#text(". Intuitively, in each subpacking, the radius ")#mi("{\\tilde r_w}")#text(" at an interior vertex ")#mi("{w}")#text(" is either “too small” or “just right”.")#linebreak()#text(" We now need a key monotonicity property, analogous to how the maximum of two subharmonic functions is again subharmonic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Monotonicity)")]#text(" ")#metadata(none) <tao-d7de34b17b4691aa77ab>

#list(
[#text("(i) Show that the angle ")#mi("{\\alpha_1( r_1, r_2, r_3)}")#text(" (as defined in Exercise ")#link(<tao-91e235e3f8168853b4d9>)[#text("15")]#text("(i)) is strictly decreasing in ")#mi("{r_1}")#text(" and (when ")#mi("{r_1}")#text(" is finite) strictly increasing in ")#mi("{r_2}")#text(" or ")#mi("{r_3}")#text(" (if one holds the other two radii fixed). Do these claims agree with your geometric intuition?")],
[#text("(ii) Conclude that whenever ")#mi("{{\\mathcal R}^{\\prime} = (r^{\\prime}_w)_{w \\in V \\backslash \\{v\\}}}")#text(" and ")#mi("{{\\mathcal R}^{\\prime\\prime} = (r^{\\prime\\prime}_w)_{w \\in V \\backslash \\{v\\}}}")#text(" are subpackings, that ")#mi("{\\max( {\\mathcal R}^{\\prime} , {\\mathcal R}^{\\prime\\prime} ) := (\\max(r^{\\prime}_w, r^{\\prime\\prime}_w))_{w \\in V \\backslash \\{v\\}}}")#text(" is also a subpacking.")],
[#text("(iii) Let ")#mi("{(r_1,r_2,r_3), (r^{\\prime}_1,r^{\\prime}_2,r^{\\prime}_3) \\in T}")#text(" be such that ")#mi("{r_i \\leq r^{\\prime}_i}")#text(" for ")#mi("{i=1,2,3}")#text(". Show that ")#mi("{\\mathrm{Area}(r_1,r_2,r_3) \\leq \\mathrm{Area}(r^{\\prime}_1,r^{\\prime}_2,r^{\\prime}_3)}")#text(", with equality if and only if ")#mi("{r_i=r^{\\prime}_i}")#text(" for all ")#mi("{i=1,2,3}")#text(". (")#emph[#text("Hint:")]#text(" increase just one of the radii ")#mi("{r_1,r_2,r_3}")#text(". One can either use calculus (after first disposing of various infinite radii cases) or one can argue geometrically.)")]
)
]

#text("As with Perron’s method, we can now try to construct a hyperbolic circle packing by taking the supremum of all the subpackings. To avoid degeneracies we need an upper bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19 (Upper bound)")]#text(" Let ")#mi("{(\\tilde r_w)_{w \\in V \\backslash \\{v\\}}}")#text(" be a subpacking. Then for any interior vertex ")#mi("{w}")#text(" of degree ")#mi("{d}")#text(", one has ")#mi("{\\tilde r_w \\leq \\sqrt{d}}")#text(".")
]

#text("The precise value of ")#mi("{\\sqrt{d}}")#text(" is not so important for our arguments, but the fact that it is finite will be. This boundedness of interior circles in a circle packing is a key feature of hyperbolic geometry that is not present in Euclidean geometry, and is one of the reasons why we moved to a hyperbolic perspective in the first place.")

#emph[#text("Proof:")]#text(" By the subpacking property and pigeonhole principle, there is a triangle ")#mi("{w, w_1, w_2}")#text(" in ")#mi("{G - \\{v\\}}")#text(" such that ")#mi("{\\alpha_1(w,w_1,w_2) \\geq \\frac{2\\pi}{d}}")#text(". The hyperbolic triangle associated to ")#mi("{(w_1,w_2,w_3)}")#text(" has area at most ")#mi("{\\pi}")#text(" by ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("(2)")]#text("; on the other hand, it contains a sector of a hyperbolic circle of radius ")#mi("{\\tilde r_w}")#text(" and angle ")#mi("{\\frac{2\\pi}{d}}")#text(", and hence has area at least ")#mi("{\\frac{1}{d} 4\\pi \\sinh^2(r/2) \\geq \\frac{\\pi r^2}{d}}")#text(", thanks to Exercise ")#link(<tao-91e235e3f8168853b4d9>)[#text("15")]#text("(iii). Comparing the two bounds gives the claim. ")#mi("\\Box")

#text("Now define ")#mi("{{\\mathcal R} = ( \\tilde r_w )_{w \\in V \\backslash \\{v\\}}}")#text(" to be the (pointwise) supremum of all the subpackings. By the above proposition, ")#mi("{\\tilde r_w}")#text(" is finite at every interior vertex. By Exercise ")#link(<tao-d7de34b17b4691aa77ab>)[#text("18")]#text(", one can view ")#mi("{{\\mathcal R}}")#text(" as a monotone increasing limit of subpackings, and is thus again a subpacking (due to the continuity properties of ")#mi("{\\alpha_1}")#text(" as long as at least one of the radii stays bounded); thus ")#mi("{{\\mathcal R}}")#text(" is the maximal subpacking. On the other hand, if ")#mi("{\\tilde r_w}")#text(" is finite at some boundary vertex, then by Exercise ")#link(<tao-d7de34b17b4691aa77ab>)[#text("18")]#text("(i) one could replace that radius by a larger quantity without destroying the subpacking property, contradicting the maximality of ")#mi("{{\\mathcal R}}")#text(". Thus all the boundary radii are infinite, that is to say the boundary condition (ii) holds. Finally, if the sum of the angles at an interior vertex ")#mi("{w}")#text(" is strictly greater than ")#mi("{\\pi}")#text(", then by Exercise ")#link(<tao-d7de34b17b4691aa77ab>)[#text("18")]#text(" we could increase the radius at this vertex slightly without destroying the subpacking property at ")#mi("{w}")#text(" or at any other of the interior vertices, again contradicting the maximality of ")#mi("{{\\mathcal R}}")#text(". Thus ")#mi("{{\\mathcal R}}")#text(" obeys the local condition (i), and we have demonstrated existence of the required hyperbolic circle packing.")

#text("Finally we establish uniqueness. It suffices to establish that ")#mi("{{\\mathcal R}}")#text(" is the unique tuple that obeys the local condition (i) and the boundary condition (ii). Suppose we had another tuple ")#mi("{{\\mathcal R}^{\\prime} = ( r^{\\prime}_w )_{w \\in V \\backslash \\{v\\}}}")#text(" other than ")#mi("{{\\mathcal R}}")#text(" that obeyed these two conditions. Then by the maximality of ")#mi("{{\\mathcal R}}")#text(", we have ")#mi("{r^{\\prime}_w \\leq \\tilde r_w}")#text(" for all ")#mi("{w}")#text(". By Exercise ")#link(<tao-d7de34b17b4691aa77ab>)[#text("18")]#text("(iii), this implies that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Area}( r^{\\prime}_{w_1}, r^{\\prime}_{w_2}, r^{\\prime}_{w_3} ) \\leq \\mathrm{Area}( \\tilde r_{w_1}, \\tilde r_{w_2}, \\tilde r_{w_3} )")]]

#text("for any triangle ")#mi("{(w_1,w_2,w_3)}")#text(" in ")#mi("{T}")#text(". Summing over all triangles and using ")#link(<tao-4a91ee5f0106c2b35c11>)[#text("(2)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{w \\in V \\backslash \\{v\\}} \\sum_{w_1,w_2: (w,w_1,w_2) \\text{ triangle}} \\alpha_1(r^{\\prime}_{w}, r^{\\prime}_{w_1}, r^{\\prime}_{w_2})")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\sum_{w \\in V \\backslash \\{v\\}} \\sum_{w_1,w_2: (w,w_1,w_2) \\text{ triangle}} \\alpha_1(\\tilde r_{w}, \\tilde r_{w_1}, \\tilde r_{w_2})")]]

#text("where the inner sum is over the pairs ")#mi("{w_1,w_2}")#text(" such that ")#mi("{(w,w_1,w_2)}")#text(" forms a triangle in ")#mi("{G - \\{v\\}}")#text(". But by the local condition (i) and the boundary condition (ii), the inner sum on either side is equal to ")#mi("{2\\pi}")#text(" for an interior vertex and ")#mi("{0}")#text(" for a boundary vertex. Thus the two sides agree, which by Exercise ")#link(<tao-d7de34b17b4691aa77ab>)[#text("18")]#text("(iii) implies that ")#mi("{r^{\\prime}_w = \\tilde r_w}")#text(" for all ")#mi("{w}")#text(". This proves Theorem ")#link(<tao-e282e7f23047a4bf856d>)[#text("14")]#text(" and thus Theorems ")#link(<tao-0b9cf00a584ce9ac5bd6>)[#text("7")]#text(", ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(", ")#link(<tao-5455fc3fb94cf1d5cac4>)[#text("4")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Quasiconformal maps — ")]]

#text("In this section we set up some of the foundational theory of quasiconformal mapping, which are generalisations of the conformal mapping concept that can tolerate some deviations from perfect conformality, while still retaining many of the good properties of conformal maps (such as being preserved under uniform limits), though with the notable caveat that in contrast to conformal maps, quasiconformal maps need not be smooth. As such, this theory will come in handy when proving convergence of circle packings to the Riemann map. The material here is largely drawn from the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=344463")[#text("text of Lehto and Virtanen")]#text(".")

#text("We first need the following refinement of the Riemann mapping theorem, known as ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_theorem")[#text("Carathéodory’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 20 (Carathéodory’s theorem)")]#text(" ")#metadata(none) <tao-b2cf1df0cc2719c5d2bd>#text(" Let ")#mi("{U}")#text(" be a bounded simply connected domain in ")#mi("{{\\bf C}}")#text(" whose boundary ")#mi("{\\partial U}")#text(" is a Jordan curve, and let ")#mi("{\\phi: D(0,1) \\rightarrow U}")#text(" be a conformal map between ")#mi("{D(0,1)}")#text(" and ")#mi("{U}")#text(" (as given by the Riemann mapping theorem). Then ")#mi("{\\phi}")#text(" extends to a continuous homeomorphism from ")#mi("{\\overline{D}(0,1)}")#text(" to ")#mi("{\\overline{U}}")#text(".")
]

#text("The condition that ")#mi("{\\partial U}")#text(" be a Jordan curve is clearly necessary, since if ")#mi("{\\partial U}")#text(" is not simple then there are paths in ")#mi("{D(0,1)}")#text(" that end up at different points in ")#mi("{\\partial D(0,1)}")#text(" but have the same endpoint in ")#mi("{\\partial U}")#text(" after applying ")#mi("{\\phi}")#text(", which prevents ")#mi("{\\phi}")#text(" being continuously extended to a homeomorphism. If one relaxes the requirement that ")#mi("{\\partial U}")#text(" be a Jordan curve to the claim that ")#mi("{{\\bf C} \\backslash U}")#text(" is locally connected, then it is possible to modify this argument to still obtain a continuous extension of ")#mi("{U}")#text(" to ")#mi("{\\overline{U}}")#text(", although the extension will no longer be necessarily a homeomorphism, but we will not prove this fact here. We remark that Carathéodory’s theorem immediately implies as a corollary the ")#link("https://en.wikipedia.org/wiki/Schoenflies_problem")[#text("Jordan-Schoenflies theorem")]#text(" that the closed region enclosed by a Jordan curve is homeomorphic to the closed unit disk (with the interior being mapped to the interior, and similarly for the boundary).")

#emph[#text("Proof:")]#text(" We first prove continuous extension to the boundary. It suffices to show that for every point ")#mi("{\\zeta}")#text(" on the boundary of the unit circle, the diameters of the sets ")#mi("{\\phi( D(0,1) \\cap D( \\zeta, r_n ) )}")#text(" go to zero for some sequence of radii ")#mi("{r_n \\rightarrow 0}")#text(".")

#text("First observe from the change of variables formula that the area of ")#mi("{U = \\phi(D(0,1))}")#text(" is given by ")#tao-math("{\\int_{D(0,1)} \\left|\\phi^{\\prime}(z)\\right|^2\\ dx dy}", block: false)#text(", where ")#mi("{dx dy}")#text(" denotes Lebesgue measure (or the area element). In particular, this integral is finite. Expanding in polar coordinates around ")#mi("{\\zeta}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^2 \\left(\\int_{0}^{2\\pi} 1_{D(0,1)}(\\zeta+re^{i\\theta}) \\left|\\phi^{\\prime}( \\zeta + r e^{i\\theta} )\\right|^2\\ d \\theta\\right) r dr < \\infty.", block: true)]]

#text("Since ")#mi("{\\int_0^2 \\frac{dr}{r}}")#text(" diverges near ")#mi("{r=0}")#text(", we conclude from the pigeonhole principle that there exists a sequence of radii ")#mi("{0 < r_n < 2}")#text(" decreasing to zero such that")

#align(center)[#tao-fit-display[#tao-math("r_n^2 \\int_{0}^{2\\pi} 1_{D(0,1)}(\\zeta+r_ne^{i\\theta}) \\left|\\phi^{\\prime}( \\zeta + r_n e^{i\\theta} )\\right|^2\\ d \\theta \\rightarrow 0", block: true)]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#mitex("r_n \\int_{0}^{2\\pi} 1_{D(0,1)}(\\zeta+r_ne^{i\\theta}) |\\phi^{\\prime}( \\zeta + r_n e^{i\\theta} )|\\ d \\theta \\rightarrow 0")]]

#text("If we let ")#mi("{C_n}")#text(" denote the circular arc ")#mi("{\\{ \\zeta + r_n e^{i\\theta}: 0 \\leq \\theta \\leq 2\\pi \\} \\cap D(0,1)}")#text(", we conclude from this and the triangle inequality (and chain rule) that ")#mi("{\\phi(C_n)}")#text(" is a rectifiable curve with length going to zero as ")#mi("{n \\rightarrow \\infty}")#text(". Let ")#mi("{a_n, b_n}")#text(" denote the endpoints of this curve. Clearly they lie in ")#mi("{\\overline{U}}")#text(". If (say) ")#mi("{a_n}")#text(" was in ")#mi("{U}")#text(", then as ")#mi("{\\phi}")#text(" is a homeomorphism from ")#mi("{D(0,1)}")#text(" to ")#mi("{U}")#text(", ")#mi("{C_n}")#text(" would have one endpoint in ")#mi("{D(0,1)}")#text(" rather than ")#mi("{\\partial D(0,1)}")#text(", which is absurd. Thus ")#mi("{a_n}")#text(" lies in ")#mi("{\\partial U}")#text(", and similarly for ")#mi("{b_n}")#text(". Since the length of ")#mi("{\\phi(C_n)}")#text(" goes to zero, the distance between ")#mi("{a_n}")#text(" and ")#mi("{b_n}")#text(" goes to zero. Since ")#mi("{\\partial U}")#text(" is a Jordan curve, it can be parameterised homeomorphically by ")#mi("{\\partial D(0,1)}")#text(", and so by compactness we also see that the distance between the parameterisations of ")#mi("{a_n}")#text(" and ")#mi("{b_n}")#text(" in ")#mi("{\\partial D(0,1)}")#text(" must also go to zero, hence (by uniform continuity of the inverse parameterisation) ")#mi("{a_n}")#text(" and ")#mi("{b_n}")#text(" are connected along ")#mi("{\\partial U}")#text(" by an arc whose diameter goes to zero. Combining this arc with ")#mi("{\\phi(C_n)}")#text(", we obtain a Jordan curve of diameter going to zero which separates ")#mi("{\\phi(D(0,1) \\cap D(\\zeta, r_n))}")#text(" from the rest of ")#mi("{U}")#text(". Sending ")#mi("{n}")#text(" to infinity, we see that ")#mi("{\\phi(D(0,1) \\cap D(\\zeta, r_n))}")#text(" (which decreases with ")#mi("{n}")#text(") must eventually map in the interior of this curve rather than the exterior, and so the diameter goes to zero as claimed.")#linebreak()#text(" The above construction shows that ")#mi("{\\phi}")#text(" extends to a continuous map (which by abuse of notation we continue to call ")#mi("{\\phi}")#text(") from ")#mi("{\\overline{D(0,1)}}")#text(" to ")#mi("{\\overline{U}}")#text(", and the proof also shows that ")#mi("{\\partial D(0,1)}")#text(" maps to ")#mi("{\\partial U}")#text(". As ")#mi("{\\phi(\\overline{D(0,1)})}")#text(" is a compact subset of ")#mi("{\\overline{U}}")#text(" that contains ")#mi("{U}")#text(", it must surject onto ")#mi("{\\overline{U}}")#text(". As both ")#mi("{\\overline{D(0,1)}}")#text(" and ")#mi("{\\overline{U}}")#text(" are compact Hausdorff spaces, we will now be done if we can show injectivity. The only way injectivity can fail is if there are two distinct points ")#mi("{\\zeta,\\omega}")#text(" on ")#mi("{\\partial D(0,1)}")#text(" that map to the same point. Let ")#mi("{C}")#text(" be the line segment connecting ")#mi("{\\zeta}")#text(" with ")#mi("{\\omega}")#text(", then ")#mi("{\\phi(C)}")#text(" is a Jordan curve in ")#mi("{\\overline{U}}")#text(" that meets ")#mi("{\\partial U}")#text(" only at ")#mi("{\\phi(\\zeta) = \\phi(\\omega)}")#text(". ")#mi("{C}")#text(" divides ")#mi("{\\overline{D(0,1)}}")#text(" into two regions; one of which must map to the interior of ")#mi("{\\phi(C)}")#text(", which implies that there is an entire arc of ")#mi("{\\partial D(0,1)}")#text(" which maps to the single point ")#mi("{\\phi(\\zeta)=\\phi(\\omega)}")#text(". But then by the ")#link("https://en.wikipedia.org/wiki/Schwarz_reflection_principle")[#text("Schwarz reflection principle")]#text(", ")#mi("{\\phi}")#text(" extends conformally across this arc and is constant in a non-isolated set, thus is constant everywhere by analytic continuation, which is absurd. This establishes the required injectivity. ")#mi("\\Box")

#text("This has the following consequence. Define a ")#emph[#text("Jordan quadrilateral")]#text(" to be the open region ")#mi("{Q}")#text(" enclosed by a Jordan curve with four distinct marked points ")#mi("{p_1,p_2,p_3,p_4}")#text(" on it in counterclockwise order, which we call the ")#emph[#text("vertices")]#text(" of the quadrilateral. The arcs in ")#mi("{\\partial Q}")#text(" connecting ")#mi("{p_1}")#text(" to ")#mi("{p_2}")#text(" or ")#mi("{p_3}")#text(" to ")#mi("{p_4}")#text(" will be called the ")#emph[#mi("{a}")#text("-sides")]#text("; the arcs connecting ")#mi("{p_2}")#text(" to ")#mi("{p_3}")#text(" or ")#mi("{p_4}")#text(" to ")#mi("{p_1}")#text(" will be called ")#emph[#mi("{b}")#text("-sides")]#text(". (Thus for instance each cyclic permutation of the ")#mi("{p_1,p_2,p_3,p_4}")#text(" vertices will swap the ")#mi("{a}")#text("-sides and ")#mi("{b}")#text("-sides, while keeping the interior region ")#mi("{Q}")#text(" unchanged.) A key example of a Jordan quadrilateral are the (Euclidean) rectangles, in which the vertices ")#mi("{p_1,\\dots,p_4}")#text(" are the usual corners of the rectangle, traversed counterclockwise. The ")#mi("{a}")#text("-sides then are line segments of some length ")#mi("{a}")#text(", and the ")#mi("{b}")#text("-sides are line segments of some length ")#mi("{b}")#text(" that are orthogonal to the ")#mi("{a}")#text("-sides. A ")#emph[#text("vertex-preserving conformal map")]#text(" from one Jordan quadrilateral ")#mi("{Q}")#text(" to another ")#mi("{Q^{\\prime}}")#text(" will be a conformal map that extends to a homeomorphism from ")#mi("{\\overline{Q}}")#text(" to ")#mi("{\\overline{Q^{\\prime}}}")#text(" that maps the corners of ")#mi("{Q}")#text(" to the respective corners of ")#mi("{Q^{\\prime}}")#text(" (in particular, ")#mi("{a}")#text("-sides get mapped to ")#mi("{a}")#text("-sides, and similarly for ")#mi("{b}")#text("-sides).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{Q}")#text(" be a Jordan quadrilateral with vertices ")#mi("{p_1,p_2,p_3,p_4}")#text(".")

#list(
[#text("(i) Show that there exists ")#mi("{r > 1}")#text(" and a conformal map ")#mi("{\\phi: Q \\rightarrow \\mathbf{H}}")#text(" to the upper half-plane ")#mi("{\\mathbf{H} := \\{ z: \\mathrm{Im} z > 0 \\}}")#text(" (viewed as a subset of the Riemann sphere) that extends continuously to a homeomorphism ")#mi("{\\phi: \\overline{Q} \\rightarrow \\overline{\\mathbf{H}}}")#text(" and which maps ")#mi("{p_1,p_2,p_3,p_4}")#text(" to ")#mi("{-r, -1, 1, r}")#text(" respectively. (")#emph[#text("Hint:")]#text(" first map ")#mi("{p_1,p_2,p_3,p_4}")#text(" to increasing elements of the real line, then use the intermediate value theorem to enforce ")#mi("{\\phi(p_1)+\\phi(p_4) = \\phi(p_2)+\\phi(p_3)}")#text(".)")],
[#text("(ii) Show that there is a vertex-preserving conformal map ")#mi("{\\psi: Q \\rightarrow R}")#text(" from ")#mi("{Q}")#text(" to a rectangle ")#mi("{R}")#text(". (")#emph[#text("Hint:")]#text(" use ")#link("https://en.wikipedia.org/wiki/Schwarz%E2%80%93Christoffel_mapping")[#text("Schwarz-Christoffel mapping")]#text(".)")],
[#text("(iii) Show that the rectangle ")#mi("{R}")#text(" in part (ii) is unique up to affine transformations. (")#emph[#text("Hint:")]#text(" if one has a conformal map between rectangles that preserves the vertices, extend it via repeated use of the Schwarz reflection principle to an entire map.)")]
)
]

#text("This allows for the following definition: the ")#emph[#text("conformal modulus")]#text(" ")#mi("{\\mathrm{mod}(Q)}")#text(" (or ")#emph[#text("modulus")]#text(" for short, also called ")#emph[#text("module")]#text(" in older literature) of a Jordan quadrilateral with vertices ")#mi("{p_1,p_2,p_3,p_4}")#text(" is the ratio ")#mi("{b/a}")#text(", where ")#mi("{a,b}")#text(" are the lengths of the ")#mi("{a}")#text("-sides and ")#mi("{b}")#text("-sides of a rectangle ")#mi("{R}")#text(" that is conformal to ")#mi("{Q}")#text(" in a vertex-preserving vashion.. This is a number between ")#mi("{0}")#text(" and ")#mi("{\\infty}")#text("; each cyclic permutation of the vertices replaces the modulus with its reciprocal. It is clear from construction that the modulus of a Jordan quadrilateral is unaffected by vertex-preserving conformal transformations.")

#text("Now we define quasiconformal maps. Informally, conformal maps are homeomorphisms that map infinitesimal circles to infinitesimal circles; quasiconformal maps are homeomorphisms that map infinitesimal circles to curves that differ from an infinitesimal circle by “bounded distortion”. However, for the purpose of setting up the foundations of the theory, it is slightly more convenient to work with rectangles instead of circles (it is easier to partition rectangles into subrectangles than disks into subdisks). We therefore introduce")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 22")]#text(" Let ")#mi("{K \\geq 1}")#text(". An orientation-preserving homeomorphism ")#mi("{\\phi: U \\rightarrow V}")#text(" between two domains ")#mi("{U,V}")#text(" in ")#mi("{{\\bf C}}")#text(" is said to be ")#emph[#mi("{K}")#text("-quasiconformal")]#text(" if one has ")#mi("{\\mathrm{mod}(\\phi(Q)) \\leq K \\mathrm{mod}(Q)}")#text(" for every Jordan quadrilateral ")#mi("{Q}")#text(" in ")#mi("{U}")#text(". (In these notes, we do not consider orientation-reversing homeomorphisms to be quasiconformal.)")
]

#text("Note that by cyclically permuting the vertices of ")#mi("{Q}")#text(", we automatically also obtain the inequality")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\mathrm{mod}(\\phi(Q))} \\leq K \\frac{1}{\\mathrm{mod}(Q)}")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{K} \\mathrm{mod}(Q) \\leq \\mathrm{mod}(\\phi(Q))")]]

#text("for any Jordan quadrilateral. Thus it is not possible to have any ")#mi("{K}")#text("-quasiconformal maps for ")#mi("{K<1}")#text(" (excluding the degenerate case when ")#mi("{U,V}")#text(" are empty), and a map is ")#mi("{1}")#text("-quasiconformal if and only if it preserves the modulus. In particular, conformal maps are ")#mi("{1}")#text("-quasiconformal; we will shortly establish that the converse claim is also true. It is also clear from the definition that the inverse of a ")#mi("{K}")#text("-quasiconformal map is also ")#mi("{K}")#text("-quasiconformal, and the composition of a ")#mi("{K}")#text("-quasiconformal map and a ")#mi("{K^{\\prime}}")#text("-quasiconformal map is a ")#mi("{KK^{\\prime}}")#text("-quasiconformal map.")#linebreak()#text(" It is helpful to have an alternate characterisation of the modulus that does not explicitly mention conformal mapping:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 23 (Alternate definition of modulus)")]#text(" ")#metadata(none) <tao-e6b54572dcc68f644f53>#text(" Let ")#mi("{Q}")#text(" be a Jordan quadrilateral with vertices ")#mi("{p_1,p_2,p_3,p_4}")#text(". Then ")#mi("{\\mathrm{mod}(Q)}")#text(" is the smallest quantity with the following property: for any Borel measurable ")#mi("{\\rho: Q \\rightarrow [0,+\\infty)}")#text(" one can find a curve ")#mi("{\\gamma}")#text(" in ")#mi("{Q}")#text(" connecting one ")#mi("{a}")#text("-side of ")#mi("{Q}")#text(" to another, and which is locally rectifiable away from endpoints, such that")

#align(center)[#tao-fit-display[#tao-math("\\left(\\int_\\gamma \\rho(z)\\ \\left|dz\\right|\\right)^2 \\leq \\mathrm{mod}(Q) \\int_Q \\rho^2(z)\\ dx dy", block: true)]]

#text("where ")#tao-math("{\\int_\\gamma \\left|dz\\right|}", block: false)#text(" denotes integration using the length element of ")#mi("{\\gamma}")#text(" (not to be confused with the contour integral ")#mi("{\\int_\\gamma\\ dz}")#text(").")
]

#text("The reciprocal of this notion of modulus generalises to the concept of ")#link("https://en.wikipedia.org/wiki/Extremal_length")[#text("extremal length")]#text(", which we will not develop further here.")

#emph[#text("Proof:")]#text(" Observe from the change of variables formula that if ")#mi("{\\phi: Q \\rightarrow Q^{\\prime}}")#text(" is a vertex-preserving conformal mapping between Jordan quadrilaterals ")#mi("{Q,Q^{\\prime}}")#text(", and ")#mi("{\\gamma}")#text(" is a locally rectifiable curve connecting one ")#mi("{a}")#text("-side of ")#mi("{Q}")#text(" to another, then ")#mi("{\\phi \\circ \\gamma}")#text(" is a locally rectifiable curve connecting one ")#mi("{a}")#text("-side of ")#mi("{Q^{\\prime}}")#text(" to another, with")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\phi \\circ \\gamma} \\rho \\circ \\phi^{-1}(w) \\ \\left|dw\\right| = \\int_\\gamma \\rho(z) |\\phi^{\\prime}(z)|\\ \\left|dz\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_{Q^{\\prime}} \\left|\\rho \\circ \\phi^{-1}(w)\\right|^2\\ dx dy = \\int_Q \\left|\\rho(z)\\right|^2 \\left|\\phi^{\\prime}(z)\\right|^2\\ dx dy.", block: true)]]

#text("As a consequence, if the proposition holds for ")#mi("{Q}")#text(" it also holds for ")#mi("{Q^{\\prime}}")#text(". Thus we may assume without loss of generality that ")#mi("{Q}")#text(" is a rectangle, which we may normalise to be ")#mi("{\\{ x+iy: 0 \\leq y \\leq 1; 0 \\leq x \\leq M \\}}")#text(" with vertices ")#mi("{i, 0, M, M+i}")#text(", so that the modulus is ")#mi("{M}")#text(". For any measurable ")#mi("{\\rho: Q \\rightarrow [0,+\\infty)}")#text(", we have from Cauchy-Schwarz and Fubini’s theorem that")

#tao-aligned(keep: true)[


#tao-math("\\int_0^1 \\left(\\int_0^M \\rho(x+iy)\\ dx\\right)^2 dy  & \\leq M \\int_0^1 \\int_0^M \\rho^2(x+iy)\\ dx dy", block: true)



#tao-math(" & = M \\int_Q \\rho^2(z)\\ dx dy", block: true)
]

#text("and hence by the pigeonhole principle there exists ")#mi("{y}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\left(\\int_0^M \\rho(x+iy)\\ dx\\right)^2 \\leq M \\int_Q \\rho^2(z)\\ dx dy.")]]

#text("On the other hand, if we set ")#mi("{\\rho=1}")#text(", then ")#mi("{\\int_Q \\rho^2(z)\\ dx dy = M}")#text(", and for any curve ")#mi("{\\gamma}")#text(" connecting the ")#mi("{a}")#text("-side from ")#mi("{0}")#text(" to ")#mi("{i}")#text(" to the ")#mi("{a}")#text("-side from ")#mi("{M}")#text(" to ")#mi("{M+i}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_\\gamma \\rho\\ \\left|dz\\right| \\geq \\left| \\int_\\gamma \\rho\\ dx \\right| = M.", block: true)]]

#text("Thus ")#mi("{M}")#text(" is the best constant with the required property, proving the claim. ")#mi("\\Box")#linebreak()#text(" Here are some quick and useful consequences of this characterisation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Rengel’s inequality)")]#text(" ")#metadata(none) <tao-10efbd4f9f5e9bf9bacb>#text(" Let ")#mi("{Q}")#text(" be a Jordan quadrilateral of area ")#mi("{A}")#text(", let ")#mi("{b}")#text(" be the shortest (Euclidean) distance between a point on one ")#mi("{a}")#text("-side and a point on the other ")#mi("{a}")#text("-side, and similarly let ")#mi("{a}")#text(" be the shortest (Euclidean) distance between a point on one ")#mi("{b}")#text("-side and a point on the other ")#mi("{b}")#text("-side. Show that")

#align(center)[#tao-fit-display[#mitex("\\frac{b^2}{A} \\leq \\mathrm{mod}(Q) \\leq \\frac{A}{a^2}")]]

#text("and that equality in either case occurs if and only if ")#mi("{Q}")#text(" is a rectangle. (")#emph[#text("Hint:")]#text(" for the equality case, conformally map ")#mi("{Q}")#text(" back to a rectangle and use the change of variables analysis used to prove Proposition ")#link(<tao-e6b54572dcc68f644f53>)[#text("23")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Superadditivity)")]#text(" ")#metadata(none) <tao-66e85493fe2c9f303dfa>

#list(
[#text("(i) If ")#mi("{Q_1, Q_2}")#text(" are disjoint Jordan quadrilaterals that share a common ")#mi("{a}")#text("-side, and which can be glued together along this side to form a new Jordan quadrilateral ")#mi("{Q_1 \\cup Q_2}")#text(", show that ")#mi("{\\mathrm{mod}(Q_1 \\cup Q_2) \\geq \\mathrm{mod}(Q_1) + \\mathrm{mod}(Q_2)}")#text(". If equality occurs, show that after conformally mapping ")#mi("{Q_1 \\cup Q_2}")#text(" to a rectangle (in a vertex preserving fashion), ")#mi("{Q_1}")#text(", ")#mi("{Q_2}")#text(" are mapped to subrectangles (formed by cutting the original parallel to the ")#mi("{a}")#text("-side).")],
[#text("(ii) If ")#mi("{Q_1, Q_2}")#text(" are disjoint Jordan quadrilaterals that share a common ")#mi("{b}")#text("-side, and which can be glued together along this side to form a new Jordan quadrilateral ")#mi("{Q_1 \\cup Q_2}")#text(", show that ")#mi("{\\frac{1}{\\mathrm{mod}(Q_1 \\cup Q_2)} \\geq \\frac{1}{\\mathrm{mod}(Q_1)} + \\frac{1}{\\mathrm{mod}(Q_2)}}")#text(". If equality occurs, show that after conformally mapping ")#mi("{Q_1 \\cup Q_2}")#text(" to a rectangle (in a vertex preserving fashion), ")#mi("{Q_1}")#text(", ")#mi("{Q_2}")#text(" are mapped to subrectangles (formed by cutting the original parallel to the ")#mi("{b}")#text("-side).")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Continuity from below)")]#text(" ")#metadata(none) <tao-ab8a1c796dbbdf684804>#text(" Suppose ")#mi("{Q_n}")#text(" is a sequence of Jordan quadrilaterals which converge to another Jordan quadrilateral ")#mi("{Q}")#text(", in the sense that the vertices of ")#mi("{Q_n}")#text(" converge to their respective counterparts in ")#mi("{Q}")#text(", each ")#mi("{a}")#text("-side in ")#mi("{Q_n}")#text(" converges (in the ")#link("https://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff sense")]#text(") to the ")#mi("{a}")#text("-side of ")#mi("{Q}")#text(", and the similarly for ")#mi("{b}")#text("-sides. Suppose also that ")#mi("{Q_n \\subset Q}")#text(" for all ")#mi("{n}")#text(". Show that ")#mi("{\\mathrm{mod}(Q_n)}")#text(" converges to ")#mi("{\\mathrm{mod}(Q)}")#text(". (")#emph[#text("Hint:")]#text(" map ")#mi("{Q}")#text(" to a rectangle and use Rengel’s inequality.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 27 (Local quasiconformality implies quasiconformality)")]#text(" Let ")#mi("{K \\geq 1}")#text(", and let ")#mi("{\\phi: U \\rightarrow V}")#text(" be an orientation-preserving homeomorphism between complex domains ")#mi("{U,V}")#text(" which is locally ")#mi("{K}")#text("-quasiconformal in the sense that for every ")#mi("{z_0 \\in U}")#text(" there is a neighbourhood ")#mi("{U_{z_0}}")#text(" of ")#mi("{z_0}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{\\phi}")#text(" is ")#mi("{K}")#text("-quasiconformal from ")#mi("{U_{z_0}}")#text(" to ")#mi("{\\phi(U_{z_0})}")#text(". Then ")#mi("{\\phi}")#text(" is ")#mi("{K}")#text("-quasiconformal.")
]

#emph[#text("Proof:")]#text(" We need to show that ")#mi("{\\mathrm{mod}(\\phi(Q)) \\leq K \\mathrm{mod}(Q)}")#text(" for any Jordan quadrilateral ")#mi("{Q}")#text(" in ")#mi("{U}")#text(". The hypothesis gives this claim for all quadrilaterals in the sufficiently small neighbourhood of any point in ")#mi("{U}")#text(". For any natural number ")#mi("{n}")#text(", we can subdivide ")#mi("{\\phi(Q)}")#text(" into ")#mi("{n}")#text(" quadrilaterals ")#mi("{\\phi(Q_1),\\dots,\\phi(Q_n)}")#text(" with modulus ")#mi("{\\frac{1}{n} \\mathrm{mod}(\\phi(Q))}")#text(" with adjacent ")#mi("{a}")#text("-sides, by first conformally mapping ")#mi("{\\phi(Q)}")#text(" to a rectangle and then doing an equally spaced vertical subdivision. Similarly, each quadrilateral ")#mi("{Q_i}")#text(" can be subdivided into ")#mi("{n}")#text(" quadrilaterals ")#mi("{Q_{i,1},\\dots,Q_{i,n}}")#text(" of modulus ")#mi("{n \\mathrm{mod}(Q_i)}")#text(" by mapping ")#mi("{Q_i}")#text(" to a rectangle and performing horizontal subdivision. By the local ")#mi("{K}")#text("-quasiconformality of ")#mi("{\\phi}")#text(", we will have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}( \\phi(Q_{i,j}) ) \\leq K \\mathrm{mod}( Q_{i,j} ) = K n \\mathrm{mod}(Q_i)")]]

#text("for all ")#mi("{i,j=1,\\dots,n}")#text(", if ")#mi("{n}")#text(" is large enough. By superadditivity this implies that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}( \\phi(Q_i) ) \\leq K\\mathrm{mod}(Q_i)")]]

#text("for each ")#mi("{i}")#text(", and hence")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}(Q_i) \\geq \\frac{1}{Kn} \\mathrm{mod}(\\phi(Q)).")]]

#text("Applying superadditivity again we obtain")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}(Q) \\geq \\frac{1}{K} \\mathrm{mod}(\\phi(Q)).")]]

#text("giving the claim. ")#mi("\\Box")#linebreak()#text(" We can now reverse the implication that conformal maps are ")#mi("{1}")#text("-quasiconformal:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 28")]#text(" ")#metadata(none) <tao-5788902e12c38ccbbe82>#text(" Every ")#mi("{1}")#text("-quasiconformal map ")#mi("{\\phi: U \\rightarrow V}")#text(" is conformal.")
]

#emph[#text("Proof:")]#text(" By covering ")#mi("{U}")#text(" by quadrilaterals we may assume without loss of generality that ")#mi("{U}")#text(" (and hence also ")#mi("{\\phi(U)=V}")#text(") is a Jordan quadrilateral; by composing on left and right with conformal maps we may assume that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are rectangles. As ")#mi("{\\phi}")#text(" is ")#mi("{1}")#text("-quasiconformal, the rectangles have the same modulus, so after a further affine transformation we may assume that ")#mi("{U=V}")#text(" is the rectangle with vertices ")#mi("{i, 0, M, M+i}")#text(" for some modulus ")#mi("{M}")#text(". If one subdivides ")#mi("{U}")#text(" into two rectangles along an intermediate vertical line segment connecting say ")#mi("{x}")#text(" to ")#mi("{x+i}")#text(" for some ")#mi("{0 < x < M}")#text(", the moduli of these rectangles are ")#mi("{x}")#text(" and ")#mi("{M-x}")#text(". Applying the ")#mi("{1}")#text("-quasiconformal map and the converse portion of Exercise ")#link(<tao-66e85493fe2c9f303dfa>)[#text("25")]#text(", we conclude that these rectangles must be preserved by ")#mi("{\\phi}")#text(", thus ")#mi("{\\phi}")#text(" preserves the ")#mi("{x}")#text(" coordinate. Similarly ")#mi("{\\phi}")#text(" preserves the ")#mi("{y}")#text(" coordinate, and is therefore the identity map, which is of course conformal. ")#mi("\\Box")

#text("Next, we can give a simple criterion for quasiconformality in the continuously differentiable case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 29")]#text(" ")#metadata(none) <tao-5d920e9810479476191a>#text(" Let ")#mi("{K \\geq 1}")#text(", and let ")#mi("{\\phi: U \\rightarrow V}")#text(" be an orientation-preserving diffeomorphism (a continuously (real) differentiable homeomorphism whose derivative is always nondegenerate) between complex domains ")#mi("{U,V}")#text(". Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\phi}")#text(" is ")#mi("{K}")#text("-quasiconformal.")],
[#text("(ii) For any point ")#mi("{z_0 \\in U}")#text(" and phases ")#tao-math("{v,w \\in S^1 := \\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|D_v \\phi(z_0)\\right| \\leq K\\left|D_w \\phi(z_0)\\right|", block: true)]]

#text("where ")#mi("{D_v \\phi(z_0) := \\frac{\\partial}{\\partial t} \\phi(z_0+tv)|_{t=0}}")#text(" denotes the directional derivative.")]
)
]

#emph[#text("Proof:")]#text(" Let us first show that (ii) implies (i). Let ")#mi("{Q}")#text(" be a Jordan quadrilateral in ")#mi("{U}")#text("; we have to show that ")#mi("{\\mathrm{mod}(\\phi(Q)) \\leq K \\mathrm{mod}(Q)}")#text(". From the chain rule one can check that condition (ii) is unchanged by composing ")#mi("{\\phi}")#text(" with conformal maps on the left or right, so we may assume without loss of generality that ")#mi("{Q}")#text(" and ")#mi("{\\phi(Q)}")#text(" are rectangles; in fact we may normalise ")#mi("{Q}")#text(" to have vertices ")#mi("{i, 0, T, T+i}")#text(" and ")#mi("{\\phi(Q)}")#text(" to have vertices ")#mi("{i, 0, T^{\\prime}, T^{\\prime}+i}")#text(" where ")#mi("{T = \\mathrm{mod}(Q)}")#text(" and ")#mi("{T^{\\prime} = \\mathrm{mod}(Q^{\\prime})}")#text(". From the change of variables formula (and the singular value decomposition), followed by Fubini’s theorem and Cauchy-Schwarz, we have")

#tao-aligned(keep: false)[


#tao-math("T^{\\prime}  & = \\int_{\\phi(Q)}\\ dx dy", block: true)



#tao-math(" & = \\int_Q \\mathrm{det}(D\\phi)(z)\\ dx dy", block: true)



#tao-math(" & = \\int_Q \\max_{v \\in S^1} \\left|D_v \\phi(z)\\right| \\min_{w \\in S^1} \\left|D_w \\phi(z)\\right|\\ dx dy", block: true)



#tao-math(" & \\geq \\int_Q \\frac{1}{K} \\left|\\frac{\\partial}{\\partial x} \\phi(z)\\right|^2\\ dx dy", block: true)



#tao-math(" & = \\frac{1}{K} \\int_0^1 \\int_0^T \\left|\\frac{\\partial}{\\partial x} \\phi(x+iy)\\right|^2\\ dx dy", block: true)



#tao-math(" & \\geq \\frac{1}{K T} \\int_0^1 \\left|\\int_0^T \\frac{\\partial}{\\partial x} \\mathrm{Re} \\phi(x+iy)\\ dx\\right|^2\\ dy", block: true)



#tao-math(" & = \\frac{1}{K T} \\int_0^1 (T^{\\prime})^2\\ dy", block: true)
]

#text("and hence ")#mi("{T^{\\prime} \\leq K T}")#text(", giving the claim.")#linebreak()#text(" Now suppose that (ii) failed, then by the singular value decomposition we can find ")#mi("{z_0 \\in U}")#text(" and a phase ")#mi("{v \\in S^1}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("D_{iv} \\phi(z_0) = i \\lambda D_v \\phi(z_0)")]]

#text("for some real ")#mi("{\\lambda}")#text(" with ")#mi("{\\lambda > K}")#text(". After translations and rotations we may normalise so that")

#align(center)[#tao-fit-display[#mitex("\\phi(0) = 0; \\frac{\\partial}{\\partial x} \\phi(0) = 1; \\frac{\\partial}{\\partial y} \\phi(0) = i\\lambda.")]]

#text("But then from Rengel’s inequality and Taylor expansion one sees that ")#mi("{\\phi}")#text(" will map a unit square with vertices ")#mi("{0, -\\varepsilon, -\\varepsilon+i\\varepsilon, i\\varepsilon}")#text(" to a quadrilateral of modulus converging to ")#mi("{\\lambda}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", contradicting (i). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Show that the conditions (i), (ii) in the above theorem are also equivalent to the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\partial}{\\partial \\overline{z}} \\phi(z_0)\\right| \\leq \\frac{K-1}{K+1} \\left|\\frac{\\partial }{\\partial z} \\phi(z_0)\\right|", block: true)]]

#text("for all ")#mi("{z_0 \\in U}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial }{\\partial z} := \\frac{1}{2} ( \\frac{\\partial }{\\partial x} - i \\frac{\\partial }{\\partial y}); \\quad \\frac{\\partial }{\\partial \\overline{z}} := \\frac{1}{2} ( \\frac{\\partial }{\\partial x} + i \\frac{\\partial }{\\partial y})")]]

#text("are the ")#link("https://en.wikipedia.org/wiki/Wirtinger_derivatives")[#text("Wirtinger derivatives")]#text(".")
]

#text("We now prove a technical regularity result on quasiconformal maps.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 31 (Absolute continuity on lines)")]#text(" Let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a ")#mi("{K}")#text("-quasiconformal map between two complex domains ")#mi("{U,V}")#text(" for some ")#mi("{K}")#text(". Suppose that ")#mi("{U}")#text(" contains the closed rectangle with endpoints ")#mi("{0, i, T+i, T}")#text(". Then for almost every ")#mi("{0 \\leq y \\leq 1}")#text(", the map ")#mi("{x \\mapsto \\phi(x+iy)}")#text(" is ")#link("https://en.wikipedia.org/wiki/Absolute_continuity")[#text("absolutely continuous")]#text(" on ")#mi("{[0,T]}")#text(".")
]

#emph[#text("Proof:")]#text(" For each ")#mi("{y}")#text(", let ")#mi("{A(y)}")#text(" denote the area of the image ")#mi("{\\{ \\phi(x+iy^{\\prime}): 0 \\leq x \\leq T; 0 \\leq y \\leq y^{\\prime}\\}}")#text(" of the rectangle with endpoints ")#mi("{0, iy, T+iy, T}")#text(". This is a bounded monotone function on ")#mi("{[0,1]}")#text(" and is hence differentiable almost everywhere. It will thus suffice to show that the map ")#mi("{x \\mapsto \\phi(x+iy)}")#text(" is absolutely continuous on ")#mi("{[0,T]}")#text(" whenever ")#mi("{y \\in (0,1)}")#text(" is a point of differentiability of ")#mi("{A}")#text(".")

#text("Let ")#mi("{\\varepsilon > 0}")#text(", and let ")#mi("{[x_1,x^{\\prime}_1],\\dots,[x_m,x^{\\prime}_m]}")#text(" be disjoint intervals in ")#mi("{[0,T]}")#text(" of total length ")#mi("{\\sum_{j=1}^m x^{\\prime}_j-x_j \\leq \\varepsilon}")#text(". To show absolute continuity, we need a bound on ")#tao-math("{\\sum_{j=1}^m \\left|\\phi(x^{\\prime}_j) - \\phi(x_j)\\right|}", block: false)#text(" that goes to zero as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" uniformly in the choice of intervals. Let ")#mi("{\\delta>0}")#text(" be a small number (that can depend on the intervals), and for each ")#mi("{j=1,\\dots,m}")#text(" let ")#mi("{R_j}")#text(" be the rectangle with vertices ")#mi("{x_j+i(y_j+\\delta)}")#text(", ")#mi("{x_j+iy}")#text(", ")#mi("{x^{\\prime}_j+iy}")#text(", ")#mi("{x^{\\prime}_j+i(y+\\delta)}")#text(" This rectangle has modulus ")#mi("{(x^{\\prime}_j-x_j)/\\delta}")#text(", and hence ")#mi("{\\phi(R_j)}")#text(" has modulus at most ")#mi("{K (x^{\\prime}_j-x_j)/\\delta}")#text(". On the other hand, by Rengel’s inequality this modulus is at least ")#tao-math("{\\left|\\phi(x^{\\prime}_j)-\\phi(x_j)-o(1)\\right|^2 / \\mathrm{Area}(\\phi(R_j))}", block: false)#text(", where ")#mi("{o(1)}")#text(" is a quantity that goes to zero as ")#mi("{\\delta \\rightarrow 0}")#text(" (holding the intervals fixed). We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\phi(x^{\\prime}_j)-\\phi(x_j)\\right|^2 \\leq \\frac{K}{\\delta} (x^{\\prime}_j-x_j) \\mathrm{Area}(\\phi(R_j)) + o(1).", block: true)]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^m \\mathrm{Area}(\\phi(R_j)) \\leq A(y+\\delta) - A(y) = (A^{\\prime}(y)+o(1)) \\delta.")]]

#text("By Cauchy-Schwarz, we thus have")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{j=1}^m \\left|\\phi(x^{\\prime}_j)-\\phi(x_j)\\right|)^2 \\leq K A^{\\prime}(y) \\sum_{j=1}^m (x^{\\prime}_j-x_j) + o(1);", block: true)]]

#text("sending ")#mi("{\\delta \\rightarrow 0}")#text(", we conclude")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j=1}^m \\left|\\phi(x^{\\prime}_j)-\\phi(x_j)\\right| \\leq K^{1/2} A^{\\prime}(y)^{1/2} \\varepsilon^{1/2}", block: true)]]

#text("giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-2c70237f50de15d265e6>#text(" Let ")#mi("{\\phi: U \\rightarrow V}")#text(" be a ")#mi("{K}")#text("-quasiconformal map between two complex domains ")#mi("{U,V}")#text(" for some ")#mi("{K}")#text(". Suppose that there is a closed set ")#mi("{S \\subset {\\bf C}}")#text(" of Lebesgue measure zero such that ")#mi("{\\phi}")#text(" is conformal on ")#mi("{U \\backslash S}")#text(". Show that ")#mi("{\\phi}")#text(" is ")#mi("{1}")#text("-quasiconformal (and hence conformal, by Proposition ")#link(<tao-5788902e12c38ccbbe82>)[#text("28")]#text("). (")#emph[#text("Hint:")]#text(" Arguing as in the proof of Theorem ")#link(<tao-5d920e9810479476191a>)[#text("29")]#text(", it suffices to show that of ")#mi("{\\phi}")#text(" maps the rectangle with endpoints ")#mi("{0, i, T+i, T}")#text(" to the rectangle with endpoints ")#mi("{0, i, T^{\\prime}+i, T^{\\prime}}")#text(", then ")#mi("{T^{\\prime} \\leq T}")#text(". Repeat the proof of that theorem, using the absolute continuity of lines at a crucial juncture to justify using the fundamental theorem of calculus.)")
]

#text("Recall ")#link("https://en.wikipedia.org/wiki/Hurwitz%27s_theorem_(complex_analysis)")[#text("Hurwitz’s theorem")]#text(" that the locally uniform limit of conformal maps is either conformal or constant. It turns out there is a similar result for quasiconformal maps. We will just prove a weak version of the result (see Theorem II.5.5 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=344463")[#text("Lehto-Virtanen")]#text(" for the full statement):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 33")]#text(" ")#metadata(none) <tao-3f22f007dace5d04260f>#text(" Let ")#mi("{K \\geq 1}")#text(", and let ")#mi("{\\phi_n: U \\rightarrow V_n}")#text(" be a sequence of ")#mi("{K}")#text("-quasiconformal maps that converge locally uniformly to an orientation-preserving homeomorphism ")#mi("{\\phi: U \\rightarrow V}")#text(". Then ")#mi("{\\phi}")#text(" is also ")#mi("{K}")#text("-quasiconformal.")
]

#text("It is important for this theorem that we do not insist that quasiconformal maps are necessarily differentiable. Indeed for applications to circle packing we will be working with maps that are only piecewise smooth, or possibly even worse, even though at the end of the day we will recover a smooth conformal map in the limit.")

#emph[#text("Proof:")]#text(" Let ")#mi("{Q}")#text(" be a Jordan quadrilateral in ")#mi("{U}")#text(". We need to show that ")#mi("{\\mathrm{mod}(\\phi(Q)) \\leq K \\mathrm{mod}(Q)}")#text(". By restricting ")#mi("{U}")#text(" we may assume ")#mi("{U=Q}")#text(". By composing ")#mi("{\\phi, \\phi_n}")#text(" with a conformal map we may assume that ")#mi("{Q}")#text(" is a rectangle. We can write ")#mi("{Q}")#text(" as the increasing limit of rectangles ")#mi("{Q_m}")#text(" of the same modulus, then for any ")#mi("{n,m}")#text(" we have ")#mi("{\\mathrm{mod}(\\phi_n(Q_m)) \\leq K \\mathrm{mod}(Q)}")#text(". By choosing ")#mi("{n_m}")#text(" going to infinity sufficiently rapidly, ")#mi("{\\phi_{n_m}(Q_m)}")#text(" stays inside ")#mi("{\\phi(Q)}")#text(" and converges to ")#mi("{\\phi(Q)}")#text(" in the sense of Exercise ")#link(<tao-ab8a1c796dbbdf684804>)[#text("26")]#text(", and the claim then follows from that exercise. ")#mi("\\Box")

#text("Another basic property of conformal mappings (a consequence of ")#link("https://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(") is that they can be glued along a common edge as long as the combined map is also a homeomorphism; this fact underlies for instance the ")#link("https://en.wikipedia.org/wiki/Schwarz_reflection_principle")[#text("Schwarz reflection principle")]#text(". We have a quasiconformal analogue:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34")]#text(" ")#metadata(none) <tao-99552de9998a2b8267df>#text(" Let ")#mi("{K \\geq 1}")#text(", and let ")#mi("{\\phi: U \\rightarrow V}")#text(" be an orientation-preserving homeomorphism. Let ")#mi("{C}")#text(" be a finite union of real analytic (and topologically closed) contours that lie in ")#mi("{U}")#text(" except possibly at the endpoints. If ")#mi("{\\phi: U \\backslash C \\rightarrow \\phi(U \\backslash C)}")#text(" is ")#mi("{K}")#text("-quasiconformal, then ")#mi("{\\phi: U \\rightarrow V}")#text(" is ")#mi("{K}")#text("-quasiconformal.")
]

#text("We will generally apply this theorem in the case when ")#mi("{C}")#text(" disconnects ")#mi("{U}")#text(" into two components, in which case ")#mi("{\\phi}")#text(" can be viewed as the gluing of the restrictions of this map to the two components.")

#emph[#text("Proof:")]#text(" As in the proof of the previous theorem, we may take ")#mi("{U}")#text(" to be a rectangle ")#mi("{Q}")#text(", and it suffices to show that ")#mi("{\\mathrm{mod}(\\phi(Q)) \\leq K \\mathrm{mod}(Q)}")#text(". We may normalise ")#mi("{Q}")#text(" to have vertices ")#mi("{i, 0, M, M+i}")#text(" where ")#mi("{M = \\mathrm{mod}(Q)}")#text(", and similarly normalise ")#mi("{\\phi(Q)}")#text(" to be a rectangle of vertices ")#mi("{i, 0, M^{\\prime}, M^{\\prime}+i}")#text(", so we now need to show that ")#mi("{M^{\\prime} \\leq KM}")#text(". The real analytic contour ")#mi("{C}")#text(" meets ")#mi("{Q}")#text(" in a finite number of curves (and points), which can be broken up further into a finite horizontal line segments (and points) and graphs ")#mi("{\\{ f_j(y) + iy: y \\in I_j\\}}")#text(" for various closed intervals ")#mi("{I_j \\subset [0,1]}")#text(" and continuous ")#mi("{f_j: I_j \\rightarrow [0,M]}")#text(". For any ")#mi("{\\varepsilon>0}")#text(", we can then use the uniform continuity of the ")#mi("{f_j}")#text(" to subdivide ")#mi("{Q}")#text(" into a finite number of rectangles ")#mi("{Q_k= \\{ x+iy: y \\in J_k, 0 \\leq x \\leq M \\}}")#text(" where on each such rectangle, ")#mi("{C}")#text(" meets the interior of ")#mi("{Q_k}")#text(" in a bounded number of graphs ")#mi("{\\{ f_j(y) +iy: y \\in J_k\\}}")#text(" whose horizontal variation is ")#mi("{O(\\varepsilon)}")#text(". This subdivides ")#mi("{Q_k}")#text(" into a bounded number of Jordan quadrilaterals ")#mi("{Q_{k,j}}")#text(". (Strictly speaking, some of these quadrilaterals may degenerate by having two or more of their vertices collide, but this can be dealt with by shrinking each of the ")#mi("{Q_k}")#text(" by a tiny amount (much less than ")#mi("{\\varepsilon}")#text(" and taking limits later in the argument; we leave the details to the interested reader.) If we let ")#mi("{s_{k,j}}")#text(" denote the distance between the ")#mi("{a}")#text("-sides of ")#mi("{\\phi(Q_{k,j})}")#text(", then by uniform continuity of ")#mi("{\\phi}")#text(" and the triangle inequality we have")

#align(center)[#tao-fit-display[#mitex("\\sum_j s_{k,j} \\geq (1+o(1)) M^{\\prime}")]]

#text("as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". By Rengel’s inequality, we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}( \\phi(Q_{k,j}) ) \\geq \\frac{s_{k,j}^2}{\\mathrm{Area}(\\phi(Q_{k,j}))};")]]

#text("since ")#mi("{\\mathrm{mod}( \\phi(Q_{k,j}) ) \\leq K \\mathrm{mod}( Q_{k,j} )}")#text(", we conclude using superadditivity that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}(Q_j) \\geq \\frac{1}{K} \\sum_k \\frac{s_{k,j}^2}{\\mathrm{Area}(\\phi(Q_{k,j}))}")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#mitex("\\mathrm{mod}(Q_j) \\geq \\frac{1}{K} \\frac{(\\sum_k s_{k,j})^2}{\\sum_k \\mathrm{Area}(\\phi(Q_{k,j}))}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\mathrm{mod}(Q_j)} \\leq (1+o(1)) K \\frac{\\mathrm{Area}(\\phi(Q_j))}{(M^{\\prime})^2}.")]]

#text("Summing in ")#mi("{j}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M} \\leq (1+o(1)) K \\frac{M^{\\prime}}{(M^{\\prime})^2}")]]

#text("giving the desired bound ")#mi("{M^{\\prime} \\leq K M}")#text(" after sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(". ")#mi("\\Box")#linebreak()#text(" It will be convenient to study analogues of the modulus when quadrilaterals are replaced by generalisations of annuli. We define a ")#emph[#text("ring domain")]#text(" to be a region bounded between two Jordan curves ")#mi("{C_1, C_2}")#text(", where ")#mi("{C_1}")#text(" (the inner boundary) is contained inside the interior of ")#mi("{C_2}")#text(" (the outer boundary). For instance, the annulus ")#tao-math("{\\{ z: r < \\left|z-z_0\\right| < R \\}}", block: false)#text(" is a ring domain for any ")#mi("{z_0 \\in {\\bf C}}")#text(" and ")#mi("{0 < r < R < \\infty}")#text(". In the spirit of Proposition ")#link(<tao-e6b54572dcc68f644f53>)[#text("23")]#text(", define the ")#emph[#text("modulus")]#text(" ")#mi("{\\mathrm{mod}(A)}")#text(" of a ring domain ")#mi("{A}")#text(" to be the supremum of all the quantities ")#mi("{M}")#text(" with the following property: for any Borel measurable ")#mi("{\\rho: A \\rightarrow [0,+\\infty)}")#text(" one can find a rectifable curve ")#mi("{\\gamma}")#text(" in ")#mi("{A}")#text(" winding once around the inner boundary ")#mi("{C_1}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left(\\int_\\gamma \\rho(z)\\ \\left|dz\\right|\\right)^2 \\leq \\frac{2\\pi}{M} \\int_A \\rho^2(z)\\ dx dy.", block: true)]]

#text("We record some basic properties of this modulus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" ")#metadata(none) <tao-1cb72bbf9f328ceee325>#text(" Show that every ring domain is conformal to an annulus. (There are several ways to proceed here. One is to start by using Perron’s method to construct a harmonic function that is ")#mi("{1}")#text(" on one of the boundaries of the annulus and ")#mi("{0}")#text(" on the other. Another is to apply a logarithm map to transform the annulus to a simply connected domain with a “parabolic” group of discrete translation symmetries, use the Riemann mapping theorem to map this to a disc, and use the uniqueness aspect of the Riemann mapping theorem to figure out what happens to the symmetry.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" ")#metadata(none) <tao-4a04926224a93c5e8ca3>

#list(
[#text("(i) Show that the modulus of an annulus ")#tao-math("{\\{ z: r < \\left|z-z_0\\right| < R \\}}", block: false)#text(" is given by ")#mi("{\\log \\frac{R}{r}}")#text(".")],
[#text("(ii) Show that if ")#mi("{\\phi: U \\rightarrow V}")#text(" is ")#mi("{K}")#text("-quasiconformal and ")#mi("{A}")#text(" is an ring domain in ")#mi("{U}")#text(", then ")#mi("{\\mathrm{mod}(\\phi(A)) \\leq K \\mathrm{mod}(A)}")#text(". In particular, the modulus is a conformal invariant. (There is also a converse to this statement that allows for a definition of ")#mi("{K}")#text("-quasiconformality in terms of the modulus of ring domains; see e.g. Theorem 7.2 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=344463")[#text("Lehto-Virtanen")]#text(".) Use this to extend the definition of modulus of a ring domain to other domains conformal to an annulus, but whose boundaries need not be Jordan curves.")],
[#text("(iii) Show that if one ring domain ")#mi("{A_1}")#text(" is contained inside another ")#mi("{A_2}")#text(" (with the inner boundary of ")#mi("{A_2}")#text(" in the interior of the inner boundary of ")#mi("{A_1}")#text("), then ")#mi("{\\mathrm{mod}(A_1) \\leq \\mathrm{mod}(A_2)}")#text(".")]
)
]

#text("As a basic application of this concept we have the fact that the complex plane cannot be quasiconformal to any proper subset:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 37")]#text(" ")#metadata(none) <tao-2bbc7d0bca968ef6f94a>#text(" Let ")#mi("{\\phi: {\\bf C} \\rightarrow V}")#text(" be a ")#mi("{K}")#text("-quasiconformal map for some ")#mi("{K \\geq 1}")#text("; then ")#mi("{V = {\\bf C}}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{V}")#text(" is homeomorphic to ")#mi("{{\\bf C}}")#text(", it is simply connected. Thus, if we assume for contradiction that ")#mi("{V \\neq {\\bf C}}")#text(", then by the Riemann mapping theorem ")#mi("{V}")#text(" is conformal to ")#mi("{D(0,1)}")#text(", so we may assume without loss of generality that ")#mi("{V = D(0,1)}")#text(".")

#text("By Exercise ")#link(<tao-4a04926224a93c5e8ca3>)[#text("36")]#text("(i), the moduli ")#mi("{\\log R}")#text(" of the annuli ")#tao-math("{\\{ z: 1 \\leq \\left|z\\right| \\leq R \\}}", block: false)#text(" goes to infinity as ")#mi("{R \\rightarrow \\infty}")#text(", and hence (by Exercise ")#link(<tao-4a04926224a93c5e8ca3>)[#text("36")]#text("(ii) (applied to ")#mi("{\\phi^{-1}}")#text(") the moduli of the ring domains ")#tao-math("{\\{ \\phi(z): 1 \\leq \\left|z\\right| \\leq R \\}}", block: false)#text(" must also go to infinity. However, as the inner boundary of this domain is fixed and the outer one is bounded, all these ring domains can be contained inside a common annulus, contradicting Exercise ")#link(<tao-4a04926224a93c5e8ca3>)[#text("36")]#text("(iii). ")#mi("\\Box")

#text("For some further applications of the modulus of ring domains, we need the following result of Grötzsch:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 38 (Grötzsch modulus theorem)")]#text(" ")#metadata(none) <tao-8f8bc388ea171998ed3f>#text(" Let ")#mi("{0 < r < 1}")#text(", and let ")#mi("{A}")#text(" be the ring domain formed from ")#mi("{D(0,1)}")#text(" by deleting the line segment from ")#mi("{0}")#text(" to ")#mi("{r}")#text(". [Technically, ")#mi("{A}")#text(" is not quite a ring domain as defined above, but as mentioned in Exercise ")#link(<tao-4a04926224a93c5e8ca3>)[#text("36")]#text("(ii), the definition of modulus remains valid in this case, as it is easy to conformally change ")#mi("{A}")#text(" to a ring domain, for instance by applying a Möbius transform to map ")#mi("{A}")#text(" to the slit plane ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(" with a disk deleted and then taking a square root followed by another Möbius transformation.] Let ")#mi("{A^{\\prime}}")#text(" be another ring domain contained in ")#mi("{D(0,1)}")#text(" whose inner boundary encloses both ")#mi("{0}")#text(" and ")#mi("{r}")#text(". Then ")#mi("{\\mathrm{mod}(A^{\\prime}) \\leq \\mathrm{mod}(A)}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{R := \\exp(\\mathrm{mod}(A))}")#text(", then by Exercise ")#link(<tao-1cb72bbf9f328ceee325>)[#text("35")]#text(" we can find a conformal map ")#mi("{f}")#text(" from ")#mi("{A}")#text(" to the annulus ")#tao-math("{\\{ z: 1 \\leq \\left|z\\right| \\leq R \\}}", block: false)#text(". As ")#mi("{A}")#text(" is symmetric around the real axis, and the only conformal automorphisms of the annulus that preserve the inner and outer boundaries are rotations (as can be seen for instance by using the Schwarz reflection principle repeatedly to extend such automorphisms to an entire function of linear growth), we may assume that ")#mi("{f}")#text(" obeys the symmetry ")#mi("{f(\\overline{z}) = \\overline{f(z)}}")#text(". Let ")#mi("{\\rho: A \\rightarrow {\\bf R}^+}")#text(" be the function ")#tao-math("{\\rho := \\left|f^{\\prime}/f\\right|}", block: false)#text(", then ")#mi("{\\rho}")#text(" is symmetric around the real axis. One can view ")#mi("{\\rho}")#text(" as a measurable function on ")#mi("{A^{\\prime}}")#text("; from the change of variables formula we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{A^{\\prime}} \\rho^2\\ dx dy \\leq \\int_{1 \\leq \\left|z\\right| \\leq R} \\frac{1}{\\left|z\\right|^2}\\ dx dy = 2\\pi \\log R,", block: true)]]

#text("so in particular ")#mi("{\\rho}")#text(" is square-integrable. Our task is to show that ")#mi("{\\mathrm{mod}(A^{\\prime}) \\leq \\log R}")#text("; by the definition of modulus, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("(\\int_\\gamma \\rho\\ \\left|dz\\right|)^2 \\geq \\frac{2\\pi}{\\log R} \\int_{A^{\\prime}} \\rho^2\\ dx dy", block: true)]]

#text("for any rectifiable curve ")#mi("{\\gamma}")#text(" that goes once around ")#mi("{A^{\\prime}}")#text(", and thus once around ")#mi("{0}")#text(" and ")#mi("{r}")#text(" in ")#mi("{D(0,1)}")#text(". By a limiting argument we may assume that ")#mi("{\\gamma}")#text(" is polygonal. By repeatedly reflecting around the real axis whenever ")#mi("{\\gamma}")#text(" crosses the line segment between ")#mi("{0}")#text(" and ")#mi("{r}")#text(", we may assume that ")#mi("{\\gamma}")#text(" does not actually cross this segment, and then by perturbation we may assume it is contained in ")#mi("{A}")#text(". (Note that because ")#mi("{\\gamma}")#text(" winds around ")#mi("{0}")#text(" and ")#mi("{r}")#text(" the same number of times, the number of times ")#mi("{\\gamma}")#text(" crosses ")#mi("{[0,r]}")#text(" from below matches the number of times it crosses from above, thanks to the ")#link("https://en.wikipedia.org/wiki/Winding_number#Alexander_numbering")[#text("Alexander numbering rule")]#text(".) But then by change of variables we have")

#align(center)[#tao-fit-display[#tao-math("\\int_\\gamma \\rho\\ \\left|dz\\right| = \\int_{f(\\gamma)} \\frac{d\\left|z\\right|}{\\left|z\\right|} \\geq \\left|\\int_{f(\\gamma)} \\frac{dz}{z}\\right| = 2\\pi", block: true)]]

#text("by the Cauchy integral formula, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" ")#metadata(none) <tao-0551ffc77d5f3a5d68f2>#text(" Let ")#mi("{\\phi_n: U \\rightarrow V_n}")#text(" be a sequence of ")#mi("{K}")#text("-quasiconformal maps for some ")#mi("{K \\geq 1}")#text(", such that all the ")#mi("{V_n}")#text(" are uniformly bounded. Show that the ")#mi("{\\phi_n}")#text(" are a ")#link("https://en.wikipedia.org/wiki/Normal_family")[#text("normal family")]#text(", that is to say every sequence in ")#mi("{\\phi_n}")#text(" contains a subsequence that converges locally uniformly. (")#emph[#text("Hint:")]#text(" use an argument similar to that in the proof of Proposition ")#link(<tao-2bbc7d0bca968ef6f94a>)[#text("37")]#text(", combined with Theorem ")#link(<tao-8f8bc388ea171998ed3f>)[#text("38")]#text(", to establish some equicontinuity of the ")#mi("{\\phi_n}")#text(".)")
]

#text("There are many further basic properties of the conformal modulus for both quadrilaterals and annuli; we refer the interested reader to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=344463")[#text("Lehto-Virtanen")]#text(" for details.")

#heading(level: 1)[#strong[#text(" — 3. Rigidity of the hexagonal circle packing — ")]]

#text("We return now to circle packings. In order to understand finite circle packings, it is convenient (in order to use some limiting arguments) to consider some infinite circle packings. A basic example of an infinite circle packing is the ")#emph[#text("regular hexagonal circle packing")]

#align(center)[#tao-fit-display[#mitex("{\\mathcal H} := ( z_0 + S^1 )_{z_0 \\in \\Gamma}")]]

#text("where ")#mi("{\\Gamma}")#text(" is the hexagonal lattice")

#align(center)[#tao-fit-display[#mitex("\\Gamma := \\{ 2 n + 2 e^{2\\pi i/3} m: n,m \\in {\\bf Z} \\}")]]

#text("and ")#mi("{z_0 + S^1 := \\{ z_0 + e^{i \\theta}: \\theta \\in {\\bf R} \\}}")#text(" is the unit circle centred at ")#mi("{z_0}")#text(". This is clearly an (infinite) circle packing, with two circles ")#mi("{z_0+S^1, z_1+S^1}")#text(" in this packing (externally) tangent if and only if they differ by twice a sixth root of unity. Between any three mutually tangent circles in this packing is an open region that we will call an ")#emph[#text("interstice")]#text(". It is inscribed in a ")#emph[#text("dual circle")]#text(" that meets the three original circles orthogonally and can be computed to have radius ")#mi("{1/\\sqrt{3}}")#text("; the interstice can then be viewed as a hyperbolic triangle in this dual circle in which all three sides have infinite length.")#linebreak()#text(" Next we need two simple geometric lemmas, due to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=906396")[#text("Rodin and Sullivan")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 40 (Ring lemma)")]#text(" ")#metadata(none) <tao-16b974583155fdcb11fb>#text(" Let ")#mi("{C}")#text(" be a circle that is externally tangent to a chain ")#mi("{C_1,\\dots,C_n}")#text(" of circles with disjoint interiors, with each ")#mi("{C_i}")#text(" externally tangent to ")#mi("{C_{i+1}}")#text(" (with the convention ")#mi("{C_{n+1}=C_1}")#text("). Then there is a constant ")#mi("{c_n}")#text(" depending only on ")#mi("{n}")#text(", such that the radii of each of the ")#mi("{C_i}")#text(" is at least ")#mi("{c_n}")#text(" times the radius of ")#mi("{C}")#text(".")
]

#emph[#text("Proof:")]#text(" Without loss of generality we may assume that ")#mi("{C}")#text(" has radius ")#mi("{1}")#text(" and that the radius ")#mi("{r_1}")#text(" of ")#mi("{C_1}")#text(" is maximal among the radii ")#mi("{r_i}")#text(" of the ")#mi("{C_i}")#text(". As the polygon connecting the centers of the ")#mi("{C_i}")#text(" has to contain ")#mi("{C}")#text(", we see that ")#mi("{r_1 \\gg_n 1}")#text(". This forces ")#mi("{r_2 \\gg_n 1}")#text(", for if ")#mi("{r_2}")#text(" was too small then ")#mi("{C_2}")#text(" would be so deep in the cuspidal region between ")#mi("{C}")#text(" and ")#mi("{C_1}")#text(" that it would not be possible for ")#mi("{C_3, C_4,\\dots C_n}")#text(" to escape this cusp and go around ")#mi("{C_1}")#text(". A similar argument then gives ")#mi("{r_3 \\gg_n 1}")#text(", and so forth, giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 41 (Length-area lemma)")]#text(" ")#metadata(none) <tao-a7a8572a4aabf25aac4c>#text(" Let ")#mi("{n \\geq 1}")#text(", and let ")#mi("{{\\mathcal H}_n}")#text(" consist of those circles in ")#mi("{{\\mathcal H}}")#text(" that can be connected to the circle ")#mi("{0 + S^1}")#text(" by a path of length at most ")#mi("{n}")#text(" (going through consecutively tangent circles in ")#mi("{{\\mathcal H}}")#text("). Let ")#mi("{{\\mathcal C}_n}")#text(" be circle packing with the same nerve as ")#mi("{{\\mathcal H}_n}")#text(" that is contained in a disk of radius ")#mi("{R}")#text(". Then the circle ")#mi("{C_0}")#text(" in ")#mi("{{\\mathcal C}_n}")#text(" associated to the circle ")#mi("{0+S^1}")#text(" in ")#mi("{{\\mathcal H}_n}")#text(" has radius ")#mi("{O(\\frac{R}{\\log^{1/2} n})}")#text(".")
]

#text("The point of this bound is that when ")#mi("{R}")#text(" is bounded and ")#mi("{n \\rightarrow \\infty}")#text(", the radius of ")#mi("{C_0}")#text(" is forced to go to zero.")

#emph[#text("Proof:")]#text(" We can surround ")#mi("{0+S^1}")#text(" by ")#mi("{n}")#text(" disjoint chains ")#mi("{(C_{j,i})_{i=1}^{6j}, j=1,\\dots,n}")#text(" of consecutively tangent circles ")#mi("{z_{j,i}+S^1}")#text(", ")#mi("{i=1,\\dots, 6j}")#text(" in ")#mi("{{\\mathcal H}_n}")#text(". Each circle is associated to a corresponding circle in ")#mi("{{\\mathcal C}}")#text(" of some radius ")#mi("{r_{j,i}}")#text(". The total area ")#mi("{\\sum_{j=1}^n \\sum_{i=1}^{6j} \\pi r_{ij}^2}")#text(" of these circles is at most the area ")#mi("{\\pi R^2}")#text(" of the disk of radius ")#mi("{R}")#text(". Since ")#mi("{\\sum_{j=1}^n \\frac{1}{n} \\gg \\log n}")#text(", this implies from the pigeonhole principle that there exists ")#mi("{j}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^{6j} \\pi r_{ij}^2 \\ll \\frac{R^2}{j \\log n}")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^{6j} r_{ij} \\ll \\frac{R}{\\log^{1/2} n}.")]]

#text("Connecting the centers of these circles, we obtain a polygonal path of length ")#mi("{O( \\frac{R}{\\log^{1/2} n})}")#text(" that goes around ")#mi("{C_0}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" For every circle ")#mi("{z_0 + S^1}")#text(" in the circle packing ")#mi("{{\\mathcal H}}")#text(", we can form the inversion map ")#mi("{\\iota_{z_0}: {\\bf C} \\cup \\{\\infty\\} \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" across this circle on the Riemann sphere, defined by setting")

#align(center)[#tao-fit-display[#mitex("\\iota_{z_0}( z_0 + re^{i\\theta} ) := z_0 + \\frac{1}{r} e^{i\\theta}")]]

#text("for ")#mi("{0 < r < \\infty}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(", with the convention that ")#mi("{\\iota_{z_0}}")#text(" maps ")#mi("{z_0}")#text(" to ")#mi("{\\infty}")#text(" and vice versa. These are conjugates of Möbius transformations; they preserve the circle ")#mi("{z_0+S^1}")#text(" and swap the interior with the exterior. Let ")#mi("{G}")#text(" be the group of transformations of ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" generated by these inversions ")#mi("{\\iota_{z_0}}")#text("; this is essentially a ")#link("https://en.wikipedia.org/wiki/Schottky_group")[#text("Schottky group")]#text(" (except for the fact that we are are allowing for conjugate Möbius transformations in addition to ordinary Möbius transformations). Let ")#mi("{I}")#text(" denote the union of all the interstices in ")#mi("{{\\mathcal H}}")#text(", and let ")#mi("{GI := \\bigcup_{g \\in G} g(I)}")#text(" be the union of the images of the interstitial regions ")#mi("{I}")#text(" under all of these transformations. We have the following basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 42")]#text(" ")#mi("{{\\bf C} \\backslash GI}")#text(" has Lebesgue measure zero.")
]

#emph[#text("Proof:")]#text(" (Sketch) I thank Mario Bonk for this argument. Let ")#mi("{G {\\mathcal H}}")#text(" denote all the circles formed by applying an element of ")#mi("{G}")#text(" to the circles in ")#mi("{{\\mathcal H}}")#text(". If ")#mi("{z}")#text(" lies in ")#mi("{{\\bf C} \\backslash GI}")#text(", then it lies inside one of the circles in ")#mi("{{\\mathcal H}}")#text(", and then after inverting through that circle it lies in another circle in ")#mi("{{\\mathcal H}}")#text(", and so forth; undoing the inversions, we conclude that ")#mi("{z}")#text(" lies in infinite number of nested circles. Let ")#mi("{C}")#text(" be one of these circles. ")#mi("{GI}")#text(" contains a union of six interstices bounded by ")#mi("{C}")#text(" and a cycle of six circles internally tangent to ")#mi("{C}")#text(" and consecutively externally tangent to each other. Applying the same argument used to establish the ring lemma (Lemma ")#link(<tao-16b974583155fdcb11fb>)[#text("40")]#text("), we see that the six internal circles have radii comparable to that of ")#mi("{C}")#text(", and hence ")#mi("{GI}")#text(" has density ")#mi("{\\gg 1}")#text(" in the disk enclosed by ")#mi("{C}")#text(", which also contains ")#mi("{z}")#text(". The ring lemma also shows that the radius of each circle in the nested sequence is at most ")#mi("{1-c}")#text(" times the one enclosing it for some absolute constant ")#mi("{c>0}")#text(", so in particular the disks shrink to zero in size. Thus ")#mi("{z}")#text(" cannot be a point of density of ")#mi("{{\\bf C} \\backslash GI}")#text(", and hence by the ")#link("https://en.wikipedia.org/wiki/Lebesgue%27s_density_theorem")[#text("Lebesgue density theorem")]#text(" this set has measure zero. ")#mi("\\Box")

#text("We also need another simple geometric observation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" ")#metadata(none) <tao-9a370ebd95136e8b2036>#text(" Let ")#mi("{C_1,C_2,C_3}")#text(" be mutually externally tangent circles, and let ")#mi("{C^{\\prime}_1, C^{\\prime}_2, C^{\\prime}_3}")#text(" be another triple of mutually external circles, with the same orientation (e.g. ")#mi("{C_1,C_2,C_3}")#text(" and ")#mi("{C^{\\prime}_1,C^{\\prime}_2,C^{\\prime}_3}")#text(" both go counterclockwise around their interstitial region). Show that there exists a Möbius transformation ")#mi("{\\phi}")#text(" that maps each ")#mi("{C_i}")#text(" to ")#mi("{C^{\\prime}_i}")#text(" and which maps the interstice of ")#mi("{C_1,C_2,C_3}")#text(" conformally onto the interstice of ")#mi("{C^{\\prime}_1,C^{\\prime}_2, C^{\\prime}_3}")#text(".")
]

#text("Now we can give a rigidity result for the hexagonal circle packing, somewhat in the spirit of Theorem ")#link(<tao-5455fc3fb94cf1d5cac4>)[#text("4")]#text(" (though it does not immediately follow from that theorem), and also due to Rodin and Sullivan:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 44 (Rigidity of infinite hexagonal packing)")]#text(" ")#metadata(none) <tao-4bab36ce40d3a7f543a2>#text(" Let ")#mi("{{\\mathcal C}}")#text(" be an infinite circle packing in ")#mi("{{\\bf C}}")#text(" with the same nerve as the hexagonal circle packing ")#mi("{{\\mathcal H}}")#text(". Then ")#mi("{{\\mathcal C}}")#text(" is in fact equal to the hexagonal circle packing up to affine transformations and reflections.")
]

#emph[#text("Proof:")]#text(" By applying a reflection we may assume that ")#mi("{{\\mathcal C}}")#text(" and ")#mi("{{\\mathcal H}}")#text(" have the same orientation. For each interstitial region ")#mi("{I_j}")#text(" of ")#mi("{{\\mathcal H}}")#text(" there is an associated interstitial region ")#mi("{I^{\\prime}_j}")#text(" of ")#mi("{{\\mathcal C}}")#text(", and by Exercise ")#link(<tao-9a370ebd95136e8b2036>)[#text("43")]#text(" there is a Möbius transformation ")#mi("{T_j: I_j \\rightarrow I^{\\prime}_j}")#text(". These can be glued together to form a map ")#mi("{\\phi_0}")#text(" that is initially defined (and conformal) on the interstitial regions ")#mi("{I =\\bigcup_j I_j}")#text("; we would like to extend it to the entire complex plane by defining it also inside the circles ")#mi("{z_j + S^1}")#text(".")

#text("Now consider a circle ")#mi("{z_j+S^1}")#text(" in ")#mi("{{\\mathcal H}}")#text(". It is bounded by six interstitial regions ")#mi("{I_1,\\dots,I_6}")#text(", which map to six interstitial regions ")#mi("{I^{\\prime}_1,\\dots,I^{\\prime}_6}")#text(" that lie between the circle ")#mi("{C_0}")#text(" corresponding to ")#mi("{z_j+S^1}")#text(" and six tangent circles ")#mi("{C_1,\\dots,C_6}")#text(". By the ring lemma, all of the circles ")#mi("{C_1,\\dots,C_6}")#text(" have radii comparable to the radius ")#mi("{r_j}")#text(" of ")#mi("{C_0}")#text(". As a consequence, the map ")#mi("{\\phi_0}")#text(", which is defined (and piecewise Möbius) on the boundary of ")#mi("{z_j + S^1}")#text(" as a map to the boundary of ")#mi("{C_0}")#text(", has derivative comparable in magnitude to ")#mi("{r_j}")#text(" also. By extending this map radially (in the sense of defining ")#mi("{\\phi(z_j + r e^{i\\theta}) := w_j + r r_j (\\phi(z_j + e^{i\\theta})-w_j)}")#text(" for ")#mi("{0 < r < 1}")#text(" and ")#mi("{\\theta \\in {\\bf R}}")#text(", where ")#mi("{w_j}")#text(" is the centre of ")#mi("{C_0}")#text(", we see from Theorem ")#link(<tao-5d920e9810479476191a>)[#text("29")]#text(" that we can extend ")#mi("{\\phi_0}")#text(" to be ")#mi("{K}")#text("-quasiconformal in the interior of ")#mi("{z_j+S^1}")#text(" except possibly at ")#mi("{z_j}")#text(" for some ")#mi("{K=O(1)}")#text(", and to a homeomorphism from ")#mi("{{\\bf C}}")#text(" to the region ")#mi("{\\phi_0({\\bf C})}")#text(" consisting of the union of the disks in ")#mi("{{\\mathcal C}}")#text(" and their interstitial regions. By many applications of Theorem ")#link(<tao-99552de9998a2b8267df>)[#text("34")]#text(", ")#mi("{\\phi_0}")#text(" is now ")#mi("{K}")#text("-quasiconformal on all of ")#mi("{{\\bf C}}")#text(", and conformal in the interstitial regions ")#mi("{I}")#text(". By Proposition ")#link(<tao-2bbc7d0bca968ef6f94a>)[#text("37")]#text(", ")#mi("{\\phi_0}")#text(" surjects onto ")#mi("{{\\bf C}}")#text(", thus the circle packing ")#mi("{{\\mathcal C}}")#text(" and all of its interstitial regions cover the entire complex plane.")

#text("Next, we use a version of the Schwarz reflection principle to replace ")#mi("{\\phi_0}")#text(" by another ")#mi("{K}")#text("-quasiconformal map that is conformal on a larger region than ")#mi("{I}")#text(". Namely, pick a circle ")#mi("{z_j+S^1}")#text(" in ")#mi("{{\\mathcal H}}")#text(", and let ")#mi("{C_0}")#text(" be the corresponding circle in ")#mi("{{\\mathcal C}}")#text(". Let ")#mi("{\\iota_j}")#text(" and ")#mi("{\\iota^{\\prime}_j}")#text(" be the inversions across ")#mi("{z_j+S^1}")#text(" and ")#mi("{C_0}")#text(" respectively. Note that ")#mi("{\\phi_0}")#text(" maps the circle ")#mi("{z_j+S^1}")#text(" to ")#mi("{C_0}")#text(", with the interior mapping to the interior and exterior mapping to the exterior. We can then define a modified map ")#mi("{\\phi_1}")#text(" by setting ")#mi("{\\phi_1(z)}")#text(" equal to ")#mi("{\\phi_0(z)}")#text(" on or outside ")#mi("{z_j+S_1}")#text(", and ")#mi("{\\phi_1(z)}")#text(" equal to ")#mi("{\\iota^{\\prime}_j \\circ \\phi_0 \\circ \\iota_j(z)}")#text(" inside ")#mi("{z_j+S_1}")#text(" (with the convention that ")#mi("{\\phi_0}")#text(" maps ")#mi("{\\infty}")#text(" to ")#mi("{\\infty}")#text("). This is still an orientation-preserving function ")#mi("{{\\bf C}}")#text("; by Theorem ")#link(<tao-99552de9998a2b8267df>)[#text("34")]#text(" it is still ")#mi("{K}")#text("-quasiconformal. It remains conformal on the interstitial region ")#mi("{I}")#text(", but is now also conformal on the additional interstitial region ")#mi("{\\iota_j(I)}")#text(". Repeating this construction one can find a sequence ")#mi("{\\phi_n:{\\bf C} \\rightarrow {\\bf C}}")#text(" of ")#mi("{K}")#text("-quasiconformal maps that map each circle ")#mi("{z_j+S^1}")#text(" to their counterparts ")#mi("{C_0}")#text(", and which are conformal on a sequence ")#mi("{I_n}")#text(" of sets that increase up to ")#mi("{GI}")#text(". By Exercise ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("39")]#text(", the restriction of ")#mi("{\\phi_n}")#text(" to any compact set forms a normal family (the fact that the circles ")#mi("{z_j+S^1}")#text(" map to the circles ")#mi("{C_0}")#text(" will give the required uniform boundedness for topological reasons), and hence (by the usual diagonalisation argument) the ")#mi("{\\phi_n}")#text(" themselves are a normal family; similarly for ")#mi("{\\phi_n^{-1}}")#text(". Thus, by passing to a subsequence, we may assume that the ")#mi("{\\phi_n}")#text(" converge locally uniformly to a limit ")#mi("{\\phi}")#text(", and that ")#mi("{\\phi_n^{-1}}")#text(" also converge locally uniformly to a limit which must then invert ")#mi("{\\phi}")#text(". Thus ")#mi("{\\phi}")#text(" is a homeomorphism, and thus ")#mi("{K}")#text("-quasiconformal by Theorem ")#link(<tao-3f22f007dace5d04260f>)[#text("33")]#text(". It is conformal on ")#mi("{GI}")#text(", and hence by Proposition ")#link(<tao-2c70237f50de15d265e6>)[#text("32")]#text(" it is conformal. But the only conformal maps of the complex plane are the affine maps (see Proposition 15 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("this previous blog post")]#text("), and hence ")#mi("{{\\mathcal C}}")#text(" is an affine copy of ")#mi("{{\\mathcal H}}")#text(" as required. ")#mi("\\Box")

#text("By a standard limiting argument, the perfect rigidity of the infinite circle packing can be used to give approximate rigidity of finite circle packings:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 45 (Approximate rigidity of finite hexagonal packings)")]#text(" ")#metadata(none) <tao-02b3dce98c61897231fd>#text(" Let ")#mi("{\\varepsilon>0}")#text(", and suppose that ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Let ")#mi("{{\\mathcal H}_n}")#text(" and ")#mi("{{\\mathcal C}_n}")#text(" be as in Lemma ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("41")]#text(". Let ")#mi("{r_0}")#text(" be the radius of the circle ")#mi("{C_1}")#text(" in ")#mi("{{\\mathcal C}_n}")#text(" associated to ")#mi("{0+S_1}")#text(", and let ")#mi("{r_1}")#text(" be the radius of an adjacent circle ")#mi("{C_1}")#text(". Then ")#mi("{1-\\varepsilon \\leq \\frac{r_1}{r_0} \\leq 1+\\varepsilon}")#text(".")
]

#emph[#text("Proof:")]#text(" We may normalise ")#mi("{r_0=1}")#text(" and ")#mi("{C_0=S^1}")#text(". Suppose for contradiction that the claim failed, then one can find a sequence ")#mi("{n}")#text(" tending to infinity, and circle packings ")#mi("{{\\mathcal C}_n}")#text(" with nerve ")#mi("{{\\mathcal H}_n}")#text(" with ")#mi("{C_0 = C_{0,n} = S^1}")#text(", such that the radius ")#mi("{r_{1,n}}")#text(" of the adjacent circle ")#mi("{C_1 = C_{1,n}}")#text(" stays bounded away from ")#mi("{1}")#text(". By many applications of the ring lemma, for each circle ")#mi("{z + S^1}")#text(" of ")#mi("{{\\mathcal H}}")#text(", the corresponding circle ")#mi("{C_{z,n}}")#text(" in ")#mi("{{\\mathcal C}_n}")#text(" has radius bounded above and below by zero. Passing to a subsequence using Bolzano-Weierstrass and using the Arzela-Ascoli diagonalisation argument, we may assume that the radii ")#mi("{r_{z,n}}")#text(" of these circles converge to a positive finite limit ")#mi("{r_{z,\\infty}}")#text(". Applying a rotation we may also assume that the circles ")#mi("{C_{1,n}}")#text(" converge to a limit circle ")#mi("{C_{1,\\infty}}")#text(" (using the obvious topology on the space of circles); we can also assume that the orientation of the ")#mi("{{\\mathcal C}_n}")#text(" does not depend on ")#mi("{n}")#text(". A simple induction then shows that ")#mi("{C_{z,n}}")#text(" converges to a limit circle ")#mi("{C_{z,\\infty}}")#text(", giving a circle packing ")#mi("{{\\mathcal C}_\\infty}")#text(" with the same nerve as ")#mi("{{\\mathcal H}}")#text(". But then by Lemma ")#link(<tao-4bab36ce40d3a7f543a2>)[#text("44")]#text(", ")#mi("{{\\mathcal C}_\\infty}")#text(" is an affine copy of ")#mi("{{\\mathcal H}}")#text(", which among other things implies that ")#mi("{r_{1,\\infty} = r_{0,\\infty} = 1}")#text(". Thus ")#mi("{r_{1,n}}")#text(" converges to ")#mi("{1}")#text(", giving the required contradiction. ")#mi("\\Box")

#text("A more quantitative version of this corollary was worked out ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1094463")[#text("by He")]#text(". There is also a purely topological proof of the rigidity of the infinite hexagonal circle packing ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1076089")[#text("due to Schramm")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. Approximating a conformal map by circle packing — ")]]

#text("Let ")#mi("{U}")#text(" be a simply connected bounded region in ")#mi("{{\\bf C}}")#text(" with two distinct distinguished points ")#mi("{z_0, z_1 \\in U}")#text(". By the Riemann mapping theorem, there is a unique conformal map ")#mi("{\\phi: U \\rightarrow D(0,1)}")#text(" that maps ")#mi("{z_0}")#text(" to ")#mi("{0}")#text(" and ")#mi("{z_1}")#text(" to a positive real. However, many proofs of this theorem are rather nonconstructive, and do not come with an effective algorithm to locate, or at least approximate, this map ")#mi("{\\phi}")#text(".")

#text("It was conjectured by Thurston, and later proven ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=906396")[#text("by Rodin and Sullivan")]#text(", that one could achieve this by applying the circle packing theorem (Theorem ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(") to a circle packing in ")#mi("{U}")#text(" by small circles. To formalise this, we need some more notation. Let ")#mi("{\\varepsilon>0}")#text(" be a small number, and let ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(" be the infinite hexagonal packing scaled by ")#mi("{\\varepsilon}")#text(". For every circle in ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(", define the ")#emph[#text("flower")]#text(" to be the union of this circle, its interior, the six interstices bounding it, and the six circles tangent to the circle (together with their interiors). Let ")#mi("{C_0}")#text(" be a circle in ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(" such that ")#mi("{z_0}")#text(" lies in its flower. For ")#mi("{\\varepsilon}")#text(" small enough, this flower is contained in ")#mi("{U}")#text(". Let ")#mi("{{\\mathcal I}_\\varepsilon}")#text(" denote all circles in ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(" that can be reached from ")#mi("{C_0}")#text(" by a finite chain of consecutively tangent circles in ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(", whose flowers all lie in ")#mi("{U}")#text(". Elements of ")#mi("{{\\mathcal I}_\\varepsilon}")#text(" will be called ")#emph[#text("inner circles")]#text(", and circles in ")#mi("{\\varepsilon \\cdot {\\mathcal H}}")#text(" that are not an inner circle but are tangent to it will be called ")#emph[#text("border circles")]#text(". Because ")#mi("{U}")#text(" is simply connected, the union of all the flowers of inner circles is also simply connected. As a consequence, one can traverse the border circles by a cycle of consecutively tangent circles, with the inner circles enclosed by this cycle. Let ")#mi("{{\\mathcal C}_\\varepsilon}")#text(" be the circle packing consisting of the inner circles and border circles. Applying Theorem ")#link(<tao-659eee59f002e69bf905>)[#text("3")]#text(" followed by a Möbius transformation, one can then find a circle packing ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" in ")#mi("{D(0,1)}")#text(" with the same nerve and orientation as ")#mi("{{\\mathcal C}_\\varepsilon}")#text(", such that all the circles in ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" associated to border circles of ")#mi("{{\\mathcal C}_\\varepsilon}")#text(" are internally tangent to ")#mi("{D(0,1)}")#text(". Applying a Möbius transformation, we may assume that the flower containing ")#mi("{z_0}")#text(" in ")#mi("{{\\mathcal C}_\\varepsilon}")#text(" is mapped to the flower containing ")#mi("{0}")#text(", and the flower containing ")#mi("{z_1}")#text(" is mapped to a flower containing a positive real. (From the exercise below ")#mi("{z_1}")#text(" will lie in such a flower for ")#mi("{\\varepsilon}")#text(" small enough.)")

#text("Let ")#mi("{U_\\varepsilon}")#text(" be the union of all the solid closed equilateral triangles formed by the centres of mutually tangent circles in ")#mi("{{\\mathcal C}_\\varepsilon}")#text(", and let ")#mi("{D_\\varepsilon}")#text(" be the corresponding union of the solid closed triangles from ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(". Let ")#mi("{\\phi_\\varepsilon}")#text(" be the piecewise affine map from ")#mi("{U_\\varepsilon}")#text(" to ")#mi("{D_\\varepsilon}")#text(" that maps each triangle in ")#mi("{U_\\varepsilon}")#text(" to the associated triangle in ")#mi("{D_\\varepsilon}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" Show that ")#mi("{U_\\varepsilon}")#text(" converges to ")#mi("{U}")#text(" as ")#mi("{\\varepsilon \\rightarrow 0}")#text(" in the sense that for every compact ")#mi("{K \\subset U}")#text(", we have ")#mi("{K \\subset U_\\varepsilon}")#text(" for all sufficiently small ")#mi("{\\varepsilon}")#text(". In particular, ")#mi("{z_1}")#text(" lies in ")#mi("{U_\\varepsilon}")#text(" for sufficiently small ")#mi("{\\varepsilon}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" By modifying the proof of the length-area lemma, show that all the circles ")#mi("{C}")#text(" in ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" have radius that goes uniformly to zero as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". (Hint: for circles ")#mi("{C}")#text(" deep in the interior, the length-area lemma works as is; for circles ")#mi("{C}")#text(" near the boundary, one has to encircle ")#mi("{C}")#text(" by a sequence of chains that need not be closed, but may instead terminate on the boundary of ")#mi("{D(0,1)}")#text(". The argument may be viewed as a discrete version of the one used to prove Theorem ")#link(<tao-b2cf1df0cc2719c5d2bd>)[#text("20")]#text(".) Using this and the previous exercise, show that ")#mi("{D_\\varepsilon}")#text(" converges to ")#mi("{D(0,1)}")#text(" in the sense that for every compact ")#mi("{K \\subset D(0,1)}")#text(", we have ")#mi("{K \\subset D_\\varepsilon}")#text(" for all sufficiently small ")#mi("{\\varepsilon}")#text(".")
]

#text("From Corollary ")#link(<tao-02b3dce98c61897231fd>)[#text("45")]#text(" we see that as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", the circles in ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" corresponding to adjacent circles of ")#mi("{{\\mathcal C}_\\varepsilon}")#text(" in a fixed compact subset ")#mi("{R}")#text(" of ")#mi("{U}")#text(" have radii differing by a ratio of ")#mi("{1+o(1)}")#text(". We conclude that in any compact subset ")#mi("{R^{\\prime}}")#text(" of ")#mi("{D(0,1)}")#text(", adjacent circles in ")#mi("{{\\mathcal C}^{\\prime}_\\varepsilon}")#text(" in ")#mi("{R^{\\prime}}")#text(" also have radii differing by a ratio of ")#mi("{1+o(1)}")#text(", which implies by trigonometry that the triangles of ")#mi("{D_\\varepsilon}")#text(" in ")#mi("{R^{\\prime}}")#text(" are approximately equilateral in the sense that their angles are ")#mi("{\\frac{\\pi}{3}+o(1)}")#text(". By Theorem ")#link(<tao-5d920e9810479476191a>)[#text("29")]#text(" ")#mi("{\\phi_\\varepsilon}")#text(" is ")#mi("{1+o(1)}")#text("-quasiconformal on each such triangle, and hence by Theorem ")#link(<tao-99552de9998a2b8267df>)[#text("34")]#text(" it is ")#mi("{1+o(1)}")#text("-quasiconformal on ")#mi("{R}")#text(". By Exercise ")#link(<tao-0551ffc77d5f3a5d68f2>)[#text("39")]#text(" every sequence of ")#mi("{\\phi_\\varepsilon}")#text(" has a subsequence which converges locally uniformly on ")#mi("{U}")#text(", and whose inverses converge locally uniformly on ")#mi("{D}")#text("; the limit is then a homeomorphism from ")#mi("{U}")#text(" to ")#mi("{D}")#text(" that maps ")#mi("{z_0}")#text(" to ")#mi("{0}")#text(" and ")#mi("{z_1}")#text(" to a positive real. By Theorem ")#link(<tao-3f22f007dace5d04260f>)[#text("33")]#text(" the limit is locally ")#mi("{1}")#text("-quasiconformal and hence conformal, hence by uniqueness of the Riemann mapping it must equal ")#mi("{\\phi}")#text(". As ")#mi("{\\phi}")#text(" is the unique limit point of all subsequences of the ")#mi("{\\phi_\\varepsilon}")#text(", this implies (by the Urysohn subsequence principle) that ")#mi("{\\phi_\\varepsilon}")#text(" converges locally uniformly to ")#mi("{\\phi}")#text(", thus making precise the sense in which the circle packings converge to the Riemann map.")

#heading(level: 1)[#text("Comments (32)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3423c5ae647ed0790af47fb8e499d5d96b468a4193d6f1cc62073b5ae1a136d2-4275359171cbe17061974bac4a87cb060c24a08806e4b01376d01d4d5c8956a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Hutchcroft")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496032")[#strong[#text("Tom Hutchcroft")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("Thanks for the great post, Terry. I would like to use this comment to direct your readers towards some further reading about the beautiful theory of circle packing and its applications, and in particular to its applications in probability with which I am most familiar.")

#text("Good places for more background are Ken Stephenson’s book, and Steffen Rhode’s survey of Oded Schramm’s contributions to the subject ")#link("https://arxiv.org/pdf/1007.2007.pdf")[#text("https://arxiv.org/pdf/1007.2007.pdf")]#text(".")

#text("First, regarding the material covered in the post:")

#text("There is an entirely combinatorial proof of the existence part of the Circle Packing Theorem due to Brightwell and Scheinerman ")#link("https://epubs.siam.org/doi/abs/10.1137/0406017")[#text("https://epubs.siam.org/doi/abs/10.1137/0406017")]#text(".")

#text("A very short proof of uniqueness for finite circle packings was found by Schramm, who (as I understand it) anonymously added it to this wikipedia article ")#link("https://en.wikipedia.org/wiki/Circle_packing_theorem")[#text("https://en.wikipedia.org/wiki/Circle_packing_theorem")]#text(". It does not appear elsewhere as far as I know.")

#text("The question of existence and uniqueness of circle packings of infinite triangulations in prescribed domains was studied by He and Schramm")#linebreak()#text(" ")#link("https://link.springer.com/article/10.1007/BF02570699")[#text("https://link.springer.com/article/10.1007/BF02570699")]#text(" ")#link("https://www.jstor.org/stable/2946541")[#text("https://www.jstor.org/stable/2946541")]#text(", who in particular proved the natural analogue of the uniformization theorem in this context, namely that every triangulation of the plane can be circle packed in either the Euclidean plane or the hyperbolic plane, but not both. The earlier paper of Schramm that you mentioned (")#link("http://www.ams.org/journals/jams/1991-04-01/S0894-0347-1991-1076089-9/home.html")[#text("http://www.ams.org/journals/jams/1991-04-01/S0894-0347-1991-1076089-9/home.html")]#text(") implies that these packings are unique up to reflections and Mobius transformations. They also proved that, if the triangulation has bounded degrees, then it gets packed in the Euclidean plane if and only if simple random walk on it is recurrent (i.e., visits every vertex infinitely often almost surely). They also studied circle packings of non-simply connected domains, a topic which is closely related to the Koebe conjecture.")

#text("The existence and uniqueness problems for infinite packings were later revisited by He in the wonderful paper ")#link("https://arxiv.org/abs/math/9901148")[#text("https://arxiv.org/abs/math/9901148")]#text(", which in my opinion has the best proofs of both results. His proofs also apply to more general “disk patterns” in which circles are required to intersect with specified angles rather than necessarily being tangent.")

#text("Now, for applications in probability:")

#text("As I mentioned already, He and Schramm proved that a bounded degree triangulation of the plane can be circle packed in the hyperbolic plane if and only it is transient for simple random walk. This result was extended by Gurel-Gurevich, Nachmias, and Suoto (")#link("https://projecteuclid.org/euclid.ecp/1483671681")[#text("https://projecteuclid.org/euclid.ecp/1483671681")]#text("), who proved that the random walk on a bounded degree triangulation circle packed in a domain D is transient if and only if Brownian motion on D is transient, i.e. leaves D in finite time almost surely.")

#text("Benjamini and Schramm (")#link("https://link.springer.com/article/10.1007/s002220050109")[#text("https://link.springer.com/article/10.1007/s002220050109")]#text(") proved that in this case, the simple random walk on the circle packed triangulation converges to a point in the ideal boundary of the hyperbolic plane, and that the law of the limit point is non-atomic and has full support. They used this result to deduce that a bounded degree planar graph admits non-constant bounded harmonic functions if and only if it is transient (equivalently, the invariant sigma-algebra of the random walk on the triangulation is non-trivial if and only if the walk is transient), and in this case it also admits non-constant bounded harmonic functions of finite Dirichlet energy. They also proved the same result using square tiling instead of circle packing in ")#link("https://projecteuclid.org/euclid.aop/1065725179")[#text("https://projecteuclid.org/euclid.aop/1065725179")]#text(". I should mention here that the regularity of the harmonic measures on the boundary is not very well understood. For example, it is an open problem to determine whether the harmonic measure of the random walk on the 7-regular hyperbolic triangulation is absolutely continuous with respect to Lebesgue (it is believed not to be, and should have a fractal structure).")

#text("The result of Benjamini and Schramm just mentioned allows one to construct harmonic functions on the graph by taking functions on the boundary and integrating them against the harmonic measure. Angel, Barlow, Gurel-Gurevich, and Nachmias (")#link("https://projecteuclid.org/euclid.aop/1463410036")[#text("https://projecteuclid.org/euclid.aop/1463410036")]#text(") proved that, in fact, every bounded harmonic function on a bounded degree triangulation arises in this way. In other words, the boundary of the hyperbolic plane can be identified with the Poisson boundary of the triangulation. They also proved the stronger result that every positive harmonic function on the triangulation admits a representation the harmonic extension of a measure on the boundary of the hyperbolic plane, i.e. that the boundary of the hyperbolic plane can be identified with the Martin boundary of the triangulation. In my paper ")#link("https://arxiv.org/pdf/1707.07751.pdf")[#text("https://arxiv.org/pdf/1707.07751.pdf")]#text(", I prove a related representation theorem for harmonic Dirichlet functions on bounded degree triangulations. Angel, Barlow, Gurel-Gurevich and Nachmias also proved various quite strong estimates for the random walk on the triangulation, to the effect that the random walk on the circle packing behaves similarly to a quasi-conformal image of Brownian motion. Their results regarding the Poisson boundary followed earlier work by Georgakopoulos (")#link("https://arxiv.org/abs/1301.1506")[#text("https://arxiv.org/abs/1301.1506")]#text("), which established a corresponding result for square tilings. Both results were revisited in my work with Peres (")#link("https://projecteuclid.org/euclid.ejp/1511578855")[#text("https://projecteuclid.org/euclid.ejp/1511578855")]#text("), which gave a simplified and unified proof that works for both embeddings.")

#text("Circle packing has been very important in the study of random planar maps. In particular, Benjamini and Schramm (")#link("https://projecteuclid.org/euclid.ejp/1461097653")[#text("https://projecteuclid.org/euclid.ejp/1461097653")]#text(") used circle packing to prove that every “distributional limit” of finite, bounded degree planar graphs is almost surely recurrent. (These limits are now commonly known as Benjamini-Schramm limits.) Alternative proofs of their result have recently been given by Angel, Nachmias, Ray, and myself (")#link("https://arxiv.org/abs/1501.04677")[#text("https://arxiv.org/abs/1501.04677")]#text(") and by Lee (")#link("https://arxiv.org/abs/1701.01598")[#text("https://arxiv.org/abs/1701.01598")]#text(").")

#text("Gurel-Gurevich and Nachmias (")#link("https://arxiv.org/abs/1206.0707")[#text("https://arxiv.org/abs/1206.0707")]#text(") later improved upon the methods of Benjamini and Schramm to prove that the Uniform Infinite Planar Triangulation (UIPT) is recurrent. The UIPT is defined to be the distributional limit of uniform triangulations of the sphere with n vertices as n goes to infinity. The circle packing of the UIPT is conjectured to converge under rescaling to so-called Liouville Quantum Gravity (LQG). Despite the recent and great advances in the understanding of LQG (which includes too many papers and authors to list here), this particular conjecture still seems quite far off.")

#text("Some more papers using circle packing to study probabilistic questions on planar graphs include ")#link("https://projecteuclid.org/euclid.ecp/1456943503")[#text("https://projecteuclid.org/euclid.ecp/1456943503")]#text(", ")#link("https://arxiv.org/abs/1603.07320")[#text("https://arxiv.org/abs/1603.07320")]#text(", ")#link("https://www.math.ubc.ca/~mathav/index_files/qs.pdf")[#text("https://www.math.ubc.ca/~mathav/index_files/qs.pdf")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j.c.")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496284")[#strong[#text("j.c.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Thanks very much for this helpful overview! Your paper with Peres on boundaries of planar graphs for both square tilings and circle packings is particularly interesting.")

#text("One non-mathematical comment: Schramm was not anonymous on wikipedia (his username was “OdedSchramm” ")#link("https://en.wikipedia.org/wiki/User:OdedSchramm")[#text("https://en.wikipedia.org/wiki/User:OdedSchramm")]#text(" ) and his contributions were quite extensive. For instance, the history of the wikipedia page on the circle packing theorem shows that he created the page and wrote the majority of it from 28 – 31 March 2008; for instance, his elementary proof of uniqueness was added in this edit ")#link("https://en.wikipedia.org/w/index.php?title=Circle_packing_theorem&diff=202165964&oldid=202158966")[#text("https://en.wikipedia.org/w/index.php?title=Circle_packing_theorem&diff=202165964&oldid=202158966")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c57f074061f86b258355f06cf2cba6e738ccc842cc506f2930185a7276809c51-6228030672959d7116730fbae5b5e0510b0edec28fe042a169284a3b6f996e4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asaf Nachmias")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496234")[#strong[#text("Asaf Nachmias")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Here’s a neat elementary argument due to Ohad Feldheim and Ori Gurel-Gurevich that avoids the topology in the proof of Prop 17. It’s stated in the Euclidean rather than the hyperbolic setting, but it seems to imply Prop 17 cause one can calculate the Euclidean centers and radii from the hyperbolic ones.")

#text("Assume you have an assignment of positive numbers (lengths) ")#mi("\\{\\ell_e\\}_{e\\in E}")#text(" to the edges of a maximal planar graph so that for each internal vertex ")#mi("v")#text(" the angles formed at ")#mi("v")#text(" by triangles with edge lengths corresponding to the edges of the faces incident to ")#mi("v")#text(" sum to ")#mi("2\\pi")#text(". Then there is a proper drawing of the graph where an edge ")#mi("e")#text(" is drawn as a straight line segment of length ")#mi("\\ell_e")#text(".")

#text("Proof: By induction on the number of vertices. For 3 vertices it is obvious. Otherwise take an internal vertex ")#mi("v")#text(" and draw the triangles corresponding to the faces incident ")#mi("v")#text(". Since the sum of angles is ")#mi("2\\pi")#text(" everything “fits” and you get a polygon where ")#mi("v")#text(" is somewhere inside. Triangulate the polygon (two ears theorem) and record the lengths of the diagonals you added. You now have a new maximal planar graph with one vertex less and the new assignment of lengths also give ")#mi("2\\pi")#text(" angle sum at each internal vertex. Use the induction hypothesis to draw the new graph with straight lines, and now the location of ")#mi("v")#text(" and the edges emanating from it are determined since the polygon above is drawn exactly the same, so you can add them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496364")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("This is a nice use of the two ears theorem! It doesn’t fit well pedagogically with the arrangement I have in my blog, but it is certainly worth noting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496274")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("It seems quite appealing to build a complex analysis out of arrangements of circles or squares. There are some excellent graphics on the internet (that may not have been available before). E.g. on Wikipedia ")#link("https://en.wikipedia.org/wiki/Circle_packing#Uniform_packings")[#text("https://en.wikipedia.org/wiki/Circle_packing#Uniform_packings")]#linebreak()#text(" My best guess is that holomorphic functions arise naturally in trying to solve differential equations such as Laplace equation or heat equation ")#mi("\\nabla^2 \\phi = 0")#text(". However, there is no free lunch since Riemann existence theorem requires Green’s functions to solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af1ca41c3c2d6fb3df1f828140e637cf33bc9b1baddde8a273643bd8799435e6-0a05df101685335f8603da8aea8c82153fa1883d5bf47ebaafec50589fb2e9fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geoishard")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496318")[#strong[#text("geoishard")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("This is lovely! Unfortunately I’m confused by Exercise 31. If I’m not being silly, it contradicts Theorem 5.14 (and the sentence following 5.14) in this removability survey: ")#link("https://arxiv.org/pdf/1503.02582.pdf")[#text("https://arxiv.org/pdf/1503.02582.pdf")]#text(". But it seems to be important, so maybe I am being silly. Any ideas/help?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496319")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Oops, I had omitted the rather important hypothesis of quasiconformality, now added.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af1ca41c3c2d6fb3df1f828140e637cf33bc9b1baddde8a273643bd8799435e6-0a05df101685335f8603da8aea8c82153fa1883d5bf47ebaafec50589fb2e9fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of geoishard")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496323")[#strong[#text("geoishard")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Ah, thanks! Very nice.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/812c4968c2829ebd771b1de0bc6f091a45091cde8239bdb623eed32c2b7c0242-fa5a85331892007a0612aa94d4088361a6d747dda3658cb448f2f56b38301898.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lexing Ying")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496330")[#strong[#text("Lexing Ying")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Thank you! In Exercise (30), should it be (K-1)/(K+1)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496508")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("So now I’m wondering what the derivative of a 1-parameter family of circle-packings is …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496521")[#strong[#text("Coloring Problems for Arrangements of Circles (and Pseudocircles) | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")]

#text("[…] Koebe’s circle packing theorem (see this recent post) this is precisely the four color theorem so the answer is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496726")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("Have you seen the notes of Stanislav Smirnov “Discrete Complex Analysis and Probability” ")#link("https://arxiv.org/abs/1009.6077")[#text("https://arxiv.org/abs/1009.6077")]#text(" these are from 8 years ago.")

#text("Actually these are totally different from the circle packings approach outlined by Thurston, Rodin, Sullivan, Stephenson and others. There’s also “Discrete Differential Geometry” by Bobenko-Suris. ")#link("http://page.math.tu-berlin.de/~bobenko/ddg-book.html")[#text("http://page.math.tu-berlin.de/~bobenko/ddg-book.html")]

#text("I have trouble memorizing the Cauchy-Riemann equations, so I start with the Taylor approximation ")#mi("f(z+dz) = f(z) + f^{\\prime}(z) dz")#text(" and I observe it could not matter if ")#mi("dz = dx, idy, \\cos \\theta dx + \\sin \\theta dy")#text(". I’m not 100% sure I can even do it still. Now that I’ve dropped out of school, I rarely use this material. ")#mi("f(z+dx) =  f(z) + (\\partial_x f) dx")#text(" however ")#mi("f(z + idy) = f(z) + i(\\partial y f)dy")#text(".")

#text("So I will obtain ")#mi("\\partial_x f = i \\partial y f")#text(" or ")#mi("(\\partial x - i \\partial y ) f = \\frac{\\partial}{\\partial \\overline{z}} f =  0")#text(" so that looks right. Good.")

#text("For the longest time, I’ve wondered… what’s so special about the Cauchy-Riemann equations? I haven’t even used this result in any intelligent way yet. For now, I content myself to know this is connected to circle packings and the ising model.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-496757")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("In Exercise 10, should the first sentence read “Let G be a maximal planar graph with at least four vertices” rather than “at most”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-497156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("same exercise (10): should the last set be G\\{v,v1,…,vd} rather than {v,v1,…,vd}?")

#emph[#text("[Corrected, thanks -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-497536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("In Exercise 15(i), should the last formula be")#linebreak()#text(" cos alpha_1(r_1,infty,infty) = 1 – 2exp(-2r_1)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-497644")[#strong[#text("246C notes 3: Univalent functions, the Loewner equation, and the Bieberbach conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("[…] To prove (i), it suffices from (11) and the Schwarz-Pick lemma (Exercise 13 from Notes 2) to establish this claim when . We can also assume that since the claim is trivial when . From the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ebe6de4cb9de9ac0c3a5d1059f9aa668ff783d49acdacd8b4ac3c00df70150c-07a9edce3bd51963008db0afe7af1327ba78ef0a7086c351daaa344225aa3dfc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-497815")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2018")])]

#text("Is are discrete conformal mappings such as (square tilings and circle packings) quasiconformal? We have that ")#mi("\\mathbb{Z}")#text(" and ")#mi("\\mathbb{Z} \\times \\big{\\left(\\mathbb{Z}/2\\mathbb{Z}\\right)}")

#text("Looks like sections 1 on Circle Packings and Section 2 on Quasiconformal maps combine in into sections 3 and 4 on rigidity and approximation.")

#text("You can draw a map of the United States out of squares using discrete conformal mappings. I wonder how they handled Utah-Arizona-New Mexico-Colorado?")

#text("These notes of Kenyon and Parry offer six models of the hyperbolic plane. At the moment I can only think of ")#mi("\\mathbb{H}")#text(" and ")#mi("\\mathbb{D}")#text(".")

#link("http://library.msri.org/books/Book31/files/cannon.pdf")[#text("Click to access cannon.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ab179caabf48ccc04e7e5b02ab843d2084f8c3699b9cc618659df2704f16b7e-3d4734d866c6409900270e83603843895ec1ff62198502a5e59d206bf319ac58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-498043")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2018")])]

#text("In Exercise 35, part (ii), the phi and mod should be interchanged.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-500284")[#strong[#text("246C notes 4: Brownian motion, conformal invariance, and SLE | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2018")])]

#text("[…] This gives an inequality similar in spirit to the Grötzsch modulus estimate from Notes 2: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622e7712b68708c5842e209f32622464735a12996ef985a281847519960272d1-ef9ef6b0c09fc550db9564ee67d67fd6e6d78236d392ce8f3ad7ae5a66c07327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Lohr")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-503068")[#strong[#text("Nick Lohr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2018")])]

#text("In the two paragraphs following right after the statement in Theorem 11, you mention Theorem 14 without stating it. Do you mean to say Theorem 11? In the last paragraph before Exercise 12, you say, “It remains to show Theorem 7.” Do you mean Theorem 11?")

#text("Also, isn’t it true that there exists a unique hyperbolic triangle with all sides infinite in $\\overline{D(0,1)}$ up to reflections and Möbius automorphisms? If so, is there a reason why its omitted from this discussion?")

#text("Lastly, a pedagogical question: Is it possible to reformulate Theorem 7 in the hyperbolic setting and prove Theorem 3,4 from it? This way one can get rid of Theorem 11 entirely and just deal with Theorem 14, right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-503087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2018")])]

#text("Thanks for the corrections. While a hyperbolic triangle with all infinite sides is indeed unique up to isometries, a hyperbolic triangle with three tangent circles centred at the vertices is not unique in this fashion, and this is really the geometric object of relevance in circle packings. Also some of the continuity statements fail if one tries to add this endpoint to the configuration space of triangles.")

#text("One can rearrange the presentation of the various theorems slightly, and one can certainly phrase Theorem 7 in the hyperbolic setting by specialising to the case when one of the circles is the exterior of the unit disk, but the inductive step still requires the use of Mobius transformations that preserve the Riemann sphere but not the hyperbolic disk, so I don’t see how to easily move the proof to entirely lie within the hyperbolic setting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622e7712b68708c5842e209f32622464735a12996ef985a281847519960272d1-ef9ef6b0c09fc550db9564ee67d67fd6e6d78236d392ce8f3ad7ae5a66c07327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Lohr")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-512629")[#strong[#text("Nick Lohr")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2019")])]

#text("Thank you. A few small typos: Before and after you use Cauchy-Schwarz in the proof of Caratheodory’s theorem the ")#mi("r")#text(" in the integrals should be ")#mi("r_n")#text(". In the proof of Proposition 23, the first equality should be an integral over ")#mi("\\gamma")#text(" and not ")#mi("\\phi")#text(". Also, in this proof, you use ")#mi("dz\\overline{dz}=dxdy")#text(" but isn’t it ")#mi("dz\\overline{dz}=-2idxdy")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622e7712b68708c5842e209f32622464735a12996ef985a281847519960272d1-ef9ef6b0c09fc550db9564ee67d67fd6e6d78236d392ce8f3ad7ae5a66c07327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Lohr")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-514490")[#strong[#text("Nick Lohr")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2019")])]

#text("Some more typos. In the statement and proof of Proposition 31, the ")#mi("R")#text(" should be ")#mi("T")#text(", the ")#mi("y_j")#text("‘s should be just ")#mi("y")#text("‘s, and there is a ")#mi("x^{\\prime}_y")#text(" that should be ")#mi("x^{\\prime}_j")#text(". Right before Exercise 35 when you are defining modulus for the annulus, the ")#mi("dz d \\overline{z}")#text(" should be just ")#mi("dxdy")#text(" to avoid complex numbers in the inequality.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622e7712b68708c5842e209f32622464735a12996ef985a281847519960272d1-ef9ef6b0c09fc550db9564ee67d67fd6e6d78236d392ce8f3ad7ae5a66c07327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Lohr")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-514704")[#strong[#text("Nick Lohr")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2019")])]

#text("Some more (important) typos (I’m doing this for my senior thesis which is why I am being so pesky). In the first indented line in Theorem 38, I think we only know ")#mi("\\leq")#text(" in the first equality. In the second indented line in this theorem, the ")#tao-math("d\\left|z\\right|", block: false)#text(" should be ")#tao-math("\\left|dz\\right|", block: false)#text(" and the ")#mi("\\leq")#text(" should be flipped to ")#mi("\\geq")#text(" (with ")#mi("2i")#text(" underneath the area form). In the last indented line of the theorem, the ")#tao-math("d\\left|z\\right|", block: false)#text("‘s should be ")#tao-math("\\left|dz\\right|", block: false)#text("‘s and the ")#mi("\\leq")#text(" needs to be flipped to ")#mi("\\geq")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/622e7712b68708c5842e209f32622464735a12996ef985a281847519960272d1-ef9ef6b0c09fc550db9564ee67d67fd6e6d78236d392ce8f3ad7ae5a66c07327.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Lohr")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-586499")[#strong[#text("Nick Lohr")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2020")])]

#text("What is the definition of homotopic triangulations used here? Beardon and Stephenson define homotopic closed chains within a simplicial 2-complex via “local modifications.” Is it a similar definition to this?")

#text("Also, is there a good reference for the topological fact that any two triangulations of a maximal planar graph of atleast four vertices are homotopic up to reflection (to reverse orientation)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e0a670ce8297524b3b07b41d8d5967557dc62a1e2efdc4d82c6fde0f49474dd-1deed55ca7609bd9ef0fe0f0f3c279f65c5e42bea924f9abf44ed1a2a899f25a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Hutchcroft")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-587490")[#strong[#text("Tom Hutchcroft")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2020")])]

#text("For the second question: This fact follows from Lemma 8.42 in Probability on Trees and Networks by Lyons and Peres ")#link("https://rdlyons.pages.iu.edu/prbtree/")[#text("https://rdlyons.pages.iu.edu/prbtree/")]#text(" They cite papers of Whitney (1932) and Imrich (1975) which I could not find copies of online.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-622835")[#strong[#text("246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: 246B Notes 4. Next set of notes: Notes 2. The fundamental object of study in real differential geometry are the real manifolds: Hausdorff […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/580272b3c941d1a69c4367f12c87f85433fe00c9865b2b9950b74d50312f7ce8-1f011b81f9c13eeb26460c48112a1e43b2d0d6691da1108b6dfa5949ca8c4435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-643255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("In Exercise 15(ii), do you mean d(\\gamma(s), \\gamma(t))= c|s-t|, instead of d(\\gamma(s)-gamma(t))?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-643566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2022")])]

#text("How does the spherical maximal operator related to circle packing? Does one help understand the other in anyway?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adc0ac16b9722ae13476af8d2686227550aea900d2f3df5e0ad9057f1a1baf31-21f98d97ca67498d846d783b1462117bfa254f329b2178dd1d63a666426cd3cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-643587")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2022")])]

#text("In the proof of Theorem 29, in the sixth line of the inequality chain, dx should be inside the absolute value.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a4e2bda2b511282fb631467b6bc557d9df960c78415d0b72d4665fa35e03a8c-95b83be551a02fec267b2fdc3e4b1f6f0a91e39b0547e3e1138126f3116e5207.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-643633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("In the proof of theorem 29, in the big chain of inequalities, I believe that the final equality should be an inequality instead.")#linebreak()#text(" \\phi(T + iy) and \\phi(iy) definitely lie on opposite sides of the rectangle, however they might not lie on the same imaginary line.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/#comment-643673")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2022")])]

#text("Does “rigidity of circle packing” omit a set of measure zero, while the “rigidity of hexagonal packing” is truly rigid?")
]
