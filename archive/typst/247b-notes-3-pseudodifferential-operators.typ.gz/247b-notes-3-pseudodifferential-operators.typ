// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/
// Converted to Typst by tao2typ: "2026-10-14T15:20:28.923606+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "247B, Notes 3: pseudodifferential operators", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("247B, Notes 3: pseudodifferential operators")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 May 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/")[#text("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In contrast to previous notes, in this set of notes we shall focus exclusively on Fourier analysis in the one-dimensional setting ")#mi("{d=1}")#text(" for simplicity of notation, although all of the results here have natural extensions to higher dimensions. Depending on the physical context, one can view the physical domain ")#mi("{{\\bf R}}")#text(" as representing either space or time; we will mostly think in terms of the former interpretation, even though the standard terminology of “time-frequency analysis”, which we will make more prominent use of in later notes, clearly originates from the latter.")

#text("In previous notes we have often performed various localisations in either physical space or Fourier space ")#mi("{{\\bf R}}")#text(", for instance in order to take advantage of the uncertainty principle. One can formalise these operations in terms of the functional calculus of two basic operations on Schwartz functions ")#mi("{{\\mathcal S}({\\bf R})}")#text(", the ")#emph[#text("position operator")]#text(" ")#mi("{X: {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("(Xf)(x) := x f(x)")]]

#text("and the ")#emph[#text("momentum operator")]#text(" ")#mi("{D: {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(", defined by ")#metadata(none) <tao-32c220482c68413fbf82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(Df)(x) := \\frac{1}{2\\pi i} \\frac{d}{dx} f(x).")]]

#text("(The terminology comes from quantum mechanics, where it is customary to also insert a small constant ")#mi("{h}")#text(" on the right-hand side of ")#link(<tao-32c220482c68413fbf82>)[#text("(1)")]#text(" in accordance with ")#link("https://en.wikipedia.org/wiki/Matter_wave")[#text("de Broglie’s law")]#text(". Such a normalisation is also used in several branches of mathematics, most notably semiclassical analysis and ")#link("https://en.wikipedia.org/wiki/Microlocal_analysis")[#text("microlocal analysis")]#text(", where it becomes profitable to consider the ")#link("https://en.wikipedia.org/wiki/Semiclassical_physics")[#text("semiclassical limit")]#text(" ")#mi("{h \\rightarrow 0}")#text(", but we will not emphasise this perspective here.) The momentum operator can be viewed as the counterpart to the position operator, but in frequency space instead of physical space, since we have the standard identity")

#align(center)[#tao-fit-display[#mitex("\\widehat{Df}(\\xi) = \\xi \\hat f(\\xi)")]]

#text("for any ")#mi("{\\xi \\in {\\bf R}}")#text(" and ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". We observe that both operators ")#mi("{X,D}")#text(" are formally self-adjoint in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle Xf, g \\rangle = \\langle f, Xg \\rangle; \\quad \\langle Df, g \\rangle = \\langle f, Dg \\rangle")]]

#text("for all ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(", where we use the ")#mi("{L^2({\\bf R})}")#text(" Hermitian inner product")

#align(center)[#tao-fit-display[#mitex("\\langle f, g\\rangle := \\int_{\\bf R} f(x) \\overline{g(x)}\\ dx.")]]

#text("Clearly, for any polynomial ")#mi("{P(x)}")#text(" of one real variable ")#mi("{x}")#text(" (with complex coefficients), the operator ")#mi("{P(X): {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" is given by the spatial multiplier operator")

#align(center)[#tao-fit-display[#mitex("(P(X) f)(x) = P(x) f(x)")]]

#text("and similarly the operator ")#mi("{P(D): {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" is given by the Fourier multiplier operator")

#align(center)[#tao-fit-display[#mitex("\\widehat{P(D) f}(\\xi) = P(\\xi) \\hat f(\\xi).")]]

#text("Inspired by this, if ")#mi("{m: {\\bf R} \\rightarrow {\\bf C}}")#text(" is any smooth function that obeys the derivative bounds ")#metadata(none) <tao-6e480ccdb5cfe7d560ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{d^j}{dx^j} m(x) \\lesssim_{m,j} \\langle x \\rangle^{O_{m,j}(1)}")]]

#text("for all ")#mi("{j \\geq 0}")#text(" and ")#mi("{x \\in {\\bf R}}")#text(" (that is to say, all derivatives of ")#mi("{m}")#text(" grow at most polynomially), then we can define the spatial multiplier operator ")#mi("{m(X): {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(m(X) f)(x) := m(x) f(x);")]]

#text("one can easily verify from several applications of the Leibniz rule that ")#mi("{m(X)}")#text(" maps Schwartz functions to Schwartz functions. We refer to ")#mi("{m(x)}")#text(" as the ")#emph[#text("symbol")]#text(" of this spatial multiplier operator. In a similar fashion, we define the Fourier multiplier operator ")#mi("{m(D)}")#text(" associated to the symbol ")#mi("{m(\\xi)}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\widehat{m(D) f}(\\xi) := m(\\xi) \\hat f(\\xi).")]]

#text("For instance, any constant coefficient linear differential operators ")#mi("{\\sum_{k=0}^n c_k \\frac{d^k}{dx^k}}")#text(" can be written in this notation as")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^n c_k \\frac{d^k}{dx^k} =\\sum_{k=0}^n c_k (2\\pi i D)^k;")]]

#text("however there are many Fourier multiplier operators that are not of this form, such as fractional derivative operators ")#mi("{\\langle D \\rangle^s = (1- \\frac{1}{4\\pi^2} \\frac{d^2}{dx^2})^{s/2}}")#text(" for non-integer values of ")#mi("{s}")#text(", which is a Fourier multiplier operator with symbol ")#mi("{\\langle \\xi \\rangle^s}")#text(". It is also very common to use spatial cutoffs ")#mi("{\\psi(X)}")#text(" and Fourier cutoffs ")#mi("{\\psi(D)}")#text(" for various bump functions ")#mi("{\\psi}")#text(" to localise functions in either space or frequency; we have seen several examples of such cutoffs in action in previous notes (often in the higher dimensional setting ")#mi("{d>1}")#text(").")

#text("We observe that the maps ")#mi("{m \\mapsto m(X)}")#text(" and ")#mi("{m \\mapsto m(D)}")#text(" are ring homomorphisms, thus for instance")

#align(center)[#tao-fit-display[#mitex("(m_1 + m_2)(D) = m_1(D) + m_2(D)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(m_1 m_2)(D) = m_1(D) m_2(D)")]]

#text("for any ")#mi("{m_1,m_2}")#text(" obeying the derivative bounds ")#link(<tao-6e480ccdb5cfe7d560ac>)[#text("(2)")]#text("; also ")#mi("{m(D)}")#text(" is formally adjoint to ")#mi("{\\overline{m(D)}}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle m(D) f, g \\rangle = \\langle f, \\overline{m}(D) g \\rangle")]]

#text("for ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(", and similarly for ")#mi("{m(X)}")#text(" and ")#mi("{\\overline{m}(X)}")#text(". One can interpret these facts as part of the ")#link("https://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text(" of the operators ")#mi("{X,D}")#text(", which can be interpreted as densely defined self-adjoint operators on ")#mi("{L^2({\\bf R})}")#text(". However, in this set of notes we will not develop the spectral theory necessary in order to fully set out this functional calculus rigorously.")

#text("In the field of PDE and ODE, it is also very common to study ")#emph[#text("variable coefficient")]#text(" linear differential operators ")#metadata(none) <tao-c66d1c378c60fac51347>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{k=0}^n c_k(x) \\frac{d^k}{dx^k}")]]

#text("where the ")#mi("{c_0,\\dots,c_n}")#text(" are now functions of the spatial variable ")#mi("{x}")#text(" obeying the derivative bounds ")#link(<tao-6e480ccdb5cfe7d560ac>)[#text("(2)")]#text(". A simple example is the ")#link("https://en.wikipedia.org/wiki/Quantum_harmonic_oscillator")[#text("quantum harmonic oscillator Hamiltonian")]#text(" ")#mi("{-\\frac{d^2}{dx^2} + x^2}")#text(". One can rewrite this operator in our notation as")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^n c_k(X) (2\\pi i D)^k")]]

#text("and so it is natural to interpret this operator as a combination ")#mi("{a(X,D)}")#text(" of both the position operator ")#mi("{X}")#text(" and the momentum operator ")#mi("{D}")#text(", where the ")#emph[#text("symbol")]#text(" ")#mi("{a: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" this operator is the function ")#metadata(none) <tao-03d506001a889aa1a0a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("a(x,\\xi) := \\sum_{k=0}^n c_k(x) (2\\pi i \\xi)^k.")]]

#text("Indeed, from the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\int_{\\bf R} \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("(2\\pi i D)^k f(x) = \\int_{\\bf R} (2\\pi i \\xi)^k \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("and hence on multiplying by ")#mi("{c_k(x)}")#text(" and summing we have")

#align(center)[#tao-fit-display[#mitex("(\\sum_{k=0}^n c_k(X) (2\\pi i D)^k) f(x) = \\int_{\\bf R} a(x,\\xi) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi.")]]

#text("Inspired by this, we can introduce the ")#emph[#text("Kohn-Nirenberg quantisation")]#text(" by defining the operator ")#mi("{a(X,D) = a_{KN}(X,D): {\\mathcal S}({\\bf R}) \\rightarrow {\\mathcal S}({\\bf R})}")#text(" by the formula ")#metadata(none) <tao-6e5cb8ddcabc1df6bc34>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("a(X,D) f(x) = \\int_{\\bf R} a(x,\\xi) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("whenever ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" and ")#mi("{a: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" is any smooth function obeying the derivative bounds ")#metadata(none) <tao-858c748f1a0b56abbf8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{\\partial^j}{\\partial x^j} \\frac{\\partial^l}{\\partial \\xi^l} a(x,\\xi) \\lesssim_{a,j,l} \\langle x \\rangle^{O_{a,j}(1)} \\langle \\xi \\rangle^{O_{a,j,l}(1)}")]]

#text("for all ")#mi("{j,l \\geq 0}")#text(" and ")#mi("{x \\in {\\bf R}}")#text(" (note carefully that the exponent in ")#mi("{x}")#text(" on the right-hand side is required to be uniform in ")#mi("{l}")#text("). This quantisation clearly generalises both the spatial multiplier operators ")#mi("{m(X)}")#text(" and the Fourier multiplier operators ")#mi("{m(D)}")#text(" defined earlier, which correspond to the cases when the symbol ")#mi("{a(x,\\xi)}")#text(" is a function of ")#mi("{x}")#text(" only or ")#mi("{\\xi}")#text(" only respectively. Thus we have combined the physical space ")#mi("{{\\bf R} = \\{ x: x \\in {\\bf R}\\}}")#text(" and the frequency space ")#mi("{{\\bf R} = \\{ \\xi: \\xi \\in {\\bf R}\\}}")#text(" into a single domain, known as ")#link("https://en.wikipedia.org/wiki/Phase_space")[#text("phase space")]#text(" ")#mi("{{\\bf R} \\times {\\bf R} = \\{ (x,\\xi): x,\\xi \\in {\\bf R} \\}}")#text(". The term “time-frequency analysis” encompasses analysis based on decompositions and other manipulations of phase space, in much the same way that “Fourier analysis” encompasses analysis based on decompositions and other manipulations of frequency space. We remark that the Kohn-Nirenberg quantization is not the only choice of quantization one could use; see Remark ")#link(<tao-e3d8c301b327d61d49b7>)[#text("19")]#text(" below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-4de68741919ee91805e5>

#list(
[#text("(i) Show that for ")#mi("{a}")#text(" obeying ")#link(<tao-858c748f1a0b56abbf8c>)[#text("(6)")]#text(", that ")#mi("{a(X,D)}")#text(" does indeed map ")#mi("{{\\mathcal S}({\\bf R})}")#text(" to ")#mi("{{\\mathcal S}({\\bf R})}")#text(".")],
[#text("(ii) Show that the symbol ")#mi("{a}")#text(" is uniquely determined by the operator ")#mi("{a(X,D)}")#text(". That is to say, if ")#mi("{a,b}")#text(" are two functions obeying ")#link(<tao-858c748f1a0b56abbf8c>)[#text("(6)")]#text(" with ")#mi("{a(X,D) f = b(X,D) f}")#text(" for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", then ")#mi("{a=b}")#text(". (")#emph[#text("Hint:")]#text(" apply ")#mi("{a(X,D)-b(X,D)}")#text(" to a suitable truncation of a plane wave ")#mi("{x \\mapsto e^{2\\pi i x \\xi}}")#text(" and then take limits.)")]
)
]

#text("In principle, the quantisations ")#mi("{a(X,D)}")#text(" are potentially very useful for such tasks as inverting variable coefficient linear operators, or to localize a function simultaneously in physical and Fourier space. However, a fundamental difficulty arises: map from symbols ")#mi("{a}")#text(" to operators ")#mi("{a(X,D)}")#text(" is now no longer a ring homomorphism, in particular ")#metadata(none) <tao-891b3a5946056b8ca897>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(a_1 a_2)(X,D) \\neq a_1(X,D) a_2(X,D)")]]

#text("in general. Fundamentally, this is due to the fact that pointwise multiplication of symbols is a commutative operation, whereas the composition of operators such as ")#mi("{X}")#text(" and ")#mi("{D}")#text(" does not necessarily commute. This lack of commutativity can be measured by introducing the ")#emph[#text("commutator")]

#align(center)[#tao-fit-display[#mitex("[A,B] := AB - BA")]]

#text("of two operators ")#mi("{A,B}")#text(", and noting from the product rule that")

#align(center)[#tao-fit-display[#mitex("[X,D] = -\\frac{1}{2\\pi i} \\neq 0.")]]

#text("(In the language of Lie groups and Lie algebras, this tells us that ")#mi("{X,D}")#text(" are (up to complex constants) the standard Lie algebra generators of the ")#link("https://en.wikipedia.org/wiki/Heisenberg_group")[#text("Heisenberg group")]#text(".) From a quantum mechanical perspective, this lack of commutativity is the root cause of the ")#link("https://en.wikipedia.org/wiki/Uncertainty_principle")[#text("uncertainty principle")]#text(" that prevents one from simultaneously localizing in both position and momentum past a certain point. Here is one basic way of formalising this principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Heisenberg uncertainty principle)")]#text(" ")#metadata(none) <tao-7e3578ed551203b40d60>#text(" For any ")#mi("{x_0, \\xi_0 \\in {\\bf R}}")#text(" and ")#mi("{f \\in \\mathcal{S}({\\bf R})}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (X-x_0) f \\right\\|_{L^2({\\bf R})} \\left\\| (D-\\xi_0) f\\right\\|_{L^2({\\bf R})} \\geq \\frac{1}{4\\pi} \\left\\|f\\right\\|_{L^2({\\bf R})}^2.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" evaluate the expression ")#mi("{\\langle [X-x_0, D - \\xi_0] f, f \\rangle}")#text(" in two different ways and apply the Cauchy-Schwarz inequality.) Informally, this exercise asserts that the spatial uncertainty ")#mi("{\\Delta x}")#text(" and the frequency uncertainty ")#mi("{\\Delta \\xi}")#text(" of a function obey the Heisenberg uncertainty relation ")#mi("{\\Delta x \\Delta \\xi \\gtrsim 1}")#text(".")
]

#text("Nevertheless, one still has the ")#link("https://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(", which asserts that in certain regimes (which, with our choice of normalisations, corresponds to the high-frequency regime), quantum mechanics continues to behave like a commutative theory, and one can sometimes proceed as if the operators ")#mi("{X,D}")#text(" (and the various operators ")#mi("{a(X,D)}")#text(" constructed from them) commute up to “lower order” errors. This can be formalised using the ")#emph[#text("pseudodifferential calculus")]#text(", which we give below the fold, in which we restrict the symbol ")#mi("{a}")#text(" to certain “symbol classes” of various orders (which then restricts ")#mi("{a(X,D)}")#text(" to be ")#link("https://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(" of various orders), and obtains approximate identities such as")

#align(center)[#tao-fit-display[#mitex("(a_1 a_2)(X,D) \\approx a_1(X,D) a_2(X,D)")]]

#text("where the error between the left and right-hand sides is of “lower order” and can in fact enjoys a useful asymptotic expansion. As a first approximation to this calculus, one can think of functions ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" as having some sort of “")#link("https://en.wikipedia.org/wiki/Phase_portrait")[#text("phase space portrait")]#text("” ")#mi("{\\tilde f(x,\\xi)}")#text(" which somehow combines the physical space representation ")#mi("{x \\mapsto f(x)}")#text(" with its Fourier representation ")#mi("{\\xi \\mapsto f(\\xi)}")#text(", and pseudodifferential operators ")#mi("{a(X,D)}")#text(" behave approximately like “phase space multiplier operators” in this representation in the sense that")

#align(center)[#tao-fit-display[#mitex("\\widetilde{a(X,D) f}(x,\\xi) \\approx a(x,\\xi) \\tilde f(x,\\xi).")]]

#text("Unfortunately the uncertainty principle (or the non-commutativity of ")#mi("{X}")#text(" and ")#mi("{D}")#text(") prevents us from making these approximations perfectly precise, and it is not always clear how to even define a phase space portrait ")#mi("{\\tilde f}")#text(" of a function ")#mi("{f}")#text(" precisely (although there are certain popular candidates for such a portrait, such as the ")#link("https://en.wikipedia.org/wiki/Fourier%E2%80%93Bros%E2%80%93Iagolnitzer_transform")[#text("FBI transform")]#text(" (also known as the ")#link("https://en.wikipedia.org/wiki/Gabor_transform")[#text("Gabor transform")]#text(" in signal processing literature), or the ")#link("https://en.wikipedia.org/wiki/Wigner_quasiprobability_distribution")[#text("Wigner quasiprobability distribution")]#text(", each of which have some advantages and disadvantages). Nevertheless even if the concept of a phase space portrait is somewhat fuzzy, it is of great conceptual benefit both within mathematics and outside of it. For instance, the musical score one assigns a piece of music can be viewed as a phase space portrait of the sound waves generated by that music.")

#text("To complement the pseudodifferential calculus we have the basic ")#emph[#text("Calderón-Vaillancourt theorem")]#text(", which asserts that pseudodifferential operators of order zero are Calderón-Zygmund operators and thus bounded on ")#mi("{L^p({\\bf R})}")#text(" for ")#mi("{1 < p < \\infty}")#text(". The standard proof of this theorem is a classic application of one of the basic techniques in harmonic analysis, namely the exploitation of ")#emph[#text("almost orthogonality")]#text("; the proof we will give here will achieve this through the elegant device of the ")#link("https://en.wikipedia.org/wiki/Cotlar%E2%80%93Stein_lemma")[#text("Cotlar-Stein lemma")]#text(".")

#text("Pseudodifferential operators (especially when generalised to higher dimensions ")#mi("{d \\geq 1}")#text(") are a fundamental tool in the theory of linear PDE, as well as related fields such as semiclassical analysis, microlocal analysis, and geometric quantisation. There is an even wider class of operators that is also of interest, namely the ")#link("https://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(", which roughly speaking not only approximately multiply the phase space portrait ")#mi("{\\tilde f(x,\\xi)}")#text(" of a function by some multiplier ")#mi("{a(x,\\xi)}")#text(", but also move the portrait around by a ")#link("https://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformation")]#text(". However, the development of theory of these operators is beyond the scope of these notes; see for instance the texts ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1481433")[#text("of Hormander")]#text(" or ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2809923")[#text("Eskin")]#text(".")

#text("This set of notes is only the briefest introduction to the theory of pseudodifferential operators. Many texts are available that cover the theory in more detail, for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1766415")[#text("this text of Taylor")]#text(".")

#metadata(none) <tao-0448f3dbb2b13d697bb7>

#heading(level: 1)[#strong[#text(" — 1. Pseudodifferential operators — ")]]

#text("The Kohn-Nirenberg quantisation ")#mi("{a(X,D)}")#text(" was defined above for any symbol ")#mi("{a: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" obeying the very loose estimates ")#link(<tao-858c748f1a0b56abbf8c>)[#text("(6)")]#text(". To obtain a clean theory it is convenient to focus attention to more restrictive classes of symbols. There are many such classes one can consider, but we shall only work with the classical symbol classes:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Classical symbol class)")]#text(" ")#metadata(none) <tao-9ecdab8fb971f60dfd51>#text(" Let ")#mi("{\\alpha \\in {\\bf R}}")#text(". A function ")#mi("{a: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" is said to be a (classical) ")#emph[#text("symbol of order ")#mi("{\\alpha}")]#text(" if it is smooth and one has the derivative bounds ")#metadata(none) <tao-1e6f0e135d02e63456c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{\\partial^j}{\\partial x^j} \\frac{\\partial^l}{\\partial \\xi^l} a(x,\\xi) \\lesssim_{a,j,l} \\langle \\xi \\rangle^{\\alpha - l}")]]

#text("for all ")#mi("{j,l \\geq 0}")#text(" and ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(". (Informally: ")#mi("{a}")#text(" “behaves like” ")#mi("{\\langle \\xi \\rangle^\\alpha}")#text(", with each derivative in the frequency variable gaining an additional decay factor of ")#mi("{\\langle \\xi \\rangle^{-1}}")#text(", but with each derivative in the spatial variable exhibiting no gain.) The collection of all symbols of order ")#mi("{\\alpha}")#text(" will be denoted ")#mi("{{\\mathcal S}^\\alpha}")#text(". If ")#mi("{a}")#text(" is a symbol of order ")#mi("{\\alpha}")#text(", the operator ")#mi("{a(X,D)}")#text(" is referred to as a ")#link("https://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operator")]#text(" of order ")#mi("{\\alpha}")#text(".")
]

#text("As a major motivating example, any variable coefficient linear differential operator ")#link(<tao-c66d1c378c60fac51347>)[#text("(3)")]#text(" of order ")#mi("{n}")#text(" will be a pseudodifferential operator of order ")#mi("{n}")#text(", so long as the coefficients ")#mi("{c_0,\\dots,c_n}")#text(" obey the bounds ")#metadata(none) <tao-103d6254a6d94bacc82e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\frac{d^j}{d x^j} c_k(x) \\lesssim_{c_k, j} 1")]]

#text("for ")#mi("{j \\geq 0}")#text(", ")#mi("{k=0,\\dots,n}")#text(", and ")#mi("{x \\in {\\bf R}}")#text(". (This would then exclude operators with unbounded coefficients, such as the harmonic oscillator, but can handle localised versions of these operators, and in any event there are other symbol classes in the literature that can be used to handle certain types of differential operators with unbounded coefficients.) Also, a fractional differential operator such as ")#mi("{(1 - 4\\pi^2 \\frac{d^2}{dx^2})^{\\alpha/2} = \\langle D \\rangle^\\alpha}")#text(" will be a pseudodifferential operator of order ")#mi("{\\alpha}")#text(" for any ")#mi("{\\alpha \\in {\\bf R}}")#text(". We refer the reader to ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1232192")[#text("Stein’s text")]#text(" for a discussion of more exotic symbol classes than the one given here.")

#text("The space of pseudodifferential operators of order ")#mi("{\\alpha}")#text(" form a vector space that is non-decreasing in ")#mi("{\\alpha}")#text(": any pseudodifferential operator of order ")#mi("{\\alpha}")#text(" is automatically also of order ")#mi("{\\beta}")#text(" for any ")#mi("{\\beta>\\alpha}")#text(". (Thus, strictly speaking, it would be more appropriate to say that ")#mi("{a(X,D)}")#text(" is a pseudodifferential operator of order ")#emph[#text("at most")]#text(" ")#mi("{\\alpha}")#text(" if ")#mi("{a \\in S^\\alpha}")#text(", but we will not adopt this convention for brevity.) The intuition to keep in mind is that a pseudodifferential operator of order ")#mi("{\\alpha}")#text(" behaves like a variable coefficient linear differential operator of order ")#mi("{\\alpha}")#text(", with the obvious caveat that in the latter case ")#mi("{\\alpha}")#text(" is restricted to be a natural number, whereas in the former ")#mi("{\\alpha}")#text(" can be any real number. This intuition will be supported by the various components of the ")#emph[#text("pseudodifferential calculus")]#text(" that we shall develop later, for instance we will show that the composition of a pseudodifferential operator of order ")#mi("{\\alpha}")#text(" and a pseudodifferential operator of order ")#mi("{\\beta}")#text(" is a pseudodifferential operator of order ")#mi("{\\alpha+\\beta}")#text(".")

#text("Before we set out this calculus, though, we give a fundamental ")#mi("{L^p}")#text(" estimate, which can be viewed as a variable coefficient version of the ")#link("https://en.wikipedia.org/wiki/Multiplier_(Fourier_analysis)#Mikhlin_multiplier_theorem")[#text("Hörmander-Mikhlin multiplier theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Calderón-Vallaincourt theorem)")]#text(" ")#metadata(none) <tao-29cdee48e28d81041865>#text(" Let ")#mi("{1 < p < \\infty}")#text(", and let ")#mi("{a(X,D)}")#text(" be a pseudodifferential operator of order ")#mi("{0}")#text(". Then one has ")#metadata(none) <tao-0cb6a51c7043809547a3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| a(X,D) f\\right\\|_{L^p({\\bf R})} \\lesssim_{a,p} \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". In particular, ")#mi("{a(X,D)}")#text(" extends to a bounded linear operator on each ")#mi("{L^p({\\bf R})}")#text(" space with ")#mi("{1 < p < \\infty}")#text(".")
]

#text("We now begin the proof of this theorem. The first step is a dyadic decomposition of Littlewood-Paley type. Let ")#mi("{\\phi \\in C^\\infty_c({\\bf R})}")#text(" be a bump function supported on ")#mi("{[-1,1]}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{[-1/2,1/2]}")#text(". Then we can write")

#align(center)[#tao-fit-display[#mitex("a(x,\\xi) = \\sum_{k=0}^\\infty a_k(x,\\xi)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("a_0(x,\\xi) := \\phi(\\xi) a(x,\\xi)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("a_k(x,\\xi) := (\\phi(\\xi/2^k) - \\phi(\\xi/2^{k-1})) a(x,\\xi)")]]

#text("for ")#mi("{k \\geq 1}")#text(". From dominated convergence, implies that")

#align(center)[#tao-fit-display[#mitex("a(X,D) f(x) = \\sum_{k=0}^\\infty a_k(X,D) f(x)")]]

#text("pointwise for ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". Thus by Fatou’s lemma, it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k=0}^K a_k(X,D) f \\right\\|_{L^p({\\bf R})} \\lesssim_{a,p} \\left\\|f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("uniformly in ")#mi("{K}")#text(". Observe from Definition ")#link(<tao-9ecdab8fb971f60dfd51>)[#text("3")]#text(" and the Leibniz rule that each ")#mi("{a_k}")#text(" is supported in the strip ")#mi("{\\{ (x,\\xi): \\langle \\xi \\rangle \\sim 2^k \\}}")#text(" and obeys the derivative estimates ")#metadata(none) <tao-6af237494ab4ec46570a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{\\partial^j}{\\partial x^j} \\frac{\\partial^l}{\\partial \\xi^l} a_k(x,\\xi) \\lesssim_{a,j,l} 2^{-kl}")]]

#text("for all ")#mi("{x,\\xi}")#text(".")

#text("From ")#link(<tao-6e5cb8ddcabc1df6bc34>)[#text("(5)")]#text(" and Fubini’s theorem we can express ")#mi("{a_k(X,D)}")#text(" as an integral operator ")#metadata(none) <tao-5f27777dd0341873a4da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("a_k(X,D) f(x) = \\int_{\\bf R} K_k(x,y) f(y)\\ dy")]]

#text("for ")#mi("{f \\in \\mathcal{S}({\\bf R})}")#text(", where the integral kernel ")#mi("{K_k(x,y)}")#text(" is given by the formula ")#metadata(none) <tao-1a5afeda973d776e31d1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("K_k(x,y) := \\int_{\\bf R} a_k(x,\\xi) e^{2\\pi i (x-y) \\xi}\\ d\\xi.")]]

#text("We can obtain several estimates on this kernel. Firstly, from the triangle inequality, ")#link(<tao-6af237494ab4ec46570a>)[#text("(11)")]#text(", and the support property of ")#mi("{a_k}")#text(" we have the trivial bound")

#align(center)[#tao-fit-display[#mitex("K_k(x,y) \\lesssim_a 2^k.")]]

#text("When ")#mi("{x \\neq y}")#text(", we may integrate by parts repeatedly, gaining factors of ")#tao-math("{O(\\frac{1}{\\left|x-y\\right|})}", block: false)#text(" at the cost of applying a ")#mi("{\\xi}")#text(" derivative to ")#mi("{a_k(x,\\xi)}")#text(" for each such factor, and then if one applies the triangle inequality, ")#link(<tao-6af237494ab4ec46570a>)[#text("(11)")]#text(", and support property of ")#mi("{a_k}")#text(" as before we conclude that ")#metadata(none) <tao-6ab9f1eb8f7d3388f4f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("K_k(x,y) \\lesssim_{a,l} 2^k (2^k \\left|x-y\\right|)^{-l}", block: true)]]

#text("for any ")#mi("{l \\geq 0}")#text("; by combining the estimates, we conclude that ")#metadata(none) <tao-015f7e6bc5aeaf483724>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("K_k(x,y) \\lesssim_{a,l} 2^k \\langle 2^k \\left|x-y\\right|\\rangle^{-l}", block: true)]]

#text("for all ")#mi("{x,y \\in {\\bf R}}")#text(" and ")#mi("{l \\geq 0}")#text(". Differentiating ")#link(<tao-1a5afeda973d776e31d1>)[#text("(13)")]#text(" in ")#mi("{x}")#text(" or ")#mi("{y}")#text(", and repeating the above arguments, we also obtain the estimates ")#metadata(none) <tao-2f5052c9fd15b19a18c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\frac{\\partial K_k}{\\partial x}(x,y), \\frac{\\partial K_k}{\\partial y}(x,y) \\lesssim_{a,l} 2^{2k} \\langle 2^k \\left|x-y\\right|\\rangle^{-l}.", block: true)]]

#text("Since the function ")#tao-math("{x \\mapsto 2^k \\langle 2^k \\left|x\\right| \\rangle^{-2}}", block: false)#text(" has an ")#mi("{L^1}")#text(" norm of ")#mi("{O(1)}")#text(" for any ")#mi("{k}")#text(", we now see from ")#link(<tao-5f27777dd0341873a4da>)[#text("(12)")]#text(" and Young’s inequality that ")#metadata(none) <tao-acc21b7a55e2ba509503>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left\\| a_k(X,D) f\\right\\|_{L^p({\\bf R})} \\lesssim_a \\left\\|f\\right\\|_{L^p({\\bf R})}.", block: true)]]

#text("Thus each component ")#mi("{a_k(X,D) f}")#text(" of ")#mi("{\\sum_{k=0}^K a_k(X,D) f}")#text(" is under control (so for instance we may now discard the ")#mi("{k=0}")#text(" term); the difficulty is to sum in ")#mi("{k}")#text(" without losing any ")#mi("{K}")#text("-dependent factors. To do this, we first observe from ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("(14)")]#text(", ")#link(<tao-015f7e6bc5aeaf483724>)[#text("(15)")]#text(" and a routine summation of that the total kernel ")#mi("{K(x,y) := \\sum_{k=0}^K K_k(x,y)}")#text(" (which is the integral kernel for ")#mi("{\\sum_{k=0}^K a_k(X,D)}")#text(") obeys the pointwise bound")

#align(center)[#tao-fit-display[#tao-math("K(x,y) \\lesssim_a \\frac{1}{\\left|x-y\\right|}", block: true)]]

#text("as well as the pointwise derivative bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\partial K}{\\partial x}(x,y), \\frac{\\partial K}{\\partial y}(x,y) \\lesssim_{a} \\frac{1}{\\left|x-y\\right|^2}.", block: true)]]

#text("These are the usual kernel bounds for one-dimensional Calderón-Zygmund theory. From that theory we conclude that in order to prove the ")#mi("{L^p}")#text(" estimate ")#link(<tao-0cb6a51c7043809547a3>)[#text("(10)")]#text(", it suffices to establish the ")#mi("{p=2}")#text(" case ")#metadata(none) <tao-3946ca64ff78d93ca610>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left\\| \\sum_{k=0}^K a_k(X,D) f\\right\\|_{L^2({\\bf R})} \\lesssim_{a} \\left\\|f\\right\\|_{L^2({\\bf R})}.", block: true)]]

#text("From ")#link(<tao-acc21b7a55e2ba509503>)[#text("(17)")]#text(", we have already established a preliminary bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_k(X,D) f\\right\\|_{L^2({\\bf R})} \\lesssim_{a} \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for each ")#mi("{k}")#text(", but a direct application of the triangle inequality will cost us a ")#mi("{K}")#text("-dependent factor, which we cannot afford. To do better, we need some “orthogonality” between the ")#mi("{a_k(X,D)}")#text(". The intuition here is that each component ")#mi("{a_k(X,D)}")#text(" only interacts with the portion of ")#mi("{L^2({\\bf R})}")#text(" that corresponds to frequencies ")#mi("{\\xi}")#text(" of magnitude ")#mi("{\\langle \\xi \\rangle \\sim 2^k}")#text(", and that these regions are somehow “orthogonal” to each other. Informally, this suggests that ")#metadata(none) <tao-3fc7c96a56b6e20ca727>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("a_k(X,D) \\approx P_k a_k(X,D) P_k")]]

#text("where ")#mi("{P_k}")#text(" is something like a Littlewood-Paley projection operator to frequencies ")#mi("{\\langle \\xi \\rangle \\sim 2^k}")#text(". If we accepted this heuristic, then we could informally use the Littlewood-Paley inequality (or ")#mi("{L^2}")#text(" decoupling theory) to calculate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{k=0}^K a_k(X,D) f \\right\\|_{L^2({\\bf R})} \\approx \\left\\| \\sum_{k=0}^K P_k a_k(X,D) P_k f \\right\\|_{L^2({\\bf R})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lessapprox (\\sum_{k=0}^K \\left\\| a_k(X,D) P_k f \\right\\|_{L^2({\\bf R})}^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lessapprox (\\sum_{k=0}^K \\left\\| P_k f \\right\\|_{L^2({\\bf R})}^2)^{1/2}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\left\\|f\\right\\|_{L^2({\\bf R})}.", block: true)]]

#text("It is possible to make this approximation ")#link(<tao-3fc7c96a56b6e20ca727>)[#text("(19)")]#text(" more precise and establish ")#link(<tao-3946ca64ff78d93ca610>)[#text("(18)")]#text(": see Exercise ")#link(<tao-4b5f3e00ae660faca142>)[#text("7")]#text(". However, we will take the opportunity to showcase another elegant way to exploit “almost orthogonality”, known as the ")#link("https://en.wikipedia.org/wiki/Cotlar%E2%80%93Stein_lemma")[#text("Cotlar-Stein lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Cotlar-Stein lemma)")]#text(" Let ")#mi("{T_1,\\dots,T_n: H \\rightarrow H^{\\prime}}")#text(" be bounded linear maps from one Hilbert space ")#mi("{H}")#text(" to another ")#mi("{H^{\\prime}}")#text(". Suppose that the maps ")#mi("{T_i^* T_j: H \\rightarrow H}")#text(" obey the operator norm bounds ")#metadata(none) <tao-8f434346648f6b96df89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\sum_{j=1}^n \\left\\|T_i^* T_j\\right\\|_{op}^{1/2} \\leq A", block: true)]]

#text("for all ")#mi("{i=1,\\dots,n}")#text(" and some ")#mi("{A \\geq 0}")#text(", and similarly the maps ")#mi("{T_i T_j^*: H^{\\prime} \\rightarrow H^{\\prime}}")#text(" obey the operator norm bounds ")#metadata(none) <tao-9294ab38039f60d2ec53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{j=1}^n \\left\\|T_i T_j^*\\right\\|_{op}^{1/2} \\leq B", block: true)]]

#text("for all ")#mi("{i=1,\\dots,n}")#text(" and some ")#mi("{B \\geq 0}")#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^n T_j \\right\\|_{op} \\leq \\sqrt{AB}.", block: true)]]
]

#text("Note that if the ")#mi("{T_i}")#text(" had pairwise orthogonal ranges then ")#mi("{T_i^* T_j}")#text(" would vanish whenever ")#mi("{i \\neq j}")#text(", and similarly if the ")#mi("{T_i}")#text(" had pairwise orthogonal coranges then the ")#mi("{T_i T_j^*}")#text(" would vanish whenever ")#mi("{i \\neq j}")#text(". Thus the hypotheses of the Cotlar-Stein lemma are indeed some quantitative form of “almost orthogonality” of the ")#mi("{T_i}")#text(".")

#emph[#text("Proof:")]#text(" We use the ")#mi("{TT^*}")#text(" method (which asserts that for a bounded linear map ")#mi("{T}")#text(" between Hilbert spaces, the operator norm of ")#mi("{TT^*}")#text(" or ")#mi("{T^* T}")#text(" is the square of that of ")#mi("{T}")#text(" or ")#mi("{T^*}")#text("). Applying this method to a single operator ")#mi("{T_i}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T_i\\right\\|_{op} = \\left\\| T_i^* T_i \\right\\|_{op}^{1/2} \\leq A", block: true)]]

#text("and similarly ")#metadata(none) <tao-1fbe8e4f4059ee0e7e8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#tao-math("\\left\\|T_i\\right\\|_{op} = \\left\\| T_i T_i^* \\right\\|_{op}^{1/2} \\leq B.", block: true)]]

#text("Taking geometric means we have ")#metadata(none) <tao-e2ea8eb98a17c6f005f4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#tao-math("\\left\\|T_i\\right\\|_{op} \\leq \\sqrt{AB},", block: true)]]

#text("then by the triangle inequality we have ")#tao-math("{\\left\\|\\sum_{j=1}^n T_j \\right\\|_{op} \\leq n \\sqrt{AB}}", block: false)#text(". This loses a factor of ")#mi("{n}")#text(" over the trivial bound. We can reduce this loss to ")#mi("{\\sqrt{n}}")#text(" by a further application of the ")#mi("{TT^*}")#text(" method as follows. Writing ")#mi("{T := \\sum_{j=1}^n T_j}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T \\right\\|_{op} = \\left\\| TT^* \\right\\|_{op}^{1/2} \\leq (\\sum_{i=1}^n \\sum_{j=1}^n \\left\\| T_i T_j^* \\right\\|_{op})^{1/2} \\leq (nB^2)^{1/2}", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T \\right\\|_{op} = \\left\\| T^*T \\right\\|_{op}^{1/2} \\leq (\\sum_{i=1}^n \\sum_{j=1}^n \\left\\| T_i^* T_j \\right\\|_{op})^{1/2} \\leq (nA^2)^{1/2}", block: true)]]

#text("so on taking geometric means we have ")#tao-math("{\\left\\|T\\right\\|_{op} \\leq n^{1/2} \\sqrt{AB}}", block: false)#text(".")

#text("We now reduce the loss in ")#mi("{n}")#text(" all the way to ")#mi("{1}")#text(" by iterating the ")#mi("{TT^*}")#text(" method (this is an instance of a neat trick in analysis, namely the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("). For any integer ")#mi("{m}")#text(" that is a power of two, we see from iterating the ")#mi("{TT^*}")#text(" method that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T \\right\\|_{op} = \\left\\| (T^* T)^m \\right\\|_{op}^{1/2m}.", block: true)]]

#text("(In fact, this identity holds for any natural number ")#mi("{m}")#text(", not just powers of two, as can be seen from spectral theory, but powers of two will suffice for the argument here.) We expand out the right-hand side and bound using the triangle inequality by")

#align(center)[#tao-fit-display[#tao-math("(\\sum_{i_1,\\dots,i_{2m} = 1,\\dots,n} \\left\\| T^*_{i_1} T_{i_2} T^*_{i_3} \\dots T^*_{i_{2m-1}} T_{i_{2m}} \\right\\|_{op})^{1/2m}.", block: true)]]

#text("On the one hand, we can bound the norm ")#tao-math("{\\left\\| T^*_{i_1} T_{i_2} T^*_{i_3} \\dots T^*_{i_{2m-1}} T_{i_{2m}} \\right\\|_{op}}", block: false)#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T^*_{i_1} T_{i_2} \\right\\|_{op} \\left\\| T^*_{i_3} T_{i_4} \\right\\|_{op} \\dots \\left\\| T^*_{i_{2m-1}} T_{i_{2m}} \\right\\|_{op};", block: true)]]

#text("grouping things slightly differently and using ")#link(<tao-1fbe8e4f4059ee0e7e8a>)[#text("(22)")]#text(" twice, we can also bound this norm by")

#align(center)[#tao-fit-display[#tao-math("B \\left\\| T_{i_2} T^*_{i_3} \\right\\|_{op} \\dots \\left\\| T_{i_{2m-2}} T^*_{i_{2m-1}} \\right\\|_{op} B.", block: true)]]

#text("Taking the geometric mean, we can bound the norm by")

#align(center)[#tao-fit-display[#tao-math("B \\left\\| T^*_{i_1} T_{i_2} \\right\\|_{op}^{1/2} \\left\\| T_{i_2} T^*_{i_3} \\right\\|_{op}^{1/2} \\dots \\left\\| T_{i_{2m-2}} T^*_{i_{2m-1}} \\right\\|_{op}^{1/2} \\left\\| T^*_{i_{2m-1}} T_{i_{2m}} \\right\\|_{op}^{1/2}.", block: true)]]

#text("Summing in ")#mi("{i_{2m}}")#text(" using ")#link(<tao-8f434346648f6b96df89>)[#text("(20)")]#text(", then in ")#mi("{i_{2m-1}}")#text(" using ")#link(<tao-9294ab38039f60d2ec53>)[#text("(21)")]#text(" and so forth until the ")#mi("{i_1}")#text(" sum (which is just summed with a loss of ")#mi("{n}")#text("), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|T\\right\\|_{op} \\leq (B n A B A \\dots B A)^{1/2m} = n^{1/2m} \\sqrt{AB}.", block: true)]]

#text("Sending ")#mi("{m \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" There is a refinement of the Cotlar-Stein lemma for infinite series ")#mi("{\\sum_{i=1}^\\infty T_i}")#text(" of operators obeying the hypotheses of the lemma, in which it is shown that the series actually converges in the strong operator topology (though not necessarily in the operator norm topology); this refinement was first observed by Meyer, and can be found for instance ")#link("https://www.math.tamu.edu/~comech/papers/CotlarStein/CotlarStein.pdf")[#text("in this note of Comech")]#text(".")
]

#text("We will shortly establish the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_k(X,D) a_j(X,D)^* f\\right\\|_{L^2({\\bf R})}, \\left\\| a_k(X,D)^* a_j(X,D) f\\right\\|_{L^2({\\bf R})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lesssim_{a} 2^{-\\left|j-k\\right|} \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for any ")#mi("{j,k \\geq 1}")#text(". The claim ")#link(<tao-3946ca64ff78d93ca610>)[#text("(18)")]#text(" then follows from the Cotlar-Stein lemma (using ")#link(<tao-acc21b7a55e2ba509503>)[#text("(17)")]#text(" to dispose of the ")#mi("{a_0(X,D)}")#text(" term).")

#text("We shall just show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| a_k(X,D)^* a_j(X,D) f\\right\\|_{L^2({\\bf R})} \\lesssim_{a} 2^{-(j-k)} \\left\\|f\\right\\|_{L^2({\\bf R})};", block: true)]]

#text("when ")#mi("{j \\geq k}")#text("; the ")#mi("{j < k}")#text(" case is treated similarly, as is the treatment of ")#mi("{a_k(X,D) a_j(X,D)^*}")#text(" (in fact this latter operator vanishes when ")#tao-math("{\\left|j-k\\right| \\geq 3}", block: false)#text(", though we will not really need this fact). We have")

#align(center)[#tao-fit-display[#mitex("a_k(X,D)^* a_j(X,D) f(x) = \\int_{\\bf R} K_{k^*j}(x,z) f(z)\\ dz")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_{k^*j}(x,z) := \\int_{\\bf R} \\overline{K_k}(y,x) K_j(y,z)\\ dy.")]]

#text("A direct application of ")#link(<tao-015f7e6bc5aeaf483724>)[#text("(15)")]#text(" and the triangle inequality gives the bounds")

#align(center)[#tao-fit-display[#mitex("K_{k^*j}(x,z) \\lesssim_{a} 2^k \\langle 2^k(x-z) \\rangle^{-10}")]]

#text("(say), which when combined with Young’s inequality does not give the desired gain of ")#mi("{2^{-(j-k)}}")#text(". To recover this gain we begin integrating by parts. From ")#link(<tao-1a5afeda973d776e31d1>)[#text("(13)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("K_j(y,z) =\\frac{\\partial}{\\partial y} \\int_{\\bf R} \\frac{a_j(y,\\xi)}{2\\pi i \\xi} e^{2\\pi i (y-z) \\xi}\\ d\\xi - \\int_{\\bf R} \\frac{\\partial}{\\partial y} \\frac{a_j(y,\\xi)}{2\\pi i \\xi} e^{2\\pi i (y-z) \\xi}\\ d\\xi.")]]

#text("Note that ")#mi("{\\frac{\\partial}{\\partial y} \\frac{a_j(y,\\xi)}{2\\pi i \\xi}}")#text(" obeys similar estimates to ")#mi("{a_j(y,\\xi)}")#text(" but with an additional gain of ")#mi("{2^{-j}}")#text(". Thus the contribution of this term to ")#mi("{K_{k^*j}}")#text(" will be acceptable. The contribution of the other term, after an integration by parts, is")

#align(center)[#tao-fit-display[#mitex("-\\int_{\\bf R} (\\frac{\\partial}{\\partial y} \\overline{K_k}(y,x)) \\int_{\\bf R} \\frac{a_j(y,\\xi)}{2\\pi i \\xi} e^{2\\pi i (y-z) \\xi}\\ d\\xi\\ dy.")]]

#text("The kernel ")#mi("{\\int_{\\bf R} \\frac{a_j(y,\\xi)}{2\\pi i \\xi} e^{2\\pi i (y-z) \\xi}\\ d\\xi}")#text(" obeys the same bounds as ")#link(<tao-015f7e6bc5aeaf483724>)[#text("(15)")]#text(" but with an additional gain of ")#mi("{2^{-j}}")#text("; similarly from ")#link(<tao-2f5052c9fd15b19a18c5>)[#text("(16)")]#text(" the expression ")#mi("{\\frac{\\partial}{\\partial y} \\overline{K_k}(y,x)}")#text(" obeys the same bounds as ")#link(<tao-015f7e6bc5aeaf483724>)[#text("(15)")]#text(" but with an additional loss of ")#mi("{2^k}")#text(". The claim follows. This concludes the proof of the Calderón-Vaillancourt theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-4b5f3e00ae660faca142>#text(" With the hypotheses as above, and with ")#mi("{P_j}")#text(" a suitable Littlewood-Paley projection to frequencies ")#mi("{\\langle \\xi \\rangle \\sim 2^j}")#text(", establish the ")#mi("{L^2}")#text(" operator norm bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P_j a_k(X,D) f \\right\\|_{L^2({\\bf R})}, \\left\\| a_k(X,D) P_j f \\right\\|_{L^2({\\bf R})} \\lesssim_a 2^{-\\left|j-k\\right|} \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for all ")#mi("{j,k \\geq 0}")#text(" and ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(". Use this to provide an alternate proof of ")#link(<tao-3946ca64ff78d93ca610>)[#text("(18)")]#text(" that does not require the Cotlar-Stein lemma.")
]

#text("Now we give a preliminary composition estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Preliminary composition)")]#text(" ")#metadata(none) <tao-67662fcc7db7368e68d7>#text(" Let ")#mi("{a(X,D)}")#text(" be a pseudodifferential operator of some order ")#mi("{\\alpha \\in {\\bf R}}")#text(", and let ")#mi("{b(X,D)}")#text(" be a pseudodifferential operator of some order ")#mi("{\\beta \\in {\\bf R}}")#text(". Then the composition ")#mi("{a(X,D) b(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{\\alpha+\\beta}")#text(", thus there exists ")#mi("{a*b \\in {\\mathcal S}^{\\alpha+\\beta}}")#text(" such that ")#mi("{(a*b)(X,D) = a(X,D) b(X,D)}")#text(" (note from Exercise ")#link(<tao-4de68741919ee91805e5>)[#text("1")]#text(" that ")#mi("{a*b}")#text(" is uniquely determined).")
]

#emph[#text("Proof:")]#text(" We begin with some technical reductions in order to justify some later exchanges of integrals. We can express the symbol ")#mi("{a(x,\\xi)}")#text(" as a locally uniform limit of truncated symbols ")#mi("{a_R(x,\\xi) := a(x,\\xi) \\phi(x/R) \\phi(\\xi/R)}")#text(" as ")#mi("{R \\rightarrow \\infty}")#text(", where ")#mi("{\\phi \\in C^\\infty_c({\\bf R})}")#text(" is a bump function equal to ")#mi("{1}")#text(" near the origin; from the product rule we see that the symbol estimates ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(" are obeyed by the ")#mi("{a_R}")#text(" uniformly in ")#mi("{R}")#text(" as long as ")#mi("{R \\geq 1}")#text(". If ")#mi("{f}")#text(" is Schwartz, then so is ")#mi("{b(X,D) f}")#text(", and ")#mi("{a_R(X,D) b(X,D) f}")#text(" can be verified to converge pointwise to ")#mi("{a(X,D) b(X,D) f}")#text(". If one can show that ")#mi("{a_R(X,D) b(X,D) = c_R(X,D)}")#text(" for some pseudodifferential operator ")#mi("{c_R(X,D)}")#text(" of order ")#mi("{\\alpha+\\beta}")#text(", with all the required symbol estimates ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(" on ")#mi("{c_R}")#text(" obeyed uniformly in ")#mi("{R}")#text(", then the claim will follow by using the Arzelà-Ascoli theorem to extract a locally uniformly convergent susbequence of the ")#mi("{c_R}")#text(" and taking a limit. The upshot of this is that we may assume without loss of generality that the symbol ")#mi("{a(x,\\xi)}")#text(" is compactly supported in ")#mi("{x,\\xi}")#text(", so long as our estimates do not depend on the size of this compact support, but only on the constants in the symbol bounds ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(" for ")#mi("{a}")#text(".")

#text("Similarly, we may approximate ")#mi("{b(x,\\xi)}")#text(" locally uniformly as the limit of symbols ")#mi("{b_R(x,\\xi)}")#text(" that are compactly supprted in ")#mi("{x,\\xi}")#text(", which makes ")#mi("{b_R(X,D) f}")#text(" converge locally uniformly to ")#mi("{b(X,D)}")#text("; from the compact support of ")#mi("{a(x,\\xi)}")#text(" this also shows that ")#mi("{a(X,D) b_R(X,D) f}")#text(" converges pointwise to ")#mi("{a(X,D) b(X,D) f}")#text(". From the same limiting argument as before, we may thus assume that ")#mi("{b}")#text(" is compactly supported in ")#mi("{x,\\xi}")#text(", so long as our estimates do not depend on the size of this support, but only on the constants in the symbol bounds ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(" for ")#mi("{b}")#text(".")

#text("For ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("b(X,D) f(y) = \\int_{\\bf R} b(y,\\xi) \\hat f(\\xi) e^{2\\pi i y \\xi}\\ d\\xi")]]

#text("hence on taking Fourier transforms")

#align(center)[#tao-fit-display[#mitex("\\widehat{b(X,D) f}(\\eta) = \\int_{\\bf R} \\int_{\\bf R} b(y,\\xi) \\hat f(\\xi) e^{2\\pi i (y \\xi- y\\eta)}\\ d\\xi dy")]]

#text("hence")

#align(center)[#tao-fit-display[#mitex("a(X,D) b(X,D) f(x) = \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} a(x,\\eta) b(y,\\xi) \\hat f(\\xi) e^{2\\pi i (y \\xi-y\\eta + x \\eta)}\\ d\\xi dy d\\eta")]]

#text("and hence by Fubini’s theorem (and the compact support of ")#mi("{a,b}")#text(" and the Schwartz nature of ")#mi("{f}")#text(") we have ")#mi("{a(X,D) b(X,D) = (a \\ast b)(X,D)}")#text(", where ")#metadata(none) <tao-a969fe535ca445c5f6b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("(a \\ast b)(x,\\xi) := \\int_{\\bf R} \\int_{\\bf R} a(x,\\eta) b(y,\\xi) e^{2\\pi i (y-x)(\\xi-\\eta)}\\ dy d\\eta.")]]

#text("Our task is now to show that ")#metadata(none) <tao-525a6f3c9deda2f8d2e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\frac{\\partial^j}{\\partial x^j} \\frac{\\partial^l}{\\partial \\xi^l} (a \\ast b)(x,\\xi) \\lesssim_{a,b,\\alpha,\\beta,j,l} \\langle \\xi \\rangle^{\\alpha+\\beta-l},")]]

#text("for all ")#mi("{j,l \\geq 0}")#text(" and ")#mi("{x,\\xi \\in {\\bf R}}")#text(", where the understanding is that the dependence of constants on ")#mi("{a,b}")#text(" is only through the symbol bounds ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(" for these symbols.")

#text("From differentiation under the integral sign and integration by parts we obtain the Leibniz identities")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial x} (a \\ast b) = (\\frac{\\partial}{\\partial x} a) \\ast b + a \\ast (\\frac{\\partial}{\\partial x} b)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial \\xi} (a \\ast b) = (\\frac{\\partial}{\\partial \\xi} a) \\ast b + a \\ast (\\frac{\\partial}{\\partial \\xi} b).")]]

#text("From this and an induction on ")#mi("{j+l}")#text(" (varying ")#mi("{\\alpha,\\beta}")#text(" as necessary, noting that if ")#mi("{\\frac{\\partial}{\\partial x}}")#text(" maps ")#mi("{{\\mathcal S}^\\alpha}")#text(" to ")#mi("{{\\mathcal S}^\\alpha}")#text(" and ")#mi("{\\frac{\\partial}{\\partial \\xi}}")#text(" maps ")#mi("{{\\mathcal S}^\\beta}")#text(" to ")#mi("{{\\mathcal S}^{\\beta-1}}")#text(") we see that to prove ")#link(<tao-525a6f3c9deda2f8d2e5>)[#text("(25)")]#text(" it suffices to do so in the ")#mi("{j=l=0}")#text(" case, thus we now only need to show that ")#metadata(none) <tao-e9058ab198f6908f7021>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\int_{\\bf R} \\int_{\\bf R} a(x,\\eta) b(y,\\xi) e^{2\\pi i (y-x)(\\xi-\\eta)}\\ dy d\\eta \\lesssim_{a,b,\\alpha,\\beta} \\langle \\xi \\rangle^{\\alpha+\\beta}")]]

#text("for a given ")#mi("{x,\\xi}")#text(".")

#text("Applying a smooth partition of unity in the ")#mi("{\\eta}")#text(" variable to ")#mi("{a}")#text(", it suffices to verify the claim in one of two cases:")

#list(
[#mi("{a(x,\\eta)}")#text(" is supported in the region ")#tao-math("{\\{ (x,\\eta): \\left|\\eta - \\xi\\right| \\leq \\langle \\xi \\rangle/2 \\}}", block: false)#text(" (so in particular ")#mi("{\\langle \\eta \\rangle \\sim \\langle \\xi \\rangle}")#text(").")],
[#mi("{a(x,\\eta)}")#text(" is supported in the region ")#tao-math("{\\{ (x,\\eta): \\left|\\eta - \\xi\\right| \\geq \\langle \\xi \\rangle/4 \\}}", block: false)#text(".")]
)

#text("(One can verify that applying the required cutoffs to ")#mi("{a}")#text(" do not significantly worsen the symbol estimates ")#link(<tao-1e6f0e135d02e63456c9>)[#text("(8)")]#text(".) In the former case we write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} K_x(x-y) b(y,\\xi) e^{2\\pi i (y-x)\\xi}\\ dy")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_x(z) := \\int_{\\bf R} a(x,\\eta) e^{2\\pi i z \\eta}\\ d\\eta.")]]

#text("By repeating the proof of ")#link(<tao-6ab9f1eb8f7d3388f4f9>)[#text("(14)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("K_x(z) \\lesssim_{a,\\alpha} \\langle \\xi \\rangle^{\\alpha+1} \\langle \\langle \\xi \\rangle z \\rangle^{-2}")]]

#text("so from this and the symbol bound ")#mi("{b(y,\\xi) \\lesssim_b \\langle \\xi\\rangle^\\beta}")#text(" we obtain the claim in this case.")

#text("It remains to handle the latter case. Here we integrate by parts repeatedly in the ")#mi("{y}")#text(" variable to write the left-hand side of ")#link(<tao-e9058ab198f6908f7021>)[#text("(26)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} \\frac{a(x,\\eta)}{(2\\pi i(\\eta-\\xi))^m} \\frac{\\partial^m}{\\partial y^m} b(y,\\xi) e^{2\\pi i (y-x)(\\xi-\\eta)}\\ dy d\\eta")]]

#text("for any ")#mi("{m}")#text(". Then as before we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} K_{x,m}(x-y) \\frac{\\partial^m}{\\partial y^m} b(y,\\xi) e^{2\\pi i (y-x)\\xi}\\ dy")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_{x,m}(z) := \\int_{\\bf R} \\frac{a(x,\\eta)}{(2\\pi i(\\eta-\\xi))^m} e^{2\\pi i z \\eta}\\ d\\eta.")]]

#text("By taking ")#mi("{m}")#text(" large enough we will eventually recover the bound")

#align(center)[#tao-fit-display[#mitex("K_{x,m}(z) \\lesssim_{a,\\alpha} \\langle \\xi \\rangle^{\\alpha+1} \\langle \\langle \\xi \\rangle z \\rangle^{-2}")]]

#text("(in fact one can gain arbitrary powers of ")#mi("{\\langle \\xi \\rangle}")#text(" if desired), and so by repeating the previous arguments we also obtain the claim in this case. ")#mi("\\Box")

#text("The above proposition shows that if ")#mi("{a \\in {\\mathcal S}^\\alpha}")#text(" and ")#mi("{b \\in {\\mathcal S}^\\beta}")#text(" then ")#mi("{a \\ast b \\in {\\mathcal S}^{\\alpha+\\beta}}")#text(". The following exercise gives some refinements to this fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9 (Composition of pseudodifferential operators)")]#text(" ")#metadata(none) <tao-a4047d44f578e8f89bbf>#text(" Let ")#mi("{a \\in {\\mathcal S}^\\alpha}")#text(" and ")#mi("{b \\in {\\mathcal S}^\\beta}")#text(" for some ")#mi("{\\alpha,\\beta \\in {\\bf R}}")#text(".")

#list(
[#text("(i) Show that ")#mi("{a \\ast b - ab \\in {\\mathcal S}^{\\alpha+\\beta-1}}")#text(". (")#emph[#text("Hint:")]#text(" reduce as before to the case where ")#mi("{a,b}")#text(" are compactly supported, and use the fundamental theorem of calculus to write ")#mi("{a(x,\\eta) = a(x,\\xi) + (\\eta-\\xi) \\int_0^1 a_\\xi(x, \\xi + t(\\eta-\\xi))\\ dt}")#text(", where ")#mi("{a_\\xi(x,\\xi) := \\frac{\\partial a}{\\partial \\xi}(x,\\xi)}")#text(". Then use the Fourier inversion formula, integration by parts, and arguments similar to those used to prove Theorem ")#link(<tao-67662fcc7db7368e68d7>)[#text("8")]#text(".")],
[#text("(ii) Show that ")#mi("{a \\ast b - ab - \\frac{1}{2\\pi i} a_\\xi b_x \\in {\\mathcal S}^{\\alpha+\\beta-2}}")#text(", where ")#mi("{a_\\xi(x,\\xi) := \\frac{\\partial a}{\\partial \\xi}(x,\\xi)}")#text(" and ")#mi("{b_x(x,\\xi) := \\frac{\\partial b}{\\partial x}(x,\\xi)}")#text(". (Hint: now apply the fundamental theorem of calculus once more to expand ")#mi("{a_\\xi(x,\\xi+t(\\eta-\\xi))}")#text(".)")],
[#text("(iii) Check (i) and (ii) directly in the classical case when ")#mi("{a(x,\\xi) = A(x) \\xi^l}")#text(" and ")#mi("{b(x,\\xi) = B(x) \\xi^m}")#text(" for some smooth ")#mi("{A,B}")#text(" obeying the bounds ")#link(<tao-103d6254a6d94bacc82e>)[#text("(9)")]#text(" and for ")#mi("{l,m \\geq 0}")#text(". Based on this, for any integer ")#mi("{r \\geq 0}")#text(", make a prediction for an approximation to ")#mi("{a \\ast b}")#text(" as a polynomial combination of the symbols arbitrary ")#mi("{a \\in {\\mathcal S}^\\alpha, b \\in {\\mathcal S}^\\beta}")#text(" and finitely many of their derivatives which is accurate up to an error in ")#mi("{{\\mathcal S}^{\\alpha+\\beta-r}}")#text(". Then verify this prediction.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" ")#metadata(none) <tao-88b3e13a98900e3dfa4b>#text(" From Exercise ")#link(<tao-a4047d44f578e8f89bbf>)[#text("9")]#text(" we see that if ")#mi("{a(X,D), b(X,D)}")#text(" are pseudodifferential operators of order ")#mi("{\\alpha,\\beta}")#text(" respectively, then the commutator ")#mi("{[a(X,D),b(X,D)]}")#text(" differs from ")#mi("{\\frac{1}{2\\pi i} \\{a,b\\}(X,D)}")#text(" by a pseudodifferential operator of order ")#mi("{\\alpha+\\beta-2}")#text(", where ")#mi("{\\{a,b\\}}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Poisson_bracket")[#text("Poisson bracket")]

#align(center)[#tao-fit-display[#mitex("\\{a,b\\}(x,\\xi) := \\frac{\\partial a}{\\partial \\xi}(x,\\xi) \\frac{\\partial b}{\\partial x}(x,\\xi) - \\frac{\\partial a}{\\partial x}(x,\\xi) \\frac{\\partial b}{\\partial \\xi}(x,\\xi).")]]

#text("This approximate correspondence between the Lie bracket ")#mi("{[,]}")#text(" (which plays a fundamental role in the dynamics of quantum mechanics) and the Poisson bracket ")#mi("{\\{,\\}}")#text(" (which plays a fundamental role in the dynamics of classical mechanics) is one of the mathematical foundations of the ")#link("https://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" relating quantum and classical mechanics, but we will not discuss this topic further here.")
]

#text("There is also a companion result regarding adjoints of pseudodifferential operators:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Adjoint of pseudodifferential operator)")]#text(" ")#metadata(none) <tao-234a6e8282daa7211ef5>#text(" Let ")#mi("{a \\in {\\mathcal S}^\\alpha}")#text(".")

#list(
[#text("(i) If ")#mi("{a}")#text(" is compactly supported, show that the function ")#mi("{\\tilde a}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde a(x,\\xi) := \\int_{\\bf R} \\int_{\\bf R} \\overline{a}(y,\\eta) e^{2\\pi i (x-y)(\\eta-\\xi)}\\ dy d\\eta")]]

#text("is also a symbol of order ")#mi("{\\alpha}")#text(", and that ")#mi("{\\tilde a(X,D)}")#text(" is the adjoint of ")#mi("{a(X,D)}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle a(X,D) f, g \\rangle = \\langle f, \\tilde a(X,D) g \\rangle")]]

#text("for all ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(".")],
[#text("(ii) Show that even if ")#mi("{a}")#text(" is not compactly supported, there is a unique pseudodifferential operator ")#mi("{a(X,D)^*}")#text(" of order ")#mi("{\\alpha}")#text(" which is the adjoint of ")#mi("{a(X,D)}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\langle a(X,D) f, g \\rangle = \\langle f, a(X,D)^* g \\rangle")]]

#text("for all ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(".")],
[#text("(iii) Show that ")#mi("{a(X,D)^* - \\overline{a}(X,D)}")#text(" is a pseudodifferential operator of order ")#mi("{\\alpha-1}")#text(".")]
)
]

#text("Now we give some applications of the above pseudodifferential calculus.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Pseudodifferential operators and Sobolev spaces)")]#text(" ")#metadata(none) <tao-454bedc703c397ac8232>#text(" For any ")#mi("{1 < p < \\infty}")#text(" and ")#mi("{s \\in {\\bf R}}")#text(", define the ")#link("https://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev space")]#text(" ")#mi("{W^{s,p}({\\bf R})}")#text(" to be the completion of the Schwartz functions ")#mi("{{\\mathcal S}({\\bf R})}")#text(" with respect to the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{s,p}({\\bf R})} := \\left\\| \\langle D \\rangle^s f \\right\\|_{L^p({\\bf R})}.", block: true)]]

#list(
[#text("(i) If ")#mi("{s}")#text(" is a non-negative integer, show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{W^{s,p}({\\bf R})} \\sim_{s,p} \\sum_{j=0}^s \\left\\| \\frac{d^j}{dx^j} f\\right\\|_{L^p({\\bf R})}", block: true)]]

#text("for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", thus in this case the Sobolev spaces agree (up to constants) with the classical Sobolev spaces (as discussed for instance in ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("this set of notes")]#text(").")],
[#text("(ii) If ")#mi("{a(X,D)}")#text(" is a pseudodifferential operator of some order ")#mi("{\\alpha \\in {\\bf R}}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|a(X,D) f\\right\\|_{W^{s-\\alpha,p}({\\bf R})} \\lesssim_{a,\\alpha,s,p} \\left\\|f\\right\\|_{W^{s,p}({\\bf R})}", block: true)]]

#text("for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", thus ")#mi("{a(X,D)}")#text(" extends to a bounded linear map from ")#mi("{W^{s,p}({\\bf R})}")#text(" to ")#mi("{W^{s-\\alpha,p}({\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" use Theorem ")#link(<tao-29cdee48e28d81041865>)[#text("4")]#text(" and Theorem ")#link(<tao-67662fcc7db7368e68d7>)[#text("8")]#text(").")],
[#text("(iii) Let ")#mi("{a(X,D)}")#text(" be a pseudodifferential operator of some order ")#mi("{\\alpha \\in {\\bf R}}")#text(" that obeys the strong ellipticity condition")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Re} a(x,\\xi) \\sim_a \\langle \\xi \\rangle^\\alpha")]]

#text("for all ")#mi("{x,\\xi \\in {\\bf R}}")#text(". Establish the ")#link("https://en.wikipedia.org/wiki/G%C3%A5rding%27s_inequality")[#text("Garding inequality")]

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} \\langle a(X,D) f, f \\rangle \\geq c \\left\\| f\\right\\|_{W^{\\alpha/2, 2}({\\bf R})}^2 - C \\left\\| f \\right\\|_{W^{(\\alpha-1)/2,2}({\\bf R})}^2", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(" and some ")#mi("{c,C>0}")#text(" depending only on ")#mi("{a,\\alpha}")#text(". (")#emph[#text("Hint:")]#text(" use Exercises ")#link(<tao-a4047d44f578e8f89bbf>)[#text("9")]#text(", ")#link(<tao-234a6e8282daa7211ef5>)[#text("11")]#text(" to express ")#mi("{\\frac{1}{2} (a(X,D) + a(X,D)^*)}")#text(" as ")#mi("{b(X,D) b(X,D)^* + e(X,D)}")#text(" for some pseudodifferential operators ")#mi("{b,e}")#text(" of orders ")#mi("{\\alpha/2}")#text(" and ")#mi("{\\alpha-1}")#text(" respectively.) If ")#mi("{\\alpha \\geq 1}")#text(", deduce also the variant inequality")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} \\langle a(X,D) f, f \\rangle \\geq c \\left\\| f\\right\\|_{W^{\\alpha/2, 2}({\\bf R})}^2 - C \\left\\| f \\right\\|_{L^2({\\bf R})}^2", block: true)]]

#text("(possibly with slightly different choices of ")#mi("{c,C}")#text(").")]
)
]

#text("The behaviour of pseudodifferential operators may be clarified by using a type of phase space transform, which we will call a ")#emph[#text("Gabor-type transform")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Gabor-type transforms and pseudodifferential operators)")]#text(" ")#metadata(none) <tao-3b0dcc1419123dbeee00>#text(" Given any function ")#mi("{\\phi \\in {\\mathcal S}({\\bf R})}")#text(" with the ")#mi("{L^2}")#text(" normalisation ")#tao-math("{\\left\\|\\phi\\right\\|_{L^2({\\bf R})}=1}", block: false)#text(", and any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", define the ")#emph[#text("Gabor-type transform")]#text(" ")#mi("{T_\\phi f: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T_\\phi f(x,\\xi) := \\int_{\\bf R} f(y) \\overline{\\phi}(y-x) e^{-2\\pi i y \\xi}\\ dy,")]]

#text("thus ")#mi("{T_\\phi f(x,\\xi)}")#text(" is the inner product of ")#mi("{f}")#text(" with the function ")#mi("{y \\mapsto \\phi(y-x) e^{2\\pi i y \\xi}}")#text(", which is the “wave packet” formed from function ")#mi("{\\phi}")#text(" by translating by ")#mi("{x}")#text(" and then modulating by ")#mi("{\\xi}")#text(". (Intuitively, ")#mi("{T_\\phi f(x,\\xi)}")#text(" measures the extent to which ")#mi("{f}")#text(" lives at spatial location ")#mi("{x}")#text(" and frequency location ")#mi("{\\xi}")#text(".) We also define the adjoint map ")#mi("{T_\\phi^* F: {\\bf R} \\rightarrow {\\bf C}}")#text(" for ")#mi("{F \\in {\\mathcal S}({\\bf R} \\times {\\bf R})}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T_\\phi^* F(y) := \\int_{\\bf R} \\int_{\\bf R} F(x,\\xi) \\phi(y-x) e^{2\\pi i y \\xi}\\ dx d\\xi.")]]

#list(
[#text("(i) Show that for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", ")#mi("{T_\\phi f}")#text(" is a Schwartz function on ")#mi("{{\\bf R} \\times {\\bf R}}")#text(", thus ")#mi("{T_\\phi}")#text(" is a linear map from ")#mi("{{\\mathcal S}({\\bf R})}")#text(" to ")#mi("{{\\mathcal S}({\\bf R} \\times {\\bf R})}")#text(". Similarly, show that for ")#mi("{F \\in {\\mathcal S}({\\bf R} \\times {\\bf R})}")#text(", ")#mi("{T_\\phi^* F}")#text(" is a Schwartz function on ")#mi("{{\\bf R}}")#text(", thus ")#mi("{T_\\phi^*}")#text(" is a linear map from ")#mi("{{\\mathcal S}({\\bf R} \\times {\\bf R})}")#text(" to ")#mi("{{\\mathcal S}({\\bf R})}")#text(".")],
[#text("(ii) Establish the identity ")#mi("{T_\\phi^* T_\\phi f = f}")#text(" for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", and conclude inparticular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_\\phi f \\right\\|_{L^2({\\bf R} \\times {\\bf R})} = \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", thus ")#mi("{T_\\phi}")#text(" extends to a linear isometry from ")#mi("{L^2({\\bf R})}")#text(" into ")#mi("{L^2({\\bf R} \\times {\\bf R})}")#text(".")],
[#text("(iii) For any smooth compactly supported ")#mi("{a \\in C^\\infty_c({\\bf R})}")#text(" and ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", establish the identity")

#align(center)[#tao-fit-display[#mitex("T_\\phi^* (a T_\\phi f) = (a*W_\\phi)(X,D) f,")]]

#text("where ")#mi("{W_\\phi: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" is the (Kohn-Nirenberg) ")#link("https://en.wikipedia.org/wiki/Wigner_quasiprobability_distribution")[#text("Wigner distribution")]#text(" of ")#mi("{\\phi}")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("W_\\phi(x,\\xi) = \\phi(x) \\overline{\\hat \\phi}(\\xi) e^{-2\\pi i x \\xi}")]]

#text("and ")#mi("{a*W_\\phi}")#text(" is the phase space convolution")

#align(center)[#tao-fit-display[#mitex("a*W_\\phi(x,\\xi) := \\int_{\\bf R} \\int_{\\bf R} a(y,\\eta) W_\\phi(x-y, \\xi-\\eta)\\ dy d\\eta.")]]]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" When ")#mi("{\\phi}")#text(" is a Gaussian, the transform ")#mi("{T_\\phi}")#text(" is essentially the ")#link("https://en.wikipedia.org/wiki/Gabor_transform")[#text("Gabor transform")]#text(" (in signal processing) or the ")#link("https://en.wikipedia.org/wiki/Fourier%E2%80%93Bros%E2%80%93Iagolnitzer_transform")[#text("FBI transform")]#text(" (in microlocal analysis), and is also closely related to the ")#link("https://en.wikipedia.org/wiki/Segal%E2%80%93Bargmann_space#The_Segal%E2%80%93Bargmann_transform")[#text("Bargmann transform")]#text(" in complex analysis. There are some technical advantages with working with Gaussian choices of ")#mi("{\\phi}")#text(", particularly with regards to the treatment of certain lower order terms in the pseudodifferential calculus; see for instance ")#link("https://math.berkeley.edu/~tataru/papers/phasespace.pdf")[#text("these notes of Tataru")]#text(".")
]

#text("Note that ")#mi("{W_\\phi}")#text(" is a Schwartz function on ")#mi("{{\\bf R} \\times {\\bf R}}")#text(", and by the Fourier inversion formula it has unit mass: ")#mi("{\\int_{\\bf R} \\int_{\\bf R} W_\\phi(x,\\xi)\\ dx d\\xi = 1}")#text(". (One also has the marginal distributions ")#tao-math("{\\int_{\\bf R} W_\\phi(x,\\xi)\\ d\\xi = \\left|\\phi(x)\\right|^2}", block: false)#text(" and ")#tao-math("{\\int_{\\bf R} W_\\phi(x,\\xi)\\ dx = \\left|\\hat \\phi(\\xi)\\right|^2}", block: false)#text(", so ")#mi("{W_\\phi}")#text(" would be a strong candidate for a “phase space probability distribution” for ")#mi("{\\phi}")#text(", save for the unfortunate fact that ")#mi("{W_\\phi(x,\\xi)}")#text(" has no reason to be non-negative. But even with oscillation, ")#mi("{W_\\phi}")#text(" still behaves like an approximation to the identity, so for ")#mi("{a}")#text(" slowly varying ")#mi("{a*W_\\phi}")#text(" can be viewed as an approximation to ")#mi("{a}")#text(". Thus, Exercise ")#link(<tao-3b0dcc1419123dbeee00>)[#text("13")]#text("(iii) can be intuitively viewed as saying that ")#mi("{a(X,D)}")#text(" behaves approximately like a multiplier in phase space:")

#align(center)[#tao-fit-display[#mitex("a(X,D) \\approx T_\\phi^* a T_\\phi.")]]

#text("Another informal way of viewing this assertion is that (for suitable choices of ")#mi("{\\phi}")#text(") the translated and modulated functions ")#mi("{y \\mapsto \\phi(y-x) e^{2\\pi i y \\xi}}")#text(" can be viewed as approximate eigenfunctions of ")#mi("{a(X,D)}")#text(" with eigenvalue ")#mi("{\\approx a(x,\\xi)}")#text(". This is for instance consistent with the approximate functional calculus ")#mi("{a(X,D) b(X,D) \\approx (ab)(X,D)}")#text(" and ")#mi("{a(X,D)^* \\approx \\overline{a}(X,D)}")#text(" that one saw in Exercises ")#link(<tao-a4047d44f578e8f89bbf>)[#text("9")]#text(", ")#link(<tao-234a6e8282daa7211ef5>)[#text("11")]#text(". The exercise below gives another way to view this approximation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (")#mi("{S^0_{0,0}}")#text(" ")#mi("{L^2}")#text(" bound)")]#text(" Let ")#mi("{a: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" be a smooth function obeying the “")#mi("{S^0_{0,0}}")#text(" bound”")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^j}{\\partial x^j} \\frac{\\partial^l}{\\partial \\xi^l} a(x,\\xi) \\lesssim_{a,j,l} 1")]]

#text("for all ")#mi("{j,l \\geq 0}")#text(" and ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(". Let ")#mi("{\\phi}")#text(" and ")#mi("{T_\\phi}")#text(" be as in Exercise ")#link(<tao-3b0dcc1419123dbeee00>)[#text("13")]#text(". Show that there is a smooth kernel ")#mi("{K: {\\bf R} \\times {\\bf R} \\times {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(" obeying the bounds")

#align(center)[#tao-fit-display[#mitex("K( x,\\xi, y,\\eta ) \\lesssim_{a,m} \\langle (x,\\xi) - (y,\\eta) \\rangle^{-m}")]]

#text("for any ")#mi("{m \\geq 0}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("T_\\phi a(X,D) T_\\phi^* F(x,\\xi) = \\int_{{\\bf R} \\times {\\bf R}} K(x,\\xi,y,\\eta) F(y,\\eta)\\ dy d\\eta")]]

#text("for any ")#mi("{F \\in {\\mathcal S}({\\bf R} \\times {\\bf R})}")#text(". (")#emph[#text("Hint:")]#text(" work first in the case when ")#mi("{a}")#text(" is compactly supported, where one can use Fubini’s theorem to derive an explicit integral expression for ")#mi("{K(x,\\xi,y,\\eta)}")#text(", which one can then control by various integrations by parts.) Use this to establish the ")#mi("{L^2}")#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|a(X,D) f \\right\\|_{L^2({\\bf R})} \\lesssim_a \\left\\|f\\right\\|_{L^2({\\bf R})}", block: true)]]

#text("for any ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text("; note that this gives an alternate proof of ")#link(<tao-3946ca64ff78d93ca610>)[#text("(18)")]#text(". (See also ")#link("https://math.berkeley.edu/~tataru/papers/phasespace.pdf")[#text("these notes of Tataru")]#text(" for further elaboration of this approach to pseudodifferential operators.)")
]

#text("As a sample application of the Gabor transform formalism we give a variant of the Garding inequality from Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("12")]#text("(iii).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (Sharp Garding inequality)")]#text(" Let ")#mi("{a(X,D)}")#text(" be a pseudodifferential operator of order ")#mi("{\\alpha}")#text(" such that ")#mi("{\\mathrm{Re} a(x,\\xi) \\geq 0}")#text(" for all ")#mi("{x,\\xi}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} \\langle a(X,D) f, f \\rangle \\geq -C \\left\\|f\\right\\|_{W^{\\alpha-\\frac{1}{2},2}}^2", block: true)]]

#text("for all ")#mi("{f \\in {\\mathcal S}({\\bf R})}")#text(", where ")#mi("{C}")#text(" depends only on ")#mi("{a,\\alpha}")#text(".")
]

#emph[#text("Proof:")]#text(" From Exercise ")#link(<tao-234a6e8282daa7211ef5>)[#text("11")]#text(" we see that ")#mi("{(i \\mathrm{Im} a)(X,D) + (i \\mathrm{Im} a)(X,D)^*}")#text(" is a pseudodifferential operator of order ")#mi("{\\alpha-1}")#text(", hence by Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("12")]#text("(ii) we have")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} \\langle (i \\mathrm{Im} a)(X,D) f, f \\rangle \\lesssim_a \\left\\|f\\right\\|_{W^{\\alpha-\\frac{1}{2},2}}^2.", block: true)]]

#text("Thus we may remove the imaginary part from ")#mi("{a}")#text(" and assume that ")#mi("{a}")#text(" is real and non-negative. Applying a smooth partition of unity of Littlewood-Paley type, we can write ")#mi("{a = \\sum_{k=0}^\\infty a_k}")#text(", where each ")#mi("{a_k}")#text(" is also non-negative, supported on the region ")#mi("{\\{ (x,\\xi): \\langle \\xi \\rangle \\sim 2^k \\}}")#text(", and obeys essentially the same symbol estimates as ")#mi("{a}")#text(" uniformly in ")#mi("{k}")#text(". It then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} \\langle \\sum_{k=0}^K a_k(X,D) f, f \\rangle \\geq -C \\left\\|f\\right\\|_{W^{\\alpha-\\frac{1}{2},2}}^2", block: true)]]

#text("uniformly in ")#mi("{K}")#text(".")

#text("We now use the Gabor-type transforms ")#mi("{T_\\phi}")#text(" from Exercise ")#link(<tao-3b0dcc1419123dbeee00>)[#text("13")]#text(", except that we make ")#mi("{\\phi}")#text(" dependent on ")#mi("{k}")#text(". Specifically we pick a single real even ")#mi("{\\phi_0 \\in {\\mathcal S}({\\bf R})}")#text(" with ")#mi("{L^2}")#text(" norm ")#mi("{1}")#text(", then define ")#mi("{\\phi_k(x) := 2^{k/4} \\phi(2^{k/2} x)}")#text(" for all ")#mi("{k>0}")#text(". We will approximate ")#mi("{a_k(X,D)}")#text(" by")

#align(center)[#tao-fit-display[#mitex("(a_k * W_{\\phi_k})(X,D) = T_{\\phi_k}^* a_k T_{\\phi_k}.")]]

#text("Observe that")

#align(center)[#tao-fit-display[#tao-math("\\langle T_{\\phi_k}^* a_k T_{\\phi_k} f, f \\rangle = \\int_{\\bf R} \\int_{\\bf R} a_k(x,\\xi) \\left|T_{\\phi_k}f(x,\\xi)\\right|^2\\ dx d\\xi \\geq 0", block: true)]]

#text("so by the triangle inequality it will suffice to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\langle \\sum_{k=0}^K (a_k - a_k * W_{\\phi_k})(X,D) f, f \\rangle \\lesssim_a \\left\\|f\\right\\|_{W^{\\alpha-\\frac{1}{2},2}}^2.", block: true)]]

#text("However, it is not difficult (see exercise below) to show that ")#mi("{\\sum_{k=0}^K a_k - a_k * W_{\\phi_k}}")#text(" is a symbol of order ")#mi("{\\alpha-1}")#text(" uniformly in ")#mi("{K}")#text(", and the claim now follows from Exercise ")#link(<tao-454bedc703c397ac8232>)[#text("12")]#text("(ii). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Verify the claim that ")#mi("{\\sum_{k=0}^K a_k - a_k * W_{\\phi_k}}")#text(" is a symbol of order ")#mi("{\\alpha-1}")#text(" uniformly in ")#mi("{K}")#text(". (Here one will need the fact that ")#mi("{W_{\\phi_k}}")#text(" is a rescaling by a scaling factor ")#mi("{2^{k/2}}")#text(" of ")#mi("{W_\\phi}")#text(", which is an even Schwartz function of mean ")#mi("{1}")#text(". The even nature of ")#mi("{W_\\phi}")#text(" is needed to cancel some linear terms which would otherwise only allow one to obtain symbol bounds of order ")#mi("{\\alpha-1/2}")#text(" rather than ")#mi("{\\alpha-1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" It is possible to improve the error term in the sharp Garding inequality, particularly if one uses the Weyl quantization rather than the Kohn-Nirenberg one (see Remark ")#link(<tao-e3d8c301b327d61d49b7>)[#text("19")]#text(" below); also the non-negativity hypothesis on ")#mi("{a}")#text(" can be relaxed in a manner consistent with the uncertainty principle; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=611747")[#text("this deep paper of Fefferman and Phong")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" ")#metadata(none) <tao-e3d8c301b327d61d49b7>#text(" Throughout this set of notes we have used the Kohn-Nirenberg quantization")

#align(center)[#tao-fit-display[#mitex("a_{KN}(X,D) f(x) = \\int_{\\bf R} a(x,\\xi) \\hat f(\\xi) e^{2\\pi i x \\xi}\\ d\\xi")]]

#text("or equivalently (taking ")#mi("{a}")#text(" to be compactly supported for sake of discussion)")

#align(center)[#tao-fit-display[#mitex("a_{KN}(X,D) f(x) = \\int_{\\bf R} (\\int_{\\bf R} a(x,\\xi) e^{2\\pi i (x-y) \\xi}\\ d\\xi) f(y) dy.")]]

#text("However, this is not the only quantization that one could use. For instance, one could also use the adjoint Kohn-Nirenberg quantization")

#align(center)[#tao-fit-display[#mitex("a_{KN^*}(X,D) f(x) := \\int_{\\bf R} (\\int_{\\bf R} a(y,\\xi) e^{2\\pi i (x-y) \\xi}\\ d\\xi) f(y) dy")]]

#text("which one can easily relate to the Kohn-Nirenberg quantization by the identity")

#align(center)[#tao-fit-display[#mitex("a_{KN^*}(X,D) = \\overline{a}_{KN}(X,D)^*.")]]

#text("In particular, from Exercise ")#link(<tao-234a6e8282daa7211ef5>)[#text("11")]#text(" we see that if ")#mi("{a}")#text(" is a symbol of order ")#mi("{\\alpha}")#text(", then ")#mi("{a_{KN}(X,D)}")#text(" and ")#mi("{a_{KN^*}(X,D)}")#text(" only differ by pseudodifferential operators of order ")#mi("{\\alpha-1}")#text(" (and that both quantizations produce the same class of pseudodifferential operators of a given order). The operators ")#mi("{T_\\phi^* a T_\\phi}")#text(" appearing earlier can also be viewed as a quantization of ")#mi("{a}")#text(" (known as the ")#emph[#text("anti-Wick quantization")]#text(" of ")#mi("{a}")#text(" associated to the test function ")#mi("{\\phi}")#text("). But perhaps the most popular quantization used in the literature is the ")#link("https://en.wikipedia.org/wiki/Wigner%E2%80%93Weyl_transform")[#text("Weyl quantization")]

#align(center)[#tao-fit-display[#mitex("a_{W}(X,D) f(x) := \\int_{\\bf R} (\\int_{\\bf R} a(\\frac{x+y}{2},\\xi) e^{2\\pi i (x-y) \\xi}\\ d\\xi) f(y) dy")]]

#text("which in some sense “splits the difference” between the Kohn-Nirenberg and adjoint Kohn-Nirenberg quantizations, being completely symmetric between the input spatial variable ")#mi("{y}")#text(" and output spatial variable ")#mi("{x}")#text(". (Strictly speaking, this formula is only well-defined for say compactly supported symbols ")#mi("{a}")#text("; for more general symbols ")#mi("{a}")#text(" one can define ")#mi("{a_W(X,D) f}")#text(" in the weak sense as the distribution for which")

#align(center)[#tao-fit-display[#mitex("\\langle a_{W}(X,D) f, g \\rangle = \\int_{\\bf R} (\\int_{\\bf R} \\int_{\\bf R} a(\\frac{x+y}{2},\\xi) e^{2\\pi i (x-y) \\xi} f(y) \\overline{g(x)}\\ dx dy)\\ d\\xi")]]

#text("for ")#mi("{f,g \\in {\\mathcal S}({\\bf R})}")#text(" (it is not difficult to use integration by parts to show that the expression in parentheses is rapidly decreasing in ")#mi("{\\xi}")#text(", hence absolutely integrable). In particular there is now no error term in the analogue of Exercise ")#link(<tao-234a6e8282daa7211ef5>)[#text("11")]#text(":")

#align(center)[#tao-fit-display[#mitex("a_W(X,D)^* = \\overline{a}_W(X,D).")]]

#text("All of the preceding theory for the Kohn-Nirenberg quantization can be adapted to the Weyl quantization with minor changes (for instance, the definition of the Wigner transform ")#mi("{W_\\phi}")#text(" changes slightly, and the operation ")#mi("{\\ast}")#text(" defined in ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(24)")]#text(" is replaced with the ")#link("https://en.wikipedia.org/wiki/Moyal_product")[#text("Moyal product")]#text("), and as seen in Exercise ")#link(<tao-04428d906a2e1cae600f>)[#text("20")]#text(" below, the two quantizations again produce the same classes of pseudodifferential operators, with symbols agreeing up to lower order terms.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Kohn-Nirenberg and Weyl quantizations are equivalent up to lower order)")]#text(" ")#metadata(none) <tao-04428d906a2e1cae600f>#text(" Let ")#mi("{\\alpha}")#text(" be a real number.")

#list(
[#text("(i) If ")#mi("{a}")#text(" is a symbol of order ")#mi("{\\alpha}")#text(", show that there exists a symbol ")#mi("{\\tilde a}")#text(" of order ")#mi("{\\alpha}")#text(" such that ")#mi("{a_{KN}(X,D) = \\tilde a_W(X,D)}")#text(". Furthermore, show that ")#mi("{a-\\tilde a}")#text(" is a symbol of order ")#mi("{\\alpha-1}")#text(".")],
[#text("(ii) If ")#mi("{a}")#text(" is a symbol of order ")#mi("{\\alpha}")#text(", show that there exists a symbol ")#mi("{\\tilde a}")#text(" of order ")#mi("{\\alpha}")#text(" such that ")#mi("{a_{W}(X,D) = \\tilde a_{KN}(X,D)}")#text(". Furthermore, show that ")#mi("{a-\\tilde a}")#text(" is a symbol of order ")#mi("{\\alpha-1}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Comparison of quantizations)")]#text(" Let ")#mi("{j,k \\geq 0}")#text(" be natural numbers, and let ")#mi("{a}")#text(" be the monomial ")#mi("{a(x,\\xi) := x^j \\xi^k}")#text(".")

#list(
[#text("(i) Show that ")#mi("{a_{KN}(X,D) = X^j D^k}")#text(".")],
[#text("(ii) Show that ")#mi("{a_{KN^*}(X,D) = D^k X^j}")#text(".")],
[#text("(iii) Show that ")#mi("{a_W(X,D) = \\frac{1}{\\binom{j+k}{k}} \\sum W_1 \\dots W_{k+j}}")#text(", where ")#mi("{(W_1,\\dots,W_{k+j})}")#text(" ranges over all tuples of operators consisting of ")#mi("{j}")#text(" copies of ")#mi("{X}")#text(" and ")#mi("{k}")#text(" copies of ")#mi("{D}")#text(". For instance, if ")#mi("{(j,k)=(1,2)}")#text(", then")

#align(center)[#tao-fit-display[#mitex("a_W(X,D) = \\frac{1}{3} (XDD + DXD + DDX).")]]]
)

#text("Informally, the Kohn-Nirenberg quantization always applies position operators to the left of momentum operators; the adjoint Kohn-Nirenberg quantization always applies position operators to the right of momentum operators; and the Weyl quantization averages equally over all possible orderings. (Taking formal generating functions, we also see (formally, at least) that the quantization of a plane wave ")#mi("{e^{2\\pi i (x \\eta + y \\xi)}}")#text(" for real numbers ")#mi("{\\eta,y}")#text(" is equal to ")#mi("{e^{2\\pi i \\eta X} e^{2\\pi i y D}}")#text(" in the Kohn-Nirenberg quantization, ")#mi("{e^{2\\pi i yD} e^{2\\pi i \\eta X}}")#text(" in the adjoint Kohn-Nirenberg quantization, and ")#mi("{e^{2\\pi i(\\eta X + yD)}}")#text(" in the Weyl quantization.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Gabor-type transforms and symmetries)")]#text(" Let ")#mi("{\\phi, f \\in {\\mathcal S}({\\bf R})}")#text(".")

#list(
[#text("(i) (Physical translation) If ")#mi("{x_0 \\in {\\bf R}}")#text(" and ")#mi("{g \\in {\\mathcal S}({\\bf R})}")#text(" is the function ")#mi("{g(x) := f(x-x_0)}")#text(", show that ")#mi("{T_\\phi g(x,\\xi) = e^{-2\\pi i x_0 \\xi} T_\\phi f(x-x_0,\\xi)}")#text(" for all ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(".")],
[#text("(ii) (Frequency modulation) If ")#mi("{\\xi_0 \\in {\\bf R}}")#text(" and ")#mi("{g \\in {\\mathcal S}({\\bf R})}")#text(" is the function ")#mi("{g(x) := e^{2\\pi i \\xi_0 x} f(x)}")#text(", show that ")#mi("{T_\\phi g(x,\\xi) = T_\\phi f(x,\\xi-\\xi_0)}")#text(" for all ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(".")],
[#text("(iii) (Dilation) If ")#mi("{\\lambda>0}")#text(" and ")#mi("{g \\in {\\mathcal S}({\\bf R})}")#text(" is the function ")#mi("{g(x) := \\lambda^{-1/2} f(\\lambda^{-1} x)}")#text(", show that ")#mi("{T_{\\phi_\\lambda}g(x,\\xi) = T_\\phi f(\\lambda^{-1} x, \\lambda \\xi)}")#text(" for all ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(", where ")#mi("{\\phi_\\lambda := \\lambda^{-1/2} \\phi(\\lambda^{-1} x)}")#text(".")],
[#text("(iv) (Fourier transform) If ")#mi("{g = \\hat f}")#text(", show that ")#mi("{T_{\\hat \\phi} g(x,\\xi) = e^{2\\pi i x \\xi} T_\\phi f(-\\xi, x)}")#text(".")],
[#text("(v) (Quadratic phase modulation) If ")#mi("{a \\in {\\bf R}}")#text(" and ")#mi("{g \\in {\\mathcal S}({\\bf R})}")#text(" is the function ")#mi("{g(x) := e^{\\pi i a x^2} f(x)}")#text(", show that ")#mi("{T_{\\tilde \\phi} g(x,\\xi) = e^{-\\pi i ax^2} T_\\phi f(x, \\xi-ax)}")#text(" for all ")#mi("{(x,\\xi) \\in {\\bf R} \\times {\\bf R}}")#text(", where ")#mi("{\\tilde \\phi(x) := e^{\\pi i ax^2} \\phi(x)}")#text(".")]
)

#text("We remark that the group generated by the transformations (i)-(v) is the (Weil representation of the) ")#link("https://en.wikipedia.org/wiki/Metaplectic_group")[#text("metaplectic group")]#text(" ")#mi("{Mp_2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" Ignoring the changes in the Gabor test function ")#mi("{\\phi}")#text(", as well as the various phases appearing on the right-hand side, we conclude from the above exercise that basic transformations on functions seem to correspond to various area-preserving maps of phase space; for instance, the Fourier transform is associated to the rotation ")#mi("{(-\\xi,x) \\mapsto (x,\\xi)}")#text(", which is consistent in particular with the fact that a fourfold iteration of the Fourier transform yields the identity operator. This is in fact a quite general phenomenon, with something asymptotically resembling such identities available for an important class of operators known as ")#link("https://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(" (but in higher dimensions one replaces the adjective with “area-preserving” with “")#link("https://en.wikipedia.org/wiki/Symplectomorphism")[#text("symplectomorphism")]#text("” or “")#link("https://en.wikipedia.org/wiki/Canonical_transformation")[#text("canonical transformation")]#text("“). However, as stated previously, the systematic development of the theory of Fourier integral operators is beyond the scope of this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 24")]#text(" Virtually all of the above theory extends to higher dimensions, and also to general smooth manifolds ")#mi("{M}")#text(" as domains. In the latter case, the natural analogue of phase space is the cotangent bundle ")#mi("{T^* M}")#text(", and the symplectic geometry of this bundle then plays a fundamental role in the theory (as already hinted at by the appearance of the Poisson bracket in Remark ")#link(<tao-88b3e13a98900e3dfa4b>)[#text("10")]#text(". See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=983366")[#text("this text of Folland for more discussion")]#text(".")
]

#heading(level: 1)[#text("Comments (71)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/85fec62161e04c2ae3b028b5eccf6ff083ede62b26d23968a23e4789869f23bf-0ca208eb6faafa70367604d809ad364a6359d20b904df7c950b7bf3d3c2fa5b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tony Carbery")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-556777")[#strong[#text("Tony Carbery")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("Hi Terry, I believe the observation about the strong operator topology in Remark 6 is due to Yves Meyer; in any case the argument is also sketched in Ch 7 Sect 5.3 of Stein’s Harmonic Analysis.")

#emph[#text("[Attribution added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-556789")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("In the syllabus of the course it is writen that the course would include paraproducts and the Walsh Carleson’s theorem. Are you still planning on giving lectures on these topics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-556852")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2020")])]

#text("The next set of notes will cover Carleson’s theorem, though I have not yet decided whether to spend time on the Walsh version of the theorem. I had initially intended to also cover paraproducts, but a substantial amount of paradifferential calculus was already covered in the preceding 247A course, so I decided to replace that discussion with pseudodifferential calculus instead.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557005")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("The two displays after (22) should have A^2, B^2 swapped?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557011")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("In the final display of the proof of the Cotlar-Stein lemma, one seems to get ")#tao-math("\\left\\|T\\right\\| \\leq (n \\sqrt{AB} ABA\\dots BA)^{1/2m}", block: false)#text(".")

#emph[#text("[I believe the estimate is correct as it stands – the estimate you claim is not dimensionally consistent (it isn’t invariant with respect to the operation of multiplying ")#mi("T,A,B")#text(" by a scalar ")#mi("\\lambda")#text("). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557013")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("If this is true, then the argument still goes through assuming ")#mi("B>0")#text(" (which can be assumed since the case ")#mi("B=0")#text(" is trivial), since then ")#mi("(A/B)^{1/(4m)}\\to 1")#text(" as ")#mi("m\\to\\infty")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557037")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("For ")#mi("\\lambda>0")#text(", ")#tao-math("\\lambda \\left\\|T\\right\\| = \\left\\|\\lambda T\\right\\| \\leq (n\\sqrt{\\lambda A\\lambda B} (\\lambda A)^m (\\lambda B)^{m-1})^{1/2m} = \\lambda (n A^{m+1/2}B^{m-1/2})^{1/2m}", block: false)#text(" is dimensionally consistent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("Ah, I see now. I’ve adjusted the text accordingly (by using a different bound on the operator norms of the two tail terms one can avoid having to artificially introduce the ratio between A and B).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557150")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text(":-)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557029")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2020")])]

#text("After (17), it seems one wants ")#mi("K(x,y):=\\sum_0^\\infty K_k(x,y)")#text(" ?")

#emph[#text("[Actually I prefer to work with the finite truncation here, but I have corrected a typo regarding this being the integral kernel for ")#mi("a(X,D)")#text(" (it should instead be ")#mi("\\sum_{k=0}^K a_k(X,D)")#text(") -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557232")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("While mathematicians tend to always write ")#mi("\\hbar")#text(" for the semiclassical parameter, strictly speaking this is correct usage only for those who follow the physicists and define the Fourier transform by integration against ")#mi("e^{ikx}")#text(". For those who use the number theory normalization with ")#mi("e^{2\\pi ikx}")#text(" the correct semiclassical parameter is ")#mi("h")#text(" (with ")#mi("\\hbar=\\frac{h}{2\\pi}")#text(").")

#text("This is visible when you define the position operator with the factor ")#mi("\\frac {1}{2\\pi i}")#text(", which can clearly be multiplied by ")#mi("h")#text(" to give the familiar ")#mi("-i\\hbar")#text(", but shouldn’t be multiplied by ")#mi("\\hbar")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2020")])]

#text("Dear Professor Tao,")#linebreak()#text(" What are the advantages/disadvantages of studying PDEs (Say Elliptic) using paraproducts and pseudodifferential operators, as oppose to using other stander methods like energy estimate, maximum principles, schauder estimates estimate. Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2020")])]

#text("Pseudodifferential operators are able to isolate specific regions of phase space; for instance it can be used in various wave equations to decompose a wave into “outgoing” and “incoming” waves (plus perhaps some error terms) which can be useful in various scattering theory type applications. They actually combine well with energy methods (for instance the “positive commutator method” is basically the energy method applied to pseudodifferential multipliers), and with various function space estimates such as Schauder estimates. Paraproducts are similarly able to isolate different types of frequency interactions (high-low, low-high, high-high), for instance leading to “microlocal gauge transformations” in which the most dangerous frequency interaction is isolated and tamed through an appropriate paradifferential gauge transformation, possibly at the cost of generating some uglier but more tractably estimated terms in the equation.")

#text("It is true though that such tools are somewhat non-local in nature and hence are not perfectly compatible with pointwise tools such as the maximum principle. (But in recent years non-local versions of the maximum principle have also been developed, so perhaps in the future one will see these tools cooperate more with each other.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2020")])]

#text("I guess applying pseudodifferential operators to nonlinear equations does not work so well. What are some ways to get around this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559191")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("The standard way to apply linear methods to nonlinear PDE is via perturbation theory; express the nonlinear PDE as a linear PDE plus a forcing term that depends nonlinearly on the solution, and try to show that the contribution of the nonlinear term is somehow controlled by the linear one using linear (or in some cases, bilinear, multilinear, or fully nonlinear) estimates. For the latter pseudodifferential operators can certainly be used. Of course, such techniques are only expected to be useful in perturbative regimes, where the solution or data is very close to an exact solution (e.g., if the data is small in some function space norm, so that the solution is expected to be close to the zero solution), or if one works only in a small region of space and time. However it can still be possible sometimes to extend such local results to global results, for instance there are certainly situations in which some energy-type quantity constructed using pseudo-differential operators enjoys some approximate monotonicity in time even after the nonlinearity is taken into account (this is particularly likely to happen if the nonlinearity is “defocusing” or “repulsive” in some sense), perhaps using variants of the Garding inequalities mentioned in this post.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a27aded23ed7733327e18ec5e7df663728afdaf36eaf470eac92f64896b15bd4-5c925d64362eb2a9b9f4a4032b2a85e8fd085ee564801ad0117851bb702e7afb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair201p")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-557990")[#strong[#text("jair201p")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2020")])]

#text("Reblogged this on ")#link("https://jair201p.wordpress.com/2020/05/07/247b-notes-3-pseudodifferential-operators/")[#text("jair201p")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba2392f030a1f36dc9c8bc229e39d39df69d4410471893359ea45a504e004010-6c88e4b38343422933a80c616c9bb944c808005aa0890d5795d6e9e9cee53c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Nash")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558062")[#strong[#text("Charles Nash")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("The Fourier Transform F: Some simple observations that could form a student exercise.")#linebreak()#text(" F is unitary with respect to the usual inner product")#linebreak()#text(" F^4=I")#linebreak()#text(" Hence F has eigenvalues taken from the 4th roots of unity")#linebreak()#text(" All the roots are realised")#linebreak()#text(" The corresponding eigenfunctions hn say, are essentially")#linebreak()#text(" Hermite Hn polynomials times a Gaussian")

#text("The eigenspaces are infinite dimensional")#linebreak()#text(" and each such space corresponds to the value of n mod 4")#linebreak()#text(" i.e.")#linebreak()#text(" F(hn)=i^n hn")

#emph[#text("[A related exercise has now been added – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("The projection operator on each of the 4 eigenspaces can be represented as a third degree polynomial of the Fourier transform.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba2392f030a1f36dc9c8bc229e39d39df69d4410471893359ea45a504e004010-6c88e4b38343422933a80c616c9bb944c808005aa0890d5795d6e9e9cee53c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Nash")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558514")[#strong[#text("Charles Nash")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("Ah Thanks. Yes, if ")#mi("\\lambda")#text(" is one of the eigenvalues, that polynomial seems to be")#linebreak()#text(" ")#mi("(F^4-I)/(4(F-\\lambda))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba2392f030a1f36dc9c8bc229e39d39df69d4410471893359ea45a504e004010-6c88e4b38343422933a80c616c9bb944c808005aa0890d5795d6e9e9cee53c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Nash")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558527")[#strong[#text("Charles Nash")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("Oops I thinkI need another ")#mi("\\lambda")#text(" in the denominator.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba2392f030a1f36dc9c8bc229e39d39df69d4410471893359ea45a504e004010-6c88e4b38343422933a80c616c9bb944c808005aa0890d5795d6e9e9cee53c03.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Nash")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558533")[#strong[#text("Charles Nash")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2020")])]

#text("arggh numerator")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558076")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("I really enjoyed the proof of the Calderon-Vaillancourt, I feel like for the first time I understand it. Usually the textbook proof is the following: by integration by parthe the boundedness for operator of order m large enough is easy to obtain. Then one inducts on ")#mi("m")#text(" to lower the degree of ")#mi("m")#text(", more precisely, if ")#mi("p")#text(" is of order ")#mi("m/2")#text(" then ")#mi("pp^*")#text(" is a sympbol of order ")#mi("m")#text(" thus bounded and by duality, so is ")#mi("p")#text(". To go down to ")#mi("m=0")#text(", one takes ")#mi("p \\in S^0")#text(" and ")#mi("M")#text(" large enough for which the relevant operator to consider is ")#mi("q:=(M-p^*p)^{1/2} \\in S^0")#text(".")

#text("The two proofs seem really different, however they both rely on some ")#mi("TT^*")#text(" argument. Can anyone know a bit more on the difference of these two proofs, and would explain to me where ‘orthogonality’ is used in the latter?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558200")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2020")])]

#text("Broadly speaking there are at least two general ways to establish inequalities ")#mi("A \\leq B")#text(" or estimates ")#mi("A \\lesssim B")#text(". One way (what one might call the “divide and conquer” approach) is to split up ")#mi("A")#text(" into pieces, apply various estimates and transforms to each of the pieces, and continue splitting up and estimating all the terms that arise until everything is satisfactorily controlled by ")#mi("B")#text(", and then sum up. The other is to try to express ")#mi("B-A")#text(", either exactly or approximately, as the sum of squares (or more generally as a sum or integral of manifestly non-negative quantities), either by using algebraic identities or some sort of monotonicity formula. Harmonic analysis arguments generally use the former type of argument, but the latter is more common in PDE, geometric analysis, and operator algebras. The latter approach is particularly good for proving sharp inequalities (e.g., ")#mi("A \\leq CB")#text(" with the optimal constant ")#mi("C")#text("), but it requires more algebraic structure on the objects being manipulated (and in some cases sum of squares decompositions are simply not available, cf. Hilbert’s seventeenth problem). Here, the algebraic structure is provided by the pseudodifferential calculus, which gives operator norm bounds on ")#mi("a(X,D)")#text(" that is basically ")#tao-math("\\left\\|a\\right\\|_{L^{\\infty}}", block: false)#text(" plus lower order terms. The divide and conquer approach in these notes (which also appears for instance in Stein’s “Harmonic analysis”) gives weaker bounds, but does not rely at all on the pseudodifferential calculus, which in this text I have arranged to come after the Calderon-Vaillancourt theorem is established rather than prior. (But note that the Garding and sharp Garding inequalities discussed in the post are proven using the sum-of-squares approach.)")

#emph[#text("[Edit: there are also many other ways to attack inequalities. For instance, one can take a variational approach and study how to maximise ")#mi("A")#text(" or minimise ")#mi("B")#text(" (or the difference or quotient of ")#mi("A")#text(" and ")#mi("B")#text(") with respect to various parameters. Or one can try to transform the entire inequality ")#mi("A \\leq B")#text(" (rather than just the left-hand side or right-hand side) using tools such as duality or symmetry reduction. One can try to “categorify” an inequality into an injection (or surjection) in some combinatorial, geometric, probabilistic, or algebraic category. Qualitative forms of inequalities can sometimes be established by compactness arguments. One can sometimes exploit “gaps” (such as spectral gaps or integrality gaps) to obtain non-trivial inequalities as soon as some degenerate case is excluded. In some cases a strict inequality ")#mi("A < B")#text(" can be established by a continuity argument, deforming both ")#mi("A")#text(" and ")#mi("B")#text(" to some degenerate case where the required inequality is easier to establish, and showing that one never passes through an equality case ")#mi("A=B")#text(" in the course of this deformation. As far as I know, though, none of these strategies are particularly well-suited for establishing the Calderon-Vaillancourt theorem.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("It seems that there is some latex problem here.")

#emph[#text("[Can you be more specific? I do not see any issues. Note that the final paragraph is intended to be in italics. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("Dear Prof. Tao:")

#text("Will you be teaching in the fall via zoom? Could you also make them accessible to the public?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2020")])]

#text("In the fall I will be teaching 246A (complex analysis), reusing the notes from ")#link("https://terrytao.wordpress.com/category/teaching/246a-complex-analysis/")[#text("https://terrytao.wordpress.com/category/teaching/246a-complex-analysis/")]#text(" . UCLA has not yet decided what the format will be (it depends of course on the projected state of the pandemic in California by that time, which nobody knows with certainty), but it is likely some remote option will be offered even if the courses will resume in our physical classrooms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558454")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("I was struggling with Exercise 1(i) all afternoon: the usual hypotheses are something like ")#mi("a\\in\\cal{S}(\\mathbb{R})")#text(", and the hypothesis (6) seemed too weak. The problem is that to gain a power ")#mi("x^{-N}")#text(" you would integrate (5) by parts ")#mi("N")#text(" times, and this hits the symbol with a differentiation in ")#mi("\\xi")#text(" that under hypothesis (6) can lose us an arbitrary power of ")#mi("x")#text(" and offset all our gains.")

#text("Eventually I found what (unless I’m missing something) is the obvious counterexample: take ")#mi("a(x,\\xi) = \\exp(-2\\pi ix\\cdot \\xi)")#text(". Then by (5) we have ")#mi("(\\mathrm{Op}(a)f)(x) = f(0)")#text(" for all Schwartz functions, and of course the constant function is not a Schwartz function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558457")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("Sorry, I meant the usual hypothesis is ")#mi("a\\in\\cal{S}(\\mathbb{R}\\times\\mathbb{R}^*)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558463")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2020")])]

#text("With apologies for the comment barrage, assuming the symbol is Schwartz makes the operator continuous from tempered distributions to Schwartz functions.")

#text("I think the symbol class you want for Exercise 1(i) is")

#tao-math("\\frac{\\partial^\\alpha}{\\partial x^\\alpha}\\frac{\\partial^\\beta}{\\partial \\xi^\\beta} a(x,\\xi) \\ll \\left\\langle x \\right\\rangle ^{O_{a,\\alpha}(1) + \\delta \\left|\\beta\\right|} \\left\\langle x \\right\\rangle ^{O_{a,\\alpha,\\beta}(1)}", block: false)

#text("where ")#mi("\\delta < 1")#text(". The key point is that while differentiation with respect to ")#mi("x")#text(" can lose arbitrary powers of ")#mi("x,\\xi")#text(" and differentiation with respect to ")#mi("\\xi")#text(" loses an arbitrary power of ")#mi("\\xi")#text(" the loss in ")#mi("x")#text(" is less than the gain from the integration by parts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-558648")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2020")])]

#text("Huh, that is an unexpected subtlety that I had not realised! For these notes the ")#mi("\\delta=0")#text(" case will suffice, so that seems to be the simplest fix.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559026")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2020")])]

#text("Shouldn’t = – due to integration by parts? for the momentum operator D.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2020")])]

#text("It’s correct as it stands because of the Hermitian inner product.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559032")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2020")])]

#text("In the proof of Lemma 5:")

#text("“Applying this method to a single operator {T_i} we have")

#text("\\displaystyle \\|T_i\\|_{op} = \\| T_i T_i^* \\|_{op}^{1/2} \\leq A")

#text("and similarly")

#text("\\displaystyle \\|T_i\\|_{op} = \\| T_i^* T_i \\|_{op}^{1/2} \\leq B. \\ \\ \\ \\ \\ (22)")

#text("Taking geometric means we have…”")

#text("I think the A and B here should be switched (compare with the statement of Lemma 5)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2020")])]

#text("Is there a reason why multipliers are called “symbols”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559193")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("I believe the term originates from the classical methods of symbolic calculus (also known as ")#link("https://en.wikipedia.org/wiki/Operational_calculus")[#text("operational calculus")]#text(") used to solve linear ODE by formally manipulating the polynomial that we would now call the symbol of the linear differential operator. I found for instance this historical article focusing in particular of the contributions of Heaviside (as well as Cauchy, Gregory, and Boole): ")#link("https://www.jstor.org/stable/41133808")[#text("https://www.jstor.org/stable/41133808")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c037b3eee30e4eb3a6ffd619c07b7e7baba7306b91ae8509b2888932599f20f-cd6eb9b77fff1ca43bbfd7313a78d8c292734fed67ab327093e9d2c3745e7c4b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("Dear Professor Tao, just curious but are you of Shanghainese Wu speaking ancestry?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("What? How could one know? DNA test?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("How to show ")#mi("D=\\mathcal{F}^{-1}X\\mathcal{F}")#text("? Here is my calculation, not sure what went wrong.")#linebreak()#text(" ")#mi("(\\mathcal{F}^{-1}X\\mathcal{F} f)(x) = \\mathcal{F}^{-1}X\\hat{f}(\\xi)")#linebreak()#text(" ")#mi("=\\mathcal{F}^{-1} (\\xi\\hat{f}(\\xi)) =\\int_\\xi\\hat{f}(\\xi)e^{2\\pi ix\\cdot\\xi}d\\xi")#linebreak()#text(" ")#mi("\\int_\\xi(\\int{f(x)e^{-2\\pi ix\\cdot\\xi}dx})e^{2\\pi ix\\cdot\\xi}d\\xi")#linebreak()#text(" ")#mi("= \\int\\int\\xi f(x) dx d\\xi")#text(", which is not equation to ")#mi("Df")#text(" defined in equation (1).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559285")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("You are using ")#mi("x")#text(" to denote both a free variable and a bound variable; I recommend using something like ")#mi("y")#text(" for the bound variable. Also, you dropped a factor of ")#mi("\\xi")#text(" after the third equals sign. At some point you will need to apply the Fourier inversion formula, as well as either an integration by parts or a differentiation under the integral sign. (You may find it easier to establish the equivalent identity ")#mi("{\\mathcal F} D = X {\\mathcal F}")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("Hi, professor")

#text("I still don’t quite understand the intuition you mentioned in class: the symbol is about constant in rectangles in the phase plane with side length 2^k in the frequency variable and side length 1 in the physical variable. Can you explain what is the meaning of being about constant and how does this motivate the idea of applying Littlewood-Paley decomposition in the proof of Calderon-Vallaincourt theorem")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559302")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2020")])]

#text("Let’s say ")#mi("a")#text(" is a symbol of order ")#mi("0")#text(", then ")#mi("a(x,\\xi) \\lesssim 1")#text(", ")#mi("\\frac{\\partial}{\\partial x} a(x,\\xi) \\lesssim 1")#text(", and ")#mi("\\frac{\\partial}{\\partial \\xi}(a,\\xi) \\lesssim 2^{-k}")#text(" when ")#mi("\\langle \\xi \\rangle \\sim 2^k")#text(". Thus, by the mean value theorem, we have ")#tao-math("a(x^{\\prime},\\xi^{\\prime}) = a(x,\\xi) + O( \\left|x-x^{\\prime}\\right| + 2^{-k} \\left|\\xi-\\xi^{\\prime}\\right|)", block: false)#text(" when ")#mi("x,x^{\\prime} \\in {\\bf R}")#text(" and ")#mi("\\langle \\xi \\rangle, \\langle \\xi^{\\prime} \\rangle \\sim 2^k")#text(" (at least if ")#mi("\\xi,\\xi^{\\prime}")#text(" have the same sign). The error term here is then lower order compared to the main term ")#mi("a(x,\\xi) = O(1)")#text(" when ")#tao-math("\\left|x-x^{\\prime}\\right| \\ll 1", block: false)#text(" and ")#tao-math("\\left|\\xi-\\xi^{\\prime}\\right| \\ll 2^k", block: false)#text(", thus we expect ")#mi("a")#text(" to behave like a constant on ")#mi("1 \\times 2^k")#text(" rectangles in the region ")#mi("\\{ (x,\\xi): \\langle \\xi \\rangle \\sim 2^k \\}")#text(". This partitions phase space into a collection of rectangles of various sizes, but the geometry of this partition becomes simpler if one restricts to a single annular region ")#mi("\\{ (x,\\xi): \\langle \\xi \\rangle \\sim 2^k \\}")#text(" in which one now just has a regularly spaced grid of rectangles, which is why a Littlewood-Paley decomposition would be a suggested tool of choice for analysing the pseudodifferential operator associated to this symbol.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2020")])]

#text("Maybe a dumb question, but shouldn’t commutator and Poisson bracket differ by an operator of order ")#mi("\\alpha + \\beta -2")#text(" in Remark 10? I thought the argument there is that ")#mi("a*b - b*a = ab + \\partial_\\xi a \\partial_x b - ba - \\partial_\\xi b \\partial_x a")#text(" plus an error which has the same order as in Exercise 9ii).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("I have two questions in the proof of theorem 8. In the second half, do we need to apply partition of unity to symbol a to get the desired estimates on kernel K_x as we already assume the symbol a to be compactly supported in both variables? I think i might miss something when i tried to build the estimate for the case \\xi is close to \\eta and \\xi is away from \\eta without applying a partition of unity to symbol a.")

#text("Also why is the case that \\xi is close to \\eta is the main contribution of the integral (26) so that we are not worried about the case \\xi is away from \\eta after we can have a good estimate on K_x for the case that \\xi is close to \\eta.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-559829")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("If one does not restrict the support of ")#mi("a")#text(" to the region where ")#mi("\\eta")#text(" is close to ")#mi("\\xi")#text(", then one does not get good bounds on the kernel ")#mi("K_x")#text(", for instance one cannot establish the bound ")#mi("K_x(z) \\lesssim \\langle \\xi \\rangle^{\\alpha+1}")#text(" because the contribution of very large ")#mi("\\eta")#text(" (for large positive ")#mi("\\alpha")#text(") or very small ")#mi("\\eta")#text(" (for large negative ")#mi("\\alpha")#text(") becomes problematic.")

#text("The case when ")#mi("\\eta")#text(" is far away from ")#mi("\\xi")#text(" is expected to be negligible from stationary phase heuristics, because the phase ")#mi("e^{2\\pi i (y-x) (\\xi-\\eta)}")#text(" becomes non-stationary in the ")#mi("y")#text(" variable in this regime.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560036")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Hi, professor. In the last part of proof of theorem 8, when we consider the two cases where \\eta is close to \\xi and \\eta is far from \\xi, is there a special meaning to consider |\\eta-\\xi| >= 1/4 instead of |\\eta-\\xi| >= 1/2 ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("One can take other constants here than 1/2 and 1/4. But the two constants in the decomposition here need to be separated for each other in order to be able to use a smooth partition of unity to reduce to the two cases: if for instance one had the same constant (e.g., 1/2) in both cases then the only way to partition ")#mi("a")#text(" into pieces with the indicated supports would be to use a rough cutoff such as ")#tao-math("1_{\\left|\\eta - \\xi\\right| \\leq \\frac{1}{2} \\langle \\xi \\rangle}", block: false)#text(", which would destroy the symbol estimates as this cutoff is not differentiable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("Dear professor Tao.")

#text("I think in the first lecture of the note 3 you mentioned that there is a reason why you place the theory of pseudodifferential operator here concerning come connection with the wave packet decomposition (maybe i misheard it). Can you briefly explain what is the connection and can you provide a reference for the wave packet decomposition (i don’t know anything about this decomposition)? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560094")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2020")])]

#text("The translated and modulated functions ")#mi("y \\mapsto \\varphi(y-x)e^{2\\pi i \\xi x}")#text(" that appear in the Gabor-type transforms are examples of ")#link("https://en.wikipedia.org/wiki/Wave_packet")[#text("wave packets")]#text(" (in this case, they are basically adapted to tiles ")#mi("[x,x+1] \\times [\\xi,\\xi+1]")#text(" of unit length in phase space). In Notes 4 wave packets ")#mi("\\phi_P")#text(" adapted to other tiles are utilised.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560222")[#strong[#text("Singular Integrals – Zeros and Ones")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2020")]

#text("[…] 2) We assume(!) that is bounded from to , i.e., . This seems to a be a pretty strong assumption (we are assuming something that we really would like to prove). In practice to figure out when a given operator is bounded in usually is a simple task and almost follows from the Plancherel’s theorem (as we did with Hilbert transform, and similarly can be done for any convolution type operator as long as the Fourier transform of its kernel is in ). However, there are other operators when it is really a difficult task to prove boundedness even in (in this case there are other arguments: a) argument; b) Cotlar–Stein lemma (see for instance the proof of Calderón-Vallaincourt theorem, i.e., Theorem 4 in Tao’s notes)). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560225")[#strong[#text("Fourier multipliers: examples on the torus – Zeros and Ones")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2020")]

#text("[…] , i.e., our Fourier multipliers to depend on , namely These inequalities arise when studying pseudodifferential operators. Such multipliers create issues with orthogonality, namely the identity may not hold anymore if we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5c9325d309850625be16f6a39070b19e49115de31b3de9e0d398ddc8069671-75bb9a6debd5f2e37f3169e692edc05997f786183f745dfb9208210e5465c712.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Calvin Khor")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560538")[#strong[#text("Calvin Khor")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("I’m not sure how to use Exercise 7 to rigourise (18), which is the ")#mi("L^2")#text(" bound uniform in ")#mi("K")#text(" for ")#mi("\\sum_{k=1}^K a_k(X,D) f")#text(" in the proof of the Calderon-Vallaincourt Theorem. When I simply replace ")#mi("a_k(X,D)f = \\sum_{j\\ge0} P_j (a_k(X,D) f)")#text(", I find that the exponential decay ")#tao-math("2^{-\\left|j-k\\right|}", block: false)#text(" is not enough to deal with the double sum in ")#mi("j,k, \\, j\\neq k")#text(": I get a bound linear in ")#mi("K")#text(". So I feel like I’m missing something quite simple. Anyone have some pointers?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560539")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2020")])]

#text("Apply Littlewood-Paley decomposition to both sides of ")#mi("a_k(X,D)")#text(" (not just the left side) to get two useful exponential decay factors rather than just one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c5c9325d309850625be16f6a39070b19e49115de31b3de9e0d398ddc8069671-75bb9a6debd5f2e37f3169e692edc05997f786183f745dfb9208210e5465c712.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Calvin Khor")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560567")[#strong[#text("Calvin Khor")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("Thanks for the hint. I managed to finish by instead using that ")#mi("a_k(X,D)P_j")#text(" vanishes for ")#tao-math("\\left|k-j\\right|\\ge 2", block: false)#text(". I’m still not sure how to get a second exponential decay factor, because I only have one copy of ")#mi("a(X,D)")#text(" which can only use up one of the ")#mi("P_j")#text("s?")

#text("Also some minor typos")

#text("1. in exercise 8(i), the last few words, it should be Theorem 8, not Exercise 8")

#text("2. Near the beginning of the application of Cotlar-Stein, I think ")#mi("a_{k}(X, D)^{*} a_{j}(X, D)^{*} f(x)=\\int_{\\mathbf{R}} K_{k^{*} j}(x, z) f(z) d z")#linebreak()#text(" has one too many stars on the left (I believe ")#mi("a_{j}(X, D)^*")#text(" should not have a star)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-560650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2020")])]

#text("Thanks for the corrections.")

#text("The operator norm of ")#mi("P_j a_k(X,D) P_{j^{\\prime}}")#text(" can be bounded both by ")#tao-math("O(2^{-\\left|j-k\\right|})", block: false)#text(" and by ")#tao-math("O( 2^{-\\left|j^{\\prime}-k\\right|})", block: false)#text(", so by taking geometric means one can get a bound ")#tao-math("O( 2^{-\\left|j-k\\right|/2} 2^{-\\left|j^{\\prime}-k\\right|/2})", block: false)#text(" that has two exponential decay factors (note that the precise numerical exponent in the exponential decay factors are not of major importance for these arguments). As you say one can certainly do better by exploiting the vanishing of ")#mi("a_k(X,D) P_{j^{\\prime}}")#text(" when ")#tao-math("\\left|k-j^{\\prime}\\right| \\geq 2", block: false)#text(", although this is a feature specific to the Kohn-Nirenberg calculus and does not hold for instance for the Weyl calculus.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbb07b1b42c4ffacdf48e5336ff2c87c5eaf8edcf3c78038a429ce82f7657c88-337f0924abbcbd9d627b18acb800b5304ee9a4608f7909196054212f645112f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Connor")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-645526")[#strong[#text("Connor")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2022")])]

#text("I’m trying to follow the argument Professor Tao has outlined but I end up with a dependence on ")#mi("K")#text(". To summarize, here is what I’ve done:")

#text("Applying Littlewood-Paley decompositions we have ")#mi("a_k(X,D)f(x) = \\sum_{j \\geq 0}\\sum_{j^{\\prime} \\geq 0} P_ja_k(X,D)P_{j^{\\prime}}f(x).")#text(" Taking the geometric mean of the two inequalities we derived we have the estimate ")#tao-math("\\left|\\left|P_j a_k(X,D)P_{j^{\\prime}}f \\right|\\right|_{L^2} \\leq C2^{-\\frac{\\left|j-k\\right|}{2}}2^{-\\frac{\\left|j^{\\prime}-k\\right|}{2}} \\left|\\left|f\\right|\\right|_{L^2}", block: false)#text(".")

#text("It seems to me that Professor Tao is indicating that ")#tao-math("\\sum_{k = 1}^{K} \\sum_{j \\geq 0}\\sum_{j^{\\prime} \\geq 0} 2^{-\\frac{\\left|j-k\\right|}{2}}2^{-\\frac{\\left|j^{\\prime}-k\\right|}{2}}", block: false)#text(" is independent of ")#mi("K")#text(". My question is how can we show that explicitly? Summing the series by splitting it into the parts where ")#mi("j > k")#text(", ")#mi("j \\leq k")#text(", ")#mi("j^{\\prime} > k")#text(" and ")#mi("j^{\\prime} \\leq k")#text(" allows us to deal with the series in ")#mi("j")#text(" and ")#mi("j^{\\prime}")#text(" but leaves us with a dependence on ")#mi("K")#text(". I think this is similar to the issue Calvin first encountered when using the single Littlewood-Paley decomposition.")

#text("If anyone has any clarifications or pointers I would be very appreciative!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-645754")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2022")])]

#text("This triple sum is unbounded (consider the contribution of the diagonal terms ")#mi("j=j^{\\prime}=k")#text("). To get operator norm bounds on ")#mi("\\sum_k a_k(X,D)")#text(" that are independent of ")#mi("K")#text(", one needs to exploit the almost orthogonality of the Littlewood-Paley projections, for instance via the Cotlar-Stein lemma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cbb07b1b42c4ffacdf48e5336ff2c87c5eaf8edcf3c78038a429ce82f7657c88-337f0924abbcbd9d627b18acb800b5304ee9a4608f7909196054212f645112f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Connor")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-646010")[#strong[#text("Connor")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("Thank you, Professor Tao! My confusion was due to the fact that in the exercise you state we should be looking to prove (18) without using the Cotlar-Stein lemma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-646013")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2022")])]

#text("In this particular case one can argue without using Cotlar-Stein, using instead estimates such as ")#tao-math("\\left\\| \\sum_j P_j f_j \\right\\|_2^2 \\lesssim \\sum_j \\left\\|P_j f_j\\right\\|_2^2", block: false)#text(" and ")#tao-math("\\sum_j \\left\\|P_j f \\right\\|_2^2 \\lesssim \\left\\|f\\right\\|_2^2", block: false)#text(" which can be easily proven by Plancherel. One can also take advantage of the approximate idempotency ")#mi("P_j = P_j \\tilde P_j")#text(" where ")#mi("\\tilde P_j")#text(" is a suitable enlargement of ")#mi("P_j")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-561740")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2020")])]

#text("[…] this symbol is far too rough for us to be able to use pseudodifferential operator tools from the previous set of notes. Nevertheless, the “time-frequency analysis” mindset of trying to efficiently decompose […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7db39a11b14395af78889fbf5ec42d40501fbdc6ebf71b2c4471f85e4b29a18f-5297b4e33ce1b9abb1f6c47751237503d516499c2fcd867852744dbcec017eb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562149")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("I was just thinking about some earlier blog post you had made about problems with finding regular solutions to Navier-Stokes. I think the argument was that a potential problem was that the energy would increasingly be concentrated at smaller length-scales as time goes on. Just based upon physical intuition, if all energy would be concentrated at small length scales I would expect a lot of small eddies spinning in different directions. In that case, as the eddies get smaller I would expect the “surface area” between them to increase, which should also increase the viscous forces that should scale with the surface area of oppositely moving segments of the fluid. My guess is that the viscous forces should eventually quench the eddies at a sufficiently small scale. Just a thought!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("The proposed blowup mechanism doesn’t necessarily involve many concentrations close together, it should be possible with just one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e09181701988f8c7482fb1a5f25493d382bc21820ec86fa285cdff28633444-9ff2945901ec218cb9c3cec767b929228bb6a5672585446558cc23324a982c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaoyan Su")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562180")[#strong[#text("Xiaoyan Su")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2020")])]

#text("I can’t get uniform bounds in ")#mi("K")#text(" for exercise 17. What I did was I expanded using Taylor’s with integral remainder ")#mi("a_k(x-y,x-\\eta) = a_k(x,\\xi) + \\nabla a_k(x,\\xi) \\cdot (-y,-\\eta) + O(y^2 + \\eta^2)")#text("; the first term is exactly what we’re subtracting from and the gradient term disappears, so I just need to estimate the remaining integral correctly. But when I do this, I think I get the correct symbol estimate, but its constant in $k$ (hence bad when summed in $k$). Does this sound like its mostly correct, and do you have any hints?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562756")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("This is the right approach (though when ")#mi("y, \\eta")#text(" is really large then the Taylor expansion is inefficient and other means of estimation may be superior). Intuitively ")#mi("a_k * W_{\\phi_k}")#text(" should be located in roughly the same location of phase space as ")#mi("a_k")#text(" and in particular should exhibit decay when ")#mi("\\langle \\xi \\rangle")#text(" is much larger than or much smaller than ")#mi("2^k")#text(", which can be used to recover summability in ")#mi("k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e09181701988f8c7482fb1a5f25493d382bc21820ec86fa285cdff28633444-9ff2945901ec218cb9c3cec767b929228bb6a5672585446558cc23324a982c12.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaoyan Su")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562799")[#strong[#text("Xiaoyan Su")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2020")])]

#text("Thank you very much Prof Tao, I used the integral form for the remainder of the Taylor expansion, and I think my form of the remainder is good for large y, eta as well. I didn’t understand that intuition because ")#mi("W_{\\phi_k}")#text(" is very spread out in frequency for ")#mi("k\\gg 1")#text(", but with your hint I managed to finish the exercise.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8bacc9b43fbce0909b2191aa3ffba7d82debf596cb10ff7edb188fea21a9255b-a12d68cccc87239fb4fd25fea9224dd6eb021608ba6b35491c0a496eb071a0e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hhy177")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562951")[#strong[#text("hhy177")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("In Exercise 20(i), I write Kohn-Nirenberg of a and Weyl quantization of ")#mi("\\tilde a")#text(" as integration against a kernel. The equality of the kernel gives me a formula for ")#mi("\\tilde a")#text(" as a necessary condition. To show it is sufficient, I need to use the kernel representation of the quantizations. Even if I assume a is compact support, ")#mi("\\tilde a")#text(" does not seem to be compact supported so I can only use the kernel representation for ")#mi("a_{KN}")#text(" but not for ")#mi("\\tilde a_W")#text(". So it seems like I can only show ")#mi("a_{KN} f = \\tilde a_W f")#text(" as tempered distribution for every Schwartz ")#mi("f")#text(". How do we (do we need to) show ")#mi("a_{KN} f = \\tilde a_W f")#text(" as Schwartz function? (I guess we haven’t show the Weyl quantization of a symbol takes Schwartz to Schwartz, we did it only for KN quantization in Ex 1, but I think it is true as well).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-562978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2020")])]

#text("For smooth compactly supported ")#mi("a")#text(", the associated Weyl symbol ")#mi("\\tilde a")#text(" will not be compactly supported in general, but one can still establish a lot of regularity and decay on ")#mi("\\tilde a")#text(" that will be sufficient to justify the formal calculations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-564234")[#strong[#text("MATH 247B: Modern Real-Variable Harmonic Analysis – Countable Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2020")]

#text("[…] Pseudifferential Operators […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-568455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2020")])]

#text("man u ever take that semiclassical approximation of the WKB to the N to the I to the G-G-A, man?")#linebreak()#text(" i got my bro egorov helping me tame the singularities for the propagation this wave i’ve surfing brah")

#text("i’m only 12 so sorry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dn1214")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-645034")[#strong[#text("dn1214")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2022")])]

#text("Is there a generalization of the symbolic calculus for Lipschitz in ")#mi("x")#text(" symbols ")#mi("a(x,\\xi)")#text("?")#linebreak()#text(" For example the elliptic symbol ")#tao-math("a(x,\\xi)=(1+\\left|x\\right|)\\left|\\xi\\right|^2\\chi(x)\\psi(\\xi)", block: false)#text(" where we smoothly localize in ")#mi("x, \\xi")#text(" around ")#mi("0")#text(". (say that on the support of ")#mi("\\xi")#text(", ")#tao-math("1+\\left|x\\right|\\ge 1/2", block: false)#text("). Is there a way of inverting the operator ")#mi("a(x,D_x)")#text(" in this way: there exists some operator ")#mi("b(x,D_x)")#text(" (of order ")#mi("-2")#text(") such that ")#mi("b(x,D)a(x,D) = \\mathrm{id} + r(x,D_x)")#text(" where ")#mi("r")#text(" has lower order?")

#text("The problem I can see is that the formula for commuting the principal symbol of ")#mi("a(x,D)b(x,D)")#text(" does not make sense anymore. But I have the intuition that the result I am asking for should be true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-645243")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2022")])]

#text("As a general principle, once one is outside the standard symbol classes, it becomes difficult to generate a useful symbolic calculus for general classes of these operators, and one should instead treat these operators with more specialized tools. For instance, inverting elliptic operators with Lipschitz (or even bounded) coefficients is a well studied topic in elliptic PDE, but requires tools specific to elliptic equations rather than general symbol calculus; see for instance the text by Gilbarg and Trudinger.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/05/02/247b-notes-3-pseudodifferential-operators/#comment-681780")[#strong[#text("Sulla cresta dell'onda: intervista con Roberta Bianchini, vincitrice del Premio SIMAI 2023 - Maddmaths!")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2023")]

#text("[…] altri risultati teorici rigorosi, con tecniche abbastanza avanzate, tra cui analisi di Fourier e calcolo paradifferenziale. Mi piaceva l’ambiente di lavoro, ma non solo per l’aspetto scientifico. Ecco, c’era quella […]")
]
