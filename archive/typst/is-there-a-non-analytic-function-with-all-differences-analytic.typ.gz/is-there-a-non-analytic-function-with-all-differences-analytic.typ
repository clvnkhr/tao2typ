// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/
// Converted to Typst by tao2typ: "2026-10-14T16:38:56.549865+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Is there a non-analytic function with all differences analytic?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Is there a non-analytic function with all differences analytic?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 May 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/")[#text("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I was asked the following interesting question from a bright high school student I am working with, to which I did not immediately know the answer:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question 1")]#text(" Does there exist a smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" which is not real analytic, but such that all the differences ")#mi("{x \\mapsto f(x+h) - f(x)}")#text(" are real analytic for every ")#mi("{h \\in {\\bf R}}")#text("?")
]

#text("The hypothesis implies that the Newton quotients ")#mi("{\\frac{f(x+h)-f(x)}{h}}")#text(" are real analytic for every ")#mi("{h \\neq 0}")#text(". If analyticity was preserved by smooth limits, this would imply that ")#mi("{f^{\\prime}}")#text(" is real analytic, which would make ")#mi("{f}")#text(" real analytic. However, we are not assuming any uniformity in the analyticity of the Newton quotients, so this simple argument does not seem to resolve the question immediately.")

#text("In the case that ")#mi("{f}")#text(" is periodic, say periodic with period ")#mi("{1}")#text(", one can answer the question in the negative by Fourier series. Perform a Fourier expansion ")#mi("{f(x) = \\sum_{n \\in {\\bf Z}} c_n e^{2\\pi i nx}}")#text(". If ")#mi("{f}")#text(" is not real analytic, then there is a sequence ")#mi("{n_j}")#text(" going to infinity such that ")#tao-math("{\\left|c_{n_j}\\right| = e^{-o(n_j)}}", block: false)#text(" as ")#mi("{j \\rightarrow \\infty}")#text(". From the Borel-Cantelli lemma one can then find a real number ")#mi("{h}")#text(" such that ")#tao-math("{\\left|e^{2\\pi i h n_j} - 1\\right| \\gg \\frac{1}{n^2_j}}", block: false)#text(" (say) for infinitely many ")#mi("{j}")#text(", hence ")#tao-math("{\\left|(e^{2\\pi i h n_j} - 1) c_{n_j}\\right| \\gg n_j^2 e^{-o(n_j)}}", block: false)#text(" for infinitely many ")#mi("{j}")#text(". Thus the Fourier coefficients of ")#mi("{x \\mapsto f(x+h) - f(x)}")#text(" do not decay exponentially and hence this function is not analytic, a contradiction.")

#text("I was not able to quickly resolve the non-periodic case, but I thought perhaps this might be a good problem to crowdsource, so I invite readers to contribute their thoughts on this problem here. In the spirit of the polymath projects, I would encourage comments that contain thoughts that fall short of a complete solution, in the event that some other reader may be able to take the thought further.")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a85e534696ef6a0b6a5de0f1f3f2b205d025b177f4c552a5cde01e8ac58998c-a21243e72d71594e72e6ae5e24a36cb646d0820c1842d239a68e887d4d7403c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Is there a non-analytic function with all differences analytic? – Mathematics, for all Mankind!")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625539")[#strong[#text("Is there a non-analytic function with all differences analytic? – Mathematics, for all Mankind!")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("[…] Is there a non-analytic function with all differences analytic? […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c50c111d753296f99e157715448eecb1f0960397cb214e821625832df460bad-f41afcbe141007df0c04d54985d059f67e6acc924c98e4d8a8b0054b76097bb3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real-user")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625542")[#strong[#text("Real-user")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("Hi,")#linebreak()#text(" This is a very interesting question. What about posting it in math.stackexchange, or mathoverflow?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625545")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("Maybe a detour via algebraic geometry considering germs of real analytic functions could work? I’m also thinking of drawing a parallel with differential geometry viewing the map that maps f to its finite Newtion quotient of parameter h as an analogue of a tangent vector, and the real analyticity of f emerging as a result of the existence of a connexion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625546")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("Let ")#mi("f")#text(" be as given in the problem. Suppose we could find an analytic function ")#mi("g")#text(" so that ")#mi("g(x+1)-g(x) = f(x+1)-f(x)")#text(". Then ")#mi("f-g")#text(" would be a periodic function with analytic difference quotients, hence analytic by the solution above and it would follow that ")#mi("f")#text(" is analytic as well.")

#text("It thus suffices to solve the following problem: given a real analytic function ")#mi("r")#text(" satisfying an appropriate hypothesis find an analytic function ")#mi("f")#text(" so that ")#mi("g(x+1)-g(x) = r")#text(".")

#text("For a flavour of the hypothesis note that if ")#mi("r(x) = f(x+1)-f(x)")#text(" and ")#mi("f")#text(" is integrable then ")#mi("\\hat{r}")#text(" vanishes on the integers, and ")#mi("\\frac{\\hat{r}(k)}{e(kx)-1}")#text(" is continuous so might possibly have an inverse Fourier transform.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a94518cec29198c93e0dee478f627c358142810fc7258c9f94c5bd58d009248-8a48e4ec821fe7d6018b16662759e733a85b82f6b90e759fcec8ef05adc81ab6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaowei Xu")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625551")[#strong[#text("Xiaowei Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("Maybe this is too elementary and I am sure you have considered this. But we could have worked with the telescoping sum")

#mi("g(n)=f(x-n)-f(x-n+1)")

#text("Then we have ")#mi("f(x)=f(x)-f(x-1)+f(x-1)-f(x-2)\\dots=\\sum_{n=0}^{\\infty}g(n)")#text(". By the hypothesis, each ")#mi("g(n)")#text(" is analytic and have the radius of convergence in an open set of the form ")#mi("I_n=(a_n, b_n)")#text(". Thus we just need some type of Baire-Category theorem to ensure that ")#mi("\\bigcap^{\\infty}_{n=1}I_{n}!=\\emptyset")#text(". Since ")#mi("f")#text(" is only smooth, we could not really restrict the size of ")#mi("I_n")#text(", but ")#tao-math("\\left|I_n\\right|", block: false)#text(" shrinking to zero would imply ")#mi("f")#text(" behaves badly near ")#mi("-n")#text(" (or positive ")#mi("n")#text(") for large enough ")#mi("n")#text(". Since there is nothing particular about ")#mi("n")#text(" being an integer, this showed ")#mi("f")#text(" should be “almost” non-analytic almost everywhere on large enough values in ")#mi("\\mathbb{R}")#text(". However, if ")#mi("f")#text(" is analytic somewhere a translation argument showed this cannot exist. So ")#mi("f")#text(" must be nowhere analytic and its translations also gradually “become worse”. But I am not sure if this is useful for anything.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdd792a77fbb5e693f6d099d750bbce27368ddeb3dcd387aadb48b4cf1071555-21338a189c379926fae673037762c0fdd944b9ce1385b033738a4a7007af2b63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of julien PUYDT")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625553")[#strong[#text("julien PUYDT")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2021")])]

#text("The indicator function for the rational numbers, denote it by ")#mi("f")#text(", has the property that for each ")#mi("h")#text(" rational, ")#mi("x\\mapsto f(x+h)-f(x)")#text(" is zero hence analytic, even though ")#mi("f")#text(" isn’t even continuous.")

#text("Granted, that doesn’t solve the question for all ")#mi("h")#text(" real, but it’s still a nice example, as it’s pretty trivial to explain to a young student and already shows how tricky things can become.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("I actually thought of this same example, but didn’t end up writing it because I’m an amateur. Glad to see it actually got some attention :)")

#text("I was also wondering about solutions to slight variations of the problem. For example, what if we remove the smoothness condition on ")#mi("f")#text(", or what if we want that ")#mi("h")#text(" takes values in some set different than ")#mi("R")#text("? I was thinking something along the lines of ")#mi("h")#text(" taking values in some set ")#mi("S")#text(", and then taking ")#mi("f")#text(" to be the indicator function of a set ")#mi("T")#text(" that is invariant by translations under elements of ")#mi("S")#text(". The case of the above comment would then be ")#mi("S = T = {\\mathbf Q}")#text(".")

#text("Yet another interesting variation would be replacing the difference by some other function of ")#mi("f(x+h)")#text(" and ")#mi("f(x)")#text(", for example there some or any arbitrary linear combination. I might be completely wrong, but something tells me that if we find an example for one linear combination, then we can easily modify it to an example for most (all?) linear combinations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("This idea is applicable to any additive group ")#mi("G")#text(" of real numbers (which may be generated from any set ")#mi("S")#text(" of real numbers – as the smallest additive group containing ")#mi("S")#text(").")#linebreak()#text(" It is interesting to observe that if ")#mi("S")#text(" is Hamel basis, then the smallest additive group containing ")#mi("S")#text(" is ")#mi("\\mathbb R")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625731")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("If you demand ")#mi("x \\mapsto f(x+h) - f(x)")#text(" to be analytic for every ")#mi("h \\in G")#text(" where ")#mi("G")#text(" is an additive subgroup of ")#mi("\\mathbf{R}")#text(" but ")#mi("\\ne \\mathbf{R}")#text(" then taking ")#mi("f")#text(" to be the indicator function of ")#mi("S")#text(" suffices, since in this case ")#mi("f")#text(" is clearly not analytic, and also ")#mi("f(x+h) - f(x) = 0")#text(" for every ")#mi("x \\in \\mathbf{R}")#text(" and every ")#mi("h \\in G.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abde883b53c8880ea5015b4d266450d48f94b872edd482be4a62a9ea7448f602-dee2d6e857a0518bf93909acdf09ea6654a25cddb725216e24441a6160b30870.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rafal Filipow")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625567")[#strong[#text("Rafal Filipow")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("The question considered in the post is connected with the so called “the difference property in the sense of de Bruijn” (see [1], and a very good survey [2]).")

#text("We say that a family F of functions has the difference property if for each function f such that f(x+h)-f(x) belongs to F for each h, there are g in F and an additive function A such that f = g + A.")

#text("In [1], de Bruijn proved that the family of all analytic functions has the difference property. Consequently, if all differences f(x+h)-f(x) are analytic, there is an analytic g and an additive A with f=g+A. Now, if we assume that f is smooth, then both f and g are bounded on the unit interval [0,1]. It means that the additive function A is bounded on [0,1] as well, so A is in fact linear. All in all, f is analytic as a sum of 2 analytic functions.")

#text("Best,")#linebreak()#text(" Rafal Filipow")

#text("[1] N. G. de Bruijn, Functions whose differences belong to a given class. Nieuw Arch. Wiskunde (2) 23, (1951). 194–218.")

#text("[2] M. Laczkovich, The difference property. Paul Erdős and his mathematics, I (Budapest, 1999), 363–410, Bolyai Soc. Math. Stud., 11, János Bolyai Math. Soc., Budapest, 2002.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db518652cc3070afcdabaa00554b256190b351b0c4b9c71591e17406f7c13d2c-3aeee3abec9d9c13ede67bd756ec0d9e752e956fb03715ee421141933f4762d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of itaibn")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625571")[#strong[#text("itaibn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("First of all, it would be nice to have a short name for the property in the question. Perhaps “difference-analytic”? I suggest that this term is not restricted to smooth functions, but perhaps to arbitrary functions whose differences is analytic, since we might want to prove partial results such as that if such a function is continuous then it is ")#mi("C^1")#text(". On the other hand, Julien’s remark suggests that there might exist pretty wild non-continuous difference-analytic functions, so it might be worth excluding them.")

#text("I was hoping it might be possible to start with one difference-analytic function ")#mi("f")#text(", and transform it into another difference-analytic function which is periodic. One approach I considered is by multiplying with an analytic function ")#mi("g")#text(". Alas, this does not work:")

#mi("f (x + h)  g (x + h) - f (x) g (x) = (f (x + h) - f (x)) g (x) + f (x + h) (g (x + h) - g (x))")

#mi("+ f(x+h) (g(x+h) - g(x))")

#text("The first term is analytic, but we couldn’t possibly know that the second term is analytic without already knowing that ")#mi("f")#text(" is analytic.")

#text("On the other hand, the convolution of ")#mi("f")#text(" with a function ")#mi("u")#text(" of compact support is difference-analytic, as")

#mi("(f * u) (x + h) - (f * u) (x) = ((f (\\cdot + h) - f) * u) (x),")

#text("which is analytic since it is a convolution of an analytic function and a function of compact support, and such a convolution is analytic because a function is analytic iff it has a holomorphic extension. ")#mi("f")#text(" and ")#mi("u")#text(" need to be regular enough so that the convolution makes sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625576")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("It occurs to me that the ")#link("https://en.wikipedia.org/wiki/Steinhaus_theorem")[#text("Steinhaus lemma")]#text(" could be useful. For any ")#mi("h \\in [0,1]")#text(", the function ")#mi("f(x+h)-f(x)")#text(" is analytic, and so obeys bounds ")#tao-math("\\left|f^{(j)}(x+h) - f^{(j)}(x)\\right| \\leq C_h^{j+1} j!", block: false)#text(" for all ")#mi("j")#text(", all ")#mi("x \\in [-10,10]")#text(" (say), and some constant ")#mi("C_h > 0")#text(" depending on ")#mi("h")#text(". As I mentioned in the main post, there is no uniformity assumed on the analyticity and so ")#mi("C_h")#text(" could behave in a bad way with respect to ")#mi("h")#text(". However, if for each ")#mi("n")#text(" we let ")#mi("E_n")#text(" be the set of ")#mi("h \\in [0,1]")#text(" such that ")#mi("C_h \\leq n")#text(", then the ")#mi("E_n")#text(" are measurable and exhaust ")#mi("[0,1]")#text(", hence one of the ")#mi("E_n")#text(" must have positive measure. The Steinhaus lemma then gives us an interval ")#mi("(-\\varepsilon,\\varepsilon)")#text(" around the origin that lies in ")#mi("E_n-E_n")#text(". Thus if ")#tao-math("\\left|h\\right| \\leq \\varepsilon", block: false)#text(" then there exists ")#mi("k \\in E_n")#text(" such that ")#mi("k+h \\in E_n")#text(", hence for any ")#mi("x \\in [-5,5]")#text(" and any ")#mi("j")#text(" we have")

#tao-math("\\left|f^{(j)}(x+h+k) - f^{(j)}(x)\\right| \\leq n^{j+1} j!", block: false)#linebreak()#text(" ")#tao-math("\\left|f^{(j)}(x+h+k) - f^{(j)}(x+h)\\right| \\leq n^{j+1} j!", block: false)

#text("and hence by the triangle inequality we now have a uniform bound")#linebreak()#text(" ")#tao-math("\\left|f^{(j)}(x+h) - f^{(j)}(x)\\right| \\leq 2n^{j+1} j!", block: false)

#text("whenever ")#tao-math("\\left|h\\right| \\leq \\varepsilon", block: false)#text(", ")#mi("j \\geq 0")#text(", and ")#mi("x \\in [-5,5]")#text(". Not sure where to go from here (still not enough uniformity to pass to the limit in the Newton quotient) but it does seem one step closer to making ")#mi("f")#text(" analytic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625581")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("I took a look at ")#link("https://pure.tue.nl/ws/portalfiles/portal/4316577/597498.pdf")[#text("de Bruijn’s paper")]#text(" mentioned in Rafal’s answer and it turns out he basically uses the same argument as above (but with Baire category instead of Steinhaus) and completes the argument as follows. For any ")#mi("x \\in [-1,1]")#text(", the ")#mi("j^{th}")#text(" divided difference ")#mi("\\Delta^j_{\\varepsilon/j} f(x)")#text(" is of the form ")#mi("f^{(j)}(x+h)")#text(" for some ")#tao-math("\\left|h\\right| \\leq \\varepsilon", block: false)#text(", where ")#mi("\\Delta_h f(x)  := (f(x+h)-f(x))/h")#text(". On the other hand, since ")#mi("f")#text(" is bounded on say ")#mi("[-2,2]")#text(", this divided difference is bounded by ")#mi("O( (2j/\\varepsilon)^j )")#text(". From the previous bound and the triangle inequality we now have")

#mi("\\displaystyle f^{(j)}(x) \\ll (2j/\\varepsilon)^j  + 2n^{j+1} j!")

#text("for any ")#mi("j")#text(" and ")#mi("x \\in [-1,1]")#text(", and this gives the analyticity of ")#mi("f")#text(" in this interval, and similarly for the rest of the real line.")

#text("Alternatively, one can integrate the inequality")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|f^{(j)}(x+h) - f^{(j)}(x)\\right| \\leq 2n^{j+1} j!", block: false)#linebreak()#text(" using the fundamental theorem of calculus to conclude that")#linebreak()#text(" ")#tao-math("f^{(j)}(x) \\ll \\frac{1}{\\varepsilon} \\left|f^{(j-1)}(x) + f^{(j-1)}(x \\pm \\varepsilon)\\right| + n^{j+1} j!", block: false)#linebreak()#text(" for either choice of sign ")#mi("\\pm")#text(", and iterate to obtain a similar estimate.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625752")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("I think this basically means that you answered (this high-schooler’s) question. One note: Since we assumed a-priori that $f$ can be essentially an arbitrary function, the notation $f^{(j)}$ doesn’t really make sense unless it’s referring to some kind of divided difference (because $f$ can be arbitrary far from being non-differentiable as many times as you want). I think this invalidates the proof on a surface level but there’s a slightly modified version of it that doesn’t suffer from this problem.")

#text("By the way, I’ve never understood how we can get bounds of the type $|f^j|\\leq CD^j j!$ for some $C, D$ for an arbitrary true real-analytic function $f$. I understand that any sequence of numbers $(a_j)_{j = 1}^{\\infty}$ with bounds $|a_j|\\leq CD^j j!$ is trivially the derivative sequence of a real-analytic function near zero by Taylor’s theorem, but I haven’t been able to come up with a converse of this (which would be that the derivative sequence of a real-analytic function can *only* be such a sequence).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625753")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("Sorry, I don’t know how to write math-that-displays-properly on this comments section, so that’s why there are lots of dollar signs. I think it’s a math tag or something, but I don’t know. You should make it clearer somewhere.")

#text("Tests: \\frac{1}{2}, ")#mi("\\frac{1}{2}")#text(", ")#tao-fit-display[#mitex("\\frac{1}{2}")]#text(", \\begin{equation}\\frac{1}{2}\\end{equation}, ")#tao-fit-display[#mitex("\\frac{1}{2}")]

#text("Again but with spaces for posterity: \\ f r a c { 1 } { 2 } , \\ ( \\ f r a c { 1 } { 2 } \\ ) , \\ [ \\ f r a c { 1 } { 2 } \\ ] , \\ b e g i n { e q u a t i o n } \\ f r a c { 1 } { 2 } \\ e n d { e q u a t i o n } , $ $ \\ f r a c { 1 } { 2 } $ $")

#emph[#text("[Instructions for using LaTeX are at the bottom left of the blog – T.]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/659f4ffcba0c6af3e8d0b9a30181d2e2e69add7e31dfe4abd49924787875bd57-cfe4df58f7c50bb233474d934d334f3b0d3e08e0b1b77dcee9d8434603cbcb72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Márton Elekes")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625580")[#strong[#text("Márton Elekes")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("A function class C has the so called difference property, if the following holds: if f(x+h)-f(x) is in C for every h then f = g + A, where g is in C and A is an additive function (i.e. A(x + y) = A(x) + A(y) for every x,y).")

#text("In the following paper it was shown that the class of real analytic functions has the difference property:")

#text("de Bruijn, N. G.")#linebreak()#text(" Functions whose differences belong to a given class.")#linebreak()#text(" Nieuw Arch. Wiskunde (2) 23, (1951). 194–218.")

#text("This implies that if f is, say, measurable, and the differences f(x+h)-f(x) are all real analytic, then f itself is real analytic.")

#text("For more information on the difference property see e.g.")

#text("Laczkovich, M. (H-EOTVO-AN)")#linebreak()#text(" The difference property. Paul Erdős and his mathematics, I (Budapest, 1999), 363–410,")#linebreak()#text(" Bolyai Soc. Math. Stud., 11, János Bolyai Math. Soc., Budapest, 2002.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hello")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625587")[#strong[#text("Hello")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("if we replace f differentiable or continuous instead of smooth what is the answer?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625734")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("See section 1.6 from the measure theory textbook by prof. Tao.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57cac1a424b22b07852cf16b559bffa6e98bd73063de03a630b8a3ce8b8cd0e-091c0e2fe196a438759d5014383ed0f659a13e1b557eb6fa776f4f27a82ed12f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625589")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("The sums and negations of analytic functions are analytic. From $A- B = A + (-B)$ you can just calculate $f(x+h) – f(x) – (f(x +h) – f(x)) = -2f(x)$ is analytic, thus f(x) is analytic?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57cac1a424b22b07852cf16b559bffa6e98bd73063de03a630b8a3ce8b8cd0e-091c0e2fe196a438759d5014383ed0f659a13e1b557eb6fa776f4f27a82ed12f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625593")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2021")])]

#text("Sorry, a calculation mistake. $f(x+h) – f(x) – (f(x +h) – f(x)) = 0. $ I don’t know much about analytic functions, but I remember that if it holds on a point it holds in some interval. So $f(0+y) – f(0) +f(0) – f(0-y)= 2f(y) $ is analytic if $f$ is odd. $f(0+y) – f(0) +f(0) – f(0-y)= 0$ is if $f$ is even. Every analytic function is a sum of it’s odd and even parts so $f$ should be analytic because this holds for any $y$.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f57cac1a424b22b07852cf16b559bffa6e98bd73063de03a630b8a3ce8b8cd0e-091c0e2fe196a438759d5014383ed0f659a13e1b557eb6fa776f4f27a82ed12f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625723")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("It seems that for even part I need this $f(0+y) – f(0) – f(0) + f(0-y)= -2f(0) +2f(y)$. However, W.L.O.G we can assume that $f(0) = 0.$ Thus, $f(0 + h) – f(0) = f(h)$ is analytic is enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0904b266ce325380988488dacbbc4274f49d9dd82956617db155ed7de50d20a-ae3871cb14b7d1a7ec4167496bcd21b873217f8a5c5da2576ec349d708903049.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mr.Postman")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-644978")[#strong[#text("Mr.Postman")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("We are not elitistic or anything…all I got was one thumb down. Tell that kid that If she wants to do deep works she is in wrong company.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1fcb59fcade702d71c06bb06ac0961f4546c4fa3deda24b737b00b25789e2b09-5db8559cf0afc272710eebe4802614afbaefe0acccb3b53802e28fa105f6924f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Donald")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625715")[#strong[#text("Donald")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("Take a hypothetical such function f. It must clearly be nonanalytic in every open neighbourhood. let k(x)=exp(-1/x) (0 for x<=0). let p(x) be formed by taking the talor expansion of f(x)/k(x) at 1. let P(x)=k(x)p(x). This is an analytic function at every point except 0. So f(x)-P(x) is not analytic, and has all derivatives 0 at 1.")#linebreak()#text(" (with the taylor series at point 0 not being effected.) flip this round, swaping 0 and 1. You now have a function F(x) such that F(x) is not analytic, and F(x) has a taylor series of 0 at points 0 and 1.")#linebreak()#text(" If you make this cyclic, the analytic difference property should hold. Even at the endpoints, its analytic at both sides, and the taylor series at the sides is the same, so analytic. Thus we have constructed a periodic function with this property. Contradiction.")#linebreak()#text(" (Probably an error somewhere here, don't know where.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#mi("p(x)")#text(" was claimed to be “formed” by taking the Taylor expansion of ")#mi("f(x)/k(x)")#text(", the problem is that ")#mi("f(x)/k(x)")#text(" is not necessarily analytic (i.e. its Taylor series has radius of convergence = 0) – so p(x) is not necessarily well defined on any open interval by its Taylor series.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-625767")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/05/08/is-there-a-non-analytic-function-with-all-differences-analytic/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-629384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2021")])]

#text("Definitely")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-630280")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#text("Another problem of a similar flavour is the following question from the Miklos Schweitzer competition, 2019 :")

#text("If ")#mi("f: \\mathbf{R} \\to \\mathbf{R}")#text(" is a measurable function such that ")#mi("\\forall t >0")#text(" the function ")#mi("x \\mapsto f(x+t)-f(x)")#text(" is locally integrable, then ")#mi("f")#text(" must also be locally integrable.")

#text("Unlike the original problem, this result can be proved in a rather elementary way by showing that if for some ")#mi("I \\subseteq \\mathbf{R}")#text(" one has ")#mi("\\int_H |f(x)| dx = \\infty")#text(" then one has either ")#mi("\\int_{I_+} f(x) dx = \\infty")#text(" or ")#mi("\\int_{I_-} f(x) dx = - \\infty")#text(" where $I_+ , I_-$ are respectively the set of points in ")#mi("I")#text(" at which ")#mi("f")#text(" is ")#mi("\\ge 0, 0)")#text(" and eventually obtain that ")#mi("\\int_S |f(x+d) - f(x)| dx = \\infty")#text(" for some ")#mi("d>0")#text(" and some measurable ")#mi("S \\subseteq I_+")#text(" which would refute the local integrability of the difference function ")#mi("x \\mapsto f(x+d) - f(x)")#text(" (for that particular choice of ")#mi("d >0")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-630400")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2021")])]

#text("Is there a smooth but nowhere real analytic function on ")#mi("\\mathbb R")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-630418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2021")])]

#link("https://en.wikipedia.org/wiki/Non-analytic_smooth_function#A_smooth_function_which_is_nowhere_real_analytic")[#text("https://en.wikipedia.org/wiki/Non-analytic_smooth_function#A_smooth_function_which_is_nowhere_real_analytic")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-630506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2021")])]

#text("It seem that in the example given in this wikipedia article, there is an error in the estimate for the radius of convergence because by Stirling’s formula ")#mi("\\lim_{n \\to \\infty}(n^n/n!)^{1/n} = e")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a58cbc95c8e0fbb5402f840ead9f898b853ca0aecf7e43d6198bc0c41143694f-1e49e1afeebf1d6f1abf062cae2444b8b58aaac493133b287a563a5f3e69afe6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mehdi Morshedi")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-632781")[#strong[#text("Mehdi Morshedi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2021")])]

#text("Could we use Fourier integral instead of Fourier series, and extend the same proof for non periodic case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h0sane")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-632900")[#strong[#text("h0sane")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2021")])]

#text("Question Dr. Tao: would the infamous piecewise function defined on R work? Where f := 0 for x <= 0 And e^{-1/x} otherwise? This is infinitely differentials but but the Taylor series converges to 0. Would this be an example of them your question holds? Thanks I’m advance, – fellow math student/learner/doer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More analysis questions from a high school student | What's new")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-634094")[#strong[#text("More analysis questions from a high school student | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("[…] few months ago I posted a question about analytic functions that I received from a bright high school student, which turned out to be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0e4291db6fe627c69f556f1bf30645241ec35497b8e5d3f045d1f0f16b38d804-5a09158a300c2285b0d21aa83eddfa803ef93f0f7d9bb6cb40f9ece7a3ec6c75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Gilson")]], [#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/#comment-689400")[#strong[#text("Frank Gilson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2025")])]

#text("A small note…")

#text("The “Difference Property” (De Bruijn’s theorem) effectively says: ")#strong[#text("“You cannot stay on a lower rung if all your differences are on a higher rung.”")]

#text("Here is the ladder:")

#enum(start: 1, 
[#strong[#text("Continuous")]#text(" ($C^0$)")],
[#strong[#text("Differentiable")]#text(" ($C^k$)")],
[#strong[#text("Smooth")]#text(" ($C^infty$) — ")#emph[#text("Infinitely differentiable, but Taylor series might diverge.")]],
[#strong[#text("Gevrey / Quasi-Analytic")]#text(" — ")#emph[#text("Taylor series might diverge, but “controlled” growth.")]],
[#strong[#text("Real Analytic")]#text(" ($C^omega$) — ")#emph[#text("Taylor series converges perfectly.")]],
[#strong[#text("Polynomials")]]
)
]
