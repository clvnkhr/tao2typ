// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/
// Converted to Typst by tao2typ: "2026-10-14T15:21:00.354051+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Dense sets of natural numbers with unusually large least common multiples", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Dense sets of natural numbers with unusually large least common multiples")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 July 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/")[#text("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2407.04226")[#text("Dense sets of natural numbers with unusually large least common multiples")]#text("“. This short paper answers (in the negative) a somewhat obscure ")#link("https://www.erdosproblems.com/442")[#text("question of Erdős and Graham")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Is it true that if ")#mi("{A}")#text(" is a set of natural numbers for which")

#metadata(none) <tao-3d9fc4bde7ceef058d65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{\\log\\log x} \\sum_{n \\in A: n \\leq x} \\frac{1}{n}")]]

#text("goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text(", then the quantity")

#metadata(none) <tao-3fe3cde54dc9f3f924c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{1}{(\\sum_{n \\in A: n \\leq x} \\frac{1}{n})^2} \\sum_{n,m \\in A: n < m \\leq x} \\frac{1}{\\mathrm{lcm}(n,m)}")]]

#text("also goes to infinity as ")#mi("{x \\rightarrow \\infty}")#text("?")
]

#text("At first glance, this problem may seem rather arbitrary, but it can be motivated as follows. The hypothesis that ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(1)")]#text(" goes to infinity is a largeness condition on ")#mi("{A}")#text("; in view of ")#link("https://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(", it can be viewed as an assertion that ")#mi("{A}")#text(" is denser than the set of primes. On the other hand, the conclusion that ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" grows is an assertion that ")#mi("{\\frac{1}{\\mathrm{lcm}(n,m)}}")#text(" becomes significantly larger than ")#mi("{\\frac{1}{nm}}")#text(" on the average for large ")#mi("{n,m \\in A}")#text("; that is to say, that many pairs of numbers in ")#mi("{A}")#text(" share a common factor. Intuitively, the problem is then asking whether sets that are significantly denser than the primes must start having lots of common factors on average.")

#text("For sake of comparison, it is easy to see that if ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(1)")]#text(" goes to infinity, then at least ")#emph[#text("one")]#text(" pair ")#mi("{(n,m)}")#text(" of distinct elements in ")#mi("{A}")#text(" must have a non-trivial common factor. For if this were not the case, then the elements of ")#mi("{A}")#text(" are pairwise coprime, so each prime ")#mi("{p}")#text(" has at most one multiple in ")#mi("{A}")#text(", and so can contribute at most ")#mi("{1/p}")#text(" to the sum in ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(1)")]#text(", and hence by Mertens’ theorem, and the fact that every natural number greater than one is divisible by at least one prime ")#mi("{p}")#text(", the quantity ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(1)")]#text(" stays bounded, a contradiction.")

#text("It turns out, though, that the answer to the above problem is negative; one can find sets ")#mi("{A}")#text(" that are denser than the primes, but for which ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" stays bounded, so that the least common multiples in the set are unusually large. It was a bit surprising to me that this question had not been resolved long ago (in fact, I was not able to find any prior literature on the problem beyond the original reference of Erdős and Graham); in contrast, ")#link("https://www.erdosproblems.com/441")[#text("another problem of Erdős and Graham")]#text(" concerning sets with unusually ")#emph[#text("small")]#text(" least common multiples was extensively studied (and essentially solved) about twenty years ago, while the study of sets with unusually large ")#emph[#text("greatest common divisor")]#text(" for many pairs in the set has recently become somewhat popular, due to their role in the ")#link("https://en.wikipedia.org/wiki/Duffin%E2%80%93Schaeffer_theorem")[#text("proof of the Duffin-Schaeffer conjecture")]#text(" by Koukoulopoulos and Maynard.")

#text("To search for counterexamples, it is natural to look for numbers with relatively few prime factors, in order to reduce their common factors and increase their least common multiple. A particularly simple example, whose verification is on the level of an exercise in a graduate analytic number theory course, is the set of ")#link("https://en.wikipedia.org/wiki/Semiprime")[#text("semiprimes")]#text(" (products of two primes), for which one can readily verify that ")#link(<tao-3d9fc4bde7ceef058d65>)[#text("(1)")]#text(" grows like ")#mi("{\\log\\log x}")#text(" but ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" stays bounded. With a bit more effort, I was able to optimize the construction and uncover the true threshold for boundedness of ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(", which was a little unexpected:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]

#list(
[#text("(i) For any ")#mi("{C>0}")#text(", there exists a set of natural numbers ")#mi("{A}")#text(" with")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A: n \\leq x} \\frac{1}{n} = \\exp( (C+o(1)) (\\log\\log x)^{1/2} \\log\\log\\log x )")]]

#text("for all large ")#mi("{x}")#text(", for which ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" stays bounded.")],
[#text("(ii) Conversely, if ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" stays bounded, then")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A: n \\leq x} \\frac{1}{n} \\ll \\exp( O( (\\log\\log x)^{1/2} \\log\\log\\log x ) )")]]

#text("for all large ")#mi("{x}")#text(".")]
)
]

#text("The proofs are not particularly long or deep, but I thought I would record here some of the process towards finding them. My first step was to try to simplify the condition that ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" stays bounded. In order to use probabilistic intuition, I first expressed this condition in probabilistic terms as")

#align(center)[#tao-fit-display[#mitex("\\mathbb{E} \\frac{\\mathbf{n} \\mathbf{m}}{\\mathrm{lcm}(\\mathbf{n}, \\mathbf{m})} \\ll 1")]]

#text("for large ")#mi("{x}")#text(", where ")#mi("{\\mathbf{n}, \\mathbf{m}}")#text(" are independent random variables drawn from ")#mi("{\\{ n \\in A: n \\leq x \\}}")#text(" with probability density function")

#align(center)[#tao-fit-display[#mitex("\\mathbb{P} (\\mathbf{n} = n) = \\frac{1}{\\sum_{m \\in A: m \\leq x} \\frac{1}{m}} \\frac{1}{n}.")]]

#text("The presence of the least common multiple in the denominator is annoying, but one can easily flip the expression to the greatest common divisor:")

#align(center)[#tao-fit-display[#mitex("\\mathbb{E} \\mathrm{gcd}(\\mathbf{n}, \\mathbf{m}) \\ll 1.")]]

#text("If the expression ")#mi("{\\mathrm{gcd}(\\mathbf{n}, \\mathbf{m})}")#text(" was a product of a function of ")#mi("{\\mathbf{n}}")#text(" and a function of ")#mi("{\\mathbf{m}}")#text(", then by independence this expectation would decouple into simpler averages involving just one random variable instead of two. Of course, the greatest common divisor is not of this form, but there is a standard trick in analytic number theory to decouple the greatest common divisor, namely to use the classic Gauss identity ")#mi("{n = \\sum_{d|n} \\varphi(d)}")#text(", with ")#mi("{\\varphi}")#text(" the ")#link("https://en.wikipedia.org/wiki/Euler%27s_totient_function")[#text("Euler totient function")]#text(", to write")

#align(center)[#tao-fit-display[#mitex("\\mathrm{gcd}(\\mathbf{n}, \\mathbf{m}) = \\sum_{d | \\mathbf{n}, \\mathbf{m}} \\varphi(d).")]]

#text("Inserting this formula and interchanging the sum and expectation, we can now express the condition as bounding a sum of squares:")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\varphi(d) \\mathbb{P}(d|\\mathbf{n})^2 \\ll 1.")]]

#text("Thus, the condition ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" is really an assertion to the effect that typical elements of ")#mi("{A}")#text(" do not have many divisors. From experience in sieve theory, the probabilities ")#mi("{\\mathbb{P}(d|\\mathbf{n})}")#text(" tend to behave multiplicatively in ")#mi("{d}")#text(", so the expression here heuristically behaves like an Euler product that looks something like")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1 + \\varphi(p) \\mathbb{P}(p|\\mathbf{n})^2)")]]

#text("and so the condition ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" is morally something like")

#metadata(none) <tao-6ee2cc105a67743140cf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_p p \\mathbb{P}(p|\\mathbf{n})^2 \\ll 1.")]]

#text("Comparing this with the Mertens’ theorems, this leads to the heuristic prediction that ")#mi("{\\mathbb{P}(p|\\mathbf{n})}")#text(" (for a typical prie ")#mi("{p}")#text(" much smaller than ")#mi("{x}")#text(") should decay somewhat like ")#mi("{\\frac{1}{p (\\log\\log p)^{1/2}}}")#text(" (ignoring for now factors of ")#mi("{\\log\\log\\log p}")#text("). This can be compared to the example of the set of primes or semiprimes on one hand, where the probability is like ")#mi("{\\frac{1}{p \\log\\log p}}")#text(", and the set of all natural numbers on the other hand, where the probability is like ")#mi("{\\frac{1}{p}}")#text(". So the critical behavior should come from sets that are in some sense “halfway” between the primes and the natural numbers.")

#text("It is then natural to try a random construction, in which one sieves out the natural numbers by permitting each natural number ")#mi("{n}")#text(" to survive with a probability resembling ")#mi("{\\prod_{p|n} \\frac{1}{(\\log\\log p)^{1/2}}}")#text(", in order to get the predicted behavior for ")#mi("{\\mathbb{P}(p|\\mathbf{n})}")#text(". Performing some standard calculations, this construction could ensure ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" bounded with a density a little bit less than the one stated in the main theorem; after optimizing the parameters, I could only get something like")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in A: n \\leq x} \\frac{1}{n} = \\exp( (\\log\\log x)^{1/2} (\\log\\log\\log x)^{-1/2-o(1)} ).")]]

#text("I was stuck on optimising the construction further, so I turned my attention to a positive result in the spirit of (ii) of the main theorem. On playing around with ")#link(<tao-6ee2cc105a67743140cf>)[#text("(3)")]#text(", I observed that one could use Cauchy-Schwarz and Mertens’ theorem to obtain the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x} \\mathbb{P}(p|\\mathbf{n}) \\ll (\\log\\log x)^{1/2}")]]

#text("which was in line with the previous heuristic that ")#mi("{\\mathbb{P}(p|\\mathbf{n})}")#text(" should behave like ")#mi("{\\frac{1}{p (\\log\\log p)^{1/2}}}")#text(". The left-hand side had a simple interpretation: by linearity of expectation, it was the expected number ")#mi("{\\mathbb{E} \\omega(\\mathbf{n})}")#text(" of prime factors of ")#mi("{\\mathbf{n}}")#text(". So the boundedness of ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" implied that a typical element of ")#mi("{A}")#text(" only had about ")#mi("{(\\log\\log x)^{1/2}}")#text(" prime factors, in contrast to the ")#mi("{\\log\\log x}")#text(" predicted by the ")#link("https://en.wikipedia.org/wiki/Hardy%E2%80%93Ramanujan_theorem")[#text("Hardy-Ramanujan law")]#text(". Standard methods from the anatomy of integers can then be used to see how dense a set with that many prime factors could be, and this soon led to a short proof of part (ii) of the main theorem (I eventually found for instance that Jensen’s inequality could be used to create a particularly slick argument).")

#text("It then remained to improve the lower bound construction to eliminate the ")#mi("{\\log\\log\\log x}")#text(" losses in the exponents. By deconstructing the proof of the upper bound, it became natural to consider something like the set of natural numbers ")#mi("{n}")#text(" that had at most ")#mi("{(\\log\\log n)^{1/2}}")#text(" prime factors. This construction actually worked for some scales ")#mi("{x}")#text(" – namely those ")#mi("{x}")#text(" for which ")#mi("{(\\log\\log x)^{1/2}}")#text(" was a natural number – but there was some strange “discontinuities” in the analysis that prevented me from establishing the boundedness of ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" for arbitrary scales ")#mi("{x}")#text(". The basic problem was that increasing the number of permitted prime factors from one natural number threshold ")#mi("{k}")#text(" to another ")#mi("{k+1}")#text(" ended up increasing the density of the set by an unbounded factor (of the order of ")#mi("{k}")#text(", in practice), which heavily disrupted the task of trying to keep the ratio ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" bounded. Usually the resolution to these sorts of discontinuities is to use some sort of random “average” of two or more deterministic constructions – for instance, by taking some random union of some numbers with ")#mi("{k}")#text(" prime factors and some numbers with ")#mi("{k+1}")#text(" prime factors – but the numerology turned out to be somewhat unfavorable, allowing for some improvement in the lower bounds over my previous construction, but not enough to close the gap entirely. It was only after substantial trial and error that I was able to find a working ")#emph[#text("deterministic")]#text(" construction, where at a given scale one collected either numbers with at most ")#mi("{k}")#text(" prime factors, or numbers with ")#mi("{k+1}")#text(" prime factors but with the largest prime factor in a specific range, in which I could finally get the numerator and denominator in ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" to be in balance for every ")#mi("{x}")#text(". But once the construction was written down, the verification of the required properties ended up being quite routine.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("Missing paper tag.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("I found confusing the following sentence in the abstract:")

#text("“The exponent 1/2 can replaced by any other positive constant”")

#text("You are referring to the multiplicative constant 1/2 and not the power of the loglog term (which is 1/2). Maybe you could make this more clear.")

#emph[#text("[This will be clarified in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685340")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("the link to the Euler totient function is not formatted properly here.")

#text("a bit later eqref is not used correctly")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91b54c55bd8655bd9015b580cd89c92f2063f99412d57d1410b4677fb19b8a86-56f32ecae7101c74ce2e38c429ea5a035aee7bb11bc0b949f116d0b263ac91a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685342")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2024")])]

#text("“On the other hand, the conclusion that ")#link(<tao-3fe3cde54dc9f3f924c3>)[#text("(2)")]#text(" grows is an assertion that")

#link("https://s0.wp.com/latex.php?latex=%7B%5Cfrac%7B1%7D%7B%5Cmathrm%7Blcm%7D%28n%2Cm%29%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7B%5Cfrac%7B1%7D%7B%5Cmathrm%7Blcm%7D%28n%2Cm%29%7D%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("becomes significantly smaller”")

#text("Should it be “significantly ")#emph[#text("larger")]#text("“?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685344")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2024")])]

#text("The expression (2) is very similar to something used in a paper of Bergelson and Richter on dynamical analogues of the PNT (it appears as the RHS of (2.4) in ")#link("https://arxiv.org/pdf/2002.03498")[#text("this paper")]#text("). Essentially if (2) is not only bounded but gets arbitrarily close to 1, then the set A can replace the primes in the Turan-Kubilius inequality. ")#linebreak()#text("I wonder if your methods can also place similar restrictions of the density of such a set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685348")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2024")])]

#text("Huh, that RHS of (2.4) is almost *exactly* the quantity studied in my paper! In particular, the authors, in their discussion after (2.4), already negatively answered the question of Erdos and Graham, without being aware of it, using basically the same counterexample I mentioned in my blog post. I’ll certainly update the paper to reflect this.")

#text("I did some calculations with what my method gives. If one assumes that the RHS of (2.4) is at most ")#mi("\\varepsilon^2")#text(" for some fixed ")#mi("\\varepsilon>0")#text(", then my upper bound arguments show that ")#mi("\\sum_{n \\in B: n \\leq x} \\frac{1}{n} \\ll \\exp( (1+o(1)) \\varepsilon (\\log\\log x)^{1/2} (\\log\\log\\log x) )")#text(". Conversely, my lower bound construction gives a set with ")#mi("\\sum_{n \\in B: n \\leq x} \\frac{1}{n} \\asymp \\exp( (1+o(1)) \\varepsilon (\\log\\log x)^{1/2} (\\log\\log\\log x) )")#text(" for which the RHS of (2.4) is indeed ")#mi("O(\\varepsilon^2)")#text(", so there is actually a nice tight relationship in this regime. (The primes correspond to the situation where ")#mi("\\varepsilon \\sim 1 / (\\log\\log x)^{1/2}")#text(", and more generally the set of products of ")#mi("k")#text(" primes to the situation where ")#mi("\\varepsilon \\sim k / (\\log\\log x)^{1/2}")#text(".) Again, I will update the paper accordingly – thanks for pointing out the connection!")

#text("[As an aside – I had thought this to be a somewhat inconsequential problem to work on, but once again I see that Paul Erdos had the uncanny knack of asking questions that touch on problems naturally arising in various areas of mathematics – in this case, ergodic theory.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6172cb67f2866d1a9c75bcd4b937ee0f29937b1a9436b3bbd3bec3383798a71-7a7d636c9329b1dad6a7c1660f8dcf5d0a6703a4a72ee7c15f92b2ba9470b1f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon Amit")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685371")[#strong[#text("Alon Amit")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2024")])]

#text("(Small typo: Erdős rather than Erdös).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43f52aa77295050335c7966ccc336777ba01cbeeb09d4dc6b2277995d0c1116e-41302a5895202f13f12503bbc7876c07f78ecc150ed85ae5e5813f55ba554208.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabrice Imparato")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685381")[#strong[#text("Fabrice Imparato")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2024")])]

#strong[#text("Lemma 2.1")]#text(" (page 7) shall we say that the probability of the event log 𝐩1+…log 𝐩k ≥ log 𝑥 is at most 𝑂(𝑐) based on Markov’s Inequality instead of log 𝐩1+…log 𝐩k ≤ log 𝑥")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685382")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I was stuck on optimising the construction further")
]

#text("Well, “being stuck on someone” seems to be an idiom with other meaning than what you seem to mean.")

#text("T.N.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685384")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2024")])]

#text("Note that the game is not for fools.")

#text("T.D. Nguyen")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2024")])]

#text("Is there a similar result for typical order of lcm ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2024")])]

#text("For typical natural numbers ")#mi("n, m")#text(" (say drawn uniformly from ")#mi("1")#text(" to ")#mi("x")#text(" for a large ")#mi("x")#text("), the limiting distribution of ")#mi("\\mathrm{gcd}(n,m)")#text(" is easily seen to be a ")#link("https://en.wikipedia.org/wiki/Zeta_distribution")[#text("zeta distribution")]#text(" with parameter ")#mi("2")#text(", so in particular is going to be bounded most of the time. The least common multiple is then going to be comparable to ")#mi("n,m")#text(". By sieving out small primes one can then create sets of density ")#mi("\\varepsilon")#text(" where the gcd is equal to ")#mi("1")#text(" with probability something like ")#mi("1 - O(\\exp(-1/\\varepsilon))")#text(", if I did my Mertens theorem calculations correctly. So the normal order for gcd has a different threshold than the average order (this has to do with the fact that the zeta distribution of parameter 2 has infinite mean).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/08/dense-sets-of-natural-numbers-with-unusually-large-least-common-multiples/#comment-685421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2024")])]

#text("Note that a medal may be empty of mathematics.")

#text("Besides, his age is about 2.5 people among you add up. Ultimately stupid.")

#text("T.D. Nguyen")
]
