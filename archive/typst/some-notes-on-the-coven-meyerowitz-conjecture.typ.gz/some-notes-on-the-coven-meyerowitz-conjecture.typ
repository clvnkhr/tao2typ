// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T09:20:49.144918+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on the Coven-Meyerowitz conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on the Coven-Meyerowitz conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/")[#text("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{G = (G,+)}")#text(" be a finite additive group. A ")#emph[#text("tiling pair")]#text(" is a pair of non-empty subsets ")#mi("{A, B}")#text(" such that every element of ")#mi("{G}")#text(" can be written in exactly one way as a sum of an element ")#mi("{a}")#text(" of ")#mi("{A}")#text(" and an element ")#mi("{b}")#text(" of ")#mi("{B}")#text(", in which case we write ")#mi("{G = A \\oplus B}")#text(". The sets ")#mi("{A, B}")#text(" are then called ")#emph[#text("tiles")]#text(", with ")#mi("{B}")#text(" being a ")#emph[#text("complementary tile")]#text(" to ")#mi("{A}")#text(" and vice versa. For instance, every subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" is a tile, as one can pick one representative from each coset of ")#mi("{H}")#text(" to form the complementary tile. Conversely, any set formed by taking one representative from each coset of ")#mi("{H}")#text(" is also a tile.")

#text("Tiles can be quite complicated, particularly when the group ")#mi("{G}")#text(" is “high-dimensional”. We will therefore restrict to the simple case of a cyclic group ")#mi("{G = {\\bf Z}/N{\\bf Z}}")#text(", and restrict even further to the special case when the modulus ")#mi("{N}")#text(" is ")#link("http://en.wikipedia.org/wiki/Square-free_integer")[#text("square-free")]#text(". Here, the situation should be much simpler. In particular, we have the following ")#link("http://www.ams.org/mathscinet-getitem?mr=1670646")[#text("conjecture of Coven and Meyerowitz")]#text(", which asserts that the previous construction of a tile is, in fact, the only such construction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Coven-Meyerowitz conjecture, square-free case)")]#text(" ")#metadata(none) <tao-b2070c1547e95f9f45e8>#text(" Let ")#mi("{N}")#text(" be square-free, and let ")#mi("{A}")#text(" be a tile of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". Then there exists a subgroup ")#mi("{H}")#text(" of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" such that ")#mi("{A}")#text(" consists of a single representative from each coset of ")#mi("{H}")#text(".")
]

#text("Note that in the square-free case, every subgroup ")#mi("{H}")#text(" of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" has a complementary subgroup ")#mi("{H^\\perp}")#text(" (thus ")#mi("{{\\bf Z}/N{\\bf Z} = H \\oplus H^\\perp}")#text("). In particular, ")#mi("{H}")#text(" consists of a single representative from each coset of ")#mi("{H^\\perp}")#text(", and so the examples of subgroups of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" are covered by the above conjecture in the square-free case.")

#text("In the non-square free case, the above assertion is not true; for instance, if ")#mi("{p}")#text(" is a prime, then the multiples of ")#mi("{p}")#text(" in ")#mi("{{\\bf Z}/p^2{\\bf Z}}")#text(" are a tile, but cannot be formed from taking a single representative from all the cosets of a given subgroup. There is a more general conjecture of Coven and Meyerowitz to handle this more general case, although it is more difficult to state:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Coven-Meyerowitz conjecture, general case)")]#text(" ")#metadata(none) <tao-312f08035f2bbe685cb7>#text(" Let ")#mi("{N}")#text(" be a natural number, and let ")#mi("{A}")#text(" be a tile of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". Then there exists a set ")#mi("{S_A}")#text(" of prime powers with ")#tao-math("{\\left|A\\right| = \\prod_{p^j \\in S_A} p}", block: false)#text(" such that the Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat 1_A(k) := \\sum_{n \\in A} e^{2\\pi i kn / N}")]]

#text("vanishes whenever ")#mi("{k}")#text(" is a non-zero element of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" whose order is the product of elements of ")#mi("{S_A}")#text(" that are powers of distinct primes. Equivalently, the generating polynomial ")#mi("{\\sum_{n \\in A} x^n}")#text(" is divisible by the ")#link("http://en.wikipedia.org/wiki/Cyclotomic_polynomial")[#text("cyclotomic polynomials")]#text(" ")#mi("{\\phi_m}")#text(" whenever ")#mi("{m}")#text(" is the product of elements of ")#mi("{S_A}")#text(" that are powers of distinct primes.")
]

#text("It can be shown (with a modest amount of effort) that Conjecture ")#link(<tao-312f08035f2bbe685cb7>)[#text("2")]#text(" implies Conjecture ")#link(<tao-b2070c1547e95f9f45e8>)[#text("1")]#text(", but we will not do so here, focusing instead exclusively on the square-free case for simplicity.")

#text("It was observed ")#link("http://www.ams.org/mathscinet-getitem?mr=1895739")[#text("by Laba")]#text(" that Conjecture ")#link(<tao-312f08035f2bbe685cb7>)[#text("2")]#text(" is connected to the following well-known conjecture of Fuglede:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3 (One-dimensional Fuglede conjecture, tiling to spectral direction)")]#text(" ")#metadata(none) <tao-d4f02eaafd1a9e9de7d1>#text(" Let ")#mi("{E}")#text(" be a compact subset of ")#mi("{{\\bf R}}")#text(" of positive measure which is a tile (thus ")#mi("{{\\bf R} = E \\oplus \\Lambda}")#text(" for some set ")#mi("{\\Lambda \\subset {\\bf R}}")#text("). Then ")#mi("{L^2(E)}")#text(" (with Lebesgue measure) has a spectrum, that is to say a complete orthogonal set of plane waves ")#mi("{x \\mapsto e^{2\\pi i \\xi x}}")#text(".")
]

#text("Indeed, it was shown by Laba that Conjecture ")#link(<tao-312f08035f2bbe685cb7>)[#text("2")]#text(" implies Conjecture ")#link(<tao-d4f02eaafd1a9e9de7d1>)[#text("3")]#text(" in the case when ")#mi("{E}")#text(" is the finite union of unit intervals. Actually, thanks to the ")#link("http://www.ams.org/mathscinet-getitem?mr=2267631")[#text("more recent work of Farkas, Matolcsi, and Mora")]#text(" we know that Conjecture ")#link(<tao-312f08035f2bbe685cb7>)[#text("2")]#text(" in fact implies the universal spectrum conjecture ")#link("http://www.ams.org/mathscinet-getitem?mr=1442160")[#text("of Lagarias and Wang")]#text(", which in turn was known to imply Conjecture ")#link(<tao-d4f02eaafd1a9e9de7d1>)[#text("3")]#text(" in full generality. (On the other hand, the conjecture fails in four and higher dimensions; see the papers ")#link("http://www.ams.org/mathscinet-getitem?mr=2237932")[#text("of Kolountzakis-Matolcsi")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2221543")[#text("of Farkas-Revesz")]#text(".)")

#text("Given the simple statement of Conjecture ")#link(<tao-b2070c1547e95f9f45e8>)[#text("1")]#text(", it is perhaps somewhat surprising that it remains open, even in simple cases such as when ")#mi("{N}")#text(" is the product of just four primes. One reason for this is that some plausible strengthenings of this conjecture (such as the Tijdeman-Sands conjecture) are known to be false, as we will review below. On the other hand, as we shall see, tiling sets have a lot of combinatorial structure, and in principle one should be able to work out a lot of special cases of the conjecture. Given the combinatorial nature of this problem, it may well be quite suitable for a polymath project in fact, if there is sufficient interest.")

#metadata(none) <tao-6ab7702b44f8d41239da>

#heading(level: 1)[#strong[#text(" — 1. Some facts about tiling pairs — ")]]

#text("Let ")#mi("{A \\oplus B = {\\bf Z}/N{\\bf Z}}")#text(" be a tiling pair for a cyclic group ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" of cyclic order. In this section we collect some well-known facts about such pairs, which can be found for instance in the previously cited ")#link("http://www.ams.org/mathscinet-getitem?mr=1670646")[#text("paper of Coven and Meyerowitz")]#text(".")

#text("The first fact is an obvious cardinality identity: ")#metadata(none) <tao-2236c2b643aa657e67e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|A\\right| \\left|B\\right| = N.", block: true)]]

#text("In particular, ")#tao-math("{\\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|B\\right|}", block: false)#text(" are divisors of ")#mi("{N}")#text(", and thus are products of disjoint sets of prime factors of ")#mi("{N}")#text(".")

#text("The next fact is a physical space separation proeprty ")#metadata(none) <tao-42a79594de3760a75d3f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(A-A) \\cap (B-B) = \\{0\\}.")]]

#text("Indeed, if there is a collision ")#mi("{a-a^{\\prime}=b-b^{\\prime}}")#text(" between a non-zero difference ")#mi("{a-a^{\\prime}}")#text(" of elements of ")#mi("{A}")#text(", and a difference ")#mi("{b-b^{\\prime}}")#text(" of elements of ")#mi("{B}")#text(", then one also has a collision ")#mi("{a+b^{\\prime}=a^{\\prime}+b}")#text(" in the sumset ")#mi("{A+B}")#text(", so that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" is no longer a tiling pair.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-4968d0cf3b24d26d1d37>#text(" If ")#mi("{A}")#text(" is a subgroup ")#mi("{H}")#text(", and ")#mi("{B}")#text(" is formed by taking a single representative from each coset of ")#mi("{H}")#text(", then ")#mi("{A-A}")#text(" is equal to ")#mi("{H}")#text(", while ")#mi("{B-B}")#text(" can take arbitrary values in ")#mi("{({\\bf Z}/N{\\bf Z} \\backslash H) \\cup \\{0\\}}")#text(".")
]

#text("In the converse direction, if two non-empty subsets ")#mi("{A, B}")#text(" of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" obey both ")#link(<tao-2236c2b643aa657e67e1>)[#text("(1)")]#text(" and ")#link(<tao-42a79594de3760a75d3f>)[#text("(2)")]#text(", then they must be a tiling pair, since the sums in ")#mi("{A+B}")#text(" are disjoint and have the same cardinality as ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(".")

#text("Now we use Fourier analysis to get more structural information. Observe that the relationship ")#mi("{A \\oplus B = {\\bf Z}/N{\\bf Z}}")#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("1_A * 1_B = 1")]]

#text("and hence (by taking Fourier transforms) as")

#align(center)[#tao-fit-display[#mitex("\\hat 1_A(k) \\hat 1_B(k) = N 1_{k=0}.")]]

#text("Note that the ")#mi("{k=0}")#text(" case of this identity is again ")#link(<tao-2236c2b643aa657e67e1>)[#text("(1)")]#text(". The remaining cases of this identity can be reformulated equivalently as a frequency space separation property ")#metadata(none) <tao-bd1505eba5af8be0aed5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\text{supp}(\\hat 1_A) \\cap \\text{supp}(\\hat 1_B) = \\{0\\}")]]

#text("where ")#mi("{\\text{supp}(\\hat 1_A) := \\{ k \\in {\\bf Z}/N{\\bf Z}: \\hat 1_A(k) \\neq 0 \\}}")#text(" is the support of ")#mi("{\\hat 1_A}")#text(". Conversely, if ")#mi("{A, B}")#text(" obey both ")#link(<tao-bd1505eba5af8be0aed5>)[#text("(3)")]#text(" and ")#link(<tao-2236c2b643aa657e67e1>)[#text("(1)")]#text(", then the above argument shows that ")#mi("{A \\oplus B = {\\bf Z}/N{\\bf Z}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Continuing Example ")#link(<tao-4968d0cf3b24d26d1d37>)[#text("1")]#text(", ")#mi("{\\hat 1_A}")#text(" is supported on ")#mi("{H^\\perp}")#text(", while ")#mi("{\\hat 1_B}")#text(" vanishes on ")#mi("{H^\\perp \\backslash \\{0\\}}")#text(".")
]

#text("Now we use some basic Galois theory to obtain an important structural control on the Fourier supports. Let us call two elements ")#mi("{a, b}")#text(" of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" ")#emph[#text("equivalent")]#text(" if one has ")#mi("{a=mb}")#text(" for some ")#mi("{m}")#text(" coprime to ")#mi("{N}")#text(" (or equivalently, if ")#mi("{(a,N) = (b,N)}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-1a5751be8a96e5976c3a>#text(" ")#mi("{\\text{supp}(\\hat 1_A)}")#text(" and ")#mi("{\\text{supp}(\\hat 1_B)}")#text(" are unions of equivalence classes, with ")#mi("{\\{0\\}}")#text(" being the only equivalence class in common.")
]

#emph[#text("Proof:")]#text(" By ")#link(<tao-bd1505eba5af8be0aed5>)[#text("(3)")]#text(" and symmetry, it suffices to show that ")#mi("{\\text{supp}(1_A)}")#text(" is the union of equivalence classes. In other words, if ")#mi("{k \\in {\\bf Z}/N{\\bf Z}}")#text(" and ")#mi("{m}")#text(" is coprime to ")#mi("{N}")#text(", it suffices to show that ")#mi("{\\hat 1_A(k)=0}")#text(" if and only if ")#mi("{\\hat 1_A(km)=0}")#text(". But observe that ")#mi("{\\hat 1_A(k) = \\sum_{a \\in A} \\omega^{ka}}")#text(" is an integer polynomial in the ")#mi("{N^{th}}")#text(" root of unity ")#mi("{\\omega := e^{2\\pi i/N}}")#text(", and ")#mi("{\\hat 1_{A}(ma)}")#text(" is the same polynomial but with ")#mi("{\\omega}")#text(" replaced by another primitive ")#mi("{N^{th}}")#text(" root ")#mi("{\\omega^m}")#text(" of unity. But from the Galois theory of the cyclotomic field ")#mi("{{\\bf Q}(\\omega)}")#text(", we know that there is a field automorphism that maps ")#mi("{\\omega}")#text(" to ")#mi("{\\omega^m}")#text(", and so ")#mi("{\\hat 1_B(k)}")#text(" is non-zero precisely when ")#mi("{\\hat 1_{A}(ma)}")#text(" is non-zero, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can also obtain the above lemma from the theory of ")#link("http://en.wikipedia.org/wiki/Cyclotomic_polynomial")[#text("cyclotomic polynomials")]#text(" and unique factorisation, noting that the product of the generating polynomials ")#mi("{\\sum_{n \\in A} z^n}")#text(" and ")#mi("{\\sum_{n \\in B} z^n}")#text(" form a multiple of ")#mi("{(z^N-1)/(z-1) = \\prod_{k|N} \\Phi_k(z)}")#text(", and that each cyclotomic polynomial ")#mi("{\\Phi_k}")#text(" is irreducible and has zeroes corresponding to a single equivalence class in ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(".")
]

#text("This feature of Fourier supports has an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Dilation invariance)")]#text(" Let ")#mi("{A \\oplus B = {\\bf Z}/N{\\bf Z}}")#text(" for some ")#mi("{N}")#text(". If ")#mi("{m}")#text(" is an integer coprime to ")#mi("{N}")#text(", then ")#mi("{A \\oplus mB = {\\bf Z}/N{\\bf Z}}")#text(", where ")#mi("{mB := \\{mb: b \\in B \\}}")#text(" is the dilation of ")#mi("{B}")#text(" by ")#mi("{m}")#text(".")
]

#emph[#text("Proof:")]#text(" From Lemma ")#link(<tao-1a5751be8a96e5976c3a>)[#text("4")]#text(" one has ")#mi("{\\text{supp}(\\hat 1_B) = \\text{supp}(\\hat 1_{mB})}")#text(". Since tiling is equivalent to the conditions ")#link(<tao-2236c2b643aa657e67e1>)[#text("(1)")]#text(" and ")#link(<tao-bd1505eba5af8be0aed5>)[#text("(3)")]#text(", the claim follows. ")#mi("\\Box")

#text("Applying this dilation invariance to the physical space separation property, we conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6 (Strong physical space separation)")]#text(" ")#metadata(none) <tao-6327fbb39c6b1e9bd8c1>#text(" The sets ")#mi("{(A-A) \\backslash \\{0\\}}")#text(" and ")#mi("{(B-B) \\backslash \\{0\\}}")#text(" lie in disjoint equivalence classes; thus any non-zero equivalence class may contain an element of ")#mi("{A-A}")#text(" or an element of ")#mi("{B-B}")#text(", but not both.")
]

#text("We can rephrase this corollary in the following more combinatorial way, taking advantage of the square-free hypothesis. We factor the square-free integer ")#mi("{N}")#text(" as ")#mi("{N = \\prod_{p \\in P} p}")#text(" for some finite set of primes ")#mi("{P}")#text(". By the Chinese remainder theorem, we may then identify ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" with the Cartesian product ")#mi("{V_P := \\prod_{p \\in P} V_p}")#text(", where ")#mi("{V_p ={\\bf Z}/p{\\bf Z}}")#text(" is the cyclic group of order ")#mi("{p}")#text(" (but we shall downplay the group structure and often view ")#mi("{V_p}")#text(" simply as a set of ")#mi("{p}")#text(" points), which each residue class ")#mi("{a \\text{ mod } N}")#text(" being identified with its quotients ")#mi("{(a \\text{ mod } p)_{p \\in P}}")#text(". Define a ")#emph[#text("diagonal")]#text(" in ")#mi("{V_P}")#text(" to be a pair ")#mi("{(a_p)_{p \\in P}, (b_p)_{p \\in P}}")#text(" such that ")#mi("{a_p \\neq b_p}")#text(" for all ")#mi("{p \\in P}")#text("; we say that a subset of ")#mi("{V_P}")#text(" is ")#emph[#text("diagonal-free")]#text(" if it contains no diagonals. Observe that if ")#mi("{A}")#text(" contains a diagonal ")#mi("{(a_p)_{p \\in P}, (b_p)_{p \\in P}}")#text(", then ")#mi("{(A-A) \\backslash \\{0\\}}")#text(" contains an element ")#mi("{(a_p-b_p)_{p \\in P}}")#text(" with all coefficients non-zero, or equivalently an invertible element of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(". As all invertible elements are equivalent, we conclude from Corollary ")#link(<tao-6327fbb39c6b1e9bd8c1>)[#text("6")]#text(" that at least one of ")#mi("{A, B}")#text(" is diagonal-free. More generally, if ")#mi("{P^{\\prime}}")#text(" is a non-empty subset of ")#mi("{P}")#text(", define a ")#emph[#mi("{P^{\\prime}}")#text("-slice")]#text(" of ")#mi("{A}")#text(" to be a subset of ")#mi("{V_{P^{\\prime}} := \\prod_{p \\in P^{\\prime}} V_p}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (a_p)_{p \\in P^{\\prime}} \\in \\prod_{p \\in P^{\\prime}} V_p: (a_p)_{p \\in P} \\in \\prod_{p \\in P} V_p \\},")]]

#text("where ")#mi("{a_p}")#text(" is a fixed element of ")#mi("{V_p}")#text(" for each ")#mi("{p \\in P \\backslash P^{\\prime}}")#text(". Thus, for instance, if one has three primes ")#mi("{p,q,r}")#text(" in ")#mi("{P}")#text(", then ")#mi("{A}")#text(" is a subset of ")#mi("{V_{\\{p,q,r\\}} := V_p \\times V_q \\times V_r}")#text(", and a ")#mi("{\\{q,r\\}}")#text(" slice would be a set of the form")

#align(center)[#tao-fit-display[#mitex("\\{ (q,r) \\in V_q \\times V_r: (p,q,r) \\in A \\}")]]

#text("for some ")#mi("{p \\in V_p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 7 (Strong physical space separation, combinatorial formulation)")]#text(" ")#metadata(none) <tao-04b5ee99e940cda83328>#text(" Let us view ")#mi("{A, B}")#text(" as subsets of ")#mi("{V_P}")#text(", and let ")#mi("{P^{\\prime}}")#text(" be a non-empty subset of ")#mi("{P}")#text(". Then one of the following statements is true:")

#list(
[#text("All ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{A}")#text(" are diagonal-free.")],
[#text("All ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{B}")#text(" are diagonal-free.")]
)
]

#text("Indeed, a diagonal in a ")#mi("{P^{\\prime}}")#text("-slice of ")#mi("{A}")#text(" would create an element of ")#mi("{A-A \\backslash \\{0\\}}")#text(" in the equivalence class of ")#mi("{P}")#text("-tuples whose support was precisely ")#mi("{P \\backslash P^{\\prime}}")#text(".")

#text("Conversely, we see that any subsets ")#mi("{A, B}")#text(" of ")#mi("{V_P}")#text(" with ")#tao-math("{\\left|A\\right| \\left|B\\right| = \\left|V_P\\right|}", block: false)#text(" obeying the conclusion of Corollary ")#link(<tao-04b5ee99e940cda83328>)[#text("7")]#text(" will necessarily obey ")#link(<tao-42a79594de3760a75d3f>)[#text("(2)")]#text(" and thus be a tiling pair. Thus we see the rather remarkable fact that the property of being a tiling pair is in fact not dependent on the underlying group structure of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", but only on the Cartesian product structure of ")#mi("{V_P}")#text("; for instance, one can arbitrarily apply a permutation (or relabeling) of one of the factors ")#mi("{V_p}")#text(" of ")#mi("{V_P}")#text(" to ")#mi("{A}")#text(" or ")#mi("{B}")#text(" (or both) and still get a tiling pair.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can make the above independence of the underlying group structure even more striking, as follows. For each prime ")#mi("{p}")#text(" in ")#mi("{P}")#text(", let ")#mi("{\\ast_p: V_p \\times V_p \\rightarrow V_p}")#text(" be an arbitrary ")#link("http://en.wikipedia.org/wiki/Quasigroup")[#text("quasigroup")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Latin_square")[#text("latin square")]#text(") operation on ")#mi("{V_p}")#text(", that is to say a binary operation (not assumed to be either commutative or associative) with the property that for each ")#mi("{a \\in V_p}")#text(", the maps ")#mi("{x \\mapsto a \\ast_p x}")#text(" and ")#mi("{x \\mapsto x \\ast_p a}")#text(" are permutations of ")#mi("{V_p}")#text(". (This quasigroup assumption is of course obeyed by the addition law ")#mi("{+}")#text(" on ")#mi("{V_p}")#text(" after identifying ")#mi("{V_p}")#text(" with a cyclic group of order ")#mi("{p}")#text(", but clearly there are also many other quasigroup laws than these.) We can then define a law ")#mi("{\\ast: V_P \\times V_P \\rightarrow V_P}")#text(" in the obvious manner:")

#align(center)[#tao-fit-display[#mitex("(a_p)_{p \\in P} \\ast (b_p)_{p \\in P} := (a_p \\ast_p b_p)_{p \\in P}.")]]

#text("The remarkable thing is then that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" form a tiling pair with respect to the usual addition law ")#mi("{+}")#text(" on ")#mi("{V_P}")#text(" if and only if they form a tiling pair with respect to this more general law ")#mi("{\\ast}")#text(", thanks to Corollary ")#link(<tao-04b5ee99e940cda83328>)[#text("7")]#text(" and its inverse.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-792525db00993809e3a3>#text(" Let us partition ")#mi("{P = P_1 \\cup P_2}")#text(", and let ")#mi("{x_2}")#text(" be an element of ")#mi("{V_{P_2}}")#text(". Then one can create a tiling pair by setting ")#mi("{A = V_{P_1} \\times \\{x_2\\}}")#text(" (identifying ")#mi("{V_P}")#text(" with ")#mi("{V_{P_1} \\times V_{P_2}}")#text(" in the obvious manner), and setting ")#mi("{B}")#text(" to consist of a single representative of each slice ")#mi("{V_{P_1} \\times \\{y_2\\}}")#text(" for each ")#mi("{y_2 \\in V_{P_2}}")#text(". Observe that if ")#mi("{P^{\\prime}}")#text(" is non-empty and contained in ")#mi("{P_1}")#text(", then all ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{B}")#text(" are diagonal-free; but if ")#mi("{P^{\\prime} \\subset P}")#text(" is non-empty and not contained in ")#mi("{P_1}")#text(", then all ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{A}")#text(" are diagonal-free.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" ")#metadata(none) <tao-e9058ab198f6908f7021>#text(" Suppose ")#mi("{P = \\{p_1,p_2,p_3,p_4\\}}")#text(". We consider the sets")

#align(center)[#tao-fit-display[#mitex("A := \\{ (f_1, x_2, f_3(x_2), x_4): x_2 \\in V_{p_2}, x_4 \\in V_{p_4} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B := \\{ (x_1, f_2(x_1), x_3, f_4(x_1,x_3)): x_1 \\in V_{p_1}, x_3 \\in V_{p_3} \\}")]]

#text("where ")#mi("{f_1 \\in V_{p_1}}")#text(" is a constant and ")#mi("{f_2: V_{p_1} \\rightarrow V_{p_2}}")#text(", ")#mi("{f_3: V_{p_2} \\rightarrow V_{p_3}}")#text(", and ")#mi("{f_4: V_{p_1} \\times V_{p_3} \\rightarrow V_{p_4}}")#text(" are arbitrary functions. One easily verifies that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are a tiling pair. If ")#mi("{P^{\\prime}}")#text(" is a non-empty subset of ")#mi("{P}")#text(", one can check that the ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{A}")#text(" are diagonal-free whenever the first element of ")#mi("{P^{\\prime}}")#text(" is either ")#mi("{p_1}")#text(" or ")#mi("{p_3}")#text(", and the ")#mi("{P^{\\prime}}")#text("-slices of ")#mi("{B}")#text(" are diagonal-free whenever the first element of ")#mi("{P^{\\prime}}")#text(" is either ")#mi("{p_2}")#text(" or ")#mi("{p_4}")#text(".")

#text("One can generalise these sorts of examples to more complicated tiling pairs in general products ")#mi("{V_P}")#text(", in which each coordinate is free for one of ")#mi("{A,B}")#text(", and a function of the previous coordinates for the other ")#mi("{A,B}")#text(".")
]

#text("We isolate one particular instance of Corollary ")#link(<tao-04b5ee99e940cda83328>)[#text("7")]#text(": that at least one of ")#mi("{A}")#text(" or ")#mi("{B}")#text(" is a partial graph in any given direction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Graph structure)")]#text(" ")#metadata(none) <tao-eef93e1d14482804277f>#text(" Let ")#mi("{p \\in P}")#text(", and view ")#mi("{V_P}")#text(" as ")#mi("{V_{P \\backslash \\{p\\}} \\times V_p}")#text(". Then at least one of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" is contained in a graph ")#mi("{\\{ (x, f(x)): x \\in V_{P \\backslash \\{p\\}} \\}}")#text(" for some function ")#mi("{f: V_{P \\backslash \\{p\\}} \\rightarrow V_p}")#text(".")
]

#text("Indeed, we know that either one of ")#mi("{A}")#text(" or ")#mi("{B}")#text(" obeys the vertical line test, in the sense that its ")#mi("{V_p}")#text("-slices are diagonal-free (and thus have cardinality at most one).")

#text("Now we convert the Fourier-analytic tiling criterion (Lemma ")#link(<tao-1a5751be8a96e5976c3a>)[#text("4")]#text(") into a combinatorial form. We need a definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9")]#text(" Let ")#mi("{V_P = \\prod_{p \\in P} V_p}")#text(" be a product set. A ")#emph[#text("cube")]#text(" in ")#mi("{V_P}")#text(" is a collection of ")#tao-math("{2^{\\left|P\\right|}}", block: false)#text(" elements of ")#mi("{V_P}")#text(" of the form ")#mi("{(a_p^{i_p})_{p \\in P}}")#text(" for ")#mi("{i_p \\in \\{0,1\\}}")#text(", where for each ")#mi("{p \\in P}")#text(", ")#mi("{a_p^0, a_p^1}")#text(" are elements of ")#mi("{V_p}")#text(". A function ")#mi("{f: V_P \\rightarrow {\\bf R}}")#text(" is said to be ")#emph[#text("balanced")]#text(" if the alternating sum of ")#mi("{f}")#text(" on any cube vanishes, thus ")#metadata(none) <tao-bb9af5d1915da1fbc132>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\sum_{(i_p)_{p \\in P} \\in \\{0,1\\}^P} (-1)^{\\sum_{p \\in P} i_p} f((a_p^{i_p})_{p \\in P}) = 0")]]

#text("whenever ")#mi("{a_p^0, a_p^1 \\in V_p}")#text(" for ")#mi("{p \\in P}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" If ")#mi("{f: V_p \\times V_q \\rightarrow {\\bf R}}")#text(" is a function, then ")#mi("{f}")#text(" is balanced if and only if")

#align(center)[#tao-fit-display[#mitex("f(a,b) - f(a^{\\prime},b) - f(a,b^{\\prime}) + f(a^{\\prime},b^{\\prime})=0")]]

#text("for all ")#mi("{a,a^{\\prime} \\in V_p}")#text(" and ")#mi("{b,b^{\\prime} \\in V_q}")#text(". Equivalently, ")#mi("{f}")#text(" takes the form ")#mi("{f(a,b) = g(a) + h(b)}")#text(" for some functions ")#mi("{g: V_p \\rightarrow {\\bf R}}")#text(" and ")#mi("{h: V_q \\rightarrow {\\bf R}}")#text(".")
]

#text("We have the following equivalent characterisations of balanced functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10")]#text(" Let ")#mi("{V_P = \\prod_{p \\in P} V_p}")#text(" be the product of cyclic groups, and let ")#mi("{f: V_P \\rightarrow {\\bf R}}")#text(" be a function. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{f}")#text(" is balanced.")],
[#text("(ii) ")#mi("{f}")#text(" is the sum of functions which depend on all but one of the coordinates in ")#mi("{V_P}")#text(" (i.e. they factor through ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" for some ")#mi("{p \\in P}")#text(").")],
[#text("(iii) ")#mi("{\\hat f}")#text(" vanishes on the equivalence class ")#mi("{\\{ (k_p)_{p \\in P} \\in V_P : k_p \\neq 0 \\text{ for all } p \\in P \\}}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" It is easy to see that (ii) implies (i) or (iii), and from the Fourier inversion formula we see that (iii) implies (ii). To see that (i) implies (ii), we apply ")#link(<tao-bb9af5d1915da1fbc132>)[#text("(4)")]#text(" with ")#mi("{a_p^0 := 0}")#text(" (say) to rewrite ")#mi("{f((a_p^1)_{p \\in P})}")#text(" in terms of functions that depend on a proper subset of the ")#mi("{a_p^1}")#text(". ")#mi("\\Box")

#text("Combining this with Lemma ")#link(<tao-1a5751be8a96e5976c3a>)[#text("4")]#text(" applied to the equivalence class in the above lemma, we conclude that at least one of ")#mi("{1_A}")#text(" and ")#mi("{1_B}")#text(" is balanced. We can also reach the other equivalence classes by projection. Given a subset ")#mi("{P^{\\prime}}")#text(" of ")#mi("{P}")#text(", let ")#mi("{\\pi_{P^{\\prime}}: V_P \\rightarrow V_{P^{\\prime}}}")#text(" be the projection map, and given a function ")#mi("{f: V_P \\rightarrow {\\bf R}}")#text(", let ")#mi("{(\\pi_{P^{\\prime}})_* f: V_{P^{\\prime}} \\rightarrow {\\bf R}}")#text(" be the pushforward function")

#align(center)[#tao-fit-display[#mitex("(\\pi_{P^{\\prime}})_* f(x^{\\prime}) = \\sum_{x \\in V_P: \\pi_{P^{\\prime}}(x)=x^{\\prime}} f(x).")]]

#text("Note that the Fourier transform of ")#mi("{(\\pi_{P^{\\prime}})_* f}")#text(" is essentially the Fourier transform of ")#mi("{f}")#text(" restricted to ")#mi("{V_P}")#text(". From Lemma ")#link(<tao-1a5751be8a96e5976c3a>)[#text("4")]#text(" we conclude that")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Strong frequency space separation, combinatorial formulation)")]#text(" ")#metadata(none) <tao-e5db289311040d781086>#text(" Let ")#mi("{P^{\\prime}}")#text(" be a non-empty subset of ")#mi("{P}")#text(". Then at least one of ")#mi("{(\\pi_{P^{\\prime}})_* 1_A}")#text(" and ")#mi("{(\\pi_{P^{\\prime}})_* 1_B}")#text(" is balanced.")
]

#text("Conversely, if ")#mi("{A, B \\subset V_P}")#text(" obey the conclusions of ")#link(<tao-e5db289311040d781086>)[#text("(11)")]#text(" and are such that ")#tao-math("{\\left|A\\right| \\left|B\\right| = \\left|V_P\\right|}", block: false)#text(", then ")#mi("{A, B}")#text(" are a tiling pair.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6")]#text(" Continuing Example ")#link(<tao-792525db00993809e3a3>)[#text("3")]#text(", ")#mi("{(\\pi_{P^{\\prime}})_* 1_B}")#text(" is balanced whenever ")#mi("{P^{\\prime}}")#text(" is contained in ")#mi("{P_2}")#text(", and ")#mi("{(\\pi_{P^{\\prime}})_* 1_A}")#text(" is balanced otherwise.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 7")]#text(" Continuing Example ")#link(<tao-e9058ab198f6908f7021>)[#text("4")]#text(", ")#mi("{(\\pi_{P^{\\prime}})_* 1_A}")#text(" is balanced whenever the largest element of ")#mi("{P^{\\prime}}")#text(" is ")#mi("{p_2}")#text(" or ")#mi("{p_4}")#text(", and ")#mi("{(\\pi_{P^{\\prime}})_* 1_B}")#text(" is balanced whenever the largest element of ")#mi("{P^{\\prime}}")#text(" is ")#mi("{p_1}")#text(" or ")#mi("{p_3}")#text(".")
]

#text("A one-dimensional function ")#mi("{f: V_p \\rightarrow {\\bf R}}")#text(" is balanced if and only if it is constant. This leads to the following conclusion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 12")]#text(" Let ")#mi("{p \\in P}")#text(". Then ")#mi("{(\\pi_p)_* 1_A}")#text(" is balanced if and only if ")#mi("{p}")#text(" divides ")#tao-math("{\\left|A\\right|}", block: false)#text(", and similarly for ")#mi("{B}")#text(".")
]

#emph[#text("Proof:")]#text(" If ")#mi("{p}")#text(" does not divide ")#tao-math("{\\left|A\\right|}", block: false)#text(", then ")#mi("{(\\pi_p)_* 1_A}")#text(" cannot be constant (since it takes integer values on ")#mi("{V_p}")#text(" and has a total ")#mi("{\\ell^1}")#text(" norm of ")#tao-math("{\\left|A\\right|}", block: false)#text("), and so is not balanced; by Corollary ")#link(<tao-e5db289311040d781086>)[#text("11")]#text(", this implies that ")#mi("{(\\pi_p)_* 1_B}")#text(" is balanced. Since ")#mi("{p}")#text(" divides exactly one of ")#tao-math("{\\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|B\\right|}", block: false)#text(", the claim follows. ")#mi("\\Box")

#text("This already gives a simple case of the Coven-Meyerowitz conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" ")#metadata(none) <tao-b5039c325d7107d60895>#text(" The square-free Coven-Meyerowitz conjecture is true when ")#tao-math("{\\left|A\\right|}", block: false)#text(" is a prime.")
]

#emph[#text("Proof:")]#text(" Write ")#tao-math("{\\left|A\\right|=p}", block: false)#text(". Then ")#mi("{(\\pi_p)_* 1_A}")#text(" is constant on ")#mi("{V_p}")#text(" and has ")#mi("{\\ell^1}")#text(" norm ")#tao-math("{\\left|A\\right|=p}", block: false)#text(", and is thus equal to ")#mi("{1}")#text(" everywhere. In other words, ")#mi("{A}")#text(" meets every coset of ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" exactly once, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14")]#text(" The square-free Coven-Meyerowitz conjecture is true when ")#mi("{N}")#text(" is the product of at most two primes.")
]

#emph[#text("Proof:")]#text(" The claim is trivial when ")#tao-math("{\\left|A\\right|=1}", block: false)#text(" or ")#tao-math("{\\left|A\\right|=N}", block: false)#text(", and the only remaining case is covered by Proposition ")#link(<tao-b5039c325d7107d60895>)[#text("13")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The paper of Coven-Meyerowitz in fact establishes the general (not necessarily square-free) conjecture when ")#mi("{N}")#text(" has at most two distinct prime factors.")
]

#heading(level: 1)[#strong[#text(" — 2. The codimension one case — ")]]

#text("Now we give a slightly more difficult case of the conjecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 15")]#text(" ")#metadata(none) <tao-0a2f133eb9f7ca028a20>#text(" The square-free Coven-Meyerowitz conjecture is true when ")#tao-math("{N/\\left|A\\right|}", block: false)#text(" is a prime.")
]

#text("We now prove this proposition. We induct on ")#mi("{N}")#text(", assuming the claim has been proven for smaller ")#mi("{N}")#text(".")

#text("Write ")#tao-math("{N/\\left|A\\right|=p}", block: false)#text(", and let ")#mi("{B}")#text(" be a tiling complement of ")#mi("{A}")#text(", thus ")#tao-math("{\\left|B\\right|=p}", block: false)#text(". As in the proof of Proposition ")#link(<tao-b5039c325d7107d60895>)[#text("13")]#text(", ")#mi("{B}")#text(" meets each coset of ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" exactly once, thus ")#mi("{B}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("B = \\{ ( b, f(b) ): b \\in V_p \\}")]]

#text("where ")#mi("{f: V_p \\rightarrow V_{P \\backslash \\{p\\}}}")#text(" is a function.")

#text("Suppose first that ")#mi("{B}")#text(" takes values in a proper coset of ")#mi("{V_P}")#text(" (or equivalently, that ")#mi("{f}")#text(" takes values in a proper coset of ")#mi("{V_{P \\backslash\\{p\\}}}")#text("). Thus ")#mi("{B}")#text(" takes values in a translate of ")#mi("{V_{P^{\\prime}}}")#text(" for some ")#mi("{P^{\\prime} \\subsetneq P}")#text(" containing ")#mi("{p}")#text(". Then every ")#mi("{P \\backslash P^{\\prime}}")#text("-slice of ")#mi("{A}")#text(" is essentially a tiling complement of ")#mi("{B}")#text(" in ")#mi("{V_{P^{\\prime}}}")#text(", which among other things implies that ")#tao-math("{\\left|B\\right|}", block: false)#text(" is the product of some primes ")#mi("{P^{\\prime\\prime}}")#text(" in ")#mi("{P^{\\prime}}")#text(", and each slice of ")#mi("{A}")#text(" then has cardinality ")#tao-math("{\\left|V_{P^{\\prime} \\backslash P^{\\prime\\prime}}\\right|}", block: false)#text(". By the inductive hypothesis, each such slice of ")#mi("{A}")#text(" must then consist of one representative from each coset of ")#mi("{V_{P^{\\prime\\prime}}}")#text(" in ")#mi("{V_{P^{\\prime}}}")#text(" (note that this is the only subgroup of ")#mi("{V_{P^{\\prime}}}")#text(" that would give the correct cardinality for each slice of ")#mi("{A}")#text("). Gluing the slices together we conclude that ")#mi("{A}")#text(" consists of one representative from each coset of ")#mi("{V_{P^{\\prime\\prime}}}")#text(" in ")#mi("{V_P}")#text(" as desired. So we may assume that ")#mi("{B}")#text(" does not take values in a proper coset of ")#mi("{V_P}")#text(", and so ")#mi("{f}")#text(" does not take values in a proper coset of ")#mi("{V_{P \\backslash \\{p\\}}}")#text(". (To put it another way, each component of ")#mi("{f}")#text(" is a non-constant function.)")

#text("Suppose ")#mi("{P}")#text(" contains at least one other element than ")#mi("{p}")#text(". Then ")#mi("{f}")#text(" is non-constant, so can find ")#mi("{b, b^{\\prime} \\in V_p}")#text(" such that ")#mi("{f(b) \\neq f(b^{\\prime})}")#text(". It is then not difficult to see that one can construct a cube which contains ")#mi("{(b,f(b))}")#text(" and no other elements of ")#mi("{B}")#text(" except possibly for ")#mi("{(b^{\\prime},f(b^{\\prime}))}")#text(". Furthermore, the only time ")#mi("{(b^{\\prime},f(b^{\\prime}))}")#text(" cannot be avoided is if ")#mi("{f(b)}")#text(" and ")#mi("{f(b^{\\prime})}")#text(" differ only in the ")#mi("{V_2}")#text(" coordinate. In either case we see that ")#mi("{1_B}")#text(" cannot be balanced. More generally, the same argument shows that ")#mi("{(\\pi_{P^{\\prime}})_* 1_B}")#text(" is not balanced for any ")#mi("{P^{\\prime}}")#text(" containing ")#mi("{p}")#text(" and at least one other element, which by Corollary ")#link(<tao-e5db289311040d781086>)[#text("11")]#text(" implies that ")#mi("{(\\pi_{P^{\\prime}})_* 1_A}")#text(" is balanced for all such ")#mi("{P^{\\prime}}")#text(". In other words, the Fourier transform ")#mi("{\\hat 1_A}")#text(" is supported on ")#mi("{V_p \\times \\{0\\} \\cup \\{0\\} \\times V_{P \\backslash \\{p\\}}}")#text(". By the Fourier inversion formula, this implies a decomposition")

#align(center)[#tao-fit-display[#mitex("1_A( x, y ) = F(x) + G(y)")]]

#text("for some functions ")#mi("{F: V_p \\rightarrow {\\bf R}}")#text(", ")#mi("{G: V_{P \\backslash \\{p\\}} \\rightarrow {\\bf R}}")#text(" and all ")#mi("{x \\in V_p}")#text(", ")#mi("{y \\in V_{P \\backslash \\{p\\}}}")#text(". But as ")#mi("{1_A}")#text(" only takes the values ")#mi("{0}")#text(" or ")#mi("{1}")#text(", we see that at least one of ")#mi("{F}")#text(" or ")#mi("{G}")#text(" is constant, thus ")#mi("{1_A(x,y)}")#text(" is either just a function of ")#mi("{x}")#text(" or a function of ")#mi("{y}")#text(". In the latter case this would imply that ")#tao-math("{\\left|A\\right| = N/p}", block: false)#text(" is a multiple of ")#mi("{p}")#text(", which is absurd since ")#mi("{N}")#text(" is square-free; so ")#mi("{1_A(x,y)}")#text(" must be a function of ")#mi("{x}")#text("; since ")#tao-math("{\\left|A\\right|=N/p}", block: false)#text(", this implies that ")#mi("{A}")#text(" is a coset of ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16")]#text(" The square-free Coven-Meyerowitz conjecture is true when ")#mi("{N}")#text(" is the product of at most three primes.")
]

#heading(level: 1)[#strong[#text(" — 3. Slices — ")]]

#text("There is an interesting property of the slices of a tiling pair ")#mi("{A \\oplus B = V_P}")#text(" which seems like it should be exploitable further. Pick a prime ")#mi("{p}")#text(" in ")#mi("{P}")#text(", and for each ")#mi("{i \\in V_p}")#text(", let ")#mi("{A_i \\subset V_{P \\backslash \\{p\\}}}")#text(" be the slice ")#mi("{A_i := \\{ x \\in V_{P \\backslash \\{p\\}}: (i,x) \\in A \\}}")#text(" of ")#mi("{A}")#text(" (identifying ")#mi("{V_P}")#text(" with ")#mi("{V_p \\times V_{P \\backslash \\{p\\}}}")#text(" in the usual manner). Similarly define ")#mi("{B_j}")#text(" for ")#mi("{j \\in V_p}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 17 (Sums of slices)")]#text(" There exists a partition of ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" into sets ")#mi("{E_i}")#text(" for ")#mi("{i \\in V_p}")#text(" and ")#mi("{F_j}")#text(" for ")#mi("{j \\in V_p}")#text(" such that ")#metadata(none) <tao-e339b46c1a1ec453ef35>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("A_i \\oplus B_j = E_i \\cup F_j")]]

#text("for all ")#mi("{i,j \\in V_p}")#text(".")
]

#emph[#text("Proof:")]#text(" Since all the sums in ")#mi("{A+B}")#text(" are distinct, we see for each ")#mi("{i,j \\in V_p}")#text(" that the sums in ")#mi("{A_i+B_j}")#text(" are also distinct, and so ")#mi("{A_i \\oplus B_j}")#text(" is well-defined. If ")#mi("{i,i^{\\prime}}")#text(" are distinct elements of ")#mi("{V_p}")#text(", and ")#mi("{j,j^{\\prime}}")#text(" are distinct elements of ")#mi("{V_p}")#text(", then from Corollary ")#link(<tao-04b5ee99e940cda83328>)[#text("7")]#text(" we see that ")#mi("{A_i \\oplus B_j}")#text(" and ")#mi("{A_{i^{\\prime}} \\oplus B_{j^{\\prime}}}")#text(" are disjoint. Thus, for any ")#mi("{x \\in V_{P \\backslash \\{p\\}}}")#text(", the set ")#mi("{\\{ (i,j) \\in V_p \\times V_p: x \\in A_i \\oplus B_j \\}}")#text(" is diagonal-free. But this set also must have cardinality ")#mi("{p}")#text(", since ")#mi("{A \\oplus B = V_P}")#text(". Thus, this set is either a vertical line ")#mi("{\\{i\\} \\times V_p}")#text(" or a horizontal line ")#mi("{V_p \\times \\{j\\}}")#text(". Letting ")#mi("{E_i}")#text(" denote the set where the former case occurs for a given ")#mi("{i \\in V_p}")#text(", and ")#mi("{F_j}")#text(" the set where the latter case occurs, one obtains the claim. ")#mi("\\Box")

#text("Here is one small application of the above proposition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 18")]#text(" ")#metadata(none) <tao-2e12b90b28001604207a>#text(" Suppose the square-free Coven-Meyerowitz conjecture is true for ")#mi("{V_{P \\backslash \\{p\\}}}")#text(". Then the square-free Coven-Meyerowitz conjecture is true for any tiling ")#mi("{A \\oplus B}")#text(" of ")#mi("{V_P}")#text(" for which at least one of the slices ")#mi("{A_i, B_j}")#text(" with ")#mi("{i,j \\in V_p}")#text(" is empty.")
]

#emph[#text("Proof:")]#text(" Suppose for instance that ")#mi("{A_0}")#text(" is empty. Then by ")#link(<tao-e339b46c1a1ec453ef35>)[#text("(5)")]#text(", we see that ")#mi("{F_j}")#text(" is empty for all ")#mi("{j}")#text("; thus ")#mi("{A_i \\oplus B_j = E_i}")#text(" is independent of ")#mi("{j}")#text(". As the ")#mi("{E_i}")#text(" are disjoint, this implies that the ")#mi("{A_i}")#text(" are disjoint. Thus, if ")#mi("{A^{\\prime} := \\bigcup_{i \\in V_p} A_i}")#text(", then ")#mi("{A^{\\prime} \\oplus B_j = V_{P \\backslash \\{p\\}}}")#text(" for any ")#mi("{j}")#text(". In particular, the ")#mi("{B_j}")#text(" all have the same cardinality. Thus, by hypothesis, ")#mi("{A^{\\prime}}")#text(" consists of one representative of each coset of some subgroup of ")#mi("{V_{P \\backslash \\{p\\}}}")#text("; multiplying this subgroup by ")#mi("{V_p}")#text(", we conclude that ")#mi("{A}")#text(" also meets one representative of each coset of a subgroup of ")#mi("{V_P}")#text(". Similarly, each of the ")#mi("{B_j}")#text(" consists of one representative of each coset of some subgroup of ")#mi("{V_{P \\backslash \\{p\\}}}")#text("; as all the ")#mi("{B_j}")#text(" have the same cardinality and ")#mi("{N}")#text(" is square-free, this subgroup must be independent of ")#mi("{j}")#text(". Thus ")#mi("{B}")#text(" also consists of exactly one representative of each coset of the same subgroup in ")#mi("{V_P}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. A counterexample — ")]]

#text("In this section we note a ")#link("http://www.ams.org/mathscinet-getitem?mr=787502")[#text("counterexample of Szabo")]#text(" to a natural conjecture (")#link("http://www.ams.org/mathscinet-getitem?mr=536586")[#text("due to Sands")]#text(", with a very similar conjecture also ")#link("http://www.ams.org/mathscinet-getitem?mr=1345184")[#text("formulated by Tijdeman")]#text("). In the square-free case, the conjecture reads:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 19 (Tijdeman-Sands conjecture)")]#text(" ")#metadata(none) <tao-44ad63f60af0f6db6fdd>#text(" Let ")#mi("{A \\otimes B = V_P}")#text(" be a tiling of a square-free cyclic group ")#mi("{V_P}")#text(". Then at least one of ")#mi("{A}")#text(" or ")#mi("{B}")#text(" is contained in a coset of a proper subgroup of ")#mi("{V_P}")#text(".")
]

#text("This conjecture would imply the (square-free) Coven-Meyerowitz conjecture, as can be seen from Corollary ")#link(<tao-2e12b90b28001604207a>)[#text("18")]#text(". All the preceding examples of tilings listed previously satisfy this conjecture. However, Szabo showed that this conjecture fails when ")#mi("{P}")#text(" consists of six primes ")#mi("{p_1,\\ldots,p_6}")#text(". The idea is to start with a base tiling which does not directly counter the conjecture, but then modify it to disprove the conjecture. The base example is given by the sets")

#align(center)[#tao-fit-display[#mitex("A := \\{ (a,b,c,F(a),G(b),H(c)): a \\in V_{p_1}, b \\in V_{p_2}, c \\in V_{p_3} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("B := \\{ (0,0,0,d,e,f): d \\in V_{p_4}, e \\in V_{p_5}, f \\in V_{p_6} \\}")]]

#text("where ")#mi("{F: V_{p_1} \\rightarrow V_{p_4}}")#text(", ")#mi("{G: V_{p_2} \\rightarrow V_{p_5}}")#text(", ")#mi("{H: V_{p_3} \\rightarrow V_{p_6}}")#text(" are arbitrary functions.")

#text("It is easy to see that ")#mi("{A \\oplus B = V_P}")#text(", regardless of what the functions ")#mi("{F,G,H}")#text(". Furthermore, if ")#mi("{F,G,H}")#text(" are chosen to be non-constant, then ")#mi("{A}")#text(" is not contained in any proper coset of ")#mi("{V_P}")#text(". On the other hand, ")#mi("{B}")#text(" is clearly contained in a coset of a proper subgroup of ")#mi("{V_P}")#text(", namely itself. However, this can be remedied by modifying ")#mi("{B}")#text(" slightly. If we let ")#mi("{\\ell_1}")#text(" be the line")

#align(center)[#tao-fit-display[#mitex("\\ell_1 := \\{ (0,0,0,0,0,f): f \\in V_{p_6} \\}")]]

#text("and ")#mi("{\\ell^{\\prime}}")#text(" be the translated line")

#align(center)[#tao-fit-display[#mitex("\\ell^{\\prime}_1 := \\{ (0,0,1,0,0,f): f \\in V_{p_6} \\}")]]

#text("then one easily verifies that")

#align(center)[#tao-fit-display[#mitex("A \\oplus \\ell_1 = A \\oplus \\ell^{\\prime}_1 = \\{ (a,b,c,F(a),G(b),f): a \\in V_{p_1}, b \\in V_{p_2}, c \\in V_{p_3}, f \\in V_{p_6} \\}.")]]

#text("In particular, if we remove ")#mi("{\\ell_1}")#text(" from ")#mi("{B}")#text(" and replace it with ")#mi("{\\ell^{\\prime}_1}")#text(", then the new set obtained is still a tiling complement to ")#mi("{A}")#text(". In a similar spirit, if we let")

#align(center)[#tao-fit-display[#mitex("\\ell_2 := \\{ (0,0,0,1,e,0): e \\in V_{p_5} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\ell^{\\prime}_2 := \\{ (0,1,0,1,e,0): e \\in V_{p_5} \\}")]]

#text("then ")#mi("{A \\oplus \\ell_2 = A \\oplus \\ell^{\\prime}_2}")#text(", and if")

#align(center)[#tao-fit-display[#mitex("\\ell_3 := \\{ (0,0,0,d,1,1): d \\in V_{p_4} \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\ell^{\\prime}_3 := \\{ (1,0,0,d,1,1): d \\in V_{p_4} \\}")]]

#text("then ")#mi("{A \\oplus \\ell_3 = A \\oplus \\ell^{\\prime}_3}")#text(". Furthermore, ")#mi("{\\ell_1,\\ell_2,\\ell_3, \\ell^{\\prime}_1, \\ell^{\\prime}_2, \\ell^{\\prime}_3}")#text(" are disjoint. Thus if we let ")#mi("{B^{\\prime}}")#text(" be the set")

#align(center)[#tao-fit-display[#mitex("B^{\\prime} := B \\backslash (\\ell_1 \\cup \\ell_2 \\cup \\ell_3) \\cup (\\ell^{\\prime}_1 \\cup \\ell^{\\prime}_2 \\cup \\ell^{\\prime}_3)")]]

#text("then we see that ")#mi("{B^{\\prime}}")#text(" remains a tiling complement of ")#mi("{B}")#text(". However, it is not difficult to see that unlike ")#mi("{B}")#text(", ")#mi("{B^{\\prime}}")#text(" is not contained in any coset of a proper subgroup of ")#mi("{V}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" This construction does not prohibit the weaker conjecture that, given a tiling ")#mi("{A \\oplus B = V_P}")#text(", that there is a prime ")#mi("{p}")#text(" such that one of the slices ")#mi("{A_i, B_j}")#text(" with ")#mi("{i,j \\in V_p}")#text(" is empty; this would still be enough to obtain the Coven-Meyerowitz conjecture, at least in the square-free case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" As noted by Szabo, the same construction also counters a conjecture of Corrádi that if ")#mi("{A \\oplus B = V_P}")#text(", then at least one of ")#mi("{A}")#text(" or ")#mi("{B}")#text(" consists of unions of cosets of a non-trivial subgroup of ")#mi("{V_P}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Curiously, even though Conjecture ")#link(<tao-44ad63f60af0f6db6fdd>)[#text("19")]#text(" is false as stated, it is true in a “density” sense. Indeed, from Corollary ")#link(<tao-04b5ee99e940cda83328>)[#text("7")]#text(" we know that at least one of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" is diagonal-free. If say ")#mi("{A}")#text(" is diagonal-free, we may translate so that ")#mi("{0 \\in A}")#text(", and then ")#mi("{A}")#text(" is contained in the union of all the “hyperplanes” ")#mi("{V_{P \\backslash \\{p\\}}}")#text(" through ")#mi("{0}")#text(". If ")#mi("{P}")#text(" consists of ")#mi("{k}")#text(" primes, then there are ")#mi("{k}")#text(" such hyperplanes, so by the pigeonhole principle, one of the hyperplanes contains at least ")#tao-math("{\\left|A\\right|/k}", block: false)#text(" of the elements of ")#mi("{A}")#text(". Perhaps it may be possible to exploit this sort of observation in the regime where ")#mi("{k}")#text(" is bounded and the primes ")#mi("{p_1,\\ldots,p_k}")#text(" were large, though I was unable to get any particularly strong control on ")#mi("{A}")#text(" or ")#mi("{B}")#text(" out of this.")
]

#heading(level: 1)[#strong[#text(" — 5. Some sub-problems — ")]]

#text("The full Coven-Meyerowitz conjecture seems difficult, even in the square-free case, but some subproblems seem feasible. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 20")]#text(" Is the square-free Coven-Meyerowitz conjecture true when ")#mi("{N}")#text(" is the product of four primes, ")#mi("{N = p_1 p_2 p_3 p_4}")#text("? In view of Proposition ")#link(<tao-b5039c325d7107d60895>)[#text("13")]#text(" and Proposition ")#link(<tao-0a2f133eb9f7ca028a20>)[#text("15")]#text(", one may assume that ")#tao-math("{\\left|A\\right| = p_1 p_2}", block: false)#text(" and ")#tao-math("{\\left|B\\right| = p_3 p_4}", block: false)#text(".")
]

#text("Or:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 21")]#text(" Suppose we already know that a tile ")#mi("{A}")#text(" obeys the square-free Coven-Meyerowitz conjecture (i.e. it consists of one representative of each coset of a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text("). Does this imply that every tiling complement ")#mi("{B}")#text(" of ")#mi("{A}")#text(" also obeys the conjecture (replacing ")#mi("{H}")#text(" with ")#mi("{H^\\perp}")#text(", of course?).")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-108075")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2011")])]

#text("Re Remark 2, such binary operations are called ")#link("http://en.wikipedia.org/wiki/Quasigroup")[#text("quasigroup")]#text(" operations. If defined on finite sets then they are also called “latin squares”.")

#emph[#text("[Remark updated to reflect this terminology, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c60fb002fac958ac61874654f834513f8ad2e79a220118feb88e48e16dcdbf14-72de779f47ae137c9e2b8759a76762c685f9a30b0f71ca71c1fbff6d491caf95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Wieland")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-112709")[#strong[#text("Ben Wieland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2011")])]

#text("The statement of Lemma 4 is missing some hats.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bda8bc9326d55a2a912b1c24976d589ba60de6a82e7d9ad63ebd8c6dceb786f7-4ab9f5e1524973ee673d50708cd662217c58113efac61018a70c96bf35daab19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Meyerowitz")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-112797")[#strong[#text("Aaron Meyerowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2011")])]

#text("For conjecture 2 the condition is not quite that ")#tao-math("\\left|A\\right|=\\prod_{s \\in S_A}s", block: false)#text(" rather that ")#tao-math("\\left|A\\right|=\\prod_{p^j \\in S_A}p", block: false)#text(" so a set perhaps ")#tao-math("\\left|A\\right|=20", block: false)#text(" and ")#mi("S_A=\\lbrace 32,512,625\\rbrace.")#text(" If I recall correctly (and I need to check), an ")#mi("N")#text(" leading to a counterexample has at least 6 prime factors (so the first open cases are ")#mi("N=900")#text(" or ")#mi("N=30030")#text(" for square free.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bda8bc9326d55a2a912b1c24976d589ba60de6a82e7d9ad63ebd8c6dceb786f7-4ab9f5e1524973ee673d50708cd662217c58113efac61018a70c96bf35daab19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ameyerowitz")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-112975")[#strong[#text("ameyerowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2011")])]

#text("Thanks for the thoughts. This gives me things to consider.")#linebreak()#text(" A few observations:")

#text("The conditions address ")#tao-math("\\left|A\\right|", block: false)#text(" but not ")#mi("N")#text(", the conditions can be phrased so that they assume ")#mi("A")#text(" is a tile for some unspecified finite cyclic group.")

#text("1) Thus in Conjecture 2 rather than saying ")#mi("\\sum_{n \\in A}e^{2\\pi i n k/N}")#text(" vanishes where ")#mi("k")#text(" has order in ")#mi("\\mathbb{Z}/N\\mathbb{Z}")#text(" which is a product… one can say ")#mi("\\sum_{n \\in A}e^{2\\pi i n /j}")#text(" vanishes when ")#mi("j")#text(" is an integer which is a product …")

#text("2) Corollary 5 remains true if we merely require that ")#mi("m")#text(" is coprime to ")#tao-math("\\left|B\\right|", block: false)#text(" (which will of course make it coprime to ")#mi("N")#text(".)")

#text("I worry that I am missing something but let me put this out there for possible correction:")

#text("3) In the event that ")#mi("A \\oplus B=\\mathbb{Z}/N\\mathbb{Z}")#text(" and ")#tao-math("m=\\left|A\\right|", block: false)#text(" is coprime to ")#tao-math("\\left|B\\right|", block: false)#text(" (as will certainly be the case when ")#mi("N")#text(" is square-free) we also have ")#mi("A \\oplus mB=\\mathbb{Z}/N\\mathbb{Z}")#text(" and here ")#mi("H=mB")#text(" is a subgroup.")

#text("4) Note that ")#mi("A")#text(" is a tile of ")#mi("\\mathbb{Z}/N\\mathbb{Z}")#text(" if and only if ")#mi("A")#text(" is a tile of ")#mi("\\mathbb{Z}/M\\mathbb{Z}")#text(" where ")#mi("M=N/d")#text(" and ")#mi("d")#text(" is the largest divisor of ")#mi("N")#text(" coprime to ")#tao-math("\\left|A\\right|", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-112980")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2011")])]

#text("Unfortunately I don’t know how to free the proof of Lemma 4 (and hence Corollary 5) from the dependence on N, as one needs coprimality of m and N to get the Galois automorphism of the cyclotomic ring of order N. If one could obtain your conclusion 3), this would immediately resolve Conjecture 1. This does seem to be a nice reformulation of that conjecture, though…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bda8bc9326d55a2a912b1c24976d589ba60de6a82e7d9ad63ebd8c6dceb786f7-4ab9f5e1524973ee673d50708cd662217c58113efac61018a70c96bf35daab19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ameyerowitz")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-112976")[#strong[#text("ameyerowitz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2011")])]

#text("Sorry, don’t have the hang of this yet and not sure how to delete and fix the latex above. ")#emph[#text("[I repaired the latex; one has to insert the keyword “latex” at the beginning of every math mode fragment, as explained in the bottom left corner of this blog. Unfortunately there is no ability to anyone other than myself to edit comments. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17091d4a03d31ec4dcf328fd4d4d32db71be5b910e8d970cb06458f485a78ee0-f9203420c8451af72d62b1b2b4d5e95ce44a69b089d67063cdb25ebaac827640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr Emmanuel Amiot")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-119853")[#strong[#text("Dr Emmanuel Amiot")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2012")])]

#text("I am happy to bring to your notice that problem 20 is solved, as is the case ")#mi("N = p^2 q r")#text(". These are two cases when ")#mi("Z/N Z")#text(" is a Hajos group, and in that case any direct sum decomposition of the cyclic group can be projected on a decomposition of a subgroup. I proved in Amiot, E., Rhythmic canons and Galois theory, Grazer Math. Ber., 347 (2005), 1–25 that condition (T2) is preserved under this operation and the converse (and some others), and hence as (tiling => (T2)) for the subgroups it must be true initially. In more modern times it boils down to expressions of DFT in ")#mi("Z/N Z")#text(" vs. ")#mi("Z/(N/p)Z")#text(".")#linebreak()#text(" This kind of transformational process fails with the Szabo counterexamples family, unfortunately. Maybe this is what Aaron had in mind in his first comment.")#linebreak()#text(" Some computational progress in that direction has been made since, with fresh ideas from Matolcsi & Koloutzakis, see Journal of Mathematics and Music, Volume 3, Issue 2 July (2009).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-121464")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2012")])]

#text("I was just looking at it today. Is there a reason why the argument from Lemma 2.3 in the Coven-Meyerowitz case wouldn’t cover the square-free case? Or am I missing something?")

#text("Suppose that ")#mi("A \\oplus B = \\mathbb{Z}_N")#text(" with N square-free. Let r be a prime dividing |B|, then r does not divide |A|. By Tijdeman’s theorem, ")#mi("rA \\oplus B=\\mathbb{Z}_N")#text(". Let ")#mi("B^{\\prime}=B \\cap r \\mathbb{Z}")#text(", then |B’|=|B|/r (this follows for example because ")#mi("\\Phi_r(x)")#text(" divides B(x), so that B has the same number of elements in each congruence class mod r). Then ")#mi("rA \\oplus B^{\\prime} = r \\mathbb{Z} / N \\mathbb{Z}")#text(". Dividing everything by r, we get that ")#mi("A \\oplus B^{\\prime\\prime} = \\mathbb{Z}_{N/r}")#text(", where B”=B’/r and |B”|=N/r.")

#text("Iterating the procedure with one prime factor of |B| at a time, we eventually get a tiling ")#tao-math("A \\oplus {0} = \\mathbb{Z}_{\\left|A\\right|}", block: false)#text(", so that A = {0,1,…,|A|-1} (mod |A|). In particular, the Coven-Meyerovitz conditions hold for A.")

#text("The argument doesn’t really seem to require that N be square-free, only that |B| be relatively prime to |A|.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-121566")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2012")])]

#text("Ah, you’re right, this does seem to resolve the square-free case (Conjecture 1). (Aaron already tried to tell me this in an earlier comment, but I somehow missed the point of his remarks.) What had happened was that I had taken the proof of Lemma 3.1 in the Coven-Meyerowitz paper and simplified it to give Lemma 4 above, but the cost of this simplification is that I needed r to be coprime to N and not just to |A|. But you are right, the original argument in Coven-Meyerowitz (or Tijdeman) does seem to work in this case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/11/19/some-notes-on-the-coven-meyerowitz-conjecture/#comment-682696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2024")])]

#text("In Example 3, do you mean for ")#mi("B")#text(" to consist of a single representative of ")#mi("V_{P_1} \\times \\{x\\}")#text(" for each ")#mi("x \\in V_{P_2}")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]
