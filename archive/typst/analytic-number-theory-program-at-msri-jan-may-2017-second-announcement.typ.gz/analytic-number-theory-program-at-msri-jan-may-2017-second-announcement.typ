// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/
// Converted to Typst by tao2typ: "2026-10-14T16:37:50.176998+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Analytic number theory program at MSRI: Jan-May 2017 (second announcement)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Analytic number theory program at MSRI: Jan-May 2017 (second announcement)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/")[#text("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.mathstat.concordia.ca/faculty/cdavid/")[#text("Chantal David")]#text(",")#link("http://www.dms.umontreal.ca/~andrew/")[#text(" Andrew Granville")]#text(", ")#link("https://people.math.ethz.ch/~kowalski/")[#text("Emmanuel Kowalski")]#text(", ")#link("http://tan.epfl.ch/philippe.michel")[#text("Phillipe Michel")]#text(", ")#link("http://math.stanford.edu/~ksound/")[#text("Kannan Soundararajan")]#text(", and I are ")#link("http://www.msri.org/programs/297")[#text("running a program at MSRI in the Spring of 2017 (more precisely, from Jan 17, 2017 to May 26, 2017) in the area of analytic number theory")]#text(", with the intention to bringing together many of the leading experts in all aspects of the subject and to present recent work on the many active areas of the subject (e.g. the distribution of the prime numbers, refinements of the circle method, a deeper understanding of the asymptotics of bounded multiplicative functions (and applications to Erdos discrepancy type problems!) and of the “pretentious” approach to analytic number theory, more “analysis-friendly” formulations of the theorems of Deligne and others involving trace functions over fields, and new subconvexity theorems for automorphic forms, to name a few). Like any other semester MSRI program, there will be a number of workshops, seminars, and similar activities taking place while the members are in residence. I’m personally looking forward to the program, which should be occurring in the midst of a particularly productive time for the subject. Needless to say, I (and the rest of the organising committee) plan to be present for most of the program.")

#text("Applications for Postdoctoral Fellowships and Research Memberships for this program (and for other MSRI programs in this time period, namely the ")#link("http://www.msri.org/programs/300")[#text("companion program in Harmonic Analysis")]#text(" and the ")#link("http://www.msri.org/programs/278")[#text("Fall program in Geometric Group Theory")]#text(", as well as the complementary program in all other areas of mathematics) ")#link("http://www.msri.org/web/msri/scientific/member-application")[#text("remain open until Dec 1")]#text(". Applications are open to everyone, but require supporting documentation, such as a CV, statement of purpose, and letters of recommendation from other mathematicians; see ")#link("http://www.msri.org/web/msri/scientific/member-application")[#text("the application page for more details")]#text(".")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae8a1836a35559319c57861dc2bb610e4821ea390b7f66b757e7a2a4dd58e8af-70b5050248c5e6323a3b5c37deea739fa97adaf39a99c575ada8e92c700aa033.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shivnarayan Dhuppar")]], [#link("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/#comment-461571")[#strong[#text("Shivnarayan Dhuppar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2015")])]

#text("I am a physicist studying nuclear architecture and its effect on gene expression, interested highly in pure mathematics. I have had many courses in the same – especially number- and group theory. Could I still apply for the geometric group theory programme? I might not get recommendations from mathematicians as you said, but could surely get from physicists and biologists who know my leaning towards mathematics very well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/#comment-461583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2015")])]

#text("Applications are open to everyone, but I would imagine that there would be more applicants than available positions for this program, so applicants who have a demonstrated record of being able to contribute to the topics in the program (or at least have strong letters from more senior experts with such a record) would be more likely to be accepted.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/744af6de8cc8d5fa42cf0dbd096e88eef82f4b51081b78514bff85bf909eab07-d4d0b110ce3d5330716c189c6d455c2cd768a34ab962b2a8c3755b79505fb788.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of grpaseman")]], [#link("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/#comment-461709")[#strong[#text("grpaseman")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2015")])]

#text("Two questions: Will the facilities accommodate non-members, either by videoing the sessions and making them available to all researchers, or by using venues large enough that non-members who wish to audit ( as in fly-on-the-wall ) can do so comfortably for all involved? ( I am considering the possibility of attending some of the lectures without applying for membership.)")

#text("Will there be a forum/blog component, where (in addition to whatever the members choose to blog individually) some highlights of the day are recorded, or perhaps some MathOverflow material is generated? (I can see where “having MathOverflow as a member” could enhance the program.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/06/analytic-number-theory-program-at-msri-jan-may-2017-second-announcement/#comment-461710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2015")])]

#text("I believe the talks will be videotaped, though it may take some time (on the order of weeks) before they are formatted and available on the MSRI web site. I think the talks will also be open to non-registered participants; it is common for instance for faculty and students from UC Berkeley to take the shuttle up to MSRI to attend some of the talks.")

#text("Outside of the workshops, though, the activities tend to be rather informal – discussions at a blackboard in one of the common spaces, or collaborations between two or more of the members. None of this is formally recorded or reported on (MSRI’s staff is probably too small to do this even if it wanted to.), which may well be a good thing, one could imagine some participants being too shy to toss out half-baked ideas if they knew there would be a worldwide audience.")
]
]
