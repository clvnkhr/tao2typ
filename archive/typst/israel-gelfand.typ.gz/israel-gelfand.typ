// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/10/07/israel-gelfand/
// Converted to Typst by tao2typ: "2026-10-14T16:35:53.911509+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Israel Gelfand", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Israel Gelfand")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/")[#text("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://en.wikipedia.org/wiki/Israel_Gelfand")[#text("Israel Gelfand")]#text(", who made profound and prolific contributions to many areas of mathematics, including functional analysis, representation theory, operator algebras, and partial differential equations, ")#link("http://www.ams.org/news/home-news.html#gelfand")[#text("died on Monday")]#text(", age 96.")

#text("Gelfand’s beautiful theory of ")#mi("{C^*}")#text("-algebras and related spaces made quite an impact on me as a graduate student in Princeton, to the point where I was seriously considering working in this area; but there was not much activity in operator algebras at the time there, and I ended up working in harmonic analysis under Eli Stein instead. (Though I am currently involved in another operator algebras project, of which I hope to be able to discuss in the near future. The commutative version of Gelfand’s theory is discussed in ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("these lecture notes of mine")]#text(".)")

#text("I met Gelfand only once, in one of the famous “Gelfand seminars” at the IHES in 2000. The speaker was Tim Gowers, on his new proof of Szemerédi’s theorem. (Endre Szemerédi, incidentally, was Gelfand’s student.) Gelfand’s introduction to the seminar, on the subject of Banach spaces which both mathematicians contributed so greatly to, was approximately as long as Gowers’ talk itself!")

#text("There are far too many contributions to mathematics by Gelfand to name here, so I will only mention two. The first are the ")#emph[#text("Gelfand-Tsetlin patterns")]#text(", induced by an ")#mi("{n \\times n}")#text(" Hermitian matrix ")#mi("{A}")#text(". Such matrices have ")#mi("{n}")#text(" real eigenvalues ")#mi("{\\lambda_{n,1} \\leq \\ldots \\leq \\lambda_{n,n}}")#text(". If one takes the top ")#mi("{n-1 \\times n-1}")#text(" minor, this is another Hermitian matrix, whose ")#mi("{n-1}")#text(" eigenvalues ")#mi("{\\lambda_{n-1,1} \\leq \\ldots \\leq \\lambda_{n-1,n-1}}")#text(" ")#emph[#text("intersperse")]#text(" the ")#mi("{n}")#text(" eigenvalues of the original matrix: ")#mi("{\\lambda_{n,i} \\leq \\lambda_{n-1,i} \\leq \\lambda_{n,i+1}}")#text(" for every ")#mi("{1 \\leq i \\leq n-1}")#text(". This interspersing can be easily seen from the minimax characterisation")

#align(center)[#tao-fit-display[#tao-math("\\lambda_{n,i} = \\inf_{\\text{dim}(V)=i} \\sup_{v \\in V: \\left\\|v\\right\\|=1} \\langle Av, v \\rangle", block: true)]]

#text("of the eigenvalues of ")#mi("{A}")#text(", with the eigenvalues of the ")#mi("{n-1 \\times n-1}")#text(" minor being similar but with ")#mi("{V}")#text(" now restricted to a subspace of ")#mi("{{\\mathbb C}^{n-1}}")#text(" rather than ")#mi("{{\\mathbb C}^n}")#text(".")

#text("Similarly, the eigenvalues ")#mi("{\\lambda_{n-2,1} \\leq \\ldots \\leq \\lambda_{n-2,n-2}}")#text(" of the top ")#mi("{n-2 \\times n-2}")#text(" minor of ")#mi("{A}")#text(" intersperse those of the previous minor. Repeating this procedure one eventually gets a pyramid of real numbers of height and width ")#mi("{n}")#text(", with the numbers in each row interspersing the ones in the row below. Such a pattern is known as a ")#emph[#text("Gelfand-Tsetlin pattern")]#text(". The space of such patterns forms a convex cone, and (if one fixes the initial eigenvalues ")#mi("{\\lambda_{n,1},\\ldots,\\lambda_{n,n}}")#text(") becomes a compact convex polytope. If one fixes the initial eigenvalues ")#mi("{\\lambda_{n,1},\\ldots,\\lambda_{n,n}}")#text(" of ")#mi("{A}")#text(" but chooses the eigenvectors randomly (using the Haar measure of the unitary group), then the resulting Gelfand-Tsetlin pattern is uniformly distributed across this polytope; the ")#mi("{n=2}")#text(" case of this observation is essentially the classic observation of Archimedes that the cross-sectional areas of a sphere and a circumscribing cylinder are the same. (Ultimately, the reason for this is that the Gelfand-Tsetlin pattern almost turns the space of all ")#mi("{A}")#text(" with a fixed spectrum (i.e. the co-adjoint orbit associated to that spectrum) into a ")#link("http://en.wikipedia.org/wiki/Toric_variety")[#text("toric variety")]#text(". More precisely, there exists a mostly diffeomorphic map from the co-adjoint orbit to a (singular) toric variety, and the Gelfand-Tsetlin pattern induces a complete set of action variables on that variety.) There is also a “quantum” (or more precisely, representation-theoretic) version of this observation, in which one can decompose any irreducible representation of the unitary group ")#mi("{U(n)}")#text(" into a canonical basis (the ")#emph[#text("Gelfand-Tsetlin basis")]#text("), indexed by integer-valued Gelfand-Tsetlin patterns, by first decomposing this representation into irreducible representations of ")#mi("{U(n-1)}")#text(", then ")#mi("{U(n-2)}")#text(", and so forth.")

#text("The structure, symplectic geometry, and representation theory of Gelfand-Tsetlin patterns was enormously influential in my own work with Allen Knutson on honeycomb patterns, which control the sums of Hermitian matrices and also the structure constants of the tensor product operation for representations of ")#mi("{U(n)}")#text("; indeed, Gelfand-Tsetlin patterns arise as the degenerate limit of honeycombs in three different ways, and we in fact discovered honeycombs by trying to glue three Gelfand-Tsetlin patterns together. (See for instance ")#link("http://front.math.ucdavis.edu/math.RT/0009048")[#text("our Notices article")]#text(" for more discussion. The honeycomb analogue of the representation-theoretic properties of these patterns was eventually established ")#link("http://front.math.ucdavis.edu/math.CO/0408114")[#text("by Henriques and Kamnitzer")]#text(", using ")#mi("{gl(n)}")#text(" crystals and their Kashiwara bases.)")

#text("The second contribution of Gelfand I want to discuss is the ")#emph[#text("Gelfand-Levitan-Marchenko equation")]#text(" for solving the one-dimensional ")#link("http://en.wikipedia.org/wiki/Inverse_scattering")[#text("inverse scattering")]#text(" problem: given the scattering data of an unknown potential function ")#mi("{V(x)}")#text(", recover ")#mi("{V}")#text(". This is already interesting in and of itself, but is also instrumental in solving integrable systems such as the Korteweg-de Vries equation, because the ")#link("http://en.wikipedia.org/wiki/Lax_pair")[#text("Lax pair")]#text(" formulation of such equations implies that they can be linearised (and solved explicitly) by applying the scattering and inverse scattering transforms associated with the Lax operator. I discuss the derivation of this equation below the fold.")

#metadata(none) <tao-8d136414acd69a7803ca>

#heading(level: 1)[#strong[#text(" — 1. Inverse scattering — ")]]

#text("Let ")#mi("{V: {\\mathbb R} \\rightarrow {\\mathbb R}}")#text(" be a smooth real potential function supported on a compact interval ")#mi("{[-R,R]}")#text(" (for simplicity), and consider the potential wave equation in one spatial dimension ")#metadata(none) <tao-63f75c890b05405e6e1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(-\\frac{\\partial^2}{\\partial t^2} + \\frac{\\partial^2}{\\partial x^2}) u(t,x) = V(x) u(t,x)")]]

#text("for the scalar field ")#mi("{u: {\\mathbb R} \\times {\\mathbb R} \\rightarrow {\\mathbb R}}")#text(". If the potential ")#mi("{V}")#text(" was zero, then ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" becomes the free wave equation, the general solution ")#mi("{u(t,x)}")#text(" of ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" would be the superposition of a rightward moving wave ")#mi("{f(x-t)}")#text(" and a leftward moving wave ")#mi("{g(x+t)}")#text(":")

#align(center)[#tao-fit-display[#mitex("u(t,x) = f(x-t) + g(x+t).")]]

#text("Now suppose ")#mi("{V}")#text(" is non-zero. Then in the left region ")#mi("{x \\leq -R}")#text(", ")#mi("{u}")#text(" solves the free wave equation and thus takes the form")

#align(center)[#tao-fit-display[#mitex("u(t,x) = f_-(x-t) + g_-(x+t)")]]

#text("for some ")#mi("{f_-,g_-}")#text(", while in the right region ")#mi("{x \\geq R}")#text(", ")#mi("{u}")#text(" solves the free wave equation and takes the form")

#align(center)[#tao-fit-display[#mitex("u(t,x) = f_+(x-t) + g_+(x+t)")]]

#text("for some ")#mi("{f_+,g_+}")#text(". As for the central region ")#mi("{-R < x < R}")#text(", we will make the simplifying assumption that the equation ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" has no bound states, which implies in particular that ")#mi("{u(t,x) \\rightarrow 0}")#text(" as ")#mi("{t \\rightarrow \\pm \\infty}")#text(" for any fixed ")#mi("{x}")#text(" and any reasonable ")#mi("{u}")#text(" (e.g. finite energy will do). From spectral theory, this assumption is equivalent to the assertion that the ")#emph[#text("Hill operator")]#text(" (or ")#emph[#text("Schrödinger operator")]#text(") ")#mi("{-\\frac{\\partial^2}{\\partial x^2} + V(x)}")#text(" has no eigenfunctions in ")#mi("{L^2({\\mathbb R})}")#text(".) Thus the wave is asymptotically equal to ")#mi("{f_-(x-t) + g_+(x+t)}")#text(" for large negative times, then evolves to interact with the potential, then eventually is asymptotic to ")#mi("{f_+(x-t)+g_-(x+t)}")#text(" for large positive ")#mi("{t}")#text(".")

#text("When ")#mi("{V}")#text(" is zero, we have ")#mi("{f_+=f_-}")#text(" and ")#mi("{g_+=g_-}")#text(". For non-zero ")#mi("{V}")#text(", the relationship between ")#mi("{f_+,f_-,g_+,g_-}")#text(", and involves something called the ")#emph[#text("reflection coefficients")]#text(" and ")#emph[#text("transmission coefficients")]#text(" of ")#mi("{V}")#text(". We will not define these just yet, but instead focus on two special cases. Firstly, consider the case when ")#mi("{f_- = \\delta}")#text(" is the Dirac delta function and ")#mi("{g_+ = 0}")#text("; thus for large negative times, the wave consists just of a Dirac mass (or “photon”, if you will) arriving from the left, and this generates some special solution ")#mi("{G(t,x)}")#text(" to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" (a bit like the fundamental solution). (We will ignore the (mild) technical issues involved in solving PDE with data as rough as the Dirac distribution.) Evolving the wave equation ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(", the solution ")#mi("{G}")#text(" eventually resolves to some transmitted wave ")#mi("{f_+}")#text(" (which should be some perturbation of the Dirac delta function) plus a reflected wave ")#mi("{g_-}")#text(", which we will call ")#mi("{B}")#text(". This function ")#mi("{B}")#text(" can be thought of as “scattering data” for the potential ")#mi("{V}")#text(".")

#text("Next, we will consider the solution ")#mi("{u(t,x) = \\delta(t-x) + K(t,x)}")#text(" to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" for which ")#mi("{f_- = \\delta}")#text(" and ")#mi("{g_- = 0}")#text("; one can view this solution as obtained by reversing the roles of space and time, and evolving ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" from ")#mi("{x=-\\infty}")#text(" to ")#mi("{x=+\\infty}")#text(" (with the potential ")#mi("{V(x)}")#text(" now being a constant-in-space, variable-in-time potential rather than the other way around). One can construct this solution by the Picard iteration method, and using finite speed of propagation, one can show that ")#mi("{K(t,x)}")#text(" is supported on the lower diagonal region ")#mi("{\\{ (t,x): t \\leq x; x \\geq -R \\}}")#text(", and is smooth except at the diagonal ")#mi("{t=x}")#text(", where it can have a jump discontinuity. One can think of ")#mi("{K}")#text(" as a dual fundamental solution for the equation ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text("; it is also the Fourier transform of the ")#emph[#text("Jost solutions")]#text(" to the eigenfunction equation ")#link(<tao-b5ddc345b514e1747327>)[#text("(5)")]#text(".")

#text("We claim that the scattering data ")#mi("{B}")#text(" can be used to reconstruct the potential ")#mi("{V}")#text(". This claim is obtained from two sub-claims:")

#list(
[#text("Given the scattering data ")#mi("{B}")#text(", one can recover ")#mi("{K}")#text(".")],
[#text("Given ")#mi("{K}")#text(", one can recover ")#mi("{V}")#text(".")]
)

#text("The second claim is easy: one simply substitutes ")#mi("{u = \\delta(t-x) + K(t,x)}")#text(" into ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(". Indeed, if one compares the ")#mi("{\\delta(t-x)}")#text(" components of both sides, one sees that")

#align(center)[#tao-fit-display[#mitex("V(x) = 2 \\frac{d}{dx} K(x,x).")]]

#text("To verify the first claim, we exploit the time translation and time reversal symmetries of ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(". Since ")#mi("{\\delta(t-x) + K(t,x)}")#text(" is a solution to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(", the time-reversal ")#mi("{\\delta(t+x) + K(-t,x)}")#text(" is also a solution. More generally, the time translation ")#mi("{\\delta(t+x-s) + K(s-t,x)}")#text(" is also a solution to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" for any real number ")#mi("{s}")#text(". Multiplying this by ")#mi("{B(s)}")#text(" and integrating in ")#mi("{s}")#text(", we see that the function")

#align(center)[#tao-fit-display[#mitex("B(t+x) + \\int_{\\mathbb R} B(s+t) K(s,x)\\ ds")]]

#text("is also a solution to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(". Superimposing this with the solution ")#mi("{\\delta(t-x) + K(t,x)}")#text(", we see that ")#metadata(none) <tao-50a8138112a3acffbdac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\delta(t-x) + B(t+x) + K(t,x) + \\int_{\\mathbb R} B(s+t) K(s,x)\\ ds")]]

#text("is also a solution to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(".")

#text("Now when ")#mi("{x < -R}")#text(", ")#mi("{K}")#text(" vanishes; and so this solution ")#link(<tao-50a8138112a3acffbdac>)[#text("(2)")]#text(" is equal to ")#mi("{\\delta(t-x) + B(t+x)}")#text(" for ")#mi("{x < -R}")#text(". Thus, by uniqueness of the evolution of ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(" (in the ")#mi("{x}")#text(" direction), ")#link(<tao-50a8138112a3acffbdac>)[#text("(2)")]#text(" must match the fundamental solution ")#mi("{G}")#text(". On the other hand, by finite speed of propagation, this solution ")#mi("{G}")#text(" vanishes when ")#mi("{t<x}")#text(". We thus obtain the ")#emph[#text("Gelfand-Levitan-Marchenko equation")]#text(" ")#metadata(none) <tao-2bf548d8056029c73e6e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("B(t+x) + K(t,x) + \\int_{-\\infty}^x B(s+t) K(s,x)\\ ds = 0.")]]

#text("For any fixed ")#mi("{x}")#text(", this is a linear integral equation for ")#mi("{K}")#text(", and one can use it to solve from ")#mi("{K}")#text(" given ")#mi("{K}")#text(" by inverting the integral operator ")#mi("{K(t) \\mapsto K(t) + \\int_{-\\infty}^x B(s+t) K(s,x)\\ ds}")#text(". (This inversion can be performed by Neumann series if ")#mi("{B}")#text(" is small enough, which is for instance the case when the potential ")#mi("{V}")#text(" is small; in fact, one can use scattering theory to show that this operator is in fact invertible for all ")#mi("{V}")#text(" without bound states, but we will not do so here.)")

#text("Now I’ll discuss briefly the relationship between the data ")#mi("{B}")#text(" and more traditional types of scattering data. We already have the fundamental solution ")#mi("{G(t,x)}")#text(", which equals ")#mi("{\\delta(t-x)+B(t+x)}")#text(" for ")#mi("{x \\leq -R}")#text(" and for which ")#mi("{g_+=0}")#text(". By time translation, we have a solution ")#mi("{G(t-s,x)}")#text(" for any ")#mi("{s \\in {\\mathbb R}}")#text(", which equals ")#mi("{\\delta(t-x-s) + B(t+x-s)}")#text(" for ")#mi("{x \\leq -R}")#text(" and for which ")#mi("{g_+=0}")#text(". Multiplying this solution by ")#mi("{e^{iks}}")#text(" for some frequency ")#mi("{k \\in {\\mathbb R}}")#text(" and then integrating in ")#mi("{s}")#text(", we obtain the (complex) solution ")#metadata(none) <tao-2e81da0faeb8d413db88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_{\\mathbb R} e^{iks} G(t-s,x)\\ ds")]]

#text("to ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(", which equals")

#align(center)[#tao-fit-display[#mitex("e^{ik(t-x)} + e^{ik(t+x)} \\hat B(k)")]]

#text("for ")#mi("{x \\leq -R}")#text(", and equals some function ")#mi("{f_+(t-x)}")#text(" for ")#mi("{x \\geq R}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\hat B(k) := \\int_{\\mathbb R} e^{-ikt} B(t)\\ dt.")]]

#text("On the other hand, we can write the solution ")#link(<tao-2e81da0faeb8d413db88>)[#text("(4)")]#text(" as ")#mi("{e^{ikt} \\phi_k(x)}")#text(", where ")#mi("{\\phi_k(x) := \\int_{\\mathbb R} e^{-ikt} G(t,x)\\ dt}")#text(". This implies that ")#mi("{f_+}")#text(" must be a multiple of the plane wave ")#mi("{e^{ikt}}")#text(", thus ")#mi("{f_+(t-x) = a(k) e^{ik(t-x)}}")#text(" for some complex number ")#mi("{a(k)}")#text(". Substituting ")#mi("{e^{ikt} \\phi_k(x)}")#text(" into ")#link(<tao-63f75c890b05405e6e1f>)[#text("(1)")]#text(", we see that ")#mi("{\\phi_k}")#text(" is a generalised eigenfunction of the Schrödinger operator: ")#metadata(none) <tao-b5ddc345b514e1747327>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("(-\\frac{d^2}{dx^2} + V(x)) \\phi_k(x) = k^2 \\phi_k(x);")]]

#text("from the asymptotics of ")#link(<tao-2e81da0faeb8d413db88>)[#text("(4)")]#text(", we also see that ")#mi("{\\phi_k(x) = e^{-ikx} + e^{ikx} \\hat B(k)}")#text(" for ")#mi("{x \\leq -R}")#text(" and ")#mi("{\\phi_k(x) = a(k) e^{-ikx}}")#text(" for ")#mi("{x \\geq +R}")#text(". Thus we see that ")#mi("{\\hat B(k)}")#text(" has an interpretation as a ")#emph[#text("reflection coefficient")]#text(" for the eigenfunction equation ")#link(<tao-b5ddc345b514e1747327>)[#text("(5)")]#text(".")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/187a5ed7a3fcc3404bc9537d47e0d821bcd548ceb566f4d811f847f9f345d557-bb05e8a2c2b8292aa06718e9b90d9abadec6c2aa7e2cb3f12a5d8b3936909523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonas")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41750")[#strong[#text("Jonas")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Any recommendations for further reading on the general theory of Gelfand-Tsetlin patterns?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bruno")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41752")[#strong[#text("bruno")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Thank you for this post (and the whole blog!). It seems that there is a typo when you introduce the solution $\\delta(t-x)+K(t,x)$, hypothesis $g_+=0$ should perhaps be $g_-=0$ (consistent with considering $x$ as time). Am I wrong ?")

#emph[#text("[Oops, you’re right – corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41754")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e88v4")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")]

#text("[…] A passing noted … and here’s a vivid demonstration of how memory is kept. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41757")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#emph[#text("the Gelfand-Tsetlin pattern almost turns the space of all {A} with a fixed spectrum (i.e. the co-adjoint orbit associated to that spectrum) into a toric variety, though one first has to blow up a few singularities first to make this precise.")]

#text("1) The action isn’t algebraic, so this isn’t a blowup in the usual complex algebraic sense.")

#text("2) It’s more of a blowdown, really. There’s a map from the coadjoint orbit onto the toric variety, whose fibers are isotropic. In the 3×3 case this map is a diffeomorphism away from the singular point on the toric variety, over which the fiber is a real-3-dimensional Lagrangian sphere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Ah, right, I had it backwards. (The coadjoint orbit is, of course, smooth for generic choices of the spectrum; it was the toric variety that had the singularity.) I’ve fixed the wording accordingly.")

#text("As an analyst, I guess I tend to think of blowups in the smooth category rather than the algebraic one, though it seems this meaning of the term is only used by a minority of mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41758")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Dear Terry,")

#text("Do you type your blog articles in say TeXnicCenter first? And then transfer them to your blog via Texter or some Perl script? Because when I first loaded the page I saw the following:")

#text("\\documentclass[12pt]{article}")#linebreak()#text(" \\usepackage[pdftex,pagebackref,letterpaper=true,colorlinks=true,pdfpagemode=none,urlcolor=blue,linkcolor=blue,citecolor=blue,pdfstartview=FitH]{hyperref}")

#text("\\usepackage{amsmath,amsfonts}")#linebreak()#text(" \\usepackage{graphicx}")#linebreak()#text(" \\usepackage{color}")

#text("\\setlength{\\oddsidemargin}{0pt}")#linebreak()#text(" \\setlength{\\evensidemargin}{0pt}")#linebreak()#text(" \\setlength{\\textwidth}{6.0in}")#linebreak()#text(" \\setlength{\\topmargin}{0in}")#linebreak()#text(" \\setlength{\\textheight}{8.5in}")

#text("\\setlength{\\parindent}{0in}")#linebreak()#text(" \\setlength{\\parskip}{5px}")

#text("\\input{macrosblog}")

#text("\\begin{document}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41760")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("I use Luca Trevisan’s LaTeX to WP converter (a python script). I accidentally copied the source LaTeX here instead of the WP HTML by mistake for a few minutes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f58a6fe8e80900cd217f5495a3218d9acd85e5cd977db9fa87967870ef862781-e2c6836262ee65f748346f68b007381932b682cc851bc4e1d0fc0658dba16387.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ramanujantao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41761")[#strong[#text("ramanujantao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Dear Terry,")

#text("Here is a site which allows you to write LaTeX flies and convert them to pdf without installing MiKTeX or any editor: ")#link("http://dev.baywifi.com/latex/")[#text("http://dev.baywifi.com/latex/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41764")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("[…] Israel Gelfand […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41765")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("There is an article on Dr. Gelfand in the NYT:")

#text("“Israel Gelfand, Math Giant, Dies at 96”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53ee184c0743ef52e7fcad063679c1aa9d654713d0db4fdd8fd94f340bde32d4-1c478047debd6a440b127087b03c03ec0da14ee1be0e9c2683193fb0051733c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Watson")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41766")[#strong[#text("Bill Watson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("One should also mention Prof. Gelfand’s important contributions to the math education of gifted students in his program at Rutgers (no longer operational).")

#link("http://gcpm.rutgers.edu/former_description.html")[#text("http://gcpm.rutgers.edu/former_description.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41768")[#strong[#text("Israel Gelfand (1913-2009). R.I.P. « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")]

#text("[…] learn more about him, see e.g. the excellent post by Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41769")[#strong[#text("Random bits « Equilibrium Networks")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")]

#text("[…] Terry Tao reports that Israel Gelfand died recently. He was one of the greats, his name familiar to every student of functional analysis from the GNS […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98c2a63766a5fc4d24659023d2f84c769191532c0aac9e123dd5a312395a700a-1ad6468a98a576ac695428b1d6ada97505692eade7d85efaf3f9d054bb99b7e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41772")[#strong[#text("Jake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")])]

#text("Typo alert: Just after (1) you have “leftward moving moving wave” ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41775")[#strong[#text("Israel M. Gelfand (1913 – 2009) « Series Divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2009")]

#text("[…] Israel Gelfand (What’s new, por Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41779")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2009")])]

#text("Hi Terry,")

#text("I think there is a repetition here:")

#emph[#text("There are far too many contributions to mathematics by Gelfand to name here, so I will ")#strong[#text("only")]#text(" mention ")#strong[#text("only")]#text(" two.")]

#text("Marco")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41784")[#strong[#text("Short News Items « Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2009")]

#text("[…] I. M. Gelfand died on Monday at the age of 96. For more about him, see here, here and here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41785")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2009")]

#text("[…] Israel Gelfand Israel Gelfand, who made profound and prolific contributions to many areas of mathematics, including functional analysis […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-41790")[#strong[#text("Israel M. Gelfand, uno de los matemáticos más importantes del s. XX, descanse en paz « Francis (th)E mule Science's News")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2009")]

#text("[…] los matemáticos y físicos, recomiendo la entrada del genial Terence Tao, “Israel Gelfand,” What’s New, 7 October, 2009. Se centra en la ecuación de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-43224")[#strong[#text("254A, Notes 3a: Eigenvalues and sums of Hermitian matrices « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("[…] for all . (Hint: use the Courant-Fischer min-max theorem, Theorem 2.) Show furthermore that the space of for which equality holds in one of the inequalities in (24) has codimension (for Hermitian matrices) or (for real symmetric matrices. Remark 5 If one takes successive minors of an Hermitian matrix , and computes their spectra, then (24) shows that this triangular array of numbers forms a pattern known as a Gelfand-Tsetlin pattern. These patterns are discussed a little more in this blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-45315")[#strong[#text("Vladimir Arnold (1937-2010). R.I.P. « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2010")]

#text("[…] Vladimir Arnold (1937-2010). R.I.P. One of the world’s greatest and most influential mathematicians, Vladimir Arnold, passed away today in Paris, France. He made major contributions, inter alia, to the fields of dynamical systems (the famous KAM (Kolmogorov-Arnold-Moser) theory) and topology (he is one of the founding fathers of symplectic topology). I hope that the prominent mathematicians like Terence Tao or Timothy Gowers will say more on their blogs about Arnold’s scientific legacy as they did for Israel Gelfand. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6830c38f05ac30e5bc2f1398dcf781f557de011be4b82e49b2b00803055a3c1b-59df4a95d0de8ea6bc7e058023bc1196f5981d79b7113b10d05e78f70929b8a7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Centenario de Israel Gelfand | :: ZTFNews.org")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-243566")[#strong[#text("Centenario de Israel Gelfand | :: ZTFNews.org")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2013")])]

#text("[…] Israel Gelfand en la página de Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6830c38f05ac30e5bc2f1398dcf781f557de011be4b82e49b2b00803055a3c1b-59df4a95d0de8ea6bc7e058023bc1196f5981d79b7113b10d05e78f70929b8a7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Israel Gelfand (1913-2009) |")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-472096")[#strong[#text("Israel Gelfand (1913-2009) |")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2016")])]

#text("[…] Israel Gelfand en la página de Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f179798e89f245675326696c3c58c8c81021c9285782d75ca22ad4c3b045f593-9c2b8a94da46b9136b70355b6d1dce7e97660457633652a1ba4a551d46e070f5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timo")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-500156")[#strong[#text("timo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2018")])]

#text("I don’t understand how you get to the equation of V(x) in terms of K (by comparing the delta components of both sides), its probably a silly misunderstanding but I would be very grateful if you could lay it out for me. Thank you very much")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-500289")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2018")])]

#text("As discussed previously, the discontinuous function ")#mi("K(t,x)")#text(" can be written as ")#mi("K(t,x) = \\tilde K(t,x) 1_{t \\leq x}")#text(", where ")#mi("\\tilde K")#text(" extends smoothly across the diagonal. Applying the differential operator ")#mi("-\\frac{\\partial^2}{\\partial t^2} + \\frac{\\partial^2}{\\partial x^2}")#text(" to this distribution then gives (after using the Leibniz rule) ")#mi("2 \\frac{\\partial \\tilde K}{\\partial x}(x,x) \\delta(t-x)")#text(" plus some smooth terms; as ")#mi("\\delta(t-x)")#text(" solves the wave equation, the left-hand side of (1) also has this form. Meanwhile, the right-hand side of (1) is equal to ")#mi("V(x) \\delta(t-x)")#text(" plus smoother terms, giving the claim.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-501031")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2018")])]

#text("Thanks for this post, Terry! Particularly for your insights into the motivations of these areas of Gelfand’s work. Timo’s question brought this blog post to my notice for the first time, as I only subscribed a few months ago.")

#text("Also, as ever, you generously answer difficulties such as Timo’s. :-)")

#text("Explanations in maths seem to fall into two styles, which I think of as “the ideas” and “the rigour”. The ideas explain why, and the rigour explains how. It’s great to start with the why! Some writers only operate at the level of technical, rigorous detail, which can leave us floundering seeking the why – shedding more darkness than light. That’s perhaps why maths is so often a mystery, even when we want to understand.")

#text("Of course, there’s a dual problem: taking the top-level ideas and translating them into technical detail. Hopefully, our “ideas” writer will sprinkle a few technical clues on how to go about that translation, as you do. Whether we can take those clues and run with them depends on our ability. But as with any translation exercise, our ability and confidence can only increase with practice.")

#text("So often, I find myself wishing for ten lifetimes, to be able to get in the practice necessary to master so many fascinating fields of mathematics! But in real life, we must decide which paths to follow and which to ignore. Do we have too many choices? Maths is truly an “embarrassment of riches”! Thanks again for sharing some of those riches with us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dd1ecd2c703d21ee8516d96efac50e4d21bb18c9053801fe55e3a1369e3337e-27f0a8d08fe1f0c0dea638c003ef91eed9201461865a60c761aa2a935bf0dff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-649538")[#strong[#text("Jonathan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2022")])]

#text("How does the GLM equation derivation (and the relationship between the scattering data B and the scattering data for the eigenfunction problem) change if the potential V supports bound states? If you could say a few words about this, I’d be very grateful. Your post on the GLM equation is the first explanation I have been able to understand. Many thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-649551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2022")])]

#text("In the presence of bound states, the wave equation formalism is no longer convenient to use because solutions that contain a bound state can grow exponentially in time (this does not violate conservation of energy, because the exponentially growing kinetic energy is balanced by the negative exponentially growing potential energy coming from the bound states), and in particular is not a tempered distribution in the time variable, which causes technical difficulties. Traditionally, one uses a spectral formalism instead, in which one takes a (formal) Fourier transform in time (or separation of variables, if you prefer) to replace the wave equation formalism by a transmission and reflection coefficient formalism (briefly alluded to in the blog post). The bound states can then be detected as poles in the transmission coefficient, and their contribution can be accounted for using the residue theorem. Perhaps this can be re-interpreted in the wave equation formalism by interpreting the contribution of bound states as resonances, by working with ")#link("https://en.wikipedia.org/wiki/Hyperfunction")[#text("hyperfunctions")]#text(" in place of tempered distributions, or by restricting attention to the orthogonal complement of the span of the bound states (which, not coincidentally, is also the maximal space on which the Gelfand-Levitan-Marchenko equation is invertible), but I have not attempted to do so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3dd1ecd2c703d21ee8516d96efac50e4d21bb18c9053801fe55e3a1369e3337e-27f0a8d08fe1f0c0dea638c003ef91eed9201461865a60c761aa2a935bf0dff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-649767")[#strong[#text("Jonathan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2022")])]

#text("I see, thanks! I guess I’m interested in this reflection and transmission coefficient formalism, then. I’d particularly like to understand what you mean when you say the bound state contributions can be accounted for using the residue theorem. Where does the residue theorem come into it? Do you happen to know of any accessible account of this, at the level of this blog post? I’m just looking for the big idea and I find myself getting bogged down in the details when I search for material on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-649768")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2022")])]

#text("This should be covered in any text on scattering and inverse scattering theory, e.g., Section 4.4 of ")#link("https://www.math.ru.nl/~koelink/edu/LM-dictaat-scattering.pdf")[#text("https://www.math.ru.nl/~koelink/edu/LM-dictaat-scattering.pdf")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/10/07/israel-gelfand/#comment-650060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2022")])]

#text("That’s a very helpful reference, thanks!")

#text("(Jonathan)")
]
]
]
]
]
