// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/
// Converted to Typst by tao2typ: "2026-10-14T15:18:52.817859+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, III: Numerical optimisation of the variational problem, and a search for new sieves")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 December 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/")[#text("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the third thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" are:")

#list(
[#text("(Maynard) Assuming the Elliott-Halberstam conjecture, ")#mi("{H_1 \\leq 12}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_1 \\leq 330}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_2 \\leq 330}")#text(".")],
[#text("(Polymath8b, tentative) ")#mi("{H_2 \\leq 484{,}126}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_4 \\leq 493{,}408}")#text(".")],
[#text("(Polymath8b) ")#mi("{H_m \\leq \\exp( 3.817 m )}")#text(" for sufficiently large ")#mi("{m}")#text(". Assuming Elliott-Halberstam, ")#mi("{H_m \\ll e^{2m} m \\log m}")#text(" for sufficiently large ")#mi("{m}")#text(".")]
)

#text("Much of the current focus of the Polymath8b project is on the quantity")

#align(center)[#tao-fit-display[#mitex("M_k = M_k({\\cal R}_k) := \\sup_F \\frac{\\sum_{m=1}^k J_k^{(m)}(F)}{I_k(F)}")]]

#text("where ")#mi("{F}")#text(" ranges over square-integrable functions on the simplex")

#align(center)[#tao-fit-display[#mitex("{\\cal R}_k := \\{ (t_1,\\ldots,t_k) \\in [0,+\\infty)^k: t_1+\\ldots+t_k \\leq 1 \\}")]]

#text("with ")#mi("{I_k, J_k^{(m)}}")#text(" being the quadratic forms")

#align(center)[#tao-fit-display[#mitex("I_k(F) := \\int_{{\\cal R}_k} F(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots dt_k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("J_k^{(m)}(F) := \\int_{{\\cal R}_{k-1}} (\\int_0^{1-\\sum_{i \\neq m} t_i} F(t_1,\\ldots,t_k)\\ dt_m)^2")]]

#align(center)[#tao-fit-display[#mitex("dt_1 \\ldots dt_{m-1} dt_{m+1} \\ldots dt_k.")]]

#text("It was shown by Maynard that one has ")#mi("{H_m \\leq H(k)}")#text(" whenever ")#mi("{M_k > 4m}")#text(", where ")#mi("{H(k)}")#text(" is the narrowest diameter of an admissible ")#mi("{k}")#text("-tuple. As discussed in the previous post, we have slight improvements to this implication, but they are currently difficult to implement, due to the need to perform high-dimensional integration. The quantity ")#mi("{M_k}")#text(" does seem however to be close to the theoretical limit of what the Selberg sieve method can achieve for implications of this type (at the Bombieri-Vinogradov level of distribution, at least); it seems of interest to explore more general sieves, although we have not yet made much progress in this direction.")

#text("The best asymptotic bounds for ")#mi("{M_k}")#text(" we have are")

#metadata(none) <tao-33c614ca3cf78827a85d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\log k - \\log\\log\\log k + O(1) \\leq M_k \\leq \\frac{k}{k-1} \\log k")]]



#text(" which we prove below the fold. The upper bound holds for all ")#mi("{k > 1}")#text("; the lower bound is only valid for sufficiently large ")#mi("{k}")#text(", and gives the upper bound ")#mi("{H_m \\ll e^{2m} \\log m}")#text(" on Elliott-Halberstam.")

#text("For small ")#mi("{k}")#text(", the upper bound is quite competitive, for instance it provides the upper bound in the best values")

#align(center)[#tao-fit-display[#mitex("1.845 \\leq M_4 \\leq 1.848")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("2.001162 \\leq M_5 \\leq 2.011797")]]

#text("we have for ")#mi("{M_4}")#text(" and ")#mi("{M_5}")#text(". The situation is a little less clear for medium values of ")#mi("{k}")#text(", for instance we have")

#align(center)[#tao-fit-display[#mitex("3.95608 \\leq M_{59} \\leq 4.148")]]

#text("and so it is not yet clear whether ")#mi("{M_{59} > 4}")#text(" (which would imply ")#mi("{H_1 \\leq 300}")#text("). See ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")[#text("this wiki page")]#text(" for some further upper and lower bounds on ")#mi("{M_k}")#text(".")

#text("The best lower bounds are not obtained through the asymptotic analysis, but rather through quadratic programming (extending the original method of Maynard). This has given significant numerical improvements to our best bounds (in particular lowering the ")#mi("{H_1}")#text(" bound from ")#mi("{600}")#text(" to ")#mi("{330}")#text("), but we have not yet been able to combine this method with the other potential improvements (enlarging the simplex, using MPZ distributional estimates, and exploiting upper bounds on two-point correlations) due to the computational difficulty involved.")

#metadata(none) <tao-98177bd51fc41626d681>

#heading(level: 1)[#strong[#text(" — 1. Upper bound — ")]]

#text("We now prove the upper bound in ")#link(<tao-33c614ca3cf78827a85d>)[#text("(1)")]#text(". The key estimate is")

#metadata(none) <tao-ae4754b6cd0217cc2db0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(\\int_0^{1-t_2-\\ldots-t_k} F(t_1,\\ldots,t_k)\\ dt_1)^2")]]





#align(center)[#tao-fit-display[#mitex("\\leq \\frac{\\log k}{k-1} \\int_0^{1-t_2-\\ldots-t_k} F(t_1,\\ldots,t_k)^2 (1 - t_1-\\ldots-t_k+ kt_1)\\ dt_1.")]]

#text("Assuming this estimate, we may integrate in ")#mi("{t_2,\\ldots,t_k}")#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("J_k^{(1)}(F) \\leq \\frac{\\log k}{k-1} \\int F^2 (1-t_1-\\ldots-t_k+kt_1)\\ dt_1 \\ldots dt_k")]]

#text("which symmetrises to")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^k J_k^{(m)}(F) \\leq k \\frac{\\log k}{k-1} \\int F^2\\ dt_1 \\ldots dt_k")]]

#text("giving the upper bound in ")#link(<tao-33c614ca3cf78827a85d>)[#text("(1)")]#text(".")

#text("It remains to prove ")#link(<tao-ae4754b6cd0217cc2db0>)[#text("(2)")]#text(". By Cauchy-Schwarz, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1-t_2-\\ldots-t_k} \\frac{dt_1}{1 - t_1-\\ldots-t_k+ kt_1} \\leq \\frac{\\log k}{k-1}.")]]

#text("But writing ")#mi("{s = t_2+\\ldots+t_k}")#text(", the left-hand side evaluates to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{k-1} (\\log k(1-s) - \\log (1-s) ) = \\frac{\\log k}{k-1}")]]

#text("as required.")

#text("This also suggests that extremal ")#mi("{F(t_1,\\ldots,t_k)}")#text(" behave like ")#mi("{\\tilde F(t_2,\\ldots,t_k) / (1-t_1-\\ldots-t_k + kt_1)}")#text(" for some function ")#mi("{\\tilde F}")#text(", and similarly for permutations. However, it is not possible to have exact equality in all variables simultaneously, which indicates that the upper bound ")#link(<tao-33c614ca3cf78827a85d>)[#text("(1)")]#text(" is not optimal, although in practice it does remarkably well for small ")#mi("{k}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Lower bound — ")]]

#text("Using the notation of ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this previous post")]#text(", we have the lower bound")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\frac{m_1^2}{m_2} {\\bf P}( X_1 + \\ldots + X_{k-1} \\leq k - T )")]]

#text("whenever ")#mi("{g}")#text(" is supported on ")#mi("{[0,T]}")#text(", ")#mi("{m_i := \\int_0^T g(t)^i\\ dt}")#text(", and ")#mi("{X_1,\\ldots,X_k}")#text(" are independent random variables on ")#mi("{[0,T]}")#text(" with density ")#mi("{\\frac{1}{m_2} g(t)^2\\ dt}")#text(". We select the function")

#align(center)[#tao-fit-display[#mitex("g(t) := \\frac{1}{1 + A t} 1_{[0,T]}(t)")]]

#text("with ")#mi("{A := \\log k}")#text(", and ")#mi("{T := \\varepsilon \\frac{k}{A}}")#text(" for some ")#mi("{0 < \\varepsilon < 1}")#text(" to be chosen later. We have")

#align(center)[#tao-fit-display[#mitex("m_1 = \\log(1+AT) = \\log( 1 + \\varepsilon k)")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("m_2  & = \\int_0^T \\frac{1}{(1+At)^2}\\ dt", block: true)



#tao-math(" & = \\frac{1}{A} - \\frac{1}{A (1+AT)}", block: true)



#tao-math(" & \\leq \\frac{1}{A} = \\log k", block: true)
]

#text("and so")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\frac{\\log^2(1+\\varepsilon k)}{\\log k} {\\bf P}( X_1 + \\ldots + X_{k-1} \\leq k - T ).")]]

#text("Observe that the random variables ")#mi("{X_i}")#text(" have mean")

#tao-aligned(keep: true)[


#tao-math("\\mu  & = \\frac{1}{m_2} \\frac{1}{A^2} (\\log(1+AT)-1+\\frac{1}{1+AT})", block: true)



#tao-math(" & = (A + \\frac{1}{\\varepsilon k}) (\\log(1+\\varepsilon k)-1+\\frac{1}{1+\\varepsilon k})", block: true)



#tao-math(" & \\leq 1 - \\frac{1}{\\log k} + O( \\frac{\\log k}{\\varepsilon k} ).", block: true)
]

#text("The variance ")#mi("{ \\sigma^2}")#text(" may be bounded crudely by")

#tao-aligned(keep: true)[


#tao-math("\\sigma^2  & \\leq \\frac{1}{m_2} \\int_0^T \\frac{t^2}{(1+At)^2}\\ dt", block: true)



#tao-math(" & = O( A \\frac{T}{A^2} ) = O( \\frac{\\varepsilon k}{\\log^2 k} ).", block: true)
]

#text("Thus the random variable ")#mi("{X_1 + \\ldots + X_{k-1}}")#text(" has mean at most ")#mi("{k - \\frac{k}{\\log k} + O( \\frac{\\log k}{\\varepsilon} )}")#text(" and variance ")#mi("{O( \\frac{\\varepsilon k^2}{\\log^2 k} )}")#text(", with each variable bounded in magnitude by ")#mi("{T = \\frac{\\varepsilon k}{\\log k}}")#text(". By ")#link("http://en.wikipedia.org/wiki/Hoeffding's_inequality")[#text("Hoeffding’s inequality")]#text(", this implies that ")#mi("{X_1 + \\ldots + X_{k-1}}")#text(" is at least ")#mi("{ k - T}")#text(" with probability at most ")#mi("{O( \\exp(- c / \\varepsilon^2 )}")#text(" for some absolute constant ")#mi("{c}")#text(". If we set ")#mi("{ \\varepsilon := C / (\\log \\log k)^{1/2}}")#text(" for a sufficiently large absolute constant ")#mi("{C}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X_1 + \\ldots + X_{k-1} \\leq k - T ) = 1 - O( 1 / \\log k)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\log k - \\log\\log\\log k + O(1)")]]

#text("giving the lower bound in ")#link(<tao-33c614ca3cf78827a85d>)[#text("(1)")]#text(".")

#text("Hoeffding’s bound is proven by the exponential moment method, which more generally gives the bound")

#align(center)[#tao-fit-display[#mitex("M_k \\geq \\frac{m_1^2}{m_2} (1 - e^{-s(k-T)} (\\frac{1}{m_2} \\int_0^T g(t)^2 e^{st}\\ dt)^{k-1} )")]]

#text("for any ")#mi("{s > 0}")#text(". However, this bound is inferior to the linear algebra method for small ")#mi("{k}")#text("; for instance, we can only obtain ")#mi("{DHL[k,2]}")#text(" for ")#mi("{k=339}")#text(" by this method (compared to ")#mi("{k=64}")#text(" from quadratic programming), even if one uses the best available MPZ estimate.")

#text("Using ")#mi("{MPZ[\\varpi,\\delta]}")#text(", one can modify this lower bound, obtaining ")#mi("{DHL[k_0,m+1]}")#text(" whenever we can find ")#mi("{\\varpi, \\delta, A, T, s, s^{\\prime}}")#text(" obeying")

#align(center)[#tao-fit-display[#mitex("\\frac{m_1^2}{m_2} ( 1 - \\kappa_1 - \\kappa_2 ) > \\frac{m}{1/4+\\varpi}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\kappa_1 := e^{-s(k-T)} (\\frac{1}{m_2}\\int_0^T e^{st} g(t)^2\\ dt)^{k-1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\kappa_2 := e^{s^{\\prime} \\theta k} (\\frac{1}{m_2}\\int_0^{\\tilde \\delta k} e^{-s^{\\prime}t} g(t)^2\\ dt)^{k-1}")]]

#text("with")

#tao-aligned(keep: true)[


#tao-math("\\tilde \\delta^{\\prime}  & := \\frac{T}{k}", block: true)



#tao-math("\\delta^{\\prime}  & = \\tilde \\delta^{\\prime} (\\frac{1}{4}+\\varpi)", block: true)



#tao-math("\\tilde \\delta  & := \\frac{\\delta}{1/4+\\varpi}.", block: true)



#tao-math("\\theta  & := \\frac{i(\\delta^{\\prime}-\\delta)/2 + \\varpi}{1/4+\\varpi}", block: true)



#tao-math(" & = i (\\tilde \\delta^{\\prime} - \\tilde \\delta)/2 + \\frac{\\varpi}{1/4+\\varpi}.", block: true)
]

#text("Details can be found at ")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-254848")[#text("this comment")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Quadratic programming — ")]]

#text("The expressions ")#mi("{\\sum_{m=1}^k J_k^{(m)}(F)}")#text(", ")#mi("{I_k(F)}")#text(" are quadratic forms in ")#mi("{F}")#text(", so one can (in principle, at least) obtain lower bounds for ")#mi("{M_k}")#text(" by restricting to a finite-dimensional space of ")#mi("{F}")#text(" and performing quadratic programming on the resulting finite-dimensional quadratic forms.")

#text("One can take ")#mi("{F}")#text(" to be symmetric without loss of generality. One can then look at functions ")#mi("{F}")#text(" that are linear combinations of symmetric polynomials")

#align(center)[#tao-fit-display[#mitex("m(\\alpha) = \\sum_{\\sigma \\in S_k} x_{\\sigma(1)}^{\\alpha_1} \\ldots x_{\\sigma(k)}^{\\alpha_k}")]]

#text("for various signatures ")#mi("{\\alpha_1,\\alpha_2,\\ldots}")#text("; actually it turns out numerically that one can get more efficient results by working with combinations of ")#mi("{m(\\alpha)}")#text(" for ")#mi("{\\alpha}")#text(" up to a fixed degree, and ")#mi("{(1-P_1)^a m(\\alpha)}")#text(" for ")#mi("{\\alpha}")#text(" at that degree afterwords, where ")#mi("{P_1(x_1,\\ldots,x_k) = x_1+\\ldots+x_k}")#text(" is the first symmetric polynomial. (Note that the GPY type sieves come from the case when ")#mi("{F}")#text(" is purely a function of ")#mi("{P_1}")#text(".)")

#text("It may be that other choices of bases here are more efficient still (perhaps choosing bases that reflect the belief that ")#mi("{F}")#text(" should behave something like ")#mi("{\\prod_{i=1}^k \\frac{1}{1+A k^{1/2} t_i}}")#text(" for some smallish ")#mi("{A}")#text("), but one numerical obstacle is that we are only able to accurately compute the required coefficients for ")#mi("{J_k^{(m)}(F), I_k(F)}")#text(" in the case of polynomials.")

#heading(level: 1)[#text("Comments (154)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255961")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("A couple of minor typos in the bulleted list of bounds: I think ")#mi("H_2 \\le 330")#text(" should be ")#mi("H_1\\le 330")#text(" and ")#mi("H_4\\le 493,408")#text(" should be ")#mi("H_2\\le 493,408")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Actually, the Elliott-Halberstam conjecture essentially allows us to double the value of ")#mi("m")#text(" for any bound previously obtained using only the Bombieri-Vinogradov theorem (such as the bound ")#mi("H_2 \\leq 493,408")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255962")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("This doesn’t directly help the numerical optimisation, but here is an alternate way to compute the integrals of polynomials on the simplex ")#mi("{\\cal R}_k")#text(", giving a slightly different way to establish Lemma 7.1 from Maynard’s paper. The starting point is the identity")

#mi("\\displaystyle \\int_{t_1,\\ldots,t_k \\geq 0} e^{-t_1-\\ldots-t_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots dt_k")

#mi("\\displaystyle = \\int_0^\\infty e^{-t} \\int_{t {\\cal R}_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots dt_k")

#text("which is a simple application of Fubini’s theorem. If F is homogeneous of degree d, then")

#mi("\\displaystyle \\int_{t {\\cal R}_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots t_k = t^{k+d} \\int_{{\\cal R}_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots dt_k;")

#text("from the Gamma function identity ")#mi("\\int_0^\\infty e^{-t} t^{k+d}\\ dt = (k+d)!")#text(", we thus see that")

#mi("\\displaystyle \\int_{t_1,\\ldots,t_k \\geq 0} e^{-t_1-\\ldots-t_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots dt_k")

#mi("\\displaystyle = (d+k)! \\int_{{\\cal R}_k} F(t_1,\\ldots,t_k)\\ dt_1 \\ldots dt_k.")

#text("Now, from the gamma function identity again we have")

#mi("\\displaystyle \\int_{t_1,\\ldots,t_k \\geq 0} e^{-t_1-\\ldots-t_k} t_1^{a_1} \\ldots t_k^{a_k}\\ dt_1 \\ldots dt_k = a_1! \\ldots a_k!")

#text("and thus")

#mi("\\displaystyle \\int_{{\\cal R}_k} t_1^{a_1} \\ldots t_k^{a_k}\\ dt_1 \\ldots t_k = \\frac{a_1! \\ldots a_k!}{(k+a_1+\\ldots+a_k)!}.")

#text("Replacing k with ")#mi("k+1")#text(", and then performing the ")#mi("t_{k+1}")#text(" integral, one also has the generalisation")

#mi("\\displaystyle \\int_{{\\cal R}_k} t_1^{a_1} \\ldots t_k^{a_k} (1-t_1-\\ldots-t_k)^{a_{k+1}}\\ dt_1 \\ldots dt_k = \\frac{a_1! \\ldots a_{k+1}!}{(k+a_1+\\ldots+a_{k+1})!}")

#text("which is equation (7.4) in Maynard’s paper.")

#text("This calculation suggests that Laplace transforms in the ")#mi("t_i")#text(" variables may possibly be useful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255965")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("I’ve been experimenting with the problem of optimising a sieve, to get some sense as to how sharp the Selberg sieve is. A model problem is the following: suppose one has a non-negative sequence ")#mi("a_n")#text(" for which one has the exact bounds")

#mi("\\sum_{n: d|n} a_n = g(d) X")

#text("for all ")#mi("d \\leq R")#text(" and some multiplicative function ")#mi("g(d)")#text(" taking values in [0,1] and some quantity ")#mi("X")#text(" (in practice there are error terms also, but I will ignore them here). Let ")#mi("P")#text(" be the product of some finite number of primes. What is the best upper bound ")#mi("\\alpha X")#text(" one can then place on the quantity")

#mi("\\sum_{n: (n,P) = 1} a_n")#text("?")

#text("(This isn’t quite the sieve problem that is of interest when trying to go beyond the Selberg sieve to prove results of the form DHL[k,m+1], but it is a much more well-studied problem and is perhaps a place to start first.)")

#text("By the Hahn-Banach theorem, ")#mi("\\alpha")#text(" is also the minimal value of the quotient")

#mi("\\sum_{d \\leq R} \\lambda_d g(d) / \\lambda_1")

#text("subject to the constraint that ")#mi("\\sum_{d|n; d \\leq R} \\lambda_d \\geq 0")#text(" for all ")#mi("n")#text(" (and that ")#mi("\\lambda_1")#text(" is non-zero, of course).")

#text("Another equivalent definition of ")#mi("\\alpha")#text(" is that it is the maximal value of ")#mi("{\\bf P} ( \\overline{\\bigvee_{p|P} E_p} )")#text(", if ")#mi("E_p")#text(" are events in a probability space such that")

#mi("{\\bf P} ( \\bigwedge_{p|d} E_p ) = g(d)")

#text("for all ")#mi("d \\leq R")#text(". For instance, by taking the ")#mi("E_p")#text(" to be independent events of probability ")#mi("g(p)")#text(", we obtain the lower bound")

#mi("\\alpha \\geq \\prod_{p|P} (1-g(p))")#text(". (1)")

#text("The Selberg sieve, in contrast, gives the upper bound")

#mi("\\alpha \\leq (\\sum_{d|P: d \\leq \\sqrt{R}} h(d))^{-1}")

#text("where ")#mi("h(d) = \\prod_{p|d} \\frac{g(p)}{1-g(p)}")#text(". For comparison, (1) can be rewritten as")

#mi("\\alpha \\geq (\\sum_{d|P} h(d))^{-1}")#text(".")

#text("But the Selberg sieve is not always optimal; for instance, when ")#mi("P")#text(" is a product of many small primes then often the beta sieve is superior (and in the model one-dimensional case when ")#mi("g(p) = \\frac{1+o(1)}{p}")#text(", the beta sieve in fact gives asymptotically optimal results).")

#text("I’ve started playing around with a model case when the primes dividing P are very close to each other, and ")#mi("g(p)")#text(" is basically constant, ")#mi("g(p) \\approx k/p")#text(" for some fixed ")#mi("k")#text(", where the question simplifies to a low-dimensional linear programming problem, with the intent of understanding the precise strength of the Selberg sieve in this particular setting. The situation is then as follows: if we have events ")#mi("E_1,\\ldots,E_N")#text(" for some large ")#mi("N")#text(" with the bounds")

#mi("{\\bf P}( E_{i_1} \\wedge \\ldots \\wedge E_{i_d} ) = \\frac{k^d}{N^d}")

#text("for all ")#mi("d \\leq d_0")#text(" and ")#mi("1 \\leq i_1 < \\ldots < i_d \\leq N")#text(", what is the best upper bound ")#mi("\\alpha( k, d_0 )")#text(" on")

#mi("{\\bf P}( \\overline{E_1 \\vee \\ldots \\vee E_N} )")

#text("in the asymptotic limit ")#mi("N \\to \\infty")#text("? There are some interesting combinatorics emerging here and I might detail them in a future post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255984")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Some preliminary computations for the ")#mi("\\alpha(k,d_0)")#text(" problem mentioned previously, where ")#mi("k \\geq 0")#text(" is real and ")#mi("d_0 \\geq 1")#text(" is a natural number:")

#text("The lower bound (1) becomes ")#mi("\\alpha(k,d_0) \\geq \\exp(-k)")#text(". The Selberg sieve upper bound is")

#mi("\\alpha(k,d_0) \\leq ( \\sum_{j \\leq d_0/2} \\frac{k^j}{j!} )^{-1}")#text(".")

#text("The Bonferroni inequalities give")

#mi("\\alpha(k,d_0) \\leq \\sum_{j \\leq d} (-1)^j \\frac{k^j}{j!}")

#text("whenever ")#mi("d \\leq d_0")#text(" is even. When ")#mi("k \\leq 1")#text(" and ")#mi("d")#text(" is the largest even number less than or equal to ")#mi("d_0")#text(", I can show that this is in fact an equality, by explicitly constructing events ")#mi("E_i")#text(".")

#text("One can also define ")#mi("\\alpha(k,d_0)")#text(" to be the infimal value of ")#mi("\\sum_{d \\leq d_0} \\frac{\\lambda_d k^d}{d!} / \\lambda_1")#text(" subject to the constraints ")#mi("\\sum_{d \\leq n} \\binom{n}{d} \\lambda_d \\geq 0")#text(" for all ")#mi("n")#text("; it is also the supremal value of ")#mi("p_0")#text(" whenever ")#mi("p_0,p_1,\\ldots")#text(" are non-negative numbers obeying the constraints ")#mi("\\sum_{n \\geq d} \\frac{1}{(n-d)!} p_n = k^d")#text(" for all ")#mi("d \\leq d_0")#text(". Unlike the general sieve problem, there is so much symmetry here that the linear programming problem can actually be solved exactly for small values of ")#mi("d_0")#text(".")

#text("The first non-trivial value of ")#mi("d_0")#text(" is ")#mi("d_0=2")#text(": here we have ")#mi("{\\bf P}(E_i) = k/N")#text(" and ")#mi("{\\bf P}(E_i \\wedge E_j ) = k^2 / N^2")#text(", and want an asymptotic upper bound for ")#mi("P( \\overline{E_1 \\vee \\ldots \\vee E_N} )")#text(". It turns out that the exact value can be computed here as")

#mi("\\alpha(k,2) = 1 - \\frac{2}{n+1} k + \\frac{1}{n(n+1)} k^2")

#text("whenever ")#mi("n \\geq 1")#text(" is a natural number and ")#mi("n-1 \\leq k \\leq n")#text(". Thus for instance the Bonferroni bound")

#mi("\\alpha(k,2) = 1 - k + \\frac{1}{2} k^2")

#text("is sharp for ")#mi("0 \\leq k \\leq 1")#text(", then we have")

#mi("\\alpha(k,2) = 1 - \\frac{2}{3} k + \\frac{1}{6} k^2")

#text("for ")#mi("1 \\leq k \\leq 2")#text(", and so forth. The Selberg sieve bound is")

#mi("\\alpha(k,2) \\leq \\frac{1}{k+1}")

#text("which happens to be sharp exactly when ")#mi("k")#text(" is a natural number – so in this case the Selberg sieve is fairly efficient. This latter bound can also be seen by observing that the counting random variable ")#mi("X := \\sum_i 1_{E_i}")#text(" has mean ")#mi("k")#text(" and second moment ")#mi("{\\bf E} X^2 = k + k^2 + o(1)")#text(", so that it has to be non-zero on an event of probability at least ")#mi("1-\\frac{1}{k+1}+o(1)")#text(" by the Cauchy-Schwarz inequality.")

#text("The ")#mi("d_0=3")#text(" situation appears to be almost identical with the ")#mi("d_0=2")#text(" situation, though I haven’t nailed this down completely. The ")#mi("d_0=4")#text(" case may be more interesting; I suspect here that the Selberg sieve bound ")#mi("\\alpha(k,4) \\leq \\frac{1}{1+k+k^2/2}")#text(" is now inefficient, although I don’t know for sure yet. This is quite an oversimplified problem compared to our true sieve problem, but may help shed some light on that problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("I confirmed that the ")#mi("d_0=3")#text(" numerology is identical to the ")#mi("d_0=4")#text(" numerology. For the ")#mi("d_0=4")#text(" case, the Selberg sieve bound ")#mi("\\alpha(k,4) \\leq (1+k+\\frac{k^2}{2})^{-1}")#text(" can be derived as follows. For a random variable of mean zero and variance 1, one has the bound ")#mi("{\\bf E} X^4 - ({\\bf E} X^3)^2 - 1 \\geq 0")#text(" relating the third and fourth moments, which arises from the Selberg-sieve type manipulation of starting with the trivial inequality ")#mi("{\\bf E} (X^2+aX+b)^2 \\geq 0")#text(" and then optimising in a and b. In our situation, the counting function ")#mi("X := \\sum_i 1_{E_i}")#text(" has falling moments ")#mi("{\\bf E} X (X-1) \\ldots (X-i) = k^i")#text(" for ")#mi("i=0,\\ldots,4")#text(", or equivalently ")#mi("{\\bf E} X^i = \\sum_{j=0}^i S(i,j) k^j")#text(" where the ")#mi("S(i,j)")#text(" are Stirling numbers of the second kind. Conditioning onto the event where ")#mi("X")#text(" is non-zero, normalising to have mean zero and unit variance, and using the previous inequality, one obtains (as I verified in Maple) the bound ")#mi("\\alpha(k,4) \\leq (1+k+\\frac{k^2}{2})^{-1}")#text(".")

#text("The inequality ")#mi("{\\bf E} X^4 - ({\\bf E} X^3)^2 - 1 \\geq 0")#text(" is sharp if and only if X takes at most two values; thus the Selberg sieve is sharp exactly when X takes at most two non-zero values. But I believe I can show by hand that this cannot actually occur for the situation at hand, and so the Selberg bound is never sharp in this case. However, I don’t yet know of an easy way to improve the bound (although in the ")#mi("d_0=4")#text(" case, brute force computation should eventually give the optimal bounds).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Actually, it turns out that in some cases (specifically, when ")#mi("k=j(j+1)")#text(" for some natural number ")#mi("j")#text(") it is possible for ")#mi("X")#text(" to take precisely two non-zero values, in which case the Selberg sieve bound ")#mi("\\alpha(k,4) \\leq (1+k+\\frac{k^2}{2})^{-1}")#text(" is indeed sharp. (For instance, when ")#mi("k=2")#text(", one can concoct a scenario in which ")#mi("X")#text(" takes the value 0 with probability 1/5, 2 with probability 2/3, and 5 with probability 2/15, and the Selberg sieve bound is sharp in this case.)")

#text("Similar scenarios are possible for larger ")#mi("d_0")#text("; in principle, the Selberg sieve bound is sharp if ")#mi("X")#text(" takes precisely ")#mi("d_0/2")#text(" non-zero values, although it becomes difficult to ensure that these values are all natural numbers. But the Selberg sieve nevertheless performs substantially better than I had expected on this model problem, which is perhaps a hint that one cannot hope to do much better than that sieve for the bounded gaps problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256523")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("I found a way to convert the general sieve problem into a Selberg-type problem, by taking advantage of the positivstellensatz of Putinar. Among other things, this theorem asserts that a polynomial of n variables ")#mi("Q(x) = Q(x_1,\\ldots,x_n)")#text(" is non-negative on the cube ")#mi("[0,1]^n")#text(" if and only if it is the sum of polynomials of the form ")#mi("x_i R(x)^2")#text(" and ")#mi("(1-x_i) R(x)^2")#text(" for various polynomials ")#mi("R")#text(" (but with the caveat that R can have degree larger than that of Q, due to cancellation).")

#text("Anyway, the sieve problem is to minimise ")#mi("\\sum_{d|P} \\lambda_d g(d)")#text(" for ")#mi("\\lambda_d")#text(" supported on ")#mi("d \\leq R")#text(", given that ")#mi("\\lambda_1 = 1")#text(" and ")#mi("\\sum_{d|n; d|P} \\lambda_d \\geq 0")#text(". Writing ")#mi("P = p_1 \\ldots p_n")#text(" and introducing the n-variate polynomial")

#mi("Q(x_1,\\ldots,x_n) := \\sum_{d|P} \\lambda_d \\prod_{i: p_i|d} x_i")

#text("we see that we are trying to minimise the linear functional")

#mi("\\sum_{x \\in \\{0,1\\}^n} Q(x) \\prod_{i=1}^n ((1-g(p_i))(1-x_i) + g(p_i) x_i)")#text(" (*)")

#text("subject to the constraints that Q is non-negative on the corners ")#mi("\\{0,1\\}^n")#text(" of the cube with ")#mi("Q(0)=1")#text(", and only involves monomials ")#mi("x_{i_1} \\ldots x_{i_k}")#text(" with ")#mi("p_{i_1} \\ldots p_{i_k} \\leq R")#text(". Since ")#mi("x_i^2 = x_i")#text(" on the corners of the cube, one can extend these monomials to ")#mi("x_{i_1}^{a_i} \\ldots x_{i_k}^{a_k}")#text(" for arbitrary ")#mi("a_1,\\ldots,a_k \\geq 0")#text(". By adding large positive multiples of ")#mi("x_i(1-x_i)")#text(" to Q, we may then assume that Q is non-negative on the entire unit cube ")#mi("[0,1]^n")#text(", not just on the corners.")

#text("One can then use the positivstellensatz to replace the non-negativity of Q with a sum-of-squares representation")

#mi("Q = \\sum_i \\sum_j x_i R_{i,j}(x)^2 + (1-x_i) S_{i,j}(x)^2")

#text("and one is now trying to minimise (*) subject to the linear constraints that Q(0)=1 and that all ")#mi("x_{i_1}^{a_i} \\ldots x_{i_k}^{a_k}")#text(" coefficients of Q with ")#mi("p_{i_1} \\ldots p_{i_k} > R")#text(" vanish. In principle this is a Selberg-type optimisation problem – the Selberg case corresponds to the case when Q is a single square, ")#mi("Q = R^2")#text(". Unfortunately the degrees of the ")#mi("R_{i,j}, S_{i,j}")#text(" can be large, as can the number of ")#mi("R_{i,j}, Q_{i,j}")#text(" involved (I think it can be something like ")#mi("2^n")#text("). But it suggests a way to go a little bit beyond the Selberg case, for instance replacing Selberg sieves")

#mi("(\\sum_{d|n} \\alpha_d)^2")

#text("(where ")#mi("d")#text(" has to be restricted to be at most ")#mi("\\sqrt{R}")#text(") with slightly more general sieves such as")

#mi("\\sum_p 1_{p|n} (\\sum_{d|n} \\alpha_{d,p})^2 + (1-1_{p|n}) (\\sum_{d|n} \\beta_{d,p})^2")

#text("for coefficients ")#mi("\\alpha_{d,p}, \\beta_{d,p}")#text(" which are arbitrary except for the linear constraint that the net coefficient of ")#mi("1_{d|n}")#text(" in the final sum vanishes for ")#mi("d>R")#text(". But it’s not yet clear to me whether this leads to a substantial improvement in the Selberg sieve numerology (from the toy cases in previous comments, there are already a lot of cases when Selberg is basically sharp already).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Here is a slight modification of the above scheme, adapted for our current sieve problem. For sake of concreteness let us take k=3 (with the tuple (0,2,6)) and assume EH. Right now, we are working with sieves of the form")

#mi("\\nu(n) = (\\sum_{d_1|n; d_2|n+2; d_3|n+6} \\lambda_{d_1,d_2,d_3})^2")

#text("for some weights ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" which we are free to choose, as long as ")#mi("d_1 d_2 d_3 \\leq x^{1/2-\\varepsilon}")#text(" (actually we can stretch this a bit to the region ")#mi("d_1 d_2, d_2 d_3, d_3 d_1 \\leq x^{1/2-\\varepsilon}")#text(", which corresponds to the enlarged region ")#mi("{\\cal R}_3")#text(", but let us ignore this enlargement for now). One possible generalisation of the above sieve is to")

#mi("\\nu(n) = (1 - \\sum_{p|n: p < x^{\\sigma}} \\frac{\\log p}{\\log x}) (\\sum_{d_1|n; d_2|n+2; d_3|n+6} \\lambda_{d_1,d_2,d_3})^2")#linebreak()#text(" ")#mi("+ (\\sum_{p|n: p < x^{\\sigma}} \\frac{\\log p}{\\log x}) (\\sum_{d_1|n; d_2|n+2; d_3|n+6} \\lambda^{\\prime}_{d_1,d_2,d_3})^2")

#text("where ")#mi("0 < \\sigma < 1/2")#text(" is a parameter one can optimise in, and ")#mi("\\lambda^{\\prime}_{d_1,d_2,d_3}")#text(" obeys the same support conditions as ")#mi("\\lambda_{d_1,d_2,d_3}")#text(", and also agrees with ")#mi("\\lambda_{d_1,d_2,d_3}")#text(" for ")#mi("d_1 d_2 d_3 \\geq x^{1/2-\\sigma-\\varepsilon}")#text(". Note that the expression ")#mi("1 - \\sum_{p|n: o < x^\\sigma} \\frac{\\log p}{\\log x}")#text(" is non-negative for ")#mi("n \\leq x")#text(", so ")#mi("\\nu")#text(" remains non-negative, and note that when one expands out ")#mi("\\nu")#text(" as a divisor sum, one only obtains terms ")#mi("1_{d|n}")#text(" with ")#mi("d \\leq x^{1-\\varepsilon}")#text(" (all larger values of ")#mi("d")#text(" end up cancelling each other out). So one can still use EH to control error terms here.")

#text("In the case when ")#mi("\\lambda=\\lambda^{\\prime}")#text(", this new sieve collapses to the old Selberg sieve. But hopefully the extra flexibility here allows us to improve the quadratic optimisation problem. One can also play with other variants of the above scheme of course.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("I’ve been trying to see if this new sieve actually improves the values of ")#mi("M_k, M^{\\prime}_k")#text(", etc. over the existing theoretical optimal values, but the results are frustratingly inconclusive: for model problems, no gain occurs, and for the original problem, the Selberg sieve is a stationary point of the optimisation problem, but it is still not clear whether it is a global extremum.")

#text("To focus the discussion, let us look at the problem of bounding the number of ")#mi("n \\leq x")#text(" such that ")#mi("n, n+2, n+6")#text(" are all prime. Hardy-Littlewood predicts an asymptotic ")#mi("(1+o(1)) {\\mathfrak G} \\frac{x}{\\log^3 x}")#text(" for this quantity, but the best upper bounds we can get are only within a large constant of this. For instance, by using a Selberg sieve")

#mi("\\nu(n) = \\nu_F(n) := (\\sum_{d_1|n, d_2|n+2,d_3|n+6} \\mu(d_1d_2d_3)")#linebreak()#text(" ")#mi("F(\\frac{\\log d_1}{\\log x}, \\ldots, \\frac{\\log d_3}{\\log x})^2")

#text("for ")#mi("F")#text(" smooth and supported on the interior of the simplex ")#mi("\\frac{1}{2} \\cdot {\\cal R}_3 = \\{ (t_1,t_2,t_3) \\in [0,1]^3: t_1+t_2+t_3 \\leq \\frac{1}{2} \\}")#text(", we get an upper bound of ")#mi("(C+o(1)) {\\mathfrak G} \\frac{x}{\\log^3 x}")#text(" where")

#mi("C := \\frac{\\int F_{123}(t_1,t_2,t_3)^2\\ dt_1 dt_2 dt_3}{F(0,0,0)^2}.")

#text("Writing ")#mi("F(0,0,0)= \\int F_{123}(t_1,t_2,t_3)\\ dt_1 dt_2 dt_3")#text(" and using Cauchy-Schwarz, we see that the best value of C is 48 (the reciprocal of the volume of the simplex ")#mi("\\frac{1}{2} \\cdot {\\cal R}_3")#text("), attained when ")#mi("F_{123}")#text(" is the indicator function of the simplex (in practice one has to infinitesimally smooth this a bit). (One can do a bit better than this by using distribution theorems on the primes; using Bombieri-Vinogradov I think we can lower C to 32, and on Elliott-Halberstam I think we can get 8, but let me ignore these directions here for simplicity.)")

#text("Now let us try a modified sieve")

#mi("\\nu^{\\prime}(n) = (1 - \\sum_{p \\leq x^{1/2}: p|n} \\frac{\\log p}{\\log x}) \\nu_F(n) + \\sum_{p \\leq x^{1/2}: p|n} \\nu_{F_p}(n)")

#text("where F is as before, and for each ")#mi("p \\leq x^{1/2}")#text(", ")#mi("F_p")#text(" has the same support properties as F with ")#mi("F_p(t_1,t_2,t_3)=F(t_1,t_2,t_3)")#text(" for ")#mi("t_1+t_2+t_3 \\geq \\frac{1}{2} - \\frac{\\log p}{\\log x}")#text(". This sieve is still non-negative for ")#mi("n \\leq x")#text(", and one can still calculate ")#mi("\\sum_{n \\leq x} \\nu^{\\prime}(n)")#text(": indeed the numerator of C is adjusted from ")#mi("\\int F_{123}(t_1,t_2,t_3)^2\\ dt_1 dt_2 dt_3")#text(" to")

#mi("\\int F_{123}^2 + \\frac{1}{\\log x} \\sum_{p \\leq x^{1/2}} \\frac{\\log p}{p}")#linebreak()#text(" ")#mi("[(\\Delta_{\\log p/\\log x}^1 (F_p)_{123})^2 -  (\\Delta_{\\log p/\\log x}^1 F_{123})^2]\\ dt_1 dt_2 dt_3")

#text("where ")#mi("\\Delta_u^1 F(t_1,t_2,t_3) := F(t_1,t_2,t_3) - F(t_1+u,t_2,t_3)")#text(". The summand vanishes when ")#mi("x+y+z \\geq \\frac{1}{2}-\\frac{\\log p}{\\log x}")#text(", and one can make ")#mi("\\Delta_{\\log p/\\log x}^1 (F_p)_{123}")#text(" vanish for ")#mi("x+y+z < \\frac{1}{2} - \\frac{\\log p}{\\log x}")#text(", and then by using Mertens' theorem, C gets reduced to")

#mi("\\int F_{123}^2\\ dt_1 dt_2 dt_3 - \\int_{u+t_1+t_2+t_3 \\leq 1/2} \\Delta_u^1 F_{123}^2\\ dt_1 dt_2 dt_3 du")#text(". (*)")

#text("At first glance it looks like this is a strict improvement, as we have subtracted a new non-negative term from C. However, this new term vanishes when F is the previous extremiser (when ")#mi("F_{123}")#text(" is the indicator of ")#mi("\\frac{1}{2} \\cdot {\\cal R}_3")#text("); furthermore, using the identity")

#mi("\\int_{u+t_1+t_2+t_3 \\leq 1/2} \\Delta_u^1 F_{123}^2\\ dt_1 dt_2 dt_3 du")#linebreak()#text(" ")#mi("= (1/2-t_2-t_3) \\int F_{123}^2\\ dt_1 t_2 t_3 - \\int F_{23}^2(0,t_2,t_3)\\ dt_2 dt_3")

#text("and some Cauchy-Schwarz, one can lower bound (*) by")

#mi("\\int \\frac{1}{1/2-t_2-t_3} F_{23}^2(0,t_2,t_3)\\ dt_2 dt_3")

#text("and by some further Cauchy-Schwarz, we get exactly the same extremum C=48 for C as before. So unfortunately in this model problem at least, the new sieve doesn't move the needle as far as bounds is concerned. However the analysis for the prime gaps problem is substantially more complicated, and I can't tell whether the extra flexibility here actually improves the global extremum; all I can say so far is that the previous extremiser remains a critical point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-326980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2014")])]

#text("It seems that ")#link("http://arxiv.org/abs/1405.0682")[#text("this preprint")]#text(" is related to the problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255986")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("Incidentally, the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" suggests that ")#mi("M_k > 8")#text(" could occur for k as low as 2973, which is a significant improvement over the value of 43,134 we currently have. Given how tight the upper bound is for small k (and for k=5 it is ridiculously tight – I would like to understand how that is so better) this suggests that there is quite a bit of room to improve our m=2 analysis. One idea I had was to replace the Cauchy-Schwarz inequality with its defect version (the ")#link("http://en.wikipedia.org/wiki/Lagrange_identity")[#text("Lagrange identity")]#text(") and then try to obtain upper bounds on the defect ")#mi("\\frac{k}{k-1}\\log k - M_k")#text(", which may be more efficient than just crudely obtaining lower bounds on ")#mi("M_k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256041")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("This difference seems to be ")#mi("o(1)")#text(" (or even ")#mi("O(1/k)")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-255995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Typographical comment: If you wrap the comma, used as ‘1000-separator’ in a large number, in curly braces, the space after the comma disappears, as it should; “")#mi("484,126")#text("” –> “")#mi("484{,}126")#text("”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256010")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("There is a typo in the upper bound for ")#mi("M_5")#text(" above (it should be ")#mi("2.011797...")#text(").")

#emph[#text("[Corrected, thanks! This helps explains why the M_5 bounds were suspiciously tight; they’re still quite good, but not unbelievably so any more… -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256012")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("In order to give a precise generalized definition for ")#mi("M_k(D)")#text(" for a domain ")#mi("D")#text(" (not necessarily ")#mi("\\mathcal R_k")#text("), it is not sufficiently clear how to define the inner integral in the expression for ")#mi("J_k^{(m)}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256101")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("True, but this can be done for the domain ")#mi("\\mathcal{R}_k^{\\prime}")#text(" defined in Maynard’s preprint. I wonder if there are some nice functions ")#mi("F")#text(" (which can take the place of our monomial symmetric polynomials) for which ")#mi("\\int_{\\mathcal{R}_k^{\\prime}} F(t_1,\\ldots, t_k)\\ dt_1\\ldots dt_k")#text(" is easily computed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Well, ")#mi("{\\cal R}^{\\prime}_k")#text(" is the union (up to measure zero sets) of ")#mi("k")#text(" pieces, all of which are reflections of")

#mi("\\displaystyle \\{ (t_1,\\ldots,t_k): t_k,\\ldots,t_2 \\geq t_1 \\geq 0; t_2 + \\ldots + t_k \\leq 1 \\}")

#text("or equivalently (after setting ")#mi("t_1 := \\frac{s_1}{k-1}")#text(" and ")#mi("t_i := \\frac{s_1}{k-1} + s_i")#text(" for ")#mi("i=2,\\ldots,k")#text(")")

#mi("\\displaystyle \\{ (\\frac{s_1}{k-1},\\frac{s_1}{k-1}+s_2,\\ldots,\\frac{s_1}{k-1}+s_k): (s_1,\\ldots,s_k) \\in {\\cal R}_k \\}")

#text("and so for symmetric F we have")

#mi("\\displaystyle \\int_{{\\cal R}^{\\prime}_k} F = \\frac{k}{k-1} \\int_{{\\cal R}_k} F( \\frac{s_1}{k-1}, \\frac{s_1}{k-1}+s_2,\\ldots,\\frac{s_1}{k-1}+s_k)\\ ds_1 \\ldots ds_k")#text(".")

#text("In principle, this means that we may integrate on ")#mi("{\\cal R}^{\\prime}_k")#text(" using the existing integration formulae on ")#mi("{\\cal R}_k")#text(" (symmetrising the integrand on the RHS if desired). For instance")

#mi("\\displaystyle \\int_{{\\cal R}^{\\prime}_k} 1 = \\frac{k}{k-1} \\frac{1}{k!}")

#text("and")

#mi("\\displaystyle \\int_{{\\cal R}^{\\prime}_k} P_1 = \\frac{k^2-k+1}{(k-1)^2} \\frac{k}{(k+1)!}")

#text("(I think). The formulae get a bit more complicated beyond this, but look computable.")

#text("[EDIT: On the other hand, the functionals ")#mi("J^{(m)}_k(F)")#text(" are a little bit tricky to compute here; will have to think about this a bit more.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256158")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("For the functionals ")#mi("J_{k}^{(m)}(F)")#text(", one may want to break up the simplex in a different way. Let’s focus on ")#mi("J_{k}^{(k)}")#text(" for a moment (the others being similar). One option (following something James sent me) is to break ")#mi("\\mathcal{R}_{k}^{\\prime}")#text(" into the ")#mi("k-1")#text(" sets")

#mi("\\mathcal{R}_k^{\\prime}(j) =\\{(t_1,\\ldots, t_k)\\ :\\ t_1,\\ldots, t_{k-1}\\geq t_j,")

#mi("0\\leq t_k\\leq 1-\\sum_{i=1}^{k-1}t_i +t_j \\}")

#text("for ")#mi("1\\leq j\\leq k-1")#text(". I think one can then follow the analysis you gave above. It seems that the formulas are a bit complicated; there may be a cleaner method here.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256162")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Actually, I realised just now that we can use symmetry to write")

#mi("J_k^{(k)}(F) = 2 \\int_{{\\cal R}^{\\prime}_k} F V_k F")

#text("where ")#mi("V_k")#text(" is the Volterra operator in the k^th direction:")

#mi("V_k F(t_1,\\ldots,t_k) := \\int_0^{t_k} F(t_1,\\ldots,t_{k-1},s_k)\\ ds_k.")

#text("In particular if F is a polynomial then ")#mi("V_k F")#text(" is a polynomial of one higher degree (without having to involve tropical expressions such as ")#mi("\\min(t_1,\\ldots,t_k)")#text("). So any formula that allows one to integrate polynomials on ")#mi("{\\cal R}^{\\prime}_k")#text(" will also be able to calculate ")#mi("J_k^{(k)}(F)")#text(" for polynomials F, and similarly for the other ")#mi("J_k^{(m)}(F)")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6de08af996f1b13b848c07305d34e8876f7bc6b7a77eb42047dcdc8ac5900725-85b0d5b83f7030bb5c34eb01a958aa331cef9d7e5909f3d107a929253025af54.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Smetalka")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256052")[#strong[#text("Smetalka")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("Possible inconsistency: on the wiki page the lower bound for k=59 (3.96508) differs from the one you mentioned in your original post (3.898)")

#emph[#text("[Corrected; the 3.898 referred to a previous lower bound that has since been superseded. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256060")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2013")])]

#text("There is still a typo (also in the wiki page): The value (as given by Pace) is ")#mi("3.95608...")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256186")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Another possibility to approximate ")#mi("M_k")#text(" is by trying to express the coefficients of ")#mi("\\mathcal L ^j 1;  j = 1, 2, ...")#text(" and than to see if by the power method ")#tao-math("\\left|\\left| \\mathcal L \\right|\\right|", block: false)#text(" may be estimated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256192")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Three lines above lemma 4.9, I suggest to replace “the first non-zero derivative is positive” by ")#mi("f(0) > 0")#text(".")

#emph[#text("[Corrected, thanks – although these sorts of comments should go in the Polymath8a thread. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256195")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("The link to this newest thread is not on the polymath wiki.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256199")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("I was looking again at the Selberg sieve to see if there was any other way to move beyond our current range. It occurred to me that we could exploit more fully the difficulty gap between the task of computing the sum ")#mi("\\sum_n \\nu(n)")#text(" (which is really easy, since we understand how integers distribute in arithmetic progressions) with the task of computing the sum ")#mi("\\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}")#text(" (which is difficult, since we need to understand how primes distribute in arithmetic progression).")

#text("Let us use the multidimensional GPY sieve as discussed in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("this blog post")]#text(" (rather than the elementary Selberg sieve from Maynard’s paper). Assuming all error terms are under control, and the underlying cutoff f is symmetric we obtain ")#mi("DHL[k,m+1]")#text(" (assuming ")#mi("EH[\\theta]")#text(") whenever the ratio")

#mi("\\displaystyle \\frac{ k \\int f_{1,\\ldots,k-1}(t_1,\\ldots,t_{k-1},0)^2\\ dt_1 \\ldots dt_{k-1}}{\\int f_{1,\\ldots,k}(t_1,\\ldots,t_k)^2\\ dt_1 \\ldots dt_k}")

#text("exceeds ")#mi("\\frac{2m}{\\theta}")#text(".")

#text("Now what constraints are there on the cutoff function f, other than it be smooth and compactly supported? Right now, we are requiring that f is supported on the simplex ")#mi("{\\cal R}_k")#text(", or on the enlarged simplex ")#mi("{\\cal R}^{\\prime}_k")#text(". But actually, if one looks at the proof, in order to control the numerator it is only necessary that the slice ")#mi("(t_1,\\ldots,t_{k-1}) \\to f(t_1,\\ldots,t_{k-1},0)")#text(" be supported on the simplex ")#mi("{\\cal R}_{k-1}")#text(", while to control the denominator, f can be supported in the larger simplex ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" to reflect the fact that the integers trivially obey the full Elliott-Halberstam conjecture. (Here let us work in the “unconditional” setting in which ")#mi("\\theta")#text(" is equal to or only slightly larger than 1/2.) It may be that this gives some extra flexibility to the variational problem. In terms of the differentiated cutoff function ")#mi("F = f_{1,\\ldots,k}")#text(" that appears in Maynard’s paper, the constraint is then essentially that F is allowed to be supported in the larger simplex ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(", so long as the marginal distribution")

#mi("(t_1,\\ldots,t_{k-1}) \\mapsto \\int F(t_1,\\ldots,t_k)\\ dt_k")

#text("is still supported on the simplex ")#mi("{\\cal R}_{k-1}")#text(". For non-negative F, this restricts F to the region ")#mi("{\\cal R}^{\\prime}_k")#text(", but there is some possibility (perhaps unlikely) that one gains something numerically by considering some oscillatory F that pokes a bit outside of ")#mi("{\\cal R}^{\\prime}_k")#text(". I’ll think about this a bit more…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256208")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Indeed, it appears that this relaxation of constraints does allow one to increase the ratio one is trying to maximise. Among other things, the optimum in the new variational problem is only achieved if the function ")#mi("F")#text(" is a sum of functions that depend only on k-1 of the k variables, thus (by symmetry)")

#mi("F(t_1,\\ldots,t_k) = \\tilde F(t_1,\\ldots,t_{k-1}) + \\tilde F(t_1,\\ldots,t_{k-2},t_k)")

#mi("+ \\ldots + \\tilde F(t_2,\\ldots,t_k)")#text(".")

#text("Whereas in the previous optimisation problem this decomposition held only inside ")#mi("{\\cal R}_k")#text(" or ")#mi("{\\cal R}^{\\prime}_k")#text(", in the new problem it must hold throughout ")#mi("\\frac{1}{\\theta} {\\cal R}_k")#text("; equivalently, the alternating sum of ")#mi("F(t_1,\\ldots,t_k)")#text(" on the vertices of any box in ")#mi("\\frac{1}{\\theta} {\\cal R}_k")#text(" with sides parallel to the axes needs to vanish. This is an additional constraint that is unlikely to have been satisfied by the original extremiser, suggesting that an improvement in the analogue for ")#mi("M_k")#text(" in this setting is available.")

#text("I’m not yet sure though how to convert this to an effectively computable optimisation problem; one needs a good basis for the space of symmetric functions of k variables on ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" whose marginal distribution on k-1 variables is supported on the simplex ")#mi("{\\cal R}_{k-1}")#text(", and I can’t see an obvious candidate for such a basis offhand…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256214")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Can you clarify what it means for the marginal distribution on ")#mi("k-1")#text(" variables to be supported on the simplex ")#mi("\\mathcal{R}_{k-1}")#text(", perhaps with a simple example of such function? [Specifically, I thought we could choose our function to be piece-wise smooth, so doesn’t that let essentially let us choose the support? I’m probably missing something simple here.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("Saying that a symmetric function ")#mi("F(t_1,\\ldots,t_k)")#text(" has k-1-marginals supported on ")#mi("{\\cal R}_{k-1}")#text(" means that the k-1-dimensional function ")#mi("(t_1,\\ldots,t_{k-1}) \\mapsto \\int_0^\\infty F(t_1,\\ldots,t_{k-1},t_k)\\ dt_k")#text(" vanishes whenever ")#mi("t_1+\\ldots+t_{k-1} > 1")#text(". An example would be the tensor product ")#mi("F(t_1,\\ldots,t_k) = h(t_1) \\ldots h(t_k)")#text(" for any function ")#mi("h: [0,+\\infty) \\to {\\bf R}")#text(" of mean zero; this symmetric oscillating function in fact has all marginals vanishing everywhere.")

#text("For sake of notation let us take k=3 and ")#mi("\\theta=1/2")#text(" (in practice of course we need to take k to be more like 59 with this value of ")#mi("\\theta")#text(", but I don’t want to write so many variables); then the new variational problem (replacing ")#mi("M_3")#text(") is that of maximising the ratio")

#mi("\\displaystyle 3 \\frac{\\int_0^\\infty \\int_0^\\infty (\\int_0^\\infty F(x,y,z)\\ dz)^2\\ dx dy}{\\int_0^\\infty \\int_0^\\infty \\int_0^\\infty F(x,y,z)^2\\ dx dy dz}")

#text("for piecewise smooth symmetric ")#mi("F: [0,+\\infty)^3 \\to {\\bf R}")#text(" supported in the simplex ")#mi("\\{ x+y+z \\leq 2\\}")#text(", and such that ")#mi("\\int_0^\\infty F(x,y,z)\\ dz")#text(" vanishes whenever ")#mi("x+y \\geq 1")#text(". The latter condition is automatic if F is supported on ")#mi("{\\cal R}^{\\prime}_3 = \\{ (x,y,z): x+y,y+z,z+x \\leq 1 \\}")#text(", but also allows for some additional oscillatory functions F.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256216")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("For ")#mi("k=2")#text(" it seems that such oscillatory ")#mi("F")#text(" (having the above symmetric form) is not possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("If ")#mi("\\theta = 1/2")#text(", then one can find oscillating symmetric functions ")#mi("F(x,y)")#text(" supported on the triangle ")#mi("\\{x+y \\leq 2\\}")#text(" whose marginals are supported on ")#mi("[0,1]")#text(", e.g. ")#mi("F(x,y) = g(x) h(y) + g(y) h(x)")#text(" where ")#mi("g, h")#text(" are supported on ")#mi("[0,1/2], [1,3/2]")#text(" respectively with g having mean zero. (Actually, the ")#mi("k=2, \\theta = 1/2")#text(" case looks like a good one to analyse even if it won’t give us any nontrivial value of m, as this is one of the few places where we can hope for an exact solution to the optimisation problem.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256234")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("I meant that it can’t be done if ")#mi("F")#text(" is of the form ")#mi("f(x)+f(y)")#text(" (symmetric sum of two functions of one variable) – which (as previously remarked) is the only possibility for an optimum.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("To be precise, F will be of the form ")#mi("F(x,y) = (f(x)+f(y)) 1_{x+y \\leq 2}")#text(". It is possible for functions of this form to have vanishing marginals outside of [0,1], although if F is an extremiser then by a Lagrange multiplier argument one can show that ")#mi("{\\cal L} F(x,y)")#text(" is a function of y only when ")#mi("0 \\leq x \\leq 1 \\leq y \\leq 2-x")#text(", and similarly when x and y are reversed, which shows after a little computation that ")#mi("F")#text(" is a scalar multiple of ")#mi("1_{[0,1] \\times [0,1]}(x,y)")#text(". This shows that in the k=2 case, we don’t gain anything over the bound ")#mi("M^{\\prime}_2 = 2")#text(" that we already have from the ")#mi("1_{[0,1] \\times [0,1]}")#text(" example.")

#text("For k=3, though, I believe a similar argument shows that the extremiser is not supported on ")#mi("{\\cal R}^{\\prime}_3")#text(", suggesting that we can improve upon ")#mi("M^{\\prime}_3")#text(" with this expanded variational problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256344")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Just to expand upon the final paragraph: Lagrange multipliers tell us that a symmetric extremiser F to the extended variational problem (in which F is supported on ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" but has marginals supported on ")#mi("{\\cal R}_{k-1}")#text(") solves the modified eigenfunction equation ")#mi("{\\cal L} F = M^{\\prime\\prime}_k F + \\sum_{i=0}^k f( t_1,\\ldots,t_{i-1},t_i,\\ldots,t_k )")#text(" on ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(", where ")#mi("{\\cal L}")#text(" as the usual operator (but now defined on ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text("), ")#mi("M^{\\prime\\prime}_k")#text(" is the optimal ratio (larger than or equal to the optimal ratio ")#mi("M^{\\prime}_k")#text(" on ")#mi("{\\cal R}^{\\prime}_k")#text(", which is in turn larger than or equal to ")#mi("M_k")#text("), and ")#mi("f")#text(" is symmetric supported on ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_{k-1}")#text(" but vanishes on ")#mi("{\\cal R}_{k-1}")#text(".")

#text("Note also from the vanishing marginal condition that ")#mi("{\\cal L} F(t_1,\\ldots,t_k) = \\sum_{i=0}^k g(t_1,\\ldots,t_{i-1},t_i,\\ldots,t_k)")#text(" where ")#mi("g")#text(" is symmetric and supported on ")#mi("{\\cal R}_{k-1}")#text(".")

#text("In the k=3 case, we have")

#mi("g(x,y)+g(y,z)+g(z,x) = M^{\\prime\\prime}_2 F(x,y,z) + f(x,y) + f(y,z) + f(z,x).")

#text("Suppose that F is supported on ")#mi("{\\cal R}^{\\prime}_3")#text(" and ")#mi("\\theta=1/2")#text(". Then in the regime ")#mi("x+y,y+z \\geq 1 \\geq x+z")#text(", we then have")

#mi("g(z,x) = f(x,y) + f(y,z)")

#text("which (setting y=1) shows that ")#mi("g(z,x) = h(z)+h(x)")#text(" for ")#mi("z+x \\leq 1")#text(" and some function ")#mi("h")#text(". In the regime ")#mi("x+z \\geq 1 \\geq x+y,y+z")#text(", we have")

#mi("g(x,y) + g(y,z) = f(x,z);")

#text("the left-hand side is ")#mi("h(x)+h(z)+2h(y)")#text(" while the RHS is independent of y, which forces h to be constant, which then forces f to be constant, and then F is a scalar multiple of the indicator function on ")#mi("{\\cal R}^{\\prime}_3")#text(", which is not the extremiser. I think a similar argument works for all ")#mi("k \\geq 3")#text(" (for ")#mi("k=2")#text(", though, the indicator on ")#mi("{\\cal R}^{\\prime}_k")#text(" happens to be the extremiser).")

#text("In the Elliott-Halberstam case ")#mi("\\theta=1")#text(", the restriction of F to ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" collapses the problem back to the M_k problem, but I think one can replace ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" by the larger region")

#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#linebreak()#text(" ")#mi("\\cup \\{ (t_1,\\ldots,t_k): t_1+\\ldots+t_{i-1}+t_{i+1}+\\ldots+t_k \\leq 1 \\text{ for some } i \\}")

#text("(by using the generalised EH to control the distribution of the ")#mi("d_i")#text(" summations) which is still larger than ")#mi("{\\cal R}^{\\prime}_k")#text(". There is now hope of getting ")#mi("M^{\\prime\\prime}_4")#text(" greater than 2 (it seems that ")#mi("M^{\\prime}_4")#text(" is about 1.92, we only need a little bit of additional boost to get over the top).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256235")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("BTW, perhaps Kolmogorov’s superposition theorem may be used here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256360")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Just to clarify, is that new range (in the ")#mi("\\theta=1")#text(" case) equal to")

#mi("\\mathcal{R}_k^{\\prime\\prime}=\\{(t_1,\\ldots, t_k)\\ :\\ \\sum_{i=1}^{k}t_i-\\max(t_1,\\ldots,t_k)\\leq 1  \\}")#text("?")

#text("If so, I can do the computation to see if ")#mi("k=4")#text(" now works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("A bit more precisely, for ")#mi("\\theta=1")#text(" the region is")

#mi("{\\cal R}^{\\prime\\prime}_k = \\{ (t_1,\\ldots,t_k) \\in [0,1]^k: \\sum_{i=1}^k t_i - \\max(t_1,\\ldots,t_k) \\leq 1 \\}")

#text("(in particular I believe this region is now non-convex for k>2), and one has to optimise ")#mi("\\sum_{m=1}^k J_k^{(m)}(F)/I(F)")#text(" for ")#mi("F")#text(" symmetric and supported in ")#mi("{\\cal R}^{\\prime\\prime}_k")#text(", subject to the constraint that the marginals ")#mi("(t_1,\\ldots,t_{k-1}) \\mapsto \\int_0^1 F(t_1,\\ldots,t_k)\\ dt_k")#text(" are supported in ")#mi("{\\cal R}_{k-1}")#text(". (In the general theta case, one has to restrict ")#mi("(t_1,\\ldots,t_k)")#text(" to ")#mi("[0,1/\\theta]^k")#text(" otherwise some of the divisors ")#mi("d_i")#text(" will exceed x.)")

#text("I’m not sure how to implement the vanishing marginal constraint computationally. One crude way would be to add a large penalty function based on the L^2 mass of the marginals outside of the simplex ")#mi("{\\cal R}_{k-1}")#text(", but this is likely to significantly degrade convergence of the algorithm.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256362")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Is it yet possible to derive the minimal k for which M’_k passes 4? (The mention of a value for M’_4 arouses irresistible curiosity that it might be!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256365")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Ah, I apologise – I now realise that M’_4 = 1.92 is simply twice the value of 0.96 that James provided two weeks ago (")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253116")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253116")]#text("), using R’ but before the “M'” notation had been introduced. (Notation is evolving quickly at present!) But it would still be of interest to learn how feasible/close a calculation of M’_k for k in the 50 range is felt to be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("I need to correct my previous comment here; actually, I don’t think we can take the support of F in the ")#mi("\\theta=1")#text(" case (taking ")#mi("k=3")#text(" for sake of concreteness) to be as large as")

#mi("\\{ (x,y,z): \\min( x+y, y+z, z+x ) \\leq 1 \\}")

#text("as I had previously claimed.")

#text("The problem comes from lack of convexity; we have to deal with the square ")#mi("(\\sum_{d_1|n,d_2|n+2,d_3|n+6}\\lambda_{d_1,d_2,d_3})^2")#text(" of the divisor sum, and if one factor in the square comes from a tuple ")#mi("(x,y,z)")#text(" with (say) ")#mi("x+y \\leq 1")#text(", and if another comes from a tuple with ")#mi("y+z \\leq 1")#text(", then we don’t get any good control on the combined factor, and in particular cannot use EH in any of the three resulting moduli. The best I can see right now is to break the symmetry and work with a region such as")

#mi("\\{ (x,y,z): x+y \\leq 1 \\}.")

#text("While this in principle is still an improvement over the previous situation in which we restricted ourselves to the region ")#mi("{\\cal R}^{\\prime}_3 = \\{ (x,y,z): x+y,y+z,z+x \\leq 1\\}")#text(", the loss of symmetry is going to make the numerical optimisation messier (especially since we still have the condition on the (y,z) and (z,x) marginals being restricted to ")#mi("y+z \\leq 1")#text(" and ")#mi("z+x \\leq 1")#text(" respectively).")

#text("But in the ")#mi("\\theta < 1")#text(" case, we can still work with the simplex ")#mi("\\frac{1}{\\theta} \\cdot {\\cal R}_k")#text(" as before, because it is convex and so this issue does not occur.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256296")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Such a basis can’t be real analytic (in particular, polynomial) on ")#mi("(1/ \\theta) \\mathcal R_k")#text(" (otherwise, the marginals are also real analytic on ")#mi("(1/ \\theta) \\mathcal R_{k-1}")#text(" – and can’t be supported on ")#mi("\\mathcal R_{k-1}")#text(" without vanishing identically!)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AndrewVSutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256294")[#strong[#text("AndrewVSutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("This ")#link("http://arxiv.org/abs/1312.2926")[#text("paper")]#text(" of Friedlander and Iwaniec posted to arXiv this morning may be of interest (and should probably be added to the bibliography)..")

#emph[#text("[Reference added, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256339")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("Thanks for the link! From a quick read through, the paper has a few innovations that aren’t in Polymath8a; for instance, in the MPZ estimates they are able to let the residue class ")#mi("a\\ (q)")#text(" vary with ")#mi("q")#text(" (in our notation, it would be ")#mi("a_q\\ (q)")#text("). By doing so, they give up some of the more advanced estimates of Polymath8a that come from averaging in modulus parameters such as q and r, but enough of the original arguments of Zhang (including Zhang’s original Type III argument, based on the Birch-Bombieri bound from Deligne’s theorem) can be adapted to still obtain a nontrivial estimate of this type.")

#text("There is also a passing remark that the Bessel function optimisation was actually performed first by Brian Conrey in an unpublished 2005 computation, thus predating the work of Farkas, Pintz, and Revesz; I’m guessing this was at an AIM workshop. I suppose we should note this also in Polymath8a, I’ll see if I can get some confirmation of this remark. ")#emph[#text("[UPDATE: Brian has confirmed the calculation and showed me some of his emails and handwritten notes on the topic. I’ll put in a remark in the paper to this effect. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256361")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("I had also heard that Brian had done this optimization around the time of the first GPY paper, but I didn’t get around to asking him for details. I actually thought that Soundararajan had a remark to this effect in his Bulletin of the AMS survey, but I couldn’t find it there, so that was probably a mis-remembrace. I agree that it is good to add a mention of this in the paper.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256389")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("I’ve added a remark to this effect in Section 4.3. I also found a reference to Conrey’s computation in p. 129 of “Opera del Cribro”, and now that I look again at the Farkas-Pintz-Revesz paper, this is also mentioned in the introduction; I remember looking at this paper before, so I’m surprised I didn’t catch this previously.")

#text("On looking through “Opera del Cribro” I also found a conjecture on page 408 which is close to what we have been calling the Motohashi-Pintz-Zhang estimate (but the authors do cite Motohashi-Pintz for further details). This should probably also be mentioned in our paper.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3e86104aacaf54a812e8832fbbf3f5a878bdb0163bab81777af2ad856f469fb-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Donal Lyons")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256840")[#strong[#text("Donal Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("“Opera de Cribro” :-)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256359")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2013")])]

#text("It would be helpful to update the wiki page about the variational problem by adding details on the associated problem for ")#mi("\\mathcal R^{\\prime}_k")#text(" (and perhaps for larger domains as discussed above.)")

#emph[#text("[Added some text for this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256515")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("On the possibility of a “piecewise polynomial” basis for the variational problem:")

#text("The idea is to represent ")#mi("\\mathcal R^{\\prime\\prime}_{k, \\theta}")#text(" as a disjoint (up to boundaries) union of ")#mi("\\mathcal R_k")#text(" and finitely many convex polytopes ")#mi("D_j")#text(" such that each basis function is a polynomial over the interior of ")#mi("\\mathcal R_k")#text(" and each ")#mi("D_j")#text(". Note that (because of ")#mi("D_j")#text(" convexity), each marginal is a sum of integrals over intervals, with at most one interval for each ")#mi("D_j")#text(".")

#text("It follows that each marginal of each monomial is “piecewise polynomial” outside ")#mi("R_{k-1}")#text(" (over similar partition ")#mi("E_l")#text(" of polytopes outside ")#mi("\\mathcal R_{k-1}")#text(" .)")

#text("We need the condition: For each FIXED ")#mi("m")#text(", the marginal (as an integral with respect to ")#mi("t_m")#text(") of each monomial is a polynomial over each ")#mi("E_l")#text(" above (where the polytopes ")#mi("E_l")#text(" are “monomial independent” but may depend on ")#mi("m")#text(").")

#text("It seems that this condition is satisfied (for sufficiently refined partition into polytopes ")#mi("D_j")#text(".)")

#text("Under the above condition, for each basis function, the vanishing of each marginal outside ")#mi("\\mathcal R_{k-1}")#text(" is described by a system of linear constraints on the coefficients of the basis function.")

#text("Therefore (for appropriate partition ")#mi("D_j")#text("), we return (for each maximal degree ")#mi("d")#text(") to a similar optimization problem (with the additional system of linear constraints on the coefficients describing the “piecewise polynomial” ")#mi("F")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("I like this idea. It may well be that by applying this with k=4 on EH, we may finally be able to get ")#mi("M^{\\prime\\prime}_4")#text(" above 2 and thus get ")#mi("H_1 \\leq 8")#text(" on EH.")

#text("But it may make sense to warm up on k=3 first, which is already somewhat complicated combinatorially (and k=4 is much worse). We have, in increasing order, the quantities ")#mi("M_3,M^{\\prime}_3,M^{\\prime\\prime}_3")#text(", where ")#mi("M_3")#text(" is the maximal value of")

#mi("\\frac{J_3^{(1)}(F) + J_3^{(2)}(F) + J_3^{(3)}(F)}{I_3(F)}")#text(" (*)")

#text("for F supported on the simplex ")#mi("{\\cal R}_3 = \\{ (x,y,z): x+y+z \\leq 1 \\}")#text(", with")

#mi("I_3(F) = \\int\\int\\int F(x,y,z)^2\\ dx dy dz")#linebreak()#text(" ")#mi("J_3^{(1)}(F) = \\int\\int (\\int F(x,y,z)\\ dx)^2\\ dy dz")

#text("and similarly for cyclic permutations, ")#mi("M^{\\prime}_3")#text(" is the maximum value of the same ratio but with F supported on the larger region ")#mi("{\\cal R}^{\\prime}_3: \\{ (x,y,z): x+y,y+z,z+x \\leq 1\\}")#text(", and ")#mi("M^{\\prime\\prime}_3")#text(" is the maximum value of the same ratio, but F now supported on the prism ")#mi("{\\cal R}^{\\prime\\prime}_3 = \\{ (x,y,z): x+y, z \\leq 1 \\}")#text(" and with marginal distributions ")#mi("\\int F(x,y,z)\\ dx")#text(" and ")#mi("\\int F(x,y,z)\\ dy")#text(" supported on ")#mi("y+z \\leq 1")#text(" and ")#mi("x+z \\leq 1")#text(" respectively. (The support of the third marginal ")#mi("\\int F(x,y,z)\\ dz")#text(" is already supported on the correct simplex.) Note that while the first two problems are completely symmetric in x,y,z, this third optimisation problem is only symmetric in x,y, so we have to work with functions F that are symmetric in x,y only.")

#text("I’m not sure if the numerically computed values of M_3 or M’_3 have already been posted here but presumably they can be calculated easily using existing algorithms, to serve as benchmarks for the potential gain M”_3 offers over M’_3.")

#text("As Eytan suggests, one can split the prism ")#mi("{\\cal R}^{\\prime\\prime}_3")#text(" into convex polytopes on which the marginal conditions become polynomial. It seems that the following partition into seven regions works:")

#mi("D_0 := \\{ x+y, y+z, z+x \\leq 1 \\}")

#mi("D_1 := \\{ x+y \\leq y+z \\leq 1 \\leq z+x \\}")

#mi("D_2 := \\{ y+z \\leq x+y \\leq 1 \\leq z+x \\}")

#mi("D^{\\prime}_1 := \\{ x+y \\leq z+x \\leq 1 \\leq y+z \\}")

#mi("D^{\\prime}_2 := \\{ z+x \\leq x+y \\leq 1 \\leq y+z \\}")

#mi("D_3 := \\{ x+y \\leq 1 \\leq z+x \\leq y+z; z \\leq 1 \\}")

#mi("D^{\\prime}_3 := \\{ x+y \\leq 1 \\leq y+z \\leq x+z; z \\leq 1 \\}")

#text("We take ")#mi("F")#text(" to be piecewise polynomial on each of these seven pieces, e.g. ")#mi("F = F_0")#text(" on ")#mi("D_0")#text(", ")#mi("F = F^{\\prime}_2")#text(" on ")#mi("D^{\\prime}_2")#text(", etc. By symmetry we may assume that ")#mi("F^{\\prime}_i(x,y,z) = F_i(y,x,z)")#text(" for ")#mi("i=0,1,2,3")#text(" (with ")#mi("F^{\\prime}_0=F_0")#text("), so we have four polynomials ")#mi("F_0,F_1,F_2,F_3")#text(" to independently optimise over. The M’_3 problem corresponds to the case ")#mi("F_1=F_2=F_3=0")#text(".")

#text("By symmetry, the only marginal condition is that ")#mi("\\int F(x,y,z)\\ dy = 0")#text(" when ")#mi("x+z \\geq 1")#text(". When ")#mi("z \\leq x")#text(", this condition is just")

#mi("\\int_0^{1-x} F_2\\ dy = 0")

#text("but when ")#mi("z \\geq x \\geq 1/2")#text(", the condition becomes")

#mi("\\int_0^{1-z} F_1\\ dy + \\int_{1-z}^{1-x} F^{\\prime}_3\\ dy= 0")

#text("and when ")#mi("x \\leq z, 1/2")#text(", the condition becomes")

#mi("\\int_0^{1-z} F_1\\ dy + \\int_{1-z}^x F^{\\prime}_3\\ dy + \\int_x^{1-x} F_3\\ dy = 0")#text(".")

#text("In principle, these are finite-dimensional linear constraints on ")#mi("F_1,F_2,F_3")#text(" that allow for a non-trivial solution when the degrees D of ")#mi("F_1,F_2,F_3")#text(" are large enough (one has about ")#mi("O(D^3)")#text(" degrees of freedom and ")#mi("O(D^2)")#text(" constraints). The quadratic program is moderately messy though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256870")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("In your definition of ")#mi("I_3, J_3")#text(" did you get the correct powers on ")#mi("F")#text("? I thought in ")#mi("I_3")#text(" we only used the square, and in ")#mi("J_3")#text(" only the square on the outside of the first integral.")

#emph[#text("[Oops, that was weird; fixed now. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256902")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("Some remarks:")

#text("1. To find the coefficients of the linear constraints and quadratic forms for the optimization, it is perhaps easier to use (iterated) symbolic integration.")

#text("2. If the linear constraints are represented by ")#mi("C a = 0")#text(" where ")#mi("C")#text(" is the constraint matrix and ")#mi("a")#text(" is a vector representing the coefficients of ")#mi("F")#text(", then we have $a = D b$ for some matrix ")#mi("D")#text(" and vector ")#mi("b")#text(" with $dim b < dim a$, so we return to the original optimization problem (without linear constraints) for ")#mi("b")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256922")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2013")])]

#text("Is there any prospect of adapting Terry’s proof from three weeks ago of a sharp upper bound on M_k (")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253731")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253731")]#text(") to give a corresponding upper bound on M’_k or M”_k ? I don’t think there has been any discussion of that (other than James’s computed upper bound for M’_4), and I’m thinking that in view of the daunting combinatorial obstacle which may now be emerging in relation to extending Eytan’s idea to k > 3 (and especially to k for which M”_k could get anywhere near 4), there may be a case for attempting to determine in advance how much progress beyond M_k could be achieved for a given k in the best-case scenario.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257013")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2013")])]

#text("For M’_k, the best bounds I know of in general are")

#mi("M_k \\leq M^{\\prime}_k \\leq \\frac{k}{k-1} M_{k-1}")

#text("(improving slightly over the previously observed upper bound ")#mi("M^{\\prime}_k \\leq \\frac{k}{k-1} M_k")#text("). The lower bound is trivial. For the upper bound, note for any F supported on the polytope ")#mi("{\\cal R}^{\\prime}_k")#text(" that one has")

#mi("J_k^{(1)}(F) + \\ldots + J_k^{(k-1)}(F) \\leq M_{k-1} I_k(F)")

#text("by looking at each fixed-")#mi("t_k")#text(" slice of F (which is a k-1-dimensional function supported on ")#mi("{\\cal R}_{k-1}")#text(") and applying the definition of ")#mi("M_{k-1}")#text(", and then integrating in ")#mi("t_k")#text(". Averaging over permutations we then obtain")

#mi("J_k^{(1)}(F) + \\ldots + J_k^{(k)}(F) \\leq \\frac{k}{k-1} M_{k-1} I_k(F)")

#text("giving the claim.")

#text("Note that we do not necessarily have monotonicity in ")#mi("M^{\\prime}_k")#text(" (for instance, ")#mi("M^{\\prime}_2 = 2")#text("). So it may well be that M’_3 exceeds 2 even if M’_4 does not. The above bound, combined with the existing bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(", gives an upper bound of 2.0794 for ")#mi("M^{\\prime}_3")#text(", so there is hope, though admittedly a slim one since the upper bound was somewhat crude.")

#text("For ")#mi("M^{\\prime\\prime}_k = M^{\\prime\\prime}_{k,\\theta}")#text(", the best bounds I can obtain easily are")

#mi("M^{\\prime}_k \\leq M^{\\prime\\prime}_{k,\\theta} \\leq M_{k-1} + \\frac{1}{\\theta}")#text(".")

#text("The lower bound is trivial, and the upper bound comes from observing that the function F for ")#mi("M^{\\prime\\prime}_{k,\\theta}")#text(" is supported in the prism ")#mi("{\\cal R}_{k-1} \\times [0,1/\\theta]")#text(", and ignoring all the vanishing marginal conditions on F. From the slicing argument we again have")

#mi("J_k^{(1)}(F) + \\ldots + J_k^{(k-1)}(F) \\leq M_{k-1} I_k(F)")

#text("and from Cauchy-Schwarz one has")

#mi("J_k^{(k)}(F) \\leq \\frac{1}{\\theta} I_k(F)")

#text("giving the claim. This is a very poor bound for small k, but it shows asymptotically that we do not break the logarithmic barrier ")#mi("M_k \\leq \\log k + O(1)")#text(" through any of these tricks, unfortunately.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257019")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2013")])]

#text("Thank you Terry! The absence of an (easily-obtainable, anyway) upper bound on ")#mi("M^{\\prime\\prime}_k")#text(" that is even close to that for ")#mi("M^{\\prime}_k")#text(" seems most encouraging. Out of interest, is ")#mi("M^{\\prime\\prime}_k")#text(" also not necessarily monotonic (for a given ")#mi("\\theta")#text(")?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257276")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2013")])]

#text("I had a look at this this afternoon.")

#text("Provisionally, my calculations are getting the bound")#linebreak()#text(" ")#mi("M_3^{\\prime\\prime}\\geq 1.914.")#linebreak()#text(" This is from taking ")#mi("F_0,F_1,F_2,F_3")#text(" to be degree 4 polynomials in ")#mi("x,y,z")#text(" and following the approach outlined above.")

#text("This should be compared with the bounds")#linebreak()#text(" ")#mi("M_3^{\\prime}\\geq 1.842")#linebreak()#text(" ")#mi("M_3\\geq 1.646.")#linebreak()#text(" I’ll give a couple details tomorrow.")

#text("Frustratingly, if the above calculations hold up then it looks like we might come just short of improving our current bound ")#mi("M_4^{\\prime} \\geq 1.937")#text(" to something above 2.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257354")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Thanks for the computations! At least we now do know (at least numerically) that ")#mi("M^{\\prime\\prime}_k")#text(" can be strictly greater than ")#mi("M^{\\prime}_k")#text(", so the idea of going outside ")#mi("{\\cal R}^{\\prime}_k")#text(" does have some potential. I’ve started putting up the data on the wiki at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#World_records")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#World_records")]

#text("I’m still missing a few cells (notably the lower bounds for M_2 and M’_5 – presumably you have these available or easily computable from your code?) but it already shows that the crude upper bounds ")#mi("M^{\\prime}_k \\leq \\frac{k}{k-1} M_{k-1}")#text(" and ")#mi("M^{\\prime\\prime}_k \\leq M_{k-1}+1")#text(" are nowhere near as sharp as the bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(", although this is not terribly surprising.")

#text("It would be somewhat amusing (though suspenseful) if ")#mi("M^{\\prime\\prime}_4 \\geq 2")#text(" was just at the edge of provability, so that a massive computer effort would be required to get high enough degree to verify it. If that doesn’t work, another option is to turn to ")#mi("M^{\\prime\\prime}_5")#text(" and shave off ")#mi("P_{0,12}")#text(" as discussed a couple weeks ago, to get ")#mi("H_1")#text(" to 10 rather than to 8.")

#text("One further option is the following (let’s take k=3 for sake of discussion). Right now, on EH, the function F is assumed to lie in the prism")

#mi("\\{ (x,y,z): x+y, z \\leq 1 \\}")

#text("with appropriate vanishing marginal conditions. This is not quite the only choice available: in principle, we can have F supported on any set ")#mi("R \\subset [0,1]^3")#text(" with the property that the sumset ")#mi("R+R = \\{ v+w: v,w \\in R \\}")#text(" lies in the non-convex region")

#mi("\\{ (x,y,z): x+y, z \\leq 2 \\} \\cup \\{ (x,y,z): y+z, x \\leq 2\\}")#linebreak()#text(" ")#mi("\\cup \\{ (x,y,z): z+x, y \\leq 2 \\}")

#text("as this represents all the ranges of moduli ")#mi("d_1,d_2,d_3")#text(" occurring in the Selberg sieve (which is the square of a divisor sum over a region associated to R) for which we can use Elliott-Halberstam in one of the three moduli (to make this work we have to first approximate F to be a finite linear combination of tensor products of one-dimensional functions, but this should be easily achievable from a Stone-Weierstrass argument, though there is a minor technicality that one has to make sure that the vanishing boundary conditions are still obeyed). Anyway, it is conceivable that there is some other choice of R which is superior to the prism ")#mi("\\{ (x,y,z): x+y, z \\leq 1 \\}")#text(", although I don’t obviously see one (my 3D geometry visualisation is not that great!).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257360")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("I get that ")#mi("M_2\\geq 1.385")#text(" and ")#mi("M_5^{\\prime}\\geq 2.059")#text(". (Actually for ")#mi("M_2")#text(" we can solve the Eigenfunction equation, and the answer is the solution ")#mi("x")#text(" of the equation")#linebreak()#text(" ")#mi("2-\\frac{1}{x}+\\log\\Big{\\left(1-\\frac{1}{x}\\right)}=0")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Thanks for this! Just for the record, I’m writing down the calculations for the eigenfunction equation ")#mi("{\\cal L}_2 F = M_2 F")#text(" on the triangle ")#mi("{\\cal R}_2 = \\{ (x,y): x+y \\leq 1\\}")#text(". Assuming symmetry and writing ")#mi("{\\cal L}_2 F = f(x) + f(y)")#text(", where ")#mi("f(x) = \\int_0^{1-x} F(x,y)\\ dy")#text(", we see that")

#mi("M_2 f(x) = (1-x) f(x) + \\int_0^{1-x} f(y)\\ dy")

#text("which in particular implies that f(1)=0. Also, differentiating we see that")

#mi("M_2 f^{\\prime}(x) = (1-x) f^{\\prime}(x) - f(x) - f(1-x)")

#text("and thus")

#mi("f^{\\prime}(x) = -\\frac{G(x)}{M_2-1+x}")#text(" (1)")

#text("where ")#mi("G(x) := f(x)+f(1-x)")#text("; reflecting, we obtain")

#mi("f^{\\prime}(1-x) = -\\frac{G(x)}{M_2-x}")

#text("and hence")

#mi("G^{\\prime}(x) = -\\frac{G(x)}{M_2-1+x} + \\frac{G(x)}{M_2-x}")

#text("which can be solved as")

#mi("G(x) = C( \\frac{1}{M_2-x} + \\frac{1}{M_2-1+x}).")

#text("We may normalise C=1. Substituting back into (1), we conclude after some calculation that")

#mi("f(x) = \\frac{1}{M_2-1+x} + \\frac{1}{2M_2-1} \\log \\frac{M_2-x}{M_2-1+x} + C^{\\prime}")

#text("but then since ")#mi("G(x)=f(x)+f(1-x)")#text(" we have C’=0. Using the boundary condition f(1)=0 we then have")

#mi("\\frac{1}{M_2} + \\frac{1}{2M_2-1} \\log \\frac{M_2-1}{M_2} = 0")

#text("which rearranges to ")#mi("2 - \\frac{1}{M_2} + \\log( 1 - \\frac{1}{M_2} ) = 0")#text(" as required. Up to scalar multiples, the eigenfunction is then")

#mi("F(x,y) = \\frac{1}{M_2-1+x} + \\frac{1}{M_2-1+y} + \\frac{1}{2M_2-1} \\log \\frac{M_2-x}{M_2-1+x} \\frac{M_2-y}{M_2-1+y}.")

#text("Wolfram alpha tells me (and one can easily confirm) that ")#mi("M_2 = 1 / (1- W(1/e)) = 1.38593...")#text(" where ")#mi("W")#text(" is the ")#link("http://en.wikipedia.org/wiki/Lambert_W_function")[#text("Lambert W function")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257381")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("I thought I’d record for completeness the solution to the Eigenfunction equation (even though it seems we can’t solve it when ")#mi("k>2")#text(" and for ")#mi("k=2")#text(" we have simpler and stronger results from using the enlarged region). The comment above was mine – I hadn’t intended it to be anonymised. ")#emph[#text("[Name restored to previous comment – T.]")]

#text("We wish to solve the eigenfunction equation (for smooth ")#mi("F")#text(" supported on ")#mi("\\mathcal{R}_2")#text(")")#linebreak()#text(" ")#mi("\\lambda F(x,y)=\\mathcal{L}_2 F=\\int_0^{1-x}F(x,t)dt+\\int_0^{1-y}F(t,y)dy.")#linebreak()#text(" We see that from this equation (and by the symmetry of ")#mi("F")#text(") that ")#mi("F")#text(" is of the form ")#mi("F(x,y)=P(x)+P(y)")#text(". This gives us an eigenfunction equation for ")#mi("P")#text(" (having simplified slightly):")#linebreak()#text(" ")#mi("(\\lambda-1+t)P(t)=\\int_0^{1-t}P(u)du.")#linebreak()#text(" Differentiating with respect to ")#mi("t")#text(" gives")#linebreak()#text(" ")#mi("(\\lambda-1+t)P^{\\prime}(t)=-(P(t)+P(1-t)), (*)")#linebreak()#text(" and since the right hand side is unchanged by the substitution ")#mi("t\\rightarrow 1-t")#text(" we see that")#linebreak()#text(" ")#mi("(\\lambda-1+t)P^{\\prime}(t)=(\\lambda-t)P^{\\prime}(1-t).")#linebreak()#text(" Differentiating (*) again and substituting our above expression for ")#mi("P^{\\prime}(1-t)")#text(" gives")#linebreak()#text(" ")#mi("P^{\\prime\\prime}(t)=P^{\\prime}(t)\\Big{\\left(\\frac{1}{\\lambda-t}-\\frac{2}{\\lambda-1+t}\\right)}.")#linebreak()#text(" This is a standard differential equation which can be solved by separation of variables. The solution is")#linebreak()#text(" ")#mi("P(t)=A+B\\Big{\\left(\\frac{2\\lambda-1}{\\lambda-1+t}-\\log\\Big{\\left(\\frac{\\lambda-1+t}{\\lambda-t}\\right)}\\right)}")#linebreak()#text(" for some constants ")#mi("A,B")#text(". We see from substituting this expression into (*) that we must have ")#mi("A=0")#text(". Since any scalar multiple of an eigenfunction is also an eigenfunction, WLOG we may take ")#mi("B=1")#text(". To calculate ")#mi("\\lambda")#text(" we notice that the eigenfunction equation for ")#mi("P")#text(" requires that ")#mi("P(1)=0")#text(". This gives the equation")#linebreak()#text(" ")#mi("2-\\frac{1}{\\lambda}+\\log\\Big{\\left(1-\\frac{1}{\\lambda}\\right)}=0")#linebreak()#text(" mentioned above. For such a ")#mi("\\lambda")#text(", we have then found the unique eigienfunction (it is easy to verify that this is an eigenfunction) given by ")#mi("F(x,y)=P(x)+P(y)")#text(" with")#linebreak()#text(" ")#mi("P(t)=\\frac{2\\lambda-1}{\\lambda-1+t}-\\log\\Big{\\left(\\frac{\\lambda-1+t}{\\lambda-t}\\right)}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257443")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Along the lines of finding a set ")#mi("R\\subset [0,1]^{3}")#text(" for which ")#mi("R+R")#text(" lies in the non-convex region Terry described above, the following is a choice which is symmetric in all three variables. (It’s not clear to me whether this domain is better than the one already being used, but it may be worth a shot.)")

#text("The region is simply")

#mi("R= \\{(x,y,z)\\ :\\ x+y+z\\leq 3/2\\}\\cap [0,1]^{3}")#text(".")

#text("I like to visualize the increasing sequence of domains (in the ")#mi("k=3")#text(" case) as follows. The domain used for computing ")#mi("M_3")#text(" is obtained by slicing the cube ")#mi("[0,1]^{3}")#text(" along the plane ")#mi("x+y+z\\leq 1")#text(" (containing three corners of the cube), leaving behind a tetrahedron.")

#text("The domain used for computing ")#mi("M_3^{\\prime}")#text(" is found by taking the tetrahedron we just described, and gluing another tetrahedron along the same plane ")#mi("x+y+z\\leq 1")#text(", with the new tetrahedron having a pinnacle at the point ")#mi("(1/2,1/2,1/2)")#text(".")

#text("The new region described above also contains the point ")#mi("(1/2,1/2,1/2)")#text(", and indeed we slice the cube ")#mi("[0,1]^{3}")#text(" along the plane ")#mi("x+y+z\\leq 3/2")#text(", which contains ")#mi("(1/2,1/2,1/2)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257445")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Alternatively, one can view this new region as cutting a cube exactly in half (with the cutting plane perpendicular to opposite corners). So the area of this new region matches that of the other one currently being used.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257455")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("I’m not sure whether this was Pace’s motivation, but it’s worth noting that even if Pace’s new suggestion for R is no larger than R”, the fact that it is symmetric in 1..k may very well make it much easier to identify an algorithm for dissecting it appropriately when k>3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257466")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("It took a while to figure out how to dissect Pace’s half-cube ")#mi("R = \\{ (x,y,z) \\in [0,1]^3: x+y+z  \\leq\\frac{3}{2}\\}")#text(" – in fact I eventually had to use my son’s construction toy set to visualise it – but I think I have a dissection into 13 pieces so that all the constraints become polynomial. First there is the base polytope")

#mi("R^{\\prime}_3 := \\{ (x,y,z): x+y,y+z,z+x \\leq 1 \\}")#text(".")

#text("Then there are three simplices ")#mi("A_x, A_y, A_z")#text(", where")

#mi("A_x := \\{ x \\leq 1 \\leq x+y, x+z; x+y+z \\leq \\frac{3}{2} \\}")

#text("and similarly for cyclic permutations of x,y,z; there are also three simplices ")#mi("B_x,B_y,B_z")#text(", where")

#mi("B_x:= \\{ x \\geq 0; y,z \\geq \\frac{1}{2}; x+y+z \\leq \\frac{3}{2} \\}")

#text("and similarly for cyclic permutations; and finally there are six simplices ")#mi("C_{xyz}, C_{xzy}, C_{yxz}, C_{yzx}, C_{zxy}, C_{zyx}")#text(", where")

#mi("C_{xyz} := \\{ x \\leq 1/2; z \\geq 0; x+y \\geq 1; y+z \\leq 1 \\}")

#text("and similarly for arbitrary permutations.")

#text("A symmetric function F can be specified by its values on R’_3 (which are arbitrary), together with its values ")#mi("F_{A_x}, F_{B_x}, F_{C_{xyz}}")#text(" on ")#mi("A_x, B_x, C_{xyz}")#text(" respectively, with ")#mi("F_{A_x}, F_{B_x}")#text(" being symmetric wrt y and z interchange. The vanishing marginal constraints, by symmetry, just assert that ")#mi("\\int F(x,y,z)\\ dz = 0")#text(" for ")#mi("x+y \\geq 1")#text(", and ")#mi("y \\leq x")#text(", which become")

#mi("\\int_0^{1-x} F_{C_{xyz}}(y,x,z)\\ dz + \\int_{1-x}^{3/2 - x - y} F_{A_x}(x,y,z)\\ dz = 0")

#text("when ")#mi("y \\leq 1/2")#text(", and")

#mi("\\int_0^{3/2-x-y} F_{B_x}(z,y,x)\\ dz = 0")

#text("when ")#mi("y > 1/2")#text(". (But this should probably be checked.)")

#text("With this new polytope, I have an upper bound ")#mi("\\tilde M^{\\prime\\prime}_3 \\leq \\frac{3}{2} M_3 \\approx 2.46")#text(", just because ")#mi("R \\subset \\frac{3}{2} \\cdot {\\cal R}_3")#text(". This is larger than the bound ")#mi("M_2 + 1 \\approx 2.356")#text(" for the prism ")#mi("\\{ x+y,z \\leq 1\\}")#text(", which is perhaps a hopeful sign, although the upper bound here is cruder because the role of the corners of ")#mi("\\frac{3}{2}\\cdot {\\cal R}_3")#text(" poking out of [0,1]^3 are ignored.")

#text("I don’t see yet though how to dissect either of the two four-dimensional candidate polytopes, namely the prism ")#mi("\\{ x+y+z, w \\leq 1 \\}")#text(" and the truncated simplex ")#mi("\\{ x,y,z,w \\leq 1; x+y+z+w \\leq \\frac{4}{3} \\}")#text(". (Certainly my son’s construction set is no longer of use here!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257548")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Is it possible to state in purely geometrical terms what it means for a polyhedron (or polytope, but let’s start with k=3) to have polynomial moment conditions? I would like to play with possibilities for doing the chopping-up of candidate R’s systematically for k > 3, and I’m thinking that there may be alternative dissections that are superficially inferior (involve more pieces, in particular) but that turn out to be easier to generalise to larger k, but this is hard to get one’s head around without a geometrical sense of what makes a dissection admissible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("The precise problem is this: given a polytope ")#mi("R \\subset [0,1]^k")#text(", subdivide it into subpolytopes ")#mi("P_1,\\ldots,P_m")#text(", such that for each polytope ")#mi("P_i")#text(" and each ")#mi("1 \\leq j \\leq k")#text(", at least one of the following is true:")

#text("(1) The projection of ")#mi("P_i")#text(" to ")#mi("{\\bf R}^{k-1}")#text(" under the operation ")#mi("\\pi_j: (t_1,\\ldots,t_k) \\to (t_1,\\ldots,t_{j-1},t_{j+1},\\ldots,t_k)")#text(" of deleting the ")#mi("t_j")#text(" coordinate maps ")#mi("P_i")#text(" to a subset of ")#mi("{\\cal R}_{k-1}")#text(" (or equivalently, ")#mi("P_i")#text(" lies in the prism ")#mi("\\pi_j^{-1}({\\cal R}_{k-1})")#text(" (which is some permutation of ")#mi("{\\cal R}_{k-1} \\times [0,1]")#text("); or")

#text("(2) The polytope ")#mi("P_i")#text(" can be viewed as a region of the form")

#mi("\\{ t \\in \\pi_j^{-1}(\\pi_j(P_i)): f(\\pi_j(t)) \\leq t_j \\leq g(\\pi_j(t)) \\}")

#text("for some affine-linear functionals ")#mi("f, g")#text(". In other words, all but two of the faces of ")#mi("P_i")#text(" are parallel to the ")#mi("e_j")#text(" coordinate direction. (This makes the vanishing marginal condition in the e_j direction a linear one in the coefficients of F, if F is piecewise polynomial on each of the P_i.)")

#text("In order to ensure that we recover at least ")#mi("M^{\\prime}_k")#text(" in our optimisation problem, we also need to require that one of the polytopes in the partition is equal to ")#mi("{\\cal R}^{\\prime}_k")#text(". (In particular, the trivial partition in which m=1 is useless, as it only gives the trivial lower bound of 0 for M”_k.)")

#text("At present it is not obvious to me that an arbitrary polytope R actually admits such a finite subdivision; for any fixed j one can apply various slicing operations parallel to ")#mi("e_j")#text(" to make the subdivision good for that particular value of j, but this may introduce new problematic faces that ruin other values of j. The subdivisions I found so far were obtained by ad hoc means, and I don’t immediately see how to generalise them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257558")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Actually, it just occurred to me that we don’t, strictly speaking, need the polytopes to obey condition (2); if there are more faces that are transverse to ")#mi("e_j")#text(", then we get more vanishing conditions, which reduces the number of degrees of freedom for a given degree of piecewise polynomial, but still in principle allows us to approach the optimal M”_k by using a sufficiently high degree. So one may be able to get by with a coarser partition that has more transverse faces, if the degrees of freedom tradeoff is favorable.")

#text("James: perhaps it may be a good idea to organise your code in such a way that one can easily swap in different partitions, polytopes, degree parameters, etc., to give some comparative numerical study of performance of different partitions in the k=3 case, which may give us some useful guidance before plunging into the all-important k=4 case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257409")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Many thanks James – and, in advance, for the details. In particular, can you elaborate on the basis of your remark concerning ")#mi("M^{\\prime\\prime}_4")#text(" ? – I was presuming that there is no simple algorithm for dissecting ")#mi("R^{\\prime\\prime}_k")#text(" with ")#mi("k > 3")#text(" according to Eytan’s idea, which is surely a prerequisite for making any such estimate, but maybe there is one?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257419")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Aubrey: I agree there is no simple algorithm at present. The same sort of decompositions should work for ")#mi("M_4^{\\prime\\prime}")#text(", although the decomposition will probably be in many more pieces. I think it should be tedious but probably relatively straightforward to do it by hand.")

#text("My comment regarding this improvement potentially not getting all the way to ")#mi("M_4^{\\prime\\prime}>2")#text(" was because we need an improvement of about 0.063 on the current bound for ")#mi("M_4^{\\prime}")#text(". When ")#mi("k=3")#text(" we appear to get an improvement of 0.072 in going from ")#mi("M_3^{\\prime}")#text(" to ")#mi("M_3^{\\prime\\prime}")#text(". My guess was that the improvement in moving from ")#mi("M_k^{\\prime}")#text(" to ")#mi("M_k^{\\prime\\prime}")#text(" would decrease quite quickly in ")#mi("k")#text(" (as it does moving from ")#mi("M_k")#text(" to ")#mi("M_k^{\\prime}")#text("), and so the current improvement of 0.072 would probably decrease to below the required 0.063. This is just my guess though (I have no proof of this) – it would be nice if I was wrong on this front.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257424")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Well, from a volume perspective at least, ")#mi("{\\cal R}^{\\prime\\prime}_k")#text(" has much bigger volume (")#mi("\\frac{1}{(k-1)!}")#text(", compared with ")#mi("\\frac{1}{(k-1) (k-1)!}")#text(" for ")#mi("{\\cal R}^{\\prime}_k")#text(" and ")#mi("\\frac{1}{k (k-1)!}")#text(" for ")#mi("{\\cal R}_k")#text("), which gives one hope. Of course, much of this extra volume is somehow “cancelled out” by the additional vanishing marginal conditions, so things are inconclusive.")

#text("This is a degenerate data point, but the improvement from M’_2 to M”_2 is precisely zero, so the improvement certainly got better going from k=2 to k=3. Perhaps going from k=3 to k=4 we still have a little bit of upward monotonicity – well, we can hope, anyway :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257582")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I’ll try to give some more details of my calculations (and hopefully if I’ve made a mistake someone will spot it). I’m not sure that I’m explaining this in the clearest language, but I hope it makes sense.")

#text("As described in Terry’s post, we are looking at polynomials ")#mi("F_0,F_1,F_1^{\\prime},F_2,F_2^{\\prime},F_3,F_3^{\\prime}")#text(" supported on ")#mi("D_0,D_1,D_1^{\\prime},D_2,D_2^{\\prime},D_3,D_3^{\\prime}")#text(" respectively.")

#text("Let’s concentrate on the calculation of ")#mi("J_x=\\int\\int\\Big{\\left(\\int F dx\\right)}^2dydz")#text(", the calculations of ")#mi("J_y,J_z,I")#text(" being similar.")

#text("I considered the projections of ")#mi("D_0\\dots d_3^{\\prime}")#text(" onto the ")#mi("y,z")#text(" plane. For example, the projection of ")#mi("D_1")#text(" is given by ")#mi("\\{(y,z):y\\leq 1/2\\leq z\\leq 1-y\\}")#text(". Based on these projections, I split the ")#mi("y,z")#text(" plane into 6 disjoint polytopes given by")#linebreak()#text(" ")#mi("E_0=\\{0   \\leq z \\leq 1/2, z\\leq y\\leq 1-z \\}")#linebreak()#text(" ")#mi("E_1=\\{1/2\\leq z \\leq 1   , 0\\leq y\\leq 1-z \\}")#linebreak()#text(" ")#mi("E_2=\\{0   \\leq z \\leq 1/2, 0\\leq y\\leq z \\}")#linebreak()#text(" ")#mi("E_3=\\{1/2\\leq z \\leq 1,    1-z\\leq y\\leq 1/2 \\}")#linebreak()#text(" ")#mi("E_4=\\{1/2\\leq z \\leq 1,    1/2\\leq y\\leq z\\}")#linebreak()#text(" ")#mi("E_5=\\{0   \\leq y \\leq 1/2, 1-y\\leq z\\leq y\\}")#linebreak()#text(" These were formed by just splitting the projections so that each region ")#mi("E_j")#text(" had a fixed set of the ")#mi("D_i")#text(" regions which projected to it (and those regions projected onto the whole of ")#mi("E_j")#text("). Since the ")#mi("D_i")#text(" regions were given by a set of linear inequalities, so too were the ")#mi("E_j")#text(" regions (and in particular they are convex).")

#text("The point of these regions is that for ")#mi("y,z")#text(" in any region the integration over ")#mi("x\\in D_i")#text(" can then be written as integration over an interval. We see that the integration over ")#mi("x")#text(" for ")#mi("y,z\\in E_3,E_4,E_5")#text(" must be zero from our marginal conditions (since ")#mi("y+z\\ge1")#text(").")

#text("Over each region, we can write down the integration ")#mi("\\int F dx")#text(":")#linebreak()#text(" ")#mi("E_0: \\int_0^{1-y}F_0dx")#linebreak()#text(" ")#mi("E_1: \\int_0^{1-z}F_0dx+\\int_{1-z}^zF_1dx+\\int_z^{1-y}F_2dx")#linebreak()#text(" ")#mi("E_2: \\int_0^{1-z}F_0dx+\\int_{1-z}^{1-y}F_2dx")#linebreak()#text(" The regions of integration for ")#mi("x")#text(" over ")#mi("E_3,E_4,E_5")#text(" correspond exactly to the vanishing conditions terry wrote above.")

#text("Thus we can perform the above integrations for ")#mi("E_0,E_1,E_2")#text(" with respect to ")#mi("x")#text(", square, and then integrate over the regions ")#mi("E_0,E_1,E_2")#text(". This gives our expression for ")#mi("J_x")#text(" as a quadratic form in the coefficients of ")#mi("F_0,F_1,F_1^{\\prime},F_2,F_2^{\\prime},F_3,F_3^{\\prime}")#text(".")

#text("To enforce the vanishing marginal conditions, we simply calculate the polynomials given by Terry above (i.e. the 2-variable polynomials obtained by integrating with respect to ")#mi("y")#text("). Each coefficient of a monomial ")#mi("x^i z^j")#text(" gives a (homogeneous) linear constraint on our coefficients. By simply using each linear constraint to eliminate one variable at a time from the quadratic form ")#mi("J_x")#text(", we arrive at a reduced quadratic form which satisifies all the vanishing marginal conditions. Doing the same for ")#mi("I,J_y,J_z")#text(" then gives us the ratio of two quadratic forms, which is our quadratic programming problem from before.")

#text("It should be relatively straightforward to modify my code so that given a decomposition into polytopes given by inequalities ")#mi("L_1\\le t_1\\le L_1, L_2(t_1)\\leq t_2\\leq L_2^{\\prime}(t_1),\\dots , L_n(t_1,\\dots,t_{n-1})\\leq t_n\\leq L_n^{\\prime}(t_1,\\dots,t_{n-1})")#text(" for linear functions ")#mi("L_j,L^{\\prime}_j:\\mathbb{R}^{j-1}\\rightarrow \\mathbb{R}")#text(" it can calculate the quadratic form corresponding to the integration over the polytope.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257584")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Also, unless I’m missing something, I think in principle there should be a fairly simple algorithm for decomposing any region given by linear inequalities to polytopes of the type we desire.")

#text("Assume we are given some region ")#mi("\\mathcal{R}^{\\prime\\prime}")#text(" which is given by a set of linear inequalities in the variables ")#mi("t_1,\\dots,t_k")#text(". We can split this into ")#mi("2^k")#text(" subregions ")#mi("D_1,\\dots")#text(" depending on which of the forms ")#mi("g_j=\\sum_{i\\ne j}t_i")#text(" are greater than 1, and which are less than 1. Each such subregion will also just be given by a set of linear inequalities. We let ")#mi("F")#text(" be a fixed polynomial ")#mi("F_i")#text(" on each such region ")#mi("D_i")#text(". Since we know exactly which of the functions ")#mi("g_j")#text(" are greater than 1 on ")#mi("D_i")#text(", each region comes with a set of ")#mi("m")#text(" vanishing marginal conditions, where ")#mi("m")#text(" is the number of the ")#mi("g_i")#text(" which are greater than 1.")

#text("Each region ")#mi("D_i")#text(" can be further decomposed into regions ")#mi("E_{i,j}")#text(" which are of the form ")#mi("L_1\\leq t_1\\leq L_1^{\\prime},\\dots, L_k(t_1,\\dots,t_{k-1})\\leq t_k\\leq L_k^{\\prime}(t_1,\\dots,t_{k-1})")#text(" for linear functions ")#mi("L_j,L_j^{\\prime}:\\mathbb{R}^{j-1}\\rightarrow\\mathbb{R}")#text(". (Proof: induction on ")#mi("k")#text(". Since ")#mi("D_i")#text(" is given by a set of linear inequalities, the lower and upper bounds for ")#mi("t_k")#text(" are given by the maximum and minimum of a set of linear functions in ")#mi("t_1,\\dots t_{k-1}")#text(". For a each ordering of these functions, this gives a upper bound and lower bound for ")#mi("t_k")#text(" which is linear. Then we use the induction hypothesis, since the remaining variables are constrained only by linear inequalities).")

#text("We then decompose the projections in the ")#mi("t_k")#text(" coordinate of the ")#mi("E_{i,j}")#text(" regions as above (so we have regions where each region is projected to from a fixed set of the ")#mi("E_{i,j}")#text("). This means on each of these subregions (which are also just given by linear inequalities) the integral of ")#mi("F")#text(" with respect to ")#mi("t_k")#text(" is given by a finite sum of integrals of ")#mi("F_i")#text(" over intervals. Thus we can calculate all these integrals explcitly and calculate the quadratic form ")#mi("J_{t_k}")#text(". Similarly for the other ")#mi("J")#text(" regions.")

#text("We still need to apply the linear constraints, but by following exactly the same method above, we can calculate the various degree ")#mi("k-1")#text(" polynomials corresponding to the vanishing marginals, which gives a set of homogeneous linear constraints on the coefficients of the ")#mi("F_i")#text(". Eliminating variables from the quadratic forms then gives reduced quadratic forms satisfying the vanishing conditions.")

#text("Since everything is just given by linear constraints at each stage, everything remains convex so we avoid issues to do with a lack of convexity.")

#text("Obviously the above would give some huge number of decompositions if done directly. We can save a lot for small ")#mi("k")#text(" by using symmetry and sometimes switching the orderings of the variables to mean we only have to consider fewer regions. Thus it is probably the case that it is still better to do things by hand.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257590")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Splendid! Hm, but if an economical decomposition is hard to find even for k=4, maybe it is worth seeking an algorithm to convert your decomposition into something with a more manageable number of components. The first approach that springs to mind is to do the decomposition as you describe and then iteratively examine each pair of component polytopes that share a (k-1)-dimensional polytope, to see whether their union satisfies the necessary conditions, and merge them if it does. Is there any reason why that would be expected to run into the sand unhelpfully quickly?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257592")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("In case my first post isn’t clear, I thought I’d try to write out explicitly what I get for some of the integrals. (Also it might make any mistakes I made clearer – there are enough terms that I can’t rule out I’ve made a small mistake somewhere).")

#text("Not assuming symmetry, I find that")#linebreak()#text(" ")#mi("J_x=J_{x,1}+J_{x,2}+J_{x,3},")#linebreak()#text(" where")#linebreak()#text(" ")#mi("J_{x,1}=\\int_0^{1/2}\\int_{z}^{1-z}\\Big{\\left(\\int_0^{1-y}F_0dx\\right)}^2dydz")#linebreak()#text(" ")#mi("J_{x,2}=\\int_{1/2}^1\\int_0^{1-z}\\Big{\\left(\\int_0^{1-z}F_0dx+\\int_{1-z}^zF_1dx+\\int_z^{1-y}F_2dx\\right)}^2dydz")#linebreak()#text(" ")#mi("J_{x,3}=\\int_0^{1/2}\\int_{0}^z\\Big{\\left(\\int_0^{1-z}F_0dx+\\int_{1-z}^{1-y}F_2dx\\right)}^2dydz")#linebreak()#text(" And this is subject to the three vanishing marginal conditions")#linebreak()#text(" ")#mi("\\int_y^{1-y} F^{\\prime}_3dx+\\int_0^{1-z}F_1^{\\prime}dx+\\int_{1-z}^yF_3dx=0")#linebreak()#text(" ")#mi("\\int_0^{1-z}F_1^{\\prime}dx+\\int_{1-z}^{1-y}F_3dx=0")#linebreak()#text(" ")#mi("\\int_0^{1-y} F^{\\prime}_2dx=0")#linebreak()#text(" The expression for ")#mi("J_y")#text(" is essentially the same, swapping all instances of ")#mi("y")#text(" with ")#mi("x")#text(" in the integration variables and limits, and swapping the functions ")#mi("F_i")#text(" with ")#mi("F_i^{\\prime}")#text(" everywhere.")

#text("For ")#mi("J_z")#text(" I obtained")#linebreak()#text(" ")#mi("J_z=J_{z,1}+J_{z,2}+J_{z,3}+J_{z,4}")#linebreak()#text(" where")#linebreak()#text(" ")#mi("J_{z,1}=\\int_0^{1/2}\\int_{1/2}^{1-y}")#linebreak()#text(" ")#mi("\\Big{\\left(\\int_0^{1-x}F_0+\\int_x^{1-y}F_1+\\int_{1-x}^xF_2+\\int_{1-y}^1F_3^{\\prime} dx\\right)}^2dxdy")#linebreak()#text(" ")#mi("J_{z,2}=\\int_{1/2}^1\\int_0^{1-y}")#linebreak()#text(" ")#mi("\\Big{\\left(\\int_0^{1-y}F_0+\\int_y^{1-x}F_1^{\\prime}+\\int_{1-y}^yF_2^{\\prime}+\\int_{1-x}^1F_3dz\\right)}^2dxdy")#linebreak()#text(" ")#mi("J_{z,3}=\\int_0^{1/2}\\int_y^{1/2}\\Big{\\left(\\int_0^{1-x}F_0+\\int_{1-x}^{1-y}F_1+\\int_{1-y}^1F_3^{\\prime}dz\\right)}^2dxdy")#linebreak()#text(" ")#mi("J_{z,4}=\\int_0^{1/2}\\int_0^{y}\\Big{\\left(\\int_0^{1-y}F_0+\\int_{1-y}^{1-x}F_1^{\\prime}+\\int_{1-x}^1F_3dz\\right)}^2dxdy")#linebreak()#text(" There are no vanishing conditions for ")#mi("J_z")#text(" since we are restricting to ")#mi("x+y\\leq 1")#text(" anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257621")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("James, did you get a chance to try the computation for ")#mi("k=3")#text(" on the new domain I described above (which Terry was kind enough to work out the linear constraints for)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257622")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I think my comments above can give a relatively straightforward decomposition of the region")#linebreak()#text(" ")#mi("\\mathcal{R}^{\\prime\\prime}_4=\\{(x,y,z,w)\\in[0,1]^4:x+y+z\\leq 1\\}.")#linebreak()#text(" We split ")#mi("\\mathcal{R}^{\\prime\\prime}_4")#text(" into 8 subregions which I’ll label ")#mi("D_0,D_x,D_y,D_z,D_{xy},D_{xz},D_{yz},D_{xyz}")#text(". To ease notation let ")#mi("L_x=y+z+w")#text(" and similarly define ")#mi("L_y,L_z,L_w")#text(" which are the forms which are the sum of all variables except for ")#mi("y,z")#text(" or ")#mi("w")#text(" respectively. Then")#linebreak()#text(" ")#mi("D_0=\\{L_x,L_y,L_z,L_w\\leq 1\\}")#linebreak()#text(" ")#mi("D_x=\\{L_y,L_z,L_w\\leq 1\\leq L_x\\}")#linebreak()#text(" ")#mi("D_{xy}=\\{L_z,L_w\\leq 1\\leq L_x,L_y\\}")#linebreak()#text(" ")#mi("D_{xyz}=\\{L_w\\leq 1\\leq L_x,L_y,L_z\\}")#linebreak()#text(" and similarly for ")#mi("D_y,D_z,D_{xz},D_{yz}")#text(" (the subscripts are indicating which of the ")#mi("L_i")#text(" are greater than 1).")

#text("We choose our function ")#mi("F")#text(" to be a polynomial ")#mi("F_i")#text(" of each region ")#mi("D_i")#text(". (For the time being I won’t assume any symmetry, although this can be used to simplify things later).")

#text("To calculate ")#mi("J_w=\\int\\int\\int\\Big{\\left(\\int F dw\\right)}^2dxdydz")#text(":")#linebreak()#text(" We split the ")#mi("x,y,z")#text(" space into 6 subregions given by ")#mi("E_{x,y,z}")#text(" and all permutations of the subscripts. (For the ")#mi("E")#text(" regions the subsripts are intended to be ordered, whist the ")#mi("D")#text(" regions the subscripts are unordered). The region ")#mi("E_{x,y,z}")#text(" is given by")#linebreak()#text(" ")#mi("E_{x,y,z}=\\{x\\leq y\\leq z, x+y+z\\leq 1\\},")#linebreak()#text(" and similarly for all other ")#mi("E_i")#text(" regions.")

#text("If we restrict to ")#mi("(x,y,z)\\in E_j")#text(", then the inner integration ")#mi("\\int F dw")#text(" is a sum of integrals of the functions ")#mi("F_i")#text(" over intervals. For example, for ")#mi("(x,y,z)\\in E_{x,y,z}")#text(" we find ")#mi("\\int F dw")#text(" is given by")#linebreak()#text(" ")#mi("\\int_0^{1-z-y}F_0+\\int_{1-y-z}^{1-x-y}F_x+\\int_{1-x-y}^{1-x-z}F_{xy}+\\int_{1-x-z}^1F_{xyz}")#linebreak()#text(" It is easy to write explicit limits for the integration with respect to ")#mi("x,y,z")#text(" for any region ")#mi("E_{i}")#text(". Thus we can calculate the quadratic form ")#mi("J_w")#text(". There are no vanishing marginal restrictions here.")

#text("To calculate ")#mi("J_x")#text(" we follow a similar approach. We again split the ")#mi("y,z,w")#text(" space into regions ")#mi("E_{y,z,w}")#text(" etc giving the orderings of the sizes of ")#mi("z,y,w")#text(". However, we further split ")#mi("E_{y,z,w}")#text(" into ")#mi("E_{y,z,w}^+")#text(" and ")#mi("E_{y,z,w}^-")#text(" depending on whether ")#mi("y+z+w\\geq 1")#text(" or ")#mi("y+z+w\\leq 1")#text(". For example, we obtain for ")#mi("(y,z,w)\\in E_{y,w,z}^-")#linebreak()#text(" ")#mi("\\int F dx=\\int_0^{1-w-z}F_0dx+\\int_{1-w-z}^{1-z-y}F_y dx")#linebreak()#text(" whilst for ")#mi("(y,z,w)\\in E_{y,w,z}^+")#text(" we obtain the vanishing condition")#linebreak()#text(" ")#mi("\\int F dx=\\int_0^{1-w-z}F_x dx+\\int_{1-w-z}^{1-z-y}F_{xy} dx=0.")

#text("By symmetry, in this case we only need to consider functions ")#mi("F")#text(" for which ")#mi("F(x,y,z,w)=F(\\sigma(x),\\sigma(y),\\sigma(z),w)")#text(" for any permutation ")#mi("\\sigma")#text(" of ")#mi("x,y,z")#text(". This should reduce the search space significantly. For example, ")#mi("F_0")#text(" and ")#mi("F_{xyz}")#text(" will be symmetric in ")#mi("x,y,z")#text(", whilst ")#mi("F_x,F_{yz}")#text(" will be symmetric in ")#mi("y,z")#text(" but equal to one of the other functions under transpositions of ")#mi("x,z")#text(" or ")#mi("y,x")#text(".")

#text("I haven’t had a chance to actually try to compute anything with this yet, though. I also haven’t had a chance to compute with Pace’s alternative region. (Work to do, although I’ll be busy with other things for most of tomorrow.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2013")])]

#text("I can get rid of the final ")#mi("\\log\\log\\log k")#text(" error in the asymptotic lower bound for ")#mi("M_k")#text(", thus")

#mi("M_k \\geq \\log k - O(1)")#text(".")

#text("I’m recording a sketch of the argument below; I may give a more detailed proof for the next blog post.")

#text("The basic idea is to do a defect analysis of the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(". We first observe that the Cauchy-Schwarz upper bound")

#mi("(\\int F)^2 \\leq (\\int F^2 / h) (\\int h),")#text(" (1)")

#text("valid for reasonable non-negative functions ")#mi("F, h")#text(", can be matched with the lower bound")

#mi("(\\int F)^2 \\geq (\\int F^2 / h) (\\int h) - (\\int (F-ah)^2/h) (\\int h)")#text(" (2)")

#text("for any scalar a (independent of the variable of integration). Indeed, the right-hand side can be calculated to be ")#mi("(\\int F)^2 - (\\int (F-ah))^2")#text(".")

#text("Now, recall that the upper bound ")#mi("M_k \\leq \\frac{k}{k-1} \\log k")#text(" comes from the inequality")

#mi("(\\int_0^\\theta F\\ dt_k)^2 \\leq \\frac{\\log k}{k-1} \\int_0^\\theta F^2 (\\theta + (k-1)t_k)\\ dt_k")

#text("for any ")#mi("t_1,\\ldots,t_{k-1} \\in {\\cal R}_{k-1}")#text(", where ")#mi("\\theta := 1-t_1-\\ldots-t_{k-1}")#text(" and ")#mi("F")#text(" is short for ")#mi("F(t_1,\\ldots,t_k)")#text("; this comes from applying (1) with ")#mi("h(t_k) := \\frac{1}{\\theta + (k-1)t_k}")#text(". Integrating this in the variables ")#mi("t_1,\\ldots,t_{k-1}")#text(" and then symmetrising gives the upper bound.")

#text("Now we make the usual choice of testing")

#mi("F(t_1,\\ldots,t_k) := 1_{t_1+\\ldots+t_k \\leq 1} g(t_1) \\ldots g(t_k)")

#text("where ")#mi("g = G 1_{[0,T]}")#text(" and ")#mi("G(t) := \\frac{1}{c+(k-1)t}")#text(", where ")#mi("c,T>0")#text(" are parameters at our disposal; a good choice here is ")#mi("c = 1/\\log k")#text(" and ")#mi("T = \\varepsilon/\\log k")#text(" for a small absolute constant ")#mi("\\varepsilon")#text(". Applying (2) with ")#mi("a := g(t_1) \\ldots g(t_{k-1})")#text(", we obtain that")

#mi("(\\int_0^\\theta F\\ dt_k)^2 \\geq \\frac{\\log k}{k-1} \\int_0^\\theta F^2 (\\theta + (k-1)t_k)\\ dt_k")#linebreak()#text(" ")#mi("- g(t_1)^2 \\ldots g(t_{k-1})^2 \\frac{\\log k}{k-1} \\int_0^\\theta (g - h)^2/h")#text(".")

#text("If we symmetrise, and let ")#mi("X_1,\\ldots,X_k")#text(" be iid random variables with law ")#mi("\\frac{1}{m_2} g(t)^2\\ dt")#text(", where ")#mi("m_2 := \\int g^2")#text(", then")

#mi("\\int_{{\\cal R}_k} F^2 = m_2^k P")

#text("where ")#mi("P := {\\bf P}( X_1 + \\ldots + X_k \\leq 1 )")#text(", and hence")

#mi("M_{k-1} \\geq \\frac{k}{k-1} \\log k - \\frac{1}{P m_2} \\frac{k \\log k}{k-1} {\\bf E} \\int_0^\\theta (g - h)^2/h")

#text("where ")#mi("\\theta")#text(" is now interpreted as ")#mi("\\theta := 1 - X_1 - \\ldots - X_{k-1}")#text(", and the integral is interpreted as vanishing if ")#mi("\\theta")#text(" is negative. One can compute that ")#mi("m_2 \\sim \\frac{\\log k}{k}")#text(", and from the second moment ")#mi("P \\sim 1")#text(" if ")#mi("\\varepsilon")#text(" is small enough, so")

#mi("M_{k-1} \\geq \\frac{k}{k-1} \\log k - O( k {\\bf E} \\int_0^\\theta (g - h)^2/h )")

#text("The integral ")#mi("\\int_0^\\theta (g - h)^2/h")#text(" may be bounded by the sum of")

#mi("\\int_T^\\theta h")

#text("(which by convention vanishes if ")#mi("\\theta \\leq T")#text(") and")

#mi("\\int_0^\\theta (G-h)^2/h")#text(".")

#text("The first term may be bounded by")

#mi("\\int_T^\\theta \\frac{1}{(k-1)t}\\ dt = \\frac{1}{k-1} \\log \\frac{\\theta}{T}.")

#text("For the second term, we use the identity ")#mi("G-h = (\\theta-c) Gh")#text(" to write this integral as")

#mi("(\\theta-c)^2 \\int_0^\\theta G^2 h")

#text("when ")#mi("\\theta \\geq c")#text(", and")

#mi("(c-\\theta) \\int_0^\\theta G (h-G)")

#text("when ")#mi("\\theta \\leq c")#text(".")

#text("When ")#mi("\\theta \\geq c")#text(", we crudely bound ")#mi("(\\theta-c)^2 \\leq \\theta^2")#text(", ")#mi("h \\leq 1/\\theta")#text(" to bound this integral by ")#mi("\\theta \\int G^2 = O( \\frac{1}{k} \\frac{\\theta}{c} )")#text(". When ")#mi("\\theta \\leq c")#text(", we bound ")#mi("h-G \\leq h")#text(" and ")#mi("(c-\\theta) Gh = h-G")#text(" to bound this integral by ")#mi("\\int h-G = O( \\frac{1}{k} \\log \\frac{c}{\\theta} )")#text(". Putting all this together, we see that")

#mi("M_k \\geq \\frac{k}{k-1} \\log k - O( {\\bf E} \\log_+ \\frac{\\theta}{T} + \\max( \\frac{\\theta}{c}, \\log \\frac{c}{\\theta} )")

#text("where we are implicitly reducing to the event that ")#mi("\\theta")#text(" is positive.")

#text("The second moment method shows that ")#mi("\\theta")#text(" has mean ")#mi("O( 1/\\log k )")#text(" and variance ")#mi("O( 1/\\log^2 k )")#text("; this makes all the error terms ")#mi("O(1)")#text(" except possibly for the ")#mi("\\log \\frac{c}{\\theta}")#text(" term, but this can also be made to be O(1) by an averaging argument (dilating the g’s by ")#mi("1 + O(1/\\log x)")#text(" and using the pigeonhole principle).")

#text("In principle this analysis might give better numerics for the m=2 bound, but it’s a bit messy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2865f968936d49bf25378451892fe21b5008575ff0f435b2c98ee89aa6957080-997ef30b72a70d6066724f69bbf1faf08c34e3048c0f9afe2532ae7ef1ea26bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Granville")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257474")[#strong[#text("Andrew Granville")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Terry: please can you give more details when you write “the \\log \\frac{c}{\\theta} term … can also be made to be O(1) by an averaging argument (dilating the g’s by 1 + O(1/\\log x) and using the pigeonhole principle).” ?")#linebreak()#text(" In my own failed efforts at proving something like this, I got stuck precisely when the range for t_k is tiny (ie reducing this term). Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257534")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I wrote up some more details of the argument (with explicit error terms, which unfortunately makes things messy) at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")]

#text("The averaging argument ends up being easier to run as follows: if we let ")#mi("F_r")#text(" be the truncation ")#mi("g(t_1) \\ldots g(t_k) 1_{t_1+\\ldots+t_k \\leq r}")#text(" of a tensor product to the dilated simplex ")#mi("r \\cdot {\\cal R}_k")#text(", then we have")

#mi("J_k^{(1)}(F_r) \\leq \\frac{r}{k} M_k I_k(F_r).")

#text("We manipulate this inequality as discussed previously, converting it into an upper bound for the defect ")#mi("\\frac{k}{k-1} \\log k - M_k")#text(" in terms of various integrals involving g and r. When one arrives at the problematic logarithmic singularity, one can then average in r (noting that the defect is independent of r).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257780")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("Can the ")#mi("O(1)")#text(" estimate be made effectively computable ? (or even be optimized for each given ")#mi("k")#text(" ?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("It is certainly effective; I don’t know yet whether it is competitive with our existing bounds for m=2, but it should certainly give reasonable bounds for higher m for the first time. I’ll try to work out some more details later today..")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("After playing around with Maple, I was only able to get the O(1) loss in ")#mi("M_k \\geq \\frac{k}{k-1} \\log k - O(1)")#text(" down to about 4 or 5 for medium-sized values of k, which unfortunately does not beat the current estimates for m=1,2, and gives a pretty lousy estimate for m=3; I can get ")#mi("k=10^7")#text(" but not much better than this. (I was hoping to recover Zhang’s original value of k=3,500,000, so that we could now stuff four primes into this tuple instead of two, but fell short of this even with our best MPZ estimate.)")

#text("I’m recording the Maple code that gave ")#mi("k=10^7")#text(" in the m=3 case below. There are three free parameters ")#mi("c,T,\\tau")#text(" that one can optimise over, although I found in practice that a (somewhat artificial) constraint ")#mi("1-k\\mu-\\tau \\geq 0")#text(" that I had to impose at some point was dominant in the sense that it set the optimal value of ")#mi("\\tau")#text(" for a given c, T.")

#raw("\nk := 10000000;\nm := 3;")

#text("# These three parameters may be chosen arbitrarily")

#text("c := 1.08/log(k);")#linebreak()#text(" T := 0.41/log(k);")#linebreak()#text(" # tau := 1.14/log(k);")

#text("M0 := k*log(k)/(k-1);")#linebreak()#text(" g := 1/(c+(k-1)*t);")#linebreak()#text(" m2 := int(g*g, t=0..T );")#linebreak()#text(" mu := int(t*g*g, t=0..T )/m2;")#linebreak()#text(" sigma2 := int(t*t*g*g, t=0..T)/m2 - mu*mu;")

#text("tau := 1 - k*mu;")

#text("denominator := (1+tau/2)*(1 - (k*sigma2)/((1+tau-k*mu)^2));")

#text("a := (r - k*mu) / T;")#linebreak()#text(" S := r * (log((r-k*mu)/T) +(k*sigma2)/(4*a*a*T*T*log(a)) ) + r*r/(4*k*T);")#linebreak()#text(" Sav := int(S, r=1..1+tau, numeric)/tau;")

#text("Z3 := int( g*g*k*t*log(1+t/T), t=0..T, numeric) / m2;")#linebreak()#text(" W := int( g*g*log(1+tau/(k*t)), t=0..T, numeric) / m2;")#linebreak()#text(" X:= (log(k)/tau) * ( (1-(k-1)*mu+max(tau-c,0))^2 +(k-1)*sigma2+ c^2 );")

#text("numerator := Sav + Z3 + W*X;")

#text("Delta := (k/(k-1)) * numerator/ denominator;")

#text("# these three quantities need to be positive")#linebreak()#text(" evalf( 1 - k*mu - T );")#linebreak()#text(" evalf( 1 - k*mu - tau );")#linebreak()#text(" evalf(denominator);")

#text("# this is the lower bound for M_k")#linebreak()#text(" evalf(M0-Delta);")

#text("varpi := m/(M0-Delta) - 1/4;")#linebreak()#text(" delta := T * ((1/4) + varpi);")

#text("# if this is less than 1, we win")#linebreak()#text(" evalf(1080*varpi/13+ 330*delta/13);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("I found a more efficient way to control one of the error terms (which I called Z_4 in the wiki page ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#Lower_bounds")]#text(" ), which gets the O(1) error down to about 2 or 3, which gets the m=3 value of k down to 1,700,000. The code below also gives a value of k=38,000 for m=2 (by setting c = 1.07/log(k) and T = 0.48/log(k)); presumably a little bit more optimisation is possible.")

#raw("\nk := 1700000;\nm := 3;")

#text("# These three parameters may be chosen arbitrarily")

#text("c := 1.06/log(k);")#linebreak()#text(" T := 0.46/log(k);")#linebreak()#text(" # tau := 1.14/log(k);")

#text("M0 := k*log(k)/(k-1);")#linebreak()#text(" g := 1/(c+(k-1)*t);")#linebreak()#text(" m2 := int(g*g, t=0..T );")#linebreak()#text(" mu := int(t*g*g, t=0..T )/m2;")#linebreak()#text(" sigma2 := int(t*t*g*g, t=0..T)/m2 - mu*mu;")

#text("tau := 1 - k*mu;")

#text("denominator := (1+tau/2)*(1 - (k*sigma2)/((1+tau-k*mu)^2));")

#text("a := (r - k*mu) / T;")#linebreak()#text(" S := r * (log((r-k*mu)/T) +(k*sigma2)/(4*a*a*T*T*log(a)) ) + r*r/(4*k*T);")#linebreak()#text(" Sav := int(S, r=1..1+tau, numeric)/tau;")

#text("Z3 := int( g*g*k*t*log(1+t/T), t=0..T, numeric) / m2;")#linebreak()#text(" W := int( g*g*log(1+tau/(k*t)), t=0..T, numeric) / m2;")#linebreak()#text(" X:= (log(k)/tau) * c^2;")

#text("V := (c/m2) * int( g^2 / (2*c+(k-1)*t) , t=0..T, numeric);")#linebreak()#text(" U := (log(k)/c) * int( (1+u*tau - (k-1)*mu - c)^2 + sigma2, u=0..1, numeric);")

#text("numerator := Sav + Z3 + W*X + V*U;")

#text("Delta := (k/(k-1)) * numerator/ denominator;")

#text("# this needs to be positive")#linebreak()#text(" evalf( 1 - k*mu - T );")#linebreak()#text(" evalf( 1 - k*mu - tau );")

#text("# this needs to be positive too")#linebreak()#text(" evalf(denominator);")

#text("# this is the lower bound for M_k")#linebreak()#text(" evalf(M0-Delta);")

#text("varpi := m/(M0-Delta) - 1/4;")#linebreak()#text(" delta := T * ((1/4) + varpi);")

#text("# if this is less than 1, we win")#linebreak()#text(" evalf(1080*varpi/13+ 330*delta/13);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257826")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("Taking the first ")#mi("k=10^7")#text(" primes greater than ")#mi("k")#text(" gives ")#mi("H(k) \\le {182,087,070}")#text(" for m=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257833")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("Taking 10,000,000 consecutive primes starting with 1,040,407 gives an admissible tuple of diameter 179,933,380 for m=3.")

#text("(and 1,040,407 is the smallest prime for which this works).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257906")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Using the Hensley-Richards sieve for k=10,000,000 gives an admissible sequence of diameter ")#link("http://math.mit.edu/~drew/admissible_10000000_175225874.txt")[#text("175,225,874")]#text(" for m=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257910")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=1,700,000, taking the first k primes greater than k gives the bound ")#mi("H\\le {27,790,250}")#text(" for m=3.")

#text("Taking 1,700,000 consecutive primes starting with 205,297 gives an admissible tuple with diameter 27,398,976 for m=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257911")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Using the Hensley-Richards sieve for k=1,700,000 gives and admissible tuple of diameter ")#link("http://math.mit.edu/~drew/admissible_1700000_26682014.txt")[#text("26,682,014")]#text(" for m=3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257914")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=38,000 a greedy sieve yields an admissible tuple of diameter ")#link("http://math.mit.edu/~drew/admissible_38000_431682.txt")[#text("431,682")]#text(" for k=2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257918")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=38,000 the bound on H can be improved to ")#link("http://math.mit.edu/~drew/admissible_38000_430448.txt")[#text("430,448")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257956")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For m=2, k=38000 we can further improve the bound on H to ")#link("http://math.mit.edu/~drew/admissible_38000_429822.txt")[#text("429,822")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257957")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Terence’s maple code with the (hopefully legal?) input m := 2, c := 0.975/log(k), T := 0.97/log(k) seems to work for k = 25819. ")#emph[#text("[This seems to check out – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Unfortunately I made a typo when entering in the formula for U; the sigma2 term should in fact be (k-1)sigma2, which makes things worse and invalidates Wouter’s optimisations – sorry about that! I was able at least to recover the k=38000 value using Wouter’s values (incidentally I have realised that it is slightly better to view c as a perturbation of 1/log(k), so I now wrote c = 1/log(k) – 0.25 / log(k)^2); similarly I can recover k=1700000 in the m=3 case by taking c = 1/log(k) – 0.07/log(k)^2 and T = 0.877/log(k)^2.")

#raw("\nk := 38000;\nm := 2;")

#text("# These three parameters may be chosen arbitrarily")

#text("c := 1/log(k) - 0.25/log(k)^2;")#linebreak()#text(" T := 0.97/log(k);")#linebreak()#text(" # tau := 1.14/log(k);")

#text("M0 := k*log(k)/(k-1);")#linebreak()#text(" g := 1/(c+(k-1)*t);")#linebreak()#text(" m2 := int(g*g, t=0..T );")#linebreak()#text(" mu := int(t*g*g, t=0..T )/m2;")#linebreak()#text(" sigma2 := int(t*t*g*g, t=0..T)/m2 - mu*mu;")

#text("tau := 1 - k*mu;")

#text("denominator := (1+tau/2)*(1 - (k*sigma2)/((1+tau-k*mu)^2));")

#text("a := (r - k*mu) / T;")#linebreak()#text(" S := r * (log((r-k*mu)/T) +(k*sigma2)/(4*a*a*T*T*log(a)) ) + r*r/(4*k*T);")#linebreak()#text(" Sav := int(S, r=1..1+tau, numeric)/tau;")

#text("Z3 := int( g*g*k*t*log(1+t/T), t=0..T, numeric) / m2;")#linebreak()#text(" W := int( g*g*log(1+tau/(k*t)), t=0..T, numeric) / m2;")#linebreak()#text(" X:= (log(k)/tau) * c^2;")

#text("V := (c/m2) * int( g^2 / (2*c+(k-1)*t) , t=0..T, numeric);")#linebreak()#text(" U := (log(k)/c) * int( (1+u*tau - (k-1)*mu - c)^2 + (k-1)*sigma2, u=0..1, numeric);")

#text("numerator := Sav + Z3 + W*X + V*U;")

#text("Delta := (k/(k-1)) * numerator/ denominator;")

#text("# this needs to be positive")#linebreak()#text(" evalf( 1 - k*mu - T );")#linebreak()#text(" evalf( 1 - k*mu - tau );")

#text("# this needs to be positive too")#linebreak()#text(" evalf(denominator);")

#text("# this is the lower bound for M_k")#linebreak()#text(" evalf(M0-Delta);")

#text("varpi := m/(M0-Delta) - 1/4;")#linebreak()#text(" delta := T * ((1/4) + varpi);")

#text("# if this is less than 1, we win")#linebreak()#text(" evalf(1080*varpi/13+ 330*delta/13);")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257960")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=25819 we can bound H by ")#link("http://math.mit.edu/~drew/admissible_25819_283242.txt")[#text("283,242")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257976")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("The bound for k=25819 can be improved to ")#link("http://math.mit.edu/~drew/admissible_25819_282792.txt")[#text("282,792")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257985")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For m = 3, the maple code seems to prove k = 1214999 on input c = 0.995/log(k) and T = 0.877/log(k). This is probably not yet optimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257987")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=1700000, m=3, a greedy sieve yields an admissible tuple of diameter ")#link("http://math.mit.edu/~drew/admissible_1700000_25602510.txt")[#text("25,602,510")]#text(".")

#text("I can take a look at k=1214999 shortly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257988")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For k=1,214,999, taking k consecutive primes starting with 157,831 gives the bound 19,152,478. Using Hensley-Richards gives 18,641,812.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258079")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("For m=2, seems k = 36000 is valid at:")

#text("c := 0.9785232473863417/log(k);")#linebreak()#text(" T := 0.9205181897139338/log(k);")

#emph[#text("[Seems to check out – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258124")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Some further improvements:")

#text("For m=2, k=38000 we can get ")#link("http://math.mit.edu/~drew/admissible_38000_429798.txt")[#text("429,798")]#text(".")#linebreak()#text(" For m=3,k=1,700,000 we can get ")#link("http://math.mit.edu/~drew/admissible_1700000_25602438.txt")[#text("25,602,438")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258148")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For k=36,000 we can bound H by ")#link("http://math.mit.edu/~drew/admissible_36000_405528.txt")[#text("405,528")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258090")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Here is a solution ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_35146_m2.mpl")[#text("35146")]#text(", which is based on the code ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257994")[#text("here")]#text(" (The only differences are at the four lines for the inputs k0, m, c, T).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258150")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For k=35146 we can bound H by ")#link("http://math.mit.edu/~drew/admissible_35146_395542.txt")[#text("395,542")]#text(".")

#text("Have you tried optimizing for m=3 (or even m=4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258182")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For m=2, k=35,146 the bound on H can be improved to ")#link("http://math.mit.edu/~drew/admissible_35146_395264.txt")[#text("395,264")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258194")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For k=35146 [m=2], H can be down to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/admissible_35146_395234_-190558.txt")[#text("395234")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258198")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#link("http://math.mit.edu/~drew/admissible_35146_395178.txt")[#text("395,178")]#text(" [m=2].")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258196")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Just tried for m=3, it can be down to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_1630680_m3.mpl")[#text("1630680")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258200")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Thanks! Hensley-Richards then gives ")#link("http://math.mit.edu/~drew/admissible_1630680_25527718.txt")[#text("25,527,718")]#text(" as a bound on H.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258268")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("A greedy sieve brings the m=3 bound with k=1,630,680 down to ")#link("http://math.mit.edu/~drew/admissible_1630680_24490758.txt")[#text("24,490,758")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258197")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For m=4, k can be at least down to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_36000000_m4.mpl")[#text("36000000")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258203")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("I was able to get k down to ")#text("35,127,242")#text(" for m=4, but you may be able to improve this further.")

#text("Taking the first k primes greater than k gets the bound on H down to 685,833,596 for m=4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258205")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Hmm, it doesn’t seem to want to post the link. In any case, the parameters I used for m=4 to get k=35,127,242 are")

#text("c := evalf(0.9529804688/log(k));")#linebreak()#text(" T := evalf(0.9999999999/log(k));")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258250")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("For m=4, seems k can be decreased to ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0/sol_varpi1080d13_25589558_m4.mpl")[#text("25589558")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258267")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Nice improvement. Taking the first k primes greater than k=25589558 then gives the bound 491149914 on H for m=4.")

#text("Out of curiosity, have you tried m=5? It might be interesting to get a sense of how close to the asymptotic prediction we can get with explicit bounds.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258151")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("So if I just change m to 3 in xfxie’s worksheet and then naively optimize k without changing anything else it appears that we can get ")#link("http://math.mit.edu/~drew/maple_3_1640042.txt")[#text("1,640,042")]#text(" for m=3.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258179")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("After fiddling with the parameters a bit, it appears that for m=3 we can get k down to ")#link("http://math.mit.edu/~drew/maple_3_1631027.txt")[#text("1,631,027")]#text(".")

#text("Hensley-Richards then gives ")#link("http://math.mit.edu/~drew/admissible_1631027_25533684.txt")[#text("25,533,684")]#text(" as an upper bound on H.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258154")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("Doing the same thing with m=4 gives k=")#link("http://math.mit.edu/~drew/maple_4_41862295.txt")[#text("41,862,295")]#text(". Taking the first k primes greater than k gives the bound 825,018,354 on H.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257498")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("The above computation of ")#mi("M_2")#text(" (the operator norm of ")#mi("\\mathcal  L_2")#text(") relies on the (yet unproved) assumption that it is attained as the corresponding eigenvalue for some smooth eigenfunction of ")#mi("\\mathcal  L_2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257539")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("That’s a good point. Smoothness is unlikely to be an issue, because everything is at least L^2 in regularity, and all the operations involved are linear in the unknown F, so that the theory of distributions will probably be able to make all the ODE manipulations rigorous. Attainment of the minimum at an eigenfunction should be possible through calculus of variations arguments due to the strict gap ")#mi("M_2 > M_1")#text(" (which we can prove rigorously, since ")#mi("M_1=1")#text(" and the explicit eigenfunction we have tells us that ")#mi("M_2 \\geq 1.38593\\ldots")#text(") prevents escape to high frequencies. More precisely, let ")#mi("F_n \\in L^2({\\cal R}_2)")#text(" be a extremising sequence for the ratio ")#mi("[J_2^{(1)}(F_n) + J_2^{(2)}(F_n)] / I_2(F_n)")#text("; we can symmetrise using the parallelogram law (as mentioned in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251870")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251870")]#text(" ) to ensure wlog that the ")#mi("F_n")#text(" are symmetric; we can also normalise them in L^2 and make them non-negative.")

#text("By passing to a subsequence, we can make the ")#mi("F_n")#text(" converge weakly in L^2. We want to upgrade this to strong convergence in L^2, so that the limit ")#mi("F")#text(" will be a true eigenfunction at the extremal eigenvalue ")#mi("M_2")#text(". Because the ")#mi("F_n")#text(" have uniformly compact support and uniformly bounded in L^2, the only way in which strong convergence fails is escape of mass to high frequencies (a sort of failure of L^2 equicontinuity, in the spirit of Arzela-Ascoli). However, in the high frequency limit, at least one of the two components in ")#mi("{\\cal L}")#text(" goes to zero, and the contribution of the high frequency component is controlled by M_1, which is strictly less than M_2. This can be used to show that escape to high frequences does not occur. (There are some technical details here due to the fact that the high and low frequency components of F_n may leak outside the simplex ")#mi("{\\cal R}_2")#text(", but I believe that these issues are manageable by sending the cutoff between high and low frequency slowly to infinity.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257567")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Concerning Aubrey’s question (on systematic dissection of ")#mi("\\mathcal  R^{\\prime\\prime}_k")#text("), a sufficient condition is that for each ")#mi("m = 1, ..., k")#text(" and each ")#mi("t_1, ... , t_{m-1}, t_{m+1}, ... , t_k")#text(", the interval")

#mi("I_{m,,j} := \\{t_m : (t_1, ..., t_k) \\in D_j\\}")

#text("for each polytope ")#mi("D_j")#text(" is either empty or has endpoints which are FIXED linear combinations of ")#mi("1, t_1, ... , t_{m-1}, t_{m+1}, ... , t_k")#text(" – (i.e. each endpoint belong to exactly one bounding plane of ")#mi("D_j")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257591")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("A possible algorithm for systematic dissection of ")#mi("\\mathcal R^{\\prime\\prime}_k")#text(" is to check for each ")#mi("m")#text(" and polytope ")#mi("D_j")#text(" if every ")#mi("(t_1, ... ,  t_{m-1}, t_{m+1}, ... , t_k)")#text(" in the projection ")#mi("D_{j, m}")#text(" of ")#mi("D_j")#text(" on the plane orthogonal to ")#mi("t_m")#text(" axis, satisfies the above condition (i.e. each endpoint of the interval ")#mi("I_{m, j}")#text(" above belongs to a FIXED bounding plane of ")#mi("D_j")#text(". Otherwise, ")#mi("D_j")#text(" should be dissected (by appropriate planes parallel to ")#mi("t_m")#text(" axis to satisfy the above condition). I think that by repeating this dissection refinement process we get a desired dissection after finitely many steps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257645")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I thought I’d give a quick update on the computational work I’ve been doing, to improve the ")#mi("k")#text(" bound we have.")

#text("I’ve tried a number of different things. One was to limit the lengths of signatures being used. It turns out that this still quickly leads to memory limitations, and also does not give good numerics in the ranges where RAM issues are gone.")

#text("Second, Frederik Ziebell sent me a very nice program to compute permutations, which is a bit slower than Mathematica, but not nearly as RAM intensive. Unfortunately, that program still eventually runs into memory issues as well!")

#text("Third, I tried pushing the degree 10 computations further, but it is clear that ")#mi("k=64")#text(" is the best result using the methods I’ve already tried.")

#text("Fourth, I found a computer nearby which has 64GB of RAM, and ran the program again. Surprisingly, I kept running into problems. It turns out that there is still trouble when we use signatures ")#mi("\\alpha=\\beta=(2,2,1,1,1,1,1,1,1)")#text(". In the next day or two, I will throw out this case, and maybe two other problem cases, and get a partial degree 11 result (which should push ")#mi("k")#text(" a bit lower).")

#text("It might be the case that I’m just not approaching the problem very well. Here is the computational hang-up:")

#text("Let ")#mi("\\alpha,\\beta")#text(" be signatures (non-decreasing sequences of positive integers). Define the monomial symmetric polynomials ")#mi("m(\\alpha),m(\\beta)")#text(" as before.")

#text("We wish to compute ")#mi("m(\\alpha)m(\\beta)=\\sum_{\\gamma} c_{\\alpha,\\beta,\\gamma}m(\\gamma)")#text(". Once the coefficients ")#mi("c_{\\alpha,\\beta,\\gamma}")#text(" are found, I put them into a look-up table and the rest of the computation does not present much difficulty.")

#text("So, the difficulty is in computing the ")#mi("c")#text("‘s. For anyone who wants to try to write a better algorithm than mine, a good test case is when ")#mi("\\alpha=\\beta=(2,2,1,1,1,1,1,1,1)")#text(". [I’m a little surprised there is not already a large look-up table of these coefficients out there (at least I can’t find one). I would think this sort of thing would be extremely useful in other contexts.]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257652")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("In an earlier post I think you mentioned looking at polynomials")#linebreak()#text(" ")#mi("(1-P_1)^a P_{\\alpha}")#linebreak()#text(" where ")#mi("P_1=\\sum_{i=1}^kt_i")#text(" and ")#mi("P_\\alpha")#text(" is a polynomial of signature ")#mi("\\alpha")#text(".")

#text("Is it not possible to use these where ")#mi("\\alpha")#text(" has no 1s in its signature? This should form a basis for all symmetric polynomials, and (if I understand correctly) should avoid the RAM issues (for a bit) since you only have to add signatures which have no 1s in them, and so they should be about half the length.")

#text("This still is a bit of a hack; I’m sure there is probably a neater solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257655")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Perhaps one could convert between the basis of symmetrised monomials ")#mi("m(\\alpha)")#text(" and the basis of monomials ")#mi("e_1^{a_1} \\ldots e_k^{a_k}")#text(" of the elementary symmetric polynomials (in your notation, ")#mi("e_j = m(1,\\ldots,1)")#text(" where there are j 1’s)? The point is that multiplication is trivial in the latter basis (particularly from a memory standpoint, which seems to be the bottleneck). Also the operation of integrating out one of the k variables, say t_k, is not too bad in this basis, because of the recursive identities")

#mi("e_j(t_1,\\ldots,t_k) = e_j(t_1,\\ldots,t_{k-1}) + t_k e_{j-1}(t_1,\\ldots,t_{k-1})")

#text("and because t_k is being integrated from 0 to ")#mi("1-e_1(t_1,\\ldots,t_{k-1})")#text(".")

#text("The price one pays for this of course is that integrating on the entire simplex is unpleasant in this basis, but one could now convert back to the symmetrised monomial basis ")#mi("m(\\alpha)")#text(" in which integration is easy. It seems to be that computing the structure constants ")#mi("c_{\\alpha,\\beta,\\gamma}")#text(" for ")#mi("m(\\alpha) m(\\beta)")#text(" is relatively easy if ")#mi("\\beta = (1,\\ldots,1)")#text(" is elementary, so the conversion from the monomials-of-elementary-functions basis to the symmetrised-monomials basis should be fairly straightforward. (The reverse conversion may not actually be necessary, if one stores F in the former basis rather than the latter.) In any case, these conversions should occupy significantly less memory (if one has an N-dimensional space of polynomials, any conversion matrices will take up ")#mi("O(N^2)")#text(" memory, as opposed to the ")#mi("O(N^3)")#text(" memory required for the multiplication structure constants ")#mi("c_{\\alpha,\\beta,\\gamma}")#text(".)")

#text("For your specific example m(221111111), it looks like this polynomial is an explicit linear combination of ")#mi("e_2 e_9, e_1 e_{10}, e_{11}")#text(", so ")#mi("m(221111111)")#text(" is a combination of ")#mi("e_2^2 e_9^2, e_1 e_2 e_9 e_{10}, e_2 e_9 e_{11}, e_1^2 e_{10}^2, e_1 e_{10} e_{11}, e_{11}^2")#text(", and each of these should be easily expandable back into ")#mi("m(\\gamma)")#text("‘s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257786")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("James and Terry, these are both great ideas. I went with James’ idea first since it is incredibly easy to implement inside the code I have already written, and it essentially doubles the degree without much extra work. [The degree 10 case takes only about 1 minute now.]")

#text("I first accidentally ran the computation on polynomials of the form ")#mi("(1-P_1)^a m(\\alpha)")#text(", where ")#mi("\\alpha")#text(" is a signature of degree ")#mi("\\leq 20")#text(" with only *even* entries. So this set of polynomials doesn’t quite span the space of all symmetric polynomials of degree 20, but it still seems to give very good numberics (perhaps better time-wise than using the full basis–I’ll experiment with this). I obtained the lower bound ")#mi("M_{59}\\geq 4.06")#text(".")

#text("I’ll continue running the code, lift the restriction on signatures with only even entries, and report more results tomorrow.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("Ah, so we have hit ")#mi("H_1 \\leq 300")#text(", excellent! It’s remarkable how close the ")#mi("\\frac{k}{k-1} \\log k")#text(" upper bound is holding up (and also reassuring that we are not contradicting that bound).")

#text("Incidentally, I changed the attribution for H(k) for small k (up to 171) on the wiki to ")#link("http://www.ams.org/journals/mcom/2001-70-236/S0025-5718-01-01348-5/home.html")[#text("Clark and Jarvis")]#text(" rather than Engelsma, as their work was earlier. (Engelsma gets optimal values up to k=342, and not necessarily optimal values up to k=800 or so.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257794")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("The change in attribution makes sense. I’ll add a note to the entries in the admissible tuples database for k < 172.")

#text("If we manage to get k down to 26 we can go back further to Smith's 1957 ")#link("http://www.ams.org/journals/mcom/1957-11-060/S0025-5718-1957-0094314-8/")[#text("paper")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257796")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("This agrees with my estimate (based on linear convergence assumption) above that ")#mi("M_{59}")#text(" should be about ")#mi("4.06")#text(", according to that assumption (with convergence rate of about ")#mi("0.8")#text("), the minimal ")#mi("k")#text(" for which $m_k > 4$ was estimated to be ")#mi("k=55")#text(" or ")#mi("56")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257969")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Doing as above (considering ")#mi("(1-P_1)^a m(\\alpha)")#text(" where ")#mi("\\alpha")#text(" is a signature with only even entries, and the total degree is at most 20) yields ")#mi("M_{55}\\geq 4.0051689")#text(". [This method is definitely faster than using all monomial symmetric polynomials of a given degree, but that can still be done.] If Eytan’s predictions hold true, this will be the smallest ")#mi("k")#text(" value for which ")#mi("M_{k}\\geq 4")#text(" on ")#mi("\\mathcal{R}_k")#text(".")

#text("But just to give more data, here are the lower bounds on ")#mi("M_{54}")#text(" using all monomials of a given degree, for degrees ")#mi("d")#text(" from 1 to 14.")

#mi("d=1,\\ M_{54}\\geq 2.843513...")#linebreak()#text(" ")#mi("d=2,\\ M_{54}\\geq 3.162473...")#linebreak()#text(" ")#mi("d=3,\\ M_{54}\\geq 3.346057...")#linebreak()#text(" ")#mi("d=4,\\ M_{54}\\geq 3.478512...")#linebreak()#text(" ")#mi("d=5,\\ M_{54}\\geq 3.579515...")#linebreak()#text(" ")#mi("d=6,\\ M_{54}\\geq 3.658674...")#linebreak()#text(" ")#mi("d=7,\\ M_{54}\\geq 3.722270...")#linebreak()#text(" ")#mi("d=8,\\ M_{54}\\geq 3.773642...")#linebreak()#text(" ")#mi("d=9,\\ M_{54}\\geq 3.815790...")#linebreak()#text(" ")#mi("d=10,\\ M_{54}\\geq 3.850349...")#linebreak()#text(" ")#mi("d=11,\\ M_{54}\\geq 3.878997...")#linebreak()#text(" ")#mi("d=12,\\ M_{54}\\geq 3.902667...")#linebreak()#text(" ")#mi("d=13,\\ M_{54}\\geq 3.922386...")#linebreak()#text(" ")#mi("d=14,\\ M_{54}\\geq 3.938729...")

#text("If any further computation is necessary, let me know.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257974")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Since the difference ")#mi("M_k - M_{k-1}")#text(" should be very close to ")#mi("\\log  k - \\log (k-1)")#text(" (i.e. very nearly ")#mi("1/k")#text("), we expect ")#mi("M_{54}")#text(" to be very close to ")#mi("M_55 - 1/55")#text(" – i.e. about ")#mi("3.987")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257983")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("3.987 is indeed very close to what our previous method (extrapolating differences with a 0.8 convergence rate) predicts for d=20. However, allowing d to rise to 26 appears to let M_54 creep over 4 – I trust Pace will be able to test this prediction – so it looks as though 0.8 is slightly over-pessimistic. It seems pretty certain that the corresponding series for k=53 will converge below 4, however (though of course that must also be checked).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257989")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Actually I retract my pessimism for k=53. Using a convergence rate of 0.8 as above, the limit of M_54 as d tends to infinity is about 4.004, but the ratio of differences for d > 10 is actually more like 0.83, which translates to a limit extremely close to 4 + 1/54, i.e. to a prediction that M_53 may creep over 4 but only for terrifyingly large d.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257991")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Pace – how much difference are you typically seeing for a given k and (double-digit) d between M calculated with all monomials versus only even entries? If the difference (or ratio, or some other simple function) is relatively constant, it may allow the even-entry version to act as a highly accurate estimator of what d (if any) would be needed to get M_53 > 4 using all monomials.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258000")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("First, I should mention that using only even entries in the signature was a mistake on my part (which fortunately sped up the computation quite a bit). My intuition is that it should be better to use signatures with entries limited to ")#mi("\\{2,3,\\ldots, d_0\\}")#text(" for some small ")#mi("d_0")#text(", which will keep the speed increase but not be quite so ad hoc.")

#text("Here are two data points about using limited signatures: For degree 4, ")#mi("k=59")#text(", using all monomials we get ")#mi("M_{59}\\geq 3.504684\\ldots")#text(" while with restricted signatures we get ")#mi("M_{59}\\geq 3.49235105\\ldots")#text(". Similarly, in degree 10 we get the bounds ")#mi("M_{59}\\geq 3.898402\\ldots")#text(" and ")#mi("M_{59}\\geq 3.88376877\\ldots")#text(". So it doesn’t appear that there is a significant difference in the outcome.")

#text("Regarding your ")#mi("k=53")#text(" pessimism, it should be kept in mind that these computations do not continue on at the same convergence rate once the degree gets to be about ")#mi("d=k/2")#text(", because the monomials involved start overlapping more often. (There are fewer monomial symmetric polynomials in ")#mi("F^2")#text(" due to the lack of available variables.) So I would guess that ")#mi("k=53")#text(" is not within the realm of possibility–but I may be wrong.")

#text("I’ll see if I can’t put together some code to try degree 26 for ")#mi("k=54")#text(". (Unfortunately, I do have finals to grade, and a family vacation to take this next week. So it may be a little while before it gets done.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258001")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("I agree with Aubrey’s conclusions. I give below more details")

#text("The last three ratios among consecutive differences are:")

#mi("0.82623... , 0.83307... , 0.82879...")#text(" – showing good stability near Aubrey’s value (0.83) for the estimated convergence rate. Using this rate we have the prediction that ")#mi("M_54")#text(" should be about ")#mi("4.018")#text(" (which is safely above the threshold ")#mi("4")#text(" – concerning the small fluctuations of the ratios around ")#mi("0.83")#text("). It seems however that ")#mi("M_54 -1/54")#text(" is “too close” to ")#mi("4")#text(" to reliably decide if ")#mi("M_53")#text(" is above or below ")#mi("4")#text(" (because of the small fluctuations in the above ratios.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258017")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Thank you Pace. The point about d > k/2 is well taken. The difference between the two versions of M_k for a given d is not so small, though – in fact I think it is enough, especially since it is bigger for d=10 than for d=4, that M_54 will probably not reach 4 for any d (certainly not d=26), if the even-entries version of your code is used. (That assumes that the difference is relatively independent of k, though.) Your new idea of a hybrid that includes only small odd numbers sounds ideal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258037")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Pace – before you write new code I should mention that if the convergence rate of 0.83 (rather than 0.8) is accurate, M_54 should actually reach 4 with d as small as 19.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258039")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Damn, apologies – actually not until d=22.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257714")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("The search for an ideal R has thus far proceeded by identifying extra volume that can be added to an R that is already known to be usable. I’m wondering whether there might be promise in the reciprocal option of first identifying a region that provably contains every possible R and then removing polytopes to arrive at a region that works. Would a suitable starting-point for such an approach be the union of k prisms of the form currently being investigated, i.e. a half-sized version of the region Terry describes in ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257354")[#text("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257354")]#text(" as the (Selberg-specific) minimal constraint for the sumset R+R ? (I’m actually having trouble seeing what prevents the use of that entire region itself as the maximal R, but I’m sure I’m missing something.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257736")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("I had initially used this very region before realising that R+R would be too big, due to the contribution of sums r+r’ where r,r’ lie in different prisms. Pace’s symmetrised region ")#mi("\\{ x,y,z \\in [0,1]^3: x+y+z \\leq 3/2 \\}")#text(" is the largest symmetric convex region available, because if ")#mi("(x,y,z)")#text(" lies in a symmetric R then so does ")#mi("\\frac{1}{3}(x+y+z,x+y+z,x+y+z)")#text(", and so R+R contains ")#mi("\\frac{2}{3}(x+y+z,x+y+z,x+y+z)")#text(", forcing ")#mi("x+y+z\\leq\\frac{3}{2}")#text(". There is a possibility of using a non-convex R, though one should proceed with caution in this case and recheck all the other steps of the argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257741")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("It seems that the generalization of Pace’s region for ")#mi("\\mathcal R^{\\prime\\prime}_k")#text(" is")

#mi("c_k \\mathcal R_k")#text(" with ")#mi("c_k = max (k/(k-1), 1/ \\theta)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257749")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("For the above region we (obviously) have the upper bound")#linebreak()#text(" ")#mi("M^{\\prime\\prime}_k \\le c_k M_k \\le (k/(k-1))^2 \\log k")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257762")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("The second inequality above is implied (of course) only for ")#mi("c_k = k/(k-1)")#text(" – i.e. ")#mi("\\theta \\ge 1-1/k")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257759")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("Ah yes, of course – indeed, for k=3 it’s immediate that no R, convex or otherwise, can be bigger than half the unit cube, simply because no pair of points whose midpoint is epsilon away from (1/2,1/2,1/2) can both be in R. I’m not sure whether this generalises to larger k, though, because I’m not clear what the equivalent sumset condition is – I see various possibilities. Could you please state it explicitly?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257772")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("For general values of ")#mi("k,\\theta")#text(", the constraint is that R+R must lie in the set")

#mi("\\bigcup_{j=1}^k \\{ (t_1,\\ldots,t_k) \\in [0,2/\\theta]^k:")#linebreak()#text(" ")#mi("t_1+\\ldots+t_{j-1}+t_{j+1}+\\ldots+t_k \\leq 2 \\}")

#text("which is the union of k prisms. For the current focus of improving the bounds on H_1 on EH, we are taking ")#mi("\\theta=1")#text(", but one could imagine that the ")#mi("\\theta=1/2")#text(" case could be useful for improving the Bombieri-Vinogradov level of k (currently at 64), e.g. by using the longer prism ")#mi("\\{ (t_1,\\ldots,t_k): t_1+\\ldots+t_{k-1} \\leq 1; t_k \\leq 2 \\}")#text(", which looks like a promisingly large amount of extra room over ")#mi("{\\cal R}_k")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Until now,proving H=2 is possible?Why does my intuition and mental telepathy keep feeling that 95% you can do.I’m really happy to see your answer very much.")#linebreak()#text(" Thank you very much,")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257797")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("The lower bound for ")#mi("M^{\\prime\\prime}_3")#text(" in the wiki page should be ")#mi("1.914")#text(" (as given by James.)")

#emph[#text("[Corrected, thanks- T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-257953")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("Currently there are several candidates for ")#mi("\\mathcal R^{\\prime\\prime}_k, \\theta")#text(" (and perhaps more future ones) for which this notation (as well as ")#mi("M^{\\prime\\prime}_k")#text(") is somewhat vague – so this notation should be made clearer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258007")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("In the asymptotic analysis for the lower bound for ")#mi("M_k")#text(" in the wiki page, the integral in the numerator of the last upper bound expression for ")#mi("\\Delta")#text(" is not sufficiently clear.")

#emph[#text("[Clarification added -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258018")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("It seems clearer to replace ")#mi("a")#text(" by ")#mi("a(u)")#text(" in the integrand")#emph[#text("[OK, -T.]")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics. | What's new")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258015")[#strong[#text("Polymath8b, IV: Enlarging the sieve support, more efficient numerics, and explicit asymptotics. | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 December 2013")])]

#text("[…] for small values of (in particular ) or asymptotically as . The previous thread may be found here. The currently best known bounds on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-258183")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2013")])]

#text("There are typos in the values of the upper bounds for ")#mi("M_{40}, M_{59}")#text(" appearing in the table in the wiki page. There is also a typo in the approximate value of ")#mi("M_2")#text(" in the last line of that page.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714d8c2f1ed8d3b1be04d8a23a36bce0f5d29c60c225ae36c4a61207a30cc42f-6a4413f17425ffb6926dda61ec55f153dd33fd24918b6df3394b5760ee7a1412.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Nicholson")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-260526")[#strong[#text("John Nicholson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2013")])]

#text("Can someone explain the link of 272 to here, from the table with m=1 at: ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-260531")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2013")])]

#text("The link is to Pace Nielsen’s comment in which he notes that M_55 > 4 = 4m. By Maynard’s result (summarized above), this implies that every admissible 55-tuple has infinitely many translates that contain at least 2 primes. The bound 272 comes from the fact that there exists an admissible 55-tuple of diameter 272, e.g. ")#link("http://math.mit.edu/~primegaps/tuples/admissible_55_272.txt")[#text("this one")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-285679")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2014")])]

#text("In Section 2 of this post, ")#mi("X_1+\\ldots X_{k-1}\\geq k-T")#text(" should be ")#mi("X_1+\\ldots X_{k-1}\\leq k-T")#text(" (3 occurrences). Correspondingly,")#linebreak()#text(" in the text, “at most ")#mi("k-T")#text("” should be “at least ")#mi("k-T")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]
