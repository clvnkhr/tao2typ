// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/
// Converted to Typst by tao2typ: "2026-10-14T15:18:10.795959+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Hilbert’s seventh problem, and powers of 2 and 3", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Hilbert’s seventh problem, and powers of 2 and 3")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 August 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")[#text("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve been focusing my blog posts recently on the mathematics around ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(" (is every locally Euclidean group a Lie group?), but today, I will be discussing another of Hilbert’s problems, namely ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_seventh_problem")[#text("Hilbert’s seventh problem")]#text(", on the transcendence of powers ")#mi("{a^b}")#text(" of two algebraic numbers ")#mi("{a,b}")#text(". (I am not randomly going through ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_problems")[#text("Hilbert’s list")]#text(", by the way; I hope to explain my interest in the seventh problem in a later post.) This problem was famously ")#link("http://en.wikipedia.org/wiki/Gelfond%E2%80%93Schneider_theorem")[#text("solved by Gelfond and Schneider")]#text(" in the 1930s:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Gelfond-Schneider theorem)")]#text(" Let ")#mi("{a, b}")#text(" be algebraic numbers, with ")#mi("{a \\neq 0,1}")#text(" and ")#mi("{b}")#text(" irrational. Then (any of the values of the possibly multi-valued expression) ")#mi("{a^b}")#text(" is transcendental.")
]

#text("For sake of simplifying the discussion, let us focus on just one specific consequence of this theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" is transcendental.")
]

#emph[#text("Proof:")]#text(" If not, one could obtain a contradiction to the Gelfond-Schneider theorem by setting ")#mi("{a := 3}")#text(" and ")#mi("{b := \\frac{\\log 2}{\\log 3}}")#text(". (Note that ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" is clearly irrational, since ")#mi("{3^p \\neq 2^q}")#text(" for any integers ")#mi("{p,q}")#text(" with ")#mi("{q}")#text(" positive.) ")#mi("\\Box")

#text("In the 1960s, Alan Baker established a major generalisation of the Gelfond-Schneider theorem known as ")#link("http://en.wikipedia.org/wiki/Baker%27s_theorem")[#text("Baker’s theorem")]#text(", as part of his work in transcendence theory that later earned him a Fields Medal. Among other things, this theorem provided explicit quantitative bounds on exactly ")#emph[#text("how")]#text(" transcendental quantities such as ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" were. In particular, it gave a strong bound on how ")#emph[#text("irrational")]#text(" such quantities were (i.e. how easily they were approximable by rationals). Here, in particular, is one special case of Baker’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Special case of Baker’s theorem)")]#text(" ")#metadata(none) <tao-530c4fc0e55038578184>#text(" For any integers ")#mi("{p, q}")#text(" with ")#mi("{q}")#text(" positive, one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\log 2}{\\log 3} - \\frac{p}{q}\\right| \\geq c \\frac{1}{q^C}", block: true)]]

#text("for some absolute (and effectively computable) constants ")#mi("{c, C > 0}")#text(".")
]

#text("This theorem may be compared with (the easily proved) Liouville’s theorem on diophantine approximation, which asserts that if ")#mi("{\\alpha}")#text(" is an irrational algebraic number of degree ")#mi("{d}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha - \\frac{p}{q}\\right| \\geq c \\frac{1}{q^d}", block: true)]]

#text("for all ")#mi("{p,q}")#text(" with ")#mi("{q}")#text(" positive, and some effectively computable ")#mi("{c>0}")#text(", and (the more significantly difficult) ")#link("http://en.wikipedia.org/wiki/Thue-Siegel-Roth_theorem")[#text("Thue-Siegel-Roth theorem")]#text(", which under the same hypotheses gives the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha - \\frac{p}{q}\\right| \\geq c_\\epsilon \\frac{1}{q^{2+\\epsilon}}", block: true)]]

#text("for all ")#mi("{\\epsilon>0}")#text(", all ")#mi("{p,q}")#text(" with ")#mi("{q}")#text(" positive and an ")#emph[#text("ineffective")]#text(" constant ")#mi("{c_\\epsilon>0}")#text(". Finally, one should compare these results against ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_diophantine_approximation")[#text("Dirichlet’s theorem on Diophantine approximation")]#text(", which asserts that for any real number ")#mi("{\\alpha}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha - \\frac{p}{q}\\right| < \\frac{1}{q^2}", block: true)]]

#text("for infinitely many ")#mi("{p,q}")#text(" with ")#mi("{q}")#text(" positive. (The reason the Thue-Siegel-Roth theorem is ineffective is because it relies heavily on the ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("dueling conspiracies argument")]#text(", i.e. playing off multiple “conspiracies” ")#mi("{\\alpha \\approx \\frac{p}{q}}")#text(" against each other; the other results however only focus on one approximation at a time and thus avoid ineffectivity.)")

#text("Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(" easily implies the following separation property between powers of ")#mi("{2}")#text(" and powers of ")#mi("{3}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Separation between powers of ")#mi("{2}")#text(" and powers of ")#mi("{3}")#text(")")]#text(" For any positive integers ")#mi("{p, q}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|3^p - 2^q\\right| \\geq \\frac{c}{q^C} 3^p", block: true)]]

#text("for some effectively computable constants ")#mi("{c, C > 0}")#text(" (which may be slightly different from those in Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(").")
]

#text("Indeed, this follows quickly from Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(", the identity ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("3^p - 2^q = 3^p ( 1 - 3^{q (\\frac{\\log 2}{\\log 3} - \\frac{p}{q})})")]]



#text(" and some elementary estimates.")

#text("In particular, the gap between powers of three ")#mi("{3^p}")#text(" and powers of two ")#mi("{2^q}")#text(" grows exponentially in the exponents ")#mi("{p,q}")#text(". I do not know of any other way to establish this fact other than essentially going through some version of Baker’s argument (which will be given below).")

#text("For comparison, by exploiting the trivial (yet fundamental) ")#emph[#text("integrality gap")]#text(" – the obvious fact that if an integer ")#mi("{n}")#text(" is non-zero, then its magnitude is at least ")#mi("{1}")#text(" – we have the trivial bound")

#align(center)[#tao-fit-display[#tao-math("\\left|3^p - 2^q\\right| \\geq 1", block: true)]]

#text("for all positive integers ")#mi("{p, q}")#text(" (since, from the fundamental theorem of arithmetic, ")#mi("{3^p-2^q}")#text(" cannot vanish). Putting this into ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(1)")]#text(" we obtain a very weak version of Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(", that only gives exponential bounds instead of polynomial ones:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5 (Trivial bound)")]#text(" ")#metadata(none) <tao-6d4c9cf5e022a07ea801>#text(" For any integers ")#mi("{p, q}")#text(" with ")#mi("{q}")#text(" positive, one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\log 2}{\\log 3} - \\frac{p}{q}\\right| \\geq c \\frac{1}{2^q}", block: true)]]

#text("for some absolute (and effectively computable) constant ")#mi("{c > 0}")#text(".")
]

#text("The proof of Baker’s theorem (or even of the simpler special case in Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(") is largely elementary (except for some very basic complex analysis), but is quite intricate and lengthy, as a lot of careful book-keeping is necessary in order to get a bound as strong as that in Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(". To illustrate the main ideas, I will prove a bound that is weaker than Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(", but still significantly stronger than Proposition ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("5")]#text(", and whose proof already captures many of the key ideas of Baker:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Weak special case of Baker’s theorem)")]#text(" ")#metadata(none) <tao-7ec833ac10110475b896>#text(" For any integers ")#mi("{p, q}")#text(" with ")#mi("{q > 1}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\log 2}{\\log 3} - \\frac{p}{q}\\right| \\geq \\exp( - C \\log^{C^{\\prime}} q )", block: true)]]

#text("for some absolute constants ")#mi("{C, C^{\\prime} > 0}")#text(".")
]

#text("Note that Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(" is equivalent to the assertion that one can take ")#mi("{C^{\\prime}=1}")#text(" (and ")#mi("{C}")#text(" effective) in the above proposition.")

#text("The proof of Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" can be made effective (for instance, it is not too difficult to make the ")#mi("{C^{\\prime}}")#text(" close to ")#mi("{2}")#text("); however, in order to simplify the exposition (and in particular, to ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("use some nonstandard analysis terminology to reduce the epsilon management")]#text("), I will establish Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" with ineffective constants ")#mi("{C, C^{\\prime}}")#text(".")

#text("Like many other results in transcendence theory, the proof of Baker’s theorem (and Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(") rely on what we would nowadays call the ")#emph[#text("polynomial method")]#text(" – to play off upper and lower bounds on the complexity of polynomials that vanish (or nearly vanish) to high order on a specified set of points. (I have discussed the polynomial method in relation to problems in incidence geometry ")#link("http://en.wordpress.com/tag/polynomial-method/")[#text("in several previous blog posts")]#text(".) In the specific case of Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(", the points in question are of the form")

#align(center)[#tao-fit-display[#mitex("\\Gamma_N := \\{ (2^n, 3^n): n = 1,\\ldots,N \\} \\subset {\\bf R}^2")]]

#text("for some large integer ")#mi("{N}")#text(". On the one hand, the irrationality of ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" ensures that the curve")

#align(center)[#tao-fit-display[#mitex("\\gamma := \\{ (2^t, 3^t): t \\in {\\bf R} \\}")]]

#text("is not algebraic, and so it is difficult for a polynomial ")#mi("{P}")#text(" of controlled complexity to vanish (or nearly vanish) to high order at all the points of ")#mi("{\\Gamma_N}")#text("; the trivial bound in Proposition ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("5")]#text(" allows one to make this statement more precise. (Here, “complexity” of a polynomial is an informal term referring both to the degree of the polynomial, and the height of the coefficients, which in our application will essentially be integers up to some normalisation factors.) On the other hand, if Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" failed, then ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" is close to a rational, which by Taylor expansion makes ")#mi("{\\gamma}")#text(" close to an algebraic curve over the rationals (up to some rescaling by factors such as ")#mi("{\\log 2}")#text(" and ")#mi("{\\log 3}")#text(") at each point of ")#mi("{\\Gamma_N}")#text(". This, together with a pigeonholing argument, allows one to find a polynomial ")#mi("{P}")#text(" of reasonably controlled complexity to (nearly) vanish to high order at every point of ")#mi("{\\Gamma_N}")#text(".")

#text("These observations, by themselves, are not sufficient to get beyond the trivial bound in Proposition ")#link(<tao-6d4c9cf5e022a07ea801>)[#text("5")]#text(". However, Baker’s key insight was to exploit the integrality gap to bootstrap the (near) vanishing of ")#mi("{P}")#text(" on a set ")#mi("{\\Gamma_N}")#text(" to imply near-vanishing of ")#mi("{P}")#text(" on a larger set ")#mi("{\\Gamma_{N^{\\prime}}}")#text(" with ")#mi("{N^{\\prime}>N}")#text(". The point is that if a polynomial ")#mi("{P}")#text(" of controlled degree and size (nearly) vanishes to higher order on a lot of points on an analytic curve such as ")#mi("{\\gamma}")#text(", then it will also be fairly small on many other points in ")#mi("{\\gamma}")#text(" as well. (To quantify this statement efficiently, it is convenient to use the tools of complex analysis, which are particularly well suited to understand zeroes (or small values) of polynomials.) But then, thanks to the integrality gap (and the controlled complexity of ")#mi("{P}")#text("), we can amplify “fairly small” to “very small”.")

#text("Using this observation and an iteration argument, Baker was able to take a polynomial of controlled complexity ")#mi("{P}")#text(" that nearly vanished to high order on a relatively small set ")#mi("{\\Gamma_{N_0}}")#text(", and bootstrap that to show near-vanishing on a much larger set ")#mi("{\\Gamma_{N_k}}")#text(". This bootstrap allows one to dramatically bridge the gap between the upper and lower bounds on the complexity of polynomials that nearly vanish to a specified order on a given ")#mi("{\\Gamma_N}")#text(", and eventually leads to Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" (and, with much more care and effort, to Proposition ")#link(<tao-530c4fc0e55038578184>)[#text("3")]#text(").")

#text("Below the fold, I give the details of this argument. My treatment here is inspired by ")#link("http://archive.numdam.org/ARCHIVE/SB/SB_1969-1970__12_/SB_1969-1970__12__73_0/SB_1969-1970__12__73_0.pdf")[#text("this expose of Serre")]#text(", and ")#link("http://math.stanford.edu/~ksound/TransNotes.pdf")[#text("these lecture notes of Soundararajan")]#text(" (as transcribed by Ian Petrow).")

#metadata(none) <tao-e930325d4cac36c251f6>

#heading(level: 1)[#strong[#text(" — 1. Nonstandard formulation — ")]]

#text("The proof of Baker’s theorem requires a lot of “")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("epsilon management")]#text("” in that one has to carefully choose a lot of parameters such as ")#mi("{C}")#text(" and ")#mi("{\\epsilon}")#text(" in order to make the argument work properly. This is particularly the case if one wants a good value of exponents in the final result, such as the quantity ")#mi("{C^{\\prime}}")#text(" in Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(". To simplify matters, we will abandon all attempts to get good values of constants anywhere, which allows one to retreat to the nonstandard analysis setting where the notation is much cleaner, and much (though not all) of the epsilon management is eliminated. This is a relatively mild use of nonstandard analysis, though, and it is not difficult to turn all the arguments below into standard effective arguments (but at the cost of explicitly tracking all the constants ")#mi("{C}")#text("). See for instance the ")#link("http://math.stanford.edu/~ksound/TransNotes.pdf")[#text("notes of Soundararajan")]#text(" for such an effective treatment.")

#text("We turn to the details. We will assume some basic familiarity with nonstandard analysis, as covered for instance in ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("this previous blog post")]#text(" (but one should be able to follow this argument using only non-rigorous intuition of what terms such as “unbounded” or “infinitesimal” mean).")

#text("Let ")#mi("{H}")#text(" be an unbounded (nonstandard) positive real number. Relative to this ")#mi("{H}")#text(", we can define various notions of size:")

#list(
[#text("A nonstandard number ")#mi("{z}")#text(" is said to be ")#emph[#text("of polynomial size")]#text(" if one has ")#tao-math("{\\left|z\\right| \\leq C H^C}", block: false)#text(" for some standard ")#mi("{C > 0}")#text(".")],
[#text("A nonstandard number ")#mi("{z}")#text(" is said to be ")#emph[#text("of polylogarithmic size")]#text(" if one has ")#tao-math("{\\left|z\\right| \\leq C \\log^C H}", block: false)#text(" for some standard ")#mi("{C > 0}")#text(".")],
[#text("A nonstandard number ")#mi("{z}")#text(" is said to be ")#emph[#text("of quasipolynomial size")]#text(" if one has ")#tao-math("{\\left|z\\right| \\leq \\exp( C \\log^C H) }", block: false)#text(" for some standard ")#mi("{C > 0}")#text(".")],
[#text("A nonstandard number ")#mi("{z}")#text(" is said to be ")#emph[#text("quasiexponentially small")]#text(" if one has ")#tao-math("{\\left|z\\right| \\leq \\exp( - C \\log^C H)}", block: false)#text(" for every standard ")#mi("{C > 0}")#text(".")],
[#text("Given two nonstandard numbers ")#mi("{X, Y}")#text(" with ")#mi("{Y}")#text(" non-negative, we write ")#mi("{X \\ll Y}")#text(" or ")#mi("{X=O(Y)}")#text(" if ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some standard ")#mi("{C > 0}")#text(". We write ")#mi("{X=o(Y)}")#text(" or ")#mi("{X \\lll Y}")#text(" if we have ")#tao-math("{\\left|X\\right| \\leq cY}", block: false)#text(" for all standard ")#mi("{c>0}")#text(".")]
)

#text("As a general rule of thumb, in our analysis all exponents will be of polylogarithmic size, all coefficients will be of quasipolynomial size, and all error terms will be quasiexponentially small.")

#text("In this nonstandard analysis setting, there is a clean calculus (analogous to the calculus of the asymptotic notations ")#mi("{O()}")#text(" and ")#mi("{o()}")#text(") to manipulate these sorts of quantities without having to explicitly track the constants ")#mi("{C}")#text(". For instance:")

#list(
[#text("The sum, product, or difference of two quantities of a given size (polynomial, polylogarithmic, quasipolynomial, or quasiexponentially small) remains of that given size (i.e. each size range forms a ring).")],
[#text("If ")#mi("{X \\ll Y}")#text(", and ")#mi("{Y}")#text(" is of a given size, then ")#mi("{X}")#text(" is also of that size.")],
[#text("If ")#mi("{X}")#text(" is of quasipolynomial size and ")#mi("{Y}")#text(" is of polylogarithmic size, then ")#mi("{X^Y}")#text(" is of quasipolynomial size, and (if ")#mi("{Y}")#text(" is a natural number) ")#mi("{Y!}")#text(" is also of quasipolynomial size.")],
[#text("If ")#mi("{\\epsilon}")#text(" is quasiexponentially small, and ")#mi("{X}")#text(" is of quasipolynomial size, then ")#mi("{X\\epsilon}")#text(" is also quasiexponentially small. (Thus, the quasiexponentially small numbers form an ideal in the ring of quasipolynomial numbers.)")],
[#text("Any quantity of polylogarithmic size, is of polynomial size; and any quantity of polynomial size, is of quasipolynomial size.")]
)

#text("We will refer to these sorts of facts as ")#emph[#text("asymptotic calculus")]#text(", and rely upon them heavily to simplify a lot of computations (particularly regarding error terms).")

#text("Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" is then equivalent to the following assertion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Nonstandard weak special case of Baker)")]#text(" ")#metadata(none) <tao-6d563251c5d6f4a82c75>#text(" Let ")#mi("{H}")#text(" be an unbounded nonstandard natural number, and let ")#mi("{\\frac{p}{q}}")#text(" be a rational of height at most ")#mi("{H}")#text(" (i.e. ")#tao-math("{\\left|p\\right|, \\left|q\\right| \\leq H}", block: false)#text("). Then ")#mi("{\\frac{\\log 2}{\\log 3} - \\frac{p}{q}}")#text(" is not quasiexponentially small (relative to ")#mi("{H}")#text(", of course).")
]

#text("Let us quickly see why Proposition ")#link(<tao-6d563251c5d6f4a82c75>)[#text("7")]#text(" implies Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" (the converse is easy and is left to the reader). This is the usual “compactness and contradiction” argument. Suppose for contradiction that Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(" failed. Carefully negating the quantifiers, we may then find a sequence ")#mi("{\\frac{p_n}{q_n}}")#text(" of (standard) rationals with ")#mi("{q_n > 1}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\log 2}{\\log 3} - \\frac{p_n}{q_n}\\right| \\leq \\exp( - n \\log^n q_n )", block: true)]]

#text("for all natural numbers ")#mi("{n}")#text(". As ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" is irrational, ")#mi("{q_n}")#text(" must go to infinity. Taking the ultralimit ")#mi("{\\frac{p}{q}}")#text(" of the ")#mi("{\\frac{p_n}{q_n}}")#text(", and setting ")#mi("{H}")#text(" to be (say) ")#mi("{q}")#text(", we contradict Proposition ")#link(<tao-6d563251c5d6f4a82c75>)[#text("7")]#text(".")

#text("It remains to prove Proposition ")#link(<tao-6d563251c5d6f4a82c75>)[#text("7")]#text(". We fix the unbounded nonstandard natural number ")#mi("{H}")#text(", and assume for contradiction that ")#mi("{\\frac{\\log 2}{\\log 3}}")#text(" is quasiexponentially close to a nonstandard rational ")#mi("{\\frac{p}{q}}")#text(" of height at most ")#mi("{H}")#text(". We will write ")#mi("{X \\approx Y}")#text(" for the assertion that ")#mi("{X-Y}")#text(" is quasiexponentially small, thus ")#metadata(none) <tao-50781ae6a4d70a21d399>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{\\log 2}{\\log 3} \\approx \\frac{p}{q}.")]]





#text("The objective is to show that ")#link(<tao-50781ae6a4d70a21d399>)[#text("(2)")]#text(" leads to a contradiction.")

#heading(level: 1)[#strong[#text(" — 2. The polynomial method — ")]]

#text("Now it is time to introduce the polynomial method. We will be working with the following class of polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8")]#text(" A ")#emph[#text("good polynomial")]#text(" is a nonstandard polynomial ")#mi("{P: {}^* {\\bf C}^2 \\rightarrow {}^* {\\bf C}}")#text(" of the form ")#metadata(none) <tao-770e607624d689265ca6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("P(x, y) = \\sum_{0 \\leq a, b \\leq D} c_{a,b} x^a y^b")]]



#text(" of two nonstandard variables of some (nonstandard) degree at most ")#mi("{D}")#text(" (in each variable), where ")#mi("{D}")#text(" is a nonstandard natural number of polylogarithmic size, and whose coefficients ")#mi("{c_{a,b}}")#text(" are (nonstandard) integers of quasipolynomial size. (A technical point: we require the ")#mi("{c_{a,b}}")#text(" to depend in an internal fashion on the indices ")#mi("{a,b}")#text(", in order for the nonstandard summation here to be well-defined.) Define the ")#emph[#text("height")]#text(" ")#mi("{M}")#text(" of the polynomial to be the maximum magnitude of the coefficients in ")#mi("{P}")#text("; thus, by hypothesis, ")#mi("{M}")#text(" is of quasipolynomial size.")
]

#text("We have a key definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9")]#text(" Let ")#mi("{N, J}")#text(" be two (nonstandard) positive numbers of polylogarithmic size. A good polynomial ")#mi("{P}")#text(" is said to ")#emph[#text("nearly vanish to order ")#mi("{J}")]#text(" on ")#mi("{\\Gamma_N}")#text(" if one has ")#metadata(none) <tao-e5b0b3cd255b4209dcb5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{d^j}{dz^j} P(2^z,3^z)|_{z=n} \\approx 0")]]



#text(" for all nonstandard natural numbers ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n \\leq N}")#text(".")
]

#text("The derivatives in ")#link(<tao-e5b0b3cd255b4209dcb5>)[#text("(4)")]#text(" can be easily computed. Indeed, if we expand out the good polynomial ")#mi("{P}")#text(" out as ")#link(<tao-770e607624d689265ca6>)[#text("(3)")]#text(", then the left-hand side of ")#link(<tao-e5b0b3cd255b4209dcb5>)[#text("(4)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\sum_{0 \\leq a, b \\leq D} c_{a,b} (a \\log 2 + b \\log 3)^j 2^{an} 3^{bn}.")]]

#text("Now, from ")#link(<tao-50781ae6a4d70a21d399>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("a \\log 2 + b \\log 3 \\approx \\frac{\\log 3}{q} (aq+bp).")]]

#text("Using the asymptotic calculus (and the hypotheses that ")#mi("{D, j}")#text(" are of polylogarithmic size, and the ")#mi("{c_{a,b}}")#text(" are of quasipolynomial size) we conclude that the left-hand side of ")#link(<tao-e5b0b3cd255b4209dcb5>)[#text("(4)")]#text(" is ")#metadata(none) <tao-27037fccea3062ee8eba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\approx (\\frac{\\log 3}{q})^j \\sum_{0 \\leq a, b \\leq D} c_{a,b} (ap+bq)^j 2^{an} 3^{bn}.")]]



#text(" The quantity ")#mi("{(\\frac{\\log 3}{q})^j}")#text(" (and its reciprocal) is of quasipolynomial size. Thus, the condition ")#link(<tao-e5b0b3cd255b4209dcb5>)[#text("(4)")]#text(" is equivalent to the assertion that")

#align(center)[#tao-fit-display[#mitex("\\sum_{0 \\leq a, b \\leq D} c_{a,b} (ap+bq)^j 2^{an} 3^{bn} \\approx 0")]]

#text("for all ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n \\leq N}")#text("; as the left-hand side is a nonstandard integer, we see from the integrality gap that the condition is in fact equivalent to the ")#emph[#text("exact")]#text(" constraint ")#metadata(none) <tao-b38222d243e636f95235>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{0 \\leq a, b \\leq D} c_{a,b} (ap+bq)^j 2^{an} 3^{bn} = 0")]]



#text(" for all ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n \\leq N}")#text(".")

#text("Using this reformulation of ")#link(<tao-e5b0b3cd255b4209dcb5>)[#text("(4)")]#text(", we can now give some upper and lower bounds on the complexity of good polynomials that nearly vanish to a high order on a set ")#mi("{\\Gamma_N}")#text(". We first give an lower bound, that prevents the degree ")#mi("{D}")#text(" from being smaller than ")#mi("{N^{1/2}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Lower bound)")]#text(" ")#metadata(none) <tao-4c5e0db5dcc545320ae8>#text(" Let ")#mi("{P}")#text(" be a non-trivial good polynomial of degree ")#mi("{D}")#text(" that nearly vanishes to order at least ")#mi("{0}")#text(" on ")#mi("{\\Gamma_N}")#text(". Then ")#mi("{(D+1)^2 > N}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{(D+1)^2 \\leq N}")#text(". Then from ")#link(<tao-b38222d243e636f95235>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{0 \\leq a, b \\leq D} c_{a,b} (2^{a} 3^{b})^n = 0")]]

#text("for ")#mi("{1 \\leq n \\leq (D+1)^2}")#text("; thus there is a non-trivial linear dependence between the ")#mi("{(D+1)^2}")#text(" (nonstandard) vectors ")#mi("{((2^a 3^b)^n)_{1 \\leq n \\leq (D+1)^2} \\in {}^* {\\bf R}^{(D+1)^2}}")#text(" for ")#mi("{0 \\leq a,b \\leq D}")#text(". But, from the formula for the ")#link("http://en.wikipedia.org/wiki/Vandermonde_determinant")[#text("Vandermonde determinant")]#text(", this would imply that two of the ")#mi("{2^a 3^b}")#text(" are equal, which is absurd. ")#mi("\\Box")

#text("In the converse direction, we can obtain polynomials that vanish to a high order ")#mi("{J}")#text(" on ")#mi("{\\Gamma_N}")#text(", but with degree ")#mi("{D}")#text(" larger than ")#mi("{N^{1/2} J^{1/2}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (Upper bound)")]#text(" ")#metadata(none) <tao-a683a2f3f0d01164ae69>#text(" Let ")#mi("{D, J, N}")#text(" be positive quantities of polylogarithmic size such that")

#align(center)[#tao-fit-display[#mitex("D^2 \\ggg N J.")]]

#text("Then there exists a non-trivial good polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{D}")#text(" that vanishes to order ")#mi("{J}")#text(" on ")#mi("{\\Gamma_N}")#text(". Furthermore, ")#mi("{P}")#text(" has height at most")

#align(center)[#tao-fit-display[#mitex("\\exp( O( \\frac{NJ^2 \\log H}{D^2} + \\frac{N^2 J}{D} ) ).")]]
]

#emph[#text("Proof:")]#text(" We use the pigeonholing argument of Thue and Siegel. Let ")#mi("{M}")#text(" be an positive quantity of quasipolynomial size to be chosen later, and choose coefficients ")#mi("{c_{a,b}}")#text(" for ")#mi("{0 \\leq a,b \\leq D}")#text(" that are nonstandard natural numbers between ")#mi("{1}")#text(" and ")#mi("{M}")#text(". There are ")#mi("{M^{(D+1)^2} \\geq \\exp( D^2 \\log M)}")#text(" possible ways to make such a selection. For each such selection, we consider the ")#mi("{N(J+1)}")#text(" expressions arising as the left-hand side of ")#link(<tao-b38222d243e636f95235>)[#text("(6)")]#text(" with ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n \\leq N}")#text(". These expressions are nonstandard integers whose magnitude is bounded by")

#align(center)[#tao-fit-display[#mitex("O( (D+1)^2 M O( DH )^J \\exp( O( N D ) ) )")]]

#text("which by asymptotic calculus simplifies to be bounded by")

#align(center)[#tao-fit-display[#mitex("\\exp( \\log M + O( J \\log H ) + O( N D ) ).")]]

#text("The number of possible values of these ")#mi("{N(J+1)}")#text(" expressions is thus")

#align(center)[#tao-fit-display[#mitex("\\exp( N(J+1) \\log M + O( N J^2 \\log H ) + O( N^2 J D ) ).")]]

#text("By the hypothesis ")#mi("{D^2 \\gg NJ}")#text(" and asymptotic calculus, we can make this quantity less than ")#mi("{\\exp(D^2 \\log M)}")#text(" for some ")#mi("{M}")#text(" of size")

#align(center)[#tao-fit-display[#mitex("M \\ll \\exp( O( \\frac{NJ^2 \\log H}{D^2} + \\frac{N^2 J}{D} ) ).")]]

#text("In particular, ")#mi("{M}")#text(" can be taken to be of polylogarithmic size. Thus, by the pigeonhole principle, one can find two choices for the coefficients ")#mi("{c_{a,b}}")#text(" which give equal values for the expressions in the left-hand side of ")#link(<tao-b38222d243e636f95235>)[#text("(6)")]#text(". Subtracting those two choices we obtain the result. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. The bootstrap — ")]]

#text("At present, there is no contradiction between the lower bound in Proposition ")#link(<tao-4c5e0db5dcc545320ae8>)[#text("10")]#text(" and the upper bound in Proposition ")#link(<tao-a683a2f3f0d01164ae69>)[#text("11")]#text(", because there is plenty of room between the two bounds. To bridge the gap between the bounds, we need a bootstrap argument that uses vanishing on one ")#mi("{\\Gamma_N}")#text(" to imply vanishing (to slightly lower order) on a larger ")#mi("{\\Gamma_{N^{\\prime}}}")#text(". The key bootstrap in this regard is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Bootstrap)")]#text(" ")#metadata(none) <tao-333c04dd151a2a6831c0>#text(" Let ")#mi("{D, J, N}")#text(" be unbounded polylogarithmic quantities, such that")

#align(center)[#tao-fit-display[#mitex("N \\ggg \\log H.")]]

#text("Let ")#mi("{P}")#text(" be a good polynomial of degree at most ")#mi("{D}")#text(" and height ")#mi("{\\exp( O(NJ) )}")#text(", that nearly vanishes to order ")#mi("{2J}")#text(" on ")#mi("{\\Gamma_N}")#text(". Then ")#mi("{P}")#text(" also vanishes to order ")#mi("{J}")#text(" on ")#mi("{\\Gamma_{N^{\\prime}}}")#text(" for any ")#mi("{N^{\\prime} = o( \\frac{J}{D} N )}")#text(".")
]

#emph[#text("Proof:")]#text(" It is convenient to use complex analysis methods. We consider the entire function")

#align(center)[#tao-fit-display[#mitex("f(z) := P( 2^z, 3^z ),")]]

#text("thus by ")#link(<tao-770e607624d689265ca6>)[#text("(3)")]

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{0 \\leq a, b \\leq D} c_{a,b} 2^{az} 3^{bz}.")]]

#text("By hypothesis, we have")

#align(center)[#tao-fit-display[#mitex("f^{(j)}(n) \\approx 0")]]

#text("for all ")#mi("{0 \\leq j \\leq 2J}")#text(" and ")#mi("{1 \\leq n \\leq N}")#text(". We wish to show that")

#align(center)[#tao-fit-display[#mitex("f^{(j)}(n^{\\prime}) \\approx 0")]]

#text("for ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n^{\\prime} \\leq N^{\\prime}}")#text(". Clearly we may assume that ")#mi("{N^{\\prime} \\geq n^{\\prime} > N}")#text(".")

#text("Fix ")#mi("{0 \\leq j \\leq J}")#text(" and ")#mi("{1 \\leq n^{\\prime} \\leq N^{\\prime}}")#text(". To estimate ")#mi("{f^{(j)}(n^{\\prime})}")#text(", we consider the contour integral ")#metadata(none) <tao-2e1025a6f0aa4c8ef105>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\frac{1}{2\\pi i} \\int_{\\left|z\\right|=R} \\frac{f^{(j)}(z)}{\\prod_{n=1}^N (z-n)^J} \\frac{dz}{z-n^{\\prime}}", block: true)]]



#text(" (oriented anticlockwise), where ")#mi("{R \\geq 2N^{\\prime}}")#text(" is to be chosen later, and estimate it in two different ways. Firstly, we have")

#align(center)[#tao-fit-display[#mitex("f^{(j)}(z) = \\sum_{0 \\leq a, b \\leq D} c_{a,b} (a \\log 2 + b \\log 3)^j 2^{az} 3^{bz},")]]

#text("so for ")#tao-math("{\\left|z\\right|=2N^{\\prime}}", block: false)#text(", we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{(j)}(z)\\right| \\ll D^2 \\exp(o(NJ)) O( D )^J \\exp( O( D R ) )", block: true)]]

#text("when ")#tao-math("{\\left|z\\right|=2N^{\\prime}}", block: false)#text(", which by the hypotheses and asymptotic calculus, simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{(j)}(z)\\right| \\ll \\exp( O( NJ + DR) ).", block: true)]]

#text("Also, when ")#tao-math("{\\left|z\\right|=R}", block: false)#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\prod_{n=1}^N (z-n)^J\\right| \\geq (R/2)^{NJ}.", block: true)]]

#text("We conclude the upper bound")

#align(center)[#tao-fit-display[#mitex("\\exp( O(NJ + DR) - NJ \\log R )")]]

#text("for the magnitude of ")#link(<tao-2e1025a6f0aa4c8ef105>)[#text("(7)")]#text(". On the other hand, we can evaluate ")#link(<tao-2e1025a6f0aa4c8ef105>)[#text("(7)")]#text(" using the ")#link("http://en.wikipedia.org/wiki/Residue_theorem")[#text("residue theorem")]#text(". The integrand has poles at ")#mi("{1,\\ldots,N}")#text(" and at ")#mi("{n^{\\prime}}")#text(". The simple pole at ")#mi("{n^{\\prime}}")#text(" has residue")

#align(center)[#tao-fit-display[#mitex("\\frac{f^{(j)}(n^{\\prime})}{\\prod_{n=1}^N (n^{\\prime}-n)^J}.")]]

#text("Now we consider the poles at ")#mi("{n=1,\\ldots,N}")#text(". For each such ")#mi("{n}")#text(", we see that the first ")#mi("{J}")#text(" derivatives of ")#mi("{f^{(j)}}")#text(" are quasiexponentially small at ")#mi("{n}")#text(". Thus, by Taylor expansion (and asymptotic calculus), one can express ")#mi("{f^{(j)}(z)}")#text(" as the sum of a polynomial of degree ")#mi("{J}")#text(" with quasiexponentially small coefficients, plus an entire function that vanishes to order ")#mi("{J}")#text(" at ")#mi("{n}")#text(". The latter term contributes nothing to the residue at ")#mi("{n}")#text(", while from the Cauchy integral formula (applied, for instance, to a circle of radius ")#mi("{1/2}")#text(" around ")#mi("{n}")#text(") and asymptotic calculus, we see that the former term contributes a residue is quasiexponentially small. In particular, it is less than ")#mi("{\\exp( O(NJ) - NJ \\log R )}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{f^{(j)}(n^{\\prime})}{\\prod_{n=1}^N (n^{\\prime}-n)^J}\\right| \\ll \\exp( O(NJ + DR) - NJ \\log R ).", block: true)]]

#text("We have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\prod_{n=1}^N (n^{\\prime}-n)^J\\right| \\leq (N^{\\prime})^{NJ}", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{(j)}(n^{\\prime})\\right| \\ll \\exp( O(NJ+DR) - NJ \\log \\frac{R}{N^{\\prime}} );", block: true)]]

#text("choosing ")#mi("{R}")#text(" to be a large standard multiple of ")#mi("{N^{\\prime}}")#text(" and using the hypothesis ")#mi("{N^{\\prime} = o( \\frac{J}{D} N)}")#text(", we can simplify this to")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{(j)}(n^{\\prime})\\right| \\ll \\exp( - NJ ).", block: true)]]

#text("To improve this bound, we use the integrality gap. Recall that from ")#link(<tao-27037fccea3062ee8eba>)[#text("(5)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{(j)}(n^{\\prime})\\right| \\approx (\\frac{\\log 3}{q})^j \\sum_{0 \\leq a, b \\leq D} c_{a,b} (ap+bq)^j 2^{an^{\\prime}} 3^{bn^{\\prime}};", block: true)]]

#text("in particular, ")#mi("{(\\frac{q}{\\log 3})^j f^{(j)}(n^{\\prime})}")#text(" is quasiexponentially close to a (nonstandard) integer. Since")

#align(center)[#tao-fit-display[#mitex("(\\frac{q}{\\log 3})^j = \\exp( O( J \\log H ) ),")]]

#text("we have")

#align(center)[#tao-fit-display[#tao-math("\\left|(\\frac{q}{\\log 3})^j f^{(j)}(n^{\\prime})\\right| \\leq \\frac{1}{2}", block: true)]]

#text("(say). Using the integrality gap, we conclude that")

#align(center)[#tao-fit-display[#mitex("(\\frac{q}{\\log 3})^j f^{(j)}(n^{\\prime}) \\approx 0")]]

#text("which implies that ")#mi("{f}")#text(" nearly vanishes to order ")#mi("{J}")#text(" on ")#mi("{\\Gamma_{N^{\\prime}}}")#text(", as required. ")#mi("\\Box")

#text("Now we can finish the proof of Proposition ")#link(<tao-6d563251c5d6f4a82c75>)[#text("7")]#text(" (and hence Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text("). We select quantities ")#mi("{D, J, N_0}")#text(" of polylogarithmic size obeying the bounds")

#align(center)[#tao-fit-display[#mitex("\\log H \\lll N_0 \\lll D \\lll J")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N_0 J \\lll D^2,")]]

#text("with a gap of a positive power of ")#mi("{\\log H}")#text(" between each such inequality. For instance, one could take")

#tao-aligned(keep: true)[


#tao-math("N_0  & := \\log^2 H", block: true)



#tao-math("D  & := \\log^{4} H", block: true)



#tao-math("J  & := \\log^{5} H;", block: true)
]

#text("many other choices are possible (and one can optimise these choices eventually to get a good value of exponent ")#mi("{C^{\\prime}}")#text(" in Proposition ")#link(<tao-7ec833ac10110475b896>)[#text("6")]#text(").")

#text("Using Proposition ")#link(<tao-a683a2f3f0d01164ae69>)[#text("11")]#text(", we can find a good polynomial ")#mi("{P}")#text(" which vanishes to order ")#mi("{J}")#text(" on ")#mi("{\\Gamma_{N_0}}")#text(", of height ")#mi("{\\exp( O( \\frac{N_0 J^2 \\log H}{D^2} + \\frac{N_0^2 J}{D} ) )}")#text(", and hence (by the assumptions on ")#mi("{N_0,D,J}")#text(") of height ")#mi("{\\exp( O( N_0 J ) )}")#text(".")

#text("Applying Proposition ")#link(<tao-333c04dd151a2a6831c0>)[#text("12")]#text(", ")#mi("{P}")#text(" nearly vanishes to order ")#mi("{J/2}")#text(" on ")#mi("{\\Gamma_{N_1}}")#text(" for any ")#mi("{N_1 = o( \\frac{J}{D} N_0)}")#text(". Iterating this, an easy induction shows that for any standard ")#mi("{k\\geq 1}")#text(", ")#mi("{P}")#text(" nearly vanishes to order ")#mi("{J/2^k}")#text(" on ")#mi("{\\Gamma_{N_k}}")#text(" for any ")#mi("{N_k = o( (\\frac{J}{D})^k N_0)}")#text(". As ")#mi("{J/D}")#text(" was chosen to be larger than a positive power of ")#mi("{\\log H}")#text(", we conclude that ")#mi("{P}")#text(" nearly vanishes to order at least ")#mi("{0}")#text(" on ")#mi("{\\Gamma_N}")#text(" for any ")#mi("{N}")#text(" of polylogarithmic size. But for ")#mi("{N}")#text(" large enough, this contradicts Proposition ")#link(<tao-4c5e0db5dcc545320ae8>)[#text("10")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument places a lower bound on quantities such as")

#align(center)[#tao-fit-display[#mitex("q \\log 2 - p \\log 3")]]

#text("for integer ")#mi("{p, q}")#text(". ")#link("http://en.wikipedia.org/wiki/Baker's_theorem")[#text("Baker’s theorem")]#text(", in its full generality, gives a lower bound on quantities such as")

#align(center)[#tao-fit-display[#mitex("\\beta_0 + \\beta_1 \\log \\alpha_1 + \\ldots + \\beta_n \\log \\alpha_n")]]

#text("for algebraic numbers ")#mi("{\\beta_0,\\ldots,\\beta_n, \\alpha_1,\\ldots,\\alpha_n}")#text(", which is polynomial in the height of the quantities involved, assuming of course that ")#mi("{1, \\alpha_1,\\ldots,\\alpha_n}")#text(" are multiplicatively independent, and that all quantities are of bounded degree. The proof is more intricate than the one given above, but follows a broadly similar strategy, and the constants are completely effective.")
]

#heading(level: 1)[#text("Comments (40)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69311")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("Is a^b defined for a<0, b irrational?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("Ah, fair point; ")#mi("a^b")#text(" can be multivalued in general (using the complex logarithm and complex exponential to define ")#mi("a^b")#text(" when a is not a positive real); but the Gelfond-Schneider theorem will apply to each of the interpretations of ")#mi("a^b")#text(". I’ve modified the statement of the theorem slightly to reflect this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69359")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")])]

#text("Doesn’t the general case (when a is neither =0 nor 1) follow easily from the special case a>0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69435")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")])]

#text("I don’t see an easy argument to establish that, no. For instance, one well-known consequence of the (complex) Gelfond-Schneider theorem is the transcendentality of ")#mi("e^\\pi")#text(", which is one of the possible values of ")#mi("(-1)^i")#text(". I don’t see how to easily establish this fact just from the positive case of that theorem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-70117")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2011")])]

#text("Sorry, I made a typo. “Doesn’t the general case follow easily from the special case a>1?”. (not a>0. That was the typo).")#linebreak()#text(" The case 0<a1, and 1/a is algebraic when a is algebraic.")#linebreak()#text(" I accept that the case a1 and {\\pi} is irrational, because e is not algebraic. The transcendentality of {(-1)^i} does not follow because i is not irrational. Or is it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-70122")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2011")])]

#text("The comment below is unreadable because I use shorthand for less than and greater than. I cannot edit a comment once it is posted.")

#text("The case “0 less than a less than 1”, follow because then 1/a is greater than 1, and 1/a is algebraic when a is algebraic.")

#text("I accept that the case: “a less than 0”, does not follow from the case: “a greater than 1”, but I do not understand you example.")

#text("The transcendentallity of e^pi does not follow because e is not algebraic.")

#text("The transcendentality of (-1)^i does not follow because i is not irrational. Or is it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-70132")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2011")])]

#text("i is not the ratio of two integers, and is hence irrational.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80b8109646066ceac6528d8d5e47a1fe392a2aa6b7d1206b017111d9933fc348-7524e4e87e50a93df1bd29da1042cd595a82c1438062002485381dc3bae9ee95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Israel Aku")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-482407")[#strong[#text("Israel Aku")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2017")])]

#text("Hello Terry, is there a case where a is algebraic and b is transcendental, and the value of a^b is algebraic? I very much enjoyed the banner’s quote. Is it from Emma Lazarus’ The New Colossus as a standalone poem or as an inscription on the Statue of Liberty?")

#emph[#text("[One can take for instance ")#mi("a = 2")#text(" and ")#mi("b = \\log_2 3")#text(". -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3276e20f81c41be100b60014a05f509ffba4a6efe962f38e3b84e36b57432be1-f852860ad680f4a97470ce72ec682306ab2f0cb2fa52b7cf73afc8f7378eb9fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cks")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-639617")[#strong[#text("cks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2022")])]

#text("This example generalizes: every integer $m>1$ can be expressed as $m=rad(m)^{ap(m)}$ where $ap(m)=\\log_{rad(m)}(m)$ is transcendental if $m$ is not a perfect power.")

#text("$ap(m)$ seems to be an arithmetic function of independent interests. If we write $m$ uniquely as $m=m_1m_2^2m_3^3…$, where $m_j=\\prod_{p^j||m}p$ , then")#linebreak()#text(" $ap(m)=\\frac{\\sum j \\log(m_j)}{\\sum \\log(m_j)}$ so it is a measure of the weighted average powers dividing $m$.")

#text("A weak form of the ABC conjecture implies that for some sufficiently large $n$, there is no integral solution to $a+b=c, gcd(a,b)=1$ with $ap(a),ap(b),ap(c) \\ge n$ which is a generalization of Fermat last theorem.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf2fc685c192c8fe2e58eaac9d400adb225661004fe30fd7d3a657102bc619c-f17c8f0478723cf5f8a606c3611f30cbc3f5f54a0d839882049c33ec65cec38a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Hurwitz")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69332")[#strong[#text("Jeremy Hurwitz")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2011")])]

#text("In the statement of Theorem 1, the last sentence got truncated. It’s currently ends “(Note that”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69434")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")])]

#text("I am a student majored in mathematics in shanghai maritime university.I regard you as a model to adore and study.(i’m sorry that i am poor at english.O(∩_∩)O).Many people said that you were genius,but i hold the view that 100%success equals 99%hardworking and 1% genius.so i think that you are not alone,there are many mathematics explorers in the world who havn’t been found.")#linebreak()#text(" Good Luck!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evgeniy")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-69752")[#strong[#text("Evgeniy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2011")])]

#text("It is a very interesting post (as much of your others posts are)!")

#text("A minor typo (as I see it): aq+bp should be replaced by ap+bq in the formula (5), the formula preceding (5) and two formulae after (5) (in (6), in particular).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-70103")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2011")])]

#text("You wrote: the gap between powers of two {3^p} and powers of three {2^q}. You ment to write: the gap between powers of three {3^p} and powers of two {2^q}. ")#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 « What’s new")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-70351")[#strong[#text("The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("[…] need a lower bound on . Here, we will use Baker’s theorem (as discussed in this previous post), which among other things gives the lower […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diophantine sets and the integers | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-82098")[#strong[#text("Diophantine sets and the integers | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] Hilbert’s seventh problem, and powers of 2 and 3 (terrytao.wordpress.com) LD_AddCustomAttr(\"AdOpt\", \"1\"); LD_AddCustomAttr(\"Origin\", \"other\"); LD_AddCustomAttr(\"theme_bg\", \"ffffff\"); LD_AddCustomAttr(\"theme_text\", \"333333\"); LD_AddCustomAttr(\"theme_link\", \"0066cc\"); LD_AddCustomAttr(\"theme_border\", \"f2f7fc\"); LD_AddCustomAttr(\"theme_url\", \"ff4b33\"); LD_AddCustomAttr(\"LangId\", \"1\"); LD_AddCustomAttr(\"Tag\", \"diophantine-equation\"); LD_AddCustomAttr(\"Tag\", \"hilberts-problems\"); LD_AddCustomAttr(\"Tag\", \"hilberts-tenth-problem\"); LD_AddSlot(\"LD_ROS_300-WEB\"); LD_GetBids(); Rate this: Share this:TwitterPrintFacebookLinkedInEmailDiggRedditStumbleUponLike this:LikeBe the first to like this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of More on Hilbert’s tenth problem | cartesian product")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-82310")[#strong[#text("More on Hilbert’s tenth problem | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2011")])]

#text("[…] Hilbert’s seventh problem, and powers of 2 and 3 (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-90162")[#strong[#text("mathsetc")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")]

#text("[…] Hilbert’s seventh problem, and powers of 2 and 3 (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-161715")[#strong[#text("Eleventh Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2012")]

#text("[…] Terence Tao: A geometric proof of the impossibility of angle trisection by straightedge and compass, Hilbert’s seventh problem, and powers of 2 and 3 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-249017")[#strong[#text("Algebraic combinatorial geometry: the polynomial method in arithmetic combinatorics, incidence combinatorics, and number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2013")])]

#text("[…] used independently many times in mathematics; for instance, it plays a key role in the proof of Baker’s theorem in transcendence theory, or Stepanov’s method in giving an elementary proof of the Riemann hypothesis for finite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87c0566cc4d48dfa89316917ed7dc95aa34f8f017b7dfe4b23197f5e143a8f64-7dfb2b384c4f03becbe72ee071ed5bdd8555ec9f76cbc63a32dc40695b87aec0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-451230")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2015")])]

#text("Do it again. Wouaow. What a synthesis ! Just a naive question. As \\displaystyle |3^p – 2^q| \\geq 1, for which For which p,q does the equality holds ? I know of 1,2. Are there other solutions ? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-451235")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2015")])]

#mi("p=2, q=3")

#text("See the Wikipedia article on Catalan’s conjecture. ")#link("http://en.wikipedia.org/wiki/Catalan%27s_conjecture")[#text("http://en.wikipedia.org/wiki/Catalan%27s_conjecture")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fff3f4cd0a0b6cdb72dd636f43e6f513be74a0dc1d96d62a730c6d60d8865ff-8857a83a5c4ceac1b2054a03070ce442ed0df059960c946610e51b07303165cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried Helms")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-485949")[#strong[#text("Gottfried Helms")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("In corollary 4 you write, “…for effectively computable constants c,C>1 …” . So far I’ve no idea how I could compute values for such constants; based on plotting up to p=1e125 it seems c=0.01, C=1 the separation is larger than the formula on the rhs – but this is surely only a guess. Are that constants already computed somewhere?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fff3f4cd0a0b6cdb72dd636f43e6f513be74a0dc1d96d62a730c6d60d8865ff-8857a83a5c4ceac1b2054a03070ce442ed0df059960c946610e51b07303165cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried Helms")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-485950")[#strong[#text("Gottfried Helms")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2017")])]

#text("… sorry, meant to cite you as “…c,C>0…”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fff3f4cd0a0b6cdb72dd636f43e6f513be74a0dc1d96d62a730c6d60d8865ff-8857a83a5c4ceac1b2054a03070ce442ed0df059960c946610e51b07303165cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gottfried Helms")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-485957")[#strong[#text("Gottfried Helms")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2017")])]

#text("I improved my rough guess to $c=0.005,C=1.01$ See some pictures which are that guesses basis at ")#link("https://math.stackexchange.com/q/2418882/1714")[#text("https://math.stackexchange.com/q/2418882/1714")]#text(" I plotted up to $p=1e175$")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of seaneberhard")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-505895")[#strong[#text("seaneberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("Typo: the inequality in the first display after Prop 7 goes the wrong way.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36c92e4888a6586acbed525d3a47fb7825ec94682c6b0582cea2b89a1c1386dc-d60767864d85ed0d92167237783c41fb5da0141fbcbbbaff4fbc6e515545ff10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Baker’s Theorem and the Class Number Problem (Part 1) – Non Sequitur")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-589683")[#strong[#text("Baker’s Theorem and the Class Number Problem (Part 1) – Non Sequitur")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2020")])]

#text("[…] I do not aim to prove this theorem here; the proof is too long but essentially is a proof by contradiction (the proof has a nice use of Siegel’s Lemma too, another favourite result of mine!). For a discussion of proof using non-standard analysis, see Tao’s excellent post here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-637882")[#strong[#text("reference request - Key concepts behind p-adic Baker's theorem Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2021")]

#text("[…] p-adic theorem). I do know the proof of the habitual Baker theorem by glorious assets love Blog put up from Terence Tao, or Soundararajan’s Notes. I marvel if anybody has any related summaries or sketches for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61fe96948c5a63ccf3c158b300059337fefc1b16d8fbf0668f70f40339d67920-a25a80f8fc491e04880f184c06eb5c36e7e752dcd9b0302f8e601cd1ac85960c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gottiks")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-639592")[#strong[#text("gottiks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2022")])]

#text("Recently I tested the idea of bounding $|2^S-3^N| > 1/10/N/\\log N$ up to $N$ with a million decimal digits. (Of course using the convergents of the cont frac) That has an amazing type of fit. (I’m unfinished with composing a comparision of the Rhin- and the Ellison-bounds, see here to have a plot: ")#link("https://math.meta.stackexchange.com/a/9386/1714")[#text("https://math.meta.stackexchange.com/a/9386/1714")]#text(" and more thoughts). Is there any chance to follow this model and develop an analytical proof? For instance, if there is a proof, then the disproof of the “1-cycle” is very simple and obvious for $N>7$ – no further analysis like with the bound by G. Rhin used by John Simons were needed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/61fe96948c5a63ccf3c158b300059337fefc1b16d8fbf0668f70f40339d67920-a25a80f8fc491e04880f184c06eb5c36e7e752dcd9b0302f8e601cd1ac85960c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gottiks")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-639593")[#strong[#text("gottiks")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2022")])]

#text("Curious. The previous link was corrupted: see the answer box in “sandbox” in meta-MSE ")#link("https://math.meta.stackexchange.com/a/4668/1714")[#text("https://math.meta.stackexchange.com/a/4668/1714")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-652057")[#strong[#text("diophantine approximation - Simple estimation of difference of powers of 2 and powers of 3? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2022")]

#text("[…] lower bound in (2) is claimed by ")#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")[#text("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/")]#text(" (proposition 3 and corollary 4) . Terry Tao uses (1.2) with $geq$ instead of (1.1) with $ 2^q$ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-672153")[#strong[#text("Show the “trivial bound” $|frac{log{2}}{log{3}} – frac{p}{q}| ge c frac{1}{2^q}$ holds for some $c > 0$ and integers $p, q$ with $q$ positive – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2023")]

#text("[…] (Paraphrased from Proposition 5 (Trivial bound) in Terence Tao's blog article.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-673275")[#strong[#text("[Answer] Show the \"trivial bound\" |log2log3?pq|?c12q??log2log3?pq???c12q holds for c>0c>0 and integers p,qp,q with qq positive - Essaynice")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2023")]

#text("[…] (Paraphrased from Proposition 5 (Trivial bound) in Terence Tao’s blog article.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-676993")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2023")])]

#text("(3 log q \\ · a q · b p · + ·) &approx; (a 3 log · b 2 log · +). But you apparently wanted to get (a 2 log · b 3 log · +) instead?")

#emph[#text("[Sorry, I was unable to parse your reverse Polish(?) notation and to connect it with a specific location in the blog post. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9138e6a30cdccdeb159ea2fdda521127ca027424c02ab660faf13a5c92e4f34d-1d7619d2f83b4a04356dadab2ae0502deee0cb37ce3f41b3fb3c900ef0575de7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien Friedli")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687067")[#strong[#text("Fabien Friedli")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2025")])]

#text("I am wondering if something along the following lines gives exponential separation between powers of two and powers of three without Baker’s machinery. Fix a large integer ")#mi("d")#text(" and look at ")#mi("p")#text(" and ")#mi("q")#text(" modulo ")#mi("d")#text(". A crude estimate then shows that ")#tao-math("\\left|3^p-2^q\\right|", block: false)#text(" is bounded below by ")#tao-math("\\left|\\frac{x}{y}-\\sqrt[d]{\\frac{2^b}{3^a}}\\right|\\cdot y^d", block: false)#text(" where ")#mi("a")#text(" and ")#mi("b")#text(" are residues of ")#mi("p")#text(" and ")#mi("q")#text(" modulo ")#mi("d")#text(", ")#mi("x= 3^{(p-a)/d}")#text(" and ")#mi("y= 2^{(q-b)/d}")#text(".")

#text("We then apply Thue theorem in diophantine approximation and get an exponential bound ")#mi("(\\sqrt{2})^q")#text(" (noting that, ")#mi("d")#text(" being fixed, the constant we get using Thue theorem will depend only on ")#mi("d")#text(").")

#text("I am trying to use as weak a result as possible but of course we could use the full Roth theorem and get a constant arbitrarily close to 2 instead of ")#mi("\\sqrt{2}")#text(", although it remains far from Baker’s or even Proposition 6.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687070")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2025")])]

#text("Nice argument! Though there is one technical wrinkle that may need to be sorted out to make this argument completely rigorous: if ")#mi("d")#text(" divides both ")#mi("p")#text(" and ")#mi("q")#text(", then ")#mi("a=b=0")#text(" and one cannot apply Thue’s theorem or its relatives. Of course, in this case we can get a separate bound for ")#tao-math("\\left|3^p-2^q\\right|", block: false)#text(" using the separation between ")#mi("d")#text("th powers. It seems that even taking ")#mi("d=3")#text(" would suffice to get an exponential bound, if I am not mistaken.")

#text("EDIT: One drawback of these sorts of arguments is that (in contrast to the Baker’s theorem argument), the implied constant is ineffective.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2025")])]

#text("A minor mistake in the statement of the dirichlet’s theorem on diophantine approximations: ")#mi("\\alpha")#text(" should be an irrational number rather than any real number, since integers and rational numbers are also real numbers but they do not satisfy this condition (i.e. “for infinitely many ")#mi("p,q")#text("“).")

#emph[#text("[Actually, I believe the statment remains true for rational ")#mi("\\alpha")#text(" (I am not requiring ")#mi("p,q")#text(" to be coprime) – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2025")])]

#text("Interesting! I’m currently looking at applying Collatz in a cumulative binary clock where every number is represented around a circle by its proportion between powers of 2, this eliminates the effect of the halving steps and means that only the 3n+1 affects position on the circle.")

#text("I think that your work here may help me prove the error from the algorithm’s attempt to approximate log3/log2 and the error from the +1 step can never match up to form a loop. If so it not only precludes any number higher than 1 being the first value in a loop but also suggests Weyl’s distribution theorem applies around the circle, ensuring eventual convergence. I need to sit down and work through it all properly when I get time!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fbcc99869957e2a8bcad3bc0a9b907e9fb13a625fca19af6131450429c860cf-d2db5b99857bade4b5b208d5b22e363c69f58c2b2e453707c4a7dd068ec011da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Agustín Meza")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687179")[#strong[#text("Agustín Meza")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("Dear professor Tao: do you think Baker’s theorem can be used in prime number theory in order to look at upper bounds of strings of smooth numbers? I was thinking that since log(p) and log(q) are linearly independent from each other, then it could be used to give upper bounds for the longest strings of (say) ")#mi("n^{\\theta}")#text(" smooth numbers, since for such numbers n, log(n) could be expressed as a linear combination of logarithms of primes less than or equal to ")#mi("n^{\\theta}")#text(", so, due to the fact that the support of the primes which contribute to the linear combination is reduced, perhaps a long string of consecutive smooth numbers would lead to several linear combinations of the form ")#mi("c_{i}\\log(p_{i})")#text(" (with c_{i} being integers) which practically cancel out or have small error terms and lead to a contradiction due to the reduced numbers of logarithms of primes which contribute and applying Baker’s theorem. Do you think Baker’s theorem is strong enough to give more efficient upper bounds on such strings than sieve methods or at least give decent bounds?")

#text("Perhaps this is another silly question, but with this argument of “no numbers with small prime factors might lead to a contradiction”, could it be used to find primes in short intervals alternatively from sieve techniques?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2025")])]

#text("I suspect Baker’s theorem and its relatives will primarily be of use for controlling extremely smooth numbers (say ")#mi("\\log\\log n")#text("-smooth), but there are a large number of potential prime factors between ")#mi("\\log\\log n")#text(" and say ")#mi("n^\\theta")#text(" that would likely require a quite different set of tools to treat.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/08/21/hilberts-seventh-problem-and-powers-of-2-and-3/#comment-687478")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2025")])]

#text("Does Thue-Siegel-Roth’s theorem assert that if a real number ")#mi("x")#text(" has irrationality measure ")#mi("\\mu(x)")#text(" strictly greater than 2, then ")#mi("x")#text(" must be transcendental?")

#emph[#text("[Yes – T.]")]
]
