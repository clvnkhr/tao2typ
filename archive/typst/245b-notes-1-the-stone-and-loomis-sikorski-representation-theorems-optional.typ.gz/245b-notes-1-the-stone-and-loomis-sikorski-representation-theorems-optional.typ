// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/
// Converted to Typst by tao2typ: "2026-10-14T07:10:09.584771+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B notes 4: The Stone and Loomis-Sikorski representation theorems (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B notes 4: The Stone and Loomis-Sikorski representation theorems (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("A (concrete) ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("Boolean algebra")]#text(" is a pair ")#mi("(X, {\\mathcal B})")#text(", where X is a set, and ")#mi("{\\mathcal B}")#text(" is a collection of subsets of X which contain the empty set ")#mi("\\emptyset")#text(", and which is closed under unions ")#mi("A, B \\mapsto A \\cup B")#text(", intersections ")#mi("A, B \\mapsto A \\cap B")#text(", and complements ")#mi("A \\mapsto A^c := X \\backslash A")#text(". The subset relation ")#mi("\\subset")#text(" also gives a relation on ")#mi("{\\mathcal B}")#text(". Because the ")#mi("{\\mathcal B}")#text(" is concretely represented as subsets of a space X, these relations automatically obey various axioms, in particular, for any ")#mi("A,B,C \\in {\\mathcal B}")#text(", we have:")

#enum(start: 1, 
[#mi("\\subset")#text(" is a partial ordering on ")#mi("{\\mathcal B}")#text(", and A and B have ")#link("http://en.wikipedia.org/wiki/Join_(mathematics)")[#text("join")]#text(" ")#mi("A \\cup B")#text(" and ")#link("http://en.wikipedia.org/wiki/Meet_(mathematics)")[#text("meet")]#text(" ")#mi("A \\cap B")#text(".")],
[#text("We have the ")#link("http://en.wikipedia.org/wiki/Distributive_lattice")[#text("distributive laws")]#text(" ")#mi("A \\cup (B \\cap C) = (A \\cup B) \\cap (A \\cup C)")#text(" and ")#mi("A \\cap (B \\cup C) = (A \\cap B) \\cup (A \\cap C)")#text(".")],
[#mi("\\emptyset")#text(" is the minimal element of the partial ordering ")#mi("\\subset")#text(", and ")#mi("\\emptyset^c")#text(" is the maximal element.")],
[#mi("A \\cap A^c = \\emptyset")#text(" and ")#mi("A \\cup A^c = \\emptyset^c")#text(".")]
)

#text("(More succinctly: ")#mi("{\\mathcal B}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Lattice_(order)")[#text("lattice")]#text(" which is ")#link("http://en.wikipedia.org/wiki/Distributive_lattice")[#text("distributive")]#text(", bounded, and complemented.)")

#text("We can then define an ")#emph[#text("abstract Boolean algebra")]#text(" ")#mi("{\\mathcal B} = ({\\mathcal B}, \\emptyset, \\cdot^c, \\cup, \\cap, \\subset)")#text(" to be an abstract set ")#mi("{\\mathcal B}")#text(" with the specified objects, operations, and relations that obey the axioms 1-4. [Of course, some of these operations are redundant; for instance, intersection can be defined in terms of complement and union by de Morgan’s laws. In the literature, different authors select different initial operations and axioms when defining an abstract Boolean algebra, but they are all easily seen to be equivalent to each other. To emphasise the abstract nature of these algebras, the symbols ")#mi("\\emptyset, \\cdot^c, \\cup, \\cap, \\subset")#text(" are often replaced with other symbols such as ")#mi("0, \\overline{\\cdot}, \\vee, \\wedge, <")#text(".]")

#text("Clearly, every concrete Boolean algebra is an abstract Boolean algebra. In the converse direction, we have ")#link("http://en.wikipedia.org/wiki/Stone%27s_representation_theorem_for_Boolean_algebras")[#text("Stone’s representation theorem")]#text(" (see below), which asserts (among other things) that every abstract Boolean algebra is isomorphic to a concrete one (and even constructs this concrete representation of the abstract Boolean algebra canonically). So, up to (abstract) isomorphism, there is really no difference between a concrete Boolean algebra and an abstract one.")

#text("Now let us turn from Boolean algebras to ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("\\sigma")#text("-algebras")]#text(".")

#text("A ")#emph[#text("concrete ")#mi("\\sigma")#text("-algebra")]#text(" (also known as a ")#emph[#text("measurable space")]#text(") is a pair ")#mi("(X,{\\mathcal B})")#text(", where X is a set, and ")#mi("{\\mathcal B}")#text(" is a collection of subsets of X which contains ")#mi("\\emptyset")#text(" and are closed under countable unions, countable intersections, and complements; thus every concrete ")#mi("\\sigma")#text("-algebra is a concrete Boolean algebra, but not conversely. As before, concrete ")#mi("\\sigma")#text("-algebras come equipped with the structures ")#mi("\\emptyset, \\cdot^c, \\cup, \\cap, \\subset")#text(" which obey axioms 1-4, but they also come with the operations of countable union ")#mi("(A_n)_{n=1}^\\infty \\mapsto \\bigcup_{n=1}^\\infty A_n")#text(" and countable intersection ")#mi("(A_n)_{n=1}^\\infty \\mapsto \\bigcap_{n=1}^\\infty A_n")#text(", which obey an additional axiom:")

#text("5. Any countable family ")#mi("A_1, A_2, \\ldots")#text(" of elements of ")#mi("{\\mathcal B}")#text(" has ")#link("http://en.wikipedia.org/wiki/Supremum")[#text("supremum")]#text(" ")#mi("\\bigcup_{n=1}^\\infty A_n")#text(" and ")#link("http://en.wikipedia.org/wiki/Infimum")[#text("infimum")]#text(" ")#mi("\\bigcap_{n=1}^\\infty A_n")#text(".")

#text("As with Boolean algebras, one can now define an ")#emph[#text("abstract ")#mi("\\sigma")#text("-algebra")]#text(" to be a set ")#mi("{\\mathcal B} = ({\\mathcal B}, \\emptyset, \\cdot^c, \\cup, \\cap, \\subset, \\bigcup_{n=1}^\\infty, \\bigcap_{n=1}^\\infty )")#text(" with the indicated objects, operations, and relations, which obeys axioms 1-5. Again, every concrete ")#mi("\\sigma")#text("-algebra is an abstract one; but is it still true that every abstract ")#mi("\\sigma")#text("-algebra is representable as a concrete one?")

#text("The answer turns out to be no, but the obstruction can be described precisely (namely, one needs to quotient out an ideal of “null sets” from the concrete ")#mi("\\sigma")#text("-algebra), and there is a satisfactory representation theorem, namely the ")#emph[#text("Loomis-Sikorski representation theorem")]#text(" (see below). As a corollary of this representation theorem, one can also represent abstract measure spaces ")#mi("({\\mathcal B},\\mu)")#text(" (also known as ")#emph[#text("measure algebras")]#text(") by concrete measure spaces, ")#mi("(X, {\\mathcal B}, \\mu)")#text(", after quotienting out by null sets.")

#text("In the rest of this post, I will state and prove these representation theorems. They are not actually used directly in the rest of the course (and they will also require some results that we haven’t proven yet, most notably ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text("), and so these notes are optional reading; but these theorems do help explain why it is “safe” to focus attention primarily on concrete ")#mi("\\sigma")#text("-algebras and measure spaces when doing measure theory, since the abstract analogues of these mathematical concepts are largely equivalent to their concrete counterparts. (The situation is quite different for ")#link("http://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("non-commutative measure theories")]#text(", such as ")#link("http://en.wikipedia.org/wiki/Quantum_probability")[#text("quantum probability")]#text(", in which there is basically no good representation theorem available to equate the abstract with the classically concrete, but I will not discuss these theories here.)")

#heading(level: 1)[#metadata(none) <tao-8b6c045623a4bcbe7951>#text("— Stone’s representation theorem —")]

#text("We first give the class of Boolean algebras the structure of a ")#link("http://en.wikipedia.org/wiki/Category_%3C/p%3E%0A%3Cp%3E%28mathematics%29")[#text("category")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Boolean algebra morphism) A ")#emph[#text("morphism")]#text(" ")#mi("\\phi: {\\mathcal A} \\to {\\mathcal B}")#text(" from one abstract Boolean algebra to another is a map which preserves the empty set, complements, unions, intersections, and the subset relation (e.g. ")#mi("\\phi(A \\cup B) = \\phi(A) \\cup \\phi(B)")#text(" for all ")#mi("A, B \\in {\\mathcal A}")#text(". An isomorphism is an morphism ")#mi("\\phi: {\\mathcal A} \\to {\\mathcal B}")#text(" which has an inverse morphism ")#mi("\\phi^{-1}: {\\mathcal B} \\to {\\mathcal A}")#text(". Two Boolean algebras are ")#emph[#text("isomorphic")]#text(" if there is an isomorphism between them.")
]

#text("Note that if ")#mi("(X,{\\mathcal A}), (Y, {\\mathcal B})")#text(" are concrete Boolean algebras, and if ")#mi("f: X \\to Y")#text(" is a map which is measurable in the sense that ")#mi("f^{-1}(B) \\in {\\mathcal A}")#text(" for all ")#mi("B \\in {\\mathcal B}")#text(", then the inverse of f is a Boolean algebra morphism ")#mi("{}f^{-1}: {\\mathcal B} \\to {\\mathcal A}")#text(" which goes in the reverse (i.e. contravariant) direction to that of f. To state Stone’s representation theorem we need another definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Stone space) A Stone space is a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological space")]#text(" ")#mi("X = (X, {\\mathcal F})")#text(" which is")#link("http://en.wikipedia.org/wiki/Compact_space")[#text(" compact")]#text(", ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(", and ")#link("http://en.wikipedia.org/wiki/Totally_disconnected")[#text("totally disconnected")]#text(". Given a Stone space, define the ")#emph[#text("clopen algebra")]#text(" ")#mi("{}Cl(X)")#text(" of X to be the concrete Boolean algebra on X consisting of the ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen sets")]#text(" (i.e. sets that are both closed and open).")
]

#text("It is easy to see that ")#mi("Cl(X)")#text(" is indeed a concrete Boolean algebra for any topological space X. The additional properties of being compact, Hausdorff, and totally disconnected are needed in order to recover the topology ")#mi("{\\mathcal F}")#text(" of X uniquely from the clopen algebra. Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" If X is a Stone space, then the topology ")#mi("{\\mathcal F}")#text(" of X is generated by the clopen algebra ")#mi("Cl(X)")#text(". Equivalently, the clopen algebra forms an ")#link("http://en.wikipedia.org/wiki/Base_(topology)")[#text("open base")]#text(" for the topology.")
]

#strong[#text("Proof.")]#text(" Let ")#mi("x \\in X")#text(" be a point, and let ")#mi("K")#text(" be the intersection of all the clopen sets containing x. Clearly, K is closed. We claim that K={x}. If this is not the case, then (since X is totally disconnected) K must be disconnected, thus K can be separated non-trivially into two closed sets ")#mi("K = K_1 \\cup K_2")#text(". Since compact Hausdorff spaces are ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal")]#text(", we can write ")#mi("K_1 = K \\cap U_1")#text(" and ")#mi("K_2 = K \\cap U_2")#text(" for some disjoint open ")#mi("U_1, U_2")#text(". Since the intersection of all the clopen sets containing x with the closed set ")#mi("(U_1 \\cup U_2)^c")#text(" is empty, we see from the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" that there must be a finite intersection K’ of clopen sets containing x that is contained inside ")#mi("U_1 \\cup U_2")#text(". In particular, ")#mi("{}K^{\\prime} \\cap U_1")#text(" and ")#mi("K^{\\prime} \\cap U_2")#text(" are clopen and do not contain K. But this contradicts the definition of K (since x is contained in one of ")#mi("{}K^{\\prime} \\cap U_1")#text(" and ")#mi("K^{\\prime} \\cap U_2")#text("). Thus K = {x}.")

#text("Another application of the finite intersection property then reveals that every open neighbourhood of x contains at least one clopen set containing x, and so the clopen sets form a base as required. ")#mi("\\Box")

#strong[#text("Exercise 1. ")]#text(" Show that two Stone spaces have isomorphic clopen algebras if and only if they are homeomorphic. ")#mi("\\diamond")

#text("Now we turn to the representation theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Stone representation theorem) Every abstract Boolean algebra ")#mi("{\\mathcal B}")#text(" is equivalent to the clopen algebra ")#mi("Cl(X)")#text(" of a Stone space X.")
]

#strong[#text("Proof. ")]#text(" We will need the binary abstract Boolean algebra ")#mi("\\{0,1\\}")#text(", with the usual Boolean logic operations. We define ")#mi("X := \\text{Hom}({\\mathcal B}, \\{0,1\\})")#text(" be the space of all morphisms from ")#mi("{\\mathcal B}")#text(" to \\{0,1\\}. Observe that each point ")#mi("x \\in X")#text(" can be viewed as a finitely additive measure ")#mi("\\mu_x: {\\mathcal B} \\to \\{0,1\\}")#text(" that takes values in ")#mi("\\{0,1\\}")#text(". In particular, this makes X a closed subset of ")#mi("\\{0,1\\}^{\\mathcal B}")#text(" (endowed with the product topology). The space ")#mi("\\{0,1\\}^{\\mathcal B}")#text(" is Hausdorff, totally disconnected, and (by ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(") compact, and so X is also; in other words, X is a Stone space. Every ")#mi("B \\in {\\mathcal B}")#text(" induces a cylinder set ")#mi("C_B \\subset \\{0,1\\}^{\\mathcal B}")#text(", consisting of all maps ")#mi("\\mu: {\\mathcal B} \\to \\{0,1\\}")#text(" that map B to 1. If we define ")#mi("\\phi(B) := C_B \\cap X")#text(", it is not hard to see that ")#mi("\\phi")#text(" is a morphism from ")#mi("{\\mathcal B}")#text(" to ")#mi("Cl(X)")#text(". Since the cylinder sets are clopen and generate the topology of ")#mi("\\{0,1\\}^{\\mathcal B}")#text(", we see that ")#mi("\\phi({\\mathcal B})")#text(" of clopen sets generates the topology of X. Using compactness, we then conclude that every clopen set is the finite union of finite intersections of elements of ")#mi("\\phi({\\mathcal B})")#text("; since ")#mi("\\phi({\\mathcal B})")#text(" is an algebra, we thus see that ")#mi("\\phi")#text(" is surjective.")

#text("The only remaining thing to check is that ")#mi("\\phi")#text(" is injective. It is sufficient to show that ")#mi("\\phi(A)")#text(" is non-empty whenever ")#mi("A \\in {\\mathcal B}")#text(" is not equal to ")#mi("\\emptyset")#text(". But by ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(", we can place A inside a maximal proper ")#link("http://en.wikipedia.org/wiki/Filter_(mathematics)")[#text("filter")]#text(" (i.e. an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(") p. The indictator ")#mi("1_p: {\\mathcal B} \\to \\{0,1\\}")#text(" of p can then be verified to be an element of ")#mi("\\phi(A)")#text(", and the claim follows. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" If ")#mi("{\\mathcal B} = 2^Y")#text(" is the power set of some set Y, then the Stone space given by Theorem 1 is the ")#link("http://en.wikipedia.org/wiki/Stone-cech_compactification")[#text("Stone-Čech compactification")]#text(" of Y (which we give the discrete topology). ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Lemma 1 and Theorem 1 can be interpreted as giving a ")#link("http://en.wikipedia.org/wiki/Duality_of_categories")[#text("duality")]#text(" between the category of Boolean algebras and the category of Stone spaces, with the duality maps being ")#mi("{\\mathcal B} \\mapsto \\text{Hom}({\\mathcal B},\\{0,1\\})")#text(" and ")#mi("X \\mapsto Cl(X)")#text(". (The duality maps are (contravariant) ")#link("http://en.wikipedia.org/wiki/Functor")[#text("functors")]#text(" which are inverses up to ")#link("http://en.wikipedia.org/wiki/Natural_transformation")[#text("natural transformations")]#text(".) It is the model example of the more general ")#link("http://en.wikipedia.org/wiki/Stone_duality")[#text("Stone duality")]#text(" between certain partially ordered sets and certain topological spaces. The idea of dualising a space X by considering the space of its morphisms to a fundamental space (in this case, ")#mi("\\{0,1\\}")#text(") is a common one in mathematics; for instance, ")#link("http://en.wikipedia.org/wiki/Pontryagin_duality")[#text("Pontryagin duality")]#text(" in the context of Fourier analysis on locally compact abelian groups provides another example (with the fundamental space in this case being the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text("). Other examples include the ")#link("http://en.wikipedia.org/wiki/Gelfand_representation")[#text("Gelfand representation")]#text(" in ")#mi("C^*")#text(" algebras (here the fundamental space is the complex numbers ")#mi("{\\Bbb C}")#text(") and the ideal-variety correspondence that provides the duality between ")#link("http://en.wikipedia.org/wiki/Algebraic_geometry")[#text("algebraic geometry")]#text(" and ")#link("http://en.wikipedia.org/wiki/Commutative_algebra")[#text("commutative algebra")]#text(" (here the fundamental space is the base field ")#mi("k")#text("). In fact there are various connections between all of the dualities mentioned above. ")#mi("\\diamond")

#strong[#text("Exercise 2. ")]#text("Show that any finite Boolean algebra is isomorphic to the power set of a finite set. (This is a special case of ")#link("http://en.wikipedia.org/wiki/Birkhoff%27s_representation_theorem")[#text("Birkhoff’s representation theorem")]#text(".) ")#mi("\\diamond")

#heading(level: 1)[#text("— The Loomis-Sikorski representation theorem —")]

#text("Now we turn to abstract ")#mi("\\sigma")#text("-algebras. We can of course adapt Definition 1 to define the notion of a morphism or isomorphism between abstract ")#mi("\\sigma")#text("-algebras, and to define when two abstract ")#mi("\\sigma")#text("-algebras are isomorphic. Another important notion for us will be that of a quotient ")#mi("\\sigma")#text("-algebra.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3.")]#text(" (Quotient ")#mi("\\sigma")#text("-algebras) Let ")#mi("{\\mathcal B}")#text(" be an abstract ")#mi("\\sigma")#text("-algebra. A ")#emph[#mi("\\sigma")#text("-ideal")]#text(" in ")#mi("{\\mathcal B}")#text(" is a \\subset ")#mi("{\\mathcal N}")#text(" of ")#mi("{\\mathcal B}")#text(" which contains ")#mi("\\emptyset")#text(", is closed under countable unions, and is downwardly closed (thus if ")#mi("N \\in {\\mathcal N}")#text(" and ")#mi("A \\in {\\mathcal B}")#text(" is such that ")#mi("A \\subset N")#text(", then ")#mi("A \\in {\\mathcal N}")#text("). If ")#mi("{\\mathcal N}")#text(" is a ")#mi("\\sigma")#text("-ideal, then we say that two elements of ")#mi("{\\mathcal B}")#text(" are equivalent modulo ")#mi("{\\mathcal N}")#text(" if their symmetric difference lies in ")#mi("{\\mathcal N}")#text(". The quotient of ")#mi("{\\mathcal B}")#text(" by this equivalence relation is denoted ")#mi("{\\mathcal B}/{\\mathcal N}")#text(", and can be given the structure of an abstract ")#mi("\\sigma")#text("-algebra in a straightforward manner.")
]

#strong[#text("Example 1.")]#text(" If ")#mi("(X, {\\mathcal B}, \\mu)")#text(" is a measure space, then the collection ")#mi("{\\mathcal N}")#text(" of sets of measure zero is a ")#mi("\\sigma")#text("-ideal, so that we can form the abstract ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}/{\\mathcal N}")#text(". This freedom to quotient out the null sets is only available in the abstract setting, not the concrete one, and is perhaps the primary motivation for introducing abstract ")#mi("\\sigma")#text("-algebras into measure theory in the first place. ")#mi("\\diamond")

#text("One might hope that there is an analogue of Stone’s representation theorem holds for ")#mi("\\sigma")#text("-algebras. Unfortunately, this is not the case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("{\\mathcal B}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Borel_algebra")[#text("Borel")]#text(" ")#mi("\\sigma")#text("-algebra on [0,1], and let ")#mi("{\\mathcal N}")#text(" be the ")#mi("\\sigma")#text("-ideal consisting of those sets with Lebesgue measure zero. Then the abstract ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}/{\\mathcal N}")#text(" is not isomorphic to a concrete ")#mi("\\sigma")#text("-algebra.")
]

#strong[#text("Proof. ")]#text(" Suppose for contradiction that we had an isomorphism ")#mi("\\phi: {\\mathcal B}/{\\mathcal N} \\to {\\mathcal A}")#text(" to some concrete ")#mi("\\sigma")#text("-algebra ")#mi("(X,{\\mathcal A})")#text("; this induces a map ")#mi("\\phi: {\\mathcal B} \\to {\\mathcal A}")#text(" which sends null sets to the empty set. Let x be a point in X. (It is clear that X must be non-empty.) Observe that any Borel set E in [0,1] can be partitioned into two Borel subsets whose Lebesgue measure is exactly half that of E. As a consequence, we see that if there exists a Borel set B such that ")#mi("\\phi(B)")#text(" contains x, then there exists another Borel set B’ of half the measure with ")#mi("\\phi(B^{\\prime})")#text(" contains x. Iterating this (starting with [0,1]) we see that there exist Borel sets B of arbitrarily small measure with ")#mi("\\phi(B)")#text(" containing x. Taking countable intersections, we conclude that there exists a null set N whose image ")#mi("\\phi(N)")#text(" contains x; but ")#mi("\\phi(N)")#text(" is empty, a contradiction. ")#mi("\\Box")

#text("However, it turns out that quotienting out by ideals is the ")#emph[#text("only")]#text(" obstruction to having a Stone-type representation theorem. Namely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (")#link("http://www.ams.org/mathscinet-getitem?%3C/p%3E%0A%3Cp%3Emr=21084")[#text("Loomis")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=126393")[#text("Sikorski")]#text(" representation theorem) Let ")#mi("{\\mathcal B}")#text(" be an abstract ")#mi("\\sigma")#text("-algebra. Then there exists a concrete ")#mi("\\sigma")#text("-algebra ")#mi("(X,{\\mathcal A})")#text(" and a ")#mi("\\sigma")#text("-ideal ")#mi("{\\mathcal N}")#text(" of ")#mi("{\\mathcal A}")#text(" such that ")#mi("{\\mathcal B}")#text(" is isomorphic to ")#mi("{\\mathcal A}/{\\mathcal N}")#text(".")
]

#strong[#text("Proof.")]#text(" We use the argument ")#link("http://www.ams.org/mathscinet-getitem?mr=21084")[#text("of Loomis")]#text(". Applying Stone’s representation theorem, we can find a Stone space X such that there is a ")#emph[#text("Boolean algebra")]#text(" isomorphism ")#mi("\\phi: {\\mathcal B} \\to Cl(X)")#text(" from ")#mi("{\\mathcal B}")#text(" (viewed now only as a Boolean algebra rather than a ")#mi("\\sigma")#text("-algebra to the clopen algebra of X. Let ")#mi("{\\mathcal A}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Baire_set")[#text("Baire")]#text(" ")#mi("\\sigma")#text("-algebra of X, i.e. the ")#mi("\\sigma")#text("-algebra generated by ")#mi("Cl(X)")#text(". The map ")#mi("\\phi")#text(" need not be a ")#mi("\\sigma")#text("-algebra isomorphism, being merely a Boolean algebra isomorphism one instead; it preserves finite unions and intersections, but need not preserve countable ones. In particular, if ")#mi("B_1, B_2, \\ldots \\in {\\mathcal B}")#text(" are such that ")#mi("\\bigcap_{n=1}^\\infty B_n = \\emptyset")#text(", then ")#mi("{}\\bigcap_{n=1}^\\infty \\phi(B_n) \\in {\\mathcal A}")#text(" need not be empty.")

#text("Let us call sets ")#mi("\\bigcap_{n=1}^\\infty \\phi(B_n)")#text(" of this form ")#emph[#text("basic null sets")]#text(", and let ")#mi("{\\mathcal N}")#text(" be the collection of sets in ")#mi("{\\mathcal A}")#text(" which can be covered by at most countably many basic null sets.")

#text("It is not hard to see that ")#mi("{\\mathcal N}")#text(" is a ")#mi("\\sigma")#text("-ideal in ")#mi("{\\mathcal A}")#text(". The map ")#mi("\\phi")#text(" then descends to a map ")#mi("\\phi: {\\mathcal B} \\to {\\mathcal A}/{\\mathcal N}")#text(". It is not hard to see that ")#mi("\\phi")#text(" is a Boolean algebra morphism. Also, if ")#mi("B_1,B_2,\\ldots \\in {\\mathcal B}")#text(" are such that ")#mi("\\bigcap_{n=1}^\\infty B_n=\\emptyset")#text(", then from construction we have ")#mi("\\bigcap_{n=1}^\\infty \\phi(B_n) = \\emptyset")#text(". From these two facts one can easily show that ")#mi("\\phi")#text(" is in fact a ")#mi("\\sigma")#text("-algebra morphism. Since ")#mi("\\phi({\\mathcal B}) = Cl(X)")#text(" generates ")#mi("{\\mathcal A}")#text(", ")#mi("\\phi({\\mathcal B})")#text(" must generate ")#mi("{\\mathcal A}/{\\mathcal N}")#text(", and so ")#mi("\\phi")#text(" is surjective.")

#text("The only remaining task is to show that ")#mi("\\phi")#text(" is injective. As before, it suffices to show that ")#mi("\\phi(A) \\neq \\emptyset")#text(" when ")#mi("A \\neq \\emptyset")#text(". Suppose for contradiction that ")#mi("A \\neq \\emptyset")#text(" and ")#mi("\\phi(A) = \\emptyset")#text("; then ")#mi("\\phi(A)")#text(" can be covered by a countable family ")#mi("\\bigcap_{n=1}^\\infty \\phi(A_n^{(i)})")#text(" of basic null sets, where ")#mi("\\bigcap_{n=1}^\\infty A_n^{(i)} = \\emptyset")#text(" for each i. Since ")#mi("A \\neq \\emptyset")#text(" and ")#mi("\\bigcap_{n=1}^\\infty A_n^{(1)} = \\emptyset")#text(", we can find ")#mi("n_1")#text(" such that ")#mi("A \\backslash A_{n_1}^{(1)} \\neq \\emptyset")#text(" (where of course ")#mi("A \\backslash B := A \\cap B^c")#text("). Iterating this, we can find ")#mi("n_2, n_3, n_4,\\ldots")#text(" such that ")#mi("A \\backslash (A_{n_1}^{(1)} \\cup \\ldots \\cup A_{n_k}^{(k)}) \\neq \\emptyset")#text(" for all k. Since ")#mi("\\phi")#text(" is a Boolean space isomorphism, we conclude that ")#mi("\\phi(A)")#text(" is not covered by any finite subcollection of the ")#mi("\\phi( A_{n_1}^{(1)} ), \\phi( A_{n_2}^{(2)} ), \\ldots")#text(". But all of these sets are clopen, so by compactness, ")#mi("\\phi(A)")#text(" is not covered by the entire collection ")#mi("\\phi( A_{n_1}^{(1)} ), \\phi( A_{n_2}^{(2)} ), \\ldots")#text(". But this contradicts the fact that ")#mi("\\phi(A)")#text(" is covered by the ")#mi("\\bigcap_{n=1}^\\infty \\phi(A_n^{(i)})")#text(". ")#mi("\\Box")

#strong[#text("Remark 3.")]#text(" The Stone representation theorem relies in an essential way on the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(" (or at least the ")#link("http://en.wikipedia.org/wiki/Boolean_prime_ideal_theorem")[#text("boolean prime ideal theorem")]#text(", which is slightly weaker than this axiom). However, it is possible to prove the Loomis-Sikorski representation theorem without choice; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2443213")[#text("this paper")]#text(". ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" The construction of ")#mi("X, {\\mathcal A}, {\\mathcal N}")#text(" in the above proof was ")#link("http://en.wikipedia.org/wiki/Canonical")[#text("canonical")]#text(", but it is not unique (in contrast to the situation with the Stone representation theorem, where Lemma 1 provides uniqueness up to homeomorphisms). ")#text(" In particular it does not seem to provide a duality similar to Stone duality.")#text(" [")#emph[#text("Removed")]#text(", Jan 13, in view of comments: the functoriality of the construction can be used to provide a Stone-type duality.] ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" The proof above actually gives a little bit more structure on ")#mi("X, {\\mathcal A}")#text(", namely it gives X the structure of a Stone space, with ")#mi("{\\mathcal A}")#text(" being its Baire ")#mi("\\sigma")#text("-algebra. [")#emph[#text("Added")]#text(", Jan 13: Furthermore, the ideal ")#mi("{\\mathcal N}")#text(" constructed in the proof is in fact the ideal of ")#link("http://en.wikipedia.org/wiki/Meagre_set")[#text("meager")]#text(" Baire sets; see comments.] ")#mi("\\diamond")

#text("A (concrete) ")#link("http://en.wikipedia.org/wiki/Measure_space")[#emph[#text("measure space")]]#text(" ")#mi("(X,{\\mathcal B},\\mu)")#text(" is a concrete ")#mi("\\sigma")#text("-algebra ")#mi("(X,{\\mathcal B})")#text(" together with a countably additive measure ")#mi("\\mu: {\\mathcal B} \\to [0,+\\infty]")#text(". One can similarly define an ")#emph[#text("abstract measure space")]#text(" ")#mi("({\\mathcal B},\\mu)")#text(" (or ")#emph[#text("measure algebra")]#text(") to be an abstract ")#mi("\\sigma")#text("-algebra ")#mi("{\\mathcal B}")#text(" with a countably additive measure ")#mi("mu: {\\mathcal B} \\to [0,+\\infty]")#text(". (Note that one does not need the concrete space ")#mi("X")#text(" in order to define the notion of a countably additive measure.)")

#text("One can obtain an abstract measure space from a concrete one by deleting X and then quotienting out by some ")#mi("\\sigma")#text("-ideal of null sets – sets of measure zero with respect to ")#mi("mu")#text(". (For instance, one could quotient out the space of all null sets, which is automatically a ")#mi("\\sigma")#text("-ideal.) Thanks to the Loomis-Sikorski representation theorem, we have a converse:")

#strong[#text("Exercise 3. ")]#text(" Show that every abstract measure space is isomorphic to a concrete measure space after quotieting out by a ")#mi("\\sigma")#text("-ideal of null sets (where the notion of morphism, isomorphism, etc. on abstract measure spaces is defined in the obvious manner.) ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 13: some corrections, and formatting fixes.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e385888ffc4c449cdf66b9af6ce912b79b809706b1208d04cecca14fc2ab2bb-ee96d14b858892f75fb2880e016d77caa816fdaed789764344676b55027f3fda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of moonseagull")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34892")[#strong[#text("moonseagull")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("Hello everybody! I would like to ask someone a surely naive question, which bothers me at the moment. The question might not be absolutely off topic, so I have decided to write it here.")

#text("By the Tychonoffs’ theorem we know, that cube ")#mi("X:= \\{0,1\\}^\\omega")#text(" with product topology of discrete topology of ")#mi("\\{0,1\\}")#text(" is compact. As far as I know, product topology is defined as topology generated by the sets ")#mi("\\mathrm{pr}_i(G)")#text(", where ")#mi("\\mathrm{pr}_i")#text(" is i-th projection and G is open set in ")#mi("\\{0,1\\}")#text(". Let’s call the set ")#mi("\\mathrm{pr}_i(\\{1\\})")#text(" as ")#mi("f_i")#text(" and ")#mi("X-f_i")#text(" as ")#mi("f_i^c")#text(". Now suppose the open set ")#mi("G:=\\bigcup_{i\\in\\omega}f_i=X-\\bigcap_{i\\in \\omega}f_i^c")#text(". Sets ")#mi("\\{f_i\\}")#text(" form and open cover of ")#mi("G")#text(" so there should be a finite subcover (from compactness), what would imply for instance, that set ")#mi("\\bigcap_{i\\in \\omega}f_i^c=\\{0\\}")#text(", where ")#mi("{}0")#text(" means indentically zero function, would lie in boolean algebra generated by sets ")#mi("f_i")#text(", what is clearly not true. I know that in some part of my thinking a must have been terribly wrong, but I can’t find where.")

#text("Dear prof. Tao, excuse me in case I spam your blog..")#linebreak()#text(" Thanks anyone for an answer!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/747a2edb4cc3a28c1d2d8769e66d53e49e2a0bb053c20117800027a2d9a753f7-184c57599cc618ad6474b3aece9d3de4470d92828182359cbe1b2c86db699c6f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Nyberg")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34900")[#strong[#text("Thomas Nyberg")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("moonseagull,")

#text("If I understand you correctly, then f_i is the set of all sequences with 1 in the ith component. In that case, the union of all f_i is not the entire space, since the 0 sequence is not in any of those f_i. So it’s not actually a cover. This would then imply that X – Uf_i is the 0 function (which is what you want).")

#text("Thomas")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7e385888ffc4c449cdf66b9af6ce912b79b809706b1208d04cecca14fc2ab2bb-ee96d14b858892f75fb2880e016d77caa816fdaed789764344676b55027f3fda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of moonseagull")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34917")[#strong[#text("moonseagull")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("Oh yes, thank you Thomas, of course, set Uf_i is not closed, i.e not compact, so we can not find finite subcover of that cover. Oh, I feel embarased, but again thank you for finding my mistake.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34936")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("With a little work, it can be shown that N is in fact the ")#mi("\\sigma")#text("-ideal of meager Borel sets. The only difficult step is to show that every closed Borel set S with empty interior is in N, i.e. is a countable intersection of clopen sets. To see this, note that S is generated by a countable subalgebra of B which corresponds to a continuous map f from X to the Cantor set K (since K is dual to the free Boolean algebra on countably many generators). Then f(S) is closed in K and is hence a countable intersection of clopen sets in K, which pull back to countably many clopen sets on X whose intersection is ")#mi("f^{-1}(f(S))")#text(". But the fact that S is generated by the subalgebra defining f can easily be seen to imply that ")#mi("f^{-1}(f(S))=S")#text(".")

#text("Using this we can easily make Theorem 2 functorial. Let A and B be ")#mi("\\sigma")#text("-algebras with Stone spaces X and Y. A map ")#mi("Y \\to X")#text(" induces a ")#mi("\\sigma")#text("-homomorphism ")#mi("Bor(X) \\to Bor(Y)")#text(", and if the inverse image of a Borel meager set is meager then it induces a ")#mi("\\sigma")#text("-homomorphism ")#mi("A \\to B")#text(". Conversely a ")#mi("\\sigma")#text("-homomorphism ")#mi("A \\to B")#text(" induces a map ")#mi("Y \\to X")#text(" under which the inverse image of a Borel meager set is meager (using the fact above that Borel meager sets are generated by countable intersections of clopen sets). The correspondence is bijective since it is just a restriction of the correspondence for ordinary Boolean algebras. This gives a duality between the category of ")#mi("\\sigma")#text("-algebras and ")#mi("\\sigma")#text("-homomorphisms and the category of “")#mi("\\sigma")#text("-Stone spaces” and continuous maps such that the inverse image of a Borel meager set is meager. In fact, “")#mi("\\sigma")#text("-Stone spaces” can be abstractly characterized as Stone spaces such that the closure of a countable union of clopen sets is clopen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/571ff60b3ac9b606b172e22a485a6f57457348c0bd2b2c28653b2d582bb0d5ed-b02d7dc9b5536deb39d3d136c7789352a7a8f5e58f09bdf588f8a82d19927bf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Leinster")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34937")[#strong[#text("Tom Leinster")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Terry: you wrote ‘So, up to isomorphism, there is really no difference between a concrete Boolean algebra and an abstract one.’ How would you define ‘isomorphism’ of concrete Boolean algebras in order to make that true?")

#text("(My point is that two concrete Boolean algebras might look rather different, but in fact be isomorphic as abstract Boolean algebras. I don’t know of any condition on a pair of concrete BAs that’s equivalent to their corresponding abstract BAs being isomorphic, apart from the tautologous one.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34938")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Oops, a correction to both the original post and my comment above: we must work with Baire sets instead of Borel sets (the Baire ")#mi("\\sigma")#text("-algebra being the ")#mi("\\sigma")#text("-algebra generated by the clopen sets, or in more general settings by the closed ")#mi("G_\\delta")#text("‘s). It is not true in general that the clopen sets generate all Borel sets, since not every open set is a countable union of clopen sets. In fact, using Borel sets instead of Baire sets gives the completion of the Boolean algebra in question. The ")#mi("\\sigma")#text("-algebra of a ")#mi("\\sigma")#text("-finite measure modulo null sets is always complete, so in that case you can use Borel sets instead of Baire sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/626e53d46c710500df401cd08527c0d77bc41c025132055eb6b1eff8f8e41115-d87af44ed68cc76739d63ca4c13478d58612e8f3dab93013de42dffa7899abb4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34939")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Tom: Let ")#mi("A\\subseteq P(X)")#text(" and ")#mi("B\\subseteq P(Y)")#text(" be concrete Boolean algebras. Then every abstract homomorphism ")#mi("A \\to B")#text(" extends to a homomorphism ")#mi("P(X) \\to P(Y)")#text(". This is because the Boolean algebra $P(Y)$ is injective in the categorical sense (in fact, a Boolean algebra is injective iff it is complete). Thus if we define a category of “concrete Boolean algebras” whose morphisms are homomorphisms ")#mi("P(X) \\to P(Y)")#text(" that map A to B, identifying homomorphisms that agree on A, we get a category equivalent to abstract Boolean algebras. However, it is not true that homomorphisms ")#mi("P(X) \\to P(Y)")#text(" correspond to maps ")#mi("Y \\to X")#text(" (this is only true for complete homomorphisms), so this is not entirely satisfying.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Dear Eric: thanks for the comments and corrections!")

#text("Dear Tom: I had intended isomorphism in that sentence to mean “abstract isomorphism”; I’ve adjusted the sentence accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-34944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Terry, I wonder if you’re going to discuss Wiener measure or anything like that in this course. I’ve been wanting for a while to understand it. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35261")[#strong[#text("245B, Notes 6: Duality and the Hahn-Banach theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2009")])]

#text("[…] looks quite different from the original object X. (For instance, in Stone duality, discussed in Notes 4, X would be a Boolean algebra (or some other partially ordered set) and would be a compact totally […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2009")])]

#text("Hi all,")#linebreak()#text(" I was wondering if the space obtained from the Loomis-Sikorski theorem was the smallest one can get. In other words, suppose we have an abstract ")#mi("\\sigma")#text("-algebra ")#mi("\\mathcal{B}")#text(", and a measurable space ")#mi("(X,\\Sigma)")#text(" with ")#mi("\\Sigma / \\mathcal{N}")#text(" isomorphic to ")#mi("\\mathcal{B}")#text(" for some ideal ")#mi("\\mathcal{N}")#text(", there is a measurable map from ")#mi("(X,\\Sigma)")#text(" to the space obtained from the Loomis-Sikorski theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 8: A quick review of point set topology « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35348")[#strong[#text("254B, Notes 8: A quick review of point set topology « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2009")])]

#text("[…] spaces, in which the collection of open sets has become an abstract lattice, in the spirit of Notes 4, but we will not need such notions in this course.] Definition 4. (Topological space) A […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35587")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Dear friends,")

#text("I have some problems in the proof of Lemma 1 because I never studied topology before but check the definitions in wiki to understand the proof. My problem is the following argument in the proof :")

#text("‘In particular, ")#mi("K^{^{\\prime}} \\cap U_1")#text(" and ")#mi("K^{^{\\prime}} \\cap U_2")#text(" are clopen and do not contain K. ‘")

#text("I can not understand why ‘ ")#mi("K^{^{\\prime}} \\cap U_1")#text(" and ")#mi("K^{^{\\prime}} \\cap U_2")#text(" do not contain K ‘ since K is the subset of ")#mi("K^{^{\\prime}} \\cap U_1")#text(" and ")#mi("K^{^{\\prime}} \\cap U_2")#text(".")

#text("My question is most probably trivial.")

#text("Thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35588")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Dear PDEbeginner,")

#mi("K^{\\prime} \\cap U_1")#text(" is disjoint from ")#mi("K_2")#text(" and thus does not contain K. Similarly, ")#mi("K^{\\prime} \\cap U_2")#text(" does not contain K. Of course, the union of ")#mi("K^{\\prime} \\cap U_1")#text(" and ")#mi("K^{\\prime} \\cap U_2")#text(" contains K, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-35897")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第四节讲了一个表示定理，用以说明为什么可以只研究具体的西格玛代数。这一节还是比较抽象的，表示定理的建立一般都是为了看清楚结构，分类，从而把问题简化。这一节也不例外。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 13: Compactification and metrisation (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-36955")[#strong[#text("245B, Notes 13: Compactification and metrisation (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2009")])]

#text("[…] be the Boolean algebra of all subsets of . By Stone’s representation theorem (Theorem 1 from Notes 1), is isomorphic to the clopen algebra of a Stone space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21a50a423238597881dc880f949e4e6797107d172f390696cec645e641f0e79d-b4ebe7029f215f840c7abd9c55436b2d47663cc117d90fe79a1ecd36d65fe649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shraddha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-41304")[#strong[#text("shraddha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2009")])]

#text("Dear friends,")

#text("I want the proof of the Lommis-Sikorski Theorem for Boolean σ-algebras i.e, “Every Boolean σ-algebra is a σ-homomorphic image of σ- algebra of subsets.” This proof is given in the book “Boolean algebras by Roman- Sikorski (1964)”.Kindly provide me the proof of afore mentioned paper.")

#text("Thanks in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-45691")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] (or equivalently, the idempotents of ). The fundamental connection between the two is given by the Stone representation theorem or the (commutative) Gelfand-Naimark […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-47248")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] operations of intersection and union . We will not take this abstract perspective here, but see this blog post of mine for some further discussion of the relationship between concrete and abstract Boolean algebras, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-48230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("Dear Prof. Tao,")

#text("I am confused by the sentence “We can then define an abstract Boolean algebra ")#mi("\\mathcal{B}=(\\mathcal{B}, \\emptyset, \\cdot^c, \\cup, \\cap, \\subset)")#text(" What do you mean by using the notation ")#mi("\\mathcal{B}")#text(" twice?")

#text("As you said, “some of these operations are redundant; for instance, intersection can be defined in terms of complement and union by de Morgan’s laws”. Is it possible to get some “minimal” set from the basic set operations such that the other operations can be represented by those in the “minimal” set? (")#mi("\\cup, \\cap, \\cdot^c, \\bigtriangleup")#text(") One possibility seems to be ")#mi("\\cup, \\cdot^c")#text(". But how can we know that it is the smallest set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-48246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2010")])]

#text("When dealing with a space that consists of a set with additional structures on top of it, it is customary to “abuse notation” and use the set as a ")#link("http://en.wikipedia.org/wiki/Synecdoche")[#text("synecdoche")]#text(" for the entire space. For instance, when we say “Let ")#mi("G")#text(" be a group”, we really mean “Let ")#mi("(G, \\text{id}, \\cdot, ()^{-1})")#text(" be a group”. One way to signal this convention is to explicitly identify the set with the structure, e.g. “Let ")#mi("G = (G, \\text{id}, \\cdot, ()^{-1})")#text(" be a group.”")

#text("For your second question, it is possible to use the rather strange Boolean operation ")#mi("(X, Y) \\mapsto X^c \\cup Y^c")#text(" (which, as far as I know, does not have a standardised name) to generate all the other operations (this is an amusing little exercise). In principle, one could then axiomatise Boolean algebras solely in terms of this one operation, but this leads to some rather strange-looking axioms and it is not clear that there is any particular advantage gained by such an extreme minimalist approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-48248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2010")])]

#text("Thank you for your nice answers. You remind me of another kind of “abuse notation” in mathematics about which you talked on Google buzz. ")#link("http://www.google.com/buzz/114134834346472219368/hTVJiP5LoPb/Bill-Thurstons-On-proof-and-progress-in")[#text("http://www.google.com/buzz/114134834346472219368/hTVJiP5LoPb/Bill-Thurstons-On-proof-and-progress-in")]#linebreak()#text(" and your post about the concept “group”.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/10/19/grothendiecks-definition-of-a-group/")[#text("Grothendieck’s definition of a group")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea22ab3f8f9e9b71f0a20804321bb9948877bbfb308f66aa6cdbcf48eae70242-217751008671f913a93737c8a0a592ee8ace94c6ad821be55577eca9586f68ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Eagle")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-48252")[#strong[#text("Chris Eagle")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("It’s called the ")#link("http://en.wikipedia.org/wiki/Sheffer_stroke")[#text("Sheffer stroke")]#text(" or NAND, and written | or ↑. ")#emph[#text("[Ah, had forgotten that that was the term. Thanks! T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-48263")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2010")])]

#text("Is the second question related to the functional completeness of the set of Boolean operators? And thus it is equivalent to “find the functionally complete subset of ")#mi("{\\cap,\\cup,\\setminus,\\bigtriangleup,\\cdot^c}")#text("“?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/436c418cbba6e8fe247d161dfaef5879dd0f8a8172cf32dabce33a7b0be8a34f-c2e4a945c6b719ced6e90ff2da5d3e0a96d9b26391d574c5ffceea8d7cbf21ca.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Shved")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-230278")[#strong[#text("Dan Shved")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2013")])]

#text("Looks like the link to Birkhoff’s representation theorem in Exercise 2 is broken.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic probability spaces | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-381792")[#strong[#text("Algebraic probability spaces | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("[…] (discussed in this previous post) combined with the Loomis-Sikorski theorem (discussed in this previous post). However, I wanted to put the construction in a single location for sake of reference. I also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-460779")[#strong[#text("Lebesgue probability spaces, part I | Vaughn Climenhaga's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2015")]

#text("[…] the form of this list I have followed this blog post by Terry Tao, which gives a good in-depth discussion of some other issues relating to concrete and abstract […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-467822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#emph[#text("A (concrete) Boolean algebra is a pair ")#mi("(X, {\\mathcal B})")#text(", where ")#mi("X")#text(" is a ")#strong[#text("set")]#text(", and ")#mi("{\\mathcal B}")#text(" is a collection of subsets of ")#mi("X")#text(" which…")]

#text("We can then define an abstract Boolean algebra ")#mi("{\\mathcal B} = ({\\mathcal B}")#text(", ")#mi("\\emptyset")#text(", ")#mi("\\cdot^c")#text(", ")#mi("\\cup")#text(", ")#mi("\\cap")#text(", ")#mi("\\subset")#text(") to be an ")#strong[#text("abstract set")]#text(" ")#mi("{\\mathcal B}")#text(" with the specified objects, operations, and relations that obey the axioms 1-4.")

#text("Would you elaborate the difference between “set” and “abstract set”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-467825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2016")])]

#text("The modifier abstract is there mostly for emphasis, to stress that the elements of the set need not belong to any existing “concrete” space. In the concrete setting, the elements of ")#mi("{\\mathcal B}")#text(" are subsets of the set ")#mi("X")#text(", but in the abstract setting ")#mi("{\\mathcal B}")#text(" can be an arbitrary set; for instance one could make ")#mi("{\\mathcal B} = \\{ a, b \\}")#text(" an abstract ")#mi("\\sigma")#text("-algebra for any distinct objects ")#mi("a,b")#text(" by (for instance) setting ")#mi("a")#text(" to be the ")#mi("\\emptyset")#text(" element and defining the operations ")#mi("\\cdot^c, \\cup, \\cap, \\subset")#text(" appropriately.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-467834")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2016")])]

#text("Doesn’t Stone’s theorem link computer science and real analysis? I could build a circuit this way")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi A. Bajaj")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-472820")[#strong[#text("Ravi A. Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2016")])]

#text("For the second equation of the distributive law, if we take B=C disjoint from A, the LHS is empty and the RHS is the union of A, B, and C. I’m not familiar with distributive lattices, so I’m not sure if it is a typo, but there is some correction needed.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-593495")[#strong[#text("Foundational aspects of uncountable measure theory: Gelfand duality, Riesz representation, canonical models, and canonical disintegration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2020")])]

#text("[…] this construction is closely tied to the functoriality of the Loomis-Sikorski theorem (discussed in this previous blog post). The precise connection in terms of functors and categories is a little complicated to describe, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ada5025cd616e13b8b04da4f8bf70f0fd980b33c0b6091e86ba1e3bf503912d-713cbc90c5b884e2c79ef3693d4c078597aaa2281c37b047a524cc68da7064e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelvin Koor")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-597270")[#strong[#text("Kelvin Koor")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("Dear Prof Tao,")

#text("You wrote “…but these theorems do help explain why it is “safe” to focus attention primarily on concrete \\sigma-algebras and measure spaces when doing measure theory, since the abstract analogues of these mathematical concepts are largely equivalent to their concrete counterparts…”")

#text("But we *are* dealing with concrete sigma-algebras in measure theory, no? Why are we concerned with abstract sigma-algebras in this context then?")

#text("You then wrote “The situation is quite different for non-commutative measure theories, such as quantum probability, in which there is basically no good representation theorem available to equate the abstract with the classically concrete, but I will not discuss these theories here.”")

#text("Again, while there is no good representation theorem, why are we concerned – since we are dealing with the concrete thing?")

#text("My impression is the raison d’etre of Stone, Loomis-Sikorsky and other abstract-concrete representation theorems is to let us visualize and get a feel of the abstract algebras via their concrete counterparts. I am probably missing something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-597446")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("There are at least two reasons to consider abstract sigma-algebras. Firstly, there are natural operations on concrete sigma-algebras that produce an abstract sigma-algebra, most notably the action of quotienting out by a null ideal such as the ideal of measure zero sets, or the ideal of meager sets. If one wants to work “up to everywhere equivalence” one is implicitly asking for the natural domain of one’s analysis to become abstract rather than concrete. The other reason is that there are ways to construct abstract sigma algebras from other naturally occuring objects in mathematics. For instance, starting with a commutative von Neumann algebra, the space of its idempotents naturally has the structure of an abstract sigma-algebra. There is a representation theorem that describes commutative von Neumann algebras as the ")#mi("L^\\infty")#text(" space of a concrete measure space, but to prove this one basically has to work with the space of idempotents and apply something like the Loomis-Sikorski theorem to it. (A physical analogue of this latter construction of an abstract sigma-algebra also shows up in ")#link("https://en.wikipedia.org/wiki/Principal_homogeneous_space")[#text("Bell’s theorem")]#text(", which can be interpreted as the assertion that the abstract algebra of observables arising from quantum mechanics (which can basically be described as an abstract von Neumann algebra) *cannot* be modeled by a classical (local) probabilistic model.)")

#text("There are also some interesting operations on abstract sigma algebras, such as the categorical coproduct (or tensor product) on such spaces, which do not have an immediately obvious counterpart for concrete measurable spaces (the Loomis-Sikorski theorem does eventually produce such a relationship, but this requires some effort to establish). It is conceivable that there are some theorems about concrete measurable spaces that are best proven by working in the abstract category, similar to how some theorems about the real numbers might be easiest to prove by working in the larger domain of complex numbers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab49b43eeb0f6b6ce79c3fec5e6d1622d9ae3a4a9f057317a5d64dfd2e3d9a05-6a07e8a9eae468ecfea9d168c1a2ef544adcccbb052d4282e3494e5590d14a48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erlend")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-621846")[#strong[#text("Erlend")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("Is there a good place I can read more about taking quotients by sigma-ideals and properties measures will still have after taking a quotient? I feel like this would be a good way to make it precise that null-sets are often irrelevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-660135")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2022")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2022/11/12/245b-notes-4-the-stone-and-loomis-sikorski-representation-theorems-optional/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91a771599181e849f8595981a9bc7ba01feade6bd5c62aace83ec13ee3922e32-3dc38cf10bc5d6ca7ef57f2ec4cd5d7040a25cbab5dbfd2e7613650e0a1c2d85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Elliot Glazer")]], [#link("https://terrytao.wordpress.com/2009/01/12/245b-notes-1-the-stone-and-loomis-sikorski-representation-theorems-optional/#comment-688338")[#strong[#text("Elliot Glazer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2025")])]

#text("The Loomis-Sikorski theorem can’t be proven in ZF. Buskes et al. implicitly use countable choice several times, e.g. in the “straightforward to verify” assertion that the ideal ")#mi("\\mathcal{I}")#text(" constructed shortly after Lemma 3.1 is ")#mi("\\sigma")#text("-complete. The best choiceless analogue is that every abstract Boolean algebra B can be expressed as quotient of a concrete algebra by an ideal.")

#text("Loomis-Sikorski fails in the Feferman-Levy model, in which ")#mi("\\mathbb{R}=\\bigcup_n A_n")#text(" for countable sets ")#mi("R_n,")#text(" and for every family ")#mi("\\mathcal{F}")#text(" of nonempty sets, there is a function which chooses a countable nonempty subset of each ")#mi("S \\in \\mathcal{F}.")#text(" Consider the random algebra ")#mi("\\mathcal{B},")#text(" constructed as the quotient of ")#mi("\\mathcal{A_0}=\\{X \\subset [0,1]: \\lambda^*(X)+\\lambda^*([0,1] \\setminus X)=1\\}")#text(" by the ideal ")#mi("\\mathcal{I}_0=\\{X: \\lambda^*(X)=0\\}.")#text(" Note that ZF proves ")#mi("\\mathcal{B}")#text(" to be a ")#mi("\\sigma")#text("-algebra of cardinality ")#tao-math("\\left|\\mathbb{R}\\right|.", block: false)

#text("Suppose there is a concrete ")#mi("\\sigma")#text("-algebra ")#mi("\\mathcal{A}=(A, \\Sigma),")#text(" ")#mi("\\sigma")#text("-ideal ")#mi("\\mathcal{I},")#text(" and isomorphism ")#mi("\\phi: \\mathcal{A} / \\mathcal{I} \\rightarrow \\mathcal{B}.")#text(" Let F be a function choosing countably many representatives from each equivalence class. Define ")#mi("\\psi: \\mathcal{B} \\rightarrow \\mathcal{A}")#text(" by ")#mi("b \\mapsto \\bigcup F(\\phi^{-1}(b)).")#text(" Notice ")#mi("b = [\\psi(b)]_{\\mathcal{I}}.")

#text("Fix a bijection ")#mi("s: \\mathbb{R} \\rightarrow \\mathcal{B}^{\\mathbb{N}}")#text(" with coordinate projections ")#mi("s_k.")#text(" Then ")#mi("Z=\\psi(0) \\cup \\psi(1)^c \\cup \\bigcup_n \\bigcup_{r \\in R_n} ((\\bigcup_k \\psi(s_k(r)))^c \\triangle \\psi((\\bigvee_k s_k(r))^c)) \\in \\mathcal{I}.")

#text("We have an embedding of ")#mi("\\sigma")#text("-algebras ")#mi("\\psi^{\\prime}: \\mathcal{B} \\rightarrow \\mathcal{P}(A \\setminus Z)")#text(" by ")#mi("b \\mapsto \\psi(B) \\setminus Z.")#text(" But this leads to a contradiction by the argument of Proposition 1 in the post.")
]
