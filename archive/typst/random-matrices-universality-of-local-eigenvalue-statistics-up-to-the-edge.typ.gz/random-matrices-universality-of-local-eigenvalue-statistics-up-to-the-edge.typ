// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/
// Converted to Typst by tao2typ: "2026-10-14T07:26:11.044629+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Universality of local eigenvalue statistics up to the edge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Universality of local eigenvalue statistics up to the edge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/")[#text("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Van Vu and I have just uploaded to the ")#link("http://www.arxiv.org/")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0908.1982")[#text("Random matrices: Universality of local eigenvalue statistics up to the edge")]#text("“, submitted to ")#link("http://www.springerlink.com/content/100467/")[#text("Comm. Math. Phys.")]#text(". This is a sequel to ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("our previous paper")]#text(", in which we studied universality of local eigenvalue statistics (such as normalised eigenvalue spacings ")#mi("\\sqrt{n} ( \\lambda_{i+1}(M_n) - \\lambda_i(M_n) )")#text(") for random matrices ")#mi("M_n")#text(" of Wigner type, i.e. Hermitian (or symmetric) random matrices in which the upper-triangular entries are independent with mean zero and variance one (for technical reasons we also have to assume an exponential decay condition on the distribution of the entries). The results in the previous paper were almost entirely focused on the ")#emph[#text("bulk")]#text(" region, in which the index i of the eigenvalues involved was in the range ")#mi("\\varepsilon n \\leq i \\leq (1-\\varepsilon) n")#text(". The main purpose of this paper is to extend the main results of the previous paper all the way up to the edge, thus allowing one to control all indices ")#mi("1 \\leq i \\leq n")#text(". As an application, we obtain a variant of ")#link("http://www.ams.org/mathscinet-getitem?mr=1727234")[#text("Soshnikov’s well-known result")]#text(" that the largest eigenvalue of Wigner matrices is distributed (after suitable normalisation) according to the Tracy-Widom law when the coefficients are symmetric, by assuming instead that the coefficients have vanishing third moment.")

#text("As one transitions from the bulk to the edge, the density of the eigenvalues decreases to zero (in accordance to the ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircular law")]#text("), and so the average spacing between eigenvalues increases. (For instance, the spacing between eigenvalues in the bulk is of size ")#mi("n^{-1/2}")#text(", but at the extreme edge it increases to ")#mi("n^{-1/6}")#text(".) On the one hand, the increase in average spacing should make life easier, because one does not have to work at such a fine spatial scale in order to see the eigenvalue distribution. On the other hand, a certain key technical step in the previous paper (in which we adapted an argument of Erdos, Schlein, and Yau to show that eigenvectors of Wigner matrices were delocalised) seemed to require eigenvalue spacings to be of size ")#mi("O(n^{-1/2})")#text(", which was the main technical obstacle to extending the preceding results from the bulk to the edge.")

#text("The main new observation in the paper is that it was not the eigenvalue spacings ")#mi("\\lambda_{i+1}(M_n) - \\lambda_i(M_n)")#text(" which were of importance to eigenvalue delocalisation, but rather the somewhat smaller ")#emph[#text("interlaced ")]#text("eigenvalue spacings ")#mi("\\lambda_{i+1}(M_n) - \\lambda_i(M_{n-1})")#text(", where ")#mi("M_{n-1}")#text(" is a ")#mi("n-1 \\times n-1")#text(" minor of ")#mi("M_n")#text(". The Cauchy interlacing law asserts that the latter is smaller than the former. But the interesting thing is that at the edge (when i is close to n), the interlaced spacings are much smaller than the former, and in particular remain of size about ")#mi("O(n^{-1/2})")#text(" (up to log factors) even though the non-interlaced spacings increase to be as large as ")#mi("O(n^{-1/6})")#text(". This is ultimately due to a sort of “attractive force” on eigenvalues that draws them towards the origin, and counteracts the usual “eigenvalue repulsion effect”, that pushes eigenvalues away from each other. This induces “bias” for eigenvalues to move in towards the bulk rescues the delocalization result, and the remainder of the arguments in our previous paper then continue with few changes.")

#text("Below the fold I wish to give some heuristic justification of the interlacing bias phenomenon, sketch why this is relevant for eigenvector delocalisation, and finally to recall why eigenvalue delocalisation in turn is relevant for universality.")

#text("[")#emph[#text("Update")]#text(", Aug 16: sign error corrected.]")

#heading(level: 1)[#metadata(none) <tao-ede89a81879fd1d1c085>#text("— Interlacing bias —")]

#text("Let ")#mi("M_n")#text(" be an ")#mi("n \\times n")#text(" Hermitian matrix, and let ")#mi("M_{n-1}")#text(" be a ")#mi("n-1 \\times n-1")#text(" symmetric minor, say the upper left minor for concreteness. The ")#mi("i^{th}")#text(" largest eigenvalue ")#mi("\\lambda_i(M_n)")#text(" of ")#mi("M_n")#text(" can be given by the ")#emph[#text("minimax formula")]

#align(center)[#tao-fit-display[#tao-math("\\lambda_i(M_n) = \\sup_{V_i} \\inf_{u \\in V_i: \\left\\|u\\right\\|=1} u^* M_n u", block: true)]]

#text("where ")#mi("V_i")#text(" ranges over all ")#mi("i")#text("-dimensional subspaces of ")#mi("{\\Bbb C}^n")#text(". The formula for ")#mi("\\lambda_i(M_{n-1})")#text(" is similar, but ")#mi("V_i")#text(" is now constrained to lie in the hyperplane ")#mi("{\\Bbb C}^{n-1}")#text(" of ")#mi("{\\Bbb C}^n")#text(". Comparing the two formulae (and noting that any i+1-dimensional subspace of ")#mi("{\\Bbb C}^n")#text(" intersects ")#mi("{\\Bbb C}^{n-1}")#text(" in a space of dimension at least i) one is led to the ")#emph[#text("Cauchy interlacing inequality")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\lambda_i(M_n) \\leq \\lambda_i(M_{n-1}) \\leq \\lambda_{i+1}(M_n)")]]

#text("or equivalently")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lambda_i(M_{n-1}) \\leq \\lambda_{i+1}(M_n) \\leq \\lambda_{i+1}(M_{n-1}).")]]

#text("Thus, the ")#mi("n-1")#text(" eigenvalues of ")#mi("M_{n-1}")#text(" intersperse (or interlace) the ")#mi("n")#text(" eigenvalues of ")#mi("M_n")#text(".")

#text("One can then ask the question (for various matrix models of ")#mi("M_n")#text(") how ")#mi("\\lambda_i(M_{n-1})")#text(" is distributed in the interval ")#mi("[\\lambda_i(M_n), \\lambda_{i+1}(M_n)]")#text(", or how ")#mi("\\lambda_{i+1}(M_n)")#text(" is distributed in the interval ")#mi("[\\lambda_i(M_{n-1}), \\lambda_{i+1}(M_{n-1})]")#text(".")

#text("The answer to the first question is rather interesting: if the eigenvalues of ")#mi("M_n")#text(" are fixed, and the eigenvectors of ")#mi("M_n")#text(" are chosen uniformly at random (or equivalently, if one conjugates ")#mi("M_n")#text(" by a randomly chosen unitary matrix), then the eigenvalue ")#mi("\\lambda_i(M_{n-1})")#text(" turns out to be distributed according to a certain piecewise polynomial distribution (connected with Gelfand-Tsetlin patterns). The situation is easiest to describe when n=2, in which ")#mi("\\lambda_1(M_1)")#text(" is uniformly distributed in the interval ")#mi("[\\lambda_1(M_2), \\lambda_2(M_2)]")#text(". Amusingly, this fact is equivalent to Archimedes’ famous result (inscribed on his tombstone) on the equivalence of areas between a sphere and a cylinder, and is an instructive exercise.")

#text("However, this type of analysis does not seem to lend itself well to general matrix ensembles, which are not invariant under unitary conjugation. An alternate approach proceeds by viewing ")#mi("M_n")#text(" as the matrix ")#mi("M_{n-1}")#text(" with an ")#mi("n-1")#text("-dimensional column vector ")#mi("X")#text(" and its transpose ")#mi("X^*")#text(" attached, together with a final coordinate ")#mi("x_{nn}")#text(", like so:")

#align(center)[#tao-fit-display[#mitex("M_n = \\begin{pmatrix} M_{n-1} & X \\\\ X^* & x_{nn} \\end{pmatrix}.")]]

#text("One can compute the characteristic polynomial ")#mi("\\det(M_n - \\lambda I)")#text(" of ")#mi("M_n")#text(" in terms of ")#mi("x_{nn}, X")#text(", and the eigenvalues ")#mi("\\lambda_i(M_{n-1})")#text(" and unit eigenvectors ")#mi("u_i(M_{n-1})")#text(" of ")#mi("M_{n-1}")#text(" to be given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\prod_{j=1}^{n-1} (\\lambda_j(M_{n-1})-\\lambda) [ x_{nn}-\\lambda-\\sum_{j=1}^{n-1} \\frac{\\left|u_j(M_{n-1})^* X\\right|^2}{\\lambda_j(M_{n-1}) - \\lambda} ]", block: true)]]

#text("which implies that ")#mi("\\lambda = \\lambda_i(M_n)")#text(" is the unique solution in the interval ")#mi("[\\lambda_{i-1}(M_{n-1}), \\lambda_i(M_{n-1})]")#text(" to the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{j=1}^{n-1} \\frac{\\left|u_j(M_{n-1})^* X\\right|^2}{\\lambda - \\lambda_j(M_{n-1})} = \\lambda - x_{nn}.", block: true)]]

#text("(Note that the LHS is increasing in ")#mi("\\lambda")#text(", while the RHS is decreasing, and the LHS also has poles at each eigenvalue of ")#mi("M_{n-1}")#text("; this establishes the uniqueness and also provides an alternate proof of the Cauchy interlacing law.)")

#text("I like to interpret the equation (3) as describing the balance between various “forces” acting on the eigenvalue ")#mi("\\lambda = \\lambda_i(M_n)")#text(". All the eigenvalues ")#mi("\\lambda_j(M_{n-1})")#text(" to the left of ")#mi("\\lambda")#text(" (i.e. for ")#mi("j<i")#text(") exert a rightward force on ")#mi("\\lambda")#text(" that is inversely proportional to the distance; meanwhile, the eigenvalues on the right exert a leftward force; thus the eigenvalues of ")#mi("M_{n-1}")#text(" “repel” the eigenvalues of ")#mi("M_n")#text(" (cf. the eigenvalue repulsion discussed in ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this previous blog post")]#text("). On the other hand, the ")#mi("\\lambda")#text(" term on the right-hand side of (3) can be viewed as an attractive force towards the origin which becomes quite significant at the edge. (The ")#mi("x_{nn}")#text(" term tends to be insignificant in applications.) This attractive force (which is of magnitude about ")#mi("\\sqrt{n}")#text(" at the edge) needs to be counterbalanced by repulsion from eigenvalues nearer the bulk, and one can show (under reasonable hypotheses on the matrix ensemble) that the only way this can occur is if ")#mi("\\lambda")#text(" is within ")#mi("O(1/\\sqrt{n})")#text(" or so of an eigenvalue of ")#mi("M_{n-1}")#text(" nearer the bulk (the numerators ")#tao-math("\\left|u_j(M_{n-1})^* X\\right|^2", block: false)#text(" have size about 1 on the average, as can be formalised by Berry-Esseen-type variants of the central limit theorem). This is basically the source of the bias in the interlacing law.")

#text("(Another way to see why the interlacing gap at the edge must remain of size ")#mi("n^{-1/2}")#text(" rather than ")#mi("n^{-1/6}")#text(" is to consider the asymptotic ")#mi("\\lambda_n(M_n) \\sim 2 \\sqrt{n}")#text(", which suggests a spacing of about ")#mi("n^{-1/2}")#text(", on the average at least, for the increase ")#mi("\\lambda_n(M_n) - \\lambda_{n-1}(M_{n-1})")#text(" in the largest eigenvalue.)")

#heading(level: 1)[#text("— Eigenvector delocalisation —")]

#text("The closeness between the eigenvalues of ")#mi("M_n")#text(" and those of ")#mi("M_{n-1}")#text(" impacts the eigenvectors of ")#mi("M_n")#text(". Indeed, suppose that ")#mi("u =\\begin{pmatrix} u^{\\prime} \\\\ u_n \\end{pmatrix}")#text(" was a unit eigenvector of ")#mi("M_n")#text(" with eigenvalue ")#mi("\\lambda")#text(", thus")

#mi("\\begin{pmatrix} M_{n-1}-\\lambda I & X \\\\ X^* & x_{nn} - \\lambda \\end{pmatrix} \\begin{pmatrix} u^{\\prime} \\\\ u_n \\end{pmatrix} = 0.")

#text("In particular")

#align(center)[#tao-fit-display[#mitex("(M_{n-1} - \\lambda I) u^{\\prime} = - X u_n.")]]

#text("If ")#mi("\\lambda")#text(" is close to an eigenvalue of ")#mi("M_{n-1}")#text(", this makes the minor ")#mi("M_{n-1}-\\lambda I")#text(" ill-conditioned. This allows the vector ")#mi("u^{\\prime}")#text(" to be quite large compared to ")#mi("u_n")#text(", which (since u is normalised to be of unit size) makes ")#mi("u_n")#text(" small. Crunching the numbers, one can show that an eigenvalue gap of size ")#mi("O(1/\\sqrt{n})")#text(" translates (using the random nature of X) to a bound of about ")#mi("O(1/\\sqrt{n})")#text(" on ")#mi("u_n")#text(" (ignoring logs). By symmetry, we get a similar bound for the other coefficients of u, thus the coefficients of u are extremely uniform in magnitude (i.e. the eigenvector is ")#emph[#text("delocalised")]#text(").")

#heading(level: 1)[#text("— Why delocalisation is needed —")]

#text("The delocalisation of eigenvectors is an essential ingredient in our Lindeberg-style proof of universality, in which we replace the coefficients of ")#mi("M_n")#text(" with a better understood distribution (e.g. a gaussian distribution) one at a time. In order to keep the errors under control, it is necessary that the effect of any given coefficient of ")#mi("M_n")#text(" on an eigenvalue ")#mi("\\lambda_i")#text(" is significantly less than the mean spacing between eigenvalues. On the other hand, if one modifies the (p,q) coefficient ")#mi("x_{pq}")#text(" of ")#mi("M_n")#text(" by O(1), then the Hadamard variation formula (see this ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("previous blog post")]#text(") suggests that the eigenvalue ")#mi("\\lambda_i")#text(" should move by about ")#tao-math("O( \\left|u_{i,p}\\right| \\left|u_{i,q}\\right| )", block: false)#text(", where ")#mi("u_{i,p}")#text(" is the p^th coordinate of the unit eigenvector ")#mi("u_i")#text(" corresponding to ")#mi("\\lambda_i")#text(". With delocalisation, these coefficients have size about ")#mi("O(1/\\sqrt{n})")#text(", leading to a total movement of ")#mi("O(1/n)")#text(", which is indeed smaller than the mean spacing (")#mi("n^{-1/2}")#text(" in the bulk, ")#mi("n^{-1/6}")#text(" at the extreme edge).")

#text("[Note there is a bit of room here; one could accept a somewhat weaker delocalisation result, conceding some powers of n, but one would need more moment assumptions on the distribution to compensate for this (one has to perform a higher order Taylor expansion before the net error terms become acceptable again.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc195cd5afc572525f3d6543957df84ac22189f2825be360bab2d1a13c9d4587-22379daf92ed86a849b98450b72faaebc2274cf38978eaf9c6184a956c9a77d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helge")]], [#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/#comment-41131")[#strong[#text("Helge")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2009")])]

#text("A small typo: In Definition~1.4. One needs to change \\xi to \\zeta .. (or \\zeta to \\xi).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ea24bcc87b751a7f0150118135b9e3f5278ca10b6b4d9965dc424fee4f9fe7d-17cbcb27f37c322c54d836708b6075866a855dac9f2e0b42c30c559618da524e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/#comment-41245")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")])]

#text("Another small typo: the minimax formula is for the ith smallest eigenvalue, not the ith largest. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2366b26a0ab1c4a3ab3582fad24a055591b2f584a69def2fdd6110e0bc3fc983-44cc73568f6c723a71cf0d6f1d8dfa8eb4af217533a8632209cda18508649f0a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mylene")]], [#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/#comment-43671")[#strong[#text("Mylene")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2010")])]

#text("In Theorem 1.14, I think that the “n suffciently large” above which the lower tail estimates holds should not depend on \\epsilon [there is no more \\epsilon in this case as you are going up to the edge].")

#emph[#text("[Thanks! This correction will appear in the next revision of the paper. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantum states of elementary three–geometry by Carbone, Carfora , and Marzuoli | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/#comment-393453")[#strong[#text("Quantum states of elementary three–geometry by Carbone, Carfora , and Marzuoli | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2014")])]

#text("[…] Random matrices: Universality of local eigenvalue statistics up to the edge (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9863f1612fa207429ed7ad0272f7f9f2b43607a3742dc28d36273a43affd9a1-6d2b1d704227554169694b4bb75b81b24144d552bb7186d7145f0895868c2798.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of noether100")]], [#link("https://terrytao.wordpress.com/2009/08/15/random-matrices-universality-of-local-eigenvalue-statistics-up-to-the-edge/#comment-513523")[#strong[#text("noether100")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2019")])]

#text("Wow — it turns out the paper in question is one of the most popular math papers that are on arXiv and have ever been trending on Twitter:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("5 most popular ")#link("https://twitter.com/hashtag/math?src=hash&ref_src=twsrc%5Etfw")[#text("#math")]#text(" ")#link("https://twitter.com/hashtag/papers?src=hash&ref_src=twsrc%5Etfw")[#text("#papers")]#text(" ever ")#link("https://twitter.com/hashtag/trending?src=hash&ref_src=twsrc%5Etfw")[#text("#trending")]#text(" on Twitter as ")#link("https://twitter.com/hashtag/openaccess?src=hash&ref_src=twsrc%5Etfw")[#text("#openaccess")]#text(" ")#link("https://twitter.com/hashtag/arXiv?src=hash&ref_src=twsrc%5Etfw")[#text("#arXiv")]#text(" ")#link("https://twitter.com/hashtag/preprints?src=hash&ref_src=twsrc%5Etfw")[#text("#preprints")]#text(" ")#link("https://t.co/xxV2oDjPs5")[#text("https://t.co/xxV2oDjPs5")]#link("https://t.co/LjGdfW8S4J")[#text("https://t.co/LjGdfW8S4J")]#link("https://t.co/R7U11bD8LY")[#text("https://t.co/R7U11bD8LY")]#link("https://t.co/n8tBXOWaAW")[#text("https://t.co/n8tBXOWaAW")]#link("https://t.co/IneiSTTmUD")[#text("https://t.co/IneiSTTmUD")]#link("https://t.co/wjetaZL55F")[#text("https://t.co/wjetaZL55F")]#text(" ")#link("https://twitter.com/hashtag/altmetrics?src=hash&ref_src=twsrc%5Etfw")[#text("#altmetrics")]#text(" ")#link("https://twitter.com/altmetric?ref_src=twsrc%5Etfw")[#text("@altmetric")]#text(" ")#link("https://twitter.com/Reddit?ref_src=twsrc%5Etfw")[#text("@reddit")]#text(" ")#link("https://twitter.com/hashtag/OpenScience?src=hash&ref_src=twsrc%5Etfw")[#text("#OpenScience")]

#text("— Integrable Systems, Nonlinear Waves & All That (@integrablesys) ")#link("https://twitter.com/integrablesys/status/1103587910237016064?ref_src=twsrc%5Etfw")[#text("March 7, 2019")]
]
]
