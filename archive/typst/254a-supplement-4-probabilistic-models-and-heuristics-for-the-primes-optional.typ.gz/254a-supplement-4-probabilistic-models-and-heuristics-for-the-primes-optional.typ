// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/
// Converted to Typst by tao2typ: "2026-10-14T10:23:23.216512+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 4: Probabilistic models and heuristics for the primes (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 January 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now move away from the world of ")#emph[#text("multiplicative")]#text(" prime number theory covered in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" and ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(", and enter the wider, and complementary, world of ")#emph[#text("non-multiplicative")]#text(" prime number theory, in which one studies statistics related to non-multiplicative patterns, such as twins ")#mi("{n,n+2}")#text(". This creates a major jump in difficulty; for instance, even the most basic multiplicative result about the primes, namely ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(" that there are infinitely many of them, remains unproven for twin primes. Of course, the situation is even worse for stronger results, such as ")#link("http://en.wikipedia.org/wiki/Divergence_of_the_sum_of_the_reciprocals_of_the_primes")[#text("Euler’s theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_arithmetic_progressions")[#text("Dirichlet’s theorem")]#text(", or the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(". Finally, even many multiplicative questions about the primes remain open. The most famous of these is the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(", which gives the asymptotic ")#mi("{\\sum_{n \\leq x} \\Lambda(n) = x + O( \\sqrt{x} \\log^2 x )}")#text(" (see Proposition 24 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). But even if one assumes the Riemann hypothesis, the precise distribution of the error term ")#mi("{O( \\sqrt{x} \\log^2 x )}")#text(" in the above asymptotic (or in related asymptotics, such as for the sum ")#mi("{\\sum_{x \\leq n < x+y} \\Lambda(n)}")#text(" that measures the distribution of primes in short intervals) is not entirely clear.")

#text("Despite this, we do have a number of extremely convincing and well supported ")#emph[#text("models")]#text(" for the primes (and related objects) that let us ")#emph[#text("predict")]#text(" what the answer to many prime number theory questions (both multiplicative and non-multiplicative) should be, particularly in asymptotic regimes where one can work with aggregate statistics about the primes, rather than with a small number of individual primes. These models are based on taking some statistical distribution related to the primes (e.g. the primality properties of a randomly selected ")#mi("{k}")#text("-tuple), and replacing that distribution by a ")#emph[#text("model")]#text(" distribution that is easy to compute with (e.g. a distribution with strong joint independence properties). One can then predict the asymptotic value of various (normalised) statistics about the primes by replacing the relevant statistical distributions of the primes with their simplified models. In this non-rigorous setting, many difficult conjectures on the primes reduce to relatively simple calculations; for instance, all four of the (still unsolved) ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau problems")]#text(" may now be justified in the affirmative by one or more of these models. Indeed, the models are so effective at this task that analytic number theory is in the curious position of being able to confidently predict the answer to a large proportion of the open problems in the subject, whilst not possessing a clear way forward to rigorously confirm these answers!")

#text("As it turns out, the models for primes that have turned out to be the most accurate in practice are ")#emph[#text("random")]#text(" models, which involve (either explicitly or implicitly) one or more random variables. This is despite the prime numbers being obviously deterministic in nature; no coins are flipped or dice rolled to create the set of primes. The point is that while the primes have a lot of obvious ")#emph[#text("multiplicative")]#text(" structure (for instance, the product of two primes is never another prime), they do not appear to exhibit much discernible ")#emph[#text("non-multiplicative")]#text(" structure asymptotically, in the sense that they rarely exhibit statistical anomalies in the asymptotic limit that cannot be easily explained in terms of the multiplicative properties of the primes. As such, when considering non-multiplicative statistics of the primes, the primes appear to behave ")#link("http://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandomly")]#text(", and can thus be modeled with reasonable accuracy by a random model. And even for multiplicative problems, which are in principle controlled by the zeroes of the Riemann zeta function, one can obtain good predictions by positing various pseudorandomness properties of these zeroes, so that the distribution of these zeroes can be modeled by a random model.")

#text("Of course, one cannot expect ")#emph[#text("perfect")]#text(" accuracy when replicating a deterministic set such as the primes by a probabilistic model of that set, and each of the heuristic models we discuss below have some limitations to the range of statistics about the primes that they can expect to track with reasonable accuracy. For instance, many of the models about the primes do not fully take into account the multiplicative structure of primes, such as the connection with a zeta function with a meromorphic continuation to the entire complex plane; at the opposite extreme, we have the GUE hypothesis which appears to accurately model the zeta function, but does not capture such basic properties of the primes as the fact that the primes are all natural numbers. Nevertheless, each of the models described below, when deployed within their sphere of reasonable application, has (possibly after some fine-tuning) given predictions that are in remarkable agreement with numerical computation and with known rigorous theoretical results, as well as with other models in overlapping spheres of application; they are also broadly compatible with the general heuristic (discussed in ")#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("this previous post")]#text(") that in the absence of any exploitable structure, asymptotic statistics should default to the most “uniform”, “pseudorandom”, or “independent” distribution allowable.")

#text("As hinted at above, we do not have a single unified model for the prime numbers (other than the primes themselves, of course), but instead have an overlapping family of useful models that each appear to accurately describe some, but not all, aspects of the prime numbers. In this set of notes, we will discuss four such models:")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér random model")]#text(" and its refinements, which model the set ")#mi("{{\\mathcal P}}")#text(" of prime numbers by a random set.")],
[#text("The ")#emph[#text("Möbius pseudorandomness principle")]#text(", which predicts that the Möbius function ")#mi("{\\mu}")#text(" does not correlate with any genuinely different arithmetic sequence of reasonable “complexity”.")],
[#text("The ")#emph[#text("equidistribution of residues principle")]#text(", which predicts that the residue classes of a large number ")#mi("{n}")#text(" modulo a small or medium-sized prime ")#mi("{p}")#text(" behave as if they are independently and uniformly distributed as ")#mi("{p}")#text(" varies.")],
[#text("The ")#emph[#text("GUE hypothesis")]#text(", which asserts that the zeroes of the Riemann zeta function are distributed (at microscopic and mesoscopic scales) like the zeroes of a GUE random matrix, and which generalises the ")#emph[#text("pair correlation conjecture")]#text(" regarding pairs of such zeroes.")]
)

#text("This is not an exhaustive list of models for the primes and related objects; for instance, there is also the model in which the major arc contribution in the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(" is predicted to always dominate, and with regards to various finite groups of number-theoretic importance, such as the class groups discussed in ")#link("https://terrytao.wordpress.com/2014/11/28/245a-supplement-1-a-little-bit-of-algebraic-number-theory-optional/")[#text("Supplement 1")]#text(", there are also heuristics of ")#link("http://en.wikipedia.org/wiki/Class_number_problem")[#text("Cohen-Lenstra type")]#text(". Historically, the first heuristic discussion of the primes along these lines was by Sylvester, who worked informally with a model somewhat related to the equidistribution of residues principle. However, we will not discuss any of these models here.")

#text("A word of warning: the discussion of the above four models will inevitably be largely informal, and “fuzzy” in nature. While one can certainly make precise formalisations of at least some aspects of these models, one should not be inflexibly wedded to a specific such formalisation as being “the” correct way to pin down the model rigorously. (To quote the statistician ")#link("http://en.wikipedia.org/wiki/George_E._P._Box")[#text("George Box")]#text(": “all models are wrong, but some are useful”.) Indeed, we will see some examples below the fold in which some finer structure in the prime numbers leads to a correction term being added to a “naive” implementation of one of the above models to make it more accurate, and it is perfectly conceivable that some further such fine-tuning will be applied to one or more of these models in the future. These sorts of mathematical models are in some ways closer in nature to the scientific theories used to model the physical world, than they are to the axiomatic theories one is accustomed to in rigorous mathematics, and one should approach the discussion below accordingly. In particular, and in contrast to the other notes in this course, the material here is not ")#emph[#text("directly")]#text(" used for proving further theorems, which is why we have marked it as “optional” material. Nevertheless, the heuristics and models here are still used ")#emph[#text("indirectly")]#text(" for such purposes, for instance by")

#list(
[#text("giving a clearer indication of what results one ")#emph[#text("expects")]#text(" to be true, thus guiding one to fruitful conjectures;")],
[#text("providing a quick way to scan for possible errors in a mathematical claim (e.g. by finding that the main term is off from what a model predicts, or an error term is too small);")],
[#text("gauging the relative strength of various assertions (e.g. classifying some results as “unsurprising”, others as “potential breakthroughs” or “powerful new estimates”, others as “unexpected new phenomena”, and yet others as “way too good to be true”); or")],
[#text("setting up heuristic barriers (such as the ")#link("http://en.wikipedia.org/wiki/Parity_problem_(sieve_theory)")[#text("parity barrier")]#text(") that one has to resolve before resolving certain key problems (e.g. the twin prime conjecture).")]
)

#text("See also ")#link("https://terrytao.wordpress.com/career-advice/there%E2%80%99s-more-to-mathematics-than-rigour-and-proofs/")[#text("my previous essay on the distinction between “rigorous” and “post-rigorous” mathematics")]#text(", or ")#link("http://arxiv.org/abs/math.HO/9404236")[#text("Thurston’s essay")]#text(" discussing, among other things, the “definition-theorem-proof” model of mathematics and its limitations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The material in this set of notes presumes some prior exposure to probability theory. See for instance ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous post")]#text(" for a quick review of the relevant concepts.")
]

#metadata(none) <tao-d95329d4f88776d45013>

#heading(level: 1)[#strong[#text(" — 1. The Cramér random model — ")]]

#text("We begin by introducing the “naive” ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér random model")]#text(" for the primes ")#mi("{{\\mathcal P}}")#text(", explicitly introduced by Harald Cramér in 1936. The naive version of the Cramér model is a little too oversimplified to give very accurate results, but tends to give predictions of the right order of magnitude at least, and will serve as a basis for a more accurate version of the Cramér model to be introduced shortly.")

#text("The starting point for the model is the prime number theorem, which implies that there are approximately ")#mi("{\\frac{\\varepsilon x}{\\log x}}")#text(" primes between ")#mi("{x}")#text(" and ")#mi("{x+\\varepsilon x}")#text(" for any fixed ")#mi("{\\varepsilon > 0}")#text(" and large ")#mi("{x}")#text(". Thus, if one chooses a natural number ")#mi("{n}")#text(" at random in ")#mi("{[x, x+\\varepsilon x]}")#text(", the probability that it will be prime is about ")#mi("{\\frac{1}{\\log x} \\approx \\frac{1}{\\log n}}")#text(". Inspired by this, we construct a random model ")#mi("{{\\mathcal P}^{\\prime}}")#text(" of the primes ")#mi("{{\\mathcal P}}")#text(" to be a random subset of the natural numbers, such that each natural number ")#mi("{n > 2}")#text(" has an independent probability of ")#mi("{\\frac{1}{\\log n}}")#text(" of lying in ")#mi("{{\\mathcal P}^{\\prime}}")#text(", thus ")#metadata(none) <tao-4e544723d0f8e7db5627>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mathop{\\bf P}( n_1, \\dots, n_k \\in {\\mathcal P^{\\prime}} ) = \\frac{1}{\\log n_1 \\dots \\log n_k}")]]



#text(" for all distinct ")#mi("{n_1,\\dots,n_k > 2}")#text(". We exclude ")#mi("{2}")#text(" from consideration in ")#link(<tao-4e544723d0f8e7db5627>)[#text("(1)")]#text(" to avoid the issue that ")#mi("{\\frac{1}{\\log 2}}")#text(" is greater than one, and thus cannot serve as a probability. The membership of ")#mi("{1}")#text(" and ")#mi("{2}")#text(" in ")#mi("{{\\mathcal P}^{\\prime}}")#text(" is not of any great importance, but given that ")#mi("{{\\mathcal P}^{\\prime}}")#text(" is supposed to model ")#mi("{{\\mathcal P}}")#text(", let us require that ")#mi("{1 \\not \\in {\\mathcal P}^{\\prime}}")#text(" and ")#mi("{2 \\in {\\mathcal P}^{\\prime}}")#text(". We ignore here the (routine) measure-theoretic machinery needed to rigorously construct a probability space that can support a countably infinite number of random variables, as this set of notes is not focused on rigorous formalism. (See for instance ")#link("https://terrytao.wordpress.com/2010/10/30/245a-notes-6-outer-measures-pre-measures-and-product-measures/")[#text("this previous post")]#text(" for the relevant theory needed.)")

#text("We then have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Model 2 (Naive Cramér random model)")]#text(" ")#metadata(none) <tao-fd8af438ec73c619fd3b>#text(" The asymptotic statistics for the set of primes ")#mi("{{\\mathcal P}}")#text(" should (almost surely) behave like the asymptotic statistics of the random set ")#mi("{{\\mathcal P}^{\\prime}}")#text(".")
]

#text("This model asserts that while the set ")#mi("{{\\mathcal P}}")#text(" of primes is certainly deterministic, it is ")#link("http://en.wikipedia.org/wiki/Pseudorandomness")[#text("pseudorandom")]#text(", in the sense that it behaves like a random set, namely ")#mi("{{\\mathcal P}^{\\prime}}")#text(". The naive version of the Cramér model uses a random set ")#mi("{{\\mathcal P}^{\\prime}}")#text(" that has no structure beyond its density.")

#text("Let’s see some basic predictions of this model. The first is that it recovers the Riemann hypothesis (cf. Proposition 24 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 3 (Riemann hypothesis)")]#text(" ")#metadata(none) <tao-064369b841ea15785385>#text(" For any fixed ")#mi("{\\varepsilon>0}")#text(", we have ")#metadata(none) <tao-cd2eb0837c9b4c962c22>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O_\\varepsilon( x^{1/2+\\varepsilon})")]]



#text(" for ")#mi("{x > 1}")#text(".")
]

#emph[#text("Proof:")]#text(" (Uses naive Cramér model) The contribution of those ")#mi("{n}")#text(" that are squares or higher order of primes can be easily seen to be ")#mi("{O( x^{1/2+\\varepsilon})}")#text(", so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1_{\\mathcal P}(n) \\log n = x + O_\\varepsilon( x^{1/2+\\varepsilon}).")]]

#text("We then invoke the Cramér random model, and verify that almost surely one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} 1_{{\\mathcal P}^{\\prime}}(n) \\log n = x + O_\\varepsilon( x^{1/2+\\varepsilon}).")]]

#text("for all ")#mi("{x}")#text(" (here we allow the implied constant in the ")#mi("{O_\\varepsilon()}")#text(" notation to be random). By the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Cantelli_lemma")[#text("Borel-Cantelli lemma")]#text(", it suffices for each fixed choice of ")#mi("{x}")#text(" (which we can take to be a natural number) to obtain the estimate ")#metadata(none) <tao-5235b5cc504c3d739a3f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_{n \\leq x} 1_{{\\mathcal P}^{\\prime}}(n) \\log n = x + O_\\varepsilon( x^{1/2+\\varepsilon})")]]



#text(" with probability ")#mi("{1-O(x^{-2})}")#text(" (say).")

#text("Fix ")#mi("{x}")#text(", and consider the random variable")

#align(center)[#tao-fit-display[#mitex("X := \\sum_{n \\leq x} 1_{{\\mathcal P}^{\\prime}}(n) \\log n")]]

#text("which we rewrite as")

#align(center)[#tao-fit-display[#mitex("X = x + O(1) + \\sum_{2 < n \\leq x} X_n")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("X_n := 1_{{\\mathcal P}^{\\prime}}(n) \\log n - 1.")]]

#text("From ")#link(<tao-4e544723d0f8e7db5627>)[#text("(1)")]#text(", the ")#mi("{X_n}")#text(" have mean zero and are independent, and have size ")#mi("{O( \\log x ) = O( x^{o(1)} )}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} (\\sum_{2 < n \\leq x} X_n)^k = O_k( x^{k/2+o(1)})")]]

#text("for any fixed natural number ")#mi("{k}")#text(" (the only terms in ")#mi("{(\\sum_{2 < n \\leq x} X_n)^k}")#text(" that give a non-zero contribution are those in which each ")#mi("{X_n}")#text(" appears at least twice, so there are at most ")#mi("{k/2}")#text(" distinct indices of ")#mi("{n}")#text(" that arise, and so there are only ")#mi("{O_k(x^{k/2})}")#text(" such terms, each contributing ")#mi("{O(x^{o(1)})}")#text(". From ")#link("http://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]#text(" this implies that ")#mi("{\\sum_{n \\leq x} X_n = O( x^{1/2+\\varepsilon})}")#text(" with probability ")#mi("{1-O( x^{-k\\varepsilon + o(1)})}")#text(". Setting ")#mi("{k}")#text(" sufficiently large depending on ")#mi("{\\varepsilon}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" One could also have proven the above claim using concentration of measure results such as the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff inequality")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this previous blog post")]#text(". The estimate ")#link(<tao-cd2eb0837c9b4c962c22>)[#text("(2)")]#text(" reflects the general heuristic of ")#emph[#text("expected square root cancellation")]#text(": when summing ")#mi("{O(x)}")#text(" “independent” expressions, each of size ")#mi("{O(A)}")#text(", the sum should typically deviate by ")#mi("{O_\\varepsilon( x^{1/2+\\varepsilon} A)}")#text(" around its expected value, thus saving a factor of about ")#mi("{\\sqrt{x}}")#text(" over the trivial deviation bound of ")#mi("{O(xA)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Use the naive Cramér model to predict the size of the error term iCn the first, second, and third Mertens theorems (Theorems 33, 36, 42 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text("). (Note that the Cramér model will not predict the constant ")#mi("{e^\\gamma}")#text(" in the third Mertens theorem, as this constant is sensitive to the values of small primes, which the Cramér model does not accurately model; however, the model can predict a rate of convergence with ")#mi("{e^\\gamma}")#text(" replaced by an unspecified constant, which can then ")#emph[#text("a posteriori")]#text(" be matched with ")#mi("{e^\\gamma}")#text(" using the existing version of the third Mertens theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" ")#metadata(none) <tao-bec766e00261fe2ba68c>#text(" The fact that the naive Cramér model recovers essentially the same prediction on the prime number error term as the Riemann hypothesis (up to factors of ")#mi("{x^\\varepsilon}")#text(") is encouraging as far as evidence for the Riemann hypothesis is concerned. But one should caution that due to the multiplicative structure of the von Mangoldt function (as evidenced by the explicit formula), the naive Cramér model does not quite give the right bounds on error terms if one looks at the ")#mi("{x^\\varepsilon}")#text(" factors more carefully. For instance, from the smoothed explicit formula (Exercise 22 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") it is a routine matter (using Proposition 16 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" and Exercise 28 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") to arrive at the bound")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) g(\\log n - \\log x) = x \\hat g(-i) + O_g( x^{1/2} )")]]

#text("assuming the Riemann hypothesis for a fixed smooth, compactly supported function ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" and all ")#mi("{x > 1}")#text(". On the other hand, if one applies the naive Cramér random model, the quantity ")#mi("{\\sum_n \\Lambda(n) g(\\log n - \\log x) - x \\hat g(-i)}")#text(" becomes modeled by a quantity of mean ")#mi("{O_g(x^{1/2})}")#text(" and variance comparable to ")#mi("{x \\log x}")#text("; we leave this computation as an exercise to the interested reader. This suggests that the error term should be closer to ")#mi("{x^{1/2} \\log^{1/2} x}")#text(" than to ")#mi("{x^{1/2}}")#text(". Thus we see that the explicit formula, which is a feature of the genuine primes that are not present in the Cramér random model, bestows (on the Riemann hypothesis) slightly ")#link("http://en.wikipedia.org/wiki/Low-discrepancy_sequence")[#text("subrandom")]#text(" behaviour on the primes – the error terms can in fact be slightly better than what a purely random model predicts! (See Section ")#link(<tao-119c047bc7ec0180a1f3>)[#text("4")]#text(" below for further examples of this subrandom behaviour.) Ultimately, the reason for this is that the multiplicative semigroup ")#mi("{\\langle {\\mathcal P} \\rangle}")#text(" generated by the primes – that is to say, the natural numbers ")#mi("{{\\bf N}}")#text(" – is unusually well distributed in the sense that ")#mi("{\\sum_{n \\in \\langle {\\mathcal P} \\rangle: n \\leq x} 1 = x + O(1)}")#text(", which we have seen in previous notes to lead to an meromorphic continuation of the zeta function to the left of the critical line. In contrast, almost any conceivable Cramér-type random model ")#mi("{{\\mathcal P}^{\\prime}}")#text(" for the primes will only have a distribution of ")#mi("{\\sum_{n \\in \\langle {\\mathcal P} \\rangle: n \\leq x} 1 = x + O_\\varepsilon(x^{1/2+\\varepsilon})}")#text(" at best (where we view ")#mi("{\\langle {\\mathcal P} \\rangle}")#text(" as a multiset, so the sum is weighted by multiplicity), and so cannot capture consequences of this subrandom distribution of ")#mi("{\\langle {\\mathcal P} \\rangle}")#text(", such as the explicit formula. However, it appears that such deviations from random behaviour are only significant if one wishes to obtain accuracy better than ")#mi("{O( x^{1/2+\\varepsilon})}")#text(" in one’s estimates, and so one should not be too concerned about such deviations if one is willing to concede these ")#mi("{O( x^{1/2+\\varepsilon})}")#text(" errors. See ")#link("http://www.ams.org/mathscinet-getitem?mr=2363833")[#text("this paper of Pintz")]#text(" for further discussion of this deviation of the primes from Cramér type models.")
]

#text("Next, we give another prediction of the naive Cramér model, which was in fact ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér’s original motivation")]#text(" for introducing the model. For any ")#mi("{X > 3}")#text(", let")

#align(center)[#tao-fit-display[#mitex("G(X) := \\sup_{n: p_n, p_{n+1} \\leq X} p_{n+1} - p_n")]]

#text("denote the largest gap between the primes up to ")#mi("{X}")#text(", where ")#mi("{p_n}")#text(" denotes the ")#mi("{n^{th}}")#text(" prime.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 7 (Cramér conjecture)")]#text(" ")#metadata(none) <tao-128c2622f546b0c06fb6>#text(" One has ")#mi("{G(X) = (1+o(1)) \\log^2 X}")#text(" as ")#mi("{X \\rightarrow \\infty}")#text(".")
]

#text("Note that this conjecture would imply ")#link("http://en.wikipedia.org/wiki/Legendre%27s_conjecture")[#text("Legendre’s conjecture")]#text(" that there is always a prime between ")#mi("{n^2}")#text(" and ")#mi("{(n+1)^2}")#text(", at least for sufficiently large ")#mi("{n}")#text("; indeed, any bound of the shape ")#mi("{G(X) = o(X^{1/2})}")#text(" would suffice for this purpose. Intuitively, the reason for this is that with an average density of ")#mi("{\\log X}")#text(", the probability that a given gap between primes exceeds ")#mi("{A \\log X}")#text(" should be like ")#mi("{e^{-A}}")#text("; as one has ")#mi("{X^{1+o(1)}}")#text(" gaps to play with, the largest gap that one still expects to actually occur would then be of size ")#mi("{A \\log X}")#text(" with ")#mi("{e^{-A} \\approx 1/X^{1+o(1)}}")#text(", which explains the ")#mi("{\\log^2 X}")#text(" factor.")

#emph[#text("Proof:")]#text(" (Uses naive Cramér model) Let ")#mi("{p^{\\prime}_1, p^{\\prime}_2, \\dots}")#text(" be the elements of the random set ")#mi("{{\\mathcal P}^{\\prime}}")#text(" in increasing order, and let ")#mi("{G^{\\prime}(X)}")#text(" be the random variable")

#align(center)[#tao-fit-display[#mitex("G^{\\prime}(X) := \\sup_{n: p^{\\prime}_n, p^{\\prime}_{n+1} \\leq X} p^{\\prime}_{n+1} - p^{\\prime}_n")]]

#text("Invoking the naive Cramér model, we will verify that almost surely one has")

#align(center)[#tao-fit-display[#mitex("G^{\\prime}(X) = (1+o(1)) \\log^2 X")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(". By the Borel-Cantelli lemma (and restricting ")#mi("{X}")#text(" to be a power of two), it suffices to show for each ")#mi("{0 < \\varepsilon < 1/2}")#text(" and ")#mi("{X>2}")#text(" that one has ")#metadata(none) <tao-2ebbdf589ecfa93f0bf3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("G^{\\prime}(X) \\leq (1+\\varepsilon) \\log^2 X")]]



#text(" and ")#metadata(none) <tao-5a3227b9d7f8b45e3435>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("G^{\\prime}(X) \\geq (1-\\varepsilon) \\log^2 X")]]



#text(" with probability ")#mi("{1 - O_\\varepsilon(X^{-\\varepsilon})}")#text(" (say).")

#text("We begin with ")#link(<tao-2ebbdf589ecfa93f0bf3>)[#text("(4)")]#text(". To show this bound, it suffices to show that every discrete interval in ")#mi("{[3,X]}")#text(" of cardinality ")#mi("{L_+ := \\lfloor (1+\\varepsilon) \\log^2 X \\rfloor-1}")#text(" contains at least one element of ")#mi("{{\\mathcal P}^{\\prime}}")#text(". There are ")#mi("{O(X)}")#text(" such intervals, so by the union bound it suffices to show that for any given interval ")#mi("{I}")#text(", the probability that ")#mi("{I}")#text(" contains at least one element of ")#mi("{{\\mathcal P}^{\\prime}}")#text(" is at least ")#mi("{1 - O_\\varepsilon(X^{-3})}")#text(". From ")#link(<tao-4e544723d0f8e7db5627>)[#text("(1)")]#text(" and the inclusion-exclusion principle, this probability is precisely")

#align(center)[#tao-fit-display[#mitex("1 - \\prod_{n \\in I} (1 - \\frac{1}{\\log n}).")]]

#text("Upper bounding ")#mi("{1 - \\frac{1}{\\log n}}")#text(" by ")#mi("{\\exp( -\\frac{1}{\\log X} )}")#text(", this probability is at least ")#mi("{1 - \\exp( -L_+ / \\log X )}")#text(", and the claim follows.")

#text("Now we show ")#link(<tao-5a3227b9d7f8b45e3435>)[#text("(5)")]#text(". Observe that the interval ")#mi("{[X/4,X/2]}")#text(" contains ")#mi("{\\gg X / \\log^2 X}")#text(" disjoint discrete intervals ")#mi("{I_1,\\dots,I_m}")#text(" of cardinality ")#mi("{L_- := \\lceil (1-\\varepsilon) \\log^2 X \\rceil}")#text(". It will suffice to show that with probability ")#mi("{1 - O_\\varepsilon(X^{-2})}")#text(", at least one of these intervals is disjoint from ")#mi("{{\\mathcal P}^{\\prime}}")#text(". (It is easy to see that the interval ")#mi("{(X/2,X]}")#text(" will contain at least one element of ")#mi("{{\\mathcal P}^{\\prime}}")#text(" with probability ")#mi("{1 - O_\\varepsilon( X^{-2} )}")#text(".) By ")#link(<tao-4e544723d0f8e7db5627>)[#text("(1)")]#text(", the probability that a given interval ")#mi("{I_j}")#text(" has this property is")

#align(center)[#tao-fit-display[#mitex("\\prod_{n \\in I} (1 - \\frac{1}{\\log n}).")]]

#text("Lower bounding ")#mi("{1 - \\frac{1}{\\log n}}")#text(" by ")#mi("{\\exp( -\\frac{1-o(1)}{\\log X})}")#text(", where the ")#mi("{o(1)}")#text(" goes to zero as ")#mi("{X \\rightarrow \\infty}")#text(" keeping ")#mi("{\\varepsilon}")#text(" fixed, we see that the probability that a given ")#mi("{I_j}")#text(" is disjoint from ")#mi("{{\\mathcal P}^{\\prime}}")#text(" is at least")

#align(center)[#tao-fit-display[#mitex("\\exp( - (1-o(1)) L_- / \\log X ) = X^{-1+\\varepsilon + o(1)}.")]]

#text("As the events that ")#mi("{I_j}")#text(" are disjoint from ")#mi("{{\\mathcal P}^{\\prime}}")#text(" are independent in ")#mi("{j}")#text(", the probability that none of them are disjoint from ")#mi("{{\\mathcal P}^{\\prime}}")#text(" is then at most")

#align(center)[#tao-fit-display[#mitex("(1 - X^{-1+\\varepsilon + o(1)})^m = 1 - O( \\exp( - X^{\\varepsilon+o(1)} ) )")]]

#text("and the claim follows. ")#mi("\\Box")

#text("As it turns out, we now believe this prediction of the naive Cramér model to be slightly incorrect; see below. For the most recent rigorous lower bounds on ")#mi("{G(X)}")#text(", see this ")#link("https://terrytao.wordpress.com/2014/12/16/long-gaps-between-primes/")[#text("recent post")]#text(". As for upper bounds, it was shown by Cramér on the Riemann hypothesis that ")#mi("{G(X) \\ll X^{1/2} \\log X}")#text(", and a slight further improvement under the additional assumption of the pair correlation conjecture (see Section ")#link(<tao-119c047bc7ec0180a1f3>)[#text("4")]#text(" below) was obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=667711")[#text("by Heath-Brown")]#text(".")

#text("Our final example of the naive Cramér model is to the twin prime conjecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 8 (Twin prime asymptotic, first attempt)")]#text(" ")#metadata(none) <tao-d945c9ba82e9f4793549>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}\\} = (1+o(1)) \\frac{x}{\\log^2 x}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(". In particular, there are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is also prime.")
]

#text("Intuitively, the reason for this asymptotic is that for most of the ")#mi("{O(x)}")#text(" numbers ")#mi("{n}")#text(" between ")#mi("{3}")#text(" and ")#mi("{x}")#text(", each of ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" have an independent probability of about ")#mi("{1/\\log x}")#text(" being prime (or more precisely, of lying in the Cramér model for the primes), so the probability that they are both prime should be about ")#mi("{1/\\log^2 x}")#text(".")

#emph[#text("Proof:")]#text(" (Uses naive Cramér model) We will show that ")#metadata(none) <tao-1e0bbd6c686ba050b8eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}^{\\prime}\\} = (1+o(1)) \\frac{x}{\\log^2 x}")]]



#text(" almost surely. By the Borel-Cantelli lemma again, it suffices to show that for each ")#mi("{x > 2}")#text(", we have ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("(6)")]#text(" with probability ")#mi("{1 - O(x^{-2+o(1)})}")#text(" (say) as ")#mi("{x \\rightarrow \\infty}")#text(".")

#text("Fix ")#mi("{x}")#text(". We write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("O(1) + \\sum_{2 \\leq n \\leq x} \\frac{1}{(\\log n) \\log(n+2)} + X_n")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("X_n := 1_{{\\mathcal P}^{\\prime}}(n) 1_{{\\mathcal P}^{\\prime}}(n+2) - \\frac{1}{(\\log n) \\log(n+2)}.")]]

#text("To estimate the sum ")#mi("{\\sum_{2 \\leq n \\leq x} \\frac{1}{(\\log n) \\log(n+2)}}")#text(", we can easily check that the contribution with ")#mi("{n \\leq x / \\log^3 x}")#text(" is ")#mi("{o(x/\\log^2 x)}")#text(", and for the remaining portion we have ")#mi("{\\frac{1}{(\\log n) \\log(n+2)} = \\frac{1+o(1)}{\\log^2 x}}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{2 \\leq n \\leq x} \\frac{1}{(\\log n) \\log(n+2)} = (1+o(1)) \\frac{x}{\\log^2 x}.")]]

#text("It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{2 \\leq n \\leq x} X_n = o( \\frac{x}{\\log^2 x} )")]]

#text("with probability ")#mi("{1 - O(x^{-2+o(1)})}")#text(". But from ")#link(<tao-4e544723d0f8e7db5627>)[#text("(1)")]#text(", each ")#mi("{X_n}")#text(" has mean zero, is bounded by ")#mi("{O(1)}")#text(", and ")#mi("{X_n}")#text(" is independent of ")#mi("{X_m}")#text(" unless ")#tao-math("{\\left|n-m\\right| \\leq 2}", block: false)#text(", from which we easily calculate that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} (\\sum_{2 \\leq n \\leq x} X_n)^2 = O(x).")]]

#text("A direct application of Chebyshev’s inequality then gives the required bound with a failure probability of ")#mi("{O( x^{-1+o(1)})}")#text(", which is not quite good enough for our purposes; but a similar calculation gives")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} (\\sum_{2 \\leq n \\leq x} X_n)^4 = O(x^2),")]]

#text("which is sufficient. (Alternatively, one can first round ")#mi("{x}")#text(" to the nearest power of ")#mi("{1+\\varepsilon}")#text(" for a small fixed ")#mi("{\\varepsilon>0}")#text(", in which case Borel-Cantelli would already work with a failure probability as large as, say, ")#mi("{O(\\log^{-2} x)}")#text(".) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" ")#metadata(none) <tao-1b2ffa27d8046b022abb>#text(" Sharpen the prediction of the naive Cramér model to")

#align(center)[#tao-fit-display[#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}\\} = \\int_2^x \\frac{dt}{(\\log t) \\log(2+t)} + O_\\varepsilon( x^{1/2+\\varepsilon} )")]]

#text("for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{x > 2}")#text(".")
]

#text("Unfortunately, the above argument reveals a significant drawback to the naive Cramér model, in that the same argument also predicts the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\# \\{ p \\leq x: p, p+1 \\in {\\mathcal P}\\} = (1+o(1)) \\frac{x}{\\log^2 x},")]]

#text("implying that there are an infinite number of ")#emph[#text("consecutive")]#text(" primes ")#mi("{p,p+1}")#text(". This is of course absurd, since all but one of the primes ")#mi("{p \\in {\\mathcal P}}")#text(" are odd. The problem is that the naive Cramér model does not take into account the severe irregularity in the distribution of the primes ")#mi("{{\\mathcal P}}")#text(" with respect to the residue classes modulo ")#mi("{2}")#text(". One also needs to take into account irregularity modulo ")#mi("{3}")#text(", to avoid predicting the infinitude of prime triplets ")#mi("{p,p+2,p+4}")#text(" (note that as one of ")#mi("{p,p+2,p+4}")#text(" must be divisible by ")#mi("{3}")#text(", the only prime triplet is in fact ")#mi("{3,5,7}")#text("); and so forth. We formalise this with the following revision of the Cramér model. Given a parameter ")#mi("{w \\geq 2}")#text(", let ")#mi("{W:= \\prod_{p \\leq w} p}")#text(" denote the product of all the primes up to ")#mi("{w}")#text(" (this is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" of ")#mi("{w}")#text("). Note that after removing the primes less than or equal to ")#mi("{w}")#text(", all the remaining primes lie in the ")#mi("{\\phi(W)}")#text(" residue classes ")#mi("{b\\ (W)}")#text(" with ")#mi("{b}")#text(" coprime to ")#mi("{W}")#text(". From the prime number theorem in arithmetic progressions (Exercise 50 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), we expect (for ")#mi("{x}")#text(" sufficiently large depending on ")#mi("{w}")#text(") each such residue class to contain about ")#mi("{\\frac{x}{\\phi(W) \\log x}}")#text(" primes less than or equal to ")#mi("{x}")#text(", compared to about ")#mi("{\\frac{x}{W}}")#text(" natural numbers less than or equal to ")#mi("{x}")#text(", leading to a density of ")#mi("{\\frac{W}{\\phi(W) \\log x}}")#text(". This motivates a variant ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" of the random set ")#mi("{{\\mathcal P}^{\\prime}}")#text(", defined by letting ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" consist (deterministically) of the primes up to ")#mi("{w}")#text(", together with a random subset of those natural numbers coprime to ")#mi("{W}")#text(", with")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}( n_1, \\dots, n_k \\in {\\mathcal P^{\\prime}}_w ) = \\prod_{i=1}^k \\min( \\frac{W}{\\phi(W) \\log n_i}, 1)")]]

#text("for distinct ")#mi("{n_1,\\dots,n_k}")#text(" coprime to ")#mi("{W}")#text(". (The minimum here is to ensure that probabilities stay less than ")#mi("{1}")#text(", and can be largely ignored in practice.) Thus, for instance, ")#mi("{{\\mathcal P}^{\\prime}_2}")#text(" consists of the prime ")#mi("{2}")#text(" together with a random set of odd numbers, with each large odd number ")#mi("{n}")#text(" having an independent probability of ")#mi("{\\frac{2}{\\log n}}")#text(" of lying in ")#mi("{{\\mathcal P}^{\\prime}_2}")#text(". Similarly, ")#mi("{{\\mathcal P}^{\\prime}_3}")#text(" consists of the primes ")#mi("{2}")#text(" and ")#mi("{3}")#text(", together with a random set of numbers coprime to ")#mi("{6}")#text(", with each such large number ")#mi("{n}")#text(" having an independent probability of ")#mi("{\\frac{3}{\\log n}}")#text(" of lying in ")#mi("{{\\mathcal P}^{\\prime}_3}")#text(". We then have the following (somewhat imprecise) modification of the Cramér model:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Model 10 (Modified Cramér random model)")]#text(" ")#metadata(none) <tao-26d98f7f4115af654379>#text(" The asymptotic statistics for the set of primes ")#mi("{{\\mathcal P}}")#text(" up to some threshold ")#mi("{x}")#text(" should (almost surely) behave like the asymptotic statistics of the random set ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" for ")#mi("{w}")#text(" slowly growing in ")#mi("{x}")#text(" (or alternatively as the limit of the statistics of ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" for fixed ")#mi("{w}")#text(", in the limit ")#mi("{w \\rightarrow \\infty}")#text(").")
]

#text("This model is not as precise as the naive Cramér model, because it does not specify exactly how ")#mi("{w}")#text(" is to depend on ")#mi("{x}")#text(", but in many applications it does not matter so much (except perhaps for predicting the size of error terms) exactly what ")#mi("{w}")#text(" is, so long as it grows slowly (e.g. ")#mi("{\\log x}")#text(" or slower).")

#text("We illustrate this model with an refined prediction for the twin prime conjecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 11 (Refined twin prime asymptotic)")]#text(" ")#metadata(none) <tao-c27c2e4875b4c241cf3a>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}\\} = (2\\Pi_2+o(1)) \\frac{x}{\\log^2 x}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{\\Pi_2}")#text(" is the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin primes constant")]#text(", defined as ")#metadata(none) <tao-68d3ff4b0ff6aa3eae88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\Pi_2 := \\prod_{p \\in {\\mathcal P}: p >2} (1 - \\frac{1}{(p-1)^2}) = 0.6601618\\dots.")]]



#text(" In particular, there are infinitely many primes ")#mi("{p}")#text(" such that ")#mi("{p+2}")#text(" is also prime.")
]

#text("In analogy with Exercise ")#link(<tao-1b2ffa27d8046b022abb>)[#text("9")]#text(", one is led to the refined prediction")

#align(center)[#tao-fit-display[#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}\\}")]]

#align(center)[#tao-fit-display[#mitex("= 2\\Pi_2 \\int_2^x \\frac{dt}{(\\log t)\\log(t+2)} + O_\\varepsilon(x^{1/2+\\varepsilon})")]]

#text("for any fixed ")#mi("{\\varepsilon}")#text(". This prediction matches well with numerics. For instance, the number of twin primes up to ")#mi("{10^{10}}")#text(" is ")#mi("{27,412,679}")#text(", which is within ")#mi("{0.004\\%}")#text(" of the prediction given by the above formula (in contrast, ")#link(<tao-d945c9ba82e9f4793549>)[#text("(8)")]#text(" is off by about thirty percent). (See ")#link("http://numbers.computation.free.fr/Constants/Primes/twin.html")[#text("this web page of Gourdon and Sebah")]#text(" for some further numerical statistics on twin primes.)")

#emph[#text("Proof:")]#text(" (Uses modified Cramér model; informal) The argument here is essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=104639")[#text("due to Pólya")]#text(". We study the statistic ")#metadata(none) <tao-40460da8c882cdc79183>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}_w\\}")]]



#text(" for fixed ")#mi("{w}")#text(" and large ")#mi("{x}")#text(". The primes less than or equal to ")#mi("{w}")#text(" contribute ")#mi("{O_w(1)}")#text(" to this statistic, so we restrict attention to those ")#mi("{p}")#text(" with ")#mi("{p > w}")#text(". A residue class ")#mi("{b\\ (W)}")#text(" only contributes to the above statistic in case ")#mi("{b}")#text(" and ")#mi("{b+2}")#text(" are both coprime to ")#mi("{W}")#text("; by the Chinese remainder theorem, the number of such residue classes is")

#align(center)[#tao-fit-display[#mitex("\\prod_{2 < p \\leq w} (p-2).")]]

#text("On the other hand, a modification of the computation in Prediction ")#link(<tao-d945c9ba82e9f4793549>)[#text("8")]#text(" shows that the contribution of a given residue class ")#mi("{b\\ (W)}")#text(" with ")#mi("{b,b+2}")#text(" both coprime to ")#mi("{W}")#text(" should be")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\frac{x}{W} \\times (\\frac{W}{\\phi(W) \\log x})^2")]]

#text("with “high probability” (we do not quantify this term here). Thus the total size of ")#link(<tao-40460da8c882cdc79183>)[#text("(8)")]#text(" should be approximately")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\frac{x}{W} \\times (\\frac{W}{\\phi(W) \\log x})^2 \\times \\prod_{2 < p \\leq w} (p-2) + O_w(1).")]]

#text("This simplifies as")

#align(center)[#tao-fit-display[#mitex("(2 \\prod_{2 < p \\leq w} (1 - \\frac{1}{(p-1)^2}) + o(1)) \\frac{x}{\\log^2 x}.")]]

#text("Letting ")#mi("{w}")#text(" grow slowly to infinity, we obtain the claim. ")#mi("\\Box")

#text("Note now that we do not run into the problem of the Cramér model predicting infinitely many pairs of consecutive primes (as ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" will avoid such patterns once ")#mi("{w \\geq 2}")#text("), or infinitely many prime triplets ")#mi("{p,p+2,p+4}")#text(", etc.")

#text("The modified Cramér model already predicts answers (and asymptotics) to many of the basic unsolved questions in analytic prime number theory, including an affirmative answer to all four of ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau’s problems")]#text("; these are discussed in the exercises below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Goldbach conjecture)")]#text(" ")#metadata(none) <tao-1f8f4b311ca78f1ffcfd>#text(" Let ")#mi("{N}")#text(" be a large even number. Use the modified Cramér model to predict that the number of ways to represent ")#mi("{N}")#text(" as the sum ")#mi("{N=p+q}")#text(" of two primes is equal to ")#metadata(none) <tao-3e399c46e9652dadde7e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(2 \\Pi_2 (\\prod_{p > 2: p|N} \\frac{p-1}{p-2}) + o(1)) \\frac{N}{\\log^2 N}")]]



#text(" as ")#mi("{N \\rightarrow \\infty}")#text(". In particular, the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("even Goldbach conjecture")]#text(" should be true for sufficiently large even numbers. Given that this conjecture has been numerically verified for even integers up to about ")#mi("{10^{18}}")#text(", it is thus widely expected that this conjecture is true.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Hardy-Littlewood prime tuples conjecture)")]#text(" ")#metadata(none) <tao-49ee4fc7f82952169a0c>#text(" Let ")#mi("{k \\geq 1}")#text(", and let ")#mi("{(h_1,\\dots,h_k)}")#text(" be a tuple of distinct integers which are ")#emph[#text("admissible")]#text(" in the sense that for every prime ")#mi("{p}")#text(", there is at least one residue class ")#mi("{a_p\\ (p)}")#text(" that is disjoint from all of the ")#mi("{h_1,\\dots,h_k}")#text(". (For instance, ")#mi("{(0,2,6)}")#text(" is admissible, but ")#mi("{(0,1)}")#text(" or ")#mi("{(0,2,4)}")#text(" is not admissible.) Use the modified Cramér model to predict the Hardy-Littlewood prime tuples conjecture: ")#metadata(none) <tao-0369a36fe856043f6475>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\#\\{ n \\leq x: n+h_1,\\dots,n+h_k \\in {\\mathcal P}\\} = ({\\mathfrak S} + o(1)) \\frac{x}{\\log^k x}")]]



#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{{\\mathfrak S}}")#text(" is the ")#emph[#text("singular series")]

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\prod_p \\frac{1 - \\omega(p) / p}{(1-1/p)^k}")]]

#text("and ")#mi("{\\omega(p)}")#text(" is the number of distinct residue classes that the ")#mi("{h_1,\\dots,h_k}")#text(" lie in modulo ")#mi("{p}")#text(". Show also that ")#mi("{{\\mathfrak S}}")#text(" is convergent to a non-zero number when the tuple ")#mi("{(h_1,\\dots,h_k)}")#text(" is admissible; in particular, the modified Cramér model predicts that there are infinitely many ")#mi("{n}")#text(" such that ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are simultaneously prime.")
]

#text("Again in analogy with Exercise ")#link(<tao-1b2ffa27d8046b022abb>)[#text("9")]#text(", one expects to be able to improve ")#link(<tao-0369a36fe856043f6475>)[#text("(10)")]#text(" to ")#metadata(none) <tao-0fbea216374b65af112c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{n \\leq x} \\Lambda(n+h_1) \\dots \\Lambda(n+h_k) = {\\mathfrak S} x + O_{k,\\varepsilon}( x^{1/2+\\varepsilon} )")]]



#text(" for any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{h_1,\\dots,h_k = O( x^{1-\\varepsilon} )}")#text("; we shall refer to this as the ")#emph[#text("strong Hardy-Littlewood prime tuples conjecture")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 14")]#text(" The even Goldbach conjecture and the prime tuples conjecture are still unsolved. However, if one performs more averaging over additional parameters, the analogous asymptotics to ")#link(<tao-3e399c46e9652dadde7e>)[#text("(9)")]#text(" or ")#link(<tao-0369a36fe856043f6475>)[#text("(10)")]#text(" can be proven in many cases, thus giving some support to the accuracy of the modified Cramér model. For instance, ")#link("http://en.wikipedia.org/wiki/Vinogradov%27s_theorem")[#text("Vinogradov famously established")]#text(" (via the ")#link("http://en.wikipedia.org/wiki/Hardy%E2%80%93Littlewood_circle_method")[#text("Hardy-Littlewood circle method")]#text(") the analogue to ")#link(<tao-3e399c46e9652dadde7e>)[#text("(9)")]#text(" for the number of representations of a large odd natural number ")#mi("{N}")#text(" as the sum of ")#emph[#text("three")]#text(" primes, implying in particular that every sufficiently large odd number was the sum of three primes. Similarly, an averaged version of the Hardy-Littlewood conjecture was obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=1084173")[#text("by Balog")]#text(", and a general higher-dimensional version of this conjecture in a ")#link("http://www.ams.org/mathscinet-getitem?mr=2680398")[#text("series of")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2877066")[#text("papers by")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2950773")[#text("Green, Ziegler, and myself")]#text(". This allows one to unconditionally establish the asymptotics predicted by the modified Cramér model for statistics such as the number of arithmetic progressions of length ")#mi("{k}")#text(" consisting solely of primes less than a given threshold ")#mi("{x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Landau’s fourth problem)")]#text(" ")#metadata(none) <tao-dc81b1d371a4072be7fc>#text(" Use the modified Cramér model to predict that")

#align(center)[#tao-fit-display[#mitex("\\# \\{ n \\leq x: n^2 + 1 \\in {\\mathcal P} \\} = {\\mathfrak S} \\frac{x}{2 \\log x}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\prod_p \\frac{1 - \\omega(p) / p}{1-1/p}")]]

#text("and ")#mi("{\\omega(p)}")#text(" is the number of residue classes ")#mi("{a\\ (p)}")#text(" such that ")#mi("{a^2 + 1 = 0\\ (p)}")#text(", with ")#mi("{{\\mathfrak S}}")#text(" convergent to a positive non-zero number. (To show the latter claim, you will need quadratic reciprocity (Exercise 59 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(") and Dirichlet’s theorem on primes in arithmetic progression, in the form of Exercise 81 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(".) In particular, the modified Cramér model predicts an affirmative answer to ")#link("http://en.wikipedia.org/wiki/Landau%27s_problems")[#text("Landau’s fourth problem")]#text(", namely that there are infinitely many ")#mi("{n}")#text(" such that ")#mi("{n^2+1}")#text(" is prime.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" A common generalisation of the previous two exercises is the ")#link("http://en.wikipedia.org/wiki/Bateman%E2%80%93Horn_conjecture")[#text("Bateman-Horn conjecture")]#text(", that asserts that given a collection ")#mi("{P_1,\\dots,P_k: {\\bf Z} \\rightarrow {\\bf Z}}")#text(" of distinct non-constant irreducible polynomials that take integer values at the integers, have positive leading coefficients, and such that for every prime ")#mi("{p}")#text(" there is a natural number ")#mi("{n}")#text(" such that ")#mi("{P_1(n),\\dots,P_k(n)}")#text(" are not divisible by ")#mi("{p}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\# \\{ n \\leq x: P_1(n),\\dots,P_k(n) \\in {\\mathcal P} \\} = ({\\mathfrak S} +o(1))\\frac{x}{D \\log^k x}")]]

#text("as ")#mi("{x \\rightarrow \\infty}")#text(", where ")#mi("{D}")#text(" is the product of the degrees of the polynomials ")#mi("{P_1,\\dots,P_k}")#text(", and")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S} := \\prod_p \\frac{1 - \\omega(p) / p}{(1-1/p)^k}")]]

#text("where ")#mi("{\\omega(p)}")#text(" is the number of residue classes ")#mi("{a\\ (p)}")#text(" such that ")#mi("{P_1(a) \\dots P_k(a) = 0\\ (p)}")#text(". This can be justified from the modified Cramér model by similar reasoning to the above, although to show that the product ")#mi("{{\\mathfrak S}}")#text(" converges to a non-zero number requires some additional algebraic number theory input (the ")#link("http://en.wikipedia.org/wiki/Chebotarev%27s_density_theorem")[#text("Chebotarev density theorem")]#text(", which can be viewed as a generalisation of Dirichlet’s theorem) which we are not covering here. A consequence of the Bateman-Horn conjecture is ")#link("http://en.wikipedia.org/wiki/Schinzel%27s_hypothesis_H")[#text("Schinzel’s hypothesis H")]#text(", which asserts under the above hypotheses that there are infinitely many natural numbers ")#mi("{n}")#text(" such that ")#mi("{P_1(n),\\dots,P_k(n)}")#text(" are simultaneously prime.")
]

#text("We saw that the twin prime conjecture asymptotic (Prediction ")#link(<tao-d945c9ba82e9f4793549>)[#text("8")]#text(") had to be adjusted (to Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text(") when the naive Cramér model was replaced by the modified Cramér model. At the other extreme of prime gap behaviour, a somewhat analogous modification of the Cramér conjecture (Conjecture ")#link(<tao-128c2622f546b0c06fb6>)[#text("7")]#text(") on ")#mi("{G(X)}")#text(" was shown ")#link("http://www.dartmouth.edu/~chance/chance_news/for_chance_news/Riemann/cramer.pdf")[#text("by Granville")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 17 (Modified Cramér conjecture)")]#text(" We have ")#mi("{G(X) \\geq (2e^{-\\gamma} - o(1)) \\log^2 X}")#text(" as ")#mi("{X \\rightarrow \\infty}")#text(".")
]

#text("Since ")#mi("{2e^{-\\gamma} = 1.1229\\dots}")#text(", we thus see that Prediction ")#link(<tao-d945c9ba82e9f4793549>)[#text("8")]#text(" is now expected to be incorrect by over ten percent. It is uncertain whether the quantity ")#mi("{2e^{-\\gamma}}")#text(" can be improved further, however it seems reasonable to continue to conjecture a weak form ")#mi("{G(X) \\asymp \\log^2 X}")#text(" of the Cramér conjecture.")

#emph[#text("Proof:")]#text(" (Uses modified Cramér model) The basic idea here is not to look at ")#emph[#text("all")]#text(" prime gaps, but gaps associated to given residue classes modulo ")#mi("{W}")#text(", for a well chosen choice of ")#mi("{W}")#text(". This is an instance of the ")#link("http://en.wikipedia.org/wiki/Maier%27s_matrix_method")[#text("Maier matrix method")]#text(", which we will revisit later in this course.")

#text("More specifically, fix a small quantity ")#mi("{\\varepsilon > 0}")#text(". Set ")#mi("{w := \\log X / \\log\\log X}")#text("; the reason for this choice is that this is almost the largest choice that keeps ")#mi("{W}")#text(" significantly less than ")#mi("{X}")#text(", since from the prime number theorem ")#mi("{\\sum_{p \\leq w} \\log p = (1+o(1)) w}")#text(" one has ")#metadata(none) <tao-4f7220c4183e22101189>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("W = \\exp( (1+o(1)) w ) = X^{o(1)}.")]]



#text(" Let")

#align(center)[#tao-fit-display[#mitex("G^{\\prime}_w(X) := \\sup_{n: p^{\\prime}_{n,w}, p^{\\prime}_{n+1,w} \\leq X} p^{\\prime}_{n+1,w} - p^{\\prime}_{n,w}")]]

#text("where ")#mi("{p^{\\prime}_{1,w}, p^{\\prime}_{2,w}, \\dots}")#text(" are the elements of ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" in increasing order. We will show that almost surely one has ")#mi("{G^{\\prime}_w(X) \\geq (2e^{-\\gamma}-O(\\varepsilon)) \\log^2 X}")#text(" as ")#mi("{X \\rightarrow \\infty}")#text(", which leads to the above prediction by applying the modified Cramér model with this choice of ")#mi("{w}")#text(".")

#text("By Borel-Cantelli, it suffices to show that ")#mi("{G(X) \\geq (2e^{-\\gamma}-O(\\varepsilon)) \\log^2 X}")#text(" with probability ")#mi("{1-O_\\varepsilon(X^{-2})}")#text(" for sufficiently large ")#mi("{X}")#text(". Set ")#mi("{L := \\lfloor (1 - \\varepsilon) 2e^{-\\gamma} \\log^2 X \\rfloor}")#text(". Suppose we can find an natural number ")#mi("{k}")#text(" between ")#mi("{X/4W}")#text(" and ")#mi("{X/2W}")#text(" such that the numbers ")#mi("{kW+1,\\dots,kW+L}")#text(" all lie outside of ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(". It is easy to see that with probability ")#mi("{1-O_\\varepsilon(X^{-2})}")#text(" there is at least one element of ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" in ")#mi("{[X/2,X]}")#text(", and so we will have ")#mi("{G^{\\prime}_w(X) \\geq L}")#text(" in this case. So it suffices to show that with probability ")#mi("{1-O_\\varepsilon(X^{-2})}")#text(" there is at least one ")#mi("{k}")#text(" with ")#mi("{kW+1,\\dots,kW+L \\not \\in {\\mathcal P}^{\\prime}_w}")#text(".")

#text("Fix ")#mi("{k}")#text(". The key point is that an unusually large number of the elements of the sequence ")#mi("{kW+1,\\dots,kW+L}")#text(" are automatically excluded from ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" by virtue of having a common factor with ")#mi("{W}")#text("; probabilistic heuristics suggest that at least ")#mi("{\\frac{\\phi(W)}{W} L}")#text(" or so of the elements should be coprime, but the truth turns out to be closer to ")#mi("{\\frac{1}{2e^{-\\gamma}} \\frac{\\phi(W)}{W} L}")#text(", which is ultimately where the gain of ")#mi("{2e^{-\\gamma}}")#text(" over Conjecture ")#link(<tao-128c2622f546b0c06fb6>)[#text("7")]#text(" is coming from. Indeed, since ")#mi("{L \\leq w^3}")#text(" for ")#mi("{X}")#text(" large enough (and ")#mi("{\\varepsilon}")#text(" small), we see from the sieve of Erathosthenes that the only elements in this sequence which are coprime to ")#mi("{W}")#text(" are ")#mi("{kW + 1}")#text(", ")#mi("{kW + p}")#text(", for primes ")#mi("{w < p\\leq L}")#text(", and ")#mi("{kW+pq}")#text(" for primes ")#mi("{w < p \\leq q \\leq L}")#text(". Let us count how many such elements there are. From the prime number theorem there are at most")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\frac{L}{\\log L} = (1-\\varepsilon+o(1)) e^{-\\gamma} \\frac{\\log^2 X}{\\log\\log X}")]]

#text("elements of the form ")#mi("{kW+p}")#text(". From the prime number theorem again, the number of elements of the form ")#mi("{kW+pq}")#text(", noting that ")#mi("{w \\leq p \\leq \\sqrt{L}}")#text(" and ")#mi("{q \\leq L/p}")#text(", is at most")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\sum_{w \\leq p \\leq \\sqrt{L}} \\frac{L/p}{\\log(L/p)}.")]]

#text("By choice of ")#mi("{w}")#text(", we have ")#mi("{\\log(L/p) = (1+o(1)) \\log \\log X}")#text(" for ")#mi("{p}")#text(" in this sum, so by Mertens’ theorem this contribution is at most")

#align(center)[#tao-fit-display[#mitex("(1+o(1)) \\frac{L}{\\log\\log X} (\\log \\log \\sqrt{L} - \\log\\log w)")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("O( \\frac{\\log^2 X}{\\log\\log X \\log\\log\\log X} ).")]]

#text("Thus the total number of elements in ")#mi("{kW+1,\\dots,kW+L}")#text(" that are coprime to ")#mi("{W}")#text(" is at most ")#mi("{(1-\\varepsilon+o(1)) e^{-\\gamma} \\frac{\\log^2 X}{\\log\\log X}}")#text(". In the modified Cramér model, each of these elements has an independent probability of ")#mi("{\\frac{W}{\\phi(W) \\log(kW+b)} = (1+o(1)) \\frac{W}{\\phi(W) \\log X}}")#text(" of lying in ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(". From Mertens’ third theorem we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{W}{\\phi(W)}  & = \\prod_{p \\leq w} (1-\\frac{1}{p})^{-1}", block: true)



#tao-math(" & = (e^{\\gamma} + o(1)) \\log w", block: true)



#tao-math(" & = (e^\\gamma + o(1)) \\log\\log X", block: true)
]

#text("and so each of the ")#mi("{kW+b}")#text(" has an independent probability of ")#mi("{(e^\\gamma + o(1)) \\frac{\\log\\log X}{\\log X}}")#text(" of lying in ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(". The probability that none of the ")#mi("{kW-L,\\dots,kW+L}")#text(" lie in ")#mi("{{\\mathcal P}^{\\prime}_w}")#text(" is thus at least")

#align(center)[#tao-fit-display[#mitex("(1 - (e^\\gamma + o(1)) \\frac{\\log\\log X}{\\log X})^{(1-\\varepsilon+o(1)) e^{-\\gamma} \\frac{\\log^2 X}{\\log\\log X}}")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\exp( - (e^\\gamma + o(1)) \\frac{\\log\\log X}{\\log X} \\times (1-\\varepsilon+o(1)) e^{-\\gamma} \\frac{\\log^2 X}{\\log\\log X} )", block: true)



#tao-math(" & = X^{\\varepsilon-1+o(1)}.", block: true)
]

#text("These events are independent in ")#mi("{k}")#text(", and there are ")#mi("{\\gg \\frac{X}{W} = X^{1-o(1)}}")#text(" choices of ")#mi("{k}")#text(". Thus the probability that none of these events occurs is at most")

#align(center)[#tao-fit-display[#mitex("(1 - X^{\\varepsilon-1+o(1)})^{X^{1-o(1)}} = \\exp( - X^{\\varepsilon+o(1)} )")]]

#text("which is ")#mi("{O_\\varepsilon(X^{-2})}")#text(" as required. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Möbius pseudorandomness — ")]]

#text("We now turn to a somewhat different model, which is not based on modeling the set of primes ")#mi("{{\\mathcal P}}")#text(" directly, but rather the ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_function")[#text("Möbius function")]#text(" ")#mi("{\\mu: {\\bf N} \\rightarrow \\{-1,0,+1\\}}")#text(", which we have seen in ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" to be closely related to the distribution of the primes. One can also work with the closely related ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda: {\\bf N} \\rightarrow \\{-1,+1\\}}")#text(", if one wants to consider a function consisting of pure sign patterns with no zeroes.")

#text("One could adopt a Cramér type model for the Möbius or Liouville functions by replacing them with a random arithmetic function, or perhaps a random ")#emph[#text("multiplicative")]#text(" arithmetic function, taking values in ")#mi("{\\{-1,0,+1\\}}")#text(" or ")#mi("{\\{-1,+1\\}}")#text(". While one can certainly do this (see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=3056104")[#text("this paper of Harper")]#text(" for a recent study of such models), we will not directly build such models here, but instead focus on studying ")#emph[#text("linear statistics")]#text(" ")#metadata(none) <tao-2cda36e6665669fdf88e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\sum_{n \\leq x} \\mu(n) f(n)")]]



#text(" of the Möbius function (or analogous statistics ")#mi("{\\sum_{n \\leq x} \\lambda(n) f(n)}")#text(" for the Liouville function), tested against various arithmetic functions ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" of interest. The Möbius and Liouville statistics are closely related, with estimates on one of these sums usually leading quite quickly in practice to analogous estimates on the other sum:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Establish the identities")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\lambda(n) f(n) = \\sum_{d \\leq \\sqrt{x}} \\sum_{n \\leq x/d^2} \\mu(n) f(d^2 n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) f(n) = \\sum_{d \\leq \\sqrt{x}} \\mu(d) \\sum_{n \\leq x/d^2} \\lambda(n) f(d^2 n)")]]

#text("for any arithmetic function ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" and any ")#mi("{x > 0}")#text(". (In practice, due to the absolute convergence of ")#mi("{\\sum_d \\frac{1}{d^2}}")#text(", the summation in ")#mi("{d}")#text(" is fairly manageable, so as a first approximation the above identities are asserting that ")#mi("{\\sum_{n \\leq x} \\lambda(n) f(n)}")#text(" and ")#mi("{\\sum_{n \\leq x} \\mu(n) f(n)}")#text(" have comparable behaviour.)")
]

#text("Henceforth we focus solely on the Möbius statistics. Let us normalise ")#mi("{f}")#text(" to be bounded in size by ")#mi("{O(1)}")#text(", then we have the trivial bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) f(n) = O(x).")]]

#text("This bound can be sharp if ")#mi("{f}")#text(" oscillates with the same sign as ")#mi("{\\mu}")#text(", for instance if ")#mi("{f}")#text(" is equal to ")#mi("{\\mu}")#text(" itself (or to ")#mi("{\\lambda}")#text("). However, in most other situations we expect significant cancellation. One can informally (and imprecisely) summarise this principle as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Principle 19 (Möbius pseudorandomness principle)")]#text(" ")#metadata(none) <tao-1a891cd9b63fc7a60be5>#text(" Let ")#mi("{x}")#text(" be a large quantity, and let ")#mi("{f: [1,x] \\rightarrow {\\bf C}}")#text(" be a function bounded by ")#mi("{O(1)}")#text(", which is not deliberately chosen so as to oscillate with the same sign as ")#mi("{\\mu(n)}")#text(", and has “polynomial complexity” in some sense (e.g. it is defined using parameters that are natural numbers of size ")#mi("{O(x^{O(1)})}")#text(". Then we predict one of the following cancellation properties:")

#list(
[#text("(Weak pseudorandomness) One has ")#mi("{\\sum_{n \\leq x} \\mu(n) f(n) = o(x)}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(".")],
[#text("(Moderate pseudorandomness) One has ")#mi("{\\sum_{n \\leq x} \\mu(n) f(n) \\ll_A x \\log^{-A} x}")#text(" for any ")#mi("{A>0}")#text(".")],
[#text("(Strong pseudorandomness) One has ")#mi("{\\sum_{n \\leq x} \\mu(n) f(n) \\ll_\\varepsilon x^{1/2+\\varepsilon}}")#text(" for any ")#mi("{\\varepsilon>0}")#text(".")]
)

#text("Similarly if we replace ")#mi("{\\mu(n)}")#text(" by ")#mi("{\\mu(P(n))}")#text(" for some non-constant polynomial ")#mi("{P}")#text(" of degree ")#mi("{O(1)}")#text(" that takes natural number values on ")#mi("{[1,x]}")#text(", and which is of polynomial complexity in the sense that its coefficients are ")#mi("{O(x^{O(1)})}")#text(".")
]

#text("Note that unlike the Cramér random model, the Möbius pseudorandomness principle is not explicitly probabilistic in nature; the predictions here are completely deterministic in nature, and do not require any analysis of a random model. However, the principle is certainly ")#emph[#text("compatible")]#text(" with various random models for the Möbius function; for instance, if one models ")#mi("{\\mu}")#text(" by a random function from ")#mi("{{\\bf N}}")#text(" to ")#mi("{\\{-1,0,+1\\}}")#text(" that is independent of all functions ")#mi("{f}")#text(" for which one wishes to apply this principle, then one can justify the strong form of this pseudorandomness principle from the Chernoff inequality (or from arguments similar to that used to justify Prediction ")#link(<tao-064369b841ea15785385>)[#text("3")]#text(").")

#text("The above principle is imprecise, as we have not formally described what functions ")#mi("{f}")#text(" are admissible for this principle. One clean formalisation of the principle is the ")#emph[#text("Sarnak conjecture")]#text(", in which ")#mi("{f}")#text(" is generated by a zero-entropy dynamical system; see this ")#link("http://publications.ias.edu/sites/default/files/MobiusFunctionsLectures(2)_0.pdf")[#text("survey of Sarnak")]#text(" or ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("this previous blog post")]#text(" for more discussion. However, we will stick with the more imprecise form of Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(", as it covers some situations that are not strictly included in the Sarnak conjecture.")

#text("We have allowed for three levels of possible strength for this principle. The weak form of this principle can actually be established rigorously for a somewhat broad range of functions ")#mi("{f}")#text(", but is not particularly useful for applications concerning primes (basically because the primes are so sparse within the integers that any properties about primes one wants to discern will usually be lost in the ")#mi("{o(x)}")#text(" error). The moderate form of this principle can be rigorously established for a smaller range of functions than the weak form, but the error bounds are strong enough to make non-trivial predictions regarding the primes. The strong form of course gives the best predictions, but has not been proven unconditionally for any non-trivial ")#mi("{f}")#text(" of number-theoretic interest, although as noted above it is certainly compatible with Cramér type models for ")#mi("{\\mu}")#text(".")

#text("Setting ")#mi("{f=1}")#text(" in the above principle, we see that the strong Möbius pseudorandomness principle gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\ll_\\varepsilon x^{1/2+\\varepsilon}")]]

#text("which as noted in Exercise 33 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" was equivalent to the Riemann hypothesis. Using shifted polynomials ")#mi("{P(n) := n+x}")#text(" we also obtain the variants ")#metadata(none) <tao-0b6f395ca14ac202374d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\sum_{x \\leq n \\leq x+y} \\mu(n) \\ll_\\varepsilon y^{1/2+\\varepsilon}")]]



#text(" for ")#mi("{x = O(y^{O(1)})}")#text(". One could be more ambitious and extend this asymptotic to larger values of ")#mi("{x}")#text(", but Cramér-type probabilistic heuristics suggest that if ")#mi("{x}")#text(" is too large (of exponential size in ")#mi("{y}")#text("), then just from (pseudo)-random fluctuations in the sign patten of the Möbius function, one should eventually end up with a choice of ")#mi("{x}")#text(" in which all (or most) of the signs of ")#mi("{\\mu(n)}")#text(" for ")#mi("{x \\leq n \\leq x+y}")#text(" line up, leading to a failure of ")#link(<tao-0b6f395ca14ac202374d>)[#text("(14)")]#text(". However, the probabilistic heuristics indicate that ")#link(<tao-0b6f395ca14ac202374d>)[#text("(14)")]#text(" is a reasonable claim to make for ")#mi("{x}")#text(" restricted to be of polynomial size in ")#mi("{y}")#text(". More generally, by using the affine polynomials ")#mi("{P(n) := q(n + \\lfloor x/q \\rfloor)+b}")#text(" we arrive at the prediction ")#metadata(none) <tao-98840065352ce0fa6bfd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\sum_{x \\leq n \\leq x+y; n = b\\ (q)} \\mu(n) \\ll_{c,\\varepsilon} (y/q)^{1/2+\\varepsilon}")]]



#text(" when ")#mi("{q \\leq y^{1-c}}")#text(" and ")#mi("{x = O( y^{O(1)} )}")#text(" for some ")#mi("{c>0}")#text(".")

#text("At the other extreme, the weak form of the Möbius pseudorandomness principle gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) = o(n)")]]

#text("which as noted in Theorem 58 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" is equivalent to the prime number theorem. It should then be unsurprising that the moderate form of the conjecture gives a version of the prime number theorem with an error term better than ")#mi("{o(x)}")#text(", but worse than predicted by the Riemann hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 20")]#text(" ")#metadata(none) <tao-b11e23303e7d8bc69ecf>#text(" One has")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x + O_A( x \\log^{-A} x)")]]

#text("for any ")#mi("{x>2}")#text(" and ")#mi("{A>0}")#text(".")
]

#emph[#text("Proof:")]#text(" (Uses moderate Möbius pseudorandomness) We use the Dirichlet hyperbola method. Since ")#mi("{\\Lambda = \\mu * L}")#text(", we may write")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = \\sum_{d \\leq \\sqrt{x}} \\mu(d) \\sum_{m \\leq x/d} \\log m + \\sum_{m \\leq \\sqrt{x}} \\log m \\sum_{\\sqrt{x} < d \\leq x/m} \\mu(d).")]]

#text("From the moderate Möbius pseudorandomness principle (applied with ")#mi("{x}")#text(" replaced by ")#mi("{x/m}")#text(" and ")#mi("{\\sqrt{x}}")#text(", and then subtracting), we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\sqrt{x} < d \\leq x/m} \\mu(d) \\ll_A \\frac{x}{m} \\log^{-A} x")]]

#text("for any ")#mi("{A}")#text(", so the contribution of the second sum can be seen to be")

#align(center)[#tao-fit-display[#mitex("\\ll_A x \\log^{1-A} x \\times \\sum_{m \\leq \\sqrt{x}} \\frac{1}{m} \\ll_A x \\log^{2-A} x.")]]

#text("Meanwhile, from Stirling’s formula (see equation (8) of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{m \\leq x/d} \\log m = \\frac{x}{d} \\log \\frac{x}{d} - \\frac{x}{d} + O( \\log x )")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) = x ( (\\log x-1) \\sum_{d \\leq \\sqrt{x}} \\frac{\\mu(d)}{d} - \\sum_{d \\leq \\sqrt{x}} \\frac{\\mu(d) \\log d}{d} ) + O_A( x \\log^{-A} x ).")]]

#text("Now from further applications of the Möbius pseudorandomness principle and dyadic decomposition, we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{\\mu(d)}{d} = \\sum_d \\frac{\\mu(d)}{d^{1+\\varepsilon}} + O_A( \\log^{-A} x )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq \\sqrt{x}} \\frac{\\mu(d)\\log d}{d} = \\sum_d \\frac{\\mu(d) \\log d}{d^{1+\\varepsilon}} + O_A( \\log^{-A} x )")]]

#text("for sufficiently small ")#mi("{\\varepsilon>0}")#text(". But on noting that ")#tao-math("{\\frac{1}{\\zeta(s)} = s-1 + O(\\left|s-1\\right|)^2}", block: false)#text(" for ")#mi("{s}")#text(" near ")#mi("{1}")#text(", we see that ")#mi("{\\sum_d \\frac{\\mu(d)}{d^{1+\\varepsilon}}}")#text(" and ")#mi("{\\sum_d \\frac{\\mu(d) \\log d}{d^{1+\\varepsilon}}}")#text(" converge to ")#mi("{0}")#text(" and ")#mi("{-1}")#text(" respectively as ")#mi("{\\varepsilon \\rightarrow 0^+}")#text(", and the claim follows. ")#mi("\\Box")

#text("Of course, the above prediction already follows from the prime number theorem with classical error term (Corollary 39 of ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("). But one can achieve much more general results by using other weights ")#mi("{f}")#text(" than the constant weight ")#mi("{f(n)=1}")#text(" in Proposition ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(". For instance, since ")#mi("{\\mu(n+2)}")#text(" has no obvious propensity to oscillate with the same sign as ")#mi("{\\mu(n)}")#text(", we expect to have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n) \\mu(n+2) = o(x)")]]

#text("from the weak Möbius pseudorandomness principle; more generally, we expect the ")#link("http://www.ams.org/mathscinet-getitem?mr=177943")[#text("Chowla conjecture")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(n+h_1) \\dots \\mu(n+h_k) = o(x)")]]

#text("for any distinct ")#mi("{h_1,\\dots,h_k}")#text(", and more generally still that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\mu(P_1(n)) \\dots \\mu(P_k(n)) = o(x)")]]

#text("whenever ")#mi("{P_1,\\dots,P_k}")#text(" are distinct irreducible polynomials of degree ")#mi("{O(1)}")#text(" and coefficients ")#mi("{O(x^{O(1)})}")#text(" that attain natural number values when ")#mi("{n \\leq x}")#text(". Of course, if one assumes the moderate or strong Möbius pseudorandomness principle one can improve the decay rates ")#mi("{o(x)}")#text(" here to ")#mi("{O_A(x \\log^{-A} x)}")#text(" or ")#mi("{O_\\varepsilon(x^{1/2+\\varepsilon})}")#text(". Using such asymptotics, one can adapt the justification of Prediction ")#link(<tao-b11e23303e7d8bc69ecf>)[#text("20")]#text(" to recover asymptotics such as the twin prime asymptotic in Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 21 (Improved twin prime asymptotic, again)")]#text(" ")#metadata(none) <tao-aee711184ed95859b93e>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2) = 2\\Pi_2 x + O_A( x \\log^{-A} x )")]]

#text("for any ")#mi("{A>0}")#text(" and ")#mi("{x \\geq 2}")#text(", where ")#mi("{\\Pi_2}")#text(" is the twin prime constant from Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text(".")
]

#text("It is not difficult to see that this prediction implies Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text(", thus demonstrating some consistency between the modified Cramér model and the Möbius pseudorandomness heuristic. We give further examples of this consistency in the exercises below.")

#emph[#text("Proof:")]#text(" (uses moderate Möbius pseudorandomness) To avoid some minor complications later in the argument we will restrict the sum over ")#mi("{n}")#text(" to odd ")#mi("{n}")#text("; this is easily accomplished because the contribution of even ")#mi("{n}")#text(" is ")#mi("{O(1)}")#text(". For odd ")#mi("{n}")#text(" we have ")#metadata(none) <tao-669cd16498cb442216f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\Lambda = \\Lambda \\chi_0 = - (L \\mu \\chi_0) * \\chi_0,")]]



#text(" where ")#mi("{\\chi_0(n) := 1_{(n,2)=1}}")#text(" is the principal character of modulus ")#mi("{2}")#text(". We can then write the odd contribution to ")#mi("{\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+2)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("-\\sum_{d,m: dm \\leq x} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) \\Lambda(dm+2).")]]

#text("We first consider the contribution of those ")#mi("{d}")#text(" with ")#mi("{d \\geq x^{1/3}}")#text(" (say), which we write as")

#align(center)[#tao-fit-display[#mitex("-\\sum_{m \\leq x^{2/3}} \\sum_{x^{1/3} \\leq d \\leq x/m} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) \\Lambda(dm+2).")]]

#text("An application of moderate Möbius pseudorandomness (dividing ")#mi("{\\Lambda(dm+2)}")#text(" by ")#mi("{\\log x}")#text(" to make it bounded) gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{x^{1/3} \\leq d \\leq x/m} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) \\Lambda(dm+2) \\ll_A \\frac{x}{m} \\log^{-A} x")]]

#text("for any ")#mi("{A>0}")#text(", so the contribution of this case is acceptable. Thus it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("-\\sum_{d,m: dm \\leq x; d < x^{1/3}} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) \\Lambda(dm+2)")]]

#align(center)[#tao-fit-display[#mitex("= 2 \\Pi_2 x + O_A( x \\log^{-A} x ).")]]

#text("We write the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{2 < n \\leq x+2} \\Lambda(n) f(n-2)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("f(n) := - \\sum_{d|n: d < x^{1/3}} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(n/d).")]]

#text("We once again use the expansion ")#link(<tao-669cd16498cb442216f0>)[#text("(16)")]#text(" to write this as")

#align(center)[#tao-fit-display[#mitex("- \\sum_{d,m: 2 < dm \\leq x+2} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) f(dm-2).")]]

#text("Using moderate Möbius pseudorandomness again, the contribution of those ")#mi("{d}")#text(" with ")#mi("{d \\geq x^{1/3}}")#text(" is acceptable, so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("- \\sum_{d,m: 2 < dm \\leq x+2; d < x^{1/3}} \\mu(d) \\log(d) \\chi_0(d) \\chi_0(m) f(dm-2)")]]

#align(center)[#tao-fit-display[#mitex("= 2 \\Pi_2 x + O_A( x \\log^{-A} x )")]]

#text("for any ")#mi("{A > 0}")#text(". The left-hand side may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 < x^{1/3}} \\mu(d_1) \\log(d_1) \\chi_0(d_1) \\mu(d_2) \\log(d_2) \\chi_0(d_2)")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{m_1,m_2: d_1m_1+2 = d_2 m_2; d_1 m_1 \\leq x} 1.")]]

#text("As ")#mi("{d_1,d_2}")#text(" are restricted to be odd, we see that the inner sum vanishes unless ")#mi("{d_1}")#text(" and ")#mi("{d_2}")#text(" are coprime. In that case, we see from the Chinese remainder theorem the inner sum is counting the portion of an arithmetic progression of modulus ")#mi("{2d_1d_2}")#text(" that is less than or equal to ")#mi("{x}")#text(", so the inner sum is ")#mi("{\\frac{x}{2d_1 d_2} + O(1)}")#text(". The contribution of the ")#mi("{O(1)}")#text(" term is easily seen to be ")#mi("{O( x^{1/3} x^{1/3} \\log x \\log x)}")#text(", which is acceptable, so it suffices to show that ")#metadata(none) <tao-24f1512ec8629d33b645>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\sum_{d_1,d_2 < x^{1/3}: (d_1,d_2)=1} \\frac{\\mu(d_1) \\log(d_1) \\chi_0(d_1) \\mu(d_2) \\log(d_2) \\chi_0(d_2)}{d_1 d_2}")]]





#align(center)[#tao-fit-display[#mitex("= 4 \\Pi_2 + O_A( \\log^{-A} x )")]]

#text("for any ")#mi("{A>0}")#text(".")

#text("From moderate Möbius pseudorandomness (applied to either the ")#mi("{d_1}")#text(" or ")#mi("{d_2}")#text(" sum, depending on which of ")#mi("{N_1,N_2}")#text(" is larger) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{N_1 < d_1 \\leq 2N_1; N_2 < d_2 < 2N_2: (d_1,d_2)=1} \\frac{\\mu(d_1) \\log(d_1) \\chi_0(d_1) \\mu(d_2) \\log(d_2) \\chi_0(d_2)}{(d_1 d_2)^{1+\\varepsilon}}")]]

#align(center)[#tao-fit-display[#mitex("\\ll_A \\log^{-A} \\max(N_1,N_2)")]]

#text("for any ")#mi("{N_1,N_2 > 2}")#text(" and any ")#mi("{A>0}")#text(", ")#mi("{\\varepsilon > 0}")#text("; by dyadic decomposition we may thus approximate the left-hand side of ")#link(<tao-24f1512ec8629d33b645>)[#text("(17)")]#text(" up to acceptable errors by")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2: (d_1,d_2)=1} \\frac{\\mu(d_1) \\log(d_1) \\chi_0(d_1) \\mu(d_2) \\log(d_2) \\chi_0(d_2)}{(d_1 d_2)^{1+\\varepsilon}}")]]

#text("if ")#mi("{\\varepsilon>0}")#text(" is small enough. But this may be written as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial^2}{\\partial s_1 \\partial s_2} F(s_1,s_2)|_{s_1=s_2=1+\\varepsilon}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F(s_1,s_2) := \\sum_{d_1,d_2: (d_1,d_2)=1} \\frac{\\mu(d_1) \\chi_0(d_1) \\mu(d_2) \\chi_0(d_2)}{d_1^{s_1} d_2^{s_2}},")]]

#text("so it suffices to show that ")#metadata(none) <tao-2492c2a18ce9f3ca5b0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\frac{\\partial^2}{\\partial s_1 \\partial s_2} F(s_1,s_2)|_{s_1=s_2=1+\\varepsilon} = 4 \\Pi_2.")]]



#text(" Factoring the series over ")#mi("{d_1,d_2}")#text(" as an ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler product")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("F(s_1,s_2) = \\prod_{p>2} ( 1 - \\frac{1}{p^{s_1}} - \\frac{1}{p^{s_2}} ).")]]

#text("Comparing this with the Euler product ")#mi("{\\zeta(s)^{-1} = \\prod_p (1 - \\frac{1}{p^s})}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("F(s_1,s_2) = \\frac{G(s_1,s_2)}{\\zeta(s_1) \\zeta(s_2)}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("G(s_1,s_2) := (1-\\frac{1}{2^{s_1}})^{-1} (1-\\frac{1}{2^{s_2}})^{-1} \\prod_{p>2} \\frac{ 1 - \\frac{1}{p^{s_1}} - \\frac{1}{p^{s_2}} }{ 1 - \\frac{1}{p^{s_1}} - \\frac{1}{p^{s_2}} + \\frac{1}{p^{s_1+s_2}} }.")]]

#text("For ")#mi("{\\text{Re}(s_1), \\text{Re}(s_2) > 1}")#text(", the second product is absolutely convergent and defines a smooth function in ")#mi("{s_1,s_2}")#text(". Thus, ")#mi("{G}")#text(" extends smoothly to a neighbourhood of ")#mi("{s_1=s_2=1}")#text(", and the left-hand side of ")#link(<tao-2492c2a18ce9f3ca5b0a>)[#text("(18)")]#text(" can then be written (using the fact that ")#mi("{\\zeta}")#text(" has a simple pole of residue ")#mi("{1}")#text(" at ")#mi("{s=1}")#text(") as ")#mi("{G(1,1)}")#text(", which can be easily computed to equal ")#mi("{4\\Pi_2}")#text(" as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Goldbach conjecture again)")]#text(" ")#metadata(none) <tao-62ffde3795b5473db018>#text(" Use moderate Möbius pseudorandomness to give another justification of the Goldbach conjecture ")#link(<tao-3e399c46e9652dadde7e>)[#text("(9)")]#text("; indeed, establish the stronger asymptotic ")#metadata(none) <tao-afa6fcdcb790ba10652e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\sum_{n \\leq N} \\Lambda(n) \\Lambda(N-n)")]]





#align(center)[#tao-fit-display[#mitex("= 2 \\Pi_2 (\\prod_{p > 3: p|N} \\frac{p-1}{p-2}) N + O_A( N \\log^{-A} N)")]]

#text("for any even ")#mi("{N \\geq 2}")#text(" and ")#mi("{A>0}")#text(". (")#emph[#text("Hint:")]#text(" here, the condition of coprimality of ")#mi("{d_1,d_2}")#text(" has to be replaced by a more complicated condition involving ")#mi("{N}")#text(", and a denominator of ")#mi("{\\frac{1}{d_1 d_2}}")#text(" has to similarly be replaced by ")#mi("{\\frac{1}{[d_1,d_2]}}")#text(", where ")#mi("{[d_1,d_2]}")#text(" is the least common multiple of ")#mi("{d_1,d_2}")#text(". Nevertheless, this more complicated expression can still be handled by Euler products as previously. On the plus side, with these complications there is no additional need to introduce the character ")#mi("{\\chi_0}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Use moderate Möbius pseudorandomness to give another justification of the Hardy-Littlewood prime tuples conjecture ")#link(<tao-0369a36fe856043f6475>)[#text("(10)")]#text("; indeed, establish the stronger asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n+h_1) \\dots \\Lambda(n+h_k) = {\\mathfrak S} x + O_{A,h_1,\\dots,h_k}( x \\log^{-A} x )")]]

#text("for any ")#mi("{A>0}")#text(" and ")#mi("{x \\geq 2}")#text(", under the hypotheses of Exercise ")#link(<tao-49ee4fc7f82952169a0c>)[#text("13")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Use moderate Möbius pseudorandomness to justify the claim")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x: n = a\\ (q)} \\Lambda(n) = (1 + O_{c,A}(\\log^{-A} x )) \\frac{x}{\\phi(q)}")]]

#text("for any primitive residue class ")#mi("{a\\ (q)}")#text(", ")#mi("{x \\geq 2}")#text(", and ")#mi("{A > 0}")#text(", assuming that ")#mi("{q \\leq x^{1/2-c}}")#text(" for some ")#mi("{c>0}")#text(". What goes wrong when ")#mi("{q}")#text(" is larger than ")#mi("{x^{1/2}}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" A Cramér type model (using ")#mi("{q}")#text(" in place of ")#mi("{W}")#text(") predicts the same asymptotic with ")#mi("{q}")#text(" as large as ")#mi("{x^{1-c}}")#text(", rather than ")#mi("{x^{1/2-c}}")#text(". This exposes some limitations of the Möbius pseudorandomness principle as formulated in Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(", in that it is not cannot obtain some of the asymptotics that Cramér type models can reach, particularly when trying to detect primes in very sparse sets of integers. (For similar reasons, Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(" has trouble recovering the asymptotic in Exercise ")#link(<tao-dc81b1d371a4072be7fc>)[#text("15")]#text("; it also does not appear to be an appropriate tool for predicting the size ")#mi("{G(X)}")#text(" of the largest prime gaps.) One can address this weakness of Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(" by assuming a stronger version of pseudorandomness, in which the function ")#mi("{f}")#text(" is allowed to be concentrated on a sparse set of integers, rather than being uniformly bounded by ")#mi("{O(1)}")#text(", but we will not detail this variant here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" ")#metadata(none) <tao-8fc21da610761c189aa4>#text(" Using the above sorts of arguments, one might expect that square root cancellation for Möbius correlations ")#mi("{\\sum_{n \\leq x} \\mu(n) f(n)}")#text(" (i.e., the strong Möbius pseudorandomness conjecture) might lead to square root error terms for von Mangoldt correlations ")#mi("{\\sum_{n \\leq x} \\Lambda(n) f(n)}")#text(". However, this is not always the case. For instance, in Appendix C of ")#link("http://www.ams.org/mathscinet-getitem?mr=1828743")[#text("this paper of Iwaniec, Luo, and Sarnak")]#text(", the strong Möbius pseudorandomness conjecture is used to predict an unusual non-square-root cancellation")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\Lambda(n) f(n) \\eta(n/x) = (c+o(1)) x^{3/4}")]]

#text("for some non-zero ")#mi("{c}")#text(", where ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a smooth compactly supported function and")

#align(center)[#tao-fit-display[#mitex("f(n) := n^{-11/2} \\tau(n) e(-2\\sqrt{n})")]]

#text("is a normalised modulated version of the ")#link("http://en.wikipedia.org/wiki/Ramanujan_tau_function")[#text("Ramanujan tau function")]#text(" ")#mi("{\\tau}")#text(" (not to be confused with the divisor function ")#mi("{1*1}")#text(", which we have called ")#mi("{\\tau}")#text(" in previous notes). This asymptotic does not seem to be easily explainable by a Cramér type model, but is still believed to be accurate, as even the strong Möbius pseudorandomness conjecture appears to be quite reliable in practice (but see the caveat below for the function field analogue).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" A huge portion of analytic number theory over the natural numbers has a counterpart in the ")#emph[#text("function field setting")]#text(", in which the ring of integers ")#mi("{{\\bf Z}}")#text(" is replaced with the ring ")#mi("{F[t]}")#text(" of polynomials over some finite field ")#mi("{F}")#text(", with the notion of primality, Möbius function, etc. modified accordingly. As it turns out, in that setting there is a modification that needs to be made to the Möbius pseudorandomness principle, due to biases in the Möbius function ")#mi("{\\mu(P(n))}")#text(" applied to polynomials ")#mi("{P: F[t] \\rightarrow F[t]}")#text(" in this ring, particularly when the characteristic of ")#mi("{F}")#text(" divides the degree of ")#mi("{P}")#text(". For instance, in characteristic three, the Möbius function of the degree ")#mi("{12}")#text(" polynomial ")#mi("{P(n) = n^{12} + (t+1) n^6 + t^4}")#text(" is twice as likely to be ")#mi("{-1}")#text(" as it is to be ")#mi("{+1}")#text(" (see Example 3.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2379779")[#text("this paper of Conrad, Conrad, and Gross")]#text("). Similarly, in an arbitrary finite field ")#mi("{F}")#text(", the Möbius function of the degree ")#tao-math("{4\\left|F\\right|}", block: false)#text(" polynomial ")#tao-math("{P(n) = n^{4\\left|F\\right|} + t^{2\\left|F\\right|-1}}", block: false)#text(" is never ")#mi("{-1}")#text(", despite ")#mi("{P}")#text(" being irreducible. We refer the reader to the Conrad-Conrad-Gross paper for further discussion of these biases, and how to adjust the pseudorandomness principle to account for them; but we will not discuss the function field setting further in these notes.")
]

#heading(level: 1)[#strong[#text(" — 3. Equidistribution of residues — ")]]

#text("We now discuss a model closely related to the Cramér model, concerning the residue classes ")#mi("{n\\ (q)}")#text(" of a randomly chosen large number ")#mi("{n}")#text(" with respect to various residues ")#mi("{q}")#text(". For sake of discussion, let us select ")#mi("{n}")#text(" uniformly at random from the natural numbers less than ")#mi("{x}")#text(", for some large quantity ")#mi("{x}")#text(". Each residue class ")#mi("{a\\ (q)}")#text(" then occupies ")#mi("{\\frac{x}{q}+O(1)}")#text(" possible values of ")#mi("{n}")#text(", so ")#mi("{n\\ (q)}")#text(" is equal to ")#mi("{a\\ (q)}")#text(" with probability ")#mi("{\\frac{1}{q} + O(\\frac{1}{x})}")#text(". Thus, for ")#mi("{x}")#text(" large compared to ")#mi("{q}")#text(", the residue class ")#mi("{n\\ (q)}")#text(" is approximately uniformly distributed in the cyclic group ")#mi("{{\\bf Z}/q{\\bf Z}}")#text(".")

#text("Now we consider the ")#emph[#text("joint")]#text(" distribution of the residue classes ")#mi("{n\\ (q)}")#text(" as ")#mi("{q}")#text(" varies. From the Chinese remainder theorem, if ")#mi("{q_1}")#text(" and ")#mi("{q_2}")#text(" are coprime, then the residue class ")#mi("{n\\ (q_1 q_2)}")#text(" is completely determined by the residue classes ")#mi("{n\\ (q_1)}")#text(" and ")#mi("{n\\ (q_2)}")#text(". Thus, in principle at least, we only need to consider the joint distribution of ")#mi("{n\\ (q)}")#text(" for moduli ")#mi("{q}")#text(" that are prime powers ")#mi("{q=p^j}")#text(". To simplify the discussion, we will just consider residue classes ")#mi("{n\\ (p)}")#text(" for ")#mi("{p}")#text(" prime. This is already enough information (in principle, at least) for many questions about the primes. For instance, to determine whether a number ")#mi("{n}")#text(" between ")#mi("{\\sqrt{x}}")#text(" and ")#mi("{x-2}")#text(" is a twin prime (in the sense that ")#mi("{n,n+2}")#text(" are both prime), it is necessary and sufficient that ")#mi("{n\\ (p)}")#text(" avoids the residue classes ")#mi("{0, -2\\ (p)}")#text(" for all ")#mi("{p \\leq \\sqrt{x}}")#text(", thanks to the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(".")

#text("If ")#mi("{p_1,\\dots,p_k}")#text(" are distinct primes with product ")#mi("{p_1 \\dots p_k}")#text(" much less than ")#mi("{x}")#text(", then by the previous discussion, ")#mi("{n\\ (p_1 \\dots p_k)}")#text(" is approximately uniformly distributed in ")#mi("{{\\bf Z}/p_1 \\dots p_k {\\bf Z}}")#text(", and so by the Chinese remainder theorem, the residue classes ")#mi("{n\\ (p_1), \\dots, n\\ (p_k)}")#text(" are approximately jointly independent. But what happens in the opposite case, when ")#mi("{p_1 \\dots p_k}")#text(" is much larger than ")#mi("{x}")#text("? Then ")#mi("{n\\ (p_1 \\dots p_k)}")#text(" is not close to uniformly distributed in ")#mi("{{\\bf Z}/p_1 \\dots p_k {\\bf Z}}")#text(" in any strong sense (such as in the ")#link("http://en.wikipedia.org/wiki/Total_variation_distance_of_probability_measures")[#text("total variation")]#text(" sense), since it only takes ")#mi("{O(x)}")#text(" of the ")#mi("{p_1 \\dots p_k}")#text(" possible values in ")#mi("{{\\bf Z}/p_1 \\dots p_k {\\bf Z}}")#text(". However, one can still hope for the random variables ")#mi("{n\\ (p_1), \\dots, n\\ (p_k)}")#text(" to be approximately independent in some ")#emph[#text("weak")]#text(" sense, in that various probabilistic statistics of these random variables approximately match what they would be if these random variables were genuinely independent.")

#text("For instance, suppose one is interested in predicting the number ")#mi("{\\pi(x,w)}")#text(" of natural numbers less than or equal to ")#mi("{x}")#text(" which are ")#emph[#mi("{w}")#text("-rough")]#text(" in the sense that they are not divisible by any prime ")#mi("{p}")#text(" less than ")#mi("{w}")#text(", for some ")#mi("{1 \\leq w \\leq x}")#text(". If we pick ")#mi("{n}")#text(" uniformly at random from the natural numbers up to ")#mi("{x}")#text(", then the probability that ")#mi("{n}")#text(" is not divisible by any given prime ")#mi("{p \\leq w}")#text(" (i.e., that ")#mi("{n \\neq 0\\ (p)}")#text(") is approximately ")#mi("{1-\\frac{1}{p}}")#text(". Assuming that the residue classes ")#mi("{n\\ (p)}")#text(" behave as if they are independent, we then expect that the probability that ")#mi("{n}")#text(" is not divisible by ")#emph[#text("any")]#text(" of the primes ")#mi("{p \\leq w}")#text(" should be approximately ")#mi("{\\prod_{p \\leq w} (1-\\frac{1}{p})}")#text(". Thus we arrive at the naive prediction ")#metadata(none) <tao-806b85f40582a236df79>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\pi(x,w) \\approx x \\prod_{p \\leq w} (1 - \\frac{1}{p}).")]]



#text(" As it turns out, this prediction works well for small ")#mi("{w}")#text(", but becomes inaccurate when ")#mi("{w}")#text(" is very large. Consider for instance the case ")#mi("{\\sqrt{x} \\leq w \\leq x}")#text(". The sieve of Erathosthenes then tells us that ")#mi("{\\pi(x,w)}")#text(" consists precisely of the primes ")#mi("{p}")#text(" with ")#mi("{w < p \\leq x}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\pi(x,w) = \\pi(x) - \\pi(w).")]]

#text("If we have ")#mi("{w = o(x)}")#text(" (in the asymptotic regime ")#mi("{x \\rightarrow \\infty}")#text("), then the prime number theorem tells us that ")#metadata(none) <tao-d31d8844e59384352a4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\pi(x,w) = (1+o(1)) \\frac{x}{\\log x}.")]]



#text(" In contrast, Mertens’ third theorem (Theorem 42 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(") gives ")#metadata(none) <tao-1c185a74fb6d1883c233>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("x \\prod_{p \\leq w} (1 - \\frac{1}{p}) = (1+o(1)) \\frac{x}{e^\\gamma \\log w}.")]]



#text(" Thus we see that the naive independence prediction is incorrect in the range ")#mi("{\\sqrt{x} \\leq w \\leq o(x)}")#text(" (except when ")#mi("{w}")#text(" is close to ")#mi("{x^{1/e^\\gamma}}")#text(", but one should view this as a numerical coincidence); this failure is sometimes known as the ")#emph[#text("Mertens paradox")]#text(". In retrospect, one can see this after noting that for any two distinct primes ")#mi("{\\sqrt{x} \\leq p,q \\leq x}")#text(", the events that ")#mi("{n=0\\ (p)}")#text(" and ")#mi("{n=0\\ (q)}")#text(" are not independent, since they can hold separately, but not simultaneously. There is a similar issue for slightly smaller primes: for instance, if ")#mi("{x^{1/3} \\leq p_1,p_2,p_3 < \\sqrt{x}}")#text(", the events ")#mi("{n = 0\\ (p_1)}")#text(", ")#mi("{n = 0\\ (p_2)}")#text(", ")#mi("{n = 0\\ (p_3)}")#text(" can hold separately, but not simultaneously. As such, one should expect the naive independence prediction to typical fail when ")#mi("{w \\approx x^{1/u}}")#text(" for a bounded exponent ")#mi("{u = O(1)}")#text(". This is indeed the case, as worked out in the following exercise (which is the “dual” of Exercise 39 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Density of rough numbers)")]#text(" ")#metadata(none) <tao-f811eb5c56eeb90a48b9>#text(" Let ")#mi("{x}")#text(" be an asymptotic parameter tending to infinity.")

#list(
[#text("(i) Show that for any fixed ")#mi("{u>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\pi( x, x^{1/u} ) = (\\omega(u)+o(1)) \\frac{x}{\\log x^{1/u}}")]]

#text("where the ")#link("http://mathworld.wolfram.com/BuchstabFunction.html")[#text("Buchstab function")]#text(" ")#mi("{\\omega(u)}")#text(" is defined by the series")

#align(center)[#tao-fit-display[#mitex("\\omega(u) = \\frac{1_{1 < u}}{u} + \\sum_{j=2}^\\infty \\frac{1}{j!} \\int_{[1,+\\infty)^{j-1}} 1_{t_1+\\dots+t_{j-1} \\leq u-1} \\frac{dt_1 \\dots dt_{j-1}}{t_1 \\dots t_j}")]]

#text("with the convention that ")#mi("{t_j = u - t_1 - \\dots - t_{j-1}}")#text(". (Note that for any given ")#mi("{u}")#text(" that only finitely many of the summands are non-zero; one can also view the first term as the ")#mi("{j=1}")#text(" term of the summation after carefully working out what zero-dimensional spaces and empty products evaluate to).")],
[#text("(ii) (Delay-differential equation) Show that ")#mi("{\\omega}")#text(" is continuous on ")#mi("{(0,+\\infty)}")#text(" except at ")#mi("{u=1}")#text(", continuously differentiable except at ")#mi("{u=1,2}")#text(", equals ")#mi("{0}")#text(" for ")#mi("{0 \\leq u \\leq 1}")#text(" and obeys the equation")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{du} \\omega(u) = \\frac{1}{u} (\\omega(u-1)-\\omega(u))")]]

#text("for ")#mi("{u > 1}")#text(" with ")#mi("{u \\neq 2}")#text(". Give a heuristic justification for this equation by considering how ")#mi("{\\pi(x,x^{1/u})}")#text(" varies with respect to small perturbations of ")#mi("{u}")#text(".")],
[#text("(iii) (Wirsing integral equation) Show that")

#align(center)[#tao-fit-display[#mitex("u \\omega(u) = 1_{(1,\\infty)}(u) + \\int_0^u 1_{(1,\\infty)}(t) \\omega(u-t)\\ dt.")]]

#text("Give a heuristic justification for this equation by starting with a ")#mi("{z}")#text("-rough number ")#mi("{n \\in [1,x]}")#text(" and considering a factor ")#mi("{n/p}")#text(", where ")#mi("{p}")#text(" is a prime factor of ")#mi("{n}")#text(" chosen at random with probability ")#mi("{j \\frac{\\log p}{\\log n}}")#text(" (if ")#mi("{p}")#text(" occurs ")#mi("{j}")#text(" times in the prime factorisation of ")#mi("{n}")#text(").")],
[#text("(iv) (Laplace transform) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\omega(u) e^{-su}\\ du = \\exp( \\int_s^\\infty \\frac{e^{-t}}{t}\\ dt ) - 1")]]

#text("for all ")#mi("{s > 0}")#text(".")],
[#text("(v) (Duality with Dickman function) If ")#mi("{\\rho}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Dickman_function")[#text("Dickman function")]#text(" from Exercise 39 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(", show that")

#align(center)[#tao-fit-display[#mitex("1 = \\rho(u) + \\int_0^u \\rho(t) \\omega(u-t)\\ dt")]]

#text("for all ")#mi("{u>0}")#text(".")],
[#text("(vi) (Asymptotic constancy) For ")#mi("{A>0}")#text(", show that ")#mi("{\\frac{d}{du} \\omega(u) \\ll_A u^{-A}}")#text(" for all sufficiently large ")#mi("{u}")#text(". Conclude in particular that ")#mi("{\\omega(u)}")#text(" converges to a limit as ")#mi("{u \\rightarrow \\infty}")#text(".")],
[#text("(vii) (Limiting value) Show that ")#mi("{\\omega(u)}")#text(" converges to ")#mi("{e^{-\\gamma}}")#text(" as ")#mi("{u \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" Use (iv) with ")#mi("{s}")#text(" small, combined with (vi).)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" One can model the dependencies of the events ")#mi("{n = 0\\ (p)}")#text(" for large ")#mi("{p}")#text(" more accurately by using a more sophisticated model than a jointly independent model, namely a ")#emph[#text("Poisson-Dirichlet process")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2013/09/21/the-poisson-dirichlet-process-and-large-prime-factors-of-a-random-number/")[#text("this previous post")]#text(". This model can be used for instance to recover for instance the Dickman and Buchstab statistics for smooth and rough numbers respectively, thus also helps explain the ")#mi("{e^\\gamma}")#text(" factor appearing in ")#link(<tao-1c185a74fb6d1883c233>)[#text("(22)")]#text(". However, we will not discuss this process further here.")
]

#text("Parts (i) and (vii) of Exercise ")#link(<tao-f811eb5c56eeb90a48b9>)[#text("28")]#text(" suggest that the naive prediction ")#link(<tao-806b85f40582a236df79>)[#text("(20)")]#text(" is in fact quite accurate for ")#mi("{w = x^{1/u}}")#text(" with ")#mi("{u}")#text(" large, even if it becomes inaccurate when ")#mi("{u}")#text(" is small. We now informally generalise this to a heuristic:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Heuristic 30 (Equidistribution of residues)")]#text(" ")#metadata(none) <tao-62cd2779311867077768>#text(" Let ")#mi("{w = x^{o(1)}}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(", and let ")#mi("{n}")#text(" be chosen uniformly at random from the numbers up to ")#mi("{x}")#text(". Then the residues ")#mi("{n\\ (p)}")#text(" for ")#mi("{p \\leq w}")#text(" behave “as if” they were independent random variables. Similarly for other “reasonable” probability distributions on natural numbers up to ")#mi("{x}")#text(" (e.g. the uniform distribution on natural numbers between ")#mi("{x/2}")#text(" and ")#mi("{x}")#text("). A similar heuristic can apply for ")#mi("{w}")#text(" as large as ")#mi("{x^{1/u}}")#text(" if one is prepared to accept some error terms which go to zero as ")#mi("{u}")#text(" goes to infinity.")
]

#text("In later notes, we will develop the basics of ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(", which provides a number of rigorous interpretations of the above heuristic (such as the ")#link("http://en.wikipedia.org/wiki/Fundamental_lemma_of_sieve_theory")[#text("fundamental lemma of sieve theory")]#text(").")

#text("Because the heuristic stops working for ")#mi("{w}")#text(" as large as ")#mi("{\\sqrt{x}}")#text(" or ")#mi("{x}")#text(", one cannot use Heuristic ")#link(<tao-62cd2779311867077768>)[#text("30")]#text(" directly to count primes to make predictions for problems such as Landau’s problems. However, one can input this heuristic into the modified Cramér model (Model ")#link(<tao-26d98f7f4115af654379>)[#text("10")]#text("), effectively giving the ability to take the ")#mi("{w}")#text(" parameter in that model to be as large as ")#mi("{x^{o(1)}}")#text(". (But, as mentioned before, in many applications the precise choice of the ")#mi("{w}")#text(" parameter is not terribly important, so long as it is eventually taken to go to infinity.)")

#text("Alternatively, by stopping the sieve of Eratosthenes early, one can use Heuristic ")#link(<tao-62cd2779311867077768>)[#text("(30)")]#text(" to predict ")#emph[#text("upper bounds")]#text(" for various prime statistics. For instance, let us return to the problem of counting prime twins ")#mi("{p, p+2}")#text(" with ")#mi("{p \\leq x}")#text(". We select a natural number ")#mi("{n}")#text(" uniformly between ")#mi("{\\sqrt{x}}")#text(" and ")#mi("{x-2}")#text(" and ask for the probability that ")#mi("{n,n+2}")#text(" are simultaneously prime (the contribution of those primes below ")#mi("{\\sqrt{x}}")#text(" is negligible). By the sieve of Eratosthenes, this is equivalent to requiring that ")#mi("{n}")#text(" avoid the residue classes ")#mi("{0\\ (p)}")#text(", ")#mi("{-2\\ (p)}")#text(" for all ")#mi("{p \\leq \\sqrt{x}}")#text(". We cannot apply the heuristic all the way to ")#mi("{\\sqrt{x}}")#text(", so let us stop at ")#mi("{w = x^\\varepsilon}")#text(" for some small ")#mi("{\\varepsilon}")#text(", with the assumption that the error terms will be somehow manageable if ")#mi("{\\varepsilon}")#text(" is small enough. For each ")#mi("{p \\leq w}")#text(", the probability that ")#mi("{n}")#text(" avoids both of ")#mi("{0\\ (p)}")#text(" and ")#mi("{-2\\ (p)}")#text(" is ")#mi("{1-\\frac{2}{p}}")#text(", except when ")#mi("{p=2}")#text(", where the probability is ")#mi("{\\frac{1}{2}}")#text(". Thus, by Heuristic ")#link(<tao-62cd2779311867077768>)[#text("30")]#text(", the probability that ")#mi("{n}")#text(" avoids ")#mi("{0, -2\\ (p)}")#text(" for all ")#mi("{p \\leq w}")#text(" should be approximately")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\prod_{2 < p \\leq w} (1 - \\frac{2}{p}).")]]

#text("Writing ")#mi("{1-\\frac{2}{p}}")#text(" as ")#mi("{(1 - \\frac{1}{(p-1)^2}) (1 - \\frac{1}{p})^2}")#text(" and recalling the twin prime constant ")#link(<tao-68d3ff4b0ff6aa3eae88>)[#text("(7)")]#text(", this probability is approximately")

#align(center)[#tao-fit-display[#mitex("2 \\Pi_2 \\prod_{p \\leq w} (1 - \\frac{1}{p})^2")]]

#text("which by Mertens’ third theorem is approximately")

#align(center)[#tao-fit-display[#mitex("\\frac{2 \\Pi_2}{(e^\\gamma \\log w)^2},")]]

#text("leading to an upper bound of approximately ")#mi("{2\\Pi_2 \\frac{x}{(e^\\gamma \\log w)^2}}")#text(" for the number of twin primes up to ")#mi("{x}")#text(". As with the problem of counting ")#mi("{\\pi(x,z)}")#text(", this upper bound fails to recover the predicted asymptotic from Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text(" if one naively sets ")#mi("{w}")#text(" equal to ")#mi("{\\sqrt{x}}")#text(" or ")#mi("{x}")#text(", but it is in some sense off “by the same factor” that ")#link(<tao-1c185a74fb6d1883c233>)[#text("(22)")]#text(" is off from ")#link(<tao-d31d8844e59384352a4d>)[#text("(21)")]#text(". In particular, if one formally sets ")#mi("{w}")#text(" equal to the “magic” value of ")#mi("{x^{1/e^\\gamma}}")#text(", one recovers Prediction ")#link(<tao-c27c2e4875b4c241cf3a>)[#text("11")]#text("; the use of this magic value has been ")#link("http://www.ams.org/mathscinet-getitem?mr=104639")[#text("proposed by Pólya")]#text(" as a computational trick for arriving at suitable predictions for prime asymptotics up to ")#mi("{x}")#text(", though I would be cautious about using this choice of ")#mi("{w}")#text(" blindly. One can perform an analogous upper bound analysis to the problems considered in Exercises ")#link(<tao-1f8f4b311ca78f1ffcfd>)[#text("12")]#text(", ")#link(<tao-49ee4fc7f82952169a0c>)[#text("13")]#text(", ")#link(<tao-dc81b1d371a4072be7fc>)[#text("15")]#text("; we leave this as an exercise to the interested reader.")

#heading(level: 1)[#strong[#text(" — 4. The pair correlation conjecture and the GUE hypothesis — ")]]

#metadata(none) <tao-119c047bc7ec0180a1f3>

#text("We now turn to what appears at first glance to be a completely different way to model the primes, via the explicit formula connecting primes with zeroes of the zeta function.")

#text("To simplify the exposition, and to obtain the strongest results and predictions, we will work in this section under the assumption of the ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" (Conjecture 28 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text("), which from the functional equation (Theorem 1 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(") is equivalent to the assertion that all the non-trivial zeroes ")#mi("{\\rho}")#text(" of the Riemann zeta function ")#mi("{\\zeta}")#text(" lie on the critical line ")#mi("{\\{ s: \\text{Re}(s) = \\frac{1}{2} \\}}")#text(". To emphasise this fact, we will write such zeroes as ")#mi("{\\rho = \\frac{1}{2} + i \\gamma}")#text(" for various real numbers ")#mi("{\\gamma}")#text(", known as the ")#emph[#text("ordinates")]#text(" of non-trivial zeroes of the zeta function. All sums over ")#mi("{\\gamma}")#text(" (or ")#mi("{\\gamma_0, \\gamma_1}")#text(", etc.) are understood to be over such ordinates. For the purposes of notational simplicity, we will also assume that the zeroes of ")#mi("{\\zeta}")#text(" are simple, so the ordinates are all distinct; it is not difficult to modify the discussion and notation below to take into account the (unlikely) possibility of repeated zeroes, but we will leave this as an exercise to the interested reader.")

#text("The explicit formula connects primes with the ordinates ")#mi("{\\gamma}")#text(". There are many equivalent ways to express this formula, but we will begin with the smoothed explicit formula (Exercise 46 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text("), which asserts that")

#tao-aligned(keep: true)[


#tao-math("\\sum_n \\Lambda(n) g(\\log n)  & = \\hat g(-i) - \\sum_\\gamma \\hat g(-i/2 + \\gamma)", block: true)



#tao-math(" & - \\sum_n \\hat g(2in)", block: true)
]

#text("for any smooth compactly supported ")#mi("{g}")#text(" supported on ")#mi("{(0,+\\infty)}")#text(", where ")#mi("{\\hat g(t) := \\int_{\\bf R} g(u) e^{itu}\\ du}")#text(" is the Fourier-Laplace transform. (One could also use the Riemann-Weil explicit formula, see Exercise 47 of ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text(", which has the advantage of not requiring ")#mi("{g}")#text(" to be supported on the positive real axis.) We can get rid of the ")#mi("{\\hat g(-i)}")#text(" and ")#mi("{\\hat g(2in)}")#text(" factors and the inconvenient shift of ")#mi("{-i/2}")#text(" in the sum over ordinates by introducing the normalised signed measure ")#mi("{\\mu}")#text(" on the real line defined by ")#metadata(none) <tao-4a5b0555fa2b2431b30c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\int_{\\bf R} g(u)\\ d\\mu(u) := \\sum_n \\frac{\\Lambda(n)}{\\sqrt{n}} g(\\log n)")]]





#align(center)[#tao-fit-display[#mitex("- \\int_0^\\infty g(u) (e^{u/2} - \\sum_n e^{-(2n+1/2) u})\\ du,")]]

#text("and then the explicit formula (after replacing ")#mi("{g(u)}")#text(" by ")#mi("{g(u) e^{-u/2}}")#text(") becomes ")#metadata(none) <tao-970ecf6c8d39032bff03>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\int_{\\bf R} g(u)\\ d\\mu(u) = - \\sum_\\gamma \\hat g(\\gamma)")]]



#text(" for any smooth compactly supported ")#mi("{g}")#text(" supported on ")#mi("{(0,+\\infty)}")#text(". This implies a multidimensional analogue ")#metadata(none) <tao-5c639995edb195ce0520>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\int_{{\\bf R}^k} g( u_1,\\dots, u_k) d\\mu(u_1) \\dots d\\mu(u_k) = (-1)^k \\sum_{\\gamma_1,\\dots,\\gamma_k} \\hat g(\\gamma_1,\\dots,\\gamma_k)")]]



#text(" of the explicit formula, where ")#mi("{k \\geq 1}")#text(" and ")#mi("{g: {\\bf R}^k \\rightarrow {\\bf C}}")#text(" is a smooth compactly supported function supported on ")#mi("{(0,+\\infty)^k}")#text(", and ")#mi("{\\hat g}")#text(" is now the multidimensional Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat g(t_1,\\dots,t_k) := \\int_{{\\bf R}^k} g(u_1,\\dots,u_k) e^{i(t_1u_1+\\dots+t_ku_k)}\\ du_1 \\dots du_k.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Derive ")#link(<tao-5c639995edb195ce0520>)[#text("(25)")]#text(" from ")#link(<tao-970ecf6c8d39032bff03>)[#text("(24)")]#text(". (")#emph[#text("Hint:")]#text(" first handle the case when the multidimensional function ")#mi("{g: {\\bf R}^k \\rightarrow {\\bf C}}")#text(" decomposes as a finite linear combination of tensor products of one-dimensional smooth compactly supported functions supported on ")#mi("{(0,+\\infty)}")#text(", and use the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(" and a limiting argument to then obtain the general case. See ")#link("http://www.ams.org/mathscinet-getitem?mr=1395406")[#text("this paper of Rudnick and Sarnak")]#text(" for a more general version of ")#link(<tao-5c639995edb195ce0520>)[#text("(25)")]#text(".")
]

#text("One can use ")#link(<tao-5c639995edb195ce0520>)[#text("(25)")]#text(" with various choices of ")#mi("{g}")#text(" to relate various correlations between the primes to correlations between ordinates. To illustrate this, let us apply ")#link(<tao-5c639995edb195ce0520>)[#text("(25)")]#text(" with ")#mi("{k=2}")#text(" and ")#mi("{g}")#text(" equal to the function")

#align(center)[#tao-fit-display[#mitex("g( u_1, u_2 ) := \\eta( \\frac{u_1}{\\log T} ) f( T(u_2-u_1) )")]]

#text("for some ")#mi("{T>2}")#text(" (which we view as an asymptotic parameter going to infinity), and ")#mi("{\\eta: {\\bf R} \\rightarrow {\\bf C}, f: {\\bf R} \\rightarrow {\\bf C}}")#text(" are fixed smooth compactly supported functions with ")#mi("{\\eta}")#text(" supported on ")#mi("{(0,\\infty)}")#text("; it will be convenient to normalise ")#mi("{f(0)=1}")#text(". This may seem like a somewhat arbitrary choice of test function ")#mi("{g}")#text(", but informally this choice is measuring a smoothed pair correlation between primes ")#mi("{p, q}")#text(" of size ")#mi("{T^{O(1)}}")#text(" which differ by a multiplicative factor of ")#mi("{1+O(1/T)}")#text(".")

#text("With this choice of ")#mi("{g}")#text(", ")#link(<tao-5c639995edb195ce0520>)[#text("(25)")]#text(" becomes (after a routine change of variables) ")#metadata(none) <tao-4d2f4b668cfc48e6059d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\frac{1}{\\log^2 T} \\int_{{\\bf R}^2} \\eta( \\frac{u_1}{\\log T} ) f( T(u_1-u_2) )\\ d\\mu(u_1) d\\mu(u_2)")]]





#align(center)[#tao-fit-display[#mitex("= \\frac{1}{T \\log T} \\sum_{\\gamma_1,\\gamma_2} \\hat \\eta( \\log T (\\gamma_1+\\gamma_2) ) \\hat f( \\frac{\\gamma_2}{T} ).")]]

#text("Let us first look at the right-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(". From conjugation symmetry ")#mi("{\\zeta(\\overline{s}) = \\overline{\\zeta(s)}}")#text(" we see that the ordinates are symmetric around the origin, so on replacing ")#mi("{\\gamma_1}")#text(" with ")#mi("{-\\gamma_1}")#text(", we can rewrite this expression as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{T \\log T} \\sum_{\\gamma_2} \\hat f( \\frac{\\gamma_2}{T} ) \\sum_{\\gamma_1} \\hat \\eta( 2\\pi L (\\gamma_2 - \\gamma_1 ) )")]]

#text("where we have introduced the normalising factor ")#mi("{L := \\frac{1}{2\\pi} \\log T}")#text(". The significance of this factor comes from the Riemann-von Mangoldt formula (Theorem 40 from ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("Supplement 3")]#text("), which tells us that the number of ordinates in ")#mi("{[0,T]}")#text(" is equal to ")#mi("{(1+o(1)) LT}")#text(", so the average spacing between ordinates in this interval is approximately ")#mi("{1/L}")#text(". The sum ")#mi("{\\sum_{\\gamma_1} \\hat \\eta( 2\\pi L (\\gamma_2 - \\gamma_1 ) )}")#text(" is a smoothed count of ordinates that lie within ")#mi("{O(1/L)}")#text(" of ")#mi("{\\gamma_1}")#text(".")

#text("We can use the Riemann-von Mangoldt formula to isolate the diagonal term:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_\\gamma \\hat f(\\frac{\\gamma}{T}) = (1+o(1)) T \\log T.")]]
]

#text("The right-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is thus")

#align(center)[#tao-fit-display[#mitex("\\hat \\eta(0) + o(1) + \\frac{1}{T \\log T} \\sum_{\\gamma_2} \\hat f( \\frac{\\gamma_2}{T} ) \\sum_{\\gamma_1 \\neq \\gamma_2} \\hat \\eta( 2\\pi L (\\gamma_2 - \\gamma_1 ) ).")]]

#text("Let us now make the hypothesis that the ")#emph[#text("normalised differences")]#text(" ")#mi("{L (\\gamma_2 - \\gamma_1)}")#text(" between distinct ordinates ")#mi("{\\gamma_1,\\gamma_2}")#text(" of size ")#mi("{O(T)}")#text(" (as weighted by ")#mi("{\\hat f(\\frac{\\gamma_2}{T})}")#text(") have a limiting density ")#mi("{\\rho_2: {\\bf R} \\rightarrow {\\bf R}^+}")#text(", in the sense that ")#metadata(none) <tao-c380779f6175766fdbe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\frac{1}{T \\log T} \\sum_{\\gamma_2} \\hat f( \\frac{\\gamma_2}{T} ) \\sum_{\\gamma_1 \\neq \\gamma_2} F( L(\\gamma_2 -\\gamma_1) ) = \\int_{\\bf R} \\rho_2(t) F(t)\\ dt + o(1)")]]



#text(" for any fixed smooth, rapidly decreasing function ")#mi("{F}")#text("; we refer to ")#mi("{\\rho_2}")#text(" as the ")#emph[#text("pair correlation function")]#text(". Intuitively, ")#mi("{\\rho_2(t) dt}")#text(" should be thought of as the asymptotic probability that a randomly chosen ordinate ")#mi("{\\gamma_2}")#text(" has another ordinate ")#mi("{\\gamma_1}")#text(" with normalised difference ")#mi("{L(\\gamma_2 - \\gamma_1)}")#text(" lying in the interval ")#mi("{[t,t+dt]}")#text(" if ")#mi("{dt}")#text(" is infinitesimal. If we assume such an asymptotic, then the right-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is now")

#align(center)[#tao-fit-display[#mitex("\\hat \\eta(0) + o(1) + \\int_{\\bf R} \\rho_2(t) \\hat \\eta(2\\pi t)\\ dt.")]]

#text("Since the average spacing between ordinates is ")#mi("{1/L}")#text(", we expect ")#mi("{\\rho_2}")#text(" to be asymptotically equal to ")#mi("{1}")#text(", at least on average, so we write ")#mi("{\\rho_2}")#text(" as ")#mi("{1 - (1-\\rho_2)}")#text(". By hypothesis ")#mi("{\\eta(0)=0}")#text(", so from the Fourier inversion formula we have ")#mi("{\\int_{\\bf R} \\hat \\eta(2\\pi t)\\ dt = 0}")#text(". Thus the left-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is now")

#align(center)[#tao-fit-display[#mitex("\\hat \\eta(0) + o(1) - \\int_{\\bf R} (1-\\rho_2)(t) \\hat \\eta(2\\pi t)\\ dt")]]

#text("which (assuming ")#mi("{1-\\rho_2}")#text(" is absolutely integrable) can be expressed using Fubini’s theorem as ")#metadata(none) <tao-2dfe04d84dd6240167fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\int_{\\bf R} \\eta(u) (1 - \\widehat{1-\\rho_2}( 2\\pi u ))\\ du + o(1).")]]



#text(" Of course, to make use of this formula we will need to know or conjecture something about the pair correlation function ")#mi("{\\rho_2}")#text(". To do this we return to the left-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(". In principle, we can use ")#link(<tao-4a5b0555fa2b2431b30c>)[#text("(23)")]#text(" to rewrite this as an expression involving the von Mangoldt function; very roughly, the left-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is a normalised variance of the error term in the prime number theorem in smoothed out versions of the interval ")#mi("{[x, x+\\frac{x}{T}]}")#text(" with ")#mi("{\\frac{\\log x}{\\log T}}")#text(" drawn from the support of ")#mi("{\\eta}")#text(". The second term on the right-hand side in ")#link(<tao-4a5b0555fa2b2431b30c>)[#text("(23)")]#text(" is somewhat annoying to deal with in general, but if ")#mi("{\\eta}")#text(" is supported close enough to the origin then things simplify somewhat:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 33")]#text(" If ")#mi("{\\eta}")#text(" is supported in ")#mi("{(0,2)}")#text(", then the left-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\sum_{n_1,n_2} \\frac{\\Lambda(n_1) \\Lambda(n_2)}{\\sqrt{n_1} \\sqrt{n_2}} \\eta( \\frac{\\log n_1}{\\log T} ) f( T(\\log n_1 - \\log n_2 ) )")]]

#align(center)[#tao-fit-display[#mitex("- \\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du) + o(1).")]]
]

#emph[#text("Proof:")]#text(" By hypothesis, ")#mi("{\\eta}")#text(" is supported on ")#mi("{[\\varepsilon,2-\\varepsilon]}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(". In this argument we will allow implied constants to depend on ")#mi("{f,\\eta,\\varepsilon}")#text(".")

#text("Expanding out ")#link(<tao-4a5b0555fa2b2431b30c>)[#text("(23)")]#text(", we see that the left-hand side of ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(" is the sum of the four terms ")#metadata(none) <tao-e94b27178a319f7d19fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\frac{1}{\\log^2 T} \\sum_{n_1,n_2} \\frac{\\Lambda(n_1) \\Lambda(n_2)}{\\sqrt{n_1} \\sqrt{n_2}} \\eta( \\frac{\\log n_1}{\\log T} ) f( T(\\log n_1 - \\log n_2 ) ),")]]



#text(" ")#metadata(none) <tao-33699ffee1a3eadbc4d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("-\\frac{1}{\\log^2 T} \\sum_{n_1} \\frac{\\Lambda(n_1)}{\\sqrt{n_1}} \\int_{\\bf R} \\eta( \\frac{\\log n_1}{\\log T} ) f( T(\\log n_1 - u ) ) E(u)\\ du,")]]



#text(" ")#metadata(none) <tao-2c414fa321275d6fb973>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("-\\frac{1}{\\log^2 T} \\sum_{n_2} \\frac{\\Lambda(n_2)}{\\sqrt{n_2}} \\int_{\\bf R} \\eta( \\frac{u}{\\log T} ) f( T(u - \\log n_2) ) E(u)\\ du,")]]



#text(" and ")#metadata(none) <tao-4eddbb13a875f572ac7d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("\\frac{1}{\\log^2 T} \\int_{{\\bf R}^2} \\eta( \\frac{u_1}{\\log T} ) f( T(u_1 - u_2) ) E(u_1) E(u_2)\\ du_1 du_2,")]]



#text(" where")

#align(center)[#tao-fit-display[#mitex("E(u) := e^{u/2} - \\sum_n e^{-(2n+1/2) u} = e^{u/2} + O(e^{-5u/2} ).")]]

#text("We first inspect ")#link(<tao-4eddbb13a875f572ac7d>)[#text("(32)")]#text(". From the support of ")#mi("{f}")#text(" and ")#mi("{\\eta}")#text(" we can write")

#align(center)[#tao-fit-display[#mitex("E(u_1) E(u_2) = e^{u_1} + O( T^{1-\\varepsilon/2} )")]]

#text("on the support of the integrand. The contribution of the ")#mi("{O(T^{1-\\varepsilon/2})}")#text(" error to ")#link(<tao-4eddbb13a875f572ac7d>)[#text("(32)")]#text(" is ")#mi("{o(1)}")#text(", so ")#link(<tao-4eddbb13a875f572ac7d>)[#text("(32)")]#text(" simplifies after a change of variables to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du) + o(1).")]]

#text("Next we turn to ")#link(<tao-33699ffee1a3eadbc4d7>)[#text("(30)")]#text(". On the support of the integrand we have")

#align(center)[#tao-fit-display[#mitex("E(u) =\\sqrt{n_1} + O( \\frac{\\sqrt{n_1}}{T} ),")]]

#text("and the integral vanishes unless ")#mi("{T^{1+\\varepsilon} \\ll n_1 \\ll T^{2-\\varepsilon}}")#text(". From this we see that the contribution of the ")#mi("{O( \\frac{\\sqrt{n_1}}{T} )}")#text(" error is ")#mi("{o(1)}")#text(", and ")#link(<tao-33699ffee1a3eadbc4d7>)[#text("(30)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{T \\log^2 T} (\\int_{\\bf R} f(u)\\ du) \\sum_{n_1} \\Lambda(n_1) \\eta( \\frac{\\log n_1}{\\log T} ) + o(1).")]]

#text("As we are assuming the Riemann hypothesis, we see from Proposition 24 from ")#link("https://terrytao.wordpress.com/2014/12/09/254a-notes-2-complex-analytic-multiplicative-number-theory/")[#text("Notes 2")]#text(" that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1 \\leq x} \\Lambda(n) = x + O( T^{1-\\varepsilon/2} )")]]

#text("for all ")#mi("{x}")#text(" in the support of ")#mi("{\\eta(\\frac{\\log x}{\\log T} )}")#text(". A routine summation by parts then shows that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n_1} \\Lambda(n_1) \\eta( \\frac{\\log n_1}{\\log T} ) = \\int_{\\bf R} \\eta(\\frac{\\log x}{\\log T} )\\ dx + O( T^{1-\\varepsilon/2} )")]]

#text("and so ")#link(<tao-33699ffee1a3eadbc4d7>)[#text("(30)")]#text(" simplifies to ")#metadata(none) <tao-8563d0d12f13ad2504d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("- \\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du) + o(1).")]]



#text(" As for ")#link(<tao-2c414fa321275d6fb973>)[#text("(31)")]#text(", a Taylor expansion gives")

#align(center)[#tao-fit-display[#mitex("\\eta( \\frac{u}{\\log T} ) E(u) = \\eta( \\frac{n_2}{\\log T} ) \\sqrt{n_2} + O( \\frac{\\sqrt{n_2}}{T} )")]]

#text("on the support of the integrand, and the integral vanishes unless ")#mi("{T^{1+\\varepsilon} \\ll n_1 \\ll T^{2-\\varepsilon}}")#text(". We can then repeat the argument used to estimate ")#link(<tao-33699ffee1a3eadbc4d7>)[#text("(30)")]#text(" to obtain the same estimate ")#link(<tao-8563d0d12f13ad2504d0>)[#text("(33)")]#text(" for ")#link(<tao-2c414fa321275d6fb973>)[#text("(31)")]#text(". Adding together all these estimates, we obtain the claim. ")#mi("\\Box")

#text("We thus arrive at the asymptotic ")#metadata(none) <tao-e3f17c0a460d5d87d5e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("\\frac{1}{\\log^2 T} \\sum_{n_1,n_2} \\frac{\\Lambda(n_1) \\Lambda(n_2)}{\\sqrt{n_1} \\sqrt{n_2}} \\eta( \\frac{\\log n_1}{\\log T} ) f( T(\\log n_1 - \\log n_2 ) )")]]





#tao-aligned(keep: true)[


#tao-math(" & = \\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du)", block: true)



#tao-math(" & + \\int_{\\bf R} \\eta(u) (1 - \\widehat{1-\\rho_2}( 2\\pi u ))\\ du + o(1)", block: true)
]

#text("whenever ")#mi("{\\eta, f: {\\bf R} \\rightarrow {\\bf C}}")#text(" are fixed functions with ")#mi("{f(0)=1}")#text(" and ")#mi("{\\eta}")#text(" supported in ")#mi("{(0,2)}")#text(". We can use this relation to try to recover the pair correlation function ")#mi("{\\rho_2}")#text(", or at least the portion of this function described by the Fourier transform ")#mi("{1 - \\widehat{1-\\rho_2}( 2\\pi u )}")#text(" with ")#mi("{u \\in [0,2]}")#text(".")

#text("We first deal with the easy case when ")#mi("{\\eta}")#text(" is in fact supported on ")#mi("{(0,1)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 34 (Easy case)")]#text(" ")#metadata(none) <tao-97c10efe01d5c9c88704>#text(" If ")#mi("{\\eta}")#text(" is supported on ")#mi("{(0,1)}")#text(", then the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\eta(u) u\\ du + o(1).")]]
]

#text("Note that when ")#mi("{\\eta}")#text(" is supported on ")#mi("{(0,1)}")#text(", the first term on the right-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" is ")#mi("{o(1)}")#text(", and so this proposition indicates that")

#align(center)[#tao-fit-display[#mitex("\\widehat{1-\\rho_2}(2\\pi u) = 1-u")]]

#text("for ")#mi("{0 < u < 1}")#text(".")

#emph[#text("Proof:")]#text(" By hypothesis, ")#mi("{\\eta}")#text(" is supported in ")#mi("{[\\varepsilon,1-\\varepsilon]}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(". The summand in the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" vanishes unless ")#mi("{n_1 \\ll T^{1-\\varepsilon}}")#text(" and ")#mi("{n_2 = (1+O(1/T)) n_1}")#text(", which implies that ")#mi("{n_2 - n_1 = o(1)}")#text(". But ")#mi("{n_1,n_2}")#text(" are natural numbers, and so (for ")#mi("{T}")#text(" large enough) this forces ")#mi("{n_1=n_2}")#text(". Thus the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" simplifies (using the normalisation ")#mi("{f(0)=1}")#text(") to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\sum_{n} \\frac{\\Lambda(n)^2}{n} \\eta( \\frac{\\log n}{\\log T} ).")]]

#text("The contribution of those ")#mi("{n}")#text(" that are prime powers ")#mi("{p^j}")#text(" for ")#mi("{j \\geq 2}")#text(" is easily seen to be ")#mi("{o(1)}")#text(", so we can write this expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p} \\frac{1}{p} (\\frac{\\log p}{\\log T})^2 \\eta( \\frac{\\log p}{\\log T} ) + o(1).")]]

#text("The claim now follows from Exercise 37 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(". ")#mi("\\Box")

#text("Now we look at the complementary case when ")#mi("{\\eta}")#text(" is supported on ")#mi("{(1,2)}")#text(", and thus on ")#mi("{[1+\\varepsilon,2-\\varepsilon]}")#text(" for some fixed ")#mi("{\\varepsilon>0}")#text(". (This skips over a transitional case when ")#mi("{\\eta}")#text(" is supported near ")#mi("{1}")#text(", but it turns out that the analysis there is basically a mixture of the two other cases, and is left as an exercise to the reader below.) This is significantly more difficult, because ")#mi("{n_1,n_2}")#text(" are no longer forced to be equal. As such, we are unable to compute the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" just from the Riemann hypothesis; we will need an even stronger claim, namely the strong Hardy-Littlewood prime tuples conjecture ")#link(<tao-0fbea216374b65af112c>)[#text("(11)")]#text(" (or more precisely, the ")#mi("{k=2}")#text(" case of this conjecture) to make headway.")

#text("The diagonal contribution ")#mi("{n_1=n_2}")#text(" to the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" can still be computed to be ")#mi("{\\int_{\\bf R} \\eta(u) u\\ du + o(1)}")#text(" by the arguments used to prove Proposition ")#link(<tao-97c10efe01d5c9c88704>)[#text("34")]#text(", so we focus on the contribution of the off-diagonal term ")#mi("{n_2 \\neq n_1}")#text(". We can write ")#mi("{n_2 = n_1 + h}")#text(" with ")#mi("{h}")#text(" non-zero, arriving at")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\sum_{h \\in {\\bf Z} \\backslash \\{0\\}} \\sum_n \\frac{\\Lambda(n) \\Lambda(n+h)}{\\sqrt{n} \\sqrt{n+h}} \\eta( \\frac{\\log n}{\\log T} ) f( T \\log(1+\\frac{h}{n}) ).")]]

#text("Note that the summand vanishes unless ")#mi("{T^{1+\\varepsilon} \\ll n \\ll T^{2-\\varepsilon}}")#text(" and ")#tao-math("{\\left|h\\right|T \\ll n}", block: false)#text(", so that ")#tao-math("{\\left|h\\right| \\ll T^{1-\\varepsilon}}", block: false)#text(". By Taylor expansion, we then have")

#align(center)[#tao-fit-display[#mitex("f( T \\log(1+\\frac{h}{n}) ) = f( \\frac{hT}{n} ) + O( \\frac{1}{T} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sqrt{n} \\sqrt{n+h}} = (1 + O(\\frac{1}{T}) \\frac{1}{n}.")]]

#text("The contribution of the ")#mi("{O( \\frac{1}{T} )}")#text(" errors can be easily seen to be ")#mi("{o(1)}")#text(", so the off-diagonal contribution to ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\sum_{h {\\bf Z} \\backslash \\{0\\}} \\sum_n \\Lambda(n) \\Lambda(n+h) \\frac{\\eta( \\frac{\\log n}{\\log T} ) f( \\frac{hT}{n} )}{n} + o(1).")]]

#text("Now, the strong Hardy-Littlewood prime tuples conjecture gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\Lambda(n+h) = {\\mathfrak S}_h x + O( x^{1/2 + \\varepsilon/4} )")]]

#text("(say) for any ")#mi("{x \\geq T}")#text(" and non-zero ")#mi("{h}")#text(" with ")#tao-math("{\\left|h\\right| \\ll T^{1-\\varepsilon}}", block: false)#text(", where ")#mi("{{\\mathfrak S}_h}")#text(" is the singular series")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_h := \\prod_p \\frac{1 - \\frac{2}{p} + \\frac{1_{p|h}}{p}}{(1-\\frac{1}{p})^2}.")]]

#text("A summation by parts then lets us write ")#mi("{\\sum_n \\Lambda(n) \\Lambda(n+h) \\frac{\\eta( \\frac{\\log n}{\\log T} ) f( \\frac{hT}{n} )}{n}}")#text(" as the sum of the integral")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_h \\int_0^\\infty \\frac{\\eta( \\frac{\\log x}{\\log T} ) f( \\frac{hT}{x} )}{x}\\ dx")]]

#text("and the error term")

#align(center)[#tao-fit-display[#mitex("O( \\int_0^\\infty x^{1/2+\\varepsilon/4} | \\frac{d}{dx} (\\frac{\\eta( \\frac{\\log x}{\\log T} ) f( \\frac{hT}{x} )}{x}) |\\ dx ).")]]

#text("For the error term, the derivative can be computed to be ")#mi("{O(1/x^2)}")#text(", and vanish unless ")#tao-math("{x \\gg \\left|h\\right|T}", block: false)#text(", so the error term is ")#tao-math("{O( (\\left|h\\right| T)^{-1/2+\\varepsilon/4} )}", block: false)#text(", and then summing over non-zero ")#tao-math("{\\left|h\\right| \\ll T^{1-\\varepsilon}}", block: false)#text(" we see that this contribution is ")#mi("{o(1)}")#text(". Thus the off-diagonal contribution has simplified (after some rearranging) to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\int_0^\\infty \\eta( \\frac{\\log x}{\\log T} ) (\\sum_{{\\bf Z} \\backslash \\{0\\}} {\\mathfrak S}_h f( \\frac{hT}{x} ))\\ \\frac{dx}{x} + o(1).")]]

#text("To proceed further we need to understand mean values of the singular series ")#mi("{{\\mathfrak S}_h}")#text(". It turns out (as ")#link("http://www.ams.org/mathscinet-getitem?mr=199165")[#text("first observed by Bombieri and Davenport")]#text(", and then generalised ")#link("http://www.ams.org/mathscinet-getitem?mr=409385")[#text("by Gallagher")]#text(") ")#mi("{{\\mathfrak S}_h}")#text(" has average value of ")#mi("{1}")#text(", (see e.g. ")#link("http://arxiv.org/abs/1108.3861")[#text("this paper of Ford")]#text(" for a short proof, related to the equidistribution of residues heuristics discussed previously). However, for our analysis we will need a finer estimate that detects a deviation from ")#mi("{1}")#text(" coming from the exclusion of ")#mi("{h=0}")#text(" from the sum (where the singular series is undefined). Namely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 35 (Mean value of singular series)")]#text(" Let ")#mi("{x \\geq 2}")#text(", and let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a fixed smooth, compactly supported function. Then ")#metadata(none) <tao-04fb78ddc42ed5b74614>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\sum_{h \\neq 0} {\\mathfrak S}_h f( \\frac{h}{x} ) = (\\int_{\\bf R} f(u)\\ du) x - f(0) \\log x + O(1).")]]




]

#text("Informally, the ")#mi("{-f(0) \\log x}")#text(" term here is reflecting a very slight but non-trivial repulsion estimate among the primes (detected by the modified Cramér model, but not the naive Cramér model): if ")#mi("{n}")#text(" is prime, and ")#mi("{h}")#text(" is small and ")#emph[#text("non-zero")]#text(", then ")#mi("{n+h}")#text(" is slightly less likely to be prime than a typical number of size ")#mi("{\\sim n}")#text(". This is because most small primes ")#mi("{q}")#text(" will not divide either ")#mi("{n}")#text(" or ")#mi("{h}")#text(", and so will be slightly more likely to divide ")#mi("{n+h}")#text(" than a typical number of this size. (Conversely, the small primes ")#mi("{q}")#text(" that do divide ")#mi("{h}")#text(" will increase the probability that ")#mi("{n+h}")#text(" is prime, but because ")#mi("{h}")#text(" is restricted to be non-zero, this latter effect is slightly weaker than the former.)")

#emph[#text("Proof:")]#text(" We allow implied constants to depend on ")#mi("{f}")#text(". Since ")#mi("{{\\mathfrak S}_h}")#text(" vanishes for odd ")#mi("{h}")#text(", we can restrict attention to even ")#mi("{h}")#text(". We can then factor")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_h = 2 \\Pi_2 \\prod_{p|h, \\text{ odd}} (1 + \\frac{1}{p-2})")]]

#text("where ")#mi("{\\Pi_2}")#text(" is the twin prime constant ")#link(<tao-68d3ff4b0ff6aa3eae88>)[#text("(7)")]#text(" (cf. ")#link(<tao-3e399c46e9652dadde7e>)[#text("(9)")]#text("). This can then be expanded as")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}_h = 2 \\Pi_2 \\sum_d g(d)")]]

#text("where ")#mi("{g}")#text(" is the multiplicative function supported on square-free numbers with ")#mi("{g(2):=0}")#text(" and ")#mi("{g(p) := \\frac{1}{p-2}}")#text(" for ")#mi("{p>2}")#text(". Writing ")#mi("{h=dn}")#text(", we may therefore write the left-hand side of ")#link(<tao-04fb78ddc42ed5b74614>)[#text("(35)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("2\\Pi_2 \\sum_d g(d) \\sum_{n \\in {\\bf Z} \\backslash \\{0\\}, \\text{ even}} f( \\frac{n}{x/d} ).")]]

#text("The summand vanishes unless ")#mi("{d = O(x)}")#text(". In this regime, we may apply Exercise 11 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" (or the Poisson summation formula, see Exercise 35 of ")#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("Supplement 2")]#text(") and restore the ")#mi("{n=0}")#text(" term to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z} \\backslash \\{0\\}, \\text{ even}} f( \\frac{n}{x/d} ) = \\frac{x}{2d} (\\int_{\\bf R} f(u)\\ du) - f(0) + O( \\frac{d}{x} ).")]]

#text("Noting that ")#mi("{g(p) \\leq \\frac{1}{\\sqrt{p}}}")#text(" whenever ")#mi("{p}")#text(" is sufficiently large, we see that ")#mi("{g(d) \\ll d^{-1/2}}")#text(". From this we see that the contribution of the ")#mi("{O(\\frac{d}{x})}")#text(" term is ")#mi("{O_\\varepsilon( 1 )}")#text(". The left-hand side of ")#link(<tao-04fb78ddc42ed5b74614>)[#text("(35)")]#text(" is now")

#align(center)[#tao-fit-display[#mitex("\\frac{\\Pi_2}{x} \\sum_{d \\ll x} \\frac{g(d)}{d} + 2\\Pi_2 f(0) \\sum_{d \\ll x} g(d) + O(1).")]]

#text("Using the bound ")#mi("{g(d) \\ll_\\varepsilon d^{-1+\\varepsilon}}")#text(" again, we see that ")#mi("{\\sum_{d \\ll x} \\frac{g(d)}{d} = \\sum_d \\frac{g(d)}{d}}")#text("; also, from Theorem 27 of ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("Notes 1")]#text(" (with ")#mi("{k=1}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\ll x} g(d) = [\\frac{1}{2} \\prod_{p>2} (1-\\frac{1}{p}) (1 + \\frac{1}{p-2})] \\log x + O(1).")]]

#text("From ")#link(<tao-68d3ff4b0ff6aa3eae88>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{p>2} (1-\\frac{1}{p}) (1 + \\frac{1}{p-2})= \\Pi_2^{-1}")]]

#text("and from Euler products we have")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\frac{g(d)}{d} = \\prod_{p>2} (1 + \\frac{1}{p(p-2)}) = \\Pi_2^{-1}")]]

#text("and the claim follows. ")#mi("\\Box")

#text("We insert this proposition into the previous asymptotic. The contribution of the ")#mi("{O(1)}")#text(" error in ")#link(<tao-04fb78ddc42ed5b74614>)[#text("(35)")]#text(" is easily seen to be ")#mi("{o(1)}")#text(", so the off-diagonal contribution to ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" is now")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\log^2 T} \\int_0^\\infty \\eta( \\frac{\\log x}{\\log T} ) ( (\\int_{\\bf R} f(u)\\ du) \\frac{x}{T} - \\log \\frac{x}{T} )\\ \\frac{dx}{x} + o(1),")]]

#text("where we have used the normalisation ")#mi("{f(0)=0}")#text(". The contribution of the ")#mi("{(\\int_{\\bf R} f(u)\\ du) \\frac{x}{T}}")#text(" term can be written after a change of variables as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du),")]]

#text("that is to say the first term of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(". A similar change of variables expresses the contribution of the ")#mi("{\\log \\frac{x}{T}}")#text(" term as")

#align(center)[#tao-fit-display[#mitex("- \\int_{\\bf R} \\eta(u) (u-1)\\ du.")]]

#text("Combining this with the diagonal contribution of ")#mi("{\\int_{\\bf R} \\eta(u) u\\ du + o(1)}")#text(" to ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" computed previously, we conclude (on the strong Hardy-Littlewood prime tuples conjecture) that the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du) + \\int_{\\bf R} \\eta(u)\\ du + o(1)")]]

#text("when ")#mi("{\\eta}")#text(" is supported on ")#mi("{(1,2)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Assuming the strong Hardy-Littlewood prime tuples conjecture, obtain the combined formula")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{T \\log T} (\\int_{\\bf R} f(u)\\ du) (\\int_{\\bf R} \\eta(u) e^{Tu}\\ du)")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{\\bf R} \\eta(u) \\max(u,1)\\ du + o(1)")]]

#text("for the left-hand side of ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(" when ")#mi("{\\eta}")#text(" is supported on ")#mi("{(0,2)}")#text(".")
]

#text("By interchanging ")#mi("{\\gamma_1}")#text(" and ")#mi("{\\gamma_2}")#text(" in ")#link(<tao-c380779f6175766fdbe9>)[#text("(27)")]#text(" one sees that the asymptotic pair correlation function ")#mi("{\\rho_2}")#text(" should be even. If one compares the above exercise with ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(", one arrives at the prediction ")#metadata(none) <tao-7f926121d753b65cf5ec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#tao-math("\\widehat{(1-\\rho_2)}(2\\pi u) = \\max( 1 - \\left|u\\right|, 0 )", block: true)]]



#text(" for all ")#tao-math("{\\left|u\\right| < 2}", block: false)#text("; the justification provided for this prediction requires the strong Hardy-Littlewood prime tuples conjecture when ")#tao-math("{1 \\leq \\left|u\\right| < 2}", block: false)#text(", but is unconditional for ")#tao-math("{\\left|u\\right| < 1}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 37")]#text(" If one uses the strong Möbius pseudorandomness principle (see Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text(") in place of the strong Hardy-Littlewood prime tuples conjecture, one will also recover ")#link(<tao-7f926121d753b65cf5ec>)[#text("(36)")]#text(", but in a range intermediate between ")#tao-math("{\\{ \\left|u\\right| < 1 \\}}", block: false)#text(" and ")#tao-math("{\\{ \\left|u\\right| < 2 \\}}", block: false)#text(", due to some inefficiencies in deploying this principle to study the primes, as discussed in Remark ")#link(<tao-8fc21da610761c189aa4>)[#text("26")]#text(". The moderate or weak Möbius pseudorandomness principles do not appear to give any improvement over the easy range ")#tao-math("{\\{ \\left|u\\right| < 1 \\}}", block: false)#text(", except possibly to clarify some endpoint behaviour at ")#tao-math("{\\left|u\\right|=1}", block: false)#text("; this is because the term we are trying to isolate in ")#link(<tao-e3f17c0a460d5d87d5e6>)[#text("(34)")]#text(", namely the second term on the right-hand side, is dominated by the first term on the right-hand side when ")#tao-math("{\\left|u\\right| > 1}", block: false)#text(", and so very strong asymptotics are needed in order to discern this lower order behaviour. It seems of interest though to come up with a stronger version of Möbius pseudorandomness (possibly involving multidimensional sums rather than just one-dimensional sums) that could recover ")#link(<tao-7f926121d753b65cf5ec>)[#text("(36)")]#text(" in the full range ")#tao-math("{\\left|u\\right| < 2}", block: false)#text(", or possibly even beyond.")
]

#text("Based on a similar calculation to the above, ")#link("http://www.ams.org/mathscinet-getitem?mr=337821")[#text("Montgomery conjectured")]#text(" that ")#link(<tao-7f926121d753b65cf5ec>)[#text("(36)")]#text(" should in fact hold for ")#emph[#text("all")]#text(" ")#mi("{u}")#text(", not just for ")#tao-math("{\\left|u\\right| < 2}", block: false)#text(". Using Fourier inversion, this leads to a prediction ")#metadata(none) <tao-9d23333fa0d3f48da3d7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("\\rho_2(t) = 1 - (\\frac{\\sin(\\pi t)}{\\pi t})^2")]]



#text(" for the pair correlation function for all ")#mi("{t \\in {\\bf R}}")#text(", with the convention that the ")#link("http://en.wikipedia.org/wiki/Sinc_function")[#text("sinc function")]#text(" ")#mi("{\\frac{\\sin x}{x}}")#text(" equals ")#mi("{1}")#text(" when ")#mi("{x=0}")#text(". Note that ")#mi("{\\rho_2(t)}")#text(" vanishes to second order as ")#mi("{t \\rightarrow 0}")#text("; this indicates a strong ")#emph[#text("repulsion")]#text(" effect between ordinates (far stronger than the weak repulsion between primes discussed previously), asserting roughly speaking that the probability that the gap ")#mi("{\\gamma_{i+1} - \\gamma_i}")#text(" between adjacent ordinates is less than ")#mi("{\\varepsilon/L}")#text(" decays like ")#mi("{\\varepsilon^3}")#text(", rather than the naive prediction of ")#mi("{\\varepsilon}")#text(" which would occur if there was no repulsion phenomenon.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Formally derive ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" from the hypothesis that ")#link(<tao-7f926121d753b65cf5ec>)[#text("(36)")]#text(" holds for all ")#mi("{u}")#text(".")
]

#text("We informally refer to the prediction ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" for all ")#mi("{u \\in {\\bf R}}")#text(" as the ")#link("http://en.wikipedia.org/wiki/Montgomery%27s_pair_correlation_conjecture")[#text("pair correlation conjecture")]#text(". Actually, because the above analysis only assumes the asymptotic ")#link(<tao-c380779f6175766fdbe9>)[#text("(27)")]#text(" for smooth compactly supported ")#mi("{\\eta}")#text(", we have only been working thus far with a smoothed version of the pair correlation conjecture. In the literature, stronger versions of the pair correlation conjecture (replacing ")#mi("{\\eta}")#text(" with rougher cutoffs) are sometimes formulated; also, in some conventions, a Dirac mass ")#mi("{\\delta(t)}")#text(" is added to ")#mi("{\\rho_2}")#text(" in order to remove the restriction ")#mi("{\\gamma_1 \\neq \\gamma_2}")#text(" of distinct ordinates; as such, one should view the pair correlation conjecture as a ")#emph[#text("family")]#text(" of closely related conjectures, rather than a single conjecture (cf. the Möbius pseudorandomness principle, Principle ")#link(<tao-1a891cd9b63fc7a60be5>)[#text("19")]#text("). With such strengthenings of the pair correlation conjecture, one can obtain asymptotics for rougher expressions than ")#link(<tao-4d2f4b668cfc48e6059d>)[#text("(26)")]#text(". For instance, we have the following elegant ")#link("http://www.ams.org/mathscinet-getitem?mr=931214")[#text("result of Goldston")]#text(": assuming the Riemann hypothesis, the statement")

#list(
[#text("(Pair correlation conjecture) One has ")#metadata(none) <tao-d8463bd3ba4b10e5916f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\sum_{0 \\leq \\gamma_1 < \\gamma_2 \\leq T: \\gamma_2 - \\gamma_1 \\leq \\frac{K}{L}} 1 = (1+o(1)) TL \\int_0^K 1 - (\\frac{\\sin(\\pi t)}{\\pi t})^2\\ dt")]]

#text("as ")#mi("{T \\rightarrow \\infty}")#text(" for any fixed ")#mi("{K > 0}")#text(".")]
)

#text("is logically equivalent to the statement")

#list(
[#text("(Variance asymptotic for prime number theorem in short intervals) One has ")#metadata(none) <tao-74356fbb67fef5edcfb2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#mitex("\\int_0^{T^\\beta} (\\psi(x+x/T) - \\psi(x)-x/T)^2 \\frac{dx}{x^2}")]]

#align(center)[#tao-fit-display[#mitex("= (\\frac{\\beta^2}{2} 1_{\\beta < 1} + (\\beta - \\frac{1}{2}) 1_{\\beta \\geq 1} + o(1)) \\frac{\\log^2 T}{T}")]]

#text("as ")#mi("{T \\rightarrow \\infty}")#text(" for any fixed ")#mi("{\\beta > 0}")#text(", where ")#mi("{\\psi(x) := \\sum_{n \\leq x} \\Lambda(n)}")#text(" is the von Mangoldt summatory function.")]
)

#text("which cleanly illustrates the duality between correlations of ordinates and correlations of primes. The implication of ")#link(<tao-74356fbb67fef5edcfb2>)[#text("(39)")]#text(" from ")#link(<tao-d8463bd3ba4b10e5916f>)[#text("(38)")]#text(" was previously obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=514680")[#text("by Gallagher and Mueller")]#text(". See also ")#link("http://www.ams.org/mathscinet-getitem?mr=1018376")[#text("this paper of Goldston and Montgomery")]#text(" for a similar equivalence (in which both of the above statements are replaced by slightly stronger versions with less averaging), as well as ")#link("http://www.ams.org/mathscinet-getitem?mr=1246830")[#text("this paper of Keating")]#text(". One should view the above variance asymptotic as a prediction that the statistic ")#mi("{\\sum_{x < n \\leq x+x/T} \\Lambda(n)}")#text(" for ")#mi("{x \\sim T^\\beta}")#text(" has variance about ")#mi("{\\min(\\beta,1) \\frac{x}{T} \\log T}")#text(" for ")#mi("{\\beta > 0}")#text(". (Note that ")#mi("{\\min(\\beta,1)}")#text(" is the derivative of ")#mi("{\\frac{\\beta^2}{2} 1_{\\beta < 1} + (\\beta - \\frac{1}{2}) 1_{\\beta \\geq 1}}")#text(".) In contrast, the naive Cramér model predicts a variance of approximately ")#mi("{\\beta \\frac{x}{T} \\log T}")#text("; there is a variance saturation effect expected for ")#mi("{\\beta > 1}")#text(" which is coming from the slight repulsion between nearby primes discussed previously; this is a further manifestation of the slight “subrandom” nature of the primes, as discussed in Remark ")#link(<tao-bec766e00261fe2ba68c>)[#text("6")]#text(". See ")#link("http://www.ams.org/mathscinet-getitem?mr=2166459")[#text("this survey of Goldston")]#text(" for a further discussion of these results; see also ")#link("http://www.ams.org/mathscinet-getitem?mr=2104891")[#text("this paper of Montgomery and Soundarajan")]#text(" for a more refined analysis, predicting a central limit theorem for the prime number theorem in short intervals that is consistent both with the refined Cramér model and the GUE hypothesis (see below).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Modify the proof of Proposition ")#link(<tao-97c10efe01d5c9c88704>)[#text("34")]#text(" to verify ")#link(<tao-74356fbb67fef5edcfb2>)[#text("(39)")]#text(" unconditionally for ")#mi("{0 < \\beta < 1}")#text(".")
]

#text("The pair correlation conjecture is also supported by substantial numerical evidence, notably through the computations of ")#link("http://www.dtc.umn.edu/~odlyzko/doc/zeta.html")[#text("Andrew Odlyzko")]#text(" and his co-authors.")

#text("It was ")#link("http://www.americanscientist.org/issues/pub/the-spectrum-of-riemannium")[#text("famously observed by Freeman Dyson")]#text(", in a tea-time conversation with Hugh Montgomery at the institute for advanced study, that the pair correlation function ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" predicted for ordinates of the zeta function also appeared as the pair correlation function for many models of random matrix theory. Here is one typical such place where it appears:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Pair correlation for GUE)")]#text(" Let ")#mi("{N}")#text(" be a natural number going to infinity, and let ")#mi("{M_N}")#text(" be an ")#mi("{N \\times N}")#text(" Hermitian random matrix whose diagonal entries are independent real Gaussians of mean zero and variance ")#mi("{1/N}")#text(", and whose strictly upper triangular entries are independent complex Gaussians of mean zero and variance ")#mi("{1/N}")#text(" (independent of the diagonal entries); this random matrix ensemble is known as the ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("Gaussian unitary ensemble")]#text(" (GUE). Let ")#mi("{\\lambda_1 \\leq \\dots \\leq \\lambda_N}")#text(" be the (necessarily real) eigenvalues of ")#mi("{M_N}")#text(", counted with multiplicity. Let ")#mi("{E \\in (-2,2)}")#text(" be fixed, and define the normalisation factor ")#mi("{L := \\sqrt{4-E^2} N}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{E \\leq \\lambda_i < \\lambda_j \\leq E + K/L: L(\\lambda_j - \\lambda_i) \\leq \\beta} 1 = (\\int_0^\\beta \\rho_2(u)\\ du + o(1)) K")]]

#text("for any fixed ")#mi("{\\beta>0}")#text(" whenever ")#mi("{K = K(N)}")#text(" goes to infinity slower than ")#mi("{N}")#text(", and where ")#mi("{\\rho_2}")#text(" is the function ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(".")
]

#text("See ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("this previous blog post")]#text(" for a proof of this claim. The factor of ")#mi("{\\sqrt{4-E^2}}")#text(" reflects the famous ")#link("http://en.wikipedia.org/wiki/Wigner_semicircle_distribution")[#text("Wigner semicircular law")]#text(" for the GUE ensemble, which does not directly appear in the theory of ordinates of zeta (the nearest analogue is the Riemann-von Mangoldt formula). But the appearance of the pair correlation function ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" does not appear to be closely tied with bulk distribution laws such as the Wigner law. For instance, here is another occurrence of the pair correlation function ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" in random matrix theory that does not involve the semicircle law:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 41 (Pair correlation for CUE)")]#text(" Let ")#mi("{N}")#text(" be a natural number going to infinity, and let ")#mi("{U_N}")#text(" be an ")#mi("{N \\times N}")#text(" unitary random matrix chosen using Haar measure; this random matrix ensemble is known as the ")#link("http://en.wikipedia.org/wiki/Circular_ensemble")[#text("circular unitary ensemble")]#text(" (CUE). Let ")#mi("{e^{i \\theta_1},\\dots,e^{i\\theta_N}}")#text(" be the (necessarily unitary) eigenvalues of ")#mi("{U_N}")#text(", counted with multiplicity, with ")#mi("{0 \\leq \\theta_1 \\leq \\dots \\leq \\theta_N \\leq 2\\pi}")#text(". Let ")#mi("{E \\in [0,2\\pi)}")#text(" be fixed, and define the normalisation factor ")#mi("{L := \\frac{N}{2\\pi}}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{E \\leq \\theta_i < \\theta_j \\leq E + K/L: L(\\theta_j - \\theta_i) \\leq \\beta} 1 = (\\int_0^\\beta \\rho_2(u)\\ du + o(1)) K")]]

#text("for any fixed ")#mi("{\\beta>0}")#text(" whenever ")#mi("{K = K(N)}")#text(" goes to infinity slower than ")#mi("{N}")#text(", and where ")#mi("{\\rho_2}")#text(" is the function ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(".")
]

#emph[#text("Proof:")]#text(" This is a ")#link("http://www.ams.org/mathscinet-getitem?mr=177643")[#text("result of Dyson")]#text(". ")#mi("\\Box")

#text("In fact, the pair correlation function ")#mi("{\\rho_2}")#text(" arises in extremely broad classes of random matrices, reflecting a general phenomenon now known as ")#emph[#text("random matrix universality")]#text("; see this ")#link("https://terrytao.wordpress.com/2010/09/14/a-second-draft-of-a-non-technical-article-on-universality/")[#text("previous blog post")]#text(" for some non-technical discussion of this phenomenon.")

#text("This result inspired a more general ")#emph[#text("GUE hypothesis")]#text(", which broadly speaking asserts that the (suitably normalised) distribution of ordinates of size ")#mi("{O(T)}")#text(" at the “microscopic” scale of ")#mi("{1/L}")#text(" (or at the “mesoscopic” scale between ")#mi("{1/L}")#text(" and ")#mi("{o(1)}")#text(") as ")#mi("{T \\rightarrow \\infty}")#text(" should asymptotically attain the same limit as the analogous (suitably normalised) asymptotics of the eigenvalues of GUE (or CUE) at the analogous microscopic or mesoscopic scales as ")#mi("{N \\rightarrow \\infty}")#text(". (Roughly speaking, ")#mi("{N}")#text(" is analogous to ")#mi("{\\log T}")#text(", as can be seen by comparing the normalising factors ")#mi("{L}")#text(" in all of the above examples.) An analogous hypothesis has also been made for other ")#mi("{L}")#text("-functions, although in some cases the GUE model needs to be replaced by another standard random matrix model; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1640151")[#text("this expository article of Katz and Sarnak")]#text(" for details. As such, rigorous results about the asymptotic distribution of eigenvalues of GUE or CUE can be used to make ")#emph[#text("predictions")]#text(" about the distribution of ordinates, which through the explicit formula can also lead to predictions about prime numbers.")

#text("For instance, the theory of ensembles such as GUE and CUE in fact provides control not just of pair correlations such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{E \\sqrt{N} \\leq \\lambda_i < \\lambda_j \\leq E \\sqrt{N} + K/L: L(\\lambda_j - \\lambda_i) \\leq \\beta} 1,")]]

#text("but of higher order correlations involving ")#mi("{k}")#text("-tuples ")#mi("{\\lambda_{i_1},\\dots,\\lambda_{i_k}}")#text(" of nearby eigenvalues for ")#mi("{k \\geq 2}")#text(". We will not state the precise results here, but remark simply that the role of the two-point correlation function ")#mi("{\\rho_2}")#text(" from ")#link(<tao-9d23333fa0d3f48da3d7>)[#text("(37)")]#text(" is replaced by the more general function ")#metadata(none) <tao-49f380546cf1e36113bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("\\rho_k(u_1,\\dots,u_{k-1}) := \\text{det}( \\frac{\\sin(\\pi(u_i-u_j))}{\\pi(u_i-u_j)} )_{0 \\leq i,j \\leq k-1}")]]



#text(" with the convention that ")#mi("{u_0 := 1}")#text(". Again, we refer the interested reader to ")#link("https://terrytao.wordpress.com/2010/02/23/254a-notes-6-gaussian-ensembles/")[#text("this previous blog post")]#text(" for the relationship between these correlation functions and the GUE ensemble. The determinantal structure of the ")#mi("{k}")#text("-point correlation function ")#mi("{\\rho_k}")#text(" is an example of the correlation function of a more general class of ")#link("http://en.wikipedia.org/wiki/Determinantal_point_process")[#text("determinantal point processes")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2009/08/23/determinantal-processes/")[#text("this previous blog post")]#text(".")

#text("The ")#mi("{k}")#text("-point correlation asymptotics for GUE or CUE leads to one precise instance (but certainly not the ")#emph[#text("only")]#text(" such instance) of the GUE hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Prediction 42 (GUE hypothesis)")]#text(" ")#metadata(none) <tao-e679b58ac0c1afdeef9b>#text(" Let ")#mi("{k \\geq 2}")#text(" be fixed, and let ")#mi("{F: {\\bf R}^{k-1} \\rightarrow {\\bf C}}")#text(" be a smooth compactly supported function. Let ")#mi("{T \\geq 2}")#text(" be an asymptotic parameter going to infinity, and set ")#mi("{L := \\frac{1}{2\\pi} \\log T}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{\\gamma_1,\\dots,\\gamma_k \\in [0,T], \\text{ distinct}} F( L(\\gamma_2-\\gamma_1), \\dots, L(\\gamma_k-\\gamma_1))")]]

#align(center)[#tao-fit-display[#mitex("= LT ( \\int_{{\\bf R}^n} F(u_1,\\dots,u_{k-1}) \\rho_k(u_1,\\dots,u_{k-1})\\ du_1 \\dots u_{k-1} + o(1))")]]

#text("where ")#mi("{\\rho_k}")#text(" is defined by ")#link(<tao-49f380546cf1e36113bd>)[#text("(40)")]#text(".")
]

#text("Much as the pair correlation conjecture leads (via the explicit formula) to asymptotics about pairs of primes ")#mi("{p, q}")#text(" that are close to each other, the more general GUE hypothesis turns out to lead to asymptotics about pairs of ")#emph[#text("products of primes")]#text(" ")#mi("{p_1 \\dots p_j, q_1 \\dots q_{k-j}}")#text(" of primes (for some ")#mi("{1 \\leq j \\leq k-1}")#text(") that are close to each other, although the precise description of such asymptotics becomes somewhat messy; see ")#link("http://user.math.uzh.ch/rodgers/ArithmeticGUE.pdf")[#text("this paper of Rodgers")]#text(" for a precise formulation. One can then develop an analogue of Proposition ")#link(<tao-97c10efe01d5c9c88704>)[#text("34")]#text(" to obtain a partial verification of the GUE hypothesis (essentially verifying that the low frequency component of ")#link(<tao-49f380546cf1e36113bd>)[#text("(40)")]#text(" is correct); this was done (in great generality, for a much wider class of ")#mi("{L}")#text("-functions than just the Riemann zeta function, and assuming GRH in place of RH) by ")#link("http://www.ams.org/mathscinet-getitem?mr=1395406")[#text("Rudnick and Sarnak")]#text(" (with some earlier results ")#link("https://terrytao.wordpress.com/category/teaching/254a-analytic-prime-number-theory/")[#text("by Hejhal")]#text("). The analogous deployment of the strong Hardy-Littlewood tuples conjecture to verify a larger portion of the GUE hypothesis was carried out ")#link("http://www.ams.org/mathscinet-getitem?mr=2104891")[#text("by Montgomery and Soundararajan")]#text(". A heuristic derivation of the entire GUE hypothesis along these lines (without rigorous treatment of error terms) was carried out ")#link("http://www.ams.org/mathscinet-getitem?mr=1399479")[#text("by Bogomolny and Keating")]#text(". A function field analogue of the GUE hypothesis, in which the integers ")#mi("{{\\bf Z}}")#text(" are replaced by a function field ")#mi("{\\mathbf{F}_q[t]}")#text(" for some large ")#mi("{q}")#text(", was also established ")#link("http://www.ams.org/mathscinet-getitem?mr=1659828")[#text("by Katz and Sarnak")]#text(".")

#text("As mentioned above, Prediction ")#link(<tao-e679b58ac0c1afdeef9b>)[#text("42")]#text(" is not the only way to formalise the GUE hypothesis. The GUE hypothesis can be used to predict the behaviour of the Riemann zeta function ")#mi("{\\zeta}")#text(", by drawing an analogy between this function and the characteristic polynomial of a GUE or CUE matrix. This can be used for instance to predict central limit theorems for the logarithm of the zeta function, or asymptotics for moments of the zeta function (or its logarithm, or logarithmic derivative) on or near the critical line; furthermore, in the few cases where these predictions can actually be verified rigorously (or on hypotheses such as the Riemann hypothesis), the predictions agree with the rigorous computations. There is now a vast literature on this topic; see for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=1986396")[#text("survey of Keating and Snaith")]#text(" for further discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 43")]#text(" Using the analogy between the statistics of the zeta function and random matrix theory, the Riemann hypothesis is then analogous to the trivial fact that the eigenvalues of a GUE matrix are all real (or that the eigenvalues of a CUE matrix all lie on the unit circle). This is reminiscent of an ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93P%C3%B3lya_conjecture")[#text("old idea of Hilbert and Pólya")]#text(" that the ordinates of zeta should arise as the eigenvalues of some “natural” unbounded linear operator on a Hilbert space, which could then be shown to be self-adjoint in order to verify the Riemann hypothesis. Unfortunately, the GUE hypothesis does not suggest a useful candidate for such an operator. In fact, the breadth of the universality phenomenon extends well beyond random matrix models, and so the GUE hypothesis may not actually indicate any direct connection between zeta and matrices (or linear operators), instead reflecting the universal nature of the correlation functions ")#link(<tao-49f380546cf1e36113bd>)[#text("(40)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 44")]#text(" As with all of the other models discussed in these notes, one should bear in mind that there are finer adjustments to the GUE hypothesis that need to be made in certain regimes. For instance, it appears that there is a very slight repulsion effect between differences ")#mi("{\\gamma_1-\\gamma_2}")#text(" of two large ordinates ")#mi("{\\gamma_1,\\gamma_2}")#text(" and one small ordinate ")#mi("{\\gamma_0}")#text(", in that ")#mi("{\\gamma_1-\\gamma_2}")#text(" is slightly less likely to be close to ")#mi("{\\gamma_0}")#text(" than a direct application of the GUE hypothesis (or Riemann-von Mangoldt law) would indicate. This repulsion was first observed ")#link("http://www.ncbi.nlm.nih.gov/pubmed/10063087")[#text("by Bogolmony and Keating")]#text(", and is ultimately a reflection of the obvious negative correlation between ")#mi("{\\Lambda^2}")#text(" and ")#mi("{-\\Lambda}")#text("; see the papers ")#link("http://www.ams.org/mathscinet-getitem?mr=2684776")[#text("of Snaith")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=3151612")[#text("of Rodgers")]#text(" for further discussion.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (80)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-513351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2019")])]

#text("Mr.Tao thanks to see this work about k-tuple conjecture:")#linebreak()#text(" ")#link("https://math.stackexchange.com/questions/3133443/weak-k-tuple-conjecture-form-and-what-we-should-proof")[#text("https://math.stackexchange.com/questions/3133443/weak-k-tuple-conjecture-form-and-what-we-should-proof")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths junior")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-518811")[#strong[#text("Maths junior")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2019")])]

#text("Dear Prof. Tao,")

#text("I’m looking for a book that’s about (or at least contains a chapter on) the Cramér models. I’d be grateful for a suggestion.")

#text("W\\BR")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Large prime gaps and probabilistic models | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-520402")[#strong[#text("Large prime gaps and probabilistic models | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2019")])]

#text("[…] more devoid of primes than average, and this region is not well explored by existing numerics. See this previous blog post for more discussion of Granville’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-532954")[#strong[#text("254A, Notes 10 – mean values of nonpretentious multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2019")])]

#text("[…] following from Exercise 33 of Notes 2). On the other hand, the randomness heuristics from Supplement 4 suggest that should be able to be taken as small as , and perhaps even if one is particularly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-570618")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2020")])]

#text("[…] problem is discussed in these previous blog posts; this obstruction is ultimately powered by the Möbius pseudorandomness principle that asserts that the Möbius function is asymptotically orthogonal to all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-635628")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2021")])]

#text("Just a small typo: in line 2 under the section title “The Cramer random model”, I think the name of the mathematician should be Harald Cramer.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-636918")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/11/10/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chowla’s conjecture and the Riemann hypothesis via the Liouville function | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-649584")[#strong[#text("Chowla’s conjecture and the Riemann hypothesis via the Liouville function | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2022")])]

#text("[…] of these notes by Soundararajan. Several other ways to leverage this heuristic are presented in this blog post of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-681905")[#strong[#text("If there is no reason for structure, assume there is none. – Vasek Rozhon's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")]

#text("[…] model of primes has a name – Cramér’s random model. The Riemann hypothesis is equivalent to the claim that the prime number theorem is never wrong by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-682052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2023")])]

#text("There is a typo. In the sentence that starts with “Writing 1 – 2/p as… the term should be (1-1/p)^2 and not (1 – 2/p)^2 as stated.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-682486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2023")])]

#text("Dear Tao, reading this post came to my mind the “Active inference” methods by Carl Friston and team where they build a network of prob. distribution (of different families) connected by transformation functions, like non-linearities in ANN, that then they update (their params) to fit the data they are exposed to, so the “prior”, the network of distributions, converges to the real distribution like in Bayes inference.")

#text("My take is, a modified version of it (maybe you need to add a new family of transformation like 1/log(n)) could be used to build a “distribution of primes” or alike, let say by exposing it to the 10, 100, 1000, etc. primes, and trying to find where the succesion of distributions obtained converges or not. If it does, then you end up having a “data-driven” distribution similar to the ones comented above.")

#text("99% it is BS, but who knows!")#linebreak()#text(" Sergio Hernandez.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-682487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2023")])]

#text("Paper on those techniques: ")#link("https://www.sciencedirect.com/science/article/pii/S0022249620300857")[#text("https://www.sciencedirect.com/science/article/pii/S0022249620300857")]

#text("A proposed challenge to find such distributions: ")#link("https://www.lesswrong.com/posts/uH4GfZwBYteiy2GrL/revisiting-the-manifold-hypothesis")[#text("https://www.lesswrong.com/posts/uH4GfZwBYteiy2GrL/revisiting-the-manifold-hypothesis")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-684674")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2024")])]

#text("Dear professor Tao: In the proof of Prediction 8, should the claim that ")#mi("X_n")#text(" is independent of ")#mi("X_m")#text(" unless ")#tao-math("\\left|n - m\\right| \\leq 2", block: false)#text(" be that unless ")#tao-math("\\left|X_n - X_m\\right| = 2", block: false)#text(" instead? And why the required bound then follows from Chebyshev? Thank you.")

#emph[#text("[I believe the statement is correct as written. Note that ")#mi("X_n")#text(" depends only on the events ")#mi("n \\in {\\mathcal P}")#text(", ")#mi("n+2 \\in {\\mathcal P}")#text(", and similarly for ")#mi("X_m")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-684799")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2024")])]

#text("Dear professor Tao:")

#text("For the last proof of Prediction 3, with the given bound, a direct application of Chebyshev’s inequality gives ")#tao-math("{\\bf P}(\\left|\\sum_{2 < n \\leq x} X_n - O(x^{1/2 + o(1)})\\right| \\geq t) \\leq \\frac{O(x^{1+o(1)})}{t^2}", block: false)#text(" for some threshold ")#mi("t > 0")#text(". I wonder what value of ")#mi("t")#text(" is being inserted here and if the ")#mi("O(1)")#text(" term gets absorbed into ")#mi("O(x^{1/2 + \\varepsilon})")#text(" in the end?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-684801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2024")])]

#text("Here we are using Chebyshev’s inequality in what is called the “measure-theoretic” form in ")#link("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality#Measure-theoretic_statement")[#text("https://en.wikipedia.org/wiki/Chebyshev%27s_inequality#Measure-theoretic_statement")]#text(" in order to get more decay in the ")#mi("t")#text(" parameter (by taking the “")#mi("p")#text("” parameter to be large, here we call it ")#mi("k")#text("); the ")#mi("p=2")#text(" case of Chebyshev’s inequality is too weak for this application.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-2/#comment-685600")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] a Siegel zero, standard heuristic models in analytic number theory (such as the ones discussed in this post) typically suggest that a given quantity of interest in number theory (e.g., the number of primes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-448771")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("The RHS of (39) seems to be negative(!) for ")#mi("\\beta \\in (0, 1/2)")#text(" and sufficiently large ")#mi("T")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c53aa0d9d85a2e6cce4eb9690ba86598ddf0fbf30ded7d8e52c07049ef737fff-f5d006be9bbff9977d7ff1a43ff664bb7ac15be1d8c2275ac6c63fc9d48e4a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anthonyquas")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-448783")[#strong[#text("anthonyquas")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("In prediction 3, I guess it should say that the non-vanishing terms in the expectation are from the ")#mi("X_n")#text("‘s that appear at *least* twice (not at most).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-448797")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("Right after Prediction 11, I believe there is a spurious ")#mi("o(1)")#text(" term in the refined estimate. Should it read: ")#mi("\\displaystyle  \\# \\{ p \\leq x: p, p+2 \\in {\\mathcal P}\\} = \\displaystyle 2\\Pi_2 \\int_2^x \\frac{dt}{(\\log t)\\log(t+2)} + O_\\varepsilon(x^{1/2+\\varepsilon})")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-448816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2015")])]

#text("Is there a similar probabilistic prediction of EH conjecture?")

#emph[#text("[Yes, though if one uses only the naive Cramer model one predicts a version of EH that turns out to be a bit too strong to be true. This will be discussed in the notes on sieve theory, which should appear in a few weeks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-448989")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2015")])]

#text("pairs of prime triplets -> prime triplets?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-449017")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2015")])]

#text("I remember getting frustrated the other day I couldn’t find enough primes. Euclid’s argument shows if you have a complete list of primes you can generate one more. But if you just have some of them, you don’t know anything. Then I found some primes on the internet and I was able to produce some of the randomness you speak of.")

#text("In fact, if you wanted to prove a universality phenomenon, you could start by arguing that the Gaussian distribution looks the same at all scales, just have to change the variance. The renormalization group flow is much harder to describe in other situations. Nor do I have any idea what it is!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-449181")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2015")])]

#text("“…we will restrict the sum n to odd n; this is easily accomplished the contribution of even n is O(1)” -> “…we will restrict the sum *over* n to odd n; this is easily accomplished *because* the contribution of even n is O(1)”")

#text("But this be written as -> But this *may* be written as")

#text("view the first as the j=1 term -> view the first *term* as the j=1 term")

#text("Also: The number of formula (23) gets clipped in my (Chrome) browser")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-449387")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2015")])]

#text("The distribution of prime numbers is always in every interval (Dirichlet serie)")

#text("bewen: (30a + 11) and (42a + 43) ; a = (1; 2;3 ;4: 5; …….)")

#text("The number of primes per interval ranges from a minimum of two and a maximum of seven.")

#text("The Riemann Hypotesis has resolved and shows that there are only zeros for ( a = 1/2) if not also for ( a = 1/3 ; 1/5 ; ……..); in all convergent series have the absence of any ")#mi("( n = p{x})")#text("; p > 3")

#text("I present one of the series:")

#mi("\\frac{1}{2} = \\frac{1}{3} + \\frac{1}{9} + \\frac{1}{24} + \\frac{1}{84} + \\frac{1}{972} + \\frac{1}{2921} + \\frac{1}{5832}")

#mi("\\frac{1}{2} = \\frac{1}{3} + \\frac{1}{9} + \\frac{1}{24} + \\frac{1}{84} + \\frac{1}{972} + \\frac{1}{2921} + \\cdot + \\cdot")

#text("and:")

#mi("\\frac{1}{3} = \\frac{1}{4} + \\frac{1}{18} + \\frac{1}{54} + \\frac{1}{162} + \\frac{1}{486} + \\frac{1}{1458} + \\frac{1}{2187} + \\frac{1}{4374}")

#mi("\\frac{1}{3} = \\frac{1}{4} + \\frac{1}{18} + \\frac{1}{54} + \\frac{1}{162} + \\frac{1}{486} + \\frac{1}{1458} + \\frac{1}{2187} + \\cdot + \\cdot")

#text("U. Journal of Applied Mathematic (2013)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-449996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("There is a polynomial generates prime numnbers only (but not all prime numbers).")

#mi("P_{(E)}: 3.4^{x} + 4^{x-1} + 4^{x-2} + \\cdot \\cdot \\cdot + 4^{x-x} = p")

#text("With, x = (1;2;3;4;5;6……….)")

#text("p = (13;53;213;853;3413;13653;……….)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-449997")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("Unfortunately, the next entry ")#mi("54613 = 13 * 4201")#text(" in this sequence (which, incidentally, is not a polynomial sequence) is not prime. (In fact, whenever ")#mi("x = 1\\ (6)")#text(", the quantity generated by this sequence will be divisible by 13.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cd37d11181f4282ef2e0909fec5db2c72d525c14fa37fea0f7dacf3b2ab4710-0c5810760cd84e1faf3fa3081057a476cadf18bfa609c977b5f4f5340d4cb3a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sridhar Ramesh")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-456640")[#strong[#text("Sridhar Ramesh")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2015")])]

#text("213 isn’t prime… It’s 3 * 71. Similarly, 13653 is also divisible by 3, and in general, every third element of this sequence is divisible by 3 [as the remainders modulo 3 increase by 1 each time].")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-450001")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("Naive Q about the Naive Cramer random model: The denominator in the RHS of (1) is the log of a tower of exponentials. Does that tower of exponentials have any independent significance in this context?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-450002")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("Oh – I think it signifies that I forgot how logarithms work:-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-450030")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2015")])]

#text("For a probabilistic prediction of RH with the simplicity of the zeta zeros, consider the Mertens function ")#mi("M(x) := \\sum_{n \\leq x} \\mu(n)")#text(".")#linebreak()#text(" It is known that RH + simplicity of zeta zeros is implied by")

#text("(1) ")#mi("M(x) = o(x^{1/2} \\log x)")

#text("Using probabilistic arguments (the law of iterated logarithm) it was conjectured that")

#text("(2) ")#mi("M(x) \\ll (x \\log \\log x)^{1/2}")

#text("The current conjecture (using more refined analysis) is")

#text("(3) ")#mi("M(x) \\ll x^{1/2} (\\log \\log \\log x)^{5/4}")

#text("(see e.g. ")#link("http://arxiv.org/abs/math/0310381")[#text("http://arxiv.org/abs/math/0310381")]#text(")")

#text("Showing subrandom growth of ")#mi("M(x)")#text(".")

#text("Clearly (1) is implied by both (2) and (3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-450159")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2015")])]

#text("Beginner Q: Can you hint at how the Borel-Cantelli lemma is used to establish that (3) is almost surely true for all x? A straightforward application of the lemma (using the probability estimate you cite) seems to establish only that the probability of (3) being *false* for an infinite number of values of x, is 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-450180")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2015")])]

#text("If (3) only fails for a finite number of values, then it holds for all values after increasing the implied constant in the ")#mi("O_\\varepsilon()")#text(" notation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-451193")[#strong[#text("254A, Supplement 5: The linear sieve and Chen’s theorem (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("[…] number theorem for the Liouville function (Exercise 41 from Notes 2, combined with Exercise 18 from Supplement 4) we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-451889")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] studied, and are conjectured by Conrey and Gonek (using the random matrix model, see Section 4 of Supplement 4) to be asymptotic to for certain explicit constants , but this remains unproven. It can be shown […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 4: Some sieve theory | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-452118")[#strong[#text("254A, Notes 4: Some sieve theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2015")])]

#text("[…] from the equidistribution of residues principle (Section 3 of Supplement 4), bearing in mind (from the modified Cramér model, see Section 1 of Supplement […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-452281")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] the form if one assumes the generalised Riemann hypothesis. The probabilistic random models from Supplement 4 suggest that one should in fact be able to take […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-452368")[#strong[#text("254A, Supplement 6: A cheap version of the theorems of Halasz and Matomaki-Radziwill | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2015")])]

#text("[…] simple sieving argument (see Exercise 18 of Supplement 4) shows that one can replace by the Möbius function and obtain the same conclusion. See this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-453605")[#strong[#text("254A, Notes 8: The Hardy-Littlewood circle method and Vinogradov’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2015")])]

#text("[…] Exercise 4 Obtain a heuristic derivation of the main term using the modified Cramér model (Section 1 of Supplement 4). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0d38ac55a0ee44000066dcb33b14672f60b65d61db23ae06fb80e11b6c1ec7f-8c13bd9fd34724d5b0835b20d13d8c3690855e3d548980a6987d92d2b31b52a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of billy")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-454841")[#strong[#text("billy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2015")])]

#text("Professor Tao")

#text("Is there any proof that the limit of the possibility that the twin prime conjecture is correct equals 1 when prime numbers approach infinity?")

#text("Thank you in advance")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-455957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("in order to make prediction 11 rigorous, define for ")#mi("\\sigma > 1")

#mi("\\zeta_2(s) := \\prod_p (1-p^{-s})^{-1}")

#text("where the product is over all twin primes ")#mi("p")#text(".")

#text("This function is well defined, non-zero and analytic for ")#mi("\\sigma > 1")#text(" (if the twin prime conjecture is false it is defined and analytic for ")#mi("\\sigma > 0")#text(").")

#text("It seems that this function plays a similar role for a possible proof of prediction 11 as the role played by ")#mi("\\zeta (s)")#text(" for the PNT.")#linebreak()#text(" More precisely, it seems that if the second derivative of ")#mi("\\log \\zeta_2(s)")#text(" has an analytic continuation for a neighborhood of the line ")#mi("\\sigma =1")#text(" except for a simple pole at ")#mi("s=1")#text(" than prediction 11 implies (via Perron’s formula) that the residue of this pole should be ")#mi("2 \\Pi_2")#text(" (i.e. the main term constant in prediction 11).")

#text("Is it possible to prove prediction 11 by such (conjectural) properties of ")#mi("\\zeta_2(s)")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-455961")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("One can indeed reformulate the Hardy-Littlewood asymptotic for the number of twin primes (with strong error term) as an assertion about the analytic continuation of ")#mi("\\zeta_2")#text(", but unless one has access to some other characterisation of ")#mi("\\zeta_2")#text(" that does not involve twin primes, this is basically just a restatement of the original problem. The reason why ")#mi("\\zeta")#text(" is such a useful tool is that it has two different interpretations, one as an Euler product and another as the Dirichlet series associated to the natural numbers, which have additive structure as well as multiplicative structure (leading in particular to the Poisson summation formula and thence to the functional equation). In contrast, ")#mi("\\zeta_2")#text(" is the Dirichlet series of the multiplicative semigroup generated by the twin primes, which has no evident additive structure (other than that of being a subset of the natural numbers). In principle, if one knew something further about this multiplicative semigroup, one could say something about twin primes, but thus far the only things we can say about this semigroup come from known or conjectured facts about twin primes, so one is not really making genuine progress through this reformulation at present.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-455971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2015")])]

#text("If ")#mi("\\zeta_2")#text(" has a meromorphic continuation for a neighborhood of ")#mi("s=1")#text(" with a pole at ")#mi("s=1")#text(", then the second derivative of ")#mi("\\log \\zeta_2(s)")#text(" should have a double pole (not a simple pole as stated in my previous comment) at ")#mi("s=1")#text(" with the (conjectured) residue as above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-455976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2015")])]

#text("By expanding ")#mi("1/ \\ zeta_2(s) = \\sum_n \\mu_2(n) n^{-s}")#text(" where ")#mi("\\mu_2(n)")#text(" is the modified Mobius function corresponding to the twin primes, and assuming(!) the corresponding modified RH, i.e.")

#mi("\\sum_{n \\leq x} \\mu_2(n) = O(x^{1/2 +o(1)})")

#text("It follows (via summation by parts) that ")#mi("1/ \\zeta_2(s)")#text(" has an analytic continuation to the half plane ")#mi("\\sigma > 1/2")#text(" (i.e. ")#mi("\\zeta_2(s)")#text(" has a meromorphic non-zero continuation to ")#mi("\\sigma > 1/2")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-456098")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2015")])]

#text("In the proof of Conjecture 7 (using the naive Cramer model), the argument for the upper bound seems to give a bound of ")#mi("O_\\epsilon(X^{-\\epsilon})")#text(" rather that ")#mi("X^{-2}")#text(" for the failure probability, so maybe this should be applied to a lacu")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-456100")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2015")])]

#text("Typos in the proof of Prediction 17 (using modified Cramer model): in the paragraph starting “Fix k.”, ")#mi("L\\le W^3")#text(" should be ")#mi("L\\le w^3")#text(", and a couple of lines later “not coprime to ")#mi("W")#text("” should be “coprime to ")#mi("W")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-457210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2015")])]

#text("Landau’s fourth problem may be generalized by defining an integer ")#mi("L")#text(" to be a “Landau number” if there are infinitely many primes of the form ")#mi("n^2 + L")#text(". Is there any known “landau number”? (or even a proof that the set of “Landau numbers” is nonempty?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-457243")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2015")])]

#text("As far as I know even the weaker statement that there exists a nonlinear polynomial ")#mi("P(n)")#text(" which attains prime values infinitely often is still open (though everyone believes it to be true, of course). Informally, the basic problem is that the set of large numbers ")#mi("m")#text(" which are representable ")#mi("m = P(n)")#text(" as nonlinear polynomials ")#mi("P")#text(" with bounded coefficients and degree applied to a medium-sized input ")#mi("n")#text(" (with ")#mi("n \\sim m^{1/\\text{deg} P}")#text(") is just too sparse a set for any of our current methods to be capable of detecting primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 3: The weak and strong law of large numbers | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-460852")[#strong[#text("275A, Notes 3: The weak and strong law of large numbers | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2015")])]

#text("[…] number theory. (It can be refined to give what are believed to be more accurate predictions; see this previous blog post for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sylvainjulien")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-462103")[#strong[#text("sylvainjulien")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("The following link might be of some interest: ")#link("http://ideasfornumbertheory.com/2015/11/18/a-pnt-based-variance-inequality-for-cramers-conjecture/")[#text("http://ideasfornumbertheory.com/2015/11/18/a-pnt-based-variance-inequality-for-cramers-conjecture/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-464711")[#strong[#text("Pumping the Primes | TRIFORCE STUDIO")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2016")]

#text("[…] the individual primes fall within the interval. For more on randomness and the primes, see the erudite essay of Terry Tao.There’s nothing random or indeterminate about the distribution of the primes, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2016")])]

#text("Is it possible to predict by the above probabilistic models a distribution law for Mersenne primes? similarly, is it possible to predict that there are only finitely many Fermat primes?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465613")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2016")])]

#text("Yes, though things are a little tricky for Mersenne and Fermat primes because of some patterns in the distribution of ")#mi("2^n \\pm 1")#text(" modulo various primes, and I think we are in general not as confident in our heuristics for such exponentially sparse sequences as we are for, say, twin primes, for which much more numerical evidence is available. See e.g. ")#link("http://www.utm.edu/staff/caldwell/preprints/Heuristics.pdf")[#text("http://www.utm.edu/staff/caldwell/preprints/Heuristics.pdf")]#text(" for a discussion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2016")])]

#text("Thanks for your answer and the link!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465877")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2016")])]

#text("If one applies the naive Cramer model to provide a hueristic to log(x)-rough numbers, that is locating an interval free of log(x)-rough numbers, then this predicts order of magnitude ")#mi("log(x)log_2(x)")#text(". But it seems to me if one assumes a uniform k-tuples conjecture, one could prove something significantly stronger using your work with Ford, Green, Konyagin and Maynard. I am curious what is going on here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa1324c1c994de839ea47c1d3fc090678b0f30678ef9322eb0fb7c21d28a5761-0bc6d52660a40354927956fb97c9f4ccdb5632a4a81997c2618c656e6462fd96.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zak")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465990")[#strong[#text("Zak")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("I made a silly mistake in the previous post, but I still have a question. The Cramer model for log(x)-rough numbers would predict gaps of order log(x)log(log(x)), yet it is conjectured that ")#mi("Y(x) \\geq x \\log(x)^{2-\\epsilon}")#text(", which would improve upon gaps for log(x)-rough number beyond the Cramer model.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-465993")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2016")])]

#text("Yes, the primes have (or are conjectured to have) unexpected irregularity (not predicted by the naive Cramer model) when measured in intervals of length close to ")#mi("\\log x")#text(" due to the largeness of the Jacobsthal function, a fact first observed by Maier. See ")#link("http://www.ams.org/mathscinet-getitem?mr=1403939")[#text("this survey of Granville")]#text(" for some more discussion.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-466691")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2016")])]

#text("At the end of prediction 3, it says “From Chebyshev’s inequality this implies that ")#mi("{\\sum_{n \\leq x} X_n = O( x^{1/2+\\varepsilon})}")#text(" with probability ")#mi("{O( x^{-k\\varepsilon + o(1)})}")#text(".” Should this be “with probability ")#mi("{1-O( x^{-k\\varepsilon + o(1)})}")#text("“?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biases between consecutive primes | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-466951")[#strong[#text("Biases between consecutive primes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2016")])]

#text("[…] nature of the bias.) The naive Cramér random model for the primes (discussed for instance in this post) suggests, as a first approximation, that for any , the number of prime differences that are equal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-467489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2016")])]

#text("Consider Ramanujan’s description (as told by Hardy) of 1729 as “the smallest number expressible as a sum of two cubes in two different ways”, is there any probabilistic prediction for the size of this number with the corresponding property for a general exponent ")#mi("n>3")#text(" ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-467499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2016")])]

#text("It is believed that no such solutions exist for ")#mi("n \\geq 5")#text(", see ")#link("https://en.wikipedia.org/wiki/Lander,_Parkin,_and_Selfridge_conjecture")[#text("https://en.wikipedia.org/wiki/Lander,_Parkin,_and_Selfridge_conjecture")]#text(" ; this is consistent with the probabilistic heuristics of this post. For ")#mi("n=4")#text(", some parametric infinite families of solutions are known, starting with ")#mi("59^4+158^4=133^4+134^4")#text(". One can in fact find (a translation of) Euler’s original article on this on the arXiv at ")#link("http://arxiv.org/abs/math/0505629")[#text("http://arxiv.org/abs/math/0505629")]#text(" . The ")#mi("n=4")#text(" situation here is similar to that of the ")#mi("n=3")#text(" FLT, in that naive probabilistic heuristics, not taking into account the presence of low genus curves, give slightly incorrect predictions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-467696")[#strong[#text("Bayesianism, frequentism, and the planted clique, or do algorithms believe in unicorns? | Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2016")]

#text("[…] hope is to obtain general heuristic methods that, like random models for the primes in number theory or the replica method in statistical physics, would allow us to predict the right […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-470398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("Is there any probabilistic (perhaps even effective) prediction for the abc conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-470860")[#strong[#text("Clarify and justify how get the derivative of the Laplace transform of the Buchstab function - mathfreebook")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2016")]

#text("[…] of Buchstab function, and its Laplace transform from Tao What’s new? I say Exercise 28 of 254A, Supplement 4: Probabilistic models and heuristics for primes, and take required theorems from Wikipedia Differentiation under the integral sign. I¡ve computed […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic computation of correlations of the divisor function | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-472023")[#strong[#text("Heuristic computation of correlations of the divisor function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("[…] of (2) and modify it a bit, in the spirit of the “modified Cramér models” from this previous blog post. Our arguments here will be even less rigorous than in the preceding section, for instance we shall […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Bajaj")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-474087")[#strong[#text("Ravi Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("The last remark was over my head but Remark 43 really clarifies the situation. I didn’t actually get that universality was at play in the GUE hypothesis… I was misled by the idea that you refer to about operators.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Bajaj")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-474108")[#strong[#text("Ravi Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2016")])]

#text("Follow Up: As I study measure theory… this is sort of the goal of the output of my understanding: to know this PDF:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Bajaj")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-474109")[#strong[#text("Ravi Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2016")])]

#text("Follow Up: As I study measure theory… this is sort of the goal of the output of my understanding: to know this article “Nonclassical stochastic flows")#linebreak()#text(" and continuous products” by Tsilerson.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/760ddd8bad27c570c5995a8ca954c5a38fd4fac69f38771b25a6b6db36d6b11e-4ad57592ce78782880a2c818635ada04dd6ba4cba69ace173598d068d4466749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Romain Viguier")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-477562")[#strong[#text("Romain Viguier")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2017")])]

#text("Trial : numbers in a structure => failure")#linebreak()#text(" Do we have to organize numbers in a structure? I don’t think so, at least not a linear structure because we only get observation and")#linebreak()#text(" that is not what I am looking for.")

#text("Other trial => works better")#linebreak()#text(" For an defined metric associated with a space in discrete expansion. Between 2 expansion e1 and e2 successive, relation")#linebreak()#text(" e2/e1 gives an other data : a cost of passage always > 1.")

#text("About metric and cost of passage :")#linebreak()#text(" The cost of passage is a feature starting from 0 (or at least normalized by 0) and related to numbers whereas metric has not start : it normalize the counting.")#linebreak()#text(" We can say that the cost of passage is the cost we need to provide to make the metric structure expend.")

#text("Mathematical axioms tell us we can infinitely extend this space metric either step by step : x (i+1) = x (i) +1 or not.")

#text("Now, let’s add a property that will have some numbers : being prime numbers.")#linebreak()#text(" The question we could ask is: is there an infinity of twin prime?")#linebreak()#text(" Reformulated : does it always exist 2 successive costs of passage e(i+3)/e(i+2) and e(i+2)/e(i+1) such as e(i+3) and e(i+1) are prime?")

#text("The question is not to simply be in the world of integers but also in the world of prime numbers (sort of abstraction of integers) and it means")#linebreak()#text(" that we can have a finitude of twin prime even if it exists an inifinity of integers.")

#text("But I have no idea how to start the demonstration, it was a reformulation of the problem to better understand what this problem is about.")#linebreak()#text(" I think my next step is to better and deeply understand prime numbers because I hate to introduce this property (prime) without fully understand the links.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c52962bc085c7a82d04195e391c8d1dd9823b60f861c7fa58f17c1556f940ca-c16e3318fc36ca622d2ae21f93beccb0cf4e23cf11549706a7dbc6a01802ec69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sander Henstra")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-481244")[#strong[#text("Sander Henstra")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("Dear professor Tao,")

#text("In many applications of the Cramer random model, e.g. in your proof of prediction 3 (RH), one relies on the independency of the random primes. For the actual primes, there is a large correlation however, at any range. This is not often mentioned; I could only find one reference:")#linebreak()#text(" P. Leboeuf, “Prime Correlations and Fluctuations”, Annales Henri Poincare 4-2, 727-752, section 4.2.")#linebreak()#text(" For the prime counting function ")#mi("\\pi(x)")#text(", the correlation occurs on a logarithmic scale, or in other words there is a correlation between ")#mi("\\pi(x)")#text(" and ")#mi("\\pi(F \\cdot x)")#text(". The autocorrelation function doesn’t vanish for ")#mi("F \\rightarrow \\infty")#text("; it keeps oscillating between ")#mi("\\pm 0.4")#text(" typically, dominated by the first few non-trivial zeroes of the Riemann zeta function. Simulations for a few 1000 sample points (evenly distributed on the log-scale) already show a striking and almost noiseless match with theory. And yet this phenomenon seems heavily under-exposed in the literature;")#linebreak()#text(" I wonder why. Isn’t this a serious problem for some heuristic arguments using random prime models?")

#text("best regards & many thanks for your blogs,")#linebreak()#text(" Sander Henstra")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-482149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2017")])]

#text("Yes, when dealing with multiplicative correlations (such as between $x$ and $Fx$) instead of additive correlations, there are some additional biases which show up. The most obvious example of multiplicative bias is that the product of two primes is never a prime. In the context of random multiplicative functions, the multiplicativity does distort some statistics in a subtle way when compared against non-multiplicative random functions: see for instance ")#link("https://arxiv.org/abs/1703.06654")[#text("this recent work of Harper")]#text(", where some sub-random phenomena are unearthed. However, for additive correlations such as those related to the twin prime conjecture, the effect of this multiplicative structure is expected to be negligible (except for its influence on local factors at small primes).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c52962bc085c7a82d04195e391c8d1dd9823b60f861c7fa58f17c1556f940ca-c16e3318fc36ca622d2ae21f93beccb0cf4e23cf11549706a7dbc6a01802ec69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sander Henstra")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-481264")[#strong[#text("Sander Henstra")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2017")])]

#text("I forgot the year in the ref.: 2003.")#linebreak()#text(" And the autocorrelation function is of course defined for fluctuations of ")#mi("\\pi(x)")#text(" around the expected value ")#mi("\\pi_0(x) = {\\rm Li}(x) - \\frac{1}{2} {\\rm Li}(\\sqrt {x}) - .. \\;")#text(". To be precise, it is calculated for the scaled function ")#mi("\\sqrt {x} \\left( 1 - \\pi(x)/\\pi_0(x) \\right)")#text(", rewritten as a function")#linebreak()#text(" of ")#mi("u = {\\log x}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions I. Long shift ranges | What's new")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-483422")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions I. Long shift ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("[…] (half of) the twin prime constant. See for instance this previous blog post for a a heuristic explanation of this conjecture. From the previous discussion we see that (2) for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6944764d5734b6b2f81fc19c8c26bc7c29c8ac8076459181ad7df03befe36d96-5a960e7f49ce3faca59a821a379ec50f8238493e0bf99679530c559039f8e0aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-486343")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("A comment on Moebius function consecutive values:")#linebreak()#text(" Exercise: Prove without a computer that there must be at least 1440 sequences of 11 consecutive ‘0’ for numbers less than (19#)^2 (primorial of 19, squared).")#linebreak()#text(" Solution: Consider the sequences 4,9,x,x,4,x,x,x,4,x,9 of 11 consecutive integers, the 1st, 5th, and 9th being multiples of 4, the 2nd and 11th being multiples of 9, and the 6 others marked ‘x’ being respectively multiples of 5^2, 7^2, 11^2, 13^2, 17^2, and 19^2. There are 6! = 720 ways to assign these numbers to the ‘x’ positions and for each combination one can solve the 11 congruence equations (n = 0 mod4, n+1 = 0 mod9, …) to get a unique positive integer n less than (2.3.5.7.11.13.17.19)^2 = (19#)^2 verifying the equations. The same process can be repeated for the sequences 9,x,4,x,x,x,4,x,x,9,4 hence the answer 2 x 6! = 1440.")

#text("And by the Chinese remainder theorem it is clear that there is an infinite number of sequences of k consecutive ‘0’ in the Moebius function sequence, for any value of k as large as it may be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6944764d5734b6b2f81fc19c8c26bc7c29c8ac8076459181ad7df03befe36d96-5a960e7f49ce3faca59a821a379ec50f8238493e0bf99679530c559039f8e0aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-486344")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Questions for Prof. Tao:")#linebreak()#text(" 1. Let ")#mi("h(x)=\\sum_{k=1}^{x}\\frac{\\mu(k)}{k}")#text(". Is there a proof that h(x) changes sign infinitely often?")

#text("2. Let ")#mi("s(a,b)=\\sum_{k=1}^{\\infty}\\frac{\\mu(ak+b)}{ak+b}")#text(". Is it known (published) that ")#mi("s(4,1)=-s(4,3)=2/\\pi")#text(", ")#mi("s(3,1)=-s(3,2)=3\\sqrt{3}/{2\\pi}")#text(", ")#mi("s(6,1)=-s(6,5)=\\sqrt{3}/\\pi")#text(", ")#mi("s(6,4)=-s(6,2)=\\sqrt{3}/2\\pi")#text(" etc. ? I have the formulas for many more…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6944764d5734b6b2f81fc19c8c26bc7c29c8ac8076459181ad7df03befe36d96-5a960e7f49ce3faca59a821a379ec50f8238493e0bf99679530c559039f8e0aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-486351")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("I call ‘Moebius twin primes’ the twin prime numbers 6p – 1 , 6p + 1 where p is a prime. E.g. p = 2, 3, 5, 7, 17, etc. It seems likely that there are an infinity of those and ")#mi("\\mu (6p-1) = \\mu (6p) = \\mu (6p + 1) = -1")#text(", which implies that there is an infinity of sequences (0, -1, -1, -1, 0) in the Moebius function sequence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6944764d5734b6b2f81fc19c8c26bc7c29c8ac8076459181ad7df03befe36d96-5a960e7f49ce3faca59a821a379ec50f8238493e0bf99679530c559039f8e0aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-486352")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("For p > 3 !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6944764d5734b6b2f81fc19c8c26bc7c29c8ac8076459181ad7df03befe36d96-5a960e7f49ce3faca59a821a379ec50f8238493e0bf99679530c559039f8e0aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Montaron")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-486354")[#strong[#text("Bernard Montaron")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2017")])]

#text("Given two distinct odd primes p, q, I call ‘Moebius prime triplets’ the numbers p1 = 1+2p”(q’-p’)+2qk p2 = 1+2q”(q’-p’)+2pk p3 = p’+pp”(q’-p’)+pqk provided they are all primes (for a well chosen k). p’, p”, q’, q” are integers defined by p = 2p’-1, q=2q’+1, and pp”- qq” = 1. p3 must be odd, therefore k is even if p’ is odd, and k is odd if p’ is even.")

#text("It seems likely that for every pair (p,q) of distinct odd primes, there exists at least one k value such that p1, p2, and p3 are all primes. And this implies that ")#mi("\\mu (2p3 -1) = \\mu (2p3) = \\mu (2p3 + 1) = +1")#text(", i.e. there is an infinity of sequences (0, +1, +1, +1, 0) in the Moebius function sequence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87aaf7979c0019af545ce8e6f678a3254023135626a998bcf7e69a5c911c689d-8de4d7e8d4f2f6e9f8d33e51a72ac830caf695d26a521f717d01dadbd19e5101.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Poisson Distribution in Prime Number Theory | Iterated logarithm")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-491465")[#strong[#text("Poisson Distribution in Prime Number Theory | Iterated logarithm")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2018")])]

#text("[…] may consult blog by Tao for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-510661")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("Let ")#mi("b,q \\in \\mathbb{P}")#text(" and ")#mi("d \\in \\mathbb{N}")#text(", consider the function :")#linebreak()#text(" ")#mi("\\Upsilon_{b,q}(d) = {\\small \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\frac{d}{a}}\\right)}")

#text("Then we can proof:")#linebreak()#text(" ")#mi("\\Upsilon_{b,q}(d) = {\\small \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\left(\\frac{d-1}{a-1}\\right)^2}\\right)} {\\small \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\frac{1}{a}}\\right)}^2 {\\small \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} \\left({\\normalsize 1+\\frac{d-2}{a}}\\right)}^{-1}")

#text("If we Consider functions :")#linebreak()#text(" ")#mi("F_b(x) = {\\small \\prod_{\\substack{b \\leq a \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\frac{x^2}{a^2}}\\right)}")#linebreak()#text(" and")#linebreak()#text(" ")#mi("C_b(d) = {\\small \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\left(\\frac{d-1}{a-1}\\right)^2}\\right)}")

#text("We have :")#linebreak()#text(" ")#mi("\\Upsilon_{b,q}(d) \\sim \\left\\{ \\begin{array}{cl}1 & \\text{ if } \\ d = 0 \\\\\\dfrac{e^{-\\gamma}}{K_b \\ln(q)} & \\text{ if } \\ d = 1 \\\\ \\\\\\dfrac{C_b(d) \\, e^{-2\\gamma}}{K_b^2 \\, F_b(d-2) \\, \\ln^{2}(q)} \\Upsilon_{b,q}(d-2) & \\text{ if } \\ d \\geq 2\\end{array} \\right.")

#text("This recursive formula give :")#linebreak()#text(" ")#mi("\\Upsilon_{b,q}(d) \\sim \\left\\{ \\begin{array}{cl}\\dfrac{C_b(2) C_b(4) \\cdots C_b(d) \\, e^{- d \\gamma}}{F_b(0) F_b(2) F_b(4) \\cdots F_b(d-2) K_b^d} \\,\\, \\dfrac{1}{\\ln^d(q)} & \\text{ if } \\ \\text{d is even} \\\\ \\\\\\dfrac{C_b(3) C_b(5) \\cdots C_b(d) \\, e^{- d \\gamma}}{F_b(1) F_b(3) \\cdots F_b(d-2) K_b^d} \\,\\, \\dfrac{1}{\\ln^d(q)} & \\text{ if } \\ \\text{d is odd}\\end{array} \\right.")

#text("Let ")#mi("n \\in \\mathbb{N}")#linebreak()#text(" If we denote ")#mi("q(n)")#text(" the small prime verify ")#mi("n < {\\small \\left( \\prod_{\\substack{a \\leq q(n) \\\\ \\text{a prime}}} {\\normalsize a} \\right)}")#text(" we can proof that $I_n \\sim e^{-\\gamma} \\frac{n}{\\ln\\ln(n)}$, with $I_n$$ is the number of elements less than n and coprime to ${\\small \\left( \\prod_{\\substack{a \\leq q(n) \\\\ \\text{a prime}}} {\\normalsize a} \\right)}$")

#text("Show that ")#mi("\\pi(n) \\sim \\frac{n}{\\ln(n)}")

#text("Consider the set ")#mi("\\mathcal{B}_q")

#mi("\\mathcal{B}_q=\\{b \\in \\mathbb{N}^{*} \\, | \\, b \\wedge {\\small \\left( \\prod_{\\substack{a \\leq q \\\\ \\text{a prime}}} {\\normalsize a} \\right)}=1 \\text{ and } b \\leq {\\small \\left( \\prod_{\\substack{a \\leq q \\\\ \\text{a prime}}} {\\normalsize a} \\right)} \\}")

#text("If we use this analogy we can say that :")#linebreak()#text(" ")#mi("\\pi_{g}(n) \\sim \\left\\{ \\begin{array}{cl}\\dfrac{1}{\\displaystyle{\\small \\left( \\prod_{\\substack{a < b \\\\ \\text{a prime}}} {\\normalsize a} \\right)}} \\dfrac{C_b(2) C_b(4) \\cdots C_b(d)}{F_b(0) F_b(2) F_b(4) \\cdots F_b(d-2) K_b^d} \\,\\, \\dfrac{n}{\\ln^d(n)} & \\text{ if } \\ \\text{d is even} \\\\ \\\\\\dfrac{1}{\\displaystyle{\\small \\left( \\prod_{\\substack{a < b \\\\ \\text{a prime}}} {\\normalsize a} \\right)}}\\dfrac{C_b(3) C_b(5) \\cdots C_b(d)}{F_b(1) F_b(3) \\cdots F_b(d-2) K_b^d} \\,\\, \\dfrac{n}{\\ln^d(n)} & \\text{ if } \\ \\text{d is odd}\\end{array} \\right.")#linebreak()#text(" with g is a gap of d consecutif primes, and verify that ")#mi("\\#\\{(\\beta_1,\\cdots,\\beta_d) \\in \\mathcal{B}_q^d \\text{ and } (\\beta_1,\\cdots,\\beta_d) \\text{ in gap g }\\} = {\\small \\left( \\prod_{\\substack{b \\leq a \\leq q \\\\ \\text{a prime}}} {\\normalsize (a-d)} \\right)} + C")#text(" With C is a constante.")#linebreak()#text(" I write 2 articles about that :")#linebreak()#text(" ")#link("http://lagrida.com/prime_numbers_construction.html")[#text("http://lagrida.com/prime_numbers_construction.html")]#linebreak()#text(" ")#link("http://lagrida.com/Fondamentale_Conjonctures_Prime_Numbers.html")[#text("http://lagrida.com/Fondamentale_Conjonctures_Prime_Numbers.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e00078a8c46fa0e0e324652e18fc56f727ea3c48adcce65393ab3108b85c3e6b-742020c8dab9b2728a436d1a6771b778dd726785efdc45f0a586565a48c3e7c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAGRIDA")]], [#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/comment-page-1/#comment-510662")[#strong[#text("LAGRIDA")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("The constante : ")#mi("K_b = {\\small \\prod_{\\substack{a < b \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\frac{1}{a}}\\right)}")

#text("The function $C_b(d) = {\\small \\prod_{\\substack{b \\leq a \\\\ \\text{a prime}}} \\left({\\normalsize 1-\\left(\\frac{d-1}{a-1}\\right)^2}\\right)} $")

#text("And ")#mi("I_n \\sim e^{-\\gamma} \\frac{n}{\\ln\\ln(n)}")#text(", with ")#mi("I_n")#text("$ is the number of elements less than n and coprime to ")#mi("{\\small \\left( \\prod_{\\substack{a \\leq q(n) \\\\ \\text{a prime}}} {\\normalsize a} \\right)}")
]
]
