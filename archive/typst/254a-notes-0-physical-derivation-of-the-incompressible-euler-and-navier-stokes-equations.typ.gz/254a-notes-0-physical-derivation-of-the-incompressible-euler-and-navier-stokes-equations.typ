// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/
// Converted to Typst by tao2typ: "2026-10-14T10:47:36.198906+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 0: Physical derivation of the incompressible Euler and Navier-Stokes equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 0: Physical derivation of the incompressible Euler and Navier-Stokes equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 September 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")[#text("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This coming fall quarter, I am ")#link("https://ccle.ucla.edu/course/view/18F-MATH254A-1")[#text("teaching a class on topics")]#text(" in the mathematical theory of incompressible fluid equations, focusing particularly on the incompressible ")#link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler")]#text(" and ")#link("https://en.wikipedia.org/wiki/Navier%E2%80%93Stokes_equations")[#text("Navier-Stokes equations")]#text(". These two equations are by no means the only equations used to model fluids, but I will focus on these two equations in this course to narrow the focus down to something manageable. I have not fully decided on the choice of topics to cover in this course, but I would probably begin with some core topics such as local well-posedness theory and blowup criteria, conservation laws, and construction of weak solutions, then move on to some topics such as boundary layers and the Prandtl equations, the Euler-Poincare-Arnold interpretation of the Euler equations as an infinite dimensional geodesic flow, and some discussion of the Onsager conjecture. I will probably also continue to more advanced and recent topics in the winter quarter.")

#text("In this initial set of notes, we begin by reviewing the physical derivation of the Euler and Navier-Stokes equations from the first principles of Newtonian mechanics, and specifically from ")#link("https://en.wikipedia.org/wiki/Newton%27s_laws_of_motion")[#text("Newton’s famous three laws of motion")]#text(". Strictly speaking, this derivation is not needed for the mathematical analysis of these equations, which can be viewed if one wishes as an arbitrarily chosen system of partial differential equations without any physical motivation; however, I feel that the derivation sheds some insight and intuition on these equations, and is also worth knowing on purely intellectual grounds regardless of its mathematical consequences. I also find it instructive to actually see the journey from Newton’s law")

#align(center)[#tao-fit-display[#mitex("F = ma")]]

#text("to the seemingly rather different-looking law")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = -\\nabla p + \\nu \\Delta u", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("for incompressible Navier-Stokes (or, if one drops the viscosity term ")#mi("{\\nu \\Delta u}")#text(", the Euler equations).")

#text("Our discussion in this set of notes is physical rather than mathematical, and so we will not be working at mathematical levels of rigour and precision. In particular we will be fairly casual about interchanging summations, limits, and integrals, we will manipulate approximate identities ")#mi("{X \\approx Y}")#text(" as if they were exact identities (e.g., by differentiating both sides of the approximate identity), and we will not attempt to verify any regularity or convergence hypotheses in the expressions being manipulated. (The same holds for the exercises in this text, which also do not need to be justified at mathematical levels of rigour.) Of course, once we resume the mathematical portion of this course in subsequent notes, such issues will be an important focus of careful attention. This is a basic division of labour in mathematical modeling: non-rigorous heuristic reasoning is used to derive a mathematical model from physical (or other “real-life”) principles, but once a precise model is obtained, the analysis of that model should be completely rigorous if at all possible (even if this requires applying the model to regimes which do not correspond to the original physical motivation of that model). See the discussion by John Ball quoted at the end of ")#link("https://www.macs.hw.ac.uk/~chris/icms/GeomAnal/friesecke.pdf")[#text("these slides of Gero Friesecke")]#text(" for an expansion of these points.")

#text("Note: our treatment here will differ slightly from that presented in many fluid mechanics texts, in that it will emphasise first-principles derivations from many-particle systems, rather than relying on bulk laws of physics, such as the laws of thermodynamics, which we will not cover here. (However, the derivations from bulk laws tend to be more robust, in that they are not as reliant on assumptions about the particular interactions between particles. In particular, the physical hypotheses we assume in this post are probably quite a bit stronger than the minimal assumptions needed to justify the Euler or Navier-Stokes equations, which can hold even in situations in which one or more of the hypotheses assumed here break down.)")

#metadata(none) <tao-0ec473f83349331c55a3>

#heading(level: 1)[#strong[#text(" — 1. From Newton’s laws to the Euler and Navier-Stokes equations — ")]]

#text("For obvious reasons, the derivation of the equations of fluid mechanics is customarily presented in the three dimensional setting ")#mi("{d=3}")#text(" (and sometimes also in the two-dimensional setting ")#mi("{d=2}")#text("), but actually the general dimensional case is not that much more difficult (and in some ways clearer, as it reveals that the derivation does not depend on any structures specific to three dimensions, such as the ")#link("https://en.wikipedia.org/wiki/Cross_product")[#text("cross product")]#text("), so for this derivation we will work in the spatial domain ")#mi("{{\\bf R}^d}")#text(" for arbitrary ")#mi("{d}")#text(". One could also work with bounded domains ")#mi("{\\Omega \\subset {\\bf R}^d}")#text(", or periodic domains such as ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text("; the derivation is basically the same, thanks to the local nature of the forces of fluid mechanics, except at the boundary ")#mi("{\\partial \\Omega}")#text(" where the situation is more subtle (and may be discussed in more detail in later posts). For sake of notational simplicity, we will assume that the time variable ")#mi("{t}")#text(" ranges over the entire real line ")#mi("{{\\bf R}}")#text("; again, since the laws of classical mechanics are local in time, one could just as well restrict ")#mi("{t}")#text(" to some sub-interval of this line, such as ")#mi("{[0,T)}")#text(" for some time ")#mi("{T>0}")#text(".")

#text("Our starting point is Newton’s second law ")#mi("{F=ma}")#text(", which (partially) describes the motion of a particle ")#mi("{P}")#text(" of some fixed mass ")#mi("{m > 0}")#text(" moving in the spatial domain ")#mi("{{\\bf R}^d}")#text(". (Here we assume that the mass ")#mi("{m}")#text(" of a particle does not vary with time; in particular, our discussion will be purely non-relativistic in nature, though it is possible to derive a ")#link("https://en.wikipedia.org/wiki/Relativistic_Euler_equations")[#text("relativistic version of the Euler equations")]#text(" by variants of the arguments given here.) We write Newton’s second law as the ordinary differential equation")

#align(center)[#tao-fit-display[#mitex("m \\frac{d^2}{dt^2} x(t) = F(t)")]]

#text("where ")#mi("{x: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" is the trajectory of the particle (thus ")#mi("{x(t) \\in {\\bf R}^d}")#text(" denotes the position of the particle at time ")#mi("{t}")#text("), and ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" is the force applied to that particle. If we write ")#mi("{x_1,\\dots,x_d: {\\bf R} \\rightarrow {\\bf R}}")#text(" for the ")#mi("{d}")#text(" coordinates of the vector-valued function ")#mi("{x: {\\bf R} \\rightarrow {\\bf R}^d}")#text(", and similarly write ")#mi("{F_1,\\dots,F_d: {\\bf R} \\rightarrow {\\bf R}}")#text(" for the components of ")#mi("{F}")#text(", we therefore have")

#align(center)[#tao-fit-display[#mitex("m \\frac{d^2}{dt^2} x_i(t) = F_i(t)")]]

#text("where we adopt in this section the convention that the indices ")#mi("{i,j,k,l}")#text(" are always understood to range from ")#mi("{1}")#text(" to ")#mi("{d}")#text(".")

#text("If one has some collection ")#mi("{(P^{(a)})_{a \\in A}}")#text(" particles instead of a single particle, indexed by some set of labels ")#mi("{A}")#text(" (e.g. the numbers from ")#mi("{1}")#text(" to ")#mi("{N}")#text(", if there are a finite number ")#mi("{N}")#text(" of particles; for unbounded domains such as ")#mi("{{\\bf R}^d}")#text(" one can also imagine situations in which ")#mi("{A}")#text(" is infinite), then for each ")#mi("{a \\in A}")#text(", the ")#mi("{a^{th}}")#text(" particle ")#mi("{P^{(a)}}")#text(" has some mass ")#mi("{m^{(a)} > 0}")#text(", some trajectory ")#mi("{x^{(a)}: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" (with components ")#mi("{x^{(a)}_i: {\\bf R} \\rightarrow {\\bf R}}")#text("), and some force applied ")#mi("{F^{(a)}: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" (with components ")#mi("{F^{(a)}_i: {\\bf R} \\rightarrow {\\bf R}}")#text(", we thus have the equation of motion")

#align(center)[#tao-fit-display[#mitex("m^{(a)} \\frac{d^2}{dt^2} x^{(a)}(t) = F^{(a)}(t)")]]

#text("or in components")

#align(center)[#tao-fit-display[#mitex("m^{(a)} \\frac{d^2}{dt^2} x^{(a)}_i(t) = F^{(a)}_i(t).")]]

#text("In this section we adopt the convention that the indices ")#mi("{a,b,c}")#text(" are always understood to range over the set of labels ")#mi("{A}")#text(" for the particles; in particular, their role should not be confused with those of the coordinate indices ")#mi("{i,j,k}")#text(".")

#text("Newton’s second law does not, by itself, completely specify the evolution of a system of ")#mi("{N}")#text(" particles, because it does not specify exactly how the forces ")#mi("{F^{(a)}}")#text(" depend on the current state of the system. For ")#mi("{N}")#text(" particles, the current state at a given time ")#mi("{t}")#text(" is given by the positions ")#mi("{x^{(b)}(t), b \\in A}")#text(" of all the particles ")#mi("{P^{(b)}}")#text(", as well as their velocities ")#mi("{\\frac{d}{dt} x^{(b)}(t), b \\in A}")#text("; we assume for simplicity that the particles have no further physical characteristics or internal structure of relevance that would require more state variables than these. (No higher derivatives need to be specified beyond the first, thanks to Newton’s second law. On the other hand, specifying position alone is insufficient to describe the state of the system; this was noticed as far back as Zeno in his ")#link("https://en.wikipedia.org/wiki/Zeno%27s_paradoxes#Arrow_paradox")[#text("paradox of the arrow")]#text(", which in retrospect can be viewed as a precursor to Newton’s second law insofar as it demonstrated that the laws of motion needed to be second-order in time (in contrast, for instance, to ")#link("https://en.wikipedia.org/wiki/Aristotelian_physics")[#text("Aristotlean physics")]#text(", which was morally first-order in nature).) At a fundamental level, the dependency of forces on the current state are governed by the laws of physics for such forces; for instance, if the particles interact primarily through electrostatic forces, then one needs the laws of electrostatics to describe these forces. (In some cases, such as electromagnetic interactions, one cannot accurately model the situation purely in terms of interacting particles, and the equations of motion will then involve some additional mediating fields such as the electromagnetic field; but we will ignore this possibility in the current discussion for sake of simplicity.)")

#text("Fortunately, thanks to other laws of physics, and in particular Newton’s other two laws of motion, one can still obtain partial information about the forces ")#mi("{F^{(a)}}")#text(" without having to analyse the fundamental laws producing these forces. For instance, Newton’s first law of motion (when combined with the second) tells us that a single particle ")#mi("{P^{(a)}}")#text(" does not exert any force on itself; the net force on ")#mi("{P^{(a)}}")#text(" only arises from interaction with other particles ")#mi("{P^{(b)}}")#text(", ")#mi("{b \\neq a}")#text(" (for this discussion we neglect external forces, such as gravity, although one could easily incorporate such forces into this discussion; see Exercise ")#link(<tao-d4e3fc7b0477747da28f>)[#text("3")]#text(" below). We will assume that the only forces present are pair interactions coming from individual pairs of particles ")#mi("{(P^{(a)},P^{(b)})}")#text("; it is theoretically possible that one could have more complicated interactions between, say, a triplet ")#mi("{(P^{(a)},P^{(b)}, P^{(c)})}")#text(" of particles that do not simply arise from the interactions between the three pairs ")#mi("{(P^{(a)},P^{(b)})}")#text(", ")#mi("{(P^{(a)},P^{(c)})}")#text(", ")#mi("{(P^{(b)},P^{(c)})}")#text(", but we will not consider this possibility here. We also assume that the net force on a particle is just the sum of all the interacting forces (i.e., the force addition law contains no nonlinear terms). This gives us a decomposition")

#align(center)[#tao-fit-display[#mitex("F^{(a)} = \\sum_{b: b \\neq a} F^{(ab)}")]]

#text("of the net force ")#mi("{F^{(a)}: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" on a particle ")#mi("{P^{(a)}}")#text(" into the interaction force ")#mi("{F^{(ab)}: {\\bf R} \\rightarrow {\\bf R}^d}")#text(" exerted on ")#mi("{P^{(a)}}")#text(" by another particle ")#mi("{P^{(b)}}")#text(". Thus the equation of motion is now ")#metadata(none) <tao-305238273bb0fac2a73b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("m^{(a)} \\frac{d^2}{dt^2} x^{(a)}(t) = \\sum_{b: b \\neq a} F^{(ab)}(t)")]]





#text("Of course, this description is still incomplete, because we have not specified exactly what the interaction forces ")#mi("{F^{(ab)}}")#text(" are. But one important constraint on these forces is provided by Newton’s third law ")#metadata(none) <tao-b1e99324505bd32da0e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("F^{(ba)} = - F^{(ab)}.")]]



#text(" This already gives some restrictions on the possible dynamics. For instance, it implies (formally, at least) that the total ")#link("https://en.wikipedia.org/wiki/Momentum")[#text("momentum")]#text(" ")#metadata(none) <tao-f4a4ce5fa6340a35aa5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_a m^{(a)} \\frac{d}{dt} x^{(a)}")]]



#text(" (which takes values in ")#mi("{{\\bf R}^d}")#text(") is conserved in time:")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} \\sum_a m^{(a)} \\frac{d}{dt} x^{(a)}  & = \\sum_a m^{(a)} \\frac{d^2}{dt^2} x^{(a)}", block: true)



#tao-math(" & = \\sum_a \\sum_{b \\neq a} F^{(ab)}", block: true)



#tao-math(" & = \\frac{1}{2} \\sum_{a,b: a \\neq b} F^{(ab)} + F^{(ba)}", block: true)



#tao-math(" & = 0.", block: true)
]

#text("We will also assume that the interaction force ")#mi("{F^{(ab)}}")#text(" between a pair ")#mi("{P^{(a)}, P^{(b)}}")#text(" of particles is parallel to the displacement ")#mi("{x^{(a)}-x^{(b)}}")#text(" between the pair; in other words, we assume the ")#link("https://en.wikipedia.org/wiki/Torque")[#text("torque")]#text(" ")#mi("{(x^{(a)} - x^{(b)}) \\wedge F^{(ab)}}")#text(" created by this force vanishes, thus ")#metadata(none) <tao-77c1f0ad5be9d1388324>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(x^{(a)} - x^{(b)}) \\wedge F^{(ab)} = 0.")]]



#text(" Here ")#mi("{\\wedge: {\\bf R}^d \\times {\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Exterior_algebra")[#text("exterior product")]#text(" on ")#mi("{{\\bf R}^d}")#text(" (which in three dimensions can be transformed if one wishes to the cross product, but is well defined in all dimensions). Algebraically, ")#mi("{\\wedge}")#text(" is the universal alternating bilinear form on ")#mi("{{\\bf R}^d}")#text("; in terms of the standard basis ")#mi("{e^1,\\dots,e^d}")#text(" of ")#mi("{{\\bf R}^d}")#text(", the wedge product ")#mi("{x \\wedge y}")#text(" of two vectors ")#mi("{x = \\sum_i x_i e^i}")#text(", ")#mi("{y = \\sum_j y_j e^j}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("x \\wedge y = \\sum_{i,j} x_i y_j e_i \\wedge e_j = \\sum_{i,j: i < j} (x_i y_j - x_j y_i) (e_i \\wedge e_j)")]]

#text("and the vector space ")#mi("{\\bigwedge^2 {\\bf R}^d}")#text(" is the formal span of the basic wedge products ")#mi("{e_i \\wedge e_j}")#text(" for ")#mi("{i<j}")#text(".")

#text("One consequence of the absence ")#link(<tao-77c1f0ad5be9d1388324>)[#text("(4)")]#text(" of torque is the conservation of total ")#link("https://en.wikipedia.org/wiki/Angular_momentum")[#text("angular momentum")]#text(" ")#metadata(none) <tao-ab7d698cd892452637b7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_a m^{(a)} x^{(a)} \\wedge \\frac{d}{dt} x^{(a)}")]]



#text(" (around the spatial origin ")#mi("{x=0}")#text("). Indeed, we may calculate")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} \\sum_a m^{(a)} x^{(a)} \\wedge \\frac{d}{dt} x^{(a)}  & = \\sum_a m^{(a)} \\frac{d}{dt} x^{(a)} \\wedge \\frac{d}{dt} x^{(a)} + m^{(a)} x^{(a)} \\wedge \\frac{d^2}{dt^2} x^{(a)}", block: true)



#tao-math(" & = \\sum_a x^{(a)} \\wedge m^{(a)} \\frac{d^2}{dt^2} x^{(a)}", block: true)



#tao-math(" & = \\sum_{a,b: a \\neq b} x^{(a)} \\wedge F^{(ab)}", block: true)



#tao-math(" & = \\frac{1}{2} \\sum_{a,b: a \\neq b} x^{(a)} \\wedge F^{(ab)} + x^{(b)} \\wedge F^{(ba)}", block: true)



#tao-math(" & = \\frac{1}{2} \\sum_{a,b: a \\neq b} (x^{(a)}-x^{(b)}) \\wedge F^{(ab)}", block: true)



#tao-math(" & =0.", block: true)
]

#text("Note that there is nothing special about the spatial origin ")#mi("{x=0}")#text("; the angular momentum")

#align(center)[#tao-fit-display[#mitex("\\sum_a m^{(a)} (x^{(a)} - x_0) \\wedge \\frac{d}{dt} x^{(a)}")]]

#text("around any other point ")#mi("{x_0 \\in {\\bf R}^d}")#text(" is also conserved in time, as is clear from repeating the above calculation, or by combining the existing conservation laws for ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(3)")]#text(" and ")#link(<tao-ab7d698cd892452637b7>)[#text("(5)")]#text(".")

#text("Now we pass from particle mechanics to continuum mechanics, by considering the limiting (bulk) behaviour of many particle systems as the number ")#mi("{N}")#text(" of particles per unit volume goes to infinity. (In physically realistic scenarios, ")#mi("{N}")#text(" will be comparable to ")#link("https://en.wikipedia.org/wiki/Avogadro_constant")[#text("Avagadro’s constant")]#text(", which seems large enough that such limits should be a good approximation to the truth.) To make such limits, we assume that the distribution of particles (and various properties of these particles, such as their velocities and net interaction forces) are approximated in a certain bulk sense by continuous fields. For instance, the mass distribution of a system of particles ")#mi("{(P^{(a)})_{a \\in A}}")#text(" at a given time ")#mi("{t}")#text(" is given by the discrete measure ")#metadata(none) <tao-4084a32b9bba4b4a03d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\mu_{\\mathrm{mass}}(t) := \\sum_a m^{(a)} \\delta_{x^{(a)}(t)}")]]



#text(" where ")#mi("{\\delta_{x_0}}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac measure")]#text(" (or distribution). We will assume that at each time ")#mi("{t}")#text(", we have a “bulk” approximation ")#metadata(none) <tao-bf8348b4107daaacf154>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\mu_{\\mathrm{mass}}(t) \\approx \\rho(t,x)\\ dx")]]



#text(" by some continuous measure ")#mi("{\\rho(t,x)\\ dx}")#text(", where the ")#link("https://en.wikipedia.org/wiki/Density")[#text("density function")]#text(" ")#mi("{\\rho: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" is some smooth function of time and space, and ")#mi("{dx}")#text(" denotes Lebesgue measure on ")#mi("{{\\bf R}^d}")#text(". What does bulk approximation mean? One could work with various notions of approximation, but we will adopt the viewpoint of the theory of ")#link("https://en.wikipedia.org/wiki/Distribution_(mathematics)")[#text("distributions")]#text(" (as reviewed for instance in these ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("old lecture notes of mine")]#text(") and consider approximation against test functions in spacetime, thus we assume that ")#metadata(none) <tao-7eed94421741f7fe255c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x)\\ d \\mu_{\\mathrm{mass}}(t)(x)\\ dt \\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) \\rho(t,x)\\ dx dt.")]]



#text(" for all spacetime test functions ")#mi("{\\psi \\in C^\\infty_c( {\\bf R} \\times {\\bf R}^d )}")#text(". (One could also work with purely spatial test functions at each fixed time ")#mi("{t}")#text(", or work with “infinitesimal” paralleopipeds or similar domains instead of using test functions; the arguments look slightly different when doing so, but the final equations of motion obtained are the same in all cases. See Exercise ")#link(<tao-4d48fba6cf5f7d6abfb3>)[#text("1")]#text(" for an example of this.) We will be deliberately vague as to what ")#mi("{\\approx}")#text(" means, other than to say that the approximation should only be considered accurate (in the sense that it becomes exact in the limit ")#mi("{N \\rightarrow \\infty}")#text(") when the test function ")#mi("{\\psi}")#text(" exists at “macroscopic” (or “bulk”) spatial scales, in particular it should not oscillate with a wavelength that goes to zero as ")#mi("{N}")#text(" goes to infinity. (For instance, one certainly expects the approximation ")#link(<tao-bf8348b4107daaacf154>)[#text("(7)")]#text(" to break down if one tries to test it on scales comparable to the mean spacing between particles.)")

#text("Applying ")#link(<tao-4084a32b9bba4b4a03d0>)[#text("(6)")]#text(" and evaluating the delta integrations, the approximation ")#link(<tao-7eed94421741f7fe255c>)[#text("(8)")]#text(" becomes ")#metadata(none) <tao-72ddfb284bc39e128798>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\int_{\\bf R} \\sum_a m^{(a)} \\psi(t,x^{(a)}(t))\\ dt \\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) \\rho(t,x)\\ dx dt.")]]



#text(" In a physical liquid, particles in a given small region of space tend to move at nearly identical velocities (as opposed to gases, where Brownian motion effects lead one to expect velocities to be distributed stochastically, for instance in a ")#link("https://en.wikipedia.org/wiki/Maxwell%E2%80%93Boltzmann_distribution")[#text("Maxwellian distribution")]#text("). To model this, we assume that there exists a smooth ")#emph[#text("velocity field")]#text(" ")#mi("{u: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" for which we have the approximation ")#metadata(none) <tao-1de7c7157752c8f50a65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{d}{dt} x^{(a)}(t) \\approx u( t, x^{(a)}(t) )")]]



#text(" for all particles ")#mi("{P^{(a)}}")#text(" and all times ")#mi("{t}")#text(". (When stochastic effects are significant, the continuum limit of the fluid will be the ")#link("https://en.wikipedia.org/wiki/Boltzmann_equation")[#text("Boltzmann equations")]#text(" rather than the Euler or Navier-Stokes equations; however the latter equations can still emerge as an approximation of the former in various regimes. See also Remark ")#link(<tao-06b004aa342d97d97ce9>)[#text("7")]#text(" below.)")

#text("Implicit in our model of many-particle interactions is the ")#link("https://en.wikipedia.org/wiki/Conservation_of_mass")[#text("conservation of mass")]#text(": each particle ")#mi("{P^{(a)}}")#text(" has a fixed mass ")#mi("{m^{(a)}}")#text(", and no particle is created or destroyed by the evolution. This conservation of mass, when combined with the approximations ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(" and ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(", gives rise to a certain differential equation relating the density function ")#mi("{\\rho}")#text(" and the velocity field ")#mi("{u}")#text(". To see this, first observe from the fundamental theorem of calculus in time that ")#metadata(none) <tao-9d3b79f6746cf2a0fabe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_{\\bf R} \\frac{d}{dt}(\\int_{{\\bf R}^d} \\psi(t,x) \\ d\\mu_{\\mathrm{mass}}(t)(x)) dt = 0")]]



#text(" or equivalently (after applying ")#link(<tao-4084a32b9bba4b4a03d0>)[#text("(6)")]#text(" and evaluating the delta integrations) ")#metadata(none) <tao-d12991253498ebd95339>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\int_{\\bf R} \\frac{d}{dt} \\sum_a m^{(a)} \\psi(t,x^{(a)}(t))\\ dt = 0")]]



#text(" for any test function ")#mi("{\\psi}")#text(" (note that we make ")#mi("{\\psi}")#text(" compactly supported in both space and time). By the chain rule and ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\frac{d}{dt} \\psi(t,x^{(a)}(t))  & = (\\partial_t \\psi)(t,x^{(a)}(t)) + \\frac{d}{dt} x^{(a)}(t) \\cdot (\\nabla \\psi)(t, x^{(a)}(t))", block: true)



#tao-math(" & \\approx (\\partial_t \\psi + u \\cdot \\nabla \\psi)(t, x^{(a)}(t))", block: true)
]

#text("for any particle ")#mi("{P^{(a)}}")#text(" and any time ")#mi("{t}")#text(", where ")#mi("{\\partial_t}")#text(" denotes the partial derivative with respect to the time variable, ")#mi("{\\nabla = (\\partial_i)_{i=1,\\dots,d}}")#text(" denotes the spatial ")#link("https://en.wikipedia.org/wiki/Gradient")[#text("gradient")]#text(" (with ")#mi("{\\partial_i}")#text(" denoting partial differentiation in the ")#mi("{x_i}")#text(" coordinate), and ")#mi("{\\cdot}")#text(" denotes the Euclidean inner product. (One could also use notation here that avoids explicit use of Euclidean structure, for instance writing ")#mi("{d\\psi(u)}")#text(" in place of ")#mi("{u \\cdot \\nabla \\psi}")#text(", but it is traditional to use Euclidean notation in fluid mechanics.) This particular combination of derivatives ")#mi("{\\partial_t + u \\cdot \\nabla}")#text(" appears so often in the subject that we will give it a special name, the ")#link("https://en.wikipedia.org/wiki/Material_derivative")[#text("material derivative")]#text(" ")#mi("{D_t}")#text(":")

#align(center)[#tao-fit-display[#mitex("D_t := \\partial_t + u \\cdot \\nabla.")]]

#text("We have thus obtained the approximation ")#metadata(none) <tao-947d5a35ff2fe522fda5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\frac{d}{dt} \\psi(t,x^{(a)}(t)) \\approx (D_t \\psi)(t,x^{(a)}(t)),")]]



#text(" which on insertion back into ")#link(<tao-d12991253498ebd95339>)[#text("(12)")]#text(" yields")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\sum_a m^{(a)} (D_t \\psi)(t,x^{(a)}(t))\\ dt \\approx 0.")]]

#text("The material derivative ")#mi("{D_t \\psi}")#text(" of a test function ")#mi("{\\psi}")#text(" will still be a test function ")#mi("{\\psi}")#text(". Therefore we can use our field approximation ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(" to conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} (D_t \\psi)(t,x) \\rho(t,x)\\ dx dt \\approx 0")]]

#text("for all test functions ")#mi("{\\psi}")#text(". The left-hand side consists entirely of the limiting fields, so on taking limits ")#mi("{N \\rightarrow \\infty}")#text(" we should therefore have the exact equation")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} (D_t \\psi)(t,x) \\rho(t,x)\\ dx dt = 0.")]]

#text("We can integrate by parts to obtain")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) (D_t^* \\rho)(t,x)\\ dx dt = 0")]]

#text("where ")#mi("{D_t^*}")#text(" is the adjoint material derivative")

#align(center)[#tao-fit-display[#mitex("D_t^* \\rho := - \\partial_t \\rho - \\nabla \\cdot (\\rho u).")]]

#text("Since the test function ")#mi("{\\psi}")#text(" was arbitrary, we conclude the ")#link("https://en.wikipedia.org/wiki/Continuity_equation")[#text("continuity equation")]#text(" ")#metadata(none) <tao-82181eeb93088b38532c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("D_t^* \\rho = 0")]]



#text(" or equivalently (and more customarily) ")#metadata(none) <tao-0adc36057cef79f8a7b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\partial_t \\rho + \\nabla \\cdot (\\rho u) = 0.")]]





#text("We will eventually specialise to the case of ")#link("https://en.wikipedia.org/wiki/Incompressible_flow")[#text("incompressible")]#text(" fluids in which the density ")#mi("{\\rho}")#text(" is a non-zero constant in both space and time. (In some texts, one uses incompressibility to refer only to constancy of ")#mi("{\\rho}")#text(" along trajectories: ")#mi("{D_t \\rho = 0}")#text(". But in this course we always use incompressibility to refer to ")#emph[#text("homogeneous incompressibility")]#text(", in which ")#mi("{\\rho}")#text(" is constant in both space and time.) In this incompressible case, the continuity equation ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" simplifies to a divergence-free condition on the velocity: ")#metadata(none) <tao-9abf3c8a074355c0cfc1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\nabla \\cdot u = 0.")]]



#text(" For now, though, we allow for the possibility of compressibility by allowing ")#mi("{\\rho}")#text(" to vary in space and time. We also note that by integrating ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" in space, we formally obtain conservation of the total mass")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\rho(t,x)\\ dx")]]

#text("since on differentiating under the integral sign and then integrating by parts we formally have")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\bf R}^d} \\rho(t,x)\\ dx = 0.")]]

#text("Of course, this conservation law degenerates in the incompressible case, since the total mass ")#mi("{\\int_{{\\bf R}^d} \\rho(t,x)\\ dx}")#text(" is manifestly an infinite constant. (In periodic settings, for instance if one is working in ")#mi("{{\\bf R}^d/{\\bf Z}^d}")#text(" instead of ")#mi("{{\\bf R}^d}")#text(", the total mass ")#mi("{\\int_{{\\bf R}^d/{\\bf Z}^d} \\rho(t,x)\\ dx}")#text(" is manifestly a finite constant in the incompressible case.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" ")#metadata(none) <tao-4d48fba6cf5f7d6abfb3>

#list(
[#text("(i) Assume that the spacetime bulk approximation ")#link(<tao-7eed94421741f7fe255c>)[#text("(8)")]#text(" is replaced by the spatial bulk approximation")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\psi(x)\\ d \\mu_{\\mathrm{mass}}(t)(x) \\approx \\int_{{\\bf R}^d} \\psi(x) \\rho(t,x)\\ dx")]]

#text("for any time ")#mi("{t}")#text(" and any spatial test function ")#mi("{\\psi \\in C^\\infty_c({\\bf R}^d)}")#text(". Give an alternate heuristic derivation of the continuity equation ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" in this case, without using any integration in time. (Feel free to ")#link("https://en.wikipedia.org/wiki/Leibniz_integral_rule")[#text("differentiate under the integral sign")]#text(".)")],
[#text("(ii) Assume that the spacetime bulk approximation ")#link(<tao-7eed94421741f7fe255c>)[#text("(8)")]#text(" is replaced by the spatial bulk approximation")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega\\ d\\mu_{\\mathrm{mass}}(t)(x) \\approx \\int_\\Omega \\rho(t,x)\\ dx")]]

#text("for any time ")#mi("{t}")#text(" and any “reasonable” set ")#mi("{\\Omega}")#text(" (e.g., a rectangular box). Give an alternate heuristic derivation of the continuity equation ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" in this case. (Feel free to introduce ")#link("https://en.wikipedia.org/wiki/Infinitesimal")[#text("infinitesimals")]#text(" and argue non-rigorously with them.)")]
)
]

#text("We can repeat the above analysis with the mass distribution ")#link(<tao-4084a32b9bba4b4a03d0>)[#text("(6)")]#text(" replaced by the momentum distribution ")#metadata(none) <tao-446be308664e1964b816>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\mu_{\\mathrm{momentum}} := \\sum_a m^{(a)} (\\frac{d}{dt} x^{(a)}(t)) \\delta_{x^{(a)}(t)},")]]



#text(" thus we now wish to exploit the conservation of momentum rather than conservation of mass. The measure ")#mi("{\\mu_{\\mathrm{momentum}}}")#text(" is a vector-valued measure, or equivalently a vector ")#mi("{\\mu_{\\mathrm{momentum}} = (\\mu_{\\mathrm{momentum},1},\\dots,\\mu_{\\mathrm{momentum},d})}")#text(" of scalar measures")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\mathrm{momentum},i} := \\sum_a m^{(a)} (\\frac{d}{dt} x^{(a)}_i(t)) \\delta_{x^{(a)}(t)}.")]]

#text("Instead of starting with the identity ")#link(<tao-9d3b79f6746cf2a0fabe>)[#text("(11)")]#text(", we begin with the momentum counterpart")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{d}{dt}(\\int_{{\\bf R}^d} \\psi(t,x) \\ d\\mu_{\\mathrm{momentum}}(t)(x)) dt = 0")]]

#text("which on applying ")#link(<tao-446be308664e1964b816>)[#text("(17)")]#text(" and evaluating the delta integrations becomes")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\frac{d}{dt} \\sum_a m^{(a)} (\\frac{d}{dt} x^{(a)}(t)) \\psi(t,x^{(a)}(t))\\ dt = 0.")]]

#text("Using the product rule and ")#link(<tao-947d5a35ff2fe522fda5>)[#text("(13)")]#text(", the left-hand side is approximately ")#metadata(none) <tao-7cb4bd2c12a41e06e757>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\int_{\\bf R} \\sum_a m^{(a)} (\\frac{d^2}{dt^2} x^{(a)}(t)) \\psi(t,x^{(a)}(t)) + m^{(a)} \\frac{d}{dt} x^{(a)}(t) D_t \\psi(t, x^{(a)}(t))\\ dt.")]]



#text(" Applying ")#link(<tao-305238273bb0fac2a73b>)[#text("(1)")]#text(" and ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(", we conclude")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\sum_{a,b: b \\neq a} F^{(ab)}(t) \\psi(t,x^{(a)}(t)) + m^{(a)} (u D_t \\psi)(t, x^{(a)}(t))\\ dt \\approx 0.")]]

#text("We can evaluate the second term using ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\sum_{a,b: b \\neq a} F^{(ab)}(t) \\psi(t,x^{(a)}(t))\\ dt + \\int_{\\bf R} \\int_{{\\bf R}^d} (u D_t \\psi)(t, x) \\rho(t,x)\\ dx dt \\approx 0.")]]

#text("What about the first term? We can use symmetry and Newton’s third law ")#link(<tao-b1e99324505bd32da0e1>)[#text("(2)")]#text(" to write")

#align(center)[#tao-fit-display[#mitex("\\sum_{a,b: b \\neq a} F^{(ab)}(t) \\psi(t,x^{(a)}(t))")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\frac{1}{2} \\sum_{a,b: b \\neq a} F^{(ab)}(t) \\psi(t,x^{(a)}(t)) + F^{(ba)}(t) \\psi(t,x^{(b)}(t))", block: true)



#tao-math(" & = \\frac{1}{2} \\sum_{a,b: b \\neq a} F^{(ab)}(t) ( \\psi(t,x^{(a)}(t)) -\\psi(t,x^{(b)}(t)) ).", block: true)
]

#text("Now we make the further physical assumption that the only significant interactions between particles ")#mi("{P^{(a)}, P^{(b)}}")#text(" are ")#emph[#text("short-range interactions")]#text(", in which ")#mi("{x^{(a)}(t)}")#text(" and ")#mi("{x^{(b)}(t)}")#text(" are very close to each other. With this hypothesis, it is then plausible to make the Taylor approximation")

#align(center)[#tao-fit-display[#mitex("\\psi(t,x^{(a)}(t)) -\\psi(t,x^{(b)}(t)) \\approx (x^{(a)}(t)-x^{(b)}(t)) \\cdot \\nabla \\psi( t, x^{(a)}(t) ).")]]

#text("We thus have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{\\bf R} \\sum_{a,b: b \\neq a} F^{(ab)}(t) (x^{(a)}(t)-x^{(b)}(t)) \\cdot \\nabla \\psi( t, x^{(a)}(t) ) \\ dt")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{\\bf R} \\int_{{\\bf R}^d} (u D_t \\psi)(t, x) \\rho(t,x)\\ dx dt \\approx 0.")]]

#text("We write this in coordinates as ")#metadata(none) <tao-490981027ca36ac0ad88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("-\\int_{\\bf R} \\sum_a \\Sigma^{(a)}_{ij}(t) \\partial_j \\psi(t, x^{(a)}(t))\\ dt")]]





#align(center)[#tao-fit-display[#mitex("+ \\int_{\\bf R} \\int_{{\\bf R}^d} (u_i D_t \\psi)(t,x) \\rho(t,x)\\ dx dt \\approx 0")]]

#text("for ")#mi("{i=1,\\dots,d}")#text(", where we use the ")#link("https://en.wikipedia.org/wiki/Einstein_notation")[#text("Einstein convention")]#text(" that indices ")#mi("{i,j,k}")#text(" are implicitly summed over ")#mi("{1,\\dots,d}")#text(" if they are repeated in an expression, and the ")#link("https://en.wikipedia.org/wiki/Cauchy_stress_tensor")[#text("stress")]#text(" ")#mi("{\\Sigma^{(a)}(t)}")#text(" on the particle ")#mi("{P^{(a)}}")#text(" at time ")#mi("{t}")#text(" is the rank ")#mi("{2}")#text("-tensor defined by the formula ")#metadata(none) <tao-38de90475bb334fb3dea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\Sigma^{(a)}_{ij}(t) := \\frac{1}{2} \\sum_{b: b \\neq a} F^{(ab)}_i(t) (x^{(b)}_j(t) - x^{(a)}_j(t))")]]



#text(" where ")#mi("{F^{(ab)}_1,\\dots,F^{(ab)}_d}")#text(" denote the components of ")#mi("{F^{(ab)}}")#text(". Recall from the torque-free hypothesis ")#link(<tao-77c1f0ad5be9d1388324>)[#text("(4)")]#text(" that ")#mi("{F^{(ab)}}")#text(" is parallel to ")#mi("{x^{(b)}-x^{(a)}}")#text(", thus we could write ")#mi("{F^{(ab)}(t) = f^{(ab)}(t) (x^{(b)}(t)-x^{(a)}(t))}")#text(" for some scalar ")#mi("{f^{(ab)}(t)}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}_{ij}(t) = \\frac{1}{2} \\sum_{b: b \\neq a} f^{(ab)}(t) (x^{(b)}_i(t) - x^{(a)}_i(t)) (x^{(b)}_j(t) - x^{(a)}_j(t)).")]]

#text("In particular, we see that the torque-free hypothesis makes the stress tensor symmetric:")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}_{ij} = \\Sigma^{(a)}_{ji}.")]]

#text("To proceed further, we make the assumption (similar to ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(") that the stress tensor ")#mi("{\\Sigma^{(a)}}")#text(" (or more precisely, the measure ")#mi("{\\sum_a \\Sigma^{(a)} \\delta_{x^{(a)}(t)}}")#text(") is approximated in the bulk by a smooth tensor field ")#mi("{\\sigma: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d \\otimes {\\bf R}^d}")#text(" (with components ")#mi("{\\sigma_{ij}: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" for ")#mi("{i,j=1,\\dots,d}")#text("), in the sense that ")#metadata(none) <tao-3d12171bc756d2f5580c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\int_{\\bf R} \\sum_a \\Sigma^{(a)}_{ij}(t) \\psi(t,x^{(a)}(t))\\ dt \\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) \\sigma_{ij}(t,x)\\ dx dt.")]]



#text(" The tensor ")#mi("{\\sigma_{ij}}")#text(" is known as the ")#link("https://en.wikipedia.org/wiki/Cauchy_stress_tensor")[#text("Cauchy stress tensor")]#text(". Since ")#mi("{\\Sigma^{(a)}}")#text(" is symmetric in ")#mi("{i,j}")#text(", the right-hand side of ")#link(<tao-3d12171bc756d2f5580c>)[#text("(21)")]#text(" is also symmetric in ")#mi("{i,j}")#text(", which by the arbitrariness of ")#mi("{\\psi}")#text(" implies that the tensor ")#mi("{\\sigma}")#text(" is symmetric also:")

#align(center)[#tao-fit-display[#mitex("\\sigma_{ij} = \\sigma_{ji}.")]]

#text("This is also known as ")#link("https://en.wikipedia.org/wiki/Cauchy_stress_tensor#Cauchy's_second_law_of_motion")[#text("Cauchy’s second law of motion")]#text(".")

#text("Inserting ")#link(<tao-490981027ca36ac0ad88>)[#text("(19)")]#text(" into ")#link(<tao-3d12171bc756d2f5580c>)[#text("(21)")]#text(", we arrive at")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} (-\\sigma_{ij} \\partial_j \\psi)(t, x)\\ dt dx + \\int_{\\bf R} \\int_{{\\bf R}^d} (u_i D_t \\psi)(t,x) \\rho(t,x)\\ dx dt \\approx 0")]]

#text("for any test function ")#mi("{\\psi}")#text(" and ")#mi("{i=1,\\dots,d}")#text(". Taking limits as ")#mi("{N \\rightarrow \\infty}")#text(" we obtain the exact equation")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} (-\\sigma_{ij} \\partial_j \\psi)(t, x)\\ dt dx + \\int_{\\bf R} \\int_{{\\bf R}^d} (u_i D_t \\psi)(t,x) \\rho(t,x)\\ dx dt = 0")]]

#text("and then integrating by parts we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) (\\partial_j \\sigma_{ij} + D^*_t (\\rho u_i))(t,x)\\ dx dt = 0;")]]

#text("as the test function ")#mi("{\\psi}")#text(" is arbitrary, we conclude the ")#link("https://en.wikipedia.org/wiki/Cauchy_momentum_equation")[#text("Cauchy momentum equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_j \\sigma_{ij} + D^*_t (\\rho u_i) = 0.")]]

#text("From the Leibniz rule (in an adjoint form) we see that")

#align(center)[#tao-fit-display[#mitex("D^*_t (\\rho u_i) = (D^*_t \\rho) u_i - \\rho D_t( u_i);")]]

#text("using ")#link(<tao-82181eeb93088b38532c>)[#text("(14)")]#text(" we can thus also write the Cauchy momentum equation in the more conventional form ")#metadata(none) <tao-370805ea593ebfaf038a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("D_t u_i = \\frac{1}{\\rho} \\partial_j \\sigma_{ij}.")]]



#text(" (This is a dynamical version of ")#link("https://en.wikipedia.org/wiki/Cauchy_stress_tensor#Cauchy's_first_law_of_motion")[#text("Cauchy’s first law of motion")]#text(".)")

#text("To summarise so far, the unknown density field ")#mi("{\\rho}")#text(" and velocity field ")#mi("{u}")#text(" obey two equations of motion: the continuity equation ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" (or ")#link(<tao-82181eeb93088b38532c>)[#text("(14)")]#text(") and the momentum equation ")#link(<tao-370805ea593ebfaf038a>)[#text("(22)")]#text(". As the former is a scalar equation and the latter is a vector equation, this is ")#mi("{d+1}")#text(" equations for ")#mi("{d+1}")#text(" unknowns, which looks good – so long as the stress tensor ")#mi("{\\sigma}")#text(" is known. However, the stress tensor is not given to us in advance, and so further physical assumptions on the underlying fluid are needed to derive additional equations to yield a more complete set of equations of motion.")

#text("One of the simplest such assumptions is ")#emph[#text("isotropy")]#text(" – that, in the vicinity of a given particle ")#mi("{P^{(a)}}")#text(" at a given point in time, the distribution of the nearby particles ")#mi("{P^{(b)}}")#text(" (and of the forces ")#mi("{F^{(b)}}")#text(") is effectively rotationally symmetric, in the sense that rotation of the fluid around that particle does not significantly affect the net stresses acting on the particle. To give more mathematical meaning to this assumption, let us fix ")#mi("{a}")#text(" and ")#mi("{t}")#text(", and let us set ")#mi("{x^{(a)}(t)}")#text(" to be the spatial origin ")#mi("{0}")#text(" for simplicity. In particular the stress tensor ")#mi("{\\Sigma^{(a)}_{ij}(t)}")#text(" now simplifies a little to")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}_{ij}(t) = \\frac{1}{2} \\sum_{b: b \\neq a} f^{(ab)}(t) x^{(b)}_i(t) x^{(b)}_j(t);")]]

#text("viewing this tensor as a ")#mi("{d \\times d}")#text(" symmetric matrix, we can also write")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}(t) = \\frac{1}{2} \\sum_{b: b \\neq a} f^{(ab)}(t) x^{(b)}(t) x^{(b)}(t)^T")]]

#text("where we now think of the vector ")#mi("{x^{(b)}(t)}")#text(" as a ")#mi("{d}")#text("-dimensional column vector, and ")#mi("{x^T}")#text(" denotes the transpose of ")#mi("{x}")#text(".")

#text("Imagine that we rotate the fluid around this spatial origin using some ")#link("https://en.wikipedia.org/wiki/Rotation_matrix")[#text("rotation matrix")]#text(" ")#mi("{U \\in SO(d)}")#text(", thus replacing ")#mi("{x^{(b)}(t)}")#text(" with ")#mi("{U x^{(b)}(t)}")#text(" (and hence ")#mi("{x^{(b)}(t)^T}")#text(" is replaced with ")#mi("{x^{(b)}(t)^T U^T}")#text("). If we assume that interaction forces are rotationally symmetric, the interaction scalars ")#mi("{f^{(ab)}}")#text(" should not be affected by this rotation. As such, ")#mi("{\\Sigma^{(a)}(t)}")#text(" would be replaced with ")#mi("{U \\Sigma^{(a)}(t) U^T}")#text(". If we assume isotropy, though, this rotated fluid should generate the same stress as the original fluid, thus we have")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}(t) =U \\Sigma^{(a)}(t) U^T")]]

#text("for all rotation matrices ")#mi("{U}")#text(", that is to say that ")#mi("{\\Sigma^{(a)}}")#text(" commutes with all rotations. This implies that all eigenspaces of ")#mi("{\\Sigma^{(a)}}")#text(" are rotation-invariant, but the only rotation-invariant subspaces of ")#mi("{{\\bf R}^d}")#text(" are ")#mi("{\\{0\\}}")#text(" and ")#mi("{{\\bf R}^d}")#text(". Thus the spectral decomposition of the symmetric matrix ")#mi("{\\Sigma^{(a)}}")#text(" only involves a single eigenspace ")#mi("{{\\bf R}^d}")#text(", or equivalently ")#mi("{\\Sigma^{(a)}}")#text(" is a multiple of the identity. In coordinates, we have")

#align(center)[#tao-fit-display[#mitex("\\Sigma^{(a)}_{ij}(t) = - p^{(a)}(t) \\delta_{ij}")]]

#text("for some scalar ")#mi("{p^{(a)}}")#text(" (known as the ")#link("https://en.wikipedia.org/wiki/Pressure")[#text("pressure")]#text(" exerted on the particle ")#mi("{P^{(a)}}")#text("), where ")#mi("{\\delta_{ij}}")#text(" denotes the Kronecker delta (the negative sign here is for compatibility with other physical definitions of pressure). Passing from the individual stresses ")#mi("{\\Sigma^{(a)}}")#text(" to the stress field ")#mi("{\\sigma}")#text(", we see that ")#mi("{\\sigma_{ij}}")#text(" is also rotationally invariant and thus is also a multiple of the identity, thus ")#metadata(none) <tao-372f1c04bdb9d720c796>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sigma_{ij}(t,x) = -p(t,x) \\delta_{ij}")]]



#text(" for some field ")#mi("{p: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(", which we call the ")#emph[#text("pressure")]#text(" field, and which we assume to be smooth. The equations ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(", ")#link(<tao-370805ea593ebfaf038a>)[#text("(22)")]#text(" now become the ")#link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations")]#text(" ")#metadata(none) <tao-46d05f15c8c58d0d2d6d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = - \\frac{1}{\\rho} \\nabla p")]]



#text(" ")#metadata(none) <tao-a612f58becfede33b3b0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_t \\rho + \\nabla \\cdot (\\rho u) = 0.")]]



#text(" This is still an underdetermined system, being ")#mi("{d+1}")#text(" equations for ")#mi("{d+2}")#text(" unknowns (two scalar fields ")#mi("{\\rho,p}")#text(" and one vector field ")#mi("{u}")#text("). But if we assume incompressibility (normalising ")#mi("{\\rho=1}")#text(" for simplicity), we obtain the ")#link("https://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)#Incompressible_Euler_equations_with_constant_and_uniform_density")[#text("incompressible Euler equations")]#text(" ")#metadata(none) <tao-519cb41b08eb99c26826>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = - \\nabla p")]]





#align(center)[#tao-fit-display[#mitex("\\nabla \\cdot u = 0.")]]

#text("Without incompressibility, one can still reach a determined system of equations if one postulates a relationship (known as an ")#link("https://en.wikipedia.org/wiki/Equation_of_state")[#text("equation of state")]#text(") between the pressure ")#mi("{p}")#text(" and the density ")#mi("{\\rho}")#text(" (in some physical situations one also needs to introduce further thermodynamic variables, such as temperature or entropy, which also influence this relationship and obey their own equation of motion). Alternatively, one can proceed using an analysis of the energy conservation law, similar to how ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(" arose from conservation of mass and ")#link(<tao-370805ea593ebfaf038a>)[#text("(22)")]#text(" arose from conservation of momentum, though at the end of the day one would still need an equation of state connecting energy density to other thermodynamic variables. For details, see Exercise ")#link(<tao-4ba69735ca53765ed6a7>)[#text("4")]#text(" below.")

#text("Now we consider relaxing the assumption of isotropy in the stress. Many fluids, in addition to experiencing isotropic stress coming from a scalar pressure field, also experience additional ")#link("https://en.wikipedia.org/wiki/Shear_stress")[#text("shear stress")]#text(" associated to ")#link("https://en.wikipedia.org/wiki/Infinitesimal_strain_theory")[#text("strain")]#text(" in the fluid – distortion in the shape of the fluid arising from fluctuations in the velocity field. One can thus postulate a generalisation to ")#link(<tao-372f1c04bdb9d720c796>)[#text("(23)")]#text(" of the form ")#metadata(none) <tao-31dd5fa24ee6c88323ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sigma_{ij}(t,x) = -p(t,x) \\delta_{ij} + \\tau_{ij}( u(t,x), \\nabla u(t,x) )")]]



#text(" where ")#mi("{\\tau_{ij}: {\\bf R}^d \\times {\\bf R}^{d^2} \\rightarrow {\\bf R}}")#text(" is some function of the velocity ")#mi("{u(t,x) \\in {\\bf R}^d}")#text(" at the point ")#mi("{(t,x)}")#text(" in spacetime, as well as the first derivatives ")#mi("{\\nabla u = (\\partial_i u_j)_{1 \\leq i,j \\leq d} \\in {\\bf R}^{d^2}}")#text(", that arises from changes in shape. (Here, we assume here that the response to stress is ")#link("https://en.wikipedia.org/wiki/Autonomous_system_(mathematics)")[#text("autonomous")]#text(" – it does not depend directly on time, location, or other statistics of the fluid, such as pressure, except insofar as those variables are related to the quantities ")#mi("{u(t,x)}")#text(" and ")#mi("{\\nabla u(t,x)}")#text(". One can of course consider more complex models in which there is a dependence on such quantities or on higher derivatives ")#mi("{\\nabla^2 u, \\nabla^3 u}")#text(", etc. of the velocity, but we will not do so here.)")

#text("It is a general principle in physics that functional relationships between physical quantities, such as the one in ")#link(<tao-31dd5fa24ee6c88323ed>)[#text("(27)")]#text(", can be very heavily constrained by requiring the relationship to be invariant with respect to various physically natural symmetries. This is certainly the case for ")#link(<tao-31dd5fa24ee6c88323ed>)[#text("(27)")]#text(". First of all, we can impose ")#link("https://en.wikipedia.org/wiki/Galilean_invariance")[#text("Galilean invariance")]#text(": if one changes to a different inertial frame of reference, thus adding a constant vector ")#mi("{u_0}")#text(" to the velocity field ")#mi("{u(t,x)}")#text(" (and not affecting the gradient ")#mi("{\\nabla u}")#text(" at all), this should not actually introduce any new stresses on the fluid. This leads to the postulate")

#align(center)[#tao-fit-display[#mitex("\\tau_{ij}( u + u_0, \\nabla u ) = \\tau_{ij}( u, \\nabla u )")]]

#text("for any ")#mi("{u_0}")#text(", and hence ")#mi("{\\tau_{ij}}")#text(" should not actually depend on the velocity ")#mi("{u(t,x)}")#text(" and should only depend on the first derivative. Thus we now write ")#mi("{\\tau_{ij}( \\nabla u(t,x) )}")#text(" for ")#mi("{\\tau_{ij}(u(t,x), \\nabla u(t,x))}")#text(" (thus ")#mi("{\\tau_{ij}}")#text(" is now a function from ")#mi("{{\\bf R}^{d^2}}")#text(" to ")#mi("{{\\bf R}}")#text(").")

#text("If ")#mi("{u=0}")#text(" then there should be no additional shear stress, so we should have ")#mi("{\\tau_{ij}(0) = 0}")#text(". We now make a key assumption that the fluid is a ")#link("https://en.wikipedia.org/wiki/Newtonian_fluid")[#text("Newtonian fluid")]#text(", in that the linear term in the Taylor expansion of ")#mi("{\\tau}")#text(" dominates, or in other words we assume that ")#mi("{\\tau_{ij}}")#text(" is a linear function of ")#mi("{\\nabla u}")#text(". (One can certainly study the mechanics of ")#link("https://en.wikipedia.org/wiki/Non-Newtonian_fluid")[#text("non-Newtonian fluids")]#text(" as well, in which ")#mi("{\\tau}")#text(" depends nonlinearly on ")#mi("{\\nabla u}")#text(", or even on past values of ")#mi("{\\nabla u}")#text(", but these are no longer governed by the Navier-Stokes equations and will not be considered further here.) One can also think of ")#mi("{\\tau}")#text(" as a linear map from the space of ")#mi("{n \\times n}")#text(" matrices (which is the space where ")#mi("{\\nabla u(t,x)}")#text(" takes values) to the space of ")#mi("{n \\times n}")#text(" matrices. In coefficients, this means we are postulating a relationship of the form")

#align(center)[#tao-fit-display[#mitex("\\tau_{ij} = \\mu_{ijkl} \\partial_k u_l(t,x)")]]

#text("for some constants ")#mi("{\\mu_{ijkl}}")#text(" (recall we are using the Einstein summation conventions). This looks like a lot of unspecified constants, but again we can use physical principles to impose significant constraints. Firstly, because stress is symmetric in ")#mi("{i}")#text(" and ")#mi("{j}")#text(", the coefficients ")#mi("{\\mu_{ijkl}}")#text(" must also be symmetric in ")#mi("{i}")#text(" and ")#mi("{j}")#text(": ")#mi("{\\mu_{ijkl} = \\mu_{jikl}}")#text(". Next, let us for simplicity set ")#mi("{x}")#text(" to be the spatial origin ")#mi("{x=0}")#text(", and consider a rotating velocity field of the form")

#align(center)[#tao-fit-display[#mitex("u(t,x) = A x")]]

#text("for some constant-coefficient anti-symmetric matrix ")#mi("{A}")#text(", or in coordinates")

#align(center)[#tao-fit-display[#mitex("u_i(t,x) = A_{ij} x_j.")]]

#text("The derivative field ")#mi("{\\partial_i u_j}")#text(" is then just the anti-symmetric ")#mi("{A_{ji} = -A_{ij}}")#text(". This corresponds to fluids moving according to the rotating trajectories ")#mi("{x(t) = \\exp(tA) x(0)}")#text(", where ")#mi("{\\exp}")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Matrix_exponential")[#text("matrix exponential")]#text(". (For instance, in two dimensions, the velocity field ")#mi("{u(t, x_1,x_2) = (-x_2, x_1)}")#text(" gives rise to trajectories ")#mi("{x_1(t) = \\cos(t) x_1(0) - \\sin(t) x_2(0)}")#text(", ")#mi("{x_2(t) = \\sin(t) x_1(0) + \\cos(t) x_2(0)}")#text(" corresponding to counter-clockwise rotation around the origin.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" When ")#mi("{A}")#text(" is anti-symmetric, show that the matrix ")#mi("{\\exp( tA )}")#text(" is orthogonal for all ")#mi("{t}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\exp( tA ) \\exp( tA )^T = \\exp(tA)^T \\exp(tA) = 1")]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(", where ")#mi("{1}")#text(" denotes the identity matrix. (")#emph[#text("Hint:")]#text(" differentiate the expressions appearing in the above equation with respect to time.) Also show that ")#mi("{\\exp(tA)}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Rotation_matrix")[#text("rotation matrix")]#text(", that is to say an orthogonal matrix of determinant ")#mi("{+1}")#text(".")
]

#text("As ")#mi("{\\exp(tA)}")#text(" is orthogonal, it describes a rigid motion. Thus this rotating motion does not change the shape of the fluid, and so should not give rise to any shear stress. That is to say, the linear map ")#mi("{\\tau}")#text(" should vanish when applied to an anti-symmetric matrix, or in coordinates ")#mi("{\\mu_{ijkl} = \\mu_{ijlk}}")#text(". Another way of saying this is that ")#mi("{\\tau(\\nabla u)}")#text(" only depends on ")#mi("{\\nabla u}")#text(" through its symmetric component ")#mi("{\\frac{1}{2} (\\nabla u + (\\nabla u)^T)}")#text(", known as the ")#link("https://en.wikipedia.org/wiki/Infinitesimal_strain_theory#Infinitesimal_strain_tensor")[#text("rate-of-strain tensor")]#text(" (or the ")#emph[#text("deformation tensor")]#text("). (The anti-symmetric part ")#mi("{\\frac{1}{2} (\\nabla u - (\\nabla u)^T)}")#text(" does not cause any strain, but instead measures the infinitesimal rotation the fluid; up to trivial factors such as ")#mi("{\\frac{1}{2}}")#text(", it is essentially the ")#link("https://en.wikipedia.org/wiki/Vorticity")[#text("vorticity")]#text(" of the fluid, which will be an important field to study in subsequent notes.)")

#text("To constrain the behaviour of ")#mi("{\\tau}")#text(" further, we introduce a hypothesis of rotational (and reflectional) symmetry. If one rotates the fluid by a rotation matrix ")#mi("{U \\in SO(d)}")#text(" around the origin, then if the original fluid had a velocity of ")#mi("{u(t,x)}")#text(" at ")#mi("{(t,x)}")#text(", the new fluid should have a velocity of ")#mi("{U u(t,x)}")#text(" at ")#mi("{(t,Ux)}")#text(", thus the new velocity field ")#mi("{\\tilde u}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("\\tilde u(t,x) = U u(t, U^T x)")]]

#text("and the derivative ")#mi("{\\nabla \\tilde U}")#text(" of this velocity field at the origin ")#mi("{0}")#text(" is then related to the original derivative ")#mi("{\\nabla u}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\nabla \\tilde u(t,0) = U \\nabla u(u, 0) U^T.")]]

#text("Meanwhile, as discussed in the analysis of the isotropic case, the new stress ")#mi("{\\tilde \\tau}")#text(" at the origin ")#mi("{0}")#text(" is related to the original stress ")#mi("{\\tau}")#text(" by the same relation:")

#align(center)[#tao-fit-display[#mitex("\\tilde \\tau = U \\tau U^T.")]]

#text("This means that the linear map ")#mi("{\\tau}")#text(" is rotationally ")#link("https://en.wikipedia.org/wiki/Equivariant_map")[#text("equivariant")]#text(" in the sense that ")#metadata(none) <tao-a2e0a5e7201695ae8e72>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\tau( U A U^T ) = U \\tau(A) U^T")]]



#text(" for any matrix ")#mi("{A}")#text(". Actually the same argument also applies for reflections, so one could also take ")#mi("{U}")#text(" in the orthogonal group ")#mi("{O(d)}")#text(" rather than the special orthogonal group.")

#text("This severely constrains the possible behaviour of ")#mi("{\\tau}")#text(". First consider applying ")#mi("{\\tau}")#text(" to the rank ")#mi("{1}")#text(" matrix ")#mi("{e_1 e_1^T}")#text(", where ")#mi("{e_1}")#text(" is the first basis (column) vector of ")#mi("{{\\bf R}^d}")#text(". The equivariant property ")#link(<tao-a2e0a5e7201695ae8e72>)[#text("(28)")]#text(" then implies that ")#mi("{\\tau(e_1 e_1^T)}")#text(" is invariant with respect to any rotation or reflection of the remaining coordinates ")#mi("{x_2,\\dots,x_d}")#text(". As in the isotropic analysis, this implies that the lower right ")#mi("{d-1 \\times d-1}")#text(" minor of ")#mi("{\\tau(e_1 e_1^T)}")#text(" is a multiple of the identity; when ")#mi("{d \\geq 3}")#text(" it also implies that the upper right entries ")#mi("{\\tau_{1i}(e_1 e_1^T)}")#text(" or lower left entries ")#mi("{\\tau_{i1}(e_1 e_1^T)}")#text(" for ")#mi("{i \\neq 1}")#text(" also vanish (one can also obtain this by applying ")#link(<tao-a2e0a5e7201695ae8e72>)[#text("(28)")]#text(" with ")#mi("{U}")#text(" the reflection in the ")#mi("{x_1}")#text(" variable). Thus we have")

#align(center)[#tao-fit-display[#mitex("\\tau_{ij}(e_1 e_1^T) = 2 \\mu \\delta_{1i} \\delta_{1j} + \\lambda \\delta_{ij}")]]

#text("for some constant scalars ")#mi("{\\mu,\\lambda}")#text(" (known as the ")#emph[#text("dynamic viscosity")]#text(" and ")#emph[#text("second viscosity")]#text(" respectively); in matrix form we have")

#align(center)[#tao-fit-display[#mitex("\\tau(e_1 e_1^T) = 2 \\mu e_1 e_1^T + \\lambda I")]]

#text("where ")#mi("{I}")#text(" is the identity matrix. Applying equivariance, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\tau(v v^T) = 2 \\mu v v^T + \\lambda I")]]

#text("for any unit vector ")#mi("{v}")#text("; applying the spectral theorem this implies that")

#align(center)[#tao-fit-display[#mitex("\\tau(A) = 2 \\mu A + \\lambda \\mathrm{tr}(A) I")]]

#text("for any symmetric matrix ")#mi("{A}")#text(". Since ")#mi("{\\tau(A)}")#text(" is already known to vanish for non-symmetric matrices, upon decomposing a general matrix ")#mi("{A}")#text(" into the symmetric part ")#mi("{\\frac{1}{2} (A + A^T)}")#text(" and anti-symmetric part ")#mi("{\\frac{1}{2} (A - A^T)}")#text(" (with the latter having trace zero) we conclude that")

#align(center)[#tao-fit-display[#mitex("\\tau(A) = \\mu (A + A^T) + \\lambda \\mathrm{tr}(A) I")]]

#text("for an arbitrary matrix ")#mi("{A}")#text(". In particular")

#align(center)[#tao-fit-display[#mitex("\\tau(\\nabla u) = \\mu ( \\nabla u + (\\nabla u)^T ) + \\lambda (\\nabla \\cdot u) I.")]]

#text("In the incompressible case ")#mi("{\\nabla \\cdot u = 0}")#text(", the second term vanishes, and this equation simply says that the shear stress is proportional to the (rate of) strain.")

#text("Inserting the above law back into ")#link(<tao-31dd5fa24ee6c88323ed>)[#text("(27)")]#text(" and then ")#link(<tao-0adc36057cef79f8a7b8>)[#text("(15)")]#text(", ")#link(<tao-370805ea593ebfaf038a>)[#text("(22)")]#text(", we obtain the ")#emph[#text("Navier-Stokes equations")]

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\frac{1}{\\rho} \\nabla p + \\frac{\\mu}{\\rho} (\\Delta u + \\nabla (\\nabla \\cdot u) ) + \\frac{\\lambda}{\\rho} \\nabla(\\nabla \\cdot u)", block: true)



#tao-math("\\partial_t \\rho + \\nabla \\cdot (\\rho u)  & = 0,", block: true)
]

#text("where ")#mi("{\\Delta u = \\partial_i \\partial_i u}")#text(" is the spatial Laplacian. In the incompressible case, setting ")#mi("{\\nu := \\frac{\\mu}{\\rho}}")#text(" (this ratio is known as the ")#emph[#text("kinematic viscosity")]#text("), and also normalising ")#mi("{\\rho=1}")#text(" for simplicity, this simplifies to the ")#emph[#text("incompressible Navier-Stokes equations")]

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p + \\nu \\Delta u", block: true)



#tao-math("\\nabla \\cdot u  & = 0.", block: true)
]

#text("Of course, the incompressible Euler equations arise as the special case when the viscosity ")#mi("{\\nu}")#text(" is set to zero. For physical fluids, ")#mi("{\\nu}")#text(" is positive, though it can be so small that the Euler equations serve as a good approximation. Negative values of ")#mi("{\\mu}")#text(" are mathematically possible, but physically unrealistic for several reasons (for instance, the total energy of the fluid would increase over time, rather than dissipate over time) and also the equations become mathematically quite ill-behaved in this case (as they carry essentially all of the pathologies of the backwards heat equation).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-d4e3fc7b0477747da28f>#text(" In a constant gravity field oriented in the direction ")#mi("{-e_d}")#text(", each particle ")#mi("{P^{(a)}}")#text(" will experience an external gravitational force ")#mi("{- m^{(a)} g e_d}")#text(", where ")#mi("{g>0}")#text(" is a fixed constant. Argue that the incompressible Euler equations in the presence of such a gravitational field should be modified to")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p - g e_d", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("and the incompressible Navier-Stokes equations should similarly be modified to")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p + \\nu \\Delta u - g e_d", block: true)



#tao-math("\\nabla \\cdot u  & = 0.", block: true)
]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-4ba69735ca53765ed6a7>

#list(
[#text("(i) Suppose that in an ")#mi("{N}")#text("-particle system, the force ")#mi("{F^{(ab)}(t)}")#text(" between two particles is given by the ")#link("https://en.wikipedia.org/wiki/Conservative_force")[#text("conservative")]#text(" law ")#metadata(none) <tao-c152d5bbb379c3f94e74>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("F^{(ab)}(t) = - (\\nabla V^{(ab)})(x^{(a)}(t) - x^{(b)}(t))")]]

#text("for some smooth potential function ")#mi("{V^{(ab)}: {\\bf R}^d \\rightarrow {\\bf R}}")#text(", which we assume to obey the symmetry ")#mi("{V^{(ab)}(x) = V^{(ba)}(-x)}")#text(" to be consistent with Newton’s third law. Show that the total energy")

#align(center)[#tao-fit-display[#tao-math("\\sum_a \\frac{1}{2} m^{(a)} \\left|\\frac{d}{dt} x^{(a)}(t)\\right|^2 + \\frac{1}{2} \\sum_{a,b: a \\neq b} V^{(ab)}( x^{(a)}(t) - x^{(b)}(t) )", block: true)]]

#text("is conserved in time (that is to say, the time derivative of this quantity vanishes). Here of course we use ")#tao-math("{\\left|v\\right| := \\sqrt{v \\cdot v}}", block: false)#text(" to denote the Euclidean magnitude of a vector ")#mi("{v}")#text(".")],
[#text("(ii) Assume furthermore that in the large ")#mi("{N}")#text(" limit, we have the velocity approximation ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(", the stress approximation ")#link(<tao-3d12171bc756d2f5580c>)[#text("(21)")]#text(", and the isotropy condition ")#link(<tao-372f1c04bdb9d720c796>)[#text("(23)")]#text(". Assume all interactions are short-range. Assume we also have a potential energy approximation ")#metadata(none) <tao-55fd88d8e0139185df7f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\int_{\\bf R} (\\frac{1}{2} \\sum_{a,b: a\\neq b} V^{(ab)}(x^{(a)}(t) - x^{(b)}(t))) \\psi(t,x^{(a)}(t))\\ dt")]]

#align(center)[#tao-fit-display[#mitex("\\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) \\rho(t,x) e(t,x)\\ dx dt")]]

#text("for all test functions ")#mi("{\\psi \\in C^\\infty_c( {\\bf R} \\times {\\bf R}^d )}")#text(" and some smooth function ")#mi("{e: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" (usually called the ")#link("https://en.wikipedia.org/wiki/Internal_energy")[#text("specific internal energy")]#text("). By analysing the energy distribution")

#tao-aligned(keep: true)[


#tao-math("\\mu_{\\mathrm{energy}}(t)  & := \\sum_a (\\frac{1}{2} m^{(a)} \\left|\\frac{d}{dt} x^{(a)}(t)\\right|^2", block: true)



#tao-math(" & + \\frac{1}{2} \\sum_{b: b \\neq a} V^{(ab)}( x^{(a)}(t) - x^{(b)}(t) )) \\delta_{x^{(a)}(t)}", block: true)
]

#text("in analogy with the previous analysis of the mass distribution ")#mi("{\\mu_{\\mathrm{mass}}(t)}")#text(" and momentum distribution ")#mi("{\\mu_{\\mathrm{momentum}}(t)}")#text(", make a heuristic derivation of the energy conservation law")

#align(center)[#tao-fit-display[#mitex("D_t^* E - \\nabla \\cdot (p u) = 0")]]

#text("or equivalently ")#metadata(none) <tao-46ec905f256c209de984>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\partial_t E + \\nabla \\cdot ((E+p) u) = 0")]]



#text(" where the ")#emph[#text("energy density")]#text(" ")#mi("{E(t,x)}")#text(" is defined by the formula ")#metadata(none) <tao-40baf2c54a3923783ebd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("E(t,x) := \\frac{1}{2} \\rho(t,x) \\left|u(t,x)\\right|^2 + \\rho(t,x) e(t,x)", block: true)]]



#text(" (that is to say, ")#mi("{E(t,x)}")#text(" is the sum of the ")#emph[#text("kinetic energy density")]#text(" ")#tao-math("{\\frac{1}{2} \\rho(t,x) \\left|u(t,x)\\right|^2}", block: false)#text(" and the ")#emph[#text("internal energy density")]#text(" ")#mi("{\\rho(t,x) e(t,x)}")#text("). Conclude in particular that the total energy")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} E(t,x)\\ dx")]]

#text("is formally conserved in time.")],
[#text("(iii) In addition to the previous assumptions, assume that there is a functional relationship between the specific energy density ")#mi("{e(t,x)}")#text(" and the density ")#mi("{\\rho(t,x)}")#text(", in the sense that there is a smooth function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" such that ")#metadata(none) <tao-4b7af475b639e6e7fc48>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("e(t,x) = F( \\rho(t,x) ).")]]

#text("at all points in spacetime and all physically relevant configurations of particles. (In particular, we are in the compressible situation in which we allow the density to vary.) By dilating the position variables ")#mi("{x^{(a)}}")#text(" by a scaling factor ")#mi("{\\lambda > 0}")#text(", scaling the test function ")#mi("{\\psi}")#text(" appropriately, and working out (via ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(") what the scaling does to the density function ")#mi("{\\rho(t,x)}")#text(", generalise ")#link(<tao-55fd88d8e0139185df7f>)[#text("(30)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (\\frac{1}{2} \\sum_{a,b: a a\\neq b} V^{(ab)}(\\lambda(x^{(a)}(t) - x^{(b)}(t)))) \\psi(t,x^{(a)}(t))\\ dt")]]

#align(center)[#tao-fit-display[#mitex("\\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) \\rho(t,x) F(\\lambda^{-d} \\rho(t,x))\\ dx dt.")]]

#text("Formally differentiate this approximation with respect to ")#mi("{\\lambda}")#text(" at ")#mi("{\\lambda = 1}")#text(" and use ")#link(<tao-c152d5bbb379c3f94e74>)[#text("(29)")]#text(", ")#link(<tao-38de90475bb334fb3dea>)[#text("(20)")]#text(", ")#link(<tao-3d12171bc756d2f5580c>)[#text("(21)")]#text(", ")#link(<tao-372f1c04bdb9d720c796>)[#text("(23)")]#text(" to heuristically derive the ")#link("https://en.wikipedia.org/wiki/Equation_of_state")[#text("equation of state")]#text(" ")#metadata(none) <tao-5ec291abdd1e7317f533>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("p(t,x) = \\rho^2(t,x) F^{\\prime}( \\rho(t,x) ).")]]



],
[#text("(iv) Give an alternate derivation of the energy conservation law ")#link(<tao-46ec905f256c209de984>)[#text("(31)")]#text(" from the equations ")#link(<tao-46d05f15c8c58d0d2d6d>)[#text("(24)")]#text(", ")#link(<tao-a612f58becfede33b3b0>)[#text("(25)")]#text(", ")#link(<tao-4b7af475b639e6e7fc48>)[#text("(33)")]#text(", ")#link(<tao-5ec291abdd1e7317f533>)[#text("(34)")]#text(". (Note that as the fluid here is compressible, one cannot use any equations in this post that rely on an incompressibility hypothesis.)")],
[#text("(v) Suppose the functional relationship ")#link(<tao-4b7af475b639e6e7fc48>)[#text("(33)")]#text(" uses a function ")#mi("{F}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("F(\\rho) = e_0 + A (\\rho-1)^2")]]

#text("for some constant ")#mi("{e_0}")#text(" (the specific energy density at equilibrium) and some large and positive ")#mi("{A}")#text("; physically, this represents a fluid which is nearly incompressible in the sense that it is very resistant to having its density ")#mi("{\\rho}")#text(" deviate from ")#mi("{1}")#text(". Assuming that the pressure ")#mi("{p}")#text(" stays bounded and ")#mi("{A}")#text(" is large, heuristically derive the approximations")

#align(center)[#tao-fit-display[#mitex("\\rho \\approx 1 + \\frac{p}{2A}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("e \\approx e_0 + \\frac{p^2}{4A}.")]]

#text("Formally, in the limit ")#mi("{A \\rightarrow \\infty}")#text(", we thus heuristically recover an incompressible fluid ")#mi("{\\rho=1}")#text(" with a constant specific energy density ")#mi("{e = e_0}")#text(". In particular the contributions of the specific energy ")#mi("{e = e_0}")#text(" to the energy conservation law ")#link(<tao-46ec905f256c209de984>)[#text("(31)")]#text(" may be ignored in the incompressible case thanks to ")#link(<tao-46d05f15c8c58d0d2d6d>)[#text("(24)")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" In the literature, the relationship between the functional relationship ")#link(<tao-4b7af475b639e6e7fc48>)[#text("(33)")]#text(" and the equation of state ")#link(<tao-5ec291abdd1e7317f533>)[#text("(34)")]#text(" is usually derived instead using the ")#link("https://en.wikipedia.org/wiki/Laws_of_thermodynamics")[#text("laws of thermodynamics")]#text(". However, as the above exercise demonstrates, it is also possible to recover this relationship from first principles. In the case of an (")#link("https://en.wikipedia.org/wiki/Isentropic_process")[#text("isoentropic")]#text(") ")#link("https://en.wikipedia.org/wiki/Ideal_gas")[#text("ideal gas")]#text(", the laws of thermodynamics can be used to establish an equation of state of the form ")#mi("{p = C \\rho^\\gamma}")#text(" for some constants ")#mi("{C,\\gamma}")#text(" with ")#mi("{\\gamma \\neq 1}")#text(", as well as the corresponding functional relationship ")#mi("{e = \\frac{1}{\\gamma - 1} \\rho^{\\gamma-1} = \\frac{p}{(\\gamma-1) \\rho}}")#text(", so that the internal energy density is ")#mi("{\\frac{p}{\\gamma-1}}")#text(". This is of course consistent with ")#link(<tao-4b7af475b639e6e7fc48>)[#text("(33)")]#text(" and ")#link(<tao-5ec291abdd1e7317f533>)[#text("(34)")]#text(", after choosing ")#mi("{F}")#text(" appropriately.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Suppose one has a (compressible or incompressible) fluid obeying the velocity approximation ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(", the stress approximation ")#link(<tao-3d12171bc756d2f5580c>)[#text("(21)")]#text(", the isotropy condition ")#link(<tao-372f1c04bdb9d720c796>)[#text("(23)")]#text(", and the torque free condition ")#link(<tao-77c1f0ad5be9d1388324>)[#text("(4)")]#text(". Assume also that all interactions are short range. Derive the angular momentum equation")

#align(center)[#tao-fit-display[#mitex("D_t ( x_i u_j - x_j u_i ) = \\frac{1}{\\rho} ( \\partial_i (x_j p) - \\partial_j (x_i p ) )")]]

#text("for ")#mi("{i,j= 1,\\dots,d}")#text(" in two different ways:")

#list(
[#text("(a) From a heuristic analysis of the angular momentum distribution")

#align(center)[#tao-fit-display[#mitex("\\mu_{\\mathrm{ang}, ij} := \\sum_a (\\frac{1}{2} m^{(a)} ( x^{(a)}_i \\frac{d}{dt} x^{(a)}_j(t) - x^{(a)}_j \\frac{d}{dt} x^{(a)}_i(t)) \\delta_{x^{(a)}(t)}")]]

#text("analogous to how the mass, momentum, and energy distributions were analysed previously; and")],
[#text("(b) Directly from the system ")#link(<tao-46d05f15c8c58d0d2d6d>)[#text("(24)")]#text(", ")#link(<tao-a612f58becfede33b3b0>)[#text("(25)")]#text(".")]
)

#text("(c) Conclude in particular that the total angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} (x_i u_j(t,x) - x_j u_i(t,x)) \\rho(t,x)\\ dx")]]

#text("is formally conserved in time.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-06b004aa342d97d97ce9>#text(" In this set of notes we made the rather strong assumption ")#link(<tao-1de7c7157752c8f50a65>)[#text("(10)")]#text(" that the velocities of particles could be approximated by a smooth function ")#mi("{u(t,x)}")#text(" of their time and position. In practice, most fluids will violate this hypothesis due to thermal fluctuations in the velocity. However, one can still proceed with a similar derivation assuming that the velocities behave ")#emph[#text("on the average")]#text(" like a smooth function ")#mi("{u(t,x)}")#text(", in the sense that ")#metadata(none) <tao-b8f92db3d80a29f5eab0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("\\int_{\\bf R} \\sum_a m^{(a)} (\\frac{d}{dt} x^{(a)}(t)) \\psi(t,x^{(a)}(t))\\ dt")]]





#align(center)[#tao-fit-display[#mitex("\\approx \\int_{\\bf R} \\int_{{\\bf R}^d} \\psi(t,x) u(t,x) \\rho(t,x)\\ dx dt")]]

#text("for any test function ")#mi("{\\rho}")#text(". The approximation ")#link(<tao-947d5a35ff2fe522fda5>)[#text("(13)")]#text(" now has to be replaced by the more general")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\psi(t,x^{(a)}(t)) \\approx (D_t \\psi)(t,x^{(a)}(t)) + w^{(a)}(t) \\cdot \\nabla \\psi(t, x^{(a)}(t))")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("w^{(a)}(t) := \\frac{d}{dt} x^{(a)}(t) - u(t, x^{(a)}(t))")]]

#text("is the deviation of the particle velocity from its mean. The second term in ")#link(<tao-7cb4bd2c12a41e06e757>)[#text("(18)")]#text(" now needs to be replaced by the more complicated expression ")#metadata(none) <tao-b3986952b145da5f0e4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\int_{\\bf R} \\sum_a m^{(a)} (u(t,x^{(a)}(t)) + w^{(a)}(t)) \\times")]]





#align(center)[#tao-fit-display[#mitex("\\times (D_t \\psi(t, x^{(a)}(t)) + w^{(a)}(t) \\cdot \\nabla \\psi(t, x^{(a)}(t))\\ dt.")]]

#text("From ")#link(<tao-b8f92db3d80a29f5eab0>)[#text("(35)")]#text(", ")#link(<tao-72ddfb284bc39e128798>)[#text("(9)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\sum_a m^{(a)} w^{(a)}(t) \\psi(t,x^{(a)}(t))\\ dt \\approx 0")]]

#text("for any test function ")#mi("{\\psi}")#text(". This allows us to heuristically drop the cross terms from ")#link(<tao-b3986952b145da5f0e4b>)[#text("(36)")]#text(" involving a single factor of ")#mi("{w^{(a)}}")#text(", and simplify this expression (up to negligible errors) as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\sum_a m^{(a)} D_t \\psi(t, x^{(a)}(t)\\ dt")]]

#align(center)[#tao-fit-display[#mitex("+ \\int_{\\bf R} \\sum_a m^{(a)} w^{(a)}(t) (w^{(a)}(t) \\cdot \\nabla) \\psi(t, x^{(a)}(t))\\ dt.")]]

#text("Repeating the analysis after ")#link(<tao-7cb4bd2c12a41e06e757>)[#text("(18)")]#text(", one eventually arrives again at ")#link(<tao-490981027ca36ac0ad88>)[#text("(19)")]#text(", except that one has to add an additional term")

#align(center)[#tao-fit-display[#mitex("- w^{(a)}_i(t) w^{(a)}_j(t)")]]

#text("to the stress tensor ")#mi("{\\Sigma^{(a)}_{ij}(t)}")#text(" of a single particle ")#mi("{P^{(a)}}")#text(". However, this term is still symmetric, and one can still continue most of the heuristic analysis in this post after suitable adjustments to the various physical hypotheses (for instance, assuming some form of the ")#link("https://en.wikipedia.org/wiki/Molecular_chaos")[#text("molecular chaos hypothesis")]#text(" to be able to neglect some correlation terms between ")#mi("{w^{(a)}}")#text(" and other quantities). We leave the details to the interested reader.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (42)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("Is the argument between (19) and (20) entirely mathematical apart from leaning on isotropy as a physical assumption?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504507")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("(I presume you now mean the argument between (20) and (21); the equation numbering changed recently due to some further edits.)")

#text("In addition to isotropy, a number of other physical assumptions were also used, including: assuming short-range, torque-free pair interactions are the only forces present, and also that the interaction strengths ")#mi("f^{ab}(t)")#text(" are rotation-invariant (they do not depend on the orientation of ")#mi("x^{(a)}-x^{(b)}")#text("). They also require various error terms in the approximations ")#mi("X \\approx Y")#text(" appearing in the text to be negligible in various specific senses. It may be though that one could derive the Cauchy momentum equation with fewer physical assumptions than the ones used here; I was not aiming for minimality of assumption in these notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504515")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Actually that specific argument is now between (21) and (22). I believe it’s only isotropy; I’d appreciate being corrected since multiple physics-oriented texts are vague on whether d=3 is a required assumption for that argument.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4bb092029e9b22e5af2255d8470c35984299104538de2211ca2491f9a7fa449-721f2c58b4d07bdddee46dd3f6b9f9558e9586bd88936718aec053bbc1eaabde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biruk Alemayehu petros")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504506")[#strong[#text("Biruk Alemayehu petros")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("What will be the implication if there is periodic smooth unique solution for NSE? The solution has decaying amplitude in time and viscosity, periodic in space with oscillating term moving with phase velocity of decaying in time and viscosity. Partial result is being published. But the solution published is not unique. Unpublished solution is unique smooth. Am an electrical engineer and need help. Am sure you are busy and not interested in this kind of request. But remember hardy and ramanujan when reading this comment.")

#text("I respect your job for public understanding of important topics")#linebreak()#text(" Biruk Alemayehu Petros")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4bb092029e9b22e5af2255d8470c35984299104538de2211ca2491f9a7fa449-721f2c58b4d07bdddee46dd3f6b9f9558e9586bd88936718aec053bbc1eaabde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biruk Alemayehu petros")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504599")[#strong[#text("Biruk Alemayehu petros")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2018")])]

#text("Smooth unique periodic solution for Navier Stokes equations. The solution suggests the turbulent term and laminar term move with the same velocity. Meaning if move along the fluids overall flow you can see the vortex being stationary and decaying in time and finally vanishes due to viscosity.")#linebreak()#text(" ")#link("http://vixra.org/abs/1809.0088")[#text("http://vixra.org/abs/1809.0088")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4bb092029e9b22e5af2255d8470c35984299104538de2211ca2491f9a7fa449-721f2c58b4d07bdddee46dd3f6b9f9558e9586bd88936718aec053bbc1eaabde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Biruk Alemayehu petros")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504600")[#strong[#text("Biruk Alemayehu petros")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2018")])]

#link("http://vixra.org/abs/1809.0088")[#text("http://vixra.org/abs/1809.0088")]

#text("Is unique smooth periodic solution defined in all times and spaces.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2018")])]

#text("Is it possible to assign a well-defined “asymptotic distribution” for ")#mi("H_t")#text(" zeros (for large zeros ")#mi("z_t")#text("), such that the dynamics of the zeros can give a corresponding evolution equation (or “flow”) for the asymptotic distribution “density” of the zeros ?")#linebreak()#text(" If so, is it possible to get a concrete form for the equations governing the dynamics of this “asymptotic density” of ")#mi("H_t")#text(" zeros (considered now as a density of a “fluid”) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504517")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Continuum limits of the zeta function (and the zeroes thereof) at the “macroscopic” or “bulk” scale 1 are discussed in this previous blog post: ")#link("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/")[#text("https://terrytao.wordpress.com/2015/03/01/254a-supplement-7-normalised-limit-profiles-of-the-log-magnitude-of-the-riemann-zeta-function-optional/")]#text(" . The heat flow is degenerate that this scale though: after any fixed positive time, the continuum limit “freezes” to a uniform distribution.")

#text("To retain an interesting dynamics, one should instead renormalise at the “microscopic” scale ")#mi("1/\\log T")#text(" (the scale of the mean spacing between zeroes), in which case one does not obtain a continuum limit, but instead a stochastic limit which is conjecturally distributed according to the GUE hypothesis. The equations of heat flow are unaffected by this rescaling. The GUE distribution is not invariant under this heat flow (it is instead invariant under the ")#mi("\\beta=2")#text(" analogue of this ")#mi("\\beta=\\infty")#text(" flow, namely Dyson Brownian motion); the evolution of this distribution is in principle explicit, but probably quite messy.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504514")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Concerning the hypothesis that the interparticle forces are aligned with the displacement vectors (just before equation (4)), this follows immediately if you assume isotropy of the laws of physics, since rotating the system in the hyperplane perpendicular to the displacement vector leaves the two pricked fixed and hence must fix the force between them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504518")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("I guess it would follow more from the rotational invariance of the laws of physics combined with a hypothesis that the internal state of each particle is also isotropic (physically indistinguishable from any rotation of that particle, after applying a Galilean transform to normalise the position and velocity of the particle to vanish). If for instance each particle had a strong magnetic moment or spin then one could conceivably have non-trivial torque between two particles even if the laws of physics remain perfectly rotationally symmetric.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504519")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Yes — I’m assuming the particles themselves have no internal structure. But this assumption was effectively made when the force was stated to only depends on the locations of the particles.")

#emph[#text("[Fair enough – I’ll add a comment to that effect in the post. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504516")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("There is a typo in the sentence:")#linebreak()#text(" …”particles that do not simply arise from the interactions between the three pairs”. The P_b, should be P^(b).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("In the displayed formula (below (4)) defining the wedge product, the first summation should be also on ")#mi("j")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e9efb06d4c61a872738955b87770d1627f59ff83879b68c736cba83e9bae792-e4e4e2bac24805997b381b5689b4739ca93cd9b8065aff3417908b28b8ebb5ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Darius")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504527")[#strong[#text("Darius")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("Absolute genius-level work. I’m pursuing physics, and have seen nothing like this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("That’s because, presumably, you read material written by physicists, not mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2018")])]

#text("It seems that this model can be refined by additional stochastic modeling of the fluid particles (i.e. molecules) for their rotations, vibrations and time-varying deformations (via inter-molecular interactions). Perhaps temperature distribution is the simplest scalar field describing such stochastic refinement (using the specific heat concept to describe the internal thermal energy contribution).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2018")])]

#text("Yes, this derivation certainly assumes far stronger conditions on the microscopic interactions than are actually needed to (heuristically) derive the Euler or Navier-Stokes equations, which are somewhat (though certainly not completely) universal in nature, in the sense that they seem to be a good approximation for a fairly wide class of fluids and physical regimes, including some that fail one or more of the assumptions given in this set of notes. I chose this particular derivation for pedagogical reasons, as I wanted to illustrate the point that it is in fact possible to derive these bulk fluid equations from the first principles of Newtonian mechanics, albeit with some rather restrictive hypotheses on the microscopic interactions. As you say, it is likely that some of these hypotheses can be relaxed while still being able to obtain a largely similar derivation.")

#text("In fluid mechanics textbooks one will find other derivations of these fluid laws that are not based so much on microscopic interactions but instead on bulk laws of physics, such as bulk conservation laws and the laws of thermodynamics. These derivations are significantly more robust than the ones given here, in that they will (heuristically, at least) apply to a much wider class of fluids and physical regimes. But they also require more physics prerequisites than I wished to give in this course, which (aside from this particular set of notes) will be focused purely on the mathematical side of things. In particular, I did not wish to digress into a discussion of the laws of thermodynamics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc369cf35750ae405b044c5720f119cf3c6183ac0968135441bdccf718e693e-f2dcd452ee411c3c2910dab194ee781317717b30d1ebf63c4c8e1ff7dba96dfa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504596")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2018")])]

#text("There is progress on the Millennium problem by Buckmaster, Colombo and Vicol:")

#link("https://arxiv.org/abs/1809.00600")[#text("https://arxiv.org/abs/1809.00600")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3cb2edb352a2cc19b539e29dcc1c1c9d0b3cfd1dde18a34edc5e0f20373e710-56171540f803a7ea4b2e632ea3d14a784690526b7e2d656e570072188af3b7b7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of roland5999")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504636")[#strong[#text("roland5999")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")])]

#text("Having derived a big deal of entertainment (and instruction) from the above,")#linebreak()#text(" humble me wonders (tongue in cheek) how pedagogically advisable it is to hand out the dessert before the main dish?")#linebreak()#text(" After all, the physics side of things (the pudding) could be looking more desirable (to some)")#linebreak()#text(" as opposed to the difficult math side (the meat).")

#text("“if you don’t eat your meat, you can’t have any pudding!”")#linebreak()

#text(":) r.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2018")])]

#text("This is not a physical derivation of Navier Stokes but a mathematical one. For the physical derivation one needs to solve the Boltzmann equation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504693")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2018")])]

#text("When the effects of stochastic fluctuations in velocity are significant then one indeed has to pass through the Boltzmann equations first before deriving hydrodynamic equations such as Euler and Navier-Stokes. But here I am assuming that such effects are negligible (see equation (10)) which allows one to take a shortcut and jump from Newtonian mechanics directly to the fluid equations without involving the Boltzmann equations. Admittedly this is a rather restrictive assumption that reduces the number of physical fluids and regimes to which the derivation in this post is valid, but I find it to be simpler pedagogically than the full-blown derivation (in particular avoiding the need to introduce laws of thermodynamics), and still is a legitimate derivation of these fluid equations from more fundamental laws of physics in these more restricted regimes. I’ve added a comment in the post as to how the Boltzmann equations will need to be deployed in the presence of stochastic velocity fluctuations, though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2018")])]

#text("You mean collisions????")#linebreak()#text(" Or does your derivation simply ignores molecular chaos???")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504704")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2018")])]

#text("The interaction forces ")#mi("F^{(ab)}")#text(" in the model in the post can effectively generate collisions, though the hypotheses of the model are that these collisions do not cause significant deviation in velocity from the mean velocity ")#mi("u")#text(". If one takes these additional deviations into account then one would obtain a further contribution to the stress tensor, but will ultimately arrive at the same hydrodynamic limits (with the pressure ")#mi("p")#text(" containing an additional term arising from those deviations), if one makes appropriate assumptions on the homogeneity, chaos, and magnitude of these deviations.")

#text("Basically, the pedagogy in this post was to find a set of physical hypotheses that would allow one to arrive at hydrodynamic equations from Newtonian first principles as rapidly as possible, without need for additional prerequisite material from other laws of physics (such as thermodynamics) or from probability. As I mentioned previously, these hypotheses are quite restrictive; however, as pointed out by other commenters, the derivation can be adapted to handle wider classes of fluids, including those with significant stochastic velocity fluctuation, at the cost of complicating the analysis somewhat, for instance by having to first derive the Boltzmann equations as an intermediate approximation. (Also, I find it an instructive point that while such velocity fluctuations is a notable feature of real-world fluids, they is not strictly necessary as an ingredient for the derivation of hydrodynamic equations.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504706")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2018")])]

#text("How about a simple Molecular Dynamics Simulation? Since you’re derivation seems to resemble an MD simulation (pair interaction etc..)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2018")])]

#text("Also how do you evaluate transport coefficients?? For instance the coefficient of viscosity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504725")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2018")])]

#text("I agree, without a closed equation for the corresponding transport coefficient this derivation is insufficient.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-504727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2018")])]

#text("The existence of transport coefficients ")#mi("\\mu_{ijkl}")#text(" here arise from the hypothesis that the fluid is Newtonian; they are not calculated or derived from the other physical quantities in the model, though as discussed in the post the Galilean and rotational symmetry hypotheses do significantly constrain how these coefficients depend on the indices ")#mi("i,j,k,l")#text(", in that these coefficients are completely determined by the two viscosity parameters ")#mi("\\mu,\\lambda")#text(". However, these axioms are not enough by themselves to calculate these latter parameters exactly. It is true though that the derivation of Navier-Stokes from Boltzmann would, in principle at least, allow one to evaluate these parameters in terms of other parameters of the Boltzmann model, which in turn could in principle be derived from Newtonian primitives such as the form of the pair interaction forces ")#mi("F^{(ab)}")#text(". However, the philosophy adopted in this post is to take the hypothesis of a Newtonian fluid as a primitive axiom, rather than as a property to be derived from more fundamental laws of physics, in order to arrive at the hydrodynamic equations as quickly as possible. [This is similar to how Hooke’s law is used to derive the equations of linear elasticity.]")

#text("Basically, while I would indeed like the derivation of the fluid equations to be 100% from Newtonian first principles, this was a secondary pedagogical consideration compared with the primary objective of keeping the derivation short and requiring minimal physics prerequisites. The assumption of bulk laws of physics such as that of a Newtonian fluid was thus a compromise to further the primary aim at the expense of the secondary one.")

#text("p.s. I have now added a final remark (Remark 7) to the post regarding the addition of velocity fluctuations to the model.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fc3b0977b50e0c5d1f19360afab92d4dab8495ea833ca56fa342c0bb36980ff-455962e6d1572005f3f027c21ae25bbfecf6236ce32a6a910ef4ad328c690903.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amiteshs4")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-607920")[#strong[#text("amiteshs4")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2020")])]

#text("Only to add on to an excellent answer, but I think this could be mentioned. From the Boltzmann equations, one obtains the Navier-Stokes equation only as a first order approximation (typically by a Chapman-Enskog expansion). Higher-order equations such as the Burnett equations do exist (of which the Navier-Stokes equations are a subset). And one could create hierarchically more complicated descriptions using the Boltzmann equations, as well as using the BBGKY hierarchy from the Liouville equations. In engineering, statistical mechanical descriptions that add on to (or even replace continuum level descriptions), are becoming more common especially in applications concerning rarefied gas dynamics and nanofluid transport.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-612871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2020")])]

#text("Also the Chapman-Enskog method delivers a conservation law for kinetic energy which is not present in Mr Tao’s derivation.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa84f594353cfe072d2b727f9aec2ea5c8fee90bf291de7cc3a55c4172f24bdb-4245098bcdac6378da8b6203880b90bc7e9fbd58d15bc8925f6adc4d0f913911.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of august")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-505230")[#strong[#text("august")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("Note from a physicist: the two dimensional case is usually considered pathological. The expressions used (Kubo formula) to calculate the viscosity diverge in two dimensions. I suspect that our author knows this, but for mathematicians reading along it shows that the formal machine is very fragile. The breakdowns are logarithmic, but show that the idea of local hydrodynamics without memory is not valid in 2d geometries.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabe")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-505231")[#strong[#text("Gabe")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2018")])]

#text("That’s used in molecular dynamics, yes? But there is a lot of math and engineering work done using the two-dimensional case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-505509")[#strong[#text("254A, Notes 2: Weak solutions of the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("[…] any smooth function (cf. the material derivative used in Notes 0). Thus, one can rewrite the initial value problem (9) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4bb092029e9b22e5af2255d8470c35984299104538de2211ca2491f9a7fa449-721f2c58b4d07bdddee46dd3f6b9f9558e9586bd88936718aec053bbc1eaabde.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of biruk")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-506902")[#strong[#text("biruk")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2018")])]

#text("Trust me there is counter example for mellinium prize problem. Available at researchgate. I propose we need to modify navier stokes equations to be valid discription of natural phenomenon.")#linebreak()#text(" ")#link("https://www.researchgate.net/publication/328249810_Non-Unique_Smooth_Periodic_Solutions_in_the_absence_of_external_Force_for_Navier_Stokes_Three_Dimensional_Equation_defined_on_a_Torus")[#text("https://www.researchgate.net/publication/328249810_Non-Unique_Smooth_Periodic_Solutions_in_the_absence_of_external_Force_for_Navier_Stokes_Three_Dimensional_Equation_defined_on_a_Torus")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-507426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2018")])]

#text("I think that there should not be a \\partial_j in the formula just before (22).")

#emph[#text("[Corrected, thanks – T].")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Local well-posedness for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-507830")[#strong[#text("254A, Notes 3: Local well-posedness for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2018")])]

#text("[…] any smooth function (cf. the material derivative used in Notes 0). Thus, one can rewrite the initial value problem (9) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-508849")[#strong[#text("255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("[…] Eulerian coordinates. However, if one reviews the physical derivation of the Euler equations from 254A Notes 0, before one takes the continuum limit, the fundamental unknowns were not the velocity field or the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3ba295d076c8a34d77de5ff54b7d090b9a93fc9723bdf4691e25df93d4145ee-8b52836589124bd9be0bad8a52a366559718bd9b18b0b5a586162a0725660d6a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of titus")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-510210")[#strong[#text("titus")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2019")])]

#text("Are there any reference (maybe some of your lecture notes ?) on how to manipulate adjoint differential operators and the Leibniz rule ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-510245")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2019")])]

#text("The adjoint Leibniz rule, as the name suggests, is simply the adjoint of the usual Leibniz rule. For instance, starting with the usual Leibniz rule")

#mi("D_t(u_i f) = D_t(u_i) f + u_i D_t(f)")

#text("for arbitrary test functions ")#mi("u_i, f")#text(", if one integrates against another test function ")#mi("\\rho")#text(" to get")

#mi("\\int \\rho D_t(u_i f) = \\int \\rho D_t(u_i) f + \\rho u_i D_t(f)")

#text("and then integrates by parts again to move derivatives off of ")#mi("f")#text(", thus")

#mi("\\int D_t^*(\\rho) u_i f = \\int \\rho D_t(u_i) f + D_t^*(\\rho u_i) f")

#text("one recovers the adjoint Leibniz rule ")#mi("D_t^*(\\rho u_i) = D_t^*(\\rho) u_i - \\rho D_t(u_i)")#text(" since ")#mi("f")#text(" was arbitrary.")

#text("To put it another way: if ")#mi("M_{u_i}: f \\mapsto u_i f")#text(" is the operation of multiplying ")#mi("u_i")#text(" by ")#mi("f")#text(", the usual Leibniz rule reads ")#mi("D_t M_{u_i} = M_{u_i} D_t + M_{D_t u_i}")#text(", which on taking adjoints (or transposes) gives ")#mi("M_{u_i} D_t^* = D_t^* M_{u_i} + M_{D_t u_i}")#text(", which when unpacked and rearranged is the adjoint Leibniz rule.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1cf1e07d08593637626ff463e30ab017ad7a75239bb3d8a866df057f04f114-c35c0273ed4ae98ad9b8f9865307d27de46010f045819ee7a04b4e1c04312540.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dmitri Gorskine")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-578210")[#strong[#text("Dmitri Gorskine")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2020")])]

#text("Dear professor Terence Tao, I found exact analytical general solution non steady 3D Navier-Stokes equation for incompressible flow. It was amazing, but solution for Navier-Stokes equation coefficient viscosity equal zero is not solution for 3D Euler equation. I don’t understand why?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5af8265c8aa902ac9ea39f55be733383cac6e66c7628bdffcf2e5e726fa2dc24-9e238cf1e6a120690e47f7b06dffdc4eb78605d9e4d9c77c2b3e653673ba0b7b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego.Y.")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-644051")[#strong[#text("Diego.Y.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("I solved problem 1 by taking time derivative on both sides of approximation ")#mi("\\int_{\\mathbb{R}^{d}}\\psi (x) d\\mu_{mass}(t)(x) \\approx \\int_{\\mathbb{R}^{d}} \\psi (x) \\rho (t,x)dx")#text(" and pass derivative under integration. But doing in this way feels like I am not using mass conservation as my starting point. Similarly, I can use the same technique to obtain (22) from a space approximation version of (21) (of course requiring smoothness in space-time) and, as in the case of mass, I am not using the momentum conservation. I am not sure if this is correct or there is something I am missing. Any help would be appreciated.")

#emph[#text("[If you used the fact that the particle masses ")#mi("m^a")#text(" are constants (not depending on time), then you have used mass conservation. Similarly, if you have used Newton’s third law, then you have used momentum conservation – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-644059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("Instead of the traditional interpretation of Newton’s second law as an equation for the computation of the momentum from a given force, it is possible to interpret this law as a definition(!) of the concept of “applied force” as the time rate of the concept of “momentum” (thus making Newton’s second law interpreted as “Newton’s definition of force” from the momentum).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/#comment-688749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2025")])]

#text("Congrats! Nice piece of elaboration.")

#text("Whence the second Law of Newton (in a broad sense) is interpreted in rotating frames, as directed by Ernst Mach (deceased) you may get the full Navier-Stokes eq. if applied to fluid particles as follows")

#text("a = F/m – – >")

#text("Du/Dt = – nabla p/ ρ + μΔ u+g+T.e_y – 2Ωe_z x u – Ωe_z x Ωe_z x r")

#text("with D/Dt u = material derivative u = d/dt u + nabla u. u,")

#text("p =pressure,")

#text("ρ= density,")

#text("μ= kinematic viscosity,")

#text("T (the temperature effect for non-isothermal processes as e. g. as in the temperature turbulence convection models,")

#text("2Ωe_z x u =Coriolis Acceleration,")

#text("Ωe_z x Ωe_z x r = centrifugal Acceleration,")

#text("u= velocity distribution,")

#text("e_y, e_z unit vectors in y resp. z direction")

#text("The elliptic particle interaction may be then modeled by the related energy Hamiltonian as E. g. the Calogero-Moser Hamiltonian")
]
