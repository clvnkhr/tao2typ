// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/
// Converted to Typst by tao2typ: "2026-10-14T16:39:11.005237+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Marton’s conjecture in abelian groups with bounded torsion", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Marton’s conjecture in abelian groups with bounded torsion")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 April 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/")[#text("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.dpmms.cam.ac.uk/~wtg10/")[#text("Tim Gowers")]#text(", ")#link("https://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(", ")#link("https://mathweb.ucsd.edu/~fmanners/")[#text("Freddie Manners")]#text(", and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2404.02244")[#text("Marton’s conjecture in abelian groups with bounded torsion")]#text("“. This paper fully resolves a conjecture of Katalin Marton (the bounded torsion case of the ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("Polynomial Freiman–Ruzsa conjecture")]#text(" (first proposed by Katalin Marton):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Marton’s conjecture)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{G = (G,+)}")#text(" be an abelian ")#mi("{m}")#text("-torsion group (thus, ")#mi("{mx=0}")#text(" for all ")#mi("{x \\in G}")#text("), and let ")#mi("{A \\subset G}")#text(" be such that ")#tao-math("{\\left|A+A\\right| \\leq K\\left|A\\right|}", block: false)#text(". Then ")#mi("{A}")#text(" can be covered by at most ")#mi("{(2K)^{O(m^3)}}")#text(" translates of a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" of cardinality at most ")#tao-math("{\\left|A\\right|}", block: false)#text(". Moreover, ")#mi("{H}")#text(" is contained in ")#mi("{\\ell A - \\ell A}")#text(" for some ")#mi("{\\ell \\ll (2 + m \\log K)^{O(m^3 \\log m)}}")#text(".")
]

#text("We had ")#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")[#text("previously established")]#text(" the ")#mi("{m=2}")#text(" case of this result, with the number of translates bounded by ")#mi("{(2K)^{12}}")#text(" (which was subsequently improved to ")#mi("{(2K)^{11}}")#text(" by Jyun-Jie Liao), but without the additional containment ")#mi("{H \\subset \\ell A - \\ell A}")#text(". It remains a challenge to replace ")#mi("{\\ell}")#text(" by a bounded constant (such as ")#mi("{2}")#text("); this is essentially the “polynomial Bogolyubov conjecture”, which is still open. The ")#mi("{m=2}")#text(" result has been formalized in the proof assistant language Lean, as discussed in ")#link("https://terrytao.wordpress.com/2023/11/18/formalizing-the-proof-of-pfr-in-lean4-using-blueprint-a-short-tour/")[#text("this previous blog post")]#text(". As a consequence of this result, many of the applications of the previous theorem may now be extended from characteristic ")#mi("{2}")#text(" to higher characteristic.")

#text("Our proof techniques are a modification of those in our previous paper, and in particular continue to be based on the theory of Shannon entropy. For inductive purposes, it turns out to be convenient to work with the following version of the conjecture (which, up to ")#mi("{m}")#text("-dependent constants, is actually equivalent to the above theorem):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Marton’s conjecture, entropy form)")]#text(" ")#metadata(none) <tao-5eb7894ca278ec24ed92>#text(" Let ")#mi("{G}")#text(" be an abelian ")#mi("{m}")#text("-torsion group, and let ")#mi("{X_1,\\dots,X_m}")#text(" be independent finitely supported random variables on ")#mi("{G}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("{\\bf H}[X_1+\\dots+X_m] - \\frac{1}{m} \\sum_{i=1}^m {\\bf H}[X_i] \\leq \\log K,")]]

#text("where ")#mi("{{\\bf H}}")#text(" denotes Shannon entropy. Then there is a uniform random variable ")#mi("{U_H}")#text(" on a subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{m} \\sum_{i=1}^m d[X_i; U_H] \\ll m^3 \\log K,")]]

#text("where ")#mi("{d}")#text(" denotes the entropic Ruzsa distance (see ")#link("https://terrytao.wordpress.com/2023/11/13/on-a-conjecture-of-marton/")[#text("previous blog post")]#text(" for a definition); furthermore, if all the ")#mi("{X_i}")#text(" take values in some symmetric set ")#mi("{S}")#text(", then ")#mi("{H}")#text(" lies in ")#mi("{\\ell S}")#text(" for some ")#mi("{\\ell \\ll (2 + \\log K)^{O(m^3 \\log m)}}")#text(".")
]

#text("As a first approximation, one should think of all the ")#mi("{X_i}")#text(" as identically distributed, and having the uniform distribution on ")#mi("{A}")#text(", as this is the case that is actually relevant for implying Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text("; however, the recursive nature of the proof of Theorem ")#link(<tao-5eb7894ca278ec24ed92>)[#text("2")]#text(" requires one to manipulate the ")#mi("{X_i}")#text(" separately. It also is technically convenient to work with ")#mi("{m}")#text(" independent variables, rather than just a pair of variables as we did in the ")#mi("{m=2}")#text(" case; this is perhaps the biggest additional technical complication needed to handle higher characteristics.")

#text("The strategy, as with the previous paper, is to attempt an entropy decrement argument: to try to locate modifications ")#mi("{X^{\\prime}_1,\\dots,X^{\\prime}_m}")#text(" of ")#mi("{X_1,\\dots,X_m}")#text(" that are reasonably close (in Ruzsa distance) to the original random variables, while decrementing the “multidistance”")

#align(center)[#tao-fit-display[#mitex("{\\bf H}[X_1+\\dots+X_m] - \\frac{1}{m} \\sum_{i=1}^m {\\bf H}[X_i]")]]

#text("which turns out to be a convenient metric for progress (for instance, this quantity is non-negative, and vanishes if and only if the ")#mi("{X_i}")#text(" are all translates of a uniform random variable ")#mi("{U_H}")#text(" on a subgroup ")#mi("{H}")#text("). In the previous paper we modified the corresponding functional to minimize by some additional terms in order to improve the exponent ")#mi("{12}")#text(", but as we are not attempting to completely optimize the constants, we did not do so in the current paper (and as such, our arguments here give a slightly different way of establishing the ")#mi("{m=2}")#text(" case, albeit with somewhat worse exponents).")

#text("As before, we search for such improved random variables ")#mi("{X^{\\prime}_1,\\dots,X^{\\prime}_m}")#text(" by introducing more independent random variables – we end up taking an array of ")#mi("{m^2}")#text(" random variables ")#mi("{Y_{i,j}}")#text(" for ")#mi("{i,j=1,\\dots,m}")#text(", with each ")#mi("{Y_{i,j}}")#text(" a copy of ")#mi("{X_i}")#text(", and forming various sums of these variables and conditioning them against other sums. Thanks to the magic of Shannon entropy inequalities, it turns out that it is guaranteed that at least one of these modifications will decrease the multidistance, except in an “endgame” situation in which certain random variables are nearly (conditionally) independent of each other, in the sense that certain conditional mutual informations are small. In particular, in the endgame scenario, the row sums ")#mi("{\\sum_j Y_{i,j}}")#text(" of our array will end up being close to independent of the column sums ")#mi("{\\sum_i Y_{i,j}}")#text(", subject to conditioning on the total sum ")#mi("{\\sum_{i,j} Y_{i,j}}")#text(". Not coincidentally, this type of conditional independence phenomenon also shows up when considering row and column sums of iid independent gaussian random variables, as a specific feature of the gaussian distribution. It is related to the more familiar observation that if ")#mi("{X,Y}")#text(" are two independent copies of a Gaussian random variable, then ")#mi("{X+Y}")#text(" and ")#mi("{X-Y}")#text(" are also independent of each other.")

#text("Up until now, the argument does not use the ")#mi("{m}")#text("-torsion hypothesis, nor the fact that we work with an ")#mi("{m \\times m}")#text(" array of random variables as opposed to some other shape of array. But now the torsion enters in a key role, via the obvious identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{i,j} i Y_{i,j} + \\sum_{i,j} j Y_{i,j} + \\sum_{i,j} (-i-j) Y_{i,j} = 0.")]]

#text("In the endgame, the any pair of these three random variables are close to independent (after conditioning on the total sum ")#mi("{\\sum_{i,j} Y_{i,j}}")#text("). Applying some “entropic Ruzsa calculus” (and in particular an entropic version of the Balog–Szeméredi–Gowers inequality), one can then arrive at a new random variable ")#mi("{U}")#text(" of small entropic doubling that is reasonably close to all of the ")#mi("{X_i}")#text(" in Ruzsa distance, which provides the final way to reduce the multidistance.")

#text("Besides the polynomial Bogoluybov conjecture mentioned above (which we do not know how to address by entropy methods), the other natural question is to try to develop a characteristic zero version of this theory in order to establish the polynomial Freiman–Ruzsa conjecture over torsion-free groups, which in our language asserts (roughly speaking) that random variables of small entropic doubling are close (in Ruzsa distance) to a discrete Gaussian random variable, with good bounds. The above machinery is consistent with this conjecture, in that it produces lots of independent variables related to the original variable, various linear combinations of which obey the same sort of entropy estimates that gaussian random variables would exhibit, but what we are missing is a way to get back from these entropy estimates to an assertion that the random variables really ")#emph[#text("are")]#text(" close to Gaussian in some sense. In continuous settings, Gaussians are known to extremize the entropy for a given variance, and of course we have the central limit theorem that shows that averages of random variables typically converge to a Gaussian, but it is not clear how to adapt these phenomena to the discrete Gaussian setting (without the circular reasoning of assuming the polynoimal Freiman–Ruzsa conjecture to begin with).")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("first again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("Trivial typo: “Bogulyubov” should be “Bogolyubov”, I think.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3558065c4103e7e732a1bb3b6edda1fdcdc82fb43bee3899cc8496acc3d604d4-cd9eed67c4ddc6a234700458a70c75a6f582299c348e014ea108ed72d3c8a0fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shacharlovett")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684666")[#strong[#text("shacharlovett")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("In theorem 2, should the bound in the conclusion depend on K? I believe it should be m^3 (log K) instead of m^3")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0a852cb82bbc339a17724a4514eabb9ea858f52202810b4a9d8b7a4be44b93e-cb2d3ce6a655739dc0f76f2121f0e47ee51fd8b000035c2717c51f53e6ca8fd1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YI")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684667")[#strong[#text("YI")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("The URL in the footnote on page 2 is overfull.")

#emph[#text("[Thanks, this will be fixed in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2024")])]

#text("I found this explanation of theorem 2 by GPT4 hilarious:")

#text("Alright, let’s break down this theorem into more digestible pieces. We’re venturing into a realm of mathematics that deals with groups, randomness, and information theory, but I’ll keep it as simple as possible.")

#enum(start: 1, 
[#strong[#text("The Setting")]#text(": Imagine you have a group of objects that follow a specific mathematical structure called an “abelian group.” This group has a special property: if you combine (technically, perform the group operation on) any two elements, you can do it in any order without changing the outcome (like adding numbers). The “m-torsion” part means that if you combine any element with itself (m) times, you’ll end up back where you started, kind of like walking in a circle and ending up at the starting point after (m) steps.")],
[#strong[#text("The Characters")]#text(": In our story, we have (m) random variables, let’s call them “mystery boxes,” (X_1) to (X_m), each containing some element from our group, chosen according to some probability distribution. These boxes are independent of each other, meaning what you find in one box doesn’t affect what you find in another.")],
[#strong[#text("The Plot Twist – Shannon Entropy")]#text(": Shannon entropy (({bf H})) is a way to measure how “surprising” the contents of a mystery box are. If a box always contains the same item, there’s no surprise, and the entropy is low. If you never know what you’ll find, the entropy is high. The equation given compares the surprise of finding the sum of all (m) boxes’ contents to the average surprise of individual boxes, stating it shouldn’t exceed a certain limit ((log K)).")],
[#strong[#text("The Hero – Uniform Random Variable")]#text(": The theorem claims there exists a hero in our story, a uniform random variable, which is like a perfectly fair mystery box ((U_H)) that equally likely contains any element from a subgroup (H) of our original group. This subgroup is a smaller circle you can walk in without stepping outside the larger circle.")],
[#strong[#text("The Conclusion")]#text(": It tells us that, on average, the distance between what we find in our original (m) mystery boxes and what we’d find in our perfectly fair box is not too far, under a specific measure called the entropic Ruzsa distance. This distance measures how different two probability distributions are in a specific entropy-related sense.")],
[#strong[#text("The Bonus")]#text(": If all our original mystery boxes only ever contained items from a specific set (S), then our hero, the subgroup (H), doesn’t stray far from home. It’s contained within a certain number of steps ((ell)) from (S), with (ell) being not too large, depending on (K), (m), and some mathematics magic.")]
)

#text("In simpler terms, this theorem tells us about the relationship between groups, randomness, and information, showing under certain conditions, we can predict the average “surprise” of combining random elements from a group with a fair degree of certainty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2024")])]

#text("Where can I learn these topics, professor? Are there any particular books?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2024")])]

#text("discrete Gaussians also have maximum entropy (of random variables supported on Z) for a given variance.")

#text("Is there a succinct way to state what kind of CLT you need?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684758")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("Roughly speaking, what seems to be needed is an assertion to the effect that if a discrete random variable ")#mi("X")#text(" behaves like a discrete Gaussian in the sense that all the entropy statistics such as ")#mi("{\\bf H}(X)")#text(", ")#mi("{\\bf H}(X_1+X_2)")#text(", ")#mi("{\\bf H}(X_1-X_2)")#text(", ")#mi("{\\bf H}(X_1+X_2,X_1-X_2)")#text(" etc. (with ")#mi("X_1,X_2,\\dots")#text(" being independent copies of ")#mi("X")#text(") are almost equal to what they would be if ")#mi("X")#text(" were indeed a discrete Gaussian, then ")#mi("X")#text(" is in fact close to such a discrete Gaussian in a Ruzsa distance sense.")

#text("For instance, one feature of continuous Gaussian variables ")#mi("X")#text(" is that ")#mi("X_1+X_2")#text(" and ")#mi("X_1-X_2")#text(" are independent; discrete Gaussian variables (that are sufficiently “nondegenerate”) approximately behave this way also. Is there an inverse theorem to this effect? I vaguely recall something of this nature in the continuous setting under enough hypotheses, but it is not clear what the discrete analogue is. (One problem is that the notion of “discrete Gaussian” needs to be invariant under Freiman homomorphisms; in particular, one is not necessarily discretizing with respect to a standard lattice such as ")#mi("{\\bf Z}^d")#text(". Among other things, this makes it unlikely that the classical notion of variance will be of much relevance, at least until one has somehow normalized away the Freiman homomorphism invariance.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two announcements: AI for Math resources, and erdosproblems.com | What's new")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684755")[#strong[#text("Two announcements: AI for Math resources, and erdosproblems.com | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2024")])]

#text("[…] I also spoke at the same conference that Thomas spoke at, on my recent work with Gowers, Green, and Manners; here is the video of my talk, and here are my […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2024")])]

#text("In appendix C of the preprint, there is a passage where I’m not sure if it’s just a bunch of typos that are confusing me or whether there is some less trivial issue: page 31, line 12, first of all I guess it should say “subspace of ")#mi("0 \\times H_1")#text("” instead of “")#mi("0 \\times H_0")#text("“. However, if “")#mi("0 \\times H_1")#text("” is indeed what it should say, then letting ")#mi("W")#text(" be such a complement of ")#mi("0 \\times H_1")#text(" in ")#mi("H")#text(", we have that for each ")#mi("(x,y)")#text(" in ")#mi("H")#text(" there are unique ")#mi("w=(w_1,w_2)\\in W")#text(" and ")#mi("z \\in H_1")#text(" such that ")#mi("(x,y)=(0,z)+w")#text(", so in particular ")#mi("w_1=x")#text(" and ")#mi("z=y-w_2")#text(". Now the main thing I was wondering about is how the linear map ")#mi("M_0")#text(" can be retrieved from this as is claimed. First, let me mention by the way that on lines 13 and 14 of page 31 there are typos with this linear map that make the passage not easy to parse: on line 13, the ")#mi("Mx")#text(" should be ")#mi("M_0x")#text(" right? And then on line 14 the domain of ")#mi("M_0")#text(" should be ")#mi("H_0")#text(", not ")#mi("H_1")#text(", right? But then the main question: as mentioned above, we have a unique expression ")#mi("(x,y)=(0,z)+w")#text(", but this is unique for ")#mi("(x,y)")#text(" in ")#mi("H")#text(", not for ")#mi("x \\in H_0")#text(". So how do we define a linear map ")#mi("M_0")#text(" on ")#mi("H_0")#text(" when, given ")#mi("x \\in H_0")#text(", there are actually more than one ")#mi("y")#text(" such that ")#mi("(x,y) \\in H")#text("? Sorry in advance if I missed something and this is all trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-684827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2024")])]

#text("Oh I see, the fact that ")#mi("W")#text(" is a complement of the “vertical” subspace ")#mi("0 \\times H_1")#text(" already implies that ")#mi("W")#text(" is a graph of a function, and this function must then be linear.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a6ffb8fc292930bc7e13650b8d87f86b2e278c0248e6205f455e5b206f530b-1165ef80ce0292beb5d0409261d2b0c0b9c45e0720b1ebeede0aea021f7e38d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel Goh")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-685149")[#strong[#text("Marcel Goh")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2024")])]

#text("Must there be some dependence on ")#mi("m")#text(" in the right-hand side of Theorem 2? That is, could it possibly be true that a bound of ")#mi("\\ll \\log K")#text(" holds, where the constant in the ")#mi("\\ll")#text(" doesn’t depend on ")#mi("m")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-685158")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2024")])]

#text("Unfortunately yes. Consider for instance the case when ")#mi("m")#text(" is a large prime ")#mi("p")#text(", ")#mi("G = {\\bf Z}/p{\\bf Z}")#text(" and ")#mi("X")#text(" be the uniform distribution on ")#mi("\\{1,\\dots,\\lfloor \\sqrt{p} \\rfloor\\}")#text(" (viewed as a subset of ")#mi("G")#text("). Then one can take ")#mi("K=O(1)")#text(", but ")#mi("X")#text(" is not close in Ruzsa distance to the uniform distribution of either of the two subgroups ")#mi("\\{0\\}, G")#text(" of ")#mi("G")#text(", except by an ")#mi("m")#text("-dependent constant.")#linebreak()#text(" By taking suitable Cartesian powers of this example, one can also generate counterexamples where ")#mi("K")#text(" is large.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An abridged proof of Marton’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2024/04/04/martons-conjecture-in-abelian-groups-with-bounded-torsion/#comment-685230")[#strong[#text("An abridged proof of Marton’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2024")])]

#text("[…] as before to ensure that has the same form as or , leading to a contradiction as before. See this previous blog post for more […]")
]
