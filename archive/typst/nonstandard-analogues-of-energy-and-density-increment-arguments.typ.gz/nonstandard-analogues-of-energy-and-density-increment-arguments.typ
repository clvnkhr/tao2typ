// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/
// Converted to Typst by tao2typ: "2026-10-14T08:50:07.515938+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Nonstandard analogues of energy and density increment arguments", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Nonstandard analogues of energy and density increment arguments")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 November 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/")[#text("https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the course of the ongoing ")#link("https://terrytao.wordpress.com/category/teaching/logic-reading-seminar/")[#text("logic reading seminar")]#text(" at UCLA, I learned about the property of ")#emph[#text("countable saturation")]#text(". A model ")#mi("{M}")#text(" of a language ")#mi("{L}")#text(" is ")#emph[#text("countably saturated")]#text(" if, every countable sequence ")#mi("{P_1(x), P_2(x), \\ldots}")#text(" of formulae in ")#mi("{L}")#text(" (involving countably many constants in ")#mi("{M}")#text(") which is finitely satisfiable in ")#mi("{M}")#text(" (i.e. any finite collection ")#mi("{P_1(x),\\ldots,P_n(x)}")#text(" in the sequence has a solution ")#mi("{x}")#text(" in ")#mi("{M}")#text("), is automatically satisfiable in ")#mi("{M}")#text(" (i.e. there is a solution ")#mi("{x}")#text(" to all ")#mi("{P_n(x)}")#text(" simultaneously). Equivalently, a model is countably saturated if the topology generated by the definable sets is ")#link("http://en.wikipedia.org/wiki/Countably_compact_space")[#text("countably compact")]#text(".")

#emph[#text("Update, Nov 19:")]#text(" I have learned that the above terminology is not quite accurate; countable saturation allows for an uncountable sequence of formulae, as long as the constants used remain finite. So, the discussion here involves a weaker property than countable saturation, which I do not know the official term for. If one chooses a special type of ultrafilter, namely a “countably incomplete” ultrafilter, one can recover the full strength of countable saturation, though it is not needed for the remarks here. Most models are not countably saturated. Consider for instance the standard natural numbers ")#mi("{{\\Bbb N}}")#text(" as a model for arithmetic. Then the sequence of formulae “")#mi("{x > n}")#text("” for ")#mi("{n=1,2,3,\\ldots}")#text(" is finitely satisfiable in ")#mi("{{\\Bbb N}}")#text(", but not satisfiable.")

#text("However, if one takes a model ")#mi("{M}")#text(" of ")#mi("{L}")#text(" and passes to an ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" ")#mi("{*M}")#text(", whose elements ")#mi("{x}")#text(" consist of sequences ")#mi("{(x_n)_{n \\in {\\Bbb N}}}")#text(" in ")#mi("{M}")#text(", modulo equivalence with respect to some fixed non-principal ultrafilter ")#mi("{p}")#text(", then it turns out that such models are automatically countably compact. Indeed, if ")#mi("{P_1(x), P_2(x), \\ldots}")#text(" are finitely satisfiable in ")#mi("{*M}")#text(", then they are also finitely satisfiable in ")#mi("{M}")#text(" (either by inspection, or by appeal to ")#link("http://en.wikipedia.org/wiki/Los%27s\\_theorem#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(" and/or the ")#link("http://en.wikipedia.org/wiki/Transfer_principle")[#text("transfer principle")]#text(" in non-standard analysis), so for each ")#mi("{n}")#text(" there exists ")#mi("{x_n \\in M}")#text(" which satisfies ")#mi("{P_1,\\ldots,P_n}")#text(". Letting ")#mi("{x = (x_n)_{n \\in {\\Bbb N}} \\in *M}")#text(" be the ultralimit of the ")#mi("{x_n}")#text(", we see that ")#mi("{x}")#text(" satisfies all of the ")#mi("{P_n}")#text(" at once.")

#text("In particular, non-standard models of mathematics, such as the non-standard model ")#mi("{*{\\Bbb N}}")#text(" of the natural numbers, are automatically countably saturated.")

#text("This has some cute consequences. For instance, suppose one has a non-standard metric space ")#mi("{*X}")#text(" (an ultralimit of standard metric spaces), and suppose one has a standard sequence ")#mi("{(x_n)_{n \\in {\\mathbb N}}}")#text(" of elements of ")#mi("{*X}")#text(" which are standard-Cauchy, in the sense that for any standard ")#mi("{\\varepsilon > 0}")#text(" one has ")#mi("{d( x_n, x_m ) < \\varepsilon}")#text(" for all sufficiently large ")#mi("{n,m}")#text(". Then there exists a non-standard element ")#mi("{x \\in *X}")#text(" such that ")#mi("{x_n}")#text(" standard-converges to ")#mi("{x}")#text(" in the sense that for every standard ")#mi("{\\varepsilon > 0}")#text(" one has ")#mi("{d(x_n, x) < \\varepsilon}")#text(" for all sufficiently large ")#mi("{n}")#text(". Indeed, from the standard-Cauchy hypothesis, one can find a standard ")#mi("{\\varepsilon(n) > 0}")#text(" for each standard ")#mi("{n}")#text(" that goes to zero (in the standard sense), such that the formulae “")#mi("{d(x_n,x) < \\varepsilon(n)}")#text("” are finitely satisfiable, and hence satisfiable by countable saturation. Thus we see that non-standard metric spaces are automatically “standardly complete” in some sense.")

#text("This leads to a non-standard structure theorem for Hilbert spaces, analogous to the orthogonal decomposition in Hilbert spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Non-standard structure theorem for Hilbert spaces)")]#text(" Let ")#mi("{*H}")#text(" be a non-standard Hilbert space, let ")#mi("{S}")#text(" be a bounded (external) subset of ")#mi("{*H}")#text(", and let ")#mi("{x \\in H}")#text(". Then there exists a decomposition ")#mi("{x = x_S + x_{S^\\perp}}")#text(", where ")#mi("{x_S \\in *H}")#text(" is “almost standard-generated by ")#mi("{S}")#text("” in the sense that for every standard ")#mi("{\\varepsilon > 0}")#text(", there exists a standard finite linear combination of elements of ")#mi("{S}")#text(" which is within ")#mi("{\\varepsilon}")#text(" of ")#mi("{S}")#text(", and ")#mi("{x_{S^\\perp} \\in *H}")#text(" is “standard-orthogonal to ")#mi("{S}")#text("” in the sense that ")#mi("{\\langle x_{S^\\perp}, s\\rangle = o(1)}")#text(" for all ")#mi("{s \\in S}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{d}")#text(" be the infimum of all the (standard) distances from ")#mi("{x}")#text(" to a standard linear combination of elements of ")#mi("{S}")#text(", then for every standard ")#mi("{n}")#text(" one can find a standard linear combination ")#mi("{x_n}")#text(" of elements of ")#mi("{S}")#text(" which lie within ")#mi("{d+1/n}")#text(" of ")#mi("{x}")#text(". From the parallelogram law we see that ")#mi("{x_n}")#text(" is standard-Cauchy, and thus standard-converges to some limit ")#mi("{x_S \\in *H}")#text(", which is then almost standard-generated by ")#mi("{S}")#text(" by construction. An application of Pythagoras then shows that ")#mi("{x_{S^\\perp} := x-x_S}")#text(" is standard-orthogonal to every element of ")#mi("{S}")#text(". ")#mi("\\Box")

#text("This is the non-standard analogue of a combinatorial structure theorem for Hilbert spaces (see e.g. Theorem 2.6 of ")#link("http://arxiv.org/abs/0707.4269")[#text("my FOCS paper")]#text("). There is an analogous non-standard structure theorem for ")#mi("{\\sigma}")#text("-algebras (the counterpart of Theorem 3.6 from that paper) which I will not discuss here, but I will give just one sample corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Non-standard arithmetic regularity lemma)")]#text(" Let ")#mi("{*G}")#text(" be a non-standardly finite abelian group, and let ")#mi("{f: *G \\rightarrow [0,1]}")#text(" be a function. Then one can split ")#mi("{f = f_{U^\\perp} + f_U}")#text(", where ")#mi("{f_U: *G \\rightarrow [-1,1]}")#text(" is standard-uniform in the sense that all Fourier coefficients are (uniformly) ")#mi("{o(1)}")#text(", and ")#mi("{f_{U^\\perp}: *G \\rightarrow [0,1]}")#text(" is standard-almost periodic in the sense that for every standard ")#mi("{\\varepsilon > 0}")#text(", one can approximate ")#mi("{f_{U^\\perp}}")#text(" to error ")#mi("{\\varepsilon}")#text(" in ")#mi("{L^1(*G)}")#text(" norm by a standard linear combination of characters (which is also bounded).")
]

#text("This can be used for instance to give a non-standard proof of Roth’s theorem (which is not much different from the “finitary ergodic” proof of Roth’s theorem, given for instance in Section 10.5 of ")#link("https://terrytao.wordpress.com/books/additive-combinatorics/")[#text("my book with Van Vu")]#text("). There is also a non-standard version of the Szemerédi regularity lemma which can be used, among other things, to prove the hypergraph removal lemma (the proof then becomes rather close to the infinitary proof of this lemma in ")#link("http://front.math.ucdavis.edu/math.CO/0602037")[#text("this paper of mine")]#text("). More generally, the above structure theorem can be used as a substitute for various “energy increment arguments” in the combinatorial literature, though it does not seem that there is a significant saving in complexity in doing so unless one is performing quite a large number of these arguments.")

#text("One can also cast density increment arguments in a nonstandard framework. Here is a typical example. Call a non-standard subset ")#mi("{X}")#text(" of a non-standard finite set ")#mi("{Y}")#text(" ")#emph[#text("dense")]#text(" if one has ")#tao-math("{\\left|X\\right| \\geq \\varepsilon \\left|Y\\right|}", block: false)#text(" for some standard ")#mi("{\\varepsilon > 0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" Suppose Szemerédi’s theorem (every set of integers of positive upper density contains an arithmetic progression of length ")#mi("{k}")#text(") fails for some ")#mi("{k}")#text(". Then there exists an unbounded non-standard integer ")#mi("{N}")#text(", a dense subset ")#mi("{A}")#text(" of ")#mi("{[N] := \\{1,\\ldots,N\\}}")#text(" with no progressions of length ")#mi("{k}")#text(", and with the additional property that")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\left|A \\cap P\\right|}{\\left|P\\right|} \\leq \\frac{\\left|A \\cap [N]\\right|}{N} + o(1)", block: true)]]

#text("for any subprogression ")#mi("{P}")#text(" of ")#mi("{[N]}")#text(" of unbounded size (thus there is no sizeable density increment on any large progression).")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{B \\subset {\\Bbb N}}")#text(" be a (standard) set of positive upper density which contains no progression of length ")#mi("{k}")#text(". Let ")#tao-math("{\\delta := \\limsup_{\\left|P\\right| \\rightarrow \\infty} \\left|B \\cap P\\right|/\\left|P\\right|}", block: false)#text(" be the asymptotic maximal density of ")#mi("{B}")#text(" inside a long progression, thus ")#mi("{\\delta > 0}")#text(". For any ")#mi("{n > 0}")#text(", one can then find a standard integer ")#mi("{N_n \\geq n}")#text(" and a standard subset ")#mi("{A_n}")#text(" of ")#mi("{[N_n]}")#text(" of density at least ")#mi("{\\delta-1/n}")#text(" such that ")#mi("{A_n}")#text(" can be embedded (after a linear transformation) inside ")#mi("{B}")#text(", so in particular ")#mi("{A_n}")#text(" has no progressions of length ")#mi("{k}")#text(". Applying the saturation property, one can then find an unbounded ")#mi("{N}")#text(" and a set ")#mi("{A}")#text(" of ")#mi("{[N]}")#text(" of density at least ")#mi("{\\delta-1/n}")#text(" for every standard ")#mi("{n}")#text(" (i.e. of density at least ")#mi("{\\delta-o(1)}")#text(") with no progressions of length ")#mi("{k}")#text(". By construction, we also see that for any subprogression ")#mi("{P}")#text(" of ")#mi("{[N]}")#text(" of unbounded size, ")#mi("{A}")#text(" hs density at most ")#mi("{\\delta+1/n}")#text(" for any standard ")#mi("{n}")#text(", thus has density at most ")#mi("{\\delta+o(1)}")#text(", and the claim follows. ")#mi("\\Box")

#text("This can be used as the starting point for any density-increment based proof of Szemerédi’s theorem for a fixed ")#mi("{k}")#text(", e.g. Roth’s proof for ")#mi("{k=3}")#text(", Gowers’ proof for arbitrary ")#mi("{k}")#text(", or Szemerédi’s proof for arbitrary ")#mi("{k}")#text(". (It is likely that Szemerédi’s proof, in particular, simplifies a little bit when translated to the non-standard setting, though the savings are likely to be modest.)")

#text("I’m also hoping that the recent results of Hrushovski on the noncommutative Freiman problem require only countable saturation, as this makes it more likely that they can be translated to a non-standard setting and thence to a purely finitary framework.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1335f741ec9d68f6f357d83d88e084d9cd5948a4dfa1cd20a7fc524dfb9e6832-84ab5f924de87d267e4d02822b02bdb8c23a8e8a711cd664631d0aac06850eae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balazs Szegedy")]], [#link("https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/#comment-42411")[#strong[#text("Balazs Szegedy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2009")])]

#text("I have two related preprints: Higher order fourier analysis as an algebraic theory I. and a Higher order fourier analysis as an algebraic theory II.")#linebreak()#text(" In which ultra products of abelian groups are studied as measure preserving systems.")#linebreak()#text(" (I am currently working on the third part)")

#link("http://arxiv.org/abs/0903.0897")[#text("http://arxiv.org/abs/0903.0897")]#linebreak()#text(" ")#link("http://arxiv.org/abs/0911.1157")[#text("http://arxiv.org/abs/0911.1157")]

#text("It turns out that on the ultra product there is a hierarchy of sigma algebras. The $k$-th one correspondes to $k$-th order fourier analysis.")

#text("An ainteresting fact is that $L_2$ of the $k$-th sigma algebra can be decomposed into rank one modules over the ring L_\\infty of the $k-1$-th sigma algebra. Quite interestingly this decomposition gives rise to higher order dual groups and higher order decompositions.")

#text("I am writing up a third paper in which nil-systems and nil-manifolds appear on the ultra product. It is very interesting that the ultra product group itself is embedded into various nilpotnt groups giving rise to $k$-th order characters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/11/16/nonstandard-analogues-of-energy-and-density-increment-arguments/#comment-42808")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] increment argument” and “density increment argument” were briefly discussed in this recent post; I may return to this topic in more detail in a future […]")
]
