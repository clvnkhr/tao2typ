// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/19/ai-anthology/
// Converted to Typst by tao2typ: "2026-10-14T11:10:22.673501+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "AI Anthology", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("AI Anthology")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/")[#text("https://terrytao.wordpress.com/2023/06/19/ai-anthology/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Back in March, I was approached to contribute to a then-upcoming anthology project to evaluate an early access version of the GPT-4 large language model, and write a short essay about my experiences. Our prompt was to focus on two core questions:")

#list(
[#text("How might this technology and its successors contribute to human flourishing?")],
[#text("How might we as society best guide the technology to achieve maximal benefits for humanity?")]
)

#text("The anthology is now ")#link("https://unlocked.microsoft.com/ai-anthology/")[#text("in the process of being rolled out")]#text(", with twelve of the twenty essays, ")#link("https://unlocked.microsoft.com/ai-anthology/terence-tao/")[#text("including mine")]#text(", public at this time of writing.")

#text("As an experiment, I also asked GPT-4 itself to contribute an essay to the anthology from the same prompts (and playing the role of a research mathematician), then I gave it my own essay (which I wrote independently) and asked it both to rewrite its own essay in the style of my own, or to copyedit my essay into what it deemed to be a better form. I recorded the results of those experiments ")#link("https://terrytao.wordpress.com/about/ai-generated-versions-of-the-ai-anthology-article/")[#text("here")]#text("; the output was reasonably well written and on topic, but not exceptional in content.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Savitha")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678801")[#strong[#text("Savitha")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2023")])]

#text("What if generative AI improved, where it can learn a person’s style of thinking, even mathematical. Do you consider that a personal threat?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678803")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2023")])]

#text("As I noted at ")#link("https://mathoverflow.net/a/38882/766")[#text("this MathOverflow answer")]#text(" (with a concurrence by Bill Thurston), one of the most intellectually satisfying experiences as a research mathematician is interacting at the blackboard with one or more human co-authors who are exactly on the same wavelength as oneself while working collaboratively on the same problem. I do look forward to the day that I can have a similar conversation with an AI attuned to my way of thinking, or (in the more distant future) talking to an attuned AI version of a human colleague when that human colleague is not available for whatever reason. (Though in the latter case there are some non-trivial issues regarding security, privacy, intellectual property, liability, etc. that would likely need to be resolved first before such public AI avatars could be safely deployed.)")

#text("I have experimented with prompting GPT-4 to play the role of precisely such a collaborator on a test problem, with the AI instructed to suggest techniques and directions rather than to directly attempt solve the problem (which the current state-of-the-art LLMs are still quite terrible at). Thus far, the results have been only mildly promising; the AI collaborator certainly serves as an enthusiastic sounding board, and can sometimes suggest relevant references or potential things to try, though in most cases these are references and ideas that I was already aware of and could already evaluate, and were also mixed in with some less relevant citations and strategies. But I could see this style of prompting being useful for a more junior researcher, or someone such as myself exploring an area further from my own area of expertise. And there have been a few times now where this tool has suggested to me a concept that was relevant to the problem in a non-obvious fashion, even if it was not able to coherently state why it was in fact relevant. So while it certainly isn’t at the level of a genuinely competent collaborator yet, it does have potential to evolve into one as the technology improves (and is integrated with further tools, as I describe in my article).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2883cd72735a899126f9490c70b6c97be67f93e85ea714173281b2af9c1ad217-19c779be695f492b73bf8fd69195bd211e7e9188d792e5e5343f5febfb2e96b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunya")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-686492")[#strong[#text("Sunya")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2024")])]

#text("You write “And there have been a few times now where this tool has suggested to me a concept that was relevant to the problem in a non-obvious fashion, even if it was not able to coherently state why it was in fact relevant”.")

#text("I believe that’s the key point. Isn’t it The Engline from Gulliver’s Travels come true?")

#text("I particularly like this contemplation from 50 years ago: “Maybe he’d just sit and pore over the work and try to discover the point of intersection of the theory of M cavities and the qualitative analysis of American cultural influence on Japan, and probably that will be a very strange point of intersection, and it’s also probable that he will find the key to the whole vicious mechanism in that point, and maybe even the key to controlling the mechanism.”")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eaa2c01a9025dbfdea6cc4d95a256bbee867f67d4b7a7d44ffe79f0f7395ae4f-b9a9eec63bd8c0cb8f4d899e3cb25fd62e4831ef4d280f4645e6c1e6ae534a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mitchellporter")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678804")[#strong[#text("mitchellporter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2023")])]

#text("Any thoughts on preventing the AI apocalypse? People worried about superintelligent AI steamrolling the human race as it pursues some goal, regularly say, “if only we could get people like Terry Tao working to make AI safe”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678832")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("In my opinion, the ordering of risks in the near and medium term will be: “Autonomous AI malfunction” << “Humans using AI incorrectly” < \"Socioeconomic disruption caused by AI adoption\" < \"Beneficial uses of AI shut down due to AI panic\" < \"Malicious humans\" < \"Malicious humans assisted by AI\". There are already examples for instance of AI being used to improve the quality and targetting of spam emails, phishing scams, and the like, and we should definitely be focusing a significant amount of effort to defending against such threats and building community resilience to AI-generated disinformation, as well as cyberresilience to infrastructure attacks that may well be AI-assisted in the near future. The Presidential Council of Advisors on Science and Technology (PCAST) that I serve on is currently working on both these topics and is seeking public input (see ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/05/13/pcast-working-group-on-generative-ai-invites-public-input/")[#text("here")]#text(" and ")#link("https://www.whitehouse.gov/pcast/briefing-room/2023/03/15/pcast-initiating-working-group-on-cyber-physical-resilience/")[#text("here")]#text(" respectively). I believe that efforts such as these will also help build defenses, expertise, and “antibodies” that will be able to manage and contain the future risks of malfunctioning autonomous AI in future decades, and may in fact be the most practical and grounded way to arrive at such workable defenses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/edb27f379fdc576c1dab62a8d3e0be2588f736ebff635634a8c4f33fba4cddcf-b66495a3b2483b5f82096cfbac6e41287d131accac08e88190032a808eb63ff6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Ericson")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678812")[#strong[#text("Lars Ericson")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Here are some ChatGPT math experiments:")

#text("“What are the 10 most cited theorems in math that are not about category theory use theorems in category theory in their proof?”: ")#link("https://www.linkedin.com/pulse/what-10-most-cited-theorems-math-category-theory-use-proof-ericson")[#text("https://www.linkedin.com/pulse/what-10-most-cited-theorems-math-category-theory-use-proof-ericson")]

#text("“What are the axioms of Category Theory? (Google Bard edition)”: ")#link("https://www.linkedin.com/pulse/what-axioms-category-theory-google-bard-edition-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/what-axioms-category-theory-google-bard-edition-lars-warren-ericson")]

#text("“What are the axioms of Category Theory? (Chat GPT edition)”: ")#link("https://www.linkedin.com/pulse/what-axioms-category-theory-chat-gpt-edition-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/what-axioms-category-theory-chat-gpt-edition-lars-warren-ericson")]

#text("“How do I get started with Coq and Isabelle?”: ")#link("https://www.linkedin.com/pulse/how-do-i-get-started-coq-isabelle-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/how-do-i-get-started-coq-isabelle-lars-warren-ericson")]

#text("“Google Bard is here to talk about Fermat’s Last Theorem and Lean”: ")#link("https://www.linkedin.com/pulse/google-bard-here-talk-fermats-last-theorem-lean-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/google-bard-here-talk-fermats-last-theorem-lean-lars-warren-ericson")]

#text("“ChatGPT finally succeeds in writing ZFC in Lean 4, but it wasn’t easy”: ")#link("https://www.linkedin.com/pulse/chatgpt-finally-succeeds-writing-zfc-lean-4-wasnt-easy-ericson")[#text("https://www.linkedin.com/pulse/chatgpt-finally-succeeds-writing-zfc-lean-4-wasnt-easy-ericson")]

#text("“Perplexity.AI on ZFC in Lean 4”: ")#link("https://www.linkedin.com/pulse/perplexityai-zfc-lean-4-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/perplexityai-zfc-lean-4-lars-warren-ericson")]

#text("“I ask Bing Chat to write Lean 4 ZFC (Part 1 of ?)”: ")#link("https://www.linkedin.com/pulse/i-ask-bing-chat-write-lean-4-zfc-part-1-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/i-ask-bing-chat-write-lean-4-zfc-part-1-lars-warren-ericson")]

#text("“Fermat’s Last Theorem”: ")#link("https://www.linkedin.com/pulse/fermats-last-theorem-lars-warren-ericson")[#text("https://www.linkedin.com/pulse/fermats-last-theorem-lars-warren-ericson")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55b9e4dbc5cc0dae099497e562dadc7a02c89eacae77155b232e9033f994f8a3-69cbfbf7d3797d836cf3c95963e0a38fd750f7c10e3e54fa36a9735720f4803c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DSWP")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678817")[#strong[#text("DSWP")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Hi Terry, I am looking forward to reading your essay on this leading edge topic. I am a friend of Trevor, we were in music class together at BHS. I last saw Trevor at Jeff’s farewell concert. I also had a lovely conversation that night with your Mum and Dad. I still catch up with Jeff K every now and then. I look forward to staying in touch with your leading edge information. Thanks for your inspirational insights. Kind regards, D Story")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arman")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678819")[#strong[#text("Arman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Genius🧠👍")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c3ad5c3b83f94b7c86816f8e646cd2005dd7f2764a4f92ccba9df8fa2153447-e96e7426eedaf9b78393cddac6b99eec6ad76a2da6f84b67956d036fea7c884b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yahiry Olivier")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678844")[#strong[#text("Yahiry Olivier")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Très intéressant… Je valide")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14e668e026d591a6d6eea6751ec1463d62e3147bf2327c8e1296d40f4cf44b87-5659947b955b2de2d952f785ebe8661bc533a90f19f82bb402a385dadeb120a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAVA")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678846")[#strong[#text("LAVA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("How do you think AI models like GPT-4 could be used to augment peer review processes in academic mathematics, if trained extensively on mathematical literature? Could they potentially spot inconsistencies or errors that human reviewers might miss?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-678848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("I don’t think that unassisted error checking will be feasible any time soon, but one can already use AI tools (such as ")#link("https://www.chatpdf.com/")[#text("ChatPDF")]#text(") to ask other questions about a given paper, such as a summary of the main results and how they are proved. (See also the discussion on ")#link("https://terrytao.wordpress.com/2023/02/18/would-it-be-possible-to-create-a-tool-to-automatically-diagram-papers/")[#text("this recent blog post")]#text(".)")

#text("One related direction where some progress is likely to be made in the near future is in using LLMs to semi-automate some aspects of formalizing a mathematical proof in a formal language such as Lean; see ")#link("http://www.ipam.ucla.edu/abstract/?tid=17909&pcode=MAP2023")[#text("this recent talk by Jason Rute")]#text(" for a survey of the current state of the art. There are already some isolated examples in which a research paper is submitted in conjunction with a formally verified version of the proofs, and these new tools may make this practice more common. One could imagine journals offering an expedited refereeing process for such certified submissions in the near future, as the referee is freed to focus on other aspects of the paper such as exposition and impact.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6da5851819a6bb1ee87f085e50e0b8ce01778aec3aa68b638b45f7fcec808214-9b3f76a8554365e1bb0f1ed1f9dfe0cf742979f7924e793c7c61b3391ac79c22.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-680429")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2023")])]

#text("Hey Terry, layperson here but I use AI for work in software development.")

#text("Do you have access to a less nerf’d version of ChatGPT? ex: A researcher edition such as the ones Microsoft have access to?")

#text("I have been very impressed by the research results as outlined in arXiv papers from folks at Microsoft, but it seems that the publicly released, “consumer grade” edition of GPT-4 is MUCH less powerful than what researchers have had a chance to play with.")

#text("I know that GPT-4’s capabilities in planning and complex multi-step (in terms of abstractions) problems are not great. I wonder if embeddings or API plugins to reference arXiv papers could help with certain specific areas of reasoning…")

#text("I apologize if any of this is addressed in your essays or paper. I’ll go ahead and try and read now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/19/ai-anthology/#comment-682118")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2023")])]

#text("Tried to ask ChatGPT and Wolfram|Alpha about computing sheaf cohomology on finite topological spaces with no success.")

#link("http://www.glacier-studio.com/blog/index.html#20231031")[#text("http://www.glacier-studio.com/blog/index.html#20231031")]
]
