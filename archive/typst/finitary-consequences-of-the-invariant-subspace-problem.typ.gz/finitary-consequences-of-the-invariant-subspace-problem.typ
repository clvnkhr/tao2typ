// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:14.496850+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finitary consequences of the invariant subspace problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finitary consequences of the invariant subspace problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/")[#text("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most notorious open problems in functional analysis is the ")#link("http://en.wikipedia.org/wiki/Invariant_subspace_problem")[#text("invariant subspace problem")]#text(" for Hilbert spaces, which I will state here as a conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Invariant Subspace Problem, ISP0)")]#text(" Let ")#mi("{H}")#text(" be an infinite dimensional complex Hilbert space, and let ")#mi("{T: H \\rightarrow H}")#text(" be a bounded linear operator. Then ")#mi("{H}")#text(" contains a proper closed invariant subspace ")#mi("{V}")#text(" (thus ")#mi("{TV \\subset V}")#text(").")
]

#text("As stated this conjecture is quite infinitary in nature. Just for fun, I set myself the task of trying to find an equivalent reformulation of this conjecture that only involved finite-dimensional spaces and operators. This turned out to be somewhat difficult, but not entirely impossible, if one adopts a sufficiently generous version of “finitary” (cf. my discussion of how to finitise the infinitary pigeonhole principle). Unfortunately, the finitary formulation that I arrived at ended up being rather complicated (in particular, involving the concept of a “barrier”), and did not obviously suggest a path to resolving the conjecture; but it did at least provide some simpler finitary consequences of the conjecture which might be worth focusing on as subproblems.")

#text("I should point out that the arguments here are quite “soft” in nature and are not really addressing the heart of the invariant subspace problem; but I think it is still of interest to observe that this problem is not purely an infinitary problem, and does have some non-trivial finitary consequences.")

#text("I am indebted to Henry Towsner for many discussions on this topic.")

#metadata(none) <tao-21cca897c7eead310c30>

#heading(level: 1)[#strong[#text(" — 1. Initial reductions — ")]]

#text("The first reduction is to get rid of the closed invariant subspace ")#mi("{V}")#text(", as this will be the most difficult object to finitise. We rephrase ISP0 as")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Invariant Subspace Problem, ISP1)")]#text(" Let ")#mi("{H}")#text(" be an infinite dimensional complex Hilbert space, and let ")#mi("{T: H \\rightarrow H}")#text(" be a bounded linear operator. Then there exist unit vectors ")#mi("{v, w \\in H}")#text(" such that ")#mi("{\\langle T^n v, w \\rangle = 0}")#text(" for all natural numbers ")#mi("{n \\in {\\bf N}}")#text(".")
]

#text("Indeed, to see that ISP1 implies ISP0, we simply take ")#mi("{V}")#text(" to be the closed invariant subspace generated by the orbit ")#mi("{v, Tv, T^2 v, \\ldots}")#text(", which is proper since it is orthogonal to ")#mi("{w}")#text(". To see that ISP0 implies ISP1, we let ")#mi("{v}")#text(" be an arbitrary unit vector in the invariant subspace ")#mi("{V}")#text(", and ")#mi("{w}")#text(" be an arbitrary unit vector in the orthogonal complement ")#mi("{V^\\perp}")#text(".")

#text("The claim is obvious if ")#mi("{H}")#text(" is not separable (just let ")#mi("{v}")#text(" be arbitrary, and ")#mi("{w}")#text(" to be a normal vector to the separable space spanned by ")#mi("{v, Tv, T^2 v, \\ldots}")#text("), so we may normalise ")#mi("{H}")#text(" to be ")#mi("{\\ell^2({\\bf N})}")#text(". We may also normalise ")#mi("{T}")#text(" to be a contraction (thus ")#tao-math("{\\left\\|T\\right\\|_{op} \\leq 1}", block: false)#text("), and let ")#mi("{(a_{ij})_{i,j \\geq 1}}")#text(" be the coefficients of ")#mi("{T}")#text(".")

#text("The next step is to restrict ")#mi("{T}")#text(" to a compact space of operators. Define a ")#emph[#text("growth function")]#text(" to be a monotone increasing function ")#mi("{F: {\\bf N} \\rightarrow {\\bf N}}")#text(". Given any growth function ")#mi("{F}")#text(", we say that a linear contraction ")#mi("{T: \\ell^2({\\bf N}) \\rightarrow \\ell^2({\\bf N})}")#text(" with coefficients ")#mi("{(a_{ij})_{i,j \\geq 1}}")#text(" is ")#emph[#mi("{F}")#text("-tight")]#text(" if one has the bound ")#metadata(none) <tao-f55ff16f66f43360266b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sup_{1 \\leq i \\leq N} \\sum_{j \\geq F(N)} \\left|a_{ij}\\right|^2 \\leq \\frac{1}{N}", block: true)]]

#text("and ")#metadata(none) <tao-2c3a4249d77070058649>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sup_{1 \\leq j \\leq N} \\sum_{i \\geq F(N)} \\left|a_{ij}\\right|^2 \\leq \\frac{1}{N}.", block: true)]]

#text("For instance, if the matrix ")#mi("{(a_{ij})_{i,j \\geq 1}}")#text(" is band-limited to the region ")#tao-math("{\\left|j-i\\right| \\leq 10}", block: false)#text(", it is ")#mi("{F}")#text("-tight with ")#mi("{F(N) := N+11}")#text(". If it is limited to the region ")#mi("{i/2 \\leq j \\leq 2i}")#text(", then it is ")#mi("{F}")#text("-tight with ")#mi("{F(N) := 2N+1}")#text(". So one can view ")#mi("{F}")#text("-tightness as a weak version of the band-limited property.")

#text("The significance of this concept lies in the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Sequential compactness)")]#text(" ")#metadata(none) <tao-4f5260d71c7e332a2c94>

#list(
[#text("(i) Every contraction ")#mi("{T: \\ell^2({\\bf N}) \\rightarrow \\ell^2({\\bf N})}")#text(" is ")#mi("{F}")#text("-tight with respect to at least one growth function ")#mi("{F}")#text(".")],
[#text("(ii) If ")#mi("{F}")#text(" is a growth function and ")#mi("{T_1, T_2, \\ldots}")#text(" is a sequence of ")#mi("{F}")#text("-tight contractions, then there exists a subsequence ")#mi("{T_{n_k}}")#text(" which converges in the strong operator topology to an ")#mi("{F}")#text("-tight contraction ")#mi("{T}")#text(". Furthermore, the adjoints ")#mi("{T_{n_k}^*}")#text(" converge in the strong operator topology to ")#mi("{T^*}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" To prove (i), observe that if ")#mi("{T}")#text(" is a contraction and ")#mi("{N \\geq 1}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq i \\leq N} \\sum_{j=1}^\\infty \\left|a_{ij}\\right|^2 \\leq 1", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1 \\leq j \\leq N} \\sum_{i=1}^\\infty \\left|a_{ij}\\right|^2 \\leq 1", block: true)]]

#text("and hence by the monotone convergence theorem we can find ")#mi("{F(N)}")#text(" such that ")#link(<tao-f55ff16f66f43360266b>)[#text("(1)")]#text(", ")#link(<tao-2c3a4249d77070058649>)[#text("(2)")]#text(". By increasing ")#mi("{F(N)}")#text(" as necessary one can make ")#mi("{F}")#text(" monotone.")

#text("To prove (ii), we apply the usual Arzelá-Ascoli diagonalisation argument to extract a subsequence ")#mi("{T_{n_k} = (a_{i,j,n_k})_{i,j \\geq 1}}")#text(" that converges componentwise (i.e. in the weak operator topology) to a limit ")#mi("{T = (a_{i,j})_{i,j \\geq 1}}")#text(". From Fatou’s lemma we see that ")#mi("{T}")#text(" is an ")#mi("{F}")#text("-tight contraction. From the tightness one can upgrade the weak operator topology convergence to strong operator topology convergence (i.e.")

#align(center)[#tao-fit-display[#tao-math("\\lim_{k \\rightarrow \\infty} \\sum_{j=1}^\\infty \\left|a_{i,j,n_k} - a_{i,j}\\right|^2 = 0", block: true)]]

#text("for all ")#mi("{i}")#text(") by standard arguments, and similarly for the adjoints. ")#mi("\\Box")

#text("We will similarly need a way to compactify the unit vectors ")#mi("{v, w}")#text(". If ")#mi("{F}")#text(" is a growth function and ")#mi("{0 < N_1 < N_2 < N_3 < \\ldots}")#text(" are natural numbers, we say that a unit vector ")#mi("{v = (v_i)_{i=1}^\\infty}")#text(" is ")#emph[#mi("{F,N_1,N_2,\\ldots}")#text("-tight")]#text(" if one has ")#metadata(none) <tao-b728b7e775f708faf513>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{i \\geq N_k} \\left|v_i\\right|^2 \\leq \\frac{1}{F(N_{k-1})}", block: true)]]

#text("for all ")#mi("{k \\geq 1}")#text(", with the convention that ")#mi("{N_0=0}")#text(". Similarly, we say that ")#mi("{v}")#text(" is ")#emph[#mi("{F,N_1,\\ldots,N_K}")#text("-tight")]#text(" if one has ")#link(<tao-b728b7e775f708faf513>)[#text("(3)")]#text(" for all ")#mi("{1 \\leq k \\leq K}")#text(". One has the following variant of Lemma ")#link(<tao-4f5260d71c7e332a2c94>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Sequential compactness)")]#text(" ")#metadata(none) <tao-04faa85cc5734cd65209>#text(" Let ")#mi("{F}")#text(" be a growth function.")

#list(
[#text("(i) Every unit vector ")#mi("{v}")#text(" is ")#mi("{F,N_1,N_2,\\ldots}")#text("-tight with respect to at least one increasing sequence ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(". In fact any finite number of unit vectors ")#mi("{v_1,\\ldots,v_m}")#text(" can be made ")#mi("{F,N_1,N_2,\\ldots}")#text("-tight with the same increasing sequence ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(".")],
[#text("(ii) If ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(", and for each ")#mi("{k \\geq 1}")#text(", ")#mi("{v_k}")#text(" is a ")#mi("{F,N_1,\\ldots,N_k}")#text("-tight unit vector, then there exists a subsequence ")#mi("{v_{n_l}}")#text(" of ")#mi("{v_k}")#text(" that converges strongly to an ")#mi("{F,N_1,N_2,\\ldots}")#text("-tight unit vector ")#mi("{v}")#text(".")]
)
]

#text("The proof of this lemma is routine and is omitted.")

#text("In view of these two lemmas, ISP0 or ISP1 is equivalent to")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 5 (Invariant Subspace Problem, ISP2)")]#text(" Let ")#mi("{F}")#text(" be a growth function, and let ")#mi("{T = (a_{ij})_{i,j \\geq 1}}")#text(" be an ")#mi("{F}")#text("-tight contraction. Then there exist a sequence ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(" and a pair of ")#mi("{F,N_1,N_2,\\ldots}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2({\\bf N})}")#text(" such that ")#mi("{\\langle T^n v, w \\rangle = 0}")#text(" for all natural numbers ")#mi("{n \\in {\\bf N}}")#text(".")
]

#text("The compactness given by the ")#mi("{F}")#text("-tightness and ")#mi("{F,N_1,N_2,\\ldots}")#text(" will be useful for finitising later.")

#heading(level: 1)[#strong[#text(" — 2. Finitising — ")]]

#text("Now we need a more complicated object.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6")]#text(" A ")#emph[#text("barrier")]#text(" is a family ")#mi("{{\\mathcal T}}")#text(" of finite tuples ")#mi("{(N_1, \\ldots, N_m)}")#text(" of increasing natural numbers ")#mi("{0 < N_1 < \\ldots < N_m}")#text(", such that")

#list(
[#text("(i) Every infinite sequence ")#mi("{N_1 < N_2 < \\ldots}")#text(" of natural numbers has at least one initial segment ")#mi("{(N_1,\\ldots,N_m)}")#text(" in ")#mi("{{\\mathcal T}}")#text("; and")],
[#text("(ii) If ")#mi("{(N_1,\\ldots,N_m)}")#text(" is a sequence in ")#mi("{{\\mathcal T}}")#text(", then no initial segment ")#mi("{(N_1,\\ldots,N_{m^{\\prime}})}")#text(" with ")#mi("{m^{\\prime} < m}")#text(" lies in ")#mi("{{\\mathcal T}}")#text(".")]
)
]

#text("I learned the terminology “barrier” after asking ")#link("http://mathoverflow.net/questions/29676/is-there-a-name-for-a-family-of-finite-sequences-that-block-all-infinite-sequence")[#text("this question on MathOverflow")]#text(". Examples of barriers include")

#list(
[#text("The family of all tuples ")#mi("{(N_1,\\ldots,N_m)}")#text(" of increasing natural numbers with ")#mi("{m=10}")#text(";")],
[#text("The family of all tuples ")#mi("{(N_1,\\ldots,N_m)}")#text(" of increasing natural numbers with ")#mi("{m=N_1+1}")#text(";")],
[#text("The family of all tuples ")#mi("{(N_1,\\ldots,N_m)}")#text(" of increasing natural numbers with ")#mi("{m=N_{N_1+1}+1}")#text(".")]
)

#text("We now claim that ISP2 is equivalent to the following finitary statement. Let ")#mi("{\\ell^2(N) \\equiv {\\bf C}^N}")#text(" denote the ")#mi("{\\ell^2}")#text(" space on ")#mi("{\\{1,\\ldots,N\\}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 7 (Finitary invariant subspace problem, FISP0)")]#text(" Let ")#mi("{F}")#text(" be a growth function, and let ")#mi("{{\\mathcal T}}")#text(" be a barrier. Then there exists a natural number ")#mi("{N_*}")#text(" such that for every ")#mi("{F}")#text("-tight contraction ")#mi("{T: \\ell^2(F(N_*)) \\rightarrow \\ell^2(F(N_*))}")#text(", there exists a tuple ")#mi("{(N_1,\\ldots,N_m)}")#text(" in ")#mi("{{\\mathcal T}}")#text(" with ")#mi("{0 < N_1 < \\ldots < N_m < N_*}")#text(", and ")#mi("{F,N_1,\\ldots,N_m}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2(F(N_*))}")#text(", such that ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{1}{F(N_m)}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq F(N_m)}")#text(".")
]

#text("We now show that ISP2 and FISP0 are equivalent.")

#strong[#text("Proof of ISP2 assuming FISP0.")]#text(" Let ")#mi("{F}")#text(" be a growth function, and let ")#mi("{T}")#text(" be an ")#mi("{F}")#text("-tight contraction. Let ")#mi("{{\\mathcal T}^{\\prime}}")#text(" denote the set of all tuples ")#mi("{0 < N_1 < \\ldots < N_m}")#text(" with ")#mi("{m > 1}")#text(" such that there does not exist ")#mi("{F,N_1,\\ldots,N_m}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2({\\bf N})}")#text(" such that ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{2}{m}}", block: false)#text(" holds for all ")#mi("{0 \\leq n \\leq m}")#text(". Let ")#mi("{{\\mathcal T}}")#text(" be those elements of ")#mi("{{\\mathcal T}^{\\prime}}")#text(" that contain no proper initial segment in ")#mi("{{\\mathcal T}^{\\prime}}")#text(".")

#text("Suppose first that ")#mi("{{\\mathcal T}}")#text(" is not a barrier. Then there exists an infinite sequence ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(" such that ")#mi("{(N_1,\\ldots,N_m) \\not \\in {\\mathcal T}}")#text(" for all ")#mi("{m}")#text(", and thus ")#mi("{(N_1,\\ldots,N_m) \\not \\in {\\mathcal T}^{\\prime}}")#text(" for all ")#mi("{m}")#text(". In other words, for each ")#mi("{m}")#text(" there exists ")#mi("{F,N_1,\\ldots,N_m}")#text("-tight unit vectors ")#mi("{v_m,w_m \\in \\ell^2({\\bf N})}")#text(" such that ")#tao-math("{\\left|\\langle T^n v_m, w_m \\rangle\\right| \\leq \\frac{2}{m}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq m}")#text(". By Lemma ")#link(<tao-04faa85cc5734cd65209>)[#text("4")]#text(", we can find a subsequence ")#mi("{v_{m_j}, w_{m_j}}")#text(" that converge strongly to ")#mi("{F,N_1,N_2,\\ldots}")#text("-tight unit vectors ")#mi("{v, w}")#text(". We conclude that ")#mi("{\\langle T^n v, w \\rangle=0}")#text(" for all ")#mi("{n \\geq 0}")#text(", and ISP2 follows.")

#text("Now suppose instead that ")#mi("{{\\mathcal T}}")#text(" is a barrier. Let ")#mi("{F^{\\prime}}")#text(" be a growth function larger than ")#mi("{F}")#text(" to be chosen later. Then the ")#mi("{F}")#text("-tight contraction ")#mi("{T}")#text(" is also ")#mi("{F^{\\prime}}")#text("-tight, as is the restriction ")#mi("{T|_N: \\ell^2(N) \\rightarrow \\ell^2(N)}")#text(" of ")#mi("{T}")#text(" to any finite subspace. Using FISP0, we can thus find ")#mi("{0 < N_1 < \\ldots < N_m < N_*}")#text(" with ")#mi("{(N_1,\\ldots,N_m) \\in {\\mathcal T}}")#text(" and ")#mi("{F^{\\prime},N_1,\\ldots,N_m}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2(F^{\\prime}(N_*))}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle (T|_{F^{\\prime}(N_m)})^n v, w \\rangle\\right| \\leq \\frac{1}{F^{\\prime}(N_m)}", block: true)]]

#text("for all ")#mi("{0 \\leq n \\leq F^{\\prime}(N_m)}")#text(", and in particular for all ")#mi("{0 \\leq n \\leq m}")#text(". Note that ")#mi("{v, w}")#text(" are almost in ")#mi("{\\ell^2(N_m)}")#text(", up to an error of ")#mi("{1/F^{\\prime}(N_{m-1})}")#text(". From this and the ")#mi("{F}")#text("-tightness of the contraction ")#mi("{T}")#text(", we see (if ")#mi("{F^{\\prime}}")#text(" is sufficiently rapid) that ")#mi("{(T|_{F^{\\prime}(N_m)})^n v}")#text(" and ")#mi("{T^n v}")#text(" differ by at most ")#mi("{1/m}")#text(" for ")#mi("{0 \\leq n \\leq m}")#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{2}{m},", block: true)]]

#text("and so ")#mi("{(N_1,\\ldots,N_m) \\not \\in {\\mathcal T}}")#text(", a contradiction. This yields the proof of ISP2 assuming FISP0.")

#strong[#text("Proof of FISP0 assuming ISP2.")]#text(" Suppose that FISP0 fails. Then there exists a growth function ")#mi("{F}")#text(" and a barrier ")#mi("{{\\mathcal T}}")#text(" such that, for every ")#mi("{N_*}")#text(", there exists an ")#mi("{F}")#text("-tight contraction ")#mi("{T_{N_*}: \\ell^2(F(N_*)) \\rightarrow \\ell^2(F(N_*))}")#text(" such that there does not exist any tuples ")#mi("{(N_1,\\ldots,N_m)}")#text(" in ")#mi("{{\\mathcal T}}")#text(" with ")#mi("{0 < N_1 < \\ldots < N_m < N_*}")#text(", and ")#mi("{F,N_1,\\ldots,N_m}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2(F(N_*))}")#text(", such that ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{1}{F(N_m)}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq F(N_m)}")#text(".")

#text("We extend each ")#mi("{T_{N_*}}")#text(" by zero to an operator on ")#mi("{\\ell^2({\\bf N})}")#text(", which is still a ")#mi("{F}")#text("-tight contraction. Using Lemma ")#link(<tao-4f5260d71c7e332a2c94>)[#text("3")]#text(", one can find a sequence ")#mi("{N_{*,k}}")#text(" going to infinity such that ")#mi("{T_{N_{*,k}}}")#text(" converges in the strong (and dual strong) operator topologies to an ")#mi("{F}")#text("-tight contraction ")#mi("{T}")#text(". Let ")#mi("{F^{\\prime}}")#text(" be a growth function larger than ")#mi("{F}")#text(" to be chosen later. Applying ISP2, there exists an infinite sequence ")#mi("{0 < N_1 < N_2 < \\ldots}")#text(" and ")#mi("{F^{\\prime},N_1,N_2,\\ldots}")#text("-tight unit vectors ")#mi("{v, w \\in \\ell^2({\\bf N})}")#text(" such that ")#mi("{\\langle T^n v, w \\rangle = 0}")#text(" for all ")#mi("{n \\geq 0}")#text(".")

#text("As ")#mi("{{\\mathcal T}}")#text(" is a barrier, there exists a finite initial segment ")#mi("{(N_1,\\ldots,N_m)}")#text(" of the above sequence that lies in ")#mi("{{\\mathcal T}}")#text(". For ")#mi("{k}")#text(" sufficiently large, we have ")#mi("{N_{*,k} \\geq N_m}")#text(", and also we see from the strong operator norm convergence of ")#mi("{T_{N_{*,k}}}")#text(" to ")#mi("{T}")#text(" (and thus ")#mi("{T^n_{N_{*,k}}}")#text(" to ")#mi("{T^n}")#text(" for any ")#mi("{n}")#text(", as all operators are uniformly bounded) that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle T^n_{N_{*,k}} v, w \\rangle\\right| \\leq \\frac{1}{F^{\\prime}(N_m)}", block: true)]]

#text("for all ")#mi("{0 \\leq n \\leq F(N_m)}")#text(".")

#text("Now we restrict ")#mi("{v, w}")#text(" to ")#mi("{\\ell^2(F(N_{*,k}))}")#text(", and then renormalise to create unit vectors ")#mi("{v^{\\prime}, w^{\\prime} \\in \\ell^2(F(N_{*,k}))}")#text(". For ")#mi("{k}")#text(" large enough, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|v-v^{\\prime}\\right\\|, \\left\\|w-w^{\\prime}\\right\\| \\leq 1 / F^{\\prime}(N_m)", block: true)]]

#text("and we deduce (for ")#mi("{F^{\\prime}}")#text(" large enough) that ")#mi("{v^{\\prime}, w^{\\prime}}")#text(" are ")#mi("{F,N_1,N_2,\\ldots,N_m}")#text("-tight and ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{1}{F(N_m)}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq F(N_m)}")#text(". But this contradicts the construction of the ")#mi("{T_{N_{*}}}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 3. A special case — ")]]

#text("The simplest example of a barrier is the family of ")#mi("{1}")#text("-tuples ")#mi("{(N)}")#text(", and one of the simplest examples of an ")#mi("{F}")#text("-tight contraction is a contraction that is ")#mi("{1}")#text("-band-limited, i.e. the coefficients ")#mi("{a_{ij}}")#text(" vanish unless ")#tao-math("{\\left|i-j\\right| \\leq 1}", block: false)#text(". We thus obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 8 (Finitary invariant subspace problem, special case, FISP1)")]#text(" Let ")#mi("{F}")#text(" be a growth function and ")#mi("{\\epsilon > 0}")#text(". Then there exists a natural number ")#mi("{N_*}")#text(" such that for every ")#mi("{1}")#text("-band-limited contraction ")#mi("{T: \\ell^2(F(N_*)) \\rightarrow \\ell^2(F(N_*))}")#text(", there exists ")#mi("{0 < N < N_*}")#text(" and unit vectors ")#mi("{v, w \\in \\ell^2(F(N_*))}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j \\geq N} \\left|v_j\\right|^2, \\sum_{j \\geq N} \\left|w_j\\right|^2 \\leq \\epsilon^2", block: true)]]

#text("(i.e. ")#mi("{v, w}")#text(" are ")#mi("{\\epsilon}")#text("-close to ")#mi("{\\ell^2(N)}")#text(") such that ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{1}{F(N)}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq F(N)}")#text(".")
]

#text("This is perhaps the simplest case of ISP that I do not see how to resolve. (Note that the finite-dimensional operator ")#mi("{T: \\ell^2(F(N_*)) \\rightarrow \\ell^2(F(N_*))}")#text(" will have plenty of (generalised) eigenvectors, but there is no particular reason why any of them are “tight” in the sense that they are ")#mi("{\\epsilon}")#text("-close to ")#mi("{\\ell^2(N)}")#text(".) Here is a slightly weaker version that I still cannot resolve:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 9 (Finitary invariant subspace problem, special case, FISP2)")]#text(" Let ")#mi("{F}")#text(" be a growth function, let ")#mi("{\\epsilon > 0}")#text(", and let ")#mi("{T: \\ell^2({\\bf N}) \\rightarrow \\ell^2({\\bf N})}")#text(" be a ")#mi("{1}")#text("-band-limited contraction. Then there exists ")#mi("{N > 0}")#text(" and unit vectors ")#mi("{v, w \\in \\ell^2({\\bf N})}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j \\geq N} \\left|v_j\\right|^2, \\sum_{j \\geq N} \\left|w_j\\right|^2 \\leq \\epsilon^2", block: true)]]

#text("(i.e. ")#mi("{v, w}")#text(" are ")#mi("{\\epsilon}")#text("-close to ")#mi("{\\ell^2(N)}")#text(") such that ")#tao-math("{\\left|\\langle T^n v, w \\rangle\\right| \\leq \\frac{1}{F(N)}}", block: false)#text(" for all ")#mi("{0 \\leq n \\leq F(N)}")#text(".")
]

#text("This claim is implied by ISP but is significantly weaker than it. Informally, it is saying that one can find two reasonably localised vectors ")#mi("{v, w}")#text(", such that the orbit of ")#mi("{v}")#text(" is highly orthogonal to ")#mi("{w}")#text(" for a very long period of time, much longer than the degree to which ")#mi("{v, w}")#text(" are localised.")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6172cb67f2866d1a9c75bcd4b937ee0f29937b1a9436b3bbd3bec3383798a71-7a7d636c9329b1dad6a7c1660f8dcf5d0a6703a4a72ee7c15f92b2ba9470b1f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45762")[#strong[#text("Alon")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2010")])]

#text("“(in particular, involving a strange concept which, for want of a better name, ” – and there it breaks. Intriguing!")

#emph[#text("[Oops, that was a remnant from an earlier draft of the article. Fixed now. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d3a1b71c24044d03d9bd15dc84b8729a2e13070076d2f32ad39bf852095b8d-a0fed3133bc299a8c9a18e572254cdc5b71b9c7c3d15c2c80ea40aed5941c6aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45765")[#strong[#text("Miguel")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2010")])]

#text("It is understood that ")#emph[#text("v,w")]#text(" in conjecture 9 are also unit vectors.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45769")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2010")])]

#text("Statement of Lemma 3, “strong operator norm topology”, it seems you mean “strong operator topology”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45776")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2010")])]

#text("When you say that conjecture 9 is implied by ISP, you mean that this is so in an elementary way or because it is a special case of FISP0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2010")])]

#text("FISP2 is a consequence of FISP1, which is in turn a consequence of FISP0.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45786")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2010")])]

#text("Here is an attempt to apply dilation theory in conjecture 9. The idea is that any contraction ")#mi("T")#text(" on the Hilbert space ")#mi("\\ell^2({\\rm {\\bf N}})")#text(" has a unitary power dilation, that is, ")#mi("\\ell^2({\\rm {\\bf N}})")#text(" is a subspace of a larger Hilbert space ")#mi("H")#text(" and there is a unitary operator ")#mi("U:H \\rightarrow H")#text(" with the nice property that ")#mi("PU^nP=T^n")#text(" for all ")#mi("n \\geq 0")#text(", where ")#mi("P:H \\rightarrow \\ell^2({\\rm {\\bf N}})")#text(" represents the orthogonal projection. This suggests the following modification of conjecture 9:")

#strong[#text("Claim A")]#text(" There exists ")#mi("N>0")#text(" and there are unit vectors ")#mi("f,g \\in H")#text(" such that")

#tao-math("\\displaystyle \\max \\{ \\left\\|(I-P_N)f \\right\\| , \\left\\|(I-P_N)g\\right\\| \\} < \\varepsilon", block: false)#text(",")

#tao-math("\\displaystyle  \\left|\\langle U^nf,g \\rangle\\right|<\\frac{1}{F(N)}", block: false)#text(" for each ")#mi("0 \\leq  n \\leq F(N)")#text(",")

#text("where ")#mi("P_N:H \\rightarrow \\ell^2(N)")#text(" denotes the orthogonal projection.")

#text("Now, consider the vectors ")#mi("v=Pf")#text(", ")#mi("w=Pg,")#text(" and notice that")

#mi("\\displaystyle \\langle  U^nPf,Pg \\rangle = \\langle U^nf,g \\rangle + \\langle U^n(Pf-f),g \\rangle + \\langle U^nPf,Pg-g \\rangle")

#text("and therefore")

#tao-math("\\displaystyle \\left|\\langle T^nv,w \\rangle\\right| = \\left| \\langle  U^nPf,Pg \\rangle \\right| < \\frac{1}{F(N)} + 2 \\varepsilon,", block: false)

#text("for all ")#mi("0 \\leq n \\leq F(N).")#text(" I wonder if this kind of argument can be turned into a proof that FISP2 is a consequence of claim A. Notice that the spectral theorem can be applied to represent the unitary operator ")#mi("U")#text(" on the Hilbert space ")#mi("H= L^2(\\mu)")#text(" as a multiplication operator, that is, ")#mi("Uf= \\varphi \\cdot f")#text(" where ")#mi("\\varphi")#text(" is a measurable function and ")#tao-math("\\left|\\varphi (z)\\right|=1", block: false)#text(" a.e.")

#text("It is clear that claim A has the following equivalent formulation:")

#strong[#text("Claim B")]#text(" There exists ")#mi("N>0")#text(" and there is a function ")#mi("h \\in L^2(\\mu)")#text(" such that")

#tao-math("\\displaystyle  \\left\\|(I-P_N)h \\right\\| < \\varepsilon", block: false)#text(",")

#tao-math("\\displaystyle \\left|\\int \\varphi^n h^2 d\\mu \\right|<\\frac{1}{F(N)}", block: false)#text(" for each ")#mi("0 \\leq  n \\leq F(N).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45787")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2010")])]

#text("Sure enough, the function ")#mi("h")#text(" in claim B has norm one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45792")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2010")])]

#text("Claim B should also reflect in the symbol ")#mi("\\varphi")#text(" the fact that ")#mi("U")#text(" is a power dilation of a 1-band limited contraction. What can be said about the symbol ")#mi("\\varphi")#text(" of the minimal unitary power dilation for a 1-band limited contraction?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c12db7c7eaab9ab62c3c8247d8ea433b70a293503fa59e81534badd33981beea-3a3e1afe3bc15edc644626ea16978057f21d37a24774ea35d6a8404804040047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45808")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2010")])]

#text("Terry,")

#text("I only read part of this entry, but here goes nuthin’.")#linebreak()#text(" Let T: H => H, and let x be in H.")

#text("2 3")#linebreak()#text(" Consider x, T(x), T (x) [= T(T(x))], T (x), etc.; let V be the subspace of H they generate.")

#text("2")#linebreak()#text(" If y is in V, then y = a x + a T(x) + a T (x) + … ; then")#linebreak()#text(" 0 1 2")

#text("2")#linebreak()#text(" T(y) = T(a x + a T(x) + a T (x) + …)")#linebreak()#text(" 0 1 2")

#text("2 3")#linebreak()#text(" = a T(x) + a T (x) + a T (x) + … , which is still in V; so, if y is in V, so is")#linebreak()#text(" 0 1 2")

#text("T(y).")#linebreak()#text(" The desired result follows immediately.")#linebreak()#text(" 2")#linebreak()#text(" Take care, T .")

#text("— Rich")

#text("P.S. When you speak of this comment in the future — and you will — please be kind. (This is, of course, a paraphrase of a famous line from “T and Sympathy”.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45810")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2010")])]

#text("oh, come on, rich, you know better than that!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c12db7c7eaab9ab62c3c8247d8ea433b70a293503fa59e81534badd33981beea-3a3e1afe3bc15edc644626ea16978057f21d37a24774ea35d6a8404804040047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45816")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2010")])]

#text("Obviously, the subspace I attempted to describe above may => not <= be proper.")#linebreak()#text(" Sorry 'bout that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d3a1b71c24044d03d9bd15dc84b8729a2e13070076d2f32ad39bf852095b8d-a0fed3133bc299a8c9a18e572254cdc5b71b9c7c3d15c2c80ea40aed5941c6aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-45820")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2010")])]

#text("The operator ")#mi("T_|N")#text(" in the proof of ISP2 assuming FISP0 should be called the compression rather than the restriction of ")#mi("T")#text(" to the subspace ")#mi("\\ell^2(N).")#text(" I say this because the subspace ")#mi("\\ell^2(N)")#text(" is not necessarily invariant under ")#mi("T.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-46132")[#strong[#text("A New Million Dollar Prize? « Gödel’s Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2010")]

#text("[…] have a non-trivial closed invariant sub-space?” See this for some history. See Terence Tao for a recent discussion of this famous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-46972")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2010")])]

#text("Dear Terry,")

#text("You stated the invariant subspace problem for operators on Hilbert space as a conjecture. My comment goes as follows: why a conjecture, with such a few examples of Hilbert space operators, ? As a comparison, with a whole lot of numerical evidence, the Riemann hypothesis, is still just a hypothesis. Could you please comment on this?")

#text("All my best,")#linebreak()#text(" Miguel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-46973")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2010")])]

#text("Well, as the name suggests, the invariant subspace problem is usually termed a “problem” rather than a “conjecture”, and I think there are opinions in both directions as to what the answer to the problem is. The only reason I called it a conjecture was to be able to talk about the logical relationships between different formulations of that conjecture; it is clear what a statement such as “Conjecture 1 implies Conjecture 2” means, whereas “Problem 1 implies Problem 2” does not make as much sense, because problems are usually not formulated as true-false statements the way a conjecture is.")

#text("There is a limit to how much one should read into a name, but I expect that RH is termed a hypothesis due to the immense number of consequences it has. In contrast, I don’t know of many other statements, in functional analysis or otherwise, that would be directly impacted by the solution to the ISP.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e63ea5e1b8218e00224ea4064e491a057dff17e7c93e5d999780a667b1087078-3d3f907f8b982b39a3aa7591934ce51e829e6701c5d4eb8f1b99d0b8dd4c075c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-46988")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("Dear Terry,")

#text("Thanks for a lot again for your reply, and thanks a lot as well for your clear explanation. Now my comment is the following.")

#text("There are a few, but really beautiful results about the existence of invariant subspaces, and they all make very good use of some fixed point theorem. I am thinking about the work of Victor Lomonosov.")

#text("I wonder if these results could be reversed to reduce the ISP to, say, a stronger version of Ky Fan’s fixed point theorem. Would that elevate the ISP to the category of the RH?")

#text("I ask you please to comment on this.")#linebreak()#text(" All my best,")#linebreak()#text(" Miguel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c0a8a299fcb423a4d8db5bf18a9bc82dc500efe8ff587e0e1ff6ed66a2b0210-bf173d265dabb65c3cd3d87b0d0cec80da923e18c05d0f7b0817ec4fcc19facf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yujiayang")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-47881")[#strong[#text("yujiayang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("Dear Terry,")

#text("In your proof of ISP2 assuming FISP0,")#linebreak()#text(" you claim:")#linebreak()#text(" (if F’ is sufficiently rapid) the two vectors differ by at most 1/m for 0=< n =1 your hints can’t be used to prove the estimation,unlucky we also can’t find a way to prove your claim.Obviously,it’s a key step for your proof,do you notice this problem?")

#text("All my best,")#linebreak()#text(" Yu")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-47882")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("The easiest way to see this is by (sequential) compactness. If the claim was not true, then for every ")#mi("M \\geq 1")#text(" there would exist an F-tight operator ")#mi("T_M")#text(" and unit vectors ")#mi("v_M")#text(" that are within ")#mi("1/M")#text(" of ")#mi("\\ell^2(N_m)")#text(", such that ")#mi("(T_M|_M)^m v_M")#text(" and ")#mi("T_M^m v_M")#text(" differ by at least some ")#mi("\\varepsilon > 0")#text(" which is independent of ")#mi("M")#text(". There is enough compactness here to make ")#mi("T_M")#text(" converge to a limit ")#mi("T")#text(" in the strong operator topology, and ")#mi("v_M")#text(" converge to a unit vector ")#mi("v")#text(" in ")#mi("\\ell^2(N_m)")#text(", after taking a subsequence. But then ")#mi("T_M|_M")#text(" also converges to ")#mi("T")#text(" in the strong operator topology, and so ")#mi("(T_M|_M)^m v_M")#text(" and ")#mi("T_M^m v_M")#text(" both converge to ")#mi("T^m v")#text(", a contradiction.")

#text("One can also argue directly by carefully choosing one’s epsilons in the right order. The point is that because ")#mi("v")#text(" is strongly localised to ")#mi("\\ell^2(N_m)")#text(" (with an accuracy that can be made as strong as one wishes by choosing ")#mi("F^{\\prime}")#text(" rapid enough) and ")#mi("T")#text(" is ")#mi("F")#text("-tight, then ")#mi("Tv")#text(" is strongly localised to some larger ")#mi("\\ell^2(N_{m,1})")#text(" (where ")#mi("N_{m,1}")#text(" does not depend on ")#mi("F^{\\prime}")#text(", but rather on ")#mi("N_m")#text(", ")#mi("F")#text(", and how strong one wishes the localisation to be). One can then obtain similar localisations for ")#mi("T^2 v, \\ldots, T^m v")#text(", and this is enough to obtain the desired approximation if ")#mi("F^{\\prime}")#text(" is large enough.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c0a8a299fcb423a4d8db5bf18a9bc82dc500efe8ff587e0e1ff6ed66a2b0210-bf173d265dabb65c3cd3d87b0d0cec80da923e18c05d0f7b0817ec4fcc19facf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yujiayang")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-47911")[#strong[#text("yujiayang")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("Dear Terry,")

#text("I compute your second suggestion and find that:")

#text("Let G(n)=max{F((n+1)^12),n},")#linebreak()#text(" if F'(n)>max{G^n(n),16(n+1)^6}for all n in N ( G^n means n composition of G)")#linebreak()#text(" then your claim do hold.")#linebreak()#text(" Your hint:”T is F-tight, then Tv is strongly localised to some larger L^2(N(m,1)) …” play a key role in this construction.")

#text("Thanks for your wise suggestion!")

#text("Best wishes!")#linebreak()#text(" Yu")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-214709")[#strong[#text("Carnaval Matemáticas: Resuelto el problema del subespacio invariante « Francis (th)E mule Science's News")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2013")]

#text("[…] están bien Terence Tao, “Finitary consequences of the invariant subspace problem,” What’s New, 29 Jun 2010; Adam Azzam, “The Invariant Subspace Problem and Lomonosov’s Theorem,” Part 1, Part […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-214720")[#strong[#text("Eva Gallardo y Carl Cowen resuelven el problema del subespacio invariante - Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2013")]

#text("[…] Finitary consequences of the invariant subspace problem en el blog de Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-263401")[#strong[#text("Carnaval Matemáticas: Resuelto el problema del subespacio invariante [erróneamente] | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2014")]

#text("[…] están bien Terence Tao, “Finitary consequences of the invariant subspace problem,” What’s New, 29 Jun 2010; Adam Azzam, “The Invariant Subspace Problem and Lomonosov’s Theorem,” Part 1, Part […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0336a067a6cc3aeeef4bcd87f79972489b374b56347f7ae71e111428ec91d9b4-d9e110bad80843e10c90c00ee1ee978eaf9d0550710d68b70e09ccec397131ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SK Rayamajhi")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-586207")[#strong[#text("SK Rayamajhi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2020")])]

#text("Why is compact operator so prevalent in Invariant subspace problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/06/29/finitary-consequences-of-the-invariant-subspace-problem/#comment-586495")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2020")])]

#text("Compact operators are basically those operators that can be well approximated (in various senses) by finite rank operators, and finite-dimensional linear algebra provides plenty of invariant subspaces for finite rank operators. So it is natural to expect that many of the partial results on the invariant subspace problem for finite rank operators can be extended to the compact case. But this still falls well short of the general case, as the class of all bounded operators is much “larger” than the space of compact operators (as witnessed by the complexity of the ")#link("https://en.wikipedia.org/wiki/Calkin_algebra")[#text("Calkin algebra")]#text(").")
]
]
