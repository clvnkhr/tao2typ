// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/
// Converted to Typst by tao2typ: "2026-10-14T11:17:25.257541+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematical Discourse", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematical Discourse")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 August 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/")[#text("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://urldefense.com/v3/__https://www.mathematicaldiscourse.org/__;!!NubF!PGgQ_0RT3MCvBODPvxkQkWkhvIFQ3BEa_NqVLtOPLC9bTbvRUv8wsTqN3SueWBpmLGw516CZg6CmQ8El$")[#emph[#text("Mathematical Discourse")]]#text(" is a new online, peer-reviewed mathematics journal, publishing ")#strong[#text("videos of mathematics research talks")]#text(" of the highest quality. Our inaugural scientific and editorial boards are listed at the end of this message.")

#text("Our goal is to promote and nourish a culture which values communication as an essential part of the research process. Giving a mathematical talk captures the human side of mathematics in a unique way, and supporting these human aspects of our discipline will be ever more important in the coming years.")

#text("We are now accepting submissions for our first issue. If you have seen (or given!) a truly excellent, mathematically stimulating research talk which was video recorded, we hope you will encourage the speaker (possibly yourself!) to submit it.")

#text("Our current call for submissions is limited to ~1 hour research seminar or colloquia style talks in pure mathematics. A detailed description of the scope of the journal and submission requirements are available at ")#link("https://urldefense.com/v3/__https://www.mathematicaldiscourse.org/submit__;!!NubF!PGgQ_0RT3MCvBODPvxkQkWkhvIFQ3BEa_NqVLtOPLC9bTbvRUv8wsTqN3SueWBpmLGw516CZg3nvHAbg$")[#text("https://www.mathematicaldiscourse.org/submit")]#text(".")

#text("We hope you will spread word of this new initiative to your colleagues and collaborators!")

#text("Sincerely yours,")

#text("Katie Mann, Akshay Venkatesh, Rachel Webb")

#text("Managing Editors of Mathematical Discourse")

#strong[#text("Scientific Board:")]#text(" Hugo Duminil-Copin, Larry Guth, Bryna Kra, Yair Minsky, Bjorn Poonen, Terence Tao, Ravi Vakil, Geordie Williamson")

#strong[#text("Editors:")]#text(" Matt Baker, Richard Bamler, Andrej Bauer, Alexei Borodin, Yaiza Canzani, Daniel Cristofaro-Gardner, Jordan Ellenberg, Hélène Eynard-Bontemps, Jessica Fintzen, Sergey Fomin, Zaher Hani, Peter Hintz, Shrawan Kumar, Justin Moore, Samuel Taylor, Richard Thomas, Isabel Vogt, Yilin Wang, Alex Wright, Zhiwei Yun")

#link("https://urldefense.com/v3/__http://mathematicaldiscourse.org__;!!NubF!PGgQ_0RT3MCvBODPvxkQkWkhvIFQ3BEa_NqVLtOPLC9bTbvRUv8wsTqN3SueWBpmLGw516CZgxlHUHem$")[#text("mathematicaldiscourse.org")]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694057")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2026")])]

#text("I must say I am a bit skeptical of “Giving a mathematical talk captures the human side of mathematics in a unique way,” … can’t AI also generate videos and talks? I don’t think it would be so hard for OpenAI or Anthopic to generate a video in which the AI-generated speaker speaks about the chain of thought and writes on a blackboard. I don’t think that changing the medium from papers to talks really does anything as far as these issues are concerned. Even if you don’t allow talks by AI, it’s very easy to edit a talk with AI, or have a human presented on an AI-generated result. I guess there is a potential issue where non-mathematicians AI generate results but don’t know mathematics and then claim credit for it, but couldn’t such people just AI generate a transcript of the talk and then present it?")

#text("In any case, I am very skeptical that LLMs will replace human mathematicians completely. I think that LLMs are a wonderfully useful tool and are very good at some kinds of results but I think humans are still very useful. Perhaps in the 2040s some kind of AI that passes the Alpha Zero test will come along and make mathematics like chess: ")#link("https://www.ams.org/journals/notices/202607/noti3373/noti3373.html")[#text("https://www.ams.org/journals/notices/202607/noti3373/noti3373.html")]#text(" . But I really doubt LLMs will do that.")

#text("I think that having a collection of great talks might be useful anyway for non-AI related reasons. Often when a result is written up, one needs to put in a lot of details that make it more rigorous but less readable. Memory span is larger for auditory input than for visual input.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2026")])]

#strong[#text("Kudos to the conveners. This is a very innovative initiative.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694066")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("what is the definition of an “excellent talk”? What type of excellence in talks is this journal try to capture?")

#text("I know a few different definitions people would find reasonable and talks might be eccellent with one and not with the other.")

#text("This should be clarified.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694068")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("As with more traditional journals, we will rely upon the judgment of the editors and referees of the journal to make these determinations. My own personal standard would be based on the extent to which a professional mathematician would have their understanding and motivation of the topic, as well as the ability to utilize the relevant literature, increased as a result of the talk. But I expect that other editors on the board may prioritize different desiderata: as the journal matures and we continue to have board discussions and referee feedback on submissions, I expect that we will be able to arrive at a consensus rubric that we can then use to provide more explicit guidance on the journal web site. (The first few published talks should also help set this standard.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/722657f2faa9f030f1032170579d4cd788c11d13aa2457abf0b947fabec44288-4167180f6089aa3a8d3d903343ef51c2d777ca642dae18df7d6675d9f570649c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of breadcrafty93340626b3")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694200")[#strong[#text("breadcrafty93340626b3")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2026")])]

#text("Dear Professor Tao,In your ICM talk, you said that if an author cannot clearly explain a result, it should not be published — even if formally verified.")

#text("I have one question: Is clear explanation itself the verification, or only its social form?")

#text("In a classical construction, verification happens when the construction locks itself. Given a segment, draw two circles with centers at its endpoints and radius equal to its length — the equilateral triangle is there. No explanation is needed for it to exist.")

#text("If so, is the irreducible act not explanation, but rather stopping at the locked point?")

#strong[#text("I ask because I am trying to understand what “human verification” means in the AI-assisted future: if the construction itself is the verification, then the human act is only to recognize that it has already happened. Is that consistent with your view, or would you place human explanation at the same level as construction?")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694075")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("To what extent will the talks be evaluated for talk quality vs the quality of the result? Will there be a priority for talks on top tier results, or an excellent presentation? Or will this be something figured out over time?")

#text("Also, is the referee process the same in this context? As in, quick opinions and then full reports, or is some other mechanism in play?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694078")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2026")])]

#text("Traditional journals value both the significance of the result and the exposition of the result, and our journal will do the same, but perhaps with a slightly higher weight on the latter than in a traditional journal. I expect the editorial discussion of the first few submissions to be detailed; it is easier to set appropriate standards once we have some concrete submissions to discuss rather than purely theoretical future submissions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("I wonder whether a more promising direction would be to build something closer to a ")#strong[#text("Wikipedia for AI-assisted mathematical results")]#text(", rather than a conventional journal.")

#text("Such a platform could be openly and continuously editable. A result might initially be ")#emph[#text("proposed by")]#text(" one person, then ")#emph[#text("developed, verified, corrected, or extended by")]#text(" others, with the contribution history transparently recorded. People could comment on individual arguments, improve proofs, add references, connect related results, or incorporate new computational and AI-assisted evidence.")

#text("One advantage of this model is that ")#strong[#text("credit would become more granular and distributed")]#text(". Instead of forcing a mathematical result into the traditional model of a fixed paper with a fixed author list, many people could receive visible credit for the different ways in which they helped turn an AI-generated or AI-assisted result into reliable mathematics.")

#text("I think this could also create much stronger incentives for mathematicians to curate, verify, organize, and improve the rapidly growing body of AI-assisted mathematics. In that sense, perhaps what we need is not so much a new journal for AI mathematics, but an ")#strong[#text("open, evolving mathematical knowledge base")]#text("—something between Wikipedia, a collaborative research notebook, and a version-controlled repository, where anyone can comment, edit, verify, and contribute, while the full history of contributions remains visible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2026")])]

#text("In traditional journals referee often points out some errors and misprints which are then corrected before the paper is published. Is there anything analogous in this journal? I assume editing a video is rarely an option. Will you be providing errata accompanying a video?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("I expect this to be a rare event, but certainly as with traditional print journals, one can add a process for inserting errata, either in the form of a revised video (if this is feasible) or a text accompaniment to the video as part of the metadata.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99069c28ff235a383a05fae3524469ed0f3ef35444c49362a9fa7097350aa83a-aaf39587c65c4e869ef7fef7eecb687316c9970160c172d3bbbaf776fb9786d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of musicoptimisticb1c805d033")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694101")[#strong[#text("musicoptimisticb1c805d033")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("I love Mathematics … but my academic specialization and level is quite far from the universe you deal with, currently. But I will try my best to understand :-).")

#text("(In my graduation as mechanical engineer, in the past 70´s, my math methods on physics teacher said “this is very difficult; I don´t want you to learn all; I only want you to know that this math area exists and what you can possibly do with it”. I felt it was a nice approach.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2026")])]

#text("nan mais c’est bon les rageux : Oui c’est possible de solutionner des problemes meme difficile par la discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Hopkins")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694116")[#strong[#text("Sam Hopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("This sounds like a very cool idea. But I’m a bit surprised by one particular, technical point: the journal is an “overlay journal,” meaning that the videos of the talks will actually be hosted at YouTube or Internet Archive or some other similar site. What was the reason for doing this? Costs associated with hosting videos? Legal reasons? Something else? To me it would seem best for preservation purposes, and ensuring open access for all, to have the journal website directly host the videos.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694117")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2026")])]

#text("Cost (including both technical hosting costs and legal compliance costs) are indeed a major issue here, since the journal is diamond open access and runs on basically a zero budget. The ")#link("https://en.wikipedia.org/wiki/Overlay_journal")[#text("overlay journal model")]#text(" already has many working examples in print form, e.g., ")#link("https://discreteanalysisjournal.com/")[#text("Discrete Analysis")]#text(", so I see no reason why it cannot also work in video form.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694186")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2026")])]

#text("Could/Would these talks be eventually used to train models in less formal aspects of mathematical thinking in which they might be lacking today? For example, asking quality questions or, well, exposition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/08/22/mathematical-discourse/#comment-694424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The only solution seems to use locally hosted models, they are good enough to serve as assistants and accelerate routine parts of research, and to keep ideas private from OpenAI and other companies that scoop any usage of their models as sounding boards for ideas.")

#text("The Navier Stokes scandal should servebas a wake up call. These companies are not friends of humanity. They dont want to provide a tool that helps spread knowledge and assist human creativity. They want to replace humans – all of humanity – with slop and techno feudalism with power concentrated in few centers in Silicon Valley. That has to be rejected if we are to survive as a species.")

#text("Going local is the only way to fight back and universities have money to get hardvare for hosting locally the most advanced opensource models – and even train them locally on specialised skills. We need independence from the Silicon Valley giants.")

#text("That would deny them transcript data from which they steal ideas and training data – they already scooped all public data books and papers. More importantly, going local would kill their bottom line of profitability and concentation of power they are betting on. Universities can lead, and companies will follow. Better a local model, possibly locally improved, that is weaker than centralised model that steals your ideas and strips you of doing research, destroying human capital.")

#text("Once their techno-feudalist promise breaks down when universities and companies start to realise that they are destructive entities, their VC bubble will burst. They cannot be maintained by ordinary users who have little need for very advanced stuff – they need companies to rely on their cloud intelligence. Going local destroys that agenda. Already, open models like kimi are pretty good, and can accelerate research. Also, we need to decentralize the progress and strip the Silicon Valley companies of their monopolies on AI. AI should be a tool, not a field killer that turns every human enterprise into slop and brute force demonstration of power at budgets that surpass budgets for entire subfields burned in days for IPO valuation push PR worth hundreds of billions of dollars based on a promise that they will make humans obsolete and concentrate power into hands of few dangerous individuals that “don’t have to be nice”. Noone should be at mercy of those sociopaths.")

#text("Navier Stokes scandal should serve as a wake up call and definite end of trust in their good intentions.")
]
