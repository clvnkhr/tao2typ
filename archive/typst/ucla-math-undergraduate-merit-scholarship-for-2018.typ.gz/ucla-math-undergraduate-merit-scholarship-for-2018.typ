// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/
// Converted to Typst by tao2typ: "2026-10-14T10:43:26.376757+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "UCLA Math Undergraduate Merit Scholarship for 2018", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("UCLA Math Undergraduate Merit Scholarship for 2018")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/")[#text("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In 2010, the UCLA mathematics department launched a scholarship opportunity for entering freshman students with exceptional background and promise in mathematics. We are able to offer one scholarship each year. The UCLA Math Undergraduate Merit Scholarship provides for full tuition, and a room and board allowance for 4 years, contingent on continued high academic performance. In addition, scholarship recipients follow an individualized accelerated program of study, as determined after consultation with UCLA faculty. The program of study leads to a Masters degree in Mathematics in four years.")

#text("More information and an application form for the scholarship can be found on the web at:")

#link("http://www.math.ucla.edu/ugrad/mums")[#text("http://www.math.ucla.edu/ugrad/mums")]

#text("To be considered for Fall 2018, candidates must apply for the scholarship and also for admission to UCLA on or before November 30, 2017.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488128")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("does this really matter? UCLA already gets very good students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("How have previous fellows done so far?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("We’re generally pretty pleased with the performance so far. For instance, our MUMS fellows usually compete in our Putnam team competition, leading to some of the best performances UCLA has ever had (e.g., in 2013 ")#link("http://newsroom.ucla.edu/releases/ucla-s-student-math-team-is-3-246022")[#text("we placed third in the entire country")]#text(", and ")#link("http://128.97.4.21/news/ucla-putnam-team-places-6th")[#text("6th in 2016")]#text("). Of the three previous MUMS scholars who have graduated, one is a grad student at MIT, and another is at Chicago, but it is perhaps too early to judge their future academic career at this point. (But our earliest MUMS graduate ")#link("http://www.tandfonline.com/doi/full/10.1080/14689367.2014.970518")[#text("does already have a publication in the mathematics research literature")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("Breaking news, student gets a paper out of an REU")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("Is a student already in university , perhaps in first or second year eligible for this scholarship?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488154")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("The eligibility requirements are listed at ")#link("http://www.math.ucla.edu/ugrad/mums")[#text("http://www.math.ucla.edu/ugrad/mums")]#text(" . In particular, the application is targeted at 12th graders. In principle there is some flexibility with regards to applicants who do not strictly obey all of the eligibility requirements, but the circumstances would have to be somewhat exceptional for such applicants to be considered ahead of those who do fulfil the requirements.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec8375733c8e59aebc8b393cfcfcd6ab0a9c22071a03f94bf5401a0b01f8efd1-ba40e9c319ea3e04b92331fe16284269f910042a2bd216b517bceb199939a292.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dendisuhubdy")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488193")[#strong[#text("dendisuhubdy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("Reblogged this on ")#link("http://suhubdy.com/research/index.php/2017/10/29/ucla-math-undergraduate-merit-scholarship-for-2018/")[#text("Artificial Intelligence Research Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe08f6e3ad488b99fc11c0a6d6f9752688a668090adabc5e5f20dda88b8a6ed1-9242b259cefb9029a8a6e2dcc7ad8377714be9d611845e79874bef3697d084b3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunday Kelly")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488245")[#strong[#text("Sunday Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2017")])]

#text("Hi good evening, i want to participate on it because i am a mathematical researcher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abb504eecbfceca1a104f1da158d0a911cf9bb8210205945467ad7254d8c5068-52f63dcf334d7407c17d7aa7bcd0ecf0d0c896f0bc31f81b2d2186f4ab3adc5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("Too bad poor people from 3rd round countries (especially African ones) don’t have any prospects at getting a decent undergraduate education.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d020de3d8e53933aef84cff32afef15e093664182b355159d2370cd1c676176-be91f03e00e7ce173b4f1e85b772856c7bf30dffb6a8c630460ad7afcdf93003.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert J. III")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488263")[#strong[#text("Robert J. III")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("Life ain’t easy … especially in academia :/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("This is a much larger problem than a single scholarship can solve, but MUMS is open to applicants from all countries, and in fact several of the previous scholars have come from middle-income countries such as Romania and Turkey. We’ve also received some decent applications from Africa in the past, and it’s not out of the question that one of the future scholars would come from that continent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9de42a73e5c742652d0e93d70412948625a799692c1eb1fdaa8351296448321-c88e856d639a8b868bfe127d59e301f2682fa93254d8688ab574c386606caaa0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Exp")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488270")[#strong[#text("Exp")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("I assume that students from Trump’s Muslim ban can still apply?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a55fa8399e2269a45e253365ac44408318dd04ed5a4d64504443e3b3824a23f0-085a229ea07122a195cbf76167de16cb175aba6c0e2bb968cbd28145c1db93c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thegregmartin")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488302")[#strong[#text("thegregmartin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")])]

#text("Terry, have all of the previous MUMS awardees been male? How is the department looking to encourage girls to apply for a prestigious scholarship, for which so many of the suggested qualifications are heavily male-typed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-488303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")])]

#text("The six awardees so far have been male. (There was one year in which our top applicant was in fact female, but despite our best recruiting efforts, she declined the offer and went to Harvard instead.) Advertising the scholarship broadly has in fact been a challenge in recent years; several mailing lists of mathematically talented students that we had previously had permission to use have now been restricted to exclude advertising emails. Any suggestions along these lines would certainly be welcome.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/#comment-490806")[#strong[#text("Peter Meehan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")]

#text("Am I right in saying that significance as in prime numbers is intimately connected with discovery/ or discoverability in the other areas of our knowledge to date ? (Euclid — Now, so to speak)..")
]
