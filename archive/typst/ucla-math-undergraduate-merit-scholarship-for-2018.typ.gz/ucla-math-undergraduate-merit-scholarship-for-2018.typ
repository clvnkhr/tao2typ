// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/
// Converted to Typst by tao2typ: "2026-10-27T12:30:49.374871+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "UCLA Math Undergraduate Merit Scholarship for 2018", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("UCLA Math Undergraduate Merit Scholarship for 2018")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 October 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/")[#text("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In 2010, the UCLA mathematics department launched a scholarship opportunity for entering freshman students with exceptional background and promise in mathematics. We are able to offer one scholarship each year. The UCLA Math Undergraduate Merit Scholarship provides for full tuition, and a room and board allowance for 4 years, contingent on continued high academic performance. In addition, scholarship recipients follow an individualized accelerated program of study, as determined after consultation with UCLA faculty. The program of study leads to a Masters degree in Mathematics in four years.")

#text("More information and an application form for the scholarship can be found on the web at:")

#link("http://www.math.ucla.edu/ugrad/mums")[#text("http://www.math.ucla.edu/ugrad/mums")]

#text("To be considered for Fall 2018, candidates must apply for the scholarship and also for admission to UCLA on or before November 30, 2017.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0848b78f6b6780908b2b1d724e695807d03e92f7e6b0acdf8bc70a6ced765db6-2b43c0a3089c5247f6165dd07a9918455c838c55a3aa69d3a52827d43dfe33ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488128")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("does this really matter? UCLA already gets very good students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488134")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("How have previous fellows done so far?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("We’re generally pretty pleased with the performance so far. For instance, our MUMS fellows usually compete in our Putnam team competition, leading to some of the best performances UCLA has ever had (e.g., in 2013 ")#link("http://newsroom.ucla.edu/releases/ucla-s-student-math-team-is-3-246022")[#text("we placed third in the entire country")]#text(", and ")#link("http://128.97.4.21/news/ucla-putnam-team-places-6th")[#text("6th in 2016")]#text("). Of the three previous MUMS scholars who have graduated, one is a grad student at MIT, and another is at Chicago, but it is perhaps too early to judge their future academic career at this point. (But our earliest MUMS graduate ")#link("http://www.tandfonline.com/doi/full/10.1080/14689367.2014.970518")[#text("does already have a publication in the mathematics research literature")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488187")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("Breaking news, student gets a paper out of an REU")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488142")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2017")])]

#text("Is a student already in university , perhaps in first or second year eligible for this scholarship?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488154")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2017")])]

#text("The eligibility requirements are listed at ")#link("http://www.math.ucla.edu/ugrad/mums")[#text("http://www.math.ucla.edu/ugrad/mums")]#text(" . In particular, the application is targeted at 12th graders. In principle there is some flexibility with regards to applicants who do not strictly obey all of the eligibility requirements, but the circumstances would have to be somewhat exceptional for such applicants to be considered ahead of those who do fulfil the requirements.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7c251830cbe71a292af3bc91e6d19377b76b00d75babf20ce1add9666a4dae3-c59d0881d8ad41c37c1dda6ec17e4dd2ed1c4d30da6327834b77b5c3a5a90ad0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dendisuhubdy")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488193")[#strong[#text("dendisuhubdy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2017")])]

#text("Reblogged this on ")#link("http://suhubdy.com/research/index.php/2017/10/29/ucla-math-undergraduate-merit-scholarship-for-2018/")[#text("Artificial Intelligence Research Blog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79a95716891a0b920ff9c07efbe61490185605ba4a149d637869b4dc36f08d52-b9493a52a5d17fabcaf3f3845e0b3c9abdfa84ed91e878f7deede3fc96f09b2c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunday Kelly")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488245")[#strong[#text("Sunday Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2017")])]

#text("Hi good evening, i want to participate on it because i am a mathematical researcher")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e63f56561f3e3e772409b52ea0f6f73b3b5272cb5934fecc7d5889abdd3cd4a-db4e566aec21bd0878d098e540c1a5afb9ac93078d8a6b6a9da87070dbf53281.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("Too bad poor people from 3rd round countries (especially African ones) don’t have any prospects at getting a decent undergraduate education.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dc40a8c3c27bba4aa586622afa1e43996f232ec282e1d4d795b12c03e1756a8-6f464e9099bee7c0083f32734b78e41a537fb4f1bf6f1645386f3e1feeeefdc2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert J. III")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488263")[#strong[#text("Robert J. III")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("Life ain’t easy … especially in academia ")#image("../assets/c2481f7f3b86cac0ea95eb7ad435f757890893ea99f13ee62418675dca781e16-175eb571c738615ce8b5b57259e81f814a9d264fc2ee96603ef291670615dbfa.svg", width: 90%, alt: ":/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("This is a much larger problem than a single scholarship can solve, but MUMS is open to applicants from all countries, and in fact several of the previous scholars have come from middle-income countries such as Romania and Turkey. We’ve also received some decent applications from Africa in the past, and it’s not out of the question that one of the future scholars would come from that continent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65b22b03f3e2eddfc8932de9318214d3c3d2b1c01a4f7ad7acd695fe94692e39-68e7315b877263434a81fd806bf07b3de19a9c4563db06b3e601be60107e6ad8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Exp")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488270")[#strong[#text("Exp")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2017")])]

#text("I assume that students from Trump’s Muslim ban can still apply?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e58f2af3954a27963bfa0ed8188e39fa5bf4440dc791136ac3cf333f3bd6530-f467fd3e5f0047854a7481b25b06508c1f9120146e04545a9b130827e519ae2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thegregmartin")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488302")[#strong[#text("thegregmartin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")])]

#text("Terry, have all of the previous MUMS awardees been male? How is the department looking to encourage girls to apply for a prestigious scholarship, for which so many of the suggested qualifications are heavily male-typed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-488303")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")])]

#text("The six awardees so far have been male. (There was one year in which our top applicant was in fact female, but despite our best recruiting efforts, she declined the offer and went to Harvard instead.) Advertising the scholarship broadly has in fact been a challenge in recent years; several mailing lists of mathematically talented students that we had previously had permission to use have now been restricted to exclude advertising emails. Any suggestions along these lines would certainly be welcome.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/10/27/ucla-math-undergraduate-merit-scholarship-for-2018/comment-page-1/#comment-490806")[#strong[#text("Peter Meehan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2017")]

#text("Am I right in saying that significance as in prime numbers is intimately connected with discovery/ or discoverability in the other areas of our knowledge to date ? (Euclid — Now, so to speak)..")
]
