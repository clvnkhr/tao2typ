// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:16:30.748767+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A quantitative formulation of the global regularity problem for the periodic Navier-Stokes equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A quantitative formulation of the global regularity problem for the periodic Navier-Stokes equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 October 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/")[#text("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" my paper “")#link("http://arxiv.org/abs/0710.1604")[#text("A quantitative formulation of the global regularity problem for the periodic Navier-Stokes equation”, ")]#text("submitted to ")#link("http://intlpress.com/PDE/")[#text("Dynamics of PDE")]#text(". This is a short note on one formulation of the ")#link("http://www.claymath.org/millennium/Navier-Stokes_Equations/")[#text("Clay Millennium prize problem")]#text(", namely that there exists a global smooth solution to the Navier-Stokes equation on the torus ")#mi("({\\Bbb R}/{\\Bbb Z})^3")#text(" given any smooth divergence-free data. (I should emphasise right off the bat that I am ")#strong[#text("not")]#text(" claiming any major breakthrough on this problem, which remains ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("extremely challenging in my opinion")]#text(".)")#linebreak()#text(" This problem is formulated in a qualitative way: the conjecture asserts that the velocity field ")#mi("u")#text(" stays smooth for all time, but does not ask for a quantitative bound on the smoothness of that field in terms of the smoothness of the initial data. Nevertheless, it turns out that the compactness properties of the periodic Navier-Stokes flow allow one to equate the qualitative claim with a more concrete quantitative one. More precisely, the paper shows that the following three statements are equivalent:")

#enum(start: 1, 
[#text("(Qualitative regularity conjecture) Given any smooth divergence-free data ")#mi("u_0: ({\\Bbb R}/{\\Bbb Z})^3 \\to {\\Bbb R}^3")#text(", there exists a global smooth solution ")#mi("u: [0,+\\infty) \\times ({\\Bbb R}/{\\Bbb Z})^3 \\to {\\Bbb R}^3")#text(" to the Navier-Stokes equations.")],
[#text("(Local-in-time quantitative regularity conjecture)")#linebreak()#text(" Given any smooth solution ")#mi("u: [0,T] \\times ({\\Bbb R}/{\\Bbb Z})^3 \\to {\\Bbb R}^3")#text(" to the Navier-Stokes equations with ")#mi("0 < T \\leq 1")#text(", one has the ")#emph[#text("a priori")]#text(" bound")#tao-math("\\left\\| u(T) \\right\\|_{H^1(({\\Bbb R}/{\\Bbb Z})^3)} \\leq F( \\left\\| u(0) \\right\\|_{H^1(({\\Bbb R}/{\\Bbb Z})^3)} )", block: false)#text(" for some non-decreasing function ")#mi("F:[0,+\\infty) \\to [0,+\\infty)")#text(".")],
[#text("(Global-in-time quantitative regularity conjecture) This is the same conjecture as 2, but with the condition ")#mi("0 < T \\leq 1")#text(" replaced by ")#mi("0 < T < \\infty")#text(".")]
)

#text("It is easy to see that Conjecture 3 implies Conjecture 2, which implies Conjecture 1. By using the compactness of the local periodic Navier-Stokes flow in ")#mi("H^1")#text(", one can show that Conjecture 1 implies Conjecture 2; and by using the energy identity (and in particular the fact that the energy dissipation is bounded) one can deduce Conjecture 3 from Conjecture 2. The argument uses only standard tools and is likely to generalise in a number of ways, which I discuss in the paper. (In particular one should be able to replace the ")#mi("H^1")#text(" norm here by any other ")#link("http://tosio.math.toronto.edu/wiki/index.php/Subcritical")[#text("subcritical")]#text(" norm.)")

#metadata(none) <tao-3a51a2ea20e9417b2ebd>#text("When I ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("previously discussed the Navier-Stokes equations")]#text(", I suggested that perhaps the best hope to attack this equation was by what I called “Strategy 1”: by obtaining a new a priori bound on solutions to this equation. What this result indicates (in the periodic case) is that this strategy is in fact essentially the ")#emph[#text("only")]#text(" strategy for solving this equation, since the regularity problem is in fact ")#emph[#text("equivalent")]#text(" to that of obtaining an a priori bound.")

#text("As the qualitative result is now logically equivalent to a quantitative one, it seems to me that purely “soft” approaches to the problem are now extremely unlikely to work, and that a substantial amount of “hard analysis” would have to go into any putative proof of this problem. In particular, it is clear that if one attempts to construct solutions by expressing them as the limit of some sort of regularised (or discretised) solutions, this can only work if one can obtain a priori bounds on the approximating solutions which are uniform in the approximation parameter, since all other bounds will be lost in the passage to the limit. One of course has the energy inequality for such approximate solutions (which is how Leray constructed global weak solutions to the Navier-Stokes equations), but to obtain smooth solutions one needs to control a norm such as H^1. [Incidentally, the energy inequality does show that ")#tao-math("\\left\\|u(T)\\right\\|_{H^1}", block: false)#text(" is square-integrable in time, but this is quite far away from what we really need, which is that ")#tao-math("\\left\\|u(T)\\right\\|_{H^1}", block: false)#text(" is bounded (or at least fourth power integrable). Actually, these two statements are radically different: the former is a supercritical control on u and the latter is subcritical (or at least critical) control.]")

#text("One amusing consequence of this equivalence is that the Navier-Stokes regularity conjecture is also equivalent to a non-perturbative global stability result for the Navier-Stokes flow. In particular, if the Navier-Stokes regularity conjecture is true, then the solution map maps any bounded set in ")#mi("H^1_x({\\Bbb R}^3/{\\Bbb Z}^3)")#text(" to a bounded set in ")#mi("C^0_t  H^1_x([0,\\infty) \\times {\\Bbb R}^3/{\\Bbb Z}^3)")#text(" in a Lipschitz manner, if one fixes the mean velocity ")#mi("\\int_{{\\Bbb R}^3/{\\Bbb Z}^3} u_0")#text(" to avoid issues with drift. (The dissipation is what allows one to control things at very late times; this is one of the strange features of supercritical estimates such as the energy inequality, in that they offer very poor short-time control but give excellent long-time control.)")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8fb330d863d5c1ae0d3952a499cd2e3e9589b8a3e7bc693519aef7247e2778c7-55d2198d5402f4682822aedc6d5f8c00575b229180bfede8c8c5174b5b0ae879.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of neuroone")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-11602")[#strong[#text("neuroone")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2007")])]

#text("Dear terry,")#linebreak()#text(" I am not a maths or physics major student,my interest is to crack the mystery of the brain or the neurosystem by mathematical ways.")

#text("I think neuroscience have the same terminal goal with maths, and the cognition of human being infulence the way human do maths, they are two interacting things.")

#text("what I want to ask is that, do you have any interest on neuroscience? do you think maths is an effective way to decipher the code of the cognition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IU student")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-11607")[#strong[#text("IU student")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2007")])]

#text("Hi Prof. Tao,")

#text("As I know , the uniqueness of weak solutions is false for Euler equation.")#linebreak()#text(" How about N-S equation ? Is the weak solution unique ?")#linebreak()#text(" What is the connection between the Hausdorff dimension of singular set of a suitable weak sloution and the regularity ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-11931")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2007")])]

#text("Dear IU student,")

#text("I do not know of rigorous non-uniqueness results for the Navier-Stokes equation, but I would not be surprised if weak solutions are indeed non-unique here. On the other hand there are various “weak-strong uniqueness theorems” which assert that if a sufficient amount of regularity is assumed on the weak solution, then the weak solution is in fact unique. I am not sure exactly what the minimal amount of regularity is in the literature in order to obtain this uniqueness result, but I would expect that one needs to control the weak solution in either a sub-critical or critical norm in order for the known methods for establishing uniqueness to be effective.")

#text("I am not sure as to the thrust of your second question; a solution is regular if and only if its singular set is empty. There are various upper bounds on the dimension of the singular set to a weak or strong solution to the Navier-Stokes equations, in particular a well-known result of Caffarelli, Kohn, and Nirenberg, though again the bounds here are subcritical or critical in nature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shuanglin Shao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-12206")[#strong[#text("Shuanglin Shao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2007")])]

#text("Two more typos?")

#text("(1) On page 7, line 3, “A^2” instead of “A” or using bound 1 by suppressing A;")

#text("(2) On page 9, subsection 3.1, “from” instead of “implies”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-12227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2007")])]

#text("Dear Shuanglin,")

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59829c51fd43a73842e7aebcd9ca18d91abecb0f700d462df043d9422c66ed6e-a42673abd950217f31058f3d110bcbf0d661f629db06064977b7ed0ff7306541.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DavePurvance")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-22862")[#strong[#text("DavePurvance")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2008")])]

#strong[#text("Bound for Periodic Navier-Stokes Equation")]#linebreak()#text(" I have shown that a for any spatially periodic flow ")#mi("\\bf{u}")#text(" of initial finite value ")#mi("\\bf{u}_0")#text(" the incompressible Navier-Stokes equation can be posed as a nonlinear matrix differential equation")#linebreak()#text(" ")#mi("d{\\bf{u}}/dt = U\\left(\\bf{u}\\right)\\bf{u}")#text(" (1)")#linebreak()#text(" where matrix ")#mi("U")#text(" is principally a function of wavenumber-shifted ")#mi("\\bf{u}")#text(". When ")#mi("\\bf{u}")#text(" is assumed to be the time series")#linebreak()#text(" ")#mi("{\\bf{u}}=\\sum_{n = 0}^\\infty {\\bf{u}}_nt^n")#text(" (2),")#linebreak()#text(" then (1) becomes")#linebreak()#text(" ")#mi("\\sum_{n=0}^\\infty n{\\bf{u}}_nt^{n-1}=\\sum_{p=0}^\\infty\\sum_{q=0}^\\infty U_p{\\bf{u}}_qt^{p+q}")#text(" (3)")#linebreak()#text(" where ")#mi("U_p")#text(" are matrices made from ")#mi("{\\bf{u}}_p")#text(". Matching coefficients in (3) when ")#mi("t^{n-1}=t^{p+q}")#text(" solves for the unknown flow coefficients ")#mi("{\\bf{u}}_n")#text(" in (3). For ")#mi("n>0")#text(" they are")#linebreak()#text(" ")#mi("{\\bf{u}}_n=1/n\\sum_ {p=0}^{n-1}U_p{\\bf{u}}_{n-1-p}")#text(". (4)")#linebreak()#text(" The remarkable discovery I have recently made is that the only difference between ")#mi("{\\bf{u}}_n")#text(" in (4) and ")#mi("{\\bf{v}}_n")#text(" made from the Taylor expansion of the matrix exponential")#linebreak()#text(" ")#mi("{\\bf{v}}=\\exp\\left(\\sum_{n=0}^\\infty 1/\\left(n+1\\right)U_nt^{n+1}\\right){\\bf{u}}_0")#text(" (5)")#linebreak()#text(" i.e.,")#linebreak()#text(" ")#mi("{\\bf{v}}=\\sum_{n=0}^\\infty 1/n!\\left(\\sum_{p=0}^\\infty 1/(p+1)U_pt^{p+1}\\right)^n{\\bf{u}}_0=\\sum_{n=0}^\\infty{\\bf{v}}_nt^n{\\bf{u}}_0")#text(" (6)")#linebreak()#text(" is a left-to-right reversal in the order of matrix products ")#mi("U_rU_s")#text(" in some of the terms making up ")#mi("{\\bf{u}}_n")#text(" and ")#mi("{\\bf{v}}_n")#text(". When ")#mi("U_n")#text(" commute, the order of a matrix product is immaterial and coefficients ")#mi("{\\bf{u}}_n")#text(" become ")#mi("{\\bf{v}}_n")#text(", as they must.")#linebreak()#text(" What I have argued ")#link("http://arxiv.org/ftp/math/papers/0610/0610086.pdf")[#text("here")]#text(" is that magnitude of the difference between ")#mi("{\\bf{u}}_n")#text(" and ")#mi("{\\bf{v}}_n")#linebreak()#text(" ")#mi("{\\bf{w}}_n={\\bf{u}}_n-{\\bf{v}}_n")#text(" (7)")#linebreak()#text(" is bounded by the magnitude of ")#mi("2{\\bf{v}}_n")#text(". The Navier-Stokes ")#mi("U_n")#text(" are stable and therefore coefficients ")#mi("{\\bf{v}}_n")#text(" converge, implying that ")#mi("{\\bf{u}}_n")#text(" converge.")#linebreak()#text(" Care to comment?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38664")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2009")])]

#text("I believe the integral in the middle of Page 5 is missing dt.")

#text("I could not figure out how you derived the 2nd to last inequality on the bottom of page 6; if you could give hints, it will be great.")

#text("On page 9, you state “The least non-trivial eigenvalue of −(Laplace) on the torus is 1” I’m sory if it’s a poor question, but I don’t see what you are trying to say by that.")

#text("Finally, on this same page you have an epsilon depending on M, but I guess you mean on E.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2009")])]

#text("Thanks for the corrections! For the inequality, one can use Holder’s inequality to bound the ")#mi("L^4_t L^2_x")#text(" norm of ")#tao-math("u \\left|\\nabla u\\right|", block: false)#text(" by the ")#mi("L^\\infty_t L^6_x")#text(" norm of u and the ")#mi("L^4_t L^3_x")#text(" norm of ")#tao-math("\\left|\\nabla u\\right|", block: false)#text(", which by another application of Holder’s inequality can be interpolated between the ")#mi("L^\\infty_t L^2_x")#text(" and ")#mi("L^2_t L^6_x")#text(" norms of ")#mi("\\nabla u")#text(". Meanwhile, T can be replaced by ")#mi("cA^{-4}")#text(" by definition of T.")

#text("The decay of ")#mi("e^{t\\Delta} u")#text(" for a function u of mean zero is controlled by the least non-trivial eigenvalue of the Laplacian. This can be seen by expanding u into eigenfunctions of the Laplacian and using functional calculus. (The mean zero condition is needed to ensure that u has no coefficient corresponding to the trivial eigenvalue of 0, or the trivial eigenfunction of 1.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38721")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear Prof. Tao,")

#text("I can’t derive the inequality in Lem 2.1. I tried in the following way:")

#tao-math("\\partial_t \\int \\partial_i u \\partial_i u=2 \\int \\partial_i u \\partial_i \\partial^2_{jj} u+2 \\int \\partial_i u F=-2 \\left|\\left|u\\right|\\right|_{H^2_0}+2\\int \\partial_i u F \\stackrel{?}{\\leq} -c \\left|\\left|u\\right|\\right|_{H^2_0}+C \\int \\left|\\nabla u\\right|^2 F", block: false)#text(" for some")#linebreak()#text(" ")#mi("\\emph{absolute}")#text(" constants ")#mi("c,C>0")#text(", where ")#mi("\\partial_i:=\\partial_{x_i}")#text(" and we use the Einstein’s notation for the summations and omit the")#linebreak()#text(" t in u and F.")

#text("On the other hand, the heat equation in the proof seems to be")#linebreak()#text(" ")#mi("u_t=\\Delta u+F")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38723")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2009")])]

#text("Dear PDEbeginner,")

#text("The right-hand side of that inequality should be ")#tao-math("\\int \\left|\\nabla^2 u\\right| \\left|F\\right|", block: false)#text(" rather than ")#tao-math("\\int \\left|\\nabla u\\right|^2 F", block: false)#text("; sorry about that. (By the way, in your computation, the ")#mi("\\partial_i u F")#text(" term should be a ")#mi("\\partial_i u \\partial_i F")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38899")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2009")])]

#text("On page 1, you state “as is well-known, we can use Leray projections to eliminate the pressure p.” I clearly see the benefit of utilizing this projection but what is the cost of doing this?")

#text("On top page 5, you state “if u0 is divergence-free then a strong H10 solution u of (4) must be divergence-free also.” I”m sorry I do not see this. Please explain.")

#text("On middle of page 9, you state “T′ ≤ 1 / epsilon” but your initial supposition was 0 ≤ T’ ≤ 1/epsiolon^2.”")

#text("On top page 10, you state “Suppose for contradiction that Conjecture 1.2 failed” when you mean Conjecture 1.3.")

#text("Finally, while reading your paper with much interest, I came across a paper “Global well-posedness for the critical 2D dissipative quasi-geostrophic equation (QG)” by A. Kiselev, F. Nazarov, A. Volberg (The paper is readily found on Arxiv). Some such as Peter Constantin have paid much attention to this QG, which is in principle supposed to be a toy model for the Euler Equation. The 2D critical dissipative QG case had a breakthrough in 2006 by the work shown in this paper. In particular, these three authors gave a brilliant proof constructing a moduli of continuity which works very much like your “non-decreasing function F.” Their method was continued to the case of super-critical QG (cf. Xinwei Yu) with the cost of initial data being small. I am investigating why this method cannot be applied to the NSE, although I’m guessing the main reason is the pressure term that exists in the NSE but not QG. I would be curious to know if you have any thought on this regard.")

#text("Thank you very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2009")])]

#text("Dear Student,")

#text("The main drawback of applying the Leray projection is that the resulting evolution equation for the velocity field u is non-local. But for Fourier-based techniques, the projection is fairly harmless.")

#text("If the initial data ")#mi("u_0")#text(" is divergence free, then so is the linear solution ")#mi("e^{t\\Delta} u_0")#text(" (note that divergence commutes with Fourier multipliers such as ")#mi("e^{t\\Delta}")#text("), and so is the integral term involving D, thanks to the nature of D. One can justify these computations in a distributional sense (testing (4) against some spacetime test function).")

#text("As for QG, one can use perturbation theory (at least in principle) to obtain global well-posedness for supercritical equations (such as Navier-Stokes in 3D) provided that some critical norm of the data is small. It seems that the result of Yu you mention is in this category. There are similar results known for Navier-Stokes, e.g. global well-posedness if the H^{1/2} norm of the velocity is small (a result due, if I recall correctly, to Kato). However these results are not enough to deal with the non-perturbative setting for large data, as I discuss in my post")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("Why global regularity for Navier-Stokes is hard")]
]

#text("Thanks for the corrections!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38973")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear Prof. Tao,")

#text("This paper is very clear for $H^1$ theory for the local wellposedness, I like it very much!")

#text("As for the derivation of Conjecture 1.2 from Conjecture 1.3, it seems a bootstrap argument is enough: On each time interval ")#mi("[n,n+1]")#text(", we take ")#mi("u(n)")#text(" as the initial data, apply Conjecture 1.3, and then obtain a uniform bounds for ")#mi("u")#text(" on ")#mi("[0, N]")#text(", where ")#mi("N \\in \\mathbb{N}")#text(" can arbitrarily large. Of course, the argument for controlling the ")#mi("u")#text(" at large time is very nice, I like it very much!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-38977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2009")])]

#text("Dear PDEBeginner,")

#text("The bound obtained by applying Conjecture 1.3 iteratively is not uniform in N, because the H^1 norm of u(n) is not conserved in n. Each application of Conjecture 1.3 can control the H^1 norm of u(n+1) in terms of the H^1 norm of u(n), but the former can be much larger than the latter, and so one ends up with a growth in N. This is why one needs the large time estimate as well.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20e13394b4a5ee1d75ea9dbdedf0784fd78520aec38a4aaf04e4a05b8dfabbd2-c050445795af850c416af5be58fcabcc054f47557f413a2a9940b5b35fd77edf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Student")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-39069")[#strong[#text("Student")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2009")])]

#text("Dear Professor Tao:")

#text("There is something about NSE being critical (sub or super) that I do not understand and I would really appreciate if you could clarify.")

#text("On one hand we have Quasi-geostrophic Equation (QG) which is a toy model for 3-D NSE and is critical with power of Laplacian at 1/2, subcritical if larger than 1/2 and supercritical if less than 1/2. That is, if \\theta (x, t) is a solution to QG, then so is \\theta (Cx, Ct) for any C a real number.")

#text("I tried to see what is the power of Laplacian of dissipative NSE such that same result occurs. First, I took Leray’s Projector to replace the NSE in a similar setting to the QG, in R^n so that the Projector commutes with Laplacian and hence the Projector really only affects the nonlinear term. Then, the power of Laplacian such that the equation enjoys a nice scaling with no multiplication by some constant seems to be 1/2 as well (and this is the case even if I do not take the Leray Projector; i.e. with the power at 1/2, if u(x, t) and p(x, t) solves the NSE, then so does u(Cx, Ct) and p(Cx, Ct)).")

#text("Is this correct? And if so, I am very confused because adding more power of Laplacian should make any PDE easier to work with and hence any more power on the Laplacian than 1/2 should be subcritical rather than supercritical. In particular, the power at 1 should be subcritical, not super, but I know that’s false.")

#text("I know the dissipative NSE is solved for the powe bigger than 5/4 (by Jonathan Mattingly). But what is the power that separates super and subcritical for NSE?")

#text("Moreover, I did read your notes on the issues of critical (sub, super) in the link below, but I guess you are talking about quantities (e.g. energy) and not the equation.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("Why global regularity for Navier-Stokes is hard")]
]

#linebreak()#text(" How are they related?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-39079")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("Dear student,")

#text("Equations, in and of themselves, are neither critical, subcritical, or supercritical. In order to obtain such a classification one needs both an equation and some functional (such as the energy, the mass, or maybe a Sobolev norm). Basically, both equations and functionals are naturally associated with a means to rescale the solution. If the two rescalings match, the functional is critical for the equation; otherwise, they are supercritical or subcritical depending on which rescaling is stronger at finer scales. When one says a statement such as “Navier-Stokes is supercritical in three dimensions”, this is shorthand for “The strongest known controlled quantity for Navier-Stokes, namely the energy, is supercritical for that equation in three dimensions.”")

#text("In the case of Navier-Stokes in d dimensions, for instance, the rescaling that preserves the equation is given by ")#mi("u(t,x) \\mapsto \\frac{1}{\\lambda} u(\\frac{t}{\\lambda}, \\frac{x}{\\lambda})")#text(", while the rescaling that preserves the energy is ")#mi("u(t,x) \\mapsto \\frac{1}{\\lambda^{d/2}} u(\\frac{t}{\\lambda}, \\frac{x}{\\lambda})")#text(". In three and higher dimensions, the energy rescaling is more severe at fine scales ")#mi("\\lambda \\ll 1")#text(", hence the energy is supeercritical for the equation in that setting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-50660")[#strong[#text("⑥ 纳维-斯托克斯方程组通解的存在性与光滑性：Existence And Smoothness of The Navier-Stokes Equation « Hezhigang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")]

#text("[…] global regularity for Navier-Stokes is hard ξ A quantitative formulation of the global regularity problem for the periodic Navier-Stokes equation ξ Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-50662")[#strong[#text("Existence And Smoothness of The Navier-Stokes Equation « Hezhigang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2011")]

#text("[…] global regularity for Navier-Stokes is hard ξ A quantitative formulation of the global regularity problem for the periodic Navier-Stokes equation ξ Global regularity for a logarithmically supercritical hyperdissipative Navier-Stokes equation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-63753")[#strong[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("[…] of Conjecture 1.4 and Conjecture 7.5 is fairly well known (it is explicitly made for instance in my previous paper). The only remaining nontrivial implication is the deduction of Conjecture 1.6 from Conjecture 1.4, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-468794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("I’m wondering has anybody extended this result to the non-periodic case. Or is it just a trivial exercise for the experts?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-468804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2016")])]

#text("I obtained an extension in a subsequent paper ")#link("http://arxiv.org/abs/1108.1165")[#text("http://arxiv.org/abs/1108.1165")]#text(" , discussed on this blog at ")#link("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("https://terrytao.wordpress.com/2011/08/04/localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")]#text(" and ")#link("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")[#text("https://terrytao.wordpress.com/2011/08/07/a-correction-to-localisation-and-compactness-properties-of-the-navier-stokes-global-regularity-problem/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-468824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2016")])]

#text("This might be a dumb question. I have seen you use the notation ")#mi("X\\lesssim Y")#text(" many times for meaning ")#mi("X\\leq CY")#text(" for some constant ")#mi("C")#text(". Do you happen to know who in history introduce this notation? (Or are you the first one to use it?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474367")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Is the heat equation globally regular?")

#text("If so. Why would Navier-Stokes not be?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474368")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Why we can not we use the solutions of the heat equation and match the rest of the terms with the pressure term? Do the solutions of the heat equation explode?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474373")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Not every term can be matched with a pressure term ")#mi("\\nabla p")#text(", because a gradient such as ")#mi("\\nabla p")#text(" is necessarily curl-free, but nonlinear terms such as ")#mi("(u \\cdot \\nabla) u")#text(" have no reason to be curl-free.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474394")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Thank you. Good Lucky in your research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474395")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Last question: Is total vorticity conserved because of its relationship to angular momentum? Is this useful?")

#text("Good work and good lucky.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474396")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("Sorry this condition is not part of the millennium problem. Do not need to answer.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474370")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2016")])]

#text("Do the derivatives of the heat equation solution “explode”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474385")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2016")])]

#text("A comment on the second last paragraph. Is it not so that the integrability of ")#tao-math("\\left\\|\\nabla\\times u(t)\\right\\|_{L^2}^4", block: false)#text(" in time would be enough for the global existence of a regular solution?")

#emph[#text("[Fair enough; I’ve edited the post accordingly. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474657")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("In “my” idea if we use Helmholtz decomposition theorem we can make some progress ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474660")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("and maybe using vorticity and momentum angular conservation…………….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474665")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2016")])]

#text("If total vorticity is a constant then some integrals may cancel out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474826")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("We can make speed explicit by transforming u=v+r_1 com")

#text("r_1=x i^{^} + y j^{^} + z k^{^} obtemos")

#text("\\frac{\\partial v}{\\partial t} + (v.\\nabla)v+v +(r_1\\nabla)v+r_1-\\ni \\nabla^{2}v=-\\nabla w")

#text("it helps ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-474830")[#strong[#text("Guilherme Rocha")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("How i put in latex ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-492559")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("I’m trying solutions like below.")

#text("latex$ \\frac{\\partial}{\\partial t}u_{i}+\\sum_{j=1}^{n}u_{j}\\frac{\\partial u_{i}}{\\partial x_{j}}=\\nu \\Delta u_{i}-\\frac{\\partial p}{\\partial x_{i}}+f_{i}(x,t) \\hspace{5mm} (x \\in \\mathbb{R}^{n},t \\geq 0) \\\\")#linebreak()#text(" div \\hspace{1mm} u=\\sum_{i=1}^{n}\\frac{\\partial u_{i}}{\\partial x_{i}}=0 \\hspace{5mm} (x \\in \\mathbb{R}^{n},t \\geq 0) \\\\")#linebreak()#text(" u_{i}(x,t)=u_{i}^{0}(x)e^{-t}+\\frac{C_{i}te^{-t}}{\\cosh(K_{1}x_{1}+K_{2}x_{2}+K_{3}x_{3})} $")

#text("The constants K1, K2 and K3 must be chosen so that the div u is = 0.")

#text("It seems that we can satisfy the boundary conditions without the divergence of the solution.")

#text("This kind of solution would not solve the millennium problem – Navier-Stokes?")

#text("I’m wrong ? Why ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b92146bf7933491cf71be4ce9d90d239dc1e15e8ccce0f6ca8d709d3f4bfd142-c5677d3e2dba73aa122253a0699d614f7c58a47c962a9ad5c21e2c5b9432b9be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-492562")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2018")])]

#text("The general form of the solution I’m looking for is u_i(x,t)=u_i^0(x)exp(-t)+t exp(-t)f_i(x). I have chosen above for f (x) the hyperbolic cosine function. Sounds like a good way. Is it really a good way? Sorry for the latex. I made some careful accounts of the solution and it seems to satisfy the contour conditions of the article defining the millennium problem – Navier-Stokes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8d7f184fcc01630238850b5d1d1abdcc6f5398263e42a4f513bcc381277a27e-ca2a6b9f6a4dfa8e38386d30c1d084ec1e8aeb729c0b965dc5e12bfe5179f589.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oleg Alexandrov")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-550442")[#strong[#text("Oleg Alexandrov")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("Say it was proven that the Navier-Stokes solution can blow up in finite time. Would that affect real-world behavior, or by that time the model stops imitating reality faithfully and the real fluid is actually fine? Navier-Stokes is, at the end of the day, an approximation, it does not work at the molecular scale, where a real fluid would be reduced to random motion of particles, while the model may still show a pattern of eddies (unless the viscosity component smoothes over those before that).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-550472")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2020")])]

#text("That is correct; an example of finite time blowup for Navier-Stokes would mean that a physical fluid that was sufficiently close to the initial data of this blowup example would eventually depart from the dynamics predicted by Navier-Stokes – certainly this would happen for instance if a non-trivial portion of the dynamics occurred at molecular scales or finer, and perhaps the deviation from Navier-Stokes could happen before then. On the other hand, Navier-Stokes does seem to be a good approximating model for many regimes that occur in practice, so it seems reasonable to predict that global regularity still holds for “typical” initial data even if we do end up finding some small sets of exceptional initial data that lead to finite time blowup.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-550613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Such blowup (with unbounded velocity) is obviously automatically avoided by any (more realistic) special relativistic model.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3353e7fbfba50534b1fad68a0e47032b8ae37d5821db5c81cc0c2c92558ccefc-b4179e756627fcd9f5c97be11f46366bed016db15d69daaae0c24cec31113734.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James")]], [#link("https://terrytao.wordpress.com/2007/10/09/a-quantitative-formulation-of-the-global-regularity-problem-for-the-periodic-navier-stokes-equation/#comment-624642")[#strong[#text("James")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2021")])]

#text("The biggest issue we face is how to resolve for curl and how to obtain a behaviour that prevents the blowup in (in)finite time.")

#text("Out of curiousity, if the vector field is the inverse of a tensor, and we differentiate to find its components, what would integrating the components of the vector field do? The same? I was thinking of rebuilding Cauchy as a rank 3 tensor and doing some work from that end.")
]
