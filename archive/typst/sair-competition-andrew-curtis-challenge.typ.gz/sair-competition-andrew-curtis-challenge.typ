// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/11/sair-competition-andrew-curtis-challenge/
// Converted to Typst by tao2typ: "2026-10-14T11:17:49.958499+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR competition: Andrews-Curtis challenge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR competition: Andrews-Curtis challenge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/11/sair-competition-andrew-curtis-challenge/")[#text("https://terrytao.wordpress.com/2026/09/11/sair-competition-andrew-curtis-challenge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This is a guest post by ")#link("https://www.linkedin.com/in/lucasfagan17/")[#text("Lucas Fagan")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("I am excited to announce the ")#link("https://competition.sair.foundation/competitions/acc")[#text("Andrews–Curtis Conjecture Challenge")]#text(", which opens today. This challenge is a collaboration between the ")#link("https://sair.foundation/")[#text("SAIR Foundation")]#text(" and the ")#link("https://math-ai.caltech.edu/")[#text("Math-AI group at Caltech")]#text(", organized by Sergei Gukov, Terence Tao, and myself.")

#text("The Andrews–Curtis conjecture is one of the most prominent open problems in combinatorial group theory and also has deep connections to low-dimensional topology. Its potential counterexamples are relevant to the search for exotic smooth four-spheres and the ")#link("https://arxiv.org/abs/0906.5177")[#text("smooth four-dimensional Poincaré conjecture")]#text(", as well as the ")#link("https://doi.org/10.2140/gt.2010.14.2305")[#text("Generalized Property R conjecture about surgery on links")]#text(". Yet unlike many open problems at its level, Andrews–Curtis can be formulated as a combinatorial search problem with easily checkable solutions, making it ideal for a challenge of this form.")

#text("At Caltech, we have been developing reinforcement learning and combinatorial search methods for this problem to resolve potential counterexamples (see ")#link("https://arxiv.org/abs/2408.15332")[#text("What makes math problems hard for reinforcement learning: a case study")]#text(" and ")#link("https://arxiv.org/abs/2606.21611")[#text("The Two-Hump Problem")]#text("). However, many important cases have resisted all our efforts. We hope that this challenge will lead to resolving these and more (or disproving the conjecture), especially given the recent progress in AI. We give more details about the different tracks of the competition below.")

#metadata(none) <tao-7a9a61a6c703812ba11f>

#text("To briefly introduce the problem: the ")#link("https://doi.org/10.1090/S0002-9939-1965-0173241-8")[#text("Andrews–Curtis conjecture")]#text(" says that any balanced presentation of the trivial group ")#mi("{\\langle x_1, \\dots, x_n \\mid r_1, \\dots, r_n \\rangle}")#text(" can be transformed to the trivial presentation ")#mi("{\\langle x_1, \\dots, x_n \\mid x_1, \\dots, x_n \\rangle}")#text(" using the following moves (which do not change the underlying group):")

#list(
[#text("(AC1) Invert a relator: ")#mi("{r_i \\rightarrow r_i^{-1}}")#text(".")],
[#text("(AC2) Multiply a relator by another: ")#mi("{r_i \\rightarrow r_i r_j}")#text(" for some ")#mi("{j \\neq i}")#text(".")],
[#text("(AC3) Conjugate a relator by a generator or its inverse: ")#mi("{r_i \\rightarrow g^{-1} r_i g}")#text(" for some ")#mi("{g \\in \\{x_1^{\\pm 1}, \\dots, x_n^{\\pm 1}\\}}")#text(".")]
)

#text("Two presentations connected by these moves are called ")#emph[#text("AC-equivalent")]#text("; a presentation that is AC-equivalent to the trivial presentation is called ")#emph[#text("AC-trivial")]#text(". As a simple example, ")#mi("{\\langle x,y \\mid xy, y \\rangle}")#text(" is AC-trivial:")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{rl} \\langle x,y \\mid xy, y \\rangle & \\stackrel{(AC1)}{\\longrightarrow} \\langle x,y \\mid xy, y^{-1} \\rangle \\\\ & \\stackrel{(AC2)}{\\longrightarrow} \\langle x,y \\mid x, y^{-1} \\rangle \\stackrel{(AC1)}{\\longrightarrow} \\langle x,y \\mid x,y \\rangle. \\end{array}")]]

#text("It is ")#link("https://arxiv.org/abs/math/0302080")[#text("generally suspected that the conjecture is false")]#text("; there are many simple potential counterexamples in which all computational efforts have failed to find a path to the trivial presentation. The most notable of these is the ")#link("https://doi.org/10.1016/0040-9383(85)90010-2")[#text("Akbulut–Kirby family")]

#align(center)[#tao-fit-display[#mitex("AK(n) = \\langle x,y \\mid xyx = yxy, x^n = y^{n+1} \\rangle,")]]

#text("whose ")#link("https://arxiv.org/abs/2408.15332")[#text("AC-triviality is open")]#text(" for ")#mi("{n \\geq 3}")#text(". Indeed, ")#mi("{AK(3)}")#text(", with total relator length ")#mi("{3+3+3+4 = 13}")#text(", is the shortest possible counterexample on two generators up to AC-equivalence: all other such candidates with total relator length ")#mi("{\\leq 13}")#text(" are AC-trivial or AC-equivalent to ")#mi("{AK(3)}")#text(" (see ")#link("https://arxiv.org/abs/math/0304305")[#text("Miasnikov and Myasnikov")]#text(" and ")#link("https://doi.org/10.1142/S0218196703001365")[#text("Havas and Ramsay")]#text(").")

#text("However, difficulty in finding a path is hardly evidence against a path’s existence: ")#link("https://arxiv.org/abs/1504.04187")[#text("Bridson")]#text(" and ")#link("https://arxiv.org/abs/1504.00418")[#text("Lishak")]#text(" demonstrated families of AC-trivial presentations whose trivialization path lengths grow faster than any fixed-height tower of exponentials in relator length. Bridson also ")#link("https://arxiv.org/abs/1504.04187")[#text("explicitly gives")]#text(" a relatively small four-generator presentation that requires more than ")#mi("{10^{10000}}")#text(" moves to trivialize.")

#text("The competition will also explore the ")#emph[#text("stable")]#text(" Andrews–Curtis conjecture. The stable version asks the same question with two additional allowed moves:")

#list(
[#text("(AC4) Add a generator ")#mi("{x_{n+1}}")#text(" and relator ")#mi("{r_{n+1} = x_{n+1}}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{l} \\langle x_1, \\dots, x_n \\mid r_1, \\dots, r_n \\rangle \\\\ \\rightarrow \\langle x_1, \\dots, x_n, x_{n+1} \\mid r_1, \\dots, r_n, x_{n+1} \\rangle. \\end{array}")]]],
[#text("(AC5) Undo (AC4), removing a generator and its matching relator:")

#align(center)[#tao-fit-display[#mitex("\\begin{array}{l} \\langle x_1, \\dots, x_n, x_{n+1} \\mid r_1, \\dots, r_n, x_{n+1} \\rangle \\\\ \\rightarrow \\langle x_1, \\dots, x_n \\mid r_1, \\dots, r_n \\rangle. \\end{array}")]]]
)

#text("Of course, AC-triviality implies stable AC-triviality, but it is unknown whether the converse holds. Even with stabilization moves, trivializations can be extremely long: ")#link("https://arxiv.org/abs/1504.04187")[#text("Bridson’s lower bounds")]#text(" still hold with these extra moves allowed.")

#text("The stable version of the conjecture is particularly interesting because of its connections to topology. ")#link("https://doi.org/10.1112/plms/s3-16.1.342")[#text("C. T. C. Wall")]#text(" proved that in dimension 3 and higher, we only need one additional dimension to realize any simple homotopy equivalence by elementary expansions and collapses. The stable AC conjecture is equivalent to the statement that this result also holds in dimension 2 in the case of finite contractible polyhedra. The stable AC conjecture is also equivalent to a restricted form of another easy-to-state hard-to-prove open conjecture in low-dimensional topology: ")#link("https://doi.org/10.1016/0040-9383(63)90014-4")[#text("Zeeman’s conjecture")]#text(", which says that for any such polyhedron ")#mi("{K}")#text(", the product ")#mi("{K \\times [0,1]}")#text(" collapses to a point.")

#text("For the competition, the ")#emph[#text("Discovery Track")]#text(" will cover both AC and stable AC and will open today. Both will use the same pool of 10,115 balanced two-generator presentations of the trivial group. The examples range from easy to open research problems, including many from the ")#mi("{AK(n)}")#text(" series mentioned above. Since difficulty is hard to predict, we leave participants to discover which examples are within reach and do not label presentations by difficulty or origin.")

#text("The goal of the Discovery Track is to find short trivialization paths. For AC, paths end at ")#mi("{\\langle x,y \\mid x,y \\rangle}")#text(", and for stable AC, paths end at the empty presentation. For the stable AC search problem, we allow up to eight generators. Participants submit move sequences, which are checked automatically, and you can download the verifier to check solutions locally before submitting.")

#text("The AC and stable AC problems will each have their own leaderboard. For each problem, only teams with the shortest accepted solution receive points, with reduced credit for ties. Finding a shorter solution therefore takes the points from the previous record holders. However, we will note the first solver of each presentation separately. Submitted paths will be private during the competition, and all valid solutions will be released afterwards to form a public benchmark.")

#text("The ")#emph[#text("Proof Track")]#text(" will open later today. It accepts proofs or disproofs of either full conjecture, and counterexamples here do not need to come from the competition pool. Submissions will be public for community review, and organizers may assess selected claims for competition recognition.")

#text("The competition closes on November 30, 2026. AI tools are welcome, and participants can enter individually or as teams. Registration is open on the ")#link("https://competition.sair.foundation/competitions/acc")[#text("competition page")]#text(". We also encourage participants to exchange ideas and discuss the challenge on the ")#link("https://zulip.sair.foundation/")[#text("SAIR Zulip")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/sair-competition-andrew-curtis-challenge/#comment-694547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("cool!")
]
