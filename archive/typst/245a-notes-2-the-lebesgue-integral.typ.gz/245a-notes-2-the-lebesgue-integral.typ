// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/
// Converted to Typst by tao2typ: "2026-10-14T16:36:17.738727+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 2: The Lebesgue integral", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 2: The Lebesgue integral")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the previous notes, we defined the ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" ")#mi("{m(E)}")#text(" of a Lebesgue measurable set ")#mi("{E \\subset {\\bf R}^d}")#text(", and set out the basic properties of this measure. In this set of notes, we use Lebesgue measure to define the ")#link("http://en.wikipedia.org/wiki/Lebesgue_integration")[#text("Lebesgue integral")]

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x)\\ dx")]]

#text("of functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(". Just as not every set can be measured by Lebesgue measure, not every function can be integrated by the Lebesgue integral; the function will need to be ")#link("http://en.wikipedia.org/wiki/Lebesgue_measurable_function")[#text("Lebesgue measurable")]#text(". Furthermore, the function will either need to be unsigned (taking values on ")#mi("{[0,+\\infty]}")#text("), or absolutely integrable.")

#text("To motivate the Lebesgue integral, let us first briefly review two simpler integration concepts. The first is that of an infinite summation")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty c_n")]]

#text("of a sequence of numbers ")#mi("{c_n}")#text(", which can be viewed as a discrete analogue of the Lebesgue integral. Actually, there are two overlapping, but different, notions of summation that we wish to recall here. The first is that of the ")#emph[#text("unsigned infinite sum")]#text(", when the ")#mi("{c_n}")#text(" lie in the extended non-negative real axis ")#mi("{[0,+\\infty]}")#text(". In this case, the infinite sum can be defined as the limit of the partial sums ")#metadata(none) <tao-989278ad10e33d97c46f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n=1}^\\infty c_n = \\lim_{N \\rightarrow \\infty} \\sum_{n=1}^N c_n")]]



#text(" or equivalently as a supremum of arbitrary finite partial sums: ")#metadata(none) <tao-827a50bcdb99747a0e83>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n=1}^\\infty c_n = \\sup_{A \\subset {\\bf N}, A \\text{ finite}} \\sum_{n \\in A} c_n.")]]



#text(" The unsigned infinite sum ")#mi("{\\sum_{n=1}^\\infty c_n}")#text(" always exists, but its value may be infinite, even when each term is individually finite (consider e.g. ")#mi("{\\sum_{n=1}^\\infty 1}")#text(").")

#text("The second notion of a summation is the ")#link("http://en.wikipedia.org/wiki/Absolute_convergence")[#text("absolutely summable infinite sum")]#text(", in which the ")#mi("{c_n}")#text(" lie in the complex plane ")#mi("{{\\bf C}}")#text(" and obey the absolute summability condition")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|c_n\\right| < \\infty,", block: true)]]

#text("where the left-hand side is of course an unsigned infinite sum. When this occurs, one can show that the partial sums ")#mi("{\\sum_{n=1}^N c_n}")#text(" converge to a limit, and we can then define the infinite sum by the same formula ")#link(<tao-989278ad10e33d97c46f>)[#text("(1)")]#text(" as in the unsigned case, though now the sum takes values in ")#mi("{{\\bf C}}")#text(" rather than ")#mi("{[0,+\\infty]}")#text(". The absolute summability condition confers a number of useful properties that are not obeyed by sums that are merely conditionally convergent; most notably, the value of an absolutely convergent sum is unchanged if one rearranges the terms in the series in an arbitrary fashion. Note also that the absolutely summable infinite sums can be defined in terms of the unsigned infinite sums by taking advantage of the formulae")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty c_n = (\\sum_{n=1}^\\infty \\text{Re}(c_n)) + i (\\sum_{n=1}^\\infty \\text{Im}(c_n))")]]

#text("for complex absolutely summable ")#mi("{c_n}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty c_n = \\sum_{n=1}^\\infty c_n^+ - \\sum_{n=1}^\\infty c_n^-")]]

#text("for real absolutely summable ")#mi("{c_n}")#text(", where ")#mi("{c_n^+ := \\max(c_n,0)}")#text(" and ")#mi("{c_n^- := \\max(-c_n,0)}")#text(" are the (magnitudes of the) positive and negative parts of ")#mi("{c_n}")#text(".")

#text("In an analogous spirit, we will first define an ")#emph[#text("unsigned Lebesgue integral")]#text(" ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" of (measurable) unsigned functions ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(", and then use that to define the ")#emph[#text("absolutely convergent Lebesgue integral")]#text(" ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" of ")#link("http://en.wikipedia.org/wiki/Absolute_convergence")[#text("absolutely integrable")]#text(" functions ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(". (In contrast to absolutely summable series, which cannot have any infinite terms, absolutely integrable functions will be allowed to occasionally become infinite. However, as we will see, this can only happen on a set of Lebesgue measure zero.)")

#text("To define the unsigned Lebesgue integral, we now turn to another more basic notion of integration, namely the ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(" ")#mi("{\\int_a^b f(x)\\ dx}")#text(" of a Riemann integrable function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(". Recall from the prologue that this integral is equal to the ")#link("http://en.wikipedia.org/wiki/Darboux_integral")[#text("lower Darboux integral")]

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x) = \\underline{\\int_a^b} f(x)\\ dx := \\sup_{g \\leq f; g \\text{ piecewise constant}} \\text{p.c.} \\int_a^b g(x)\\ dx.")]]

#text("(It is also equal to the upper Darboux integral; but much as the theory of Lebesgue measure is easiest to define by relying solely on outer measure and not on inner measure, the theory of the unsigned Lebesgue integral is easiest to define by relying solely on lower integrals rather than upper ones; the upper integral is somewhat problematic when dealing with “improper” integrals of functions that are unbounded or are supported on sets of infinite measure.) Compare this formula also with ")#link(<tao-827a50bcdb99747a0e83>)[#text("(2)")]#text(". The integral ")#mi("{\\text{p.c.} \\int_a^b g(x)\\ dx}")#text(" is a ")#emph[#text("piecewise constant")]#text(" integral, formed by breaking up the piecewise constant functions ")#mi("{g, h}")#text(" into finite linear combinations of ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator functions")]#text(" of intervals, and then measuring the length of each interval.")

#text("It turns out that virtually the same definition allows us to define a ")#emph[#text("lower Lebesgue integral")]#text(" ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(" of any unsigned function ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(", simply by replacing intervals with the more general class of Lebesgue measurable sets (and thus replacing piecewise constant functions with the more general class of ")#link("http://en.wikipedia.org/wiki/Simple_function")[#text("simple functions")]#text("). If the function is ")#link("http://en.wikipedia.org/wiki/Lebesgue_measurable_function")[#text("Lebesgue measurable")]#text(" (a concept that we will define presently), then we refer to the lower Lebesgue integral simply as the ")#emph[#text("Lebesgue integral")]#text(". As we shall see, it obeys all the basic properties one expects of an integral, such as monotonicity and additivity; in subsequent notes we will also see that it behaves quite well with respect to limits, as we shall see by establishing the two basic convergence theorems of the unsigned Lebesgue integral, namely ")#link("http://en.wikipedia.org/wiki/Fatou's_lemma")[#text("Fatou’s lemma")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(".")

#text("Once we have the theory of the unsigned Lebesgue integral, we will then be able to define the absolutely convergent Lebesgue integral, similarly to how the absolutely convergent infinite sum can be defined using the unsigned infinite sum. This integral also obeys all the basic properties one expects, such as linearity and compatibility with the more classical Riemann integral; in subsequent notes we will see that it also obeys a fundamentally important convergence theorem, the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(". This convergence theorem makes the Lebesgue integral (and its abstract generalisations to other measure spaces than ")#mi("{{\\bf R}^d}")#text(") particularly suitable for analysis, as well as allied fields that rely heavily on limits of functions, such as PDE, probability, and ergodic theory.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" This is not the only route to setting up the unsigned and absolutely convergent Lebesgue integrals. Stein-Shakarchi, for instance, proceeds slightly differently, beginning with the unsigned integral but then making an auxiliary stop at integration of functions that are bounded and are supported on a set of finite measure, before going to the absolutely convergent Lebesgue integral. Another approach (which will not be discussed here) is to take the metric completion of the Riemann integral with respect to the ")#mi("{L^1}")#text(" metric.")
]

#text("The Lebesgue integral and Lebesgue measure can be viewed as ")#emph[#text("completions")]#text(" of the Riemann integral and Jordan measure respectively. This means three things. Firstly, the Lebesgue theory ")#emph[#text("extends")]#text(" the Riemann theory: every Jordan measurable set is Lebesgue measurable, and every Riemann integrable function is Lebesgue measurable, with the measures and integrals from the two theories being compatible. Conversely, the Lebesgue theory can be ")#emph[#text("approximated")]#text(" by the Riemann theory; as we saw in ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("the previous notes")]#text(", every Lebesgue measurable set can be approximated (in various senses) by simpler sets, such as open sets or elementary sets, and in a similar fashion, Lebesgue measurable functions can be approximated by nicer functions, such as Riemann integrable or continuous functions. Finally, the Lebesgue theory is ")#emph[#text("complete")]#text(" in various ways; we will formalise this properly only in the next quarter when we study ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#mi("{L^p}")#text(" spaces")]#text(", but the convergence theorems mentioned above already hint at this completeness. A related fact, known as ")#link("http://en.wikipedia.org/wiki/Egorov's_theorem")[#text("Egorov’s theorem")]#text(", asserts that a pointwise converging sequence of functions can be approximated as a (locally) uniformly converging sequence of functions. The facts listed here manifestations of ")#link("http://en.wikipedia.org/wiki/Littlewood's_three_principles_of_real_analysis")[#text("Littlewood’s three principles of real analysis")]#text(", which capture much of the essence of the Lebesgue theory.")

#metadata(none) <tao-ea246842cafb354b778a>

#heading(level: 1)[#strong[#text(" — 1. Integration of simple functions — ")]]

#text("Much as the Riemann integral was set up by first using the integral for piecewise constant functions, the Lebesgue integral is set up using the integral for simple functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Simple function)")]#text(" A (complex-valued) ")#emph[#text("simple function")]#text(" ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a finite linear combination ")#metadata(none) <tao-0d4bf5b068aa598c0648>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f = c_1 1_{E_1} + \\ldots + c_k 1_{E_k}")]]



#text(" of indicator functions ")#mi("{1_{E_i}}")#text(" of Lebesgue measurable sets ")#mi("{E_i \\subset {\\bf R}^d}")#text(" for ")#mi("{i=1,\\ldots,k}")#text(", where ")#mi("{k \\geq 0}")#text(" is a natural number and ")#mi("{c_1,\\ldots,c_k \\in {\\bf C}}")#text(" are complex numbers. An ")#emph[#text("unsigned simple function")]#text(" ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(", is defined similarly, but with the ")#mi("{c_i}")#text(" taking values in ")#mi("{[0,+\\infty]}")#text(" rather than ")#mi("{{\\bf C}}")#text(".")
]

#text("It is clear from construction that the space ")#mi("{\\text{Simp}({\\bf R}^d)}")#text(" of complex-valued simple functions forms a complex vector space; also, ")#mi("{\\text{Simp}({\\bf R}^d)}")#text(" also closed under pointwise product ")#mi("{f, g \\mapsto fg}")#text(" and complex conjugation ")#mi("{f \\mapsto \\overline{f}}")#text(". In short, ")#mi("{\\text{Simp}({\\bf R}^d)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("commutative ")#mi("{*}")#text("-algebra")]#text(". Meanwhile, the space ")#mi("{\\text{Simp}^+({\\bf R}^d)}")#text(" of unsigned simple functions is a ")#mi("{[0,+\\infty]}")#text("-module; it is closed under addition, and under scalar multiplication by elements in ")#mi("{[0,+\\infty]}")#text(".")

#text("In this definition, we did not require the ")#mi("{E_1,\\ldots,E_k}")#text(" to be disjoint. However, it is easy enough to arrange this, basically by exploiting Venn diagrams (or, to use fancier language, finite boolean algebras). Indeed, any ")#mi("{k}")#text(" subsets ")#mi("{E_1,\\ldots,E_k}")#text(" of ")#mi("{{\\bf R}^d}")#text(" partition ")#mi("{{\\bf R}^d}")#text(" into ")#mi("{2^k}")#text(" disjoint sets, each of which is an intersection of ")#mi("{E_i}")#text(" or the complement ")#mi("{{\\bf R}^d \\backslash E_i}")#text(" for ")#mi("{i=1,\\ldots,k}")#text(" (and in particular, is measurable). The (complex or unsigned) simple function is constant on each of these sets, and so can easily be decomposed as a linear combination of the indicator function of these sets. One easy consequence of this is that if ")#mi("{f}")#text(" is a complex-valued simple function, then its absolute value ")#tao-math("{\\left|f\\right|: x \\mapsto \\left|f(x)\\right|}", block: false)#text(" is an unsigned simple function.")

#text("It is geometrically intuitive that we should define the integral ")#mi("{\\int_{{\\bf R}^d} 1_E(x)\\ dx}")#text(" of an indicator function of a measurable set ")#mi("{E}")#text(" to equal ")#mi("{m(E)}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} 1_E(x)\\ dx = m(E).")]]

#text("Using this and applying the laws of integration formally, we are led to propose the following definition for the integral of an unsigned simple function:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Integral of a unsigned simple function)")]#text(" If ")#mi("{f = c_1 1_{E_1} + \\ldots + c_k 1_{E_k}}")#text(" is an unsigned simple function, the integral ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx := c_1 m(E_1) + \\ldots + c_k m(E_k),")]]

#text("thus ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" will take values in ")#mi("{[0,+\\infty]}")#text(".")
]

#text("However, one has to actually check that this definition is well-defined, in the sense that different representations")

#align(center)[#tao-fit-display[#mitex("f = c_1 1_{E_1} + \\ldots + c_k 1_{E_k} = c^{\\prime}_1 1_{E^{\\prime}_1} + \\ldots + c^{\\prime}_{k^{\\prime}} 1_{E^{\\prime}_{k^{\\prime}}}")]]

#text("of a function as a finite unsigned combination of indicator functions of measurable sets will give the same value for the integral ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(". This is the purpose of the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Well-definedness of simple integral)")]#text(" Let ")#mi("{k, k^{\\prime} \\geq 0}")#text(" be natural numbers, ")#mi("{c_1,\\ldots,c_k,c^{\\prime}_1,\\ldots,c^{\\prime}_{k^{\\prime}} \\in [0,+\\infty]}")#text(", and let ")#mi("{E_1,\\ldots,E_k,E^{\\prime}_1,\\ldots,E^{\\prime}_{k^{\\prime}} \\subset {\\bf R}^d}")#text(" be Lebesgue measurable sets such that the identity ")#metadata(none) <tao-a41fcdc6548615856f54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("c_1 1_{E_1} + \\ldots + c_k 1_{E_k} = c^{\\prime}_1 1_{E^{\\prime}_1} + \\ldots + c^{\\prime}_{k^{\\prime}} 1_{E^{\\prime}_{k^{\\prime}}}")]]



#text(" holds identically on ")#mi("{{\\bf R}^d}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("c_1 m(E_1) + \\ldots + c_k m(E_k) = c^{\\prime}_1 m(E^{\\prime}_1) + \\ldots + c^{\\prime}_{k^{\\prime}} m(E^{\\prime}_{k^{\\prime}}).")]]
]

#emph[#text("Proof:")]#text(" We again use a Venn diagram argument. The ")#mi("{k+k^{\\prime}}")#text(" sets ")#mi("{E_1,\\ldots,E_k,E^{\\prime}_1,\\ldots,E^{\\prime}_{k^{\\prime}}}")#text(" partition ")#mi("{{\\bf R}^d}")#text(" into ")#mi("{2^{k+k^{\\prime}}}")#text(" disjoint sets, each of which is an intersection of some of the ")#mi("{E_1,\\ldots,E_k,E^{\\prime}_1,\\ldots,E^{\\prime}_{k^{\\prime}}}")#text(" and their complements. We throw away any sets that are empty, leaving us with a partition of ")#mi("{{\\bf R}^d}")#text(" into ")#mi("{m}")#text(" non-empty disjoint sets ")#mi("{A_1,\\ldots,A_m}")#text(" for some ")#mi("{0 \\leq m \\leq 2^{k+k^{\\prime}}}")#text(". As the ")#mi("{E_1,\\ldots,E_k,E^{\\prime}_1,\\ldots,E^{\\prime}_k}")#text(" are Lebesgue measurable, the ")#mi("{A_1,\\ldots,A_m}")#text(" are too. By construction, each of the ")#mi("{E_1,\\ldots,E_k,E^{\\prime}_1,\\ldots,E_{k^{\\prime}}}")#text(" arise as unions of some of the ")#mi("{A_1,\\ldots,A_m}")#text(", thus we can write")

#align(center)[#tao-fit-display[#mitex("E_i = \\bigcup_{j \\in J_i} A_j")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("E^{\\prime}_{i^{\\prime}} = \\bigcup_{j^{\\prime} \\in J^{\\prime}_{i^{\\prime}}} A_{j^{\\prime}}")]]

#text("for all ")#mi("{i=1,\\ldots,k}")#text(" and ")#mi("{i^{\\prime}=1,\\ldots,k^{\\prime}}")#text(", and some subsets ")#mi("{J_i, J^{\\prime}_{i^{\\prime}} \\subset \\{1,\\ldots,m\\}}")#text(". By finite additivity of Lebesgue measure, we thus have")

#align(center)[#tao-fit-display[#mitex("m(E_i) = \\sum_{j \\in J_i} m(A_j)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("m(E^{\\prime}_{i^{\\prime}}) = \\sum_{j \\in J^{\\prime}_{i^{\\prime}}} m(A_{j})")]]

#text("Thus, our objective is now to show that ")#metadata(none) <tao-3a623e3b06844cf53e0b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\sum_{i=1}^k c_i \\sum_{j \\in J_i} m(A_j) = \\sum_{i^{\\prime}=1}^{k^{\\prime}} c^{\\prime}_{i^{\\prime}} \\sum_{j \\in J^{\\prime}_{i^{\\prime}}} m(A_{j}).")]]



#text(" To obtain this, we fix ")#mi("{1 \\leq j \\leq m}")#text(" and evaluate ")#link(<tao-a41fcdc6548615856f54>)[#text("(4)")]#text(" at a point ")#mi("{x}")#text(" in the non-empty set ")#mi("{A_j}")#text(". At such a point, ")#mi("{1_{E_i}(x)}")#text(" is equal to ")#mi("{1_{J_i}(j)}")#text(", and similarly ")#mi("{1_{E^{\\prime}_{i^{\\prime}}}}")#text(" is equal to ")#mi("{1_{J^{\\prime}_{i^{\\prime}}}(j)}")#text(". From ")#link(<tao-a41fcdc6548615856f54>)[#text("(4)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^k c_i 1_{J_i}(j) = \\sum_{i^{\\prime}=1}^{k^{\\prime}} c^{\\prime}_{i^{\\prime}} 1_{J^{\\prime}_{i^{\\prime}}}(j).")]]

#text("Multiplying this by ")#mi("{m(A_j)}")#text(" and then summing over all ")#mi("{j=1,\\ldots,m}")#text(" we obtain ")#link(<tao-3a623e3b06844cf53e0b>)[#text("(5)")]#text(". ")#mi("\\Box")

#text("We now make some important definitions that we will use repeatedly in the course:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4 (Almost everywhere and support)")]#text(" A property ")#mi("{P(x)}")#text(" of a point ")#mi("{x \\in {\\bf R}^d}")#text(" is said to hold ")#link("http://en.wikipedia.org/wiki/Almost_everywhere")[#text("(Lebesgue) almost everywhere")]#text(" in ")#mi("{{\\bf R}^d}")#text(", or ")#emph[#text("for (Lebesgue) almost every point")]#text(" ")#mi("{x \\in {\\bf R}^d}")#text(", if the set of ")#mi("{x \\in {\\bf R}^d}")#text(" for which ")#mi("{P(x)}")#text(" fails has Lebesgue measure zero (i.e. ")#mi("{P}")#text(" is true outside of a null set). We usually omit the prefix Lebesgue, and often abbreviate “almost everywhere” or “almost every” as a.e.")

#text("Two functions ")#mi("{f, g: {\\bf R}^d \\rightarrow Z}")#text(" into an arbitrary range ")#mi("{Z}")#text(" are said to ")#emph[#text("agree almost everywhere")]#text(" if one has ")#mi("{f(x)=g(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}^d}")#text(".")

#text("The ")#link("http://en.wikipedia.org/wiki/Support_(mathematics)")[#text("support")]#text(" of a function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" or ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is defined to be the set ")#mi("{\\{x \\in {\\bf R}^d: f(x) \\neq 0 \\}}")#text(" where ")#mi("{f}")#text(" is non-zero.")
]

#text("Note that if ")#mi("{P(x)}")#text(" holds for almost every ")#mi("{x}")#text(", and ")#mi("{P(x)}")#text(" implies ")#mi("{Q(x)}")#text(", then ")#mi("{Q(x)}")#text(" holds for almost every ")#mi("{x}")#text(". Also, if ")#mi("{P_1(x), P_2(x), \\ldots}")#text(" are an at most countable family of properties, each of which individually holds for almost every ")#mi("{x}")#text(", then they will ")#emph[#text("simultaneously")]#text(" be true for almost every ")#mi("{x}")#text(", because the countable union of null sets is still a null set. Because of these properties, one can (as a rule of thumb) treat the almost universal quantifier “for almost every” as if it was the truly universal quantifier “for every”, as long as one is only concatenating at most countably many properties together, and as long as one never specialises the free variable ")#mi("{x}")#text(" to a null set. Observe also that the property of agreeing almost everywhere is an equivalence relation, which we will refer to as ")#emph[#text("almost everywhere equivalence")]#text(".")

#text("In later notes we will also see the notion of the ")#emph[#text("closed support")]#text(" of a function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", defined as the closure of the support.")

#text("The following properties of the simple unsigned integral are easily obtained from the definitions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Basic properties of the simple unsigned integral)")]#text(" Let ")#mi("{f, g: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be simple unsigned functions.")

#enum(start: 1, 
[#text("(Unsigned linearity) We have")

#tao-aligned(keep: true)[


#tao-math("\\text{Simp} \\int_{{\\bf R}^d} f(x)+g(x)\\ dx  & = \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx", block: true)



#tao-math(" & + \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_{{\\bf R}^d} c f(x)\\ dx = c \\times \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx")]]

#text("for all ")#mi("{c \\in [0,+\\infty]}")#text(".")],
[#text("(Finiteness) We have ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx < \\infty}")#text(" if and only if ")#mi("{f}")#text(" is finite almost everywhere, and its support has finite measure.")],
[#text("(Vanishing) We have ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx = 0}")#text(" if and only if ")#mi("{f}")#text(" is zero almost everywhere.")],
[#text("(Equivalence) If ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree almost everywhere, then ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx = \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx}")#text(".")],
[#text("(Monotonicity) If ")#mi("{f(x) \\leq g(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}^d}")#text(", then ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx \\leq \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx}")#text(".")],
[#text("(Compatibility with Lebesgue measure) For any Lebesgue measurable ")#mi("{E}")#text(", one has ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} 1_E(x)\\ dx = m(E)}")#text(".")]
)

#text("Furthermore, show that the simple unsigned integral ")#mi("{f \\mapsto \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is the only map from the space ")#mi("{\\text{Simp}^+({\\bf R}^d)}")#text(" of unsigned simple functions to ")#mi("{[0,+\\infty]}")#text(" that obeys all of the above properties.")
]

#text("We can now define an absolutely convergent counterpart to the simple unsigned integral. This integral will be superceded by the absolutely Lebesgue integral, but we give it here as motivation for that more general notion of integration.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Absolutely convergent simple integral)")]#text(" A complex-valued simple function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Absolutely_integrable")[#text("absolutely integrable")]#text(" if ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} |f(x)|\\ dx < \\infty}")#text(". If ")#mi("{f}")#text(" is absolutely integrable, the integral ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is defined for real signed ")#mi("{f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx := \\text{Simp} \\int_{{\\bf R}^d} f_+(x)\\ dx - \\text{Simp} \\int_{{\\bf R}^d} f_-(x)\\ dx")]]

#text("where ")#mi("{f_+(x) := \\max(f(x),0)}")#text(" and ")#mi("{f_-(x) := \\max(-f(x),0)}")#text(" (note that these are unsigned simple functions that are pointwise dominated by ")#tao-math("{\\left|f\\right|}", block: false)#text(" and thus have finite integral), and for complex-valued ")#mi("{f}")#text(" by the formula")

#tao-aligned(keep: true)[


#tao-math("\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx  & := \\text{Simp} \\int_{{\\bf R}^d} \\text{Re} f(x)\\ dx", block: true)



#tao-math(" & + i \\text{Simp} \\int_{{\\bf R}^d} \\text{Im} f(x)\\ dx.", block: true)
]

#text("(Strictly speaking, this is an abuse of notation as we have now defined the simple integral ")#mi("{\\text{Simp} \\int_{{\\bf R}^d}}")#text(" three different times, for unsigned, real signed, and complex-valued simple functions, but one easily verifies that these three definitions agree with each other on their common domains of definition, so it is safe to use a single notation for all three.)")
]

#text("Note from the preceding exercise that a complex-valued simple function ")#mi("{f}")#text(" is absolutely integrable if and only if it has finite measure support (since finiteness almost everywhere is automatic). In particular, the space ")#mi("{\\text{Simp}^{abs}({\\bf R}^d)}")#text(" of absolutely integrable simple functions is closed under addition and scalar multiplication by complex numbers, and is thus a complex vector space.")

#text("The properties of the unsigned simple integral then can be used to deduce analogous properties for the complex-valued integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Basic properties of the complex-valued simple integral)")]#text(" Let ")#mi("{f, g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be absolutely integrable simple functions.")

#enum(start: 1, 
[#text("(*-linearity) We have")

#tao-aligned(keep: true)[


#tao-math("\\text{Simp} \\int_{{\\bf R}^d} f(x)+g(x)\\ dx  & = \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx", block: true)



#tao-math(" & + \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx", block: true)
]

#text("and ")#metadata(none) <tao-1a6a2ae780a4093ad54a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\text{Simp} \\int_{{\\bf R}^d} c f(x)\\ dx = c \\times \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx")]]



#text(" for all ")#mi("{c \\in {\\bf C}}")#text(". Also we have")

#align(center)[#tao-fit-display[#mitex("\\text{Simp} \\int_{{\\bf R}^d} \\overline{f}(x)\\ dx = \\overline{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}.")]]],
[#text("(Equivalence) If ")#mi("{f}")#text(" and ")#mi("{g}")#text(" agree almost everywhere, then ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx = \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx}")#text(".")],
[#text("(Compatibility with Lebesgue measure) For any Lebesgue measurable ")#mi("{E}")#text(", one has ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} 1_E(x)\\ dx = m(E)}")#text(".")]
)

#text("(")#emph[#text("Hints:")]#text(" Work out the real-valued counterpart of the linearity property first. To establish ")#link(<tao-1a6a2ae780a4093ad54a>)[#text("(6)")]#text(", treat the cases ")#mi("{c>0, c=0, c=-1}")#text(" separately. To deal with the additivity for real functions ")#mi("{f,g}")#text(", start with the identity")

#align(center)[#tao-fit-display[#mitex("f + g = (f+g)_+ - (f+g)_- = (f_+-f_-) + (g_+-g_-)")]]

#text("and rearrange the second inequality so that no subtraction appears.) Furthermore, show that the complex-valued simple integral ")#mi("{f \\mapsto \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is the only map from the space ")#mi("{\\text{Simp}^{abs}({\\bf R}^d)}")#text(" of absolutely integrable simple functions to ")#mi("{{\\bf C}}")#text(" that obeys all of the above properties.")
]

#text("We now comment further on the fact that (simple) functions that agree almost everywhere, have the same integral. We can view this as an assertion that integration is a ")#emph[#text("noise-tolerant")]#text(" operation: one can have “noise” or “errors” in a function ")#mi("{f(x)}")#text(" on a null set, and this will not affect the final value of the integral. Indeed, once one has this noise tolerance, one can even integrate functions ")#mi("{f}")#text(" that are not defined ")#emph[#text("everywhere")]#text(" on ")#mi("{{\\bf R}^d}")#text(", but merely defined ")#emph[#text("almost everywhere")]#text(" on ")#mi("{{\\bf R}^d}")#text(" (i.e. ")#mi("{f}")#text(" is defined on some set ")#mi("{{\\bf R}^d \\backslash N}")#text(" where ")#mi("{N}")#text(" is a null set), simply by extending ")#mi("{f}")#text(" to all of ")#mi("{{\\bf R}^d}")#text(" in some arbitrary fashion (e.g. by setting ")#mi("{f}")#text(" equal to zero on ")#mi("{N}")#text("). This is extremely convenient for analysis, as there are many natural functions (e.g. ")#mi("{\\frac{\\sin x}{x}}")#text(" in one dimension, or ")#tao-math("{\\frac{1}{\\left|x\\right|^\\alpha}}", block: false)#text(" for various ")#mi("{\\alpha > 0}")#text(" in higher dimensions) that are only defined almost everywhere instead of everywhere (often due to “division by zero” problems when a denominator vanishes). While such functions cannot be evaulated at certain singular points, they can still be integrated (provided they obey some integrability condition, of course, such as absolute integrability), and so one can still perform a large portion of analysis on such functions.")

#text("In fact, in the subfield of analysis known as ")#link("http://en.wikipedia.org/wiki/Functional_analysis")[#text("functional analysis")]#text(", it is convenient to abstract the notion of an almost everywhere defined function somewhat, by replacing any such function ")#mi("{f}")#text(" with the ")#emph[#text("equivalence class")]#text(" of almost everywhere defined functions that are equal to ")#mi("{f}")#text(" almost everywhere. Such classes are then no longer functions in the standard set-theoretic sense (they do not map each point in the domain to a unique point in the range, since points in ")#mi("{{\\bf R}^d}")#text(" have measure zero), but the properties of various function spaces improve when one does this (various semi-norms become norms, various topologies become Hausdorff, and so forth). See ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("these 245B lecture notes")]#text(" for further discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The “Lebesgue philosophy” that one is willing to lose control on sets of measure zero is a perspective that distinguishes Lebesgue-type analysis from other types of analysis, most notably that of ")#link("http://en.wikipedia.org/wiki/Descriptive_set_theory")[#text("descriptive set theory")]#text(", which is also interested in studying subsets of ")#mi("{{\\bf R}^d}")#text(", but can give completely different structural classifications to a pair of sets that agree almost everywhere. This loss of control on null sets is the price one has to pay for gaining access to the powerful tool of the Lebesgue integral; if one needs to control a function at absolutely ")#emph[#text("every")]#text(" point, and not just almost every point, then one often needs to use other tools than integration theory (unless one has some regularity on the function, such as continuity, that lets one pass from almost everywhere true statements to everywhere true statements).")
]

#heading(level: 1)[#strong[#text(" — 2. Measurable functions — ")]]

#text("Much as the piecewise constant integral can be completed to the Riemann integral, the unsigned simple integral can be completed to the unsigned Lebesgue integral, by extending the class of unsigned simple functions to the larger class of unsigned Lebesgue measurable functions. One of the shortest ways to define this class is as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Unsigned measurable function)")]#text(" An unsigned function ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is ")#emph[#text("unsigned Lebesgue measurable")]#text(", or ")#emph[#text("measurable")]#text(" for short, if it is the ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("pointwise limit")]#text(" of unsigned simple functions, i.e. if there exists a sequence ")#mi("{f_1, f_2, f_3, \\ldots: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" of unsigned simple functions such that ")#mi("{f_n(x) \\rightarrow f(x)}")#text(" for every ")#mi("{x \\in {\\bf R}^d}")#text(".")
]

#text("This particular definition is not always the most tractable. Fortunately, it has many equivalent forms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Equivalent notions of measurability)")]#text(" ")#metadata(none) <tao-3d528efc1f58b816302e>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be an unsigned function. Then the following are equivalent:")

#enum(start: 1, 
[#mi("{f}")#text(" is unsigned Lebesgue measurable.")],
[#mi("{f}")#text(" is the pointwise limit of unsigned simple functions ")#mi("{f_n}")#text(" (thus the limit ")#mi("{\\lim_{n \\rightarrow \\infty} f_n(x)}")#text(" exists and is equal to ")#mi("{f(x)}")#text(" for all ")#mi("{x \\in {\\bf R}^d}")#text(").")],
[#mi("{f}")#text(" is the pointwise almost everywhere limit of unsigned simple functions ")#mi("{f_n}")#text(" (thus the limit ")#mi("{\\lim_{n \\rightarrow \\infty} f_n(x)}")#text(" exists and is equal to ")#mi("{f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}^d}")#text(").")],
[#mi("{f}")#text(" is the supremum ")#mi("{f(x) = \\sup_n f_n(x)}")#text(" of an increasing sequence ")#mi("{0 \\leq f_1 \\leq f_2 \\leq \\ldots}")#text(" of unsigned simple functions ")#mi("{f_n}")#text(", each of which are bounded with finite measure support.")],
[#text("For every ")#mi("{\\lambda \\in [0,+\\infty]}")#text(", the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\}}")#text(" is Lebesgue measurable.")],
[#text("For every ")#mi("{\\lambda \\in [0,+\\infty]}")#text(", the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\}}")#text(" is Lebesgue measurable.")],
[#text("For every ")#mi("{\\lambda \\in [0,+\\infty]}")#text(", the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) < \\lambda \\}}")#text(" is Lebesgue measurable.")],
[#text("For every ")#mi("{\\lambda \\in [0,+\\infty]}")#text(", the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) \\leq \\lambda \\}}")#text(" is Lebesgue measurable.")],
[#text("For every interval ")#mi("{I \\subset [0,+\\infty)}")#text(", the set ")#mi("{f^{-1}(I) := \\{ x\\in {\\bf R}^d: f(x) \\in I \\}}")#text(" is Lebesgue measurable.")],
[#text("For every (relatively) open set ")#mi("{U \\subset [0,+\\infty)}")#text(", the set ")#mi("{f^{-1}(U) := \\{ x \\in {\\bf R}^d: f(x) \\in U \\}}")#text(" is Lebesgue measurable.")],
[#text("For every (relatively) closed set ")#mi("{K \\subset [0,+\\infty)}")#text(", the set ")#mi("{f^{-1}(K) := \\{ x \\in {\\bf R}^d: f(x) \\in K \\}}")#text(" is Lebesgue measurable.")]
)
]

#emph[#text("Proof:")]#text(" (1.) and (2.) are equivalent by definition. (2.) clearly implies (3.). As every monotone sequence in ")#mi("{[0,+\\infty]}")#text(" converges, (4.) implies (2.). Now we show that (3.) implies (5.). If ")#mi("{f}")#text(" is the pointwise almost everywhere limit of ")#mi("{f_n}")#text(", then for almost every ")#mi("{x \\in {\\bf R}^d}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("f(x) = \\lim_{n \\rightarrow \\infty} f_n(x) = \\limsup_{n \\rightarrow \\infty} f_n(x) = \\inf_{N>0} \\sup_{n\\geq N} f_n(x).")]]

#text("This implies that, for any ")#mi("{\\lambda}")#text(", the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\}}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{M>0} \\bigcap_{N>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}")]]

#text("outside of a set of measure zero; this set in turn is equal to")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{M>0} \\bigcap_{N>0} \\bigcup_{n \\ge N} \\{ x \\in {\\bf R}^d: f_n(x) > \\lambda + \\frac{1}{M} \\}")]]

#text("outside of a set of measure zero. But as each ")#mi("{f_n}")#text(" is an unsigned simple function, the sets ")#mi("{\\{ x \\in {\\bf R}^d: f_n(x) > \\lambda + \\frac{1}{M} \\}}")#text(" are Lebesgue measurable. Since countable unions or countable intersections of Lebesgue measurable sets are Lebesgue measurable, and modifying a Lebesgue measurable set on a null set produces another Lebesgue measurable set, we obtain (5.).")

#text("To obtain the equivalence of (5.) and (6.), observe that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\} = \\bigcap_{\\lambda^{\\prime} \\in {\\bf Q}^+: \\lambda^{\\prime} < \\lambda} \\{ x \\in {\\bf R}^d: f(x) > \\lambda^{\\prime} \\}")]]

#text("for ")#mi("{\\lambda \\in (0,+\\infty]}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\} = \\bigcup_{\\lambda^{\\prime} \\in {\\bf Q}^+: \\lambda^{\\prime} > \\lambda} \\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda^{\\prime} \\}")]]

#mi("{\\lambda \\in [0,+\\infty)}")#text(", where ")#mi("{{\\bf Q}^+ := {\\bf Q} \\cap [0,+\\infty]}")#text(" are the non-negative rationals. The claim then easily follows from the countable nature of ")#mi("{{\\bf Q}^+}")#text(" (treating the extreme cases ")#mi("{\\lambda = 0, +\\infty}")#text(" separately if necessary). A similar argument lets one deduce (5.) or (6.) from (9.).")

#text("The equivalence of (5.), (6.) with (7.), (8.) comes from the observation that ")#mi("{\\{ x \\in {\\bf R}^d: f(x) \\leq \\lambda \\}}")#text(" is the complement of ")#mi("{\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\}}")#text(", and ")#mi("{\\{ x \\in {\\bf R}^d: f(x) < \\lambda \\}}")#text(" is the complement of ")#mi("{\\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\}}")#text(". A similar argument shows that (10.) and (11.) are equivalent.")

#text("By expressing an interval as the intersection of two half-intervals, we see that (9.) follows from (5.)-(8.), and so all of (5.)-(9.) are now shown to be equivalent.")

#text("Clearly (10.) implies (7.), and hence (5.)-(9.). Conversely, because every open set in ")#mi("{[0,+\\infty)}")#text(" is the union of countably many open intervals in ")#mi("{[0,+\\infty)}")#text(", (9.) implies (10.).")

#text("The only remaining task is to show that (5.)-(11.) implies (4.). Let ")#mi("{f}")#text(" obey (5.)-(11.). For each positive integer ")#mi("{n}")#text(", we let ")#mi("{f_n(x)}")#text(" be defined to be the largest integer multiple of ")#mi("{2^{-n}}")#text(" that is less than or equal to ")#mi("{\\min(f(x),n)}")#text(" when ")#tao-math("{\\left|x\\right| \\leq n}", block: false)#text(", with ")#mi("{f_n(x) := 0}")#text(" for ")#tao-math("{\\left|x\\right| > n}", block: false)#text(". From construction it is easy to see that the ")#mi("{f_n: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" are increasing and have ")#mi("{f}")#text(" as their supremum. Furthermore, each ")#mi("{f_n}")#text(" takes on only finitely many values, and for each non-zero value ")#mi("{c}")#text(" it attains, the set ")#mi("{f_n^{-1}(c)}")#text(" takes the form ")#tao-math("{f^{-1}(I_c) \\cap \\{ x \\in {\\bf R}^d: \\left|x\\right| \\leq n \\}}", block: false)#text(" for some interval or ray ")#mi("{I_c}")#text(", and is thus measurable. As a consequence, ")#mi("{f_n}")#text(" is a simple function, and by construction it is bounded and has finite measure support. The claim follows. ")#mi("\\Box")

#text("With these equivalent formulations, we can now generate plenty of measurable functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]

#enum(start: 1, 
[#text("Show that every continuous function ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable.")],
[#text("Show that every unsigned simple function is measurable.")],
[#text("Show that the supremum, infimum, limit superior, or limit inferior of unsigned measurable functions is unsigned measurable.")],
[#text("Show that an unsigned function that is equal almost everywhere to an unsigned measurable function, is itself measurable.")],
[#text("Show that if a sequence ")#mi("{f_n}")#text(" of unsigned measurable functions converges pointwise almost everywhere to an unsigned limit ")#mi("{f}")#text(", then ")#mi("{f}")#text(" is also measurable.")],
[#text("If ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable and ")#mi("{\\phi: [0,+\\infty] \\rightarrow [0,+\\infty]}")#text(" is continuous, show that ")#mi("{\\phi \\circ f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable.")],
[#text("If ")#mi("{f, g}")#text(" are unsigned measurable functions, show that ")#mi("{f+g}")#text(" and ")#mi("{fg}")#text(" are measurable.")]
)
]

#text("In view of part (4.) of the above exercise, one can define the concept of measurability for an unsigned function that is only defined almost everywhere on ")#mi("{{\\bf R}^d}")#text(", rather than everywhere on ")#mi("{{\\bf R}^d}")#text(", by extending that function arbitrarily to the null set where it is currently undefined.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-b3b436e09116ce56ed88>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(". Show that ")#mi("{f}")#text(" is a ")#emph[#text("bounded")]#text(" unsigned measurable function if and only if ")#mi("{f}")#text(" is the ")#emph[#text("uniform")]#text(" limit of ")#emph[#text("bounded")]#text(" simple functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Show that an unsigned function ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is a simple function if and only if it is measurable and takes on at most finitely many values.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be an unsigned measurable function. Show that the region ")#mi("{\\{ (x,t) \\in {\\bf R}^d \\times {\\bf R}: 0 \\leq t \\leq f(x) \\}}")#text(" is a measurable subset of ")#mi("{{\\bf R}^{d+1}}")#text(". (There is a converse to this statement, but we will wait until later notes to prove it, once we have the Fubini-Tonelli theorem available to us.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Lemma ")#link(<tao-3d528efc1f58b816302e>)[#text("7")]#text(" tells us that if ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable, then ")#mi("{f^{-1}(E)}")#text(" is Lebesgue measurable for many classes of sets ")#mi("{E}")#text(". However, we caution that it is ")#emph[#text("not")]#text(" necessarily the case that ")#mi("{f^{-1}(E)}")#text(" is Lebesgue measurable if ")#mi("{E}")#text(" is Lebesgue measurable. To see this, we let ")#mi("{C}")#text(" be the Cantor set")

#align(center)[#tao-fit-display[#mitex("C := \\{ \\sum_{j=1}^\\infty a_j 3^{-j}: a_j \\in \\{0,2\\} \\text{ for all } j\\}")]]

#text("and let ")#mi("{f: {\\bf R} \\rightarrow [0,+\\infty]}")#text(" be the function defined by setting")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sum_{j=1}^\\infty 2 b_j 3^{-j}")]]

#text("whenever ")#mi("{x \\in [0,1]}")#text(" is not a terminating binary decimal, and so has a unique binary expansion ")#mi("{x = \\sum_{j=1}^\\infty b_j 2^{-j}}")#text(" for some ")#mi("{b_j \\in\\{0,1\\}}")#text(", and ")#mi("{f(x) := 0}")#text(" otherwise. We thus see that ")#mi("{f}")#text(" takes values in ")#mi("{C}")#text(", and is bijective on the set ")#mi("{A}")#text(" of non-terminating decimals in ")#mi("{[0,1]}")#text(". Using Lemma ")#link(<tao-3d528efc1f58b816302e>)[#text("7")]#text(", it is not difficult to show that ")#mi("{f}")#text(" is measurable. On the other hand, by modifying the construction from the previous notes, we can find a subset ")#mi("{F}")#text(" of ")#mi("{A}")#text(" which is non-measurable. If we set ")#mi("{E := f(F)}")#text(", then ")#mi("{E}")#text(" is a subset of the null set ")#mi("{C}")#text(" and is thus itself a null set; but ")#mi("{f^{-1}(E) = F}")#text(" is non-measurable, and so the inverse image of a Lebesgue measurable set by a measurable function need not remain Lebesgue measurable.")

#text("However, in later notes we will see that it is still true that ")#mi("{f^{-1}(E)}")#text(" is Lebesgue measurable if ")#mi("{E}")#text(" has a slightly stronger measurability property than Lebesgue measurability, namely ")#link("http://en.wikipedia.org/wiki/Borel_set")[#text("Borel measurability")]#text(".")
]

#text("Now we can define the concept of a complex-valued measurable function. As discussed earlier, it will be convenient to allow for such functions to only be defined ")#emph[#text("almost everywhere")]#text(", rather than ")#emph[#text("everywhere")]#text(", to allow for the possibility that the function becomes singular or otherwise undefined on a null set.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Complex measurability)")]#text(" An almost everywhere defined complex-valued function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is ")#emph[#text("Lebesgue measurable")]#text(", or ")#emph[#text("measurable")]#text(" for short, if it is the pointwise almost everywhere limit of complex-valued simple functions.")
]

#text("As before, there are several equivalent definitions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be an almost everywhere defined complex-valued function. Then the following are equivalent:")

#enum(start: 1, 
[#mi("{f}")#text(" is measurable.")],
[#mi("{f}")#text(" is the pointwise almost everywhere limit of complex-valued simple functions.")],
[#text("The (magnitudes of the) positive and negative parts of ")#mi("{\\text{Re}(f)}")#text(" and ")#mi("{\\text{Im}(f)}")#text(" are unsigned measurable functions.")],
[#mi("{f^{-1}(U)}")#text(" is Lebesgue measurable for every open set ")#mi("{U \\subset {\\bf C}}")#text(".")],
[#mi("{f^{-1}(K)}")#text(" is Lebesgue measurable for every closed set ")#mi("{K \\subset {\\bf C}}")#text(".")]
)
]

#text("From the above exercise, we see that the notion of complex-valued measurability and unsigned measurability are compatible when applied to a function that takes values in ")#mi("{[0,+\\infty) = [0,+\\infty] \\cap {\\bf C}}")#text(" everywhere (or almost everywhere).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]

#enum(start: 1, 
[#text("Show that every continuous function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable.")],
[#text("Show that a function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is simple if and only if it is measurable and takes on at most finitely many values.")],
[#text("Show that a complex-valued function that is equal almost everywhere to an measurable function, is itself measurable.")],
[#text("Show that if a sequence ")#mi("{f_n}")#text(" of complex-valued measurable functions converges pointwise almost everywhere to an complex-valued limit ")#mi("{f}")#text(", then ")#mi("{f}")#text(" is also measurable.")],
[#text("If ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable and ")#mi("{\\phi: {\\bf C} \\rightarrow {\\bf C}}")#text(" is continuous, show that ")#mi("{\\phi \\circ f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable.")],
[#text("If ")#mi("{f, g}")#text(" are measurable functions, show that ")#mi("{f+g}")#text(" and ")#mi("{fg}")#text(" are measurable.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Let ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" be a Riemann integrable function. Show that if one extends ")#mi("{f}")#text(" to all of ")#mi("{{\\bf R}}")#text(" by defining ")#mi("{f(x)=0}")#text(" for ")#mi("{x \\not \\in [a,b]}")#text(", then ")#mi("{f}")#text(" is measurable.")
]

#heading(level: 1)[#strong[#text(" — 3. Unsigned Lebesgue integrals — ")]]

#text("We are now ready to integrate unsigned measurable functions. We begin with the notion of the lower unsigned Lebesgue integral, which can be defined for arbitrary unsigned functions (not necessarily measurable):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Lower unsigned Lebesgue integral)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be an unsigned function (not necessarily measurable). We define the ")#emph[#text("lower unsigned Lebesgue integral")]#text(" ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(" to be the quantity")

#align(center)[#tao-fit-display[#mitex("\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx := \\sup_{0 \\leq g \\leq f; g \\text{ simple}} \\text{Simp} \\int_{{\\bf R}^d} g(x)\\ dx")]]

#text("where ")#mi("{g}")#text(" ranges over all unsigned simple functions ")#mi("{g: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" that are pointwise bounded by ")#mi("{f}")#text(".")

#text("One can also define the ")#emph[#text("upper unsigned Lebesgue integral")]

#align(center)[#tao-fit-display[#mitex("\\overline{\\int_{{\\bf R}^d}} f(x)\\ dx := \\inf_{h \\geq f; h \\text{ simple}} \\text{Simp} \\int_{{\\bf R}^d} h(x)\\ dx")]]

#text("but we will use this integral much more rarely. Note that both integrals take values in ")#mi("{[0,+\\infty]}")#text(", and that the upper Lebesgue integral is always at least as large as the lower Lebesgue integral.")
]

#text("In the definition of the lower unsigned Lebesgue integral, ")#mi("{g}")#text(" is required to be bounded by ")#mi("{f}")#text(" pointwise everywhere, but it is easy to see that one could also require ")#mi("{g}")#text(" to just be bounded by ")#mi("{f}")#text(" pointwise almost everywhere without affecting the value of the integral, since the simple integral is not affected by modifications on sets of measure zero.")

#text("The following properties of the lower Lebesgue integral are easy to establish:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Basic properties of the lower Lebesgue integral)")]#text(" Let ")#mi("{f, g: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be unsigned functions (not necessarily measurable).")

#enum(start: 1, 
[#text("(Compatibility with the simple integral) If ")#mi("{f}")#text(" is simple, then ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx = \\overline{\\int_{{\\bf R}^d}} f(x)\\ dx = \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(".")],
[#text("(Monotonicity) If ")#mi("{f \\leq g}")#text(" pointwise almost everywhere, then ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx \\leq \\underline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(" and ")#mi("{\\overline{\\int_{{\\bf R}^d}} f(x)\\ dx \\leq \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(".")],
[#text("(Homogeneity) If ")#mi("{c \\in [0,+\\infty)}")#text(", then ")#mi("{\\underline{\\int_{{\\bf R}^d}} cf(x)\\ dx = c \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(".")],
[#text("(Equivalence) If ")#mi("{f, g}")#text(" agree almost everywhere, then ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx = \\underline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(" and ")#mi("{\\overline{\\int_{{\\bf R}^d}} f(x)\\ dx = \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(".")],
[#text("(Superadditivity) ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\geq \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\underline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(".")],
[#text("(Subadditivity of upper integral) ")#mi("{\\overline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\leq \\overline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx}")],
[#text("(Divisibility) For any measurable set ")#mi("{E}")#text(", one has ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx = \\underline{\\int_{{\\bf R}^d}} f(x) 1_E(x)\\ dx + \\underline{\\int_{{\\bf R}^d}} f(x) 1_{{\\bf R}^d \\backslash E}(x)\\ dx}")#text(".")],
[#text("(Horizontal truncation) As ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\underline{\\int_{{\\bf R}^d}} \\min(f(x),n)\\ dx}")#text(" converges to ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(".")],
[#text("(Vertical truncation) As ")#mi("{n \\rightarrow \\infty}")#text(", ")#tao-math("{\\underline{\\int_{{\\bf R}^d}} f(x) 1_{\\left|x\\right| \\leq n}\\ dx}", block: false)#text(" converges to ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(". ")#emph[#text("Hint:")]#text(" From Exercise 11 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(", we have ")#tao-math("{m( E \\cap \\{ x: \\left|x\\right| \\leq n \\}) \\rightarrow m(E)}", block: false)#text(" for any measurable set ")#mi("{E}")#text(".")],
[#text("(Reflection) If ")#mi("{f+g}")#text(" is a simple function that is bounded with finite measure support (i.e. it is absolutely integrable), then ")#mi("{\\text{Simp} \\int_{{\\bf R}^d} f(x)+g(x)\\ dx = \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx}")#text(".")]
)

#text("Do the horizontal and vertical truncation properties hold if the lower Lebesgue integral is replaced with the upper Lebesgue integral?")
]

#text("Now we restrict attention to measurable functions.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Unsigned Lebesgue integral)")]#text(" If ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable, we define the unsigned Lebesgue integral ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" of ")#mi("{f}")#text(" to equal the lower unsigned Lebesgue integral ")#mi("{\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx}")#text(". (For non-measurable functions, we leave the unsigned Lebesgue integral undefined.)")
]

#text("One nice feature of measurable functions is that the lower and upper Lebesgue integrals can match, if one also assumes some boundedness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-d98aabb411f6f9cc49db>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable, bounded, and vanishing outside of a set of finite measure. Show that the lower and upper Lebesgue integrals of ")#mi("{f}")#text(" agree. (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-b3b436e09116ce56ed88>)[#text("4")]#text(".) There is a converse to this statement, but we will defer it to later notes. What happens if ")#mi("{f}")#text(" is allowed to be unbounded, or is not supported inside a set of finite measure?")
]

#text("This gives an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Finite additivity of the Lebesgue integral)")]#text(" Let ")#mi("{f, g: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable. Then ")#mi("{\\int_{{\\bf R}^d} f(x)+g(x)\\ dx = \\int_{{\\bf R}^d} f(x)\\ dx + \\int_{{\\bf R}^d} g(x)\\ dx}")#text(".")
]

#emph[#text("Proof:")]#text(" From the horizontal truncation property and a limiting argument, we may assume that ")#mi("{f, g}")#text(" are bounded. From the vertical truncation property and another limiting argument, we may assume that ")#mi("{f, g}")#text(" are supported inside a bounded set. From Exercise ")#link(<tao-d98aabb411f6f9cc49db>)[#text("11")]#text(", we now see that the lower and upper Lebesgue integrals of ")#mi("{f}")#text(", ")#mi("{g}")#text(", and ")#mi("{f+g}")#text(" agree. The claim now follows by combining the superadditivity of the lower Lebesgue integral with the subadditivity of the upper Lebesgue integral. ")#mi("\\Box")

#text("In later notes we will improve this finite additivity property for the unsigned Lebesgue integral further, to countable additivity; this property is also known as the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Upper Lebesgue integral and outer Lebesgue measure)")]#text(" Show that for any set ")#mi("{E \\subset {\\bf R}^d}")#text(", ")#mi("{\\overline{\\int_{{\\bf R}^d}} 1_E(x)\\ dx = m^*(E)}")#text(". Conclude that the upper and lower Lebesgue integrals are not necessarily additive if no measurability hypotheses are assumed.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Area interpretation of integral)")]#text(" If ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" is measurable, show that ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is equal to the ")#mi("{d+1}")#text("-dimensional Lebesgue measure of the region ")#mi("{\\{ (x,t) \\in {\\bf R}^d \\times {\\bf R}: 0 \\leq t \\leq f(x) \\}}")#text(". (This can be used as an alternate, and more geometrically intuitive, definition of the unsigned Lebesgue integral; it is a more convenient formulation for establishing the basic convergence theorems, but not quite as convenient for establishing basic properties such as additivity.) (")#emph[#text("Hint:")]#text(" use Exercise 22 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that the Lebesgue integral ")#mi("{f \\mapsto \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is the only map from measurable unsigned functions ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" to ")#mi("{[0,+\\infty]}")#text(" that obeys the following properties for measurable ")#mi("{f, g: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(":")

#list(
[#text("(Compatibility with the simple integral) If ")#mi("{f}")#text(" is simple, then ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx = \\text{Simp} \\int_{{\\bf R}^d} f(x)\\ dx}")#text(".")],
[#text("(Finite additivity) ")#mi("{\\int_{{\\bf R}^d} f(x)+g(x)\\ dx = \\int_{{\\bf R}^d} f(x)\\ dx + \\int_{{\\bf R}^d} g(x)\\ dx}")#text(".")],
[#text("(Horizontal truncation) As ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{\\int_{{\\bf R}^d} \\min(f(x),n)\\ dx}")#text(" converges to ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(".")],
[#text("(Vertical truncation) As ")#mi("{n \\rightarrow \\infty}")#text(", ")#tao-math("{\\int_{{\\bf R}^d} f(x) 1_{\\left|x\\right| \\leq n}\\ dx}", block: false)#text(" converges to ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Translation invariance)")]#text(" ")#metadata(none) <tao-cbd31fe312a05a4718b4>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable. Show that ")#mi("{\\int_{{\\bf R}^d} f(x+y)\\ dx = \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" for any ")#mi("{y \\in {\\bf R}^d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Linear change of variables)")]#text(" ")#metadata(none) <tao-2f48b881ea7073f1c6f0>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable, and let ")#mi("{T: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be an invertible linear transformation. Show that ")#tao-math("{\\int_{{\\bf R}^d} f(T^{-1}(x))\\ dx = \\left|\\det T\\right| \\int_{{\\bf R}^d} f(x)\\ dx}", block: false)#text(", or equivalently ")#tao-math("{\\int_{{\\bf R}^d} f(T x)\\ dx = \\frac{1}{\\left|\\det T\\right|} \\int_{{\\bf R}^d} f(x)\\ dx}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Compatibility with the Riemann integral)")]#text(" ")#metadata(none) <tao-2b33a9570d42f8af1c84>#text(" Let ")#mi("{f: [a,b] \\rightarrow [0,+\\infty]}")#text(" be Riemann integrable. If we extend ")#mi("{f}")#text(" to ")#mi("{{\\bf R}}")#text(" by declaring ")#mi("{f}")#text(" to equal zero outside of ")#mi("{[a,b]}")#text(", show that ")#mi("{\\int_{\\bf R} f(x)\\ dx = \\int_a^b f(x)\\ dx}")#text(".")
]

#text("We record a basic inequality, known as ")#link("http://en.wikipedia.org/wiki/Markov's_inequality")[#text("Markov’s inequality")]#text(", that asserts that the Lebesgue integral of an unsigned measurable function controls how often that function can be large:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Markov’s inequality)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable. Then for any ")#mi("{0 < \\lambda < \\infty}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_{{\\bf R}^d} f(x)\\ dx.")]]
]

#emph[#text("Proof:")]#text(" We have the trivial pointwise inequality")

#align(center)[#tao-fit-display[#mitex("\\lambda 1_{\\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\}} \\leq f(x).")]]

#text("From the definition of the lower Lebesgue integral, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\lambda m( \\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\} ) \\leq \\int_{{\\bf R}^d} f(x)\\ dx")]]

#text("and the claim follows. ")#mi("\\Box")

#text("By sending ")#mi("{\\lambda}")#text(" to infinity or to zero, we obtain the following important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-a33ff8eef24006b1c225>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(" be measurable.")

#list(
[#text("Show that if ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx < \\infty}")#text(", then ")#mi("{f}")#text(" is finite almost everywhere. Give a counterexample to show that the converse statement is false.")],
[#text("Show that ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx = 0}")#text(" if and only if ")#mi("{f}")#text(" is zero almost everywhere.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The use of the integral ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" to control the distribution of ")#mi("{f}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Second_moment_method#First_moment_method")[#text("first moment method")]#text(". One can also control this distribution using higher moments such as ")#tao-math("{\\int_{{\\bf R}^d} \\left|f(x)\\right|^p\\ dx}", block: false)#text(" for various values of ")#mi("{p}")#text(", or exponential moments such as ")#mi("{\\int_{{\\bf R}^d} e^{tf(x)}\\ dx}")#text(" or the Fourier moments ")#mi("{\\int_{{\\bf R}^d} e^{itf(x)}\\ dx}")#text(" for various values of ")#mi("{t}")#text("; such moment methods are fundamental to probability theory.")
]

#heading(level: 1)[#strong[#text(" — 4. Absolute integrability — ")]]

#text("Having set out the theory of the unsigned Lebesgue integral, we can now define the absolutely convergent Lebesgue integral.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 13 (Absolute integrability)")]#text(" An almost everywhere defined measurable function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is said to be ")#emph[#text("absolutely integrable")]#text(" if the unsigned integral")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^1({\\bf R}^d)} := \\int_{{\\bf R}^d} |f(x)|\\ dx", block: true)]]

#text("is finite. We refer to this quantity ")#tao-math("{\\left\\|f\\right\\|_{L^1({\\bf R}^d)}}", block: false)#text(" as the ")#emph[#mi("{L^1({\\bf R}^d)}")#text(" norm")]#text(" of ")#mi("{f}")#text(", and use ")#mi("{L^1({\\bf R}^d)}")#text(" or ")#mi("{L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(" to denote the space of absolutely integrable functions. If ")#mi("{f}")#text(" is real-valued and absolutely integrable, we define the Lebesgue integral ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" by the formula ")#metadata(none) <tao-5bedc4713bc2338afcf1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\int_{{\\bf R}^d} f(x)\\ dx := \\int_{{\\bf R}^d} f_+(x)\\ dx - \\int_{{\\bf R}^d} f_-(x)\\ dx")]]



#text(" where ")#mi("{f_+ := \\max(f,0)}")#text(", ")#mi("{f_- := \\max(-f,0)}")#text(" are the magnitudes of the positive and negative components of ")#mi("{f}")#text(" (note that the two unsigned integrals on the right-hand side are finite, as ")#mi("{f_+, f_-}")#text(" are pointwise dominated by ")#tao-math("{\\left|f\\right|}", block: false)#text("). If ")#mi("{f}")#text(" is complex-valued and absolutely integrable, we define the Lebesgue integral ")#mi("{\\int_{{\\bf R}^d} f(x)\\ dx}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x)\\ dx := \\int_{{\\bf R}^d} \\text{Re} f(x)\\ dx + i \\int_{{\\bf R}^d} \\text{Im} f(x)\\ dx")]]

#text("where the two integrals on the right are interpreted as real-valued absolutely integrable Lebesgue integrals. It is easy to see that the unsigned, real-valued, and complex-valued Lebesgue integrals defined in this manner are compatible on their common domains of definition.")
]

#text("Note from construction that the absolutely integrable Lebesgue integral extends the absolutely integrable simple integral, which is now redundant and will not be needed any further in the sequel.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can attempt to define integrals for non-absolutely-integrable functions, analogous to the improper integrals ")#mi("{\\int_0^\\infty f(x)\\ dx := \\lim_{R \\rightarrow \\infty} \\int_0^R f(x)\\ dx}")#text(" or the principal value integrals ")#mi("{p.v. \\int_{-\\infty}^\\infty f(x)\\ dx := \\lim_{R \\rightarrow \\infty} \\int_{-R}^R f(x)\\ dx}")#text(" one sees in the classical one-dimensional Riemannian theory. While one can certainly generate any number of such extensions of the Lebesgue integral concept, such extensions tend to be poorly behaved with respect to various important operations, such as change of variables or exchanging limits and integrals, so it is usually not worthwhile to try to set up a systematic theory for such non-absolutely-integrable integrals that is anywhere near as complete as the absolutely integrable theory, and instead deal with such exotic integrals on an ")#emph[#text("ad hoc")]#text(" basis.")
]

#text("From the pointwise triangle inequality ")#tao-math("{\\left|f(x)+g(x)\\right| \\leq \\left|f(x)\\right|+\\left|g(x)\\right|}", block: false)#text(", we conclude the ")#mi("{L^1}")#text(" triangle inequality ")#metadata(none) <tao-cddd67830982a78cc839>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|f+g\\right\\|_{L^1({\\bf R}^d)} \\leq \\left\\|f\\right\\|_{L^1({\\bf R}^d)} + \\left\\|g\\right\\|_{L^1({\\bf R}^d)}", block: true)]]



#text(" for any almost everywhere defined measurable ")#mi("{f, g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(". It is also easy to see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|c f\\right\\|_{L^1({\\bf R}^d)} = \\left|c\\right| \\left\\|f\\right\\|_{L^1({\\bf R}^d)}", block: true)]]

#text("for any complex number ")#mi("{c}")#text(". As such, we see that ")#mi("{L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(" is a complex vector space. (The ")#mi("{L^1}")#text(" norm is then a seminorm on this space, but we will not need to discuss norms and seminorms in detail until ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("245B")]#text(".) From Exercise ")#link(<tao-a33ff8eef24006b1c225>)[#text("18")]#text(" we make the important observation that a function ")#mi("{f \\in L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(" has zero ")#mi("{L^1}")#text(" norm, ")#tao-math("{\\left\\|f\\right\\|_{L^1({\\bf R}^d)}=0}", block: false)#text(", if and only if ")#mi("{f}")#text(" is zero almost everywhere.")

#text("Given two functions ")#mi("{f, g \\in L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(", we can define the ")#emph[#mi("{L^1}")#text(" distance")]#text(" ")#mi("{d_{L^1}(f,g)}")#text(" between them by the formula")

#align(center)[#tao-fit-display[#tao-math("d_{L^1}(f,g) := \\left\\|f-g\\right\\|_{L^1({\\bf R}^d)}.", block: true)]]

#text("Thanks to ")#link(<tao-cddd67830982a78cc839>)[#text("(8)")]#text(", this distance obeys almost all the axioms of a ")#link("http://en.wikipedia.org/wiki/Metric_(mathematics)")[#text("metric")]#text(" on ")#mi("{L^1({\\bf R}^d)}")#text(", with one exception: it is possible for two different functions ")#mi("{f, g \\in L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(" to have a zero ")#mi("{L^1}")#text(" distance, if they agree almost everywhere. As such, ")#mi("{d_{L^1}}")#text(" is only a semi-metric (also known as a ")#link("http://en.wikipedia.org/wiki/Pseudometric_space")[#text("pseudo-metric")]#text(") rather than a metric. However, if one adopts the convention that any two functions that agree almost everywhere are considered equivalent (or more formally, one works in the quotient space of ")#mi("{L^1({\\bf R}^d)}")#text(" by the equivalence relation of almost everywhere agreement, which by abuse of notation is also denoted ")#mi("{L^1({\\bf R}^d)}")#text("), then one recovers a genuine metric. (Later on, we will establish the important fact that this metric makes the (quotient space) ")#mi("{L^1({\\bf R}^d)}")#text(" a complete metric space, a fact known as the ")#link("http://en.wikipedia.org/wiki/Riesz%E2%80%93Fischer_theorem")[#mi("{L^1}")#text(" Riesz-Fischer theorem")]#text("; this completeness is one of the main reasons we spend so much effort setting up Lebesgue integration theory in the first place.)")

#text("The linearity properties of the unsigned integral induce analogous linearity properties of the absolutely convergent Lebesgue integral:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Integration is linear)")]#text(" Show that integration ")#mi("{f \\mapsto \\int_{{\\bf R}^d} f(x)\\ dx}")#text(" is a (complex) linear operation from ")#mi("{L^1({\\bf R}^d)}")#text(" to ")#mi("{{\\bf C}}")#text(". In other words, show that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} f(x) + g(x)\\ dx = \\int_{{\\bf R}^d} f(x)\\ dx + \\int_{{\\bf R}^d} g(x)\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} cf(x)\\ dx = c\\int_{{\\bf R}^d} f(x)\\ dx")]]

#text("for all absolutely integrable ")#mi("{f, g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" and complex numbers ")#mi("{c}")#text(". Also establish the identity")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} \\overline{f(x)}\\ dx = \\overline{\\int_{{\\bf R}^d} f(x)\\ dx},")]]

#text("which makes integration not just a linear operation, but a ")#link("http://en.wikipedia.org/wiki/*-algebra")[#text("*-linear")]#text(" operation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Show that Exercises ")#link(<tao-cbd31fe312a05a4718b4>)[#text("15")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("16")]#text(", and ")#link(<tao-2b33a9570d42f8af1c84>)[#text("17")]#text(" also hold for complex-valued, absolutely integrable functions rather than for unsigned measurable functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Absolute summability is a special case of absolute integrability)")]#text(" Let ")#mi("{(c_n)_{n \\in {\\bf Z}}}")#text(" be a doubly infinite sequence of complex numbers, and let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("f(x) := \\sum_{n \\in {\\bf Z}} c_n 1_{[n,n+1)}(x) = c_{\\lfloor x \\rfloor}")]]

#text("where ")#mi("{\\lfloor x \\rfloor}")#text(" is the greatest integer less than ")#mi("{x}")#text(". Show that ")#mi("{f}")#text(" is absolutely integrable if and only if the series ")#mi("{\\sum_{n \\in {\\bf Z}} c_n}")#text(" is absolutely convergent, in which case one has ")#mi("{\\int_{\\bf R} f(x)\\ dx = \\sum_{n \\in {\\bf Z}} c_n}")#text(".")
]

#text("We can localise the absolutely convergent integral to any measurable subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text(". Indeed, if ")#mi("{f: E \\rightarrow {\\bf C}}")#text(" is a function, we say that ")#mi("{f}")#text(" is measurable (resp. absolutely integrable) if its extension ")#mi("{\\tilde f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable (resp. absolutely integrable), where ")#mi("{\\tilde f(x)}")#text(" is defined to equal ")#mi("{f(x)}")#text(" when ")#mi("{x \\in E}")#text(" and zero otherwise, and then we define ")#mi("{\\int_E f(x)\\ dx := \\int_{{\\bf R}^d} \\tilde f(x)\\ dx}")#text(". Thus, for instance, the absolutely integrable analogue of Exercise ")#link(<tao-2b33a9570d42f8af1c84>)[#text("17")]#text(" tells us that")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(x)\\ dx = \\int_{[a,b]} f(x)\\ dx")]]

#text("for any Riemann-integrable ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" If ")#mi("{E, F}")#text(" are disjoint measurable subsets of ")#mi("{{\\bf R}^d}")#text(", and ")#mi("{f: E \\cup F \\rightarrow {\\bf C}}")#text(" is absolutely integrable, show that")

#align(center)[#tao-fit-display[#mitex("\\int_E f(x)\\ dx = \\int_{E \\cup F} f(x) 1_E(x)\\ dx")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_E f(x)\\ dx + \\int_F f(x)\\ dx = \\int_{E \\cup F} f(x)\\ dx.")]]
]

#text("We will study the properties of the absolutely convergent Lebesgue integral in more detail in later notes, as a special case of the more general Lebesgue integration theory on abstract measure spaces. For now, we record one very basic inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Triangle inequality)")]#text(" Let ")#mi("{f \\in L^1({\\bf R}^d \\rightarrow {\\bf C})}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} f(x)\\ dx\\right| \\leq \\int_{{\\bf R}^d} |f(x)|\\ dx.", block: true)]]
]

#emph[#text("Proof:")]#text(" If ")#mi("{f}")#text(" is real-valued, then ")#tao-math("{\\left|f\\right| = f_+ + f_-}", block: false)#text(" and the claim is obvious from ")#link(<tao-5bedc4713bc2338afcf1>)[#text("(7)")]#text(". When ")#mi("{f}")#text(" is complex-valued, one cannot argue quite so simply; a naive mimicking of the real-valued argument would lose a factor of ")#mi("{2}")#text(", giving the inferior bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} f(x)\\ dx\\right| \\leq 2\\int_{{\\bf R}^d} |f(x)|\\ dx.", block: true)]]

#text("To do better, we exploit the phase rotation invariance properties of the absolute value operation and of the integral, as follows. Note that for any complex number ")#mi("{z}")#text(", one can write ")#tao-math("{\\left|z\\right|}", block: false)#text(" as ")#mi("{z e^{i\\theta}}")#text(" for some real ")#mi("{\\theta}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} f(x)\\ dx\\right| = e^{i\\theta} \\int_{{\\bf R}^d} f(x)\\ dx = \\int_{{\\bf R}^d} e^{i\\theta} f(x)\\ dx", block: true)]]

#text("for some real ")#mi("{\\theta}")#text(". Taking real parts of both sides, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} f(x)\\ dx\\right| = \\int_{{\\bf R}^d} \\text{Re}( e^{i\\theta} f(x) )\\ dx.", block: true)]]

#text("Since ")#tao-math("{\\text{Re}(e^{i\\theta} f(x)) \\leq \\left|e^{i\\theta} f(x)\\right| = \\left|f(x)\\right|}", block: false)#text(", we obtain the claim. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 5. Littlewood’s three principles — ")]]

#link("http://en.wikipedia.org/wiki/Littlewood's_three_principles_of_real_analysis")[#text("Littlewood’s three principles")]#text(" are informal heuristics that convey much of the basic intuition behind the measure theory of Lebesgue. Briefly, the three principles are as follows:")

#enum(start: 1, 
[#text("Every (measurable) set is nearly a finite sum of intervals;")],
[#text("Every (absolutely integrable) function is nearly continuous; and")],
[#text("Every (pointwise) convergent sequence of functions is nearly uniformly convergent.")]
)

#text("Various manifestations of the first principle were given in the ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("previous set of notes")]#text(" (and specifically, in Exercises 7 and 14 of those notes). We now discuss the second principle. Define a ")#link("http://en.wikipedia.org/wiki/Step_function")[#text("step function")]#text(" to be a finite linear combination of indicator functions of boxes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Approximation of ")#mi("{L^1}")#text(" functions)")]#text(" ")#metadata(none) <tao-e73f1787966888b9221e>#text(" Let ")#mi("{f \\in L^1({\\bf R}^d)}")#text(" and ")#mi("{\\epsilon > 0}")#text(".")

#enum(start: 1, 
[#text("There exists an absolutely integrable simple function ")#mi("{g}")#text(" such that ")#tao-math("{\\left\\|f-g\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon}", block: false)#text(".")],
[#text("There exists a step function ")#mi("{g}")#text(" such that ")#tao-math("{\\left\\|f-g\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon}", block: false)#text(".")],
[#text("There exists a continuous, compactly supported ")#mi("{g}")#text(" such that ")#tao-math("{\\left\\|f-g\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon}", block: false)#text(".")]
)
]

#text("To put things another way, the absolutely integrable simple functions, the step functions, and the continuous, compactly supported functions are all dense subsets of ")#mi("{L^1({\\bf R}^d)}")#text(" with respect to the ")#mi("{L^1({\\bf R}^d)}")#text(" (semi-)metric. Much later in the course (")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("in 245C")]#text("), we will see that a similar statement holds if one replaces continuous, compactly supported functions with ")#emph[#text("smooth")]#text(", compactly supported functions, also known as ")#link("http://en.wikipedia.org/wiki/Test_function#Test_functions_and_distributions")[#text("test functions")]#text("; this is an important fact for the theory of ")#emph[#text("distributions")]#text(".")

#emph[#text("Proof:")]#text(" We begin with part (1.). When ")#mi("{f}")#text(" is unsigned, we see from the definition of the lower Lebesgue integral that there exists an unsigned simple function ")#mi("{g}")#text(" such that ")#mi("{g \\leq f}")#text(" (so, in particular, ")#mi("{g}")#text(" is absolutely integrable) and")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} g(x)\\ dx \\geq \\int_{{\\bf R}^d} f(x)\\ dx - \\epsilon,")]]

#text("which by linearity implies that ")#tao-math("{\\left\\|f-g\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon}", block: false)#text(". This gives (1.) when ")#mi("{f}")#text(" is unsigned. The case when ")#mi("{f}")#text(" is real-valued then follows by splitting ")#mi("{f}")#text(" into positive and negative parts (and adjusting ")#mi("{\\epsilon}")#text(" as necessary), and the case when ")#mi("{f}")#text(" is complex-valued then follows by splitting ")#mi("{f}")#text(" into real and imaginary parts (and adjusting ")#mi("{\\epsilon}")#text(" yet again).")

#text("To establish part (2.), we see from (1.) and the triangle inequality in ")#mi("{L^1}")#text(" that it suffices to show this when ")#mi("{f}")#text(" is an absolutely integrable simple function. By linearity (and more applications of the triangle inequality), it then suffices to show this when ")#mi("{f=1_E}")#text(" is the indicator function of a measurable set ")#mi("{E \\subset {\\bf R}^d}")#text(" of finite measure. But then, by Exercise 14 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(", such a set can be approximated (up to an error of measure at most ")#mi("{\\epsilon}")#text(") by an elementary set, and the claim follows.")

#text("To establish part (3.), we see from (2.) and the argument from the preceding paragraph that it suffices to show this when ")#mi("{f = 1_E}")#text(" is the indicator function of a box. But one can then establish the claim by direct construction. Indeed, if one makes a slightly larger box ")#mi("{F}")#text(" that contains the closure of ")#mi("{E}")#text(" in its interior, but has a volume at most ")#mi("{\\epsilon}")#text(" more than that of ")#mi("{E}")#text(", then one can directly construct a piecewise linear continuous function ")#mi("{g}")#text(" supported on ")#mi("{F}")#text(" that equals ")#mi("{1}")#text(" on ")#mi("{E}")#text(" (e.g. one can set ")#mi("{g(x) = \\max(1 - R \\text{dist}(x,E),0)}")#text(" for some sufficiently large ")#mi("{R}")#text("; one may also invoke ")#link("http://en.wikipedia.org/wiki/Urysohn's_lemma")[#text("Urysohn’s lemma")]#text(", which we wil cover ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("in 245B")]#text("). It is then clear from construction that ")#tao-math("{\\left\\|f-g\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon}", block: false)#text(" as required. ")#mi("\\Box")

#text("This is not the only way to make Littlewood’s second principle manifest; we return to this point shortly. For now, we turn to Littlewood’s third principle. We recall three basic ways in which a sequence ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" of functions can converge to a limit ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(":")

#list(
[#text("(Pointwise convergence) ")#mi("{f_n(x) \\rightarrow f(x)}")#text(" for every ")#mi("{x \\in {\\bf R}^d}")#text(".")],
[#text("(Pointwise almost everywhere convergence) ")#mi("{f_n(x) \\rightarrow f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}^d}")#text(".")],
[#text("(Uniform convergence) For every ")#mi("{\\epsilon > 0}")#text(", there exists ")#mi("{N}")#text(" such that ")#tao-math("{\\left|f_n(x)-f(x)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{n \\geq N}")#text(" and all ")#mi("{x \\in {\\bf R}^d}")#text(".")]
)

#text("Uniform convergence implies pointwise convergence, which in turn implies pointwise almost everywhere convergence.")

#text("We now add a fourth mode of convergence, that is weaker than uniform convergence but stronger than pointwise convergence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 16 (Locally uniform convergence)")]#text(" ")#metadata(none) <tao-b0c5b7d99c9349a573fd>#text(" A sequence of functions ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" converges ")#emph[#text("locally uniformly")]#text(" to a limit ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" if, for every bounded subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^d}")#text(", ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" on ")#mi("{E}")#text(". In other words, for every bounded ")#mi("{E \\subset {\\bf R}^d}")#text(" and every ")#mi("{\\epsilon > 0}")#text(", there exists ")#mi("{N > 0}")#text(" such that ")#tao-math("{\\left|f_n(x) - f(x)\\right| \\leq \\epsilon}", block: false)#text(" for all ")#mi("{n \\geq N}")#text(" and ")#mi("{x \\in E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" At least as far as ")#mi("{{\\bf R}^d}")#text(" is concerned, an equivalent definition of local uniform convergence is: ")#mi("{f_n}")#text(" converges locally uniformly to ")#mi("{f}")#text(" if, for every point ")#mi("{x_0 \\in {\\bf R}^d}")#text(", there exists an open neighbourhood ")#mi("{U}")#text(" of ")#mi("{x_0}")#text(" such that ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" on ")#mi("{U}")#text(". The equivalence of the two definitions is immediate from the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(". More generally, the adverb “locally” in mathematics is usually used in this fashion; a propery ")#mi("{P}")#text(" is said to hold ")#emph[#text("locally")]#text(" on some domain ")#mi("{X}")#text(" if, for every point ")#mi("{x_0}")#text(" in that domain, there is an open neighbourhood of ")#mi("{x_0}")#text(" in ")#mi("{X}")#text(" on which ")#mi("{P}")#text(" holds.")

#text("One should caution, though, that on domains on which the Heine-Borel theorem does not hold, the bounded-set notion of local uniform convergence is not equivalent to the open-set notion of local uniform convergence (though, for ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("locally compact spaces")]#text(", one can recover equivalence if one replaces “bounded” by “compact”).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" The functions ")#mi("{x \\mapsto x/n}")#text(" on ")#mi("{{\\bf R}}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" converge locally uniformly (and hence pointwise) to zero on ")#mi("{{\\bf R}}")#text(", but do not converge uniformly.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" The partial sums ")#mi("{\\sum_{n=0}^N \\frac{x^n}{n!}}")#text(" of the Taylor series ")#mi("{e^x = \\sum_{n=0}^\\infty \\frac{x^n}{n!}}")#text(" converges to ")#mi("{e^x}")#text(" locally uniformly (and hence pointwise) on ")#mi("{{\\bf R}}")#text(", but not uniformly.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-55ea4297a9fef0c87427>#text(" The functions ")#mi("{f_n(x) := \\frac{1}{nx} 1_{x>0}}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" (with the convention that ")#mi("{f_n(0)=0}")#text(") converge pointwise everywhere to zero, but do not converge locally uniformly.")
]

#text("From the preceding example, we see that pointwise convergence (either everywhere or almost everywhere) is a weaker concept than local uniform convergence. Nevertheless, a remarkable ")#link("http://en.wikipedia.org/wiki/Egorov's_theorem")[#text("theorem of Egorov")]#text(", which demonstrates Littlewood’s third principle, asserts that one can recover local uniform convergence as long as one is willing to delete a set of small measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Egorov’s theorem)")]#text(" Let ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a sequence of measurable functions that converge pointwise almost everywhere to another function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a Lebesgue measurable set ")#mi("{A}")#text(" of measure at most ")#mi("{\\epsilon}")#text(", such that ")#mi("{f_n}")#text(" converges locally uniformly to ")#mi("{f}")#text(" outside of ")#mi("{A}")#text(".")
]

#text("Note that Example ")#link(<tao-55ea4297a9fef0c87427>)[#text("3")]#text(" demonstrates that the exceptional set ")#mi("{A}")#text(" in Egorov’s theorem cannot be taken to have zero measure, at least if one uses the bounded-set definition of local uniform convergence from Definition ")#link(<tao-b0c5b7d99c9349a573fd>)[#text("16")]#text(". (If one instead takes the “open neighbourhood” definition, then the sequence in Example ")#link(<tao-55ea4297a9fef0c87427>)[#text("3")]#text(" does converge locally uniformly on ")#mi("{{\\bf R} \\backslash \\{0\\}}")#text(" in the open neighbourhood sense, even if it does not do so in the bounded-set sense. On a domain such as ")#mi("{{\\bf R}^d \\backslash A}")#text(", bounded-set locally uniform convergence implies open-neighbourhood locally uniform convergence, but not conversely, so for the purposes of applying Egorov’s theorem, the distinction is not too important since one has local uniform convergence in both senses.)")

#emph[#text("Proof:")]#text(" By modifying ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" on a set of measure zero (that can be absorbed into ")#mi("{A}")#text(" at the end of the argument) we may assume that ")#mi("{f_n}")#text(" converges pointwise everywhere to ")#mi("{f}")#text(", thus for every ")#mi("{x \\in {\\bf R}^d}")#text(" and ")#mi("{m > 0}")#text(" there exists ")#mi("{N \\geq 0}")#text(" such that ")#tao-math("{\\left|f_n(x)-f(x)\\right| \\leq 1/m}", block: false)#text(" for all ")#mi("{n \\geq N}")#text(". We can rewrite this fact set-theoretically as")

#align(center)[#tao-fit-display[#mitex("\\bigcap_{N=0}^\\infty E_{N,m} = \\emptyset")]]

#text("for each ")#mi("{m}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("E_{N,m} := \\{ x \\in {\\bf R}^d: \\left|f_n(x)-f(x)\\right| > 1/m \\text{ for some } n \\geq N \\}.", block: true)]]

#text("It is clear that the ")#mi("{E_{N,m}}")#text(" are Lebesgue measurable, and are decreasing in ")#mi("{N}")#text(". Applying downward monotone convergence (Exercise 9 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") we conclude that, for any radius ")#mi("{R>0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} m( E_{N,m} \\cap B(0,R) ) = 0.")]]

#text("(The restriction to the ball ")#mi("{B(0,R)}")#text(" is necessary, because the downward monotone convergence property only works when the sets involved have finite measure.) In particular, for any ")#mi("{m \\geq 1}")#text(", we can find ")#mi("{N_m}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("m( E_{N,m} \\cap B(0,m) ) \\leq \\frac{\\epsilon}{2^m}")]]

#text("for all ")#mi("{N \\geq N_m}")#text(".")

#text("Now let ")#mi("{A := \\bigcup_{m=1}^\\infty E_{N_m,m} \\cap B(0,m)}")#text(". Then ")#mi("{A}")#text(" is Lebesgue measurable, and by countable subadditivity, ")#mi("{m(A) \\leq \\epsilon}")#text(". By construction, we have")

#align(center)[#tao-fit-display[#tao-math("\\left|f_n(x)-f(x)\\right| \\leq 1/m", block: true)]]

#text("whenever ")#mi("{m \\geq 1}")#text(", ")#mi("{x \\in {\\bf R}^d \\backslash A}")#text(", ")#tao-math("{\\left|x\\right| \\leq m}", block: false)#text(", and ")#mi("{n \\geq N_m}")#text(". In particular, we see for any ball ")#mi("{B(0,m_0)}")#text(" with an integer radius, ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" on ")#mi("{B(0,m_0) \\backslash A}")#text(". Since every bounded set is contained in such a ball, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Unfortunately, one cannot in general upgrade local uniform convergence to uniform convergence in Egorov’s theorem. A basic example here is the ")#emph[#text("moving bump")]#text(" example ")#mi("{f_n := 1_{[n,n+1]}}")#text(" on ")#mi("{{\\bf R}}")#text(". This sequence converges pointwise (and locally uniformly) to the zero function ")#mi("{f \\equiv 0}")#text(". However, for any ")#mi("{0 < \\epsilon < 1}")#text(" and any ")#mi("{n}")#text(", we have ")#tao-math("{\\left|f_n(x) - f(x)\\right| > \\epsilon}", block: false)#text(" on a set of measure ")#mi("{1}")#text(", namely on the interval ")#mi("{[n,n+1]}")#text(". Thus, if one wanted ")#mi("{f_n}")#text(" to converge uniformly to ")#mi("{f}")#text(" outside of a set ")#mi("{A}")#text(", then that set ")#mi("{A}")#text(" has to contain a set of measure ")#mi("{1}")#text(". In fact, it must contain the intervals ")#mi("{[n,n+1]}")#text(" for all sufficiently large ")#mi("{n}")#text(" and must therefore have infinite measure.")

#text("However, if all the ")#mi("{f_n}")#text(" and ")#mi("{f}")#text(" were supported on a ")#emph[#text("fixed")]#text(" set ")#mi("{E}")#text(" of finite measure (e.g. on a ball ")#mi("{B(0,R)}")#text("), then the above “escape to horizontal infinity” cannot occur, it is easy to see from the above argument that one can recover uniform convergence (and not just locally uniform convergence) outside of a set of arbitrarily small measure.")
]

#text("We now use Theorem ")#link(<tao-e73f1787966888b9221e>)[#text("15")]#text(" to give another version of Littlewood’s second principle, known as ")#link("http://en.wikipedia.org/wiki/Lusin's_theorem")[#text("Lusin’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 18 (Lusin’s theorem)")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be absolutely integrable, and let ")#mi("{\\epsilon > 0}")#text(". Then there exists a Lebesgue measurable set ")#mi("{E \\subset {\\bf R}^d}")#text(" of measure at most ")#mi("{\\epsilon}")#text(" such that the restriction of ")#mi("{f}")#text(" to the complementary set ")#mi("{{\\bf R}^d \\backslash E}")#text(" is continuous on that set.")
]

#text("Caution: this theorem does ")#emph[#text("not")]#text(" imply that the unrestricted function ")#mi("{f}")#text(" is continuous on ")#mi("{{\\bf R}^d \\backslash E}")#text(". For instance, the absolutely integrable function ")#mi("{1_{\\bf Q}: {\\bf R} \\rightarrow {\\bf C}}")#text(" is nowhere continuous, so is certainly not continuous on ")#mi("{{\\bf R} \\backslash E}")#text(" for any ")#mi("{E}")#text(" of finite measure; but on the other hand, if one deletes the measure zero set ")#mi("{E := {\\bf Q}}")#text(" from the reals, then the restriction of ")#mi("{f}")#text(" to ")#mi("{{\\bf R} \\backslash E}")#text(" is identically zero and thus continuous.")

#emph[#text("Proof:")]#text(" By Theorem ")#link(<tao-e73f1787966888b9221e>)[#text("15")]#text(", for any ")#mi("{n \\geq 1}")#text(" one can find a continuous, compactly supported function ")#mi("{f_n}")#text(" such that ")#tao-math("{\\left\\|f-f_n\\right\\|_{L^1({\\bf R}^d)} \\leq \\epsilon/4^n}", block: false)#text(" (say). By Markov’s inequality, that implies that ")#tao-math("{\\left|f(x)-f_n(x)\\right| \\leq 1/2^{n}}", block: false)#text(" for all ")#mi("{x}")#text(" outside of a Lebesgue measurable set ")#mi("{E_n}")#text(" of measure at most ")#mi("{\\epsilon/2^{n}}")#text(". Letting ")#mi("{E := \\bigcup_{n=1}^\\infty E_n}")#text(", we conclude that ")#mi("{E}")#text(" is Lebesgue measurable with measure at most ")#mi("{\\epsilon}")#text(", and ")#mi("{f_n}")#text(" converges uniformly to ")#mi("{f}")#text(" outside of ")#mi("{E}")#text(". But the uniform limit of continuous functions is continuous. We conclude that the restriction ")#mi("{f}")#text(" to ")#mi("{{\\bf R}^d \\backslash E}")#text(" is continuous, as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Show that the hypothesis that ")#mi("{f}")#text(" is absolutely integrable in Lusin’s theorem can be relaxed to being locally absolutely integrable (i.e. absolutely integrable on every bounded set), and then relaxed further to that of being measurable (but still finite everywhere or almost everywhere). (To achieve the latter goal, one can replace ")#mi("{f}")#text(" locally with a horizontal truncation ")#tao-math("{f 1_{\\left|f\\right| \\leq n}}", block: false)#text("; alternatively, one can replace ")#mi("{f}")#text(" with a bounded variant, such as ")#tao-math("{\\frac{f}{(1+\\left|f\\right|^2)^{1/2}}}", block: false)#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Show that a function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable if and only if it is the pointwise almost everywhere limit of continuous functions ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is measurable and ")#mi("{n \\geq 1}")#text(", show that there exists a continuous function ")#mi("{f_n: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" for which the set ")#tao-math("{\\{ x \\in B(0,n): \\left|f(x)-f_n(x)\\right| \\geq 1/n \\}}", block: false)#text(" has measure at most ")#mi("{\\frac{1}{2^n}}")#text(". You may find Exercise ")#link(<tao-b5e983998c0000db19f0>)[#text("25")]#text(" below to be useful for this.) Use this (and Egorov’s theorem) to give an alternate proof of Lusin’s theorem for arbitrary measurable functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" ")#metadata(none) <tao-44afc1ffd858bd0bbb15>#text(" This is a trivial but important remark: when dealing with unsigned measurable functions such as ")#mi("{f: {\\bf R}^d \\rightarrow [0,+\\infty]}")#text(", then Lusin’s theorem does not apply directly because ")#mi("{f}")#text(" could be infinite on a set of positive measure, which is clearly in contradiction with the conclusion of Lusin’s theorem (unless one allows the continuous function to also take values in the extended non-negative reals ")#mi("{[0,+\\infty]}")#text(" with the extended topology). However, if one knows already that ")#mi("{f}")#text(" is almost everywhere finite (which is for instance the case when ")#mi("{f}")#text(" is absolutely integrable), then Lusin’s theorem applies (since one can simply zero out ")#mi("{f}")#text(" on the null set where it is infinite, and add that null set to the exceptional set of Lusin’s theorem).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" By combining Lusin’s theorem with ")#link("http://en.wikipedia.org/wiki/Inner_regular_measure")[#text("inner regularity")]#text(" (Exercise 13 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(") and the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(" (which we will cover ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("in 245B")]#text("), one can conclude that every measurable function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" agrees (outside of a set of arbitrarily small measure) with a continuous function ")#mi("{g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Littlewood-like principles)")]#text(" ")#metadata(none) <tao-b5e983998c0000db19f0>#text(" The following facts are not, strictly speaking, instances of any of Littlewood’s three principles, but are in a similar spirit.")

#list(
[#text("(Absolutely integrable functions almost have bounded support) Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{\\epsilon > 0}")#text(". Show that there exists a ball ")#mi("{B(0,R)}")#text(" outside of which ")#mi("{f}")#text(" has an ")#mi("{L^1}")#text(" norm of at most ")#mi("{\\epsilon}")#text(", or in other words that ")#mi("{\\int_{{\\bf R}^d \\backslash B(0,R)} |f(x)|\\ dx \\leq \\epsilon}")#text(".")],
[#text("(Measurable functions are almost locally bounded) Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be a measurable function supported on a set of finite measure, and let ")#mi("{\\epsilon > 0}")#text(". Show that there exists a measurable set ")#mi("{E \\subset {\\bf R}^d}")#text(" of measure at most ")#mi("{\\epsilon}")#text(" outside of which ")#mi("{f}")#text(" is locally bounded, or in other words that for every ")#mi("{R > 0}")#text(" there exists ")#mi("{M < \\infty}")#text(" such that ")#tao-math("{\\left|f(x)\\right| \\leq M}", block: false)#text(" for all ")#mi("{x \\in B(0,R) \\backslash E}")#text(".")]
)

#text("As with Remark ")#link(<tao-44afc1ffd858bd0bbb15>)[#text("8")]#text(", it is important in the second part of the exercise that ")#mi("{f}")#text(" is known to be finite everywhere (or at least almost everywhere); the result would of course fail if ")#mi("{f}")#text(" was, say, unsigned but took the value ")#mi("{+\\infty}")#text(" on a set of positive measure.")
]

#heading(level: 1)[#text("Comments (142)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-230754")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("Dear Professor Tao,")

#text("I think Exercise 4 is wrong,it says:")

#text("Exercise 4 Let ")#mi("f: \\mathbf {R}^d \\rightarrow [0,+\\infty]")#text(". Show that ")#mi("f")#text(" is a bounded unsigned measurable function if and only if ")#mi("f")#text(" is the uniform limit of bounded simple functions.")

#text("A counterexample is the moving bump in Remark 7…")

#text("In order to repair,I think ")#mi("f")#text(" should be bounded in two directions,both horizontal and vertical.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-230755")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("I have to say sorry again because it is my fault.It is the distinction between the potential and reality.")

#text("Now I understand that In exercise 4,")#mi("f")#text(" is the uniform limit of bounded simple function means there EXISTS a sequence of bounded simple functions which approximated uniformly to ")#mi("f")#text("…So the counterexample moving bump is no longer a counterexample,because ")#mi("f=0")#text(" can be approximated uniformly by ")#mi("f_n=0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-230791")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("A remark to Lusin’s theorem:")

#text("I prove Lusin’s theorem myself,because I don’t like to see proofs provided by other people.")

#text("Theorem 18 (Lusin’s theorem) Let ")#mi("f: \\mathbf{R} \\rightarrow \\mathbf{R}\\bigcup\\{\\infty\\}")#text(" be measurable,and finite almost")#linebreak()#text(" everywhere, and let ")#mi("\\epsilon > 0")#text(". Then there exists a Lebesgue")#linebreak()#text(" measurable set ")#mi("E \\subset {\\bf R}^d")#text(" of measure at most ")#mi("\\epsilon")#text(" such that the restriction of ")#mi("f")#text(" to the complementary set ")#mi("{\\bf R}^d \\backslash E")#text(" is continuous on that set.")

#text("Proof:For sake of convenience we ignore the measure zero set,let we")#linebreak()#text(" assume that ")#mi("f")#text(" is finite everywhere and measurable.Suppose that ")#mi("f")#text(" is pointwise approximated by a sequence of simple functions")#linebreak()#text(" ")#mi("f_1,f_2,\\cdots,f_n,\\cdots")#text(".According to Egorov’s theorem,for any")#linebreak()#text(" given ")#mi("\\varepsilon_1>0")#text(",there exists a measurable ")#mi("A\\subset \\mathbf{R}")#text(" such that ")#mi("m(A)\\leq\\varepsilon_1")#text(",and such that ")#mi("f")#text(" can be locally uniformly approximated by ")#mi("f_n")#text(".")

#text("There is little difference between a simple function and a finite")#linebreak()#text(" linear combination of indicator functions on boxes.In fact,")#mi("\\displaystyle \\text{simple function}+\\text{vanishing function}")#linebreak()#text(" ")#mi("\\displaystyle =\\text{a finite linear combination of indicator function on}")#text(" ")#mi("\\displaystyle \\text{at most countable numbers of elementary sets}")#text(", where a vanishing function means a function whose")#linebreak()#text(" support set has measure zero.")

#text("So it in fact does no harm to assume that ")#mi("\\forall i\\in \\mathbf{N}^{+},f_i")#text(" is a finite linear combination of indicator")#linebreak()#text(" functions on at most countable numbers of elementary box(Why it does")#linebreak()#text(" no harm?).")

#text("Suppose that the support set of ")#mi("f_i")#text(" is ")#mi("\\bigcup_{h=1}^{\\infty}(S_h)")#text(",where ")#mi("\\forall h\\in\\mathbf{N}^{+}")#text(",")#mi("S_h")#linebreak()#text(" is an elementary box who has positive measure.And ")#mi("\\forall k\\neq k")#text(",")#mi("S_k")#text(" and ")#mi("S_j")#text(" are almost disjoint.")

#text("Now ")#mi("\\forall h\\in\\mathbf{N}^{+}")#text(",we take ")#mi("S_h=[a,b]")#text("(or")#linebreak()#text(" ")#mi("(a,b),[a,b),(a,b]")#text("),we cut a very small fraction of ")#mi("S_h")#text(" out,which is denoted by ")#mi("S_{h,out}")#text(",whose measure is ")#mi("\\varepsilon_h")#text(",after cut ")#mi("S_{h,out}")#text(",")#mi("S_h\\backslash S_{h,out}=(c,d)")#text(" is still an elementary box,and such that ")#mi("a<c<d<b")#text(".")

#text("By using the trick \"give yourself an epsilon of room\",we can let")#linebreak()#text(" ")#mi("\\sum_{h\\in\\mathbf{N}^{+}}\\varepsilon_h")#text(" as small as possible.")

#text("So after this operation,the support set of ")#mi("f_i")#text(" becomes")#linebreak()#text(" ")#mi("\\bigcup_{h=1}^{\\infty}(S_h\\backslash S_{h,out})")#text(",and we let ")#mi("f_i")#text(" be restricted on ")#mi("\\bigcup_{h=1}^{\\infty}(S_h\\backslash S_{h,out})")#text(".After ")#mi("f_i")#text(" is restricted,it can be easily be verified that ")#mi("f_i")#text(" is continuous.")

#text("It is easy to verify that a if a sequence of continuous function convergent locally uniformly to a function,then that function is also continuous.")

#text("So Lusin's theorem is proved!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-230907")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2013")])]

#text("A remark to Egorov’s theorem:")

#text("A generalization of this theorem is stated as follows,but it is not true:")

#text("(A false generalization of Egorov’s theorem) Let ")#mi("f_n: {\\bf R}^d \\rightarrow {\\bf C}")#text(" be a sequence of measurable functions that converge pointwise almost everywhere to another function ")#mi("f: {\\bf R}^d \\rightarrow {\\bf C}\\bigcup\\{\\infty\\}")#text(", and let ")#mi("\\epsilon > 0")#text(". Then there exists a Lebesgue measurable set ")#mi("A")#text(" of measure at most ")#mi("\\epsilon")#text(", such that ")#mi("f_n")#text(" converges locally uniformly to ")#mi("f")#text(" outside of ")#mi("A")#text(",and ")#mi("f")#text(" can not reach ")#mi("\\infty")#text(" outside of ")#mi("A")#text(".")

#text("Because if ")#mi("f")#text(" is from ")#mi("\\mathbf{R}^d")#text(" to ")#mi("\\mathbf{C}\\bigcup\\{\\infty\\}")#text(",then in the process of the proof, ")#mi("\\displaystyle \\bigcap_{N=0}^\\infty E_{N,m} = \\emptyset")#text(" will not hold.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-367817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2014")])]

#text("“the upper integral is somewhat problematic when dealing with “improper” integrals of functions that are unbounded or are supported on sets of infinite measure.”")

#text("Could you give an example to explain your remark above? (What “problem” are you refering to?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-368781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2014")])]

#text("The upper integral of, say, ")#mi("\\int_{-\\infty}^\\infty e^{-\\pi x^2}\\ dx")#text(", will be infinite (if one insists on only using finitely many pieces for the partition). Similarly for ")#mi("\\int_0^1 x^{-1/2}\\ dx")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-370139")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2014")])]

#text("“To obtain the equivalence of (5.) and (6.), observe that")

#mi("\\displaystyle  \\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda \\} = \\bigcap_{\\lambda^{\\prime} \\in {\\bf Q}^+: \\lambda^{\\prime} < \\lambda} \\{ x \\in {\\bf R}^d: f(x) > \\lambda^{\\prime} \\}")

#text("for ")#mi("{\\lambda \\in (0,+\\infty]}")#text(" and")

#mi("\\displaystyle  \\{ x \\in {\\bf R}^d: f(x) > \\lambda \\} = \\bigcup_{\\lambda^{\\prime} \\in {\\bf Q}^+: \\lambda^{\\prime} > \\lambda} \\{ x \\in {\\bf R}^d: f(x) \\geq \\lambda^{\\prime} \\}")

#mi("{\\lambda \\in [0,+\\infty)}")#text(", where ")#mi("{{\\bf Q}^+ := {\\bf Q} \\cap [0,+\\infty]}")#text(" are the non-negative rationals. ”")

#text("——————————")#linebreak()#text(" In the first formula, if one uses ")#mi("{\\bf Q}")#text(" instead of ")#mi("{\\bf Q}^+")#text(", then it seems that the formula works for ")#mi("\\lambda=0")#text(" also.")

#text("In the second formula, why doesn’t it work when ")#mi("\\lambda=+\\infty")#text("? (the LHS is an empty set and the RHS is an empty union…)")

#emph[#text("[The formulae work at these endpoints also. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-370284")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2014")])]

#text("In the first formula, when ")#mi("\\lambda=0")#text(", I think it doesn’t work? The left hand side is equal to ")#mi("{\\bf R}^d")#text(" but the RHS is an empty intersection (unless one replaces ")#mi("{\\bf Q}^+")#text(" with ")#mi("{\\bf Q}")#text("). Or is it a convention that an empty intersection is indeed ")#mi("{\\bf R}^d")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-370323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2014")])]

#text("That would be the appropriate convention in this case: ")#link("http://math.stackexchange.com/questions/370188/empty-intersection-and-empty-union")[#text("http://math.stackexchange.com/questions/370188/empty-intersection-and-empty-union")]#text(" . In any event, one does not need to consider these endpoint cases for the application at hand.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-370775")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2014")])]

#text("I’m trying to get the formula in the proof of Lemma 7:")

#text("the set ")#mi("{\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\}}")#text(" is equal to")

#mi("\\displaystyle  \\bigcup_{M>0} \\bigcap_{N>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}")

#text("Since ")#mi("\\{f>\\lambda\\}=\\bigcup_{M>0}{\\{f>\\lambda+1/M\\}}")#text(", it suffices to show that")

#mi("\\displaystyle  \\bigcap_{N>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}=\\left\\{\\inf_{N>0}\\sup_{n\\geq N}f_n>\\lambda+\\frac{1}{M}\\right\\}")

#text("One direction is obvious:")

#mi("\\displaystyle  \\bigcap_{N>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}\\supset\\left\\{\\inf_{N>0}\\sup_{n\\geq N}f_n>\\lambda+\\frac{1}{M}\\right\\}")

#text("since")

#mi("\\displaystyle \\inf_{N>0}\\sup_{n\\geq N}f_n\\leq \\sup_{n\\geq N} f_n")

#text("for all ")#mi("N>0")#text(". But the other direction is not:")

#mi("\\displaystyle \\bigcap_{N>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}")

#text("only implies that")

#mi("\\displaystyle \\inf_{N>0}\\sup_{n\\geq N}f_n\\geq\\lambda+\\frac{1}{M}")#text(".")

#text("Where do I do wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-370778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2014")])]

#text("The reduction in your “suffices to show that” gives away too much, and is indeed false in general; you should focus on proving the original identity instead. Note that ")#mi("x \\geq \\lambda+\\frac{1}{M}")#text(" implies that ")#mi("x  > \\lambda")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43831a796dee59a70f274a775d6b91924c6257ab3c900679c9cf3850ca1a3a40-a0897c3bbef47bafe156f538c087dc78c03c0161e5f5293b7d1130066b40915a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410840")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Why is the union over ")#mi("\\frac{1}{M}")#text("s even necessary? Couldn’t we use just an intersection?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410943")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("The intersection is too small. Consider for instance the example when ")#mi("\\lambda = 0")#text(" and ")#mi("f(x)=f_n(x) = \\frac{1}{10}")#text(" for all ")#mi("n \\geq 1")#text(" and ")#mi("x \\in {\\bf R}^d")#text(". Then")

#mi("\\{ x \\in {\\bf R}^d: f(x) > \\lambda \\} = {\\bf R}^d")

#text("but")

#mi("\\bigcap_{M=1}^\\infty \\bigcap_{N=1}^\\infty \\{x \\in {\\bf R}^d: \\text{sup}_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\} = \\emptyset")

#text("as one can see by considering what happens when ")#mi("M \\leq 10")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/403523fd4d053809eaa080d835063baa29e7460ea168b36a8e9ea520ca32437c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410956")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("I’m sorry, I didn’t write that clearly. What I meant was that elsewhere in the book (I think) we do limsup’s with just ")#mi("\\bigcap\\bigcup")#text(" and not like here where we end up with ")#mi("\\bigcup\\bigcap\\bigcup")#text(".")

#text("Equivalently, it seems to me that")

#mi("\\bigcup_{M>0}\\bigcap_{N>0} \\{x \\in {\\bf R}^d: \\text{sup}_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\} = \\bigcap_{N>0} \\{x \\in {\\bf R}^d: \\text{sup}_{n \\geq N} f_n(x) > \\lambda\\}")

#text("By some argument of monotone convergence?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410991")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("This is not correct; for instance, if ")#mi("f_n(x) = 1/n")#text(" and ")#mi("\\lambda=0")#text(", then the right-hand side is ")#mi("{\\bf R}^d")#text(" but the left-hand side is empty. However, the right-hand side is equal to ")#mi("\\bigcap_{N>0} \\bigcup_{M>0} \\{ x \\in {\\bf R}^d: \\sup_{n \\geq N} f_n(x) > \\lambda + \\frac{1}{M} \\}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/403523fd4d053809eaa080d835063baa29e7460ea168b36a8e9ea520ca32437c-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Dybdahl Ahle")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-411019")[#strong[#text("Thomas Dybdahl Ahle")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("Ah! The sharp inequality is not preserved by the “limit” so we add an “infinitesimal” on the right hand side using ")#mi("\\frac{1}{M}")#text("!")#linebreak()#text(" Ingenious. Thank you very much, you are a great inspiration.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-377830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2014")])]

#text("Do you have a hint for the “only if part” for Exercise 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Question")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-379168")[#strong[#text("Question")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2014")])]

#text("For Exercise 4, Using the simple functions (without being truncated vertically, i.e., ")#mi("f_n")#text(" being the largest ")#mi("c\\dot 2^{-n}")#text(" less than or equal to ")#mi("\\min (f(x),n)")#text(") defined in the last step of the proof of Lemma 7, one has the desired sequence of simple functions.")

#text("I don’t see what strategy one should use in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("245A: Problem solving strategies")]
]

#text("It seems that one can take the “finite measure support” out from (4) in Lemma 7. Are simple functions with finite measure support of special interest in application? Isn’t “uniform convergence” preferable?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-380876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Could you give a hint for Ex 14?")

#text("If I don’t understand it wrong, the “uniqueness of the Lebesgue integral” means the following:")

#text("Let ")#mi("L")#text(" be a operator such that")

#text("– ")#mi("Lf=Simp \\int f")#text(" when ")#mi("f")#text(" is simple")#linebreak()#text(" – ")#mi("L(f+g)=Lf+Lg")#text(" for any measurable functions f and g")#linebreak()#text(" – ")#mi("\\displaystyle \\lim_n L(\\min(f,n))=Lf")#linebreak()#text(" – ")#tao-math("\\displaystyle \\lim_n L(f1_{\\left|x\\right|\\leq n})=Lf", block: false)

#text("Show that ")#mi("Lf=\\int f")#text(" for any Lebesgue measurable functions.")

#mi("Lf=\\int f")#text(" is immediately true when ")#mi("f")#text(" is simple. How can one past the case of simple functions the to general cases?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("The (real) Lebesgue measurable functions are ")#mi("({\\mathcal L},{\\mathcal B}_{\\bf R})")#text(" measurable by definition. What if one considers the ")#mi("({\\mathcal L},{\\mathcal L})")#text(" measurable functions only?")

#text("For doing integration of functions ")#mi("f:(X,{\\mathcal M})\\to(Y,{\\mathcal N})")#text(", why is it enough to use Borel measure in the target space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-410337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2014")])]

#text("For the purposes of integration theory, the range ")#mi("(Y,{\\mathcal N})")#text(" and domain ")#mi("(X,{\\mathcal M})")#text(" are treated quite differently (in contrast to the more category-theoretic areas of mathematics, in which the domain and range of a morphism are consciously treated on a very equal footing). In particular, the range needs the structure of a complete vector space in order to have any sensible (linear) integration theory. (There are some nonlinear generalisations of the integration concept, but they usually fit better with the more classical Riemann theory of integration than the Lebesgue theory.)")

#text("One way to think of a ")#mi("({\\mathcal L}, {\\mathcal B}_{\\bf R})")#text("-measurable function is as the pointwise limit of simple functions (finite linear combinations of indicator functions of measurable sets). This ties in with the underlying intuition of Lebesgue integration as coming from “horizontally” slicing up the graph of a function (as opposed to Riemann integration, which is focused instead on “vertically” slicing up the graph).")

#text("Strengthening the measurability requirement by placing the Lebesgue sigma algebra, rather than the Borel sigma algebra, on the range leads to some pathologies, for instance the very natural function ")#mi("x \\mapsto (x,0)")#text(" from ")#mi("({\\bf R}, {\\mathcal L})")#text(" to ")#mi("({\\bf R}^2, {\\mathcal L}^2)")#text(" is now a non-measurable function! (if ")#mi("E")#text(" is a non-measurable subset of ")#mi("{\\bf R}")#text(", then ")#mi("E \\times \\{0\\}")#text(" is a null set and is thus Lebesgue measurable, but not Borel measurable in ")#mi("{\\bf R}^2")#text(".) One can achieve similar pathologies in one-dimension by using an essentially bijective map between, say, the unit interval and the Cantor set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-469728")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("This is a follow up question. When doing probability theory, why Borel measurable functions, namely, ")#mi("(\\mathcal{B}_{\\bf R},\\mathcal{B}_{\\bf R})")#text("-measurable functions, are used (as random variables), instead of the Lebesgue measurable functions, namely, ")#mi("(\\mathcal{L},\\mathcal{B})_{\\bf R}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-469733")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("The property of completeness of a sigma-algebra turns out to not be so useful in probability theory (which tries to ignore the set-theoretic structure of the sample space as much as possible). On the other hand, some technical measure-theoretic constructions, such as disintegration of measure (used to construct conditional expectations) and the Kolmogorov extension theorem are more convenient to state using Borel sigma algebras (particularly if one is working with standard Borel spaces). So there are some slight advantages in probability theory with sticking with Borel sigma algebras throughout, though I doubt there would be much harm in trying to work instead with Lebesgue sigma algebras if one so desired.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-469816")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("While it is better to use ")#mi("(\\mathcal{B}_{\\bf R},\\mathcal{B}_{\\bf R})")#text("-measurable functions in probability theory, for what reasons would one need ")#mi("(\\mathcal{L},\\mathcal{B}_{\\bf R})")#text("-measurable functions in general integration theory (for instance, when working in PDE, ")#mi("(\\mathcal{L},\\mathcal{B}_{\\bf R})")#text("-measurable functions are used instead of the ")#mi("(\\mathcal{B}_{\\bf R},\\mathcal{B}_{\\bf R})")#text("-measurable ones)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-469821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")])]

#text("I don’t think it makes much difference in PDE; one often works in function spaces in which one identifies functions which agree almost everywhere, in which case there is no difference between Lebesgue measurable functions and Borel measurable functions. The distinction is certainly important in descriptive set theory, and in certain classical areas of Fourier analysis (e.g. in describing exactly the set of divergence of some Fourier series is). I think there are also some advantages to working in a complete sigma algebra in geometric measure theory, though I can’t think of a concrete such example immediately (other than that it makes it easier to verify that a set is measurable – e.g. it would be enough to show that the outer measure vanishes).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-420238")[#strong[#text("Integral Bounds In Latex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2014")]

#text("[…] 245a, notes 2: the lebesgue integral | what’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-464500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")])]

#text("In Exercise 10 (8), should it be “vertical truncation”? It is not consistent with Notes 3 Exercise 34 (9).")

#emph[#text("[Notes 3 changed -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-466400")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2016")])]

#text("Dear Prof. Tao and all the readers,")

#text("I don’t quite understand some detail of the proof of Lusin’s theorem.")

#text("Why we control the measure of A by ")#mi("\\epsilon/2")#text(" instead of ")#mi("\\epsilon")#text("? What is the relation between ")#mi("A")#text(" and ")#mi("E")#text("? And how local uniform limits play any role?")

#text("I think that if we control ")#mi("m(A)<\\epsilon")#text(", then we are almost done. Since ")#mi("f_n")#text(", which is continuous, uniformly converges to ")#mi("f")#text(" outside of ")#mi("A")#text(", then ")#mi("f")#text(" is continuous outside of ")#mi("A")#text(", problem solved. What wrong with this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-466412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2016")])]

#text("Sorry, this was a remnant from an earlier version of the post where I also addressed the locally integrable case (but this was pushed to an exercise). The proof has been replaced by the more natural one you indicate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of k")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-466404")[#strong[#text("k")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2016")])]

#text("Hi Terry,")#linebreak()#text(" What do you think about this breakthrough in Fourier analysis")#linebreak()#text(" ")#link("http://arxiv.org/abs/1602.05384")[#text("http://arxiv.org/abs/1602.05384")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-468739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("For the linear transformation ")#mi("x\\mapsto -x")#text(", one has from calculus")

#mi("\\displaystyle \\int_a^bf(-x)\\ dx=-\\int_{-a}^{-b} f(y)\\ dy=\\int_{-b}^{-a}f(y)\\ dy")

#text("which looks rather different from Exercise 16. Is this a contradiction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-468744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("This is the signed definite integral ")#mi("\\int_a^b f(x)\\ dx")#text(", which differs from the unsigned definite integral ")#mi("\\int_{[a,b]} f(x)\\ dx")#text(" for ")#mi("b<a")#text(" in precisely the fashion indicated. See ")#link("http://www.math.ucla.edu/~tao/preprints/forms.pdf")[#text("this previous article of mine")]#text(" for some comparison between the two.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-472639")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("[…] as the Lebesgue integral. The precise definition of this integral is a little complicated (see e.g. this previous post), but roughly speaking the idea is to approximate by simple functions for some coefficients and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-473652")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2016")])]

#text("I’m having trouble with Exercise 10.8 and 10.9 (horizontal and vertical truncation properties of the lower Lebesgue integral). In particular, I can’t figure out which other theorems can help me out here since $f$ isn’t even necessarily measurable and therefore neither is ")#mi("f^{-1}([0,n])")#text(" for instance. Can I have a hint?")

#emph[#text("[")#mi("f")#text(" may not be measurable, but the simple functions lying underneath it are. See also the general advice at ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" . -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-473674")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2016")])]

#text("Got it. Thanks so much Terry! Not only do you post this text for free, but you even answer questions on it!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-485722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("… horizontal truncation ")#tao-math("{f 1_{\\left|f\\right| \\leq n}}", block: false)#text("; alternatively, one can replace ")#mi("{f}")#text(" with a bounded variant, such as ")#tao-math("{\\frac{f}{(1+\\left|f\\right|^2)^{1/2}}}", block: false)#text(".)")

#text("Would you elaborate the hint for Exercise 23? I don’t quite understand what that means. Moreover, is ")#tao-math("{\\frac{f}{(1+\\left|f\\right|)}}", block: false)#text(" also a bounded variant?")

#emph[#text("[To obtain Lusin’s theorem for arbitrary measurable ")#mi("f")#text(", first apply Lusin’s theorem to a bounded measurable function such as ")#tao-math("f 1_{\\left|f\\right| \\leq n}", block: false)#text(", ")#tao-math("f / (1+\\left|f\\right|^2)^{1/2}", block: false)#text(", or ")#tao-math("f / (1+\\left|f\\right|)", block: false)#text(", and figure out how to use the continuous approximation of those functions to obtain a continuous approximation to ")#mi("f")#text(". -T]</I ")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-505563")[#strong[#text("Limit of Bounded measurable function – Website Information")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")]

#text("[…] 245A, Notes 2: The Lebesgue integral […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a4e862e411af35c4243c9a9f9a79daefa671006463291d79788ac05b2913bf-988f1beec5199d6bf39fff81e0b3f82338377e1459b63d9eb92e510cfdf0d3a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pratim Mitra")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-630714")[#strong[#text("Pratim Mitra")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2021")])]

#text("Dear Sir,")

#text("In the Ex. 25 (second part) we have to show that “Almost everywhere measurable function is almost locally bounded”. Isn’t an immediate consequence of Lusin’s theorem ? However my question is can we prove it without using Lusin’s theorem ?")

#text("Thank you.")

#emph[#text("[Hint: first establish the claim in the case when ")#mi("f")#text(" is compactly supported. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-642009")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" For the simple function ")#mi("f_n")#text(" constructed in the proof of Lemma 7, it seems that for ")#tao-math("\\left|x\\right| \\leq n", block: false)#text(", ")#mi("f_n(x)")#text(" could take infinite different values at such ")#mi("x")#text(" where ")#mi("f(x) < n")#text(". Where did I get it wrong ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-642038")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2022")])]

#text("The only values that ")#mi("f_n(x)")#text(" can take are those non-negative multiples of ")#mi("2^{-n}")#text(" less than or equal to ")#mi("n")#text(", which is a finite set.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-642051")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2022")])]

#text("Thank you so much professor. Now I see it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-642341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" For exercise 6, if one wishes to approximate the region under $f$ with countable union of regions under simple functions $f_n$ within a null set using (4) of Lemma 7, does one need to divide into cases where f is bounded /unbounded?")

#emph[#text("[One can if one wishes, but there are multiple ways to solve this problem -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-643477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" I wonder why Example 3 demonstrates that the exceptional set A in Egorov’s theorem cannot be taken to have zero measure if one uses the bounded-set definition of local uniform convergence, but we can still have locally uniform convergence if one uses the open- neighborhood definition?")

#emph[#text("[Which of the two claims do you want clarification on? And how far were you able to get verifying them on your own? -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-643608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("Dear professor Tao:")#linebreak()#text(" To answer your question, it is the first claim in particular that I want some clarification. My understanding is that ")#mi("\\forall n \\geq 1, f_{n}(1/n) = 1 \\neq 0")#text(", so the exceptional set ")#mi("A")#text(" must contain the interval ")#mi("(0, \\epsilon)")#text(" for arbitrarily small ")#mi("\\epsilon > 0")#text(" for ")#mi("f_n")#text(" to converge locally uniformly to zero in the bounded-set sense. But I’m not sure if this is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-643609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("Yes, this is correct. If ")#mi("A")#text(" is a set and ")#mi("n")#text(" is such that ")#tao-math("\\left|f_n(x) - 0\\right| < 1", block: false)#text(" for all ")#mi("x")#text(" outside of ")#mi("A")#text(", then ")#mi("A")#text(" must contain ")#mi("(0,1/n)")#text(" and hence has positive measure. Taking contrapositives gives the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-643614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2022")])]

#text("Thank you so much for your patient explanation.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-676665")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2023")])]

#text("You are a bright mathematician. I have a Ph. D. from U.T. at Austin. And José Ramón Madrid wroked with you for a short time with you.")#linebreak()#text(" Next time I will comment some mathematics with you.")#linebreak()#text(" I am in Harmonic Analisys in non commutative “Lebesgue Integral” Very different to José Ramón who is in Real Analysis.I thank you are is almost everything.")#linebreak()#text(" Best regards.")#linebreak()#text(" José Adalid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bba809b99911cd8e1b969bbf6e1715e65649cb5a8224bf625923947ded4ecb6a-c6b9d52224f2d6f76bba8b52f0bb23948aa001d54b98b5274d899b714098d869.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-678184")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Could you please explain why the notion of unsigned measurable functions is necessary? Why not real-valued? Many books said it is convenient, but I do know the detailed reason.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-678201")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("The main advantage is that unsigned measurable functions (taking values in the extended unsigned real line ")#mi("[0,+\\infty]")#text(") are well-behaved under arbitrary summation (even uncountable summation) – for instance they obey the monotone convergence theorem – without any requirement of absolute convergence, and so serve as a very convenient starting point for the theory. There are other ways to arrange the foundations of the theory; for instance one can start with simple bounded functions of finite measure support, or with absolutely integrable functions, or (via the Riesz representation theorem) continuous functions of compact support.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bba809b99911cd8e1b969bbf6e1715e65649cb5a8224bf625923947ded4ecb6a-c6b9d52224f2d6f76bba8b52f0bb23948aa001d54b98b5274d899b714098d869.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-678205")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Thanks a lot. Two more questions:")

#text("Besides these technical advantages, is there any example of unsigned measurable function from physics or other branches of science? I used to think that Dirac’s delta function ($\\dalta(x)=0$ if $x\\neq 0$, $\\dalta(x)=\\infty$ if $x=0$, and $\\int_{\\mathbb{R}}\\delta(x)\\dx=1$) is a typical unsigned measurable function. But, in fact it is not. Am I right?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-678210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Densities of various physical or mathematical quantities (e.g., density of a fluid, or probability density functions) are common examples of naturally non-negative measurable functions that appear in practice.")

#text("The Dirac delta function is not, strictly speaking, an unsigned measurable function, but it is a ")#link("https://en.wikipedia.org/wiki/Generalized_function")[#text("generalized function")]#text(" that is the (weak) limit of unsigned measurable functions (")#link("https://en.wikipedia.org/wiki/Approximation_to_the_identity")[#text("approximations to the identity")]#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2025")])]

#text("Where can I find reference answers to these exercises?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687058")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2025")])]

#text("Dear professor Tao: In Definition 5 the notion of absolute-integrability is given using the notion of complex-valued simple integral, which is given for integrable functions, is there some circularity here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687063")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2025")])]

#text("We are using the simple unsigned integral to define the notion of absolute integrability for complex simple functions; there is no circularity (but one can check that the absolutely integrable integral and the unsigned integral agree for unsigned, absolutely integrable simple functions).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687129")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("Dear professor Tao:")

#text("To show that (4) and (5) implies (1) to (3) in Exercise 7, is it fine to first show that the preimage of any interval under the real and imaginary parts of ")#mi("f")#text(" are measurable, and then imitate the ")#mi("2^{-n}")#text(" construction in Lemma 7? Are there other ways to do it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687145")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2025")])]

#text("Dear professor Tao:")

#text("Can you also provide a little hint on why the horizontal and vertical truncation properties fail for upper integral in Exercise 10?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687148")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2025")])]

#text("Dear professor Tao:")

#text("I think I got this part, by considering a sequence of tower of increasing heights and decreasing width, for the horizontal truncation, and likewise for the vertical truncation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687172")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2025")])]

#text("Dear professor Tao:")#linebreak()#text(" For part (2) of Exercise 25, using Lusin’s theorem one can get ")#mi("f")#text(" to be continuous on sets of the form ")#mi("B(0, R) \\backslash  E")#text(", but as compactness is absent, how can we obtain boundeness?")

#emph[#text("[Inner regularity will finish the job here, though actually one can solve this problem without any topology at all, by directly truncating the original function rather than appealing to Lusin’s theorem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687479")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2025")])]

#text("In the conclusion of Lusin’s theorem, the function ")#mi("f")#text(" is only guaranteed to be continuous when restricted to a subset ")#mi("E")#text(" whose complement has a given small measure, with continuity considered in the subspace topology of ")#mi("E")#text(". Why is this still useful in applications? It seems that losing continuity with respect to the original topology of ")#mi("\\mathbf{R}^d")#text(" could limit its impact. Moreover, since any function can be made continuous by restricting it to a sufficiently “small” subset, what makes Lusin’s theorem nontrivial or significant in this regard?")

#text("I noticed in Remark 9 you mention an extension of Lusin’s theorem: by combining it with inner regularity and the Tietze extension theorem, every measurable function agrees (outside a set of arbitrarily small measure) with a globally continuous function. Does this stronger result resolve the concern about the subspace topology, making Lusin’s theorem primarily an intermediate technical step? Or is the original form of the theorem already meaningful in applications without appealing to this extension?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-687480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2025")])]

#text("Personally, on the occasions I have had to use Lusin’s theorem, I usually pair it with some sort of extension theorem such as the Tietze extension theorem to obtain a globally defined approximation. But this is to some extent a personal preference; for some applications just working with the continuous function defined on the large subset is already sufficient for applications, for instance if one wants to conclude that some other property relating to the function in question holds on a set of large measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("Dear Dr Tao,")

#text("In Lebesgue integration theory (specifically the part concerning absolutely integrable integrals), analysts decompose a function f into its positive and negative parts. However, such an approach is not taken when studying the Riemann integral. Is it because this decomposition aligns with ideas in harmonic analysis or other fields of analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692062")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("I am ")#link("https://claude.ai/share/46cbe64d-035a-4c5c-83e7-941745545378")[#text("outsourcing this question to an AI")]#text(". I will add that fundamentally, the Lebesgue integral is based on “horizontal” decompositions of functions (based on level sets, etc.), while the Riemann integral is based on “vertical” decompositions of functions (partitioning the domain into intervals, etc.). Splitting into positive and negative parts is very much a “horizontal” decomposition.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("Your additional answer cleared up my confusion instantly!")

#text("I’d also like to ask one more thing: for the negative part: in Analysis II, you use the notation as f⁻ :=-min(f,0), but in this book An Introduction to Measure Theory, it’s defined as f⁻ :=max(-f,0). Why is there this distinction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("This is just a sign convention (one of these definitions is the negative of the other). One can either have an additive splitting ")#mi("f = f_+ + f_-")#text(" but have ")#mi("f_-")#text(" negative, or a subtractive splitting ")#mi("f = f_+ - f_-")#text(" with ")#mi("f_-")#text(" positive; both conventions have (very) minor advantages and disadvantages over the other.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692148")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2026")])]

#text("Dr. Tao, analysts have defined the Lebesgue integral to be a supremum of approximations of simple integral, why not replace the ")#emph[#text("supremum")]#text(" in the definition with the ")#emph[#text("limit")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2026")])]

#text("A limit requires a ")#link("https://en.wikipedia.org/wiki/Neighbourhood_system")[#text("neighborhood filter")]#text(") on the parameter space, in order to quantify what it means for the parameter to be “sufficiently close” to the limit. What filter do you propose to place on the space of simple integral approximations? I.e., what would it mean for an approximation to be “sufficiently good”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692182")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2026")])]

#text("This question is beyond my level of expertise. What I originally meant was: suppose we have a sequence of simple functions s_n(x) converging pointwise to f . Why don’t we define the integral of f as \\lim_{n \\to \\infty} \\int s_n(x) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-2/#comment-692192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2026")])]

#text("This approach runs into the fundamental issue that limits and integrals cannot always be safely interchanged. Pointwise convergence of ")#mi("s_n")#text(" to ")#mi("f")#text(" will not guarantee that the integrals ")#mi("\\int s_n")#text(" converge at all, let alone converge to what one believes the integral of ")#mi("f")#text(" to be. (If the ")#mi("s_n")#text(" increase monotone upwards to ")#mi("f")#text(", then one is in better shape, but at that point one may as well work with the supremum rather than the limit.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47164")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("typo: “but much as the theory of Lebesgue measure is easiest to define by relying solely on outer measure and noton inner measure…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47165")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("And exercises 1 and 2 (and to a lesser extent definition 5) have not typeset properly: the equations break the bounding box and are cut off.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47167")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2010")])]

#text("“$latex{c_n^+ := \\max(c_n,0)}$ and $latex{c_n^- := \\max(-c_n,0)}$ are the positive and negative parts of $latex{c_n}$” means “$latex{c_n^+ := \\max(c_n,0)}$ and $latex{-c_n^- := \\min(c_n,0)}$ are the positive and negative parts of {c_n}”. ($latex{c_n^-}$ is neither negative nor part of $Latex{c_n}$).")

#emph[#text("[Reworded slightly – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8ed407ead0a8dc7443a968b031721e58eac73651a9c272245d2c6782af9e16-cfee6947f3a487cb7ddc47b9646cc2891fdb394a8346bf2a3b02d049d3cabe21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47169")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2010")])]

#text("The end of the proof of Theorem 15 appears to have gone awry. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2010")])]

#text("in definition 1, is ")#mi("k \\geq 1")#text(" or ")#mi("k \\geq 0")#text("?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47176")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2010")])]

#text("It doesn’t matter much for this definition (either way, 0 will be a simple function).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47178")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("[…] Prolog: Grundfragen und Jordansche Maß Lecture 1: Das Lebesguesche Maß. Lecture 2: Das Lebesguesche Integral […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c29264fb486ceaec33223c77038ad1b8efd8aa68feb66d6cfa8871af18b07f-fdec1d329b3909327d05b13b92473ec66f3d60d5790e6fee1cf23b2d0d2988f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Schwarzmann")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47185")[#strong[#text("Mark Schwarzmann")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2010")])]

#text("Another possible definition of the unsigned Lebesgue integral arises from its interpretation as the area (or n-dimensional volume, in general) under the graph of a function. Formally, if ")#mi("f:\\mathbb{R}^n \\to \\mathbb{R}")#text(" is a non-negative measurable function, one may define the integral of ")#mi("f")#text(" on ")#mi("\\mathbb{R}^n")#text(" as the ")#mi("n+1")#text("-dimensional Lebesgue measure of the set ")#mi("\\{ (\\mathbf{x},y) \\in \\mathbb{R}^{n+1} : 0 \\le y < f (\\mathbf{x}) \\}")#text(", where $x \\in \\mathbb{R}^n$ and $y \\in \\mathbb{R}$. For this definition, the basic limit theorems of the Lebesgue integral (the monotone convergence theorem and Fatou's lemma) follow readily from the corresponding theorems for sets, though other properties of the integral are admittedly more difficult to establish.")

#emph[#text("[A comment added to Exercise 13 to reflect this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurent")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47198")[#strong[#text("Laurent")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Very nice series of posts, thank you!")#linebreak()#text(" In the proof of Egorov’s theorem, it seems that ")#mi("E_{N,m}")#text(" should be defined to be the complement of what it is defined to be.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47252")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] now define the unsigned integral, similarly to what was done for the unsigned Lebesgue integral in Notes 2: Definition 11 Let be a measure space, and let be measurable. Then we define the unsigned […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2010")])]

#text("Dear Prof. Tao")

#text("Thanks for the nice posts!")

#text("I have a question regarding the definition of the simple function: It is defined to take finite many values (i=1,…k in Def. 1). I can see it is sufficient for the theory (e.g., the lower Lebesgue integral is taken to be the supremum of the integral of simple function). But would it be problematic if we allow k go to infinity in the Definition 1?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2010")])]

#text("Well, I suppose one could consider functions that take countably many values; given that the measure is countably additive, one would imagine that much of the theory for finitely-valued functions would carry over to countably-valued functions. But simple functions are in any event just a stepping stone to the integration of arbitrary unsigned measurable functions, which can take uncountably many values, so it’s not clear what advantage would be gained by making simple functions less simple.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47501")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2010")])]

#text("Respected Sir,")

#text("Instead of using the ” \\rightarrow” symbol for getting ")#mi("\\rightarrow")#text(" just use “\\to” for getting the same symbol, thereby saving time!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a7e91a3b4420dee4b57ee776d738188f237a7aa6e3912716edd78c4ca67872-37e41a590d50e7ad502f777dfb04510b457d16906f7ea295ee7acb267060016a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brent Nelson")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47526")[#strong[#text("Brent Nelson")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2010")])]

#text("In exercise 19, one of the complex constants ‘c’ should be moved inside the integral.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64a7e91a3b4420dee4b57ee776d738188f237a7aa6e3912716edd78c4ca67872-37e41a590d50e7ad502f777dfb04510b457d16906f7ea295ee7acb267060016a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brent Nelson")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47573")[#strong[#text("Brent Nelson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2010")])]

#text("In part (5) of exercise 7, the U should be changed to a K. In definition 10, you say that the unsigned Lebesgue integral is equal to the lower unsigned Lebesgue integral, but you use the notation for the upper unsigned Lebesgue integral. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47644")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] integrable, and let be arbitrary. Applying Littlewood’s second principle (Theorem 15 from Notes 2) to the absolutely integrable function , we can find a continuous, compactly supported function […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("Hi Prof. Tao,")

#text("I have a question of Exercise 4. Why f is a bounded unsigned measurable function if it is uniform limit of simple function.")#linebreak()#text(" What if we take f_n equals infinity, and it is a simple function and uniformly convergent to f which also equals infinity.")

#emph[#text("[Oops, I had omitted the requirement that the simple functions must also be bounded. Fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c29264fb486ceaec33223c77038ad1b8efd8aa68feb66d6cfa8871af18b07f-fdec1d329b3909327d05b13b92473ec66f3d60d5790e6fee1cf23b2d0d2988f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Schwarzmann")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47831")[#strong[#text("Mark Schwarzmann")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("Another fact in the spirit of Littlewood’s three principles is that every absolutely integrable function nearly vanishes at infinity (that is, outside a set of arbitrarily small measure).")

#emph[#text("[A good point! I’ve added a final exercise to the notes to draw attention to this (and also to the related fact that a function that is finite a.e. is almost locally bounded.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc320250f2e23d5a4c9efd13c18aa4941157c4483224f5206fde5273e462a9e9-119f2a6769ba244433fc0111fff7bd89f9d8a8bca1c37d17b83bf61bd63fc0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein Naderi")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47846")[#strong[#text("Hossein Naderi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("Dear Professor Tao,")

#text("I had a quick question on excersice 4 (The more difficult direction), why would boundedness of f as a measureable function cause uniform instead of pointwise convergence of simple functions?")#linebreak()#text(" Thank you in advance,")#linebreak()#text(" Hossein")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47847")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("To approximate arbitrary measurable functions by (bounded) simple functions, one has to perform two operations: vertical truncation and discretisation. (Horizontal truncation is not necessary because we are not requiring the simple functions to have finite measure support.) The latter would lead to uniform convergence, but the former does not, which is why one only has pointwise convergence in the arbitrary case. But in the bounded case, one does not need to perform vertical truncation, only discretisation, and this recovers the uniform convergence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc320250f2e23d5a4c9efd13c18aa4941157c4483224f5206fde5273e462a9e9-119f2a6769ba244433fc0111fff7bd89f9d8a8bca1c37d17b83bf61bd63fc0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein Naderi")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-47848")[#strong[#text("Hossein Naderi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("Thank you Professor Tao,")

#text("I got it. Really appreciate your help.")#linebreak()#text(" Hossein")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiang")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-48140")[#strong[#text("Qiang")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Dear Prof. Tao")

#text("In Remark 3, the second sentence should be … if ")#mi("E")#text(" is NOT Lebesgue measurable… ")#emph[#text("[Actually, I think the sentence is correct as it stands – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-48440")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("Prof. Tao,")#linebreak()#text(" In your route to setting up the unsigned and absolutely convergent Lebesgue integrals, could you explain what are the advantages for allowing the unsigned simple functions to be unbounded, say, ")#mi("f:\\mathbb{R}^{d}\\rightarrow [0,+\\infty]")#text(" instead of ")#mi("f:\\mathbb{R}^{d}\\rightarrow [0,+\\infty)")#text("? In many of the proofs of your notes, you truncate the simple functions because it can be unbounded by the definition. What if you just “define” that the unsigned simple functions are bounded? Then does your route to setting up the Lebesgue integrals still work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-48442")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("Yes, this is an alternate way to proceed. It moves some minor difficulties elsewhere; for instance, showing that two functions have the same integral if they differ on a set of measure zero becomes very slightly more difficult if simple functions are required to be finite-valued.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-48940")[#strong[#text("245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("[…] the partial sums converge to a limit, and we can then define the infinite sum by the same formula (1) as in the unsigned case, though now the sum takes values in rather than . The absolute summability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-49208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2010")])]

#text("Dear professor Tao,")

#text("(actually I don’t know how you would like to be called)")

#text("I believe there is a mistake in the proof of lemma 7 (and I’m sorry if it is my mistake), more precisely in the statement (3) => (5).")

#text("If you take ")#mi("f_n")#text(" to be constant and equal to ")#mi("\\frac{1}{n}")#text(", clearly ")#mi("f_n \\rightarrow 0")#text(" pointwise. Take ")#mi("\\lambda = 0")#text(". For a fixed ")#mi("N")#text(" the set ")#mi("\\bigcup{n \\ge N} \\{f_n(x) > \\lambda\\}")#text(" is the whole ")#mi("\\mathbb{R}^d")#text(", so that the intersection of these sets is ")#mi("\\mathbb{R}^d")#text(", while the set of values for each ")#mi("f(x) > 0")#text(" is empty, which shows the sets are in general different, isn’t it?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-49248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Professor Tao,")

#text("In Lemma 7, how do you know the set ")#mi("\\left\\{ x \\in \\mathcal{R}^d: f_n(x) > \\lambda + \\frac{1}{M} \\right\\}")#text(", for simple functions ")#mi("f_n")#text(", is Lebesgue measurable?")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-49314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2010")])]

#text("Anonymous (above me),")

#text("by definition simple functions have finite image. Therefore, for any constant ")#mi("c")#text(", ")#mi("f^{-1}(]c, \\infty[)")#text(" is the union of a finite number of measurable sets, each of them being ")#mi("f^{-1}(t)")#text(" for some constant ")#mi("t")#text(". And each of that sets is measurable by definition.")

#text("Dear professor Tao,")

#text("(I still don’t know how you would like to be called)")

#text("In exercise 10.3, of course remembering that ")#mi("f")#text(" is not necessarily simple, I wonder if the tricky part to which you refered is not showing the equality for ")#mi("c = \\infty")#text(", for the lower integral. It seems that the upper integral case is just about proving that a countable partition of a set with nonzero exterior measure yields some sets of nonzero exterior measure. Isn’t it?")

#text("If I am correct, could you please include some hints?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-49569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2011")])]

#text("Dear professor and readers,")

#text("actually I think there is a counter example to exercise 10.3, for ")#mi("c = \\infty")#text(" (which is of course a non-measurable function ")#mi("f")#text(". That is, there is ")#mi("f: X \\rightarrow [0, \\infty]")#text(" such that ")#mi("\\int cf \\not= c\\int f")#text(".")

#text("Suppose we have found sets ")#mi("A_1, A_2, ...")#text(" such that ")#mi("\\bigcup_{i=1}^{\\infty} A_i = [0, 1]")#text(" but each ")#mi("A_1 \\cup A_2 \\cup ... A_n")#text(" contains no (measurable) set of positive measure. Take ")#mi("f = \\sum \\frac{1_{A_i}}{i}")#text(". Any nonnegative simple function that is pointwise smaller than or equals to ")#mi("f")#text(" which is ")#mi("\\geq 1/n")#text(" in a set of positive measure induces a subset of ")#mi("A_1 \\cup ... \\cup A_n")#text(" with positive measure, which cannot exist. Thus ")#mi("f")#text(" has a null integral, while ")#mi("cf")#text(" is infinite in ")#mi("[0, 1]")#text(", and we get our example.")

#text("To find such sets, take ")#mi("V")#text(" to be a Vitali set, i.e., a set which contains exactly one number in each coset ")#mi("t + \\mathbb{Q}")#text(" of the group ")#mi("\\mathbb{R} / \\mathbb{Q}")#text(". If ")#mi("(q_n)_{n \\in \\mathbb{N}}")#text(" is an enumeration of ")#mi("\\mathbb{Q}")#text(", choose ")#mi("A_n = (V + q_n) \\cap [0, 1]")#text(".")

#text("A subset of ")#mi("[0, 1]")#text(" contains no set of positive measure if and only if its complement is not contained in any set of measure smaller than 1. This is the same as saying that it has outer measure 1, by outer regularity (each measurable set is contained in open sets which approximate its measure arbitrarily much).")

#text("Thus, we ought to prove that ")#mi("A_{n + 1} \\cup A_{n + 2} ...")#text(" has outer measure 1. Here there is a result similar to Lebesgue differentiation theorem (see notes 5, and more precisely exercise 24; but the needed result is here: ")#link("http://www.artofproblemsolving.com/Forum/viewtopic.php?f=67&t=381857")[#text("http://www.artofproblemsolving.com/Forum/viewtopic.php?f=67&t=381857")]#text("). Given ")#mi("\\epsilon")#text(" and set ")#mi("S")#text(" of positive outer measure, there is an interval ")#mi("I")#text(" such that the density ")#mi("\\frac{\\mu^*(S \\cap I)}{\\mu(I)}")#text(" is ")#mi("\\geq 1 - \\epsilon")#text(". By ")#mi("\\sigma")#text("-subadditivity we may suppose ")#mi("S")#text(" bounded, so that we can cover it by open intervals whose total measure is ")#mi("\\leq 1 + \\epsilon")#text(", and the result is not hard.")

#text("We already know that ")#mi("V")#text(" has positive outer measure (exercise 25, notes 1), so that there are intervals ")#mi("I")#text(" where ")#mi("V")#text(" has a high density. Because ")#mi("\\mathbb{Q}")#text(" is dense in ")#mi("\\mathbb{R}")#text(", even if we ignore a finite set of points, for each interval ")#mi("J \\subset [0, 1]")#text(" such that ")#tao-math("\\left|I\\right| = \\left|J\\right|", block: false)#text(", there is an ")#mi("A_m")#text(" which has high density at $J$, even if we require ")#mi("m \\geq n")#text(". Furthermore, roughly speaking, it is possible to choose small ")#mi("I")#text(" and ")#mi("J")#text("s, so that ")#mi("\\bigcup_{m \\geq n}")#text(" has arbitrarily high density, and to cover ")#mi("[0, 1]")#text(" with these ")#mi("J")#text("s. The result follows.")

#text("Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-49575")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2011")])]

#text("Hmm, you’re right; I’ve amended the exercise accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/779bcda87c3c8f9c192d06559c826a81773cc29d4bb6bd8a015c78ee96e92450-de4cab180116da41f51780720c353a58f121263621b757b5054fa6879aa40285.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-78222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2011")])]

#text("Could someone explain why Em,n is lebesgue measurable (in proof of egorov thm)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-466398")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2016")])]

#text("Since fn is, then so is f (pointwise limit), then so is fn – f, then so si |fn-f|, then so is Em,n.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6497c48c5b1a229e8a9bec33cf1e49a934591e6c0201f16e57ebf4aa1d90476-8fc20c33da5ccc74f1db06091ffd6fbc912060a79609619ba4c8a51f98e2a39f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gandhi Viswanathan")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-87266")[#strong[#text("Gandhi Viswanathan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2011")])]

#text("Dear Professor Tao,")

#text("In Definition 5 above there is a minor typo:")

#text("“…to be absolutely integrable of Simp….” should be “…to be absolutely integrable if Simp….”")

#text("This typo is also in Definition 1.3.6 of the PDF version of you book on measure theory (which, along with your other books, I am greatly enjoying reading).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-131841")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2012")])]

#text("Stein/Shakarchi’s Real Analysis requires that their simple functions have finite measure support, whereas here you do not adopt any such condition. Is there any advantage gained by making this additional hypothesis for simple functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-131850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2012")])]

#text("See Remark 1. It does not matter too much what route one takes to the Lebesgue integral, as one has to deal with a fixed set of technical issues, such as horizontal and vertical truncation, additivity, convergence theorems, etc., at some point in the construction. However, the order in which these issues are encountered can depend on what route one selects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-203605")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("For the Riemann integration, I saw many times that people use ")#mi("\\int_a^b")#text(" and ")#mi("\\int_{[a,b]}")#text(" interchangeably where ")#mi("-\\infty<a<b<+\\infty")#text(". Is this always justifiable? Also, I saw people use ")#mi("\\int_{-\\infty}^{+\\infty}")#text(" when they mean ")#mi("\\int_{{\\Bbb R}}")#text(". But ")#mi("\\int_{-\\infty}^{+\\infty}")#text(" is very ambiguous. It can have at least 3 meanings: 1.")#mi("\\int_{-\\infty}^{+\\infty}=\\int_{-\\infty}^a+\\int_{a}^{+\\infty}")#text("; 2. ")#mi("\\int_{-\\infty}^{+\\infty}=\\lim_{a\\to\\infty}\\lim_{b\\to\\infty}\\int_a^b")#text("; 3. ")#mi("\\int_{-\\infty}^{+\\infty}=\\lim_{b\\to\\infty}\\int_b^b")#text(" which is called the principal value. I'm confused which one is supposed to be used. As I understand, 3 is used since 1 and 2 is not always defined and when 1 and 2 are defined, 3 should gives the same result. How can one know whether ")#mi("\\int_{-\\infty}^{+\\infty}")#text(" means ")#mi("\\int_{\\Bbb R}")#text(" or the improper integral?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-203619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("Different texts have different conventions, but personally I use ")#mi("\\int_a^b")#text(" for the Riemann integral (with the sign convention ")#mi("\\int_b^a = -\\int_a^b")#text(") and ")#mi("\\int_{[a,b]}")#text(" for the Lebesgue integral (with the two being of course compatible when integrating continuous functions; see Exercise 17 above).")

#text("For ")#link("http://en.wikipedia.org/wiki/Improper_integral")[#text("improper Riemann integrals")]#text(" such as ")#mi("\\int_{-\\infty}^\\infty f(x)\\ dx")#text(", there is no ambiguity if the integrand is either non-negative or absolutely convergent (as then one can use the Lebesgue theory to show that all the different interpretations you mention agree), but otherwise if one wants to be fully rigorous, one does indeed have to specify the precise interpretation of the integral. (Assuming that the author is sufficiently careful, though, this should indeed be the case when encountering improper integrals in a rigorous mathematical context. In looser contexts, such as in calculations done in engineering or physics, these issues might be glossed over, although in most cases one can find some way to make rigorous sense of the integrals appearing in such calculations (though in some cases one has to use the theory of distributions or some regularisation of the integral (e.g. ")#link("http://en.wikipedia.org/wiki/Zeta_function_regularization")[#text("zeta regularisation")]#text("), rather than the Riemann or Lebesgue theory of integration, to do so).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-203660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("I’m a little bit confused that in your PCM article “differential forms and integration”, you distinguish ")#mi("\\int^b_a")#text(" and ")#mi("\\int_{[a,b]}")#text(" in the Riemann integral setting. According to that article, ")#mi("\\int_a^b f(x)dx")#text(" is a signed definite integral and ")#mi("\\int_{[a,b]}f(x)dx")#text(" is an unsigned definite integral which can be generalized to integration on a measure space. Are these notations in that article interpreted differently from those in your comment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-203681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2012")])]

#text("No, the interpretations in that article and in this blog post are the same (see previous comment about the sign convention). In particular, the signed definite integral and unsigned definite integral are linked in one dimension by the identities ")#mi("\\int_a^b = \\int_{[a,b]}")#text(" and ")#mi("\\int_b^a = -\\int_{[a,b]}")#text(" for ")#mi("a<b")#text(" (when restricting attention to integrating continuous functions, at least).")

#text("The quickest way to define integration on forms is indeed by using the connection with the Riemann or Lebesgue integral on a coordinate chart, combined with a suitable partition of unity, as the definition (but then one has to check that the definition is independent of the choice of chart). It is however also possible to define integration of a form without reference to coordinates, for instance by triangulating the manifold and performing a Riemann sum construction directly.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-212719")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2013")])]

#text("Regarding the proof of Lemma 7, (3)–>(5), why would one need to introduce the ")#mi("M")#text(" in the proof? Can one use only the Lebesgue measurability of ")#mi("\\{x\\in{\\bf R}^d:f_n(x)>\\lambda\\}")#text(" to do the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-212738")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2013")])]

#text("No, this is not sufficient, because if one only knows that ")#mi("\\sup_{n \\geq N} f_n(x) > \\lambda")#text(" for all ")#mi("N")#text(", then it could be possible that ")#mi("\\lim\\sup f_n(x)")#text(" is equal to ")#mi("\\lambda")#text(", rather than being greater than ")#mi("\\lambda")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-212788")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2013")])]

#text("In Lemma 7, one has the equivalence between “pointwise convergence” and “almost every convergence”. But generally this is not true. I don’t see why. After all, (3)–>(2) is not obvious (3–>5–>4–>2). What’s the essential reason for this equivalence? To what extend can one generalize it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-212791")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2013")])]

#text("If one only want (4)–>(2), can one drop the assumption “bounded with finite measure support”? I don’t see where this is used in the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-213088")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("Regarding Lemma 7, in the proof of (5.)-(11.) implying (4.), the construction of ")#mi("f_n")#text(" seems rather artificial. Could you elaborate the intuition of such construction?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-213864")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2013")])]

#text("Regarding Exercise 10.8, hint for the unbounded case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-214037")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2013")])]

#text("It can be done by doing the simple function case and then dealing with “=” by proving “")#mi("\\leq")#text("” and “")#mi("\\geq")#text("” respectively.")

#text("I still don’t know how the claim in Exercise 10.3 can fail when ")#mi("c=+\\infty")#text(". Is it possible to find a counterexample without using anything related to axiom of choice (Or does one have to use it)?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-215151")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("I don’t quite understand the remark after Egorov’s Theorem.")

#text("“On a domain such as ")#mi("{\\bf R}^d \\backslash A")#text(", bounded-set locally uniform convergence implies open-neighbourhood locally uniform convergence, but not conversely”")

#text("In Remark 6, it is pointed out that these two definition are equivalent and it fails when the domain is where the Heine-Borel theorem does not hold.")

#text("In the wikipidia article (")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")]#text("), the Heine-Borel theorem holds for any subset ")#mi("S\\subset{\\bf R}^d")#text(". (So it should also hold for ")#mi("{\\bf R}^d \\backslash A")#text(". )")

#text("I’m lost… What do I miss here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-215160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("The notion of a closed set in the ")#link("http://en.wikipedia.org/wiki/Subspace_topology")[#text("relative topology")]#text(" of ")#mi("{\\bf R}^d \\backslash A")#text(" is not the same as the notion of a closed set in the larger space ")#mi("{\\bf R}^d")#text("; a subset of ")#mi("{\\bf R}^d \\backslash A")#text(" can be closed in the former sense but not in the latter. (For instance, ")#mi("(1,2]")#text(" is closed in ")#mi("{\\bf R} \\backslash \\{1\\}")#text(" – it contains all its limit points in that space – but not in ")#mi("{\\bf R}")#text("). So the Heine-Borel theorem need not be inherited by non-closed subpaces of ")#mi("{\\bf R}^d")#text("; for instance ")#mi("(1,2]")#text(" is closed and bounded in ")#mi("{\\bf R} \\backslash \\{1\\}")#text(" but fails to be compact.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-215220")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("OK. It is the relative topology that is used. There is still something I don’t fully understand about the “immediate equivalence” you mentioned in Remark 6.")

#text("In ")#mi("{\\bf R}^d")#text(", bounded-set notion implies open-neighborhood definition since one can take a bounded open disk center on any ")#mi("x\\in{\\bf R}^d")#text(". But in order to use Heine-Borel to show that the open-neighborhood definition implies the bounded-set one, I think one needs to take closure of a given bounded set first (which renders a compact set, i.e., closed and bounded) and then use the finite open cover properties. It follows that the open-neighborhood definition implies a compact-set definition (replacing “bounded” with “compact”). Hence the bounded-set definition implies the compact-set one. But boundedness would not imply compactness.")

#text("I somehow messe up. There must be something wrong here…")

#text("(P.S. I thinks the last sentence “since one local uniform convergence in both senses”, which is not in the textbook, in the remark paragraph after Egorov’s theorem, misses some words.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-215279")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2013")])]

#text("“thinks”—>”think”")

#text("Gah, I don’t notice that I asked a silly question until I try to write down everything. Something is true (say, uniform convergence here) on a bounded set is definitely true on a compact set. And thus the compact-set definition is a weaker one than those two (bounded-set and open-neighborhood ones).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-215728")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2013")])]

#text("Regarding Exercise 6, one can first show that it is true for any simple functions and then the bounded unsigned measurable functions (by Exercise 4 where one can use the uniform limit). This is the Trick 3 in the notes (")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text("). But how can one pass back to the general case where ")#mi("f")#text(" can be unbounded? I don’t see how one can write an unbounded measurable function as a limit/decomposition of a bounded function. (One might use Lemma 7.2 to approximate an unbounded function, but the limit is not uniform…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-217177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2013")])]

#text("If one uses MCT to prove the linearity of the integration, for example in Corollary 11, should that be viewed as invalid circular proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-227805")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2013")])]

#text("Dear Prof.Tao,")

#text("I think there is a problem to the definition 1(Simple function).I think the domain of a simple function ")#mi("f")#text(" should not be ")#mi("\\mathbf{R}^d")#text(",but should be ")#mi("\\bigcup_{1\\leq i\\leq k}E_i")#text("…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d752742258b6b08c314600551ff8705826cfa7b256f36f482398e772219bc061-8a69a378099cedb469c4ab99f655e886e13ccc3f478a895484100e8e6cc7a1d3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shen Zeng")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-227855")[#strong[#text("Shen Zeng")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2013")])]

#text("The definition is correct. Where do you see a problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-227886")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2013")])]

#text("I think only when ")#mi("\\mathbf{R}^d=\\bigcup_{1\\leq i\\leq k}E_i")#text(" then the definition would be correct,otherwise,let ")#mi("x_0\\in \\mathbf{R}^d\\backslash (\\bigcup_{1\\leq i\\leq k}E_i)")#text(",then ")#mi("f(x_0)")#text(" would be meaningless.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-227888")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2013")])]

#text("…Forgive me.I am wrong.The definition is right.……")

#text("I have a wrong understanding about indicator function…I didn’t think clearly.")

#text("Dear Shen Zeng,last time I have a stupid question about support function,then you appeared.This time I have a stupid question about support function again then you appear again.…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228081")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2013")])]

#text("I think a Riemann measurable function can be defined as follows,which is defined in a way similar to Lebesgue measurable function:")

#text("1.First,I define Riemann-simple function.This is very similar to Lebesgue-simple function(Definition 1),except that for all ")#mi("1\\leq i\\leq k")#text(", ")#mi("E_i")#text(" is Jordan measurable instead of Lebesgue measurable.And there is another difference,Riemann-simple function is from ")#mi("\\mathbf{R}^d")#text(" to ")#mi("[0,+\\infty)")#text(",but a Lebesgue-simple function is from ")#mi("\\mathbf{R}^d")#text(" to ")#mi("[0,+\\infty]")#text(".")

#text("2.Then I define Riemann measurable function to be a function which can be uniformly approximated by Riemann-simple function.")

#text("I think a function is Riemann measurable function iff it is Riemann integrable,i.e,it is coherent with the standard definition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228116")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2013")])]

#text("A remark to exercise 4:")

#text("It is amazing to see that when ")#mi("f")#text(" is bounded,then ")#mi("f")#text(" can be uniformly approximated by a list of simple functions.Although this theorem is just a easy consequence of Hein-Borel finite covering theorem and supremum principle….Regard a simple function as a finite number of points in the vertical direction,then everything will be OK.")

#text("This means when ")#mi("f")#text(" is bounded,we can also define a measurable function ")#mi("f")#text(" by means of approximation uniformly by a list of simple functions…")

#text("So the only purpose of defining a measurable function ")#mi("f")#text(" by means of approximation pointwise by a list of simple functions is to deal with the case when ")#mi("f")#text(" is unbounded…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228132")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2013")])]

#text("A remark to exercise 6:")

#text("I think exercise 6 is a good exercise.Let me guess how Lebesgue created the concept of measurable function.")

#text("Firstly,Lebesgue created the Lebesgue measurable set,which is a generalization of Jordan measurable set.I think if there is no such thing as Jordan measurable set in the mathematics,Lebesgue will not discover his measurable set easily.")

#text("Then it is evident that we should let a simple function to be measurable.Then,what should we do?")

#text("It seems that Lebesgue used an idea which is similar to analytic continuation(I havn’t learned analytic continuation,I only heard this vocabulary,so hope I am not wrong).Because the countable union and countable intersection of Lebesgue measurable set is also Lebesgue measurable,so Lebesgue defined a measurable function to be countable “intersection” and “union” of simple functions,which is exactly a function which can be point wise approximated by simple functions.No less,no more,the concept of measurable function is created exactly suited to our needs!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228263")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2013")])]

#text("A remark to Remark 3:")

#text("In constructing the L-masurable function ")#mi("f")#text(" which turns a L-measure 0 set ")#mi("E")#text(" into L-unmeasurable set ")#mi("f^{-1}(E)")#text(",I think the order preserving property is very important.")

#text("To express more explicitly,There is an order preserving bijective map from the Cantor set to ")#mi("[0,1]\\backslash \\{k\\frac{1}{2^n}:\\forall n\\in\\mathbf{N}^+,\\forall 0\\leq k\\leq 2^n\\}")#text(".This order preverving property is essential to the measurability of ")#mi("f")#text(".")

#text("In fact,this example shows the intuitive procedure that we can project an umeasurable set into a null set,this projection is order preserving and bejective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228641")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("A remark to Exercise 10(Basic properties of the lower Lebesgue")#linebreak()#text(" integral).")

#text("Exercise 10 consists of ten properties.However,I think another")#linebreak()#text(" important property should be mentioned,I call this property “Property")#linebreak()#text(" 11:The principle of correspondence and optimization”,which is invented")#linebreak()#text(" by me :-}")

#text("Now I describe the principle of correspondence and optimization in")#linebreak()#text(" detail.I think the principle of correspondence and optimazation is the")#linebreak()#text(" hidden mechanism for property 2,3,5,6,10 in exercise 10.")

#text("First I decribe the principle of correspondence and optimization in general.Let ")#mi("A")#text(" be")#linebreak()#text(" a system,let ")#mi("B")#text(" be another system.For any state ")#mi("P_A")#text(" in system ")#mi("A")#text(",there always exists a state ")#mi("P_B")#text(" in system ")#mi("B")#text(" correspoinding to")#linebreak()#text(" state ")#mi("P_A")#text(",then we say that system ")#mi("A")#text(" is more crude than system ")#mi("B")#text(",or,equivalently,system ")#mi("B")#text(" is more sophisticated than system ")#mi("A")#text(".")

#text("If any one of the two systems is more sophisticated than the")#linebreak()#text(" other,then we call these two system equi-sophisticated.")

#text("Now let me explain the reason why I use the word sophisticate.If for")#linebreak()#text(" any state in ")#mi("A")#text(",there is always a state in ")#mi("B")#text(" correspoinding to")#linebreak()#text(" it,but for any state in ")#mi("B")#text(",there is not neccessarily a state in ")#mi("A")#linebreak()#text(" that correspoinding to that state in ")#mi("B")#text(",then we can regard")#linebreak()#text(" system ")#mi("A")#linebreak()#text(" equi-sophisticated to part of the system ")#mi("B")#text(",suppose that ")#mi("A")#text(" is equi-sophisticated to")#linebreak()#text(" ")#mi("B^{\\prime}\\subseteq B")#text(".So the remaining of ")#mi("B")#text(" has the potential to be more")#linebreak()#text(" optimized then ")#mi("A")#text(",just like Pareto improvement in economy.so we call ")#mi("B")#text(" is more sophisticated than ")#mi("A")#text(".")

#text("To explain my general dicussion ,now we look at a concrete")#linebreak()#text(" example.Let’s see property 10 in exercise 10 for example.This property")#linebreak()#text(" is stated as follows:")

#text("(Reflection) If ")#mi("f+g")#text(" is a simple function that is bounded with")#linebreak()#text(" finite measure support (i.e. it is absolutely integrable), then ")#mi("\\text{Simp} \\int_{{\\bf R}^d} f(x)+g(x)\\ dx = \\underline{\\int_{{\\bf       R}^d}} f(x)\\ dx + \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx")#text(".")

#text("Let system ")#mi("A")#text(" be the set of simple functions ")#mi("\\{f_{A}:f_{A}(x)\\leq f(x)\\}")#text(",Let system ")#mi("B")#text(" be the set of simple functions")#linebreak()#text(" ")#mi("\\{g_B:g_B(x)\\geq g(x)\\}")#text(". For any simple function ")#mi("f_{A}")#text(" in system")#linebreak()#text(" ")#mi("A")#text(",it is easy to verify that ")#mi("f+g-f_A")#text(" is a simple function in system")#linebreak()#text(" ")#mi("B")#text(".And for any simple function in system ")#mi("B")#text(",it is easy to verify")#linebreak()#text(" that ")#mi("f+g-f_B")#text(" is a simple function in system ")#mi("A")#text(".So system ")#mi("A")#text(" is")#linebreak()#text(" more sophisticated than system ")#mi("B")#text(",and system ")#mi("B")#text(" is more sophisticated than system ")#mi("A")#text(",so they are equi-sophisticated.So ")#mi("\\text{Simp} \\int_{{\\bf R}^d} f(x)+g(x)\\ dx = \\underline{\\int_{{\\bf       R}^d}} f(x)\\ dx + \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx")#text(".")

#text("Let’s look at property 5 in exercise 10 for another example.")

#text("(Superadditivity) ")#mi("\\underline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\geq \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\underline{\\int_{{\\bf R}^d}} g(x)\\ dx")#text(".")

#text("Let system ")#mi("A")#text(" be the set of simple functions ")#mi("\\{f_{A}:f_{A}(x)\\leq f(x)\\}")#text(",let system ")#mi("B")#text(" be the set of simple functions")#linebreak()#text(" ")#mi("\\{g_B:g_B(x)\\leq g(x)\\}")#text(".Let ")#mi("C")#text(" be the set of simple functions")#linebreak()#text(" ")#mi("\\{f_C:f_C(x)\\leq f(x)+g(x)\\}")#text(".It is easy to verify that ")#mi("\\forall f_A\\in A,g_B\\in B")#text(",")#mi("f_A+g_B")#text(" must be in ")#mi("C")#text(".But for any ")#mi("f_C\\in C")#text(",it")#linebreak()#text(" is not necessarily that there exists ")#mi("f_A\\in A,g_B\\in B")#text(",such that")#linebreak()#text(" ")#mi("f_C=f_A+f_B")#text("(Why?),so ")#mi("\\underline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\geq \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\underline{\\int_{{\\bf       R}^d}} g(x)\\ dx")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228688")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2013")])]

#text("Dear Prof.Tao,")

#text("In exercise 10,(9),(Vertical truncation),in the hint,you say:”From Exercise 9 of Notes 1, we have ")#tao-math("m( E \\cap \\{ x: \\left|x\\right| \\leq n \\}) \\rightarrow m(E)", block: false)#text(" for any measurable set ")#mi("E")#text(". ”")

#text("But I can’t see anything special about Exercise 9 of Notes 1(Jordan measurable sets are Lebesgue measurable),Instead,I think it is monotone convergence theorem of measurable sets that plays the central role…")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228861")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("A remark to Exercise 10,(8)(Horizontal truncation) .")

#text("I think the property of Horizontal truncation should also make use of monetone convergence theorem of measurable sets,which is similar to Vertical truncation.")

#text("The only difference is that Horizontal truncation make use of the monetone convergence theorem of measurable sets in the perpendicular to X direction,but the Vertical trucation make use of the monetone convergence theorem of measurable sets in the perpendicular to Y direction.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228852")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("A generalization to exercise 10,(5),(6).(5) and (6) is stated as")#linebreak()#text(" follows:")

#text("(Superadditivity) ")#mi("\\underline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\geq \\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\underline{\\int_{{\\bf       R}^d}} g(x)\\ dx")#text(".")

#text("(Subadditivity of upper integral) ")#mi("\\overline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\leq \\overline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\overline{\\int_{{\\bf R}^d}} g(x)\\ dx")#text(".")

#text("In order to generalize,let me introduce some new definitions first.Let")#linebreak()#text(" ")#mi("f: {\\bf R}^d \\rightarrow [0,+\\infty]")#text(" be an unsigned function")#linebreak()#text(" (not necessarily measurable). We define the lower unsigned integral")#linebreak()#text(" ")#mi("\\#\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx")#text(" to be the quantity")

#mi("\\displaystyle \\#\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx := \\sup_{0 \\leq g \\leq f; g ~\\text{is~ unsined~measurable}}\\int_{{\\bf     R}^d} g(x)\\ dx")#text(".")

#text("where ")#mi("g")#text(" ranges over all unsigned measurable functions ")#mi("g: {\\bf R}^d \\rightarrow [0,+\\infty]")#text(" that are pointwise bounded by")#linebreak()#text(" ")#mi("f")#text(".")

#text("One can also define the upper unsigned Lebesgue integral")

#mi("\\displaystyle \\#\\overline{\\int_{{\\bf R}^d}} f(x)\\ dx := \\inf_{h   \\geq f; h ~\\text{is~measurable}}\\int_{{\\bf R}^d} h(x)\\ dx")#text(".")

#text("With this definition,now I think we can say that")

#text("(additivity) ")#mi("\\#\\underline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\geq \\#\\underline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\#\\underline{\\int_{{\\bf       R}^d}} g(x)\\ dx")#text(".")

#text("(additivity of upper integral) ")#mi("\\#\\overline{\\int_{{\\bf R}^d}} f(x)+g(x)\\ dx \\leq\\#\\overline{\\int_{{\\bf R}^d}} f(x)\\ dx + \\#\\overline{\\int_{{\\bf R}^d}} g(x)\\ dx")#text(".")

#text("In fact,I think the proof is easy with the help of Exercise 11,and")#linebreak()#text(" Exercise 10,(5),(6).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228863")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("A remark to exercise 11:")

#text("Now I answer the question left in exercise 11:")

#text("I think that if ")#mi("f")#text(" is allowed to be unbounded, or is not supported inside a set of finite measure,then the lower Lebesgue integral and upper Lebesgue integral of ")#mi("f")#text(" still agree.")

#text("In order to prove this ,I think I should make use of the Verticle truncation and Horizontal truncation in Exercise 10.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-228971")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2013")])]

#text("A solution to Exercise 12 (Upper Lebesgue integral and outer Lebesgue measure).")

#text("Prove that :")

#text("Show that for any set ")#mi("E \\subset {\\bf R}^d, \\overline{\\int_{{\\bf R}^d}} 1_E(x)\\ dx = m^*(E)")#text(".")

#text("For any set ")#mi("E\\in\\mathbf{R}^d")#text(",let the set ")#mi("A")#text(" be ")#mi("\\{U:U~\\text{is}~\\text{open},E\\subseteq U\\}")#text(".Denote the intersection of all the elements of ")#mi("A")#text(" to be ")#mi("\\bigcap A")#text(".It is easy to verify that ")#mi("\\bigcap A")#text(" is a measurable set,and ")#mi("m(\\bigcap A)=m*(E)")#text(".")

#text("And it is easy to verify that ")#mi("\\overline{\\int_{{\\bf R}^d}} 1_E(x)\\ dx=m(\\bigcap A)")#text(".Done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-229049")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2013")])]

#text("A remark to Exercise 14:")

#text("I think the property of finite additivity is not neccessary.Finite additivity implies monotonicity:It is monotonicity that is actually used.")

#text("For unsigned measurable function ")#mi("f,g")#text(",if for almost every point ")#mi("x")#text(",")#mi("f(x)\\leq g(x)")#text(",then ")#mi("\\int_{\\mathbf{R}^d}f(x)\\leq \\int_{\\mathbf{R}^d}g(x)")#text(".")

#text("This is the property of monotonicity.I think if monotonnicity replace finite additivity,then the Exercise still holds.")

#text("As for the Horizontal and and Vertical truncation,their usage is to extend the L-integral of finite support and bounded function ")#mi("f")#text(" to infinite in both the Horizontal and Vertical direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-229678")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("A question comes to me when I was trying to solve Exercise 16(Linear change of variables).")

#text("When ")#mi("f:[a,b]\\to [0,+\\infty)")#text(" is Riemann integrable,suppose the")#linebreak()#text(" Riemann integration of ")#mi("f")#text(" on the interval ")#mi("[a,b]")#text(" is")#linebreak()#text(" ")#mi("\\mathbf{Riemann}\\int_{[a,b]}f(x)dx")#text(".Let ")#mi("\\{m_0,\\cdots,m_n\\}")#text(" be a set")#linebreak()#text(" of partitioning point of the interval ")#mi("[a,b]")#text(",and ")#mi("m_0=a,m_n=b")#text(".")#linebreak()#text(" ")#mi("x_i")#text(" be an arbitrary real number in the interval ")#mi("[m_i,m_{i+1}]")#text(",then")#linebreak()#text(" it is easy to verify that ")#mi("\\displaystyle \\sum_{i=0}^{n-1}f(x_i)(m_{i+1}-m_i)\\to \\mathbf{Riemann}\\int_{[a,b]}f(x)dx")#text(" when ")#mi("\\forall 0\\leq j\\leq n-1")#text(",")#mi("m_{j+1}-m_j\\to 0")#text(".")

#text("There is a similar result to Lebesgue integration.When")#linebreak()#text(" ")#mi("f:\\mathbf{R}\\to [0,+\\infty]")#text(" is Lebesgue measurable,suppose the")#linebreak()#text(" Lebesgue integration of ")#mi("f")#text(" on the set ")#mi("\\mathbf{R}")#text(" is")#linebreak()#text(" ")#mi("\\mathbf{Lebesgue}\\int_{[a,b]}f(x)dx")#text(".Let")#linebreak()#text(" ")#mi("G_1,G_2,\\cdots,G_n,\\cdots")#text("be a sequence of measurable sets,and that")#linebreak()#text(" ")#mi("\\bigcup_{j=1}^{\\infty}G_i=\\mathbf{R}")#text(".Now,")#mi("\\forall j\\in\\mathbf{N}^{+}")#text(",let ")#mi("m(G_j)\\to 0")#text(".And let ")#mi("x_i")#text(" be an arbitrary")#linebreak()#text(" real number on the set ")#mi("G_i")#text(".Do we have")#linebreak()#text(" ")#mi("\\sum_{i=1}^{\\infty}f(x_i)m(G_i)\\to \\mathbf{Lebesgue}\\int_{\\mathbf{R}}f(x)dx")#text(" when ")#mi("\\forall j\\in\\mathbf{N}^{+}")#text(",")#mi("m(G_j)\\to 0")#text("?")

#text("Once I solve this question(Maybe this question is wrong),then Exercise 16 can be easily solved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-229680")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2013")])]

#text("I lose an additonal hypothythese,now I add it:")#mi("\\forall i\\neq j")#text(",")#mi("G_i\\bigcap G_j=\\emptyset")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-230138")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2013")])]

#text("When I was solving lemma 12(Markov’s inequality),a problem came into my mind，prove or disprove it:")

#text("Let ")#mi("f:\\mathbf{R}\\to\\mathbf{R}")#text(" be Lebesgue measurable,and which is pointwise approximated by simple functions ")#mi("f_1,f_2,\\cdots,f_n,\\cdots")#text(".For any real number ")#mi("a")#text(" and positive real number ")#mi("\\varepsilon")#text(",there exists positive integer ")#mi("k")#text(" such that ")#tao-math("\\displaystyle \\left|m({x:f_k(x)>=a})-m({x:f(x)>=a})\\right|<\\varepsilon", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-230723")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("Fistly I fix this question.I should have added the additional hypothythese that ")#mi("m(x:f_k(x)\\geq a)")#text(" should be finite.")

#text("Now I disprove this question after it is fixed.The counterexample is in Remark 7—— moving bump.I think moving bump is an interesting example,it is as matter of fact a relationship between the reality and potential.")#mi("f\\equiv 0")#text(" is approximated by ")#mi("f_n:= 1_{[n,n+1]}")#text(",this is the reality.But ")#mi("f\\equiv 0")#text(" can be approxiamted by ")#mi("f_n=0")#text(",this is the potential.")

#text("So if I change my question in this way,then it will be true:")

#text("Let ")#mi("f:\\mathbf{R}\\to\\mathbf{R}")#text(" be Lebesgue measurable,then there")#linebreak()#text(" exists a sequence of simple functions ")#mi("f_1,f_2,\\cdots,f_n,\\cdots")#linebreak()#text(" which convergent pointwise to ")#mi("f")#text(" ,such that for any real number ")#mi("a")#text(" and positive real number ")#mi("\\varepsilon")#text(" which makes ")#mi("m(x:f_k(x)\\geq a)")#text(" finite,there exists positive integer k such that ")#tao-math("\\displaystyle \\left|m({x:f_k(x)\\geq a})-m({x:f(x)\\geq a})\\right|\\leq \\varepsilon", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-230307")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2013")])]

#text("A remark to Lemma 14 (Triangle inequality) .")

#text("I enjoy Mr.Tao’s proof of this lemma very much.It is a beautiful,elegant proof!I love this proof very much!")

#text("In fact,I prove it in somewhat different way,first,I approximate ")#mi("f")#text(" by simple functions,then I prove the triangle inequality for simple functions.")

#text("But Mr.Tao’s proof is really an amazing proof,in fact,Mr.Tao’s proof has a strong geometric meaning,that is,the smallest path between twp point is a line,because any curve (or polyline) through the two points can project on the line,and the function of projection can only make the length shorter !")

#text("Especially I enjoy the formula")

#tao-math("\\displaystyle \\left|\\int_{{\\bf R}^d} f(x)\\ dx\\right| = e^{i\\theta} \\int_{{\\bf R}^d} f(x)\\ dx = \\int_{{\\bf R}^d} e^{i\\theta} f(x)\\ dx", block: false)

#text("This formula strongly reminds me of Fourier transform(Which I only learned from Mr.Tao’s Analysis II),so I think this formula combined with my geometric meaning will give me a very vivid geometric meaning about Fourier transform!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-230567")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("A remark to Theorem 17 (Egorov’s theorem):")

#text("I proved this theorem myself.Now I provide my general idea for proving this theorem.For sake of convenience,I take ")#mi("f")#text(" as a function from ")#mi("\\mathbf{R}")#text(" to ")#mi("\\mathbf{R}")#text(".")

#text("For any point ")#mi("x_0\\in\\mathbf{R}^d")#text(",and any ")#mi("\\varepsilon>0")#text(", If ")#mi("f")#text(" is bounded on ")#mi("(x_0-\\varepsilon,x_0+\\varepsilon)")#text(",then let it be.")

#text("If ")#mi("f")#text(" is not bounded on ")#mi("(x_0-\\varepsilon,x_0+\\varepsilon)")#text(",then let ")#mi("\\varepsilon")#text(" be as small")#linebreak()#text(" as possible,if when ")#mi("\\varepsilon>0")#text(" is small enough so that ")#mi("f")#linebreak()#text(" becomes bounded on ")#mi("(x_0-\\varepsilon,x_0+\\varepsilon)")#text(",then let it be,in such case,we call ")#mi("x_0")#text(" as “not real infinity point”.If")#linebreak()#text(" ")#mi("\\varepsilon")#text(" becomes “arbitrarily” small but ")#mi("f")#text(" still keeps unbounded on ")#mi("(x_0-\\varepsilon,x_0+\\varepsilon)")#text(",then just let ")#mi("\\varepsilon")#text(" be small enough,in this case,we call ")#mi("x_0")#text(" as “real infinity point”.")

#text("In doing so,we will separate all those open interval in ")#mi("\\mathbf{R}^d")#text(" on which ")#mi("f")#text(" tends to infinity,and because we let ")#mi("\\varepsilon")#text(" be small enough,the region we separated has measure as small as")#linebreak()#text(" possible(Why?hint:consider the trick give yourself an epsilon of room")#linebreak()#text(" ")#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")[#text("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")]#text(").")

#text("Now we consider those open interval on which ")#mi("f")#text(" is bounded.According to ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/#comment-228116")[#text("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/#comment-228116")]#text(" It is easy to verify that on those interval,")#mi("f_n")#text(" converges uniformly to ")#mi("f")#text(".")

#text("So the Egorov’s theorem is proved!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/comment-page-1/#comment-230763")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2013")])]

#text("A remark to Egolov’s theorem:")

#text("My above comment prove Egolov’s theorem,however,my writing is bad,and")#linebreak()#text(" lose several key point.")

#text("In my opinion,the key words of proving Egolov’s theorem is “localize")#linebreak()#text(" and minimize”.We localize the region on which ")#mi("f")#text(" tends to infinity so as to make use of the downward monotone convergence theorem(In order to manage it successfully,we must make use of the regularity of ")#mi("f")#text(",because ")#mi("f")#text(" can be pointwise approximated by a sequence measurable functions,so ")#mi("f")#text(" itself must be measurable.Measurable function is lovely,it is very regular,i.e,it can be pointwise approximated by simple functions),after that,we use the trick “give yourself an epsilon of room”,to minimize the region on which ")#mi("f")#text(" tends to infinity.")

#text("We also localize the region on which ")#mi("f")#text(" is bounded,to avoid such case as “escape to horizontal infinity” happen.")
]
]
