// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/
// Converted to Typst by tao2typ: "2026-11-08T13:41:06.379307+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The mathematical sciences in an AI-enabled world", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The mathematical sciences in an AI-enabled world")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")[#text("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-08 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://www.acadmathsci.org.uk/")[#text("Academy for the Mathematical Sciences")]#text(", which is based in the UK, has ")#link("https://www.acadmathsci.org.uk/the-mathematical-sciences-in-an-ai-enabled-world-acadmathsci-shares-new-preprint/")[#text("released a report")]#text(" “")#link("https://www.acadmathsci.org.uk/wp-content/uploads/2026/10/Mathematical_Sciences_AI_AcadMathsSci_Oct2026_preprint_final.docx.pdf")[#text("The mathematical sciences in an AI-enabled world")]#text("“. To quote from the release:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper examines how recent advances in artificial intelligence are changing mathematical research and its applications, bringing new opportunities for discovery, verification and the use of mathematics across science, industry and society. It also considers the risks associated with these developments and identifies the support and infrastructure needed to realise the opportunities while addressing the challenges.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances. Identifying promising questions, providing key ideas, assessing the reliability of AI-generated results, developing mathematical understanding and translating discoveries into wider use will remain essential.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper identifies priorities for the community, including education and skills, independent verification, access to AI capabilities, research assessment, publication and the infrastructure needed to support mathematical knowledge. It sets out areas for action in the near term and over the coming years.")
]

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-698978")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances.")
]

#text("I can attest to this. As an experiment, I had codex (Astra-6-Max) try and prove irrationality of β(4). 17 iterations and around 48 agent-hours later, codex finally threw in the towel: “we need a specialist to make further progress”. To be clear, in codex’s opinion, we’re still not remotely close to a proof.")

#text("I don’t have access to a specialist so codex is writing it up as a negative result which I will upload to github. Hopefully it will be useful to others.")

#text("This may be a new avenue for publication by agents. Negative results can save a lot of (costly) model time. I burned through all the free resets OpenAI have been granting users, and swapped between personal and business accounts to give the models more time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699076")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Following up: the writeup is now available in a ")#link("https://github.com/twinheterodox/beta4")[#text("β(4) github research repository")]#text(".")

#text("The ")#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/output/pdf/beta4-determinant-obstructions.pdf")[#text("main paper")]#text(" (21 pages) proves obstruction results for two specified infinite families of positive determinants.")

#text("A ")#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/output/pdf/beta4-investigations.pdf")[#text("technical supplement")]#text(" (67 pages) documents the broader investigation, distinguishing further proved obstructions from unfinished approaches and identifying the missing steps. Source, code and supporting records are included.")

#text("The math was all Astra-6-Max. Roughly 48 agent-hours total.")

#text("The papers were prepared with codex on Astra-6-Max as well, with editing by me. I put a fair bit of effort into making the first one relatively readable. Not so much the second one (but did have codex try and emulate our efforts in the first). The papers and code have been independently cross-checked by another model.")

#text("My hope is that making the unsuccessful work explicit and reproducible will save others, including agents, from repeating it, and provide a starting point for further work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df060cdc34290ad6899b266136c6c43e7e8e336d2c540709a57b55fe7eedb950-2fc2b31a32ea88c94bceb18b41af24d73be2029982bd140154179b8841f561e6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Russell")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699113")[#strong[#text("Kevin Russell")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Thanks for publishing the dead end; that’s the part most people bury, and it’s often the most useful. One suggestion from our own work: having a second model agree is a good filter, but it isn’t independent the way a re-run is. Where the obstruction results come down to finite checks, a script that replays them in exact arithmetic lets a reader confirm them without trusting either model. We keep our own retracted and weakened claims on the public record for the same reason you give: it saves the next person the cost.")

#text("— Kevin Russell")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699122")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Thanks Kevin. The model cross-check usually checks the calculations a different way if it can. We do already include ")#link("https://github.com/twinheterodox/beta4/blob/main/checks/README.md")[#text("reproducible exact-arithmetic and interval checks")]#text(", with ")#link("https://  github.com/twinheterodox/beta4/blob/main/checks/SUPPLEMENT.md")[#text("additional certificates for the supplement")]#text(".")

#text("I just uploaded a new, positive result:")

#text("For every sufficiently large even integer s,")

#mi("\\dim_{\\mathbb{Q}}\\mathrm{span}_{\\mathbb{Q}}\\{\\beta(2),\\beta(4),\\ldots,\\beta(s)\\}\\geq 0.21\\sqrt{\\frac{s}{\\log s}}")

#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/even-beta-independence/output/pdf/even-beta-independence.pdf")[#text("Paper (PDF)")]#text(" · ")#link("https://github.com/twinheterodox/  beta4/tree/main/even-beta-independence")[#text("Source and exact checks")]#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df060cdc34290ad6899b266136c6c43e7e8e336d2c540709a57b55fe7eedb950-2fc2b31a32ea88c94bceb18b41af24d73be2029982bd140154179b8841f561e6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Russell")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699156")[#strong[#text("Kevin Russell")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Thanks, and my mistake for missing checks/README. That’s exactly the kind of replay I meant, and it’s good to see the interval certificates for the supplement too. Congratulations on the even-s result; I’ll take a look at the source and the exact checks.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699162")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2026")])]

#text("Check the latest version of the even-s result. Math is the same, but exposition is much improved. I realized that a large obstacle to improved exposition is that the AI does not have a good model of human limitations relative to its own mathematical ability. I now have the following background instructions for exposition:")

#text("Mathematical exposition for human readers")

#text("Recorded 3 November 2026")

#text("The purpose of mathematical exposition is to help the intended human reader acquire an understanding of the argument. An AI’s ability to follow or verify a manuscript is an inadequate test of that purpose.")

#text("There is an asymmetry in the burden of reconstructing an argument. AI can often understand both carefully explained mathematics and compressed mathematics whose author made little effort to guide a human reader. It can silently recover motivation, supply intermediate steps, connect distant definitions, and reverse-engineer the purpose of a construction. A human reader must spend attention on that reconstruction while also learning the mathematics. The author should put the essential connections into the text.")

#text("This observation concerns the demands of reading. It does not require assigning intuition or creativity exclusively to humans, or attributing expert research judgment to every human with mathematical training. Choose an intended audience and make the prerequisites explicit. Write so that a reader with those prerequisites can build the needed mental model in the order the argument is presented.")

#text("The central editorial question is:")

#text("What did I supply silently while reading that the manuscript ought to supply explicitly?")

#text("Apply the following principles when drafting or revising.")

#enum(start: 1, 
[#text("Give the reader a purpose before introducing machinery.")]
)

#text("Explain the current goal, the obstacle, and what the next construction must accomplish. Introduce its notation after establishing that need. A definition can be precise yet leave its reader unable to see why it belongs in the proof.")

#enum(start: 2, 
[#text("Build a mental model before presenting a complicated general formula.")]
)

#text("Use a small worked case when it exposes a new mechanism. Show what changes, what stays fixed, and how the construction meets its goal. The general formula should then express an operation the reader already recognizes. Examples should illuminate the mechanism rather than merely substitute numbers into a finished formula.")

#enum(start: 3, 
[#text("Keep the proof’s central ideas visible.")]
)

#text("Distinguish the decisive insight from the algebra that implements it. Organize calculations into stages with recognizable purposes. At a major transition, say what has been established and what it enables. Make the dependency between stages visible without requiring the reader to keep every formula active at once.")

#enum(start: 4, 
[#text("Respect sequential reading.")]
)

#text("At each point, use only the concepts and notation already introduced, together with the stated prerequisites. An informal preview should define the roles of any symbols it needs. Avoid making readers read ahead to discover a construction’s purpose and then reinterpret the earlier pages. Repeat the meaning of a symbol when a distant return to it would otherwise require searching backwards.")

#enum(start: 5, 
[#text("Explain the choices that control the argument.")]
)

#text("State why an evaluation point, change of variable, derivative range, normalization, or parameter scale is useful. Show the relevant gain and cost. Identify which features are essential and which are convenient choices. Readers should understand why a construction has its shape, even when discovering it independently would be difficult.")

#enum(start: 6, 
[#text("Make essential connections explicit and keep routine work compact.")]
)

#text("Add prose where it removes an inference the reader would otherwise have to discover. Remove repetition and commentary that do not advance understanding. More explanation does not automatically mean more length: reorganizing a passage around its main idea can make it both shorter and clearer.")

#enum(start: 7, 
[#text("Review correctness and exposition separately.")]
)

#text("Checking identities, hypotheses, references, and limiting arguments addresses correctness. Review exposition by tracking the reader’s knowledge, local goal, and conceptual burden at each stage. Successful AI verification does not establish human readability. Preserve the mathematical claim and all necessary conditions when simplifying.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/610c305c5a89f7a5031c7ec6bc8ddb6d91d521994e86d8363c06a3ce953e68cc-8aab02501278ed1ae21b91bbf2eb5e337a6f723c99915386207d17de6af92b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marx")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-698989")[#strong[#text("Marx")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#text("Yeah, great, keep alienating more human capital/labour for ai corps, so that one day they simply will not need you any more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ec2f78ceb57d9bd64b34cc4b78429f1c5eac54c83816135c602986374a75021-e038760ba298b6b7b263cacae9f591e1977f4216ef31f5659d7913e113c583d0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-698996")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Reading the UK Academy for the Mathematical Sciences preprint and the Harvard CMSA report highlights what is still needed to connect AI capabilities to applied mathematics.")

#text("The UK report gives a thorough snapshot of what 2026 agentic harnesses can and cannot do, and its summary rightly notes that “translating discoveries into wider use will remain essential.” Section 4.7 also makes an important start on the human and technical infrastructure needed: calling for sustained support for “maintainers, reviewers and research software engineers” and for building “equivalent infrastructure for statistics, OR and applied mathematics: reproducible code and data artefacts, and open validation environments.”")

#text("What the report mentions, but does not yet lay out, is the ")#emph[#text("mechanism")]#text(" of translation, especially in relation to the long history of computer-aided research in mathematics, the role of High-Performance Computing and Data infrastructure in the application of mathematics, and how the next generation of mathematically fluent Research Software Engineers (RSEs) is to be trained.")

#text("In applied mathematics, every idealized model carries “applicability debt”: essentially the difference between the model and the concrete application that it is meant to address. Similarly, mathematical methods must be made concrete if they are to be actually used to solve problems. Managing this translation involves three activities: assessment (abstract “how well does this work?” and concrete “how much does this help?”), adaptation (functional adaptation of the model to the problem and formal adaptation of the software to the computing environment), and adoption, sustained by a web of skills including applied mathematics, domain specialist skills, and research software engineering.")

#text("By coincidence, just before seeing this post, I uploaded a monograph to Zenodo examining this mechanism of translation, and addressing skill development and computing infrastructure from an Australian perspective.")

#text("See “What Does It Mean to Apply Mathematics in Australia Today?” at ")#link("https://doi.org/10.5281/zenodo.23838583")[#text("https://doi.org/10.5281/zenodo.23838583")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b2471604c8902ec9746d53afa441873dadc9012b5022d6ff0bc83852a9993e-b8d80f565218ccfbd08a65971f9e4d3de692f80225ef4b30178db5d2e2c01251.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-698997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("The Renaissance Foundation and XTX markets are not philanthropic organizations, neither is the Simons Foundation, which even owns the pro-AI magazine (Quanta).")

#text("All of these have been invested in machine learning in trading for a long time.")

#text("Even when the misanthropic “Anthropic” company chose the propaganda name, “philanthropic” still means pro-human and not replacing humans with machines.")

#text("At least in hard copies of the OED that Silicon Valley cannot modify.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/#comment-699000")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("This was informative.")

#text("This caught my eye:")

#emph[#text("‘Graduate labour market. Replacing students and postdocs with agentic AI set-ups would cut off the pipeline of young researchers and leave a shortfall of highly skilled graduates, not only for mathematical jobs but in all the areas where PhDs in the mathematical sciences are valued. AI may remove the entry-level roles through which mathematical sciences graduates traditionally build expertise outside academia. Mitigation: support PhD training and positions for early-career researchers; work with employers on what AI-fluent mathematical graduates offer, and on structured routes into work.’")]

#text("The risk identified is an honest one. The mitigation strategy raised some questions for me – are there existing strong channels of communication between mathematical societies and employers, through which one may persuade firms to hire young mathematical scientists? Is the hope to expand existing structured routes into work?")

#text("If the mathematical societies indeed have strong connections to industry, it would also be valuable to ask such firms: what skills are they expecting of their new mathematical-sciences hires? We may -guess-, but it could be useful to at least ask.")

#text("Impressionistically, in some countries the links between industry and mathematics departments via internships and joint research opportunities with student are stronger than in others.")

#text("– Nilima Nigam")
]
