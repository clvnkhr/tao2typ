// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/
// Converted to Typst by tao2typ: "2026-11-01T13:39:57.220891+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The mathematical sciences in an AI-enabled world", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The mathematical sciences in an AI-enabled world")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")[#text("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-01 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://www.acadmathsci.org.uk/")[#text("Academy for the Mathematical Sciences")]#text(", which is based in the UK, has ")#link("https://www.acadmathsci.org.uk/the-mathematical-sciences-in-an-ai-enabled-world-acadmathsci-shares-new-preprint/")[#text("released a report")]#text(" “")#link("https://www.acadmathsci.org.uk/wp-content/uploads/2026/10/Mathematical_Sciences_AI_AcadMathsSci_Oct2026_preprint_final.docx.pdf")[#text("The mathematical sciences in an AI-enabled world")]#text("“. To quote from the release:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper examines how recent advances in artificial intelligence are changing mathematical research and its applications, bringing new opportunities for discovery, verification and the use of mathematics across science, industry and society. It also considers the risks associated with these developments and identifies the support and infrastructure needed to realise the opportunities while addressing the challenges.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances. Identifying promising questions, providing key ideas, assessing the reliability of AI-generated results, developing mathematical understanding and translating discoveries into wider use will remain essential.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper identifies priorities for the community, including education and skills, independent verification, access to AI capabilities, research assessment, publication and the infrastructure needed to support mathematical knowledge. It sets out areas for action in the near term and over the coming years.")
]

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698978")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances.")
]

#text("I can attest to this. As an experiment, I had codex (Astra-6-Max) try and prove irrationality of β(4). 17 iterations and around 48 agent-hours later, codex finally threw in the towel: “we need a specialist to make further progress”. To be clear, in codex’s opinion, we’re still not remotely close to a proof.")

#text("I don’t have access to a specialist so codex is writing it up as a negative result which I will upload to github. Hopefully it will be useful to others.")

#text("This may be a new avenue for publication by agents. Negative results can save a lot of (costly) model time. I burned through all the free resets OpenAI have been granting users, and swapped between personal and business accounts to give the models more time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e2d2ec72f139ade45f18d213f32638eb808b8147ec5045666eeac8f89314d11-bf4f623534463971c22c2797770b4533128721c4fda5b9ff6b4f8f50d9f4554e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marx")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698989")[#strong[#text("Marx")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#text("Yeah, great, keep alienating more human capital/labour for ai corps, so that one day they simply will not need you any more.")
]
