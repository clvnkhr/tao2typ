// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/
// Converted to Typst by tao2typ: "2026-11-03T14:31:20.976858+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The mathematical sciences in an AI-enabled world", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The mathematical sciences in an AI-enabled world")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")[#text("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-03 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The ")#link("https://www.acadmathsci.org.uk/")[#text("Academy for the Mathematical Sciences")]#text(", which is based in the UK, has ")#link("https://www.acadmathsci.org.uk/the-mathematical-sciences-in-an-ai-enabled-world-acadmathsci-shares-new-preprint/")[#text("released a report")]#text(" “")#link("https://www.acadmathsci.org.uk/wp-content/uploads/2026/10/Mathematical_Sciences_AI_AcadMathsSci_Oct2026_preprint_final.docx.pdf")[#text("The mathematical sciences in an AI-enabled world")]#text("“. To quote from the release:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper examines how recent advances in artificial intelligence are changing mathematical research and its applications, bringing new opportunities for discovery, verification and the use of mathematics across science, industry and society. It also considers the risks associated with these developments and identifies the support and infrastructure needed to realise the opportunities while addressing the challenges.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances. Identifying promising questions, providing key ideas, assessing the reliability of AI-generated results, developing mathematical understanding and translating discoveries into wider use will remain essential.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("The paper identifies priorities for the community, including education and skills, independent verification, access to AI capabilities, research assessment, publication and the infrastructure needed to support mathematical knowledge. It sets out areas for action in the near term and over the coming years.")
]

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698978")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("A central theme is that, as AI becomes increasingly capable of carrying out technical mathematical work, human expertise will be crucial to direct advances.")
]

#text("I can attest to this. As an experiment, I had codex (Astra-6-Max) try and prove irrationality of β(4). 17 iterations and around 48 agent-hours later, codex finally threw in the towel: “we need a specialist to make further progress”. To be clear, in codex’s opinion, we’re still not remotely close to a proof.")

#text("I don’t have access to a specialist so codex is writing it up as a negative result which I will upload to github. Hopefully it will be useful to others.")

#text("This may be a new avenue for publication by agents. Negative results can save a lot of (costly) model time. I burned through all the free resets OpenAI have been granting users, and swapped between personal and business accounts to give the models more time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-699076")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Following up: the writeup is now available in a ")#link("https://github.com/twinheterodox/beta4")[#text("β(4) github research repository")]#text(".")

#text("The ")#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/output/pdf/beta4-determinant-obstructions.pdf")[#text("main paper")]#text(" (21 pages) proves obstruction results for two specified infinite families of positive determinants.")

#text("A ")#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/output/pdf/beta4-investigations.pdf")[#text("technical supplement")]#text(" (67 pages) documents the broader investigation, distinguishing further proved obstructions from unfinished approaches and identifying the missing steps. Source, code and supporting records are included.")

#text("The math was all Astra-6-Max. Roughly 48 agent-hours total.")

#text("The papers were prepared with codex on Astra-6-Max as well, with editing by me. I put a fair bit of effort into making the first one relatively readable. Not so much the second one (but did have codex try and emulate our efforts in the first). The papers and code have been independently cross-checked by another model.")

#text("My hope is that making the unsuccessful work explicit and reproducible will save others, including agents, from repeating it, and provide a starting point for further work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a989836e67e21e16c9aa2ce6a7cc124d741c8cbe532f05ef59774758538bc11-21fdbc77968d114cd99bae5f0dbfe9a8b0bec978f168d319534919800b817661.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Russell")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-699113")[#strong[#text("Kevin Russell")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Thanks for publishing the dead end; that’s the part most people bury, and it’s often the most useful. One suggestion from our own work: having a second model agree is a good filter, but it isn’t independent the way a re-run is. Where the obstruction results come down to finite checks, a script that replays them in exact arithmetic lets a reader confirm them without trusting either model. We keep our own retracted and weakened claims on the public record for the same reason you give: it saves the next person the cost.")

#text("— Kevin Russell")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-699122")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("Thanks Kevin. The model cross-check usually checks the calculations a different way if it can. We do already include ")#link("https://github.com/twinheterodox/beta4/blob/main/checks/README.md")[#text("reproducible exact-arithmetic and interval checks")]#text(", with ")#link("https://  github.com/twinheterodox/beta4/blob/main/checks/SUPPLEMENT.md")[#text("additional certificates for the supplement")]#text(".")

#text("I just uploaded a new, positive result:")

#text("For every sufficiently large even integer s,")

#mi("\\dim_{\\mathbb{Q}}\\operatorname{span}_{\\mathbb{Q}}\\{\\beta(2),\\beta(4),\\ldots,\\beta(s)\\}\\geq 0.21\\sqrt{\\frac{s}{\\log s}}.")

#link("https://raw.githubusercontent.com/twinheterodox/beta4/main/even-beta-independence/output/pdf/even-beta-independence.pdf")[#text("Paper (PDF)")]#text(" · ")#link("https://github.com/twinheterodox/  beta4/tree/main/even-beta-independence")[#text("Source and exact checks")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-699123")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2026")])]

#text("latex didn’t render. second attempt:")

#text("For every sufficiently large even integer s,")

#mi("\\dim_{\\mathbb{Q}}\\mathrm{span}_{\\mathbb{Q}}\\{\\beta(2),\\beta(4),\\ldots,\\beta(s)\\}\\geq 0.21\\sqrt{\\frac{s}{\\log s}}")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e2d2ec72f139ade45f18d213f32638eb808b8147ec5045666eeac8f89314d11-bf4f623534463971c22c2797770b4533128721c4fda5b9ff6b4f8f50d9f4554e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marx")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698989")[#strong[#text("Marx")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2026")])]

#text("Yeah, great, keep alienating more human capital/labour for ai corps, so that one day they simply will not need you any more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cdb9621d104979af20a9688d619653dac117f8446a4ea9ebdb5b01eb0516d368-77c3c5fe196b4a4824fda22d207ea23dd6bd7f0a492aa1098b95d025d2ddbe4d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Leopardi")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698996")[#strong[#text("Paul Leopardi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("Reading the UK Academy for the Mathematical Sciences preprint and the Harvard CMSA report highlights what is still needed to connect AI capabilities to applied mathematics.")

#text("The UK report gives a thorough snapshot of what 2026 agentic harnesses can and cannot do, and its summary rightly notes that “translating discoveries into wider use will remain essential.” Section 4.7 also makes an important start on the human and technical infrastructure needed: calling for sustained support for “maintainers, reviewers and research software engineers” and for building “equivalent infrastructure for statistics, OR and applied mathematics: reproducible code and data artefacts, and open validation environments.”")

#text("What the report mentions, but does not yet lay out, is the ")#emph[#text("mechanism")]#text(" of translation, especially in relation to the long history of computer-aided research in mathematics, the role of High-Performance Computing and Data infrastructure in the application of mathematics, and how the next generation of mathematically fluent Research Software Engineers (RSEs) is to be trained.")

#text("In applied mathematics, every idealized model carries “applicability debt”: essentially the difference between the model and the concrete application that it is meant to address. Similarly, mathematical methods must be made concrete if they are to be actually used to solve problems. Managing this translation involves three activities: assessment (abstract “how well does this work?” and concrete “how much does this help?”), adaptation (functional adaptation of the model to the problem and formal adaptation of the software to the computing environment), and adoption, sustained by a web of skills including applied mathematics, domain specialist skills, and research software engineering.")

#text("By coincidence, just before seeing this post, I uploaded a monograph to Zenodo examining this mechanism of translation, and addressing skill development and computing infrastructure from an Australian perspective.")

#text("See “What Does It Mean to Apply Mathematics in Australia Today?” at ")#link("https://doi.org/10.5281/zenodo.23838583")[#text("https://doi.org/10.5281/zenodo.23838583")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-698997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("The Renaissance Foundation and XTX markets are not philanthropic organizations, neither is the Simons Foundation, which even owns the pro-AI magazine (Quanta).")

#text("All of these have been invested in machine learning in trading for a long time.")

#text("Even when the misanthropic “Anthropic” company chose the propaganda name, “philanthropic” still means pro-human and not replacing humans with machines.")

#text("At least in hard copies of the OED that Silicon Valley cannot modify.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/31/the-mathematical-sciences-in-an-ai-enabled-world/comment-page-1/#comment-699000")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2026")])]

#text("This was informative.")

#text("This caught my eye:")

#emph[#text("‘Graduate labour market. Replacing students and postdocs with agentic AI set-ups would cut off the pipeline of young researchers and leave a shortfall of highly skilled graduates, not only for mathematical jobs but in all the areas where PhDs in the mathematical sciences are valued. AI may remove the entry-level roles through which mathematical sciences graduates traditionally build expertise outside academia. Mitigation: support PhD training and positions for early-career researchers; work with employers on what AI-fluent mathematical graduates offer, and on structured routes into work.’")]

#text("The risk identified is an honest one. The mitigation strategy raised some questions for me – are there existing strong channels of communication between mathematical societies and employers, through which one may persuade firms to hire young mathematical scientists? Is the hope to expand existing structured routes into work?")

#text("If the mathematical societies indeed have strong connections to industry, it would also be valuable to ask such firms: what skills are they expecting of their new mathematical-sciences hires? We may -guess-, but it could be useful to at least ask.")

#text("Impressionistically, in some countries the links between industry and mathematics departments via internships and joint research opportunities with student are stronger than in others.")

#text("– Nilima Nigam")
]
