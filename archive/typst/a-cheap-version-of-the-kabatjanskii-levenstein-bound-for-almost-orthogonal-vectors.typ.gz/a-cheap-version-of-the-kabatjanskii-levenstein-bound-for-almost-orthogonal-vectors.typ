// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/
// Converted to Typst by tao2typ: "2026-10-14T09:32:25.288393+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A cheap version of the Kabatjanskii-Levenstein bound for almost orthogonal vectors", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A cheap version of the Kabatjanskii-Levenstein bound for almost orthogonal vectors")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")[#text("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{n}")#text(" be a natural number. We consider the question of how many “almost orthogonal” unit vectors ")#mi("{v_1,\\ldots,v_m}")#text(" one can place in the Euclidean space ")#mi("{{\\bf R}^n}")#text(". Of course, if we insist on ")#mi("{v_1,\\ldots,v_m}")#text(" being ")#emph[#text("exactly")]#text(" orthogonal, so that ")#mi("{\\langle v_i,v_j \\rangle = 0}")#text(" for all distinct ")#mi("{i,j}")#text(", then we can only pack at most ")#mi("{n}")#text(" unit vectors into this space. However, if one is willing to relax the orthogonality condition a little, so that ")#mi("{\\langle v_i,v_j\\rangle}")#text(" is small rather than zero, then one can pack a lot more unit vectors into ")#mi("{{\\bf R}^n}")#text(", due to the important fact that pairs of vectors in high dimensions are typically almost orthogonal to each other. For instance, if one chooses ")#mi("{v_i}")#text(" uniformly and independently at random on the unit sphere, then a standard computation (based on viewing the ")#mi("{v_i}")#text(" as gaussian vectors projected onto the unit sphere) shows that each inner product ")#mi("{\\langle v_i,v_j \\rangle}")#text(" concentrates around the origin with standard deviation ")#mi("{O(1/\\sqrt{n})}")#text(" and with gaussian tails, and a simple application of the union bound then shows that for any fixed ")#mi("{K \\geq 1}")#text(", one can pack ")#mi("{n^K}")#text(" unit vectors into ")#mi("{{\\bf R}^n}")#text(" whose inner products are all of size ")#mi("{O( K^{1/2} n^{-1/2} \\log^{1/2} n )}")#text(".")

#text("One can remove the logarithm by using some number theoretic constructions. For instance, if ")#mi("{n}")#text(" is twice a prime ")#mi("{n=2p}")#text(", one can identify ")#mi("{{\\bf R}^n}")#text(" with the space ")#mi("{\\ell^2({\\bf F}_p)}")#text(" of complex-valued functions ")#mi("{f: {\\bf F}_p \\rightarrow {\\bf C}}")#text(", where ")#mi("{{\\bf F}_p}")#text(" is the field of ")#mi("{p}")#text(" elements, and if one then considers the ")#mi("{p^2}")#text(" different quadratic phases ")#mi("{x \\mapsto \\frac{1}{\\sqrt{p}} e_p( ax^2 + bx )}")#text(" for ")#mi("{a,b \\in {\\bf F}_p}")#text(", where ")#mi("{e_p(a) := e^{2\\pi i a/p}}")#text(" is the standard character on ")#mi("{{\\bf F}_p}")#text(", then a standard application of Gauss sum estimates reveals that these ")#mi("{p^2}")#text(" unit vectors in ")#mi("{{\\bf R}^n}")#text(" all have inner products of magnitude at most ")#mi("{p^{-1/2}}")#text(" with each other. More generally, if we take ")#mi("{d \\geq 1}")#text(" and consider the ")#mi("{p^d}")#text(" different polynomial phases ")#mi("{x \\mapsto \\frac{1}{\\sqrt{p}} e_p( a_d x^d + \\ldots + a_1 x )}")#text(" for ")#mi("{a_1,\\ldots,a_d \\in {\\bf F}_p}")#text(", then an application of the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures for curves")]#text(", proven by Weil, shows that the inner products of the associated ")#mi("{p^d}")#text(" unit vectors with each other have magnitude at most ")#mi("{(d-1) p^{-1/2}}")#text(".")

#text("As it turns out, this construction is close to optimal, in that there is a polynomial limit to how many unit vectors one can pack into ")#mi("{{\\bf R}^n}")#text(" with an inner product of ")#mi("{O(1/\\sqrt{n})}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Cheap Kabatjanskii-Levenstein bound)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" Let ")#mi("{v_1,\\ldots,v_m}")#text(" be unit vector in ")#mi("{{\\bf R}^n}")#text(" such that ")#tao-math("{\\left|\\langle v_i, v_j \\rangle\\right| \\leq A n^{-1/2}}", block: false)#text(" for some ")#mi("{1/2 \\leq A \\leq \\frac{1}{2} \\sqrt{n}}")#text(". Then we have ")#mi("{m \\leq (\\frac{Cn}{A^2})^{C A^2}}")#text(" for some absolute constant ")#mi("{C}")#text(".")
]

#text("In particular, for fixed ")#mi("{d}")#text(" and large ")#mi("{p}")#text(", the number of unit vectors one can pack in ")#mi("{{\\bf R}^{2p}}")#text(" whose inner products all have magnitude at most ")#mi("{dp^{-1/2}}")#text(" will be ")#mi("{O( p^{O(d^2)} )}")#text(". This doesn’t quite match the construction coming from the Weil conjectures, although it is worth noting that the upper bound of ")#mi("{(d-1)p^{-1/2}}")#text(" for the inner product is usually not sharp (the inner product is actually ")#mi("{p^{-1/2}}")#text(" times the sum of ")#mi("{d-1}")#text(" unit phases which one expects (cf. the ")#link("http://en.wikipedia.org/wiki/Sato%E2%80%93Tate_conjecture")[#text("Sato-Tate conjecture")]#text(") to be uniformly distributed on the unit circle, and so the typical inner product is actually closer to ")#mi("{(d-1)^{1/2} p^{-1/2}}")#text(").")

#text("Note that for ")#mi("{0 \\leq A < 1/2}")#text(", the ")#mi("{A=1/2}")#text(" case of the above theorem (or more precisely, Lemma ")#link(<tao-4862f447f2c7f272fa2f>)[#text("2")]#text(" below) gives the bound ")#mi("{m=O(n)}")#text(", which is essentially optimal as the example of an orthonormal basis shows. For ")#mi("{A \\geq \\sqrt{n}}")#text(", the condition ")#tao-math("{\\left|\\langle v_i, v_j \\rangle\\right| \\leq A n^{-1/2}}", block: false)#text(" is trivially true from Cauchy-Schwarz, and ")#mi("{m}")#text(" can be arbitrariy large. Finally, in the range ")#mi("{\\frac{1}{2} \\sqrt{n} \\leq A \\leq \\sqrt{n}}")#text(", we can use a volume packing argument: we have ")#tao-math("{\\left\\|v_i-v_j\\right\\|^2 \\geq 2 (1 - A n^{-1/2})}", block: false)#text(", so of we set ")#mi("{r := 2^{-1/2} (1-A n^{-1/2})^{1/2}}")#text(", then the open balls of radius ")#mi("{r}")#text(" around each ")#mi("{v_i}")#text(" are disjoint, while all lying in a ball of radius ")#mi("{O(1)}")#text(", giving rise to the bound ")#mi("{m \\leq C^n (1-A n^{-1/2})^{-n/2}}")#text(" for some absolute constant ")#mi("{C}")#text(".")

#text("As I learned recently from Philippe Michel, a more precise version of this theorem is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=514023")[#text("Kabatjanskii and Levenstein")]#text(", who studied the closely related problem of sphere packing (or more precisely, cap packing) in the unit sphere ")#mi("{S^{n-1}}")#text(" of ")#mi("{{\\bf R}^n}")#text(". However, I found a short proof of the above theorem which relies on one of my favorite tricks – the ")#link("http://www.tricki.org/article/The_tensor_power_trick")[#text("tensor power trick")]#text(" – so I thought I would give it here.")

#text("We begin with an easy case, basically the ")#mi("{A=1/2}")#text(" case of the above theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" ")#metadata(none) <tao-4862f447f2c7f272fa2f>#text(" Let ")#mi("{v_1,\\ldots,v_m}")#text(" be unit vectors in ")#mi("{{\\bf R}^n}")#text(" such that ")#tao-math("{\\left|\\langle v_i, v_j \\rangle\\right| \\leq \\frac{1}{2n^{1/2}}}", block: false)#text(" for all distinct ")#mi("{i,j}")#text(". Then ")#mi("{m < 2n}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that ")#mi("{m \\geq 2n}")#text(". We consider the ")#mi("{2n \\times 2n}")#text(" ")#link("http://en.wikipedia.org/wiki/Gramian_matrix")[#text("Gram matrix")]#text(" ")#mi("{( \\langle v_i,v_j \\rangle )_{1 \\leq i,j \\leq 2n}}")#text(". This matrix is real symmetric with rank at most ")#mi("{n}")#text(", thus if one subtracts off the identity matrix, it has an eigenvalue of ")#mi("{-1}")#text(" with multiplicity at least ")#mi("{n}")#text(". Taking ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt norms")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq i,j \\leq 2n: i \\neq j} \\left|\\langle v_i, v_j \\rangle\\right|^2 \\geq n.", block: true)]]

#text("But by hypothesis, the left-hand side is at most ")#mi("{2n(2n-1) \\frac{1}{4n} = n-\\frac{1}{2}}")#text(", giving the desired contradiction. ")#mi("\\Box")

#text("To amplify the above lemma to cover larger values of ")#mi("{A}")#text(", we apply the tensor power trick. A direct application of the tensor power trick does not gain very much; however one can do a lot better by using the ")#emph[#text("symmetric")]#text(" tensor power rather than the raw tensor power. This gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3")]#text(" Let ")#mi("{k}")#text(" be a natural number, and let ")#mi("{v_1,\\ldots,v_m}")#text(" be unit vectors in ")#mi("{{\\bf R}^n}")#text(" such that ")#tao-math("{\\left|\\langle v_i, v_j \\rangle\\right| \\leq 2^{-1/k} (\\binom{n+k-1}{k})^{-1/2k}}", block: false)#text(" for all distinct ")#mi("{i,j}")#text(". Then ")#mi("{m < 2\\binom{n+k-1}{k}}")#text(".")
]

#emph[#text("Proof:")]#text(" We work in the ")#link("http://en.wikipedia.org/wiki/Symmetric_algebra")[#text("symmetric component")]#text(" ")#mi("{\\text{Sym}^k {\\bf R}^n}")#text(" of the tensor power ")#mi("{({\\bf R}^n)^{\\otimes k} \\equiv {\\bf R}^{n^k}}")#text(", which has dimension ")#mi("{\\binom{n+k-1}{k}}")#text(". Applying the previous lemma to the tensor powers ")#mi("{v_1^{\\otimes k},\\ldots,v_m^{\\otimes k}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Using the trivial bound ")#mi("{e^k \\geq \\frac{k^k}{k!}}")#text(", we can lower bound")

#tao-aligned(keep: true)[


#tao-math("2^{-1/k} (\\binom{n+k-1}{k})^{-1/2k}  & \\geq 2^{-1/k} (n+k-1)^{-1/2} (k!)^{1/2k}", block: true)



#tao-math(" & \\geq 2^{-1/k} e^{-1/2} k^{1/2} (n+k-1)^{-1/2} .", block: true)
]

#text("We can thus prove Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" by setting ")#mi("{k := \\lfloor C A^2 \\rfloor}")#text(" for some sufficiently large absolute constant ")#mi("{C}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f08746571f83d1b2a8c384ad68e2c30ed78bd1144145ca771874d8961908d48-86f323d736cb323c5a24cbb64bf4da041087f3a4ec78cd7499c2ed9b0a158fb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of frankpmurphyh")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239056")[#strong[#text("frankpmurphyh")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Reblogged this on ")#link("http://algebrafm.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/")[#text("algebrafm")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239084")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Didn’t you build ")#mi("p^2")#text(" independent vectors with inner product less than ")#mi("\\frac{1}{\\sqrt{p}}")#text(" ? Then why is your bound ")#mi("2n")#text(" in Lemma 2 ?")

#text("I am skeptical as we had drilled into our heads that ")#mi("\\mathbb{R}^n")#text(" had exactly ")#mi("n")#text(" basis vectors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2013")])]

#text("Lemma 2 concerns vectors whose inner product is less than ")#mi("\\frac{1}{2n^{1/2}}")#text(" in magnitude, which in the case ")#mi("n=2p")#text(" would be ")#mi("\\frac{1}{\\sqrt{8p}}")#text(". This is less than the ")#mi("\\frac{1}{\\sqrt{p}}")#text(" bound obeyed by the example of the quadratic phase functions. The factor of ")#mi("\\sqrt{8}")#text(" makes a big difference!")

#text("This is one of the initially unintuitive aspects of high-dimensional geometry; perfect orthogonality is difficult to achieve (and, as you say, one can only pack ")#mi("n")#text(" perfectly orthogonal vectors into ")#mi("{\\bf R}^n")#text("), but almost orthogonality becomes increasingly easy to achieve as one loosens the definition of almost orthogonality, basically because with the exponentially large amount of “room” available in a high-dimensional space. With ")#mi("n=2p")#text(", one can pack ")#mi("p^2")#text(" vectors together with an inner product of at most ")#mi("1/\\sqrt{p}")#text(", or ")#mi("p^3")#text(" vectors together with an inner product of at most ")#mi("2/\\sqrt{p}")#text(", and so forth. Of course, these vectors cannot be linearly independent, but it is possible in high dimensions for a family of vectors to be simultaneously linearly dependent and almost orthogonal, as the latter only guarantees a “local” form of linear independence. (Among other things, this is one of the reasons why ")#link("http://en.wikipedia.org/wiki/Compressed_sensing")[#text("compressed sensing")]#text(" can work.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed46753abb9b9d7ba883d5f49e124f7cdf1fa4982cfdc2d73317ea132b59f9f-16e7223e25b645f3285465cecad79eaa69988183cc76bd52780a04e9496ddd80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mikhail Katz")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239104")[#strong[#text("Mikhail Katz")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("I wonder if this ties in with Gil Kalai’s negative solution of the Borsuk problem (coloring pointsets in Euclidean space).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A.")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239123")[#strong[#text("A.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Sorry for the stupid question. I haven’t seen the symmetric component before. Is the scalar product of tensor powers in the symmetric component the same as in the tensor product?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A.")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239125")[#strong[#text("A.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("Ok, I got it now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed443d8a11784c5982f0b00db9d6e57690f7cc863fb7396ea292b24f4fd574cd-b10cb900580c30ca3df78ffbb919dd4350ef5dfed17e13b62581b02831e2799a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239145")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("This is quite nice! A few years ago, Akshay wondered whether there was a bound of this quality with a simple proof (but didn’t get anything).")

#text("This means that the number of points one can pack on an ")#mi("n")#text("-dimensional sphere at angles ")#mi("\\pi/2-\\epsilon")#text(" from each other is at most ")#mi("2^{f(\\epsilon) n}")#text(", where ")#tao-math("f(t) \\ll \\epsilon^2 \\left|\\log \\epsilon\\right|", block: false)#text(". Can the ")#tao-math("\\left|\\log \\epsilon\\right|", block: false)#text(" be removed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239159")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2013")])]

#text("For very small ")#mi("\\varepsilon")#text(", comparable to ")#mi("1/\\sqrt{n}")#text(", one can’t remove the logarithm, because of the number-theoretic examples, e.g. ")#mi("\\sim n^2")#text(" vectors all at angle at least ")#mi("\\pi/2 - c/\\sqrt{n}")#text(" from each other. But one may be able to do better for larger values of ")#mi("\\varepsilon")#text("; when ")#mi("\\varepsilon \\sim A/\\sqrt{n}")#text(" the upper bound is of shape ")#mi("n^{A^2}")#text(" or so but the number-theoretic construction only gives ")#mi("n^A")#text(" vectors (this is something to do with the Sato-Tate type fluctuations in the Frobenius eigenvalues in the number theoretic constructions, and so may represent the limit of the number-theoretic method).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72a0bb9d17be287ee87f437f6b3cad1b7efd6bee7c93cb31c16647fa798703b1-da9daa63ddb597248c41a171379d6585ed8f120ae25be59b66dc72752ab7df3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tomer Milo")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-692200")[#strong[#text("Tomer Milo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("Dear Prof. Tao, ")#linebreak()#text("Your last remark about the number theoretic construction having the limit ")#mi("n^A")#text(" seems contradictory to your remark in your post that generally, the inner product is bounded by ")#mi("\\frac{\\sqrt{d}}{p}")#text(" rather than ")#mi("\\frac{d}{p}")#text(", for polynomial phases of degree ")#mi("d")#text(".")#linebreak()#text("It is not clear to me whether or not one can pack about ")#mi("p^d")#text(" vectors with inner products of order at most ")#mi("\\frac{\\sqrt{d}}{p}")#text(" using the more delicate Sato-Tate estimate you reference, which would in fact show your upper bound is asymptotically optimal (up to constants)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-692203")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("The Sato-Tate law (and its variants) are statistical (average-case) results rather than uniform (worst-case) results. They indicate that the inner product between two polynomial phases of degree ")#mi("d")#text(" will *typically* be of size ")#mi("O(\\sqrt{d}/\\sqrt{p})")#text(", but could be as bad as ")#mi("O(d/\\sqrt{p})")#text(" in the worst-case, and so unfortunately one cannot rigorously use a Sato-Tate law to improve the correlation bound uniformly down to ")#mi("O(\\sqrt{d}/\\sqrt{p})")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72a0bb9d17be287ee87f437f6b3cad1b7efd6bee7c93cb31c16647fa798703b1-da9daa63ddb597248c41a171379d6585ed8f120ae25be59b66dc72752ab7df3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tomer Milo")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-692204")[#strong[#text("Tomer Milo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2026")])]

#text("Can this typical behaviour be made quantitive, so that one obtains many (maybe of order $p^d$, optimistically?) degree d polynomial phases with mutual inner product of magnitude at most $\\frac{\\sqrt{d}}{p}? Is the distribution of the magnitude of degree $d$ polynomial phases around the mean $\\frac{\\sqrt{d}}{p}$ well understood?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Riemann hypothesis in various settings | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239254")[#strong[#text("The Riemann hypothesis in various settings | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2013")])]

#text("[…] To enter in LaTeX in comments, use ")#mi("<Your LaTeX code>")#text(" (without the < and > signs, of course; in fact, these signs should be avoided as they can cause formatting errors). See the about page for details and for other commenting policy. « A cheap version of the Kabatjanskii-Levenstein bound for almost orthogonal vectors […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239276")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2013")])]

#text("A few (a bit rusty) remarks and thoughts on the post. We start with a nice symmetric space ")#mi("X")#text(". In our case ")#mi("X")#text(" is an ")#mi("n")#text("-dimensional sphere, and other important cases are when ")#mi("X=\\{0,1\\}^n")#text(" (Hamming scheme) , and ")#mi("X= {[n] \\choose {k}}")#text(" (Johnson scheme). (Association schemes is a useful general setting, and Gelfand pairs may serve as another nice general relevant setting.) The questions we can ask are:")

#text("1) What is the maximum number of points of a set ")#emph[#text("Y")]#text(" in ")#emph[#text("X")]#text(" of vectors with the property that the distance between every two points in ")#emph[#text("Y")]#text(" is at least α?")

#text("2) What is the maximum measure for a (measurable) set ")#emph[#text("Y")]#text(" where the distance between every two points is at most α?")

#text("3) What is the maximum measure for a (measurable) set ")#mi("Y")#text(" where the distance between every two points is different than α?")

#text("4) What is the maximum ratio ")#tao-math("\\left|Z\\right|/\\left|Y\\right|", block: false)#text(" where the distance between every two points in ")#emph[#text("Y")]#text(" is at least α, and between two points in ")#emph[#text("X")]#text(" is greater than α.")

#text("5) What is the maximum ratio between the measures ")#mi("\\lambda (Z)/\\lambda (Y)")#text(" where the distance between every two points in ")#emph[#text("Y")]#text(" is at least α, and between two points in ")#emph[#text("X")]#text(" is greater than α?")

#text("The object for question 1) are called ")#strong[#text("codes")]#text(". (Error-correcting codes for ")#mi("\\{0,1\\}^n")#text(" and spherical codes for ")#mi("S^n")#text(".) Question 2 is an isoperimetric question. Question 3 is related to the Frankl-Wilson theorem where the polynomial methods is used to derive (close to optimal) bounds for the {0,1}^n case. The Frankl-Rodl paper gives an amazing method to move from question 2 to question 3. Problem 5 is related to the Borsuk’s problem that Jeff Kahn and I disproved. A special case of Problem 4 is the ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Faber%E2%80%93Lov%C3%A1sz_conjecture")[#text("Erdos-Faber-Lovasz conjecture")]#text(". A natural construction for question 3 is to take open caps of radius β/2 around the codewords of an optimal spherical code of minimal distance α+2β for some β. (Maybe it is even always the best to take α+2β=π so the code is two antipodal points.)")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Faber%E2%80%93Lov%C3%A1sz_conjecture")[#linebreak()#text(" ")]

#text("The very basic upper bounds for codes is the volume bound. There is a simple improvement based on intersecting our code with a small spherical strip (for ")#mi("S^n")#text(") or with all ")#mi("\\{0,1\\}")#text(" vectors of fixed weight (for the Hamming scheme) and apply the volume bound for the intersection. (I am not quite sure if this already gives the quantitative results in this post.) The most advanced method is Delsartes linear-programming method which is used by Kabatjanskii and Levenstein, to give the best known results for spherical codes. Improving asymptotically these bounds for spherical codes and the bounds by McELIECE, RODEMICH, RUMSEY, and WELCH for error correcting codes are outstanding open problems with no progress over three decades. Of course the question of spherical codes is closely related to the classical problem of the densest sphere packing in Euclidean spaces.")

#text("The tensor power/symmetric power trick is indeed very nice and it is curious that here we have to insist on symmetric powers. A similar trick is used to move from problem 3 to 5 in the case of Borsuk’s problem, and it also played a role in the disproof by Khot and Vishnoi of the Goemans-Linial conjecture. A propos this, I am curious if symmetric powers of sets of constant width have constant width but this is a long shot.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239278")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2013")])]

#text("Let me state more carefully problems 4 and 5.")

#text("4) What is the minimum over subsets ")#mi("Y")#text(" of ")#mi("X")#text(" of the maximum over subsets ")#mi("Z")#text(" of ")#mi("Y")#text(" of the ratio ")#tao-math("\\left|Z\\right|/\\left|Y\\right|", block: false)#text(", where the distance between every two points in ")#mi("Y")#text(" is at least α, and between two points in ")#mi("Z")#text(" is greater than α.")

#text("5) What is the minimum over ")#mi("Y")#text(" of the maximum over ")#mi("Z \\subset Y")#text(" of the ratio between the measures ")#mi("\\lambda(Z)/\\lambda(Y)")#text(" where the distance between every two points in Y is at least α, and between two points in Z is greater than α?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239333")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("Sorry, 5) still needs to be corrected")

#text("5) What is the minimum over choices of ")#mi("Y")#text(" of the maximum over ")#mi("Z \\subset Y")#text(" of the ratio between the measures ")#mi("\\lambda (Z)/\\lambda (Y)")#text(" where the distance between every two points in Y is ")#strong[#text(" at most α, and between every two points in Z is ")]#strong[#text(" less than α? ")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239349")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("This proof seems to be closely related to results of of Noga Alon on matrices close to the identity. See Section 9 of his paper")

#text("Problems and results in extremal combinatorics, I, Discrete Math. 273 (2003), 31-53")

#link("http://www.tau.ac.il/~nogaa/PDFS/extremal1.pdf")[#text("Click to access extremal1.pdf")]

#text("or his paper")

#text("Perturbed identity matrices have high rank: proof and applications, Combinatorics, Probability and Computing 18 (2009), 3-15")

#link("http://www.tau.ac.il/~nogaa/PDFS/identity1.pdf")[#text("Click to access identity1.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("Thanks for the reference! This isn’t the first time I managed to rediscover some argument or trick that Noga had figured out years ago… :-) (I once gave a talk mentioning a result I had proven recently and was quite proud of, and within a minute Noga (who was in the audience) asked, “Did you use [technique X] to reduce the problem to [simpler problem Y]?”. Of course, this is what I had done, and was the heart of the argument.)")

#text("I also see that Noga has a discussion of Harald’s question of removing the logarithm factor (when ")#mi("\\varepsilon")#text(" is fixed rather than decaying in ")#mi("n")#text("), but it seems that this is closely related to the notorious problem of removing the logarithm in the Johnson-Lindenstrauss lemma, so is likely to be very difficult (though also very interesting).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239358")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2013")])]

#text("This is very nice indeed!")

#text("Actually, I think that Kabatjanski-Levenstein never explicitly address the regime where the inner product is O(1/sqrt(n)); in my paper with Phllippe and Fouvry where we used such ideas to give upper bounds on the number of sheaves with bounded complexity on a curve ( ")#link("http://www.math.ethz.ch/~kowalski/counting-sheaves.pdf")[#text("http://www.math.ethz.ch/~kowalski/counting-sheaves.pdf")]#text(" ) we ended proving such a bound using their method and a lemma on zeros of Hermite polynomials.")

#text("The question of optimizing the lower bounds for the regime O(1/sqrt(n)) using as many sheaves as possible is very interesting, and related to conjectures of Drinfeld, Deligne and others. We haven’t yet succeeded in getting a serious improvement on counting merely rank one sheaves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-239745")[#strong[#text("A cheap version of the Kabatjanskii-Levenstein bound for almost orthogonal vectors | Fashion")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2013")]

#text("[…] Read more… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-250450")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2013")])]

#text("Some of the ideas and results in this blog may be used to study “almost normal matrices.” If we let ")#mi("A \\in M_n")#text(" be the matrix with “almost orthogonal vectors,” then ")#tao-math("\\left|\\left|AA^* - A^*A\\right|\\right|", block: false)#text(" will be small. Moreover, one can show that there exists a normal matrix ")#mi("N")#text(" and a universal constant, ")#mi("K")#text(" such that $||N-A|| \\leq K ||AA^* – A^*A||$. In other words, “almost normal matrices” are near normal approximates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-270092")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("I don’t understand your remark that the bound when A=1 is O(n). It seems to be ")#mi("n^C")#text(" for an absolute constant C.")

#text("I’m asking because I’m interested to know what the correct bound is when A is something like 1/2. Do you have any information about this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-270126")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Oops, you’re right; the argument above only gives a linear bound for A=1/2 rather than A=1 (Lemma 2). I’ve reworded the text accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-270136")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2014")])]

#text("Oops — I missed that what I wanted to know about was dealt with in Lemma 2.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-273813")[#strong[#text("The Rank Lemma | Geometry and Combinatorics")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")]

#text("[…] Before giving a proof of Lemma 1, I present the following application, which is a slight strengthening of Lemma 2 of this post by Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of When is correlation transitive? | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-363826")[#strong[#text("When is correlation transitive? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2014")])]

#text("[…] the exceptional pairs that are even weakly correlated to each other become exponentially rare. (See this previous blog post for some related discussion; in particular Lemma 2 from that post is closely related to the van der […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-458798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2015")])]

#text("Is this post available in any of your books, I just checked some of them but I could not find anyone which includes with this post?")

#emph[#text("[The posts from 2012 onward have not been published in book format; I may do so at some later point in time, though. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boosting the van der Corput inequality using the tensor power trick | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-622842")[#strong[#text("Boosting the van der Corput inequality using the tensor power trick | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] separate application of tensor powers to amplify correlations was also noted in this previous blog post giving a cheap version of the Kabatjanskii-Levenstein bound, but this seems to not be directly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17cc074905de092d7644c59dba173a784e0a9bd28cc597e1338b18e690f281ca-3d946610d0bc3f2e8cf4b415780134cd8e31f76bf0f4b7e6a07447b97bcc700e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brent Werness")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-676753")[#strong[#text("Brent Werness")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2023")])]

#text("Hi, I know this post is a decade old, but I was just implementing these vectors as a practical alternative to random generation (they work significantly better in some regimes) and I’m a bit perplexed by the ones depending on the Weil Conjecture. As a specific example, if you set ")#mi("p = 3")#text(" and ")#mi("d = 3")#text(", there are off-diagonal elements which are exactly one by Fermat’s little theorem for instance ")#mi("x \\mapsto e_p(x+2x^3)/\\sqrt{p}")#text(".")

#text("Even if you are not in this extremely degenerate case, I’m still getting inner products off diagonal which are much larger than could be explained by machine error (for instance for ")#mi("p=11")#text(", ")#mi("d=3")#text(" where I find off-diagonal terms of size 0.54 vs a bound of 0.43).")

#text("This is in sharp contrast to the ")#mi("d=2")#text(" case, where the bound can be established by much more elementary means, and appear to always hold up to machine precision. Short python code can be provided if interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/18/a-cheap-version-of-the-kabatjanskii-levenstein-bound-for-almost-orthogonal-vectors/#comment-676958")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2023")])]

#text("The Weil bound is ")#mi("(d-1) p^{-1/2}")#text(", which is consistent with both of the examples you provided (for instance, when ")#mi("d=3")#text(" and ")#mi("p=11")#text(" the bound is ")#mi("2/\\sqrt{11} = 0.603\\dots")#text(", not 0.43 as you write). It is rare though that the Weil bound would be attained with equality.")
]
]
