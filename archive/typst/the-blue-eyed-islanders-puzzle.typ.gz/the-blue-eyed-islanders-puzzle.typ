// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/
// Converted to Typst by tao2typ: "2026-10-14T15:16:38.554978+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The blue-eyed islanders puzzle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The blue-eyed islanders puzzle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 February 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all the previous comments to this post). The text here is adapted from an ")#link("http://www.math.ucla.edu/~tao/blue.html")[#text("earlier web page of mine")]#text(" from a few years back.")

#text("The puzzle has a number of formulations, but I will use this one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("There is an island upon which a tribe resides. The tribe consists of 1000 people, with various eye colours. Yet, their religion forbids them to know their own eye color, or even to discuss the topic; thus, each resident can (and does) see the eye colors of all other residents, but has no way of discovering his or her own (there are no reflective surfaces). If a tribesperson does discover his or her own eye color, then their religion compels them to commit ritual suicide at noon the following day in the village square for all to witness. All the tribespeople are highly logical and devout, and they all know that each other is also highly logical and devout (and they all know that they all know that each other is highly logical and devout, and so forth).")

#text("[")#emph[#text("Added")]#text(", Feb 15: for the purposes of this logic puzzle, “highly logical” means that any conclusion that can logically deduced from the information and observations available to an islander, will automatically be known to that islander.]")

#text("Of the 1000 islanders, it turns out that 100 of them have blue eyes and 900 of them have brown eyes, although the islanders are not initially aware of these statistics (each of them can of course only see 999 of the 1000 tribespeople).")

#text("One day, a blue-eyed foreigner visits to the island and wins the complete trust of the tribe.")

#text("One evening, he addresses the entire tribe to thank them for their hospitality.")

#text("However, not knowing the customs, the foreigner makes the mistake of mentioning eye color in his address, remarking “how unusual it is to see another blue-eyed person like myself in this region of the world”.")

#text("What effect, if anything, does this ")#emph[#text("faux pas")]#text(" have on the tribe?")
]

#text("The interesting thing about this puzzle is that there are two quite plausible arguments here, which give opposing conclusions:")

#text("[Note: if you have not seen the puzzle before, I recommend thinking about it first before clicking ahead.]")

#metadata(none) <tao-ebbb0f56f3b3c21f4b18>#linebreak()#text(" ")#strong[#text("Argument 1")]#text(". The foreigner has no effect, because his comments do not tell the tribe anything that they do not already know (everyone in the tribe can already see that there are several blue-eyed people in their tribe). ")#mi("\\diamond")

#strong[#text("Argument 2.")]#text(" 100 days after the address, all the blue eyed people commit suicide. This is proven as a special case of")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition.")]#text(" Suppose that the tribe had n blue-eyed people for some positive integer n. Then n days after the traveller’s address, all n blue-eyed people commit suicide.")
]

#strong[#text("Proof:")]#text(" We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day. Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: “If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island, and so they will all commit suicide n-1 days after the traveler’s address”. But when n-1 days pass, none of the blue-eyed people do so (because at that stage they have no evidence that they themselves are blue-eyed). After nobody commits suicide on the ")#mi("(n-1)^{st}")#text(" day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the ")#mi("n^{th}")#text(" day. ")#mi("\\Box")#text(" ")#mi("\\diamond")

#text("Which argument is valid? I won’t spoil it in this main post, but readers are welcome to discuss the solution in the comments. (Again, for those of you who haven’t seen the puzzle before, I recommend thinking about it first before reading the comments below.)")

#emph[#text("Added")]#text(", Feb 12: It is undoubtedly true that the assumptions of this logic puzzle are highly unrealistic, and defy common sense. ")#text("This however does not invalidate the above question")#text(", which is to resolve the fact that there are two separate and seemingly valid arguments which start with the same hypotheses but yield contradictory conclusions. This fact requires resolution even if the hypotheses are extremely unlikely to be completely satisfied in any reasonable situation; it is only when the hypotheses are ")#emph[#text("logically impossible")]#text(" to satisfy completely that there is no need to analyse the situation further.")

#text("[")#emph[#text("Update")]#text(", Feb 10: wording of the puzzle clarified. (My original version, which did not contain the last parenthetical of the first paragraph, can be found ")#link("http://www.math.ucla.edu/~tao/blue.html")[#text("on my web page")]#text("; it had an unexpectedly interesting subtlety in its formulation, but was not the puzzle I had actually intended to write. See also ")#link("http://xkcd.com/blue_eyes.html")[#text("this formulation of the puzzle by xkcd")]#text(".)]")

#heading(level: 1)[#text("Comments (471)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-10/#comment-643671")[#strong[#text("Two fun math puzzles – FENQ")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2022")]

#text("[…] The blue-eyed islanders puzzle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-10/#comment-675886")[#strong[#text("When you spot a Stag | Thought Flow")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")]

#text("[…] this information hierarchy is central to how values are formed and destroyed in human societies. The blue-eyed islander puzzle illustrates how complex this hierarchy can […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lenoxuss")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-48388")[#strong[#text("lenoxuss")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Suppose there are just five people: Alice, Bob, Charlie, Diane, Elaine. It so happens they are ")#emph[#text("all")]#text(" blue. (-eyed, not sad.) In such a situation, none will commit suicide, because each will think: “")#emph[#text("My")]#text(" eyes might be brown, green, or red.”")

#text("Now, Alice knows that Elaine is blue, and Alice knows that Diane knows that Elaine is blue — but Alice ")#emph[#text("doesn’t")]#text(" know if Bob knows if Charlie knows if Diane knows if Elaine knows that there is at least one blue on the island. She really, really doesn’t! Alice would only know that ")#emph[#text("if")]#text(" she knew her own eye color (which she can’t), or if she thought that someone else know their own eye color (which she knows they can’t).")

#text("What the foreigner’s comment does is cut that bridge short. Now it is the case for any person X that she knows that any person Y knows that there is at least one blue, and further for any possible nesting thereof. So the count begins…")

#text("Except it still seems weird to me that there would be that wait. Surely everyone already knows that no one will die on day 1 — and therefore the absence of deaths on day 1 is not new information! Right? If someone ")#emph[#text("did")]#text(" kill themselves, then every islander would correctly think “Wow, he screwed up.” (Which is, of course, impossible for these islanders to do — so would the survivors’ heads explode?) Hmm. I’m ")#emph[#text("alllmost")]#text(" getting how it works…")

#text("====")

#text("Now, I’m not sure if this quite needs to be a stated part of the problem, but perhaps the most counterintuitive thing is that these weirdo Vulcan islanders ")#emph[#text("do")]#text(" consider it horribly wrong to discuss eye color, but simultaneously can’t help themselves from ")#emph[#text("thinking")]#text(" about it, even when doing so carries the risk of death. They don’t shy away from it in their minds the way that actual people operating under taboos tend to, especially if the taboo is specifically about knowledge itself.")

#text("However, the nature of the problem doesn’t require that dying (or just leaving the island) is something an islander wants to avoid — indeed, great pains have to be taken about just how dead-set the islanders are on following the law. They can even have the ")#emph[#text("incentive")]#text(" to die/leave, and it still works exactly as well.")

#text("So a better phrasing might be this: It’s a group of prisoners who, once per day, have the opportunity to guess their eye color (written down to some independent party) or stay quiet. If they get it right, they go free, but if they get it wrong, they are shot. These highly logical prisoners will therefore only guess if they are rigidly certain, and they know that about the other prisoners. For kicks, it’s not until day 7 that someone says “There is at least one blue”, and no one knows of this announcement until then.")

#text("Or have I changed the problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e162a15824b2fc7ef27fd1e9006a0821c985bedbd930d7b1b03ffbacaf2e8b53-2a33842fbbe49c73ae1029e4b706f985f892a062136f36ded79f8fee872c0ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Zellman")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-49085")[#strong[#text("Matt Zellman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2010")])]

#text("It appears to me that no one has considered the n=4 case separately from the n=3 case, but there is a serious distinction on this level. You can’t just infer that the n=4 case invokes the n=3 case, because there is a major change in what everyone knows at n=4.")

#text("When there are 4 blue-eyed islanders, every islander can deduce that every other islander can see at least 2 other blue-eyed islanders. Since those 2 can see each other, the existence of blue-eyed islanders really is common knowledge, as long as there are 4 or more blue-eyed individuals.")

#text("No islander will ever assume that another islander thinks that there are fewer than 2 blue-eyed individuals, because they all *know* that everyone else can see at least that many.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e162a15824b2fc7ef27fd1e9006a0821c985bedbd930d7b1b03ffbacaf2e8b53-2a33842fbbe49c73ae1029e4b706f985f892a062136f36ded79f8fee872c0ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Zellman")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-49097")[#strong[#text("Matt Zellman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2010")])]

#text("Nevermind, I get it now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72facf4ee3056f2d1ebbc536a28a58e31ad30d2d53c0bd78635b1a768dbd963b-e7da81addd0a20ad0d791fe3e4d3db9a1fceef62ded6b0517612993529017c0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-49618")[#strong[#text("Marcel")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2011")])]

#text("Dr. Tao,")

#text("I believe there is a problem with your proof:")

#text("“Proof: We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day. Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: “If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island, and so they will all commit suicide n-1 days after the traveler’s address”. But when n-1 days pass, none of the blue-eyed people do so (because at that stage they have no evidence that they themselves are blue-eyed). After nobody commits suicide on the (n-1)^{st} day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the n^{th} day. \\Box \\diamond”")

#text("The problem is in the reasoning of the blue-eyed people in the inductive step:")

#text("“If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island, and so they will all commit suicide n-1 days after the traveler’s address”")

#text("Of course, we have assumed for the inductive step that the claim holds given n-1 blue eyed people. That is, the claim is true for n-1.")

#text("However, we have neither shown nor assumed that the blue-eyed islanders /know/ the claim is true for n-1.")

#text("In order for an arbitrary blue-eyed islander to reason by contrapositive that, given that no islanders commit suicide on the n-1’th day, therefore there must be more than n-1 blue-eyed islanders, he first must assume that:")

#text("“There are exactly n-1 blue-eyed islanders \\Rightarrow All blue-eyed islanders commit suicide on the n-1’th day.”")

#text("Obviously this statement is true by hypothesis in the inductive step, but the islander must be shown to know the statement is true for the induction to proceed as stated.")

#text("Thank you for all your great work,")#linebreak()#text(" Marcel")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d543ba6b27af670103f8a106a0d16c0d0f87b0a962572ee614ef053d49a3d125-23a636c2216129d378c928140cb2a61d3ee9a9664b2b03e7fb5f19198982d522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Vaccaro")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-50446")[#strong[#text("David Vaccaro")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("As the tribe are logical they will realise straight-away that the stranger’s comment will eventually lead to mass immolation. Could they therefore avoid most of the bloodshed by killing one blue-eyed person at the outset?")

#text("The removal of one blue-eyed isalnder avoids the inductive argument- because, for example, if there were just two blue-eyed islanders the second one would not commit suicide because he would have no way of finding out whether the murdered islander was the only blue-eyed person on the island.")

#text("The murder of a blue-eyed islander at the start may be slightly morally dubious- but they would have died anyway.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2ff0409ee5c7a014387d8cad77105f93020776e46b86f489ee9a66d069cab9-ab8de23da69be110a12ddcf02a1fadfcab4cdb7eda20199b9388796828011ca9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Vogt")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51352")[#strong[#text("Jack Vogt")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2011")])]

#text("I just came across this web site but I have been following the same puzzle on the xkcd site. It’s also in the Wikipedia section ‘Common Knowledge (Logic)’. Both of them have it wrong. The answer is that the blue-eyed stranger told the islanders nothing and nobody is going to die as a consequence of what the stranger said.")

#text("I realize this has been covered before but since it’s still a matter of discussion let me offer a slightly different analysis.")

#text("First off, it was stated at the beginning that all the islanders are highly logical, which means that anything that can be logically deduced from the available information and observations will be deduced by every islander, and furthermore, all of the islanders know this. Therefore, every islander has long known the following THEORUM:")#linebreak()#text(" If there are n>2 blue eyed islanders then every islander knows that every other islander knows (by direct observation) that there are (n-2)>0 blue-eyed islanders.")

#text("If there are three or more blue-eyes in a group it is impossible for any one of the group not to see that every other person in the group sees at least one other blue-eye.")

#text("Consider a simplified version of the puzzle: only four blue-eyes imaginativly named A, B, C, and D, mixed in with any number of people with eyes that are not blue. The ‘Common Knowledge’ analysis goes something like this: A can see three blue-eyes, so he knows that B knows that there are at least two blue-eyes, so in turn A knows that B knows that C knows that there is at least one blue-eye, and finally A knows that B knows that C knows that D knows there is at least zero blue-eyes. When the blue-eyed stranger spills the beans D (and everyone else, thus making it ‘Common Knowledge’) knows that the possibility for zero blue-eyes is ruled out, and from that C realizes that one blue-eye is ruled out, and then B knows that the two blue-eyes case is ruled out, and then all of them know that there must be four blue-eyes.")

#text("The first part of the analysis is not wrong; it is only irrelevant. From the THEORUM, we know that everyone sees at least three blue-eyes. Each of the four knows that n is either three or four, so they each know that the minimum is either one or two.")

#text("The second part is nonsense, because it implicitly assumes that because D does not know by one line of reasoning that there is at least one blue-eye, then he cannot know it by any other line of reasoning, and therefore is dependant upon the information from a stranger.")

#text("Something that I find strange is that many have noted that the stranger provides no new information to the islanders and yet his zero information message changes everything. Even the Wikipedia article notes this apparent logical incongruity but makes no attempt to resolve it.")

#text("Another thing puzzling to me is this: the stranger informs 1000 people that he sees blue eyes, but the iterative ‘solution’ starts out ‘consider the case of n=1’. There is no mention in the puzzle of an island with only one blue-eye or of a stranger ever visiting that island. Then we are supposed to consider the case n=2. Another island with two blue eyes on it? The Wikipedia article then goes on, and concludes that since the logic works for n=1 and n=2, it must work for all n. But the THEORUM shows that something else applies for n>2.")

#text("Even if the islanders thought that the stranger had shown up for cases n=1 and n=2, why would they believe that he would have shown up for all cases from 2 through 100, as apparently required by the iterative ‘solution’?")

#text("Of course I think my analysis is correct, but not everyone will agree with it. I would appreciate any feedback from any quarter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad56a2b06644c09a4b235f45d4c1ad8968f65c20c15fe9b388a7426645544d79-ffa9a1b180a4116d16196e1a936009b10497f99e4c74d71ee550ede06f642d60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Wegener")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51356")[#strong[#text("Henry Wegener")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2011")])]

#text("Hello Jack,")

#text("I’m pretty sure that your arguments are wrong. And that Prof. Tao’s arguments are right.")

#text("How much comments on this page did you read? I recommend to read at least until Prof. Tao’s post on 8 February, 2008 at 3:57 pm.")

#text("To give you a better feedback I could but will not repeat ideas that have already been mentioned many times. But here are two things:")#linebreak()#text(" 1. The solution does not state that the stranger gives no new information. He does.")#linebreak()#text(" 2. The solution does not state that the cases n=1 and n=2 imply all other cases. It is an inductive argument that considers the cases n=1 and (n-1) ==> n.")#linebreak()#text(" I do not claim that you didn’t understand Prof. Tao’s solution. But in your comment I find no single argument against it.")

#text("Greetings")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d543ba6b27af670103f8a106a0d16c0d0f87b0a962572ee614ef053d49a3d125-23a636c2216129d378c928140cb2a61d3ee9a9664b2b03e7fb5f19198982d522.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David vaccaro")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51366")[#strong[#text("David vaccaro")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2011")])]

#text("Hey Jack-")

#text("A good place to start on a problem like this is to look at the simpleset cases.")

#text("On an island with two blue eyed people, A and B, although they both already know that there are blue eyed people on the island, before the foreigner speaks A does *not know* that B knows that this is the case (and vice-versa), because A could believe that his eyes were brown. Once the foreigner has spoken, A knows that B would commit suicide if he saw a brown eyed person and when he fails to do so he can deduce that his eyes are blue.")

#text("This is very clear- and I suspect that it why you started your induction at n=3 rather than n=2.")

#text("What about the case with three blue eyed people A, B and C? Before the foreigner speaks (even though your theorem holds) there are vital pieces of information missing: e.g. A does *not know* that B knows that C knows that there blue eyed islanders, because if A’s eyes were brown, B could think that C saw two brown eyed islanders.")

#text("The problem is hard because for large n it is really difficult to get a grip of what information is given by the foreigner (to start with A *does not* know that B knows that C knows that D knows that…..Z knows that there are blue eyed islanders). However, this new piece of information is precisely what allows the induction to kick-off.")

#text("Keep thinking about it and keep reading the blog posts (it’s a wonderful moment when it all clicks)- but Prof Tao’s proof is definitely correct.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa2ff0409ee5c7a014387d8cad77105f93020776e46b86f489ee9a66d069cab9-ab8de23da69be110a12ddcf02a1fadfcab4cdb7eda20199b9388796828011ca9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack Vogt")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51394")[#strong[#text("Jack Vogt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("You are right, sort of. It was late and I thought that I had really thought of something and posted before I thought about what I had thought about or what I had thought about what I had thought about, etc, etc, etc.")

#text("That said, and realizing that the puzzle is by necessity quite contrived, I am still not happy with it. The form of the puzzle on the xkcd site is a little more precise (and much less bloody) in that it has a guru who shows up and say that she sees a (that is, one) blue-eye. Consider: the proof relies upon a definite starting point, and it needs a sequence of transition points. The usual assumption is that starting point is one blue-eye on day one, and the transition points are the days. But I remember one version of this puzzle in which the sheriff tells the prisoners something about their hats and all the steps in the induction seem to happen instantaneously.")

#text("So consider another version, in which there is a High Priest who is not subject to the rules governing ordinary mortals, and one day the HP announces that he is going to ring a gong, and after he rings it any blue-eye on the island who knows the color of his eyes must jump into the volcano. So he rings it once and nothing happens. Some time later he rings it again. This goes on and then one day when he rings the gong all the blue-eyes rush to the volcano. The question is, how many times did he ring the gong? If we assume that all the very, very logical blue-eyes started counting at n=1, as is normal in a mathematical proof we get one answer. But every logical blue-eye knows (and knows that everyone else knows) that there are no fewer than 99 blue-eyes on the island, so why would they not realize that they could just as well start at n=99? The brown-eyes would start at n=100, but that would cause no problems. Would logical people necessarily think that n=1 is more logical than n=99? What if the HP had added a parenthetical remark such as “I know that you are all aware that there are at least forty-three blue-eyes on this island”? Would logical people now think that n=43 is the most logical starting point?")

#text("Isn’t it possible that logical people would conclude that there is no logical reason for picking any one starting point over any other? If they do not just happen to choose the same starting point is the puzzle solvable? I haven’t yet thought through this possibility very carefully so I don’t have an answer. Also, I can’t remember reading about this in any of the posts, but somebody must have discussed it.")

#text("The main sticking point for me has always been the conviction that telling them that there are blue-eyes on the island when they already knew that, and knew that everyone else knew it as well, is a message devoid of information. Information is a probability thing and it’s not just some boozy babel heard in a bar. The message can be considered more abstractly as ‘there is at least one blue-eye on the island (True/False)’. If it were possible to assign probabilities to True/False then there would be information in the message. But False is not just an event of probability zero, it is not even a possibility. It’s not a point in the sample space, so to speak.")

#text("I think I have this figured out. Consider the scene from countless movies and TV cop shows in which somebody prowls through a dark place, flashlight in hand, and calls out, “Is anybody there?” It doesn’t matter if the responce is “Yes’, “Help”, or “Nobody but us chickens”; the message is the message itself and not the content of the message. It seems to me that the content of the message in this puzzle is immaterial and the only purpose of the message is to provide a starting point, as has been noted by many others. Note that in my version of the puzzle the High Priest did not even acknowledge the existance of any blue-eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d11933e2f2cf9ad6a41b4151cd5b8d19da2789598308e0887ec835bc2feecf8-8127916497ad541035f555aa1ee5fbdfb4b9030239c49422806c54d8d9c4f298.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Filipe")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51396")[#strong[#text("Filipe")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("Dear Prof. Tao,")

#text("If your conclusion, it will mean the suicide of the entire tribe. If all blue-eyed people suicide themselves on the 100th day after the speech, then the rest of the islanders will know they are brown-eyed, so they are forced to commit suicide the day after.")

#text("Greetings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The blue-eyed islanders puzzle – repost « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51398")[#strong[#text("The blue-eyed islanders puzzle – repost « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("[…] April, 2011 in Uncategorized | by Terence Tao [This is a (lightly edited) repost of an old blog post of mine, which had attracted over 400 comments, and as such was becoming difficult to load; I request that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-51400")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2011")])]

#text("I’m happy to see that even three years after this puzzle was first posted, it still generates lively discussion; it is my favorite logic puzzle, and the moment when one really understands what is going on with it is quite satisfying.")

#text("But at 400+ comments, this page is becoming quite difficult to load; so I am closing the comments and ask that participants continue their discussion at the new thread")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2011/04/07/the-blue-eyed-islanders-puzzle-repost/")[#text("The blue-eyed islanders puzzle – repost")]
]

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The cost of knowledge « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-124803")[#strong[#text("The cost of knowledge « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2012")])]

#text("[…] to merely mutually known. (Amusingly, this distinction is also of crucial importance in my favorite logic puzzle, but that’s another story.) One can also see Elsevier’s side of the story in this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-148147")[#strong[#text("The Blue Eyes Problem and Solution « Summation of z over dj's, parameterized by Time")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2012")]

#text("[…] problem is this (Source: Terence Tao blog): There is an island upon which a tribe resides. The tribe consists of 1000 people, with various […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-247978")[#strong[#text("用眼神杀人——红蓝眼睛问题的胡思乱想 | 蘅芜散人的小站")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2013")]

#text("[…] 陶哲轩提出了这么个有趣的问题。关于这个问题的由来和讨论。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-248324")[#strong[#text("用眼神杀人2 — 红蓝眼睛问题续 | 蘅芜散人的小站")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2013")]

#text("[…] 首先，依旧是关于这个问题的由来和讨论。然后是我之前的一些胡思乱想。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-270231")[#strong[#text("猜疑链，Mutual knowledge | fubupc's learning records")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")]

#text("[…] 陶哲轩原题： https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad8365adbe519af884aaa6e0ed1dfa30c88a482f22617863682d672a83344d31-0eefd5879700a4db29a611db9482890631df42f0c51233040fc8f192ef6b53bc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Head banging (1) | Ciocolată cu sare")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-271140")[#strong[#text("Head banging (1) | Ciocolată cu sare")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2014")])]

#text("[…] E clasica problema, o referinta ar fi asta: ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-315195")[#strong[#text("Arcade of Thoughts » Democracy, Right to Reject, and Common Knowledge")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2014")]

#text("[…] [link, link]: There is a tribe residing in an island in which the religion dictates that a person should not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-399241")[#strong[#text("关于「第 N 天有 N 个红眼睛自杀」的数学题 | 暖黑网")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2014")]

#text("[…] 补题源：https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-420740")[#strong[#text("My great WordPress blog – The blue-eyed islanders puzzle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] you give up (don’t!) or simply want to check your reasoning, read Terry Tao’s entire post and the subsequent comments. And if you still have problems understanding, you’re welcome to drop a line […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-433895")[#strong[#text("Maryborough Brain Teasers And Logical Thinking Style Thinkers | BestBrainTeasers.net")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")]

#text("[…] The blue-eyed islanders puzzle | What’s new – Feb 05, 2008 · Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all …… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-433960")[#strong[#text("Gaspe Brain Teasers And Answers Hard Drive | BestBrainTeasers.net")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")]

#text("[…] The blue-eyed islanders puzzle | What’s new – Feb 05, 2008 · Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all …… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-433984")[#strong[#text("Blue River Printable Brain Teasers Puzzles With Answers | BestBrainTeasers.net")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")]

#text("[…] The blue-eyed islanders puzzle | What’s new – Feb 05, 2008 · Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all …… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-434453")[#strong[#text("Blaeberry Brain Teasers Puzzles Pdf | BestBrainTeasers.net")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")]

#text("[…] The blue-eyed islanders puzzle | What’s new – Feb 05, 2008 · Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all …… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-434601")[#strong[#text("Delta Hidden Meanings Brain Teasers Puzzles Free | BestBrainTeasers.net")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2014")]

#text("[…] The blue-eyed islanders puzzle | What’s new – Feb 05, 2008 · Given that there has recently been a lot of discussion on this blog about this logic puzzle, I thought I would make a dedicated post for it (and move all …… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-453518")[#strong[#text("EDITH JUDIT MARILYN | Silver Lining Mama")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2015")]

#text("[…] too? Does Terry Tao, who is listed by many as #1 most intelligent person living, get trolled in his Word Press blog attacking his intelligence? He probably does, judging by the extensive rules he wrote on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-454127")[#strong[#text("It's often the puzzles that baffle that go viral | Em News")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")]

#text("[…] The paradox of the blue eyed islanders. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-454133")[#strong[#text("It’s often the puzzles that baffle that go viral — Ebook Teacher - Education")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")]

#text("[…] The paradox of the blue eyed islanders. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-454208")[#strong[#text("#thatlogicproblem round-up | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2015")]

#text("[…] boxes. If you really want to blow your brain sockets, try the blue-eyed islanders puzzle. Terry Tao posted it to his blog once and a gargantuan comments thread full of people not getting it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-456620")[#strong[#text("Joker大人 | 倒霉的红眼")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2015")]

#text("[…] 1陶哲轩博客中曾引述此题The blue-eyed islanders puzzle ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-465400")[#strong[#text("Some maths puzzles that are actually clever | brain -> blueprint -> build")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-469269")[#strong[#text("It ought to be common knowledge that Donald Trump is not fit for the presidency of the United States of America | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("[…] favourite example of the distinction comes from the blue-eyed islander puzzle, discussed previously here, here and here on the blog. (By the way, I would ask that any commentary about that puzzle be […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-469281")[#strong[#text("故事背后的逻辑学 – 127.0.0.1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")]

#text("[…] 还有那个blue-eyed islander puzzle也很有意思。n=1时，可以很快理解。n=2时，得思考一下，第1天，a看到没人自杀，明白了那个蓝眼睛的人b看到a自己就是蓝眼睛，所以b并没有行动，那么a就能推出自己是蓝眼睛，这样就得接受处罚，于是在第2天自杀，b亦是如此。n=3时，a看到b,c都是蓝眼睛，于是不行动，b想a是看到c是蓝眼睛了，所以并不行动。c想a是看到b了。但如果只有2个人的话，第2天c想他们两个都会自杀吧，但并没有，环顾周围没有第3个人有蓝眼睛。所以c就想到自己是蓝眼睛。于是第三天自杀了。同理适用于a,b。 blue-eyed islander真是一个高智商而偏执的一群岛名。。。我都是边写边边想了好久才明白的。 所以这个例子是想说，只有智商和偏执成这样，才能不言不语，亦能明白真理？所以对于我们这样不爱专研的人，需要说出来？ 还是别人眼睛的颜色，是mutual knowledge，但岛民自己眼睛的颜色并不是common knowledge，因为岛民自己并不知道。只有透过外国人的话，才能把mutual knowledge转化为common knowledge？我自己好牵强的解释。。。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/407a6ea9d20f51d66e19ce220898b5da95f48a5dca0100b8e8224496d8f3e355-0b63cd214dba92ceee81806d1311186579f46fc2c2ce461917a45f30b27a63f3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trump’s new cloths | The Leisure of the Theory Class")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-469315")[#strong[#text("Trump’s new cloths | The Leisure of the Theory Class")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2016")])]

#text("[…] to infinity. A good example of a situation with mutual knowledge and no common knowledge is the blue-eyed islanders puzzle (using the story as it appears Terrence’ blog and a big spoiler ahead if you are not familiar […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fabc6ac5c7c18d91e1f36cd4d84200238664d45a1b6215f487f7e3cf498ca4a2-c978fcd099a2f126b97f1ec32810c52a4547bf5b420cbe98347bb6cb17757f60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of #Brexit: when the walls started coming up again all over Europe | Progressive Culture | Scholars & Rogues")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-470054")[#strong[#text("#Brexit: when the walls started coming up again all over Europe | Progressive Culture | Scholars & Rogues")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2016")])]

#text("[…] A more brutal, and more interesting telling of that distinction is the tale of the blue-eyed islanders. You can read a good description of it, and its analysis, by Terence Tao: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ab037468a2533f63afa8892c6a7bbd19bd4f0f878accfdbd1ba20e19b3719b2-417fb6117e7118f64f4d19c416f7d4ccc4a7966f9228676c760b60803d8f2db7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of “The Magus” (Part 4/9) | Michelle Podsiedlik")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-471424")[#strong[#text("“The Magus” (Part 4/9) | Michelle Podsiedlik")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("[…] only blue-islander reference I’m finding is a logic puzzle called “The blue-eyed islanders puzzle.” I’m guessing, like Summerland, Conchis’s is referring to a paradise/heaven-like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-478473")[#strong[#text("Shalom to Ning – Roy & His Friends")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2017")]

#text("[…] used to talk about math puzzles, from blue-eyed islander puzzle to the hardest logic puzzle ever, every time on the bus from or to Shuk. We joked about the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-479112")[#strong[#text("红眼睛与蓝眼睛 – 饱蠹阁baoduge")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2017")]

#text("[…] 这是陶哲轩（Terence Tao）2008年发在自己Blog上的一个puzzle。（原博：https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/）有兴趣的朋友可以思考一下，挺有意思。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-493843")[#strong[#text("Common Knowledge – Point at Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2018")]

#text("[…] There’s another famous puzzle involving common knowledge, initially even more baffling than this one. It is known as the blue-eyed islanders puzzle. It has been written about extensively elsewhere, so let me just point you to one such place, namely, Terence Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-503815")[#strong[#text("Hanabi: a card game for logicians – Math ∩ Programming")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2018")]

#text("[…] students often hear about the classic “blue-eyed islanders” puzzle early in their career. If you haven’t seen it, read Terry Tao’s excellent writeup […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-503867")[#strong[#text("a card game for logicians – Math ∩ Programming | Premium apps reviews Blog and Programing")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2018")]

#text("[…] students often hear about the classic “blue-eyed islanders” puzzle early in their career. If you haven’t seen it, read Terry Tao’s excellent writeup linked above. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-508198")[#strong[#text("Blue-eyed islander puzzle – Qiao Zhou")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2018")]

#text("[…] [1] ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-508813")[#strong[#text("LoopJump's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")]

#text("[…] 地址在这里：https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/ 。你可以直接跳过去读原文。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-510382")[#strong[#text("Shalom to Ning – Zilin & His Friends")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2019")]

#text("[…] the last day we say farewell to each. Red Sea from Eilat We used to talk about math puzzles, from blue-eyed islander puzzle to the hardest logic puzzle ever, every time on the bus from or to Shuk. We joked about the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-512132")[#strong[#text("a card game for logicians – Math ∩ Programming – Dinezh.com")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")]

#text("[…] students often hear about the classic “blue-eyed islanders” puzzle early in their career. If you haven’t seen it, read Terry Tao’s excellent writeup linked above. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-512134")[#strong[#text("What colour are my eyes? – A Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2019")]

#text("[…] ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")[#text("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-555567")[#strong[#text("公共知识与共有知识 – PP BLOG")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2020")]

#text("[…] 陶哲轩教授在多年前贴出过一道经典的蓝眼睛棕眼睛问题，后被广为流传为“红眼睛蓝眼睛问题”。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb8e630cae8cf1a8bcf27bac046f096cd29a759f3bd209dc4a491f47c907639d-b09be42e572603a85e8783ced4ad5b95aa22517cdf5cd0ce0cefb1e8307988f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Island of Blue-Eyed People | Logos con carne")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-582137")[#strong[#text("Island of Blue-Eyed People | Logos con carne")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2020")])]

#text("[…] I started following Terry Tao’s blog, and his “Selected Articles” list includes a post about this puzzle. I read it, and this time I stuck with it. I didn’t solve it, but I did sort of kind of maybe […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-639723")[#strong[#text("蓝眼岛自杀事件始末 - 嘎嘎资讯")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2022")]

#text("[…] The blue-eyed islanders puzzle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-9/#comment-643668")[#strong[#text("两个有趣的数学 Puzzle – 爱读书网")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2022")]

#text("[…] The blue-eyed islanders puzzle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-41414")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2009")])]

#text("I still see no response to my indicating the meta-meta-problem which is an obstruction to the use of induction in the meta-problem. One implicitly or explicitly has a Temporal Epistemic logic, whose axioms deal with the passage of time and inferences on sequences of events (including null evens, of the “dog that did not bark in the night” variety). The axioms also deal with the beliefs and the belief-revision algorithm of the agents (islanders). For induction to work as naively assumed, one needs to have unbounded introspection, with an axiom P^(KP) ==> KKP, that is, if proposition P is true, and you know that proposition P is true, then you know that you know that proposition P is true. Given a finite number of agents, and a countable set of propositions at all times in the belief set of each, then one needs to deal with the combinatorial complexity of the recursion of every agent modeling every other agent’s belief set and its dynamics, in a way that Felix Klein [Indra’s Pearls: The Vision of Felix Klein is a geometry book written by David Mumford, Caroline Series and David Wright] noted bears resemblance to Indian metaphysics. Francis Harold Cook describes the metaphor of Indra’s net from the perspective of the Huayan school in the book Hua-Yen Buddhism: The Jewel Net of Indra:")#linebreak()#text(" “Far away in the heavenly abode of the great god Indra, there is a wonderful net which has been hung by some cunning artificer in such a manner that it stretches out infinitely in all directions. In accordance with the extravagant tastes of deities, the artificer has hung a single glittering jewel in each “eye” of the net, and since the net itself is infinite in dimension, the jewels are infinite in number. There hang the jewels, glittering like stars in the first magnitude, a wonderful sight to behold. If we now arbitrarily select one of these jewels for inspection and look closely at it, we will discover that in its polished surface there are reflected all the other jewels in the net, infinite in number. Not only that, but each of the jewels reflected in this one jewel is also reflecting all the other jewels, so that there is an infinite reflecting process occurring.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a244c8a2e08ff52c5a75cd097dd09c9e218838618986b1e461efd9295c2a9cfa-a6656d17a8ee4884aed7a5247569d6022ccce5ae6c5d3d8b822a5f3ab4de88c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DAGwyn")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-41600")[#strong[#text("DAGwyn")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2009")])]

#text("On Day 0, the islanders kill the foreigner for setting them ALL onto a fatal path! As somebody else noted, after the blue-eyed suicide, the remaining population know they don’t have blue eyes. If they assume there are only two eye colors, then they definitely now know their own, and will commit suicide the next day. Otherwise, they now have SOME knowledge about their own eye color, so I suppose they fuzzily have to injure themselves — or does a nonzero fraction of suicide have the same effect/value/whatever as a full suicide?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ade9c4552cc7b431789bbca0b1a342e855682531180d28882e760db939d7b711-387af8e07c0b3b3656e1254820e9000817d110d1c416d19d0e6008a8519bffec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sav")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-41731")[#strong[#text("Sav")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2009")])]

#text("The only thing that happens to the tribe is that they “lose trust in the visitor”. He had won their trust and then they learned that he knew his own eye color and was still alive which is contray to their belief. They know nothing more about their own eye color then before the visitor came to the island. Unless, we were given the information that he looked at only one person or was looking directly at one person when he spoke about his eye color, we cannot assume that anyone deduced they had discovered their eye color. One can project that they demanded he commit suicide in order to pay tribute to their religion, but that would be more drama than fact.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8d19a62dc2c9cca6720ea3deb21b2677cf6e1c97fa1962e701f917b0c980028-77b42268598c6ce510b0f6844e53a5850ec1e822ff153159d7ab85c4850ccd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dietmar Kulsch")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42036")[#strong[#text("Dietmar Kulsch")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2009")])]

#text("There’s another obvious logical flaw.")

#text("All we know is that the foreigner, in the case that there are 100 blue eyed people, makes his statement.")

#text("The tacid assumption then is that, if there were only one blue eyed person, the foreigner would say exactly the same.")

#text("While this certainly sounds fairly reasonable, there is no strict logical foundation for this conclusion. If there were only one blue eyed person, the foreigner may or may not make his remark.")

#text("I may logically postulate that, if there is only one blue eyed person, this foreigner will say nothing. Since the presumption of my statement is obviously false (there is more than one blue eyed person), my conclusion is logically true. But the opposite conclusion is also true (ex falso quodlibet).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca049e02570449cd97c7046be009a3409a8be5442e4b3fd0a5f91d89420a31d6-beeb0f40645d70792055f7d565f8ed8b7be6a5f8062f2cd5e79a43657638f9bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42190")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2009")])]

#text("I did not have time to read through all the comments to see if this has been already mentioned, but this is very similar to the muddy children puzzle and other logic puzzles (")#link("http://en.wikipedia.org/wiki/Induction_puzzles")[#text("http://en.wikipedia.org/wiki/Induction_puzzles")]#text("). It can be modelled using multi-agent epistemic logic to show that n blue eyed people would commit suicide after n days, assuming of course that they are all perfect logicians themselves. (which is stated in the puzzle, and of course means that they would immediately know the answer to this puzzle also)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fe63346010441d38f6f6a601a5deb12e7090cc252ca60e2a162778f702e2df4-7870c397f8e2e5c58ecae94515387d306ccfdb24a40af9885f924545cf2dbfa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42207")[#strong[#text("Yale")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2009")])]

#text("The induction argument makes sense, but I don’t think it’s correct. The problem is it fails to take into account one key fact. The traveler gives them the information that at least one person has blue eyes. However, the fact that nobody kills himself after the first day comes as no surprise to the islanders. Indeed, they all know in advance with 100% certainty that nobody will kill himself, because each islander can plainly see that there are at least 99 or 100 blue eyed people on the island. So after the first day, they still only know that there is at least one blue eyed person on the island. They cannot logically conclude that there must be at least two blue eyed people on the island on that basis alone, because the fact that nobody killed himself provides no new information. So they are left in exactly the same position as before, where they still know that there is at least one blue eyed person on the island, and because they all know that there is more than one–and furthermore, they all know that everybody knows there is more than one–nobody will kill himself.")

#text("The induction argument is based on the premise that the fact that nobody kills himself after each day reveals new information. But because each islander, being completely logical, could conclude prior to the appointed suicide time that nobody would kill himself (and could also conclude that everybody else would be able to reach the same conclusion), all of the information that can possibly be discovered by anybody is already known to everybody at the outset, and therefore the induction argument is invalid.")

#text("It would be true for two blue eyed people only, because in that case both of the blue eyed people would learn something new when the other blue eyed person doesn’t commit suicide as expected. But for three or more, the fact that nobody would commit suicide after the first day doesn’t add any new information, because everybody on the island knows that nobody will commit suicide, given that there is definitely more than one (but still some unknown number more than one) person with blue eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42303")[#strong[#text("In the Long Run We Are All Dead « The Twofold Gaze")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2009")]

#text("[…] 7, 2009 · Leave a Comment Quoting Terry Tao, albeit with small modifications, There is an island upon which a tribe resides. The tribe consists […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/841201122e23de401dd89ce47fe13091f7aa63571afb78ffced6f287b128c80d-8760ccc30d38474dfd919026362d9b422ad4145033b00cbd1f97015ef6da9a5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of freddo")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42342")[#strong[#text("freddo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")])]

#text("More such daily puzzles at:")

#link("http://tough-nut.blogspot.com/")[#text("http://tough-nut.blogspot.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42355")[#strong[#text("Brain Teaser at Steven Landsburg | The Big Questions: Tackling the Problems of Philosophy with Ideas from Mathematics, Economics, and Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2009")]

#text("[…] teaser has more than a little in common with a brain teaser that recently got a lot of play over on the blog of the Fields-medal winning mathematician Terence Tao: There is an island upon which a tribe resides. The tribe consists of 1000 people, with various […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8d19a62dc2c9cca6720ea3deb21b2677cf6e1c97fa1962e701f917b0c980028-77b42268598c6ce510b0f6844e53a5850ec1e822ff153159d7ab85c4850ccd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dietmar Kulsch")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42357")[#strong[#text("Dietmar Kulsch")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Maybe it helps to understand what happens if we allow the chief of the tribe to announce the obvious, without talking directly about eye colors:")

#text("After the foreigner makes his remark, the chief might call the tribe together and say:")

#text("“Listen! We all have heard that the foreigner has announced that there is at least one blue eyed person among us. Some of us may think this comes as no surprise. I am not allowed to comment directly on that. However, since we all know the foreigner as a trusted person, we have now to assume his remark as common knowledge.”")

#text("“I may – just a formality – remind you all that should anyone of us see only brown eyed persons, he would now have to conclude that he is the only person who has blue eyes, and by the rules of our tribe has to commit suicide this night.”")

#text("After the first night, the chief might say:")

#text("“I hereby acknowledge that nobody committed suicide this night. Again, some of us may think this comes as no surprise. I cannot comment on that directly.”")

#text("“However, while I may certainly not comment directly on our eye colours, I still can announce it is now logically clear for everyone and therefore can be assumed as common knowledge that there are at least two blue eyed persons. So again may I remind you all – certainly just a formality – that by the rules of our tribe, those who should see only one blue eyed person would have to conclude that they have blue eyes, and have to commit suicide this night.”")

#text("And so on.")

#text("There seems to be no paradox any more if we allow the chief to declare openly what logic conclusions the tribespersons are obliged to draw.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42066f5360c988c4b9eaa7b857fe7cc2fa1c7bcc082c2a079736ec73a5b0815-c7b3cf2d99b95113971ec6ea21d306793c2c5c8a2a88758f1a22da0f9db3f875.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Hirsch")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42365")[#strong[#text("Steve Hirsch")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("What really would happen is: He’d be mobbed and killed immediately before he could identify the identity of any specific islander. The logical islanders would immediately perceive that he is a threat to public safety whose careless statements could require many islanders to commit suicide. Acting almost as one, they would silence him immediately and permanently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42066f5360c988c4b9eaa7b857fe7cc2fa1c7bcc082c2a079736ec73a5b0815-c7b3cf2d99b95113971ec6ea21d306793c2c5c8a2a88758f1a22da0f9db3f875.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Hirsch")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42366")[#strong[#text("Steve Hirsch")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2009")])]

#text("Excuse typo in my last post. It should have said:")

#text("What really would happen is: He’d be mobbed and killed immediately before he could identify the eye color of any specific islander. The logical islanders would immediately perceive that he is a threat to public safety whose careless statements could require many islanders to commit suicide. Acting almost as one, they would silence him immediately and permanently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42381")[#strong[#text("Weekend Roundup at Steven Landsburg | The Big Questions: Tackling the Problems of Philosophy with Ideas from Mathematics, Economics, and Physics")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2009")]

#text("[…] namely that honest truthseekers can’t agree to disagree. I threw in a comparison to a related brain teaser about blue-eyed islanders, and my own brain teaser was quickly forgotten as the blue-eyed islanders […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2009")])]

#text("I’m not taking the time to read all of these, but the answer is very simple. I could as likely have green eyes as blue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8d19a62dc2c9cca6720ea3deb21b2677cf6e1c97fa1962e701f917b0c980028-77b42268598c6ce510b0f6844e53a5850ec1e822ff153159d7ab85c4850ccd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dietmar Kulsch")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42427")[#strong[#text("Dietmar Kulsch")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2009")])]

#text("Can anyone answer the following question?")

#text("Let’s assume that 14 days have passed after the foreigner’s remark.")

#text("Now he adresses the tribe again:")

#text("“Two weeks ago I told you that I saw at least one blue eyed person. Meanwhile I can say that there are indeed many more.”")

#text("“I tried to count them, but stopped counting at 20, because I noticed there are so many more. I can say that I am now sure that more or less half of the population have blue eyes, even if I don’t know the exact number.”")

#text("The foreigner obviously gives additional information, but thereby disturbes the running clock. Should the tribespersons continue with their schedule, i. e. there are at least 14 persons? Or should they now assume that there are at least 20 persons? After all anyone can verify that the foreigner is also right with his remark that more or less half of the population has blue eyes.")

#text("Obviously the foreigner changes to fuzzy logic now: There are 20 persons for sure, but since he has seen “many more”, there are at least 22 (if we assume “many” means at least two) – but the probability that there are only 22 is “practically zero”. In fact, anyone can verify immediately that there are more than 22.")

#text("What will happen?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42599")[#strong[#text("Uri Nieto » El Acertijo de los Isleños de Ojos Azules")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2009")]

#text("[…] poco me contaron el mejor acertijo que haya escuchado nunca: El Acertijo de los isleños de Ojos Azules. Este acertijo usa la lógica pura de las matemáticas, el resultado es precioso y me produce un […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81a0724ec90e59e8b9d93c276bab1bd5cdde01131ad18a18f24acf95792e99f4-9dfca277fdb26789cc2a4dfbbd9866fadf7d70f7554157fb47ee8a968b7e6978.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narendra")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42698")[#strong[#text("Narendra")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2009")])]

#text("Let us assume there are n blue eyed people on the island.")

#text("Argument 1 is flawed because it fails for n = 1 in which case the information given by the foreigner is of value.")

#text("Coming to Argument 2:")

#text("Each of the blue eyed tribal has a doubt that there are either n-1 or n blue eyed people. Now this doubt has also become a common knowledge among all the blue eyed islanders. Let us call this doubt d.")

#text("Argument 2 would work for only one value of n that is 1.")#linebreak()#text(" For Argument 2 to work for n = 1 it requires the information given by the foreigner.")#linebreak()#text(" And for any other value n > 1 Argument 2 would not work even with the information given by the foreigner in the puzzle statement as it fails to dispel the doubt d of the tribals.")

#text("If the foreigner says that there are atleast k blue eyed people where k < n noone would commit suicide at all because it fails to dispel the doubt d of the tribals.")

#text("Now for Argument 2 to work as mentioned it requires the exact number n to be specified by the foreigner. And in this situation where the foreigner specifies the exact number of blue eyed people the puzzle becomes identical to the article specified in wikipedia about common knowledge.")

#text("Argument 2 tempts one to think it would work for any n. But what is that instance of n, noone in the island knows so it fails to dispel the doubt d ..so it is flawed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wangzirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42967")[#strong[#text("wangzirui")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("How do you prove that “at that stage they have no evidence that they themselves are blue-eyed”? It seems hard to give a proof of this statement. This is a weakness of the induction argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("One can formalise the concept of “no evidence” by considering two parallel universes, one in which a given islander is blue eyed, and one in which that islander is brown eyed, and showing that both universes are consistent with the information given so far. (Actually constructing the universes is a little tricky, though, because one has to specify not just whether islander A has blue eyes, but whether islander B knows that islander A has blue eyes, whether islander C knows that islander B knows that islander A has blue eyes, and so forth. It can be done – it’s easier to start with a simpler situation, e.g. one with just two islanders – but does require a certain amount of effort.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Zirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42986")[#strong[#text("Wang Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("OK. So in the brown universe the other person should kill himself. But the problem is that the blue universe is precisely the case we try to analyze. I mean it’s circular: We start by supposing there are two blue-eyed persons, then one of them supposes he is blue-eyed and goes to the start of our analysis. Why is it consistent with our current knowledge?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42987")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("At no point do any of the islanders “suppose” that they are blue-eyed. Instead, each of the blue-eyed islanders eventually ")#emph[#text("deduces")]#text(" that they are blue-eyed, by realising that the hypothesis that they are brown-eyed leads to a conclusion which is not supported by their own observation (namely, that it would cause the other blue-eyed islanders to commit suicide at a certain date). As soon as this deduction is made, no further analysis on the part of the blue-eyed islander is needed; by the laws of that islander’s religion, the islander must now commit suicide on the noon of the next day.")

#text("The key to resolving the puzzle correctly is to carefully distinguish between what we (as outside observers) know to be true, what each islander knows (or can deduce) to be true, what each islander knows what other islanders know to be true, and so forth. Failing to distinguish these different levels of knowledge properly is likely to lead to significant confusion.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Zirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42988")[#strong[#text("Wang Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("What I mean by “supposing” an islander himself is blue-eyed is to consider the universe in which he is blue-eyed. In your previous post you said we should consider such a universe in order to reach the “no evidence” conclusion. I mean this universe is the same as the case we are considering, so it’s circular.")

#text("Maybe my understanding of the concept of universe is not right. In that case, please elaborate on the difference between “considering a universe” and making an assumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43002")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("The more precise statement is that the universe is infinite, rather than circular. One can define the universe in a logical sense to be the truth value of all the statements that one can make in the world, such as")

#text("“A has blue eyes”.")#linebreak()#text(" “B knows that A has blue eyes”")#linebreak()#text(" “A knows that A has blue eyes”")#linebreak()#text(" “A knows that at least one islander has blue eyes”")#linebreak()#text(" “C knows that B knows that A has blue eyes”")

#text("etc. This is an infinite collection of statements, and so in that sense the universe is infinite even if the number of islanders is finite.")

#text("Now, the universe does contain copies of itself, in the sense that if X is a meaningful statement in the universe, then so is “A knows that X is true”. This does demonstrate the infinite nature of the universe, and so some care is required to ensure that one can consistently assign a truth value to every such statement, but this can be done if one is careful enough; mathematicians have learned how to safely handle infinite sets over the years. :-) [For instance, one can induct on the “depth” of the statements in the universe – roughly, the number of times the phrase “knows that” is used. One can first consistently assign truth values to depth 0 statements, then to depth 1 statements, and so forth. To do everything completely formally, one would need to introduce a ")#link("http://en.wikipedia.org/wiki/Epistemic_modal_logic")[#text("epistemic modal logic")]#text(" system, but this can be done, although it is somewhat tedious.]")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Zirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43018")[#strong[#text("Wang Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2009")])]

#text("I think Argument 2 is only good enough to prove that Argument 1 is false. For the purpose of contradiction, suppose that Argument 1 is true, that is, no islander will die, if the number of blue-eyed islanders is >= 2. Now consider the case of two blue islanders. One of them could suppose he is not blue-eyed. Then the other guy should have realized that he is the only blue-eyed and killed himself. But Argument 1 says no one dies, so contradiction. So this islander is blue-eyed. So he kills himself and by symmetry the other guy kills himself too. Again contradiction with Argument 1, so Argument 1 is false.")

#text("Note that Argument 2 relies on (a weaker version of) Argument 1 in an essential way. Whatever way you use to prove that no one dies by the noon of the first day proves the weaker version of Argument 1, that is, no islander dies by the noon of the first day, instead of forever. Therefore by saying Argument 2 is unconditionally right, you are also supporting Argument 1, to some extent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81a0724ec90e59e8b9d93c276bab1bd5cdde01131ad18a18f24acf95792e99f4-9dfca277fdb26789cc2a4dfbbd9866fadf7d70f7554157fb47ee8a968b7e6978.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narendra")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42989")[#strong[#text("Narendra")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Prof Tao,")

#text("In the argument 2 the tribes themselves have no way of knowing what is the instance value of ‘n’. I mean the argument has no connection to the real world operation. An argument is said to be true if what it deduces operates in the real world and false if it does not operate. Please let me know if I am missing something.")

#text("Thanks")#linebreak()#text(" Narendra")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81a0724ec90e59e8b9d93c276bab1bd5cdde01131ad18a18f24acf95792e99f4-9dfca277fdb26789cc2a4dfbbd9866fadf7d70f7554157fb47ee8a968b7e6978.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narendra")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42990")[#strong[#text("Narendra")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Please ignore my previous comment. I guess I got it wrong . Just wanted to add something more.. if n > 1 the logic of argument 2 would have been in operation the day the rules were made..without requiring the foreigners information. Looks like only when n=1 the logic of argument 2 requires the foreigners information.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81a0724ec90e59e8b9d93c276bab1bd5cdde01131ad18a18f24acf95792e99f4-9dfca277fdb26789cc2a4dfbbd9866fadf7d70f7554157fb47ee8a968b7e6978.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Narendra")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-42996")[#strong[#text("Narendra")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("I understand what you are trying to say. But since the problem statement also has a emphasis on the value of foreigner’s information, for")#linebreak()#text(" n = 1, Argument 2 requires foreigners information and for other n, the settings and rules of the tribes are enough to trigger the mass suicide. And")#linebreak()#text(" in this case of n=1, Argument 1 would fail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Zirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43017")[#strong[#text("Wang Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2009")])]

#text("Death doesn’t imply knowledge.")

#text("We are only told that if a person knows his eye color he will commit suicide. But if a person dies, we can’t conclude that it’s because he knows his eye color.")

#text("If such a deduction is valid, this will contradict with the custom that villagers are not allowed to discuss their eye colors, because by dying, a villager is declaring he knows his eye color.")

#text("As a corollary, mass suicide is not possible, because even the blue-eyed villagers all die, the other villagers still don’t know that it’s because the blue-eyed know their eye color. And hence the rest can’t deduce anything about their eye color.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43019")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2009")])]

#text("I think you are confusing the ")#link("http://en.wikipedia.org/wiki/Conversion_(logic)")[#text("converse")]#text(" with the ")#link("http://en.wikipedia.org/wiki/Contrapositive")[#text("contrapositive")]#text(".")

#text("Starting from “if a person knows his eye color, he will commit suicide”, we can take contrapositives and conclude “if a person does not commit suicide, then he does not know his eye color”. This is not the same as the converse statement you mention above.")

#text("(To put it another way, while death does not necessarily imply information about eye colour, ")#emph[#text("lack of")]#text(" death does.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3151fb444dac2da9d36c49f7c60ba206c0112d3ee3d64e9d5d29de3c51a4705e-141b070896f757d38f941b6200574842fd0efa4e8b71cb7abb0655f666a1323a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Zirui")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43025")[#strong[#text("Wang Zirui")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2009")])]

#text("Precisely. But I was making another point.")

#text("Your comment does bring out another point: Since by staying alive a villager is telling others that he does not know his eye color while the custom forbids discussion about eye colors, it follows that all villagers should immediately kill themselves at the start. Otherwise they are discussing their eye colors by staying alive and thereby telling others that they don’t know their eye colors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e25c653dec017309ff53911ff8d7c3dbe59a151bcda457cb1f78c9b4bd37c87f-468f705244ac7db5a6947158df6b3479a15de9357261ab59dc39a3abcadf6206.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lenoxuss")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-48384")[#strong[#text("lenoxuss")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("That’s one of the best points on this page. The original problem may even have to be amended to allow “committing or not committing suicide” as a means to communicate information.")

#text("Another way of simplifying the problem is to say that each islander knows ")#emph[#text("only")]#text(" two things: How many other islanders have a given eye color, and how many within each eye color remain alive. (Plus the knowledge that everyone else has the same knowledge I do.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43022")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2009")])]

#text("A while ago, I wrote two arguments which are less concise but possibly convincing from a diferent angle,")#linebreak()#text(" ")#link("http://twofoldgaze.wordpress.com/2009/11/07/in-the-long-run-we-are-all-dead/")[#text("here")]#text(" and ")#link("http://twofoldgaze.wordpress.com/2009/11/12/in-the-long-run-we-are-all-dead-ii/")[#text("here")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43021")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2009")])]

#text("Professor T.Tao,")#linebreak()#text(" Happy New Year !")#linebreak()#text(" This words comes from China…")#linebreak()#text(" 2009年12月31日23:25:35")#linebreak()#text(" 李志夙（Li Zhisu）")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 98blueeyesatleast")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-43219")[#strong[#text("98blueeyesatleast")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2010")])]

#text("I can follow the induction puzzles of ‘Josephine’s problem’ and ‘Alice at the convention of logicians’ (from ")#link("http://en.wikipedia.org/wiki/Induction_puzzles")[#text("http://en.wikipedia.org/wiki/Induction_puzzles")]#text(") because they have an obvious start time and obvious interval of action, from which they can be solved by induction.")

#text("However the blue-eyed islanders problem doesn’t seem to fall into the same category for me. The foreigner doesn’t provide any ‘new information’ because it was already common knowledge to EVERYONE that there were greater than 97 blue-eyed people on the island (because everyone sees at least 99 and they can each deduce that all those 99 would think there are either 98 or 99 blue-eyed, but not less). I don’t know why you have to recursively try to put yourself into all the other islanders minds about what they might be thinking IF they incorrectly think they might be brown and what the remaining people MIGHT think IF they incorrectly think they might be brown and so on and so on. I think if they’re perfect logicians, they can easily prove (as a first person observer) that everyone already knows there are at least 98 blue-eye people on the island. I don’t see why anyone on the island would be getting any new information on days 1-97 when nobody has committed suicide. The ONLY thing the foreigner introduces (at least the way I’m thinking) is the starting gun to initiate the “from this day forward, if you know for sure you have blue eyes, you need to commit suicide at noon of the next day”. If the suicide directive were introduced with the foreigner, then I think it falls into the same category as the puzzles above in which the directive, start time AND time interval are all introduced at once! Maybe this just goes back to other arguments that state that this island is not stable if the suicide directive already existed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("You are certainly going in the right direction, but the concept of “common knowledge” goes further than that. To show greater than 97 blue-eyed people is common knowledge, you need to show everyone knows that everyone else knows that everyone else knows there are >97 blue-eyed people on the island. That is, everyone knows that everyone else knows there are >97 blue-eyed people on the island, and everyone knows everyone else knows THAT fact. Of course “common knowledge” doesn’t stop here. At every level of iteration the number of blue-eyed people decreases by 1, so at about 100’th level, one can conclude that is not common knowledge that there is at least one blue-eyed person. So the foreigner did introduce something new.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b8ac2b3e0854614109248d3146e3c9a87739d124739847f01ba182335af95c5-0b0cfa17a057f717de73437d894960c16336a69728206a67cf43f6ea5bf9e947.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jim")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44933")[#strong[#text("jim")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2010")])]

#text("The simplest argument to show that nothing will happen on the island is, in the case of exactly 100 blue eyed and 100 brown eyed people, to look at four cases:")#linebreak()#text(" 1. The foreigner remarks on seeing blue eyes.")#linebreak()#text(" 2. The foreigner remarks on seeing brown eyes.")#linebreak()#text(" 3. The foreigner remarks on seeing brown and blue eyes.")#linebreak()#text(" 4. The foreigner asks everyone to deduce his/her own eye color without making any remark about what he sees. Assume there is a taboo about thinking about one’s own eye color until he arrives or some such detail.")

#text("Clearly one can’t both deduce in case 1 that all the blue eyed people leave the island/commit suicide/whatever on the 100th day and then in case 2 deduce that the brown eyed people do the same. In both cases no new information is given. If that isn’t sufficient argument then surely case 3 should give one pause, or if that fails, case 4 where no information at all is given but only a starting time for people to think logically.")

#text("So where does the inductive argument fail? On an island with one blue eyed person and some brown eyed people clearly something happens if the foreigner claims to see blue eyes. Likewise an island with two blue eyed people.")

#text("However nothing at all happens on an island with 3 blue eyed people. This is because everyone deduces, regardless of one’s own eye color, that nothing will happen on the first day. Hence no new information will be gleaned from observing events on the first day. Since no new information is acquired by waiting one day how can there be any information acquired on any subsequent day?")

#text("If you don’t like the inductive argument blowing up that fast consider an island with four blue eyed people where not only does everyone know that nothing will happen on the first day but everyone knows that everyone else knows it as well. So what is everyone waiting for?")

#text("I have given this problem for years to my high school students and not one of them has ever taken my side on it. I think they confuse putative islands of one, two, etc., blue eyed people with the actual island given, that has 100 of each. No one on the island of 100 blue eyed and 100 brown eyed people imagines that they actually live on an island with one, two, etc. people and if no one imagines this then where is the induction?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44151")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Dear Professor Tao:")

#text("I just read a paper named “Agreeing to disagree” written by Robert Aumann in 1976, published in a statistics journal, which announced a somewhat surprising conclusion, that,")#linebreak()#text(" “If two people have the same priors, and their posteriors for an event A are common knowledge, then these posteriors are equal.”")

#text("It may be a little off the topic, but the notion “common knowledge” is the very basis from which the above conclusion was drawed. Here is the link to that work:")

#link("http://www.econ.brown.edu/Students/Debipriya_Chatterjee/EC2060page/Readings/Aumann76.pdf")[#text("Click to access Aumann76.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44152")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Yet in this puzzle, there is no direct communications between the islanders, except the fact that the common knowledge is announced. But they use their actions to accomplish the communications. (i.e. to commit suicide or not.) Eventually they actually all get the whole picture, which means the these posteriors are jsut equal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ccd244d3607cd017bf254327d075f2c28d9f45729d5d1baba201825fc3d23f8-22b234b9d16bfc0986c64a35635a2235b15db3d0884fbfdb066c29b4177f131d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44237")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("Here is an example of common knowledge from the pop culture :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fb3f08ce5d9cc909449cd5b2073dc89f507dac1cd98d5ceb1686db9f764efd6-a2b625fa50562dc6b0a0722ea7b04a17e8f44b51acb9476ea2dc74522b549f6e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cooperback")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44263")[#strong[#text("cooperback")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2010")])]

#text("it’s not much, but if none of the islanders has blue eyes, then they all commit suicide after the words of the stranger")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Provence 2010 « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44460")[#strong[#text("Provence 2010 « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2010")])]

#text("[…] Aufgabe für die Praktiker: Das “Blue Eyed Islanders Puzzle” Problem von T. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93a9ecee39df216996a53ecb8277da88d5f391d704bea3c0641c91d6fbebbac5-cd576d9b7397d581e1e39cdc84660bb314144e97c98930973cb1d90d199cbbde.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ji")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-44750")[#strong[#text("Ji")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("I just want to add the statement 2 that one day after all blue-eyed islanders committed suicide, the island will be unoccupied.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8c724e89d014e898a73143866cc5b2a695d4709715e8f3a3b31c49cbf57b9bec-40d65d27fd4d14c18d8e6b91fe996ecef752204a589673a9fccee61b0f19703d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgar")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45116")[#strong[#text("Edgar")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2010")])]

#text("If there are 2 blue-eyed people, Blue-1 will see Blue-2 and not leave because he is unsure whether the guru meant Blue-1 or 2. Blue-2 reasons the same way.")

#text("The next day, they both realize that the other did not leave because they saw someone with blue eyes. That someone has to be themselves; both blues kill themselves.")

#text("With 3 people, however,on the second day Blue-1 sees that Blue-2 and Blue-3 did not leave. But this tells him no information about himself! Blue-2 could have decided not to leave because he still saw Blue-3 and thought he didn’t have to be blue-eyed. Blue-3 could have seen Blue-2 (in the opinion of Blue-1) or Blue-1 (in the opinion of BLue-2). Blue-1 could still have any color eyes (or so he thinks), same as the other blues.")

#text("Obviously, any brown-eyed person could also think of themselves as having green or red eyes, and never kill themselves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02301ca7c83d7dea3bdba89fb65b42e09b5a71701e04f0acd6cf14a8bc543ad4-02a940789782373194cf49f79473458a061535f7b2dd3953a43b0efd4bcc6a45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of palibacsi")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45126")[#strong[#text("palibacsi")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2010")])]

#text("Dear Edgar,")

#text("if there are 3 blue-eyed persons, each of them knows that there either two or three blue-eyed ones. If there were only two of them, they would kill themselves on the second day. If nobody kills herself on that day, every blue-eyed person concludes that there must be at least three of them, from which all the blue-eyed ones now know their eye-colour and are going to commit suicide the next day.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/508461b274493e6d039d379e0f4b372d1371396ad62702787bdec2c1bcb304eb-e9b33a6565f94023cc7af3f6491312079f0be4703e4e586aa6d6dcd5706674b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bender")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45189")[#strong[#text("Bender")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2010")])]

#text("Listen up meatbags.")

#text("I’ve asked Professor Farnsworth to fire up his brand spanking new invention the Calcuanator 5000 (with extra spank) and get to the bottom of this. Results: no new information regarding eye color provided by the foreigner. I was about to tell you all this, but then that do-gooder Ethan “Bubblegum” Tate showed up, acting all smug in his fancy white lab coat. Anyways, Bubblegum says “It’s not about new eye color information baby, the razzamatazz is all in the reference point.” Bubblegum also says the brown eyed peeps keep on keeping on, they all thinking they the only one got green eyes.")

#text("Now to find me some inorganic nookie . . . or something to steal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45512")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2010")])]

#text("(I do not know if this is already discussed in the 397 answers.) There are three challenges regarding this problem: The first is to prove by induction what will happen after 100 days. The second is to explain (via common knowledge) what information is gained by a statement that seemingly carries no information. The third and most important is to find a less somber way to tell the puzzle. (The colored eyed version is already a more politically correct version compared to some other versions where one member of a family kills another, yet this version is still rather macabre.)")

#text("One variation is that all young people have long golden hair and spend their time in pleasures, logic riddles, and football. However, once a youngster discovers the colour of his eyes, he is considered an adult, lose the spoiling benefits of youth, and he has to shave his head in the town square.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samthebazi")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45519")[#strong[#text("samthebazi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2010")])]

#text("The common knowledge is not the color of eyes, it is the unanimously agreed upon mark in time where all start counting days. The mark in time is the day the the announcer makes the announcement. All islanders have the same common knowledge then. If each islander was told in secret the same announcement with the following twist “I saw blue eyes on the island and I told and will be telling the rest of the people on different days”, then in case of two islander with blue eys, none will commit suicide either because they would not have a common mark in time to make a conclusion when the other did not commit suicide.")

#text("Sorry if I am repeating anyone’s words; I only read the first 20 or so comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4311c5db086f89615351f4ffe1743fbe198890e09b42de6cd4130eb0edd9bd2-6ee0af59120128670a2e8c3ed7523195f89d8c64d4c6e2221dbbadf6442da214.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tal")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45670")[#strong[#text("Tal")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2010")])]

#text("The induction argument gives an upper bound for the number of days by which those with blue eyes can determine their eye color. However, it does not explicitly rule out the possibility of more efficient reasoning that reaches the same conclusion on an earlier day.")

#text("Formalizing the argument in (e.g.) modal logic would bound the reasoning power of the islanders and thus permit solid conclusions about what deductions CANNOT happen within N days, for each N. But this would require a completeness proof, i.e., a clear and convincing argument that whatever logical formalism is used correctly captures all possible “information” and “conclusions” available to the logicians on the island.")#linebreak()#text(" Possibly Aumann’s approach is clearly general enough to encompass this, but again, it may contain hidden assumptions as to what the islanders can and cannot reason about.")

#text("To see the difficulty, think about what if the visitor had made a higher-order statement such as “in the first draft of my speech, there were comments that, had I made them, would have certainly caused suicides within 100 days; but luckily, I noticed this in time to strike the comments from the speech I am now making!”. One needs a way of capturing not only the logic that the islanders can perform in a given logical system but a way of seeing that the system analyzed is as strong as possible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad56a2b06644c09a4b235f45d4c1ad8968f65c20c15fe9b388a7426645544d79-ffa9a1b180a4116d16196e1a936009b10497f99e4c74d71ee550ede06f642d60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Wegener")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-45745")[#strong[#text("Henry Wegener")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2010")])]

#text("I don’t know if the following was already mentioned. However, here is why the foreigner does indeed bring new information.")#linebreak()#text(" Let P=’There are blue-eyed islanders.’")#linebreak()#text(" Say there are in fact n blue-eyed islanders ")#mi("A_1,...,A_n")#text(".")#linebreak()#text(" In case of n=1,2, P is no common knowledge.")#linebreak()#text(" In case of n=3: ")#mi("A_1")#text(" knows P, and knows that ")#mi("A_2")#text(" knows P, but does not know that ")#mi("A_2")#text(" knows that ")#mi("A_3")#text(" knows P.")#linebreak()#text(" In case of n=4, ")#mi("A_1")#text(" doesn’t know that ")#mi("A_2")#text(" knows that ")#mi("A_3")#text(" knows that ")#mi("A_4")#text(" knows P…")#linebreak()#text(" This shows that P is no common knowledge before the foreigner’s address. The justification of argument 1 is false.")#linebreak()#text(" Again sorry for repeating, if I did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c1e2ddc6e1564fd7d9e9b39463d3d9566d14f650310dd090cffa471d577bd8-596bf8ff3666074677546ac165e54a596c7a839fd86f4e5d9caf1de7de0685a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aleks.")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-46276")[#strong[#text("aleks.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2010")])]

#text("If such an island would exist (given premises) the logicians inhabiting")#linebreak()#text(" would immediately gather in the village square and group in two*. At the moment all realize there is no 3’d eye-color (that they all belong to group A or B) an understanding will be reached. They then wait for first noon and commit mass suicide.")

#text("(*by instruction not discussion).")

#text("There is no other correct solution to the puzzle and the the information")#linebreak()#text(" on the foreigner is irrelevant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c1e2ddc6e1564fd7d9e9b39463d3d9566d14f650310dd090cffa471d577bd8-596bf8ff3666074677546ac165e54a596c7a839fd86f4e5d9caf1de7de0685a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aleks.")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-46281")[#strong[#text("aleks.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2010")])]

#text("Even better they will all reach the conclusion that their religion is not")#linebreak()#text(" logical and so mass-convert by not committing the ritual suicide. The visitor would then later be friendly welcomed by enlightened (and logic-scientific) islanders not ridden by superstition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c1e2ddc6e1564fd7d9e9b39463d3d9566d14f650310dd090cffa471d577bd8-596bf8ff3666074677546ac165e54a596c7a839fd86f4e5d9caf1de7de0685a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aleks.")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-46283")[#strong[#text("aleks.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2010")])]

#text("If the puzzle is (more correctly) re-phrased it should sound like this:")

#text("In an experiment a number of persons are put in room where they all see each other but have no way of internal communication whatsoever. On their heads are caps clearly visible to all. These caps are in different colors. The persons are told they escape the experiments by correctly guessing their own cap color (and punished badly if they give wrong answer). The only access to answering is by pushing a button that opens once every N minutes. All participants are professors of mathematics and none are senile or retarded. Assume none of them makes a mistake when… Etc.")

#text("(As easily seen a more precise re-phrase gives a more obvious answer. By adding words like tribe, suicide, discuss, topic and religion the example becomes too unclear to answer using plain logic.)")

#text("The main deal is: all are unsure of whether they possess the only extra color in the group (theoretically a grey/green/yellow cap could be on the head of one of the contestants) when all they see around them are caps of two distinct colors??")

#text("Let’s see what happens. First 99 (as example mentioned) periods no button is pushed. If the question is giving an answer based on logical proof (as opposed to qualified guesswork based on probability) no button may be pushed the 100th either. Any cap could be green. Even after an infinite number of time periods no-one could be fully sure they do not sport an odd colored cap.")

#text("The addition of an extra mathematician sporting a blue cap would trigger the needed chain reaction in order to finish the experiment. Day 100 the realization would come (as stated and explained above) as every blue-cap understands the 99 others are not staring at 1000 brown caps plus 1 green (or yellow) and the other 98 blues.")

#text("Or would it???")

#text("Say a more strict experiment is put up. A number of hyper-intelligent species (sporting super-computers) are put in isolated cages. They are told the total number of other cages in the experiment and the color on each cage. No communication is possible (due to to an unbreakable firewall system).")

#text("In the above example (translated) 100 cages will be told there are 900 brown cages and and 99 blue cages. 900 cages will hear there are 100 blue cages and 899 brown cages. Each must then decide their own status.")

#text("The possibilities are; 900A-99B-1X, 899A-100B-1X,")#linebreak()#text(" 900A-100B,")#linebreak()#text(" 899A-101B, 901A-99B")#linebreak()#text(" where X is a different color than blue or brown. The last two scenarios are")#linebreak()#text(" of course unlikely but not yet known to the A’s and B’s.")

#text("As we now see the problem is unsolvable to all participants until more information is given (this marks the difference between a proof and statistic possibility.)")

#text("On a given period of time -(when there is agreed on a signal every N minutes, we must also here assume no cages are travelling at light speed or are close to black holes, time periods must be synchronized)- a message is delivered to all cages that an extra blue cage is added and it’s habitant is happy to register/see another blue cage present. What happens next?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-46347")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2010")])]

#text("The link explains this puzzle in detail")

#link("http://www.rawkam.com/?p=978")[#text("http://www.rawkam.com/?p=978")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d592f4c736baa084ba99e38448e0ed5f93b0740656b44e6813d1239d7483027-646939168414b819b1ff1cd35bdb4174dc43867f8efecb0d115375e857033b3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mariusz")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47225")[#strong[#text("Mariusz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2010")])]

#text("This is a related, simpler problem – may help understand the solution:")#linebreak()#text(" ")#link("http://mariuszessays.blogspot.com/2009/10/masters-of-logic-puzzle.html")[#text("http://mariuszessays.blogspot.com/2009/10/masters-of-logic-puzzle.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54ccbe1880562cda3072982ac2c7749bf0422d7babad74e672cdd14baf0500b0-b86ef7f20f8f0796d87643aa105a78c2651b51b97828b9693596439e9b0d5e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick S")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47344")[#strong[#text("Nick S")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")])]

#text("Cool problem, when do we get the solution? :)")

#text("I think that the second proof is rigth. If the traveler doesn’t make that statement, the 100 blue eyes don’t suicide after 100 days because… 100 days from WHEN?")

#text("The traveler gives them an important piece of information, gives them a starting point for their rationale. And in my oppinion, the main reason why induction works in this case is because not only each islander can make the induction argument, but they know that each other islander can make exactly the same argument in exactly the same day (without the statement of the visitor this is not the case).")

#text("In shorter words the visitor gave them the following piece of information, which is critical for the induction: you can all start reasoning now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fe63346010441d38f6f6a601a5deb12e7090cc252ca60e2a162778f702e2df4-7870c397f8e2e5c58ecae94515387d306ccfdb24a40af9885f924545cf2dbfa5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yale")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47345")[#strong[#text("Yale")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")])]

#text("I’ve done some more thinking about this problem, and I believe I can prove through reductio ad absurdum that the second argument is logically impossible.")

#text("From the description of the problem: “for the purposes of this logic puzzle, “highly logical” means that any conclusion that can logically deduced from the information and observations available to an islander, will automatically be known to that islander.”")

#text("So let’s assume the second argument to be correct. Under that assumption, the event that starts the countdown to the mass suicide is the knowledge that everybody on the island now knows that there is at least one blue eyed person (and everybody knowing that everybody else knows that fact). But given that there are at least three blue eyed people on the island, it must already be the case that every islander knows that every other islander knows that there is at least one blue eyed person on the island. After all, these islanders are “highly logical” and automatically deduce any fact that they are capable of deducing. So the countdown must have started at some point before the visitor came to the island. Therefore, the puzzle is itself paradoxical. In other words, the second argument is a solution to a puzzle that cannot logically exist if the second argument is correct.")

#text("The only way to prove that the second argument is correct is to explain why the islanders didn’t figure things out before the visitor ever reached the island. But the only way to do that is to invalidate one of the premises of the puzzle.")

#text("Note, however, that this does not necessarily invalidate the general problem, but merely invalidates this particular case. For example, the similar “cheating husbands problem” is essentially a restatement of this problem in a way that avoids this paradox. It would also be possible to modify this problem to resolve the paradox, by eliminating the visitor and the suicide requirement (although keeping the taboo on discussing eye color), and instead having the high priest announce one day that anybody who deduces his own eye color must plunge himself into the ocean, or jump off a cliff, or perform any public activity in full view of the islanders on noon the day after discovery.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54ccbe1880562cda3072982ac2c7749bf0422d7babad74e672cdd14baf0500b0-b86ef7f20f8f0796d87643aa105a78c2651b51b97828b9693596439e9b0d5e8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick S")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47346")[#strong[#text("Nick S")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2010")])]

#text("@Yale")

#text("What starts the argument is not the knowledge that there is at least a blue eyed person on the island, and that everyone knows it. What starts the argument is the fact that everyons STARTS reasoning at the same time, and that they know it.")

#text("To over simplify the problem, the traveler statement tell them the following:")#linebreak()#text(" “If there is only one blue eyed person on the Island he will suicide tomorrow”. This is implied in his statement, is a completelly new piece of information, and without it the induction is not possible ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01c9959c9760007c27f00a94f0e000fbb05e5fc65c2ec4beb7f119b3abd17bba-c888df68cd7dae40d177a87331eb0c19af3c0d156568766775701f3801a45588.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bunbury")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47350")[#strong[#text("bunbury")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Set up like this the induction doesn’t work because it isn’t an induction on the number of people with blue eyes.")

#text("If no visitor turns up a lone blue eyed person can survive. As long as there are at least three people with blue eyes when the visitor turns up nothing happens.")

#text("The induction would only work with the further assumption that a tactless visitor turned up after every new addition and that at one time there were two or fewer people with blue eyes and that the cult members know that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The “no self-defeating object” argument, revisited « What’s new")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47675")[#strong[#text("The “no self-defeating object” argument, revisited « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("[…] Despite the presence of these non-mathematical analogies, though, proofs by contradiction are still often viewed with suspicion and unease by many students of mathematics. Perhaps the quintessential example of this is the standard proof of Cantor’s theorem that the set of real numbers is uncountable. This is about as short and as elegant a proof by contradiction as one can have without being utterly trivial, and despite this (or perhaps because of this) it seems to offend the reason of many people when they are first exposed to it, to an extent far greater than most other results in mathematics. (The only other two examples I know of that come close to doing this are the fact that the real number is equal to 1, and the solution to the blue-eyed islanders puzzle.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc8ed5c87d57a846710296171027933fff23c473ba7fc7db2f518a3d73380458-57fc5df3e1b20113fa8c67216a867110469e336825512105ec3e7263c0f34f91.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yevgeny Liokumovich")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47682")[#strong[#text("Yevgeny Liokumovich")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2010")])]

#text("There is a puzzle that is related to what Maurizio called “synchronizing the knowledge” (sorry if someone already mentioned it):")#linebreak()#text(" On Sunday a prisoner is sentenced to be executed on one of the days of the following week. The judge notes: “You will not know the day when you’re executed until they come for you”. After returning to his cell, the prisoner argued as follows:")#linebreak()#text(" They can not execute me on Sunday for then on Saturday at midnight I will know for sure that I will die on Sunday.")#linebreak()#text(" They can not execute me on Saturday either. Because at the end of the day on Friday I will know that it will have to happen either on Saturday or on Sunday. It can not be Sunday, so it must be Saturday. But since I know that it is Saturday, it can not be Saturday either.")#linebreak()#text(" And so on. He concludes that he can’t be executed.")#linebreak()#text(" Where’s the mistake?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a5fc912b63c1e63554f4cd4ec4a38737c31b4527a7efc1eac1891acc628c52d4-c8a18ffb96cb242151d2704aee4add05b516a8c1e31e5d47bebe29f5db130b76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pratik Poddar")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47778")[#strong[#text("Pratik Poddar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2010")])]

#text("Professor Tao,")

#text("There are various nice problems similar to this. A few are posted ")#link("http://pratikpoddarcse.blogspot.com/2009/10/another-hat-puzzle.html")[#text("here")]

#text("The only information that the foreigner gave was that “lets start counting from today”. So, he helped synchronized local variable for every person to a global variable. That implicit conclusion was what made the difference. In the second argument, you assume everyone starts counting from that day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aquazorcarson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47888")[#strong[#text("aquazorcarson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("What happens if the foreigner instead of saying he saw a blue eyed person, asks the following question: “Is there a blue eyed person among you?”. Then everyone would know that the answer would be yes. I.e., it is equivalent to the foreigner saying I have seen at least one blue eyed person. So how is this any different from the original situation? This is why I feel the foreigner is completely redundant in this problem, and that the villagers will commit suicide spontaneously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad56a2b06644c09a4b235f45d4c1ad8968f65c20c15fe9b388a7426645544d79-ffa9a1b180a4116d16196e1a936009b10497f99e4c74d71ee550ede06f642d60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry Wegener")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47890")[#strong[#text("Henry Wegener")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2010")])]

#text("@aquazorcarson: No. Asking the question is not equivalent to telling the answer. That’s exactly the point in this puzzle.")#linebreak()#text(" Saying “there are blue-eyed people” makes the fact common knowledge for the attendant people. Asking the question does not – so nothing would happen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/856fc0da1c9a3c75de2c315acf5494af282e3af7aabb170248308f60935484d8-1c4fb91b4fd98685e467b536986f76753286c043cc0e48628617abe019ffc86f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Foreigner")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-8/#comment-47953")[#strong[#text("The Foreigner")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2010")])]

#text("As the puzzle states, brown/blue eyed ones doesn’t know their own color and this logical conclusion is logically known to this brilliant islanders.")

#text("After the statement by foreigner, the logical reasoning kicks off in islanders super brain, and they will all logically conclude that, even after historical speech, NO one came to know their own EYE color.")

#text("They all know from day 1 that there are 99-100 blue eyed people here and none of their people knew eye color of their own…")

#text("So the island is another happy, peaceful place, until the moron foreigner open his mouth with more information…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e997f8a926637af51c5cbed3931a46403e2abf5a2339476de3cff9392148afb-931436a33a6eefc041135ef293a466b5946c54c8c7e520672a782b6f782830db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26661")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("“For a very similar reason, if the traveler does not mention eye colour at all, then no information is communicated and no suicides begin at any time.”")

#text("Ok, let me correct the Playing Card analogy so that it matches the problem.")

#text("Formulation 1: Gather 10 people who know and understand this problem, sit them at the table, deal the cards and have them hold them face out. The 11th person walks into the room and says “One of these cards is red” and then starts counting. On the Nth count (where N is the number of red cards) all red cards will be turned up simultaneously.")

#text("Formulation 2: Gather 10 people who know and understand this problem, sit them at the table, deal the cards and have them hold them face out. The 11th person walks into the room and says “Begin” and starts counting. On the Nth count (where N is the number of red cards) all red cards will be turned up simultaneously.")

#text("In cases where at least three red cards have been dealt (to match the Blue Eyed Islander problem), I am understanding that you are saying that in Formulation 1, the players will accurately turn up the red cards every time and in Formulation 2, the players will NOT always accurately turn up the red cards every time. Is this correct?")

#text("Just trying to turn this problem into something that can be empirically tested to prove whether the statements we are making are indeed true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear Randy,")

#text("Assuming that the players are playing using rule (3′) rather than rule (3), your assertions are correct; in Formulation 1, the players will turn up the red cards on the Nth count, whereas in Formulation 2, nobody will turn up their card at any time. (This is easiest to see by first considering the N=0 and N=1 cases (note that the N=0 case does not occur in Formulation 1 but can occur in Formulation 2). For simplicity, one may also want to restrict the number of players to equal 1 or 2.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Churl")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26666")[#strong[#text("Churl")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Suppose that there are zero blue-eyes and the foreigner is joking. The next day all of the brown-eyes commit suicide?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a1734b963de70e4f9869435e9c02e4fc2a9dd545bb883c8efd926902405130d-36eea3aac53c291647ce026bb42a50f3176d5fe510ee117cd7dab5cad7b28b06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26667")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Maybe I am being foolish here but..")

#text("After the visitor leaves, why would only the blue eyed people commit suicide?")

#text("They would not know they had blue eyes")

#text("They would not know how many in their number had blue eyes")

#text("Unless you’re saying that via common knowledge, they can see that 99 other people have blue eyes.")

#text("Why wouldn’t the brown eyed people assume they had blue eyes?")

#text("The visitor did not state how many blue eyed people there were.")

#text("If all hundred blue eyed tribesmen die, that wouldn’t stop the brown eyed people thinking they were blue eyed aswell.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4cccd31c787b77fe4ad2c2e09a8a463225f806881ae9653ded2651b50cf0cfc7-010d72fa6d4bd5cad8d90f7808206e9f8222abd00ad307bb40cdeade887f9885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anh Huynh")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26668")[#strong[#text("Anh Huynh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear Terrence,")#linebreak()#text(" I have a small question, but in order to ask it, I would first modify your statement at 9:51 Feb 26th as “everyone (who is blue-eyed) on the island already knows that there are 99 blue-eyed persons on the island, and assumes that these 99 know that there are 98 blue-eyed persons (that is assuming himself brown-eyed), and also assumes that these 99 assume that those 98 persons know that there are 97 blue-eyed persons, and so on. At every stage there is an assumption, and to the end of the sequence, 2 persons see that there is 1 blue-eyed person, and assume that this person doesn’t see any blue-eyed person”. So normally this sequence ends peacefully. Only when the traveler addresses the tribe does the assumption fail at the last step, which leads to other assumptions being false too. Now my question is: what if the first blue-eyed person in the hierarchy assumes that he is blue-eyed instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d84cc069a4566280ffb6b2893889885bf1b9da4d9403f73350941488edf81e0a-4629fbae08220f1d728378c446f03b6239b745ec9b9b0811afcceaeded7c9a6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hanh Pham")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26669")[#strong[#text("Hanh Pham")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("It seems to me that after these 100 persons commit suicide, the rest will discover that they are brown-eyed, and so they would commit suicide the next day, and the whole population is wiped out. :D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9ece91fd1c052b63d4e3220bc1f8023af8ae3137e75a9d075528edfe095189d-16db09503ade5c0c0c2b46710f6dd403a4d29c98a599727de9d08208a3880c83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duncan M")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26675")[#strong[#text("Duncan M")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("I’m not sure I understand correctly, but just to check:")#linebreak()#text(" Is the key point here that the tribe-people all obtain the common knowledge that the tribe contains at least one blue eyed person at the same time?")

#text("i.e. suppose instead of a stranger coming to the island, and making the unfortunate statement in front of the whole tribe, s/he told:")#linebreak()#text(" – half the tribe on Monday")#linebreak()#text(" – half the tribe on Tuesday")#linebreak()#text(" – both halves of the tribe know they were told, but don’t know when they were told")#linebreak()#text(" would the result be the same?")

#text("Or alternatively, suppose the tribe has a special ceremony where they all gather round in a big circle, and each tribesperson takes turns going around the circle looking into every other tribes-person’s eyes, and furthermore, everyone in the tribe sees everyone in the tribe doing so, would this have the same outcome as in the initial formulation?")

#text("ok. now my brain hurts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a9ece91fd1c052b63d4e3220bc1f8023af8ae3137e75a9d075528edfe095189d-16db09503ade5c0c0c2b46710f6dd403a4d29c98a599727de9d08208a3880c83.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duncan M")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26676")[#strong[#text("Duncan M")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Oops. Ok — I see that the “special ceremony” situation doesn’t cause any mass suicides.")

#text("But I’m still not sure about the delayed case? Would the result be context dependent? i.e. if all the blue eyed people were told at the same time, is that sufficient?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8edec265555b032ca819d412d4f217d1629f67b675be68b4613c234981e05ecc-927b861b45853445a38eab7f4d646e8bd933abd2a16c28c3c1bfcde27c9e518f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dimitri Polyakov")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26716")[#strong[#text("Dimitri Polyakov")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I think the induction method (argument 2) does not work simply because the n=1 case")#linebreak()#text(" is not admissible logically. Indeed, imagine a single blue eyed tribesman")#linebreak()#text(" among other 999 islanders with brown eyes.")#linebreak()#text(" He (or she) knows about the religious prohibition of knowing his own eyes")#linebreak()#text(" color. But the prohibition itself logically implies that there are more than one")#linebreak()#text(" (two) eye colors present. And since the blue eyed person knows for sure")#linebreak()#text(" that the rest 999 of the islanders are brown eyed, he (she) concludes inevitably")#linebreak()#text(" that his (her) eyes must be blue! So in the n=1 case the blue eyed person has to commit")#linebreak()#text(" a suicide at the moment he (she) learns about the religious commandment to do so,")#linebreak()#text(" without any reference to the foreigner. For this reason, the visiting foreigner would never find the island in the n=1 situation and the induction sequence cannot start.")#linebreak()#text(" At the same time, there seems to be absolutely no logical inconsistency in the argument 1, which seems to be the actual solution")#linebreak()#text(" Regards")

#text("which I believe is the actual solution to the problem")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26729")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("Dear Anh: An islander is of course free to assume whatever he or she wishes, but a conclusion based on an unproven assumption does not count as knowledge (though the implication of the conclusion from the hypothesis can be). For instance, if an islander sees 99 blue-eyed islanders and assumes that he or she is also blue-eyed, then this of course implies that there are 100 blue-eyed islanders (and that all other islanders see at least 99 blue-eyed islanders, etc.), but the islander does not know this for a fact since the hypothesis is unproven. Of course, if an assumption eventually leads to an absurd conclusion, then the islander gains the knowledge that the assumption was false. For instance, if an islander sees 99 blue-eyed islanders and assumes that he or she is not blue-eyed, the islander will conclude that the other blue-eyed islanders will commit suicide on the 99th day; if this does not happen, the islander learns that he or she is in fact blue-eyed (and will therefore commit suicide on the 100th day).")

#text("Dear Chris: You may wish to understand a simple case (e.g. one blue-eyed islander and one brown-eyed islander) first; I believe this will answer your question.")

#text("Dear Dimitri: The prohibition merely prevents an islander from ")#emph[#text("knowing")]#text(" one’s own eye colour (or more precisely, from knowing one’s eye colour for more than a day). It may still be ")#emph[#text("true")]#text(" that only one eye colour exists in the population, but truth is not the same as knowledge (and this distinction is the key to understanding the whole puzzle).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1c6342ac1721745a7353468cd3c901d2f73a04aa0acaf218a02ff62ff1eb2d-c7a0c0f4d89df933bff8c10095e5496289ddc8d307ba1797246a4882182011ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsilvestre")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26760")[#strong[#text("dsilvestre")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2008")])]

#text("I’m reading your solving mathematical problems book and I think I can apply some of the things I learned to this problem.")#linebreak()#text(" (Hope I learned well)")

#text("On page 14 on your book you analize a problem like this: “The first sneaky thing to be done is to guess the answer. Circumstancial evidence (this problem is from a mathematics competition) suggests that this is not a trial-and error question”.")

#text("In this problem I would say “I will first try to guess the answer. This is a mathematician’s blog, suggests that the answer is not simply argument 1, as argument 2 seems more sophisticated.”")

#text("Then on your strategies chapter you say “modify the problem slightly”.")#linebreak()#text(" In this sense I would first consider only 1 blue eyed. When the foreigner says what he saids, the only blue eyed gains knowledge on his eyes and comits suicide the next day. If they where two blue-eyes, when the next day no-one suicides, they both gain knowledge and suicide the 2th day.")#linebreak()#text(" And so on if they where 100 blue eyed they would suicide the 100th day. So it look’s better this than argument 1.")

#text("A question, though, would be: do the tribe know that there are in total only 2 eye colors (blue and brown)? because one would pherhaps think they could have green or black eyes, and as they are not sure, they don’t gain knowledge.")

#text("One thing more, if they know there are only two eye colors, after all the blue eyes suicides, all the brown eyed gains knowledge and suicides the next day.")

#text("Sorry if this was already asked before, I didn’t read all the comments.")

#text("Am I on the good road?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ee1c6342ac1721745a7353468cd3c901d2f73a04aa0acaf218a02ff62ff1eb2d-c7a0c0f4d89df933bff8c10095e5496289ddc8d307ba1797246a4882182011ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dsilvestre")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26761")[#strong[#text("dsilvestre")]]#text(size: 9pt, fill: rgb("596477"), " · 29 February 2008")])]

#text("Now I thinked it better and I found something that makes argument 1 somewhat invalid.")

#text("Argument 1 says:")#linebreak()#text(" “The foreigner has no effect, because his comments do not tell the tribe anything that they do not already know (everyone in the tribe can already see that there are several blue-eyed people in their tribe).”")

#text("But this is not completly true, the forainger is indirectly saying something else, he is giving the information (indirectly) that all the blue eyes are going to suicide, from the point of view of a blue eyed on the 99th day or in the 100th day (depending she is brown/blue eyed repectively). For a brown eyed on the 100th day or in the 101th day (depending she is brown/blue eyed).")

#text("Is this correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-26785")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2008")])]

#text("I am now even more sure argument 2 is the valid one.")

#text("Supose we arbitrary choose a sequence of the blue-eyed residents. Lets call it a_n, a_(n-1), …, a_1.")#linebreak()#text(" (In this case n=100 blue-eyed people)")

#text("lema 1:")#linebreak()#text(" every blue-eyed person knows this: at least there are (n-1) blue eyed people (because she sees them), and at most (n).")#linebreak()#text(" lema 2:")#linebreak()#text(" every other-color-eyed person knows this: at least there are (n) blue eyed people, and at most (n+1).")

#text("When the foreigner says what he says, every person thinks like this:")#linebreak()#text(" if I’m not blue-eyed, the foreigner didn’t say anything about my eye color, so I will surely not have to commit suicide.")#linebreak()#text(" But if I am blue-eyed, what I know is this: (I’m a_n, and the number in brackts [] means how many blue-eyed people at least each a_i knows there are)")

#text("a_n [b-1], a_(n-1) [b-2], …, a_1 [0]")

#text("that means a_n knows a_(n-1) knows … etc … that a_1 may not know if there are blue-eyed people on the island.")

#text("but when day (n-1) arrives, using lema 1, noone suicides because they all know there are at least (n-1) blue eyed people, so there still is a chance that they have other-colored eyes.")

#text("lema 3:")#linebreak()#text(" But this means that there have to be more than (n-1) blue eyed people, because everyone knows that everyone knows … etc, that each other is also highly logical, so she realizes everyone other blue-eyed has deduced the same thing like her, that is basically the proof of induction of argument 2.")

#text("lema 4:")#linebreak()#text(" using lema 1 and lema 3 we know that the number of blue eyed has to be exactly (n), so each a_i realizes she’s got blue-eyes, and the next day (day n), all a_i suicide.")

#text("I think if we asume argument 1 we can arrive at a contradiction, because if all the blue eyed are higly logical and knows every other are … etc, they should be able to deduce lema 1 and lema 3, and from their combination lema 4, thus they should suicide.")

#text("I hope this makes at least a bit of sense :)")

#text("I see an analogy between this problem and what in computer science is called a deadlock: example when n process have n recurses (1 proces – 1 recurse) and each other needs a recurse of some other but noone is going to drop the recurses it has, so all the proceesses are hanged. (it’s somewhat cyclic)")#linebreak()#text(" If someone puts an aditional recurse the deadlock can disapear and the process continue operation.")#linebreak()#text(" In this case the aditional recurse would be the information the foreigner tell them so solving the deadlock that no blue-eyed people knows wich is her own eye color.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-29253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2008")])]

#text("Dear Prof.Tao")

#text("I just wonder how can these people’s population reach 1000. This can only happens when the religion started to exist after the 1000th person born, which is not mentioned on the question. But if the religion existed since the day the 1000th person born, then the one who already know their eye color must commit suicide. However, there is an unrealistic condition, that all of them did not know their eye color even before the religion exist although it had not become a taboo. Also, I have a question. Do all the villagers know that there are two eye colors? Sorry for losing mathematical sense from this question.Maybe there must exist two or more eye colors when the religion first exist. But, for example if there was 1001 people, only 1 with the blue eye color, then the blue-eyed die (not by suicide), it can happens that all of the population are brown-eyed. So, if before the death of 1 blue eyed person there exist 2 blue eyed and 999 brown eyed, after 1 blue eyed die, the other blue eyed could not determine his/her eye color. In this case, the foreigner’s statement has an effect. But this case could not happened if the villagers are immortal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alsee")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-29665")[#strong[#text("Alsee")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2008")])]

#text("An even more interesting problem: The visitor states that there are [any-specific-number] eye colors in the tribe.")#linebreak()#text(" Everyone eventually dies, multiple eye colors will suicide on the same day if equal numbers of people have those eye colors, and the largest group will suicide either on the same day as another equal size group or immediately after the second largest group.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cde7d27c5d3ae35625bf7d5e6650b4ce6571c5495c986540ce055b41019ec57f-b7ec0247b9c6671e60ef84f98daebfabe20520b22b3e75e2b6654a2b993019ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramu")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30256")[#strong[#text("Ramu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2008")])]

#text("Dear Professor Tao,")

#text("The induction argument is correct, but I found it hard to understand what was going on before reading the inductive proof several times and restating the argument for myself. Would the following be a rigorous argument? Assume that the foreigner gives his address on day 0 and that ")#mi("x_1")#text(", ")#mi("x_2")#text(", …, ")#mi("x_n")#text(" are the n blue-eyed people. For concreteness, I’ll put myself in the place of ")#mi("x_1")#text(".")

#text("On day n-1, I reason as follows: if I am not blue-eyed, there are n-1 blue-eyed people. Since ")#mi("x_2")#text(" is not dead, he did not know his eye colour (blue) as of day n-2. So, on day n-2, x2 would have reasoned as follows: if I am not blue-eyed, there are n-2 blue-eyed people. Since ")#mi("x_3")#text(" is not dead, he did not know his eye colour (blue) as of day n-3. So, on day n-3, ")#mi("x_3")#text(" would have ….")#linebreak()#text(" …")#linebreak()#text(" …")#linebreak()#text(" So, on day 0, ")#mi("x_n")#text(" would have reasoned as follows: if I am not blue-eyed, there are no blue-eyed people, contradicting the foreigner’s address today. So I must be blue-eyed, and must commit suicide on day 1. This contradicts (in turn) the claims of ")#mi("x_{n-1}")#text(", ")#mi("x_{n-2}")#text(", …, ")#mi("x_{2}")#text(" that their eyes are not blue and means that ")#mi("x_2")#text(" must have discovered his eye colour on day n-2.")

#text("But since he is not dead as of day n-1, my (")#mi("x_1")#text("‘s) claim of my eye colour not being blue is contradicted. Thus I will commit suicide on day n, and by symmetry, ")#mi("x_2")#text(", …, ")#mi("x_n")#text(" also discover their eye colour on day n-1 and commit suicide on day n. QED.")

#text("The argument above uses the fact that ")#mi("x_1")#text(" knows ")#mi("x_2")#text(" knows …. ")#mi("x_n")#text(" is not dead as of day n-1, which is ensured by making the suicide known to all (in the village square), for instance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3898f97572bd01936cecbe3e2ed83ea99005cb7537006fe64927948e61a64fdd-da225fb38ad1604a10df455ad6587bf13eb2ffe89aaf0c6a59e56a83f45672fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jongshik")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30264")[#strong[#text("jongshik")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2008")])]

#text("S={k | k blue-eyed persons commit suicide, after k days}")#linebreak()#text(" 1) 1 in S. (Actually true~)")#linebreak()#text(" 2) k in S -> k+1 in S (?) No!!! this is fault.")#linebreak()#text(" its contraposion : k+1 not in S -> k not in S")#linebreak()#text(" at 99th days, 99 persons did not commit suicide, therefore At 98th days, 98 persons did not commit suicide.")#linebreak()#text(" And 97 is same…, 96 same…,…")#linebreak()#text(" At last, at first day(after 1 day) 1 person did not commit suicide!")#linebreak()#text(" it’s the opposite of condition 1)…")

#text("Argument 2) means that k not in S, then k+1 in S. The induction argument is not correct")

#text("(Sorry, forgive my poor english. )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/245110ffbdb1c43671ea48253bb3a3cac59ac06e2d2c4221ebd25a712a1db292-0f19e485325aad35c0b93ea9503938dc4abf4fff54e74acce49c649f69fc58ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30273")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2008")])]

#text("All of you are using way too much brain power on this one.")

#text("The answer is simple, really. I just figured it out myself, having not read all the comments yet… and I’m sure I’m not as smart as all you are.")

#text("Although each person can see the eye color of the other 999 people, they cannot see or know their own eye color.")

#text("Even after seeing that others have eyes of blue and brown, for all they know, their own eye color could be purple. Read the puzzle question carefully.")

#text("So nobody ever commits suicide, even after the visitor’s visit, at least not for reasons of eye color.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/245110ffbdb1c43671ea48253bb3a3cac59ac06e2d2c4221ebd25a712a1db292-0f19e485325aad35c0b93ea9503938dc4abf4fff54e74acce49c649f69fc58ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30274")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2008")])]

#text("I see the possible objection to my solution: since these islanders are logical, they will, seeing only blue and brown eyes, conclude that these are the only two possible colors.")

#text("I would beg to differ – that’s why we have words like ‘exception’ and ‘outlier.’ The islanders, being logical, would be aware of the possibility that their own eye color was different from that of the others. An islander could hypothesize that it is LIKELY that their eye color must be one of blue or brown, but for them to conclude absolutely that: “all eyes that I have seen are either blue or brown. therefore all eyes are either blue or brown” would not be logical.")

#text("An islander must commit suicide the next day upon knowing their eye color.")

#text("Knowing, to a logical person, means knowing absolutely, with logic. Not knowing with a feeling of some probability.")

#text("Faced with the choice of committing suicide, or making a conclusion based on probability (but not on logic) a logical thinker would make the winning choice: reject probability, follow logic, and do not commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30303")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2008")])]

#text("Mark, suppose there were only two persons who did not have brown eyes. If one had blue eyes and the other green, then the blue-eyed one commits suicide the next day. If that does not happen, they both have blue eyes.")

#text("Suppose there were three persons who did not have brown eyes. If two had blue eyes and one green, then the blue-eyed ones commit suicide after two days. If that does not happen, all three have blue eyes.")

#text("The general conclusion is that if there are n blue-eyed islanders, then they all commit suicide after n days. A green-eyed islander sees this happen, and will never make any conclusions about his eye color except that it’s not blue! (In particular, he won’t necessarily know it’s brown, as you point out.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30308")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2008")])]

#text("(A joke)")

#text("This surely proves, finally, the inconsistency of ZF set theory and logic; so all of us mathematicians might as well commit suicide now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wise One")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30338")[#strong[#text("Wise One")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("When foreigners come, there is usually death in masses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/17e70246f94742e620a4b34c22a1a81973da718e6b4491afc9bb42bfa2325126-90ab863b535990bd4e34ceefe1963eced763a0a16864bba156f3c7317708cff5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of architectonic1")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30339")[#strong[#text("architectonic1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("Of course if the islanders had a self preservation instinct, then they would choose not to observe the eye colours of others and introduce uncertainty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f0d53400fc7d29a12aab92931c0898148bcf0fb2963a808b20e2a4a2e774359-7a2ff90578189d3e9e1d1c3b29258b66f4ddbcd129ebe9ff473f422c0e98a654.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Friedman")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30406")[#strong[#text("Ben Friedman")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2008")])]

#text("dear Pof. Tao")

#text("I am pretty sure u made a mistake if there are NO blue eyed people left then wont the brown eyed people know their eye color thus kill themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30411")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2008")])]

#text("No, Ben: as individuals the non-blue-eyed people don’t know their own eye color after the blue-eyed ones are gone — it could be green ")#emph[#text("for all they know")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5da3686e8ebb390a73c06d774a8202e8ce3f0e64f58e1435a280290547ad91a8-5ad9414e648252996440a30afaa32d8dab0ef2f2b5c27f233485c97e3808a43e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Freeze")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30518")[#strong[#text("Jacob Freeze")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2008")])]

#text("In order to avoid confusion with the usual meaning of “knowing,” the blue-eyed islanders puzzle should be reformulated using a term of convenience. If we replace “knowing” with “woogling,” and write, for example, “their religion forbids them to woogle their own eye color,” then the ambiguities introduced into the puzzle by natural language disappear, and “woogling” can be precisely defined according to more elementary terms, or treated as an undefined term, like a ")#emph[#text("point")]#text(" in the usual development of elementary geometry.")

#text("The introduction of a term of convenience cannot compromise the logical structure of the puzzle, but subsequent failures to reproduce the peculiar islanders in well-defined terms may suggest that the absurdity of the details is intrinsic, rather than incidental, and it was only the illusion that “knowing” could somehow retain its natural force after undergoing a whole series of impossible qualifications which imparted a shadow of epistemological significance to a phony “logic” where the most salient term isn’t well-defined.")

#text("The “blue-eyed islanders” aren’t so much a puzzle as a set-up for the sort of sophistical word-play that Socrates learned to deflate in a bargain course from Prodicus (one drachma: Cratylus 384b), and one drachma is a very small price to pay for avoiding the delusion that you ")#emph[#text("know")]#text(" a little something about epistemology, when you’re really only ")#emph[#text("woogling")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1129e36b69f6271a711e5e7cf76b4d12d1aaaf3804c02039446776f710c1d15-04466e4dc50f043e7f319a537a489d0062b23bce9264bae15a7040110e17b67e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carsten Dietzel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30541")[#strong[#text("Carsten Dietzel")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2008")])]

#text("Dear Professor Tao,")

#text("Maybe most people find this logical puzzle “unbelievable” because it’s necessary for a mass suicide that the existence of blue eyed islanders is known.")

#text("But let’s have a little look at the induction argument:")

#text("The induction is based on the idea that each islander knows the following law:")

#text("L(n-1): If there are exactly n-1 islanders with blue eyes they’ll all kill themselves n-1 days after hearing about the existence of blue-eyed islanders.")

#text("If we assume this assertion as a logical law then it must also be known by the highly logical thinking islanders.")

#text("The logical law must not be broken, so if a islander sees exactly n-1 blue eyed islanders which don’t commit mass suicide the n-1-th day, there cannot be just n-1 islanders with blue eyes but the islander has to have blue eyes, too. Otherwise the law L(n-1) would be broken.")

#text("The information of the stranger is needed, because then we can deduct the “starting law” L(1), which starts the “motor” which’ll end in the mass suicide.")

#text("Maybe for “normal” humans it’s just hard to imagine that there is a inductive list of logical laws which behave as follows:")

#text("A: “If the events A(1), A(2),…, A(n) don’t occur then A(n+1) has to occur.”")#linebreak()#text(" This is a deduction which interacts with the logical laws L(n):")#linebreak()#text(" L: “If there are n blue-eyed islanders they’ll commit suicide after n days.”")

#text("It’s hard to understand, that the aspects A and L of the solution of this problem “play ping-pong”. I had some problems with solving this problem when I started studying maths (some university give pupils a chance to take a part of the studies during schooltime) but with many patience I could get the “ping-pong”-solution.")

#text("It’s a nice problem and I’m glad that you help other people to get to know such interesting problems like this.")

#text("One of your (17 year old) fans ;)")

#text("P.S. Please excuse my bad English – I didn’t have English-class in school for two years.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2008")])]

#text("Interesting. Funny thing is, however (never having seen this puzzle before), I was immediately able to arrive at both conclusions without even resorting to numeracy or proofs. I’ll try to be brief (the thought occurred in a split second, honestly).")

#text("It all hinges on the phrase “another blue-eyed person”. Either this refers to everyone specifically, which results in the death of all (for this would be a revelation of their own eye colour), or this refers to a differing visible person according to one individual’s frame of reference across all the tribe members. Simple. Numbers needn’t apply here, really. In actuality, I consider these the two alternative, logical extremes; each individual would have to decide to what this phrase refers.")

#text("(The situation, I think, would have been slightly different if the man mentioned a different eye colour (green), because the only reference the individual would have is others as a known condition; and since all other members are visible, each would have to commit suicide immediately.)")

#text("Perhaps my thought-process is less sequential-synthetic-analytic than others’ and more global-holistic; or I merely had a stroke of luck. [|;-)")

#text("Well, just my perspective. Fun puzzle. Thanks for sharing it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of L")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30683")[#strong[#text("L")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2008")])]

#text("Very interesting. And I have a question – what content of the foreigner’s speech will trigger suicides?")

#text("For example, instead of saying “how unusual it is to see another blue-eyed person like myself in this region of the world”, the foreigener says")#linebreak()#text(" i) there are two different eye-colored people on this island. or")#linebreak()#text(" ii) there are various eye-colored people on this island. or")#linebreak()#text(" iii) do you know how many blue eye-colored people on this island?")#linebreak()#text(" ….")

#text("What will be the respective outcomes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c723e460d63cf9426e47e11e075d92d54c15da75b1968df6e89e0156eaad2d4c-4311704f56bc66afa9672c6ce2710961ade12597a441673dac0b4a66e3bce729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwazidan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30809")[#strong[#text("qwazidan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("i can’t see the comment field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c723e460d63cf9426e47e11e075d92d54c15da75b1968df6e89e0156eaad2d4c-4311704f56bc66afa9672c6ce2710961ade12597a441673dac0b4a66e3bce729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwazidan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30810")[#strong[#text("qwazidan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("The 100 blue will not suicide because 3 blue would not suicide. No suicide on day 2 is consistent with both two blue (and a brown) .. and 3 blue. It doesn’t discriminate anyone’s eye color.")

#text("If 3 blue .. each sees 2 blue.")#linebreak()#text(" For none is it the case there is 1 blue that will know and suicide.")#linebreak()#text(" Therefore .. no conclusion can be drawn from no one suiciding.")

#text("it is interesting that in the case of 2 blue .. if suicide is immediate no knowledge is obtained from the stranger’s info. Each sees a blue .. each knows if the other sees brown they will suicide .. each will know they are brown when the other leaps. But both are blue .. so neither will leap to a false conclusion.")

#text("Sequenced suicide adds information only in the case of 2 blue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c723e460d63cf9426e47e11e075d92d54c15da75b1968df6e89e0156eaad2d4c-4311704f56bc66afa9672c6ce2710961ade12597a441673dac0b4a66e3bce729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwazidan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30816")[#strong[#text("qwazidan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("Some puzzle readers complained of ambiguity. For my own clarity i restated the puzzle as follows …….")

#text("There is an island where it is taboo to mention eye color or know your own.")#linebreak()#text(" If anyone finds out their eye color they will leap into the volcano .. noon next day.")#linebreak()#text(" Everyone sees everyone else’s eye color and if anyone leaps.")#linebreak()#text(" They correctly assume only two eye colors .. brown and blue.")#linebreak()#text(" They correctly assume everyone is perfectly logical.")#linebreak()#text(" There are 100 blue and 900 brown.")#linebreak()#text(" A departing stranger correctly assumed to be truthful and accurate informs them ..")#linebreak()#text(" “at least one of you has blue eyes”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c723e460d63cf9426e47e11e075d92d54c15da75b1968df6e89e0156eaad2d4c-4311704f56bc66afa9672c6ce2710961ade12597a441673dac0b4a66e3bce729.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwazidan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30817")[#strong[#text("qwazidan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2008")])]

#text("Fortunately .. the volcano that was still spewing red hot lava in the time of the blue-eyed missionary’s previous departure .. is now extinct so the worst that can happen is a few scraped knees and such.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zgrav")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30834")[#strong[#text("zgrav")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("I have enjoyed reading the many comments to this thread and thinking about the different suggestions that have been made. I follow the logic in the explanations for what would happen with the small numbers of blue eyed islanders, where n=3 or less, but I think it breaks down when the numbers are larger.")

#text("When n is a greater number, I do not understand why there would be any shared understanding by the islanders to wait for the number of days that matched the relative number of n they could see (which would either be n, or n-1, depending upon their own unknown eye color) to see if that number of islanders would commit suicide.")

#text("Just because 1 person with blue eyes would commit suicide on day 1 if n=1, or 2 on day 2 if n=2, does not necessarily suggest that 34 people would commit suicide on day 34 if n=34.")

#text("If there were 34 islanders with blue eyes, for example, and everyone on the island would see either 33 OR 34 blue-eyed islanders, what shared understanding would drive everyone to wait 33 days to see if there is a mass suicide of 33 islanders before each blue-eyed observer would add himself to the total for n and 34 people commit suicide on day 34?")

#text("When everyone knows that n equals EITHER 33 OR 34 (from my example above), it seems odd that everyone then has to mark off 33 days on the calendar before looking around to see what happens. I am not sure that the premises for the problem would require these steps to be taken.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30836")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("I feel that zgrav put his finger on WHY this puzzle is counterintuitive.")

#text("It is that, somehow, we intuit that mathematical induction breaks down on iteration of an apparently well-defined function, when that function involves knowledge. That is, the sequence:")#linebreak()#text(" x,")#linebreak()#text(" knowledge-of x,")#linebreak()#text(" f(knowledge-of x),")#linebreak()#text(" knowledge-of f(knowledge-of x),")#linebreak()#text(" f(knowledge-of(f(knowledge-of(…x…))))")#linebreak()#text(" undergoes a fuzzy phase change in truth value for some depth of nesting.")

#text("Furthermore, non-identical people differ as to where that level of nesting appear, and we do not know the distribution.")

#text("This is inconsistent with unbounded rationality, but entirely plausible under bounded rationality. It is hard, however, to axiomatize satisficing, so this problem will not go away any time soon.")

#text("There is some experimental evidence that the level of nesting is close to that magic number 7 plus or minus 2, for ordinary adults, when dealing with exceptions to exceptions to exceptions to… for dealing with items on an assembly line. EXCEPT for programmers, who experimentally deal with an unbounded level of nesting, having abstracted that procedural approach to exception-handling.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d2a32dd198d05055be4346a853036b824c077f0cb78745d3c538d6613bded30-27f4c9e455a442680fa4f21b47beb09d8e2b30c31c6db47a539b77197fc7762b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qwazidan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-30854")[#strong[#text("qwazidan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2008")])]

#text("if suicide is immediate rather than next day .. only in the case of 1 blue will anyone know their eye color. Because suicide “next day” adds info in the case of 2 blue .. it is argued that “next day” adds info for any larger number of blue. This is not true.")

#text("Suicide “next day” adds information only in the case of 2 blue. For 3 blue (or more) the situation becomes the same as 2 blue with immediate suicide .. the knowledge of each is dependent on the knowledge of the other .. thus no knowledge is obtained.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b46620670a9ddace794e7e76a0dc2773bbbfd5ced917df2d0a75bd112d5757e3-2995c504c95d76e7bcea89a4e1a5db901933e8c0960b352852d8b07edc862598.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Walsh")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-31688")[#strong[#text("Daniel Walsh")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2008")])]

#text("I disagree with Phillip. I think that the newcomer does give away unknown information by telling everyone that there are some blue eyed people. By saying this, he makes the information “common knowledge”. Thus the island will continue living on forever if left to themselves. The reason is thus: I claim that an islander just looking around and seeing another blue eyed person only gives them a “first order” knowledge of who has blue eyes. Take for example the case of two blue and several brown eyed people. Everyone can see another blue eyed person, However, from the point of view of one of those blue eyed people, I have no way of knowing that the other blue eyed person can make the same claim (I see no more blue-eyed people). Only as problem solvers of this riddle do we know this information, but it is not necessarily known to the islanders. Take the case of three blue eyed people, the rest brown. Every blue eyed person can see that there are other blue eyed people. Further, they know that their friends who they can see have blue eyes, also make the same conclusion, since there is one other blue eyed person who they each can see. So they know that he knows there is a blue eyed person on the island. But that’s as far as we can go, since there are no more blue eyed people that they can see! A similar situation results from considering what a brown eyed person would conclude. My point is that I believe that Dr. Tao’s induction is flawless, but the claim that the islanders would have already known the information given by the newcomer is misguided (as I am sure he is aware.) The key is to distinguish between information that we (as problem solvers) know, and information that each inhabitant of the island knows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa906c263f5bb7b079f271d12287ffd45499e81315b15c74e87376d5c1bf3f64-1da7242bfa49f37088366f0d24445e425e7f5c18e1620c4b468ac69f48da7cdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of millenia20")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-33135")[#strong[#text("millenia20")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("“If there were 34 islanders with blue eyes, for example, and everyone on the island would see either 33 OR 34 blue-eyed islanders, what shared understanding would drive everyone to wait 33 days to see if there is a mass suicide of 33 islanders before each blue-eyed observer would add himself to the total for n and 34 people commit suicide on day 34?")

#text("When everyone knows that n equals EITHER 33 OR 34 (from my example above), it seems odd that everyone then has to mark off 33 days on the calendar before looking around to see what happens. I am not sure that the premises for the problem would require these steps to be taken.”")

#text("I don’t think that works.")

#text("There would be two cases")#linebreak()#text(" 1. A blue eyed islander sees 33. (That person knows there must be either 33 or 34)")#linebreak()#text(" 2. A brown eyed islander see 34. (That person knows that there must be either 34 or 35)")

#text("How would the blue eyed islander be able to figure out he’s the 34th?")

#text("It still ends up being the same induction. Because lets say for case 1 that person says well I see 33 people, so obviously if those 33 people kill themselves tomorrow I have brown eyes, otherwise I have blue eyes.")

#text("But the brown eyed people would make the same incorrect inference. All the brown eyes people would say I see 34 blue eyes people so if they all don’t kill themselves tomorrow obviously I also have blue eyes.")

#text("So everyone would incorrectly kill themselves on the second day after they first knew there was at least one blue eyed person.")

#text("The problem is that it would only work if the people knew what the other people were seeing. Because without some inductive increment no one could figure it out since both sides would work under different assumptions that would never resolve. As long as there’s some understood increment this works and I think by the wording of the puzzle its inferred that its a daily thing.")

#text("It doesn’t have to be days though it could be hours or minutes if thats what they decide. If they say if you figure it out by the end of the minute you need to kill yourself at the beginning of the next it would work where the 34 blue eyed people would kill themselves at the start of the 35th minute.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a6d2377463a70198e77786faf900b1c7a1c04dd3e7c8ebdeaacc3de2f893fc4-03b6d54b708e21dcba44527d19142d464269ca4009dc1d8edc28956ebc80979b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of free online jigsaw")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-34907")[#strong[#text("free online jigsaw")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2009")])]

#text("that is just silly, what kind of religion would prevent you from knowing your own eye color? What if you go swimming and see your reflection in the water?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f68fca893cb8e9439872e92b414253a8d981d13788872cec7f5245baa525ac7a-2f0d24cfdde8d31b6f27d9eab662c9a682adfcfa39fac6820520b3663ff69c14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-34959")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2009")])]

#text("I think it is quite obvious that the inductive argument is flawed.")

#text("It would be perfectly satisfactory if every islander knew that there were only blue and brown-eyed persons on the island.")

#text("But any particular islander might consider the possibility that they have green eyes… And would be perfectly right to do so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-34972")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2009")])]

#text("Daniel, this point has already been covered. See the comment dated June 10, 2008. The inductive argument works; think about it some more. (Of course, we must assume that the islanders have absolute trust that the foreigner is telling the truth!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-35220")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2009")])]

#text("The paper which provides the proper model theory to express this class of problems is (there are special sumbols which do not correctly appear in the text below, but can be seen by following the link):")

#link("http://journals.cambridge.org/action/displayAbstract?fromPage=online&aid=2955404")[#text("‘KNOWABLE’ AS ‘KNOWN AFTER AN ANNOUNCEMENT’")]#linebreak()#text(" PHILIPPE BALBIANIa1, ALEXANDRU BALTAG, HANS VAN DITMARSCH, ANDREAS HERZIG, TOMOHIRO HOSHI and TIAGO DE LIMA")

#text("The Review of Symbolic Logic (2008), 1 : 305-334 Cambridge University Press")#linebreak()#text(" doi:10.1017/S1755020308080210")#linebreak()#text(" Published online by Cambridge University Press 15 Dec 2008")

#text("Abstract")

#text("Public announcement logic is an extension of multiagent epistemic logic with dynamic operators to model the informational consequences of announcements to the entire group of agents. We propose an extension of public announcement logic with a dynamic modal operator that expresses what is true after any announcement: xs22C4φ expresses that there is a truthful announcement ψ after which φ is true. This logic gives a perspective on Fitch’s knowability issues: For which formulas φ, does it hold that φ → xs22C4Kφ? We give various semantic results and show completeness for a Hilbert-style axiomatization of this logic. There is a natural generalization to a logic for arbitrary events.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3ca9d54488f747d3a7c906f637d8f3c1e67f35d3e348b0b82ac2596a21dae40-817796d4d47874121cbcd8c32a1921823de0f4451f00cc5cb7eaee5337ac6e42.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of G.M. Palmer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-35937")[#strong[#text("G.M. Palmer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2009")])]

#text("The problem with this puzzle’s solution is that it assumes everyone sees everyone at the same time.")

#text("You cannot say for certainty that the suicide/departure will happen in k+1 days time because, even though the islanders have perfect knowledge of each others’ eye color (once seen), they likely haven’t already seen all of them.")

#text("Now, if they’ve seen everyones eye color, then they’ll all leave/kill themselves on the second day.")

#text("That first day Tom will think “well, there goes Bob and Joe and Carl — it was nice knowing them.” But when Bob and Joe and Carl don’t off themselves in the morning, Tom will realize that he is also blue eyed (everyone else being brown eyed) and join the merry immolation throng in the morning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e09b98d8ff43c625fd1bec55b9e713195e124cfe7588ff649b5b83194ae79b11-da8cd304022fcdc2f84f73382702aec1cdd306a6648270a1b93e23b839bcb870.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Cernea")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-38312")[#strong[#text("Paul Cernea")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2009")])]

#text("According to my reasoning, the induction goes through, but it is important to be precise about the numbers. We have already established the base case n=1; that was what we needed the foreigner for.")

#text("Now suppose it holds for (n-1). We’ll examine the case of n people. The people with brown eyes deduce there are either n people with blue eyes, or (n+1) people with blue eyes. So they don’t need to start worrying until the nth day. The people with blue eyes observe that if they are not blue-eyed, there are (n-1) people.")

#text("When there is no mass suicide on the (n-1)st day, the blues realize they have to kill themselves on the nth day. So they do. And the brown eyes don’t have to worry. Note that the brown eyes don’t ever have to kill themselves, because they don’t know what their eye color is; the foreigner didn’t mention it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/051f43989f475117a28550495b0eb9fba188accf3fb1af673102d9ec62b69244-26f074963f13648f05bb0ec55d39d7c2a218428ce6fcb7b92c9d3c91d47ed572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Ilinca")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-40025")[#strong[#text("Marius Ilinca")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("But the brown eyed ones do kill themselves also :). Not because the foreigner didn’t say anything about them but because “they all knew that everyone knew there are brown eyed people”.This is the trigger that makes every brown eyed or blue eyed person to kill themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of triplm")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-40063")[#strong[#text("triplm")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("i believe the answer is that no one person kills themselves as they already knew that there were two different types of eye colors")

#text("the only way for them to figure out what eye color they are is to know how many of a certain eye color there is on the island and to logically go from there but since the outsider never gave an exact number and their religion forbids discussing of it there is no way to know thus no-one commits suicide")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1075172adc0367bf2fc3f936f14cfdebf9a30115b7d1f71f5e22adf8ac8789b1-9bb77dd3968d49dcba8fb6871d4cadb994c433318002c62bb267211aa6dbff3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Patrick S")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-40571")[#strong[#text("Patrick S")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("What a great puzzle!")

#text("I think the resolution is that the first proposed solution is false; the foreigner DOES give the islanders new information. The inductive argument is correct, but we must still explain how the islanders survive before the foreigner arrives!")

#text("The way I figured this out, and the easiest way to understand it I think, is to consider the simplest cases. Let ")#mi("N")#text("be the number of blue-eyed islanders.")

#text("If ")#mi("N=1")#text(", then each islander sees zero or one blue-eyed islanders, but since he or she doesn’t know ")#mi("N")#text(", no conclusions are drawn.")

#text("If ")#mi("N=2")#text(", then while each islander already knows that there are blue-eyed islanders, he or she does NOT know that all the other islanders know this. If we call the two blue-eyed islanders Alvin and Barry, then Alvin knows that Barry has blue eyes, but he does not know whether Barry knows about any blue-eyed islanders, since Barry is the only blue-eyed person Alvin sees, and he doesn’t know his own eye color. Thus, the fact that Barry does not kill himself the day before doesn’t mean anything to Alvin. However, once the foreigner comes along, Alvin suddenly knows that Barry knows that there are blue-eyed islanders, and we can use the inductive argument as presented: Alvin now knows that Barry would have killed himself after one day unless Alvin had blue eyes, and thus both kill themselves on day two.")

#text("This works for all ")#mi("N")#text(". For ")#mi("N=3")#text(", Alvin knows that Barry knows that there are blue-eyed islanders, but he DOESN’T know that Barry knows that Cathy knows this! Without this information, he cannot know his own eye color, despite the information that no one killed themselves in the preceding days. In general, the foreigner provides the ")#mi("N")#text("th step in the chain of reasoning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98e08bcd0c40abecba141129de04279ea7424db6fee8e8877d013e060fbc6df2-c65a658e38a2ef69d4d0752b69989eb668b37d3f9c8778ef224f360f2b21d5c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Italo")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-40829")[#strong[#text("Italo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2009")])]

#text("First of all I wanna apologise for my english (I’m peruvian), well been trying to solve this puzzle all this day long, but it takes me to one question, is there any name for this mathematical concept of solving the puzzle? well there’s a similar one in ")#link("http://www.hackquest.com")[#text("http://www.hackquest.com")]#text(" in the LOGIC section the “To boldly go…” and to get this puzzle done they ask for a mathematical concept, can anyone help me with this? =D")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-41252")[#strong[#text("Condemned prisoners and random permutations « Lewko's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")]

#text("[…] In this post I will present one of my favorite logic puzzles. As with many great logic puzzles (see the blue-eyed islanders puzzle, for example), the mathematics is embedded in a gruesome storyline. The puzzle can be stated as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b303f0edaec0e4c769cfd2d93a6d1da59673b34d84c284e5a8842d55feec2da-e1bd812325656c8e0fcc669ed189edd160d08e14fdc7f8944935e2458cf65265.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ant")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-7/#comment-41254")[#strong[#text("Ant")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2009")])]

#text("For me an interesting factor is the time leading up to the visit of the foreigner. All of the islanders gradually meet one another ie the 1000 islanders do not get to look at each others eyes and do any colour counting on the same day. I assume that they all cary a notepad and gradually write down each persons eye colour or they just have good memories – doesn’t really matter.")

#text("An important point is that they have no concept of a synchronised “day zero” to work from.")

#text("We assume that everyone has completed their eye colour audit prior to the foreigner’s visit. I think that the gathering of the whole tribe and the input of common knowledge (even if trivial) synchronises day zero since it is the first day that everyone knows that everyone has performed a complete counting for the first time … and this generates a reference.")

#text("Alternatively, if everyone looked at everyone else’s eyes on the same day, and everyone knew this, then that would also be day zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("Yes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93fb26ec0795d2f4c84825063418b1de4f7aa1d6772003aca2a0d9a070e75c40-3bf5a49ffb4af024981d964c7b63103f409f1b918dc75d53cee8286ceee87d1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jose Brox")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26462")[#strong[#text("Jose Brox")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("I believe – by a somewhat subtle reason – that the initial situation is impossible, because the system is unstable for any n>0; there’s no need for the foreigner to state the common knowledge, even in the n=1 case. My reasoning goes as follows:")

#text("Consider n=1 and no foreigner.")#linebreak()#text(" Then there’s only one blue-eyed person, that sees brown-eyed all the rest.")#linebreak()#text(" But him, being as devoted as anyone else, knows perfectly the prohibition that states clearly that one must not know his own eyes color.")#linebreak()#text(" “Therefore”, he thinks, “since there’s a prohibition, there must be more than one eyes color, because in other case, there won’t be place for choice, so there won’t be any alternatives, and consecuently no uncertainty and everyone would trivially know his eyes color (because all of us can make this thought and we all see this argument).")#linebreak()#text(" Therefore, there must be at least two eye colors; but I can see only one type!")#linebreak()#text(" My last conclusion is going to be fatal: Now I know that indeed there are only two eye colors, and mine is distinct.”")

#text("We could discuss if he would actually suicide or not, because he doesn’t really know that if his eyes are BLUE or GREEN or of any other color; we maybe need a more precise statement of the problem to decide this question; but in what I think it’s the spirit of it, I would say he will suicide, because has arrived to forbidden knowledge about eye colors.")

#text("Note that the counterargument: “religion could have been devised so to mantain all the villagers in a fraud, making them think that there are different eye colors when there aren’t” doesn’t prevent him from making the same thought, because he is strictly logical, and would despise that argument inmediately (if there’s a prohibition about knowing something then there must be something to know; in other case there couldn’t be anything to know about and by definition it couldn’t be forbidden!) and act as if his color was distinct even if he were actually being deceived.")

#text("So the real situation, if we accept this argument as sound, is that the foreigner arrives and feels the soleliness of a bloody and deserted island.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("Wouldn’t it also be possible that the blue persons kill themselves on the second day. I mean they now this hole procedure, so they can swap the days in between.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of smartmonk")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26506")[#strong[#text("smartmonk")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("The answer is pretty easy. Just have a view on this idea. Everybody who gets adressed will show up the next noon to kill himself (or not depending on the reliability of the stranger).")#linebreak()#text(" And those who show up will defenitely do it, unless any of those showing up has/have an eye colour that is different (maybe the foreigner lied). Then they’ll all go home, as they can be sure the guy lied.")

#text("Well if all of those who got adressed and show up, have the same colour, then they’ll commit suicide and that’s it, since the others left, still may not talk about their eye colour nothing will follow. They won’t be able to make any conclusion out of this, since they will only know those suiciders had the same eye colour, not more.")

#text("To put it all together- each of those who got adressed will decide on their own to kill or not to kill himself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OJ")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26511")[#strong[#text("OJ")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("I think no one will die.")#linebreak()#text(" 1. The stranger tells them, that there IS another (means one) blue-eyed person.")#linebreak()#text(" 2. The villagers do NOT talk about the eye color.")#linebreak()#text(" 3. The villagers do NOT know the exact ratio of blue and brown eyed people.")#linebreak()#text(" Every blue-eyed villager knows 900 brown-eyed and 99 blue-eyed villager and every brown-eyed villager knows 899 brown-eyed and 100 blue-eyed villager.")#linebreak()#text(" As I menioned, there is no communication about the eye color and thus the stranger adds no new information.")#linebreak()#text(" If there is only one blue-eyed villager, the situation is different, because he sees 999 brown-eyed mates. So he can reason – without any further information – that he must have blue eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8bfcf6ba89ca8ba5d0447b5b50ab9cfdbf511700704529d2864e063798cc3d2-0fb47dba734933cf877a72aa7ff87dbe0228e80a291ae10c3240a6689f90be0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Niko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26513")[#strong[#text("Niko")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("I’m 100% with OJ.")

#text("BUT I think, mathematics has its way to proof the unlogical to be perfectly logical.")

#text("No offence ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a28db64ce5a987f902f32d7a88823ae220f1db47b4dcd292922b8c0edba0e5c-fbd67e64f5ce60ed018ac4dceaa1eaa3b99f325f2eb212bc78a84fadf2ab43ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil'sBarber")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26517")[#strong[#text("Gil'sBarber")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("I haven’t read all comments, but no where in the original puzzle does it state the tribe consists of (only) two eye colors. If a third color is added (e.g., green) all bets are off ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a244c8a2e08ff52c5a75cd097dd09c9e218838618986b1e461efd9295c2a9cfa-a6656d17a8ee4884aed7a5247569d6022ccce5ae6c5d3d8b822a5f3ab4de88c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Douglas A. Gwyn")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26518")[#strong[#text("Douglas A. Gwyn")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("I basically agree with Jose Brox; the problem statement is of an unstable system and whenever the clock is considered to have started kicks off the inductive chain. The visitor does not start the clock, so the problem statement is utterly misleading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beru")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26519")[#strong[#text("Beru")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("my first idea was that the tribe must be irritated because the STRANGER does know his own eye colour, but didnt commit suicide. this could have no effect on the tribe because they accept that there are other religions beneath theirs. or they will kill the stranger or they will not believe in their god any longer. blablubb…. hope, you got the point, my english is not so good :p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("Even with [number of people with blue eyes]=1 there would be only one person commiting suicide. Each other tribe member could have green eyes too.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26521")[#strong[#text("Carnival of Mathematics 1000 « JD2718")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")]

#text("[…] Walking Randomly investigated heart plots, surfaces, and tangrams. 11 – Terence Tao proposes a problem about some blue-eyed islanders. But who knows what their own eye color is? (logic puzzle) 11 – I have a hat-guessing (not really […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("One can imagine the islanders were all robots to see the validity of the induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OJ")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26526")[#strong[#text("OJ")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("To all ignorami:")#linebreak()#text(" TRY to read the puzzle or keep quiet…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26527")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("OJ, the correct plural is “ignoramuses”. The word ")#emph[#text("ignoramus")]#text(" in Latin literally means “we do not know”; in Latin it’s a verb form. In particular, the -us ending should not be construed as indicating a noun of masculine gender which in its plural form ends with -i. But in English, where it ")#emph[#text("is")]#text(" a noun, it is pluralized as “ignoramuses”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("To Todd – the ignoramus!")

#text("The plural can be ignorami as well:")

#link("http://www.merriam-webster.com/cgi-bin/dictionary?book=Dictionary&va=ignoramus")[#text("http://www.merriam-webster.com/cgi-bin/dictionary?book=Dictionary&va=ignoramus")]

#text("Simple Mind…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26530")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("Hmm… in response to very tactfully put observation of “Anonymous”, I just looked it up in the OED (2nd edition), where “ignorami” appears not to be listed. I imagine “ignorami” is a recent invention by people who did not know the Latin origin. This leads me to believe “ignoramuses” is much to be preferred — those who use “ignorami” do so in a terribly misguided effort to appear knowledgeable about Latinate plurals.")

#text("But, I’m always happy to be corrected! :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26531")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("Not to go further afield, but OED beats Merriam-Webster every time. And no matter how many people think “octopi” is right, the proper plural is “octopodes”, with “octopuses” as an acceptable English alternative.")

#text("People who say “octopi” or “ignorami” are just trying to sound smarter than they are by using what sounds like Latin.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/131a76b6a4dc892e683c943a5c5cee92190108ec3b14c4cbbd103ece01a51877-26269157ac0db9470c366f5f88e8b0504fa217fdce6a53db288313abe3649457.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sinisterfish")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26532")[#strong[#text("Sinisterfish")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2008")])]

#text("it depends on your geographical location i guess…")#linebreak()#text(" Americans cannot spell…it’s a fact… ‘dumbest people i know…..")#linebreak()#text(" Webster encourages this….")#linebreak()#text(" for example … the word ‘Pedophile’ would mean that somebody somewhere loves FEET…..not children…")#linebreak()#text(" and philial love has nothing to do with sex…")#linebreak()#text(" (otherwise I, as a Bibliophile would be ‘banging away at the books’ in a whole new light)")

#text("also, about the maths thing (which seems to have been forgotten), who cares…. ???")#linebreak()#text(" Bertrand Russell would have us believe that the only thing exact about mathematics is its exactness…..")#linebreak()#text(" get over the arbitrary…….")#linebreak()#text(" reality is no contender to actuality……")#linebreak()#text(" so the ‘answer’ really is not important…")#linebreak()#text(" too busy being distracted by your seperatist humanity is just not good enough.. there is NO UNDERSTANDING in mathematics… purely DESCRIPTION….")#linebreak()#text(" that’s why it is a puzzle and nothing more….")#linebreak()#text(" Prof Tao would have been better off devoting his life to Esoteric wisdom litlerature or something worthwhile, maybe…?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb7d2633d19ea2ce5ecf2cd18789ae30c3e19087c18ff31cd9704a815785fbd6-563661a1e9def9df542b540d82657569326113e311a81e04dc9f71522ccfc677.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Wilshire")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26534")[#strong[#text("John Wilshire")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("To John Armstrong:")#linebreak()#text(" 1) It is very tactless to comment about")#linebreak()#text(" people’s grammatical mistakes, real or imaginary.")#linebreak()#text(" 2) It is laughably ridiculous to claim that you know better than Merriam-Webster how to form a plural.")#linebreak()#text(" 3) Your preference for OED just displays your snobbishness: this is America, not England.")#linebreak()#text(" 4) Your comment about “people […] trying to sound smarter than they are ”")#linebreak()#text(" exactly applies to you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26536")[#strong[#text("Tim")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("die erste person stellt sich alleine hin")#linebreak()#text(" die zweite person stellt sich neben ihm")#linebreak()#text(" die dritte person sieht entweder 2 Blaue oder 2 Braune und stellt sich neben sie")#linebreak()#text(" oder die dritte person sieht 1 Blau und 1 Braun und stellt sich zwischen sie")#linebreak()#text(" die 4 Person sieht Blaue und Braune und stellt sich in die mitte")#linebreak()#text(" die 5 Person sieht Blaue und Braune und stellt sich in die mitte")#linebreak()#text(" und so weiter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d48b39e175bbb6d4e6af9a357ef84d4bb5e853a446c32c30880ce41b0992510-8bf62b7458cba118cce7aa10d8d6f0727d22cd6aef96d810701928c2e4f2d55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26538")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("browned-eyed-girl –")#linebreak()#text(" “John Armstrong, I think you only need meta-knowledge to the n-th degree where n is the number of blue-eyed islanders. I attempted to argue this in my comment above”")

#text("I really don’t see how the meta-knowledge is necessary at all. Refer to my playing cards formulation above. As long as you know that everyone understands the rules (logical) and will follow them (devout), you know with 100% certainty that on day N+1 (where N is the number of Blue Eyes *you* see) that you absolutely have blue eyes *IF* the Blue Eyed People you see did not suicide on day N.")

#text("All that is necessary is a Time 0 and a ticking clock. In this problem the foreigner provides the Time 0, but no meta-knowledge is necessary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trebuchet")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26539")[#strong[#text("Trebuchet")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("quote:")#linebreak()#text(" >>All that is necessary is a Time 0 and a ticking clock. In this problem the >>foreigner provides the Time 0, but no meta-knowledge is necessary.")

#text("just wanted to post the same.")

#text("so the foreigner does not add any new information, he just initializes the system.")#linebreak()#text(" thats the flaw of the whole story, the “system” is not stable, it will be “begin to die” with its creation, no foreigner needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Trebuchet")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26540")[#strong[#text("Trebuchet")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("just wanted to add, that both arguments are correct then.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26541")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("(This thread is getting to be longer than it’s worth, but since I started it)")

#text("@John Wilshire — I agree that generally speaking, it ")#emph[#text("is")]#text(" bad form to point out spelling mistakes, grammatical mistakes, etc. in venues like the comments board of a blog. I made an exception here because use of the Latinate plural form in this instance, instead of the default -es, indicates to me that the writer was actually ")#emph[#text("trying")]#text(" to be correct, but got it wrong anyway [IMO], and so I thought a little clarification was in order.")

#text("Regarding your point (2): there are different schools of thought on the editing of dictionaries, under the broad headings of “descriptivist” and “prescriptivist”. I’m not an expert on this, but generally speaking a prescriptivist editor would hold that unabridged dictionaries should not only be a fairly complete representative of the lexicon, but also set a standard on which usages are accepted by educated speakers, which are less accepted, etc. The most authoritative dictionary in the prescriptivist line is, without question, the OED. Editors of other dictionaries may take a more relaxed descriptivist point of view, and list other usages or spellings (including for example ebonics spellings) as they have appeared, without further comment. The online MW seems to be in that general category. But for my money, if I want to get a question like this straightened out, I head for the OED. It’s not a matter of snobbishness, but of the differing functions of dictionaries.")

#text("Point (3): this isn’t America, it’s the ")#emph[#text("Web")]#text(". The site may be from within the US, but the blog is written by a native Australian and is addressed to the international community. For what interest it may have, John Armstrong and I are both American, and speak American English. But that’s neither here nor there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26545")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Actually, words like “color” (Br. “colour”) derive ultimately from Latin, where the ‘u’ isn’t in there. You can look it up if you like. But either spelling is acceptable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d462171b316f271710c9d465db8dcc14eaef376a3a899b0a5d83b31dd811715-4879073d7a2217c811484ecdeafc8a7fccaa7566eb6b4e162247451b1380e64b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Todd Trimble")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26546")[#strong[#text("Todd Trimble")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("(Terry, I know, it’s really off-topic. If you like you can delete this, and anyway I’ll get off this topic, but first I wanted to address this chap Sinisterfish.)")

#text("So: you’re put out that Americans don’t write pædophile — is that it? I guess you’ll just have to get used to dumb, ugly Americans then.")

#text("Just in case you’re suffering from a more elementary confusion: the stem pedo- in this case comes from the Greek ")#mi("\\pi\\alpha\\iota\\sigma")#text(", ")#mi("\\pi\\alpha\\iota\\delta o")#text(", “boy” — not from the Latin ")#emph[#text("pes")]#text(", ")#emph[#text("pedem")]#text(", meaning “foot” (whence “pedal”).")

#text("You do seem somewhat thrown off by the stem -phile, also from the Greek, ")#mi("\\phi\\iota\\lambda\\epsilon\\iota\\nu")#text(", with a general meaning “to love”. Obviously this can carry many variations of meaning. But the term “pædophilia” or “pedophilia” was coined by psychologists, dating from the early 20th century, and has nothing particularly to do with Americanisms. You’ll find the suffix -philia used in similar ways, e.g., in “necrophilia”, where there is not the slightest chance of contamination by those reviled Americans and their abominable spellings.")

#text("I didn’t find your word “philial” in the dictionary. At first it looked like a slip for “filial”, but on second thought it looks like you just made it up. As long as you go on rants like this, you might want to consult a dictionary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("See ")#link("http://swfoundry.wordpress.com/category/arts-and-entertainment/language/")[#text(" ‘The Software Foundry’ on WordPress")]#text(":")#linebreak()#text(" ~ Eros")#linebreak()#text(" ~ Philia – Philial/the Love of Friendship (1 to 3 years) – This is the most broad and ambiguous of the greek loves")#linebreak()#text(" [hence Philadelphia]")#linebreak()#text(" ~ Agape")#linebreak()#text(" ~ Storgē")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26554")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Dear all: just a reminder to please keep the discussion polite, constructive, and on-topic. Comments that consist primarily of ")#emph[#text("ad hominem")]#text(" attacks (together with responses to such attacks) will be deleted.")

#text("Dear Randy & Trebuchet: As I stated before on 8 Feb 2:02 pm, in the absence of the foreigner there is insufficient information available for any islander to determine their own eye colour; this can be seen by considering the base case of the inductive step (one blue-eyed islander). More generally, the problem is that there is no common knowledge of existence of a blue-eyed islander before the foreigner speaks. As such, no suicides happen until the traveller begins speaking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JP")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26561")[#strong[#text("JP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("“More generally, the problem is that there is no common knowledge of existence of a blue-eyed islander before the foreigner speaks.”")

#text("Isn’t this only true in the case of # of blues = 1?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26562")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Dear JP,")

#text("When there is more than one blue-eyed islander, the existence of blue-eyed islanders is known to all, but it is not common knowledge (and it is this precise distinction which resolves the puzzle). See")

#link("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")[#text("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JP")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26563")[#strong[#text("JP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Thanks for reminding me of the logical definition (which I’d read and already forgot to reference by the time I finished the thread). Still, in the case of 2+ blue-eyed islanders, taking the proposition p as “the existence of blue-eyed islanders,” is it not that case that even before the foreigner speaks, each islander knows p, and knows that each knows p, and so on? I don’t see what “order” of this knowledge the foreigner adds… ah… but in thinking it through I see the proof. What the foreigner does provide is a common starting point for this chain of logic to begin. They establish common knowledge not just about the existence of blue-eyed islanders, but also that everyone must begin working through the consequences of that truth as of the time of the announcement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Dear JP,")

#text("p is not common knowledge until the foreigner speaks, no matter how many blue-eyed islanders there are. For instance, when there are 2 blue-eyed islanders, everyone knows p, but not everyone knows that everyone else knows p. When there are three blue-eyed islanders, everyone knows p, and knows that everyone else knows p, but not everyone knows that everyone knows that everyone knows p. And so forth.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JP")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26565")[#strong[#text("JP")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("I believe the phrasing of p is important though. If p is the “existence of blue-eyed people,” I argue that was common knowledge before the foreigner’s announcement in any case with 2+ blue-eyed residents. Everyone could have seen a blue-eyed person, every person would know that everyone could see one, everyone would know everyone else knows that, etc. The p that matters is “existence of blue-eyed people AND announced to all at time t by the foreigner.”")

#text("Without loss of generality for 2+ blues, consider the case of 5 blue-eyed people. Before the announcement, everyone already knew blue-eyed people existed and knew there were either 4, 5, or possibly 6 of them. But they had no common frame of reference about when to expect the other 4 or 5 should appear for their ritual. Once the foreigner’s announcement was made, each of the non-blue eyed persons would expect the 5 blues to go through the process, culminating on the 5th day. Each of the blues would do the same, and realize on that 5th fateful day that they must be the 5th.")

#text("The information the foreigner contributes is to augment the common knowledge with a common starting point for applying their logic.")

#text("In any case, thank you for offering a very captivating logic problem. JP")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("Dear JP,")

#text("As I said before, if there are two blue-eyed islanders, it is not true that everyone knows that everyone knows p. More precisely, if A and B are the two blue-eyed islanders, it is not the case that A knows that B knows that p is true, because A does not know of any blue-eyed islander other than B. Similarly, with three blue-eyed islanders A, B, C, it is not the case that A knows that B knows that C knows p (because A does not know if B sees any blue-eyed islander other than C), and so forth.")

#text("There is a very subtle distinction between truth and knowledge that needs to be maintained at every level of the knowledge hierarchy, otherwise one will be led to an incorrect conclusion with this problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26585")[#strong[#text("Persone con gli occhi azzurri « Storia di un matematico")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")]

#text("[…] e con molta gente che però partecipa alla discussione dicendo cose a caso) del problema degli isolani con gli occhi azzurri, un problema che cerca di far capire cosa sia la conoscenza colettiva. Mi è venuta voglia di […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/30f67c16eeeba610ca2835813682daea16f8645ba17cc1945e1ee742c3920adc-68d9e18ae8f45bf23c70627f6c909ef4aed6987254a65285e89490115d8dba7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ihilien")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26586")[#strong[#text("ihilien")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("you people are really over thinking this. the foreigner’s statement would have no effect. (at least some of) the community members already know there are bue eyed people in the community, since they can see each others eye color. they just don’t know if they themselves are in the blue eyed group. since they only have to kill themselves (?) if they find out THEIR OWN eye color what is the big deal? the statement of the foreigner did not specify who had blue eyes so if they all keep their mouths shut no harm don. i think the bigger question is why so many people would willing participate in a suicide cult.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26587")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("ihilien,")

#text("It’s not a matter of “keeping their mouths shut.” As professor Tao stated above:")

#text("[for the purposes of this logic puzzle, “highly logical” means that any conclusion that can logically deduced from the information and observations available to an islander, will automatically be known to that islander.]")

#text("Given this, the events unfold the way they do. Also, it’s just a puzzle. Asking why people would willingly be in a suicide cult is missing the point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OJ")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26589")[#strong[#text("OJ")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("I agree with ihilien!")

#text("@Saad:")#linebreak()#text(" In puzzles are sometimes information provided to disorient people – that’s the nature of the game…")

#text("And I think, the statement of professor Tao (about “highly logical”) has no effect on the islanders, because they can not reason anything NEW from the strangers statement…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26590")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("OJ,")

#text("There IS new information given to the people: common knowledge of the statement that there are blue-eyed people on the island. I think you’re having trouble understanding common knowledge and how it applies to this example. I don’t think I can explain it better and more succinctly than Professor Tao did in his post above (23 February, 2008 at 4:23 pm).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of OJ")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26591")[#strong[#text("OJ")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("Saad,")

#text("I think, I got it now.")#linebreak()#text(" The new information given by the stranger is the beginning of common knowledge (like starting a chain reaction, with the result of killing the whole population)")#linebreak()#text(" But I still want to stick to my initial statement – if nobody starts reasoning, no one will die…")#linebreak()#text(" ;-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d48b39e175bbb6d4e6af9a357ef84d4bb5e853a446c32c30880ce41b0992510-8bf62b7458cba118cce7aa10d8d6f0727d22cd6aef96d810701928c2e4f2d55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26592")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("“Dear Randy & Trebuchet: As I stated before on 8 Feb 2:02 pm, in the absence of the foreigner there is insufficient information available for any islander to determine their own eye colour; this can be seen by considering the base case of the inductive step (one blue-eyed islander).”")

#text("If this is the case, how can the Playing Card formulation possibly work? No information is exchanged about card color and yet it works with 100% accuracy as long as not every card is black (which is not the case in our problem).")

#text("Or put another way: if the foreigner instead said (after having learned the ‘rules’ of the religion) “OK everyone, kill yourself as soon as you know your eye color, starting now”, the end result would be exactly the same. Me, as a blue-eyed person, would have 100% certain knowledge of my eye color on day 100, as long as I know that everyone else can reason as well I (logical) and will follow the rules (devout).")

#text("All that is necessary (hence the foreigner) is a clock to start.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("For more on common knowledge, see")

#link("http://plato.stanford.edu/entries/common-knowledge/")[#text("http://plato.stanford.edu/entries/common-knowledge/")]

#text("This page give the topic a thoroughgoing assessment. I think a lot of people here who can’t penetrate this puzzle b/c they don’t understand this notion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e093c233e3b4fd9212414ffdc0d05387015073c746c4571d57b8c51214acf03c-5d88fa03311d8419597a0e9087ae18cdffbacff798cecbf2f817831c878cbfa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26603")[#strong[#text("jian")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2008")])]

#text("Again, if one imagines all islanders were AI robots (who can only reason logically, and infallibly and only so), then one won’t have any difficulties in accepting the induction. In fact, it will be quite natural. Most difficulties in accepting the induction are implicitly in the artificial nature of the set up of the puzzle. I had that difficulty at the beginning.")

#text("Or one could imagine it as a games played among computers. It is in fact quite straight forward a solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of somejan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26616")[#strong[#text("somejan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("The induction can also be made the other way around:")#linebreak()#text(" There are 100 blue eyed people on the island.")#linebreak()#text(" If the stranger said “there are not 99 BEPs” (he’s talking about tribespeople, excluding himself), all BEPs will commit suicide the next day, because every BEP knows there are 99 or 100 BEPs on the island.")#linebreak()#text(" Now, if the stranger says “there are not 98 BEPs”, then, each BEP would reason that if there are actually 99 BEPs, they’ll all kill themselves the next day. That doesn’t happen, so every BEP concludes that he himself is also a BEP.")#linebreak()#text(" (Note that everybody already knows that there are not 98 BEPs, they’re all considering the options that there are either 99 or 100 BEPs.)")#linebreak()#text(" The same holds true if the stranger says “There are not 97 BEPs”, but it would take 3 days. The strangers declaration that there is at least one BEP is equivalent to saying that there are not 0 BEPs, so after 100 days all BEPs kill themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of somejan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26619")[#strong[#text("somejan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("The assumption that everybody is logical and devout, and that that is common knowledge, is, however, not strong enough. Everybody would not have to be mere logicians, but also logicians totally committed to Kripke logic, or modal logic, or whatever this type of logic is called. That is not what real people do, since if they are logical at all, they better be bayesian logicians as there are only very few things totally beyond a doubt 100% certain in our world.")#linebreak()#text(" And, of course, the world in which the tribe lives can’t be our world, but needs to be a perfect platonic mathematical world. In our world, thanks in part to quantum mechanics, there are always uncertainties. How would the tribespeople be certain that everybody understood the stranger correctly? Perhaps somebody erronously thought the stranger was talking about brown eyes. “Blue” and “brown” do not sound terribly different. And if there is the smallest chance of doubt, the induction fails.")

#text("Secondly, the story doesn’t tell why these perfectly logical tribespeople follow this religion. That’s because on this island, there also lives a demon (named ‘the eye of Kripke’). That demon is a perfect modal logician, and if he determines that someone could have learned his own eye color, and didn’t kill himself, he will torment that person for eternity and will not allow them a chance to commit suicide again.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2008")])]

#text("Dear Randy,")

#text("The card game you mention is not directly analogous to the blue eyed islander puzzle, because the behaviour of the players is bound by a fundamentally different rule. The correct analogue of the puzzle would be if you replaced rule (3) in your Feb 18 11:15am comment by")

#text("3′) If at any time you discover which colour your card is, lay it down on the table.")

#text("One can then show by induction that at each stage of the count, no cards are laid down and no new information (of any order) on the colour of the cards is obtained. For a very similar reason, if the traveler does not mention eye colour at all, then no information is communicated and no suicides begin at any time.")

#text("[It is true that once the traveler speaks, the islanders behave as if they are executing a rule similar to (3), but this is an emergent phenomenon rather than a fundamental one, and one which is contingent on the traveler’s actions.]")

#text("Dear somejan,")

#text("Regarding your final comment, I refer you to the second paragraph of the puzzle (the one that was added Feb 15), as well as the penultimate paragraph of the post (which was added Feb 12).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JP")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26643")[#strong[#text("JP")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Here is what I don’t understand (and it only applies for 3+ blue-eyed residents, 1 and 2 being cases where the conclusion is clear): The islanders don’t have common knowledge until the foreigner’s remark. Yet the foreigner’s remark adds no new information, since everyone already knows that blue-eyed islanders exist, that everyone else can see this, that everyone knows that everyone else can see this, and so on. Aside from my previous idea about a common reference point in time, I can’t grasp what the remark adds that wasn’t there before. And if it adds nothing, the conclusions should have played out long before the foreigner.")

#text("If the foreigner had said, “I can’t believe 100 of you have blue eyes just like me,” I see what common knowledge is created. But they didn’t, and it’s apparently not the common reference point in time that matters. If that’s the case, would the outcome be the same if the foreigner gave their speech on multiple nights to subsets that covered everyone on the island?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Dear JP,")

#text("The “and so on” in your statement “everyone already knows that blue-eyed islanders exist, that everyone else can see this, that everyone knows that everyone else can see this, and so on” is, unfortunately, incorrect. Please see my comment from 23 Feb at 6:32pm for a discussion of the k=3 case, which is already typical. When there are 100 blue-eyed islanders, the correct statement is that “everyone already knows that at least 99 blue-eyed islanders exist, and knows that everyone else knows that at least 98 blue-eyed islanders exist, that everyone else knows that everyone else knows that at least 97 blue-eyed islanders exist, and so on”, with this chain of knowledge terminating after 99 steps. The foreigner adds the crucial 100th step that starts off the chain reaction. (If the foreigner asserted that blue-eyed islanders existed to overlapping proper subsets of islanders only, then it is indeed true that no new information is added, because the information content of each of the foreigner’s statements does not reach the 100th level of the hierarchy.)")

#text("As I said in my previous comment, one has to continually distinguish between truth and knowledge at every stage of the hierarchy in order to obtain a correct conclusion; in particular, when there are k blue-eyed islanders, one has to make this distinction k times (and not just once or twice).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e093c233e3b4fd9212414ffdc0d05387015073c746c4571d57b8c51214acf03c-5d88fa03311d8419597a0e9087ae18cdffbacff798cecbf2f817831c878cbfa6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26658")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("For those still can’t see how new information is added in by the foreigner’s speech, consider the two statements below. First, let’s name the blue eyeds B1, B2 … B100.")

#text("Statement A: B1 knows that B2 knows that B3 knows … … B99 knows that there are blue eyeds.")

#text("Statement B: B1 knows that B2 knows that B3 knows … … B99 knows that B100 knows that there are blue eyeds.")

#text("Before the foreigner makes the speech, only statement A is true. After the foreigner makes the speech, statement B is true. The key to see this is that, as B1 speculates he sees 99 blues. As B2 speculates IN B1’S SPECULATION he sees only 98 THEORETICAL blue eyeds (ie. blue eyeds for sure) due to the fact that B1 does not know his own eye color. Similarly, B3 in B2’s speculation which is in B1’s speculation sees only 97 theoretical blue eyeds. … … Hence, B99 in B98’s speculation which is in B97’s speculation …. … which is in B2’s speculation which is in B1’s speculation sees 1 theoretical blue eyed. Finally B100 in B99’s speculation which is in B98’s speculation … … which is in B1’s speculation sees NO theoretical blue eyed. Then the foreigner makes his speech. Now, B100 in B99’s speculation … … which is in B1’s speculation knows that there are blue eyeds, ie. he now sees theoretical blue eyeds.")

#text("One can think this through when there are only 3 blue eyeds first to see how this works. Then try 4, 5 to see how this holds true for higher numbers.")

#text("Hope this helps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-6/#comment-26660")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2008")])]

#text("Prof. Tao,")#linebreak()#text(" How does the idea of having a weekly(or so) puzzle section of your blog sound to you?")

#text("John")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("No one kills themselves. The reason is that they can’t agree on the time by which they wait for others to figure out the solution.")

#text("Say we have two blue eyed people. They are both very logical so they instantly grasp the inductive nature of the problem. So the first guy says “Hey, I will wait one day for the other blue eyed guy to figure it out. If he does, we are both dead”")

#text("the second guy thinks “Hey, I will wait five seconds for the other blue eyed guy to figure it out. If he does, we are both dead”")

#text("Then they both realize that they cannot logically predict how long they are both are going to wait to have the other guy figure it out. Logically, and instantly, they conclude that there is no way to agree on a time period to figure it out. They go about their daily lives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a3e27e3c8d2b4af19c98579bfe6d444a661770979935c8cba14511f730e69f2-2a5a861e6f252a51db5ed9f46b690b326943570f2a2e9f002cc6c432375140e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Rice")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26215")[#strong[#text("Adam Rice")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Saad’s explanation seems to work for me, but I’d posit an addendum: the day after the blue-eyed people all kill themselves, so do the brown-eyed people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7383f8d80a8b888729dfa3316abe243dc3cd4ce58d6bb737ba536d1898fba7e7-f167e42c2a04e433f1a217e60790ed58c89730c79584c3e86143fc0f5c98f855.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brown-eyed-girl")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26216")[#strong[#text("brown-eyed-girl")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("This may have been said already (I have not read all comments), but the intuitive difficulty I have with the puzzle is understanding what new information the stranger provides. There can be no suicide if he provides no new information.")

#text("1 blue-eyed person (BP):")#linebreak()#text(" Beforehand the single BP does not know the island has BP.")#linebreak()#text(" Afterwards he does. So new information.")

#text("2 BP:")#linebreak()#text(" Beforehand every islander knows that the island has BP, but each BP does not know that the other BP knows that there are BP on the island. Or more simply, everyone knows there are BP on the island, but not everyone knows that everyone knows there are BP on the island.")#linebreak()#text(" Afterwards, everyone knows that everyone knows there are BP on the island, so new information.")

#text("3 BP:")#linebreak()#text(" Now everyone can see at least 2BP. So everyone knows that everyone knows there are BP on the island. But each BP can only see two other BP, and they do not know whether each of the BP that they see can see one or two other BP. If a BP can only see one other BP, then as with the 2 BP case, they don’t know whether that BP knows whether there are BP on the island. Therefore, each of the 3BP do not know whether the two other BPs know whether everyone knows there are BP on the island. Or more simply, everyone knows that everyone knows there are BP on the island, but not everyone knows that everyone knows that everyone knows there are BP on the island.")#linebreak()#text(" Afterwards, everyone knows that everyone knows that everyone knows there are BP on the island. So new information.")

#text("4BP: etc")

#text("So to break it down, you have the following theorem:")

#text("Let P0 be the proposition that there are blue-eyed people on the island, and let Pk be the proposition that everyone knows Pk-1. If there are n blue-eyed people on the island, then n days after Pn becomes true, all blue-eyed people will commit suicide.")

#text("Pn-1 is true before the stranger makes his faux pas, but Pn is false beforehand. Afterwards, Pn is true (as is Pn+1, Pn+2 etc but we don’t need those). That’s why the BP don’t commit suicide until the stranger speaks.")

#text("This is so hard to think about because we (or at least I) have absolutely no intuition about the difference between Pn and Pn+1 when n is bigger than 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e47a7975ce4e313be358fccbac7c344fbe23f9b2f89ef0149c3e33ba5d00df18-1da0631760f6dbe1187cea346e95ba241ae9db5d9e6947a3fc8c6f6ee3071943.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mark Kraft")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26218")[#strong[#text("mark Kraft")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("But what if I’m green-eyed? Admittedly, I would have to admit it would be statistically improbable, but not impossible… and I wouldn’t *KNOW* I wasn’t green-eyed.")

#text("Besides, I could be colorblind too. ;-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26224")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("No, EVERYONE would kill themselves on the 100th day.")

#text("EVERYONE would see on the 99th day that no one killed themselves.")

#text("EVERYONE, since they don’t know the color of their own eyes, would assume that *they* were the 100th.")

#text("And EVERYONE would die on the 100th day.")

#text("If you’re making the assumptions that lead to the second conclusion, then the real answer is the whole tribe is dead, on day 100. There’s no other conclusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brown-eyed-girl")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26226")[#strong[#text("brown-eyed-girl")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("No David, the brown-eyed islanders see 100 blue-eyed islanders, The blue-eyed islanders see 99 blue-eyed islanders. So the blue-eyed islanders, seeing no-one killed themselves on day 99, will kill themselves the next day, but the brown-eyed islanders won’t know until they see the blue-eyed islanders kill themselves on day 100 that they do not have blue eyes.")

#text("Note that the brown-eyed islanders do not kill themselves the day after the blue-eyed islanders, because they don’t know that there are only two eye-colors, so each one doesn’t know whether they are the only non-browned eyed person or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26227")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("david:")

#text("no, the brown eyed people know there are 100 blue eyed people, because they count all of them, the blue eyed people only know that there are 99 blue eyed people, so when day 100 rolls around with no death toll everyone who thought there was only 99 blue eyed people realize that there must be 100, and since they were wrong in their earlier count, that they must be one of the blue eyed people, thus they take their own lives.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/607e148344e30fc5522da4f989d0ee24b0117770dafe1f35750c6a59f3086199-0dfc51be64a5af5a2825bea9ab8972ee48de8348728b22d6450075ffd6795096.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of papaya nirvana")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26229")[#strong[#text("papaya nirvana")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("First off, it is obvious that the traveler knows his own eye color… therefore if he didn’t kill himself immediately, the tribe would kill him as a heretic.")

#text("He didn’t add any new information, everyone in the tribe knew that there were either 99 or 100 Blues in the tribe, and either 999 or 1000 Browns… and one more talley based on his/her own color, which may be green for all he/she knows.")

#text("Since nobody is talking about it, there is some ambiguity in the common knowledge: most people have either brown or blue eyes, and that ratio is about 10:1.")

#text("Nobody will kill themselves if the possibility exists that he/she has a different color eyes.")

#text("…and if we start adding in colored contacts, it becomes even more muddled.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh Simmons")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26235")[#strong[#text("Josh Simmons")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("The obvious answer is that the foreigner would commit suicide the next day. But the whole island would die anyway due to some flu or illness previously unseen on the island that the foreigner unknowingly brought with him.")

#text("Answer: Everyone Dies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26242")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("Argument 1 is the correct answer.")#linebreak()#text(" Argument 2 is incorrect because if the the blue eyed folks knew they had blue eyes they would have already committed suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26243")[#strong[#text("Zach")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("The foreigner is irrelevant. The instant all of the islanders gather together they will have the information necessary, and know that everyone else has the information necessary, to trigger the string of suicides. Therefore if they suicide hypothesis is accepted by the islanders, they would consider it suicidal to gather every single islander together, and would refuse to all be gathered together. If they were, they would immediately kill the foreigner for attempted murder and run away before they finished counting, and refuse to speak of the event. Since they wouldn’t know for certain that all of them had finished counting, none of them would have to commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mekki")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26253")[#strong[#text("mekki")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("All the islanders were kill themselves. There’s no math needed. Once the foreigner said he was glad to see all the blue eyed people, everyone had to assume that they were one of the blue eyed people and thus they would have to kill him or herself. If they didn’t think they were blue eyed then they had to be convinced that they were brown eyed. Thus, again, they would have to kill themselves.")

#text("Why? Because you may know the statistic of 1000 islanders with this number of blue eyed people and this number of brown eyed people but the islanders, themselves, don’t.")

#text("Either way, you have an island full of dead people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5096993a73d6a028865a8699cca292454f0b535708bb65a54e3938e6901c18ba-368bb028ddc2f83c9875769ab3992472d282cb70dfe65d976c04edbd9aea13bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of still awake")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26254")[#strong[#text("still awake")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("I only read the first few comments but am going to post this anyway. Hopefully I won’t sound like (or turn out to be) an idiot. Here’s my idea:")

#text("(i) Say there is 1 blue-eyed person (‘BEP’) on the island. The traveler’s statement will tell this person they are blue-eyed (because that person sees no other BEP) and that person will kill themselves.")

#text("(ii) Say there are 2 BEP on the island. Each will know there is 1 BEP, 998 brown-eyed people, and themselves (eye colour unknown). Each will be able to determine their own eye colour from the actions of the other BEP. On the appropriate day, if the other BEP were to kill themselves, the person would have to have brown eyes (as the dead BEP would not have seen any other BEP). If the person were *not* to kill themselves, however, that would mean the person has blue eyes, as the other person would have been waiting for the same determination. Next day both will have to kill themselves.")

#text("(iii) Say there are 3 BEP on the island. The idea is to extend this pattern to the 3rd BEP: each BEP knows that there are 2 BEP, 997 brown-eyed people, and themselves (eye colour unknown). Each BEP could then determine their own eye colour from the actions of the other 2 BEP: if they were to have brown eyes, the 2 BEP would be stuck in the same situation as above, and would end up killing themselves. When the other 2 BEP do not kill themselves at the appointed time, however, the person knows they must *not* be brown-eyed, and thus must kill themselves. Each BEP has this perspective, and so all BEP must kill themselves on the next day.")

#text("But in (iii) is where I think a mistake is made. If there are 3 or more BEP, such as in (iii), then each BEP knows something they do not in (i) or (ii), which is that every BEP (regardless of their own eye colour) knows that there is at least one other BEP. So only with 3 or more BEP in the group is it common knowledge – i.e. known to every member of the group – that *every other member of the group knows* that there is at least 1 BEP. This is different from the idea that “everybody knows there is at least 1 BEP”, which would be true in (ii).")

#text("So in both (iii) and the problem’s stated 100 BEP case, the traveler’s statement actually does not change the tribespeople’s situation, i.e. it does not give any person new information about the number of BEP. Each already knows that there is at least 1 BEP, *and* each already knows that everyone else already knows there is at least 1 BEP. Nobody starts questioning; that is, the chain of reasoning that results in many (probably grisly) demises cannot begin under these circumstances because the reasoning in (i) – and (ii) – is not consistent with this knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26255")[#strong[#text("links for 2008-02-16 at Everybody needs Somebaudy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")]

#text("[…] The blue-eyed islanders puzzle « What’s new There is an island upon which a tribe resides. The tribe consists of 1000 people, with various eye colours. Yet, their religion forbids them to know their own eye color, or even to discuss the topic (tags: enigme yeux bleus bruns blue brown eyes logic) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("wow! interestin puzzle man!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe693411f3c1ef83f6bd962fe42037d9a4afa822eb0d29da2d83736743dea583-8ada899733eedc408d7ba23b39ec5dbe35357491131fa6c90b87e7499d54b575.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26262")[#strong[#text("Jordan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("When the foreigner mentions seeing someone else with blue eyes, all the blue-eyed people will just look around and say ‘well, there are indeed several blue-eyed people here.’ But since no one has any idea exactly how many blue-eyed people there are, no one could possibly assume their own eyes are either blue or brown.")

#text("When no one commits suicide, I don’t think anyone will say ‘oh man, it must be me.’ If anything, everyone will just either get really annoyed that no one stuck to the culture, or they’ll just think ‘well, none of us knows our own eye colour anyway, so that’s why they didn’t do it. We can forgive them for that.’")

#text("Everyone knows their own eye colour is either blue or brown; when no one commits suicide, each person is still left with just that possibility (unless some of them think they might have eyes of a different colour).")

#text("The induction process can’t even begin because ")#emph[#text("n")]#text(" and ")#emph[#text("n-1")]#text(" don’t exist. There is no spoon…er, I mean ")#emph[#text("n")]#text(". There’s just a bunch of people who know there are blue-eyed people among them; when some newbie blurts out the obvious, no suicides will take place because everyone will remain blissfully unaware of their own eye colour—even if they squint their eyes and think about it real hard.")

#text("I’ll admit it, I almost failed math in high school (I only passed because the teacher made the mistake of telling my dad he’d pass me if he thought I was trying, so of course I acted like I was trying). But in the end I really don’t think this is a math problem. Just a happy story where nobody dies.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26268")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("Its counter intuitive but I believe its correct:")

#text("A. If there is 1 blue-eyed he will obviously deduct that he has blue eyes after the foreigner’s comment: 1 suicide on day 1.")

#text("B. If there are 2 blue-eyed, each will deduct from the others hesitation (A does not occur) that there must be one more hence they will each know they have it: 2 suicides on day 2.")

#text("C. If there are 3 blue-eyed, each will deduct from the other 2’s hesitation (B does not occur) that there must be another: 3 suicides on day 3.")

#text("And so on..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26284")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("I think you only need to think of the case with three blue-eyed islanders to understand the problem.")

#text("If we take the case before the foreigner comes there will not be a mass suicide. The reason is that while each person A,B, and C will know there are two other blue-eyed persons, known of them will know whether the other two are seeing one or two other persons with blue eyes.")

#text("To simplify, lets just imagine that each person assumes he has brown eyes, if he doesn’t have evidence to the contrary.")

#text("So, A is thinking that B and C see one blue eyed person, since A assumes that he is brown eyed if no evidence to the contrary. In addition A, is thinking that B thinks that C see no blue eyes, and vice versa.")

#text("In this state the knowledge propagates to A because B thinks C doesn’t think there are any blue eyes and and B thinks there is only one blue eye.")

#text("The foreigners announcement changes that because A can’t think that B thinks that C thinks there are no blue eyed people. So it changes the reasoning after each day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26286")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2008")])]

#text("thanks to all of you for arguing any of this…proof and mysteries are made in, and from, the questions no one can answer, or ask (as the case may be). It’s been fun and enlightening reading them all.")

#text("ciao")

#text("kiki")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26297")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("Nice puzzle! one of thease that after one minute you think “an easy one!” then after 5 minutes you think “oh, wait, I was wrong!” and ony after some time, half an hour or few hours or few days, doesn’t matter you finally say “oh, oh, I was wrong again…” and realize what is really going on there…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd04be6db72e2104c08f64365f51ebbfb2a1fab29fdfd01a55b6ce5cbd9748e4-62cccdb3d95822c07f7ac7206ae9d0ed2390fd36b6fa9f95b0bdd189813c07c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26314")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("“But in (iii) is where I think a mistake is made. If there are 3 or more BEP, such as in (iii), then each BEP knows something they do not in (i) or (ii), which is that every BEP (regardless of their own eye colour) knows that there is at least one other BEP. So only with 3 or more BEP in the group is it common knowledge – i.e. known to every member of the group – that *every other member of the group knows* that there is at least 1 BEP. This is different from the idea that “everybody knows there is at least 1 BEP”, which would be true in (ii).")

#text("So in both (iii) and the problem’s stated 100 BEP case, the traveler’s statement actually does not change the tribespeople’s situation, i.e. it does not give any person new information about the number of BEP. Each already knows that there is at least 1 BEP, *and* each already knows that everyone else already knows there is at least 1 BEP. Nobody starts questioning; that is, the chain of reasoning that results in many (probably grisly) demises cannot begin under these circumstances because the reasoning in (i) – and (ii) – is not consistent with this knowledge.”")

#text("Suppose instead of saying “at least one of you has blue eyes”, the visitor said “I like football”. Then in the case where there are three blue eyed people A, B and C, A knows that B knows that there is at least one person with blue eyes. But he does not know that A knows that B knows that C knows there is at least one blue eyed person or BEP. I find the best phrase to use is “for all A knows”. For all A knows, it is the case that B is thinking “for all I know, C is thinking “for all I know, there is noone with blue eyes on the island””. To write out A’s thought’s in full:")

#text("“For all I know, B is thinking “for all I know, C is thinking “for all I know, there is noone with blue eyes on the island”””.")

#text("It doesn’t take much imagination to imagine what the thoughts of A will be for the case where there are 4 or more BEP on the island. Naturally the thoughts of B, C, D and so on will be the same.")

#text("The way to imagine it is put yourself in the position of a blue eyed islander, and think thoughts of nested “for all I know”s. Then you will realise that the visitor does provide new knowledge when he says “at least one of you has blue eyes”. He provides new nth order knowledge, where n is the number of blue eyed people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/961bef834de1e0fb4281b9a4bd7a53e84b39b3d226e6228a8379b130ee1957d9-a05a97d93e569d02342ad767d8993a72c03edb468e7dcf5f3b6630fafdd05dda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of henry haver")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26328")[#strong[#text("henry haver")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("their religion forbids them to know their own eye color, or even to discuss the topic, so the comment logically has no effect. case closed. why all the discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("i thought i’d write this out at length to ensure no ambiguity about the necessity of the foreiner’s input.")

#text("before any information is given to the islanders:")

#text("if there is 1 blue-eye person on the island then he does not know there are blue-eyed people and so will never commit suicide.")

#text("if there are 2 blue-eyed people on the island then they each know there are blue-eyed people on the island but do not know if the other person does, as they do not know if they themselves are blue-eyed. for this reason it gives no new information when no-one commits suicide.")

#text("if there are 3 blue-eyed people on the island then each in turn will think the following (statement 1): “those two blue-eyed people each know there are blue-eyed people on the island, however, assuming my eyes are not blue, they do not know that the other person knows there are blue-eyed peole on the island, and so no-one commits suicide and this gives no new information. if my eyes were blue then those people would think exactly as i have and so once again no-one commits suicide and this gives no new information.”")

#text("and for completeness, so that it is clearly justifiable to extend to an arbitrarily large number of blue-eyed peole N,")

#text("if there are 4 blue eyed people on the island then each in turn will think the following: “those three blue-eyed people each know there are blue-eyed people on the island, however, assuming that my eyes are not blue, each one of them will think as in statement 1 because they do not know their own eye-colour. if my eyes were blue then those people would think exactly as i have and so once again no-one commits suicide and this gives no new information.")

#text("thus without any information being given to the islanders each blue-eyed person can form a chain of such reasoning, and no suicide occurs. the act of the foreigner saying there is a blue-eyed person doesn’t appear to give any information, however it does confirm to everyone that everyone knows there are blue-eyed people on the island, something which is necessary for the inductive reasoning to occur.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b29a7adf98fedc044a7d40dbe30f01e031e53712ddb6d43eda31b89f6ed5e72-5b66fde2700663134500b3ab52a6ae75b36db68dfa2ec56586c26ab09713a3e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jd2718")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26336")[#strong[#text("jd2718")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2008")])]

#text("I include this in a group of problems I give high school students. The element they have in common is “adopting multiple points of view.” In this problem, if our BEP are George, Harry, and Isaac, we adopt the POV of George as he adopts the POV of view of the other two, deciding why they haven’t done themselves in… This, for us, is central. I handwave through the induction.")

#text("The first problem in the series is introductory to this theme. It is also fun, if not as engaging: 3 blindfolded prisoners are seated, and a hat is placed on each of their heads. All know that there are 3 red and 2 white hats. A prisoner guessing the color of his own hat is set free.")

#text("The first prisoner’s blindfold is removed, and he announces he does not know the color of his hat.")

#text("The second prisoner’s blindfold is removed, and he announces he does not know the color of his hat.")

#text("And, blindfold still on, the third prisoner announces the color of his hat and goes free.")

#text("Explain.")

#text("Jonathan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Red.")

#text("The second prisoner knows there is at least one red hat on himself and the third prisoner from the first prisoner’s statement. so, if he sees a white hat on the third prisoner, he would deduce that his own hat must be red. But he can’t decide in fact. From which the third prisoner concludes that his hat must be red.")

#text("I love the idea of setting prisoners free but massive suicide!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b29a7adf98fedc044a7d40dbe30f01e031e53712ddb6d43eda31b89f6ed5e72-5b66fde2700663134500b3ab52a6ae75b36db68dfa2ec56586c26ab09713a3e9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jd2718")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26346")[#strong[#text("jd2718")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Discuss suicide lightly in high school? LOL. Way too ‘correct’ for that. My version describes the island as paradise, but if you learn your eye color you must swim away and never return… Otherwise, yes, the irony…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d48b39e175bbb6d4e6af9a357ef84d4bb5e853a446c32c30880ce41b0992510-8bf62b7458cba118cce7aa10d8d6f0727d22cd6aef96d810701928c2e4f2d55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26357")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("To bypass the discussions of religion and suicide, etc. consider this formulation of the problem, which is one that can be tried at home:")

#text("* Sit 10 people (or any number greater than 2) at a circular table")#linebreak()#text(" * Deal a shuffled deck of cards, one card per person, face down on the table")#linebreak()#text(" * Each person lifts up their card, face out, so that everyone can see it but themselves")#linebreak()#text(" * Give the instructions:")#linebreak()#text(" 1) Look around and count the number of Red cards you see")#linebreak()#text(" 2) The game is over when when all of the Red cards are laid face up on the table")#linebreak()#text(" 3) If you hear a count one greater than the number of Red cards you see, lay your card face up on the table")#linebreak()#text(" * Someone starts counting out loud")

#text("If the instructions are followed, all of the Red cards, and only the Red cards will be turned up at the count N, where N is the number of Red cards.")

#text("Makes for a neat parlor trick!")

#text("This also makes me think that the absolutely only purpose of the foreigner in the original problem is to “start the count”. His statement adds no knowledge, third order or otherwise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d48b39e175bbb6d4e6af9a357ef84d4bb5e853a446c32c30880ce41b0992510-8bf62b7458cba118cce7aa10d8d6f0727d22cd6aef96d810701928c2e4f2d55d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Randy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26358")[#strong[#text("Randy")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("To follow up… there is one condition where this game will fail:")

#text("* All cards are black – In this case, everyone will turn up their card on the first count")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("This puzzle is as stupid as the endless banter it has created.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("I was asking myself what new information are the tribe’s folk getting from the travellers speach. I mean every guy already knows that there are someone with blue eyes on the island. So what’s new after the speach?")

#text("I think the new situation is that afterwards “everyone knows for sure that everyone knows that there are some blue eyed people on the island” and hence can conclude wether he or she has a blue eye or not after couple of days. right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b242adf2155578c7366d3735a65d688ba31a7016c46281093a22c37c6e6fa1e7-f662bfb65d95c18998fdd7fa561ae89ce0ab8b8f203ce76289e7d12ab9455048.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Icecycle")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26369")[#strong[#text("Icecycle")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Well, they ask him politely (at spear point on the edge of a volcano) to commit (Hoot Gibson*.)")#linebreak()#text(" This being the only logically worked out answer given all the conditions.")

#text("*Or maybe they were a ‘Clutch Cargo’ cult.")#linebreak()#text(" This being your snarky obscure reference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26370")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I think the new situation is that afterwards “everyone knows for sure that everyone knows that there are some blue eyed people on the island” and hence can conclude wether he or she has a blue eye or not after couple of days. right?")
]

#text("More accurately: everyone knows for sure that everyone knows for sure that everyone knows for sure that …. that everyone knows that there are some blue eyed people on the island.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26371")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("This may be nonsense but:")

#text("The tribe lives in a delicate balance where each member knows every eye color but their own.")

#text("So, for each islander, there is both common knowledge yet one unknown.")

#text("The stranger, however, brings common knowledge but NO ADDITIONAL UNKNOWN. Thereby tipping the scale and setting off the chain reaction.")

#text("Total bs im sure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8d0d4abdfcaec9629544c1131bf581ccd7276c7a74f1379510709d34e751a5d-34447db0f6dfbe7edb59185c9df43b32d4cf8275e86ef618a9f7e3a37597cc5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Church")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26374")[#strong[#text("Tim Church")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Shouldn’t the second blue-eyed person have already committed suicide? They can clearly see the first, and so they should both commit suicide on the second day after the first is born.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26378")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Hi Terence,")

#text("This version of the problem has become an example of the social phenomenon of cognitive distortion known as ")#link("http://en.wikipedia.org/wiki/Emotional_reasoning")[#text(" emotional reasoning")]#text(".")

#text("Readers may want to ask themselves how a different set of utilities or outcomes would effect this problem with otherwise the same parameters?")

#text("For example, instead of punishing the blue eyes, reward them with a trip to the stranger’s homeland;")#linebreak()#text(" or if all blue eyes donate a blood sample for testing, then reward the entire tribe with a hospital or other community facility.")

#text("Considering the study from the University of Copenhagen in my comment on 7 February, 2008 at 7:18 pm, another interesting problem may be to calculate other possible eye color combinations that may be hidden from the stranger; see ")#link("http://en.wikipedia.org/wiki/Eye_color")[#text(" Eye color")]#text(" genetics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26379")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("See also this reference from the wiki eye color page ,a href=”http://www.thetech.org/genetics/ask.php?id=29″> understanding genetics, eye color.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brown-eyed-girl")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26383")[#strong[#text("brown-eyed-girl")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("More accurately: everyone knows for sure that everyone knows for sure that everyone knows for sure that …. that everyone knows that there are some blue eyed people on the island.")
]

#text("John Armstrong, I think you only need meta-knowledge to the n-th degree where n is the number of blue-eyed islanders. I attempted to argue this in my ")#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/#comment-26216")[#text("comment above")]

#text("I may be wrong, but I think the key to understanding the puzzle and to understanding why the puzzle is so difficult to understand is to note that the information provided by the stranger ensures everyone on the island has meta-level “n” knowledge, whereas before he speaks they only have meta-level “n-1” knowledge. Meta-level “n” knowledge is necessary and sufficient for suicide on the n-th day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe53e2925b52c294782bd4e930d2feb2de5e11ce79155ce0379827eacee195d-0b2bcba381604c3b2c28513b8174ea7ebd6f528a5e4af90bf8fd28bc81c65024.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haelfix")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26384")[#strong[#text("Haelfix")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Let us hope for the islanders sake, that a baby is born with below average intellect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe53e2925b52c294782bd4e930d2feb2de5e11ce79155ce0379827eacee195d-0b2bcba381604c3b2c28513b8174ea7ebd6f528a5e4af90bf8fd28bc81c65024.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haelfix")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26385")[#strong[#text("Haelfix")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Actually I should say, exactly average intellect")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26387")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Yes, to the ")#mi("n")#text("-th level. I’m sorry I left the explicit number of repetitions out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22d88a80e07cf3ef3beb2d9b58165019278b62080e032cdd712b72a7d533975f-5e85cebb7a9b33576a5250a1bddfb3654ce6e18576aa03e4c30e9d33ca642d0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anton")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26388")[#strong[#text("Anton")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Here’s a variation to think about once you’ve solved the original. What difference is there, if any, if one of the tribespeople happens to go to the bathroom during the foreigner’s speech? Having not heard the foreigner’s comment, this tribesperson doesn’t see any cause for alarm, but what about all the others? Does the color of this person’s eyes make a difference?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Amazing! Endless comments!")

#text("Since people love puzzles this much, I like to share too cute puzzles given to me by my friend, so that you folks can take a break from thinking of the blue eyeds:")

#text("Puzzle 1.")

#text("Consider the two sequences below:")

#text("A E F H I K L M N T V W")

#text("B C D G J O P Q R S U")

#text("Now, consider the last three letters in the alphabet X Y Z, which sequence do they belong to?")

#text("Puzzle 2.")

#text("There are 12 ping-pong balls, all look the same, yet one is either lighter or heavier than the rest. Now, given a balance but without weights, and you are allowed to make no more than three weightings to find out which ball is the defective one.")

#text("( Professor Tao,")

#text("Since this is unrelated to the original puzzle, it is OK if you like to delette this post.")

#text("Thank you.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("By the way, persons who figure out the first puzzle can state the answer but please do NOT tell why. This childish puzzle once defeated a friend of mine who was a very talented mathematician. When he learnt the answer, he could only smile…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("to the first sequence?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26421")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2008")])]

#text("Dear Anonymous,")

#text("In order not to spoil the puzzle for others, I won’t tell if your answer is right or wrong…")

#text("Puzzle 2 looks easy and conventional, but it is quite fun and difficult (at least for me). Don’t give up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26432")[#strong[#text("Mundane Ramblings » Mind-bending puzzle")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")]

#text("[…] by it. Here’s the text of the puzzle for your own enjoyment, which I thoughtfully ganked from the original site. There is an island upon which a tribe resides. The tribe consists of 1000 people, with various eye […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vlad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26436")[#strong[#text("Vlad")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("How about this approach:")

#text("The question is why the foreigner’s speech would ever trigger ANYTHING at all, since he, in fact, discloses NO new information to the public. Their common knowledge seems not have changed after they listened to him, as they were already well aware of the fact, that some of them are blue-eyed.")

#text("Suppose, however, that there was only one person with blue eyes. Then, the foreigner’s speech would indeed bring news to him, so it will trigger his reaction. If there were two blue-eyed person, each of them would think that the speech did bring new information to the other, and after they realized it did not – this would trigger their reaction.")

#text("Therefore, we have a chained predicate of a kind “I think that you think that he thinks etc…. that this information is news to him” – and the very fact that the predicate turns out to be false constitutes this “new bit of information” that triggers the consequences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26437")[#strong[#text("Những chàng trai mọc sừng hay câu đố những người trên đảo mắt xanh. « Bờ-nốc bình dân")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")]

#text("[…] 20, 2008 at 4:55 pm (Cực khoái) Tình cờ đọc trên blog của anh Tao có một bài viết vui nhộn về đố vui – trò đùa nhảm nhí mà anh em ở Nice thỉnh thoảng vẫn hay đem ra […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26449")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("No one will commit suicide because he doesn’t say how many there are nor is he saying it to anyone in general… how is this a math problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-5/#comment-26452")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2008")])]

#text("XYZ go to the first sequence since all letters contain only strainght lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25886")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("I think the traveler should ask from the public “anyone who want to sacrifice himself for all the blue eyed people please raise your hand” and then choose from the volunteers :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25895")[#strong[#text("Sean")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("“Yet, their religion forbids them to know their own eye color, or even to discuss the topic”")

#text("Seems to me no one would commit suicide. Even if they were highly logical, they’d have to go to extraordinary effort in order to count out exactly how many blue eyed people they see and then count out exactly how many days had passed since the visitor had said he saw a blue eyed person.")

#text("On top of that, you’d have to believe, with their life, that everyone else is so interested in commiting suicide that they, too, would put forth the same effort.")

#text("Putting that much effort in deducing something that is verboten seems against their religion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fe06e6738500479d4b5c8067d625d0001241e34297661d30fabf47dcdd78696-45c87c89951e0728153889790535b8b0980dbe6fb4670f343eb5f49638622b19.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grover")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25896")[#strong[#text("Grover")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("According to the rule of the game “If a tribesperson does discover his or her own eye color, then their religion compels them to commit ritual suicide at noon the following day in the village square for all to witness.”")#linebreak()#text(" If it weren’t for the rule saying “the following day”, on the 100th day, as the 100 blue-eyed people go to the village square to commit suicide, the 900 brown-eyed ones, seeing the blue-eyed ones walking there, would then know there were only 100 blue-eyed people in the world, and so would go there too at the same time on the 100th day to also commit suicide. But then because no villager would know whether each of the others was there for being blue-eyed or for being brown-eyed, they’d all turn around and walk away, and so equilibrium would be kept.")#linebreak()#text(" The rule dividing something continuous, time, into something discrete, 24-hr periods from noon to noon, is as much responsible for the suicides, 100 on the 100th day and 900 on the 101st day, as is the maths of knowledge discovery. The statement of the foreigner provides the first “tick” through this discrete medium.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Why would they wait for N-1 days?")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25898")[#strong[#text("Why would they wait for N-1 days?")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Everyone knows the eye-color of all the other tribes people. In the case with 1 blue-eyed person, he can see that everyone else has brown eyes. So when the traveler says there is at least one person with blue eyes, the blue-eyed guy knows it’s himself. And suicides the next day. If there are two blue-eyed people, each would expect the other to kill himself the following day. When neither of them kill themselves, they can only conclude that the other has seen someone with blue eyes, which since everyone else has brown eyes, must be themselves. They both kill themselves the second day. With three blue-eyed people, all three know no one will kill themselves on the first day, each will expect the other two to kill themselves on the second day. But they don’t. From this they can each conclude there must be a third person with blue-eyes, and it can only be themselves. So on the third day they kill themselves.")

#text("They wait n-1 days, because that’s the number of blue-eyed people they can see. (They can’t see themselves) So when on n-1 days no one kills themselves, each blue-eyed person realizes there must be one more blue-eyed person than the ones they can see, and that it can only be themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orolokarr")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25900")[#strong[#text("Orolokarr")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("This is not a puzzle. There is nothing to figure out. This is merely a test of reading comprehension. The “puzzle” clearly states that the islanders are not allowed to discuss eye color. The foreigner makes a general statement, not a specific statement. He mentions he sees a blue eye person, he doesn’t say he sees 100 blue eye people.")

#text("The rules of the religion (again, reading comprehension) state that if a, “tribesman discovers his or her own eye color” they are to commit suicide. The foreigners comment is not directed at any specific person, so no one has any reason to think that they have blue eyes. They can all clearly see other tribesmen with blue eyes, so they can safely assume that the speaker was referring to them and then instantly forget about the whole thing.")

#text("Anything else is speculation and is not based upon the information provided. For any of the previously mentioned contrived theories to be anywhere near plausible, we have to assume a number of things that are not mentioned in the original statement, such as intelligence and reasoning ability of the tribesmen, mathematical knowledge, curiosity, memory (100 days is a long time), and even the average lifespan or even if they are nomadic and intermingle with other tribes, etc.")

#text("This is not a mathematical problem, this is an English problem and quite a few of you have failed at reading comprehension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25903")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("No, this is a biological problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd04be6db72e2104c08f64365f51ebbfb2a1fab29fdfd01a55b6ce5cbd9748e4-62cccdb3d95822c07f7ac7206ae9d0ed2390fd36b6fa9f95b0bdd189813c07c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25907")[#strong[#text("Dan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Hello, a lot of people seem to be arguing with the assumptions of the question! The point is not whether those assumptions would apply to any real-world situation, but what follows from those assumptions.")

#text("The knowledge that is required to make things go is not that every islander knows that there is someone with blue eyes on the island, but that for any configuration of the n blue eyed islanders that are present, A1 knows that A2 knows that … An knows that there is at least one person with blue eyes. The latter is much more in terms of information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/833b7b1a979e4e932537cf2c923fe520f0fb2ff726b3d967e7f32b97ad4144be-db8fe5049190e6967fa41b997687825ad906118bc79e75eb6c3a902bb6179b17.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Larry Clapp")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25909")[#strong[#text("Larry Clapp")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("I think the tribe would get together and kill the visitor the next day for violating their taboo and knowing his own eye color, and then go blissfully on as they had. :)")

#text("I also tried to “jump out of the system”, as Hofstadter says, and note that nowhere does it say that everyone knows that only two eye colors are possible. I theorized that a tribesman might reason that his eyes are, say, green, but in any case aren’t blue, but that doesn’t work out. Oh well. Misery death and despair K days later, probably on somebody’s birthday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25911")[#strong[#text("Blue Eyed Islanders. (now in puzzle format) « Essays by Danielle Fong")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")]

#text("[…] Eyed Islanders. (now in puzzle format) Terry Tao’s recent post on a classical logical puzzle has seeded a bloom of activity in the nerdsphere. A friend of mine […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25916")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Do anyone know of any physical examples to which the logic of common knowledg appies? There must not be human agency involved in the examples, thus better be in physics, chemistry etc. but enonomics and the like.")

#text("What is the application of the principle of common knowledge in general?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25922")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Jian: you’re joking, right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Dear Jian,")

#text("I would doubt that any such situation free of human agents would exist (although network effects could arguably be viewed as a demonstration of a very weak form of common knowledge). Even in biology, it appears that intelligent animals such as primates can exhibit empathy (which can be viewed as a crude form of second-order knowledge) but do not have the ability to understand third-order or higher forms of knowledge (which, as the above discussion shows, can be a subtle issue even for humans); indeed I understand that this capacity for higher-order abstraction is supposed to be one of the key traits that separate humans from other animals. It is perhaps possible that certain biological mechanisms (e.g. determination of the social hierarchy or pecking order) are non-trivially impacted by third-order or higher forms of “knowledge” (embarrassment is a good example of information with higher-order aspects – is it possible for animals to get genuinely embarrassed?), but this seems unlikely (and rather difficult to to prove, if it did exist). I would imagine that in the absence of advanced mental faculties in a species, actions based on direct observation or second-order observation (i.e. signals of direct observation, as are commonplace among social animals) rather than higher-order information would be simpler and more robust, and thus more likely to be selected for by evolutionary processes.")

#text("In economics, though, in which human agents are of course fundamental, this type of concept does play a non-trivial role. Robert Aumann and Thomas Schelling won the Nobel prize in economics in 2005 in part for their work on a rigorous formulation of common knowledge in game theory. I am not an expert on these things, but it is apparently theorised that certain delayed reactions to information in various markets are caused by the propagation delay in the conversion of first-order knowledge to common knowledge, somewhat analogously to the situation in the artificial puzzle discussed in this post.")

#text("I am even less of an expert in sociology, but I would expect that this concept is even more important there. The concept of a taboo, for instance, can be viewed as a collective attempt by a society to prevent first-order knowledge from propagating into common knowledge (at which point the taboo becomes completely ineffective).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ff9d041efc360886fef7a4ebe916a0d8e6c2b792d4b5fad75dd4ee11cd2dde3-b1a116733bf6840ccabf231ce8fac2746f25bfe9b14585a0d3480e88bf5f931f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Haacked")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25927")[#strong[#text("Haacked")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("> although the islanders are not initially aware of these statistics")

#text("So why shouldn’t a brown-eyed islander assume he/she has green eyes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25934")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("John,")#linebreak()#text(" I was serious. I was wondering if there exist systems in the physical world in logic paralell to that of common knowledge.")

#text("Professor Tao,")#linebreak()#text(" Thank you for your comment and the information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e4aea535aee52f57a81a64794aefd1e9d06b13d1569ef30af4d0242cbd32995-0e4df94382241e531f7b3fa1630422c1bd3e30f9c27e27c246d02db8e85e2bad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Me")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25937")[#strong[#text("Me")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Wouldn’t EVERYONE commit suicide? After all, if the blue eyes eventually equal zero, then a logical person would know this, and realise there eye colour must be brown…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25942")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Terence,")

#text("As a long time dog owner, and now with a very smart herding dog in the house, I can attest that animals can indeed experience embarrassment and shame, in addition to complex behaviors such as evasion while breaking rules and even playful deceit. Humans probably experience a lot more embarrassment though simply because we exist in a complex web of (often needless and destructive) expectations and strictures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25944")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("Isn’t Faith the only genuine form of common knowledge in humanity supposedly?")

#text("Isn’t form of common knowledge the mathematical form for meditation? It is my experience too: Faith is only a fancy word for trust: When one completely (in our language: “Commonly”) trusts the universe, trusts its elements Commonly, one sees the universe as a through entirety.")

#text("The meditating individual is already aware to the fullness of the blue-eyedness of the universe, but lacks self-awareness (reality confirmation). Then the visitor’s reality confirming message touches in: n = 1 ! (In Zen Buddhsim, it could take form in sound, imagery, line of poetry, thought, suddent trivial happening etc.). Infinity is thus reached (induction).")

#text("The individual then suddenly becomes aware to his own blue-eyedness. The individual becomes enlightened.")

#text("It actually makes better sense to understand our original puzzle the above way (even logicaly) with favorable enlightenment but ritual suicide as the consequences. Isn’t it consistent with our actual life experience in many situations too: We are already seeing it in full, but just lacking that final piece of reality to set in, and so we get stuck (like in a love relation)? Our conciousness system is in fact highly unstable towards enlightenment, like the Daoist sages say: The Dao is simple and the road to it flat, the foolish miss it, the clever overlook it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25976")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Jian: you’re asking for “knowledge” without “agency”. Please, fill me in on what miraculous philosophy allows for this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25981")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("John,")

#text("“knowledge” could be understood as interaction. (For instance, one could say two objects have knowledge about each other through gravitation). With agency I meant human agency.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alistilla")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25984")[#strong[#text("alistilla")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Since the stranger didn’t point out who exactly has blue eyes.. the custom hasn’t been violated. Although it will raise some doubt in some of them’s mind.. No one will know the color of their eyes.. n so..No suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8e925613dc5b902c82f02ef3d5fd95f0a7a5b7983d937c0079952e11a1641fd-420eb3d1edfa3fc42bd4381d0814ef978ade85b9e01f8e4c4c2a5cc6d0e80872.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alistilla")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25985")[#strong[#text("alistilla")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("If some1 doesnt sees any logic about my argument..do let me knw ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25993")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("alistilla, the stranger doesn’t have to point out who has the blue eyes.")

#text("By saying that there are blue eyes on the island, he has caused every inhabitant to know that every inhabitant knows there are blue eyes on the island. This initiates the inductive reasoning which leads to all the blue eyed people killing themselves on the 101th day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-25996")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("There exists a Stanford web paper 1997 discussing a variant of the Richard Borcherds [5 February, 2008 at 9:19 pm] variant of this problem by ")#link("http://www-formal.stanford.edu/jmc/model/model.html")[#text(" John McCarthy et al [or Nikos Drakos, Leeds], translated by Yasuko Kitajima")]#text(" using Kripke-structured semantics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26022")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("It is mandatory that I quote my mentor/coauthor Richard Feynman at this point.")

#text("“I wonder why. I wonder why. /")#linebreak()#text(" I wonder why I wonder /")#linebreak()#text(" I wonder why I wonder why /")#linebreak()#text(" I wonder why I wonder!”")

#text("Feynman was quite a party animal, when in the mood, and this has come up in prior threads about whether or not one needs to be a genius, and whether there is such a thing. But this leads me quickly to an anecdote on the fuzzy border between logic puzzles and deconstruction of the counterculture in the Summer of Love and its after effects.")

#text("In the (1968,1970) interval, when drug use on the Caltech campus was rather more liberal than was legal thereafter, and I was studying (among other things) infinitary logic, modal logic, Kripke semantics, and the like) I used to amuse myself by walking into smoke-filled parties and asking people the following original question:")

#text("“True or false?")#linebreak()#text(" If you don’t know")#linebreak()#text(" that you know")#linebreak()#text(" that you don’t know")#linebreak()#text(" that you’re not stoned,")#linebreak()#text(" then you’re stoned,")#linebreak()#text(" but you don’t know it!”")

#text("In a twisted sense, the best answer I ever got was this:")

#text("“30 days hath september,")#linebreak()#text(" april, june, and no wonder.")#linebreak()#text(" All the rest have peanut butter.")#linebreak()#text(" Except my grandmother.")#linebreak()#text(" She had a red tricycle.")#linebreak()#text(" I stole it.”")

#text("Common knowledge is a slippery concept, when there is limited rationality. And whether or not any islander commits suicide presupposes a common knowledge answer to the meta-question: “Why be logical?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Often, to be logical is to be irrational.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26027")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Professor Tim Poston")#linebreak()#text(" ")#link("http://www.geocities.com/nias_mmu/poston.htm")[#text("http://www.geocities.com/nias_mmu/poston.htm")]#linebreak()#text(" emailed me to comment:")#linebreak()#text(" 10:37 pm (22 minutes ago)")#linebreak()#text(" Besides the assumption that “All the tribespeople are highly logical and devout”, the argument needs the assumption that every blue-eyed tribesperson is obsessive about counting, and actually goes around tallying how many blue-eyes are on the island. (NB that you may know which of your relatives are red-haired, but that does not mean that you consciously assign a number.)")

#text("The assumption is dubious for most adults in most cultures, weird in the context of the specified taboo,")#linebreak()#text(" and absurd for any complete community, since it is clear that the youngest blue-eyes cannot have this obsession.")

#text("There is some evidence that even very small babies can ‘subitize’ numbers up to four, but infants do not reason about the numbers 99 and 100, do not count people or days that far, and do not suicide.")#linebreak()#text(" Since the others know this, the induction fails.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Mexbacher")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26049")[#strong[#text("Peter Mexbacher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("I have a question: why do we need an outsider?")

#text("Does it make a difference if an islander breaks the custom and declares: some of you have blue eyes?")#linebreak()#text(" Does it make a difference if the one who declares it has brown eyes or blue eyes (he himself can’t know which).")

#text("Imagine: there are 10 people with blue eyes, 90 with brown eyes.")

#text("One of them breaks the silence and says: some of you have blue eyes. After that, all respect the traditions again.")

#text("Is the introduction of the outsider mathematically necessary or is it just so that in the example the islanders don’t have to violate their tradition?")

#text("regards,")#linebreak()#text(" peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26051")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("I’m pretty sure that would do the exact same thing, Peter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Mexbacher")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26057")[#strong[#text("Peter Mexbacher")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Dear John,")

#text("thanks for your answer, I thought so too, but this common knowledge problem did quite upset my intuition so I didn’t know if maybe I missed something.")

#text("Regards,")#linebreak()#text(" Peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f81f40eee2773f6c7600bf0073873d5088e8920716f9597230f1397a44406f8c-42fb23057476bb97e8d0dd0a37106b9968e634d0eeade387ae4f153f8dfede5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26059")[#strong[#text("Charles Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("I’m still not following the logic that leads to all the blue eyed people die on day 100 or 101. I’m not a mathematician, I don’t get all this number theory hocus pocus. Can anyone explain in English, without using “n-1” and all that mumbo jumbo, exactly why this would happen? I can’t for the life of me figure out how only the blue-eyed people would figure out they have blue eyes, and why it would take 100 days and cause a mass suicide.")

#text("The logic seems to be binary: either the islander knows his eye color, and therefore must commit suicide, or he doesn’t. Is knowing the same as assuming? On Day 1 nobody assumes they have blue eyes. When nobody commits suicide on Day 1, wouldn’t *everyone* assume they’re the one with blue eyes? Is that enough to trigger and mass suicide on Day 2?")

#text("Is an assumption about eye color enough to trigger the suicide clause? They wouldn’t know for a fact what it is, but they’re making an assumption based on how everyone else behaves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26064")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Charles, it’s all about knowing what ")#emph[#text("the other people")]#text(" know. I don’t know whether I have blue eyes or not today, but I know what you would do if you ")#emph[#text("did")]#text(" know you had blue eyes. But since you don’t know, how could you not know? And from that I can learn information about what ")#emph[#text("other")]#text(" people know, and eventually about my own eye color.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Some general responses:")

#text("1. Several commenters have pointed out that the hypotheses of the puzzle have to be extremely strong in order for Argument 2 to apply, so much so that it is unrealistic to expect them to be satisfied. This is true, but does not actually resolve the issue that we have two arguments that use the same hypotheses to give contradictory conclusions. Unless the hypotheses are in fact logically impossible to satisfy in full (i.e. absurd), at least one of the arguments must be invalid, and it is therefore a good question to ask which one (or both) of the arguments is flawed. But the fact that the hypotheses are unrealistic does not by itself invalidate or validate either of the two arguments, and does not absolve one from answering the above question. In short: “unrealistic” is not the same as “absurd”.")

#text("2. If it is one of the islanders who makes the comment (thus breaking the taboo), it is as if that islander is now a stranger. If it is a blue-eyed islander (and if it is common knowledge that this islander is trustworthy), what would happen is that all the other blue-eyed islanders now commit suicide on the 99th day, while the original islander learns nothing about his or her own eye colour and does not commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e98110b0732d42932523211282a93d6b2a338396f7b3bd1b0194e95e07365c67-532888ede9295a5057b6d07af440e85b1db4626d3789d5291e67da4c5eae0c0c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26071")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("I really don’t get why anybody would kill themselves in this case!")

#text("Gives this bit of information:")#linebreak()#text(" “Of the 1000 islanders, it turns out that 100 of them have blue eyes and 900 of them have brown eyes, although the islanders are not initially aware of these statistics (each of them can of course only see 999 of the 1000 tribespeople).”")

#text("We have to believe that:")#linebreak()#text(" * all the blue eyed islanders believe there are either 99 or 100 blue eyed islanders.")#linebreak()#text(" * all the brown eyed islanders believe there are either 100 or 101 blue eyed islanders.")

#text("The visitors comment doesn’t come as a surprise to anyone as it is common knowledge that there are blue eyed people on the island.")

#text("“(and they all know that they all know that each other is highly logical and devout, and so forth).”")#linebreak()#text(" Given this information we can reason that everybody understands that none of the others know what eye color they have.")#linebreak()#text(" Since the total number of blue eyed islanders isn’t given to anybody but an outsider, the islanders will not react because none of the blue eyed islanders commit suicide as they know none of the blue eyed islanders would know that they are blue eyed.")

#text("The proof for argument number 2 goes like this:")#linebreak()#text(" “Proof: We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day.”")

#text("This makes sense as the one blue eyed person would not know of the existence of other another blue eyed person before it is mentioned by the visitor.")

#text("“Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: “If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island,”")

#text("Correct")

#text("“and so they will all commit suicide n-1 days after the traveler’s address”.”")

#text("This does not make sense to me. Each islanders knows that, like themselves, none of the other islanders know what eye color they have and therefore do not have any reason to kill themselves! The same argument is valid even though nobody has committed suicide after n-1 days! Everybody still knows that none of the other islanders know their eye color and all believe the travelers comment could just as well have been to any of the blue eyed islanders as to him/herself.")

#text("“But when n-1 days pass, none of the blue-eyed people do so (because at that stage they have no evidence that they themselves are blue-eyed). After nobody commits suicide on the day, each of the blue eyed people then realizes that they themselves must have blue eyes, and will then commit suicide on the day.”")#linebreak()#text(" To me this doesn’t make any more sense than the statement above. The fact that nobody commits suicide when the n-1 days have passed still doesn’t mean that you have blue eyes as each blue eyed islanders knows of n-1 other blue eyed islanders the comment could have been directed to.")

#text("Let us say that n-1 blue eyed islanders commit suicide after n-1 days. That would still not give the last blue eyed islander a reason to kill himself! He would still not know whether or not the comment was directed to him unless the visitor says it once more after all the other blue eyed islanders have killed themselves.")

#text("I am therefore in favor of argument number 1. Nothing happens.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e98110b0732d42932523211282a93d6b2a338396f7b3bd1b0194e95e07365c67-532888ede9295a5057b6d07af440e85b1db4626d3789d5291e67da4c5eae0c0c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26073")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("I shortened down my argument above to the essentials to make it quicker to read:")

#text("1) All islanders know that there are blue eyed islanders")#linebreak()#text(" 2) No islanders know if they have blue or brown eyes themselves")#linebreak()#text(" 3) All islanders know that all the other islanders know 1) and 2).")#linebreak()#text(" 4) All islanders understand that all the other islanders, including themselves, know the comment could have been directed to a) any of the blue eyed islanders they know about (1) or b) themselves (2), but has no reason to believe b) is either false or true as because of (1) and (2).")#linebreak()#text(" 5) No islander will have a reason to commit suicide because none of the other know blue eyed islanders commit suicide. Knowing (3) each islander has to conclude that all the other islanders will also have concluded with (4) and therefore not committed suicide.")

#text("Best regards")#linebreak()#text(" Sebastian")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26074")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Sebastian, try this formulation:")

#text("n=2. Each blue-eyed person says: “If I am not blue-eyed, then there is one blue-eyed person on the island, and he will kill himself tomorrow because of what the traveller just told us.”")

#text("“But then the next day comes and the other doesn’t kill himself! That must mean there are ")#emph[#text("two")]#text(" blue-eyed people, and I am the other one!”")

#text("n=3. Each blue-eyed person says: “If I am not blue-eyed, then there are two blue-eyed people on the island. They are each looking at each other and thinking (“If I am not blue-eyed, then there is one blue-eyed person on the island, and he will kill himself tomorrow because of what the traveller just told us.”). But neither will kill himself tomorrow, and they will realize their mistake tomorrow and kill themselves on the day after.”")

#text("“But then the third day comes and they don’t kill themselves! That must mean there are ")#emph[#text("three")]#text(" blue-eyed people, and I am the third!”")

#text("n=4. Do I really need to write this out in full?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26075")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Charles and Sebastian,")

#text("If there is only one blue-eyed person (BP) on the island, it’s obvious.")

#text("(**)")#linebreak()#text(" So say there are two BP. Then the reasoning will be as follows:")

#text("The day of the stranger’s address, each BP will expect the other BP to commit suicide the next day (that is, one day after the stranger’s address). The next day will come. Nobody will commmit suicide, so each BP will know he has blue-eyes. Therefore, according to the custom, they’ll both commit suicide the next day (that is, two days after the stranger’s address).")

#text("(***)")#linebreak()#text(" Say there are three BP. Then the reasoning will be as follows:")

#text("The day of the stranger’s address, each BP will look at the other two BP and think that if it there are only two BP on the island (the two he’s looking at), then they’ll follow the (**) argument above and two days after the stranger’s address, they’ll be dead. If they’re not dead after the two days, then I’ll know I’m a BP. However, EACH of the three BP is thinking this about the other two BP, so none of them will be dead after two days. Therefore, the next day (that is, three days after the stranger’s address), all three will know they’re BP and will kill themselves.")

#text("(****)")#linebreak()#text(" Say there are four BP. Then the reasoning will be as follows:")

#text("The day of the stranger’s address, each BP will look at the other three BP and think that if it there are only three BP on the island (the three he’s looking at), then they’ll follow the (***) argument above and three days after the stranger’s address, they’ll be dead. If they’re not dead after the three days, then I’ll know I’m a BP. However, EACH of the four BP is thinking this about the other three BP, so none of them will be dead after three days. Therefore, the next day (that is, four days after the stranger’s address), all four will know they’re BP and will kill themselves.")

#text("And so on for five BP, six BP, all the way up to a hundred BP. Therefore, on the 101st day after the stranger’s address, the 101 BP will all kill themselves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e98110b0732d42932523211282a93d6b2a338396f7b3bd1b0194e95e07365c67-532888ede9295a5057b6d07af440e85b1db4626d3789d5291e67da4c5eae0c0c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26104")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Alright, John and Saad, I get it now.")#linebreak()#text(" Thanks for the thorough explanation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26108")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Saad:")

#text("If there are four BP then:")#linebreak()#text(" – Everyone knows that there is at least 3 BP")#linebreak()#text(" (BP see 3 BP")#linebreak()#text(" Non BP see 4 BP)")#linebreak()#text(" – And everyone know that every one else knows that there is at least 2 BP")

#text("So everyone knows that nobody will commit suicide on a second day.")#linebreak()#text(" So this reasoning makes no sense at all for more than 3 people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f81f40eee2773f6c7600bf0073873d5088e8920716f9597230f1397a44406f8c-42fb23057476bb97e8d0dd0a37106b9968e634d0eeade387ae4f153f8dfede5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26110")[#strong[#text("Charles Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("I’m brown-eyed. I see 2 blue-eyed people. They don’t commit suicide. Why don’t I deduce I have blue eyes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guest")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26111")[#strong[#text("Guest")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Charles Robinson")

#text("The difference between blue-eyed people and brown-eyed is in number of blue eyes they see.")

#text("So brown eyed person would deduce he has blue eyes on the same day when all blue-eyed people commit suicide. But when they do commit suicide he knows he don’t have blue eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26114")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Charles,")

#text("Because the 2 blue-eyed people you see both commit suicide 2 days after the stranger’s address. As I said in my answer above, that confirms that there were only 2 blue-eyed people on the island. Remember, the pattern is that if there are N blue-eyed people, N days after the stranger’s address, they’ll all commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26115")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Or to put it another way:")

#text("When the suicide(s) happen, there are no more blue-eyed people left.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5284b9adc24f305e33b56cdcf2bc593f8b340de451c8a1de76650d8d0cb10c75-36d4ce87a9e522aa1351f0778f7ca1e2225b3621c3502271766cac09ee8ac773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Conlon")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26118")[#strong[#text("Peter Conlon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("If the religion forbids them to know their own eye colour, and they are all highly devout, why would they engage in logical games to discover their eye colour? A highly logical highly devout islander would surely realise the peril of engaging in that line of reasoning which might allow them to discover their eye colour and therefore reason alternately saying:")#linebreak()#text(" “Everybody can see people with blue eyes, so this stranger has told us nothing new.” and subsequently put the other way of reasoning out of mind.")

#text("Is it truly ‘illogical’ to reason in that way?")

#text("Peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5284b9adc24f305e33b56cdcf2bc593f8b340de451c8a1de76650d8d0cb10c75-36d4ce87a9e522aa1351f0778f7ca1e2225b3621c3502271766cac09ee8ac773.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Conlon")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26119")[#strong[#text("Peter Conlon")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("One more thing, I’m beginning to think the premises are complete nonsense.")#linebreak()#text(" eg:")#linebreak()#text(" All the tribespeople are highly logical and devout, and they all know that each other is also highly logical and devout (and they all know that they all know that each other is highly logical and devout, and so forth).")

#text("So they all know that they are identical to each other? Doesn’t this cause problems? Wouldn’t they all try to speak exactly at the same time during meetings?")#linebreak()#text(" If I knew that the others were identical to me, I could control their reasoning, just by reasoning in my own way, since the others necessarily think the same way. Should I be able to control the other’s thoughts like that? Something is beginning to sound paradoxical here…")

#text("Maybe they live their identical lives by rolling dice to decide a course of action so as to not cause problems like all going to the toilet at exactly the same time.")

#text("My problem is that the notion of individual choice is lost by imposing the common knowledge that everyone is logical in the premises of the question, the implication of “logical” being some sort of deterministic behaviour. What does a logical person do – are logical people rational and vice versa?")#linebreak()#text(" Peter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f81f40eee2773f6c7600bf0073873d5088e8920716f9597230f1397a44406f8c-42fb23057476bb97e8d0dd0a37106b9968e634d0eeade387ae4f153f8dfede5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26120")[#strong[#text("Charles Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Saad / Guest – All the stranger said was that he sees people with blue eyes. He didn’t say how many. There could be 1 or there could be 1000. If all I see are brown eyes I know I have blue eyes. But if I have brown eyes and I see the blue eyed person (or 2 or 10 or 900) I still don’t know that I have brown eyes.")

#text("I just don’t get that leap of logic that says “2 (or 10 or 900) people died, and I saw 2 people with blue eyes, that means I can’t have blue eyes”. Why not?")

#text("Anyway, once I think I know my own eye color I have to kill myself anyway, so at the end of this it’s Easter Island. :-p")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saad")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26125")[#strong[#text("Saad")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2008")])]

#text("Charles,")

#text("“I just don’t get that leap of logic that says “2 (or 10 or 900) people died, and I saw 2 people with blue eyes, that means I can’t have blue eyes”. Why not?”")

#text("Let’s say there are N BP on the island. Then each non-BP will be thinking that if I had blue eyes too, then the N BP I’m seeing would not commit suicide on day N. But when he does see the N BP commit suicide on day N, he’ll know he’s not a BP. Walk through the explanation I posted above to see why N BP will commit suicide on day N.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7aeb54646bc9a8f4e8465e55cbf9fdcd7f7522303c8336200910d9cacbb7b6b3-80c7f35590f93fa2ac639781105edd3f920b9cf091a7981b9ec2c7813d1a3a29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris In A Strange Land")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26152")[#strong[#text("Chris In A Strange Land")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#emph[#text("The second argument is flawed. The people will never know if there are 101, 100, 99 blue eye people in the tribe, as they wouldn’t know there own eye colour.")]

#text("I agree. Plus, there’s no new information here. The foreigner merely acknowledges that there are people of blue eye colour on the island, and this is a fact previously established by the islanders through observation.")

#text("On the other hand, if each of the tribesmen were dumb enough to hold a census of eye colours and compare results, they will be able to determine the colour of their own. All it will require is for two persons of opposite colour to compare notes, the one with the lower count is blue. Since we know that everyone on the island is both logical and honourable, this will under no circumstances happen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f81f40eee2773f6c7600bf0073873d5088e8920716f9597230f1397a44406f8c-42fb23057476bb97e8d0dd0a37106b9968e634d0eeade387ae4f153f8dfede5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charles Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26160")[#strong[#text("Charles Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("Saad – I went through that, and I just don’t get it. Maybe I’m dense. Let’s assume 2 blue eyed people actually exists.")

#text("Day 0 – Stranger says “some of you have blue eyes”.")

#text("Day 1 – No one commits suicide. I see two blue eyed people, but they aren’t committing suicide. They must each see at least one other blue-eyed person.")

#text("Now we get to the part that’s hinged on assumption and supposition. Do I presume I *don’t* have blue eyes and wait to see if others commit suicide? Or do I err on the side of religious zealotry and assume I *do* have blue eyes? Depending on whether religion or logic win we either end up in the scenario you describe, or it’s mass suicide. Assume the religion wins out…")

#text("Day 2 – We all line up and do the deed at the same time.")

#text("It doesn’t say “villagers will review the suicide queue, count the people, and use that to deduce their eye color.” Once they decide what it is they must do the deed. Therefore if nobody commits suicide on Day 1 then everyone would commit suicide on Day 2. They can’t deduce they don’t have blue eyes until after the suicides are done. If they’re supposed to all commit suicide at noon, they would all line up at the same time and do it. It all depends on whether logic or religion winds out. Based on how zealots behave, I’m betting on the latter.")

#text("Anyway, even if there was some sort of mythical perfect logic that would override the religious fanaticism, everyone would have to commit suicide. Either they would deduce they have blue eyes or they would deduce they have brown eyes. Whether that’s Day 2 or Day 102 is irrelevant, they’re all still dead.")

#text("This isn’t a logic puzzle, it’s genocide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26187")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2008")])]

#text("One way to think about it is that the foreigner’s comment, plus induction, plus the passing days creates new information.")

#text("Before the foreigner comes, every blue eyed person knows that there are at least 99 blue eyed people (since they can see them) and there may be 100 (if they themselves on blue-eyed). Likewise, every brown eyed person knows that there are at least 100 blue eyed people and maybe 101.")

#text("Since these are logical people, they would come up with and follow the inductive reasoning behind the second argument. At the end of the first day, since no one kills themselves, all the people would know that there are at least 2 blue eyed people on the island. By the end of the 99th day, since no one has killed themselves, the blue eyed people would all know that there are 100 blue eyed people and, seeing only 99 others, would know that they have blue eyes and commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-4/#comment-26208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2008")])]

#text("hmm, where is the solution?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("since its legitimacy is fundamental for the induction’s validity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25744")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I think the induction does not assume anything on the legitimacy of “Common knowledge”. “Common knowledge” itself is just a way of interpreting why the induction is working.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bc8e2b7ddd65727453ca3b344f4c1f6692701681ab8e8becb0bda5008bb5eff-4a509057b72e6158034237bf7b359d583c4c3243635c380fbf6ccc19d11cf331.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SJH")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25745")[#strong[#text("SJH")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I did not read all the comments thoroughly, and since I am not mathematician, I know almost nothing about mathematical logics…")

#text("But from what I understand from the induction technique on natural numbers is that given n greater than the base (here 1), then you can roll back the reasoning to the base case and everything is now true.")

#text("What I am concerned is that, in this case, every islander knows that it is ‘common knowledge’ that everyone else knows there are at least n-2 = 98 people with blue eyes. If you are blue-eyed, then you see 99 other blue-eyed people, so you know that all other blue-eyed people know that there are at least 98 blue-eyed people. If you are brown-eyed this number increases by one.")

#text("Then for me, it seems it does not matter what happens when n = 1. You are always 100% sure that everyone in this island knows this is never the case. So my opinion is that n=1 cannot serve as a base case.")

#text("I think the tricky part is that the induction hypothesis includes an assumption: “suppose there are n blue-eyed people”. This may kick out some natural number n in the problem domain.")

#text("For example, suppose you try to prove by induction with n starting from 0. Then you cannot get the same result, and this is why without this evil foreigner no one will commit suicide. What this evil foreigner brings is the common knowledge that n = 0 should be ruled out.")

#text("But if there are 100 blue-eyed people in the island, there is stronger common knowledge that n < 98 should be ruled out. So the base case should start from 98.")

#text("Well, this is an engineer’s opinion. I also really want to hear prof. Tao’s answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bc8e2b7ddd65727453ca3b344f4c1f6692701681ab8e8becb0bda5008bb5eff-4a509057b72e6158034237bf7b359d583c4c3243635c380fbf6ccc19d11cf331.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SJH")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25746")[#strong[#text("SJH")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Uh, I think I have to correct one thing.")

#text("—————————————————–")#linebreak()#text(" For example, suppose you try to prove by induction with n starting from 0. Then you cannot get the same result,")#linebreak()#text(" —————————————————–")

#text("I should have added they do not have common knowledge n > 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25747")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I haven’t gotten around to thinking carefully about this, but I’m suspicious of Matt’s “And so on.” When ")#mi("n \\geq 3")#text(", everybody already knows that there is at least one blue-eyed person, and furthermore everybody already knows that everybody already knows this. So it’s less clear that the traveler gives any new information in that case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25750")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Hi Terence,")

#text("Alas, the University of Copenhagen may have genetic information about blue eyes in ")#link("http://www.ku.dk/english/news/?content=http://www.ku.dk/english/news/blue-eyes.htm")[#text(" ‘Blue-eyed humans have a single, common ancestor’")]#text(" with a “genetic mutation affecting the OCA2 gene” that may be problematic for this version of the puzzle.")#linebreak()#text(" How did the 100 blue eyes get to the island?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25751")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Mark, in this case they can recurse down to 1, but they can’t tell the difference between 0 and 1, and so they still don’t know whether there are ")#mi("n")#text(" or ")#mi("n+1")#text(" blue-eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25752")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Just reason without math:")

#text("1 blue eyed: obvious, he dies the next day after hearing the foreigner.")

#text("2 blue eyeds: When the above doesn’t happen the next day, each realizes he himself is blue eyed, dies the following day.")

#text("3 blue eyeds: When the above doesn’t happen, each realizes he himself is blue eyed, dies the following day.")

#text("etc.")

#text("100 blue eyeds: each seeing 99 blue eyeds don’t die 99 days after the foreigner’s comment, realizes that he himself is blue eyed, dies the following day.")

#text("I understand this PERFECTLY. My only problem is that, can we really reason that way?? We can not see the property of a triangle by viewing it as a sequence of its three sides coming together one by one (induction). We can only see it as a whole when all three sides are together. n = 100, this is all we have. I feel that something went wrong during the mathematicalization of this physical problem.")

#text("I am still awaiting enlightenment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25754")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I would rather say that this is a physical model of a mathematical concept.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25757")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("t8m8r,")

#text("True, it is intended that way. But what if the physical situation is already given and demands a solution? We can’t refuse it by saying that it doesn’t fit into a good mathematical model, can we? Can we deny the reality of the feet since we don’t have fitting shoes for them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25758")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("t8m8r,")

#text("Actualy… you may be right. The system described by the mathematical concept is extra-ordinarily unstable (when n is very large). Perhaps it is for this reason, any physical model we make up to demonstrate it must be im-practical. Thanks for pointing this out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25761")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Jian,")

#text("Of course we do not deny the reality of the feet since we don’t have fitting shoes for them. Indeed we actually may have a lot of shoes and a lot of good shoemakers but as I understand what we are doing here is just that we are talking about one particular pair of shoes and some imaginary feet that perfectly fit for them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25787")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("John,")

#text("I should have been clearer about what’s unclear to me. I do see that the recursion happens, but I don’t see what new information the traveler has added when ")#mi("n \\geq 3")#text(". Essentially, I follow and believe the proof, but my intuition is unsatisfied.")

#text("I suppose this is where understanding “common knowledge” comes in. I haven’t read the wikipedia page, but this seems to indicate that common knowledge is more than just “something that everyone knows, and everyone knows that everyone else knows it”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25789")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("No, no.. there’s nothing different about ")#mi("n\\geq3")#text(". That was my mistake for going along with it.")

#text("Okay, to try again…")

#text("1 blue-eyed: see 0 blue-eyed, but there could be 0 or 1 blue-eyed.")#linebreak()#text(" 2 blue-eyed: see 1 blue-eyed, but there could be 1 or 2 blue-eyed.")#linebreak()#text(" …")#linebreak()#text(" ")#mi("n")#text(" blue-eyed: see ")#mi("n-1")#text(" blue-eyed, but there could be ")#mi("n-1")#text(" or ")#mi("n")#text(" blue-eyed.")

#text("Now what happens when the traveller comes is we remove the possibility of zero.")

#text("1 blue-eyed: see 0 blue-eyed, but there must be 1 (himself).")

#text("2 blue-eyed: see 1 blue-eyed, but there could be 1 or 2 blue-eyed.")#linebreak()#text(" If 1 then we’re in the previous case, and he’ll kill himself tomorrow.")#linebreak()#text(" nbsp;If he doesn’t kill himself, must be 2 (including the observer)")

#text("3 blue-eyed: see 2 blue-eyed, but there could be 2 or 3 blue-eyed.")#linebreak()#text(" If 2 then we’re in the previous case, and they’ll kill themselves in 2 days.")#linebreak()#text(" nbsp;If they doesn’t kill themselves, must be 3 (including the observer).")

#text("…")

#mi("n")#text(" blue-eyed: see ")#mi("n-1")#text(" blue-eyed, but there could be ")#mi("n-1")#text(" or ")#mi("n")#text(" blue-eyed.")#linebreak()#text(" If ")#mi("n-1")#text(" then we’re in the previous case, and they’ll kill themselves in ")#mi("n-1")#text(" days.")#linebreak()#text(" nbsp;If they doesn’t kill themselves, must be ")#mi("n")#text(" (including the observer).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("mark,")

#text("when n=3, everyone knows there is at least one blue-eyed, and everyone knows that everyone knows it; however, any blue-eyed person does not know (or cannot logically deduce) that “everyone knows that everyone knows it”. by seeing the other 2 blue-eyed, he could only deduce the first two layers, but not any further. similarly for n>3… (see comment by Peter on 5 February, 2008 at 2:28 pm)")#linebreak()#text(" on the contrary, the stranger makes all the layers explicit to everyone")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/604d0c2f405084d3860687162faf8c93538bbc45c5ade86a1ac7160ba63caced-f8fb5087f6dcd67a5d2a0c1f965f6cd0faafa559a0613d0c9f896cf69d8e6da5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carson Chow")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25791")[#strong[#text("Carson Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("It is a rather sad story because on the 101st day, everyone else must then commit suicide since they all know that whomever is left must have brown eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/604d0c2f405084d3860687162faf8c93538bbc45c5ade86a1ac7160ba63caced-f8fb5087f6dcd67a5d2a0c1f965f6cd0faafa559a0613d0c9f896cf69d8e6da5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carson Chow")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25792")[#strong[#text("Carson Chow")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("Oops, my previous statement would only be correct if they all had the common knowledge that eyes were either brown or blue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25795")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("Anonymous,")

#text("Thanks, that was the (rather obvious) point my intuition was missing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f7946f9ae888012c14e790fd0140ae8ccfe256f8a4dc7b5a9d51e0200c8c83-9c4ba5b6f9bcebb67c07e29f9252696b1e5d4ffe6cd502a005228c0eee83e099.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Hartley")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25796")[#strong[#text("Ralph Hartley")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("I think the problem is in the interpretation of the sentence:")

#text("All the tribespeople are highly logical and highly devout, and they all know that each other is also highly logical and highly devout.")

#text("In order for the induction to work, it must be taken to mean that all tribespeople will always reach every conclusion it is possible to reach from the information available. Without that, on day n the n blue eyed people will not be able to conclude that they have blue eyes, because the n-1 blue eyed people might have failed to come to the conclusion that they have blue eyes, even if they could.")

#text("But is that interpretation even logically possible? If not, of course assuming it can lead to contradictions. Even if it is logically possible, it would make the tribespeople so different from human beings that one would expect all sorts of bizarre behavior.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25799")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("Hi Terence,")

#text("Your reference to wiki ‘common knowledge’ [4 February, 2008 at 7:35 am] has reference to Robert Aumann, Nobel 2005 Economics with Thomas Schelling. This suggests a mathematical game theory approach with incomplete information using John Harsanyi [Nobel 1994 Economics with Reinhard Selten and John Nash] techniques. Triple concepts of agents, strategies and utilities are likely important.")

#text("Your wiki reference also has Kripke structures as an alternative approach.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("Wow, this has certainly been a livelier discussion than I had anticipated. I certainly can’t hope to respond to all the points made, but here are just a few comments (which are already mostly contained in the above discussion):")

#text("Firstly, the situation is indeed very artificial and unstable (and also somewhat violent), but, as the volume of response already proves, it is rather thought-provoking nevertheless, and illustrates the concept of common knowledge better than any other explanation I know of.")

#text("As several commenters have pointed out, the resolution of the puzzle depends very much on the precise assumptions in the puzzle, and in particular what is common knowledge and what isn’t. If it is common knowledge that the foreigner is completely trusted, and if it is also common knowledge that all villagers are rational and devout, then there will indeed be a mass suicide of the blue-eyed villagers on the 100th day. If, furthermore, it is common knowledge that the only eye colours on the island are blue or brown, then there will be a mass suicide of the brown-eyed villagers on the 101th day. But if these facts are only known to first or second order, then nothing will happen. (In particular, as pointed out, the phrasing of the problem only assumes devoutness to second order, and so one cannot conclude that the suicides will happen.)")

#text("In the absence of the foreigner, nothing happens (unless some other non-trivial common knowledge about eye colour statistics is somehow acquired, of course).")

#text("It is probably the n=3 case (three blue-eyed people) which causes the first major conceptual difficulty, in which common knowledge separates from both first-order and second-order knowledge. As pointed out above, in this case the three blue-eyed people all know that there is at least one blue-eyed person, and they know that everyone else knows this also… but they don’t know that everyone else knows that everyone else knows this, until the foreigner speaks. The remarkable thing about the puzzle, to me, is how such a subtle and seemingly academic change in the knowledge environment eventually propagates to have a concrete and dramatic effect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonas S Karlsson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-41411")[#strong[#text("Jonas S Karlsson")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2009")])]

#text("So I was right!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d818093fd069493d2c92d1a31a5ffc58b8bd4b07a6f49ea2b41879a17df786-db7ea168cc5924b05e767c7d5498103df17fd7a8b555fc66880e3c1e6553dab4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of micca")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25803")[#strong[#text("micca")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("I have some strong feelings against Argument 2. Going like this..")

#text("P_k, k<99 ain’t possible for this island. And to use induction, P_k needs to be possible for the object thats the P_k say something about.")

#text("If we say thats on some other island (hypothetical or whatever) with 3 blue eyed islander something happens.. it does not mean anything for this island with all least 99 blue eyed islanders, as seen from one islander (not counting the visitor).")

#text("It is not contingent.")

#text("And no common knowledge is added in this case, as Argument 1 states. Everybody already knows that everybody knows that it is 99 or 100 blue eyed islanders.")

#text("This is driving me crazy.. Are the any pills for this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("Dear micca,")

#text("The statement “P_k (i.e. that there are k people with blue eyes) is not true for any k < 99” is true, and known to every islander… but it is not common knowledge. For instance, each islander can see that P_98 is false, and knows that everyone else knows P_98 is false, but doesn’t know that everyone else knows that everyone else knows that P_98 is false.")

#text("The basic thing that one has to get one’s head around is that just because everybody knows a fact P, and that everybody knows that everybody else knows P, does not make P common knowledge! Equivalently, one may know that an assertion S cannot be true (it is not contingent, in your language), and that everyone else knows that S cannot be true, and yet the falsity of S need not be common knowledge, because one may still entertain the scenario that someone else might still allow for the possibility that a third person could believe S to be possibly true. (Yes, it is true that everybody knows that everybody else knows S to be false… but each islander does not necessarily know that truth to be the case! One has to distinguish truth from knowledge at every level.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25809")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2008")])]

#text("I think I can finally accept the induction but only with a fellow commentator’s enlightenment that it is only a physical model (an exteremely unstable system) for a math concept (Thus the reverse to physics). Isn’t modern economics such a mathematical conception and people of reality are expected to fit themselves into this conception. It is little wander that modern people are wealthy but so unhappy. It is like fitting natural feet into pre-made shoes. Of course, this is a little off topic…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d818093fd069493d2c92d1a31a5ffc58b8bd4b07a6f49ea2b41879a17df786-db7ea168cc5924b05e767c7d5498103df17fd7a8b555fc66880e3c1e6553dab4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of micca")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25829")[#strong[#text("micca")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Thanks Tao 8)")

#text("The ever exceeding tower of truths about knowledges has to be flatted to be common knowledge. The function of the visitor.")

#text("Now I can reason about other Islanders believes.")

#text("Great puzzle 8)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sune Kristian Jakobsen")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25831")[#strong[#text("Sune Kristian Jakobsen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Roberta:")#linebreak()#text(" “I’m thinking about that… the foreigner have a wife and he writes in the letter “how unusual it is to see another blue-eyed person like myself in this region of the world and another red-eyed such my wife”.")#linebreak()#text(" and the tribe consists of 1100, 100 blue-eyed, 100 red-eyed and 900 brown-eyed”")

#text("If everyone has exactly one eye color and that is common knowledge, the two eye colors doesn’t “interfere”, so if the tribe is told that there is both blue-eyed and red-eyed on the island, both the blue-eyed and the red-eyed will commit suicide after 100 days. Generally: if there are a A-eyed, b B-eyed,…, and z Z-eyed, and it suddenly becomes common knowledge that there is A-eyed, B-eyed, …, and Z-eye people on the island, the A-eyed will commit suicide after a days, the B-eyed after b days and so on.")

#text("However, if everyone knows that these eye colors are the only eye colors on the island, and a=Max(a,b,…z), the A-eyed will commit suicide after Min(a, Max(b,…,z)+1) days. So if the tribe knows, that there are no other eye colors than blue, red and brown on the island, the brown-eyed will commit suicide after 101 days.")

#text("John Armstrong:")#linebreak()#text(" “What no solution I’ve seen yet mentions is that the next day, all the other villagers would follow suit, since they would know that anyone with blue eyes would have killed himself the previous day, and so they must have brown eyes.”")#linebreak()#text(" (assuming that everyone knows that brown and blue are the only eye colors on the island)")

#text("It is even more tragic: When the foreigner says that there is a blue-eyed on the island, all the tribe members know which day they have to commit suicide: If a tribesperson sees n blue-eyed and m brown-eyed, he will have to commit suicide after Min(n,m)+1 days, no matter his own eye color. (Assuming no one sacrifice himself by talking about eye colors.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa4604b06e8a2346f6c9d0d4b356fecae946f304f9316ad6431f0adffb4da833-6e683ff3261e22826f36286c315fa16b9dfe793cd49a85bf4cd198643aeb7683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25845")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("This was always a great puzzle. The key to understanding it, as a few have pointed out, is to understand that the puzzle assumes a logical foundation not found in the real world. It’s a model for firm mathematical reasoning and as such operates under a very strict set of rules. A bunch of real world people like you and I on an island would not kill ourselves, but these robot-like entities would, because they’re following strict logical rules as defined by the field of formal logic and the specifications of the problem.")

#text("Under such a formal system, the inductive reasoning is sound, and the basis case of n == 1 is ABSOLUTELY REQUIRED. Mathematical induction is nothing without both a proper basis and inductive rule. And remember folks, this is a math/logic problem, not a reflection of any real world behavior.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa4604b06e8a2346f6c9d0d4b356fecae946f304f9316ad6431f0adffb4da833-6e683ff3261e22826f36286c315fa16b9dfe793cd49a85bf4cd198643aeb7683.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25846")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Also worth noting, based on a few of the comments I’ve seen, that in most version of this problem, the islanders do NOT know how many different eye colors there are. They see two colors, but their own eye color could be red or green or blue or black or clear. They simply don’t know. This is sufficient to prevent any kind of mass suicide of the whole island. Unfortunately, the problem as stated in this blog is mum on that point, and so the problem is ill specified. As such, one simply can’t know what will happen to the brown eyed folks, as we don’t know if they know that there are only two eye colors. The only reasoning we can apply is induction on the blue eyed population.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b68341bec58acd74a11456c1297d66ece589f6be7e980ffe674829a1368928f-b808a0e8f6b647fc146a784f82010a4c7974fbf2951373d69ce7731bf8b3f887.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwenhwyfaer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25847")[#strong[#text("gwenhwyfaer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("The induction breaks at the point where the foreigner names the number of blue-eyed people on the island.")

#text("If, in this case, he says “how nice to see another blue-eyed person”, then if that blue-eyed person cannot see anyone else with blue eyes, he must commit suicide. However, if there are two blue-eyed people, all they have been told is that there is *another* blue-eyed person on the island… which they already knew, because they can see them. (Everyone with brown eyes can see two blue-eyed people, but cannot tell them so.) So nothing changes.")

#text("Had he said “a hundred blue-eyed people”, then whilst everyone would could see 100 blue-eyed people could breathe a sigh of relief, everyone who could see only 99 blue-eyed people would pretty much have to kill themselves at the earliest possible opportunity. (The remainder of the islanders would have to die the day after, of course – because if everyone around you has one of only two eye colours, including your immediate family, it is illogical to hope you were some kind of genetic throwback with a unique eye colour! Add the possibility of green eyes, though, and the rest of the islanders could survive.)")

#text("And of course, if he had slipped up and said “101 blue-eyed people”, every *brown*-eyed person would have had to kill themselves the next day, because they could only see 100 blue-eyed people; whilst the blue-eyed people would have been highly amused at the silly foreigner until the next lunchtime, when the horrible truth dawned on them that they now knew they all had blue eyes…")

#text("BUT if he’d said “102 blue-eyed people”, an entire island would have been chortling merrily about silly foreigners who had no manners and couldn’t count.")

#text("C’est la vie. Let’s hope they never invent mirrors, or drink from streams.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97b65edb583e3d5e21fa9fa5f1a1606f347e1d7147aa8c3a35fb8834ba18cea4-5ebe4ccd7b2a903c249a845790086a27dfa759912be389a9ba8a87c39c97a494.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ezequielpozzo")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25848")[#strong[#text("ezequielpozzo")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("I think the problem is that you add an implicit rule that I don’t see why should be even considered:")

#text("“All blue eyed should commit suicide after n days, with n being the number of blue eyed people”")

#text("If you introduce that rule all blue eyed commit suicide eventually, without the need for a foreigner. Your proof proves that.")

#text("But I would say such rule doesn’t exist. So nobody is expecting that kind of “implicit counting” to happen, and the foreigner shouldn’t change that.")

#text("Think about a village with and without that rule:")

#text("Without:")#linebreak()#text(" They aren’t expecting n-1 people to kill after n-1 days. So they don’t kill themselves at day n.")

#text("With:")#linebreak()#text(" The countdown starts, all blue eyed expect the rest to kill themselves at the day n-1, and since that doesn’t happen they all kill themselves the next day.")

#text("But this rule isn’t even mentioned in the problem, and the foreigner doesn’t change that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b68341bec58acd74a11456c1297d66ece589f6be7e980ffe674829a1368928f-b808a0e8f6b647fc146a784f82010a4c7974fbf2951373d69ce7731bf8b3f887.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwenhwyfaer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25849")[#strong[#text("gwenhwyfaer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Mneh. I was right, but for the wrong reason.")

#text("My initial conclusion neglected nth-order effects, of course, as is obvious to anyone. However, as several other people have written, if we allow for nth-order effects, the islanders would have had to kill themselves spontaneously – specifically speaking, each islander would have had to kill themselves M+1 days after the two conditions (all islanders know the rule; M people with eye colour X still alive after M days) are met.")

#text("Clearly they haven’t – which either means they’re already on a countdown, or we can discount nth-order effects altogether. Either way, the foreigner’s faux pas adds no existing knowledge, and therefore has no effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b68341bec58acd74a11456c1297d66ece589f6be7e980ffe674829a1368928f-b808a0e8f6b647fc146a784f82010a4c7974fbf2951373d69ce7731bf8b3f887.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwenhwyfaer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25850")[#strong[#text("gwenhwyfaer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("(typos: all islanders know -> he/she becomes aware that all islanders know; adds no existing knowledge -> adds nothing to existing knowledge)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippa")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25851")[#strong[#text("Philippa")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("“All the tribespeople are highly logical and highly devout, and they all know that each other is also highly logical and highly devout.”")

#text("Which means they only have first-order knowledge of each others’ reasoning abilities. Nobody is certain that everyone else knows they’re highly logical and highly devout, so the inductive case is broken.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25852")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("I think the devout part should be considered a common knowledge due to nature of religion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a501d50de0ee45b628acb68db923cd3462af89bfdd0d89f79e259861070e0be-b986ecc6a40b180f312a4bf8914a6191220f7ed4bfcf7c0668efebc87b7f1549.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of part b")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25853")[#strong[#text("part b")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Part b of this puzzle: The visitor waits until 12:01 the next day, then announces he was only kidding. What effect, if any, will this have on the visitor’s life? :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b68341bec58acd74a11456c1297d66ece589f6be7e980ffe674829a1368928f-b808a0e8f6b647fc146a784f82010a4c7974fbf2951373d69ce7731bf8b3f887.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gwenhwyfaer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25854")[#strong[#text("gwenhwyfaer")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Jian: it doesn’t matter. All that matters is that the faux pas of the foreigner does not add anything to the knowledge the islanders already have.")

#text("(As an irrelevant aside, religious devotion is not generally held to be a logical trait…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bayareaguy")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25858")[#strong[#text("bayareaguy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Sunglasses.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25859")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("An informal game theory approach:")

#text("Triple concepts of agents, strategies and utilities are likely important.")

#text("Agents: Besides the foreigner, there are 1000 agents = 100 blue + 900 brown of 1 tribe in the original problem.")#linebreak()#text(" This is relatively equivalent [or reducible?] to:")#linebreak()#text(" 100 clans [or cycles], each of 1 blue + 9 brown in proportion to the original problem.")

#text("Strategies: there are two for each agent;")#linebreak()#text(" 1) “I have brown eyes.”")#linebreak()#text(" 2) “I have blue eyes.”")

#text("Utilities: there are two outcomes or payoffs;")#linebreak()#text(" 1) life")#linebreak()#text(" 2) death.")

#text("Using a bifurcation tree model:")#linebreak()#text(" 10 agents –> 9 brown: strategy 1 with utility 1")#linebreak()#text(" |")#linebreak()#text(" \\/")#linebreak()#text(" 1 blue –> strategy 1 with utility 1 results 0 blue loss")#linebreak()#text(" |")#linebreak()#text(" \\/")#linebreak()#text(" strategy 2 with utility 2 results 1 blue loss next day")

#text("Since there were 100 cycles, if all blues select strategy 2 with utility 2 then 100 blue losses after 100(*1)+1 days; if all blues select strategy 1 with utility 1 then no blue losses 100(*0).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37b210256a276d70cb2a691f6b637a81c106e68cb10376cc2288616355b56c71-1fef9ff716f5118b67e23cf15b39333c374ffb446320bb78c6679fcedc640e79.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dataangel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25860")[#strong[#text("dataangel")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Hrm… I simply don’t follow the reasoning in the induction. Peeling it apart:")

#text("“Proof: We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her, and thus commits suicide on the next day.”")

#text("Why do they realize? If none of them are told their eye color from birth, and the speaker has only indicated that some member of the tribe has blue eyes, no individual in the tribe has a way of knowing whom it is, unless the speaker deliberately points them out. If N were the total number of members of the tribe and not the total number of blue eyed people, this would make sense, but as is it doesn’t.")

#text("“Now suppose inductively that n is larger than 1. Each blue-eyed person will reason as follows: ‘If I am not blue-eyed, then there will only be n-1 blue-eyed people on this island”")

#text("Why would they reason that? It’s as if you’re saying: 1. N people have blue eyes. 2. I don’t have blue eyes. 3. There must be N-1 people with blue eyes. This doesn’t make any logical sense. Are you sure you’re not confusing N being people with blue eyes versus total tribe members?")

#text("“, and so they will all commit suicide n-1 days after the traveler’s address’.”")

#text("This seems pulled out of a hat. If we take the rule of the culture/religion seriously, they have to kill themselves the day after they find out. Why would they wait for N-1 days? Or any number of days? Unless for some reason they didn’t know until that time — but whether or not they realize something yet only comes below…")

#text("… I can’t even get any farther through it. Am I seriously missing something or is the problem’s wording just totally mangled?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25868")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("The induction of commenting has been set off, and will never stop…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54017b3f985336d0563829af48592decc414986610d77abf8b72334f90a3d511-a830340fdc02fc1671dcac45795cac8faf3d8b78ab9696674229f1fbacf9561e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danno")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25872")[#strong[#text("Danno")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("The basis is incorrect.")

#text("“Proof: We induct on n. When n=1, the single blue-eyed person realizes that the traveler is referring to him or her”")

#text("When n = 2, the two blue-eyed people think that the traveler is referring to the other blue eyed person.")

#text("Only in the situation that there is one blue eyed person does any state change occur, otherwise, no new information is being given to the islanders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25874")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Apparently the general solution to this puzzle has caused quite a bit of confusion (including myself). To help readers better understand the solution, I think it helps to view the situation from the perspective of a blue-eyed islander rather than as a third-party observer.")

#text("Let’s use the letter k to represent the number of blue-eyed islanders, of which you will be one of. In the argument “I” is used so that you may read this aloud to yourself as if it were your own dilema.")

#text("If k is 1, then I cannot see any blue-eyed people on the island. This was fine until the visitor told us that they exist. But now, knowing that they do exist and not being able to see any, I can only conclude that it must be me! Thus, I must die one day from now.")

#text("If k is 2, then I can see only one other blue-eyed person, Joe. I know that Joe is as logical as I am so by the reasoning when k is 1, he’s going to have to kill himself. I check on him tomorrow and see that he hasn’t, but how can that be? The only logical conclusion is that the above reasoning did not apply for Joe because when he looked around he must have seen someone else with blue eyes. But I don’t see such a person so it means that it must be me! Thus the following day (two days after the information)I must die. But since Joe is as logical as I am and has been faced with the same situation, he must also have discovered, exactly as I did, that he has blue eyes. Thus he will kill himself at the same time as I do.")

#text("If k is 3, then I can see see two blue-eyed people, Joe and Ted. Now, here is where you see the argument continue to depend on the earlier cases (this is what is meant by induction). If Joe and Mike are truly the only two people on the island, then based on the exact same reasoning when k is 2, they will both be dead after two days exactly. However, after two days I see that both are still living. Again, the only logical conlusion is that when Joe and Ted looked around they must have seen someone other than each other with blue eyes. Since I can’t see such a person it means that it must be me! Thus I must kill myself the next day (now three days after the information). But, since Joe and Ted are equally logical, also have blue eyes, and have been part of the same situation, they must have learned exactly as I did that they too have blue eyes. They will join me at the suicide ritual on the same day.")

#text("At this point you can see the repetitive nature of the argument. For each higher value of k the argument is quickly formed in terms of our previous argument for k-1. The induction proof is merely a concise formation of this which (correctly) reasons in terms of a general value of k. The visitor’s information is essential because it sets up the “base case” where k is 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d01f9b66e93d091c84d263bc4181138c36bfde0a2bf2871bda55d8fd67593eb-0c4590562138a53e28a1a10e9da8e5fb8cab28bfdbe112f29407c1cab7ec212a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25875")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Phillip, I think you are over complicating things with your mathematical inuendo. It’s not impressing me. Other people might be blown away with it and think, “he must be right.”")

#text("So let’s say you have 2 blue eyed people, then how after 2 days would they kill themselves? If you had 3? Why would they kill themselves after 3 days.")

#text("Let me put myself in the shoes of a blue eyed person. I don’t know my eye color, but I see 2 people with blue eyes. How do I know I have blue eyes. He didn’t give a number. I am not going to tell those 2 their eye color and no one is going to tell me mine. So why would I just kill myself without knowing?")

#text("Now, let’s assume I am a brown eyed person. I see 3 people with blue eyes. After 3 days… would I kill myself? Do I have blue eyes too? see, that is the unknown and the visitor gives no indication as to the number of blue eyed people. Common knowledge says that what the visitor claimed is what people already knew. So therefore, argument 1 is correct because he didn’t tell the people anything knew. Also, since he is not of their religion, he doesn’t have to kill himself. Worse case scenario would be that the villagers expect him to commit suicide but if he is not part of their religion, then there should be no effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/625f9e6dd425a6e726b12fdb3ed9db8482ec78c6f25d2926d6ea63c8c801460a-ad343f0b1eac95b36680a2dada68bd5a26411ba81968ffdbc732eea2e898ed31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cstb")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25877")[#strong[#text("cstb")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#strong[#text("Argument 3.")]#text(" Let i,j be two whole numbers chosen at random s.t. 0 <= i < j <= 1001. Within ")#strong[#emph[#text("i")]]#text(" days after the visitor’s speech, ")#strong[#emph[#text("j")]]#text(" islanders will have succumbed. ")#strong[#text("Proof")]#text(": (by example)See the previous comments.")#strong[#emph[#text("Q.E.D>")]]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc4d03ea8fc44ce98c4b2e58932fd667437dd1e4b78a6bd00adb17ccf578f585-3d41207f73e32c16ae310be20f84937d8d6147c645604e1426085f12ab48a65a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of steve")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25878")[#strong[#text("steve")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Hi from Adelaide, Terry. You’re quite well known back in your hometown!")

#text("There are two faults with the puzzle.")

#text("1) It tells you, but assumes that the islanders know, the exact numbers of people with eye colours.")

#text("2) The statement was clearly “how unusual it is to see another blue-eyed person like myself in this region of the world”, but Argument 2 is based on the assumption that at least 1 person (to start induction) worked out their own eye colour from that statement.")

#text("The puzzle would have been more interesting if it didn’t have these various interpretations, but then perhaps there wouldn’t be as much discussion and interest due to the lack of ambiguity!")

#text("I personally believe there would be an argument 3) based on the exact wording of the puzzle… which is that 100 days after the speech, nobody has committed suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcc35c6f08ee1ab8a5a21d7a60f6b90c26802188bfd29badf1ca9e43e9aa87a3-6527b6e8b7bd217a1a84f2f6e4a18695b2a4b4b65da59961e3cc96d35aea3707.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonimouse")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25879")[#strong[#text("anonimouse")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Tom is right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venkat")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25880")[#strong[#text("Venkat")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("The following argument works for me.")

#text("Case 1: There is only one blue eyed person (A).")#linebreak()#text(" Day 1: A thinks there are 0 or 1 blue-eyed persons. Foreigner says atleast")#linebreak()#text(" 1. So he immediately deduces it must be himself.")

#text("Case 2: Two blue eyed (A,B)")#linebreak()#text(" Day 1: A thinks B thinks there must be 0/1/2 blue-eyed. Foreigner speaks.")#linebreak()#text(" Day 2: 0/1 case covered by Case 1. So it must be 2, A sees that B is one")#linebreak()#text(" blue-eyed and the other one must be himself.")

#text("Case 3: Three blue eyed (A,B,C)")#linebreak()#text(" Day 1: A thinks B thinks C thinks there must be 0/1/2/3 blue-eyed. Foreigner speaks.")#linebreak()#text(" Day 2: 0/1 case covered by Case 1. Remaining 2/3.")#linebreak()#text(" Day 3: 2 covered by Case 2. So there must be 3 blue-eyed. A sees two")#linebreak()#text(" other blue eyed. So the other one must be himself.")

#text("And so on.")#linebreak()#text(" I think this is the same as induction , which somehow was not very intuitive to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b6568539eb95721e8ffe5073dddea221b2f2994d7d0f3089ff2e08bfb5cf802-010d91c12b9a44d211b3a85ef33befff26bc14c87ad58925bc3d69a30d955330.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatoly")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25881")[#strong[#text("Anatoly")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("What I haven’t seen discussed in the variations of this puzzle I’ve seen over the years is the possibility of self-sacrifice and how it may alter the islanders’ behavior. The puzzle as formulated here doesn’t rule out an islander committing the exact form of the ritual suicide they ought to commit when they know their eye color, without in fact knowing it.")

#text("Say you’re an islander. You see 99 or 100 more blue-eyed islanders around you. You reason in the following way after the traveler’s announcement: oh my God, we’re so screwed. There are k “blues” on this island (I may or may not be one of them) and they’re all going to kill themselves on day k, after which all the remaining “browns” will kill themselves on day k+1. We are all dead.")

#text("But what if I kill myself earlier, trying to convince everyone that I know my color whereas in fact I don’t (yet)? I’m scheduled to die on day 100, whether I’m a blue or a brown. What if I kill myself on day 99? If I’m a brown, that’s not going to fool anyone, but if I’m a blue, all the other blues might think that I killed myself on day 99 because I only saw 98 blues around me, and since so do they, they must be brown. Oh, wait, then they’ll kill themselves for *that* reason on day 100.")

#text("Unless… they’re all as intelligent as I am and figured out that my suicide might have been fake. But then again it might not have been! The fact of the suicide doesn’t mean that the person figured out their color; it’s only the absence of suicide that implies they still haven’t.")

#text("If my suicide was true, they’re brown; if it was fake, they’re blue. Since they don’t know, they can go on living! But what about the browns? Damn, they’ll know they’re not blue, won’t they? Because if they were, my suicide would make sense on the 100th but not on the 99th when it happened. So they’ll kill themselves on the 100th, and the blues will follow anyway, the next day.")

#text("OK, that doesn’t work. Sod it all, never mind deceiving others into thinking I knew my color. Let’s just get to the root of this problem, which is negating the shared knowledge we now have. It’ll be enough to get one blue person dead before day 100 for all the others to live, because then they won’t be able to form the hypothetical chain of inductive reasoning with this person somewhere in it – and the chain needs to include all blues.")

#text("I could just kill myself here and now, after the traveler finished his speech, but that won’t help anything if I’m a brown. Besides, I know everyone’s thinking in much the same way I do, or at the very least they’ll figure what I was up to when I cut my throat, so if I’m a brown, other attempts will follow immediately until one blue is dead. This will end up sacrificing around 8 lives – not good. Hey, I know….")

#text("==============")

#text("So, my prediction is that immediately after the traveler’s speech, when they’re still all gathered together, someone with the highest combination of both wit and ruthlessness will rush some blue-eyed islander – maybe there’s someone everyone else really dislikes? one may hope – and kill them on the spot. After which the rest of them live happily ever after. Well, they may decide to cut the traveler’s tongue out, just to prevent any further mishaps of that sort. I wouldn’t blame them if they did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25884")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("Dear Anatoly,")

#text("This is an interesting meta-puzzle. Your analysis seems largely correct, except that one has to kill off a blue-eyed person by the first day in order to avert disaster. This can be seen by analysing the situation as follows:")

#text("As soon as the traveller speaks, it becomes common knowledge that there is at least one blue-eyed islander.")

#text("After noon on the next day, it becomes common knowledge that there are at least two blue eyed islanders.")

#text("After noon on the next day, it becomes common knowledge that there are at least three blue eyed islanders.")

#text("And so forth. Killing (or deporting, or deconverting) a blue-eyed islander will reduce the commonly known number of blue eyed islanders (as well as the actual number of blue-eyed islanders) by one, so if it is done after the first day, it has no effect (unless one kills more than one such islander, of course).")

#text("[An interesting moral dilemma: the traveller can save 99 lives after his faux pas, by ")#emph[#text("naming")]#text(" a specific blue-eyed person as the one he referred to, causing that unlucky soul to commit suicide the next day and sparing everyone else. Would it be ethical to do so?]")

#text("This type of analysis also shows that trying to segregate the islanders or to otherwise disrupt their activities will only delay the doom rather than dissipate it; whenever the islanders all meet again for a day, this will advance the number of commonly known blue-eyed islanders by one, and when that number reaches 100, all the blue-eyed islanders commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-3/#comment-25885")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2008")])]

#text("So if the traveler realizes he did something bad immediately after he said about a blue eyed person, he can directly point to some (unlucky) blue eyed person and say “he is the one”. Then all but the unlucky one will be saved. If the traveller realize it after n days, he can kill off n+1 blue eyed person in this way in order to save the rest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9f0c8da0be7701d3a1250e0c60366bbad8c57eba3980132ac7e66cc83017ce4-06560e0d5475a01eb86557e716d3df85e85715975780127491f655072260386c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25627")[#strong[#text("Ken")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Bjoern: haha, that is true.")

#text("Hey, Aus. You are not quite right. As Bjoern mentioned, they don’t have any intention to kill each other all the time. Even, after the stranger mentioned blue-eyed people, they don’t have to count on everybody. Because sooner or later (100days or 101days later), everyone dies (if all one them started to check calender). It is also interesting to mention that if they counted brown-eyed people instead of blue, they could live longer. As somebody mentioned above, this is the begining of science and the results of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25628")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Dear t8m8r, we can use the same argument 2 for the red-eyed version. (or not?) =D")#linebreak()#text(" I’m going to tell my friends about this puzzle, come on, it’s really fun =P")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25630")[#strong[#text("Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("If everyone leaves the island on the 99th day then everyone would be saved. Theorically they could live in isolation for a day and then join each other for another 99 days. So a population of people like that could survive.")

#text("Unless, someone tells the population how many blue eyed people their our or brown eyed people their our they won’t die out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79111b1ca80e4c40e8844533bc648e03fc4809b3bbd6658c5bd32a892aa35431-d6fb418c95adaaeba8722e4f20e9ba8a8cfdc4bda3b4b78c69e68dc9aead584a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isabel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25631")[#strong[#text("Isabel")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("t8m8r wrote (Feb 5, 1:03 pm), in response to my comment (Feb 5, 12:40 pm)")#linebreak()#text(" “I think the main point of the puzzle was about the common knowledge. Suicide, religion and so on are just wording.”")

#text("I agree that the main point of the puzzle is about the common knowledge. I was just trying to bring attention to why the result might seem so counterintuitive — basically because we have preconceptions about what actual people (as opposed to imaginary mathematical people) do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25633")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Again, we can get rid of the brow eyeds since their presince doesn’t affect the logic. And to Isabel, let’s say, the islanders will leave the island but suicide. So the new puzzle is:")

#text("There are 100 blue eyeds and blue eyeds ONLY in the island, if one finds out his/her own eye clolor, he/she leaves the island. One day, a visitor tells that blue eyed(s) exists among them. What will happen?")

#text("Let’s stick with this simpler and less violent version unless you don’t think it is logically equivelant to the original.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("A similar puzzle without several agents (as seem to be crucial in the Wikipedia article): On Sunday, a prisoner was told that execution are always at noon and he will be executed on one of the following five days but he will not know the exact day until he is collected by the executioner.")

#text("The prisoner deduces that we will not be executed on Friday since he would know this already Thursday at 12:01pm. By the same argument he can then exclude Thursday and eventually all other days of the week.")

#text("He was executed on Tuesday and in fact it came as a complete surprise to him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25635")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("A similar puzzle without several agents (as seem to be crucial in the Wikipedia article): On Sunday, a prisoner was told that executions are always at noon and he will be executed on one of the following five days but he will not know the exact day until he is collected by the executioner.")

#text("The prisoner deduces that he will not be executed on Friday since he would know this already Thursday at 12:01pm. By the same argument he can then exclude Thursday and eventually all other days of the week.")

#text("He was executed on Tuesday and in fact it came as a complete surprise to him.")

#text("Now not anonymous and hopefully with two typos less.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25636")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Following Prof. Tao’s answer, my speculation is the following:")

#text("To make it more intuitive, say n = one million in the new version of the puzzle above. Its seems obvious that the statement that “blue eyed(s) exists” is automatically a “common knowledge”. Yet the induction begins at n = 1 (or 2,3…) , in which case, it does require a visitor to make the anouncement as to create the “common knowledge”. I am unable to locate at what n value “common knowledge” becomes self-edvident. However, I would argue that the induction is invalid since it first reduces n to a value that “common knowledge” is no more a property of the set while with the actual value n = 100, “common knowledge” is a property of the set.")

#text("So, intuitively my answer is: at n=100 (or one million), the visitor’s comment has no effect. But then we need to find the special value k such that the visitor has an effect for all n < = k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e881857a9beba977ea4a22fcbd149468bace47880bc6ed516d21f90c8dda7423-1c2e4feff3f4c0b6bc264f544a24238ed5944052c0e6964614fc50b3cde78e10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charlie C")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25638")[#strong[#text("Charlie C")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Help me out here. Assume we have a stable, closed system consisting of the islanders. Nothing is changing. They somehow have arrived at a state (assume it doesn’t matter how) in which nobody will ever commit suicide. Then the stranger arrives. He states something that they apparently already know, so it seems that he has done nothing to change the state of the system. So how can anyone then decide to commit suicide?")

#text("Put differently, what is the minimal abstract system model describing this situation and what attribute of that minimal system has changed so that the state of the system has been changed, (thus leading to a new action)?")

#text("Translate that minimal system description back into the language (people, eye-colors, actions, etc.) compatible with the problem statement so that ordinary folks can understand it. I believe this final step is crucial to achieving a true understanding of this problem. Or is my re-framing of the problem (and/or my assumptions) invalid?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8016c07d66a0ae2e5ce7aa22ab90010da9b153bdfb3ecb4d68ba450cd6cd736-b65cf35278746737392ea3fb30755adbc749507db3505edc5427bba393401e90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Randby")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25642")[#strong[#text("Scott Randby")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("There is an unstated assumption that is required for the second argument to work. The assumption is that the islanders already know that there are only two possible eye colors. If the islanders do not have this common knowledge, then only the n=1 step of the induction works. To see this, assume that the islanders do not know that there are only two possible eye colors. Let n be the number of islanders with blue eyes. If n=1, the person with blue eyes will see no others with blue eyes and will thus commit suicide. However, if n>1, then each islander will see at least one other person with blue eyes. A blue-eyed islander who observes n-1 other blue-eyed islanders may not conclude that their eyes are blue after n-1 days because the possibility that their eyes are green has not been ruled out. It would be illogical for the islander to assume that if there are any green-eyed islanders, then there must be more than one.")

#text("Thus, we must assume that the islanders know a priori that there are only two possible eye colors in order for the second argument to work. However, even here there is a difficulty and we must make the second assumption that the islanders know that no person has one blue eye and one brown eye. For if the islanders do not know this fact, then the argument given above applies again by substituting “one blue eye and one brown eye” for “green-eyed.”")

#text("So, in order for the second argument to work, the islanders must already have the common knowledge that (1) there are only two possible eye colors, and (2) no islander has one blue eye and one brown eye. With these two assumptions, we may now see why the foreigner’s statement is required in order to implement the mass suicide. Before the foreigner’s statement, the proof of the proposition fails when n=1 because the only islander with blue eyes has no way of knowing this fact. Thus, while the induction step of the proof of the proposition always works, the initial step requires the foreigner’s statement. As the islanders are highly logical, they do not accept the proposition until they hear the foreigner’s statement.")

#text("Thus, argument 2 is invalid unless the islanders’ society allows some discussion of eye color. It seems unlikely that a society that forbids individual knowledge of ones eye color would permit other discussions of eye color. So, I’m inclined to favor the conclusion of argument 1, that the foreigner’s statement will have no effect on the islanders, but not its justification. I think that the proper justification for argument 1 is that the islanders will not have (1) and (2) as common knowledge and hence cannot provide a proof to the proposition.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25644")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("I think this discussion is getting foolish with details while the mathematics is ignored. There are only two maths involved:")

#text("1. Is the induction valid?")#linebreak()#text(" 2. Is “common knowledge” legitimate here?")

#text("The rest is un-important, and the formulation of the original puzzle may not be the best (getting rid of the brown eyeds altogether may be better), but it is clear enough. I hope better mathematicians or Prof. Tao himself will give us the final enlightenment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25645")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Even if there can be more than two colors, n=2 works because nobody committed suicide on day 1 means that every blue eyed person sees at least one other blue eyed person, and if n=2 every blue eyed person will see one and only one blue eyed person, and every other colored person will see 2 blue eyed person. So blue eyed people can determine themselves easily.")

#text("As for the other amusing variants of the puzzle, I think the foreigner should choose one blue eyed person and announce that he is blue eyed in front of all the islanders. Then that man will commit suicide but the other blue eyed islanders will be saved.")

#link("http://www.math.ucla.edu/~tao/blue_variant.html")[#text("http://www.math.ucla.edu/~tao/blue_variant.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25647")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Dear Jian,")

#text("How do you know everyone commented here is “worse mathematicians”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b76815132cbcef321b9605105abbf58261487514b170c1687e2a50b30da9a13-ebb793d8fd9d046e44f81de3a2aa9c451483d72ac5a9386c1d7e803651d8de45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhilGibbs")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25649")[#strong[#text("PhilGibbs")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("I have been trying to think of ways to avoid objections such as you need to state in the puzzle that “everybody knows that everyboday knows that everybody knows that everybody is logical”, etc. and that “everybody believes the foreigner and everybody knows that everybody believes the foreigner etc.")

#text("Perhaps it would be sufficient to say something like this…")

#text("… By the end of his stay on the Island everybody had come to trust everything the foreigner said which was fair enough because in fact he did always tell the truth. Then he made a speech saying “I am happy to see that everybody is here to hear me today, and that you have all come to trust everything I say, and that you are all totally logical, and that you have all carefully observed the colour of everybody elses eyes. How unusual it is to see another blue-eyed person like myself in this region of the world.”")

#text("Then we would know that everybody knew that everybody knew that everybody was logical etc. Or at least we would know that everybody believed that everybody believed etc. I think belief is sufficient to make the blue-eyes commit suicide on the hundredth day :-)")

#text("Am I making any sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25650")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("You believe you are logical does not make you logical, does it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25651")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("I don’t understand why so many people have a problem with the induction argument.")#linebreak()#text(" Think of it like this:")#linebreak()#text(" 1) Island has only 1 blue eyed person. Since he hears the foreigner and can see 999 brown eye balls, he concludes its he who has blue eyes. Suicide.")

#text("2) Island has 2 blue eyed persons. Each can see 998 brown, 1 blue. So, each expects case 1) to happen. When it doesn’t, they realize that the only way it can’t happen is if there are 2 blue eyed persons. Suicide day #2.")

#text("3) Island has 3 blue eyed persons. Each expects case 2) to happen")

#text("etc.")

#text("Why should such a reasoning be impractical when it has already been assumed that the islanders are perfectly bound by logic and religion?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25653")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Klien4g,")

#text("Every body sees that, we are just unsure if this is the only way the islanders can think.")

#text("Please see Robert’s prisoner puzzle posted at 9:am today. Induction may be deceptive. Or “Anonymous”‘s millitary exercise puzzle posted 11:25 am yesterday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b76815132cbcef321b9605105abbf58261487514b170c1687e2a50b30da9a13-ebb793d8fd9d046e44f81de3a2aa9c451483d72ac5a9386c1d7e803651d8de45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhilGibbs")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25654")[#strong[#text("PhilGibbs")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("“You believe you are logical does not make you logical, does it?”")

#text("No, but if they are logical and they believe that everybody is logical and they believe that everybody believes etc. then the induction argument can be made watertight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8b76815132cbcef321b9605105abbf58261487514b170c1687e2a50b30da9a13-ebb793d8fd9d046e44f81de3a2aa9c451483d72ac5a9386c1d7e803651d8de45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhilGibbs")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25655")[#strong[#text("PhilGibbs")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("“You believe you are logical does not make you logical, does it?”")

#text("No, but if they are logical and they believe that everybody is logical and they believe that everybody believes etc. then the induction argument can be made watertight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25656")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("In fact, there is no need for a foreigner to visit the island, provided there are at least 2 blue-eyed persons.")#linebreak()#text(" Here’s why.")#linebreak()#text(" (There is no need for induction to start at n=1.)")

#text("Case 1) Let there are 998 brown-eyed islanders and 2 blue-eyed. Each can see each other, so they each see 998 brown and 1 blue. Each reason like this, “Suppose a foreigner were to come and make a silly gaffe like… then the blue-eyed fellow i see over there should commit suicide in a day”")#linebreak()#text(" After a day, when none of them commit suicide, they realize that there has to be 2 blue-eyed fellows and since each can see 998 brown eyes they each reason that the other blue-eyed fellow must be himself. So by day 2 they both commit suicide. The 998 brown-eyed islanders follow suit the next day.")

#text("Next, consider 997 brown-eyed and 3 blue-eyed…each expects case 1) to occur, etc.. so for n blue-eyed by day n+1 all of the islanders are dead.")

#text("Since we are given that there are 100 blue-eyed islanders, the island should be completely uninhabited by the 101st day. (The un-mathematical question is: 101st day from what??)")

#text("Anonymous: Robert’s puzzle is different since there is no way to get in an induction step. The soldier is only guaranteed that he won’t be executed on Friday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Dear Klien4g,")

#text("The prisoner can still be executed on Friday precisely because he doesn’t think it will occur that day. A suprise, as told ahead.")

#text("I don’t understand your argument in case 1). How something a blue person images can account for the other blue person? If that can happen, the situation of having any blue persons at all can never occur. In what particular day the imagination should occur so that the suicide will occur “the next day”? Perhaps I missed something… I think you are operating with some external knowledge which is unaccessible to the two blues until the foreigner comes over.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("The “common knowledge” that the foreigner brings about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25662")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Dear klien4g,")

#text("Your Case 1) does not work, because:")

#text("Each blue eyed reason like “Suppose a foreigner were to come and make a silly gaffe like… then the blue-eyed fellow i see over there should commit suicide in a day”, but they do not know the other one is reasoning about him/her like this. So there is no reason to commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf96ffefbeb5fe60d802b0545d1c33272fc56199071bc3e44ad2e67e8e8927d7-9ea472afe3278b22bc85707dcd14fe9eb418b48e7ff896669c4d4b199565a3f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd Man Out")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25675")[#strong[#text("Odd Man Out")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Marko:")

#text("“””")#linebreak()#text(" the argument doesn’t apply to the brown eyed people, because they see one more blue-eyed person than the blue people, so for example if there are n blue-eyed, the brown eyed will see n but the blue eyed will see n-1.")#linebreak()#text(" “””")

#text("This makes no sense. The tribes people don’t know the actual number. They see what the other people have and know that they are of one of those two values. This is specified in the problem “each resident can (and does) see the eye colors of all other residents, but has no way of discovering his own (there are no reflective surfaces).”. Thus, they know the true number +/- 1. Even though a person may have brown eyes, they have no way of knowing that and as such, they couldn’t know if the foreigner was speaking to them and as such, are just as likely to think that they have to commit suicide the next day.")

#text("The theorem/proof is flawed because it assumes something that it can’t.")

#text("Scott Randby pointed out another flaw. That there is the knowledge that there are only two possible eye colours.")

#text("klien4g:")

#text("People have problems with it because it assumes that all villagers know the exact number of blue/brown-eyed people. This is not true given that they cannot know there own. Thus, the induction argument falls apart.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25689")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Odd Man Out,")

#text("___________")#linebreak()#text(" This makes no sense. The tribes people don’t know the actual number. They see what the other people have and know that they are of one of those two values.")

#text("__________________")

#text("sorry but it actually makes perfect sense. Let’s say there are n blue eyed people. If you are blue eyed you see that there is n-1 blue eyeds, so you don’t know if the true number is n or n-1. Because the other blue eyeds than don’t commit suicide on the n-1st day all of you conclude that there is n blue eyeds and all of you commit suicide on the nth day.")

#text("From the point of view of a brown eyed person, you see n blue eyes, and you’re not sure if the real number is n or n+1. So you wait see if they commit suicide on the nth day. Since they do, you correctly conclude that there was only n of them and that you have brown eyes. So you would only conclude that there’s n+1 blue eyeds if no one commits suicide on the nth day.")

#text("So in this part of the argument, there’s nothing wrong. Also there’s nothing wrong with people knowing there’s only 2 eye colors. They can be taught in school that there’s only 2 possible eye colors, and also that if you ever find out your eye color you have to kill yourself. So they could all have this knowledge, but for this it is not necessary for them to know that there’s anyone who actually has blue eyes – they just know that it’s possible, but that doesn’t necessarily mean that the possibility is fulfilled. So if there is only one person with blue eyes, there would be no need for him to assume that he has blue eyes just because no one else does, because even though blue eyes are possible it doesn’t mean that someone has to have them. And that’s why the stranger’s statement is important, and that’s why everyone lives happily until the stranger makes that statement.")

#text("The induction argument at no point assumes that the villagers know the exact number of blue/brown eyed people. All it says is that they count the number of blue eyed people they see, from that conclude the 2 possible values of the number of blue eyed people, and then based on the extra information of who commits suicide they are able to conclude what their eye color is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25697")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I know my second argument sound’s impractical. But I am assuming a certain kind of symmetry of reasoning among the islanders (why not?). The argument sounds odd because it requires each of the islanders to begin the reasoning at the same time and know that each has begun the reasoning at the same time.")#linebreak()#text(" In the first case, it is the foreigner that provides the ground for each of them to start reasoning and know that each has begun reasoning.")#linebreak()#text(" If there are at least two blue-eyed islanders. We can imagine that when the two people bump into each other for the first time it begins the reasoning process in them with each knowing that such a process has begun. (Meeting a rare blue-eyed person in a sea of brown-eyed person is surely a note-worthy event)")

#text("Of course, the whole thing goes to ruin if someone were to say that of the 100 islanders, that first 10 of them bumped into each other for the first time on such and such day, next 20 met for the first time by the campfire, etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("klien4g,")

#text("there is a need for the foreigner. In the case you describe let’s say there’s 2 islanders and they bump into each other. Each sees a guy with blue eyes for the first time. But they have no reason to suspect that the second guy sees a guy with blue eyes (since they have no idea that their own eyes are blue). So they each see a guy with blue eyes, make no comment about it, and go about their business. And they can even reason that the other guy has blue eyes but has no reason to suspect it, because there’s nothing to guarantee that there should be any islanders with blue eyes. And that’s why the foreigner is important.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25699")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("klien4g,")

#text("there is a need for the foreigner. In the case you describe let’s say there’s 2 islanders and they bump into each other. Each sees a guy with blue eyes for the first time. But they have no reason to suspect that the second guy sees a guy with blue eyes (since they have no idea that their own eyes are blue). So they each see a guy with blue eyes, make no comment about it, and go about their business. And they can even reason that the other guy has blue eyes but has no reason to suspect it, because there’s nothing to guarantee that there should be any islanders with blue eyes. And that’s why the foreigner is important.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25700")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("klien4g")

#text("I like your idea of two blues bumping into each other (indeed practical), but I still don’t see how a metal process without any external comfirmation would have any effect in actuality. The foreigner’s comment is still needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25701")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Sorry about the double post guys, there was a glitch in my browser.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e881857a9beba977ea4a22fcbd149468bace47880bc6ed516d21f90c8dda7423-1c2e4feff3f4c0b6bc264f544a24238ed5944052c0e6964614fc50b3cde78e10.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Charlie C")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25704")[#strong[#text("Charlie C")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("What relevant information did the stranger add that was unknown before he arrived?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47646a615a8ecd9140b19cc46af1f92602d3e6c3fe0714de5693ae2ff06a3794-95feb637aec1b13fe9705a687e75174ea85c94f3f0b908f05d5865750137997a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25709")[#strong[#text("Liam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Hm, an interesting variation has cropped up in my mind:")

#text("The island contains 100 blue-, 1 green-, 1 yellow-, and 898 brown-eyed people. The inhabitants assume that the only possible eye colors are the ones they can see, or have seen in the past. The foreigner comes to the island and makes the same gaffe.")

#text("Who kills themselves, and on which days?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ThM")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25712")[#strong[#text("ThM")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("This problem is just all nonsense anyway, because of the following theorem:")

#text("In any given Island, all the inhabitants must have the same eye colour.")

#text("Proof: reason inductively on n,the number of islanders. If n=1, the theorem is trivial (I assume that everybody must have two yes of the same colour, of course). Suppose it is true for n-1. Then consider an island with n islanders. Remove the nth one, let me call him Jim. You get an island with n-1 islanders, all of which must have the same eye colour, by the induction hypothesis. Then Jim, must have the same eye color as the other ones, for if it were not the case, you could instead take back Jim in and remove Agatha instead. This way you would get an island with n-1 islanders an all of them would not have the same eye color, contrary to the hypothesis. QED")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25714")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Get your tongue out of your cheek, ThM :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8deabace824b2da2c606af4c3fed9e25ad0d6e4f49f21710e28efaa59363728c-d1a4924896a6fcf4eb5aa9c4e8e8db7e9d9720f4ec94c515911fe6095b87020d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Summarizer")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25715")[#strong[#text("Summarizer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("on 6 February, 2008 at 11:13 am t8m8r said:")

#text("> ")#link("http://www.math.ucla.edu/~tao/blue_variant.html")[#text("http://www.math.ucla.edu/~tao/blue_variant.html")]#linebreak()#text(" > As for the other amusing variants of the puzzle, I think the foreigner should choose one blue eyed person and announce that he is blue eyed in front of all the islanders. Then that man will commit suicide but the other blue eyed islanders will be saved.")

#text("This is correct. And on the nth day before noon, he would have to publicly out n blue-eyed islanders to save the remaining 100-n.")

#text("[Two other possibilities, though these probably go beyond the permissible guidelines, are:")#linebreak()#text(" a) on the first day, choose a brown-eyed islander and announce he is blue-eyed, in which case either")#linebreak()#text(" (i) the foreigner is understood to be color-blind and entirely ignored")#linebreak()#text(" (ii) the foreigner alone is executed as a liar and scoundrel")#linebreak()#text(" b) on the first day, the foreigner announces that “All blue-eyed people are liars.”")#linebreak()#text(" ]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25719")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Marko,")

#text("You almost convinced me there. But, isn’t it likely that when the two blue-eyed islanders meet each other and see blue-eyes for the first time in their lives, they are made aware of the existence of an eye-colour different from brown. And since each know that they cannot see their own eye-colour, that there own could, now, possibly be blue.")#linebreak()#text(" Isn’t this similar to the kind of information that the foreigner would provide to an island with only one blue-eyed person and hence set off the induction?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Klien4g")

#text("Blue and brown are inter-changable, it isn’t a special color. You are still assuming an external knowledge that the visitor will bring about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25723")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Anon")

#text("The colours are irrelevant (Imagine the foreigner saying, “How unusual to see another person with coloured eyes in this part of the world”). Its the number of distinct colour-types that sets off the suicides. Thats the knowledge in question, which needs no foreigner if there are at least 2 islanders whose eye-colours are different from the rest.")

#text("Thm")

#text("G Polya had formulated a few interesting induction problems for his students… have forgotten where its written though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Klien4g")

#text("But then bumping into any other person will do? That means any islander seeing any other human the first time in his/her life!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25725")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Anon")

#text("Of course not. When an individual X(regardless of eye colour) meets another person whose eye colour is different from the rest, s/he can infer that there are two colour types. This won’t happen if X were to bump into a person whose eye-colour was similar to what X had seen till now.")#linebreak()#text(" I’m afraid I don’t know how I can make my point any clearer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25726")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("ThM, your induction step should work for any n>1. So how is it when n=2?")

#text("klien4g, you know you possibly have blue eyes is not a reason to suicide. You have to be sure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25729")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("t8m8r")

#text("The deal is can we get the islanders to have second-order knowledge (X knows that Y knows that P) without a foreigner. According to me, you can.. if we have a chance meeting of all the blue-eyed islanders at the same time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25731")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("K,")

#text("I wish you were right too since I do think the idea of “common knowlege” is a bit forced.")

#text("Say, A meets B as the first islander with a differnt color, yet A may not appear to B the same way.")

#text("Perhaps I am missing something. Let me think a bit more. Feel free to skip my posts at this moment. Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("i find Phillip’s argument (posted on 5 February, 2008 at 8:29 am) really interesting! how the blue-eyed population could grow is seemingly a puzzle: when the 1st blue-eyed person (let’s call him/her “A”) is born, there is no way for him to figure out his eye color;")#linebreak()#text(" then the 2nd blue-eyed person (“B”) is born. both of them can see there is at least one blue-eyed person, but they both don’t know that the other knows this statement;")#linebreak()#text(" now the 3rd blue-eyed person is born (“C”), which makes things interesting. you would think his birth acts the same role as the stranger: from that particular day, everyone now knows there is at least one blue-eyed person: for brown-eyed person, this is trivial. for blue-eyed person, consider A: he knows there is at least one blue-eye person, because B and C can see each other. and this is exactly what the stranger does – thanks to him, at one particular day, everyone knows there is at least one blue-eyed person. so you could use argument 2 and conclude that the three blue-eyed would commit suicide after two days. so the blue-eyed population is unstable once beyond 2.")#linebreak()#text(" —– spoiler below —–")

#text("however, is the birth of C really equivalent to what the stranger does? the problem of the reasoning above is that the birth of C did not provide the information that everyone knows that “everyone knows there is at least one blue-eyed person”. to see this, let’s consider A again (this might be a bit wordy to explain). all he could reason is as following: if my eye color were blue, then B would know that C knows there is at least one blue-eyed person; but if my eye color were brown, then B cannot deduce that any more – there is this valid possibility to B that C is the only person who has blue eyes, so C does not know there is at least one blue-eyed person.")#linebreak()#text(" the stranger tells everyone _explicitly_ that there is at least one blue-eyed person. because the presence of everyone during the announcement, everyone knows that everyone knows there is at least one blue-eyed person, everyone knows that everyone knows that everyone knows there is at least one blue-eyed person, and so on ad infinitum (")#link("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")[#text("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")]#text(");")#linebreak()#text(" on the other hand, the birth of the 3rd blue-eyed person only allows everyone to _deduce_ that there is at least one blue-eyed person, and there are no more information to deduce the next layer, which makes the difference.")

#text("by this reasoning, you can see why things like blue-eyed ppl one day bumping into each other are NOT equivalent to the stranger. it is confusing to think the role of stranger is to “synchronize” the knowledge (like some early posts saying).")

#text("i am too lazy to type any more – ppl should have no problem figure out that argument 2 works only when “there is at least one blue-eyed person” is common knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1354580030618e6c062d0d073bd832130063d7efe7c1f328e8f9f118b375f80-33cc669411f51039b758b073461a5edfd4e2a696efdc977f90696f707ee6188d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of klien4g")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25735")[#strong[#text("klien4g")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Perhaps we can replace the presence of the foreigner for second-order knowledge to come about by using something like this:")#linebreak()#text(" Imagine the total number of islanders to be very large. If there are two-islanders who have eye colour different from the rest then the likelihood of them meeting each other is low. Their knowledge of the unlikelihood of meeting an islander of a different eye-colour should be enough to set the reasoning going in their heads.")#linebreak()#text(" Now, (sorry for all this hand-wavy manner) it is important that the number of blue-eyed islanders should be really small in comparison to the brown-eyed islanders.")#linebreak()#text(" There are flaws (how do they measure the unlikelihood?), but can this sort of reasoning be made precise?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25737")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("No matter how many blue eyed islanders are there, no matter they meet each other or not, they will not commit suicide. Only the message of the foreigner that matters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25739")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I haven’t read all the comments yet, so somebody may have already said this, but here is the way to understand the way the traveler changes the situation. Let n = number of islanders with blue eyes.")

#text("In the case n=1, it is obvious that the traveler is bringing new information; namely, the one person with blue eyes did not previously know that anybody had blue eyes, and now he does.")

#text("In the case n=2, let A and B be the islanders with blue eyes. They each know that there is at least one person with blue eyes. However, they do not know that everybody knows that. ie, A sees that B has blue eyes, but does not know that B can see the same thing about A. As far as A is knows, B could be the only person with blue eyes. Once the traveler comes in, A reasons that B cannot be the only person with blue eyes, because if that were the case, B would have committed suicide. Then, by process of elimination, A reasons that he must be the other person with blue eyes. The new information (for A) is not that somebody has blue eyes. A already knows that. The new information is that B (whom A already knows to have blue eyes) also knows that somebody else has blue eyes.")

#text("And so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Klien4g")

#text("I appreciate your effort in trying to remove the necessity of “common knowledge” introduced by a visitor (since like I said, I didn’t like it either), but I don’t think your arguement is convincing enough. However, the small number of blues in a large pool of browns is very interesting! Keep going!")

#text("I just for some reason distrust CK (Common Knowledge). Image the whole universe is filled up with blues eyes and blue eyes only, is it still not CK? And one sentence from the visitor sets all of them dead? It must be a very unstable system! I am guessing there exists a number K (perhaps small in value), for all n > = K, CK is automatic. For all n < K, it takes a visitor to create CK. n =1, 2, 3 are obviously such cases (when number of browns is also small).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25741")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("Yes, Matt makes an excellent summation. I spoke too swiftly to agree with Philipp before (I blame Mardi Gras), and Matt’s position is more accurate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-2/#comment-25742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2008")])]

#text("I like to hear your guy’s opinions on “Common Knowledge”. Do you trust its legitimacy??")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2008")])]

#text("Pro. Tao,")

#text("I really can’t figure out the “blue eyed islanders” puzzle, and there is no post option in that web page, so I can only ask you here:")

#text("What is the correct answer?")

#text("I tent to think the Induction is invalid.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25527")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2008")])]

#text("Dear Anonymous,")

#text("I don’t want to spoil the puzzle for others, but the key to resolving the apparent contradiction is to understand the concept of “common knowledge”; see")

#link("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")[#text("http://en.wikipedia.org/wiki/Common_knowledge_%28logic%29")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25528")[#strong[#text("Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("The second argument is flawed. The people will never know if there are 101, 100, 99 blue eye people in the tribe, as they wouldn’t know there own eye colour. The person would have to give the number of blue eyed people for the second argument to work, because then the brown eyed people will know they have brown eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phillip")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25529")[#strong[#text("Phillip")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Prof. Tao,")

#text("I don’t want to spoil the puzzle either. But I think the wikipedia entry misses an important point.")

#text("The induction argument is basically right. The blue-eyed islanders will eventually commit suicide. But in my opinion they would commit suicide even if no foreigner visits the island. Proof:")

#text("The same is true if the number of blue-eyed islanders is not 100 but any positive integer greater than two. For simplicity asumme that there are exactly three blue-eyed islanders, say A, B and C. (The same argument works for any larger number as well.)")

#text("Consider the day of birth (or better the day of religious initiation) of the third blue-eyed person. On that day A, B and C see each other. Person A knows that B knows that there are blue-eyed persons, because A knows that B can see C. The same holds for any permutation of A, B, C. So everybody knows that there are blue-eyed persons.")

#text("On the second day nobody commits suicide. Everybody can deduce from this fact that there are at least two blue-eyed islanders: If there was only one blue-eyed islander, (s)he would have committed suicide, because (s)he had encountered to be the only person with blue eyecolor. Furthermore everybody knows that everybody can deduce from this fact that there are at least two blue-eyed persons on the island. The lower bound of two is now “common knowledge”.")

#text("On the third day nobody commits suicide. Everybody can deduce from this fact that there are at least three blue-eyed islanders: If there were only two blue-eyed islanders, they would have committed suicide, because they would have known that they are among the two blue-eyed persons. It is now common knowledge that there are at least three islanders with blue eyes.")

#text("The islander A now sees only two blue-eyed persons and realizes that (s)he has blue eyes.")

#text("On the fourth day A, B and C commit suicide. ")#mi("\\Box")

#text("Note that the same argument works for any number of blue-eyed persons greater than two. I therefore wonder how the population of blue-eyed persons can grow so high. Everytime there are more than two persons with blue eyes, they shortly thereafter will commit suicide.")

#text("The first argument given in your description of the puzzle is therefore also correct, i.e. the stranger’s adress doesn’t change anything because (s)he doesn’t tell anything new.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25530")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("My intuition goes with Philipp. Another way to put it is that both arguments Dr. Tao gives are correct. The visitor has brought no new information, and they would end up killing themselves regardless.")

#text("What no solution I’ve seen yet mentions is that the next day, all the other villagers would follow suit, since they would know that anyone with blue eyes would have killed himself the previous day, and so they must have brown eyes.")

#text("Actually, the problem might be stated better. Say that there are some with each eye color. Having 0, 1, or 2 blue-eyed villagers seems stable, so those are the only actual possibilities. Now the visitor does bring new information, and changes the game. We now know that there’s at least one blue-eyed villager. If there’s only one, he realizes it since nobody else has blue eyes, and kills himself. If there are two, they’ll realize it soon enough and kill themselves, just as the proposition states.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6351b8ac7aaaf1226949432cb775f977c07e0da0338f15b40ab464bfaa5b15c-b8faa30f60ad996e03e225c56fee47f31cf1f4df586a575cda27acb2fd46e63d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A T")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-44173")[#strong[#text("A T")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("Well… for all the brown-eyed people to kill themselves on the following day they would have to assume that there are only two possible eye colours.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robinson")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25531")[#strong[#text("Robinson")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Oh, yeah now I get it. Everyone would die including the brown eyed people. As after the blue eyed people commit suicide on day 100 the brown eye people will commit suicide on day 101, since they would know they have brown eyes because all the blue eyed people are dead.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2b3d527200d40ffc510ec370f0ffd1e29d3944c0191cb3005e01ce5fd748ee3-0d2a7ed286294fd49cd3fe3fee5b3f654603c6f676bf1b568563c54427c82c58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MikeBravo")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-44174")[#strong[#text("MikeBravo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("Except for my cousin, who would be on the horns of a moral dilemma. She has one blue eye and one brown eye.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Prof. Tao,")

#text("Sorry for having led this web page into the discussion (since it is originally under “career advice”). However, this is what I think:")

#text("Mathemacality has a limit as applied to reality. Mathematical induction starts with K=1, but the reality is GIVEN K=100, which does not arrive as a sequence from K=1. So the sequencial reasoning isn’t valid here. The blue-eyed islanders could comprehan their reallity with our induction only when they want to (that is, if they are mathematical souls), but they don’t have too (which does not necessarily violate logic). In fact one could argue that, since induction is not necessary therefore following it is not logical, therefore there will be no effect for the islanders. Or if they are indeed mathematical souls, then I go with Philipp: They will all commit suicide even if the outsider never came. Or K= 100 is an impossible situation to be a reality (so the puzzle contradicts itself).")

#text("However, my intuition goes with the limitation of mathematical reasoning. I am reminded another puzzle, though not the same, but also about the mathematical handling of information:")

#text("(supposedly a real story, I might not get the time right) During WW2, a city (in Poland?) made an anouncement: A military exercise would be conducted some day in the following week, yet in order to get the residents of the city used to unprepared situations during the war time, the specific day of the exercise would not be given so that it would come as an suprise. A mathematician (name I forgot) immediately reasoned:")

#text("The exercise can not take place in Sunday (the last day of the week), since if so, by Saturday night, people will know (therefore not a suprise). But then it can’t be Saturday either since if so by Friday night people will know that it will happen on Saturday since the possibility of Sunday is already ruled out. But then, Friday, Thursday, Wednesday, Tuesday, Monday are not valid days either. Therefore the exercise can never happen!")

#text("The exercise still took place on Wednesday, as nobody had induced, therefore still a suprise as promised.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("To my observation, the “foolishness” of mathematical reasoning sets in usually when time dimension is involved, precisely in term of deduction. In the case of the military exercise, the mathematical sequence replaces (improperly) the time order which is a physical reality. In the case of the Blue eyed islanders, it disrecards K is given as 100 as the starting point of reality, and reasons back to K=1, which is only a mathematical reality. Of course this is getting a little philosophical.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Philip,")

#text("In the situation you are considering that is no visitor visits island, if there is only one blue eyed person, how would he know he is blue eyed. Quoting you “If there was only one blue-eyed islander, (s)he would have committed suicide” I think its not true in the scenario you are considering.")

#text("I believe rather the visitor is indeed adding some information.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Prof. Tao")

#text("Thank you for setting up the seperate post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec07bf3eb7d5f74df41531b1fa1bcd5107ff184bb1b563247b130fc591c49d7-7fd6f55baeb7909e9e24eb483c9fefa1b3f64df6363292101c1c521ed794cf0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron Bergman")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25537")[#strong[#text("Aaron Bergman")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("The version I know has only the blue-eyed people killing themselves (why do these puzzles always involve so much death, anyways?). The follow-up question is then to ask what is the new information. It’s easiest to figure out that question by studying the case where only two people have blue eyes.")

#text("For the answer, here’s an old ")#link("http://groups.google.com/group/rec.puzzles/browse_frm/thread/97481189aa166c2c")[#text("thread")]#text(" from rec.puzzles.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/79111b1ca80e4c40e8844533bc648e03fc4809b3bbd6658c5bd32a892aa35431-d6fb418c95adaaeba8722e4f20e9ba8a8cfdc4bda3b4b78c69e68dc9aead584a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Isabel")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25539")[#strong[#text("Isabel")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I believe the second argument as a mathematical argument, but somehow I have trouble picturing this actually happening. I mean, come on, exactly one hundred days later a hundred people commit suicide? Nobody mis-counts the number of blue-eyed people? Every single one of the blue-eyed islanders independently thinks of this argument? (Someone it seems strange that the religion in question would permit people to discuss eye-color-related questions in the abstract but not let people talk about their own eye colors.) There are so many things that could go wrong.")

#text("And I think that’s why people have trouble with the second argument. It makes sense with, say, two blue-eyed people — then they only have to count one other person each, and keep that information in mind for two days — but probabilistically speaking someone will make an error before the hundredth day, just like books inevitably include errors. The reason the mass suicide seems highly implausible is because we know nobody’s perfect. Perhaps an equivalent problem in which the actors are non-human (I can’t cook one up off the top of my head) would cause less cognitive dissonance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25541")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I think the main point of the puzzle was about the common knowledge. Suicide, religion and so on are just wording.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6b562d38b96cf657178c57a00162656d21e0796cee1bce089d46b095f465503-d73df4ba1958da133c15dd70e43bf60c592fbcc31fbc6cecb8ede2f08b8ef88a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of avfonarev")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25542")[#strong[#text("avfonarev")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Prof. Tao,")

#text("I’ve never seen this puzzle before, but the second argument reminds me of the following “problem”:")

#text("A number of married couples live in a small village. Every time some husband cheats on his wife, every woman except her finds out about it. If one can deduce that her husband is a cheater, she is allowed to kill him. One day an old lady that never lies comes and tells everyone that there is a least one cheater in the village. What happens next?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60b3b948f0438bae7b547bc11b4a69a4d80d058fc65f223cecff5dc70de06e59-65f2193f3743cf8a79a545e72903fc67cf26d5ec050968f780a93ccb33746b00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray Pereda")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-47942")[#strong[#text("Ray Pereda")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2010")])]

#link("http://www.mytechinterviews.com/is-your-husband-a-cheat")[#text("http://www.mytechinterviews.com/is-your-husband-a-cheat")]

#text("Google uses this problem during their technical interviews.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1f2060c6149bd657144d550418b609703e03ef9d9f396fd49a96b4517ae9f8c4-51b3b67b52eff2358f9ae9503a8aa4d9ee5875ccde9abee20b7ee2d9742c8d0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maurizio")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25544")[#strong[#text("Maurizio")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Philip,")#linebreak()#text(" i can’t understand how you proved that A,B and C should suicide.")#linebreak()#text(" Consider this: when the 2nd blue eyed is introduced nobody dies. So, when the 3rd blue eyed is introduced, each already-initiated blue-eyed thinks that it is the 2nd that is being introduced, and so he is not surprised if nobody dies. On the other side, from the point of view of the newly introduced guy, nothing changes if he is blue-eyed or brown-eyed, unless someone dies (and this is not happening).")#linebreak()#text(" Passing from 2,3 to n,n+1, this should prove by induction that an arbitrary numer of blue eyed people can be introduced and survive.")#linebreak()#text(" The funny fact is that in some way the foreigner is “synchronizing” the knowledge about the existence of blue-eyed people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b82bf046c7e11accbfe3c4faaf4b8a21024b332d8287462b2b7144ee1e82acf-b75b8fc7a8eb889ba79c35fbbe6b841349d874675810116eac900d74ae56ff98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Samal")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25547")[#strong[#text("Robert Samal")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Prof. Tao,")

#text("thank you for posting this nice puzzle.")#linebreak()#text(" I have one suggestion, though, to clarify the problem statement")#linebreak()#text(" (but perhaps it was left ambiguous on purpose?).")

#text("“… one resident can see the eye colors of all other residents”:")#linebreak()#text(" this sentence doesn’t seem to tell that everybody really did see everybody")#linebreak()#text(" else’s eyes. Perhaps the tribepeople prefer not to look into eyes of too many other")#linebreak()#text(" people (to avoid learning about their own eye color :-) ).")

#text("Anyway, thanks again.")

#text("Robert Samal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" If the total number of brown and blue eyed color people is known to each individual then they can easily figure out the color of their own eyes.")

#text("Thus instead of 100 the answer should be 1000 i.e. all the thousand people try to commit suicide. A brown eye person will wait till 100 days")#linebreak()#text(" for all the blue eye people to commit suicide. On 101st day he will think that he is also blue eyed. This applies to everybody.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ryan Reich")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25549")[#strong[#text("Ryan Reich")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Concerning the comment of Anyonymous, at 11:25, 5 Feb 2008: you are not quite appreciating how each islander applies induction in the second proof. I’ll give symbolic names to the groups involved in his reasoning: say the islander in question is named A, and he sees a set S of n – 1 blue-eyed fellows. He reasons that if he himself doesn’t have blue eyes, then S must in fact be the set of all blue-eyed people on the island, and therefore the induction hypothesis applies to THEM: they will all die after n – 1 days of waiting. When this fails to occur, he realizes that he must actually have blue eyes. So although you are correct that the n blue-eyed islanders are not given as a sequence of 1, 2, …, n islanders each independently constituting a sub-puzzle, that is not how n is used in the proof: there, it shows up as “one more than the number of blue-eyed people any blue-eyed person can see”; in other words, the proof implicitly realizes the n islanders as a union of subsets of size n – 1, which are unions of subsets of size n – 2, …. It is not the SET itself which is the termination of a sequence, but its CARDINALITY, and cardinalities are linearly well-ordered and hence amenable to induction.")

#text("This technicality showed up in a comment on Timothy Gowers’ blog recently (“A paradox in probability”, comment by JB on 1:04, 4 Feb 2008): slightly reworded, start at time zero and in one hour, put balls 1-10 in a bag. In another half hour, take them out and put in balls 11-20. In another quarter hour, replace those with 21-30, and so on. How many balls are in the bag after two hours have passed? The answer is seemingly both “10” and “none”, since no particular ball is there, yet at all times preceding, there are ten balls there. The resolution is that the sequence of SETS of balls is not linearly ordered, so that in fact the SET of balls in the bag after two hours is empty (the sense in which we were intuitively viewing the “limit” of the sequence of balls was as the set of all balls which remained for sufficiently large times); however, their CARDINALITIES are ordered (and constant). So if we insist on “abstracting” the contents of the bag away from the particular numbered balls it contains to simply a collection of ten balls, we get a limit; however, it is the limit of a different sequence. A pithy way of saying this is that “the cardinality function is discontinuous”.")

#text("For a variety of reasons, this problem is unrealistic; however, it encapsulates the same phenomenon that confounded you with the islanders problem, which is realistic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6172cb67f2866d1a9c75bcd4b937ee0f29937b1a9436b3bbd3bec3383798a71-7a7d636c9329b1dad6a7c1660f8dcf5d0a6703a4a72ee7c15f92b2ba9470b1f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon Amit")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25550")[#strong[#text("Alon Amit")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("This is one of those problems that never fails to produce a lively discussion :-)")

#text("A few comments and pointers:")

#text("1. A sharp version of this problem can be found in the lovely “7 puzzles you think you must not have heard correctly” by Peter Winkler. In this version the foreigner says something – anything – non-trivial about the number of blue-eyed people. Here’s a link to the doc + solutions:")

#link("http://gauss.dartmouth.edu/~pw/solutions.pdf")[#text("Click to access solutions.pdf")]

#text("2. I, too, am unable to follow Philip’s argument (I get stuck at “because (s)he had encountered to be the only person with blue eyecolor”). An island with three people, all blue-eyed, seems fairly stable to me.")

#text("3. A related puzzle I like is this one: Alice and Bob each have a number glued to their forehead for the other one to see. The numbers are N and N+1 for some positive integer N and Alice and Bob both know that, but they don’t know what N is and they don’t know which of them has the N and which has the N+1. They are repeatedly interrogated about their state of knowledge – first Alice, then Bob, then Alice again, and so on. For various values of N, what happens?")

#text("(for example, if N=1 and if Alice has the 1 and Bob has the 2, Alice would say “I don’t know” since she could either have 1 or 3, but Bob would say “I do know”, following which Alice would say “Now I know, too”. Now if N=2…)")

#text("4. Prof. Tao – thanks for a most wonderful blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25551")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("If we’re living in ideal logic-land, then I’m with the “mass suicide” camp — as Aaron says, there is indeed new information. Answering his question a bit more mathematically than the thread he links to does, we can see exactly what that new information is.")

#text("Let’s write P_1 for the statement “there is somebody with blue eyes”, P_2 for “everybody knows there’s somebody with blue eyes”, and similarly P_(k+1) for “everybody knows P_k”.")

#text("Going back to the island, suppose I’m an islander. If I can’t see anyone with blue eyes, then I’m not sure about P_1. If I can see one person with blue eyes, I know P_1 is true, but I don’t know whether or not he can see one or none, so I don’t know if he knows P_1, so I don’t know about P_2. Carrying on, if I can see n people with blue eyes, I know that P_n is true, but I can’t be sure about P_(n+1), because it depends on my own eye colour. (Formally, we can check this by induction, using the fact that if I can see n blue-eyed people, I know everyone else can see at least n-1.) So at first, I only know finitely many of the statements P_k, limited by how many pairs of blue eyes I can see.")

#text("Now, when the visitor speaks up, he says P_0… but since he’s addressing the whole tribe, I also know that everyone else heard, i.e. I know P_1; but since everyone else is logical, I know they’ve also deduced P_1, so now I know P_2… so continuing, I (along with everyone else) can now deduce P_k for /any/ k. (This is one of the weird things about how common knowledge works when everyone’s perfectly logical, and everyone knows that everyone’s logical, and so on…)")

#text("So the new information is (well, includes — there may be more) all the P_k’s bigger than I knew before. In the case where there are one or two blue-eyed islanders, it’s very intuitive that this is new information; for bigger k, P_k is a difficult statement to grasp, but the argument still holds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25552")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("By the way, Phillip: there’s a hole in your argument, if I’m not mistaken. You write:")

#text("—")#linebreak()#text(" Consider the day of birth (or better the day of religious initiation) of the third blue-eyed person. On that day A, B and C see each other. Person A knows that B knows that there are blue-eyed persons, because A knows that B can see C. The same holds for any permutation of A, B, C. So everybody knows that there are blue-eyed persons.")

#text("On the second day nobody commits suicide. Everybody can deduce from this fact that there are at least two blue-eyed islanders: If there was only one blue-eyed islander, (s)he would have committed suicide, because (s)he had encountered to be the only person with blue eyecolor. Furthermore everybody knows that everybody can deduce from this fact that there are at least two blue-eyed persons on the island. The lower bound of two is now “common knowledge”.")

#text("On the third day nobody commits suicide. Everybody can deduce from this fact that there are at least three blue-eyed islanders: If there were only two blue-eyed islanders, they would have committed suicide, because they would have known that they are among the two blue-eyed persons. It is now common knowledge that there are at least three islanders with blue eyes.")#linebreak()#text(" —")

#text("How does an islander (A, say) know there are at least 3? You say he can argue: if if there were only two, then they would have committed suicide. Why should they have? Well, if there were only two, and they each knew there were at least two, then they would know they’re among them. But if there were only two others, they wouldn’t each know that there were at least two!")

#text("You’ve argued why everyone knows that there are at least two, but you worked from the external knowledge that all three of them are blue-eyed. A doesn’t have this knowledge, so can’t go through the same reasoning, so doesn’t deduce on the third day that there are at least three.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Part of the issue is the that the problem is very sensitive to rephrasal.")

#text("Peter’s argument is a good start. Ideally, the problem should be worded so that P_100 can clearly be deduced.")

#text("But you also need something else but similar. The problem says:")

#text("“All the tribespeople are highly logical and highly devout, and they all know that each other is also highly logical and highly devout.”")

#text("This is insufficient.")#linebreak()#text(" If Q_1 = “All the tribespeople are highly logical and highly devout” and Q_(K+1) = “All the tribespeople know Q_K”. You need both P_K and Q_K to prove the Kth step of the induction. So we need to have Q_100 as well. The problem as stated only gives Q_2, which is not powerful enough.")

#text("Unrelatedly, when I was an undergraduate, I knew a professor who claimed very adamantly that this problem was “not mathematics.” I never really understood why he cared so much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25556")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("In Phillip’s argument, everybody knows there is a blue eyed person on the island, and everybody knows everybody knows there is a blue eyed person on the island, and so on; but for any given person Bob, a person Bob knows having blue eyes is never Bob, Bob precisely knows everyone else’s eye color. But the foreigner’s message has a different meaning, it just says somebody has blue eyes, nothing specific. Now for any given Bob, he knows somebody has blue eyes, himself included, and he knows that everybody knows so.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25558")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("My english is not good … sorry…")

#text("I think the foreigner information is really important. Because we have two different things here: 1) you know the possibility about your eye (it’s blue or not) and 2) you know that everybody knows about blue-eyed. Before the information, you know only 1), but you don’t discuss about eyes with your friends, so you don’t know what they know about eyes. But after the foreigner’s information you know you know that everybody knows.")

#text("So I think argument 2 is correct… The tribe consists of 1000 people, and")#linebreak()#text(" n=100")

#text("1) I am blue-eyed: I can see 99 blue-eyed. So in the 100 day, each blue-eyed person sees 99 blue-eyed and nobody in tribe dies ! So I am blue-eyed and committed suicide.")#linebreak()#text(" 2) I am not blue-eyed: I can see 100 blue-eyed. I will wait until the 101 day. But in 100 day everybody with blue-eye is dead, if I am a blue-eyed I have to be dead in the 100 day because blue-eyed people saw only 99 blue-eyed and not 100 like me. So, I don’t have blue eye (If I conclude somehow that I am brown-eyed I have to commit suicide)")#linebreak()#text(" * no one committed suicide in days < n.")

#text("But I’m thinking about that… the foreigner have a wife and he writes in the letter “how unusual it is to see another blue-eyed person like myself in this region of the world and another red-eyed such my wife”.")#linebreak()#text(" and the tribe consists of 1100, 100 blue-eyed, 100 red-eyed and 900 brown-eyed")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25560")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Does there any red- eyed person exist? :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ab3c34aedee5b5910eb0e5de0baf4adf6a20f915d725f1881913c5b42a796a-6258bcbe1f32f9bfc8e69d744b69ea33223c6c9407cdb9bf89d478a1b0acb8b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of christine")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25561")[#strong[#text("christine")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("terry, i don’t get it. is this supposed to be a fun puzzle? :/")

#text("hehe. niki and i watched a movie this weekend and thought of u. guess which one?! :P")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vlk")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25562")[#strong[#text("vlk")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I don’t see what the foreigner has to do with anything. Since everybody can see everybody else’s eyes, they should all have an accurate count of the respective populations except for their own. So a blue-eyed person will see that there are 900 browns and 99 blues, and a brown-eyed person will see that there are 899 browns and 100 blues. After 100 days, every blue will realize that none of the other blues have killed themselves, so there must be 100 blues, and so everyone that can see 900 browns will realize that they must be one of the blues, and will therefore kill themselves on day 101. Now, the browns will realize that there are no blues left, because they have all killed themselves, so everyone that is left must be browns, and will kill themselves on day 102.")

#text("So the foreigner’s sole function seems to be set up the problem, and perhaps a timer, by having everybody assemble in one place so they can get an accurate count of the populations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25569")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("No, without the foreigner there would not be a “mass suicide”.")

#text("If there is only one blue eyed person then he would not know his eye color and the others would not tell him.")

#text("If there are two blue eyed person then each of them knows that the other’s eyes are blue but they cannot be certain that everybody on the island knows there is at least on blue eyed person.")

#text("If there are three or more blue eyed person then everybody knows there is at least one blue eyed person on the island, and everybody knows everybody knows and so on. But the induction has to start at n=3 because for the cases n=1 and n=2 are special from this point of view. If n=3 the suicide occurs after 4 days, then the suicide will occur for any n>=3. But for n=3 there will not be any suicide because in order to imply from the fact that there was no suicide for last 3 days that there are 3 blue eyed person on the island, one has to go through n=1 and n=2 cases and we know it does not work for n=1 ad n=2 unless there is a foreigner announcing somebody has blue eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0106d1a51149435c0e7cc34d90e8026547a432e9bf1348c67b9eb9712116364-f26191209d651bb87abe0695a0206e6e25995780d590cc394681eab053fdce6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richard borcherds")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25573")[#strong[#text("richard borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("This puzzle occurs in the book “puzzle math” by G. Gamow (as in big bang) and Stern, with an extra twist at the end. In response to concerns about unfaithful wives a sultan announces that anyone may kill his unfaithful wife. (This was in pre PC days.) 40 nights later 40 wives are killed much to the puzzlement of the vizier, who has the solution explained to him by the sultan. It ends by the sultan saying “I am glad that you finally understand the situation. It is nice to have a vizier whose intelligence is so much inferior to that of the average citizen. But what if I tell you that the reported number of unfaithful wives was actually forty-one?”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian (the first \"Anonymous\" who started this trouble))")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25577")[#strong[#text("Jian (the first \"Anonymous\" who started this trouble))")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Ryan Reich,")

#text("I understood the induction, but I wasn’t sure of its necessity. To reformulate the puzzle to make it more intuitive, the presence of the brown eyeds doesn’t affect the logic, so we can get rid of them:")

#text("There are 100 blue eyeds (and only blue eyeds) in the island, one day a vistitor tells them that there exists blue eyed(s) among them. Then all 100 islanders will kill themselves (Or just leave the island in order to make the puzzle less bloody)? No way… Math can be counter-intuitive but irrational!")

#text("“There exists blue eyed(s)” is such a fact that each islander can assume it as “common knowledge”, (Can someone give a reason why this can be not a common knowledge given that everyboby sees only blue eyeds in the island?) don’t you think? There must be something went wrong in our reasoning. I tend to think that it is some kind of limitation in mathematics in describing reality (just like in the millitary exercise puzzle (see post of 11:25 am)). I can see the cases of n = 1,2,3… (One can just reason without induction). Perhaps for some strange number (such as strange primes, etc.) the reasoning can no more close, or “common knowledge” (which seems like a very artificial concept too) will be left with some gap. I am unable to pin point it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25578")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I’m not a mathematician but a physicist, so I may be wrong, but I think that mathematical induction can’t be used here. The reason is that you start with case n=1, and then you prove that n follows from n-1. But the case n=1 is impossible in this story, because everyone at the island can see that there is more than one person with blue eyes. To use induction, I think we would have to prove this for some other n, for example n=2, and then show that n follows from n-1. I haven’t thought that much about it, but I think that for n=2 they can’t just figure it out based on the fact that the stranger said that there is at least one person with blue eyes, because everyone on the island sees at least one other person with blue eyes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25583")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Marko,")

#text("I am with you that Induction may not be valid here (though perhaps for a different reason). But I also question the legitimacy of “common knowledge”, it just seems too artificial a concept.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25586")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Math is dangerous!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25593")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("because of its foolishness combined with its power!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25598")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I was just wondering if the islanders know there are only two eye colors among them. If they don’t know then the brown eyed ones will not do suicide after the blue eyed ones did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25599")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Jian,")

#text("Please do not be too upset. The point is just to illustrate some concept, nobody is trying to make people do suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25601")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Jian,")

#text("honestly I don’t think that math is foolish and danegerous. t8m8r is right, don’t get too upset :-)")

#text("I thought some more about what I said. I think the case n=3 should be proved first and then if we can prove by induction that n follows from n-1 they would all commit suicide. If there were only 2 people with blue eyes then n=1 is still possible, because each of the blue eyes sees only one other and doesn’t know if that’s the only one, and induction is ok. However if n=3 everyone can see at least 2, and I think that they can’t start reasoning from n=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jian")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25602")[#strong[#text("Jian")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear t8m8r,")

#text("Thanks.")

#text("Dear all,")

#text("Please do consider the reformulation that there are only blue eyeds in the island (my post of 9:40 pm) (Or show that it is not logically equivelant to the original puzzle). This makes the problem much simpler in showing the ligitimacy of “common knowledge”. When everybody sees only blue eyeds, I just don’t see how “there exists blue eyed(s)” not automatically a “common knoledge” and takes a visitor to create it…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25603")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I just looked over some of the posts that I’ve missed, and I saw that t8m8r in his 9:05 pm post has a similar argument to what I said, the difference though is that, if I interpret his post correctly, he thinks that after the foreigner makes the statement the inhabitants will commit suicide, so his statement makes a difference, whereas I think that the foreigner’s statement doesn’t make a difference and the inhabitants won’t commit suicide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25604")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("I think it is because if you consider someone specific, he/she can really name the persons who have blue eyes in his/her knowledge. He/she does not know about his/her eye color. But when the voyager says someone has blue eyes, there is a possibility that he/she has blue eyes too. It kind of uniformizes the knowledge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25605")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2008")])]

#text("Dear Marko,")

#text("If the foreigner makes the statement, you can start the induction at n=1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf96ffefbeb5fe60d802b0545d1c33272fc56199071bc3e44ad2e67e8e8927d7-9ea472afe3278b22bc85707dcd14fe9eb418b48e7ff896669c4d4b199565a3f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Odd Man Out")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25611")[#strong[#text("Odd Man Out")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Argument 2 is invalidated by the fact that there will be some brown-eyed people that will think that he was referring to them (assuming people will assume he was talking to a specific person), and without the ability to verify the information, they’d commit suicide as well; it doesn’t account for the human factor.")

#text("The most likely outcome is argument 1 because, as stated above, there is no way to verify who the foreigner was talking to. So, they just go on not knowing anything new.")

#text("However, depending on how the tribe views others rights to hold different belief systems, they may “insist” that he commit suicide the next day for speaking about eye colour.")

#text("@John Armstrong:")

#text("You are incorrect assuming that if one committed suicide that the next day everyone else would. There may have be a different reason why they are killing themselves, such as, making the faux pas on there own earlier or later in the day i.e. there is no way to know if they are killing themselves because of what the foreigner said.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marko")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25612")[#strong[#text("Marko")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Odd Man Out,")

#text("the argument doesn’t apply to the brown eyed people, because they see one more blue-eyed person than the blue people, so for example if there are n blue-eyed, the brown eyed will see n but the blue eyed will see n-1. So when no one commits suicide on the n-1 st day all of the n blue eyed people will commit suicide on the nth. From the point of view of the brown-eyed people they see n people committing suicide on the nth day, and they conclude that they don’t have blue eyes. Also, I think that for the problem it’s safe to assume that people only commit suicide because they figure out their eye color, and not for other reason.")

#text("I said before that I don’t think that the people will commit suicide, but I’m not so sure anymore. I have to think some more. Interesting puzzle!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Barks")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25614")[#strong[#text("Barks")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Argument 1 is wrong since the traveller")#linebreak()#text(" adds a crucial bit of information in the case n=1")#linebreak()#text(" (for the poor sap n). It is the logical consequences")#linebreak()#text(" of this single bit of information that leads to Ragnarök.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390f81bc403abbaa8705d528326b2523fa57d0b8d96a8625fdf3137195984de9-d72493108d6c1d94a82de1fb4c8ac5733837bfe3934e27530cdeee359b8b1909.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaennio")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25618")[#strong[#text("nicolaennio")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("I do not understand the point of Phillip “Consider the day of birth (or better the day of religious initiation) of the third blue-eyed person. On that day A, B and C see each other. Person A knows that B knows that there are blue-eyed persons, because A knows that B can see C. The same holds for any permutation of A, B, C. So everybody knows that there are blue-eyed persons.”. Because if A see B and C he knows that there are two blue-eyed people, but he cannot know that B and C know the same thing (indeed if he knew it he could magically know its own eye color!). The foreign is used for breaking this chain of disinformation. Interesting concept, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8909c1c488a23a7dcb33e311381bb9df7751f1f30839d6ec63f333907e08173-d29df98df64373835b252e2a855a40d3c92b8c934d61cdf1278504905e5c724c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aus")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25619")[#strong[#text("Aus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Well, first of all, I don’t think the tribe can know that there are 100 blue-eyed people and 900 blue-eyed people. If so, everybody should commit suicide long time before, because you can see the rest of people. So, I think the remark will not take any effect.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8909c1c488a23a7dcb33e311381bb9df7751f1f30839d6ec63f333907e08173-d29df98df64373835b252e2a855a40d3c92b8c934d61cdf1278504905e5c724c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aus")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25620")[#strong[#text("Aus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Sorry. 900 “brown-eyed”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f873927f0e7025052194d795663c26d2f858e7fb56718eba3ee67066afa5e59-c8b7c6630a17c9f2e5fde787d0b82b1063728a374c51b93ed271ffb629f6ebfb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arjun Ramakrishnan")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25623")[#strong[#text("Arjun Ramakrishnan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Prof Tao,")

#text("I guessed the first part, but the second part was quite non-intuitive. On the other hand, a friend of mine found it quite simple")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8909c1c488a23a7dcb33e311381bb9df7751f1f30839d6ec63f333907e08173-d29df98df64373835b252e2a855a40d3c92b8c934d61cdf1278504905e5c724c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aus")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25624")[#strong[#text("Aus")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("Oh, I was silly. Off course they don’t know that there are 100 blue and 900 brown.")

#text("Then, both wrong. On the first day nobody dies. On 99th day nobody dies. On 100th day blue-eyed people all dies. On 101th day, brown-eyed people will not commit suicide even though they are not sure of their eye colour.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bjoern S.")]], [#link("https://terrytao.wordpress.com/2008/02/05/the-blue-eyed-islanders-puzzle/comment-page-1/#comment-25626")[#strong[#text("Bjoern S.")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2008")])]

#text("there at least two simple ways to save the role of the stranger and therefore the puzzle")

#text("one:")#linebreak()#text(" if you restrict the suicidal-rule to blue-eye-people only")#linebreak()#text(" and assume the villagers dont know what blue eyes look like initually")

#text("two:")#linebreak()#text(" we assume that the normal village life is quite boring, and consist of sleeping and working only")#linebreak()#text(" so the day the visiter arrived was the first day they hab a party, and therefore were able to see each other simultainously")
]
