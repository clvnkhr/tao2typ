// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/
// Converted to Typst by tao2typ: "2026-10-14T07:17:39.608422+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Decomposing a factorial into large factors", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Decomposing a factorial into large factors")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 March 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")[#text("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv the paper “")#link("https://arxiv.org/abs/2503.20170")[#text("Decomposing a factorial into large factors")]#text("“. This paper studies the quantity ")#mi("{t(N)}")#text(", defined as the largest quantity such that it is possible to factorize ")#mi("{N!}")#text(" into ")#mi("{N}")#text(" factors ")#mi("{a_1, \\dots, a_N}")#text(", each of which is at least ")#mi("{t(N)}")#text(". The first few values of this sequence are")

#align(center)[#tao-fit-display[#mitex("1,1,1,2,2,2,2,2,3,3,3,3,3,4, \\dots")]]

#text("(")#link("https://oeis.org/A034258")[#text("OEIS A034258")]#text("). For instance, we have ")#mi("{t(9)=3}")#text(", because on the one hand we can factor")

#align(center)[#tao-fit-display[#mitex("9! = 3 \\times 3 \\times 3 \\times 3 \\times 4 \\times 4 \\times 5 \\times 7 \\times 8")]]

#text("but on the other hand it is not possible to factorize ")#mi("{9!}")#text(" into nine factors, each of which is ")#mi("{4}")#text(" or higher.")

#text("This quantity ")#mi("{t(N)}")#text(" was introduced by Erdös, who asked for upper and lower bounds on ")#mi("{t(N)}")#text("; informally, this asks how equitably one can split up ")#mi("{N!}")#text(" into ")#mi("{N}")#text(" factors. When factoring an arbitrary number, this is essentially a variant of the notorious ")#link("https://en.wikipedia.org/wiki/Knapsack_problem")[#text("knapsack problem")]#text(" (after taking logarithms), but one can hope that the specific structure of the factorial ")#mi("{N!}")#text(" can make this particular knapsack-type problem more tractable. Since")

#align(center)[#tao-fit-display[#mitex("N! = a_1 \\dots a_N \\geq t(N)^N")]]

#text("for any putative factorization, we obtain an upper bound")

#metadata(none) <tao-5f2b1d6f5492140fa7b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("t(N) \\leq (N!)^{1/N} = \\frac{N}{e} + O(\\log N)")]]

#text("thanks to the Stirling approximation. At one point, Erdös, Selfridge, and Straus claimed that this upper bound was asymptotically sharp, in the sense that")

#metadata(none) <tao-38d85d578d525ce72b10>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("t(N) = \\frac{N}{e} + o(N)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text("; informally, this means we can split ")#mi("{N!}")#text(" into ")#mi("{N}")#text(" factors that are (mostly) approximately the same size, when ")#mi("{N}")#text(" is large. However, as reported in ")#link("https://zbmath.org/0871.11003")[#text("this later paper")]#text(", Erdös “believed that Straus had written up our proof… Unfortunately Straus suddenly died and no trace was ever found of his notes. Furthermore, we never could reconstruct our proof, so our assertion now can be called only a conjecture”.")

#text("Some further exploration of ")#mi("{t(N)}")#text(" was conducted ")#link("https://zbmath.org/0918.11013")[#text("by Guy and Selfridge")]#text(". There is a simple construction that gives the lower bound")

#align(center)[#tao-fit-display[#mitex("t(N) \\geq \\frac{3}{16} N - o(N)")]]

#text("that comes from starting with the standard factorization ")#mi("{N! = 1 \\times 2 \\times \\dots \\times N}")#text(" and transferring some powers of ")#mi("{2}")#text(" from the later part of the sequence to the earlier part to rebalance the terms somewhat. More precisely, if one removes one power of two from the even numbers between ")#mi("{\\frac{3}{8}N}")#text(" and ")#mi("{N}")#text(", and one additional power of two from the multiples of four between ")#mi("{\\frac{3}{4}N}")#text(" to ")#mi("{N}")#text(", this frees up ")#mi("{\\frac{3}{8}N + o(N)}")#text(" powers of two that one can then distribute amongst the numbers up to ")#mi("{\\frac{3}{16} N}")#text(" to bring them all up to at least ")#mi("{\\frac{3}{16} N - o(N)}")#text(" in size. A more complicated procedure involving transferring both powers of ")#mi("{2}")#text(" and ")#mi("{3}")#text(" then gives the improvement ")#mi("{t(N) \\geq \\frac{1}{4} N - o(N)}")#text(". At this point, however, things got more complicated, and the following conjectures were made by Guy and Selfridge:")

#list(
[#text("(i) Is ")#mi("{\\frac{t(N)}{N} \\leq \\frac{1}{e}}")#text(" for all ")#mi("{N \\neq 1,2,4}")#text("?")],
[#text("(ii) Is ")#mi("{t(N) \\geq \\lfloor 2N/7 \\rfloor}")#text(" for all ")#mi("{N \\neq 56}")#text("? (At ")#mi("{N=56}")#text(", this conjecture barely fails: ")#mi("{t(56) = 15 < 16 = \\lfloor 2 \\times 56/7 \\rfloor}")#text(".)")],
[#text("(iii) Is ")#mi("{\\frac{t(N)}{N} \\geq \\frac{1}{3}}")#text(" for all ")#mi("{N \\geq 300000}")#text("?")]
)

#text("In this note we establish the bounds ")#metadata(none) <tao-5e1cf42878df58fea7bf>#mi("\\displaystyle  \\frac{1}{e} - \\frac{O(1)}{\\log N} \\leq \\frac{t(N)}{N} \\leq \\frac{1}{e} - \\frac{c_0+o(1)}{\\log N} \\ \\ \\ \\ \\ (3)")#text(" ")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{c_0}")#text(" is the explicit constant")

#align(center)[#tao-fit-display[#mitex("c_0 := \\frac{1}{e} \\int_0^1 \\left \\lfloor \\frac{1}{x} \\right\\rfloor \\log \\left( ex \\left \\lceil \\frac{1}{ex} \\right\\rceil \\right)\\ dx \\approx 0.3044.")]]

#text("In particular this recovers the lost result ")#link(<tao-38d85d578d525ce72b10>)[#text("(2)")]#text(". An upper bound of the shape")

#metadata(none) <tao-8f455bba4522752c63bb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{t(N)}{N} \\leq \\frac{1}{e} - \\frac{c+o(1)}{\\log N}")]]

#text("for some ")#mi("{c>0}")#text(" was previously conjectured ")#link("https://zbmath.org/0434.10001")[#text("by Erdös and Graham")]#text(" (")#link("https://www.erdosproblems.com/391")[#text("Erdös problem #391")]#text("). We conjecture that the upper bound in ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(3)")]#text(" is sharp, thus")

#metadata(none) <tao-8f24402b95530852c7bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{t(N)}{N} = \\frac{1}{e} - \\frac{c_0+o(1)}{\\log N},")]]

#text("which is consistent with the above conjectures (i), (ii), (iii) of Guy and Selfridge, although numerically the convergence is somewhat slow.")

#text("The upper bound argument for ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(3)")]#text(" is simple enough that it could also be modified to establish the first conjecture (i) of Guy and Selfridge; in principle, (ii) and (iii) are now also reducible to a finite computation, but unfortunately the implied constants in the lower bound of ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(3)")]#text(" are too weak to make this directly feasible. However, it may be possible to now crowdsource the verification of (ii) and (iii) by supplying a suitable set of factorizations to cover medium sized ")#mi("{N}")#text(", combined with some effective version of the lower bound argument that can establish ")#mi("{\\frac{t(N)}{N} \\geq \\frac{1}{3}}")#text(" for all ")#mi("{N}")#text(" past a certain threshold. The value ")#mi("{N=300000}")#text(" singled out by Guy and Selfridge appears to be quite a suitable test case: the constructions I tried fell just a little short of the conjectured threshold of ")#mi("{100000}")#text(", but it seems barely within reach that a sufficiently efficient rearrangement of factors can work here.")

#text("We now describe the proof of the upper and lower bound in ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(3)")]#text(". To improve upon the trivial upper bound ")#link(<tao-5f2b1d6f5492140fa7b4>)[#text("(1)")]#text(", one can use the large prime factors of ")#mi("{N!}")#text(". Indeed, every prime ")#mi("{p}")#text(" between ")#mi("{N/e}")#text(" and ")#mi("{N}")#text(" divides ")#mi("{N!}")#text(" at least once (and the ones between ")#mi("{N/e}")#text(" and ")#mi("{N/2}")#text(" divide it twice), and any factor ")#mi("{a_i}")#text(" that contains such a factor therefore has to be significantly larger than the benchmark value of ")#mi("{N/e}")#text(". This observation already readily leads to some upper bound of the shape ")#link(<tao-8f455bba4522752c63bb>)[#text("(4)")]#text(" for some ")#mi("{c>0}")#text("; if one also uses the primes ")#mi("{p}")#text(" that are slightly less than ")#mi("{N/e}")#text(" (noting that any multiple of ")#mi("{p}")#text(" that exceeds ")#mi("{N/e}")#text(", must in fact exceed ")#mi("{\\lceil N/ep \\rceil p}")#text(") is what leads to the precise constant ")#mi("{c_0}")#text(".")

#text("For previous lower bound constructions, one started with the initial factorization ")#mi("{N! = 1 \\times \\dots \\times N}")#text(" and then tried to “improve” this factorization by moving around some of the prime factors. For the lower bound in ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(3)")]#text(", we start instead with an approximate factorization roughly of the shape")

#align(center)[#tao-fit-display[#mitex("N! \\approx (\\prod_{t \\leq n < t + 2N/A, \\text{ odd}} n)^A")]]

#text("where ")#mi("{t}")#text(" is the target lower bound (so, slightly smaller than ")#mi("{N/e}")#text("), and ")#mi("{A}")#text(" is a moderately sized natural number parameter (we will take ")#mi("{A \\asymp \\log^3 N}")#text(", although there is significant flexibility here). If we denote the right-hand side here by ")#mi("{B}")#text(", then ")#mi("{B}")#text(" is basically a product of ")#mi("{N}")#text(" numbers of size at least ")#mi("{t}")#text(". It is not literally equal to ")#mi("{N!}")#text("; however, an easy application of ")#link("https://en.wikipedia.org/wiki/Legendre%27s_formula")[#text("Legendre’s formula")]#text(" shows that for odd small primes ")#mi("{p}")#text(", ")#mi("{N!}")#text(" and ")#mi("{B}")#text(" have almost exactly the same number of factors of ")#mi("{p}")#text(". On the other hand, as ")#mi("{B}")#text(" is odd, ")#mi("{B}")#text(" contains no factors of ")#mi("{2}")#text(", while ")#mi("{N!}")#text(" contains about ")#mi("{N}")#text(" such factors. The prime factorizations of ")#mi("{B}")#text(" and ")#mi("{N!}")#text(" differ somewhat at large primes, but ")#mi("{B}")#text(" has slightly more such prime factors as ")#mi("{N!}")#text(" (about ")#mi("{\\frac{N}{\\log N} \\log 2}")#text(" such factors, in fact). By some careful applications of the prime number theorem, one can tweak some of the large primes appearing in ")#mi("{B}")#text(" to make the prime factorization of ")#mi("{B}")#text(" and ")#mi("{N!}")#text(" agree almost exactly, except that ")#mi("{B}")#text(" is missing most of the powers of ")#mi("{2}")#text(" in ")#mi("{N!}")#text(", while having some additional large prime factors beyond those contained in ")#mi("{N!}")#text(" to compensate. With a suitable choice of threshold ")#mi("{t}")#text(", one can then replace these excess large prime factors with powers of two to obtain a factorization of ")#mi("{N!}")#text(" into ")#mi("{N}")#text(" terms that are all at least ")#mi("{t}")#text(", giving the lower bound.")

#text("The general approach of first locating some approximate factorization of ")#mi("{N!}")#text(" (where the approximation is in the “adelic” sense of having not just approximately the right magnitude, but also approximately the right number of factors of ")#mi("{p}")#text(" for various primes ")#mi("{p}")#text("), and then moving factors around to get an exact factorization of ")#mi("{N!}")#text(", looks promising for also resolving the conjectures (ii), (iii) mentioned above. For instance, I was numerically able to verify that ")#mi("{t(300000) \\geq 90000}")#text(" by the following procedure:")

#list(
[#text("Start with the approximate factorization of ")#mi("{N!}")#text(", ")#mi("{N = 300000}")#text(" by ")#mi("{B = (\\prod_{90000 \\leq n < 102000, \\text{ odd}} n)^{50}}")#text(". Thus ")#mi("{B}")#text(" is the product of ")#mi("{N}")#text(" odd numbers, each of which is at least ")#mi("{90000}")#text(".")],
[#text("Call an odd prime ")#mi("{B}")#text("-heavy if it divides ")#mi("{B}")#text(" more often than ")#mi("{N!}")#text(", and ")#mi("{N!}")#text("-heavy if it divides ")#mi("{N!}")#text(" more often than ")#mi("{B}")#text(". It turns out that there are ")#mi("{14891}")#text(" more ")#mi("{B}")#text("-heavy primes than ")#mi("{N!}")#text("-heavy primes (counting multiplicity). On the other hand, ")#mi("{N!}")#text(" contains ")#mi("{2999992}")#text(" powers of ")#mi("{2}")#text(", while ")#mi("{B}")#text(" has none. This represents the (multi-)set of primes one has to redistribute in order to convert a factorization of ")#mi("{B}")#text(" to a factorization of ")#mi("{N!}")#text(".")],
[#text("Using a greedy algorithm, one can match a ")#mi("{B}")#text("-heavy prime ")#mi("{p^{\\prime}}")#text(" to each ")#mi("{N!}")#text("-heavy prime ")#mi("{p}")#text(" (counting multiplicity) in such a way that ")#mi("{p^{\\prime} \\leq 2^{m_p} p}")#text(" for a small ")#mi("{m_p}")#text(" (in most cases one can make ")#mi("{m_p=0}")#text(", and often one also has ")#mi("{p^{\\prime}=p}")#text("). If we then replace ")#mi("{p^{\\prime}}")#text(" in the factorization of ")#mi("{B}")#text(" by ")#mi("{2^{m_p} p}")#text(" for each ")#mi("{N!}")#text("-heavy prime ")#mi("{p}")#text(", this increases ")#mi("{B}")#text(" (and does not decrease any of the ")#mi("{N}")#text(" factors of ")#mi("{B}")#text("), while eliminating all the ")#mi("{N!}")#text("-heavy primes. With a somewhat crude matching algorithm, I was able to do this using ")#mi("{\\sum_p m_p = 39992}")#text(" of the ")#mi("{299992}")#text(" powers of ")#mi("{2}")#text(" dividing ")#mi("{N!}")#text(", leaving ")#mi("{260000}")#text(" powers remaining at my disposal. (I don’t claim that this is the most efficient matching, in terms of powers of two required, but it sufficed.)")],
[#text("There are still ")#mi("{14891}")#text(" ")#mi("{B}")#text("-heavy primes left over in the factorization of (the modified version of) ")#mi("{B}")#text(". Replacing each of these primes with ")#mi("{2^{17} \\geq 90000}")#text(", and then distributing the remaining ")#mi("{260000 - 17 \\times 14891 = 6853}")#text(" powers of two arbitrarily, this obtains a factorization of ")#mi("{N!}")#text(" into ")#mi("{N}")#text(" terms, each of which are at least ")#mi("{90000}")#text(".")]
)

#text("However, I was not able to adjust parameters to reach ")#mi("{t(300000) \\geq 100000}")#text(" in this manner. Perhaps some readers here who are adept with computers can come up with a more efficient construction to get closer to this bound? If one can find a way to reach this bound, most likely it can be adapted to then resolve conjectures (ii) and (iii) above after some additional numerical effort.")

#text("UPDATE: There is now an ")#link("https://github.com/teorth/erdos-guy-selfridge")[#text("active Github project")]#text(" to track the latest progress, coming from multiple contributors.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (83)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2025")])]

#text("there is an open brace for href")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/392d4ba7a1da60a14a41e91346e1c55d50c0a0d19f1c10a7227edd4ede8cede1-10dfa50494184a809919ed36e8eeb7e6d079b4a690b900c085f100ef9fa88c31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samuel Bonaya Buya")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687562")[#strong[#text("Samuel Bonaya Buya")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2025")])]

#text("In my opinion the paper is a significant contribution by Tao on the understanding of the prime number theorem")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687735")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2025")])]

#text("No it’s not")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687564")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("Looking at the first few numbers in the OEIS sequence, it looks like t(n+1) – t(n) is always zero or one. Is there any reason for this to be true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687568")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("No; in fact, in Guy’s article on this problem, he notes that there is a jump of ")#mi("2")#text(" from ")#mi("t(124)=35")#text(" to ")#mi("t(125)=37")#text(" (though he does not provide enough preceding values to extend the sequence in the OEIS). In that article he also notes that Erdos conjectures that the gaps can in fact be arbitrarily large, though I see no way to attack this question even heuristically (as the extremizers for this problem may be neither structured nor (pseudo)random, but exhibit some very strange intermediate behavior).")

#text("In the image below, I display the upper bound on ")#mi("t(N)/N")#text(" (the pink dots) in the intermediate range ")#mi("80 \\leq N \\leq 599")#text(" coming from Lemma 2.1 of my paper (there is no plot for ")#mi("t(N)/N")#text(" in this image as I do not have data in this range). [Incidentally there is a slight typo in that lemma, which I will correct in the next revision: the term ")#mi("\\sqrt{t}+1")#text(" should instead be ")#mi("\\lfloor \\sqrt{t} \\rfloor")#text(".] There is considerable fluctuation here (due to the corresponding fluctuation in the primes), which is also reflected in the related plot in Figure 2 of the paper. Of course, fluctuation in the upper bound for ")#mi("t(N)/N")#text(" does not imply fluctuation in the true value of ")#mi("t(N)/N")#text(", but it is perhaps evidence in that direction.")

#image("../assets/0989655316adea30a6a25177d76d2bc40e32ac0cda45ab47a405b948f717e3f9-cfbd5fcbd91b5661ddc3100c7d84567792bf548952df3f73553b8a2b8ce59e0f.png", width: 90%, alt: "Upper bound on t(N)/N")

#text("And below is a comparison of the upper bound against the true value of ")#mi("t(N)/N")#text(" in the range ")#mi("N \\leq 79")#text(":")

#image("../assets/684ba219adc0ad37b2c9b42e1ab85c9b37716a6c653fabcfdee736a6b71cc9ee-63175deb8dbfba6d8e56079ad6fb05e3fe651185aca3062c3c3a6ad67a621b31.png", width: 90%, alt: "Comparison of t(N)/N with upper bound")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb96bf20532183a3ea620cfa064fca6c1d53ff523416dc9f887eea471d862491-dbba911415218c684810308a174e23141ce476a277d84326347395ca647d0826.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687565")[#strong[#text("Ivan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("You may want to enclose the comma in curly brackets when it is used as a thousands separator so that ")#mi("LaTeX")#text(" does not generate extra space after it, e.g., ")#mi("300{,}000")#text(" instead of ")#mi("300,000")#text(" (p. 3 of the paper).")

#emph[#text("[Thanks, this will be done in the next revision of the ms -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687566")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("I don’t immediately see the connection to the knapsack problem. If we pick the non-dividable items to be the logs of the prime factors of N!, then the problem amounts to distributing *all* of these items into N knapsacks, such that each knapsack contains *at least* a value of t(N). This is quite different from the original knapsack problem where the goal is rather to select a *subset* of items, and maximize the value while remaining *below* the knapsack capacity. Is there a deeper or more natural connection that I am missing? Can further progress on this Erdos problem be expected to eventually yield insights on the knapsack problem, or is the relation between the two too distant for that to happen?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687569")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("It’s more accurate to say that the factorial problem is a *variant* of the knapsack problem; most directly, it corresponds to a knapsack problem with negative item sizes (and negative capacity in the backpack), which of course is not physically realistic (or intuitive), but it is possible that some of the knapsack algorithms that work for positive sizes and capacities can carry over to this new context with suitable modification. (For instance, I would guess that the problem of solving this sort of factoring problem for a general input number (rather than a factorial) is NP-complete, by some modification of the proof of NP-completeness of the knapsack problem.)")

#text("Note by the way that to solve the factorization problem, it suffices to distribute some subset of the log-primes into the knapsacks rather than all of them, since one can just add in the remaining log-primes arbitrarily to finish the job.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("At first view it looks that this is closer to a ")#link("https://en.wikipedia.org/wiki/Bin_packing_problem")[#text("Bin packing problem")]#text(" than to a knapsack problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Following your hint, it seems in fact that this problem is a special case of the ")#link("https://en.wikipedia.org/wiki/Bin_covering_problem")[#text("bin covering problem")]#text(", which is dual to the bin packing problem.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687571")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("That technique I think can be used to limit prime gaps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687572")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("Small typo: “multiples of four between 3/4 to N” ")#linebreak()#text("It should be 3/4N to N.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("I’m posting (with permission) some computational work by Andrew Sutherland, who implemented a greedy approach working through the prime factors ")#mi("p")#text(" of ")#mi("N!")#text(" in")#linebreak()#text("reverse order (with multiplicity), constucting integers of the form ")#mi("cp \\geq t")#text(" with ")#mi("c")#text(" chosen to be minimal subject to the constraint that it can be constructed from the divisors of ")#mi("N!")#text(" that still remain. For instance when ")#mi("N=300000")#text(", it is able to factor ")#mi("N!")#text(" into ")#mi("300372")#text(" numbers greater than or equal to ")#mi("100000")#text(", verifying the Guy-Selfridge conjecture at this value. The code (in Maple) is at ")#link("https://math.mit.edu/~drew/GuySelfridge.m")[#text("https://math.mit.edu/~drew/GuySelfridge.m")]#text(" . An earlier (less efficient) factorization with these parameters can be found at ")#link("https://math.mit.edu/~drew/ES300000.txt")[#text("https://math.mit.edu/~drew/ES300000.txt")]#text(" .")

#text("Andrew writes, ” It only takes about a few seconds on a fast machine so I was able to run it on all ")#mi("N")#text(" in ")#mi("[100000,500000]")#text(" and noticed that while it typically succeeds on ")#mi("N \\geq 300000")#text(", it still fails to prove ")#mi("t(N) \\geq N/3")#text(" in ")#mi("922")#text(" cases in ")#mi("[300000,500000]")#text(", including ")#mi("N")#text(" as large as ")#mi("490230")#text(". But it succeeds on every ")#mi("N")#text(" in ")#mi("[298344,300000]")#text(", so if the conjecture is true, it is still true if you replace ")#mi("300000")#text(" with ")#mi("298344")#text(" (probably this can be lowered a lot further, the greedy approach is not optimal).")

#text("I then tested the threshold ")#mi("\\lfloor 2N/7 \\rfloor")#text(" on all ")#mi("N")#text(" from ")#mi("5")#text(" to ")#mi("100000")#text(". It failed only for ")#mi("N = 56,182,200,207")#text("“.")

#text("With this data, one can now reduce conjecture (ii) to conjecture (iii) provided one can construct suitable factorizations of ")#mi("N!")#text(" to resolve the three remaining cases ")#mi("N = 182, 200, 207")#text(" (one also has to retest the range ")#mi("100000 < N \\leq 300000")#text(" but this should be straightforward, since there is now enough room that one should be able to sample this range quite sparsely, e.g., test the threshold ")#mi("\\lfloor 2N/7\\rfloor + 2000")#text(" for ")#mi("N")#text(" a multiple of ")#mi("7000")#text("). But the range ")#mi("N \\geq 300000")#text(" seems a bit more delicate, as the most direct greedy algorithm sometimes fails.")

#text("Andrew adds, “I think it’s possible that one might be able to turn this algorithm into an asymptotic bound. For sufficiently large prime divisors ")#mi("p")#text(" of ")#mi("N!")#text(", you can just take ")#mi("c = \\lceil T/p \\rceil")#text(" because ")#mi("c")#text(" will be small and there are plenty of powers of small primes initially available (and you can quantify this), and even if you focus just on the integers the algorithm constructs before it hits the first cofactor it cannot minimize you should get some constant factor of ")#mi("N")#text(" that might be bigger than ")#mi("1/4")#text(".”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687575")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("Andrew has kindly shared with me the lower bounds for ")#mi("t(N)")#text(" for ")#mi("80 \\leq N \\leq 600")#text(" given by this approach, and I have incorporated them into my previous plot here, showing the current upper (pink) and lower (blue) bounds on ")#mi("t(N)/N")#text(":")

#image("../assets/dc3832ad160d53514acce5bf8457221226fc84e168409a91ac95d8efd5d6ff87-484f3462a065ae97d1f6d194c993b79b2f63f786e60d457855b9cab109453974.png", width: 90%, alt: "Upper and lower bounds on t(N)/N")

#text("Note the verification of the conjecture ")#mi("t(N) \\geq \\lfloor 2N/7 \\rfloor")#text(" in this range for ")#mi("N \\neq 182, 200, 207")#text(". The data also replicates Guy’s reported values ")#mi("t(124)=35, t(125)=37")#text(", and suggests that the jumps in ")#mi("t")#text(" are indeed rather irregular. (The text file for the data can be found ")#link("https://terrytao.wordpress.com/wp-content/uploads/2025/03/tbounds.txt")[#text("here")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2025")])]

#text("shouldn’t lower bound also be a weakly increasing function?")

#text("…I guess that’s a post-processing step")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2025")])]

#mi("t(N)")#text(" is a weakly increasing function, but the ratio ")#mi("t(N)/N")#text(" can oscillate. Here is a plot of the unnormalized bounds: ")#image("../assets/6b47311649ff5168b92de1ef77c1714d6b614b1e062d099bb6e6ecbc8c41d7b8-ddbf48a5d51514ecc250649791c696bd44bbd08f3303bb7898088a579e2b844a.png", width: 90%, alt: "Unnormalized upper and lower bounds for t(N)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21c85bd4a565e088ef9d7a56e2fa6bf511adc15269b81d99269cafaae9d3f77f-bb7d97eb0d02548c3fb837ccc117e21bff5e25c2b39ba510aa69ffa3e3a35d40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of frobitzblog")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687579")[#strong[#text("frobitzblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2025")])]

#text("With a bit of fiddling by hand I was able to improve the factorizations for N=182,200,207, so now (ii) is confirmed up to 100,000. You can find the factorizations ")#link("https://math.mit.edu/~drew/ES182.txt")[#text("here")]#text(", ")#link("https://math.mit.edu/~drew/ES200.txt")[#text("here")]#text(", and ")#link("https://math.mit.edu/~drew/ES207.txt")[#text("here")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1147b8a2e9fefe16b45980723247e4ac51dc9a8c211b447ccd433b2f0ff45533-990149e2e36c44e854c979cce9f5764d80fee535aec0e9dd072342adc9b3fa60.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hideoutinstantab46bc0124")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687787")[#strong[#text("hideoutinstantab46bc0124")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2025")])]

#text("I personnally link this to Erdös-Tenenbaum’s formula")

#mi("\\displaystyle \\mathbb{E}[p_{\\min}(n)] = \\frac{e^{-\\gamma}\\log x}{\\log\\log x + M - \\frac{\\gamma}{2}} + O\\left(\\frac{\\log x}{(\\log\\log x)^2}\\right)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("Should inequality (4) have t(N)/N on the left-hand side (as opposed to just t(N))?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2025")])]

#text("A back of the envelope calculation suggests that the upper bound in my paper, if made explicit, would verify the conjecture ")#mi("t(N)/N \\geq 1/3")#text(" for roughly ")#mi("N \\geq 10^{11}")#text(". (There are particular inefficiencies when ")#mi("N/3")#text(" is slightly larger than a power of two, as it then becomes expensive to adopt strategies that save the powers of two for last.) So some additional constructions will be needed to cover the medium range ")#mi("3 \\times 10^5 \\leq N \\leq 10^{11}")#text(".")

#text("A natural idea to improve both the numerics and the asymptotics is to mix and match powers of 2 and 3 in the endgame when these are the only primes left to assign, taking advantage of the incommensurability of ")#mi("\\log 2")#text(" and ")#mi("\\log 3")#text(" to get more accurate matches to a target threshold. This does make the algorithms and analysis more complicated, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687608")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("After running Andrew’s code to verify ")#mi("t(300000) \\geq 100000")#text(" I noticed that the greedy algorithm exhausts the factors of 2 and 3 relatively early; by the time the algorithm reaches the prime 29, the factors of 2 and 3 are already gone and so one has to use primes 5 and higher to fill up the remaining factors. This is likely the main source of inefficiency in the direct greedy algorithm. Some sort of ad hoc modification of the greedy algorithm in which some preference is given to terms that avoid 2 and 3 may improve performance. If one can get to a final stage where only powers of 2 and 3 remain, then it may also make sense to switch from a greedy method to a linear programming method: specifically, if one wants to distribute ")#mi("2^a 3^b")#text(", one can locate the smallest ")#mi("2^{a_1} 3^{b_1} \\geq t")#text(" with ")#mi("a_1/b_1 \\geq a/b")#text(", and the smallest ")#mi("2^{a_2} 3^{b_2} \\geq t")#text(" with ")#mi("a_2/b_2 \\leq a/b")#text(", and express ")#mi("(a,b)")#text(" as an integer linear combination of ")#mi("(a_1,b_1)")#text(" and ")#mi("(a_2,b_2)")#text(" (plus a negligible error which one may simply discard) to get a pretty good factorization.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687609")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Currently, Andrew’s code permits one to factor ")#mi("N!")#text(" for ")#mi("N=300000")#text(" into ")#mi("N+372")#text(" factors greater than or equal to ")#mi("N/3")#text(", so one has a surplus of ")#mi("372")#text(" factors here. I am hoping that this surplus can be increased somewhat through some tweaking of the greedy algorithm, which should allow one to cover more ranges for the conjecture ")#mi("t(N) \\geq N/3")#text(". I have in mind something like this:")

#text("1. First, apply the greedy algorithm to remove all primes larger than, say, ")#mi("N/30")#text(". These primes will be problematic no matter what algorithm one chooses (it is rare for their multiples to be very close to ")#mi("N")#text(") and so one may as well dispose of them as efficiently as possible immediately.")#linebreak()#text(" 2. Now, take all the numbers between ")#mi("N/3")#text(" and (say) ")#mi("N/3 + 3000")#text(" that are coprime to both ")#mi("2")#text(" and ")#mi("3")#text(", and remove them from the remaining portion of ")#mi("N!")#text(" (only if they are available, of course). Iterate this greedily until no further such numbers can be removed. One should now be left with mostly copies of ")#mi("2")#text(" and ")#mi("3")#text(" and only a small number of remaining primes to allocate (the point being that the numbers between ")#mi("N/3")#text(" and ")#mi("N/3+3000")#text(" have a very similar distribution of prime factors to the numbers between ")#mi("1")#text(" and ")#mi("N")#text(", except at the large primes which we have just removed).")#linebreak()#text(" 3. Use the greedy algorithm again to eliminate all primes larger than ")#mi("3")#text(". This should leave a large pool of copies of ")#mi("2")#text(" and ")#mi("3")#text(".")#linebreak()#text(" 4. Use the linear programming method in the previous comment to group these copies of ")#mi("2")#text(" and ")#mi("3")#text(" into quantities ")#mi("2^a 3^b")#text(" slightly larger than ")#mi("N/3")#text(".")#linebreak()#text(" 5. Apply the greedy algorithm to clean up any leftovers.")

#text("Unfortunately I will not have time today to try to implement such a scheme, but perhaps other commenters could try this (or some other method) to improve upon the previous surplus of 372, which I think is a reasonable proxy for algorithmic efficiency. Note for this value of ")#mi("N")#text(" that ")#mi("\\log N! / \\log(N/3) \\approx N + 2570")#text(", which provides a hard upper limit for the surplus (and due to the large primes which can’t be multiplied to be close to ")#mi("N/3")#text(", the hard limit is actually a little less than this). Still, there is room for improvement beyond 372.")

#text("EDIT: by taking into account the amount by which all large primes will go over ")#mi("N/3")#text(" (see Lemma 2.1 of the paper; the gap between the LHS and RHS of (2.1), divided by ")#mi("\\log t")#text(", upper bounds the surplus), I now revise the theoretical upper limit for the surplus to just 454. So not as much room for improvement as I thought… the greedy algorithm is actually quite efficient! This also suggests that if the greedy algorithm fails significantly at some ")#mi("N")#text(" slightly larger than 300000, then the Guy-Selfridge conjecture may in fact be false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("I was able to get the surplus in the ")#mi("t(300000) \\geq 100000")#text(" verification up to 410 (")#link("https://terrytao.wordpress.com/wp-content/uploads/2025/03/output.txt")[#text("here")]#text(" is the list of factors) by an extremely ad hoc method; I had attempted to coax the greedy algorithm to set aside some powers of 2 and 3 for later use, which helped somewhat (I could improve 372 to 401 this way), but then by accidentally putting in some rather bad choices of parameters (which used up the powers of 2 and 3 prematurely), I mysteriously got an improvement to 410. It seems there are a lot of discontinuities in this problem; I am not sure how to systematize the search for better constructions.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("@")#strong[#text("Ivan")]#text(" Or even better; use num from the ")#link("https://ctan.org/pkg/siunitx")[#text("siunitx")]#text(" package (or qty for physical quantities) when typing numbers with more than four digits on either side of the decimal marker.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("I’ve only been experimenting with small factorials, but fractional improvements can be made by optimising the factorisation process.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2025")])]

#text("Sorry, that last post was mine.")

#text("I spent the day writing a php program to check t(N). The beauty is I don’t need to work out the entire factorial, only the products of two of its factors. It was a bit involved and has a few shortcomings, but it gets the job done. It flies through the lower numbers but struggles with higher T’s. I can see the primes appearing as the array iterates. I’m just an amateur, but it was fun to see the final result.")

#text("For example:")

#text("t(100): 29 = 3.448 (Script Execution Time = 0.426 sec).")

#text("t(300): 73 = 4.109 (58.697 sec).")

#text("t(600): 148 = 4.054 (3 min 46.433 sec).")

#text("I appreciate the skill of mathematicians like you who are able to improve t(n) with greater precision.")

#text("Alan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1cabdc6bbbe6fcc236e2010be2eb46d82a523466601d0f6857dbfd8e4132b71-96e32538d3a58371d310273c54e095adb3b57d1d97564a27ab0fd31de21892d4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jsahil730")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687635")[#strong[#text("jsahil730")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2025")])]

#text("Is it possible to share the source code?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687630")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2025")])]

#text("I’ve been thinking about the problem, and realise you need to break the factors down into its own factors to tackle the problem. I’ll use t(100) as an example. Ideally, if we weren’t dealing with whole numbers, the precise result would be 100! ° 1/100 = 37.992. 100/e = 36.787, which is very close. Interestingly, the number of identical products of two factors is 1737/4950 = 35.09%. My result of 29 is average and was based on the original factors, but I’ll explore one level deeper.")

#text("Alan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2025")])]

#text("the Spanner theorem : Distribution of the Composite numbers as Complement of the Primes in the set {1,2,3,4 …}")

#text("Jenda Vondra 2024")

#text("do you want it folks? .. just ask me nicely")

#text("gives the EXACT factorization of every composite number up to any number n .. each of these numbers is of course composed of the primes up to n/2 .. simply Eratothsenes seive(but only doing crossings out ONCE) .. computer does that for u .. primes are those numbers left uncrossed .. perfectly countable too .. since we count the composite numbers as we make them .. in sequential order of course")

#text("now of course to make these primes up to n .. we need to know the primes up n/2 .. seems hard .. but it’s not .. to get the primes up to n/2 .. we just use the same process as we used to get them up to n .. but start with knowing the primes up to n/4")

#text("should be getting obvious now .. that to get the primes up to n/4 .. we only need to know the primes up to n/8")

#text("once more .. to get the primes up to n/8 .. what do we need?")

#text("yes .. we only need the primes up to.. u guessed it .. n/16")

#text("the computer time is halved each time too .. lucky .. next list of primes we need is only up to n/32 to get them to n/16")

#text("so it goes on .. pretty soon we get back to the first prime .. number 2")

#text("so let’s go the other way .. use the multiplicative operation .. in order")

#text("the prime 2 .. gives the primes up to 4 .. namely 3")

#text("primes 2 and 3 by multiplicative operation(in orderly fashion) give the primes up to 8")

#text("primes 2 3 5 7 then give(same orderly multiplication with ONE crossing out each time)(remember the computer is recording the exact prime factorization by virtue of MAKING each composite number and writing down what it is)")

#text("so we get the primes 2 3 5 7 11 13 (n=16)")

#text("next lot written out is 2 3 5 7 11 13 17 19 23 29 31 (n=32)")

#text("and so on")

#text("In the case of some factorization of n! .. it’s a trivial quest")

#text("rhe Spanner theorem writes out each composite number prime factorization .. up to any number n! = N in polynomial time O(N) with the exponent on N being just less than 1 as N gets large")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2025")])]

#text("What do the + signs in subscripts mean in Proposition 3.1 in the paper? I cannot find this notation defined in the paper.")

#emph[#text("[")#mi("x_+ := \\max(x,0)")#text(" denotes the ")#link("https://en.wikipedia.org/wiki/Positive_and_negative_parts")[#text("positive part")]#text(" of ")#mi("x")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687641")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("I have written a heuristic that seems to work to improve the factorization compared to the greedy factorization. Whenever you use the largest remaining prime p you want to construct a factorization of i=n/(3p) if possible (otherwise, you try to construct i+1, i+2…). Suppose the factorization of i+1 uses less factors than the factorization of i then it could be a better choice to construct i+1 instead as we keep more smaller factors for the rest of the packing procedure.")

#text("Here is a link to a c++ code doing just that:")

#link("https://www.lirmm.fr/~mrosenfeld/things/test_v2.cpp")[#text("https://www.lirmm.fr/~mrosenfeld/things/test_v2.cpp")]

#text("The interesting part are the 3 lines 132-135.")

#text("For 300000, it gives a surplus of 393, which i can then slightly improve to a surplus of 415 by adding 62 occurrences of 2*2*2*2*2*5*5*5*5*5 (this part is completely ad-hoc) [ ")#link("https://www.lirmm.fr/~mrosenfeld/things/decomposition300000.out")[#text("https://www.lirmm.fr/~mrosenfeld/things/decomposition300000.out")]#text(" ]")

#text("For 490230, the same code (without the add-hoc trick), yields a surplus of 553 instead of having not enough factors [")#link("https://www.lirmm.fr/~mrosenfeld/things/decomposition490230.out")[#text("https://www.lirmm.fr/~mrosenfeld/things/decomposition490230.out")]#text("].")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("The process of increasing t(N) is complicated in that there are two ways to simplify: break down the number into two factors, or peform swaps of products. 9 can be broken down into 3×3, but 9×2 = 6*3 (9->6 and 2->3). They both increase t(9) to 3 but higher numbers would have to involve both processes in some ratio.")

#text("Alan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d256a2283220faacfd533450c93b05f00ad1a03fe71a7164de4795bf03f1af14-dce6fda6b35704263589652c87bde6a086ea98bff491b242a766200fb938dd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uhrmar")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687646")[#strong[#text("uhrmar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("I might be late to the party, but I was able to make the approach of Andrew Sutherland non-greedy using linear programming. Surprisingly, the solutions are ‘almost integral’ and quite good by just rounding down the fractional components. The residual factor (after dividing out the integral LP solution) can then be further processed using the greedy strategy.")

#text("This method finds for the benchmark problem ")#mi("N=300000")#text(", ")#mi("t(N)=100000")#text(" a solution with ")#mi("N+445")#text(" factors (which should be optimal, since the LP upper bound is 300445.8339878815.")

#text("I’ve published the code in this repository: ")#link("https://gitlab.com/uhrm/facfac")[#text("https://gitlab.com/uhrm/facfac")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")])]

#text("Thanks to both you and Matthieu for these (surprisingly efficient) numerical explorations! It now seems hopeful that we can verify the Guy-Selfridge conjecture at the scale of ")#mi("N=300000")#text(" (and I now suspect that the authors had some inkling that this was close to the threshold, given how narrow the margin of error is here).")

#text("Because ")#mi("(N/3)^{N+s} \\approx (N/3 + s \\log(N/3) / 3)^N")#text(", I would expect heuristically that a surplus of ")#mi("s")#text(" should allow one to raise the lower bound on the factors from ")#mi("N/3")#text(" to about ")#mi("N/3 + s \\log(N/3) / 3")#text(", and thus also automatically verify the conjecture for the next ")#mi("s \\log(N/3)")#text(" or so elements past ")#mi("N")#text(" from the monotone nature of ")#mi("t(N)")#text(". For instance for ")#mi("N = 300000")#text(" and ")#mi("s = 445")#text(" this predicts the ability to cover a range of about ")#mi("5000")#text(" or so. So one might estimate that to get from this up to say ")#mi("N = 10^6")#text(" one might need to perform one of these algorithms a couple hundred times, which seems quite feasible. As ")#mi("N")#text(" increases, I expect the available surplus to also increase at an eventually linear fashion (asymptotically it is ")#mi("N (1/e-1/3 - o(1))")#text(", with the error decaying at a logarithmic rate), so hopefully one can scale up to ")#mi("N = 10^7")#text(", ")#mi("N = 10^8")#text(", etc. at a subexponential rate. As I said before, my own theoretical arguments seem to kick in at about ")#mi("10^{11}")#text(", which may be slightly out of reach of brute forcing the remaining ranges, but perhaps these sorts of optimizations may also suggest a new construction to handle very large ")#mi("N")#text(" that one could also try to analyze theoretically. (I could imagine there being a speed/simplicity vs. strength tradeoff; there may be constructions that offer a small surplus, but are faster to compute numerically and also easier to analyze theoretically. So as ")#mi("N")#text(" increases and there is more surplus to play with one might transition into simpler and faster constructions.)")

#text("p.s. I have decided not to submit my paper for now in view of the ongoing numerical work. If it looks like we have a real shot at the Guy-Selfridge conjecture, then I would be happy to convert the paper into a collaborative project that incorporates both the theoretical analysis and numerical validation.")

#text("p.p.s. if the linear program provides a rigorous upper bound on ")#mi("t(N)")#text(" then it may now be possible to extend OEIS A034258 if the bound is tight enough to match the known constructions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ventullo")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687676")[#strong[#text("ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("Hi,")

#text("I took the ideas from this comment to validate ")#mi("t(N) >= N/3")#text(" for ")#mi("N \\in [3*10^5,  10^8]")#text(". It took about 7h22m in total. By the end, it took about 5 minutes to greedily compute a factorization for N ~ 10^8.")

#text("I used my own implementation of Sutherland’s greedy algorithm, together with a heuristic based on the comment. Instead of calculating surpluses, I set the target lower bound to be a little higher than ")#mi("N/3")#text(", something like ")#mi("N*(\\frac{1}{3}+\\epsilon)")#text(". Finding a solution thus validates the entire range ")#mi("[N, (1+3\\epsilon) N]")#text(". As for the choice of epsilon, I hardcoded it at .01 to start, bumped it up to .02 once ")#mi("N > 3*10^6")#text(", then bumped it to .03 once ")#mi("N > 3*10^7")#text(".")

#text("Occasionally the greedy algorithm fails, but that’s okay: just decrement N and try again. It usually doesn’t take too many retries to work. That said, I noticed the existence of “challenging ranges”, where many nearby N’s resist the greedy approach. So, I did what I believe is a slight optimization, where instead of decrementing N, I subtract .00001*N rounded. Failures became very rare in the higher ranges, suggesting I could probably bump up that coefficient some more.")

#text("Code is here: ")#link("https://github.com/kevinventullo/TaoFactorial/")[#text("https://github.com/kevinventullo/TaoFactorial/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("That’s great progress! It suggests that we could get another order of magnitude or so by just being much more efficient in implementing the vanilla greedy algorithm. One thing I noticed when running the greedy algorithm myself was that it spent the bulk of its time at the end of the process when only small primes like 2, 3, and 5 remain, and the factors acquire a high multiplicity. One possible speedup is, when removing a factor from the remaining portion of the factorial, to automatically remove the maximum number of copies of that factor from the factorial rather than have a loop that removes them one by one. For instance, if one has located a factor ")#mi("2^a 3^b 5^c")#text(" and the remaining expression to be factorized is ")#mi("2^A 3^B 5^C \\dots")#text(", then pull out ")#mi("\\lfloor \\min(A/a, B/b, C/c)\\rfloor")#text(" copies of ")#mi("2^a 3^b 5^c")#text(" right away. This may give some speedup. (Also, for the purposes of storing the factorization for future verification, it is probably more compact to store the factors with multiplicity, which this procedure does automatically.)")

#text("Another thing that can help is that the initial stages of the greedy algorithm are quite predictable and could be largely precomputed, in a way that dispenses with the need to store information about large primes. For instance, the primes greater than or equal to ")#mi("t")#text(" simply remove themselves from the factorial without any further impact (other than each prime contributing one factor to the factorization) so one could already start by restricting attention to those primes less than ")#mi("t")#text(". More generally, if one runs the algorithm to exhaust down to prime factors ")#mi("p \\geq t/K")#text(" for some natural number ")#mi("K")#text(" that is not too large (in particular ")#mi("K \\leq \\sqrt{t}")#text("), then what should happen is that all the primes appearing in ")#mi("N!")#text(" in the range ")#mi("t/k \\leq p < t/k-1")#text(" for some ")#mi("2 \\leq k \\leq K")#text(" will pull out a factor of ")#mi("k")#text(" from the factorial when the greedy algorithm is run (and as stated before, the primes above ")#mi("t")#text(" will not pull out any factor at all). So, the net effect of running the greedy algorithm down to the threshold ")#mi("t/K")#text(" is that one keeps all the primes in ")#mi("N!")#text(" below ")#mi("t/K")#text(", with an additional ")#mi("M_k := \\sum_{t/k \\leq p < t/k-1} \\lfloor \\frac{N}{p} \\rfloor")#text(" factors of ")#mi("k")#text(" removed for each ")#mi("2 \\leq k \\leq K")#text(", and one has already acquired ")#mi("M_1 + \\dots + M_K")#text(" factors. So if one has a rapid way to compute ")#mi("M_k")#text(" (or even just to get an accurate upper bound) for ")#mi("2 \\leq k \\leq K")#text(", one can initialize the greedy algorithm only using primes up to ")#mi("t/K")#text(", which may save some run time as well as memory. In principle one may be able to take ")#mi("K")#text(" all the way up to ")#mi("\\sqrt{t}")#text(" without running out of primes, thus theoretically gaining something like a square root speedup in run time and memory usage.")

#text("There is a formula for ")#mi("M_k")#text(" in terms of the prime counting function ")#mi("\\pi")#text(":")

#mi("\\displaystyle M_k = \\sum_{j \\geq 1} j \\sum_{t/k \\leq p < t/k-1; N/(j+1) < p \\leq N/j} 1")

#mi("\\displaystyle = \\sum_{j: a_{j,k} \\leq a_{j+1,k}} j (\\pi(a_{j,k}) - \\pi(a_{j+1,k})")

#text("where ")#mi("a_{j,k} := \\min( \\lfloor N/j \\rfloor, \\lceil t/k-1\\rceil - 1)")#text(". So, with precomputed values of the prime counting function, or with accurate upper bounds from effective versions of the prime number theorem, one should be able to compute ")#mi("M_k")#text(" relatively quickly, allowing one to reduce the problem to just the primes up to ")#mi("t/K")#text(" for fairly large values of ")#mi("K")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687689")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("I was also trying to use the fact that we have some margin to improve the efficiency of the verification. In particular, I spent a lost of time improving my code by using the fact that most of the time one easily build a factorization for (3(k+1))! from the factorization of (3k)!. It works reasonably well, and I was able to reach 20.000.000 in 20 minutes (and I did not run it for more than this).")

#text("But it seems much better to do the range as suggested by Ventullo. My current implementation [ ")#link("https://gite.lirmm.fr/mrosenfeld/guy-selfridgeconj/-/blob/main/RangeOfValuesWithEpsilon.cpp?ref_type=heads")[#text("here")]#text(" ] of this idea takes 13 minutes to go from 300.000 to 10^8 and 41 minutes to go to 3*10^8. At this point, it slows down because it uses almost all my RAM, so I will need to wait Monday to run it for 10^9 or more on a machine with more RAM .")

#text("A few implementations details:")

#list(
[#text("I am using a parameter epsilon that I decrease (“step by step” from 62 to 0 if it comes to this) until I find a factorization with n factors of size (n*(1000+eps)/1000)/3.")]
)

#list(
[#text("I am still using the heuristic that I previously mentioned (in the greedy algorithm, we sometimes choose a larger factor if it is the product of fewer small primes).")]
)

#list(
[#text("If a factor can be added multiple time, then I add as many copies of it as possible at once (I was already doing this).")]
)

#list(
[#text("One should stop the factorization process as soon as we have found the desired amount of large enough factors. It seems to save more time than what I would expect.")]
)

#list(
[#text("Note that I pre-compute the factorization of every integers (storing for each integer the smallest prime number that divides it) and the list of prime numbers. This would not be much more expensive to also precompute the prime counting functions, although I am not sure that It would save a lot (as you mentioned it seems most of the running time is already spent on the smallest factors). I will try to implement this tomorrow to see how much this helps.")]
)

#text("(I suspect that a part of the speed difference might also be due to me using C++ instead of Python).")

#text("On the other side, adding a second magic heuristic parameter allows getting down to 80000. But I think this heuristic approach will fail between 60000 and 80000 (as it currently fails for many of the values in between).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687692")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("Thanks for the new code runs! If I now understand correctly, the conjecture ")#mi("t(N) \\geq N/3")#text(" is now verified in the range ")#mi("8 \\times 10^4 \\leq N \\leq 3 \\times 10^8")#text(". Combined with Andrew’s verification of ")#mi("t(N) \\geq \\lfloor 2N/7 \\rfloor")#text(" for ")#mi("N \\leq 10^5")#text(", ")#mi("N \\neq 57")#text(" (which presumably can also be replicated by the newer code), we have now reduced the second Guy-Selfridge conjecture to the third (and probably there is already enough room for the analytic approach to fully resolve the second conjecture in the remaining range ")#mi("N \\geq 3 \\times 10^8")#text(", though this would be redundant if we can settle the third in this range).")

#text("Do you have a sense of how much surplus there is for say ")#mi("N = 3 \\times 10^8")#text("? I would like to get a sense of whether we can “afford” to use estimates for the prime counting function rather than exact counts. Because of the ")#link("https://arxiv.org/abs/1511.02032")[#text("work of Buthe")]#text(", we can estimate this function to square root accuracy (i.e. Riemann hypothesis levels of accuracy) for ")#mi("N")#text(" as large as ")#mi("10^{19}")#text(" [basically this is due to the numerical verification of RH up to a certain large height]. In fact the error in ")#mi("\\pi(N)")#text(" is basically ")#mi("\\sqrt{N}/\\log N")#text(", so for ")#mi("N = 3 \\times 10^8")#text(" the error is something like ")#mi("10^3")#text(". If the surplus is comfortably larger than this (say ")#mi("10^4")#text(") then we should have some margin to use approximations for the prime counting function at the very largest scales. This may become increasingly useful as we go to even higher scales than ")#mi("3 \\times 10^8")#text(". (There are also some good estimates for the prime counting function beyond ")#mi("10^{19}")#text(", for instance ")#link("https://piyanit.nl/wp-content/uploads/2020/10/art_10.1007_s11139-016-9839-4.pdf")[#text("of Dusart")]#text(", but I think the analytic approach will be able to cover this range and so these results will not be needed for the numerical analysis (and in any event I doubt the numerical methods could ever get to ")#mi("10^{19}")#text(" without some serious compute and/or speedup tricks).)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687695")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("In fact, I was able to use a machine with more RAM and that the ")#mi("t(n) \\ge n/3")#text(" conjecture is verified for n in ")#mi("[8 \\times 10^4, 10^9]")#text(" .")

#text("For ")#mi("n=10^8")#text(", the greedy algorithm achieves a surplus of 252799 (that is, it factors ")#mi("10^8!")#text(" in 100252799 factors larger than 10^8). It seems large enough for what you have in mind, I suppose that in order to keep using Ventullo’s idea we need to keep some of this margin. Suppose I chose epsilon to be 2/100 (that is we take care of the interval [n, n*1.02]), then we find 100131496 factors of size at least (1.02*n/3), so we still have a decent margin.")

#text("It is not completely clear to me how to use this. If I understand, the idea would be to use the bound ")#mi("0.94\\sqrt{n}")#text(" mentioned in to bound the contribution of large enough primes factors to allow us to focus on only the smaller primes ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("Yes, that is the basic idea. From equation (1.8) of Buthe’s paper and the triangle inequality one has")

#mi("\\displaystyle \\pi(x) - \\pi(y) \\leq \\pi^*(x) - \\pi^*(y) \\leq \\int_y^x \\frac{dt}{\\log t} + \\frac{\\sqrt{x}}{\\log x} + \\frac{\\sqrt{y}}{\\log y}")

#text("whenever ")#mi("2 \\leq y \\leq x \\leq 10^{19}")#text(". So, up to terms much smaller than the available surplus, we can approximate the number of primes in an interval ")#mi("y < p \\leq x")#text(" by the logarithmic integral ")#mi("\\int_y^x \\frac{dt}{\\log t}")#text(" (there is also a matching lower bound, but it is the upper bound which is relevant for our application). So for instance we can use this to upper bound how many primes dividing ")#mi("N!")#text(" there are between ")#mi("t")#text(" and ")#mi("N")#text(" (keeping in mind that primes between ")#mi("N/3")#text(" and ")#mi("N/2")#text(" need to be counted twice, etc.), avoiding the need to count them directly. Similarly for the primes between ")#mi("t/2")#text(" and ")#mi("t")#text(", each of which removes one factor of 2 from the factorization of ")#mi("N!")#text(", and so forth. Because this is a slight overcount of the number of primes, this “virtual greedy algorithm” procedure may remove a few too many factors of 2 etc. from ")#mi("N!")#text(" when compared against the actual greedy algorithm, but because of the large surplus, we should still be able to locate well over ")#mi("N")#text(" factors of this size,")

#text("This may become important for larger values of ")#mi("N")#text(", where one may not have enough memory to store the entire table of primes, though perhaps it is not yet an issue for ")#mi("N = 10^9")#text(".")

#text("I am guessing that the reason why the greedy algorithm slows down when one has very few primes remaining is that there are many fewer available factors, and the algorithm has to increment its way from ")#mi("t")#text(" upwards for quite a while to find them. One could perhaps precompute a table of smooth numbers (e.g., numbers with all prime factors in ")#mi("\\{2,3,5,7\\}")#text(" that are greater than or equal to ")#mi("t")#text(", but with no factor greater than or equal to ")#mi("t")#text("), and switch to that table to find factors once these are the only available primes remaining. It may take some trial and error though to determine what is a reasonable definition of “smooth” here.")

#text("(Small correction: I believe you meant \"larger than 10^8/3\" instead of \"larger than 10^8\" in your previous comment.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687699")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2025")])]

#text("I am not sure how to use an upper bound on ")#mi("\\pi(x)-\\pi(y)")#text(". The idea, as I understand it, would be: we simply ignore prime larger than say ")#mi("n/K")#text(", and for all ")#mi("i \\le K")#text(":")

#list(
[#text("we add ")#mi("3i(\\pi(n/(3i-1))-\\pi(y/(3i)))")#text(" to the number of constructed factors larger than ")#mi("n/3")#text(",")],
[#text("and we remove from the remaining available primes factors the same number of occurrences of ")#mi("i")#text(" (or its factorization) (all of this is up to ")#mi("+1")#text(" or ")#mi("-1")#text(").")]
)

#text("So it seems a lower bound on ")#mi("\\pi(x)-\\pi(y)")#text(" would be more useful. Am I missing something on how to use the upper-bound ?")

#text("Either way, on a powerful machine, storing the primes is not a problem yet (the ")#mi("4 \\times 10^9")#text(" primes below ")#mi("10^11")#text(" would still easily fit in “only” ")#mi("32GB")#text("). Memory-wise, the main problem seems to be the precomputation of the factorization of every integer. Currently, for each ")#mi("n")#text(", I only store the smallest prime divisor (or ")#mi("-1")#text(" if ")#mi("n")#text(" is prime, so we always store something smaller than ")#mi("\\sqrt{n}")#text(", hence on 32 bits instead of 64). For $10^11$ this would still take $400GB$ which is really near the limit of reasonable machines.")

#text("Inspired by this “smooth number” idea, I might have a way to reduce the number of integers whose factorizations need to be kept. Suppose during the greedy procedure, the largest available prime is ")#mi("p")#text(", and we try to multiply it with a number ")#mi("z")#text(" such that ")#mi("z \\times p \\ge n/3")#text(". Let ")#mi("s(z)")#text(", ")#mi("L(z)")#text(" be respectively the smallest and largest prime divisors of ")#mi("z")#text(" (I do not know if there are standard notations for these). Then ")#mi("\\frac{z}{s(z)}\\times p< n/3")#text(" (otherwise we would have picked ")#mi("\\frac{z}{s(z)}")#text("). On the other hand, since $p$ is the largest available prime, we know ")#mi("L(z)\\le p")#text(", which implies ")#mi("\\frac{z}{s(z)}\\times L(z)< n/3")#text(". So during the greedy procedure, we only need to know the factorizations of numbers that respect this condition (based on some experimentations, for ")#mi("n =5\\times 10^7")#text(", this represents roughly ")#mi("10^6")#text(" integers). There might be more clever ways to eliminate “useless” integers that I do not see.")

#text("Based on one of your comments of March 29th, I was under the impression that we want to reach a value near ")#mi("10^11")#text(" where the asymptotic argument from your preprint takes care of the rest. It really seems doable with the current approach on a big machine with a few extra optimizations. Also since each factorization covers an interval of the form ")#mi("[n, 1.02n]")#text(" (maybe for different values of ")#mi("1.02")#text("), then the certificate of the verification for the interval ")#mi("[10^6,10^11]")#text(" is the factorization of only ")#mi("600")#text(" numbers (although, I am not sure that it is easier to verify the certificate than to produce it).")

#text("(Yes, I meant 10^8/3.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2025")])]

#text("Ah, you are right, both upper and lower bounds are needed: lower bounds to ensure that we have produced enough terms in the factorization, and upper bounds to ensure that we have not “spent” more small primes than are actually available in the factorization. Fortunately, the results of Buthe also provide lower bounds of essentially the same shape as the upper bounds (there are some minor changes in the constants and some lower order terms). Equations (1.9) and (2.0) gives the lower bound")

#mi("\\displaystyle \\pi(x) - \\pi(y) \\geq \\int_y^x \\frac{dt}{\\log t} - \\frac{\\sqrt{x}}{\\log x} (1.95 + \\frac{3.9}{\\log x} + \\frac{19.5}{\\log^2 x})")

#text("which is slightly less elegant than the upper bound, but no problem for a computer of course (for fast computation one would probably want to use some asymptotic approximation of the logarithmic integral with known bounds on error terms, but these can be found in the literature, and may even already exist in code libraries). But it sounds like they won’t be needed just yet, unless we want to push up by another order of magnitude or two.")

#text("I like your idea of pruning the table of available integers to only keep the “non-useless” ones. I had a further idea that looks easy to implement, and performs a tradeoff between optimality of the factorization, and the speed of the factorization. Currently, when the largest available prime is ")#mi("p")#text(", we search for complementary factors ")#mi("z \\geq t/p")#text(" that are still available (after removing ")#mi("p")#text(" from the available pool of primes remaining), usually taking the smallest such value, to join with ")#mi("p")#text(" to create a new factor in our factorization. When ")#mi("p")#text(" is small, then ")#mi("t/p")#text(" is large, and so we have a large search space to cover, which is presumably taking up most of the run time. But suppose we select an intermediate parameter ")#mi("1 \\leq K \\leq \\sqrt{t}")#text(" and modify the greedy algorithm as follows: greedily select the largest primes ")#mi("p_1, p_2, \\dots")#text(" available until we reach a product ")#mi("p_1 \\dots p_k")#text(" that is at least ")#mi("K")#text(" (and will therefore be at most ")#mi("K^2")#text(", unless it consists of a single large prime ")#mi("p")#text("), then match it with a complementary factor greater than equal to ")#mi("t/p_1 \\dots p_k")#text(". This threshold is at most ")#mi("t/K")#text(", so by taking ")#mi("K")#text(" larger we have to store fewer factorizations, and perform faster searches. When the largest prime ")#mi("p")#text(" is at least ")#mi("K")#text(", this modified algorithm is identical to the greedy algorithm; but when one is down to the primes smaller than ")#mi("K")#text(" it is a little more inefficient, though the threshold ")#mi("t/p_1 \\dots p_k")#text(" we are searching at is still relatively large (it doesn’t go below ")#mi("t/K^2")#text(") so as long as ")#mi("K")#text(" is not too close to ")#mi("\\sqrt{t}")#text(", it should still give a reasonably efficient factorization. So one has an additional parameter ")#mi("K")#text(" to play with: ")#mi("K=1")#text(" is the vanilla greedy algorithm (gives a good surplus but is slow), and increasing ")#mi("K")#text(" trades off the surplus for speed.")

#text("I’m glad it looks like getting up to ")#mi("10^{11}")#text(" is in fact feasible. I’d been postponing working out the details exactly, because working with completely effective constants everywhere is something of a pain, but now that we seem to be approaching that scale, I should go work out the details soon.")

#text("A reasonably standard notation for ")#mi("s(z), L(z)")#text(", by the way, are ")#mi("P_-(z)")#text(" and ")#mi("P_+(z)")#text(" respectively.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d256a2283220faacfd533450c93b05f00ad1a03fe71a7164de4795bf03f1af14-dce6fda6b35704263589652c87bde6a086ea98bff491b242a766200fb938dd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uhrmar")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687690")[#strong[#text("uhrmar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("I think you have to be careful with how many problem instances you skip when solving problems with higher threshold. In particular, it also depends on the number of factors you find. If you solve for ")#mi("N")#text(" and ")#mi("t(N)=N(\\frac{1}{3}+\\epsilon)")#text(" and you find ")#mi("N(1+\\delta)")#text(" factors (say), this verifies only the interval ")#mi("[N, N\\cdot\\min(1+3\\epsilon, 1+\\delta)]")#text(". Ideally, ")#mi("\\epsilon \\approx \\delta")#text(".")

#text("Plugging in the numbers ")#mi("N=300000")#text(", ")#mi("\\epsilon=0.01")#text(" (")#mi("t(N)=103000")#text(") finds 299733 factors, making ")#mi("\\delta")#text(" negative and the interval empty.")

#text("(I hope I got this right.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("As you go from ")#mi("N!")#text(" to ")#mi("(N+1)!")#text(", you can add one factor for free, namely ")#mi("N+1")#text(". So as soon as you can (sub)factor ")#mi("N!")#text(" with at least ")#mi("N")#text(" factors that are greater than equal to ")#mi("N(1/3+\\epsilon)")#text(", then you can also factor ")#mi("N^{\\prime}!")#text(" into ")#mi("N^{\\prime}")#text(" factors that are greater than or equal to ")#mi("N^{\\prime}")#text(" for any ")#mi("N \\leq N^{\\prime} \\leq N (1+3\\epsilon)")#text(". So I don’t think it’s necessary to take ")#mi("\\delta")#text(" into account (other than to ensure that it is nonnegative).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d256a2283220faacfd533450c93b05f00ad1a03fe71a7164de4795bf03f1af14-dce6fda6b35704263589652c87bde6a086ea98bff491b242a766200fb938dd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uhrmar")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687693")[#strong[#text("uhrmar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2025")])]

#text("Please disregard what I wrote in the previous comment – I got it completely wrong.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("Looking at the code, it seems the strategy is to view the factorization as ")#mi("\\prod_{t \\leq j \\leq N} j^{x_j} = N!")#text(" (actually it is slightly better to work with subfactorizations ")#mi("\\prod_{t \\leq j \\leq N} j^{x_j} | N!")#text(") for some natural number variables ")#mi("x_j")#text(", in which case the problem of factoring ")#mi("N!")#text(" to as many factors ")#mi("\\geq t")#text(" as possible amounts to maximizing ")#mi("\\sum_{t \\leq j \\leq N} x_j")#text(" subject to the constraints ")#mi("\\sum_{t \\leq j \\leq N} \\nu_p(j) x_j \\leq \\nu_p(N!)")#text(" for every prime ")#mi("p \\leq N")#text(". It is somewhat impressive to me that the linear programming package you use (Gurobi) can handle programs of this size (for ")#mi("N=300000")#text(", this is 35997 equations in 200000 unknowns). Still, it seems to give very good results, and even tight upper bounds. It should be very helpful in determining ")#mi("t(N)")#text(" exactly for small ")#mi("N")#text(" (e.g., the range ")#mi("80 \\leq N \\leq 599")#text(" depicted in my paper).")

#text("There are some small ways to reduce variables which may improve the runtime of the linear program (at the cost of making the code a bit more complicated). Any even number ")#mi("j")#text(" with ")#mi("j \\geq 2t")#text(" can be deleted, since there is no harm in replacing ")#mi("j")#text(" by ")#mi("j/2")#text("; this already gets rid of 50001 unknowns in the ")#mi("N=300000")#text(" case. Any prime ")#mi("p")#text(" with ")#mi("N/2 < p \\leq N")#text(" appears exactly once in ")#mi("N!")#text(", and the only ")#mi("j")#text(" that is usable here is ")#mi("p")#text(", so this forces ")#mi("j_p=1")#text(". Similarly we must have ")#mi("j_p=2")#text(" for ")#mi("t < p \\leq N/2")#text(" (assuming ")#mi("t \\geq N/3")#text("). Once we make these reductions, we no longer need to test primes larger than ")#mi("t")#text("; for ")#mi("N=300000")#text(", this reduces the number of equations from 35997 to 9592. (But it is possible that Gurobi is already smart enough to find these sorts of initial reductions on its own, and the actual speedup in practice may be slight.)")

#text("EDIT: there is one subtlety in using the linear programming method to rigorously demonstrate an upper bound on ")#mi("t(N)")#text(". As currently implemented, the method assumes that all factors of ")#mi("N!")#text(" involved are not only greater than or equal to ")#mi("t")#text(", but also less than or equal to ")#mi("N")#text(". This is a pretty reasonable assumption: if one had a putative factorization (or subfactorization) that involved a factor larger than ")#mi("N")#text(", in most cases one can perform some sort of “trade” in which one decreases that number and increases some other one in a way that moves the subfactorization more towards being having all terms bounded by ")#mi("N")#text(", but I don’t see yet why this is possible to do in all cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("OK, here is a possible way to provide a fully rigorous demonstration of an upper bound for the number of factors greater than or equal to ")#mi("t")#text(" in a subfactorization of ")#mi("N!")#text(". There is a dual linear program to the primary one: if one can find non-negative reals ")#mi("a_p \\geq 0")#text(" for primes ")#mi("p \\leq N")#text(" such that ")#mi("\\sum_p a_p \\nu_p(j) \\geq 1")#text(" for all ")#mi("j \\geq t")#text(", then one has the upper bound ")#mi("\\sum_{j \\geq t} x_j \\leq \\sum_p a_p \\nu_p(N!)")#text(" to the primary problem. So one just has to find a solution to the dual problem with ")#mi("\\sum_p a_p \\nu_p(N!)")#text(" as small as possible.")

#text("The catch is that there are infinitely many ")#mi("j")#text("‘s. But if we impose the additional (presumably reasonable) constraint that the ")#mi("a_p")#text(" are weakly increasing, then for ")#mi("j > N")#text(", we can use Bertrand’s postulate to reduce one of its prime factors of ")#mi("j")#text(" by a factor of at most two to obtain ")#mi("t \\leq j^{\\prime} < j")#text(" with ")#mi("\\sum_p a_p \\nu_p(j) \\geq \\sum_p a_p \\nu_p(j^{\\prime})")#text(". So if we solve the finite linear program ")#mi("\\sum_p a_p \\nu_p(j) \\geq 1")#text(" for all ")#mi("t \\leq j \\leq N")#text(", with the additional constraint that the ")#mi("a_j")#text(" are weakly increasing, this should give a rigorous upper bound that I expect to be close (or exactly equal to) what the previous not-quite-rigorous linear programming bound gave.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d256a2283220faacfd533450c93b05f00ad1a03fe71a7164de4795bf03f1af14-dce6fda6b35704263589652c87bde6a086ea98bff491b242a766200fb938dd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uhrmar")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687672")[#strong[#text("uhrmar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("I also think ignoring factors ")#mi("j > N")#text(" is the only way the LP upper bound could fail. The argument with the weakly increasing dual variables is very elegant. Just to make sure I correctly understand it: the argument only works for ")#mi("t(N) \\leq N/2")#text(" since one has to apply it repeatedly to end up with ")#mi("t \\leq j^{\\prime} \\leq N")#text(" (the base case verified by linear programming). As such it might be worth pointing out that only replacing primes with smaller nearby primes might get stuck at powers of two. But it is also possible to just drop factors of two.")

#text("I’ve opted to implement this in my primal formulation by adding additional variables that force the optimal dual variables to be weakly increasing. Unfortunately, adding these variables might destroy the validity of the factorization – it is only useful to verify the upper bound. I’ve also added a test of monotonicity of the optimal dual variables to the original formulation. It seems that the optimal duals are very often (always?) weakly increasing.")

#text("It ")#emph[#text("feels")]#text(" like one should be able to prove the weakly increasing property of the simple formulation, but I’m unable to do so.")

#text("If I find time, I might implement a verification of solutions found by Gurobi using rational arithmetic. This would make the code more trustworthy for extending OEIS A034258.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687673")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2025")])]

#text("Yes, the argument assumes ")#mi("t(N) \\leq N/2")#text(", but this can be proven from the trivial bound ")#mi("t(N) \\leq (N!)^{1/N}")#text(" for ")#mi("N \\geq 6")#text(" (and is also true for ")#mi("N=2,3,4,5")#text(". You’re right that I neglected to treat the case of powers of two, but as you say that case can also be handled.")

#text("Regarding rational arithmetic, if there is some room in the linear programming bound (e.g., if we want to prove ")#mi("t(N) = 45")#text(" and the linear programming upper bound is ")#mi("45.943\\dots")#text(") then one could simply round up the weights ")#mi("a_j")#text(" to the nearest multiple of ")#mi("1/1000")#text(" or something and verify using integer arithmetic. This might be good enough for the small values of ")#mi("N")#text(" needed to extend A034258, and one simply needs to report the weights to this level of precision.")

#text("I can’t yet prove the weakly increasing property for the finite linear program (with ")#mi("t \\leq j \\leq N")#text("), but I can do it for the infinite linear program (with ")#mi("j\\geq t")#text("). Suppose for contradiction that the optimal weights ")#mi("a_p")#text(" for the infinite linear program obey ")#mi("a_{p_1} > a_{p_2}")#text(" for some primes ")#mi("p_1 < p_2")#text(". Let ")#mi("a^{\\prime}_p")#text(" be the same weights as ")#mi("a_p")#text(", except that ")#mi("a^{\\prime}_{p_1}")#text(" is assigned to equal ")#mi("a_{p_2}")#text(" rather than ")#mi("a_{p_1}")#text(". I claim that these new weights still solve the linear program ")#mi("\\sum_p a^{\\prime}_p \\nu_p(j) \\geq 1")#text(" for all ")#mi("j \\geq t")#text(". This is because ")#mi("\\sum_p a^{\\prime}_p \\nu_p(j) = \\sum_p a_p \\nu_p(j^{\\prime})")#text(" where ")#mi("j^{\\prime}")#text(" is formed from ")#mi("j")#text(" by replacing any factors of ")#mi("p_1")#text(" with ")#mi("p_2")#text(". So these new weights are admissible, but on the other hand ")#mi("\\sum_p a^{\\prime}_p < \\sum_p a_p")#text(", contradicting the optimality hypothesis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dragonbriskly18bd0d56d5")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687732")[#strong[#text("dragonbriskly18bd0d56d5")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("It seems to me that one can prove, in the original formulation, that no factor need be greater than ")#mi("n^2")#text(" (or, in fact, ")#mi("n t")#text("). Any such factor has a proper divisor which is smaller, but still at least ")#mi("t")#text(".")

#text("Accordingly, in the primal formulation, it suffices to extend the range of ")#mi("j")#text(" somewhat higher. Or even better: only consider potentially “useful” ")#mi("j")#text(" that have the appropriate divisors. Nonetheless, this would make the problem bigger and thus potentially take longer.")

#text("But: Do I reason correctly, then, that in the dual formulation, it suffices to check ")#mi("j")#text(" up to this same bound (say ")#mi("n^2")#text(" for simplicity), even if the ")#mi("a_j")#text(" are *not* sorted?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687734")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("Nice observation! Yes, this would allow for a rigorous dual certificate without requiring the ")#mi("a_j")#text(" to be non-decreasing, as long as it covered all possible ")#mi("j")#text(".")

#text("There is a way to cut down the set of ")#mi("j")#text(" significantly, but it is complicated. The first observation is that if a factorization involves two factors ")#mi("j_1,j_2")#text(", and ")#mi("j_2")#text(" dominates ")#mi("j_1")#text(" in the sense that there exist factorizations ")#mi("j_1 = k_1 l_1")#text(" and ")#mi("j_2 = k_2 l_2")#text(" for which ")#mi("k_1 < k_2")#text(" and ")#mi("l_1 < l_2")#text(", then it is possible to interchange these two factors to ")#mi("k_2 l_1")#text(" and ")#mi("k_1 l_2")#text(" instead, which reduces the variance of the logarithms of the factors. So without loss of generality, if one restricts to factorizations (or subfactorizations) that minimize variance (for a fixed value of total product), one can assume that no such domination occurs.")

#text("To use this, we make a second observation: if there is a (sub)factorization ")#mi("\\prod_{j \\geq t} j^{m_j} | N!")#text(" with at least ")#mi("N")#text(" elements then we must have ")#mi("\\sum_{j \\geq t} m_j \\log \\frac{j}{t} \\leq \\log N! - N \\log t")#text(". This puts a cap on having too many factors ")#mi("j")#text(" in which ")#mi("\\log \\frac{j}{t}")#text(" is large.")

#text("One can combine these as follows. Suppose that we have a factorization that contains a large factor ")#mi("j = kl")#text(" with ")#mi("k,l")#text(" both large. Let ")#mi("p")#text(" be a prime with ")#mi("e^\\sigma t/l \\leq p < k")#text(" for some ")#mi("\\sigma > 0")#text(". Then, in order to avoid domination, the only factors that contain ")#mi("p")#text(", must be the product of ")#mi("p")#text(" and a quantity which is at least ")#mi("l")#text(", and so will contribute at least ")#mi("\\sigma")#text(" to the sum ")#mi("\\sum_{j \\geq t} m_j \\log \\frac{j}{t}")#text(". On the other hand, as all factors have size at most ")#mi("nt")#text(", the total number of factors of this form is at least ")#mi("\\frac{1}{\\log(nt)} \\sum_{e^\\sigma t/l \\leq p < k} \\nu_p(N!) \\log p")#text(". So we get a contradiction provided that")

#mi("\\sup_{\\sigma} \\frac{1}{\\log(nt)} \\sum_{e^\\sigma t/l \\leq p < k} \\nu_p(N!) \\log p \\times \\sigma > \\log N! - Nt.")

#text("This criterion in principle rules out a lot of large factors ")#mi("j = k \\times l")#text(" from consideration; but the amount of effort needed to test this criterion may be comparable to the time needed to just run the larger linear program.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687655")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("I have written a version of my code [https://gite.lirmm.fr/mrosenfeld/guy-selfridgeconj] that allows to run the heuristic for all values between a given range with a few different parameters for each value.")

#text("In the range [100000,500000] the largest integer that fails is 138074 and there are only 18 of them failing in the range. On my laptop, it currently runs in under ~70 minutes.")

#text("It seems that the linear program based solution is a bit too slow to run it on all integer up to 500000 (it takes ~10m on my machine, although a big fraction of the time seem to be spent on initializing the LP ? ). It probably makes sens to improve the heuristic to reduce the question to as few cases as possible before running the LP based solution for the remaining ones.")

#text("PS: This is not the deepest remark, but it took me a while to notice that it is enough to verify the conjecture for all multiple of 3. In particular, there are in fact only 6 missing values in [100000, 138074]:100014, 100017, 100020, 100023, 101790, 138072")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687662")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("Thanks for the additional runs. It seems your method, though less powerful, is significantly faster than the linear programming method, so perhaps it makes sense to do some sort of two-pass search where one uses the faster method to eliminate most candidates and then the slower one to handle the few remaining exceptions.")

#text("One can also consider a three-pass search in which one first uses the faster method with an aggressive parameter selection heuristic to achieve an initial winnowing, and then again with a more conservative heuristic on the remaining candidates, and then finally the linear programming method on the remainder, but perhaps this is overly intricate.")

#text("It makes sense to restrict attention to multiples of three throughout.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d256a2283220faacfd533450c93b05f00ad1a03fe71a7164de4795bf03f1af14-dce6fda6b35704263589652c87bde6a086ea98bff491b242a766200fb938dd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of uhrmar")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687670")[#strong[#text("uhrmar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("Yes, setting up the linear program was extremely inefficient. I’ve pushed a fix that makes the code run significantly faster.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("In the paper, in the definition of t(N), it is not clearly stated that the factors should be integers")

#emph[#text("[Fair enough, I will add that ")#mi("a_1,\\dots,a_N \\in {\\mathbf N}")#text(" in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687667")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2025")])]

#text("If the factorization of N! is to arbitrary poditive numbrs than t(N) should be the geometric mean of 1, …,N (which is assymptotic to N/e)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687707")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2025")])]

#text("I started a ")#link("https://github.com/teorth/erdos-guy-selfridge")[#text("Github repository")]#text(" to record the various progress towards the Guy-Selfridge conjecture, with an aim to coordinate future work. I am also beginning to ")#link("https://github.com/teorth/erdos-guy-selfridge/tree/main/LaTeX")[#text("draft some notes")]#text(" on how to numerically generate upper and lower bounds on t(N) within the repository, though this is currently a work in progress (in particular I have some ideas on how to improve and make explicit the asymptotic construction, and hopefully meet the numerical computations somewhere in the middle).")

#text("As listed on the repository, there are various directions to pursue here. The major one is to complete the verification of the Guy-Selfridge conjecture ")#mi("t(N) \\geq N/3")#text(", which is currently known for ")#mi("8 \\times 10^4 \\leq N \\leq 10^9")#text(" and for sufficiently large ")#mi("N")#text(". Actually, the lower bound may be close to optimal, given the predicted asymptotic ")#mi("t(N) \\approx N/e - c_0 N / \\log N")#text(" with ")#mi("c_0 \\approx 0.3044\\dots")#text(", as this approximation meets ")#mi("N/3")#text(" at about ")#mi("N = 6700")#text(". (I’ve also listed the more accurate evaluation of ")#mi("c_0")#text(" as a further numerical goal.) A further goal is to extend the OEIS table for ")#mi("t(N)")#text(", which currently goes up to ")#mi("N \\leq 79")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/094d3a4afafc4b15d41318284c2793f669c652fa25de78d54e81ec79d56b06d1-7bd83a067de926febbd326d5fbb07a8c24c7f8180773830f5b707328a9a6bdd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687715")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2025")])]

#text("Thanks for starting the GitHub repository. A couple comments, which I didn’t know whether to raise here or as an issue there:")

#text("1. The file ")#link("https://terrytao.wordpress.com/wp-content/uploads/2025/03/tbounds.txt")[#text("https://terrytao.wordpress.com/wp-content/uploads/2025/03/tbounds.txt")]#text(" which is linked from the bottom of the README.md as “Lower bounds on $t(N)$ for $80 leq N leq 599$” is inaccessible to me. The message is “— 403: Access Denied — This file requires authorization.: You must be logged in and a member of this blog.”")

#text("2. You currently report the OEIS entries as known up to t(79)=22, which is indeed as far as ")#link("https://oeis.org/A034258/b034258.txt")[#text("https://oeis.org/A034258/b034258.txt")]#text(" goes. However, ")#link("https://oeis.org/A034259/b034259.txt")[#text("https://oeis.org/A034259/b034259.txt")]#text(" is a different representation of the same data and there it goes up to t(200)=59.")

#emph[#text("[Thanks, these issues have now been corrected – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687708")[#strong[#text("Decomposing factorial of 300K as the product of 300K factors larger than 100K - Gustavo")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2025")]

#text("[…] few days ago, Terence Tao proposed a challenge to decompose the 300K! as the product of 300K factors larger than 1…. A smaller example is decomposing 10! as the product of 10 factor greater or equal than […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/781f29af449c9bc71662b5f43f8e78f15dfba3317257713eb73722729cc0a8a9-0061153343de0372d3e92c4b9b903c1cb5830cbb12ee00f4d6c48ddf9019c9ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Eduardo Ruiz")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687710")[#strong[#text("Daniel Eduardo Ruiz")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2025")])]

#text("Trivially ")#mi("\\min a_j  \\leq  \\Omega(N!) =  n \\ln(\\ln(n)) + Cn + O( \\frac {n} {\\ln(n)}")#text(". Omega’s function counts repetitions. It looks like VLSM.")#linebreak()#text("Naive algorithm:")#linebreak()#text("0. n_i<-N!, T_n=0")#linebreak()#text("1. Take min a_i = Omega( n_i) and divisor of N_i.")#linebreak()#text("2. n_i /= a_i")#linebreak()#text("3. T_n ++")#linebreak()#text("4. Repeat until a_i > 1 or something like that.")

#text("It would be interesting to combine with the result:")

#mi("\\left( 1 - \\frac{\\pi^2}{12} \\right) \\frac{N^2}{\\log N} + C \\frac{N^2}{\\log^2 N} + o\\left( \\frac{N^2}{\\log^2 N} \\right), \\quad C \\doteq 0.1199")

#text("The source is ")#link("https://ntrg.math.unideb.hu/SP2023Talk.pdf")[#text("Properties of sum-of-digits functions")]#text(" page 55. Or full article ")#link("https://ntnuopen.ntnu.no/ntnu-xmlui/bitstream/handle/11250/2980249/no.ntnu:inspera:56982622:29703762.pdf")[#text("Digit sums and the number of prime factors of the factorial n!=1·2···n")]#text(", and also have")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2025")])]

#text("I’ve found a way to make the constructions in my paper more efficient, and in particular a viable path to providing fast factorizations of ")#mi("N!")#text(" for say ")#mi("10^9 \\leq N \\leq 10^{11}")#text(", using 3-smooth numbers (products of 2 and 3) rather than just 2-smooth numbers (powers of 2) for improved efficiency.")

#text("The algorithm is described in Section 5 of ")#link("https://github.com/teorth/erdos-guy-selfridge/blob/main/LaTeX/notes.pdf")[#text("these notes")]#text(", but roughly speaking it proceeds as follows. One first starts with an approximate factorization formed by taking all the numbers between ")#mi("t")#text(" and ")#mi("t (1+3t/A)")#text(" that are coprime to 6, with multiplicity ")#mi("A")#text(", where ")#mi("A")#text(" is a parameter that is not too large. This gives a factorization that uses up about the right number of medium primes, but has the “wrong” large primes, and uses none of the available primes at 2 and 3. Then one deletes all the factors with large primes ")#mi("p")#text(" (say larger than ")#mi("t/K")#text(" for some parameter ")#mi("K")#text(" a bit larger than ")#mi("A")#text(") and replaces them with what the greedy algorithm says to use, namely ")#mi("p \\lceil t/p \\rceil")#text(". Then, for all remaining primes between ")#mi("3")#text(" and ")#mi("t/K")#text(", one fixes up the factorization by rounding any excess primes up to the nearest 3-smooth number (products of 2 and 3), and also filling in any missing primes by a greedy argument also using 3-smooth numbers. After all this, one will be left with a large number of powers of 2 and 3, which one can efficiently factor using a simple 2-dimensional linear program.")

#text("I believe that this construction is slightly less efficient than the greedy algorithm, but is relatively straightforward to analyze theoretically, and I think also should be fairly quick to implement numerically as most of the primes are already allocated automatically, and only a small amount of “cleaning” is needed.")

#text("As an application of this new construction, I believe I can improve the lower bound ")#mi("t(N)/N \\geq 1/e - O(1/\\log N)")#text(" to ")#mi("t(N)/N \\geq 1/e - c_0/\\log N - O(1/\\log^{1+c} N)")#text(", thus matching the upper bound. I plan to write up the details of this soon. After that, I will try to make everything explicit and see exactly what range of ")#mi("N")#text(" I can cover with the theoretical approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687728")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("I have been rewriting my code to use the optimization I mentioned in the previous message (store only the factorization of the “useful” integers). I also had to rewrite the sieve for this, and to turn it into a segmented sieve (takes ")#mi("O(n/\\log n)")#text(" space instead of ")#mi("n")#text("). Lot of other small implementation details, means I spent more time than expected to implement this new version. But, yesterday I was able to run it for up to ")#mi("2 \\times 10^{10}")#text(" in 2h45m using ")#mi("70GB")#text(" of RAM (memory consumption is sublinear, and the machine has 300GB of RAM, so I should be able to push it at least to ")#mi("8 \\times 10^{10}")#text("). I will try to make a pull request, for the C++ code and the output after cleaning-up and running the code for ")#mi("8 \\times 10^{10}")#text(".")

#text("If needed, using the trick of working with approximation of ")#mi("\\pi(i)")#text(" for ")#mi("i\\le t/3= N/9")#text(" should allow us to reach ")#mi("10^{12}")#text(". Memory is the main limitation, so we could precompute and store the exact value of ")#mi("\\pi(K*i)")#text(" for all ")#mi("i< N/K")#text(" for some ")#mi("K~10000")#text(", this would only take ")#mi("O(N/K)")#text(" bytes but provide good approximations on ")#mi("\\pi")#text(". (I could also use even more powerful machines with up to 3TB of RAM, but it should be only for final computation as there are more complicated to access. It would also make the computation more difficult to check).")

#text("For the approach you suggest in section 5 of the notes, there are some implementation details, that I am not sure how to implement if we want to reach values ")#mi("\\ge 10^{11}")#text(". For part (6), we need to know the factorization of all numbers in ")#mi("[t, t(1+3/A)]")#text(". I believe that it is too expensive to compute it as you need it for each number (I might be wrong ?), and on the other hand precomputing it with a sieve will be too expensive memory-wise. It is really nice to see that it improves the theoretical bounds, though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687731")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2025")])]

#text("That’s great news! I am still in the process of working out exactly what the construction I have will give (and the notes will be fluctuating a fair bit doing this process, for instance the algorithm has currently been moved to Section 3.2), but I have several ideas for upper bounding various quantities coming from things such as the prime factorizations in ")#mi("[t, t(1+3/A)]")#text(" that should allow for a more computationally feasible test of the algorithm I propose. But it is still a work in progress, I will update here when there is a concrete criterion that can be tested numerically.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687736")[#strong[#text("Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2025")])]

#text("Matthieu,")

#text("Earlier you mentioned that storing the smallest prime factor for every $n < 10^{11}$ would take up about 400GB of memory. Naively, it seems to me you could halve that by only storing the values for odd n; computing divisibility on the fly for p=2 is extremely cheap.")

#text("More generally, there is an approach that would let you index only those n for which the smallest prime factor is greater than say, 7. This already brings the array’s size down to under 100GB. It would mean doing O(1) runtime multiplications and managing a few small auxiliary arrays instead of a direct lookup in firstDivisor and nbPrimeDiv, but maybe this is worth the overhead.")

#text("Happy to expand on this and write up some code if you’re interested.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0a843b233e16e43db809fd52c0e601152aaf348c457214e2a1d49c9581b7dc4-97c39545e606c20f62c8de8bb5e339087b9b5f503c9757987c1d939f766264da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evan Conway")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687741")[#strong[#text("Evan Conway")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2025")])]

#text("I think this is a good approach, given that many small divisibility checks are extremely cheap.")

#text("In terms of implementation, would you first do divisibility checks against the first ")#mi("k")#text(" primes and then proceed to doing a lookup in firstDivisor? If so, then you could potentially do an optimization where you store a single bit for all ")#mi("n < 10^{11}")#text(" numbers saying if it has a small smallest factor (do the manual divisibility checks) or a large smallest factor (lookup in firstDivisor). This would add an array of size 12.5 GB, but I think it would ultimately decrease memory usage, since you can add more manual divisibility checks without decreasing performance too much.")

#text("Working through an example of this, suppose we do manual checks for the first 10 primes. All but around 15.8% of numbers have one of these primes as their smallest factor, so we would need around 400 * 15.8% = 63.2 GB to store the direct lookup array. We then add 12.5 GB for the helper array I’m proposing, for a total of 75.7 GB.")

#text("Then, for each lookup, we run a lookup on the helper array. 15.8% of the time, we then just run another lookup on the direct lookup array. The rest of the time, we try divisibility checks for the first 10 primes. I think this should actually be fairly cheap (I’m getting around 2 expected checks, if my calculations are right), since we’re likely to find the smallest prime factor within the first few checks.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687744")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2025")])]

#text("This is a really reasonable trick that should allow to go a bit further. I haven’t had time to clean up my code. But it was easy to make a small modification that does this trick for even numbers. I started a computation with ")#mi("10^{11}")#text(". Adding other primes has diminishing returns, but also taking care of even numbers is enough to allow us to reach ")#mi("10^{11}")#text(". Also, the numbers whose factorization is useless by the previous criterion I gave tend to have small factors, so it might be better to try this trick without the trick hat I added to my code ? Maybe in that case you want to precompute an array that tell you what to do based on N modulo K (where K is the product of the 10 first primes).")

#text("I hope that I will be able to share a reasonable version of the code tomorrow. I suspect there is something a bit inefficient with the sieve I have written, as the precomputation is the most expensive part now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f832c7334b3f139142f58e810a51fe512f4a88e11da9b4aa59649df1c717f459-ad995c6cb972815820045ff0a3deedee85e3cf2b9495fffe4eb337526e7cc50e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687745")[#strong[#text("Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2025")])]

#text("For p=2, you check directly. For other primes, there are two more issues to consider:")

#enum(start: 1, 
[#text("In addition to the smallest prime divisor of a given number, Matthieu is also interested in the number of times that prime divides the number. This information is stored in the array nbPrimeDiv. For p=2 this can also be cheaply computed on the fly by counting trailing zeroes.")],
[#text("The indexing scheme for firstDivisor and nbPrimeDiv gets a little weird when you only want to index numbers which are coprime to the first k primes.")]
)

#text("To resolve this, let P_k denote the product of the first k primes, ignoring 2. My thinking was you could do a single multiplication to compute the remainder of n modulo P_k, and then use a precomputed auxiliary array of length P_k to store either the smallest divisor when n is not coprime to P_k, or indexing information when n is coprime to P_k (as well as metadata about which of the two situations we’re in). When n is coprime to P_k, one more multiplication is required to compute the exact index into firstDivisor and nbPrimeDiv.")

#text("In any case, that gets you the firstDivisor information in just two multiplications, independent of k.")

#text("There’s a bit more work to compute nbPrimeDiv when n is not coprime to P_k, which requires at most three more multiplications (so at most four in total) and some small-ish auxiliary data. Basically, the idea is to bring back the arrays firstDivisor and nbPrimeDiv, but only for multiples of p^5 for each p in the first k primes (ignoring p=2). The size of this array shrinks rapidly: for p=3, the array is ~1.6GB, and for p=5 it is ~128MB. The multiplications come from checking divisibility by p^5, and then a tiny binary search when the exponent is less than 5. Note that when the exponent is >= 5, only two multiplications are required in total.")

#text("Now, this is not really viable if you take k=10, as then P_k is rather large. However, I think you hit diminishing returns well before 10. As you observed, k=10 gets you to ~16%, but even k=4 already gets you to ~23%. In any case, there some knobs to fiddle which trade off memory usage with runtime compute cost.")

#text("Footnotes:")

#text("As for how to turn exact division and remainder calculations with compile-time constant divisors into runtime multiplications, see ")#link("https://lemire.me/blog/2019/02/08/faster-remainders-when-the-divisor-is-a-constant-beating-compilers-and-libdivide/")[#text("https://lemire.me/blog/2019/02/08/faster-remainders-when-the-divisor-is-a-constant-beating-compilers-and-libdivide/")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b756d9448435615f916b7a2af172ac1c778f1484038d1ecbb86225bb444ce9f8-f377d0cf0304740e39f03a6957cbdf9a5a098c29e243323b2a810531927a4c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthieu Rosenfeld")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687746")[#strong[#text("Matthieu Rosenfeld")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2025")])]

#text("I have added the last source code to my git repo [ ")#link("https://gite.lirmm.fr/mrosenfeld/guy-selfridgeconj/-/blob/main/RangeOfValuesWithEpsilonSpecialDivisors.cpp?ref_type=heads")[#text("https://gite.lirmm.fr/mrosenfeld/guy-selfridgeconj/-/blob/main/RangeOfValuesWithEpsilonSpecialDivisors.cpp?ref_type=heads")]#text(" ]. I have tried to add some comments to make it more readable, but I might still be missing some comments. I will try to learn how to do a pull request this afternoon (europe afternoon).")

#text("I have also added to this git the output of the run with ")#mi("10^{11}")#text(" (with the output of /bin/time -v in the file aswell have time and memory consumption). It ran for 15h and used 218GB of RAM. Theoreticaly the running time should be sublinear: for a given integer $n$ it should be proportional to ")#mi("\\pi{n}")#text(", and we need to treat fewer number in ")#mi("[10^{10},10^{11}]")#text(" than in ")#mi("[10^{9},10^{10}]")#text(" because the epsilon of margin is larger. It is also sublinear in practice (which is a surprise to me, as I was expecting cache misses and other problems to be really compensate): it takes ~6 minutes for ")#mi("10^8")#text(" which is roughly 150 times less than for ")#mi("10^{11}")#text(". Anyway, will all the tricks mentionned in previous comments, and the fact that we can still use even more powefull computers, we can still go a bit further than ")#mi("10^{11}")#text(" with this implementation if needed.")

#text("Note that if one starts with ")#mi("10^7")#text(" the heuristic becomes almost useless. It cost the same amount of time to try the heuristic with different parameters than to simply decrease the value of epsilon until it works. On the other hand the array that keeps the number of primes in the factorization of a number is only usefull for this heuristic. So I simply removed the heuristic from this version of the code (it also simplifies the code a bit).")

#text("Interestingly, the greedy procedure finds a solution with epsilon = 60 at almost every value after ")#mi("10^10")#text(". This means we find $n$ factors of size at least ")#mi("(n\\times(1000+60)/1000)/3")#text(" (keep in mind that all the divisions are integer divisions). ")#mi("3/1.06 = 2.83")#text(" which is not much larger than ")#mi("e")#text(".")

#text("I do not know when it starts to find solution with epsilon = 70, as it it currently not one the considered parameters.")

#text("other implementation details for those who might look at the code (this also adress some details from the few previous comments ):")

#text("* I am using cc_hash_map they are more efficient than stl::unordered_map, but they might not be available if you are not using g++ on a linux machine (as far as I understand the ext/pb_ds/assoc_container.hpp is part of gcc/g++, but I am not sure…). Also they seem to occupy more memory than stl::unordered_map, so if needed we could simply replace them to go a bit further. In fact, someone more competent with hashmaps, might be able to replace it with a well chosen hashmap for the current usage…")

#text("* A large fraction of the computation time is spent on the precomputation. I suspect that this might be because writing in a really large hashmap is expensive (lots of cache misses ?). There might be easy trick that I do not know to make this part more efficient (without implementing more advanced sieves than Eratosthenes’).")

#text("* behavior for ")#mi("10^9")#text(" and ")#mi("10^{11}")#text(" is really different, so verifying if a small change improves something require to run the computation on large values and takes a lot of time.")

#text("* Although I have a couple of sanity checks, I cannot yet claim with sufficient certitude that there is not small glitchs in this code.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2025")])]

#text("That’s great news! I’ve added some comments on your ")#link("https://github.com/teorth/erdos-guy-selfridge/pull/14")[#text("associated pull request")]#text(" for some possible next steps (some of which would help with the “sanity checks”).")

#text("There has been a fair bit of progress on the github, by the way, beyond what is reported in the blog comments here; for instance, there is now a separate proof of Conjecture 2 in the asymptotic regime, although it is currently not clear how effective it can be made. I am getting close to completing the effective analysis of my own asymptotic construction, although it was messier than I expected; in the end, though, it should not involve any actual counting of large primes, as the effective prime number theorems in the literature appear to be sufficient to control error terms in ranges such as ")#mi("N \\approx 10^{11}")#text(", although I am yet to fully identify a set of parameters in which all the numerical conditions required for the construction to actually certify that ")#mi("t(N) \\geq N/3")#text(" are actually valid in this range. Will report later when I have some more conclusions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687755")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2025")])]

#text("Very provisionally, I found some parameter choices in my construction that resolve Conjecture 2 for ")#mi("N \\geq 10^{13}")#text(", two orders of magnitude higher than I expected. Am trying to tinker with the argument to see if one can do a little better than this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2025")])]

#text("After making explicit estimates of all error terms (which was significantly more tedious than anticipated, especially when trying to find ways to make the estimates not lose factors of two etc.), I was able to arrive at a numerical criterion for verifying Conjecture 2 for ")#mi("N geq N_0")#text(" for any given ")#mi("N_0")#text(", provided that one supplies some supplemental parameters ")#mi("A,K,L")#text(" that verify some complicated numerical inequalities. With ")#link("https://github.com/teorth/erdos-guy-selfridge/blob/main/src/python/calculations.py")[#text("a little bit of python")]#text(" and some trial and error I could verify these conditions for ")#mi("N_0 =10^{12}")#text(" with very little room to spare; so there may be a little bit of leeway to push this down, but probably not all the way to meet the greedy algorithm at ")#mi("10^{11}")#text(" unfortunately. The theoretical justification of the criterion is in the ")#link("https://github.com/teorth/erdos-guy-selfridge/blob/main/LaTeX/notes.pdf")[#text("draft version of the paper here")]#text(", though I need to proofread it further.")

#text("I will have to turn attention to other matters for a bit, but hopefully only a small amount of additional effort will be needed to fully settle the Guy-Selfridge conjecture.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0a843b233e16e43db809fd52c0e601152aaf348c457214e2a1d49c9581b7dc4-97c39545e606c20f62c8de8bb5e339087b9b5f503c9757987c1d939f766264da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evan Conway")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687772")[#strong[#text("Evan Conway")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2025")])]

#text("Since we now need to extend this to reach $10^{12}$, here are some questions / comments I had on improving the code:")

#list(
[#text("Is there a particular reason the code using a hashmap rather than an array? I was looking at accesses and it looked like every number in the range was being accessed by the sieve, so I’m unclear why an array wouldn’t be used instead.")],
[#text("For the sieve, I agree that there’s a good chance that that’s being slowed down by cache issues. Currently, it looks like the code is looping through primes one at a time (2, 3, 5, etc) and then going through and marking down all those multiples. I would imagine this would lead to a large number of cache misses. My thought is to switch to an array (as mentioned in the last bullet) and then sieve each block one at a time, sieving all numbers in that block. This way you only access each block once.")],
[#text("This seems to have some good details on fast prime sieving: ")#link("https://github.com/kimwalisch/primesieve/blob/master/doc/ALGORITHMS.md")[#text("https://github.com/kimwalisch/primesieve/blob/master/doc/ALGORITHMS.md")]],
[#text("I notice that currently, 2 is one of the primes that is sieved. I’m unsure how much time this takes up, but one possible optimization is to use the optimization Kevin Ventullo suggested and just handle checking for divisors of power 2 directly, when you’re actually running the greedy algorithm.")],
[#text("I’m wondering if you can exploit the jumps of $N * (epsilon / 1000)$ to decrease the number of factorizations you need to store. Specifically, I was thinking that instead of jumping by $N * (epsilon / 1000)$, you could jump to the first multiple of 1024 (for example) before $N * (1 + epsilon / 1000)$. The idea here is that you could then just check $N / 1024$ to get the remaining factorization. If I’m thinking about this correctly, I believe you could get a very large decrease in the number of factorizations you need to store, at a relatively low cost.")],
[#text("You’ve probably already accounted for this, but what compiler flags are you using? If you’re not using -O3 and -march=native, that often gives a decent constant-factor speedup.")]
)

#text("Please let me know what you think of this. Also, take this all with a grain of salt, since I haven’t had a chance to properly look at what’s taking up the most time in the code (premature optimization is the root of all evil, etc).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687774")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2025")])]

#text("It might be worth switching languages away from python at this point. Julia might be a good candidate here as it will have much better runtime than Python, good datastructes and the Primes.jl package which has very fast primality testing and factorization of small numbers, and a pretty decent prime sieve. I’d be happy to help with the translation if desired.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687754")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2025")])]

#text("Here’s a wacky idea. I don’t know whether it goes anywhere. We begin with the (integer) linear programming formulation as described in this comment: ")#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")[#text("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/")]

#text("It is to find natural ")#mi("\\{x_j\\}_{j=t}^N")#text(" maximizing ")#mi("\\sum_j x_j")#text(" subject to the constraints ")#mi("\\sum_j v_p(j) x_j \\le v_p(N!)")#text(" for each prime ")#mi("p")#text(". This is a faithful translation of the original problem (assuming the factors don’t exceed $N$).")

#text("What if we make the problem harder? What if we instead have constraints for each prime power ")#mi("q")#text(" that ")#mi("\\sum_{q\\mid j} x_j \\le N/q")#text("? By summing over all powers ")#mi("q")#text(" of the same prime ")#mi("p")#text(" (and taking a floor on the RHS), we would recover the original constraints, so this is a harder problem.")

#text("I ran some experiments and I find that solutions with ")#mi("t=N/3")#text(" seem to exist for ")#mi("N\\ge 50000")#text(" or so, perhaps only slightly worse than the original Conjecture 2. (")#mi("N=43632")#text(" does fail.) I would boldly conjecture that for this problem, it’s also the case that ")#mi("t(n)/n \\to 1/e")#text("…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687771")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2025")])]

#text("Some brief comments regarding computing the constant ")#mi("c_0")#text(". Split the floor function ")#mi("\\lfloor y \\rfloor = y-\\{y\\}")#text(" to get two different integrals.")

#text("The integral with ")#mi("y")#text(" can then be written, essentially, in terms of the infinite sum ")#mi("\\sum_{k=1}^\\infty \\log^2(1+1/k)")#text(". This infinite series can basically be computed to any desired precision by series acceleration techniques, for instance Kummer’s transformation.")

#text("The integral with the fractional part ")#mi("\\{y\\}")#text(" is still tricky, but here one has gained a factor of ")#mi("y^{-1}")#text(" when trivially bounding the tail, so this should allow one to squeeze out some more digits of accuracy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2025")])]

#text("In the ")#link("https://github.com/teorth/erdos-guy-selfridge/pull/27")[#text("latest version")]#text(" of the draft paper, I have managed to optimize the explicit form of the asymptotic construction to the point where it (barely) works down to ")#mi("N \\geq 10^{11}")#text(", improving from the previous ")#mi("N \\geq 10^{12}")#text(". Subject to checking both the numerics and the theoretical analysis, this now fully resolves the Guy-Selfridge conjectures.")

#text("However, the estimates are delicate, and it would be good to have more of a safety margin. I’ve set the construction up so that one has to verify two numerical conditions ")#mi("\\sum_{i=1}^8 \\delta_i \\leq \\delta")#text(" and ")#mi("\\sum_{i=1}^7 \\alpha_i \\leq 1")#text(" in order to verify a claim such as ")#mi("t(N) \\geq N/3")#text(". For ")#mi("N=10^{11}")#text(", I was able to numerically locate parameters for which ")#mi("\\sum_{i=1}^8 \\delta_i \\leq 0.9729 \\delta")#text(" and ")#mi("\\sum_{i=1}^7 \\alpha_i \\leq 0.9627")#text("; so one wins, but only barely. There may be some play in optimizing the parameters further to widen the safety margin and perhaps lower the threshold for ")#mi("N")#text(" somewhat.")

#text("One consequence of having such little margin of error is that one has to retain more terms in the effective estimates than I would like; I am accustomed to, say, bounding ")#mi("X+Y")#text(" by ")#mi("2 \\mathrm{max}(X,Y)")#text(" because the factor of 2 is usually something I can afford to lose, but these sorts of simplifying moves are basically not available except for some extremely small lower order terms, and the argument has become quite complicated. Having more of a margin of error would also allow some simplifications to the theoretical analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687782")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2025")])]

#text("An unfortunate update: it turns out that the estimates I was using were non-monotone in ")#mi("N")#text("; so while they do verify the conjecture precisely at ")#mi("N = 10^{11}")#text(", they do not necessarily cover the entire range ")#mi("N \\geq 10^{11}")#text(", and similarly for the previous verification at ")#mi("N = 10^{12}")#text(". (The asymptotic verification for sufficiently large ")#mi("N")#text(" is still fine, though.) In the efforts to optimize the estimates, I started saving negative terms in order to use them to cancel some positive terms; but this caused the issue that the difference of two monotone decreasing functions is not necessarily monotone decreasing.")

#text("The failure of monotonicity is somewhat mild, but cannot be easily addressed in the ")#mi("N \\approx 10^{11}")#text(" regime where there is so little margin of error available. I will probably have to resort to ")#link("https://en.wikipedia.org/wiki/Interval_arithmetic")[#text("interval arithmetic")]#text(" to rigorously quantify the errors here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687788")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2025")])]

#text("Second update: the interval arithmetic approach works; coverage of the entire region ")#mi("N \\geq 10^{11}")#text(", and the Guy-Selfridge conjectures are once again fully proved (assuming no further bugs in either the code or the theoretical analysis, of course).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687783")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2025")])]

#strong[#text("Is a generalization to z-smooth numbers possible?")]

#enum(start: 1, 
[#strong[#text("z-smooth ceiling (min z-smooth >= x ):")]]
)

#text("Introduce a cutoff L≤x, e.g. $ latex L = \\log ^2 n$, and define:")

#raw("")

#enum(start: 2, 
[#strong[#text("Rounding-error constant:")]]
)

#raw("")

#enum(start: 3, 
[#strong[#text("Oscillatory-loss function:")]]
)

#raw("")

#strong[#text("Lower bound")]#linebreak()#text("Construct an admissible factorization using z-smooth numbers:")

#enum(start: 1, 
[#text("Fix ")#mi("\\alpha < 1")#text(", and set ")#mi("t = \\alpha N")#text(".")],
[#text("Choose a smoothness bound ")#mi("z")#text(", define ")#mi("\\mathcal{{P}}_z = \\{{ p  \\le  z \\}}")#text(" and ")#mi("M =  \\prod_{{p   \\le z}} p")#text(".")],
[#text("Pick parameters ")#mi("A")#text(" and ")#mi("\\sigma")#text(" such that")#linebreak()#mi("A t  \\ln(1 + \\sigma ) = N")#text(" and ")#mi("\\sigma = \\frac{{  \\pi (z) N}}{{A t}}")#text(".")],
[#text("Define the multiset ")#mi("\\mathcal{{E}}^{{(0)}}")#text(" to be ")#mi("A")#text(" copies of all z-rough integers in ")#mi("(t, t(1 + \\sigma)]")#text(".")],
[#text("For each prime ")#mi("p > z")#text(", repair the deficit ")#mi("\\Delta_p")#text(" in the factorization by swapping in factors")#linebreak()#mi("\\lceil p/t  \\rceil_{{mathcal{{P}}_z}}^{{(L)}} \\cdot t")#text(",")#linebreak()#text("each costing at most ")#mi("\\kappa_L(z)")#text(" in log-space.")],
[#text("For primes ")#mi("p  \\le z")#text(", use the supply from N! to fill in missing p-powers with z-smooth replacements, also at cost ")#mi("\\kappa_L(z)")#text(" per use.")],
[#text("The initial log-product of the approximate factorization satisfies")#linebreak()#mi("\\sum_{{a  \\in \\mathcal{{E}}^{{(0)}}}}  \\ln a  \\approx N")#text(",")#linebreak()#text("and by Stirling’s approximation, this leaves a small excess log-budget of ")#mi("O(N /  \\ln N)")#text(".")],
[#text("The total cost to fix all prime discrepancies is ")#mi("O( \\kappa_L(z) N)")#text(", which is ")#mi("o(N)")#text(" if ")#mi("\\kappa_L(z) \\to 0")#text(" (e.g., with ")#mi("L = \\log^2 N")#text(").")]
)

#text("Therefore, a full admissible factorization exists, so")#linebreak()#mi("t(N) \\ge \\alpha N")#text(".")

#text("This generalizes the 3-smooth case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-687785")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2025")])]

#text("Yes, the method I gave for the 3-smooth case should also work for other thresholds, though I believe the quantitative bounds become worse for medium values of ")#mi("N")#text(" due to the increased size of the primorial. Asymptotically, this might help improve the convergence bounds on ")#mi("t(N)/N")#text(", though instead of just using irrationality of a single ratio ")#mi("\\log 3/\\log 2")#text(", one needs some joint incommensurability assertions about multiple logarithms, which the vanilla version of Baker’s theorem is not particularly good at getting strong bounds on (but perhaps there are some other results in transcendence theory that could be useful here).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Decomposing a factorial into large factors (second version) | What's new")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-688246")[#strong[#text("Decomposing a factorial into large factors (second version) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2025")])]

#text("[…] a factorial into large factors“. This is a completely rewritten and expanded version of a previous paper of the same name. Thanks to many additional theoretical and numerical contributors from the other coauthors, we now […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/831da2ac9da5ea6418bf957c4fc82d3790b4d9c02e085a2b9a46a28caec3335f-ad5527be1bed9dd628fa60a6bf06cf3c5396f65d761d29db1c0b25ac0d1736a0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Guy-Selfridge Conjecture – Kevin Ventullo")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-688265")[#strong[#text("The Guy-Selfridge Conjecture – Kevin Ventullo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("[…] Rosenfeld, Andrew Sutherland, Terence Tao, and Markus Uhr on a problem posed in this blog post by Tao, which has now culminated in a joint […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/03/26/decomposing-a-factorial-into-large-factors/#comment-688429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2025")])]

#text("Why don’t we fit a regression model to the difference between actual log N! and Stirling’s approximation, to learn the correction behavior more precisely — maybe even optimize it?")
]
