// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:34:57.189258+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: The parity problem in sieve theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: The parity problem in sieve theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 June 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The parity problem is a notorious problem in ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(": this theory was invented in order to count prime patterns of various types (e.g. twin primes), but despite superb success in obtaining upper bounds on the number of such patterns, it has proven to be somewhat disappointing in obtaining lower bounds. [Sieves can also be used to study many other things than primes, of course, but we shall focus only on primes in this post.] Even the task of reproving ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(" – that there are infinitely many primes – seems to be extremely difficult to do by sieve theoretic means, unless one of course injects into the theory an estimate at least as strong as Euclid’s theorem (e.g. the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text("). The main obstruction is the ")#emph[#text("parity problem")]#text(": even assuming such strong hypotheses as the ")#link("http://en.wikipedia.org/wiki/Elliott-Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" (a sort of “super-generalised Riemann Hypothesis” for sieves), sieve theory is largely (but not completely) unable to distinguish numbers with an odd number of prime factors from numbers with an even number of prime factors. This “parity barrier” has been broken for some select patterns of primes by injecting some powerful non-sieve theory methods into the subject, but remains a formidable obstacle in general.")

#text("I’ll discuss the parity problem in more detail later in this post, but I want to first discuss how sieves work [drawing in part on some excellent unpublished lecture notes of Iwaniec]; the basic ideas are elementary and conceptually simple, but there are many details and technicalities involved in actually executing these ideas, and which I will try to suppress for sake of exposition.")

#metadata(none) <tao-9479103d2e6492d8fb16>

#text("Let’s consider a basic question in prime number theory, namely how to count the number of primes in a given range, say between N and 2N for some large integer N. (This problem is more or less equivalent to that of counting primes between 1 and N, thanks to dyadic decomposition, but by keeping the magnitude of all numbers comparable to N we can simplify some (very minor) technicalities.) Of course, we know that this particular question can be settled fairly satisfactorily (the answer is ")#mi("(1+o(1)) \\frac{N}{\\log N}")#text(") using known facts about the ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(", but let us pretend for now that we do not know about this function. (Once one moves to slightly more complicated additive questions about the primes, such as counting twin primes, the theory of the zeta function and its relatives becomes much less powerful, even assuming such things as the Riemann hypothesis; the problem is that these functions are measuring the ")#emph[#text("multiplicative")]#text(" structure of the primes rather than the additive structure.)")

#text("The set of primes does not appear to have enough usable structure in order to perform such counts quickly. However, one can count other sets of numbers between N and 2N with much more ease. For instance, the set of integers between N and 2N can be easily counted with small error:")

#align(center)[#tao-math("\\left| \\{ n \\in [N,2N]: n \\text{ integer} \\}\\right| = N + O(1)", block: false)#text(";")]

#text("the error term O(1) in this case is in fact just 1. Similarly, we can count, say, the number of odd numbers between N and 2N,")

#align(center)[#tao-math("\\left| \\{ n \\in [N,2N]: n \\text{ odd} \\}\\right| = \\frac{1}{2} N + O(1)", block: false)#text(",")]

#text("simply because the set of odd numbers has density ")#mi("\\frac{1}{2}")#text(" and is periodic of period 2. The error term O(1) now depends on the parity of N. More generally, we can count any given residue class in [N,2N] to a reasonable accuracy:")

#align(center)[#tao-math("\\left| \\{ n \\in [N,2N]: n = a\\mod q \\}\\right| = \\frac{1}{q} N + O(1)", block: false)#text(",")]

#text("where the error term is now more complicated, and depends on what N is doing modulo q. This estimate is quite good as long as q is small compared with N, but once q is very large, the error term O(1) can begin to overwhelm the main term (especially if the main term is going to appear in a delicate summation with lots of cancellation). In general, any summation involving the main term N/q will be relatively easy to manipulate (because it is essentially multiplicative in q, and thus amenable to all the methods of multiplicative number theory, in particular ")#link("http://en.wikipedia.org/wiki/Euler_product")[#text("Euler products")]#text(" and zeta functions); it is the error term O(1) which causes all the difficulty.")

#text("Once we have figured out how to count these basic sets, we can also count some combinations of these sets, as long as these combinations are simple enough. For instance, suppose we want to count")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1).")])
#tao-math("\\left| \\{ n \\in [N,2N]: n \\text{ coprime to } 2,3 \\}\\right|", block: true)]]

#text("Well, we know that the total number of integers in [N,2N] is N+O(1). Of this set, we know that ")#mi("\\frac{1}{2} N + O(1)")#text(" are not coprime to 2 (i.e. divisible by 2), and that ")#mi("\\frac{1}{3} N + O(1)")#text(" are not coprime to 3. So we should subtract those two sets from the original set, leaving ")#mi("\\frac{1}{6}N + O(1)")#text(". But the numbers which are divisible by both 2 and 3 (i.e. divisible by 6) have been subtracted twice, so we have to put them back in; this adds in another ")#mi("\\frac{1}{6} N + O(1)")#text(", giving a final count of ")#mi("\\frac{1}{3} N + O(1)")#text(" for the quantity (1); this is of course a simple instance of the ")#link("http://en.wikipedia.org/wiki/Inclusion-exclusion_principle")[#text("inclusion-exclusion principle")]#text(" in action. An alternative way to estimate (1) is to use the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text(" to rewrite (1) as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\in [N,2N]: n = 1,5 \\mod 6 \\}\\right|", block: true)]]

#text("and use our ability to count residue classes modulo 6 to get the same final count of ")#mi("\\frac{1}{3} N + O(1)")#text(" (though the precise bound on the error term will be slightly different). For very small moduli such as 2 and 3, the Chinese remainder theorem is quite efficient, but it is somewhat rigid, and for higher moduli (e.g. for moduli much larger than ")#mi("\\log N")#text(") it turns out that the more flexible inclusion-exclusion principle gives much better results (after applying some tricks to optimise the efficiency of that principle).")

#text("We can of course continue the example in (1), counting the numbers in [N,2N] which are coprime to 2,3,5,7, etc., which by the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(" will eventually give us a count for the primes in [N,2N], but let us pause for a moment to look at the larger picture. We have seen that some sets in [N,2N] are fairly easy to count accurately (e.g. residue classes with small modulus), and others are not (e.g. primes, twin primes). What is the defining characteristic of the former types of sets? One reasonable answer is that the sets that are easy to count are ")#emph[#text("low-complexity")]#text(", but this is a rather vaguely defined term. I would like to propose instead that sets (or more generally, weight functions – see below) are easy to count (or at least estimate) whenever they are ")#emph[#text("smooth")]#text(" in a certain sense to be made more precise shortly. This terminology comes from harmonic analysis rather than from number theory (though number theory does have the related concept of a ")#link("http://en.wikipedia.org/wiki/Smooth_number")[#text("smooth number")]#text("), so I will now digress a little bit to talk about smoothness, as it seems to me that this concept implicitly underlies the basic strategy of sieve theory.")

#text("Instead of talking about the problem of (approximately) counting a given set in [N,2N], let us consider instead the analogous problem of (approximately) computing the area of a given region E (e.g. a solid ellipse) in the unit square ")#mi("{}[0,1]^2")#text(". As we are taught in high school, one way to do this is to subdivide the square into smaller squares, e.g. squares of length ")#mi("10^{-n}")#text(" for some n, and count how many of these small squares lie completely or partially in the set E, and multiply by the area of each square; this is of course the prelude to the ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integral")]#text(". It works well as long as the set E is “smooth” in the sense that most of the small squares are either completely inside or completely outside the set E, with few borderline cases; this notion of smoothness can also be viewed as a quantitative version of Lebesgue measurability. Another way of saying this is that if one wants to determine whether a given point (x,y) lies in E, it is usually enough just to compute x and y to the first n significant digits in the decimal expansion.")

#text("Now we return to counting sets in [N,2N]. One can also define the notion of a “smooth set” here by again using the most significant digits of the numbers n in the interval [N,2N]; for instance, the set [1.1 N, 1.2 N] would be quite smooth, as one would be fairly confident whether n would lie in this set or not after looking at just the top two or three significant digits. However, with this “Euclidean” or “")#link("http://en.wikipedia.org/wiki/Archimedean_principle")[#text("Archimedean")]#text("” notion of smoothness, sets such as the primes or the odd numbers are certainly not smooth. However, things look a lot better if we change the metric, or (more informally) if we redefine what “most significant digit” is. For instance, if we view the ")#emph[#text("last")]#text(" digit in the base 10 expansion of a number n (i.e. the value of ")#mi("n \\mod 10")#text(") as the most significant one, rather than the first – or more precisely, if we use the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#text("10-adic")]#text(" metric intead of the Euclidean one, thus embedding the integers into ")#mi("{\\Bbb Z}_{10}")#text(" rather than into ")#mi("{\\Bbb R}")#text(" – then the odd numbers become quite smooth (the most significant digit completely determines membership in this set). The primes in [N,2N] are not fully smooth, but they do exhibit some partial smoothness; indeed, if the most significant digit is 0, 2, 4, 5, 6, or 8, this fully determines membership in the set, though if the most significant digit is 1, 3, 7, or 9 then one only has partial information on membership in the set.")

#text("Now, the 10-adic metric is not fully satisfactory for characterising the elusive concept of number-theoretic “smoothness”. For instance, the multiples of 3 should be a smooth set, but this is not the case in the 10-adic metric (one really needs ")#emph[#text("all ")]#text("the digits before one can be sure whether a number is a multiple of 3!). Also, we have the problem that the set [N/2,N] itself is now no longer smooth. This can be fixed by working not with just the Euclidean metric or a single n-adic metric, but with the product of all the n-adic metrics and the Euclidean metric at once. Actually, thanks to the Chinese remainder theorem, it is enough to work with the product of the p-adic metrics for primes p and the Euclidean metric, thus embedding the integers in the ")#link("http://en.wikipedia.org/wiki/Adele_ring")[#text("integer adele ring")]#text(" ")#mi("{\\Bbb R} \\times \\prod_p {\\Bbb Z}_p")#text(". For some strange reason, this adele ring is not explicitly used in most treatments of sieve theory, despite its obvious relevance (and despite the amply demonstrated usefulness of this ring in algebraic number theory or in the theory of L-functions, as exhibited for instance by Tate’s thesis). At any rate, we are only using the notion of “smoothness” in a very informal sense, and so we will not need the full formalism of the adeles here. Suffice to say that a set of integers in [N,2N] is “smooth” if membership in that set can be largely determined by its most significant digits in the Euclidean sense, and also in the p-adic senses for small p; roughly speaking, this means that this set is approximately the pullback of some “low complexity” set in the adele ring – a set which can be efficiently fashioned out of a few of basic sets which generate the topology and ")#mi("\\sigma")#text("-algebra of that ring. (Actually, in many applications of sieve theory, we only need to deal with moduli q which are square-free, which means that we can replace the p-adics ")#mi("{\\Bbb Z}_p")#text(" with the cyclic group ")#mi("{\\Bbb Z}/p{\\Bbb Z}")#text(", and so it is now just the residues mod p for small p, together with the Euclidean most significant digits, which should control what smooth sets are; thus the adele ring has been replaced by the product ")#mi("{\\Bbb R} \\times \\prod_p ({\\Bbb Z}/p{\\Bbb Z})")#text(".)")

#text("Let us now return back to sieve theory, and the task of counting “rough” sets such as the primes in [N,2N]. Since we know how to accurately count “smooth” sets such as ")#mi("\\{ n \\in [N,2N]: n = a \\mod q \\}")#text(" with q small, one can try to describe the rough set of primes as some sort of combination of smooth sets. The most direct implementation of this idea is the sieve of Eratosthenes; if one then tries to compute the number of primes using the inclusion-exclusion principle, one obtains the ")#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("Legendre sieve")]#text("; we implicitly used this idea previously when counting the quantity (1). However, the number of terms in the inclusion-exclusion formula is very large; if one runs the sieve of Eratosthenes for k steps (i.e. sieving out multiples of the first k primes), there are basically ")#mi("2^k")#text(" terms in the inclusion-exclusion formula, leading to an error term which in the worst case could be of size ")#mi("O(2^k)")#text(". A related issue is that the modulus q in many of the terms in the Legendre sieve become quite large – as large as the product of the first k primes (which turns out to be roughly ")#mi("e^k")#text(" in size). Since the set one is trying to count is only of size N, we thus see that the Legendre sieve becomes useless after just ")#mi("\\log N")#text(" or so steps of the Eratosthenes sieve, which is well short of what one needs to accurately count primes (which requires that one uses ")#mi("N^{1/2}/\\log N")#text(" or so steps). More generally, “exact” sieves such as the Legendre sieve are useful for any situation involving only a logarithmically small number of moduli, but are unsuitable for sieving with much larger numbers of moduli.")

#text("One can describe the early development of sieve theory as a concerted effort to rectify the drawbacks of the Legendre sieve. The first main idea here is to not try to compute the size of the rough set exactly – as this is too “expensive” in terms of the number of smooth sets required to fully describe the rough set – but instead to just settle for upper or lower bounds on the size of this set, which use fewer smooth sets. There is thus a tradeoff between how well the bounds approximate the original set, and how well one can compute the bounds themselves; by selecting various parameters appropriately one can optimise this tradeoff and obtain a final bound which is non-trivial but not completely exact. For instance, in using the Legendre sieve to try to count primes between N and 2N, one can instead use that sieve to count the much larger set of numbers between N and 2N which are coprime to the first k primes, thus giving an upper bound for the primes between N and 2N. It turns out that the optimal value of k here is roughly ")#mi("\\log N")#text(" or so (after this, the error terms in the Legendre sieve get out of hand), and give an upper bound of ")#mi("O( N / \\log \\log N )")#text(" for the number of primes between N and 2N – somewhat far from the truth (which is ")#mi("\\sim N/\\log N")#text("), but still non-trivial.")

#text("In a similar spirit, one can work with various truncated and approximate versions of the inclusion-exclusion formula which involve fewer terms. For instance, to estimate the cardinality ")#tao-math("\\left|\\bigcup_{j=1}^k A_j\\right|", block: false)#text(" of the union of k sets, one can replace the inclusion-exclusion formula")

#tao-aligned(keep: true)[


#tao-math("\\left|\\bigcup_{j=1}^k A_j\\right|  & = \\sum_{j=1}^k \\left|A_j\\right| - \\sum_{1 \\leq j_1 < j_2 \\leq k} \\left|A_{j_1} \\cap A_{j_2}\\right|", block: true)



#tao-math(" & +\\sum_{1 \\leq j_1 < j_2 < j_3 \\leq k} |A_{j_1}\\cap A_{j_2} \\cap A_{j_3}| \\ldots", block: true, numbering: n => [#text("(2)")])
]

#text("by the obvious upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{j=1}^k A_j\\right| \\leq \\sum_{j=1}^k \\left|A_j\\right|", block: true)]]

#text("(also known as the ")#emph[#text("union bound")]#text("), or by the slightly less obvious lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigcup_{j=1}^k A_j\\right| \\geq \\sum_{j=1}^k \\left|A_j\\right| - \\sum_{1 \\leq j_1 < j_2 \\leq k} |A_{j_1} \\cap A_{j_2}|.", block: true)]]

#text("More generally, if one takes the first n terms on the right-hand side of (2), this will be an upper bound for the left-hand side for odd n and a lower bound for even n. These inequalities, known as the ")#link("http://planetmath.org/encyclopedia/BonferroniInequalities.html")[#text("Bonferroni inequalities")]#text(", are a nice exercise to prove: they are equivalent to the observation that in the binomial identity")

#align(center)[#tao-fit-display[#mitex("0 = (1-1)^m = \\binom{m}{0} - \\binom{m}{1} + \\binom{m}{2} - \\binom{m}{3} + \\ldots + (-1)^m \\binom{m}{m}")]]

#text("for any ")#mi("m \\geq 1")#text(", the partial sums on the right-hand side alternate in sign between non-negative and non-positive. If one inserts these inequalities into the Legendre sieve and optimises the parameter, one can improve the upper bound for the number of primes in [N,2N] to ")#mi("O( N \\log \\log N / \\log N )")#text(", which is significantly closer to the truth. Unfortunately, this method does not provide any lower bound other than the trivial bound of 0; either the main term is negative, or the error term swamps the main term. A similar argument was used by Brun to show that the number of twin primes in [N,2N] was ")#mi("O( N (\\log \\log N / \\log N)^2 )")#text(" (again, the truth is conjectured to be ")#mi("\\sim N / \\log^2 N")#text("), which implied his famous theorem that the sum of reciprocals of the twin primes is convergent.")

#text("The full inclusion-exclusion expansion is a sum over ")#mi("2^k")#text(" terms, which one can view as binary strings of 0s and 1s of length k. In the Bonferroni inequalities, one only sums over a smaller collection of strings, namely the ")#link("http://en.wikipedia.org/wiki/Hamming_distance")[#text("Hamming ball")]#text(" of strings which only involve n or fewer 1s. There are other collections of strings one can use which lead to upper or lower bounds; one can imagine revealing such a string one digit at a time and then deciding whether to keep or toss out this string once some threshold rule is reached. There are various ways to select these thresholding rules, leading to the family of ")#emph[#text("combinatorial")]#text(" sieves. One particularly efficient such rule is similar to that given by the Bonferroni inequalities, but instead of using the number of 1s in a string to determine membership in the summation, one uses a ")#emph[#text("weighted")]#text(" number of 1s (giving large primes more weight than small primes, because they tend to increase the modulus too quickly and thus should be removed from the sum sooner than the small primes). This leads to the ")#emph[#text("beta sieve")]#text(", which for instance gives the correct order of magnitude of ")#mi("O( N / \\log N )")#text(" for the number of primes in [N,2N] or ")#mi("O( N / \\log^2 N )")#text(" for the number of twin primes in [N,2N]. This sieve is also powerful enough to give lower bounds, but only if one stops the sieve somewhat early, thus enlarging the set of primes to a set of ")#emph[#text("almost primes")]#text(" (numbers which are coprime to all numbers less than a certain threshold, and thus have a bounded number of prime factors). For instance, this sieve can show that there are an infinite number of twins ")#mi("n, n+2")#text(", each of which has at most nine prime factors (the nine is not optimal, but to get better results requires much more work).")

#text("There seems however to be a limit as to what can be accomplished by purely combinatorial sieves. The problem stems from the “binary” viewpoint of such sieves: any given term in the inclusion-exclusion expansion is either included or excluded from the sieve upper or lower bound, and there is no middle ground. This leads to the next main idea in modern sieve theory, which is to work not with the cardinalities of sets in [N,2N], but rather with more flexible notion of sums of weight functions (real-valued functions on [N,2N]). The starting point is the obvious formula")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| = \\sum_{n \\in [N, 2N]} 1_A(n)", block: true)]]

#text("for the cardinality of a set A in [N,2N], where ")#mi("1_A")#text(" is the indicator function of the set A. Applying this to smooth sets such as ")#mi("\\{ n \\in [N,2N]: n = a \\mod q\\}")#text(", we obtain")

#align(center)[#mi("\\sum_{n \\in [N, 2N]} 1_{n=a \\mod q}(n) = \\frac{N}{q} + O(1)")#text(";")]

#text("in particular, specialising to the 0 residue class a = 0 (which is the residue class of importance for counting primes) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in [N,2N]} 1_{d|n}(n) = \\frac{N}{d} + O(1)")]]

#text("for any d. Thus if we can obtain a pointwise upper bound on ")#mi("1_A")#text(" by a divisor sum (which is a number-theoretic analogue of a ")#emph[#text("smooth function")]#text("), thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("1_A(n) \\leq \\sum_{d} c_d 1_{d|n}(n)")]]

#text("for all n and some real constants ")#mi("c_d")#text(" (which could be positive or negative), then on summing we obtain the upper bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|A\\right| \\leq N \\sum_{d} \\frac{c_d}{d} + O( \\sum_d \\left|c_d\\right| ).", block: true)]]

#text("One can also hope to obtain lower bounds on |A| by a similar procedure (though in practice, lower bounds for primes have proven to be much more difficult to obtain, due to the parity problem which we will discuss below). These strategies are suited for the task of bounding the number of primes in [N,2N]; if one wants to do something fancier such as counting twin primes n, n+2, one has to either involve more residue classes (e.g. the class a = -2 will play a role in the twin prime problem) or else insert additional weights in the summation (e.g. weighting all summations in n by an additional factor of ")#mi("\\Lambda(n+2)")#text(", where ")#mi("\\Lambda")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text("). To simplify the exposition let us just stick with the plainer problem of counting primes.")

#text("These strategies generalise the combinatorial sieve strategy, which is a special case in which the constants ")#mi("c_d")#text(" are restricted to be +1, 0, or -1. In practice, the sum ")#mi("\\sum_{d} \\frac{c_d}{d}")#text(" in (4) is relatively easy to sum by multiplicative number theory techniques (the coefficients ")#mi("c_d")#text(", in applications, usually involve the ")#link("http://en.wikipedia.org/wiki/Mobius_function")[#text("Möbius function")]#text(" (not surprising, since they are encoding some sort of inclusion-exclusion principle) and are often related to the coefficients of a ")#link("http://en.wikipedia.org/wiki/Hasse-Weil_zeta_function")[#text("Hasse-Weil zeta function")]#text(", as they basically count solutions modulo d to some set of algebraic equations), and the main task is to ensure that the error term in (3) does not swamp the main term. To do this, one basically needs the weights ")#mi("c_d")#text(" to be concentrated on those d which are relatively small compared with N, for instance they might be restricted to some range ")#mi("d \\leq R")#text(" where the ")#emph[#text("sieve level")]#text(" ")#mi("R = N^\\theta")#text(" is some small power of N. Thus for instance, starting with the identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\Lambda(n) = \\sum_{d|n} \\mu(d) \\log\\frac{n}{d} = -\\sum_{d|n} \\mu(d) \\log(d),")]]

#text("which corresponds to the zeta-function identity")

#align(center)[#mi("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\zeta(s) \\frac{d}{ds} \\frac{1}{\\zeta(s)}")#text(",")]

#text("where ")#mi("\\Lambda")#text(" is the von Mangoldt function and ")#mi("\\mu")#text(" is the ")#link("http://en.wikipedia.org/wiki/Mobius_function")[#text("Möbius function")]#text(", we obtain the upper bound")

#align(center)[#tao-fit-display[#mitex("1_A(n) \\leq - \\sum_{d \\leq 2N} \\mu(d) \\frac{\\log d}{\\log N} 1_{d|n}")]]

#text("where A denotes the primes from N to 2N. This is already enough (together with the elementary asymptotic ")#mi("\\sum_{d \\leq 2N} \\frac{\\mu(d)}{d} \\log d = O(1)")#text(") to obtain the weak prime number theorem ")#tao-math("\\left|A\\right| = O( N / \\log N )", block: false)#text(", but unfortunately this method does not give a nontrivial lower bound for |A|. However, a variant of the method does give a nice asymptotic for ")#mi("P_2")#text(" ")#emph[#text("almost primes")]#text(" – products of at most two (large) primes [e.g. primes larger than ")#mi("N^\\epsilon")#text(" for some fixed ")#mi("\\epsilon > 0")#text("]. Indeed, if one introduces the second von Mangoldt function")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\Lambda_2(n) = \\sum_{d|n} \\mu(d) \\log^2(\\frac{n}{d}) = \\Lambda(n) \\log n + \\sum_{d|n} \\Lambda(d) \\Lambda(\\frac{n}{d})")]]

#text("which is mostly supported on ")#mi("P_2")#text(" almost primes (indeed, ")#mi("\\Lambda_2(p) = \\log^2 p")#text(" and ")#mi("\\Lambda_2(pq) = 2\\log p \\log q")#text(" for distinct primes p, q, and ")#mi("\\Lambda_2")#text(" is mostly zero otherwise), and uses the elementary asymptotic")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\leq N} \\frac{\\mu(d) }{d} \\log^2 \\frac{N}{d} = 2 \\log N + O(1)")]]

#text("then one obtains the ")#emph[#text("Selberg symmetry formula")]

#align(center)[#mi("\\sum_{n \\leq N} \\Lambda_2(N) = 2 N \\log N + O(N)")#text(".")]

#text("This formula (together with the weak prime number theorem mentioned earlier) easily implies an “")#mi("P_2")#text(" almost prime number theorem”, namely that the number of ")#mi("P_2")#text(" almost primes less than N is ")#mi("(2+o(1)) \\frac{N}{\\log N}")#text(". [This fact is much easier to prove than the prime number theorem itself. In terms of zeta functions, the reason why the prime number theorem is difficult is that the simple pole of ")#mi("\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}")#text(" at s=1 could conceivably be counteracted by other simple poles on the line ")#mi("\\text{Re}(s)=1")#text(". On the other hand, the ")#mi("P_2")#text(" almost prime number theorem is much easier because the effect of the ")#emph[#text("double")]#text(" pole of ")#mi("\\frac{\\zeta^{\\prime\\prime}(s)}{\\zeta(s)}")#text(" at s=1 is not counteracted by the other poles on the line ")#mi("\\text{Re}(s)=1")#text(", which are at most simple.]")

#text("The ")#mi("P_2")#text(" almost prime number theorem establishes the prime number theorem “up to a factor of 2”. It is surprisingly difficult to improve upon this factor of 2 by elementary methods, though once one can replace 2 by ")#mi("2-\\epsilon")#text(" for some ")#mi("\\epsilon > 0")#text(" (a fact which is roughly equivalent to the absence of zeroes of ")#mi("\\zeta(s)")#text(" on the line ")#mi("\\text{Re}(s)=1")#text("), one can iterate the Selberg symmetry formula (together with the tautological fact that an ")#mi("P_2")#text(" almost prime is either a prime or the product of two primes) to get the prime number theorem; this is essentially the Erdős-Selberg elementary proof of that theorem.")

#text("One can obtain other divisor bounds of the form (3) by various tricks, for instance by modifying the weights in the above formulae (5) and (6). A surprisingly useful upper bound for the primes between N and 2N is obtained by the simple observation that")

#align(center)[#tao-fit-display[#mitex("1_A(n) \\leq (\\sum_{d < N} \\lambda_d 1_{d|n}(n))^2")]]

#text("whenever ")#mi("\\lambda_d")#text(" are ")#emph[#text("arbitrary")]#text(" real numbers with ")#mi("\\lambda_1 = 1")#text(", basically because the square of any real number is non-negative. This leads to the ")#emph[#text("Selberg sieve")]#text(", which suffices for many applications; for instance, it can prove the ")#emph[#text("Brun-Titchmarsh inequality")]#text(", which asserts that the number of primes between N and N+M is at most ")#mi("(2+o(1)) M / \\log M")#text(", which is again off by a factor of 2 from the truth when N and M are reasonably comparable. There are also some useful lower bounds for the indicator function of the almost primes of divisor sum type, which can be used for instance to derive ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("Chen’s theorem")]#text(" that there are infinitely many primes p such that p+2 is a ")#mi("P_2")#text(" almost prime, or the theorem that there are infinitely many ")#mi("P_2")#text(" almost primes of the form ")#mi("n^2+1")#text(".")

#text("In summary, sieve theory methods can provide good upper bounds, lower bounds, and even asymptotics for almost primes, which lead to upper bounds for primes which tend to be off by a constant factor such as 2. Rather frustratingly, though, sieve methods have proven largely unable to count or even lower bound the primes themselves, thus leaving the twin prime conjecture (or the conjecture about infinitely many primes of the form ")#mi("n^2+1")#text(") still out of reach. The reason for this – the ")#emph[#text("parity problem")]#text(" – was first clarified by Selberg. Roughly speaking, it asserts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Parity problem")]#text(". If A is a set whose elements are all products of an odd number of primes (or are all products of an even number of primes), then (without injecting additional ingredients), sieve theory is unable to provide non-trivial lower bounds on the size of A. Also, any upper bounds must be off from the truth by a factor of 2 or more.")
]

#text("Thus we can hope to count ")#mi("P_2")#text(" almost primes (because they can have either an odd or an even number of factors), or to count numbers which are the product of 6 or 7 primes (which can for instance be done by a sieve of Bombieri), but we cannot hope to use plain sieve theory to just count primes, or just count semiprimes (the product of exactly two primes).")

#text("To explain this problem, we introduce the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("\\lambda(n)")#text(" (a close relative of the Möbius function), which is equal to +1 when n is the product of an even number of primes and -1 otherwise. Thus the parity problem applies whenever ")#mi("\\lambda")#text(" is identically +1 or identically -1 on the set A of interest.")

#text("The Liouville function oscillates quite randomly between +1 and -1. Indeed, the prime number theorem turns out to be equivalent to the assertion that ")#mi("\\lambda")#text(" is asymptotically of mean zero,")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq N} \\lambda(n) = o(N)")]]

#text("(a fact first observed by Landau), and if the Riemann hypothesis is true then we have a much better estimate")

#align(center)[#mi("\\sum_{n \\leq N} \\lambda(n) = O_\\epsilon(N^{1/2+\\epsilon})")#text(" for all ")#mi("\\epsilon > 0")#text(".")]

#text("Assuming the generalised Riemann hypothesis, we have a similar claim for residue classes:")

#align(center)[#mi("\\sum_{n \\leq N} 1_{n = a \\mod q} \\lambda(n) = O_\\epsilon(N^{1/2+\\epsilon})")#text(" for all ")#mi("\\epsilon > 0")#text(".")]

#text("What this basically means is that the Liouville function is essentially orthogonal to all smooth sets, or all smooth functions. Since sieve theory attempts to estimate everything in terms of smooth sets and functions, it thus cannot eliminate an inherent ambiguity coming from the Liouville function. More concretely, let A be a set where ")#mi("\\lambda")#text(" is constant (e.g. ")#mi("\\lambda")#text(" is identically -1, which would be the case if A consisted of primes) and suppose we attempt to establish a lower bound for the size of a set A in, say, [N,2N] by setting up a divisor sum lower bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("1_A(n) \\geq \\sum_{d} c_d 1_{d|n}(n),")]]

#text("where the divisors d are concentrated in ")#mi("d \\leq R")#text(" for some reasonably small sieve level R. If we sum in n we obtain a lower bound of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|A\\right| \\geq \\sum_{d} c_d \\frac{N}{d} + ...", block: true)]]

#text("and we can hope that the main term ")#mi("\\sum_{d} c_d \\frac{N}{d}")#text(" will be strictly positive and the error term is of lesser order, thus giving a non-trivial lower bound on |A|. Unfortunately, if we multiply both sides of (6) by the non-negative weight ")#mi("1 + \\lambda(n)")#text(" and sum in n, we obtain")

#align(center)[#tao-fit-display[#mitex("0 \\geq \\sum_{d} c_d 1_{d|n}(n) (1 + \\lambda(n))")]]

#text("since we are assuming ")#mi("\\lambda")#text(" to equal -1 on A. If we sum this in n, and use the fact that ")#mi("\\lambda")#text(" is essentially orthogonal to divisor sums, we obtain")

#align(center)[#tao-fit-display[#mitex("0 \\geq \\sum_{d} c_d \\frac{N}{d} + ...")]]

#text("which basically means that the bound (7) cannot improve upon the trivial bound ")#tao-math("\\left|A\\right| \\geq 0", block: false)#text(". A similar argument using the weight ")#mi("1 - \\lambda(n)")#text(" also shows that any upper bound on |A| obtained via sieve theory has to essentially be at least as large as 2|A|.")

#text("Despite this parity problem, there are a few results in which sieve theory, in conjunction with other methods, can be used to count primes. The first of these is the elementary proof of the prime number theorem alluded to earlier, using the multiplicative structure of the primes inside the almost primes. This method unfortunately does not seem to generalise well; for instance, the product of twin primes is not a twin almost prime. Other examples arise if one starts counting certain special ")#emph[#text("two-parameter")]#text(" families of primes; for instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=1670065")[#text("Friedlander and Iwaniec showed")]#text(" that there are infinitely many primes of the form ")#mi("a^2 + b^4")#text(" by a lengthy argument which started with Vaughan’s identity, which is sort of like an exact sieve, but with a (non-smooth) error term which has the form of a bilinear sum, which captures correlation with the Liouville function. The main difficulty is to control this bilinear error term, which after a number of (non-trivial) arithmetic manipulations (in particular, factorising ")#mi("a^2 + b^4")#text(" over the Gaussian integers) reduces to understanding some correlations between the Möbius function and the ")#link("http://en.wikipedia.org/wiki/Jacobi_symbol")[#text("Jacobi symbol")]#text(", which is then achieved by a variety of number-theoretic tools. The method was then modified ")#link("http://www.ams.org/mathscinet-getitem?mr=1828372")[#text("by Heath-Brown")]#text(" to also show infinitely many primes of the form ")#mi("a^3 + 2b^3")#text(". Related results for other cubic forms using similar methods have since been obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=1881392")[#text("by Heath-Brown and Moroz")]#text(" and ")#link("http://www.arxiv.org/abs/math.NT/0501177")[#text("by Helfgott")]#text(" (analogous claims for quadratic forms ")#link("http://www.ams.org/mathscinet-getitem?mr=342464")[#text("date back to Iwaniec")]#text("). These methods all seem to require that the form be representable as a norm over some number field and so it does not seem as yet to yield a general procedure to resolve the parity problem.")

#text("The parity problem can also be sometimes be overcome when there is an exceptional ")#link("http://en.wikipedia.org/wiki/Siegel_zero")[#text("Siegel zero")]#text(", which basically means that there is a ")#link("http://en.wikipedia.org/wiki/Jacobi_symbol")[#text("quadratic character")]#text(" ")#mi("\\chi(n) = \\left( \\frac{n}{q} \\right)")#text(" which correlates very strongly with the primes. Morally speaking, this means that the primes can be largely recovered from the ")#mi("P_2")#text(" almost primes as being those almost primes which are quadratic non-residues modulo the conductor q of ")#mi("\\chi")#text(", and this additional information seems (in principle, at least) to overcome the parity problem obstacle (related to this is the fact that Siegel zeroes, if they exist, disprove ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("GRH")]#text(", and so the Liouville function is no longer as uniformly distributed on smooth sets as Selberg’s analysis assumed). For instance, ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("Heath-Brown showed")]#text(" that if a Siegel zero existed, then there are infinitely many prime twins. Of course, assuming GRH then there are no Siegel zeroes, in which case these results would be technically vacuous; however, they do suggest that to break the parity barrier, we may assume without loss of generality that there are no Siegel zeroes.")

#text("Another known way to partially get around the parity problem is to combine precise asymptotics on almost primes (or of weight functions concentrated near the almost primes) with a lower bound on the number of primes, and then use combinatorial tools to parlay the lower bound on primes into lower bounds on prime patterns. For instance, suppose you knew could count the set")

#align(center)[#tao-fit-display[#mitex("A := \\{ n \\in [N,2N]:  n, n+2, n+6 \\in P_2\\}")]]

#text("accurately (where ")#mi("P_2")#text(" is the set of ")#mi("P_2")#text("-almost primes), and also obtain sufficiently good lower bounds on the sets")

#tao-aligned(keep: true)[


#tao-math("A_1  & := \\{ n \\in A: n \\text{ prime} \\}", block: true)



#tao-math("A_2  & := \\{ n \\in A: n+2 \\text{ prime} \\}", block: true)



#tao-math("A_3  & := \\{ n \\in A: n+6 \\text{ prime} \\},", block: true)
]

#text("and more precisely that one obtains")

#align(center)[#tao-math("\\left|A_1\\right| + \\left|A_2\\right| + \\left|A_3\\right| > \\left|A\\right|", block: false)#text(".")]

#text("(For comparison, the parity problem predicts that one cannot hope to do any better than showing that ")#tao-math("\\left|A_1\\right|, \\left|A_2\\right|, \\left|A_3\\right| \\geq \\left|A\\right|/2", block: false)#text(", so the above inequality is not ruled out by the parity problem obstruction.)")

#text("Then, just from the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(", one deduces the existence of ")#mi("n \\in [N,2N]")#text(" such that at least two of n, n+2, n+6 are prime, thus yielding a pair of primes whose gap is at most 6. This naive approach does not quite work directly, but by carefully optimising the argument (for instance, replacing the condition ")#mi("n, n+2, n+6 \\in P_2")#text(" with something more like ")#mi("n(n+2)(n+6) \\in P_6")#text("), ")#link("http://arxiv.org/abs/math/0508185")[#text("Goldston, Yildirim, and Pintz")]#text(" were able to show unconditionally that prime gaps in ")#mi("{}[N, 2N]")#text(" could be as small as ")#mi("o(\\log N)")#text(", and could in fact be as small as 16 infinitely often if one assumes the ")#link("http://en.wikipedia.org/wiki/Elliott-Halberstam_conjecture")[#text("Elliot-Halberstam conjecture")]#text(".")

#text("In a somewhat similar spirit, ")#link("http://arxiv.org/abs/math/0404188")[#text("my result with Ben Green")]#text(" establishing that the primes contain arbitrarily long progressions proceeds by first using sieve theory methods to show that the almost primes (or more precisely, a suitable weight function ")#mi("\\nu")#text(" concentrated near the almost primes) are very pseudorandomly distributed, in the sense that several self-correlations of ")#mi("\\nu")#text(" can be computed and agree closely with what one would have predicted if the almost primes were distributed randomly (after accounting for some irregularities caused by small moduli). Because of the parity problem, the primes themselves are not known to be as pseudorandomly distributed as the almost primes; however, the prime number theorem does at least tell us that the primes have a positive relative density in the almost primes. The main task is then to show that any set of positive relative density in a sufficiently pseudorandom set contains arithmetic progressions of any specified length; this combinatorial result (a “relative ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi theorem")]#text("“) plays roughly the same role that the pigeonhole principle did in the work of Goldston-Yildirim-Pintz. (On the other hand, the relative Szemerédi theorem works even for arbitrarily low density, whereas the pigeonhole principle does not; because of this, our sieve theory analysis is far less delicate than that in Goldston-Yildirim-Pintz.)")

#text("It is probably premature, with our current understanding, to try to find a systematic way to get around the parity problem in general, but it seems likely that we will be able to find some further ways to get around the parity problem in special cases, and perhaps once we have assembled enough of these special cases, it will become clearer what to do in general.")

#text("[")#emph[#text("Update")]#text(", June 6: definition of almost prime modified, to specify that all prime factors are large. Reference to profinite integers deleted due to conflict with established notation.]")

#heading(level: 1)[#text("Comments (87)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-459426")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] such as (2) or (3) are known to be subject to the “parity problem” (discussed numerous times previously on this blog), which roughly speaking means that they cannot be proven solely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-469818")[#strong[#text("Primos gemelos: Un vistazo a algunos resultados. – Lo fascinante de la teoría de números")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2016")]

#text("[…] otra conjetura acerca de teoría de números bastante tratada. En palabras de Terence Tao, “Una especie de Hipotesis de Riemann super generalizada para […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-469849")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2016")])]

#text("What is the best upper estimate for the number ")#mi("\\{0<n<x | \\Omega{(F(n)}1")#text("? In the book Halberstam, Richert “Sieve_methods” only lower bounds. Could You recommend literature about upper bounds? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-469850")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2016")])]

#text("Sorry, ")#mi("\\{0<n<x | \\Omega{F(n)}k")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Bombieri asymptotic sieve | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-470702")[#strong[#text("Notes on the Bombieri asymptotic sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("[…] scalar thus embodies the “parity problem” for the twin prime conjecture (discussed in these previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-471660")[#strong[#text("Notes on the Bombieri asymptotic sieve - TAREA LISTA")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2016")]

#text("[…] scalar thus embodies the “parity problem” for the twin prime conjecture (discussed in these previous blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-477790")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2017")])]

#text("Are there any known sieves of Twin Pairs that do not break down with an either/or at one of the numbers? — And if not, my main question is, Of all known sieves:")

#text(">> What is the farthest a sieve has gone when producing twin pairs before it breaks? <<")

#text("Lastly, if a sieve was found that never broke down, how could it be used to give a proof for the infinitude of twin pairs? ( I am lead to believe that even a perfect sieve is not a proof. Am I wrong?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/065138e1b1902805d7f744a8b774918e0ccbb72d8c610f9cb5f0d04cde9795e3-c304526fcf69ae299ab157ae31b1f0cc68fc0ab5c24aaa809399deb8b52fce69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mats Granvik")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-484388")[#strong[#text("Mats Granvik")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2017")])]

#text("Is the use of eigenvalues allowed in approaching the parity problem?")#linebreak()#text(" ")#link("https://oeis.org/A275345")[#text("https://oeis.org/A275345")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aa0641521193f11161b198d40760c04ba59ee55bf02f681f0b1249e95464cc87-dd8e9bcc88e1cc7b188f6c68e212e3682e1415e4f678eebbdc566ef269d4af38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Pratt")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-486436")[#strong[#text("Kyle Pratt")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2017")])]

#text("I apologize for posting a comment on an old post.")

#text("In your discussion of Selberg’s elementary proof of the PNT you mention that ")#mi("\\sum_{n \\leq N} \\mu(n)(\\log(n))^2/n")#text(" grows like ")#mi("\\log N")#text(". However, for every ")#mi("k \\geq 1")#text(" we have ")#mi("\\sum_{n \\leq N} \\mu(n) (\\log n)^k/n \\sim c_k")#text(" for some constant ")#mi("c_k")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-491655")[#strong[#text("Hammer and Nails | Radimentary")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2018")]

#text("[…] Usually even the failure of certain techniques sheds light on shape of the difficulty. One classic example of an enlightening failure is the consistent overcounting (by exactly a factor of two!) of primes by sieve methods. This failure is so serious and unfixable that it has its own name: the Parity Problem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DZ")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-493112")[#strong[#text("DZ")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("The line “For comparison, the parity problem predicts that one cannot hope to do any better than showing that $|A_1|, |A_2|, |A_3| \\geq |A|/2$ …” probably should be read $|A_1| + |A_2| +|A_3| \\geq |A|/2$ ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-493113")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2018")])]

#text("Actually the statement is as I intended: it is possible to obtain a lower bound of the form ")#tao-math("\\left|A_1\\right|+\\left|A_2\\right|+\\left|A_3\\right| > \\left|A\\right|", block: false)#text(" through lower bounds on ")#tao-math("\\left|A_1\\right|, \\left|A_2\\right|, \\left|A_3\\right|", block: false)#text(" that are no stronger than ")#tao-math("\\left|A_1\\right| \\geq \\left|A\\right|/2", block: false)#text(", ")#tao-math("\\left|A_2\\right| \\geq \\left|A\\right|/2", block: false)#text(", ")#tao-math("\\left|A_3\\right| \\geq \\left|A\\right|/2", block: false)#text(". In contrast, one cannot prove a lower bound of the form ")#tao-math("\\left|A_1\\right|+\\left|A_2\\right| > \\left|A\\right|", block: false)#text(" in this fashion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-497505")[#strong[#text("Finding Coprime Pairs | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")]

#text("[…] comment by Ben Green neatly expresses the analytical motivation, as does section 4 of this paper. The […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b8b61b8486fb9fceafb89ab1903d4e5693d7501eb21e3872899e1613cb1be0c-fed003baf1744860d7f6a9b6f522a02dc6cbc656761071ef66e73ac3cc31632a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Daniel Kline")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-534213")[#strong[#text("Fred Daniel Kline")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2019")])]

#text("I’m an amateur and in my attempts to find symmetry in Binary Goldbach, I had to make my odd number function use positive indexes. This eliminated a one-off issue for me. I don’t know how this would affect the Twin Prime parity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95703cb64738bf251f2138af0140e5c1a76ffe994b4771c93e89e05d290a9ef0-9b50b3852f96816721fe32bbc75b1dbc46ba8ad8d4a9f99141405a88bd6bf885.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Di Savino")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-632283")[#strong[#text("Giovanni Di Savino")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2021")])]

#text("The only way to be sure of being able to find all the prime numbers is not, as mentioned in another post, to calculate but to understand the logic of the generation of prime numbers ")#link("https://www.quora.com/How-come-la-distanza-tra-numeri-primi-soddisfa-la-versione-forte-della-congettura-di-Goldbach-Che-da-soluzione-alla-congettura-dei-gemelli/answer/Giovanni-163-1")[#text("https://www.quora.com/How-come-la-distanza-tra-numeri-primi-soddisfa-la-versione-forte-della-congettura-di-Goldbach-Che-da-soluzione-alla-congettura-dei-gemelli/answer/Giovanni-163-1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/207a49e8cb97452c9302feb2000eb4190e45d0827e5359a4d22c684d95b7819f-e9ea6e64d641cf35bf4b469e92e0dbfb76db00841b5df45e42190b3dc153abd7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of james")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-642943")[#strong[#text("james")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2022")])]

#text("Is there a way to make the second display after (7) a bit more quantitively precise? For example if we sum the first display after (7) over ")#mi("n")#text(" as you suggested then we obtain ")#mi("0\\geq \\sum_d c_d\\frac{N}{d} + \\sum_d c_d \\sum_n 1_{d|n}\\lambda(n)")#text(". GRH then lets us conclude that ")#tao-math("\\sum_d c_d\\frac{N}{d} \\leq O\\left(N^{0.51}\\sum_d \\left|c_d\\right|\\right)", block: false)#text(". I agree this probably implies ")#mi("\\sum_d c_d\\frac{N}{d}")#text(" would not be of the correct order of magnitude (e.g. ")#mi("N/\\log n")#text(" if we are counting primes) unless ")#mi("c_d")#text("s are all very large and of the same sign or something. However, I don’t see how this rules out the possibility that e.g. ")#mi("\\sum_d c_d\\frac{N}{d} \\gg N^{0.01}")#text(" which, although weak, would imply that there are infinitely many primes (or infinitely many twin primes in another setting). So to rephrase my question, is it possible to use you sketch argument to show that one shouldn’t expect even a very weak ")#mi("w(1)")#text(" lower bound, i.e. I am not quite convinced by your conclusion that one shouldn’t expect to improve the trivial ")#tao-math("\\left|A\\right|\\geq 0", block: false)#text(" bound?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-643031")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2022")])]

#text("Let’s adopt the (somewhat non-rigorous) Liouville pseudorandomness hypothesis for sake of discussion, so that ")#mi("\\lambda(n)")#text(" behaves like a random sequence of +-1s. Then the sum ")#mi("\\sum_d c_d \\sum_n 1_{d|n} \\lambda(n)")#text(" is not only expected to be small in magnitude, but also to fluctuate in sign, and in particular be positive about 50% of the time, and so this wouuld force ")#mi("\\sum_d c_d \\frac{N}{d}")#text(" to be negative half the time, thus ruling out a uniform lower bound such as ")#mi("\\sum_d c_d \\frac{N}{d} \\gg N^{0.01}")#text(". Now it is true that this obstruction still does not rule out the possibility that one could maybe introduce a sieve that has a non-trivial, non-uniform bound that holds for infinitely many ")#mi("N")#text(" but not all ")#mi("N")#text(", but this would be a very unusual species of sieve that does not resemble any existing sieve (which, if it works at all, would work for all sufficiently large ")#mi("N")#text(", rather than for just a subset of ")#mi("N")#text("). Furthermore, such a sieve by its nature would have to be sensitive to the fluctuations of the Liouville function and so controlling such a sieve seems to be of comparable difficulty to the type of problem one is trying to attack in the first place.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-685596")[#strong[#text("Erdos problem #385, the parity problem, and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2024")])]

#text("[…] out that this problem is closely related to the parity barrier in sieve theory (as discussed in this previous post), with the possibility of Siegel zeroes presenting a particular obstruction. I suspect that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88ef6ab90ab98c8e2ec278d976ee6be9fd9dc7d64744bc51ae7f4582df02239f-4f065853317853faa6f6f8682a0df2c8bcb6bb754328a97b29fe0f2237e7ca2d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathematicalsilence")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-2/#comment-685945")[#strong[#text("mathematicalsilence")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2024")])]

#text("Professor Tao … above(on 22/4/22) you discuss hypothetical behaviour of the Liouville function “like a random sequence of +-1s” … you go on to speculate on the desirable existence of some- “very unusual sieve that does not resemble any existing sieve” … furthermore, you go on to suggest that such a sieve would have to be- “sensitive to the fluctuations of the Liouville function”")

#text("Professor … I have such a sieve … THE sieve … THE one and only one that will ever be available to mankind and mathematics … besides being sensitive to the prime numbers and Mobius function the algorithm prints out the sequence of +-1s, known as the Liouville function, without missing a beat … and it starts from scratch … only information input is the first prime, the number 2, and the multiplicative property defining the primes and it sails away computing the utterly and totally non-random Liouville sequence from 2 … up to … N … all in approx time complexity O(N^(7/10)) … no such thing as a “parity problem” exists with this sieve.")

#text("Fundamentally it is Eratothsenes sieve, therefore foolproof, but one has to cross out numbers ahead only ONCE, unlike the two thousand year old method with its overwhelming double ups and triple ups…etc which you have noted in public lectures renders the ancient Greek’s venerable work as computationally “useless” for modern mathematicians … bit hasty maybe… furthermore, instead of crosses, one labels +1 or -1 according to the parity of the exponents on the primes … Liouville…Mobius u name it … prints em out!(by constructing ALL numbers in order… but that is not necessarily in ‘consecutive’ order) … That is the secret to understanding multiplicatively defined sequences of which primes are the primary example.")

#text("Professor Tao I would very much like to discuss this mathematics with you and I enclose my Email as a contact should you be interested- ")#link("mailto:jendavondra@icloud.com")[#text("jendavondra@icloud.com")]

#text("Many thanks and cheers from Australia")

#text("google Jenda Vondra Wolfram Demonstrations Project if u wish for some of my mathematical publications")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1735")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2007")])]

#text("This blog is the best I’ve seen on the internet for mathematical exposition. Second only to the arxiv as a source of wisdom.")#linebreak()#text(" Kudos to the author; I hope he will continue to find time to write these long postings.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1769")[#strong[#text("Rob")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("How could one go about obtaining a copy of the unpublished lecture notes of Iwaniec referred to above?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1785")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("This is indeed a wonderful post!")

#text("Here is a remark which may also be useful to understand some issues with sieve.")

#text("In the “almost prime” setting, there is often a distinction between integers having few prime factors (with multiplicity) and integers having no small prime factors. Most sieves typically produce the second type of integers, more precisely integers ")#mi("n\\leq X")#text(" such that all primes ")#mi("p")#text(" dividing ")#mi("n")#text(" are larger than ")#mi("X^{c}")#text(" for some (fixed) positive constant ")#mi("c")#text(" (often small). So those ")#mi("n")#text(" have at most ")#mi("1/c")#text(" prime factors.")

#text("The reason the distinction is sometimes important lies in the density of the two sets: for instance, there are about ")#mi("X(\\log\\log X)/\\log X")#text(" integers ")#mi("\\leq X")#text(" divisible by at most two primes, but only a constant (depending on ")#mi("c")#text(") times ")#mi("X/\\log X")#text(" integers with no prime factor ")#mi("\\leq X^c")#text(" . In other words, the density of the second type of “almost primes” is comparable to that of the primes themselves, whereas there are rather more of the first type.")

#text("This might explain for instance (where the parity problem might suggest a serious difficulty) why Goldston, Graham, Pintz and Yildirim were able to prove that there are infinitely many integers which are products of two primes exactly and at some bounded distance (i.e., what looks like the analogue of bounded distances between primes; but among a set where the mean spacing is not ")#mi("\\log N")#text(" but somewhat smaller).")

#text("To reply (partly) to the last comment: Iwaniec and Friedlander are currently finishing")#linebreak()#text(" a book on sieve based in large part on those unpublished notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336811934d3cb006d79e622f6fe2c4978a4ad2da9a392b367a5a67a80c9f364c-07098da6288ae6af78297972d09ae037aab4ccd2220b9d137166d74d913a1a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-463801")[#strong[#text("Justin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("I am very interested in the distribution of integers that are the product of at most two primes. You mention that there are asymptotically ")#mi("k_c X/\\log X")#text(" integers with no prime factor ")#mi("\\leq X^c")#text(", where ")#mi("k_c")#text(" is a constant depending on $c$. Does this directly appear in the literature somewhere? Or is it derived from a more general result? I have been searching high and low for it, but to no avail.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-463802")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("See ")#link("https://en.wikipedia.org/wiki/Buchstab_function")[#text("https://en.wikipedia.org/wiki/Buchstab_function")]#text(" . Tenenbaum’s text “Introduction to analytic and probabilistic number theory” should have a thorough treatment of this (probably Montgomery-Vaughan’s “Multiplicative Number Theory” also).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/336811934d3cb006d79e622f6fe2c4978a4ad2da9a392b367a5a67a80c9f364c-07098da6288ae6af78297972d09ae037aab4ccd2220b9d137166d74d913a1a43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Justin")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-463826")[#strong[#text("Justin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2015")])]

#text("This is really helpful; thanks for the quick reply!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1792")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")]

#text("[…] Open question: The parity problem in sieve theory The parity problem is a notorious problem in sieve theory: this theory was invented in order to count prime patterns of […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e3ea0e461d1d736c668411472d5f628588e8adf015c16fbbe10de0d15fd1eca-70ff2301f8f81ca485a632489f67c0312ea697218a8a0e60e2a3013f321cf13e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Voloch")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1797")[#strong[#text("Felipe Voloch")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("Sometimes one can get lower bounds out of upper bounds in prime number estimates using some Galois theory. Two examples of this (actually closely related) occur in Bombieri’s version of Stepanov’s proof of the Riemann hypothesis for function fields and in Chebotarev’s proof of his density theorem. I’ve never seen these arguments in the context of sieve theory, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1808")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2007")])]

#text("In sieve, getting lower bounds from upper bounds is usually done with the Buchstab identity, which is again a form of inclusion exclusion and states that")

#mi("S(z)=S(y)-\\sum_{y\\leq p < z}{S(p)}")

#text("where ")#mi("S(x)")#text(" is the sum of some sequence ")#mi("a_n")#text(" over integers with no prime factor less than ")#mi("x")#text(", and ")#mi("y")#text(" is chosen arbitrarily less than ")#mi("z")#text(", i.e, integers with no prime factor less than ")#mi("z")#text(" are those with no prime factors less than ")#mi("y")#text(" (there are more of them), minus those with smallest prime divisor ")#mi("p")#text(" between ")#mi("y")#text(" and ")#mi("z")#text(", and no prime factor smaller than this ")#mi("p")#text(".")

#text("Somewhat related is the nice trick of “switching sieve”, found first (I think) in the paper of Iwaniec on primes represented by quadratic forms, and spectacularly used by Chen in his result on ")#mi("p+2=P_2")#text(": in this second case, roughly, Chen showed first that some weighted counting of primes ")#mi("p")#text(" with ")#mi("p+2=P_3")#text(" is “large”; then he showed that the number of primes ")#mi("p")#text(" where ")#mi("p+2=p_1p_2p_3")#text(" is smaller than this lower bound, so most of the first lower bound had to come from ")#mi("p")#text(" where ")#mi("p+2=P_2")#text("… The second step is done by sieving the sequence ")#mi("(p_1p_2p_3-2)")#text(" to count how many primes it may represent (there one needs only an upper bound!). It is not obvious a priori that this will work; in Chen’s first version, it depends on getting some numerical inequality right (and this depends of course on the careful choice of weight in the first lower bound).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9d00e86ca8cffb6563fa6d82adfdceb9240d70813780bf0099170bd53cbe49f-d1146be2136fe601e3437e4ef8dc7a871b4c56e029cfda7fd997b69781efe2ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan Ellenberg")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1826")[#strong[#text("Jordan Ellenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2007")])]

#text("You ask why the adelic formulation is rarely used in sieve theory; I think it’s probably just because when you work over Z you")#linebreak()#text(" can get away with _not_ using it. It’s when you want to prove things")#linebreak()#text(" over arbitrary number fields (or for that matter function fields)")#linebreak()#text(" that the adelic point of view becomes really indispensible — so I")#linebreak()#text(" think one good outcome of using the adeles systematically is that it")#linebreak()#text(" will be clear (if you care) which of these theorems in sieve theory")#linebreak()#text(" truly have to do with Z and which are theorems about integers in")#linebreak()#text(" general number fields. Of course it is not quite obvious even what the correct questions are over more general fields! (And perhaps here, too, the adelic formulation would be of use.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1828")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2007")])]

#text("With respect to adèles, I think even when it would be a good conceptual tool, it is not necessarily a good fit for the foundational part of sieve methods (before applications), which tends to be very “finitistic” (although O() symbols are sometimes used, they can pretty much be replaced by completely explicit bounds if one is careful enough — Iwaniec did this very successfully for the so-called beta-sieve). So adèles could be also be replaced with finite products of completions, and then dissolved in finite quotients…")

#text("Recently I’ve been playing with quite general sieve settings, where the integers are replaced with potentially much more complicated-looking things (e.g., discrete groups, algebraic fundamental groups, probability spaces with random walks,…) without seeing infinitary objects like the adèles being obviously necessary (though they can be used to phrase things in a clean way).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2007")])]

#text("Dear Emmanuel and Jordan,")

#text("Thanks very much for your comments! I can see that adeles are perhaps not the right tool for really getting into the quantitative and finitary details of error estimates, etc., but they should at least provide a nice way to compute the “main term” that comes out of sieve theory (such as the expressions ")#mi("\\sum_d \\frac{c_d}{d}")#text(" mentioned in my post). For instance, I have felt that all the standard conjectures (Hardy-Littlewood prime tuples conjecture, Bateman-Horn conjecture, etc.) about the distribution of prime patterns would be very cleanly stated in an adelic setting.")

#text("Regarding other number fields, I ")#link("http://front.math.ucdavis.edu/math.CO/0501314")[#text("have a paper")]#text(" establishing infinitely many constellations amongst the Gaussian integer primes (or any dense subset thereof), by modifying the methods of my paper with Ben. For this, I of course had to do some sieving in the Gaussian integers, but this was fairly straightforward to do by hand. I don’t know how to do the same thing for more general integral rings, e.g. ")#mi("{\\Bbb Z}(\\sqrt{-d})")#text(", mainly because I am using a rather “low-tech” approach to sieving that relies in particular on unique factorisation (the fundamental theorem of arithmetic). (There are also some mild problems with units, but as long as there are only finitely many of these, this does not seem to be dangerous.) A model problem would be to figure out how to use sieve theory to count constellations of “almost primes” or “almost irreducibles” in such integral rings, though I am not entirely sure exactly what those concepts even mean once one loses unique factorisation. There is also the question of exactly what type of “boxes” one should count the patterns in, though presumably the Archimedean valuations should tell you what to do there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1831")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2007")])]

#text("Certainly, as far as the main term is concerned, or for any Euler product more generally, (involving in addition an archimedean term), seeing things adelically is the right thing to do as soon as some generality is desired.")

#text("For problems in rings of integers in number fields with no unique factorization, one might look naively for problems involving “irreducibles”, i.e., elements of the ring which generate a prime ideal. Algebraic/analytic number theory proves that there are many of those (a proportion $1/h$ of prime ideals are principal, where $h$ is the class number). If there are infinitely many units, more needs to be done to get nice finite sets in which to sieve, but for imaginary quadratic fields, this makes it possible to write down some nice twin-prime like problems in general.")

#text("There might well be more interesting problems remaining to be discovered, on the other hand…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d51b223e38cdf785607711f616db09a6ed2aafb07ed6854161533b46fa9ecdf3-d3291f2eeb879bfff80e455be66b2ca7d9bfd4bb90e05def04df35322f689230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keith Conrad")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1914")[#strong[#text("Keith Conrad")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2007")])]

#text("This post is about Terry’s remark on what type of “boxes” one should count in.")

#text("There certainly is no canonical choice unless the number field has a unique archimedean place (thus limiting you to Q and imagiary quadratics). In other cases, you could pick some region in the product of archimedean completions of the number field — so in R x R if you had in mind Q(sqrt(2)), say, and take uniformly expanded versions of that as some appropriate scaling parameter grows. (If you aren’t careful then you can pick regions that are too thin in some direction.) Even if there’s nothing canonical about such a choice of boxes in which you tabulate statistics on prime values of some expression across the region, numerics shows that the number of prime values you find in the box (if you’re looking at values of a polynomial f(x), generating a principal prime ideal in case h > 1) grows with the scaling parameter in the same asymptotic way as the classical Hardy–Littlewood constant you would attach to the polynomial times the sum of 1/log|N(f(x))| where N is the norm down to Z from your ring of integers and x runs over integers in the box. I am not saying there is any hope of a proof in such generality, but the numerics look okay. (This is just an extrapolation of the usual heuristic probability of f(n) being prime as C_f/log|f(n)| where f is in Z[X] and C_f is a Hardy–Littlewood constant which measures how often f’s values on Z are not divisible by the primes.)")

#text("One way to get around the choice of ad hox “boxes” is to forget about any kind of “(un)natural density” for prime values and use the Zariski topology instead. This is done in recent work of Sarnak, Bourgain, Gamburd.")

#text("In a somewhat different direction, ordinarily it is said that looking at prime pairs n and n + 1 is silly: one of n and n + 1 is even. But if you work not in Z but in Z[1/2] then the idea makes sense since the problem at 2 goes away. Just as Z is discrete and co-compact in R, Z[1/2] is discrete and co-compact in R x Q_2. If you draw a large region in R x Q_2 which is not thin in some direction then the number of n in the region from Z[1/2] (not just Z) for which n and n+1 are both prime (in Z[1/2], of course) agrees with the sum of 1/log N_2(n(n+1)) over the region times the corresponding Hardy–Littlewood constant with the local factor at 2 dropped out. By N_2(m) for m in Z[1/2] I mean the size of Z[1/2]/(m), just as one measures (nonzero) integers k by |k| = #(Z/k). Here I am not claiming one can actually prove something new, but the numerics look okay. Similarly, for the “triple primes” of the form n, n+2, n+4, which is nonsense in Z because one of the terms is always a multiple of 3, there is meaning to this idea in Z[1/3] and counting triple primes n, n+2, n+4 from Z[1/3] within regions of R x Q_3 returns numerics consistent with analogues of the usual prime-counting heuristics for polynomial values over Z, but here the Hardy–Littlewood constant has no local factor at 3.")

#text("Oh, when I say the Hardy–Littlewood constant has its local factor at 2 or 3 taken out depending on n and n + 1 or n, n+2, and n+4 being considered, the effect of 2 and 3 reappears elsewhere: you need to include in the heuristic prime-counting estimate a reciprocal of the residue of a zeta-function at s = 1 with the local Euler factor at 2 or 3 removed, which actually makes something show up from 2 or 3 in the residue itself. (Since")#linebreak()#text(" Res_{s=1} zeta(s) = 1, one doesn’t notice zeta-residues in the classical setting over Z.)")

#text("Ack, I’ve probably written too much. Good night.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1918")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("This reminds me a little bit of a trick Terry and I use in our work on linear equations in primes which we call the “W-trick”. Suppose you want to find long arithmetic progressions in the odd primes")

#text("3,5,7,11,13,17,19….")

#text("Then you may as well look for progressions in the sequence")

#text("1,2,3,5,6,8,9….")

#text("which I got from the previous one by subtracting one from each term and dividing by two. The new sequence doesn’t suffer from the same dislike of the even numbers that the primes do – in fact since asymptotically 50 percent of the primes are 1 mod 4, about half of the elements of this sequence are even and half odd.")

#text("Now I’ll just look at the elements of the new sequence which are divisible by 3, and I’ll divide each of them by 3 to get a new sequence")

#text("1,2,3,5,6,7,9…..")

#text("This sequence is now nicely distributed mod 2 and mod 3 (that is, mod 6). To see why, let’s ask when 6n + r lies in the sequence. This is the case if and only if 6(6n + r) + 1 is prime, that is to say iff 36n + a is prime where a = 6r + 1. But there are, asymptotically, equal numbers of primes in each residue class a mod 36 for which a is coprime to 36.")

#text("One can continue in this way mod 5, 7 and so on up to w, obtaining a sequence which is a rescaled version of the primes congruent to 1 mod W, where W = 2 x 3 x 5 x 7… x w (this is why we call it the W-trick).")#linebreak()#text(" You can actually play the same game for the primes congruent to a mod W, for any a.")

#text("These rescaled primes will have negligible bias mod every prime less than or equal to w. This makes computing the Hardy-Littlewood constant a rather trivial matter – if w is large then it tends to be very close to 1 (actually there are some slight issues with this – the Hardy-Littlewood constant appearing in the Goldbach conjecture can be dominated by the contribution from large primes, say if you’re counting the number of ways to represent N = p + q where N has many large prime factors).")

#text("If one can prove that all these Hardy-Littlewood constants are about 1 then one can piece together the information over all progressions a (mod W), for different a, to recover the Hardy-Littlewood constant for the original problem. For example one can use this technique to make the classical prediction of the number of twin primes less than N.")

#text("The point about these rescaled primes is that (unlike the primes themselves) they look sort of random. Thus in making predictions about them one can look at what is true for a random set of similar size and just guess that the same ought to be true for the primes.")

#text("There is another heuristic which is more accurate than the above, which is the so-called Mobius Randomness Principle. This asserts that the Mobius function is highly orthogonal to everything unless there is some obvious reason why it shouldn’t be (for example, it is not orthogonal to itself or to the von Mangoldt function). This principle can also be used to guess these Hardy-Littlewood constants, and much more – for example the Riemann hypothesis is equivalent to the statement that Mobius is highly orthogonal (with square-root cancellation) to the constant function 1.")

#text("Proving even a weak instance of the Mobius randomness principle involves overcoming the parity problem, as Terry explained above. There’s more on all this in Terry’s earlier post (Simons Lecture I) and in some of the comments that follow it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1943")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("Very fine thread! I understood it better, having seen ben Green’s recent lectures to the Caltech Math department.")

#text("The same methods seem to work for quasi-Eratosthenesian sieves, such as for Ulam’s “lucky numbers.”")

#link("http://www.research.att.com/~njas/sequences/A000959")[#text("http://www.research.att.com/~njas/sequences/A000959")]

#text("Note the comment at that OEIS link:")#linebreak()#text(" COMMENT")#linebreak()#text(" An interesting general discussion of the phenomenon of ‘random primes’ (generalizing the lucky numbers) occurs in Hawkins (1958). Heyde (1978) proves that Hawkins’ random primes do not only almost always satisfy the PNT but also the Riemann Hypothesis. – Alf van der Poorten, Jun 27 2002")

#text("REFERENCES")

#text("M. Gardner, Lucky numbers and 2187, Math. Intellig., 19 (No. 2, 1997), 26-29.")

#text("M. Gardner, Gardner’s Workout, Chapter 21 “Lucky Numbers and 2187” pp 149-156 A.K.Peters MA 2002.")

#text("V. Gardiner, R. Lazarus, N. Metropolis and S. Ulam, On certain sequences of integers defined by sieves, Math. Mag., 29 (1955), 117-119.")

#text("R. K. Guy, Unsolved Problems in Number Theory, C3.")

#text("D. Hawkins, The random sieve, Math. Mag. 31 (1958), 1-3.")

#text("C. C. Heyde, Ann. Probability, 6 (1978), 850-875.")

#text("C. S. Ogilvy, Tomorrow’s Math. 2nd ed., Oxford Univ. Press, 1972, p. 99.")

#text("D. Wells, The Penguin Dictionary of Curious and Interesting Numbers. Penguin Books, NY, 1986, 114.")

#text("One can examine intersections such as:")

#text("A031157 Numbers that are both lucky and prime.")#linebreak()#text(" 3, 7, 13, 31, 37, 43, 67, 73, 79, 127, 151, 163, 193, 211, 223, 241, 283, 307, 331, 349, 367, 409, 421, 433, 463, 487, 541, 577, 601, 613, 619, 631, 643, 673, 727, 739, 769, 787, 823, 883, 937, 991, 997, 1009, 1021, 1039, 1087, 1093, 1117, 1123, …")

#text("Looking mod 10 can be confusing to me, as in:")

#link("http://www.research.att.com/~njas/sequences/A129864")[#text("http://www.research.att.com/~njas/sequences/A129864")]#linebreak()#text(" A129864 Numbers that are both lucky and emirp.")

#text("13, 31, 37, 73, 79, 739, 769, 991, 1009, 1021, …")

#text("FORMULA")#linebreak()#text(" A000959 INTERSECTION A006567. a(n) is n element of A000959 AND a(n) is an element of A000040 AND R(a(n)) = A004086(a(n)) is an element of A000040.")

#text("EXAMPLE")#linebreak()#text(" a(9) = 1009 because 1009 is a lucky number A000959(154) and 1009 is an emirp because 1009 is prime and R(1009) = 9001 is prime (but is not lucky).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of physics_grad_student")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1948")[#strong[#text("physics_grad_student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("Hi Terry,")

#text("I was wondering if the techniques you mentioned can be used to solve a problem I’m dealing with but I can’t seem to get it to work after trying for a few days. I would like to prove the following (BTW I’m not a math major)")

#text("Suppose we are interested in modular arithmetic mod d. d>1")

#text("Let S be the set of numbers coprime to d excluding zero. Let a and b be elements of set S.")

#text("Then what is the range of the function x = a+b mod d?")

#text("Numerically, for all d less than 2000, the answer is")#linebreak()#text(" 1) If d is even, x = {0,2,4. . . d-2} (all even numbers less than d)")#linebreak()#text(" 2) If d is odd, x= {0,1,2,. . .d-1} (all numbers less than d)")

#text("I would like to prove that the above result holds for all values of d.")

#text("I can prove this for d=odd prime, which can be extended to odd prime powers, which can then be extended to d=product of at most 4 odd prime powers. Any help is greatly appreciated.")

#text("BTW is there any connection between this problem and the Goldbach Conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c58d20ac76d30688691ba02cd1ba2090efa08a031aa044e1c84aebfd3e7a2b2-c6238ca5fb438c878029dd135258924aab53e9fd3b29079ad77063ed9f9048bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noah Snyder")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1971")[#strong[#text("Noah Snyder")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2007")])]

#text("physics_grad_student:")

#text("Your conjecture is true, and although it is totally unrelated to the Goldbach Conjecture it is still a cute little excercise in elementary number theory. I’ll just do the d is odd case, though the d is even case is basically identical with a small twist.")

#text("By the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text(" it is enough to do the case where d is a power of a prime, say d=p^n. Now, modulo p^n it is easy to compute what fraction of the numbers are relatively prime to p^n, namely (p-1)/p. In particular, if p is odd then more than half of the numbers modulo p^n are relatively prime to p^n.")

#text("Now, let’s rephrase the problem slightly. Let U be the set of numbers relatively prime to d=p^n. For some number x, let x-U be the set of elements of the form x-u for u in U. Saying that x is of the form a+b as above is equivalent to saying that U and x-U have a nontrivial intersection. (If y is in U and in x-U then x = y + (x-y) exhibits x as a sum of two elements of U.) If p is odd, since more than half of the numbers are in U and more than half of the numbers are in x-U they must overlap!")

#text("The interesting thing about this argument is that it only works if you tackle it one prime at a time. In particular, in Z/105 fewer than half of the integers less than 105 are relatively prime to 105. So a direct pidgeon hole argument won’t work, you need the Chinese remainder theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2007")])]

#text("Actually, there is some connection to the Goldbach conjecture; physics_grad_student’s conjecture is the “local” version. If there was a residue class mod n which was not expressible as a sum of two classes coprime to n, but was expressible as an even number, then Goldbach’s conjecture would easily be seen to be false. In the language of my Simons I lecture, the fact that the above conjecture is true means that there are no local obstructions to solvability of the Goldbach problem. Unfortunately, we don’t currently have a “local to global” principle for this type of problem to then finish the job.")

#text("The type of sieve theory that gives near misses to the Goldbach conjecture (e.g. Chen’s theorem that every large even number is the sum of a prime and a P_2) implicitly uses the fact that the above conjecture is true to ensure that the “main term” or “singular series” in the number of solutions is safely bounded away from zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-1996")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2007")])]

#text("105 doesn’t work as a side-effect of it being the smallest odd sphenic number, i.e. product of 3 distinct odd primes. The next odd sphenic number is 165. Why does the argument break down at these? If we patch the argument, wheat then onstructs that approach to proof?")

#link("http://www.research.att.com/~njas/sequences/A007304")[#text("http://www.research.att.com/~njas/sequences/A007304")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-2015")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2007")])]

#text("I think these exceptions come from Sylow’s theorems.")

#text("A homework problem of Brian Harbourne, U. Nebraska at Lincoln, gives most of the reason.")

#link("http://www.math.unl.edu/~bharbourne1/M417Spr03/M417Hmwk9Sols.html")[#text("http://www.math.unl.edu/~bharbourne1/M417Spr03/M417Hmwk9Sols.html")]

#text("Problem: Let H and K be subgroups of a group G of order pqr, where p, q and r are distinct primes. If |H| = pq and |K| = qr, prove that the intersection (call it I) of H and K has order q.")

#text("Proof: Since |I| divides both |H| and |K|, we see that |I divides both qr and qp. But the only common factors of qr and qp are 1 and q.")#linebreak()#text(" So suppose |I| = 1. Let HK denote the subset")#linebreak()#text(" {g in G : g = hk for some h in H and some k in K}. Suppose h_1 and h_2 are in H and that k_1 and k_2 are in K.")

#text("If h_1 k_1 = h_2 k_2, then (k_1 k_2)^-1 =")#linebreak()#text(" (h_1)^-1 h_2, but (k_1 k_2)^-1 is in K and")#linebreak()#text(" (h_1)^-1 h_2 is in H, so (k_1 k_2)^-1 =")#linebreak()#text(" ( h_1)^-1 h_2 is in I, and by assumption must thus be e (since we are assuming |I| = 1).")#linebreak()#text(" Thus (k_1 k_2)^-1 = e so k_1 = k_2, and likewise h_1 = h_2. Thus the map f : HxK -> HK defined by f((h, k)) = hk is injective. It is obviously surjective, so it is bijective, hence |HK| = |H||K| = (prq)^2. But HK is a subset of G, and this means |HK| = (prq)^2 is bigger than |G| = pqr, which is impossible. Thus |I| = 1 must be false, so |I| = q.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of (Emmanuel Kowalski) The large sieve inequalities « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-6121")[#strong[#text("(Emmanuel Kowalski) The large sieve inequalities « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2007")])]

#text("[…] post may be seen as complementary to the post “The parity problem in sieve theory“. In addition to a survey of another important sieve technique, it might be interesting as a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Atle Selberg « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-6530")[#strong[#text("Atle Selberg « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2007")])]

#text("[…] In working on the zeta function, Selberg developed two powerful tools which are still used routinely in analytic number theory today. The first is the method of mollifiers to smooth out the magnitude oscillations of the zeta function, leaving making the (more interesting) phase oscillation more visible. The second was the method of the Selberg sieve, which is a particularly elegant choice of sieve which allows one to count patterns in almost primes (and hence to upper bound patterns in primes) quite accurately. Variants of the Selberg sieve were a crucial ingredient in the work of Goldston-Yıldırım-Pintz on prime gaps, and the work of Ben Green and myself on arithmetic progressions in primes. (I discuss the Selberg sieve, as well as the Selberg symmetry formula below, in my post on the parity problem.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Milliman Lecture III: Sum-product estimates, expanders, and exponential sums « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-19288")[#strong[#text("Milliman Lecture III: Sum-product estimates, expanders, and exponential sums « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2007")])]

#text("[…] one has to add back in points which are divisible by multiple small factors, and so forth). See my post on sieve theory and the parity problem for further discussion. In order for sieve theory to work well, one needs to be able to accurately […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99eee887bd6264daef14a422cd2fca665c9c08aa7a39e76fec45aa92865cb88b-83998045c272b35c14d1a0dad2799941d8016626df49dbd8a6c3e88c97bbb5c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amateur")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-22781")[#strong[#text("Amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2008")])]

#text("I’m not a mathematician, so please forgive this intrusion, but I’ve been fascinated by sieve theory")#linebreak()#text(" and this seems the right place to ask about an aspect of it that I find very puzzling and would very much appreciate if someone could point out an error in my reasoning.")#linebreak()#text(" The phenomenon is already apparent in examples of counting problems given by T.Tao at the beginning of his esssay on parity problem at the top of this thread. The simplest question that exhibits the phenomenon explicitly is a variation on the second example given by T.Tao and asks: How many odd numbers are contained in a set of three cosecutive integers?")#linebreak()#text(" The problem is not with determining the answers, but with their plurality. This lack of uniqueness implies lack of functional dependence. Specifically that the cardinality of the presumed set of solutions is not a function of the cardinality of the original set to which the sieve is applied.")#linebreak()#text(" Abstractly the sieve can be viewed as an instance of the implicit function problem – actually an explicit formula for its solution, if and when applicable. It seems that in this case the underlying functional relationship neccessary for the existence of solution to the implicit function problem is not in place.")#linebreak()#text(" In the generic case of inclusion-exclusion the problem does not appear, because this procedure is applied to sets defined explicitly, or at least, as in the case of the various subsets appearing in the formula, capable of being so defined (explicitly computed), by the use of set operations (union, intersection, relative complement) as functions of the original set and relations defined on it. In this setting there is no problem in coverting the method to handle the corresponding cardinalities if those appearing in the formula can be explicitly determined.")#linebreak()#text(" Likewise in number theory, if enough information is supplied to nail the set down explicitly the problem disappears.")#linebreak()#text(" If per chance I’m right then the meaning and significance of the “error term” in at least some sieves")#linebreak()#text(" might require a re-examination.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-22963")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2008")])]

#text("Dear Amateur,")

#text("The sieve of Eratosthenes (for instance) does provide an explicit, deterministic formula for the number of primes in any given range. This formula is known as the Legendre identity, see")

#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("http://en.wikipedia.org/wiki/Legendre_sieve")]

#text("Unfortunately, the formula contains the greatest integer part function ")#mi("\\lfloor x \\rfloor")#text(", which is hard to compute with. We can express this function as a combination of the “main term” x and the “error term” ")#mi("\\{x\\}")#text(". We understand how to sum up the main term very well, but the error terms are what cause all the trouble. Heuristically, the fractional parts of all the terms which arise in the Legendre identity should be uniformly distributed between 0 and 1 – what reason would they have for doing otherwise? – but we unfortunately cannot prove this; similarly for other sieves. So there’s not much we can do with the error terms for other than treat them as being essentially arbitrary numbers between 0 and 1, which is what causes the formulae from sieve theory to become somewhat inexact. But actually, in many cases having a simple but somewhat inexact formula is more useful than an exact but overly complicated formula. For instance, to prove the twin prime conjecture, it is not necessary to count the number of twin primes exactly; having a rough lower bound on this count which goes to infinity would be sufficient, and presumably simpler to establish than an exact count.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AMS lecture: Structure and randomness in the prime numbers « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-23462")[#strong[#text("AMS lecture: Structure and randomness in the prime numbers « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2008")])]

#text("[…] well before the mark (sieve levels such as are typical). (The reason for this has to do with the parity problem, which I will not discuss further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lecture III: Small gaps between primes « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-33576")[#strong[#text("Marker lecture III: Small gaps between primes « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2008")])]

#text("[…] But there seems to be a significant obstacle to pushing things all the way to 2. Indeed, the parity problem tells us that for any reasonable definition of “almost prime” which is amenable to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lecture IV: sieving for almost primes and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-33583")[#strong[#text("Marker lecture IV: sieving for almost primes and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("[…] fairly typical). The selection of the sieve weights is now a well-developed science (see also my earlier post, and Kowalski’s guest post, on this topic), and Bourgain, Gamburd and Sarnak basically use […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-41236")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("The mathematician Sun Tzu and the military general Sun Tzu seem to be different individuals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-41238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2009")])]

#text("Hmm, I think you’re right. A shame; the story I had was a good one, but it appears to be apocryphal after all, so I’ve deleted it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-41248")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2009")])]

#text("A long time ago in a galaxy far, far away… :))")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The prime number theorem in arithmetic progressions, and dueling conspiracies « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-41576")[#strong[#text("The prime number theorem in arithmetic progressions, and dueling conspiracies « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2009")])]

#text("[…] while the genuine primes do not, is a reflection of the parity problem in sieve theory; see this post for further discussion. The symmetry formula is however enough to get “within a factor of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-42991")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("I was thinking about your theorem with Ben Green that says that the primes contain arbitrarily long progressions. Here is a strange but simple argument that this must be true:")

#text("Suppose that it weren’t true. Then there must exist an N such that there are no N-term arithmetic progressions of primes. Then if we exhibited an arithmetic progression a+bk, k=1,2,3,…,N-1 of all primes, we could know immediately that a is not prime, since if so then a would be part of an N-term progression of primes.")

#text("Also note that if this were possible, we could know that a is not prime without having any information about the possible divisors of a, since the fact that each a+bk, k=1,2,3,…,N-1, is prime says nothing about the possible divisors of a. But we need to have some information about the divisors of a in order to know that a is not prime, since the truth of the statement (a is not prime) depends on the divisors of a. This is a contradiction. Hence, your and Ben Green’s theorem must be true.")

#text("Comments?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jc")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-42993")[#strong[#text("jc")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("I don’t follow this argument. In particular, what you mean by “information about possible divisors” doesn’t make any sense to me. Consider the fact that one can test a number for primality without factoring, for instance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-42994")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("jc,")

#text("Yes, it is true that you can test a number for primality without factoring, but you cannot test a number for primality without having some information about its factors.")

#text("For instance, see the Wikipedia entry for the AKS algorithm. When testing whether n is prime, the algorithm checks whether 1<gcd(a,n)<n for a<= r < n. The result of this test gives some information about the factors of n.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Actually, the primality of a+bk does tell us something about the divisors of a. For instance, if a+b and a+2b are both prime (and b is positive), this forces a to be odd, simply because a+2b is also odd.")

#text("More generally, an ")#link("http://en.wikipedia.org/wiki/Argument_from_ignorance")[#text("argumentam ad ignorantiam")]#text(" does not rise to the level of a rigorous proof, though it may have some heuristic value: just because we cannot see any obvious way to connect the primality of a+b, a+2b, …, a+(N-1)b to the divisors of a, it does not necessarily follow that no such connection exists (and could possibly be discovered in the future by a sufficiently clever mathematician).")

#text("Incidentally, there are plenty of primality tests that do not require any explicit tests of divisibility by potential factors of the number being tested at all; Wilson’s theorem provides a simple (though impractical) such example. Another example is the Lucas-Lehmer test for the primality of a Mersenne number. (Of course, the certificate of primality provided by such tests does imply ")#emph[#text("a posteriori")]#text(" that there is no divisibility by smaller factors, but this does not imply that an explicit trial division is necessary ")#emph[#text("prior")]#text(" to establishing the primality certificate.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43003")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Terrence,")

#text("You are correct about my argument being refuted since a+b, a+2b prime implies that a is odd. But what if I formulate the argument as: a+bk, k=0,1,2,…,N-2, are prime doesn’t say anything about whether a+b(N-1) is prime, since it says nothing about the divisors of a+b(N-1)?")

#text("Also, I disagree with you about Wilson’s theorem. Calculating whether (n-1)! mod n is zero or negative one is essentially the same thing as asking whether n is prime, just stated in a different way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Essentially the same example applies: if a, a+b, a+2b are prime, and b is positive, then a+3b is odd (because a+b is odd).")

#text("In any case, even one could not immediately produce such examples, the basic argument is still an ")#emph[#text("argumentam ad ignorantiam")]#text(", and could potentially be refuted by an example of this type in the future. For instance, to use Wilson’s theorem as a hypothetical, suppose some clever mathematician found an ingenious formula that connected (a-1)!, (a+b-1)!, (a+2b-1)!, and (a+3b-1)! to each other. Then it is potentially conceivable that one could use Wilson’s theorem and the primality of a+b, a+2b, a+3b to say something about the primality of a. Now, I don’t know of such a formula (and in fact I strongly doubt that one exists); but I cannot rigorously rule out the possibility that something like this (or one of an infinite number of other possibilities, using some other number-theoretic fact than Wilson’s theorem) could actually happen (except by using my theorem with Ben, of course). All I can say is that I do not see any obvious way to pull off anything like this, but to use this ignorance to deduce anything is the logical fallacy of ")#emph[#text("argumentam ad ignorantium.")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43006")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("OK, that makes sense. Thank you very much for your response, Terence, and sorry for mispelling your name before.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3346bce1a43878be1b369685130200fcce7a8f33d86bf4c13c62143c4c11560-3f02520e83cf9c53fa5526d16f2585580850032b58825dba82709d31ef6d5060.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonios Manoussos")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-42995")[#strong[#text("Antonios Manoussos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Dear Prof. Tao,")

#text("In the text of your very nice article it is written “however, the prime number theorem does at least tell us that the primes have a positive relative density in the almost primes”. I am not an expert in this field but I have a question about that: Since the 2-primes less than a given $n$ are asymptotically $\\frac{n}{\\log n} \\log \\log{n}$ it looks like the relative density of the primes in the semi primes is 0. Is this o.k.?")

#text("Congratulations for your very interesting blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43001")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("For sake of this discussion, I define a semiprime to be the product of two ")#emph[#text("large")]#text(" primes – e.g. primes larger than ")#mi("N^\\varepsilon")#text(" for some fixed threshold ")#mi("\\varepsilon")#text(". These are the types of almost primes that are generated by sieves (semiprimes with small factors tend to get eliminated quite easily by such sieves). With this definition, the number of semiprimes less than N is comparable to ")#mi("N/\\log N")#text(" rather than ")#mi("N \\log \\log N / \\log N")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3346bce1a43878be1b369685130200fcce7a8f33d86bf4c13c62143c4c11560-3f02520e83cf9c53fa5526d16f2585580850032b58825dba82709d31ef6d5060.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antonios Manoussos")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-43005")[#strong[#text("Antonios Manoussos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2009")])]

#text("Thank you for the answer! Now it is clear to me.")

#text("Antonios")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-46452")[#strong[#text("Goldbach’s conjecture (to prove or not to prove) | MathFax.com")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")]

#text("[…] ")#link("https://terrytao.wordpress.com/2007/06/0")[#text("https://terrytao.wordpress.com/2007/06/0")]#text(" … ve-theory/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c463be46b6477cc24cafb2ed51437a99b0035dfbdfdc04b77234c20af1e6ed31-67a8a56e3e8cacc2f54c9da067a492e10c20b52e4a6af328247c773bfbbbbda7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Primos gemelos: Un vistazo a algunos resultados. « Lo fascinante de la teoría de números")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-66465")[#strong[#text("Primos gemelos: Un vistazo a algunos resultados. « Lo fascinante de la teoría de números")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2011")])]

#text("[…] 5. La conjetura de Elliot-Halberstam es otra conjetura acerca de teoría de números bastante tratada. En palabras de Terence Tao, “Una especie de Hipotesis de Riemann super generalizada“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4b2e474fcb71ccbf22fb2f3e0d3865364866635b7c00fd1c5920926cdd52c1b-9923419749e18ae264b9b207a4f15a27cf6f2ffe42351fe2212d49109697d57c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-110854")[#strong[#text("Craig")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2011")])]

#text("Yao’s XOR Lemma shows that computing the parity of several independent weakly unpredictable predicates amplifies the unpredictability to the point where it is almost random. Is there any connection between this and the parity problem in sieve theory?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 7: Sieving and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-131025")[#strong[#text("254B, Notes 7: Sieving and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2012")])]

#text("[…] known as the parity problem, which prevents sieve theory from lowering all the way to ; see this blog post for more discussion.) One formulation of this principle was established by Bourgain, Gamburd, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heuristic limitations of the circle method « What’s new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-144377")[#strong[#text("Heuristic limitations of the circle method « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2012")])]

#text("[…] which are much easier) on prime patterns, namely the parity problem. I discuss this problem in this previous blog post, and do not have much more to add here to what I already wrote in that […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-182747")[#strong[#text("Mathematics: What it takes to prove the Goldbach Conjecture? - Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2012")]

#text("[…] know, but finding creative ways around the parity problem in sieve theory is a promising approach:")#link("https://terrytao.wordpress.com/20")[#text("https://terrytao.wordpress.com/20")]#text("…Embed QuoteComment Loading… • Share • Embed • 4m ago Add […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-234613")[#strong[#text("强扭的瓜是甜的 » 素数并不孤独")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2013")]

#text("[…] Open question: The parity problem in sieve theory, Terence Tao, ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oldhat")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-234725")[#strong[#text("oldhat")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2013")])]

#text("dear professor Tao,")#linebreak()#text(" congratulations for your wonderful site! but it is ‘argumentum ad ignorantiam’, not ‘argumentam ad ignorantium’ (sorry for the nitpickery…).")

#emph[#text("[Unfortunately I am not able to locate this typo. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b31455ca026c6f7187cf9bdbdbfa1c75341ef2e188c9ad046fc92599a8473cf-0a9e59fd7bdaaa3c9040e490c909140b65f90a007ee93a7b4e1ae2deac46d6b3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 素数并不孤独 | fwjmath的相空间")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-235792")[#strong[#text("素数并不孤独 | fwjmath的相空间")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] Open question: The parity problem in sieve theory, Terence Tao, ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oldhat")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-235798")[#strong[#text("oldhat")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Dear professor Tao")#linebreak()#text(" yes, in fact it is not in your post, but it appears in two remarks above, which you wrote on december 29 2009, at 11:59 and at 12:58….forgive the grammatical obsession of an old latinist…and keep up your marvelous work (I can’t begin to tell you how envious I am, as a non mathematician, of the way of doing science you show in your blog)!")

#emph[#text("[Ah, found it, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-237094")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Regarding the remark immediately following (5):")#linebreak()#text(" I am having trouble seeing how (5) corresponds to the zeta-function identity you have posted (in the display following (5)).")

#text("Instead, (5) appears more closely related to the “identity” ")#mi("-\\frac{\\zeta^{\\prime}(s)}{\\zeta(s)}=\\left[\\frac{1}{\\zeta(s)}\\right]\\left[-\\zeta^{\\prime}(s)\\right]")#text(", which I will call (5*).")

#text("Here’s my reasoning.")#linebreak()#text(" First, (5) is just a verbose way of writing ")#mi("\\Lambda(n)=\\mu * L")#text(" (in the notation of recent Polymath8 blog posts)")

#text("Then, since ")#mi("\\mu")#text(" corresponds to ")#mi("\\frac{1}{\\zeta(s)}")#text(" and ")#mi("L=n\\to\\log n")#text(" corresponds to ")#mi("-\\zeta^{\\prime}(s)")#text(", (5) is a restatement of (5*).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-237097")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("The first part of (5) (equating ")#mi("\\Lambda")#text(" with ")#mi("\\mu * L")#text(") does correspond to the identity you state, but the second part of (5) (equating ")#mi("\\Lambda")#text(" with ")#mi("- 1 * \\mu L")#text(") instead corresponds to the identity in the text. Of course both identities are very easy to prove (and easily seen to be equivalent).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-237216")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Ah, it seems that the point of (5) is to justify the second equality. I was assuming that (5) was already asserting this statement, which boils down to ")#mi("(\\log n)(\\mu * 1)(n)=0")#text(" for all ")#mi("n \\in \\mathbb{N}")#text(".")

#text("Instead, if I understand correctly, you are using the display after (5) in order to justify the second equality of (5)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-237254")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Yes, one line using Liebniz: ")#mi("0 = L(\\mu * 1) = (L\\mu * 1) + (\\mu * L)")#text(" ")#mi("\\square")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-237258")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("In (4), ")#tao-math("O\\left(\\sum_d \\left|\\lambda_d\\right|\\right)", block: false)#text(" should be ")#tao-math("O\\left(\\sum_d \\left|c_d\\right|\\right)", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-238029")[#strong[#text("科学 – 六号教父 » 素数并不孤独")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")]

#text("[…] Open question: The parity problem in sieve theory, Terence Tao, ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-242074")[#strong[#text("Euclid Strikes Back | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")]

#text("[…] This idea can be extended to triples of boxes. Now Bob must make them pairwise relatively prime. I had an application to a complexity theory problem, in which it was needed to avoid randomness. In my application, the solution is being done by a deterministic machine. Perhaps there are other uses of this simple trick. I note that it is quite close to the “W-trick” described by Terence Tao in relation to Yitang Zhang’s advance on the twin-prime conjecture, and sketched by Ben Green in a comment here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/650426fc930caba813ddfce8f526fece228b505832f389ddd7827770ab01f89b-d79edc23ec186fe2eaba3da8af03d19aa8946bfe6d3911f341977071a01100c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kolbjorn Tunstrom")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-246490")[#strong[#text("Kolbjorn Tunstrom")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Regarding a sieve theoretic proof of Euclid’s theorem: If we sieve the interval ")#mi("A=\\{1,\\dots, p_k\\#\\}")#text(" by the ")#mi("k")#text(" first primes, then ")#tao-math("\\left|A\\right|=p_k\\#", block: false)#text(" is divisible by all denominators in the Legendre identity; no terms need to be rounded, the error term vanishes, and the number of integers in ")#mi("A")#text(" not divisible by any ")#mi("p\\in P_k:=\\{p_1,\\dots, p_k\\}")#text(" is given exactly by")

#mi("S(A,p_k\\#) = p_k\\# \\cdot \\prod_{p \\in  P_k}(1-\\frac{1}{p}) = \\prod_{p \\in  P_k}(p-1)\\geq 1.")

#text("Since this holds for any ")#mi("k\\geq 1")#text(", it follows that there must be infinitely many primes. Shouldn’t this work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-246498")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Yes, this is a valid proof of Euclid’s theorem, albeit one which is very close to Euclid’s original proof. But note that the sifted set that ")#mi("S(A,p_k\\#)")#text(" is counting here is not the set of primes in A, so one is not directly establishing the infinitude of primes by the usual sieve-theoretic method of viewing the primes as a sifted set, but instead using the primes as the set of sieving moduli, which is a different type of argument (more multiplicative number theory than sieve theory).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/650426fc930caba813ddfce8f526fece228b505832f389ddd7827770ab01f89b-d79edc23ec186fe2eaba3da8af03d19aa8946bfe6d3911f341977071a01100c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kolbjorn Tunstrom")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-246523")[#strong[#text("Kolbjorn Tunstrom")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2013")])]

#text("Thanks for the reply. You are right it is close to Euler’s proof. In fact, an almost replica of his proof appears by sieving the interval ")#mi("A = \\{1+ p_k\\#\\}")#text(" and exploiting the ")#mi("p_k\\#")#text("-periodicity of ")#mi("S(A,p_k\\#)")#text(" to show that ")#mi("S(A,p_k\\#) =  S(\\{1\\},p_k\\#) = 1")#text(".")

#text("I agree completely with your point that these proofs lean more or less towards multiplicative number theory. However, as a basis for building up intuition about what structures that develops throughout sieving it seems quite useful to think in these terms (and perhaps even more so pedagogically). From this perspective, proofs of landmark theorems, like Dirichlet’s theorem on arithmetic progressions, your own Green-Tao theorem on arbitrarily long arithmetic progressions of primes, or Zhang’s very recent result on bounded gaps between primes, all boil down to simple variations of the proofs above. Naturally, these proofs hold only for coprimes and not primes. But it is interesting to observe the immense gap between this simplicity and the sieve theoretic proofs.")

#text("Another aspect is that the periodicity of ")#mi("S(A,p_k\\#)")#text(" introduces certain symmetries and constraints. For example, it is easy to show that for an interval ")#mi("A_m")#text(" of length ")#mi("m")#text(", the bounds of ")#mi("S(A_{m}, p_k\\#)")#text(" and ")#mi("S(A_{p_k\\#-m}, p_k\\#)")#text(" are anti-symmetric, in the sense that")

#mi("\\inf  S(A_{m}, p_k\\#) -  m \\cdot \\prod_{p \\in P_k} \\left( 1-\\frac{1}{p} \\right)")

#mi("= - \\sup  S(A_{p_k\\#-m}, p_k\\#) +  (p_k\\#-m) \\cdot \\prod_{p \\in  P_k} \\left( 1-\\frac{1}{p} \\right).")

#text("It is merely a playful speculation, but do you think exploring the constraints and symmetries imposed by the periodicity of ")#mi("S(A,p_k\\#)")#text(" could be a useful parallel or addition to sieve theory?")#linebreak()#text(" Or has this already been done and doomed?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-248487")[#strong[#text("素数并不孤独 | ZHANG RONG")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")]

#text("[…] Open question: The parity problem in sieve theory, Terence Tao,")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-251525")[#strong[#text("Number Theory: Lecture 17 | Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")]

#text("[…] I mentioned that there is a field of study called sieve theory. In addition to the Wikipedia page, you might also like to look at this blog post by Terry Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-253502")[#strong[#text("Polymath 8 – a Success! | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2013")]

#text("[…] 6) (Added Nov 27) There is a difficult “parity problem” which seems to be a difficult obstacle for getting the gap to two. (And for various related goals). Terry Tao wrote about it in 2007 in this post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The parity problem obstruction for the binary Goldbach problem with bounded error | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-391134")[#strong[#text("The parity problem obstruction for the binary Goldbach problem with bounded error | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2014")])]

#text("[…] in both problems, preventing a solution to either conjecture by almost all known methods (see this previous blog post for more […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/comment-page-1/#comment-458471")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] way that can distinguish them from other twins of almost primes. The parity problem is discussed in these previous blog posts; this obstruction is ultimately powered by the Möbius pseudorandomness […]")
]
