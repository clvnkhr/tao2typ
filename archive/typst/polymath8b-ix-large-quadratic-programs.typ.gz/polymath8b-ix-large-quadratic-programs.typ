// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/
// Converted to Typst by tao2typ: "2026-10-14T15:18:57.116010+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8b, IX: Large quadratic programs", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8b, IX: Large quadratic programs")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 February 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/")[#text("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is the ninth thread for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8b project")]#text(" to obtain new bounds for the quantity")

#align(center)[#tao-fit-display[#mitex("H_m := \\liminf_{n \\rightarrow\\infty} (p_{n+m} - p_n),")]]

#text("either for small values of ")#mi("{m}")#text(" (in particular ")#mi("{m=1,2}")#text(") or asymptotically as ")#mi("{m \\rightarrow \\infty}")#text(". The previous thread may be found ")#link("https://terrytao.wordpress.com/2014/02/09/polymath8b-viii-time-to-start-writing-up-the-results/")[#text("here")]#text(". The currently best known bounds on ")#mi("{H_m}")#text(" can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the wiki page")]#text(".")

#text("The focus is now on bounding ")#mi("{H_1}")#text(" unconditionally (in particular, without resorting to the Elliott-Halberstam conjecture or its generalisations). We can bound ")#mi("{H_1 \\leq H(k)}")#text(" whenever one can find a symmetric square-integrable function ")#mi("{F}")#text(" supported on the simplex ")#mi("{{\\cal R}_k := \\{ (t_1,\\dots,t_k) \\in [0,+\\infty)^k: t_1+\\dots+t_k \\leq 1 \\}}")#text(" such that ")#metadata(none) <tao-d5963d22f572ba25cba0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("k \\int_{{\\cal R}_{k-1}} (\\int_0^\\infty F(t_1,\\dots,t_k)\\ dt_k)^2\\ dt_1 \\dots dt_{k-1}")]]

#align(center)[#tao-fit-display[#mitex("> 4 \\int_{{\\cal R}_{k}} F(t_1,\\dots,t_k)^2\\ dt_1 \\dots dt_{k-1} dt_k.")]]

#text("Our strategy for establishing this has been to restrict ")#mi("{F}")#text(" to be a linear combination of symmetrised monomials ")#mi("{[t_1^{a_1} \\dots t_k^{a_k}]_{sym}}")#text(" (restricted of course to ")#mi("{{\\cal R}_k}")#text("), where the degree ")#mi("{a_1+\\dots+a_k}")#text(" is small; actually, it seems convenient to work with the slightly different basis ")#mi("{(1-t_1-\\dots-t_k)^i [t_1^{a_1} \\dots t_k^{a_k}]_{sym}}")#text(" where the ")#mi("{a_i}")#text(" are restricted to be even. The criterion ")#link(<tao-d5963d22f572ba25cba0>)[#text("(1)")]#text(" then becomes a large quadratic program with explicit but complicated rational coefficients. This approach has lowered ")#mi("{k}")#text(" down to ")#mi("{54}")#text(", which led to the bound ")#mi("{H_1 \\leq 270}")#text(".")

#text("Actually, we know that the more general criterion ")#metadata(none) <tao-1fad2581c75937a373a0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("k \\int_{(1-\\epsilon) \\cdot {\\cal R}_{k-1}} (\\int_0^\\infty F(t_1,\\dots,t_k)\\ dt_k)^2\\ dt_1 \\dots dt_{k-1}")]]

#align(center)[#tao-fit-display[#mitex("> 4 \\int F(t_1,\\dots,t_k)^2\\ dt_1 \\dots dt_{k-1} dt_k")]]

#text("will suffice, whenever ")#mi("{0 \\leq \\epsilon < 1}")#text(" and ")#mi("{F}")#text(" is supported now on ")#mi("{2 \\cdot {\\cal R}_k}")#text(" and obeys the vanishing marginal condition ")#mi("{\\int_0^\\infty F(t_1,\\dots,t_k)\\ dt_k = 0}")#text(" whenever ")#mi("{t_1+\\dots+t_k > 1+\\epsilon}")#text(". The latter is in particular obeyed when ")#mi("{F}")#text(" is supported on ")#mi("{(1+\\epsilon) \\cdot {\\cal R}_k}")#text(". A modification of the preceding strategy has lowered ")#mi("{k}")#text(" slightly to ")#mi("{53}")#text(", giving the bound ")#mi("{H_1 \\leq 264}")#text(" which is currently our best record.")

#text("However, the quadratic programs here have become extremely large and slow to run, and more efficient algorithms (or possibly more computer power) may be required to advance further.")

#heading(level: 1)[#text("Comments (119)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("“")#mi("sym")#text("” –> “")#mi("\\mathrm{sym}")#text("” (two times)")

#text("(Just remove the comment when noted.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272397")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Concerning a previous suggestion to work with orthonormal basis, it has the advantage that the matrix ")#mi("M_1")#text(" (representing the denominator quadratic form) is the unit matrix. So (for such basis) the M-value is simply the largest eigenvalue of the matrix ")#mi("M_2")#text(" (representing the numerator quadratic form) – which should be simpler to compute (than for the generalized eigenproblem.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272402")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("I’d just like to try to check in my own mind where we are for the different possible improvements in the unconditional setting. I’ve tried to recall all the main ideas for improvements to the ")#mi("H_1")#text(" bound, but I’ve probably forgotten one or two.")

#text("Use of general symmetric polynomial approximations: Currently implemented, although run-time restrictions mean that we are limited to degree at most about 18 at the moment. Potential to reduce k by 1 or 2 if we can feasibly calculate much larger degrees. Bottleneck is currently calculating the matrices ")#mi("M_1,M_2")#text(".")

#text("Use of the epsilon trick: Currently implemented. Appears to reduce k by 1 or 2.")

#text("Using a piecewise polynomial decomposition: Not implemented. We don’t have a suitable decomposition of our region into a small number of polytopes where we can analytically write down a simple expression for integrating a monomial. For the vanilla region ")#mi("\\mathcal{R}_k")#text(" this would probably only be of minor benefit anyway, whereas when we incorporate other ideas (such as the epsilon trick) we would expect this to make our polynomial approximations converge faster (as the degree increases). Doesn’t change the bound for ")#mi("M_k")#text(", but can improve implementation.")

#text("Use of support restricted to products of k-1 variables small: Not implemented. This would require a difficult region to integrate over, and we do not know how to do this (as with piecewise polynomial problem). Would probably only reduce k by at most 1.")

#text("Functions with larger support but with vanishing marginals: Not implemented. The vanishing marginal condition is very restrictive for relatively low degree approximations unless we can split the support into different polytopes (which we do not know how to do effectively). Numerics from small ")#mi("k")#text(" suggest that this might not offer much potential improvement when combined with the epsilon trick.")

#text("Removing terms ")#mi("1_{n+h_i,n+h_j}")#text(" prime: Not implemented. Back of the envelope numerics suggest that this is only of small potential benefit for the size of k we are looking at. Since (by parity) we lose a factor of at least 2 in our upper bound, we find that the contribution of these terms (of size roughly ")#mi("2(\\log{k})^2/k^2")#text(") is similar to the difference ")#mi("M_{k-1}-M_k")#text(". Therefore this appears to only be of potential use if we are stuck at a numerical bound which just fails to decrease k by 1. Would probably only reduce ")#mi("H_1")#text(" by 2 even if this was the case.")

#text("Removing contributions when all the ")#mi("n+h_i")#text(" are not prime: Not implemented. Any possible benefit expected to be negligible.")

#text("Incorporation of Zhang/Polymath 8a technology: Not implemented. Since ")#mi("2\\varpi")#text(" is similar in size to ")#mi("1/k")#text(", the smoothness/dense divisibility restrictions to the moduli are rather non-trivial. Unfortunately this means that it appears difficult to obtain a suitably simple integral expression which can be evaluated easily like the monomials. Anything which does avoid the use of e.g. Dickman rho functions appears to throw out too much information to give a non-negligible benefit. There are also (again) issues to do with splitting of the polytope, since we would want to make full use of Bombieri-Vinogradov and only use Zhang/8a to estimate terms from a region outside of this. Would give a noticeable improvement if the restriction to smooth/densely divisible moduli was dropped, but it is slightly unclear to me how much benefit could be expected if this were able to be implemented (it would mainly hurt large divisors, which are the key ones to increase the chances of getting primes).")

#text("Would this count as a fair summary? Please correct me if not.")

#text("It appears that unless we come up with a effective means of doing a polytope decomposition or of incorporating Zhang/polymath 8a (or some new idea) then the remaining scope for improvement appears to just be enabling a higher degree approximation (by choosing only `good’ monomials, optimising the code, or by doing a larger computation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272409")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Concerning the epsilon trick, Terry’s upper bound for")#linebreak()#text(" ")#mi("M_{k, \\epsilon}")#text(" implies (at least currently) only that ")#mi("k > 23")#text(". If this bound is sufficiently tight (as for the ")#mi("M_k")#text(" case), there is still some hope for significant improvement.")

#text("It should also be remarked that the optimal ")#mi("F")#text(" should vanish on a certain sub-region of ")#mi("R")#text(" (disjoint from the supports of the integrands for the numerator functionals ")#mi("J^{(i)}_{k, \\epsilon}(F)")#text(") – resulting by a reduced denominator (since its integrand ")#mi("F^2")#text(" should be integrated over smaller region). Some preliminary analysis shows that this reduction of ")#mi("F")#text(" support happens only for ")#mi("\\epsilon > 1/(2 k -1)")#text(" and grows with ")#mi("\\epsilon")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272433")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Yes, this is a good summary of the situation. I had the vague thought that perhaps some other bases than the polynomial basis may possibly provide some speedup (perhaps by making the relevant matrices better conditioned), but the price one pays for this is that the matrix coefficients are unlikely to be rational once we move away from the polynomial setting (e.g. they are likely to involve some logarithms, at the very least) and this will slow things down a lot of we insist on exact arithmetic.")

#text("One possible “cheap” way to implement the Polymath8a stuff is to calculate a good near-extremiser for an untruncated simplex, and then naively truncate it to a truncated simplex. But my feeling is that if one does this too crudely, the error terms are too big (because of the ")#mi("\\varpi \\sim 1/k")#text(" issue, or more precisely ")#mi("\\delta \\sim 1/k")#text("), and if one tries to be as sparing as possible with the terms to be cut off then one may be dealing with some tricky 50-dimensional integral for the error terms which does not look appetising at all to compute. In a sense, we’re victims of our own success here; it used to be that k was so large that there were all sorts of good ways to estimate the truncation error, but we’ve manged to get k so low that it is well out of the asymptotic regime (but not yet out of the “curse of dimensionality” regime, alas).")

#text("It’s possible that in the future, progress on EH advances to the point where the optimal k drops down to something like k=10 rather than k=50, at which point some of these currently infeasible options become feasible again. (But that would require quite a huge amount of progress on EH, I think.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272405")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Pace, I wonder if you could give a high-level summary of the current methods for bounding ")#mi("M_k")#text(" and ")#mi("M_{k,\\varepsilon}")#text(" with some estimation of which steps are the most memory and CPU intensive: is it the creation of the matrices ")#mi("M_1,M_2")#text(", the inversion of ")#mi("M_1")#text(", or the eigenvalue computation for ")#mi("M_1^{-1} M_2")#text(" that is the biggest cost? Also, I’m curious as to why the eigenvector ends up having rational coefficients rather than algebraic coefficients (or is one just getting an approximate eigenvector instead?).")

#text("I do like the idea of using imprecise (but possibly faster) methods to locate a good vector, and then doing a precise (and relatively quick) verification of the required quadratic inequality for that vector – this would also make the claims easier to reconfirm independently. Unfortunately some of the methods suggested so far (e.g. computing determinants of ")#mi("M_2 - 4 M_1")#text(") don’t automatically produce a vector (at least as far as I can tell), although they would still be useful for such tasks as finding the optimal epsilon for a given value of k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272413")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("It is still possible to compute (sufficiently good) approximation of the eigenvector corresponding to the largest eigenvalue of")#linebreak()#text(" ")#mi("M_2 - 4 M_1")#text(" – which should be useful for confirmation that ")#mi("M_k > 4")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272440")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("Here is a quick high-level summary. (Maybe not so high-level [and maybe not so quick!]. Ignore details as you choose. On the other hand, if you would like more details about any point, just let me know.)")

#text("The first step of the computation is finding the entries of symmetric matrices ")#mi("M_1")#text(" and ")#mi("M_2")#text(", corresponding to the ")#mi("I")#text(" and ")#mi("J")#text("-integrals respectively. This is done as described in Maynard’s work. The computation relies on Maynard’s formulas (7.4) and (7.5) from his preprint. These allow one to express the integral over ")#mi("\\mathcal{R}_k")#text(" on a single arbitrary monomial, possibly multiplied by a power of ")#mi("1-e_1")#text(", in terms of easily computed rational numbers. Similar formulas over the regions ")#mi("(1\\pm \\varepsilon)\\mathcal{R}_k")#text(" follow similarly by the obvious substitutions, replacing ")#mi("1-e_1")#text(" with ")#mi("1\\pm \\varepsilon-e_1")#text(" as needed.")

#text("Fix some collection of symmetric polynomials ")#mi("b_n:=b_n(x_1,\\ldots, x_k)")#text(". (Ideally these polynomials are linearly independent.) We then take ")#mi("F=\\sum_{n} c_n b_n")#text(" for indeterminates ")#mi("c_n")#text(" which correspond to coordinates of the matrices after squaring. In other words, the ")#mi("(i,j)")#text(" entry of ")#mi("M_1")#text(" is ")#mi("\\int_{\\mathcal{R}_k} b_i b_j\\ dx_1\\ldots dx_k")#text(". So we need to find the types of monomials that occur in the product ")#mi("b_i b_j")#text(", and how often they occur in order to apply James’ formula. A similar computation is done for the ")#mi("J")#text("-integral although this is much slower, as the inner integral involves some expanding of terms. This part of the computation is highly parallelizable and is not memory or CPU intensive; just time intensive. [The computation is affected by the complexity of ")#mi("\\varepsilon")#text(", as we are doing exact arithmetic. As will be clear a bit later, we could work with real approximations here if necessary. This *might* speed things up, but I doubt it would be by much at present, and we would unfortunately lose our knowledge that the eventual output is a proven lower-bound.]")

#text("Currently this step takes a little more than half of the total time. However, some of this time can be saved if one pre-computes a table of the monomials that occur in products ")#mi("b_i b_j")#text(" and ")#mi("\\left(\\int_{0}^{1-\\sum_{i=1}^{k-1}} b_i\\ dx_k\\right)\\left(\\int_{0}^{1-\\sum_{i=1}^{k-1}} b_j\\ dx_k\\right)")#text(". This look-up table computation is also highly parallelizable, but at present is memory intensive. If someone wants to work on finding a basis which (1) multiplies well, (2) integrates well with respect to the inner ")#mi("J")#text("-integral, and (3) from which it is easy to find which monomials occur, that would be very useful. In particular, finding an algorithm to count the number and types of monomials in ")#mi("e_1^{a_1}e_2^{a_2}\\cdots e_k^{a_k}")#text(" which is not memory intensive (and which is somewhat quick) would be very helpful. [I imagine this is not a hard problem. I just haven’t thought about it yet.]")

#text("At present, the second step in the computation is to find the *exact* inverse of ")#mi("M_1")#text(". This is the most memory intensive part of the program, and simply won’t run in Mathematica without more than 64GB of RAM, when the degree gets to be about 20-22. I’m currently playing with the other option that has been discussed recently, of instead just solving the generalized eigenvalue problem. I don’t know yet if this is less memory intensive (as implemented in Mathematica), but I believe it probably is.")

#text("The third step is to compute ")#mi("M_3= M_1^{-1}M_2")#text(" exactly. This is relatively quick and easy.")

#text("Fourth, we compute a real approximation ")#mi("M_3^{\\prime}")#text(" to ")#mi("M_3")#text(". This step is also very quick. In the past we’ve been using 150 digit approximations in every entry, but I’m currently thinking this may have been extreme overkill (and may slow down subsequent steps). We may be able to get by with many fewer digits (but not too many fewer, I’m still experimenting with this).")

#text("Fifth, we find an eigenvector ")#mi("x^{\\prime}")#text(" of ")#mi("M_3^{\\prime}")#text(", corresponding to the largest eigenvalue. This step is not too long, nor too memory intensive; but I haven’t been able to explore this step in the past because the computation of ")#mi("M_1^{-1}")#text(" was usually the hang-up. We will likely replace this step with finding the generalized eigenvector. I expect the new computation to take about the same time as the old, but I don’t have a lot of data yet.")

#text("Sixth, we find a rational approximation ")#mi("x")#text(" of the vector ")#mi("x^{\\prime}")#text(". This is again very quick and easy.")

#text("Finally, we compute ")#mi("(x^{T}M_2 x)/(x^{T}M_1 x)")#text(" using exact arithmetic. This is very quick, and the output is a proven lower bound on ")#mi("M_{k,\\varepsilon}")#text(".")

#text("If the generalized eigenvector functionality in Mathematica turns out to be less RAM intensive, then the new difficulty will be in building the look-up table for large degrees.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272444")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2014")])]

#text("It should be remarked that since ")#mi("M_3")#text(" is not symmetric, some of the eigenvalues (and corresponding eigenvectors) of ")#mi("M^{\\prime}_3")#text(" may be complex (in particular, for clusters of eigenvalues). A related problem is that the algorithm for the eigenproblem of nonsymmetric ")#mi("M_3")#text(" is in general slower (with less numerical stability) than the corresponding algorithm for the generalized eigenproblem with the symmetric positive definite matrices ")#mi("M_1, M_2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andre")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272485")[#strong[#text("andre")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("The numerical analysis mathematican’s standard questions are")#linebreak()#text(" 1. Do you really need the matrices explicitly in memory?")#linebreak()#text(" 2. Wouln’t it suffice to only use matrix-vector-products?")#linebreak()#text(" 3. If your matrices are symmetric what could you say about their")#linebreak()#text(" L.D.L^T decomposition?")#linebreak()#text(" 4. Is it possible to factor the L matrices again?")

#text("So perhaps on needs to check if there are somehow better polynomials")#linebreak()#text(" for easier decomposition of the $M_1$ and $M_2$ matrices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272489")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("I woke up this morning, and realized there is the potential to get a huge speed up when doing multiple runs of the computation of the ")#mi("J")#text("-integral by creating a second look-up table.")

#text("The first look-up table, for the ")#mi("I")#text("-integral, yields the the number and types of monomials occurring in a product ")#mi("b_i b_j")#text(". For the ")#mi("J")#text("-integral, we first explicitly compute ")#mi("\\left(\\int_{0}^{1-\\sum_{t=1}^{k-1}x_t} b_i\\ dx_k\\right)\\left(\\int_{0}^{1-\\sum_{t=1}^{k-1}x_t} b_j\\ dx_k \\right)")#text(", re-express this as a linear combination of products ")#mi("b_i^{\\prime} b_j^{\\prime}")#text(", and then use the first look-up table. Ultimately, it would make more sense to just have a separate look-up table for these more complicated products (possibly still using the first look-up table to construct the second one).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272490")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Pace, does “explicitly compute” means using symbolic computation?")#linebreak()#text(" (I’m asking that because symbolic computation can take much more time than numerical one).")#linebreak()#text(" Perhaps symbolic computation may be made only once (to prepare an additional table for the coefficients of the above linear combination of products – since these coefficients are dependent only on the indices ")#mi("i ,j")#text(" of the above products.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272504")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Right! The idea is to do the (symbolic) computation once to form the look-up table of coefficients.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272462")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Way back in ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251896")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-251896")]#text(" James gave approximate values for the entirely unenhanced M_k for k=10, 20 etc. I just realised that those entries can easily be checked using the code developed by James and Pace for use on k in the 50’s, and moreover that this can give at least a provisional guide to the dependence of M on d for values of k across the whole range still of interest. Accordingly, and after checking that the code duly gives the same M_k for k=3 and 4 that were obtained using other methods, I did a few runs and obtained the following improved values:")

#text("k=5: d=5, M=2.00679…")#linebreak()#text(" k=10: d=8, M=2.54478…; d=10, M=2.54534…")#linebreak()#text(" k=20: d=8, M=3.11055…; d=10, M=3.12136…; d=12, M=3.12543…")#linebreak()#text(" k=30: d=8, M=3.41946…; d=10, M=3.45095…; d=12, M=3.46744…")#linebreak()#text(" k=40: d=8, M=3.60972…; d=10, M=3.66230…; d=12, M=3.69443…")#linebreak()#text(" k=50: d=8, M=3.73521…; d=10, M=3.80574…; d=12, M=3.85268…")

#text("I’m presuming these are reliable; at least they do not contravene the upper bounds previously determined. But it’s interesting that they are so much closer to those bounds than the estimates we had before, and also that there is non-trivial dependence on d throughout, albeit diminishing as d approaches k.")

#text("I also did a little survey for k = 10 through 50 with Pace’s latest code that incorporates epsilon. Here are the optimal values that come out using d=10, with values for epsilon drawn only from reciprocals of integers:")

#text("k=10, eps=1/9, M=2.68235…")#linebreak()#text(" k=20, eps=1/15, M=3.21470…")#linebreak()#text(" k=30, eps=1/23, M=3.51943…")#linebreak()#text(" k=40, eps=1/34, M=3.71480…")#linebreak()#text(" k=50, eps=1/46, M=3.84772…")

#text("I think it would be possible to use small-d calculations of this kind to obtain a more accurate idea of how the optimal epsilon varies with d for a given k, leading to a better guess for what epsilon to explore in the highly CPU-intensive calculations currently in progress for k=52. I’ll probably have a go at that soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272488")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("If you are just using my code as-is, then these values are not reliable. You would need to add the restriction that signatures are limited to lengths at most size ")#mi("k")#text(". (Now that I think about it, this should be an easy change. In the TermIntegral function, just return 0 if the length of T is larger than k. [You might also want to restrict the symmetric function generator as well.])")

#text("That said, thank you for this work! I hope you continue to find patterns, as these will be helpful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272497")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Pace: I remembered your earlier comment about this, but I’m confused – I’m not (yet) exploring values of d exceeding k, so surely this issue doesn’t yet arise? (Indeed, since you exclude signatures with any element equal to 1, surely it wouldn’t arise until d exceeds 2k?) Please clarify. At any rate, I’ve made the change you suggest and for a couple of sample parameters I’m getting the same values I posted above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272502")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("When computing the integrals you are squaring quantities. So for instance, when ")#mi("k=10")#text(" and ")#mi("d=10")#text(", you will be squaring ")#mi("m=m(2,2,2,2,2)")#text(", one term of which is ")#mi("m(2,2,2,2,2,2,2,2,2,2)")#text(". This would (barely) have been okay, except that when computing the ")#mi("J")#text("-integral (after the initial integration, one summand of which leaves ")#mi("m")#text(" alone) we now only have ")#mi("k=9")#text(" variables. (So, this probably does not have a large effect, but it does exist.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272505")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Looking more closely, the d=10, k=10 case should have been the only one where this problem arises.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272510")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Ah, I get it – many thanks. Yes, I’d just reached the same conclusion (we’re safe until d=k, and also for d=k when k is odd). Actually there seems to be some subtler reason why the specific case d=k, k even is also OK, because I’m not seeing a change in values even at 50-digit precision from excluding that signature. (By the way, for simplicity of audit trail I’m now only using your latest code, specifying epsilon as zero as desired.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/274d5e7e5d392ff1f8ea0fc5163469e93787a972af241c54606bd447853f7698-f743794bc50c62000ba24db25576f2b1f3735c70d04b33e4e8d4646b98a67e16.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of turcas")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272472")[#strong[#text("turcas")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Reblogged this on ")#link("http://georgeturcas.wordpress.com/2014/02/22/polymath8b-ix-large-quadratic-programs/")[#text("George Turcas")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272506")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("One more data point. I ran the ")#mi("d=22, \\varepsilon=1/30, k=51")#text(" computation (using only signatures with even entries) and got ")#mi("M_{51,1/30}\\geq 4.011910")#text(". This means we are down to ")#mi("H\\leq 252")#text(", and it looks probable that we can reduce ")#mi("k")#text(" once more with minimal effort.")

#text("It took 1 day 5 hours to form the matrices (not counting the time to make the look-up table). It took 2 hours to find the inverse matrix. Finally, it took a little less than 4 hours to find the eigenvector.")

#text("I also ran the generalized eigenvector computation, got the same answer, only used 50 digits real approximations, and the computation took 2.5 hours (as opposed to the 6 hours above).")

#text("I wasn’t near the computer during these computations, so have no idea about the RAM needs of each step (except that the matrix formation step didn’t require much RAM at all).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Nice! Great to see that the improved matrix computation performance is translating into tangible gains in the degree, and thence in the value of k and H. (Amusingly, this already makes obsolete the value of H given in the recent survey of Ben Green at ")#link("http://arxiv.org/abs/1402.4849")[#text("http://arxiv.org/abs/1402.4849")]#text(" .) The fact that the two different matrix computations arrive at the same answer is also reassuring :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272515")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Is it possible that the optimal ")#mi("\\epsilon")#text(" (which by now is ")#mi("1.7/k")#text(") could be much larger than ")#mi("1/k")#text(" (for sufficiently large degree)?")

#text("Perhaps the dependence of optimal ")#mi("\\epsilon")#text(" on the degree may be explained by the fact that the optimal ")#mi("F")#text(" vanishes on a certain simplex (whose size is growing with ")#mi("\\epsilon")#text(") inside the whole simplex ")#mi("R")#text(" – so for polynomial approximation with larger degree it is easier to approximate zero (the value of optimal ")#mi("F")#text(") on this inner simplex for larger values of ")#mi("\\epsilon")#text(".")

#text("This indicates the possibility that by taking this inner simplex into account by taking the integral in the denominator over the (true) reduced support of ")#mi("F")#text(", it may be possible to get much larger values of optimal ")#mi("\\epsilon")#text(" (without using very large degrees) with larger M-values (for the same ")#mi("k")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272521")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("I’m currently doing some more precise computations of the optimal epsilon (using a simple binary chop) for small k and for d ranging up to k, and the trend seems to be that the optimal epsilon peaks when d is k-1 or k-2, and for d=k (which, unsurprisingly, always gives the best M) the optimal epsilon exceeds 1/k by a number that grows slowly with k, but the absolute value of the optimal epsilon for d=k still falls with increasing k. (Incidentally, I’m not exploring d exceeding k, because the code is throwing me singular-matrix errors then, but the growth of M (for optimal epsilon) with d decelerates really sharply as d approaches k so I don’t think this is an urgent issue.) I think when d=k=40 or 50 we will be looking at an optimal epsilon between 0.05 and 0.1, but I’ll be more confident once I’ve gathered more data points.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272528")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("The (exact) matrix ")#mi("M_1")#text(" representing the denominator quadratic form should be positive definite for each degree ")#mi("d")#text(" (since we are working with linearly independent basis functions) – therefore its apparent singularity (for ")#mi("d > k")#text(") shows that there is some bug in the implementation of the algorithm!")

#text("More interesting than the behavior of optimal ")#mi("\\epsilon")#text(" is the behavior of ")#mi("k \\epsilon")#text(" (for optimal epsilon) – is it growing with ")#mi("d")#text(" (for each fixed ")#mi("k")#text(")? could you please give some data about it (for several pairs ")#mi("(k, d)")#text(") to illustrate its behavior?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272531")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Pace just confirmed to me that he does not expect his code to work for d greater than k, so there’s no concern there. As to your question, can you clarify? – clearly for a fixed k, ke grows with d iff e does, so I must not be understanding your question.")

#text("I’ll have some reasonably comprehensive trend summaries later today.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272534")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Concerning the behavior of ")#mi("k \\epsilon")#text(" with respect to ")#mi("d")#text(" you are right (of course), but it is also interesting to see its behavior wrt ")#mi("k")#text(" (for sufficiently large d).")#linebreak()#text(" I have some indication (from a preliminary analysis) that optimal ")#mi("\\epsilon")#text(" is decaying more slowly than ")#mi("1/k")#text(". (i.e. that ")#mi("k  \\epsilon")#text(" for sufficiently large ")#mi("d")#text(" should grow unboundedly with ")#mi("k")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272535")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Got it. So far I only have data for small d, but I can say that for d=5, ke rises with k at first but peaks at 1.097 when k=11 and is down to 0.67 by k=50. The peak for d=4 is also at k=11, but for d=3 it’s falling with rising k all the way from k=3, so I’ll have to look at slightly higher d to know what’s really going on here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272537")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("In other words, the idea is to estimate the “large d limit” of ")#mi("k  \\epsilon")#text(" for each fixed ")#mi("k")#text(", and see its behavior as a function of ")#mi("k")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272538")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Well, now you’re confusing me again – that would be the same as the behaviour of the “large d limit” of epsilon as a function of k, which is as I noted above – it’s slightly over 1/k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272541")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("The meaning of the “large d limit” of ")#mi("k \\epsilon")#text(" (for each fixed k) is simply to estimate the limit of ")#mi("k\\epsilon")#text(" as ")#mi("d")#text(" tends to infinity. (e.g. for the current k=51 and ")#mi("\\epsilon = 1/30")#text(" it seems that this limit should be larger than 51/30 = 1.7).")#linebreak()#text(" As stated above, ")#mi("\\epsilon > 1/k")#text(", so we know that this limit is larger than 1 and grows with k, but how fast it grows, as a function of k? (is it unbounded for large k, as I think, or not?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272543")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Regarding the ")#mi("d")#text(" bigger than ")#mi("k")#text(" case: The old code should not work here, because the set of symmetric polynomials of the form ")#mi("(1-e_1)^a m(\\alpha)")#text(" (with the signature $\\alpha$ having entries bigger than 1) does not remain linearly independent when the degree of the signatures ranges over all possibilities up to and exceeding ")#mi("k")#text(". (Try the case when ")#mi("k=1")#text(" for instance.) However, as far as I know, this should not cause a problem in the generalized eigenvector set-up (other than to slightly slow things down).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272545")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Ah, OK. Well, as noted, I can’t test values of d exceeding k using Pace’s current code. I would expect that the best epsilon continues to rise with d beyond k for any fixed k, but I’m not sure that that’s worth exploring, because M seems to be very nearly maximal (i.e. it is growing with d much more slowly than before) before d reaches k.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272550")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("What is really interesting is the behavior of the “large d limit” of ")#mi("k \\epsilon")#text(". Is it bounded as a function of k (as previously assumed), or is it unbounded (as seems to me now)?")#linebreak()#text(" If it is unbounded, the optimal ")#mi("\\epsilon")#text(" can be much larger (with sufficiently large d) – which may indicate a significant improvement in k.")#linebreak()#text(" (Note that the current upper bound on ")#mi("M_{k, \\epsilon}")#text(" implies only that ")#mi("k > 23")#text(").")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272523")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Just to fill in the gap in the world-records column of current interest: for k=5, d=5 I get M=2.20264… (with an optimal epsilon of 0.2048).")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272539")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Here’s a question I just asked Pace but he thought others (especially Eytan, I suspect) might have a better idea. I checked k=d=4 using Pace’s code, and the best M I get is 2.062926693 (with epsilon = 0.22956). This is greater than the value of 2.01869 that Pace obtained with epsilon=0.18 (in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262158")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-262158")]#text("), so I tried that value of epsilon and I still got a bigger value than Pace’s, 2.054687. So, remembering the issue of signatures of length exceeding k, I stepped back to d=3 – but I get 2.045786, still well above Pace’s value. Should I be worried about this? I don’t properly understand the maths behind Eytan’s idea described in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261838")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-261838")]#text(" (which was the basis of Pace’s computation), so I thought I should check.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272540")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("If you can post (or put on dropbox) the polynomials used, say for d=3, together with the J and I values, I could verify them with Maple.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272542")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Many thanks! However, here I’m using the code that Pace developed for large k, from which I don’t know how to extract the explicit polynomials. If Pace can offer guidance on how to do that, I’ll do as you suggest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272553")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("I double checked it and my program seems to work out. Take ")#mi("k=4, \\varepsilon=18/100")#text(". Let ")#mi("c_1,\\ldots, c_7")#text(" be the entries of")

#text("{35958260/235553951, -(50078641/92388318), 79192071/282465067, -(")#linebreak()#text(" 48604192/195227029), -(78520320/199602007), -(81680335/")#linebreak()#text(" 131295067), 8512013/371894111}")

#text("Take ")#mi("F=c_1*1 + c_2*p_2 + c_3 p_3 + c_4*(1+\\varepsilon-e_1) + c_5*(1+\\varepsilon-e_1)p_2+c_6*(1+\\varepsilon-e_1)^2+ c_7(1+\\varepsilon-e_1)^3")#text(" where ")#mi("e_1=x_1+x_2+x_3+x_4")#text(", ")#mi("p_2=x_1^2+x_2^2+x_3^2+x_4^2")#text(" and ")#mi("p_3=x_1^3+x_2^3+x_3^3+x_4^3")#text(".")

#text("You should get ")#mi("M_{4,18/100}\\geq 2.04579")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272567")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("I actually get ")#mi("M_{4,18/100} \\geq 2.045655896")#text(" from this, but I’ll call it close enough (presumably it is coming from rounding the eigenvector?).")

#raw("\neps := 18/100;")

#text("c1 := 35958260/235553951;")#linebreak()#text(" c2 := -(50078641/92388318);")#linebreak()#text(" c3 := 79192071/282465067;")#linebreak()#text(" c4 := -(48604192/195227029);")#linebreak()#text(" c5 := -(78520320/199602007);")#linebreak()#text(" c6 := -(81680335/131295067);")#linebreak()#text(" c7 := 8512013/371894111;")

#text("e1 := x1+x2+x3+x4;")#linebreak()#text(" p2 := x1^2+x2^2+x3^2+x4^2;")#linebreak()#text(" p3 := x1^3+x2^3+x3^3+x4^3;")#linebreak()#text(" F := c1*1 + c2*p2 + c3 *p3 + c4*(1+eps-e1) + c5*(1+eps-e1)*p2+c6*(1+eps-e1)^2+ c7(1+eps-e1)^3;")

#text("Iint := int(int(int(int(F*F, x4=0..1+eps-x1-x2-x3),x3=0..1+eps-x1-x2),x2=0..1+eps-x1),x1=0..1+eps);")

#text("marginal := int(F, x4=0..1+eps-x1-x2-x3);")

#text("Jint := 4 * int(int(int( marginal*marginal, x3=0..1-eps-x1-x2), x2=0..1-eps-x1), x1=0..1-eps);")

#text("evalf(Jint/Iint);")#linebreak()
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272571")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("That discrepancy is strange! It isn’t round-off on my end. The value I’m getting for Jint/Iint (using those rational coefficients) is exactly")

#text("2875735523016629068741175964840742575048112964757776538183474000859721435716670538831465909183618392849627156512838669025828999932027/")#linebreak()#text(" 1405687353551049804337736122604236419384565626408790839655020559027003306701017406210501472288913119227666603789342318453993312108750")

#text("So ")#mi("M_{4,18/100}\\geq 2.045786010489\\ldots")#text(". Maybe round-off error on your end?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272575")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("I am getting")

#text("Jint/Iint =")

#text("112805940582930117839342308454515665732548154445069213111398986990206498514376044710654769998982151256045268574930189154070867853942748204311984028009988367010311873424")#linebreak()#text(" /")#linebreak()#text(" 55144142657853654365564445664600642139014017 646291100083550438379226357318392264559974985439172491855197950450119863075917734899756314238903142624644107058773523923075")

#text("with")

#text("Jint= 7050371286433132364958894278407229108284259652816825819462436686887906157148502794415923124936384453502829285933136822129429240871421762769499001750624272938144492089")#linebreak()#text(" /")#linebreak()#text(" 1503397131218453159163272735128833401375525832080327795183919892914673536996939361897130816655717647821109961157503227305815102605266463600374304201477050781250000000000")#linebreak()#text(" = 0.004689626673")

#text("and")

#text("Iint=353658121903823340487827132689438141023017589522469777672281150419922124857413914125220365170258084689420878307647029507248580405684234336399824432541972478906679")#linebreak()#text(" /")#linebreak()#text(" 154268745226841433680374306634993326419807043856246559069698369643320677197056468111939028805460845695929192743434674599281973010641420026333101601562500000000000000")#linebreak()#text(" = 0.002292480706")

#text("so there is some weird discrepancy here that we should probably track down. (My maple code is just the one posted above, so if you have maple, you may be able to do a side-by-side comparison with your Mathematica code.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272584")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("I’m getting the same as Pace Nielsen; see ")#link("http://speedy.sh/revYz/output.jpg")[#text("http://speedy.sh/revYz/output.jpg")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272603")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("I ran your code in Maple and got the same answer as you did. Then I added the symbol * in the definition of F after the c7, reran the code, and got my answer. It is amazing how picky these computing platforms can be!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272618")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("Ah, so that was it! (Actually, it would have been better if Maple was _more_ picky, and complained on the lack of *, rather than silently deciding to treat constants as functions (which I suppose is a useful convention elsewhere…).) Anyway, good catch – I had scanned over the code several times and didn’t pick it up.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272554")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Aubrey: that comment of mine was for the exact computation of ")#mi("M_{k, \\epsilon}^{1D}")#text(" – a (1D) modification for ")#mi("M_{k, \\epsilon}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272556")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Ah, excellent – thanks – I didn’t realise it was for d=1. I get 2.0055 as the best M for k=4 and d=1 (the epsilon being 0.16841). Does the fact that your value of 2.01869 is slightly bigger imply that there is still some unexplored space here? – for example, scope to increase M using partitioning, or non-polynomials? (0.003 isn’t much, but I guess there might be a greater disparity for larger k and/or d.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272557")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("This M-value modification is for optimizing ")#mi("F(t_1,...,t_k)")#text(" of the particular (1D) type: ")#mi("F = f(\\sum_i t_i)")#text(", where ")#mi("f")#text(" is a function of one variable. Therefore this M-value is smaller than the usual (with more general F) ")#mi("M_{k, \\epsilon}")#text(".")

#text("The optimal ")#mi("f")#text(" is not a polynomial (so the degree d is meaningless here!)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272547")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Some comments on trying to implement the Polymath8a stuff. For simplicity I’ll only work with the ")#mi("MPZ[\\varpi,\\delta]")#text(" estimates and not the more complicated ")#mi("MPZ^{(i)}[\\varpi,\\delta]")#text(" estimates. I’ll also avoid any use of the Dickman function, which in principle can be used to claw back a lot of the losses from the truncation to smooth moduli, but looks very complicated to analyse and implement.")

#text("Let A denote the region of integration for the J functional, and B the support of the F marginal ")#mi("\\int F\\ dt_k")#text(". Right now we are taking ")#mi("A = (1-\\varepsilon) \\cdot {\\cal R}_{k-1}")#text(" and ")#mi("B = (1+\\varepsilon) \\cdot {\\cal R}_{k-1}")#text(". The key relation between these two sets is that whenever ")#mi("(a_1,\\dots,a_{k-1}) \\in A")#text(" and ")#mi("(b_1,\\dots,b_{k-1}) \\in B")#text(", we have")

#mi("a_1+\\dots+a_{k-1}+b_1+\\dots+b_{k-1} \\leq 2")#text(" (*)")

#text("which roughly speaking means that we can use the Bombieri-Vinogradov theorem to control interactions between A and B.")

#text("If we use ")#mi("MPZ[\\varpi,\\delta]")#text(" instead of Bombieri-Vinogradov for some fixed choice of ")#mi("\\varpi,\\delta")#text(", we get to replace this condition (*) with the conjunction of")

#mi("a_1+\\dots+a_{k-1}+b_1+\\dots+b_{k-1} \\leq 2 (1+4\\varpi)")#text(" (**)")#linebreak()#text(" and")

#mi("a_1,\\dots,a_{k-1},b_1,\\dots,b_{k-1} \\leq 4\\delta.")#text(" (***)")

#text("The condition (**) is more generous than (*), but the price one pays for this is the new restriction (***).")

#text("By the way, it would be OK if for some choices of ")#mi("(a_1,\\dots,a_{k-1}) \\in A")#text(" and ")#mi("(b_1,\\dots,b_{k-1}) \\in B")#text(", we had (*), whilst for other choices one had (**) and (***), and one could also have ")#mi("\\varpi,\\delta")#text(" vary with the a and b’s. But for simplicity I’ll stick with a single choice of ")#mi("\\varpi,\\delta")#text(" and just use (**) and (***) for that choice. Then one natural choice for the polytopes A,B would be")

#mi("A = \\{ (a_1,\\dots,a_{k-1}: a_1+\\dots+a_{k-1} \\leq (1-\\varepsilon)(1+4\\varpi);")#linebreak()#text(" ")#mi("a_1,\\dots,a_{k-1} \\leq 4\\delta \\}")

#mi("B = \\{ (b_1,\\dots, b_{k-1}): b_1+\\dots+b_{k-1} \\leq (1+\\varepsilon) (1+4\\varpi);")#linebreak()#text(" ")#mi("b_1,\\dots,b_{k-1} \\leq 4\\delta \\}")

#text("so one could try to maximise the ratio J/I for functions F supported on ")#mi("\\{ (t_1,\\dots,t_k): t_1+\\dots+t_k \\leq (1+\\varepsilon)(1+4\\varpi); t_1,\\dots,t_k \\leq 4\\delta\\}")#text(", with the J integration being on A.")

#text("Our most optimistic numerology for ")#mi("\\varpi,\\delta")#text(" currently is roughly ")#mi("83 \\varpi + 25 \\delta < 1")#text(", so if we split the difference we could take for instance ")#mi("\\varpi \\approx 1/166, \\delta \\approx 1/50")#text(". The enlarging of the simplex by ")#mi("1+4\\varpi \\approx 1.02")#text(" is in principle equivalent to lowering the threshold for ")#mi("M_k")#text(" from 4 to about 3.92, which would in principle reduce k by about 5. But we have to truncate all the coefficients ")#mi("t_i")#text(" to ")#mi("4\\delta \\approx 4/k")#text(", which looks like a pretty serious truncation. If ")#mi("t_1,\\dots,t_k")#text(" are chosen uniformly on the simplex, then each ")#mi("t_i")#text(" behaves roughly like an exponential random variable of mean ")#mi("1/k")#text(", so that it hits ")#mi("4/k")#text(" pretty often. I’m not exactly sure how things change when one weights by F^2, but from the large k analysis it looks like each of the ")#mi("t_i")#text(" behave like Cauchy random variables of mean about 1/k, so asking for all k of these variables to stay below ")#mi("4/k")#text(" looks like quite a big ask. So this suggests that the “naive” strategy of taking an optimiser for the untruncated problem and simply lopping off the regions where ")#mi("t_1,\\dots,t_k \\geq 4\\delta")#text(" may give poor results. (But this doesn’t preclude a direct optimisation of the truncation problem giving better results than what we currently have, although we are still faced with the difficult problem of computing the relevant integrals such as ")#mi("\\int b_j b_k")#text(" properly.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272572")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Note that if we restrict all variables to be less than ")#mi("c/k")#text(" and drop all other restrictions, the optimal function is just a constant (by Cauchy-Schwarz), which then gives a ratio of ")#mi("c")#text(". So the ")#mi("c=4")#text(" case from above will certainly be too restrictive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272577")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2014")])]

#text("Good point! We have the room to double ")#mi("\\delta")#text(", but this gives up all the gain in ")#mi("\\varpi")#text(". So it may well be that k is now too small for the Polymath8a estimates to be of much use.")

#text("In principle we can be much less drastic than forcing all of the ")#mi("t_k")#text(" to be bounded by ")#mi("4\\delta")#text("; it should be enough that most of them are bounded by this, as long as the exceptional ones are not too huge (here we would need the more refined ")#mi("MPZ^{(i)}")#text(" estimates that only require dense divisibility on the moduli). Then there is also the Dickman function card to play, since a significant fraction of those numbers above ")#mi("x^\\delta")#text(" would still be ")#mi("x^\\delta")#text("-smooth. This all looks rather complicated though (and may not play well with the epsilon trick, which is currently giving almost all of our recent improvements).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272647")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("I’ve been exploring variations on Pace’s initially-accidental restriction of monomial signatures to those in which all elements are even, and I can report substantial progress (although the pattern of which values give the best trade-off between execution time and M remains thoroughly mysterious).")

#text("I’ve been using k=20 as a benchmark. The bottom line is that it’s essential to include 2 in signatures in order to keep M competitive, but thereafter we can be quite sparse with not much loss in M. A fairly thorough survey using d=6, 10, 12 and 14 reveals that, relative to using all even numbers, particularly good performance arises from restricting signature entries to just the values 2, 6 and 10 – it loses only about 0.02 in M (which equates to about one increment of k at present), and it improves execution time by a factor of 4 for d=10, 7 for d=12 and 13 for d=14. I don’t have a feel for what are the ideal subsequent numbers to allow in signatures (presumably some will be needed to maintain an acceptable shortfall in M as k rises), but 4n+2 should be pretty good.")

#text("I don’t know whether these speed gains will still be so big after the new code enhancements (especially the second lookup table), and I also don’t know what the RAM implications are, but I’d hope this will still help quite a bit in progressing us to the goal of computing M for d=k for k in the 40-50 range. (Simplistically it would seem to get us to computability of d=40 on its own, but let’s see!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb18e5cf0ac164150a9d90a92dc13b6799488792ae084d95d84036149c338ace-4c45049caad09fbd4cc808c429fb61406e59bf9d786c8cfe50e39ab3bab7d9f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272652")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("“us”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272659")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2014")])]

#text("Update: it seems that adding back 8 as an admissible member of signatures makes more and more difference to M as k rises, and with only modest impact on execution time. It may be that for k in the region of current interest most of the benefit in execution time from these restrictions on signatures (over and above just restricting to even numbers) arises just from deleting 4 from the list of allowed values, i.e. from using 2, 6, 8, 10, 12 etc. Deleting both 4 and 6 costs too much in M for d up to 16, but is probably the next thing to look at for d in the 20s (which is beyond my puny MacBook’s ability to explore using the currently-available code).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2b057ba494f674faf85d4735b6d3ce2954102ac82c57119e789cbd60ac0bfd5-7328fd6a4580b68310e420c51f4c6ed6448b6cbca1ef763db641040b996c13ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272695")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("Is there a central repository with up to date code/notebooks? On the wiki there are some notes by Pace Nielsen, but all the other code is rather outdated. I can imagine that a github repository, or maybe just a dropbox directory could really help. Currently there are some snippets of code in the comments, but I have a hard time finding the most current versions…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272709")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("The repository being used at present is ")#link("https://www.dropbox.com/home/Polymath8/Polymath8b")[#text("https://www.dropbox.com/home/Polymath8/Polymath8b")]#text(" . The code from Pace that was deposited there on Feb 19th doesn’t have the latest ideas (precomputing a second lookup table for the J matrix, restricting the values allowed in signatures) but otherwise I think it has everything that has been discussed here concerning the unconditional (i.e. theta=1/2) setting).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2b057ba494f674faf85d4735b6d3ce2954102ac82c57119e789cbd60ac0bfd5-7328fd6a4580b68310e420c51f4c6ed6448b6cbca1ef763db641040b996c13ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272711")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("Is it possible that the link you provided is not public? Even with a dropbox account I cannot access it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272712")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("Ah – I’m not sure, since I only accessed it after receiving an “invitation” email from Terry. I’m sure Terry will advise.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272723")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#text("I’m rather sure that Terry needs to invite Johan Commelin before he can get access to the folder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dbb99b0e91087ac3c4fd57302fbd1510a44fa7d02373b8b38faa99bd5e2df26-2193e83c266e7bd41d0a4f50ad4fa234e5c17f18cc749edf33abb221e4ed6b6b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eckhard")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272726")[#strong[#text("Eckhard")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2014")])]

#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/raL055WXr5/Polymath8b")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/raL055WXr5/Polymath8b")]#text(" is the correct dropbox link, I believe.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272823")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2014")])]

#text("James – concerning your summary in ")#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272402")[#text("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-272402")]#text(" of the situation regarding functions with larger support than R_k,epsilon but with vanishing marginals, I am wondering about two ideas raised in posts from December:")

#text("1) In ")#link("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256158")[#text("https://terrytao.wordpress.com/2013/12/08/polymath8b-iii-numerical-optimisation-of-the-variational-problem-and-a-search-for-new-sieves/#comment-256158")]#text(" Pace proposed (based on something he credited to you) a relatively simple way to dissect R’_k that seems not to involve any marginals (but does it work for R’_k,epsilon?);")

#text("2) In ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258264")]#text(" Terry proposed (and Pace refined in ")#link("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")[#text("https://terrytao.wordpress.com/2013/12/20/polymath8b-iv-enlarging-the-sieve-support-more-efficient-numerics-and-explicit-asymptotics/#comment-258471")]#text(") a method for satisfying marginals automatically on 2R_k.")

#text("Do either of these lines of thought lead to a more optimistic prognosis for going beyond R_k,epsilon, at least for large k and d? (I ask especially because the past day’s exploration has sharply reducied my earlier optimism concerning improvements to the trick of only allowing even numbers in monomials.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6525d7cd9db10f0f8b9a18fa0e62f21ac78916ee3eed4debea5956daeaf030-72219f07d23f0f1bc893af77a76e1cfd99cff0d2c3626a52796f2e15ac6c7e88.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of interested non-expert")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273021")[#strong[#text("interested non-expert")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2014")])]

#text("Hello!")#linebreak()#text(" In this weeks issue of Nature journal, there is a small text about scientific crowd-sourcing. Among others, about this polymath project")#linebreak()#text(" ")#link("http://www.nature.com/news/parallel-lines-1.14759?WT.ec_id=NATURE-20140227")[#text("http://www.nature.com/news/parallel-lines-1.14759?WT.ec_id=NATURE-20140227")]

#text(":)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/396cbddb8a092f3ce3c7214ce4e7c870bf1cd06db6220390117e931041ee7da4-3315f3bb037df5551ba625bcb58ebb5df2afae3379fa877574878002f7e84ac5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous visitor")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273317")[#strong[#text("Anonymous visitor")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2014")])]

#text("As a visitor who knows very little about this, I wonder if there is some form to the functions F that satisfy condition 1 particularly well. I mean, can one construct such a function to be ideal? And I wonder about the constant 4, what is the maximum such constant for each k (assuming equality is included)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273429")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2014")])]

#text("This is a great question. For large k (setting epsilon to zero for simplicity), it appears that functions F that are roughly of the form ")#mi("F(t_1,\\dots,t_k) := \\prod_{i=1}^k \\frac{1}{1+At_i}")#text(" for a well-chosen parameter A works quite well, though it is not quite the optimal function. For k=2, which is the only case in which we have found the exact optimiser, the optimal function F (when epsilon is zero) is the rather strange function")

#mi("F(t_1,t_2) = \\frac{1}{M_2-1+t_1} + \\frac{1}{M_2-1+t_2} + \\frac{1}{2M_2-1} \\log \\frac{M_2-t_1}{M_2-1+t_1} \\frac{M_2-t_2}{M_2-1+t_2},")

#text("where ")#mi("M_2 = 1/(1-W(1/e)) = 1.38593...")#text(". This unfortunately does not give many clues as to what the general structure of the optimiser is like.")

#text("We’ve used ")#mi("M_k")#text(" to denote the optimal value of the constant in place of 4 (at least in the simpler case ")#mi("\\varepsilon=0")#text("). The best lower and upper numerical bounds on this quantity that we have can be found at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#World_records")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem#World_records")]#text(" . Asymptotically we know that ")#mi("M_k= \\log k + O(1)")#text(", so we can exceed 4 for k large enough; the challenge is to exceed 4 for explicit values of k such as 50.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273320")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2014")])]

#text("Just on grounds of mathematical naturalness alone, it seems to me that")#linebreak()#text(" you might want to consider putting in nonpolynomial factors of")#linebreak()#text(" exp(A*(x1+x2+…+xk))")#linebreak()#text(" into the ansatz definition for F, for various constants A.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273431")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2014")])]

#text("I played around with this some time ago. When working with functions ")#mi("F(t_1,\\dots,t_k)")#text(" that is homogeneous of degree d, thus ")#mi("F(\\lambda t_1,\\dots,\\lambda t_k) = \\lambda^d F(t_1,\\dots,t_k)")#text(" for all ")#mi("\\lambda>0")#text(", then there is a clean relationship between integration on the solid simplex, the boundary, and against exponential weights: we have")

#mi("\\int_{t_1,\\dots,t_k \\geq 0} e^{-a(t_1+\\dots+t_k)} F(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k")#linebreak()#text(" ")#mi("= a^{-d-k} \\Gamma(d+k) \\int_{t_1+\\dots+t_k=1} F(t_1,\\dots,t_k)\\ dt_1 \\dots dt_{k-1}")#linebreak()#text(" ")#mi("= a^{-d-k} \\Gamma(d+k+1) \\int_{t_1+\\dots+t_k \\leq 1} F(t_1,\\dots,t_k)\\ dt_1 \\dots dt_k")

#text("which was useful for us in integrating monomial functions on the simplex. Unfortunately, when F is not homogeneous, then the relationship is much messier and we have not been able to exploit it. If one adds in weights such as ")#mi("\\exp(A(t_1+\\dots+t_k))")#text(", then one begins to see the incomplete Gamma function appear in the formulae, and this does not look very appealing (especially since our current optimisation methods rely on writing all the coefficients as exact rationals).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2014")])]

#text("@TT: What’s going on in the last line of your comment? :)")

#emph[#text("[Deleted, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273476")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2014")])]

#text("It seems odd that a post such as this received so many downvotes, when the blog host has advised that downvoting be used sparingly. (Posted in the possibly-vain hope that this will be taken as food for thought rather than as fodder for debate:-)")

#emph[#text("[This was possibly related to a further comment on this post which has since been deleted. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D Smith")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273323")[#strong[#text("Warren D Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2014")])]

#text("Or, if you could reformulate the problem somehow to change the region of integration from being x1>0, x2>0, …, xk>0, x1+x2+…+xk< 1; x1> 0, x2>0, …, xk>0, but now with the weighting function exp(-x1-x2-…-xk), then that would be more natural. I’m saying this out of total ignorance of where this comes from, but just because it is a common experience that you get nicer results in problems of this sort if you can do this.")

#text("Another more-elegant region of integration (if it can be done) is")#linebreak()#text(" the REGULAR simplex x1>0, x2>0, …, xk>0")#linebreak()#text(" with x1+x2+…+xk=1 (this is 1-less dimensional).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273757")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2014")])]

#text("A podcast discussing bounded gaps between primes and Polymath8: ")#link("http://podacademy.org/podcasts/maths-isnt-standing-still/")[#text("http://podacademy.org/podcasts/maths-isnt-standing-still/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3dd15e1312ea4cfe3d78db7a1972df6398ccd2055d0f4cd02c036849c1960e2-e962c218f388ad97cbf0736a1b5f4f177f871dfa20ed585bf86b8b5e99f3ae5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luoyu4304")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273930")[#strong[#text("luoyu4304")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Professor Tao, I am an amateur in number theory. I’ve been paying attention to this project for a couple of month. When I heard the big news of Zhang’s breakthrough in the twin prime conjecture, I began to search for more information about Zhang and the conjecture. At first, I tried to read Zhang’s paper, but soon I found it too difficult for me. Then I learned elementary number theory and a little analysis number theory by myself, and read the paper again. This time I can only understand no more than ten pages of the paper, it is still so difficult for me. So I was just want to quit and back to my study. And later I noticed this project by accident, I was shocked by the names of the members of this project. So I bagan to read your blogs, I’ve learned a lot and understood more details of zhang’s paper during this period. And then I know that James maynard have got the amazing H1of 600 and 12(under EH). Inspired by this news, I decided to read james’ paper. This time, I can understand most of his paper except for some complicated calculations. And I noticed that most members of the project are focusing on improving the value of Mk and other vertions of Mk’……Unfortunately, I’ve never used the mathematics and maple , I even donnot have a maple installed in my notebook. And I doubt the possibility of getting the most promising result（2）only by improving the value of Mk. Why not try to improve the “lambda function”（in james’ paper）and build a new Mk instead? Maybe I was asking a boring question, I just want to know more……")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("It looks like the choice ")#mi("\\lambda_{d_1,\\dots,d_k} = \\mu(d_1 \\dots d_k) F(\\frac{\\log d_1}{\\log R},\\dots,\\frac{\\log d_k}{\\log R})")#text(" that we use (this is slightly different from the choice in Maynard’s paper, but the differences are negligible for the purposes of computing ")#mi("M_k")#text(" quantities) is basically optimal for Selberg-type sieves (in which ")#mi("\\nu")#text(" is the square of a divisor sum), with the only remaining task being to optimise in F. For instance, it looks like the upper bounds we have for ")#mi("M_k")#text(" using our current choices of ")#mi("\\lambda")#text(" are also present for other choices too (see this comment ")#link("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253118")[#text("https://terrytao.wordpress.com/2013/11/22/polymath8b-ii-optimising-the-variational-problem-and-the-sieve/#comment-253118")]#text(" for details).")

#text("It’s conceivable that non-Selberg sieves could also give good results, but we tried for quite a while to search for these, and thus far it appears that such sieves (while they exist) are not superior to the Selberg sieve (which appears to be some sort of “local optimum” for these sorts of problems).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3dd15e1312ea4cfe3d78db7a1972df6398ccd2055d0f4cd02c036849c1960e2-e962c218f388ad97cbf0736a1b5f4f177f871dfa20ed585bf86b8b5e99f3ae5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luoyu4304")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274051")[#strong[#text("luoyu4304")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("You mean that the lambda function we are using are the best for selberg seive method? And the remaining task is finding an optimal F . I think I’ve got it. Many thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/775b164a9fb4ce525531203b392d21f78c3e5fd2c13250dd11a801e48b387ca7-ec3592175e5a9ed760cf0c07a519f84fd8d53989a9765024062737440910c6af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273967")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Hello! I have only been (quietly) following this blog for the last two months. My normal research has got nothing to do with number theory, but rather with solving large linear systems, usually by means of Krylov subspace methods. Since this and previous posts have made the link between quadratic forms and bounded gaps between primes, I have gotten interested in applying Krylov subspaces for the problem of computing M_k. (I know that other regions than the unit simplex allow better values for k to be found, but I wanted to start with a relatively doable problem.)")

#text("I have tried a different (and hopefully interesting) way to compute M_k, based on associating a linear operator with the relevant quadratic form. A description of the approach (KrylovMk.pdf) and accompanying Maple files with the calculations can be found at the following location:")

#link("http://users.ugent.be/~ibogaert/KrylovMk/")[#text("http://users.ugent.be/~ibogaert/KrylovMk/")]

#text("At the least, it confirms Pace’s result that M_{54} > 4 and improves many of the lower bounds listed on ")#link("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Selberg_sieve_variational_problem")]#text(". Hopefully, it also contains some ideas that are useful for the other regions M_{k,\\varepsilon}…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Thanks very much for this (and for confirming and improving previous numerical lower bounds for ")#mi("M_k")#text(")! We had considered the power method a long time ago (see e.g. ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252133")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/#comment-252133")]#text(" ) but never tried implementing it, and the additional trick of combining the power method with the quadratic program method by taking linear combinations of powers ")#mi("{\\cal A}_k^i 1")#text(" (which we would call ")#mi("{\\cal L}^i 1")#text(" in our notation) is a clever one. It’s interesting though that the memory and CPU costs seem to be roughly comparable with our existing methods; if I understand your notes, you are computing the coefficients ")#mi("\\langle 1, {\\cal A}_k^i 1 \\rangle")#text(" for degrees i up to 51 or so to create ")#mi("25 \\times 25")#text(" Hankel matrices ")#mi("(\\langle 1, {\\cal A}_k^{i+j} 1 \\rangle)_{1 \\leq i,j \\leq r}")#text(" and ")#mi("(\\langle 1, {\\cal A}_k^{i+j+1} 1 \\rangle)_{1 \\leq i,j \\leq r}")#text(" to perform quadratic optimisation over, so you have much smaller matrices than we do with our existing method, but the time and memory needed to compute the coefficients looks to be much larger.")

#text("Do you have any sense as to the relationship between degree (I guess you call this parameter r) and accuracy? If the bounds for low r are already reasonably good, then there is a good chance that we could use this technique for truncated simplices, opening up the possibility of actually using the Polymath8a results. But we may have to work with very small values of r, as we’re going to get piecewise polynomials showing up pretty quickly. Similarly if we try to attack the ")#mi("M_{k,\\varepsilon}")#text(" problem this way; the analogue of the ")#mi("{\\cal A}")#text(" operator in this case is")

#mi("{\\cal L}_{k,\\varepsilon} F(t_1,\\dots,t_k) := \\sum_{i=1}^k 1_{t_1+\\dots+t_{i-1}+t_{i+1}+\\dots+t_k \\leq 1-\\varepsilon}")#linebreak()#text(" ")#mi("\\int_0^{1+\\varepsilon-t_1-\\dots-t_{i-1}-t_{i+1}-\\dots-t_k} F(t_1,\\dots,t_{i-1},t^{\\prime}_i,t_{i+1},\\dots,t_k)\\ dt^{\\prime}_i")

#text("which generates piecewise polynomials rather quickly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274016")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("This confirmation (by the power method) of ")#mi("k=54")#text(" should be added to the timeline page.")

#emph[#text("[Done – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273981")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Nice work! (It seems that the “")#mi("\\epsilon")#text(" – trick” is really necessary to reduce ")#mi("k")#text(" below 54.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273998")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Ignace, this looks very promising. Hopefully the methods can be adapted to the ")#mi("\\varepsilon")#text(" setting, and make all of my computations obsolete!")

#text("———————-")

#text("I thought I’d also give an update on the computations I’ve been doing. I still haven’t found time to try to optimize the symmetric polynomial multiplier, or make a second look-up set, so I’ve just been running the existing code as is. I found that the optimal epsilon in the ")#mi("k=51")#text(" case was ")#mi("1/28")#text(" (using the limited set of polynomials I’ve used previously–with only signatures with even entries).")

#text("I then raised the power on ")#mi("(1-e_1)")#text(" by 2, which made the 1280×1280 matrices grow to size 1614×1614. The new computation uses 14 GB of RAM (on a 64 GB machine), almost all of which is simply storing the entries of the two matrices. (The generalized eigenvalue part used maybe 1-2GB is all.) The matrix formation takes 62 hours, while the generalized eigenvalue part takes about 8 hours. Taking ")#mi("\\varepsilon=1/25")#text(" I get ")#mi("M_{50,1/25}\\geq 3.9971")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273999")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Ooops, the 1/28 optimal epsilon was for the k=50 case (with the 1280×1280 matrices), in which case I get 3.995…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/775b164a9fb4ce525531203b392d21f78c3e5fd2c13250dd11a801e48b387ca7-ec3592175e5a9ed760cf0c07a519f84fd8d53989a9765024062737440910c6af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ignace Bogaert")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274090")[#strong[#text("Ignace Bogaert")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("Thanks for all the feedback!")

#text("@Terence: Indeed, the computation of the matrix entries is the real bottleneck in this approach. The r = 25 case was the furthest that I could push the code (the computation for the last matrix entry took about a day and used 30GB), and it just barely managed to get \\sigma_k larger than 4 at k = 54.")

#text("With regard to the convergence rate: it decreases substantially for higher k. Convergence is more or less exponential in r (in the 2D case, this can be expected because of the eigenfunction’s singularities that surround the simplex). Hence, I have approximated the convergence as \\sigma_k = M_k – C exp(-Lambda * r). Using some (very approximate) finite differences, I get the following values for Lambda (for various values of k):")

#text("k, Lambda")#linebreak()#text(" 2, 2.34")#linebreak()#text(" 7, 0.92")#linebreak()#text(" 12, 0.66")#linebreak()#text(" 17, 0.52")#linebreak()#text(" 22, 0.44")#linebreak()#text(" 27, 0.39")#linebreak()#text(" 32, 0.35")#linebreak()#text(" 37, 0.30")#linebreak()#text(" 42, 0.25")#linebreak()#text(" 47, 0.22")#linebreak()#text(" 52, 0.20")#linebreak()#text(" 57, 0.17")

#text("Therefore, a small r will most likely not be good enough. Also, the piecewise polynomials might mess with the convergence rate.")

#text("@Pace: I was hoping to extend this method to the \\varepsilon setting, but the point Terence made about the piecewise polynomials appears troubling indeed. I’ll give it some further thought, but it seems your computations may be the only viable ones for this problem…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274116")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("Since any polynomial basis can be used to approximate")#linebreak()#text(" ")#mi("M_{k, \\epsilon}")#text(", your current (quite efficient) polynomial basis")#linebreak()#text(" ")#mi("\\mathcal  A_k^i 1")#text(" (used to approximate ")#mi("M_k")#text(") can still be used to approximate ")#mi("M_{k, \\epsilon}")#text(" (replacing the less efficient polynomial basis currently used by Pace).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274130")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2014")])]

#text("Might it be possible to adapt Ignace’s new method to the epsilon setting by using the “cheap scaling trick” that Terry mentioned in January (")#link("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")[#text("https://terrytao.wordpress.com/2014/01/08/polymath8b-v-stretching-the-sieve-support-further/#comment-263500")]#text(")? Would this not avoid the need to use the complicated analogue of A that Terry gave above?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273973")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Terry: I just noticed that you have added my Feb 22 value of 2.062926693 for M_4,epsilon to the world records table. Since this was with d=k and k even, it potentially falls foul of the issue that Pace pointed out in which there is one signature whose length exceeds k. Even though I was unable to confirm that excluding that signature reduces M_k in the case d=k=10, the question must be viewed as unresolved, so I think for now it is better to enter the value 2.05411, which is what I get for k=4, d=3 and epsilon optimised to 0.2294921875.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274877")[#strong[#text("Aubrey")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2014")])]

#text("FWIW I guess that same value should be entered for Mhat_4,epsilon,1. Also a typo has occurred in copying Mhat_2,epsilon,1 to M_2,epsilon,1/2 – it should be 1.69… not 1.68…")

#emph[#text("[Updated, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-273994")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2014")])]

#text("Is it possible to derive lower bounds on ")#mi("M_{k, \\epsilon}")#text(" from its upper bound (as done for ")#mi("M_k")#text(")?")#linebreak()#text(" Such upper bounds may be used to improve the current numerical bounds on ")#mi("H_m")#text(" for ")#mi("m = 2, 3, ...")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274827")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2014")])]

#text("It seems that the conjectural ")#mi("H_m")#text(" in the main page refers simply to ")#mi("H(m)")#text(" – defined as the smallest width for admissible m-tuples (if so, perhaps this should be explicitly stated there).")#linebreak()#text(" Is it true that ")#mi("H(m) \\leq H_m")#text(" unconditionally? (If so, than the conjecture ")#mi("H_m = H(m)")#text(" is best possible!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2014")])]

#text("More precisely, ")#mi("H(m+1) \\leq H_m")#text(" unconditionally, because any interval that does not contain any admissible m+1-tuple, cannot contain m+1 primes if shifted sufficiently far to the right. For instance, ")#mi("H_2")#text(" cannot be less than 6, since no interval ")#mi("[n,n+5]")#text(" can contain 3 primes once ")#mi("n > 3")#text(" (such a triplet would then be an admissible 3-tuple).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-274890")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2014")])]

#text("Thanks! (this shows that admissible tuples are closely related to ")#mi("H_m")#text(" – not merely limited to a particular technique for obtaining upper bounds for ")#mi("H_m")#text(").")#linebreak()#text(" So perhaps the (best possible) conjecture should be ")#mi("H_m = H(m+1)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-275069")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2014")])]

#text("Yes, the conjecture ")#mi("H_m=H(m+1)")#text(" follows from the Dickson-Hardy-Littlewood conjectures. That is why we use the notation DHL(k,m). Sorry if I missed something, I am fighting some nasty illness at the moment.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-275554")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("I have a possible thought on how to use the Krylov subspace machinery that Ignace introduced to this problem for the modified problems ")#mi("M^{\\prime}_{k,\\varepsilon}")#text(", etc. Basically, the idea is to replace the initial function F=1 by something that we already suspect to be close to the optimiser, namely a function of the form ")#mi("F(t_1,\\dots,t_k) = \\prod_{i=1}^k \\frac{1}{1+At_i}")#text(". It looks like the first few inner products ")#mi("\\langle F, {\\mathcal L}^i F \\rangle")#text(" could be computable for small i (e.g. i=1,2,3); these experssions seem to be expressible as low-dimensional integrals where one factor in the integrand is something like a ")#mi("k-O(1)")#text("-fold convolution of ")#mi("\\frac{1}{(1+At)^2}")#text(", but one may be able to compute these convolutions using Fourier analysis or Laplace transforms. The hope is that by selecting an initial F that is already pretty good, we won’t need to work with really large values of r. I have to run now, but I’ll try to flesh out this idea more in a little bit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-275676")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2014")])]

#text("OK, here are a few more details. I’ll work on functions F supported on the orthant ")#mi("\\{ t_1,\\dots,t_k \\geq 0 \\}")#text(", restricting to simplices as necessary. Let’s first work with ")#mi("M_k")#text(" for simplicity. We have an operator ")#mi("{\\cal L} = {\\cal L}_1+\\dots+{\\cal L}_k")#text(", where")

#mi("\\displaystyle {\\cal L}_k F(t_1,\\dots,t_k) = 1_{t_1+\\dots+t_k \\leq 1} \\int_0^\\infty 1_{t_1+\\dots+t_{k-1}+s_k \\leq 1}")#linebreak()#text(" ")#mi("\\displaystyle F(t_1,\\dots,t_{k-1},s_k)\\ ds_k")

#text("and similarly for permutations. Thus for instance")

#mi("\\displaystyle \\langle F, {\\cal L}_k F \\rangle = \\int_{t_1+\\dots+t_k, t_1+\\dots+t_{k-1}+s_k \\leq 1}")#linebreak()#text(" ")#mi("\\displaystyle F(t_1,\\dots,t_k) F(t_1,\\dots,t_{k-1},s_k)\\ dt_1 \\dots dt_k ds_k")

#mi("\\displaystyle \\langle F, {\\cal L}_{k-1} {\\cal L}_k F \\rangle = \\int_{t_1+\\dots+t_k, t_1+\\dots+t_{k-1}+s_k,t_1+\\dots+t_{k-2}+s_{k-1}+s_k \\leq 1}")#linebreak()#text(" ")#mi("\\displaystyle F(t_1,\\dots,t_k) F(t_1,\\dots,t_{k-2},s_{k-1},s_k)\\ dt_1 \\dots dt_k ds_{k-1} ds_k")

#mi("\\displaystyle \\langle F, {\\cal L}_k^2 F \\rangle = \\int_{t_1+\\dots+t_k, t_1+\\dots+t_{k-1}+s_k,t_1+\\dots+t_{k-1}+u_k \\leq 1}")#linebreak()#text(" ")#mi("\\displaystyle F(t_1,\\dots,t_k) F(t_1,\\dots,t_{k-1},u_k)\\ dt_1 \\dots dt_k ds_k du_k")

#text("and so forth. If F is symmetric, we also have")

#mi("\\displaystyle \\langle F, {\\cal L} F \\rangle= k \\langle F, {\\cal L}_k F \\rangle")

#mi("\\langle F, {\\cal L}^2 F \\rangle= k \\langle F, {\\cal L}_k^2 F \\rangle + k(k-1) \\langle F, {\\cal L}_k {\\cal L}_{k-1} F \\rangle")

#text("and so forth. If F takes the tensor product form")

#mi("\\displaystyle F(t_1,\\dots,t_k) = g(t_1) \\dots g(t_k)")

#text("then we have")

#mi("\\displaystyle \\langle F, F \\rangle = \\int_0^1 (g^2)^{*k}(T)\\ dT")

#mi("\\displaystyle \\langle F, {\\cal L} F \\rangle = k \\int_{T+t_k, T+s_k \\leq 1} (g^2)^{*k-1}(T) g(t_k) g(s_k)\\ dT dt_k ds_k")

#mi("\\displaystyle \\langle F, {\\cal L} F^2 \\rangle = k \\int_{T+t_k, T+s_k, T+u_k \\leq 1} (g^2)^{*k-1}(T) g(t_k) g(u_k)\\ dT dt_k ds_k")#linebreak()#text(" ")#mi("\\displaystyle + k(k-1) \\int_{T+t_{k-1}+t_k, T+t_{k-1}+s_k, T+s_{k-1}+s_k \\leq 1}")#linebreak()#text(" ")#mi("(g^2)^{*k-2}(T) g(t_{k-1}) g(t_k) g(s_{k-1}) g(s_k)\\ dT dt_{k-1} dt_k ds_{k-1} ds_k")

#text("and so forth, where ")#mi("(g^2)^{*k}")#text(" is the ")#mi("k")#text("-fold convolution of ")#mi("g^2")#text(". This can be computed via Laplace or Fourier transforms.")

#text("For ")#mi("M^{\\prime}_{k,\\varepsilon}")#text(", the situation is similar, with ")#mi("{\\cal L}_k")#text(" replaced by")

#mi("\\displaystyle {\\cal L}_{k,\\varepsilon} F(t_1,\\dots,t_k) = 1_{t_1+\\dots+t_k \\leq 1+\\varepsilon; t_1+\\dots+t_{k-1} \\leq 1-\\varepsilon}")#linebreak()#text(" ")#mi("\\displaystyle \\int_0^\\infty 1_{t_1+\\dots+t_{k-1}+s_k \\leq 1+\\varepsilon} F(t_1,\\dots,t_{k-1},s_k)\\ ds_k")

#text("with corresponding changes elsewhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-276283")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2014")])]

#text("I wrote a short program which converts products of elementary symmetric polynomials into a list of the corresponding signatures for monomial symmetric polynomials. The Mathematica file is available in dropbox. I have done a moderate amount of testing, but others may want to give it a double check to make sure it is working properly. The program is currently written to run on a single machine, but it could easily be rewritten to work on multiple computers independently.")

#text("There is one issue that makes me a little wary of this approach. While the computation now takes almost no RAM, it is incredibly slow. It would appear that this could be mitigated by distributing the computation, but the slowness (I believe) arises from the fact that expanding something like ")#mi("e_2^{15}")#text(" involves a large number of different signatures. So this will ultimately slow down the creation of the appropriate matrices as well. Thus, it appears that any time saved by having a nice basis (with respect to squaring) will be lost when finding the exact rational entries of the corresponding integrals. I will have to do more testing to see if I’m correct in this guess.")

#text("I should also mention something else I’ve run into lately, that could be another problem. Namely, the size of the rational fractions being used to create the entries of these matrices, in conjunction with the linear algebra step, can sometimes result in the creation of incredibly small real number approximations–small enough to give a warning in Mathematica. Thus, while our exact arithmetic step will still give us valid outputs, there begins to be the chance for inefficiency in the optimum eigenvector.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-277194")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2014")])]

#text("I have a pleasant (and somewhat embarrassing) surprise. After realizing that converting products of elementary symmetric polynomials to linear combinations of monomial symmetric polynomials was costly, I went back to my original program (which just multiplies monomial symmetric polynomials) to see if I couldn’t speed it up. I realized that the major slowdown in my program was that while computing the number of times a signature appears in a product I wasn’t using multinomials, but rather computing a giant permutation set and then looking at the size of the set. This was completely unnecessary.")

#text("So, I fixed that problem, and the multiplier function is now extremely fast and does not run into any RAM issues (for reasonably sized degrees). So, for instance, to build the look-up set for such products on a single machine it takes approximately 10 minutes for degree 18, 50 minutes for degree 20, and 5 hours for degree 22.")

#text("The program overall still takes a lot of RAM to run the generalized eigenvector routine. [It appears I was wrong when I had previously said it took little RAM for this step.] The program also takes a lot of time to build the matrices; although this can be parallelized. I’m going to be out of town this weekend, so I won’t be able to do much testing. I’ll probably upload the new program sometime in the next week or two after playing around with it some more. I expect we should be able to at least get down to k=50 or k=49 without doing any parallelization.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-279021")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2014")])]

#text("The following preprint can be added to the relevant wiki page (")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")]#text("): ")#link("http://arxiv.org/abs/1403.5808")[#text("http://arxiv.org/abs/1403.5808")]

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-279449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("Just out of curiosity: What is the status of the project? Has it finished at ")#mi("H_{1} = 252")#text(" or are there still things going on?")

#text("(Asked by an interested amateur who follows this blog.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-279651")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2014")])]

#text("My understanding of Pace Nielsen’s last comment (20 March, 2014 at 6:43 am) is that he and others are still improving the optimization algorithm so that hopefully ")#mi("H_1=246")#text(" or even ")#mi("H_1=240")#text(" can be achieved. Check out ")#link("http://math.mit.edu/~primegaps/")[#text("http://math.mit.edu/~primegaps/")]#text(" with ")#mi("k=50")#text(" and ")#mi("k=49")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5171b764ce7a8e13fa132e7f4fb9477d163649d1575c780b3040dde534ba5048-54d24503f984010cebdf04379486feed52c9ace696e12b7b912f21f6f6f4d03b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Another interested amateur")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-280400")[#strong[#text("Another interested amateur")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2014")])]

#text("Is the rest of the reduction pretty much relying on computer code now?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-280838")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2014")])]

#text("Oh, by no means. The computations are essential, certainly, but in addition there are quite a few potential ways forward that would change what is being computed and would thereby reduce k and thence H. There have been occasional posts here that have summarised the current state of play in that regard; I think the most recent was by James Maynard on February 21st, which is the third post on this page. Also, of course there is always the possibility of new ideas that will allow further improvements – given the pace of progress over recent months, it would rather surprise me if nothing new comes up in the next month or two.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-283266")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("One more data point. I finished a computation I began before the latest fix to my code, so it doesn’t represent the best we can do (definitely using a substandard set of monomials), but it does give some information about the speed of the computation.")

#text("Using most (but not all) of the polynomials of the form ")#mi("e_1^a m(\\alpha)")#text(" where ")#mi("\\alpha")#text(" is a signature consisting of only even entries and total degree at most 22, and the total degree of the monomial is at most 29, we form matrices of size 2382 x 2382. The matrix formation step takes 8 days, and about 4 GB of ram. Solving for the eigenvector takes less than one day, but it turns out that 50 digit real approximations for the matrix entries is not enough to give accurate numerics! So taking 100 digit approximations, using ")#mi("\\varepsilon=1/27")#text(", the eigenvector step takes 2 days, and we get as output ")#mi("M\\geq 3.99767")#text(".")

#text("While I wasn’t around for some parts of the computation, it appears that the entire computation takes only about 4 GB of RAM, with most of it used to store the matrices.")

#text("I’ve uploaded the code (filename MonomialMultiplier05.nb) to dropbox to do the computation for a basis consisting of all symmetric polynomials of a given degree, but I’m going to continue playing around with the even signature case. Any data on the optimal epsilons for differing degrees and k=48 would be useful to me.")

#text("We may want to start writing up the paper, and then decide how much further we want to push these computations. I would guess that in a few weeks we should have k down to 50 or 49, but not get much more out of it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-283298")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("Thanks for this! What value of k is this for?")

#text("I’ve been distracted by other things recently, but I should be able to start on the writing process for this paper in a week or so (and also to work on the retrospective article, which has languished a bit).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-283356")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2014")])]

#text("Oops! k=50.")

#text("If you need me to write anything let me know.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-288286")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2014")])]

#text("In the paper to be written, it would be worthwhile to note that ")#mi("M_{50} < 4")#text(" by Terry's upper bound ")#mi("M_k \\leq \\frac{k}{k-1}\\log k")#text(", hence ")#mi("k=50")#text(" requires a larger support than the simplex ")#mi("{\\cal R}_k")#text(". This also shows that the current value ")#mi("k=51")#text(" is remarkably good.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-291412")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("Thanks for this! Incidentally I now have a bit of time to devote to writing up the paper, and have started doing so at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/")]#text(" (with the compiled PDF at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/newergap.pdf")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/uk2C-pj8Eu/Polymath8b/newergap.pdf")]#text(" ). Nowhere near done yet; For now I’m focusing mainly on the sieve-theoretic side of things, that reduces the task of bounding H_k to that of solving various variational problems. At some point I’ll turn to the asymptotic bounds for M_k at which point this remark would fit in very well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-291422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("Abstract: Shouldn’t it be “")#mi("H_1 \\leq 270")#text("” –> “")#mi("H_1 \\leq 252")#text("” and “")#mi("me^{(4-\\frac{28}{157})m}")#text("” –> “")#mi("me^{(4-\\frac{4}{43})m}")#text("” accroding to ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#Current_records")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#Current_records")]#text(" or am I missing something?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-291457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("Thanks for the correction. Regarding the current records page, there is an issue which I guess we should discuss: most of the results on the “Without EH” column are contingent on a certain distributional estimate on the primes (more precisely, ")#mi("MPZ[\\varpi,\\delta]")#text(" for ")#mi("1080 \\varpi + 330 \\delta < 13")#text(") which we believe to be true, but have not actually proven (there is a tricky algebraic geometry component that we have not yet looked at). I think the initial plan was to try to prove this estimate if it turned out that it led to the best bound on H_1. However the current bound of 252 in fact only uses Bombieri-Vinogradov, with the MPZ estimate only needed for the ")#mi("m \\geq 2")#text(" estimates, and so it may be simpler just to revert back to the slightly weaker MPZ estimates in Polymath8a (which hold for ")#mi("600 \\varpi + 180 \\delta < 7")#text(") as this will shorten the paper (but at the cost of worsening the ")#mi("m \\geq 2")#text(" estimates slightly. We would have to recalculate the numerology of course; but there is also some potential for improving the analysis of the ")#mi("m=2,3,4,5")#text(" cases by being more efficient in bounding ")#mi("M_k")#text(" (and maybe we could also try to use ")#mi("M_{k,\\varepsilon}")#text(" technology).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-291526")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("In theorem 1.3(v), ")#mi("m^3")#text(" should be ")#mi("m")#text(".")

#emph[#text("[That improved result is Theorem 1.4(xi); it uses a bound on M_k that is not present in Maynard’s paper. -T.]")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-291700")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")])]

#text("Thanks! (so theorem 1.3(v) should be considered as directly implied by Maynard’s paper.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-294496")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2014")])]

#text("I’ve been busy for the past few weeks, but I’m much freer now. I’m happy to help with the writing in whatever way is most useful; I’m happy to write a couple of sections myself, or to let others write a first draft and then to check through the details and language. What would you prefer?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-294848")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2014")])]

#text("Either would be very helpful :). I’ve written down most of the sieving stuff that reduces the task of proving DHL[k,j] to that of performing a variational problem, but it was surprisingly lengthy, particularly the bit where one uses GEH to go outside the simplex. There’s one more section on that part still to write, because I’ve only computed the asymptotics when the multidimensional cutoff is a finite linear combination of tensor products of smooth functions, and there is a slightly tricky approximation argument to replace this with the case of piecewise polynomial cutoffs (which is what we use in practice). I’ll try to finish that off in a few days and then you could have a look at those sections. Then there are the sections in which we actually try to solve the variational problem, which have not been started on yet.. for the 3D stuff I remember Pace had some nice writeup here with pictures, maybe if he could donate his source files to the Dropbox then we could merge them in somehow.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a4037b6d232593eab18df43e09180d73f95cc39ee5e1256aa043812a31decf3-bdca24206e8b2367cde53326730ce089ad7d930ed31b9301b8b3b612946b0ca3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-297718")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("OK, when you’ve finished the sieve argument I’ll try to go through it all thoroughly.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-284590")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2014")])]

#text("I think that Maynard’s lower bound ")#mi("M_k > \\log k-2\\log\\log k-2")#text(" is valid for all ")#mi("k")#text(". See my comment (with annoying parsing errors) under ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-296492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2014")])]

#text("I am a novice, my comments might be misplaced. How about an approach that goes like this.")

#text("1. there are infinitely many natural numbers. 1, 2, 3, ..")#linebreak()#text(" 2. each interval of N^2 and (N+1)^2 has at least one set of twin primes")

#text("Is there a way to prove this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-296555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2014")])]

#text("The second assertion is false for N=1")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7a76cd66a757d19d9f5af908aaed13cda328d2dc85fc45cb638835f8f0b2a-8f4cfbdf2ec7a89c9d4c76f0eb76619c0bc29a5ea4ff8cf298140822c00bc6f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andre")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-296706")[#strong[#text("Andre")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2014")])]

#link("http://oeis.org/A091592")[#text("http://oeis.org/A091592")]#text(" gives many counter examples")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-297456")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("We now have k=50. I’ve uploaded the file “DegreeOptimizer-2014-03-31.nb” to the dropbox. It contains the printout of the computations. Here are some details.")

#text("I took epsilon=1/25 (I have no idea if this is optimal, but I believe it is close–others are welcome to run the code with different epsilons to test this). My basis of polynomials was of the form ")#mi("e_1^a m(\\alpha)")#text(" where ")#mi("\\alpha")#text(" is an arbitrary signature with only even entries of degree at most 26, and the total degree of the monomials is at most 27. The corresponding matrices have size 2526×2526, and the matrix formation step took almost two weeks. The generalized eigenvector step took 2 days; and we get ")#mi("M\\geq 4.0043")#text(". If people are interested, I printed two arbitrary entries from the matrices, so this can serve as a double-check if people want to verify that those entries are correct.")

#text("I next plan to run a similar computation using signatures of degree at most 28.")

#text("————")

#text("On the newergap paper, I’ve uploaded to dropbox my source files for my write-up of the 3D computation. The main file is “BddGapsSize6.tex”, with the picture file “xyplot.pdf”. This version doesn’t contain some of the nice color graphics that an earlier write-up had, because I didn’t know at the time if we were going to simplify things further. (For instance, I believe that James showed we don’t have to break up the F-region any further.) However, I have uploaded the file “RegionPlots-BddGapsSize6.nb” which is the mathematica file that can be used to create 3D graphics. All you do is save the associated region plot as a pdf file, and then open up the pdf and re-save it in a condensed format (otherwise the graphic is too unwieldy). For brighter-better graphics, you can increase the plotpoint count. One can also remove the bounding box, the coordinates, etc… or add other information.")

#text("If this is too confusing, and there are specific graphics you would like me to make, I’m happy to do that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-297561")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("Nice work! (it is still possible that the optimal epsilon is much larger – due to the fact that the optimal ")#mi("F")#text(" should vanish on a certain inner simplex whose size increases with epsilon – making it difficult to approximate ")#mi("F")#text(" by a single polynomial over the whole simplex.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-297652")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("Great news! I’ve incorporated this new info on the wiki and will shortly do so on the paper as well, and will also start a new thread focused on writing the paper, and clearing up any further loose ends. I think hitting the nice round number of k=50 (and hence ")#mi("H_1 \\leq 246")#text(") is a nice place at which to “declare victory”; even though there may still be one or two more values of k we could squeeze out with enormous effort, it may be smarter to actually let things rest for a while in case some external development makes further progress a lot easier (similar to the situation with Polymath8a).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b, X: writing the paper, and chasing down loose ends | What's new")]], [#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-297930")[#strong[#text("Polymath8b, X: writing the paper, and chasing down loose ends | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2014")])]

#text("[…] the previous thread may be found here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/02/21/polymath8b-ix-large-quadratic-programs/#comment-516361")[#strong[#text("Tutto quello che dovete sapere sui numeri primi - Galileo")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2019")]

#text("[…] coppie di numeri primi distanti tra loro meno di 70 milioni. Successivamente altri matematici hanno ulteriormente affinato tale dimostrazione, riducendo la differenza a […]")
]
