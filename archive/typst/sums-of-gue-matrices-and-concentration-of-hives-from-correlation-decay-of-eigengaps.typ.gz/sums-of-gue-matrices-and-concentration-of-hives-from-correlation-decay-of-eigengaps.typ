// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/
// Converted to Typst by tao2typ: "2026-10-14T11:10:26.038327+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sums of GUE matrices and concentration of hives from correlation decay of eigengaps", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sums of GUE matrices and concentration of hives from correlation decay of eigengaps")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/")[#text("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.tifr.res.in/~hariharan.narayanan/")[#text("Hariharan Narayanan")]#text(", ")#link("https://math.mit.edu/~sheffield/")[#text("Scott Sheffield")]#text(", and I have just uploaded to the arXiv our paper “")#link("https://arxiv.org/abs/2306.11514")[#text("Sums of GUE matrices and concentration of hives from correlation decay of eigengaps")]#text("“. This is a personally satisfying paper for me, as it connects the work I did as a graduate student (with Allen Knutson and Chris Woodward) on sums of Hermitian matrices, with more recent work I did (with Van Vu) on random matrix theory, as well as several other results by other authors scattered across various mathematical subfields.")

#text("Suppose ")#mi("{A, B}")#text(" are two ")#mi("{n \\times n}")#text(" Hermitian matrices with eigenvalues ")#mi("{\\lambda = (\\lambda_1,\\dots,\\lambda_n)}")#text(" and ")#mi("{\\mu = (\\mu_1,\\dots,\\mu_n)}")#text(" respectively (arranged in non-increasing order. What can one say about the eigenvalues ")#mi("{\\nu = (\\nu_1,\\dots,\\nu_n)}")#text(" of the sum ")#mi("{A+B}")#text("? There are now many ways to answer this question precisely; one of them, introduced ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1671451")[#text("by Allen and myself")]#text(" many years ago, is that there exists a certain triangular array of numbers called a “hive” that has ")#mi("{\\lambda, \\mu, \\nu}")#text(" as its boundary values. On the other hand, by the pioneering ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1094052")[#text("work of Voiculescu")]#text(" in free probability, we know in the large ")#mi("{n}")#text(" limit that if ")#mi("{\\lambda, \\mu}")#text(" are asymptotically drawn from some limiting distribution, and ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are drawn independently at random (using the unitarily invariant Haar measure) amongst all Hermitian matrices with the indicated eigenvalues, then (under mild hypotheses on the distribution, and under suitable normalization), ")#mi("{\\nu}")#text(" will almost surely have a limiting distribution that is the ")#link("https://en.wikipedia.org/wiki/Free_convolution")[#text("free convolution")]#text(" of the two original distributions.")

#text("One of my favourite open problems is to come up with a theory of “free hives” that allows one to explain the latter fact from the former. This is still unresolved, but we are now beginning to make a bit of progress towards this goal. We know (for instance from the calculations ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3835549")[#text("of Coquereaux and Zuber")]#text(") that if ")#mi("{A, B}")#text(" are drawn independently at random with eigenvalues ")#mi("{\\lambda, \\mu}")#text(", then the eigenvalues ")#mi("{\\nu}")#text(" of ")#mi("{A+B}")#text(" are distributed according to the boundary values of an “augmented hive” with two boundaries ")#mi("{\\lambda,\\mu}")#text(", drawn uniformly at random from the polytope of all such augmented hives. (This augmented hive is basically a regular hive with another type of pattern, namely a ")#emph[#text("Gelfand-Tsetlin pattern")]#text(", glued to one side of it.) So, if one could show some sort of concentration of measure for the entries of this augmented hive, and calculate what these entries concentrated to, one should presumably be able to recover Voiculescu’s result after some calculation.")

#text("In this paper, we are able to accomplish the first half of this goal, assuming that the spectra ")#mi("{\\lambda, \\mu}")#text(" are not deterministic, but rather drawn from the spectra of rescaled ")#link("https://en.wikipedia.org/wiki/Random_matrix#Gaussian_ensembles")[#text("GUE matrices")]#text(" (thus ")#mi("{A,B}")#text(" are independent rescaled copies of the GUE ensemble). We have chosen to normalize matters so that the eigenvalues ")#mi("{\\lambda,\\mu}")#text(" have size ")#mi("{O(n)}")#text(", so that the entries of the augmented hive have entries ")#mi("{O(n^2)}")#text(". Our result is then that the entries of the augmented hive in fact have a standard deviation of ")#mi("{o(n^2)}")#text(", thus exhibiting a little bit of concentration. (Actually, from the Brunn-Minkowski inequality, the distribution of these entries is log concave, so once once controls the standard deviation one also gets a bit of exponential decay beyond the standard deviation; Narayanan and Sheffield had also ")#link("https://arxiv.org/abs/2111.00421")[#text("recently established")]#text(" the existence of a rate function for this sort of model.) Presumably one should get much better concentration, and one should be able to handle other models than the GUE ensemble, but this is the first advance that we were able to achieve.")

#text("Augmented hives seem tricky to work with directly, but by adapting the octahedron recurrence introduced for this problem ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2097327")[#text("by Knutson, Woodward, and myself")]#text(" some time ago (which is related to the associativity ")#mi("{(A+B)+C = A+(B+C)}")#text(" of addition for Hermitian matrices), one can construct a piecewise linear volume-preserving map between the cone of augmented hives, and the product of two Gelfand-Tsetlin cones. The problem then reduces to establishing concentration of measure for certain piecewise linear maps on products of Gelfand-Tsetlin cones (endowed with a certain GUE-type measure). This is a promising formulation because Gelfand-Tsetlin cones are by now quite well understood.")

#text("On the other hand, the piecewise linear map, initially defined by iterating the octahedron relation ")#mi("{f = \\max(a+c,b+d)-e}")#text(", looks somewhat daunting. Fortunately, there is an explicit formulation of this map ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2317336")[#text("due to Speyer")]#text(", as the supremum of certain linear maps associated to perfect matchings of a certain “excavation graph”. For us it was convenient to work with the dual of this excavation graph, and associate these linear maps to certain “lozenge tilings” of a hexagon.")

#text("It would be more convenient to study the concentration of each linear map separately, rather than their supremum. By the Cheeger inequality, it turns out that one can relate the latter to the former provided that one has good control on the ")#link("https://en.wikipedia.org/wiki/Cheeger_constant")[#text("Cheeger constant")]#text(" of the underlying measure on the Gelfand-Tsetlin cones. Fortunately, the measure is log-concave, so one can use the very recent ")#link("https://arxiv.org/abs/2303.14938v1")[#text("work of Klartag")]#text(" on the ")#link("https://mathscinet.ams.org/mathscinet/article?mr=1318794")[#text("KLS conjecture")]#text(" to eliminate the supremum (up to a logarithmic loss which is only moderately annoying to deal with).")

#text("It remains to obtain concentration on the linear map associated to a given lozenge tiling. After stripping away some contributions coming from lozenges near the edge (using some eigenvalue rigidity results ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3109424")[#text("of Van Vu and myself")]#text("), one is left with some bulk contributions which ultimately involve eigenvalue interlacing gaps such as")

#align(center)[#tao-fit-display[#mitex("\\lambda_i - \\lambda_{n-1,i}")]]

#text("where ")#mi("{\\lambda_{n-1,i}}")#text(" is the ")#mi("{i^{th}}")#text(" eigenvalue of the top left ")#mi("{n-1 \\times n-1}")#text(" minor of ")#mi("{A}")#text(", and ")#mi("{i}")#text(" is in the bulk region ")#mi("{\\varepsilon n \\leq i \\leq (1-\\varepsilon) n}")#text(" for some fixed ")#mi("{\\varepsilon > 0}")#text(". To get the desired result, one needs some non-trivial correlation decay in ")#mi("{i}")#text(" for these statistics. If one was working with eigenvalue gaps ")#mi("{\\lambda_i - \\lambda_{i+1}}")#text(" rather than interlacing results, then such correlation decay was conveniently obtained for us by ")#link("https://mathscinet.ams.org/mathscinet/article?mr=4556290")[#text("recent work of Cippoloni, Erdös, and Schröder")]#text(". So the last remaining challenge is to understand the relation between eigenvalue gaps and interlacing gaps.")

#text("For this we turned to the ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3010400")[#text("work of Metcalfe")]#text(", who uncovered a ")#link("https://en.wikipedia.org/wiki/Determinantal_point_process")[#text("determinantal process structure")]#text(" to this problem, with a kernel associated to Lagrange interpolation polynomials. It is possible to satisfactorily estimate various integrals of these kernels using the residue theorem and eigenvalue rigidity estimates, thus completing the required analysis.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678859")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Dear, pro. Tao,")#linebreak()#text(" Very interesting !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28b3868b80ddac4925ef086ec21dfa6072e21c4b29229fe8b5c3cf3d35e3449b-bfdd190fab8f1a5bcbe14c22cda807b92bd161077c1788a4e461aa77ec67166d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678870")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Congratulations for the fascinating work! Beyond new proofs of the relation between the eigenvalue distribution of sums of large random Hermitian matrices and free convolution, what interesting new applications and tools do you imagine would emerge from a theory of “free hives”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("I think it may lead to a new approach to free probability, in which operations such as free convolution are viewable as boundaries of free hives (which also should come with a free associator coming from the octahedron recurrence). The local structure of a random hive should also be an interesting process; we know that the local structure of a random Gelfand-Tsetlin pattern is given by the Boutiller bead process, which should have a generalization that covers hives, and possibly other processes as well. The study of random Young tableaux and random partitions should also presumably be connected to this story somehow…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/14e668e026d591a6d6eea6751ec1463d62e3147bf2327c8e1296d40f4cf44b87-5659947b955b2de2d952f785ebe8661bc533a90f19f82bb402a385dadeb120a7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LAVA")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678873")[#strong[#text("LAVA")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Can the techniques in this paper be applied to analyze the concentration of other types of random structures beyond augmented hives, such as random tilings or random partitions ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678881")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Well, my two coauthors come from that field, and they have actually been importing some ideas from those areas into this subject, for instance in their other paper where they manage to define a surface tension for hives and relate it to large deviations. Hives are closely related to puzzles which do resemble the type of random tilings often studied in the literature, except that while domino tilings (for instance) have a lot of “local moves” that can be used to study statistical limits of these tilings, puzzles are somewhat more rigid and have some strange long-range correlations that aren’t well understood yet. But perhaps now that we have proof of concept that these problems are tractable, we can start making more progress.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe84aefbdae7a9cdd79cde3aa9378da703426b50c31ccf1d9d43b15c6c7d8ffa-5a4900c266b0fe4916766455751ef80af6722c3dcaa970037bf15c97a1072509.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Not elvesier")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678901")[#strong[#text("Not elvesier")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2023")])]

#text("It would be nice if mathscinet atheist allowed abstracts for free.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-678904")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2023")])]

#text("In what you’re doing, to get the right measure, instead of a delta function placed at the spectrum you use Lebesgue measure on a Gel’fand-Cetlin polytope to work with a measure on the space of possible diagonals. There’s a formally related expansion when thinking about equivariant Schubert classes that we (Terry and I) used in our puzzles paper ")#link("https://arxiv.org/abs/math/0112150")[#text("https://arxiv.org/abs/math/0112150")]#text(" , taking an equivariant Schubert class to its restrictions at all fixed points. In each case one is dealing with an injective ring homomorphism (convolutions of measures in the first case, multiplication in cohomology in the second).")

#text("With that parallel in mind, the piecewise-linear volume-preserving bijection you allude to is an analogue of the argument we (Paul Zinn-Justin and I) use in ")#link("https://arxiv.org/abs/1706.10019")[#text("https://arxiv.org/abs/1706.10019")]#text(" . Check out p23; the equation on the top relates “augmented puzzles” (LHS) to pairs of AJS/Billey computors (RHS, the analogue of the Gel’fand-Cetlin computation). The final argument is on p28.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-679398")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2023")])]

#text("I’m from Africa Ethiopian grade 10th student that has dream to be best physicists, mathematician, cosmologist and other natural science I interested in knowledge I don’t want to have constant job because of I would like to explore nature and contribute")#linebreak()#text(" New things to the world but in Africa education is limited also people believe that you are learning for only getting job I hate this idea for me education is live I some time assume that it’s my heart even if hadn’t any material that I can do math and physics I will use my blood like pen I will write and calculate by my blood if it’s needed I know my talent is in physics and I love it because of you Terry I also love math")#linebreak()#text(" I hope we’ll meet someday")#linebreak()#text(" Thanks for your time")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c619410101d0c3e14076fbc6256b3a3eeb95fb28a7a88af02fb983a7b3f3eefd-acebd0eb18e594e23afcf5d4bdf9b8e632b750fe365dbd0aed4779023ce9a4db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vince MENDY")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-679401")[#strong[#text("vince MENDY")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2023")])]

#text("Hey there! I hope you’re doing great. I wanted to share some words of encouragement with you: keep exploring, keep pushing, and pursue your passions with unwavering dedication. I come from Africa, specifically Senegal, and I can attest that it’s not always easy to embrace the mindset of following your dreams. However, I encourage you to persevere because one day, your hard work will pay off. In my own academic journey, I studied mathematics, physics, computer science, and chemistry at university. Throughout it all, Terence was my source of inspiration in the realm of mathematics. So, stay determined and make your dreams a reality.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the distribution of eigenvalues of GUE and its minors at fixed index | What's new")]], [#link("https://terrytao.wordpress.com/2023/06/20/sums-of-gue-matrices-and-concentration-of-hives-from-correlation-decay-of-eigengaps/#comment-686917")[#strong[#text("On the distribution of eigenvalues of GUE and its minors at fixed index | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2024")])]

#text("[…] I’ve just the arXiv the paper “On the distribution of eigenvalues of GUE and its minors at fixed index“. This is a somewhat technical paper establishing some estimates regarding one of the most well-studied random matrix models, the Gaussian Unitary Ensemble (GUE), that were not previously in the literature, but which will be needed for some forthcoming work of Hariharan Narayanan on the limiting behavior of “hives” with GUE boundary conditions (building upon our previous joint work with Sheffield). […]")
]
