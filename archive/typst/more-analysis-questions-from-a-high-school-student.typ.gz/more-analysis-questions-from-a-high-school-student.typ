// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/
// Converted to Typst by tao2typ: "2026-10-14T15:20:40.760742+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "More analysis questions from a high school student", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("More analysis questions from a high school student")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 September 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/")[#text("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("A few months ago ")#link("https://terrytao.wordpress.com/2021/05/04/is-there-a-non-analytic-function-with-all-differences-analytic/")[#text("I posted a question")]#text(" about analytic functions that I received from a bright high school student, which turned out to be studied and resolved ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=43870")[#text("by de Bruijn")]#text(". Based on this positive resolution, I thought I might try my luck again and list three further questions that this student asked which do not seem to be trivially resolvable.")

#enum(start: 1, 
[#text("Does there exist a smooth function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" which is nowhere analytic, but is such that the Taylor series ")#mi("{\\sum_{n=0}^\\infty \\frac{f^{(n)}(x_0)}{n!} (x-x_0)^n}")#text(" converges for every ")#mi("{x, x_0 \\in {\\bf R}}")#text("? (Of course, this series would not then converge to ")#mi("{f}")#text(", but instead to some analytic function ")#mi("{f_{x_0}(x)}")#text(" for each ")#mi("{x_0}")#text(".) I have a vague feeling that perhaps the Baire category theorem should be able to resolve this question, but it seems to require a bit of effort. (Update: answered by Alexander Shaposhnikov in comments.)")],
[#text("Is there a function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" which meets every polynomial ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" to infinite order in the following sense: for every polynomial ")#mi("{P}")#text(", there exists ")#mi("{x_0}")#text(" such that ")#mi("{f^{(n)}(x_0) = P^{(n)}(x_0)}")#text(" for all ")#mi("{n=0,1,2,\\dots}")#text("? Such a function would be rather pathological, perhaps resembling a space-filling curve. (Update: solved for smooth ")#mi("{f}")#text(" by Aleksei Kulikov in comments. The situation currently remains unclear in the general case.)")],
[#text("Is there a power series ")#mi("{\\sum_{n=0}^\\infty a_n x^n}")#text(" that diverges everywhere (except at ")#mi("{x=0}")#text("), but which becomes pointwise convergent after dividing each of the monomials ")#mi("{a_n x^n}")#text(" into pieces ")#mi("{a_n x^n = \\sum_{j=1}^\\infty a_{n,j} x^n}")#text(" for some ")#mi("{a_{n,j}}")#text(" summing absolutely to ")#mi("{a_n}")#text(", and then rearranging, i.e., there is some rearrangement ")#mi("{\\sum_{m=1}^\\infty a_{n_m, j_m} x^{n_m}}")#text(" of ")#mi("{\\sum_{n=0}^\\infty \\sum_{j=1}^\\infty a_{n,j} x^n}")#text(" that is pointwise convergent for every ")#mi("{x}")#text("? (Update: solved by Jacob Manaker in comments.)")]
)

#text("Feel free to post answers or other thoughts on these questions in the comments.")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MyMathYourMath")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634096")[#strong[#text("MyMathYourMath")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("Dr Tao, small question if the map was from complex to complex then this wouldn’t even be a question correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634099")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("For question 2, do we know how to construct such a function meeting, not all real polynomials, but just the linear ones ")#mi("T(x) = \\lambda x")#text(" for ")#mi("\\lambda \\in \\mathbf{R}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7147abf1f864f5d4e59468f4c746c30c4582d6ef5f42cb70633d4aef960da350-0012912961b60610788baf9104e6e101c0ed6fe4917ac5c588d0a26cbf59936a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Indeed, if ")#mi("f(x_a)=0")#text(" and ")#mi("f^{\\prime}(x_a)=a")#text(", then ")#mi("\\{x_a\\}_{a\\neq 0}")#text(" forms a discrete subset of R (since in some small neighborhood of $x_a$ the function ")#tao-math("f(x) = a(x-x_a)+o(\\left|x-x_a\\right|)", block: false)#text(" has no zeroes other than ")#mi("x_a")#text(" and hence this neighborhood contains no ")#mi("x_b")#text(" for ")#mi("b\\neq a")#text("), and so only countably many polynomials of the form ")#mi("P(x)=ax")#text(" can be accommodated. This argument also does not require any global continuity or smoothness of f.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634129")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("This argument looks nice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fba7098f7286623bf3673657f1ff96e3be67e69487e67018084add49c3ba031-5aa510afc990f970bb1801ee33b9d7ffaae5f7cd3249f3ff8927bd3e0b9d5b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Why are we looking at the zeroes of $ latex f$?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36aff54e2e0a56c390058a7fee0df08758bbacc2d40df76f2f8ec3e71095f23-a41a0a22d3ae663f0e0835a9ec1dfb45e97835a308006af1abce572b8b804e92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634100")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("Maybe we can answer second one using interpolation polynomials….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36aff54e2e0a56c390058a7fee0df08758bbacc2d40df76f2f8ec3e71095f23-a41a0a22d3ae663f0e0835a9ec1dfb45e97835a308006af1abce572b8b804e92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634101")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("x_{0} selects the polynomials.")

#text("Em ter., 14 de set. de 2021 às 22:48, Guilherme Rocha de Rezende escreveu:")

#text("> Maybe we can answer second one using interpolation polynomials…. > > Em ter., 14 de set. de 2021 às 21:34, What’s new <")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a36aff54e2e0a56c390058a7fee0df08758bbacc2d40df76f2f8ec3e71095f23-a41a0a22d3ae663f0e0835a9ec1dfb45e97835a308006af1abce572b8b804e92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rocha de Rezende")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634104")[#strong[#text("Guilherme Rocha de Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("I am a physicist and have good intuition but your technique is much better than mine.")

#text("Em ter., 14 de set. de 2021 às 23:18, Guilherme Rocha de Rezende escreveu:")

#text("> We must pass to continuous coefficients…..perhaps discretizing the > coefficients and take the limit to approximate the continuous case. > > Em ter., 14 de set. de 2021 às 22:49, Guilherme Rocha de Rezende ")#link("mailto:1434903@etfbsb.edu.br")[#text("1434903@etfbsb.edu.br")]#text("> escreveu: > >> x_{0} selects the polynomials. >> >> Em ter., 14 de set. de 2021 às 22:48, Guilherme Rocha de Rezende > ")#link("mailto:1434903@etfbsb.edu.br")[#text("1434903@etfbsb.edu.br")]#text("> escreveu: >> >>> Maybe we can answer second one using interpolation polynomials…. >>> >>> Em ter., 14 de set. de 2021 às 21:34, What’s new <")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd44210f3549d978db9216b19a1414fcba9e176296ca1cedfd8fc84fc3f4bdff-4084c48c66beadbfd0a80ba3e61de5526dd75472e9918dbb7641a8a81c5d01f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam Denchfield")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634105")[#strong[#text("Adam Denchfield")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("For 3), physicists encounter this situation of a power series diverging everywhere except x=0 fairly often. The concept of resummation has been refined tremendously over the decades, since every physical problem of interest involves power series whose coefficients grow as fast or faster than n!. One of the simplest models exhibiting this is doing perturbation theory for the lowest eigenvalue of the anharmonic oscillator, talked about extensively by folks like Carl Bender. Borel resummation can be used here, involving taking the Taylor series coefficients, dividing them by n!, evaluating the modified power series then, and performing an integration against a Borel kernel to get the ‘resummed’ form of the function. For more: ")#link("https://en.wikipedia.org/wiki/Borel_summation")[#text("https://en.wikipedia.org/wiki/Borel_summation")]

#text("Perhaps this process could be reinterpreted as the desired above reorganization of the Taylor series terms. On the other hand, I think the equivalence of summation methods that preserve order of summation is proved in Bender & Orszag’s text, and I don’t recall if Borel resummation falls under this roof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0afc3bc4973901ccb349c733489ebbaf4fa181eda4e984d9f4b17645a30d8008-a063fd2fe99145ace95e48dfb6cc7fa6ef48b54c3e000a5f523819561e23d0c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksei Kulikov")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634107")[#strong[#text("Aleksei Kulikov")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("Answer to the second question is negative, below are 1,5 proofs of it:")

#text("1)Cheap argument via Sard’s theorem — you can not even serve all the constant polynomials. Indeed, if ")#mi("f(x_0) = c")#text(", ")#mi("f^{\\prime}(x_0) = 0")#text(", then ")#mi("c")#text(" is a critical value of ")#mi("f")#text(", so the measure of possible ")#mi("c")#text("‘s is ")#mi("0")#text(" and it can’t be all of ")#mi("\\mathbb{R}")#text(". Excluding constants also wouldn’t work as ")#mi("P(x) = cx")#text(" for all ")#mi("c")#text(" can’t work either (consider ")#mi("g(x) = f(x)/x")#text(", then the same argument works for ")#mi("x_0\\ne 0")#text(", and ")#mi("x_0 = 0")#text(" gives us at most one more polynomial).")

#text("1.5)Here’s an argument which is more appealing to my analysis soul, but which I’m too lazy to make rigorous since we already have an easy proof.")

#text("Consider the curve ")#mi("(x, f(x), f^{\\prime}(x))")#text(" — it’s a smooth ")#mi("1")#text("-dimensional curve in ")#mi("\\mathbb{R}^3")#text(" (since ")#mi("f\\in C^2(\\mathbb{R})")#text(", so no space-filling curves possible). Each polynomial ")#mi("P(x)")#text(" also gives us a smooth curve in this space. By the assumption these curves intersect. Now it remains to pick a ")#mi("2")#text("-dimensional family of polynomials which is generic enough, then there’s no way our smooth curve intersect every curve in this family just by dimension counting (rigorous argument here would probably repeat many steps from the proof of Sard’s theorem, though).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634126")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("This was also the argument I thought in mind; but for applying Sard’s theorem we need ")#mi("f")#text(" to be smooth everywhere, but I don’t see any easy way to infer that about ")#mi("f")#text(" from the given conditions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Nice argument! Here is a variant that works for any two-parameter set of polynomials, such as the linear polynomials ")#mi("a+bx")#text(" for sake of argument, and avoids Sard’s theorem: if a smooth function ")#mi("f")#text(" was tangent to every linear polynomial ")#mi("a+bx")#text(", then the smooth map ")#mi("x \\mapsto (f(x)-xf^{\\prime}(x), f^{\\prime}(x))")#text(" would be a surjective smooth map from ")#mi("{\\bf R}")#text(" onto ")#mi("{\\bf R}^2")#text(". But this is impossible (Lipschitz maps cannot increase Hausdorff dimension).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harry West")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634118")[#strong[#text("Harry West")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("A negative answer to 1 is a theorem of Boas: ")#link("https://projecteuclid.org/journals/bulletin-of-the-american-mathematical-society-new-series/volume-41/issue-4/A-theorem-on-analytic-functions-of-a-real-variable/bams/1183498133.full")[#text("https://projecteuclid.org/journals/bulletin-of-the-american-mathematical-society-new-series/volume-41/issue-4/A-theorem-on-analytic-functions-of-a-real-variable/bams/1183498133.full")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634121")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("No it does not answer the question. The result you cite consider the case where the radii of convergence are uniformly lower bounded by a positive constant.")

#text("This tells at least that if such a function exists then there is no possible lower bound of these radii of convergence.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9b4e1cd706403fa1d7ee5c8343737580c61db0e288168126cdf6ff9e93c663-e5af0721fb5c13c5b7f5cc8310830d6a8363b7d834ab9fde8b3f5044f6d9d5fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Shaposhnikov")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634119")[#strong[#text("Alexander Shaposhnikov")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("Let ")#mi("X_{N}")#text(" be the set of ")#mi("x_0")#text(" such that for all ")#mi("n")#text(", ")#tao-math("\\left| f^{(n)}(x_0) \\right| \\leq n! * N", block: false)#text(". It is clear that ")#mi("X_{N}")#text(" is closed and ")#mi("\\mathbb{R}")#text(" equals the union of all ")#mi("X_{N}, N \\in \\mathbb{N}")#text(". Then by the Baire category theorem there exists ")#mi("N_0")#text(" such that ")#mi("X_{N_0}")#text(" contains an interval ")#mi("J")#text(". Without loss of generality one may assume that ")#tao-math("\\left|J\\right| < 1/2N", block: false)#text(". Now one can see that ")#mi("f")#text(" is analytic on ")#mi("J")#text(", e.g. using the the Lagrange form for the remainder in Taylor's theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Nice! A good textbook use of the Baire category theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634124")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2021")])]

#text("Negative answer to (2.)")#linebreak()#text(" Assume to the contrary that such a function ")#mi("f")#text(" exists. Then for each constant polynomial ")#mi("c")#text(" one must have a solution ")#mi("x_0")#text(" to the system of equations ")#mi("f(x_0) = c, f^{\\prime}(x_0)=0")#text(" and thus each real number must be a critical value of ")#mi("f")#text("; but according to Sard’s theorem the set of critical values of ")#mi("f")#text(" must have measure 0, a contradiction!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634125")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Now, I find that my solution above is same as one posted much earlier in the comments.")

#text("Unfortunately, this argument won’t hold if our function ")#mi("f")#text(" is not smooth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fba7098f7286623bf3673657f1ff96e3be67e69487e67018084add49c3ba031-5aa510afc990f970bb1801ee33b9d7ffaae5f7cd3249f3ff8927bd3e0b9d5b8d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nkv")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634170")[#strong[#text("Nkv")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Does Sard theorem work if restrict the domain to smooth points?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634180")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("No, we need the domain to be a manifold.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634138")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/09/15/more-analysis-questions-from-a-high-school-student/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634162")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("Terry, I think its great that you are open to the younger generation presenting mathematical concepts to you and the above-commenters who are all experts within their discipline. With schools at a virtual standstill because of COVID, I know that you can think of additional innovative ways to get younger students involved in math/science on a much larger scale. Thank you,")#linebreak()#text(" David")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634181")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("I really like the kind of mathematics questions which are asked by this high school student. Back during my high school days, I used to try solving analysis problems from contests such as the Putnam or the notoriously difficult Miklos Schweitzer competition, and literally that led to several interesting encounters with challenging problems and sometimes slight modifications of the problems (often done by me) seemed very difficult to solve; I did not know about places to ask these questions until quite long, and so they remained unattended by audience (until much later when I learned the right place to ask these questions). I am happy that this high school student has been identified and that he or she is receiving support with his or her questions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634163")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2021")])]

#text("A well-known example for a smooth nowhere analytic function on ")#mi("[0, +\\infty)")#text(" is the Fabius function (which has many interesting properties), see")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Fabius_function")[#text("https://en.wikipedia.org/wiki/Fabius_function")]

#text("Perhaps a modification of this function may answer the first question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634224")[#strong[#text("Terry Tao teaches – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")]

#text("[…] A few months ago I posted a question about analytic functions that I received from a bright high school student, which turned out to be studied and resolved by de Bruijn. Based on this positive resolution, I thought I might try my luck again and list three further questions that this student asked which do not seem to be trivially resolvable. … (What’s New) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634460")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2021")])]

#text("The answer to (3) is yes. Let ")#mi("\\sum_n{a_nx^n}")#text(" be any divergent power series, and fix a conditionally convergent power series ")#mi("\\{b_m\\}_m")#text(" (i.e., ")#mi("\\left\\{\\frac{(-1)^m}{m}\\right\\}")#text("). For each ")#mi("n")#text(", there is a rearrangement ")#mi("\\{b_{\\sigma_n(m)}\\}_m")#text(" of ")#mi("\\{b_m\\}_m")#text(" such that")

#mi("\\displaystyle a_n=\\sum_m{b_{\\sigma_n(m)}}")

#text("OTOH, there is also a rearrangement ")#mi("b_{\\alpha(m)}")#text(" summing to 0. Now we have the following rearrangement heuristic:")

#mi("\\displaystyle \\sum_n{a_nx^n}=\\sum_n{\\sum_m{b_{\\sigma_n(m)}}x^n}\\sim\\sum_n{\\sum_m{b_{\\alpha(m)}}x^n}=\\sum_n{0\\cdot x^n}=0")

#text("which converges everywhere.")

#text("Of course, this does not quite address the problem, because we need to linearize the order of summation from ordinal ")#mi("\\omega\\times\\omega")#text(" to ordinal ")#mi("\\omega")#text(". But that is easy enough to solve, as shown below.")

#text("Fix any power series ")#mi("f(x)=\\sum_j{c_jx^j}")#text(" that converges everywhere and has positive coefficients (i.e. ")#mi("\\sum_j{\\frac{x^j}{j!}}")#text("). Define a “")#mi("\\mathbb{N}")#text("-graded” summation order ")#mi("\\mathcal{O}")#text(" as follows: at level k, we sum enough terms of the form ")#mi("b_{\\alpha(m)}x^j")#text(" with ")#mi("j\\leq k")#text(" so that")

#text("(a) the partial sum is a polynomial ")#mi("p(x)")#text(" of degree at most k with ")#tao-math("\\displaystyle \\left|[x^j]p(x)\\right|<\\frac{c_j}{k}", block: false)#text(" and")

#text("(b) we've used all terms of the form ")#mi("\\{b_mx^j\\}_m")#text(" where ")#tao-math("\\left|b_m\\right|\\geq\\frac{c_j}{k}", block: false)#text(".")

#text("Since ")#mi("\\{b_{\\alpha(m)}\\}_m")#text(" is a conditionally convergent series, there are only finitely many terms necessary to achieve both effects.")

#text("Now suppose we apply ")#mi("\\mathcal{O}")#text(". Then, at the completion of each level, our partial sum is (for any x) at most")

#tao-math("\\displaystyle \\sum_{j=0}^k{\\frac{c_j\\left|x\\right|^j}{k}}\\leq\\frac{1}{k}\\sum_{j=0}^{\\infty}{c_jx^j}=\\frac{f(x)}{k}\\quad\\quad(1)", block: false)#text(".")

#text("Suppose we now sum more terms. Any coming from ")#mi("\\{b_mx^j\\}_m")#text(" are at most ")#mi("\\frac{c_jx^j}{k}")#text(", so the proof of the Riemann rearrangement theorem guarantees that (1) will continue to hold. Thus")

#tao-math("\\displaystyle \\left|\\sum_{n,m:\\mathcal{O}}{b_{\\alpha(m)}x^n}\\right|\\leq\\limsup_{k\\to\\infty}{\\frac{f(x)}{k}}=0", block: false)

#text("holds pointwise, as desired.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634462")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2021")])]

#text("Also worth mentioning: this shows that in fact, we can take _any_ power series and split+rearrange it to get any _other_ power series, with pointwise convergence if the “destination” series is convergent. (Also probably if it isn’t, but I’d need to think about it more to be sure.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("Nice solution!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bb842258b040d699c721f644030fecdc22c9238ba0571551bda772faf17210e-2cc94c6bf194e5f0820ef564dde484baadd6d805623e6bbc5b4fa0616a1b258d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacob Manaker")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-634726")[#strong[#text("Jacob Manaker")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("Aww, thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14b565e5356186b40da68d6e88ca9e7f1e39baacc7dc80d5d8308af7de65b35-90cef7f39fa9244af0b3f2e7efbedf804d1442ed7791e5d8f7447a8c0d584640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Weiland")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-636954")[#strong[#text("Christian Weiland")]]#text(size: 9pt, fill: rgb("596477"), " · 11 November 2021")])]

#text("Hello everyone!")#linebreak()#text(" I’d like to propose the following solution for problem 2: There can’t be such a function ")#mi("f:\\mathbb{R}\\to\\mathbb{R}")#text(" even for polynomials of the form ")#mi("ax+b")#text(". Suppose there is such an ")#mi("f")#text(" and let ")#mi("C:=\\{x\\in\\mathbb{R}: f(x) = c, f^{\\prime}(x) \\text{ exists}\\}")#text(". Then ")#mi("C")#text(" has the same cardinality as ")#mi("\\mathbb{R}")#text(". The number of isolated points in ")#mi("C")#text(" is at most countably infinite. So most of the points in ")#mi("C")#text(" are limit points of ")#mi("C")#text(". But ")#mi("f^{\\prime}(x)=0")#text(" for each such limit point ")#mi("x\\in C")#text(" rendering it impossible for $f$ to exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14b565e5356186b40da68d6e88ca9e7f1e39baacc7dc80d5d8308af7de65b35-90cef7f39fa9244af0b3f2e7efbedf804d1442ed7791e5d8f7447a8c0d584640.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Weiland")]], [#link("https://terrytao.wordpress.com/2021/09/14/more-analysis-questions-from-a-high-school-student/#comment-637111")[#strong[#text("Christian Weiland")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2021")])]

#text("Hi again, I’d like to retract my “solution” because it contains a mistake.")
]
