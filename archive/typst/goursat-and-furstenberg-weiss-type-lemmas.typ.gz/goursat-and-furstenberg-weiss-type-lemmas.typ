// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/
// Converted to Typst by tao2typ: "2026-10-14T16:38:57.138955+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Goursat and Furstenberg-Weiss type lemmas", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Goursat and Furstenberg-Weiss type lemmas")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 May 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/")[#text("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’m collecting in this blog post a number of simple group-theoretic lemmas, all of the following flavour: if ")#mi("{H}")#text(" is a subgroup of some product ")#mi("{G_1 \\times \\dots \\times G_k}")#text(" of groups, then one of three things has to happen:")

#list(
[#text("(")#mi("{H}")#text(" too small) ")#mi("{H}")#text(" is contained in some proper subgroup ")#mi("{G^{\\prime}_1 \\times \\dots \\times G^{\\prime}_k}")#text(" of ")#mi("{G_1 \\times \\dots \\times G_k}")#text(", or the elements of ")#mi("{H}")#text(" are constrained to some sort of equation that the full group ")#mi("{G_1 \\times \\dots \\times G_k}")#text(" does not satisfy.")],
[#text("(")#mi("{H}")#text(" too large) ")#mi("{H}")#text(" contains some non-trivial normal subgroup ")#mi("{N_1 \\times \\dots \\times N_k}")#text(" of ")#mi("{G_1 \\times \\dots \\times G_k}")#text(", and as such actually arises by pullback from some subgroup of the quotient group ")#mi("{G_1/N_1 \\times \\dots \\times G_k/N_k}")#text(".")],
[#text("(Structure) There is some useful structural relationship between ")#mi("{H}")#text(" and the groups ")#mi("{G_1,\\dots,G_k}")#text(".")]
)

#text("These sorts of lemmas show up often in ergodic theory, when the equidistribution of some orbit is governed by some unspecified subgroup ")#mi("{H}")#text(" of a product group ")#mi("{G_1 \\times \\dots \\times G_k}")#text(", and one needs to know further information about this subgroup in order to take the analysis further. In some cases only two of the above three options are relevant. In the cases where ")#mi("{H}")#text(" is too “small” or too “large” one can reduce the groups ")#mi("{G_1,\\dots,G_k}")#text(" to something smaller (either a subgroup or a quotient) and in applications one can often proceed in this case by some induction on the “size” of the groups ")#mi("{G_1,\\dots,G_k}")#text(" (for instance, if these groups are Lie groups, one can often perform an induction on dimension), so it is often the structured case which is the most interesting case to deal with.")

#text("It is perhaps easiest to explain the flavour of these lemmas with some simple examples, starting with the ")#mi("{k=1}")#text(" case where we are just considering subgroups ")#mi("{H}")#text(" of a single group ")#mi("{G}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a group ")#mi("{G}")#text(". Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists a non-trivial group homomorphism ")#mi("{\\eta: G \\rightarrow K}")#text(" into a group ")#mi("{K = (K,\\cdot)}")#text(" such that ")#mi("{\\eta(h)=1}")#text(" for all ")#mi("{h \\in H}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" normally generates ")#mi("{G}")#text(") ")#mi("{G}")#text(" is generated as a group by the conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{G^{\\prime}}")#text(" be the ")#text("group normally generated")#text(" by ")#mi("{H}")#text(", that is to say the group generated by the conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(". This is a normal subgroup of ")#mi("{G}")#text(" containing ")#mi("{H}")#text(" (indeed it is the smallest such normal subgroup). If ")#mi("{G^{\\prime}}")#text(" is all of ")#mi("{G}")#text(" we are in option (ii); otherwise we can take ")#mi("{K}")#text(" to be the quotient group ")#mi("{K := G/G^{\\prime}}")#text(" and ")#mi("{\\eta}")#text(" to be the quotient map. Finally, if (i) holds, then all of the conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(" lie in the kernel of ")#mi("{\\eta}")#text(", and so (ii) cannot hold. ")#mi("\\Box")

#text("Here is a “dual” to the above lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a group ")#mi("{G}")#text(". Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too large) ")#mi("{H}")#text(" is the pullback ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" of some subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G/N}")#text(" for some non-trivial normal subgroup ")#mi("{N}")#text(" of ")#mi("{G}")#text(", where ")#mi("{\\pi: G \\rightarrow G/N}")#text(" is the quotient map.")],
[#text("(ii) (")#mi("{H}")#text(" is core-free) ")#mi("{H}")#text(" does not contain any non-trivial conjugacy class ")#mi("{\\{ ghg^{-1}: g \\in G \\}}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Let ")#mi("{N}")#text(" be the ")#link("https://en.wikipedia.org/wiki/Core_(group_theory)")[#text("normal core")]#text(" of ")#mi("{H}")#text(", that is to say the intersection of all the conjugates ")#mi("{gHg^{-1}}")#text(" of ")#mi("{H}")#text(". This is the largest normal subgroup of ")#mi("{G}")#text(" that is contained in ")#mi("{H}")#text(". If ")#mi("{N}")#text(" is non-trivial, we can quotient it out and end up with option (i). If instead ")#mi("{N}")#text(" is trivial, then there is no non-trivial element ")#mi("{h}")#text(" that lies in the core, hence no non-trivial conjugacy class lies in ")#mi("{H}")#text(" and we are in option (ii). Finally, if (i) holds, then every conjugacy class of an element of ")#mi("{N}")#text(" is contained in ")#mi("{N}")#text(" and hence in ")#mi("{H}")#text(", so (ii) cannot hold. ")#mi("\\Box")

#text("For subgroups of nilpotent groups, we have a nice dichotomy that detects properness of a subgroup through abelian representations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-46273d7c3f42babd4165>#text(" Let ")#mi("{H}")#text(" be a subgroup of a nilpotent group ")#mi("{G}")#text(". Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists non-trivial group homomorphism ")#mi("{\\eta: G \\rightarrow K}")#text(" into an abelian group ")#mi("{K = (K,+)}")#text(" such that ")#mi("{\\eta(h)=0}")#text(" for all ")#mi("{h \\in H}")#text(".")],
[#text("(ii) ")#mi("{H=G}")#text(".")]
)
]

#text("Informally: if ")#mi("{h}")#text(" is a variable ranging in a subgroup ")#mi("{H}")#text(" of a nilpotent group ")#mi("{G}")#text(", then either ")#mi("{h}")#text(" is unconstrained (in the sense that it really ranges in all of ")#mi("{G}")#text("), or it obeys some abelian constraint ")#mi("{\\eta(h)=0}")#text(".")

#emph[#text("Proof:")]#text(" By definition of nilpotency, the ")#link("https://en.wikipedia.org/wiki/Central_series#Lower_central_series")[#text("lower central series")]

#align(center)[#tao-fit-display[#mitex("G_2 := [G,G], G_3 := [G,G_2], \\dots")]]

#text("eventually becomes trivial.")

#text("Since ")#mi("{G_2}")#text(" is a normal subgroup of ")#mi("{G}")#text(", ")#mi("{HG_2}")#text(" is also a subgroup of ")#mi("{G}")#text(". Suppose first that ")#mi("{HG_2}")#text(" is a proper subgroup of ")#mi("{G}")#text(", then the quotient map ")#mi("{\\eta \\colon G \\rightarrow G/HG_2}")#text(" is a non-trivial homomorphism to an abelian group ")#mi("{G/HG_2}")#text(" that annihilates ")#mi("{H}")#text(", and we are in option (i). Thus we may assume that ")#mi("{HG_2 = G}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("G_2 = [G,G] = [G, HG_2].")]]

#text("Note that modulo the normal group ")#mi("{G_3}")#text(", ")#mi("{G_2}")#text(" commutes with ")#mi("{G}")#text(", hence")

#align(center)[#tao-fit-display[#mitex("[G, HG_2] \\subset [G,H] G_3 \\subset H G_3")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("G = H G_2 \\subset H H G_3 = H G_3.")]]

#text("We conclude that ")#mi("{HG_3 = G}")#text(". One can continue this argument by induction to show that ")#mi("{H G_i = G}")#text(" for every ")#mi("{i}")#text("; taking ")#mi("{i}")#text(" large enough we end up in option (ii). Finally, it is clear that (i) and (ii) cannot both hold. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" When the group ")#mi("{G}")#text(" is locally compact and ")#mi("{H}")#text(" is closed, one can take the homomorphism ")#mi("{\\eta}")#text(" in Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(" to be continuous, and by using Pontryagin duality one can also take the target group ")#mi("{K}")#text(" to be the unit circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(". Thus ")#mi("{\\eta}")#text(" is now a character of ")#mi("{G}")#text(". Similar considerations hold for some of the later lemmas in this post. Discrete versions of this above lemma, in which the group ")#mi("{H}")#text(" is replaced by some orbit of a polynomial map on a nilmanifold, were obtained ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2122920")[#text("by Leibman")]#text(" and are important in the equidistribution theory of nilmanifolds; see ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("this paper of Ben Green and myself")]#text(" for further discussion.")
]

#text("Here is an analogue of Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(" for special linear groups, due ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=263823")[#text("to Serre")]#text(" (IV-23):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" ")#metadata(none) <tao-536c351ae15e5f5e3dc3>#text(" Let ")#mi("{p \\geq 5}")#text(" be a prime, and let ")#mi("{H}")#text(" be a closed subgroup of ")#mi("{SL_2({\\bf Z}_p)}")#text(", where ")#mi("{{\\bf Z}_p}")#text(" is the ring of ")#mi("{p}")#text("-adic integers. Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists a proper subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{SL_2({\\mathbf F}_p)}")#text(" such that ")#mi("{h \\text{ mod } p \\in H^{\\prime}}")#text(" for all ")#mi("{h \\in H}")#text(".")],
[#text("(ii) ")#mi("{H=SL_2({\\bf Z}_p)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" It is a standard fact that the reduction of ")#mi("{SL_2({\\bf Z}_p)}")#text(" mod ")#mi("{p}")#text(" is ")#mi("{SL_2({\\mathbf F}_p)}")#text(", hence (i) and (ii) cannot both hold.")

#text("Suppose that (i) fails, then for every ")#mi("{g \\in SL_2({\\bf Z}_p)}")#text(" there exists ")#mi("{h \\in H}")#text(" such that ")#mi("{h = g \\text{ mod } p}")#text(", which we write as")

#align(center)[#tao-fit-display[#mitex("h = g + O(p).")]]

#text("We now claim inductively that for any ")#mi("{j \\geq 0}")#text(" and ")#mi("{g \\in SL_2({\\bf Z}_p)}")#text(", there exists ")#mi("{h \\in SL_2({\\bf Z}_p)}")#text(" with ")#mi("{h = g + O(p^{j+1})}")#text("; taking limits as ")#mi("{j \\rightarrow \\infty}")#text(" using the closed nature of ")#mi("{H}")#text(" will then place us in option (ii).")

#text("The case ")#mi("{j=0}")#text(" is already handled, so now suppose ")#mi("{j=1}")#text(". If ")#mi("{g \\in SL_2({\\bf Z}_p)}")#text(", we see from the ")#mi("{j=0}")#text(" case that we can write ")#mi("{g = hg^{\\prime}}")#text(" where ")#mi("{h \\in H}")#text(" and ")#mi("{g^{\\prime} = 1+O(p)}")#text(". Thus to establish the ")#mi("{j=1}")#text(" claim it suffices to do so under the additional hypothesis that ")#mi("{g = 1+O(p)}")#text(".")

#text("First suppose that ")#mi("{g = 1 + pX + O(p^2)}")#text(" for some ")#mi("{X \\in M_2({\\bf Z}_p)}")#text(" with ")#mi("{X^2=0 \\text{ mod } p}")#text(". By the ")#mi("{j=0}")#text(" case, we can find ")#mi("{h \\in H}")#text(" of the form ")#mi("{h = 1 + X + pY + O(p^2)}")#text(" for some ")#mi("{Y \\in M_2({\\bf Z}_p)}")#text(". Raising to the ")#mi("{p^{th}}")#text(" power and using ")#mi("{X^2=0}")#text(" and ")#mi("{p \\geq 5 > 3}")#text(", we note that")

#tao-aligned(keep: true)[


#tao-math("h^p  & = 1 + \\binom{p}{1} X + \\binom{p}{1} pY + \\binom{p}{2} X pY + \\binom{p}{2} pY X", block: true)



#tao-math(" & + \\binom{p}{3} X pY X + O(p^2)", block: true)



#tao-math(" & = 1 + pX + O(p^2),", block: true)
]

#text("giving the claim in this case.")

#text("Any ")#mi("{2 \\times 2}")#text(" matrix of trace zero with coefficients in ")#mi("{{\\mathbf F}_p}")#text(" is a linear combination of ")#mi("{\\begin{pmatrix} 0 & 1 \\\\ 0 & 0 \\end{pmatrix}}")#text(", ")#mi("{\\begin{pmatrix} 0 & 0 \\\\ 1 & 0 \\end{pmatrix}}")#text(", ")#mi("{\\begin{pmatrix} 1 & 1 \\\\ -1 & -1 \\end{pmatrix}}")#text(" and is thus a sum of matrices that square to zero. Hence, if ")#mi("{g \\in SL_2({\\bf Z}_p)}")#text(" is of the form ")#mi("{g = 1 + O(p)}")#text(", then ")#mi("{g = 1 + pY + O(p^2)}")#text(" for some matrix ")#mi("{Y}")#text(" of trace zero, and thus one can write ")#mi("{g}")#text(" (up to ")#mi("{O(p^2)}")#text(" errors) as the finite product of matrices of the form ")#mi("{1 + pY + O(p^2)}")#text(" with ")#mi("{Y^2=0}")#text(". By the previous arguments, such a matrix ")#mi("{1+pY + O(p^2)}")#text(" lies in ")#mi("{H}")#text(" up to ")#mi("{O(p^2)}")#text(" errors, and hence ")#mi("{g}")#text(" does also. This completes the proof of the ")#mi("{j=1}")#text(" case.")

#text("Now suppose ")#mi("{j \\geq 2}")#text(" and the claim has already been proven for ")#mi("{j-1}")#text(". Arguing as before, it suffices to close the induction under the additional hypothesis that ")#mi("{g = 1 + O(p^j)}")#text(", thus we may write ")#mi("{g = 1 + p^j X + O(p^{j+1})}")#text(". By induction hypothesis, we may find ")#mi("{h \\in H}")#text(" with ")#mi("{h = 1 + p^{j-1} X + O(p^j)}")#text(". But then ")#mi("{h^p = 1 + p^j X + O(p^{j+1})}")#text(", and we are done. ")#mi("\\Box")

#text("We note a generalisation of Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(" that involves two groups ")#mi("{G_1,G_2}")#text(" rather than just one:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-da6fb65b6e434d9d8869>#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2}")#text(" of two nilpotent groups ")#mi("{G_1, G_2}")#text(". Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists group homomorphisms ")#mi("{\\eta_1: G^{\\prime}_1 \\rightarrow K}")#text(", ")#mi("{\\eta_2: G_2 \\rightarrow K}")#text(" into an abelian group ")#mi("{K = (K,+)}")#text(", with ")#mi("{\\eta_2}")#text(" non-trivial, such that ")#mi("{\\eta_1(h_1) + \\eta_2(h_2)=0}")#text(" for all ")#mi("{(h_1,h_2) \\in H}")#text(", where ")#mi("{G^{\\prime}_1 := \\{ h_1: (h_1,h_2) \\in H \\text{ for some } h_2 \\in G_2 \\}}")#text(" is the projection of ")#mi("{H}")#text(" to ")#mi("{G_1}")#text(".")],
[#text("(ii) ")#mi("{H = G^{\\prime}_1 \\times G_2}")#text(" for some subgroup ")#mi("{G^{\\prime}_1}")#text(" of ")#mi("{G_2}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Consider the group ")#mi("{\\{ h_2 \\in G_2: (1,h_2) \\in H \\}}")#text(". This is a subgroup of ")#mi("{G_2}")#text(". If it is all of ")#mi("{G_2}")#text(", then ")#mi("{H}")#text(" must be a Cartesian product ")#mi("{H = G^{\\prime}_1 \\times G_2}")#text(" and option (ii) holds. So suppose that this group is a proper subgroup of ")#mi("{G_2}")#text(". Applying Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(", we obtain a non-trivial group homomorphism ")#mi("{\\eta_2: G_2 \\rightarrow K}")#text(" into an abelian group ")#mi("{K = (K,+)}")#text(" such that ")#mi("{\\eta(h_2)=0}")#text(" whenever ")#mi("{(1,h_2) \\in H}")#text(". For any ")#mi("{h_1}")#text(" in the projection ")#mi("{G^{\\prime}_1}")#text(" of ")#mi("{H}")#text(" to ")#mi("{G_1}")#text(", there is thus a unique quantity ")#mi("{\\eta_1(h_1) \\in H}")#text(" such that ")#mi("{\\eta_1(h_1) + \\eta_2(h_2) = 0}")#text(" whenever ")#mi("{(h_1,h_2) \\in H}")#text(". One easily checks that ")#mi("{\\eta_1}")#text(" is a homomorphism, so we are in option (i).")

#text("Finally, it is clear that (i) and (ii) cannot both hold, since (i) places a non-trivial constraint on the second component ")#mi("{h_2}")#text(" of an element ")#mi("{(h_1,h_2) \\in H}")#text(" of ")#mi("{H}")#text(" for any fixed choice of ")#mi("{h_1}")#text(". ")#mi("\\Box")

#text("We also note a similar variant of Lemma ")#link(<tao-536c351ae15e5f5e3dc3>)[#text("5")]#text(", which is Lemme 10 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=387283")[#text("this paper of Serre")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" Let ")#mi("{p \\geq 5}")#text(" be a prime, and let ")#mi("{H}")#text(" be a closed subgroup of ")#mi("{SL_2({\\bf Z}_p) \\times SL_2({\\bf Z}_p)}")#text(". Then exactly one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists a proper subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{SL_2({\\mathbf F}_p) \\times SL_2({\\mathbf F}_p)}")#text(" such that ")#mi("{h \\text{ mod } p \\in H^{\\prime}}")#text(" for all ")#mi("{h \\in H}")#text(".")],
[#text("(ii) ")#mi("{H=SL_2({\\bf Z}_p) \\times SL_2({\\bf Z}_p)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" As in the proof of Lemma ")#link(<tao-536c351ae15e5f5e3dc3>)[#text("5")]#text(", (i) and (ii) cannot both hold. Suppose that (i) does not hold, then for any ")#mi("{g \\in SL_2({\\bf Z}_p)}")#text(" there exists ")#mi("{h_1 \\in H}")#text(" such that ")#mi("{h_1 = (g+O(p), 1 + O(p))}")#text(". Similarly, there exists ")#mi("{h_0 \\in H}")#text(" with ")#mi("{h_0 = (1+O(p), 1+O(p))}")#text(". Taking commutators of ")#mi("{h_1}")#text(" and ")#mi("{h_0}")#text(", we can find ")#mi("{h_2 \\in H}")#text(" with ")#mi("{h_2 = (g+O(p), 1+O(p^2))}")#text(". Continuing to take commutators with ")#mi("{h_0}")#text(" and extracting a limit (using compactness and the closed nature of ")#mi("{H}")#text("), we can find ")#mi("{h_\\infty \\in H}")#text(" with ")#mi("{h_\\infty = (g+O(p),1)}")#text(". Thus, the closed subgroup ")#mi("{\\{ g \\in SL_2({\\bf Z}_p): (g,1) \\in H \\}}")#text(" of ")#mi("{SL_2({\\bf Z}_p)}")#text(" does not obey conclusion (i) of Lemma ")#link(<tao-536c351ae15e5f5e3dc3>)[#text("5")]#text(", and must therefore obey conclusion (ii); that is to say, ")#mi("{H}")#text(" contains ")#mi("{SL_2({\\bf Z}_p) \\times \\{1\\}}")#text(". Similarly ")#mi("{H}")#text(" contains ")#mi("{\\{1\\} \\times SL_2({\\bf Z}_p)}")#text("; multiplying, we end up in conclusion (ii). ")#mi("\\Box")

#text("The most famous result of this type is of course the ")#link("https://en.wikipedia.org/wiki/Goursat%27s_lemma")[#text("Goursat lemma")]#text(", which we phrase here in a somewhat idiosyncratic manner to conform to the pattern of the other lemmas in this post:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Goursat lemma)")]#text(" ")#metadata(none) <tao-2622d2f670c77ec5dc69>#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2}")#text(" of two groups ")#mi("{G_1, G_2}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) ")#mi("{H}")#text(" is contained in ")#mi("{G^{\\prime}_1 \\times G^{\\prime}_2}")#text(" for some subgroups ")#mi("{G^{\\prime}_1}")#text(", ")#mi("{G^{\\prime}_2}")#text(" of ")#mi("{G_1, G_2}")#text(" respectively, with either ")#mi("{G^{\\prime}_1 \\subsetneq G_1}")#text(" or ")#mi("{G^{\\prime}_2 \\subsetneq G_2}")#text(" (or both).")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exist normal subgroups ")#mi("{N_1, N_2}")#text(" of ")#mi("{G_1, G_2}")#text(" respectively, not both trivial, such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1/N_1 \\times G_2/N_2}")#text(", where ")#mi("{\\pi: G_1 \\times G_2 \\rightarrow G_1/N_1 \\times G_2/N_2}")#text(" is the quotient map.")],
[#text("(iii) (Isomorphism) There is a group isomorphism ")#mi("{\\phi: G_1 \\rightarrow G_2}")#text(" such that ")#mi("{H = \\{ (g_1, \\phi(g_1)): g_1 \\in G_1\\}}")#text(" is the graph of ")#mi("{\\phi}")#text(". In particular, ")#mi("{G_1}")#text(" and ")#mi("{G_2}")#text(" are isomorphic.")]
)
]

#text("Here we almost have a trichotomy, because option (iii) is incompatible with both option (i) and option (ii). However, it is possible for options (i) and (ii) to simultaneously hold.")

#emph[#text("Proof:")]#text(" If either of the projections ")#mi("{\\pi_1: H \\rightarrow G_1}")#text(", ")#mi("{\\pi_2: H \\rightarrow G_2}")#text(" from ")#mi("{H}")#text(" to the factor groups ")#mi("{G_1,G_2}")#text(" (thus ")#mi("{\\pi_1(h_1,h_2)=h_1}")#text(" and ")#mi("{\\pi_2(h_1,h_2)=h_2}")#text(" fail to be surjective, then we are in option (i). Thus we may assume that these maps are surjective.")

#text("Next, if either of the maps ")#mi("{\\pi_1: H \\rightarrow G_1}")#text(", ")#mi("{\\pi_2: H \\rightarrow G_2}")#text(" fail to be injective, then at least one of the kernels ")#mi("{N_1 \\times \\{1\\} := \\mathrm{ker} \\pi_2}")#text(", ")#mi("{\\{1\\} \\times N_2 := \\mathrm{ker} \\pi_1}")#text(" is non-trivial. We can then descend down to the quotient ")#mi("{G_1/N_1 \\times G_2/N_2}")#text(" and end up in option (ii).")

#text("The only remaining case is when the group homomorphisms ")#mi("{\\pi_1, \\pi_2}")#text(" are both bijections, hence are group isomorphisms. If we set ")#mi("{\\phi := \\pi_2 \\circ \\pi_1^{-1}}")#text(" we end up in case (iii). ")#mi("\\Box")

#text("We can combine the Goursat lemma with Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(" to obtain a variant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9 (Nilpotent Goursat lemma)")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2}")#text(" of two nilpotent groups ")#mi("{G_1, G_2}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists ")#mi("{i=1,2}")#text(" and a non-trivial group homomorphism ")#mi("{\\eta_i: G_i \\rightarrow K}")#text(" such that ")#mi("{\\eta_i(h_i)=0}")#text(" for all ")#mi("{(h_1,h_2) \\in H}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exist normal subgroups ")#mi("{N_1, N_2}")#text(" of ")#mi("{G_1, G_2}")#text(" respectively, not both trivial, such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1/N_1 \\times G_2/N_2}")#text(".")],
[#text("(iii) (Isomorphism) There is a group isomorphism ")#mi("{\\phi: G_1 \\rightarrow G_2}")#text(" such that ")#mi("{H = \\{ (g_1, \\phi(g_1)): g_1 \\in G_1\\}}")#text(" is the graph of ")#mi("{\\phi}")#text(". In particular, ")#mi("{G_1}")#text(" and ")#mi("{G_2}")#text(" are isomorphic.")]
)
]

#emph[#text("Proof:")]#text(" If Lemma ")#link(<tao-2622d2f670c77ec5dc69>)[#text("8")]#text("(i) holds, then by applying Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(" we arrive at our current option (i). The other options are unchanged from Lemma ")#link(<tao-2622d2f670c77ec5dc69>)[#text("8")]#text(", giving the claim. ")#mi("\\Box")

#text("Now we present a lemma involving three groups ")#mi("{G_1,G_2,G_3}")#text(" that is known in ergodic theory contexts as the “Furstenberg-Weiss argument”, as an argument of this type arose in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1412607")[#text("this paper of Furstenberg and Weiss")]#text(", though perhaps it also implicitly appears in other contexts also. It has the remarkable feature of being able to enforce the abelian nature of one of the groups once the other options of the lemma are excluded.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Furstenberg-Weiss lemma)")]#text(" ")#metadata(none) <tao-07f7ab476bc3a83fad63>#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2 \\times G_3}")#text(" of three groups ")#mi("{G_1, G_2, G_3}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There is some proper subgroup ")#mi("{G^{\\prime}_3}")#text(" of ")#mi("{G_3}")#text(" and some ")#mi("{i=1,2}")#text(" such that ")#mi("{h_3 \\in G^{\\prime}_3}")#text(" whenever ")#mi("{(h_1,h_2,h_3) \\in H}")#text(" and ")#mi("{h_i = 1}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exists a non-trivial normal subgroup ")#mi("{N_3}")#text(" of ")#mi("{G_3}")#text(" with ")#mi("{G_3/N_3}")#text(" abelian, such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1 \\times G_2 \\times G_3/N_3}")#text(", where ")#mi("{\\pi: G_1 \\times G_2 \\times G_3 \\rightarrow G_1 \\times G_2 \\times G_3/N_3}")#text(" is the quotient map.")],
[#text("(iii) ")#mi("{G_3}")#text(" is abelian.")]
)
]

#emph[#text("Proof:")]#text(" If the group ")#mi("{\\{ h_3 \\in G_3: (1,h_2,h_3) \\in H \\}}")#text(" is a proper subgroup of ")#mi("{G_3}")#text(", then we are in option (i) (with ")#mi("{i=1}")#text("), so we may assume that")

#align(center)[#tao-fit-display[#mitex("\\{ h_3 \\in G_3: (1,h_2,h_3) \\in H \\} = G.")]]

#text("Similarly we may assume that")

#align(center)[#tao-fit-display[#mitex("\\{ h_3 \\in G_3: (h_1,1,h_3) \\in H \\} = G.")]]

#text("Now let ")#mi("{g_3,g^{\\prime}_3}")#text(" be any two elements of ")#mi("{G}")#text(". By the above assumptions, we can find ")#mi("{h_1 \\in G_1, h_2 \\in G_2}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("(1, h_2, g_3) \\in H")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(h_1,1, g^{\\prime}_3) \\in H.")]]

#text("Taking commutators to eliminate the ")#mi("{h_1,h_2}")#text(" terms, we conclude that")

#align(center)[#tao-fit-display[#mitex("(1, 1, [g_3,g^{\\prime}_3]) \\in H.")]]

#text("Thus the group ")#mi("{\\{ h_3 \\in G_3: (1,1,h_3) \\in H \\}}")#text(" contains every commutator ")#mi("{[g_3,g^{\\prime}_3]}")#text(", and thus contains the entire group ")#mi("{[G_3,G_3]}")#text(" generated by these commutators. If ")#mi("{G_3}")#text(" fails to be abelian, then ")#mi("{[G_3,G_3]}")#text(" is a non-trivial normal subgroup of ")#mi("{G_3}")#text(", and ")#mi("{H}")#text(" now arises from ")#mi("{G_1 \\times G_2 \\times G_3/[G_3,G_3]}")#text(" in the obvious fashion, placing one in option (ii). Hence the only remaining case is when ")#mi("{G_3}")#text(" is abelian, giving us option (iii). ")#mi("\\Box")

#text("As before, we can combine this with previous lemmas to obtain a variant in the nilpotent case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Nilpotent Furstenberg-Weiss lemma)")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2 \\times G_3}")#text(" of three nilpotent groups ")#mi("{G_1, G_2, G_3}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There exists ")#mi("{i=1,2}")#text(" and group homomorphisms ")#mi("{\\eta_i: G^{\\prime}_i \\rightarrow K}")#text(", ")#mi("{\\eta_3: G_3 \\rightarrow K}")#text(" for some abelian group ")#mi("{K = (K,+)}")#text(", with ")#mi("{\\eta_3}")#text(" non-trivial, such that ")#mi("{\\eta_i(h_i) + \\eta_3(h_3) = 0}")#text(" whenever ")#mi("{(h_1,h_2,h_3) \\in H}")#text(", where ")#mi("{G^{\\prime}_i}")#text(" is the projection of ")#mi("{H}")#text(" to ")#mi("{G_i}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exists a non-trivial normal subgroup ")#mi("{N_3}")#text(" of ")#mi("{G_3}")#text(", such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1 \\times G_2 \\times G_3/N_3}")#text(".")],
[#text("(iii) ")#mi("{G_3}")#text(" is abelian.")]
)
]

#text("Informally, this lemma asserts that if ")#mi("{(h_1,h_2,h_3)}")#text(" is a variable ranging in some subgroup ")#mi("{G_1 \\times G_2 \\times G_3}")#text(", then either (i) there is a non-trivial abelian equation that constrains ")#mi("{h_3}")#text(" in terms of either ")#mi("{h_1}")#text(" or ")#mi("{h_2}")#text("; (ii) ")#mi("{h_3}")#text(" is not fully determined by ")#mi("{h_1}")#text(" and ")#mi("{h_2}")#text("; or (iii) ")#mi("{G_3}")#text(" is abelian.")

#emph[#text("Proof:")]#text(" Applying Lemma ")#link(<tao-07f7ab476bc3a83fad63>)[#text("10")]#text(", we are already done if conclusions (ii) or (iii) of that lemma hold, so suppose instead that conclusion (i) holds for say ")#mi("{i=1}")#text(". Then the group ")#mi("{\\{ (h_1,h_3) \\in G_1 \\times G_3: (h_1,h_2,h_3) \\in H \\text{ for some } h_2 \\in G_2 \\}}")#text(" is not of the form ")#mi("{G^{\\prime}_2 \\times G_3}")#text(", since it only contains those ")#mi("{(1,h_3)}")#text(" with ")#mi("{h_3 \\in G^{\\prime}_3}")#text(". Applying Lemma ")#link(<tao-da6fb65b6e434d9d8869>)[#text("6")]#text(", we obtain group homomorphisms ")#mi("{\\eta_1: G^{\\prime}_1 \\rightarrow K}")#text(", ")#mi("{\\eta_3: G_3 \\rightarrow K}")#text(" into an abelian group ")#mi("{K= (K,+)}")#text(", with ")#mi("{\\eta_3}")#text(" non-trivial, such that ")#mi("{\\eta_1(h_1) + \\eta_3(h_3) = 0}")#text(" whenever ")#mi("{(h_1,h_2,h_3) \\in H}")#text(", placing us in option (i). ")#mi("\\Box")

#text("The Furstenberg-Weiss argument is often used (though not precisely in this form) to establish that certain key structure groups arising in ergodic theory are abelian; see for instance Proposition 6.3(1) of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2150389")[#text("this paper of Host and Kra")]#text(" for an example.")

#text("One can get more structural control on ")#mi("{H}")#text(" in the Furstenberg-Weiss lemma in option (iii) if one also broadens options (i) and (ii):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 12 (Variant of Furstenberg-Weiss lemma)")]#text(" ")#metadata(none) <tao-72fa85fb3a8d4184e00a>#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2 \\times G_3}")#text(" of three groups ")#mi("{G_1, G_2, G_3}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There is some proper subgroup ")#mi("{G^{\\prime}_{ij}}")#text(" of ")#mi("{G_i \\times G_j}")#text(" for some ")#mi("{1 \\leq i < j \\leq 3}")#text(" such that ")#mi("{(h_i,h_j) \\in G^{\\prime}_{ij}}")#text(" whenever ")#mi("{(h_1,h_2,h_3) \\in H}")#text(". (In other words, the projection of ")#mi("{H}")#text(" to ")#mi("{G_i \\times G_j}")#text(" is not surjective.)")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exists a normal ")#mi("{N_1, N_2, N_3}")#text(" of ")#mi("{G_1, G_2, G_3}")#text(" respectively, not all trivial, such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1/N_1 \\times G_2/N_2 \\times G_3/N_3}")#text(", where ")#mi("{\\pi: G_1 \\times G_2 \\times G_3 \\rightarrow G_1/N_1 \\times G_2/N_2 \\times G_3/N_3}")#text(" is the quotient map.")],
[#text("(iii) ")#mi("{G_1,G_2,G_3}")#text(" are abelian and isomorphic. Furthermore, there exist isomorphisms ")#mi("{\\phi_1: G_1 \\rightarrow K}")#text(", ")#mi("{\\phi_2: G_2 \\rightarrow K}")#text(", ")#mi("{\\phi_3: G_3 \\rightarrow K}")#text(" to an abelian group ")#mi("{K = (K,+)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("H = \\{ (g_1,g_2,g_3) \\in G_1 \\times G_2 \\times G_3: \\phi(g_1) + \\phi(g_2) + \\phi(g_3) = 0 \\}.")]]]
)
]

#text("The ability to encode an abelian additive relation in terms of group-theoretic properties is vaguely reminiscent of the ")#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/")[#text("group configuration theorem")]#text(".")

#emph[#text("Proof:")]#text(" We apply Lemma ")#link(<tao-07f7ab476bc3a83fad63>)[#text("10")]#text(". Option (i) of that lemma implies option (i) of the current lemma, and similarly for option (ii), so we may assume without loss of generality that ")#mi("{G_3}")#text(" is abelian. By permuting we may also assume that ")#mi("{G_1,G_2}")#text(" are abelian, and will use additive notation for these groups.")

#text("We may assume that the projections of ")#mi("{H}")#text(" to ")#mi("{G_1 \\times G_2}")#text(" and ")#mi("{G_3}")#text(" are surjective, else we are in option (i). The group ")#mi("{\\{ g_3 \\in G_3: (1,1,g_3) \\in H\\}}")#text(" is then a normal subgroup of ")#mi("{G_3}")#text("; we may assume it is trivial, otherwise we can quotient it out and be in option (ii). Thus ")#mi("{H}")#text(" can be expressed as a graph ")#mi("{\\{ (h_1,h_2,\\phi(h_1,h_2)): h_1 \\in G_1, h_2 \\in G_2\\}}")#text(" for some map ")#mi("{\\phi: G_1 \\times G_2 \\rightarrow G_3}")#text(". As ")#mi("{H}")#text(" is a group, ")#mi("{\\phi}")#text(" must be a homomorphism, and we can write it as ")#mi("{\\phi(h_1+h_2) = -\\phi_1(h_1) - \\phi_2(h_2)}")#text(" for some homomorphisms ")#mi("{\\phi_1: G_1 \\rightarrow G_3}")#text(", ")#mi("{\\phi_2: G_2 \\rightarrow G_3}")#text(". Thus elements ")#mi("{(h_1,h_2,h_3)}")#text(" of ")#mi("{H}")#text(" obey the constraint ")#mi("{\\phi_1(h_1) + \\phi_2(h_2) + h_3 = 0}")#text(".")

#text("If ")#mi("{\\phi_1}")#text(" or ")#mi("{\\phi_2}")#text(" fails to be injective, then we can quotient out by their kernels and end up in option (ii). If ")#mi("{\\phi_1}")#text(" fails to be surjective, then the projection of ")#mi("{H}")#text(" to ")#mi("{G_2 \\times G_3}")#text(" also fails to be surjective (since for ")#mi("{(h_1,h_2,h_3) \\in H}")#text(", ")#mi("{\\phi_2(h_2) + h_3}")#text(" is now constrained to lie in the range of ")#mi("{\\phi_1}")#text(") and we are in option (i). Similarly if ")#mi("{\\phi_2}")#text(" fails to be surjective. Thus we may assume that the homomorphisms ")#mi("{\\phi_1,\\phi_2}")#text(" are bijective and thus group isomorphisms. Setting ")#mi("{\\phi_3}")#text(" to the identity, we arrive at option (iii). ")#mi("\\Box")

#text("Combining this lemma with Lemma ")#link(<tao-46273d7c3f42babd4165>)[#text("3")]#text(", we obtain a nilpotent version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 13 (Variant of nilpotent Furstenberg-Weiss lemma)")]#text(" ")#metadata(none) <tao-85beb2723c1001175332>#text(" Let ")#mi("{H}")#text(" be a subgroup of a product ")#mi("{G_1 \\times G_2 \\times G_3}")#text(" of three groups ")#mi("{G_1, G_2, G_3}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There are homomorphisms ")#mi("{\\eta_i: G_i \\rightarrow K}")#text(", ")#mi("{\\eta_j: G_j \\rightarrow K}")#text(" to some abelian group ")#mi("{K =(K,+)}")#text(" for some ")#mi("{1 \\leq i < j \\leq 3}")#text(", with ")#mi("{\\eta_i, \\eta_j}")#text(" not both trivial, such that ")#mi("{\\eta_i(h_i) + \\eta_j(h_j) = 0}")#text(" whenever ")#mi("{(h_1,h_2,h_3) \\in H}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" too large) There exists a normal ")#mi("{N_1, N_2, N_3}")#text(" of ")#mi("{G_1, G_2, G_3}")#text(" respectively, not all trivial, such that ")#mi("{H = \\pi^{-1}(H^{\\prime})}")#text(" arises from a subgroup ")#mi("{H^{\\prime}}")#text(" of ")#mi("{G_1/N_1 \\times G_2/N_2 \\times G_3/N_3}")#text(", where ")#mi("{\\pi: G_1 \\times G_2 \\times G_3 \\rightarrow G_1/N_1 \\times G_2/N_2 \\times G_3/N_3}")#text(" is the quotient map.")],
[#text("(iii) ")#mi("{G_1,G_2,G_3}")#text(" are abelian and isomorphic. Furthermore, there exist isomorphisms ")#mi("{\\phi_1: G_1 \\rightarrow K}")#text(", ")#mi("{\\phi_2: G_2 \\rightarrow K}")#text(", ")#mi("{\\phi_3: G_3 \\rightarrow K}")#text(" to an abelian group ")#mi("{K = (K,+)}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("H = \\{ (g_1,g_2,g_3) \\in G_1 \\times G_2 \\times G_3: \\phi(g_1) + \\phi(g_2) + \\phi(g_3) = 0 \\}.")]]]
)
]

#text("Here is another variant of the Furstenberg-Weiss lemma, attributed to Serre ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=419358")[#text("by Ribet")]#text(" (see Lemma 3.3):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14 (Serre’s lemma)")]#text(" Let ")#mi("{H}")#text(" be a subgroup of a finite product ")#mi("{G_1 \\times \\dots \\times G_k}")#text(" of groups ")#mi("{G_1,\\dots,G_k}")#text(" with ")#mi("{k \\geq 2}")#text(". Then one of the following hold:")

#list(
[#text("(i) (")#mi("{H}")#text(" too small) There is some proper subgroup ")#mi("{G^{\\prime}_{ij}}")#text(" of ")#mi("{G_i \\times G_j}")#text(" for some ")#mi("{1 \\leq i < j \\leq k}")#text(" such that ")#mi("{(h_i,h_j) \\in G^{\\prime}_{ij}}")#text(" whenever ")#mi("{(h_1,\\dots,h_k) \\in H}")#text(".")],
[#text("(ii) (")#mi("{H}")#text(" too large) One has ")#mi("{H = G_1 \\times \\dots \\times G_k}")#text(".")],
[#text("(iii) One of the ")#mi("{G_i}")#text(" has a non-trivial abelian quotient ")#mi("{G_i/N_i}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The claim is trivial for ")#mi("{k=2}")#text(" (and we don’t need (iii) in this case), so suppose that ")#mi("{k \\geq 3}")#text(". We can assume that each ")#mi("{G_i}")#text(" is a ")#link("https://en.wikipedia.org/wiki/Perfect_group")[#text("perfect group")]#text(", ")#mi("{G_i = [G_i,G_i]}")#text(", otherwise we can quotient out by the commutator and arrive in option (iii). Similarly, we may assume that all the projections of ")#mi("{H}")#text(" to ")#mi("{G_i \\times G_j}")#text(", ")#mi("{1 \\leq i < j \\leq k}")#text(" are surjective, otherwise we are in option (i).")

#text("We now claim that for any ")#mi("{1 \\leq j < k}")#text(" and any ")#mi("{g_k \\in G_k}")#text(", one can find ")#mi("{(h_1,\\dots,h_k) \\in H}")#text(" with ")#mi("{h_i=1}")#text(" for ")#mi("{1 \\leq i \\leq j}")#text(" and ")#mi("{h_k = g_k}")#text(". For ")#mi("{j=1}")#text(" this follows from the surjectivity of the projection of ")#mi("{H}")#text(" to ")#mi("{G_1 \\times G_k}")#text(". Now suppose inductively that ")#mi("{1 < j < k}")#text(" and the claim has already been proven for ")#mi("{j-1}")#text(". Since ")#mi("{G_k}")#text(" is perfect, it suffices to establish this claim for ")#mi("{g_k}")#text(" of the form ")#mi("{g_k = [g^{\\prime}_k, g^{\\prime\\prime}_k]}")#text(" for some ")#mi("{g^{\\prime}_k, g^{\\prime\\prime}_k \\in G_k}")#text(". By induction hypothesis, we can find ")#mi("{(h^{\\prime}_1,\\dots,h^{\\prime}_k) \\in H}")#text(" with ")#mi("{h^{\\prime}_i = 1}")#text(" for ")#mi("{1 \\leq i < j}")#text(" and ")#mi("{h^{\\prime}_k = g^{\\prime}_k}")#text(". By surjectivity of the projection of ")#mi("{H}")#text(" to ")#mi("{G_j \\times G_k}")#text(", one can find ")#mi("{(h^{\\prime\\prime}_1,\\dots,h^{\\prime\\prime}_k) \\in H}")#text(" with ")#mi("{h^{\\prime\\prime}_j = 1}")#text(" and ")#mi("{h^{\\prime\\prime}_k=g^{\\prime\\prime}_k}")#text(". Taking commutators of these two elements, we obtain the claim.")

#text("Setting ")#mi("{j = k-1}")#text(", we conclude that ")#mi("{H}")#text(" contains ")#mi("{1 \\times \\dots \\times 1 \\times G_k}")#text(". Similarly for permutations. Multiplying these together we see that ")#mi("{H}")#text(" contains all of ")#mi("{G_1 \\times \\dots \\times G_k}")#text(", and we are in option (ii). ")#mi("\\Box")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c8b535ba19730c35a11a54e0f6a172b8257b3231d3f6bcb585012a98f16a4c7-b074f52a1020db534fef6621b105be8a1ffe96a2efd905bdf88cb80e35925a68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ehud Schreiber")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625771")[#strong[#text("Ehud Schreiber")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2021")])]

#text("Hi,")

#text("it seems a prime is missing in Lemma 8 (i), where it shows")#linebreak()#text(" h_3 \\in G_3")

#text("Thanks,")#linebreak()#text(" Ehud.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625774")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2021")])]

#text("Goursat’s lemma and the generalizations to more than two factors (and variants involving Lie algebras) arise fairly frequently in arithmetic geometry.")

#text("The earliest reference I know is Serre’s 1972 paper “Propriétés galoisiennes des points d’ordre fini des courbes elliptiques” (see section 6 there), then there are papers of Ribet and others. Katz uses extensively such ideas under the name “Goursat-Kolchin-Ribet criterion” (in his book “Exponential sums and differential equations” for instance), but I never tracked Kolchin’s contribution.")#linebreak()#text(" It’s one of the key underlying mechanisms in estimates for multiple correlations of translated Kloosterman sums, among many similar applications to analytic number theory.")

#text("I didn’t know the Furstenberg-Weiss reference, but the argument (with the commutator trick) does seem related to Lemma 3.3 in Ribet’s 1975 paper “On ell-adic representations attached to modular forms” (who attributes the proof to Serre); this is then used to get statements involving finite products with any number of factors.")

#text("In (maybe) similar spirit, number theory often uses statements like “A subgroup of SL_2(Z_p) which surjects to SL_2(F_p) is equal to SL_2(Z_p)” (which is true for p at least 5, if I remember correctly) to reduce problems about profinite groups to the case of finite groups. This also generalizes to other groups, in suitable form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625823")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2021")])]

#text("Thanks for these references! I have incorporated these results into the text.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d7e300690de87a747451b2c79ec870ded5b49d568309f2ccab5387f8b3c2c01e-916164f838f4ccb9ec144814e215a21fc48c70c9942c33e475d8d46098f1e5ff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of P")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625780")[#strong[#text("P")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2021")])]

#text("Should the first instance of “or obeys” be there?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09f5e42236f84baa161d4fb1e1e9244d4cb35e302851782309faff583966b430-11002f0e725618ae2423a91c1c45314a122ea65c45e8746a0fb5a1a392084072.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul F. Dietz (@PaulFDietz)")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625828")[#strong[#text("Paul F. Dietz (@PaulFDietz)")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2021")])]

#text("“Combining this lemma with Lemma \\reF{nilp}, we obtain a nilpotent version:”")

#text("Typo")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64aee548614c8a74c608c21996cabb6e94ed99ef091e7d2455db13bb97839c54-355b8af6f245e801d2e76b8092d814af9bdb38bb16c66d8b4fc5eda62de7d1bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Crystalline")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625887")[#strong[#text("Crystalline")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2021")])]

#text("In the proof of Lemma 5, there is a typo. “Suppose that (i) fails, then for every g \\in SL_2(\\ZZ_p) there exists h \\in SL_2(\\ZZ_p)” , you mean h \\in H.")

#text("Also, when you deal with the case g = 1+pX+O(p^2), you note that one can find an h of the form 1+X+pY+O(p^2), and you then say that, raising to the pth power and using X^2=0 and p \\geq 5, we get that h^p = 1+ pX +O(p^2).")

#text("I managed to show this by explicitly writing down a recursive formula for the coefficients of h^n, n \\geq 3. It wasn’t hard, but there was still some computations to be made, so I wanted to ask, is there a direct way to see that h^p = 1+pX+O(p^2), without writing down a formula for the coefficients?")

#emph[#text("[Corrected and expanded, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625916")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2021")])]

#text("In the proof of Lemma 5,there’s a repeated word: “… such such …”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-625997")[#strong[#text("Goursat and Furstenberg-Weiss type lemmas – scroo0ooge")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2021")]

#text("[…] the group is locally compact and is closed, one can take the homomorphism in Lemma 3 to be continuous, and by using Pontryagin duality one can also take the target group to be the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Otto")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-626041")[#strong[#text("Otto")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")])]

#text("A minor typo founded at the end of the proof of lemma 12: “similarly” instead of “simiarly”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-626084")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2021")])]

#text("In the proof of lemma 6 : “One easily checcks that” “One easily checks that”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-626420")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2021")])]

#text("Dear Pro.Tao,")#linebreak()#text(" Recently, I have heard of four mathematicians and even AI programs solving Navier Stokes equation.")#linebreak()#text(" Today, I have some advice:")#linebreak()#text(" + Navier Stokes problem is water or other liquid problem.")#linebreak()#text(" + Firestly, I’d like to say that nature itself is answer and number.For example, a day has 24 hours, a year has 12 months , a year has 4 seasons, ….and all human beings were born after 9 months and 10 days. You notice that these numbers are even number.")#linebreak()#text(" + We know that water boils at 100°C.")#linebreak()#text(" + I guarantee that “finite time blow up Navier Stokes equations that you concern is even number.")#linebreak()#text(" +And today, I’d like to conclude that great and super science without philosophy will never be successful.")#linebreak()#text(" +Why do all mathematicians in the world keep their heads solving Navier Stokes with one way?")#linebreak()#text(" + Likely, you close a screw, you must turn it from left to right.When you open it , you must anticlockwise(from right to left).")#linebreak()#text(" Navier Stokes is water.We must find something is opposite it. That’s fire!")#linebreak()#text(" +Water is plentiful of shapes and fire is also like")#linebreak()#text(" + Water can rise object up and fire can also like this.")#linebreak()#text(" + You imagine you have an ancient oil lamp. First, its flame is very little and then 1 minute, it blow up a big flame. Movement of fire is also like movement of water.")#linebreak()#text(" +Hundreds of years, all scientists in the world only research of water, no one research of fire.")#linebreak()#text(" + Navier Stokes invented water equation. Why do not you invent fire equation and solve it? Secrete of water is also secrete of fire.( Fire can turn into water).")#linebreak()#text(" +About this, you should use Topology knowledge to solve it.")#linebreak()#text(" +Navier Stokes itself is looking for you, you can not choose it although you are genuis . Navier Stokes is very suitable for you.")#linebreak()#text(" +Likely, a man wins Jackpot lotterly ( itself numbers choose its owner, no one can choose number)")#linebreak()#text(" +Today, I confirm that your Navier Stokes work is absolutely right.I say the truth. You never be doubtful of your work . You try little, you are the only mathematician in the world being successfull in solving Navier Stokes in this year.")#linebreak()#text(" + wake up and go! Continue! A ripe fruit is waiting for you. This is your duty and mission.!")#linebreak()#text(" * You do not need to know me who is . You close your eyes, you will see and understand. I always help you. I am not a mathematician , I am a superman in other field.")#linebreak()#text(" Best wishes,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-629085")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2021")])]

#text("Wise words.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Villoria")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-626603")[#strong[#text("Michael Villoria")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2021")])]

#text("Hi, Professor Tao! I’m a huge fan, keep up the great work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-628940")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2021")])]

#text("“Next, if either of the maps ")#mi("{\\pi_1: H \\rightarrow G_1}")#text(", ")#mi("{\\pi_2: H \\rightarrow G_2}")#text(" fail to be injective, then at least one of the kernels ")#mi("{N_1 := \\mathrm{ker} \\pi_1}")#text(", ")#mi("{N_2 := \\mathrm{ker} \\pi_2}")#text(" is non-trivial. We can then descend down to the quotient ")#mi("{G_1/N_1 \\times G_2/N_2}")#text(" and end up in option (ii).”")

#text("Isn’t it exactly the other way around? ")#mi("N_1")#text(" is a subgroup of ")#mi("H")#text(" of the form ")#mi("\\{e\\}\\times N_1^{\\prime}")#text(" for some ")#mi("N_1^{\\prime}\\lhd G_2")#text("; ")#mi("N_2")#text(" is a subgroup of ")#mi("H")#text(" of the form ")#mi("N_2^{\\prime}\\times \\{e\\}")#text(" for some ")#mi("N_2^{\\prime}\\lhd G_1")#text(". Then we can descend down to the quotient ")#mi("G_1/N_2^{\\prime}\\times G_2/N_1^{\\prime}")#text(" and end up in option (ii).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebac2346a2f5f3c7d26a7388a04413acee6a4e18b404d8173ec2c9e8f09f5536-9744003d1a83accb9aeb6dd0500dfb0af215373d012109dc338eba8a08f34e72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sabino Lamonaca")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-629026")[#strong[#text("Sabino Lamonaca")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2021")])]

#text("Very nice work prof Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-629079")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2021")])]

#text("There is a typo in the (ii) of Lemma 12: a comma is missing between G2 and G3 i.e. “of G1, G2, G3 respectively”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-629127")[#strong[#text("Steve")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2021")])]

#text("I my previous post I have forgotten to point out that the same typo occurs in the Corollary 13 (ii) (H too large): “of G1, G2, G3”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eacfc8e1210258a6fb0996a7c582e438589232b43b45f70474202d9a965a6fbf-a7c24908489e041415a74c3a76051f157aa9a8e342523a18283b9e1d064c10dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre de la Harpe")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-634352")[#strong[#text("Pierre de la Harpe")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2021")])]

#text("Goursat lemma (= Lemma 8), often stated in a slighlty more precise form,")#linebreak()#text(" has appeared several times and has been forgotten several times.")#linebreak()#text(" Some references and the standard proof in the attached pdf.")

#text("/Users/laharpe/Desktop/GoursatL19sept21.pdf")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02986eacbd76645596d6dff15d41d252362cf60cf362152dd040b3b802ccd582-400479df1d44563dbbc7c81b9a12e52cd17e3aae1ce8a6f3d886082801f7b680.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rene Brice Amougou")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-642691")[#strong[#text("Rene Brice Amougou")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2022")])]

#text("Please can I have pdf, I am author of Goursat Matrix")#linebreak()#text(" University of Yaounde Cameroon")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eacfc8e1210258a6fb0996a7c582e438589232b43b45f70474202d9a965a6fbf-a7c24908489e041415a74c3a76051f157aa9a8e342523a18283b9e1d064c10dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre de la Harpe")]], [#link("https://terrytao.wordpress.com/2021/05/07/goursat-and-furstenberg-weiss-type-lemmas/#comment-642693")[#strong[#text("Pierre de la Harpe")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2022")])]

#text("\\documentclass[10pt,leqno]{amsart}")

#text("\\usepackage{amsmath}")#linebreak()#text(" \\usepackage{enumerate,enumitem}")

#text("\\newtheorem{thm}{Theorem}")

#text("\\newtheorem{prop}[thm]{Proposition}")#linebreak()#text(" \\newtheorem{bon}[thm]{Bonus}")

#text("\\theoremstyle{definition}")#linebreak()#text(" \\newtheorem{exe}[thm]{Example}")

#text("\\title[Subgroups of products]")#linebreak()#text(" {Subgroups of products")#linebreak()#text(" \\\\")#linebreak()#text(" Goursat lemma}")

#text("\\date{December 14, 2014, Pierre de la Harpe}")

#text("\\begin{document}")

#text("\\maketitle")

#text("\\section{Subgroups of products of two groups}")

#text("The first example below is straightforward, but less particular than it looks at first sight.")

#text("\\begin{exe}")#linebreak()#text(" \\label{d’uniso}")#linebreak()#text(" Consider two isomorphic groups $G_1, G_2$")#linebreak()#text(" and an isomorphism $\\varphi$ from $G_1$ onto $G_2$.")#linebreak()#text(" \\par")#linebreak()#text(" The graph of $\\varphi$")#linebreak()#text(" $$")#linebreak()#text(" \\{ (g_1,g_2) \\in G_1 \\times G_2 \\mid g_2 = \\varphi(g_1) \\}")#linebreak()#text(" $$")#linebreak()#text(" is a subgroup of the direct product $G_1 \\times G_2$.")#linebreak()#text(" \\end{exe}")

#text("Example \\ref{d’uniso} is indeed the skeleton of:")

#text("\\begin{exe}")#linebreak()#text(" \\label{gonfle}")#linebreak()#text(" For $j = 1,2$, let $G_j$ be a group, $T_j$ a subgroups of $G_j$")#linebreak()#text(" and $S_j$ a normal subgroup of $T_j$.")#linebreak()#text(" Assume that there exists an isomorphism $\\varphi : T_1/S_1 \\to T_2/S_2$.")#linebreak()#text(" Let $\\pi : T_1 \\times T_2 \\to T_1/S_1 \\times T_2/S_2$ be the quotient homomorphism.")#linebreak()#text(" \\par")#linebreak()#text(" Then")#linebreak()#text(" $$")#linebreak()#text(" H := \\pi^{-1} \\left( \\Big\\{ (h_1 \\times h_2) \\in T_1/S_1 \\times T_2/S_2")#linebreak()#text(" \\hskip.1cm \\Big\\vert \\hskip.1cm")#linebreak()#text(" h_2 = \\varphi(h_1) \\Big\\} \\right)")#linebreak()#text(" $$")#linebreak()#text(" is a subgroup of $T_1 \\times T_2$,")#linebreak()#text(" and a fortiori a subgroup of $G_1 \\times G_2$.")#linebreak()#text(" \\end{exe}")

#text("\\noindent")#linebreak()#text(" \\emph{Remark.}")#linebreak()#text(" In Example \\ref{d’uniso}, suppose that $G_1$ and $G_2$ are abelian;")#linebreak()#text(" then $G_1 \\times G_2$ is abelian (!) and the graph of $\\varphi$")#linebreak()#text(" is therefore trivially normal there.")#linebreak()#text(" \\par")#linebreak()#text(" It follows that, in Example \\ref{gonfle}, if moreover")#linebreak()#text(" $S_j$ is normal in $G_j$ and $T_j/S_j$ is central in $G_j/S_j$,")#linebreak()#text(" for $j=1,2$,")#linebreak()#text(" then $H$ is normal in $G_1 \\times G_2$.")

#text("\\vskip.2cm")

#text("It happens that Example \\ref{gonfle} is the general case:")#linebreak()#text(" this is the statement sometimes known as “Goursat Lemma”:")

#text("\\begin{prop}")#linebreak()#text(" \\label{Goursat}")#linebreak()#text(" Let $H$ be a subgroup of the product $G_1 \\times G_2$ of two groups.")#linebreak()#text(" For $j=1,2$, let $p_j : G_1 \\times G_2 \\to G_j$ denote the canonical projection, and set")#linebreak()#text(" \\begin{equation*}")#linebreak()#text(" \\aligned")#linebreak()#text(" &T_j = p_j(H),")#linebreak()#text(" \\\\")#linebreak()#text(" &S_j = G_j \\cap H .")#linebreak()#text(" \\endaligned")#linebreak()#text(" \\end{equation*}")#linebreak()#text(" Then:")#linebreak()#text(" \\begin{enumerate}[noitemsep,label=(\\arabic*)]")#linebreak()#text(" \\item\\label{1}")#linebreak()#text(" $S_j$ is a normal subgroup of $T_j$;")#linebreak()#text(" \\item\\label{2}")#linebreak()#text(" $T_1/S_1$ and $T_2/S_2$ are isomorphic;")#linebreak()#text(" \\item\\label{3}")#linebreak()#text(" there exists an isomorphism $\\varphi : T_1/S_1 \\to T_2/S_2$ such that")#linebreak()#text(" $H$ is as in Example \\ref{gonfle}.")#linebreak()#text(" \\end{enumerate}")#linebreak()#text(" \\end{prop}")

#text("\\begin{proof}")#linebreak()#text(" Claim \\ref{1} is straightforward.")#linebreak()#text(" Observe that $$")#linebreak()#text(" S_1 \\times S_2 \\le H \\le T_1 \\times T_2 \\le G .")#linebreak()#text(" $$")#linebreak()#text(" \\par")

#text("Let $g_1 \\in T_1$.")#linebreak()#text(" There exists $g_2 \\in T_2$ such that $(g_1, g_2) \\in H$.")#linebreak()#text(" On the one hand,")#linebreak()#text(" if $g’_2 \\in T_2$ is also such that $(g_1, g’_2) \\in S$,")#linebreak()#text(" then\\footnote{The subgroup $\\{1\\} \\times S_2$ of $G_1 \\times G_2$ is")#linebreak()#text(" abusively denoted by $S_2$ again.}")#linebreak()#text(" $(g_1, g_2)^{-1}(g_1, g’_2) = (1, g_2^{-1}g’_2) \\in S_2$,")#linebreak()#text(" so that $g_2$ and $g’_2$ have the same image in $T_2/S_2$;")#linebreak()#text(" denote it by $\\widetilde \\varphi(g_1)$, so that we have")#linebreak()#text(" a homomorphism $\\widetilde \\varphi : T_1 \\to T_2/S_2$.")#linebreak()#text(" On the other hand,")#linebreak()#text(" if $g_1 \\in S_1$,")#linebreak()#text(" then $\\widetilde \\varphi (g_1) = 1$;")#linebreak()#text(" thus we have a homomorphism $\\varphi : T_1/S_1 \\to T_2/S_2$,")#linebreak()#text(" defined by $\\varphi(g_1S_1) = \\widetilde \\varphi(g_1)$ for all $g_1 \\in T_1$.")#linebreak()#text(" \\par")#linebreak()#text(" Similarly, we have a group homomorphism $\\psi : T_2/S_2 \\to T_1/S_1$.")#linebreak()#text(" It follows from their definitions that $\\psi$ and $\\varphi$ are inverse to each other.")#linebreak()#text(" The proposition follows.")#linebreak()#text(" \\end{proof}")

#text("\\begin{bon}")#linebreak()#text(" Let the notation be as in Example \\ref{gonfle} and Proposition \\ref{Goursat}.")#linebreak()#text(" The following are equivalent:")#linebreak()#text(" \\begin{enumerate}[noitemsep,label=(\\roman*)]")#linebreak()#text(" \\item\\label{i}")#linebreak()#text(" $H$ is normal in $G$,")#linebreak()#text(" \\item\\label{ii}")#linebreak()#text(" for $j=1,2$,")#linebreak()#text(" the subgroup $S_j$ is normal in $G_j$")#linebreak()#text(" and $T_j/S_j$ is contained in the centre of $G_j/S_j$.")#linebreak()#text(" \\end{enumerate}")#linebreak()#text(" \\end{bon}")

#text("\\noindent")#linebreak()#text(" \\emph{Remark.}")#linebreak()#text(" Proposition \\ref{Goursat} originates in \\cite{Gou89},")#linebreak()#text(" apparently in \\S\\S~11-12, pages 42-48.")#linebreak()#text(" It seems it has been forgotten several times,")#linebreak()#text(" and has reappeared more recently in several places,")#linebreak()#text(" see e.g.\\ \\cite{AnC09}, \\cite{Bou70}, \\cite{Lam58}, and/or \\cite{The97}.")#linebreak()#text(" \\par")#linebreak()#text(" Th\\’evenaz regrets that")#linebreak()#text(" “the result is well known (and ought to appear in textbooks!), but we only found it in …”.")#linebreak()#text(" As a matter of fact, the result appears in \\cite[Exercice 8 du \\S~4, Page I.124]{Bou70}.")

#text("\\section{More if needed}")

#text("For subgroups of $G_1 \\times \\cdots \\times G_n$ with $n \\ge 2$,")#linebreak()#text(" see \\cite{BSZ}.")

#text("There is a version of Goursat’s Lemma for algebraic groups,")#linebreak()#text(" see 1.8.2 (?) in \\cite{Kat90}, refering to \\cite{Kol68} and \\cite{Rib76}.")#linebreak()#text(" This was refereed to me as the (clearly well-known) “Goursat-Kolchin-Ribet lemma”")#linebreak()#text(" (conversation with E.\\ Kowalski)")

#text("\\begin{thebibliography}{AkGW–08}")

#text("\\bibitem[AnC09]{AnC09}")#linebreak()#text(" D.D.\\ {\\sc Anderson} and V.\\ \\textsc{Camillo},")#linebreak()#text(" \\emph{Subgroups of direct products of groups, ideals and subrings of direct products")#linebreak()#text(" of rings, and Goursat’ lemma},")#linebreak()#text(" in “Rings, modules and representations”, Contemp.\\ Math.\\ \\textbf{480} (A.M.S. 2009), 1–12.")#linebreak()#text(" Math.\\ Scand.\\ \\textbf{92} (2003) 261–268.")

#text("\\bibitem[Bou70]{Bou70}")#linebreak()#text(" N.\\ \\textsc{Bourbaki},")#linebreak()#text(" \\emph{Alg\\`ebre, chapitres 1 \\`a 3},")#linebreak()#text(" Diffusion C.C.L.S., 1970.")

#text("\\bibitem[BSZ]{BSZ}")#linebreak()#text(" K.\\ \\textsc{Bauer}, S.\\ \\textsc{Sen} and P.\\ \\textsc{Zvengrowski},")#linebreak()#text(" \\emph{A generalized Goursat lemma},")#linebreak()#text(" arXiv:1109:0024v2, 19 sep 2011.")

#text("\\bibitem[Gou89]{Gou89}")#linebreak()#text(" \\’E.\\ \\textsc{Goursat},")#linebreak()#text(" \\emph{Sur les substitutions orthogonales et les divisions r\\’eguli\\`eres de l’espace},")#linebreak()#text(" Ann.\\ Sci\\ \\’Ecole Norm.\\ Sup.\\ (3) \\textsc{6} (1889), 9–102.")

#text("\\bibitem[Kat90]{Kat90}")#linebreak()#text(" N.M.\\ \\textsc{Katz},")#linebreak()#text(" \\emph{Exponential sums and differential equations},")#linebreak()#text(" Annals of Math.\\ Studies \\textbf{124}, Princeton Univ.\\ Press, 1990.")

#text("\\bibitem[Kol68]{Kol68}")#linebreak()#text(" E.R.\\ \\textsc{Kolchin},")#linebreak()#text(" \\emph{|Algebraic groups and algebraic dependence},")#linebreak()#text(" Amer.\\ J.\\ Math.\\ \\textbf{90} (1968), 1151–1164.")

#text("\\bibitem[Lam58]{Lam58}")#linebreak()#text(" J.\\ \\textsc{Lambek},")#linebreak()#text(" \\emph{Goursat’s Theorem and the Zassenhaus Lemma},")#linebreak()#text(" Canad.\\ J.\\ Math.\\ \\textsc{10} (1958), 45–56.")

#text("\\bibitem[Rib76]{Rib76}")#linebreak()#text(" K.A.\\ \\textsc{Ribet},")#linebreak()#text(" \\emph{Galois action on division points of abelian varieties with real multiplication},")#linebreak()#text(" Amer.\\ J.\\ Math.\\ \\textbf{98} (1976), 751–804.")

#text("\\bibitem[The97]{The97}")#linebreak()#text(" J.\\ {\\sc Th\\’evenaz},")#linebreak()#text(" \\emph{Maximal subgroups of direct products},")#linebreak()#text(" J.\\ of Algebra \\textbf{198} (1997), 352–361.")

#text("\\end{thebibliography}")

#text("\\end{document}")
]
]
]
