// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/23/ias-applications-for-membership-in-the-school-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-24T11:20:41.944307+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IAS applications for membership in the school of mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IAS applications for membership in the school of mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/23/ias-applications-for-membership-in-the-school-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/10/23/ias-applications-for-membership-in-the-school-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-24 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The IAS has ")#link("https://www.ias.edu/math/apply/membership")[#text("opened its application page for its membership program")]#text(" for the upcoming year. This by itself would be unremarkable — the program does this every year — but there is an additional statement included in the announcement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("We realize that applying to positions in the current environment is stressful. To help alleviate this, the School of Mathematics offers applicants the option to submit research statement based only on already conducted research. It would be helpful if such a statement would be focused on a few select projects (in most cases up to three) and not a wide ranging list.")
]

#text("I would expect other departments and institutes advertising positions this year to adopt similar guidance. (See also a ")#link("https://simons.berkeley.edu/AITCSreport")[#text("recent report")]#text(" from a working group making similar recommendations in the area of theoretical computer science.)")

#text("Readers are also invited to post links to other job openings in mathematics in the comments.")

#heading(level: 1)[#text("Comments (2)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/23/ias-applications-for-membership-in-the-school-of-mathematics/comment-page-1/#comment-698700")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("I think in practice, no one is going to get rejected from anything because their grant problems are solved by AI. You understand this is a serious researcher and they should go on to the next technique.")

#text("Personally I do think it’s somewhat healthy if results that are within the range of existing techniques are a bit more devalued and things with no prior work are valued more. We should value new approaches and new idea more than just pushing existing techniques to get new results. Humans goodharting problems, rather than having new and interesting ideas, isn’t really different from AIs doing it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd49bd67b10ec658b70ad9e12d24843bf1324c4b9787f76f5acb63bd6ecda756-6fa9e9615fc64ba32d0fddaee0db3fb86190bf882930cf5476b84e946539e258.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Po-Lam Yung")]], [#link("https://terrytao.wordpress.com/2026/10/23/ias-applications-for-membership-in-the-school-of-mathematics/comment-page-1/#comment-698704")[#strong[#text("Po-Lam Yung")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("Thanks Terry. Hope the following is helpful in a stressful time for many.")

#link("https://www.mathjobs.org/jobs/list/29092")[#text("https://www.mathjobs.org/jobs/list/29092")]

#text("The Australian National University (ANU) is seeking to appoint up to ")#link("https://secure.dc2.pageuppeople.com/apply/658/gateway/default.aspx?sData=-hjRPfc4I_2K-0F4nsh7amoqWsOP2HcIREpELWVG2jIi3ieD5OxPHFNL_Bpdwkt_mnUbMdRAb9CCaN-hx27_iLczcig8vj38sDorNKGnPWY21dNMGHqleEQXDddOyQVAGXiAVVWTeugeldLadNpMITFGgnLoo1xlVfVL-yDeTVs%7e")[#text("four permanent Lecturers and/or Senior Lecturers")]#text(" at Academic Level B and/or Level C, broadly equivalent to Assistant Professor and Associate Professor in the United States.")

#text("We welcome applications from outstanding mathematicians in any area of mathematics. Applicants should have an excellent research record, relative to opportunity and career stage, and a strong commitment to high-quality teaching.")

#text("Successful applicants will be expected to develop an internationally visible research program, contribute to the MSI’s undergraduate and postgraduate teaching, supervise research students, and participate in the life of the Institute.")

#text("The positions include a two-year start-up grant to support research, visitors and conference travel, as well as a reduced teaching load for the first two years.")

#text("ANU is committed to building a diverse and inclusive community, and particularly welcomes applications from women, Aboriginal and Torres Strait Islander people and candidates from culturally and linguistically diverse backgrounds. For more information about staff equity at ANU, visit ")#link("https://services.anu.edu.au/human-resources/respect-inclusion")[#text("https://services.anu.edu.au/human-resources/respect-inclusion")]#text(".")
]
