// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/
// Converted to Typst by tao2typ: "2026-10-14T11:01:39.351397+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246B, Notes 1: Zeroes, poles, and factorisation of meromorphic functions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 December 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")[#text("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A Notes 5")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2021/01/23/246b-notes-2-some-connections-with-the-fourier-transform/")[#text("Notes 2")]#text(".")

#heading(level: 1)[#strong[#text(" — 1. Jensen’s formula — ")]]

#text("Suppose ")#mi("{f}")#text(" is a non-zero rational function ")#mi("{f =P/Q}")#text(", then by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(" one can write")

#align(center)[#tao-fit-display[#mitex("f(z) = c \\frac{\\prod_\\rho (z-\\rho)}{\\prod_\\zeta (z-\\zeta)}")]]

#text("for some non-zero constant ")#mi("{c}")#text(", where ")#mi("{\\rho}")#text(" ranges over the zeroes of ")#mi("{P}")#text(" (counting multiplicity) and ")#mi("{\\zeta}")#text(" ranges over the zeroes of ")#mi("{Q}")#text(" (counting multiplicity), and assuming ")#mi("{z}")#text(" avoids the zeroes of ")#mi("{Q}")#text(". Taking absolute values and then logarithms, we arrive at the formula")

#metadata(none) <tao-d69a1f191c8d5a0ce9f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\log \\left|f(z)\\right| = \\log \\left|c\\right| + \\sum_\\rho \\log\\left|z-\\rho\\right| - \\sum_\\zeta \\log \\left|z-\\zeta\\right|,", block: true)]]

#text("as long as ")#mi("{z}")#text(" avoids the zeroes of both ")#mi("{P}")#text(" and ")#mi("{Q}")#text(". (In this set of notes we use ")#mi("{\\log}")#text(" for the natural logarithm when applied to a positive real number, and ")#mi("{\\mathrm{Log}}")#text(" for the standard branch of the complex logarithm (which extends ")#mi("{\\log}")#text("); the multi-valued complex logarithm ")#mi("{\\log}")#text(" will only be used in passing.) Alternatively, taking logarithmic derivatives, we arrive at the closely related formula")

#metadata(none) <tao-3f2d9b7700a6ece24221>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\frac{f^{\\prime}(z)}{f(z)} = \\sum_\\rho \\frac{1}{z-\\rho} - \\sum_\\zeta \\frac{1}{z-\\zeta},")]]

#text("again for ")#mi("{z}")#text(" avoiding the zeroes of both ")#mi("{P}")#text(" and ")#mi("{Q}")#text(". Thus we see that the zeroes and poles of a rational function ")#mi("{f}")#text(" describe the behaviour of that rational function, as well as close relatives of that function such as the log-magnitude ")#tao-math("{\\log\\left|f\\right|}", block: false)#text(" and log-derivative ")#mi("{\\frac{f^{\\prime}}{f}}")#text(". We have already seen these sorts of formulae arise in our treatment of the argument principle in ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions")[#text("246A Notes 4")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{P(z)}")#text(" be a complex polynomial of degree ")#mi("{n \\geq 1}")#text(".")

#list(
[#text("(i) (")#link("https://en.wikipedia.org/wiki/Gauss%E2%80%93Lucas_theorem")[#text("Gauss-Lucas theorem")]#text(") Show that the complex roots of ")#mi("{P^{\\prime}(z)}")#text(" are contained in the closed convex hull of the complex roots of ")#mi("{P(z)}")#text(".")],
[#text("(ii) (Laguerre separation theorem) If all the complex roots of ")#mi("{P(z)}")#text(" are contained in a disk ")#mi("{D(z_0,r)}")#text(", and ")#mi("{\\zeta \\not \\in D(z_0,r)}")#text(", then all the complex roots of ")#mi("{nP(z) + (\\zeta - z) P^{\\prime}(z)}")#text(" are also contained in ")#mi("{D(z_0,r)}")#text(". (")#emph[#text("Hint:")]#text(" apply a suitable Möbius transformation to move ")#mi("{\\zeta}")#text(" to infinity, and then apply part (i) to a polynomial that emerges after applying this transformation.)")]
)
]

#text("There are a number of useful ways to extend these formulae to more general meromorphic functions than rational functions. Firstly there is a very handy “local” variant of ")#link(<tao-d69a1f191c8d5a0ce9f6>)[#text("(1)")]#text(" known as ")#link("http://en.wikipedia.org/wiki/Jensen%27s_formula")[#text("Jensen’s formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Jensen’s formula)")]#text(" ")#metadata(none) <tao-c87f42bd454c031b875b>#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open neighbourhood of a disk ")#tao-math("{\\overline{D(z_0,r)} = \\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(", with all removable singularities removed. Then, if ")#mi("{z_0}")#text(" is neither a zero nor a pole of ")#mi("{f}")#text(", we have")

#metadata(none) <tao-21c9625fc6b6db6a0baf>

#tao-aligned(keep: true)[


#tao-math("\\log \\left|f(z_0)\\right|  & = \\int_0^1 \\log \\left|f(z_0+re^{2\\pi i t})\\right|\\ dt + \\sum_{\\rho: \\left|\\rho-z_0\\right| \\leq r} \\log \\frac{\\left|\\rho-z_0\\right|}{r}", block: true, numbering: n => [#text("(3)")])



#tao-math(" & - \\sum_{\\zeta: \\left|\\zeta-z_0\\right| \\leq r} \\log \\frac{\\left|\\zeta-z_0\\right|}{r}", block: true)
]

#text("where ")#mi("{\\rho}")#text(" and ")#mi("{\\zeta}")#text(" range over the zeroes and poles of ")#mi("{f}")#text(" respectively (counting multiplicity) in the disk ")#mi("{\\overline{D(z_0,r)}}")#text(".")
]

#text("One can view ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(3)")]#text(" as a truncated (or localised) variant of ")#link(<tao-d69a1f191c8d5a0ce9f6>)[#text("(1)")]#text(". Note also that the summands ")#tao-math("{\\log \\frac{\\left|\\rho-z_0\\right|}{r}, \\log \\frac{\\left|\\zeta-z_0\\right|}{r}}", block: false)#text(" are always non-positive.")

#emph[#text("Proof:")]#text(" By perturbing ")#mi("{r}")#text(" slightly if necessary, we may assume that none of the zeroes or poles of ")#mi("{f}")#text(" (which form a discrete set) lie on the boundary circle ")#tao-math("{\\{ z: \\left|z-z_0\\right| = r \\}}", block: false)#text(". By translating and rescaling, we may then normalise ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(", thus our task is now to show that ")#metadata(none) <tao-3879d6995a5cdfe52e9d>#tao-math("\\displaystyle  \\log \\left|f(0)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt + \\sum_{\\rho: \\left|\\rho\\right| < 1} \\log \\left|\\rho\\right| - \\sum_{\\zeta: \\left|\\zeta\\right| < 1} \\log \\left|\\zeta\\right|. \\ \\ \\ \\ \\ (4)", block: false)#text(" ")#text(" We may remove the poles and zeroes inside the disk ")#mi("{D(0,1)}")#text(" by the useful device of ")#link("http://en.wikipedia.org/wiki/Blaschke_product")[#text("Blaschke products")]#text(". Suppose for instance that ")#mi("{f}")#text(" has a zero ")#mi("{\\rho}")#text(" inside the disk ")#mi("{D(0,1)}")#text(". Observe that the function ")#metadata(none) <tao-8172b90bd44320037349>#mi("\\displaystyle  B_\\rho(z) := \\frac{\\rho - z}{1 - \\overline{\\rho} z} \\ \\ \\ \\ \\ (5)")#text(" ")#text(" has magnitude ")#mi("{1}")#text(" on the unit circle ")#tao-math("{\\{ z: \\left|z\\right| = 1\\}}", block: false)#text(", equals ")#mi("{\\rho}")#text(" at the origin, has a simple zero at ")#mi("{\\rho}")#text(", but has no other zeroes or poles inside the disk. Thus Jensen’s formula ")#link(<tao-3879d6995a5cdfe52e9d>)[#text("(4)")]#text(" already holds if ")#mi("{f}")#text(" is replaced by ")#mi("{B_\\rho}")#text(". To prove ")#link(<tao-3879d6995a5cdfe52e9d>)[#text("(4)")]#text(" for ")#mi("{f}")#text(", it thus suffices to prove it for ")#mi("{f/B_\\rho}")#text(", which effectively deletes a zero ")#mi("{\\rho}")#text(" inside the disk ")#mi("{D(0,1)}")#text(" from ")#mi("{f}")#text(" (and replaces it instead with its inversion ")#mi("{1/\\overline{\\rho}}")#text("). Similarly we may remove all the poles inside the disk. As a meromorphic function only has finitely many poles and zeroes inside a compact set, we may thus reduce to the case when ")#mi("{f}")#text(" has no poles or zeroes on or inside the disk ")#mi("{D(0,1)}")#text(", at which point our goal is simply to show that")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(0)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt.", block: true)]]

#text("Since ")#mi("{f}")#text(" has no zeroes or poles inside the disk, it has a holomorphic logarithm ")#mi("{F}")#text(" (Exercise 46 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/#comment-606099")[#text("246A Notes 4")]#text("). In particular, ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(" is the real part of ")#mi("{F}")#text(". The claim now follows by applying the mean value property (Exercise 17 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("246A Notes 3")]#text(") to ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(". ")#mi("\\Box")

#text("An important special case of Jensen’s formula arises when ")#mi("{f}")#text(" is holomorphic in a neighborhood of ")#mi("{\\overline{D(z_0,r)}}")#text(", in which case there are no contributions from poles and one simply has ")#metadata(none) <tao-63eca9ff4b5a02f497c8>#tao-math("\\displaystyle  \\int_0^1 \\log \\left|f(z_0+re^{2\\pi i t})\\right|\\ dt = \\log \\left|f(z_0)\\right| + \\sum_{\\rho: \\left|\\rho-z_0\\right| \\leq r} \\log \\frac{r}{\\left|\\rho-z_0\\right|}. \\ \\ \\ \\ \\ (6)", block: false)#text(" ")#text(" This is quite a useful formula, mainly because the summands ")#tao-math("{\\log \\frac{r}{\\left|\\rho-z_0\\right|}}", block: false)#text(" are non-negative; it can be viewed as a more precise assertion of the subharmonicity of ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(" (see Exercises 60(ix) and 61 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A Notes 5")]#text("). Here are some quick applications of this formula:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Use ")#link(<tao-63eca9ff4b5a02f497c8>)[#text("(6)")]#text(" to give another proof of ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(": a bounded holomorphic function ")#mi("{f}")#text(" on the entire complex plane is necessarily constant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-943a1abf223ddf833460>#text(" Use Jensen’s formula to prove the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(": a complex polynomial ")#mi("{P(z)}")#text(" of degree ")#mi("{n}")#text(" has exactly ")#mi("{n}")#text(" complex zeroes (counting multiplicity), and can thus be factored as ")#mi("{P(z) = c (z-z_1) \\dots (z-z_n)}")#text(" for some complex numbers ")#mi("{c,z_1,\\dots,z_n}")#text(" with ")#mi("{c \\neq 0}")#text(". (Note that the fundamental theorem was invoked previously in this section, but only for motivational purposes, so the proof here is non-circular.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Shifted Jensen’s formula)")]#text(" ")#metadata(none) <tao-3d6ae8ac38dd20f70b27>#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open neighbourhood of a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(", with all removable singularities removed. Show that")

#metadata(none) <tao-d917018c300dd8d83386>

#tao-aligned(keep: true)[


#tao-math("\\log \\left|f(z)\\right|  & = \\int_0^1 \\log \\left|f(z_0+re^{2\\pi i t})\\right| \\mathrm{Re} \\frac{r e^{2\\pi i t} + (z-z_0)}{r e^{2\\pi i t} - (z-z_0)}\\ dt", block: true, numbering: n => [#text("(7)")])



#tao-math(" & + \\sum_{\\rho: \\left|\\rho-z_0\\right| \\leq r} \\log \\frac{\\left|\\rho-z\\right|}{\\left|r - \\rho^* (z-z_0)\\right|}", block: true)



#tao-math(" & - \\sum_{\\zeta: \\left|\\zeta-z_0\\right| \\leq r} \\log \\frac{\\left|\\zeta-z\\right|}{\\left|r - \\zeta^* (z-z_0)\\right|}", block: true)
]

#text("for all ")#mi("{z}")#text(" in the open disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < r\\}}", block: false)#text(" that are not zeroes or poles of ")#mi("{f}")#text(", where ")#mi("{\\rho^* = \\frac{\\overline{\\rho-z_0}}{r}}")#text(" and ")#mi("{\\zeta^* = \\frac{\\overline{\\zeta-z_0}}{r}}")#text(". (The function ")#mi("{\\Re \\frac{r e^{2\\pi i t} + (z-z_0)}{r e^{2\\pi i t} - (z-z_0)}}")#text(" appearing in the integrand is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]#text(", particularly if one normalises so that ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Bounded type)")]

#list(
[#text("(i) If ")#mi("{f}")#text(" is a holomorphic function on ")#mi("{D(0,1)}")#text(" that is not identically zero, show that ")#tao-math("{\\liminf_{r \\rightarrow 1^-} \\int_0^{2\\pi} \\log \\left|f(re^{i\\theta})\\right|\\ d\\theta > -\\infty}", block: false)#text(".")],
[#text("(ii) If ")#mi("{f}")#text(" is a meromorphic function on ")#mi("{D(0,1)}")#text(" that is the ratio of two bounded holomorphic functions that are not identically zero, show that ")#tao-math("{\\limsup_{r \\rightarrow 1^-} \\int_0^{2\\pi} |\\log \\left|f(re^{i\\theta})\\right||\\ d\\theta < \\infty}", block: false)#text(". (Functions ")#mi("{f}")#text(" of this form are said to be of ")#link("https://en.wikipedia.org/wiki/Bounded_type_(mathematics)")[#text("bounded type")]#text(" and lie in the ")#emph[#text("Nevanlinna class")]#text(" for the unit disk ")#mi("{D(0,1)}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Smoothed out Jensen formula)")]#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open set ")#mi("{U}")#text(", and let ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" be a smooth compactly supported function. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_\\rho \\phi(\\rho) - \\sum_\\zeta \\phi(\\zeta)")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\frac{-1}{2\\pi} \\int\\int_U ((\\frac{\\partial}{\\partial x} + i \\frac{\\partial}{\\partial y}) \\phi(x+iy)) \\frac{f^{\\prime}}{f}(x+iy)\\ dx dy", block: true)



#tao-math(" & = \\frac{1}{2\\pi} \\int\\int_U ((\\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2}) \\phi(x+iy)) \\log \\left|f(x+iy)\\right|\\ dx dy", block: true)
]

#text("where ")#mi("{\\rho, \\zeta}")#text(" range over the zeroes and poles of ")#mi("{f}")#text(" (respectively) in the support of ")#mi("{\\phi}")#text(". Informally argue why this identity is consistent with Jensen’s formula. (Note: as many of the functions involved here are not holomorphic, complex analysis tools are of limited use. Try using real variable tools such as Stokes theorem, Greens theorem, or integration by parts.)")
]

#text("When applied to entire functions ")#mi("{f}")#text(", Jensen’s formula relates the order of growth of ")#mi("{f}")#text(" near infinity with the density of zeroes of ")#mi("{f}")#text(". Here is a typical result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" ")#metadata(none) <tao-92da40b4ed7468ae120f>#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be an entire function, not identically zero, that obeys a growth bound ")#tao-math("{\\left|f(z)\\right| \\leq C \\exp( C\\left|z\\right|^\\alpha)}", block: false)#text(" for some ")#mi("{C, \\alpha > 0}")#text(" and all ")#mi("{z}")#text(". Then there exists a constant ")#mi("{C^{\\prime}>0}")#text(" such that ")#mi("{D(0,R)}")#text(" has at most ")#mi("{C^{\\prime} R^\\alpha}")#text(" zeroes (counting multiplicity) for any ")#mi("{R \\geq 1}")#text(".")
]

#text("Entire functions that obey a growth bound of the form ")#tao-math("{\\left|f(z)\\right| \\leq C_\\varepsilon \\exp( C_\\varepsilon \\left|z\\right|^{\\rho+\\varepsilon})}", block: false)#text(" for every ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{z}")#text(" (where ")#mi("{C_\\varepsilon}")#text(" depends on ")#mi("{\\varepsilon}")#text(") are said to be of ")#link("https://en.wikipedia.org/wiki/Entire_function#Order_and_type")[#text("order at most ")#mi("{\\rho}")]#text(". The above theorem shows that for such functions that are not identically zero, the number of zeroes in a disk of radius ")#mi("{R}")#text(" does not grow much faster than ")#mi("{R^\\rho}")#text(". This is often a useful preliminary upper bound on the zeroes of entire functions, as the order of an entire function tends to be relatively easy to compute in practice.")

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{f(0)}")#text(" is non-zero. From ")#link(<tao-63eca9ff4b5a02f497c8>)[#text("(6)")]#text(" applied with ")#mi("{r=2R}")#text(" and ")#mi("{z_0=0}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\int_0^1 \\log(C \\exp( C (2R)^\\alpha ) )\\ dt \\geq \\log \\left|f(0)\\right| + \\sum_{\\rho: \\left|\\rho\\right| \\leq 2R} \\log \\frac{2R}{\\left|\\rho\\right|}.", block: true)]]

#text("Every zero in ")#mi("{D(0,R)}")#text(" contribute at least ")#mi("{\\log 2}")#text(" to a summand on the right-hand side, while all other zeroes contribute a non-negative quantity, thus")

#align(center)[#tao-fit-display[#tao-math("\\log C + C (2R)^\\alpha \\geq \\log \\left|f(0)\\right| + N_R \\log 2", block: true)]]

#text("where ")#mi("{N_R}")#text(" denotes the number of zeroes in ")#mi("{D(0,R)}")#text(". This gives the claim for ")#mi("{f(0) \\neq 0}")#text(". When ")#mi("{f(0)=0}")#text(", one can shift ")#mi("{f}")#text(" by a small amount to make ")#mi("{f}")#text(" non-zero at the origin (using the fact that zeroes of holomorphic functions not identically zero are isolated), modifying ")#mi("{C}")#text(" in the process, and then repeating the previous arguments. ")#mi("\\Box")

#text("Just as ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(3)")]#text(" and ")#link(<tao-d917018c300dd8d83386>)[#text("(7)")]#text(" give truncated variants of ")#link(<tao-d69a1f191c8d5a0ce9f6>)[#text("(1)")]#text(", we can create truncated versions of ")#link(<tao-3f2d9b7700a6ece24221>)[#text("(2)")]#text(". The following crude truncation is adequate for many applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Truncated formula for log-derivative)")]#text(" ")#metadata(none) <tao-460ae9dccd6be97f7a91>#text(" Let ")#mi("{f}")#text(" be a holomorphic function on an open neighbourhood of a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" that is not identically zero on this disk. Suppose that one has a bound of the form ")#tao-math("{\\left|f(z)\\right| \\leq M^{O_{c_1,c_2}(1)} \\left|f(z_0)\\right|}", block: false)#text(" for some ")#mi("{M \\geq 1}")#text(" and all ")#mi("{z}")#text(" on the circle ")#tao-math("{\\{ z: \\left|z-z_0\\right| = r\\}}", block: false)#text(". Let ")#mi("{0 < c_2 < c_1 < 1}")#text(" be constants. Then one has the approximate formula")

#align(center)[#tao-fit-display[#tao-math("\\frac{f^{\\prime}(z)}{f(z)} = \\sum_{\\rho: \\left|\\rho - z_0\\right| \\leq c_1 r} \\frac{1}{z-\\rho} + O_{c_1,c_2}( \\frac{\\log M}{r} )", block: true)]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(" other than zeroes of ")#mi("{f}")#text(". Furthermore, the number of zeroes ")#mi("{\\rho}")#text(" in the above sum is ")#mi("{O_{c_1,c_2}(\\log M)}")#text(".")
]

#emph[#text("Proof:")]#text(" To abbreviate notation, we allow all implied constants in this proof to depend on ")#mi("{c_1,c_2}")#text(".")

#text("We mimic the proof of Jensen’s formula. Firstly, we may translate and rescale so that ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(", so we have ")#tao-math("{\\left|f(z)\\right| \\leq M^{O(1)} \\left|f(0)\\right|}", block: false)#text(" when ")#tao-math("{\\left|z\\right|=1}", block: false)#text(", and our main task is to show that ")#metadata(none) <tao-93850b707585e404e495>#tao-math("\\displaystyle  \\frac{f^{\\prime}(z)}{f(z)} - \\sum_{\\rho: \\left|\\rho\\right| \\leq c_1} \\frac{1}{z-\\rho} = O( \\log M ) \\ \\ \\ \\ \\ (8)", block: false)#text(" ")#text(" for ")#tao-math("{\\left|z\\right| \\leq c_2}", block: false)#text(". Note that if ")#mi("{f(0)=0}")#text(" then ")#mi("{f}")#text(" vanishes on the unit circle and hence (by the maximum principle) vanishes identically on the disk, a contradiction, so we may assume ")#mi("{f(0) \\neq 0}")#text(". From hypothesis we then have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(z)\\right| \\leq \\log \\left|f(0)\\right| + O(\\log M)", block: true)]]

#text("on the unit circle, and so from Jensen’s formula ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(3)")]#text(" we see that")

#metadata(none) <tao-db4f552e9a7a7f2498e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\sum_{\\rho: \\left|\\rho\\right| \\leq 1} \\log \\frac{1}{\\left|\\rho\\right|} = O(\\log M).", block: true)]]

#text("In particular we see that the number of zeroes with ")#tao-math("{\\left|\\rho\\right| \\leq c_1}", block: false)#text(" is ")#mi("{O(\\log M)}")#text(", as claimed.")

#text("Suppose ")#mi("{f}")#text(" has a zero ")#mi("{\\rho}")#text(" with ")#tao-math("{c_1 < \\left|\\rho\\right| \\leq 1}", block: false)#text(". If we factor ")#mi("{f = B_\\rho g}")#text(", where ")#mi("{B_\\rho}")#text(" is the Blaschke product ")#link(<tao-8172b90bd44320037349>)[#text("(5)")]#text(", then")

#tao-aligned(keep: true)[


#tao-math("\\frac{f^{\\prime}}{f}  & = \\frac{B^{\\prime}_\\rho}{B_\\rho} + \\frac{g^{\\prime}}{g}", block: true)



#tao-math(" & = \\frac{g^{\\prime}}{g} + \\frac{1}{z-\\rho} - \\frac{1}{z-1/\\overline{\\rho}}.", block: true)
]

#text("Observe from Taylor expansion that the distance between ")#mi("{\\rho}")#text(" and ")#mi("{1/\\overline{\\rho}}")#text(" is ")#tao-math("{O( \\log \\frac{1}{\\left|\\rho\\right|} )}", block: false)#text(", and hence ")#tao-math("{\\frac{1}{z-\\rho} - \\frac{1}{z-1/\\overline{\\rho}} = O( \\log \\frac{1}{\\left|\\rho\\right|} )}", block: false)#text(" for ")#tao-math("{\\left|z\\right| \\leq c_2}", block: false)#text(". Thus we see from ")#link(<tao-db4f552e9a7a7f2498e3>)[#text("(9)")]#text(" that we may use Blaschke products to remove all the zeroes in the annulus ")#tao-math("{c_1 < \\left|\\rho\\right| \\leq 1}", block: false)#text(" while only affecting the left-hand side of ")#link(<tao-93850b707585e404e495>)[#text("(8)")]#text(" by ")#mi("{O( \\log M)}")#text("; also, removing the Blaschke products does not affect ")#tao-math("{\\left|f(z)\\right|}", block: false)#text(" on the unit circle, and only affects ")#tao-math("{\\log \\left|f(0)\\right|}", block: false)#text(" by ")#mi("{O(\\log M)}")#text(" thanks to ")#link(<tao-db4f552e9a7a7f2498e3>)[#text("(9)")]#text(". Thus we may assume without loss of generality that there are no zeroes in this annulus.")

#text("Similarly, given a zero ")#mi("{\\rho}")#text(" with ")#tao-math("{\\left|\\rho\\right| \\leq c_1}", block: false)#text(", we have ")#mi("{\\frac{1}{z-1/\\overline{\\rho}} = O(1)}")#text(", so using Blaschke products to remove all of these zeroes also only affects the left-hand side of ")#link(<tao-93850b707585e404e495>)[#text("(8)")]#text(" by ")#mi("{O(\\log M)}")#text(" (since the number of zeroes here is ")#mi("{O(\\log M)}")#text("), with ")#tao-math("{\\log \\left|f(0)\\right|}", block: false)#text(" also modified by at most ")#mi("{O(\\log M)}")#text(". Thus we may assume in fact that ")#mi("{f}")#text(" has no zeroes whatsoever within the unit disk. We may then also normalise ")#mi("{f(0) = 1}")#text(", then ")#tao-math("{\\log \\left|f(e^{2\\pi i t})\\right| \\leq O(\\log M)}", block: false)#text(" for all ")#mi("{t \\in [0,1]}")#text(". By Jensen’s formula again, we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt = 0", block: true)]]

#text("and thus (by using the identity ")#tao-math("{\\left|x\\right| = 2 \\max(x,0) - x}", block: false)#text(" for any real ")#mi("{x}")#text(")")

#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\int_0^1 \\left|\\log \\left|f(e^{2\\pi i t})\\right|\\right|\\ dt \\ll \\log M.", block: true)]]

#text("On the other hand, from ")#link(<tao-d917018c300dd8d83386>)[#text("(7)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(z)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right| \\mathrm{Re} \\frac{e^{2\\pi i t} + z}{e^{2\\pi i t} - z}\\ dt", block: true)]]

#text("which implies from ")#link(<tao-7f1b55b860590406f84f>)[#text("(10)")]#text(" that ")#tao-math("{\\log \\left|f(z)\\right|}", block: false)#text(" and its first derivatives are ")#mi("{O( \\log M )}")#text(" on the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq c_2 \\}}", block: false)#text(". But recall from the proof of Jensen’s formula that ")#mi("{\\frac{f^{\\prime}}{f}}")#text(" is the derivative of a logarithm ")#mi("{\\log f}")#text(" of ")#mi("{f}")#text(", whose real part is ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(". By the Cauchy-Riemann equations for ")#mi("{\\log f}")#text(", we conclude that ")#mi("{\\frac{f^{\\prime}}{f} = O(\\log M)}")#text(" on the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq c_2 \\}}", block: false)#text(", as required. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" ")#metadata(none) <tao-1e0bbd6c686ba050b8eb>

#list(
[#text("(i) (")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Carath%C3%A9odory_theorem")[#text("Borel-Carathéodory theorem")]#text(") If ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" is analytic on an open neighborhood of a disk ")#mi("{\\overline{D(z_0,R)}}")#text(" and ")#mi("{0 < r < R}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{z \\in D(z_0,r)} \\left|f(z)\\right| \\leq \\frac{2r}{R-r} \\sup_{z \\in \\overline{D(z_0,R)}} \\mathrm{Re} f(z) + \\frac{R+r}{R-r} |f(z_0)|.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" one can normalise ")#mi("{z_0=0}")#text(", ")#mi("{R=1}")#text(", ")#mi("{f(0)=0}")#text(", and ")#tao-math("{\\sup_{\\left|z-z_0\\right| \\leq R} \\mathrm{Re} f(z)=1}", block: false)#text(". Now ")#mi("{f}")#text(" maps the unit disk to the half-plane ")#mi("{\\{ \\mathrm{Re} z \\leq 1 \\}}")#text(". Use a Möbius transformation to map the half-plane to the unit disk and then use the ")#link("https://en.wikipedia.org/wiki/Schwarz_lemma")[#text("Schwarz lemma")]#text(".)")],
[#text("(ii) Use (i) to give an alternate way to conclude the proof of Theorem ")#link(<tao-460ae9dccd6be97f7a91>)[#text("9")]#text(".")]
)
]

#text("A variant of the above argument allows one to make precise the heuristic that holomorphic functions locally look like polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Local Weierstrass factorisation)")]#text(" Let the notation and hypotheses be as in Theorem ")#link(<tao-460ae9dccd6be97f7a91>)[#text("9")]#text(". Then show that")

#align(center)[#tao-fit-display[#mitex("f(z) = P(z) \\exp( g(z) )")]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(", where ")#mi("{P}")#text(" is a polynomial whose zeroes are precisely the zeroes of ")#mi("{f}")#text(" in ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq c_1r \\}}", block: false)#text(" (counting multiplicity) and ")#mi("{g}")#text(" is a holomorphic function on ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(" of magnitude ")#mi("{O_{c_1,c_2}( \\log M )}")#text(" and first derivative ")#mi("{O_{c_1,c_2}( \\log M / r )}")#text(" on this disk. Furthermore, show that the degree of ")#mi("{P}")#text(" is ")#mi("{O_{c_1,c_2}(\\log M)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Preliminary Beurling factorisation)")]#text(" Let ")#mi("{H^\\infty(D(0,1))}")#text(" denote the space of bounded analytic functions ")#mi("{f: D(0,1) \\rightarrow {\\bf C}}")#text(" on the unit disk; this is a normed vector space with norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{H^\\infty(D(0,1))} := \\sup_{z \\in D(0,1)} \\left|f(z)\\right|.", block: true)]]

#list(
[#text("(i) If ")#mi("{f \\in H^\\infty(D(0,1))}")#text(" is not identically zero, and ")#mi("{z_n}")#text(" denote the zeroes of ")#mi("{f}")#text(" in ")#mi("{D(0,1)}")#text(" counting multiplicity, show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_n (1-\\left|z_n\\right|) < \\infty", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sup_{1/2 < r < 1} \\int_0^{2\\pi} | \\log \\left|f(re^{i\\theta})\\right| |\\ d\\theta < \\infty.", block: true)]]],
[#text("(ii) Let the notation be as in (i). If we define the ")#link("http://en.wikipedia.org/wiki/Blaschke_product")[#text("Blaschke product")]

#align(center)[#tao-fit-display[#tao-math("B(z) := z^m \\prod_{\\left|z_n\\right| \\neq 0} \\frac{\\left|z_n\\right|}{z_n} \\frac{z_n-z}{1-\\overline{z_n} z}", block: true)]]

#text("where ")#mi("{m}")#text(" is the order of vanishing of ")#mi("{f}")#text(" at zero, show that this product converges absolutely to a holomorphic function on ")#mi("{D(0,1)}")#text(", and that ")#tao-math("{\\left|f(z)\\right| \\leq \\left\\|f\\right\\|_{H^\\infty(D(0,1)} \\left|B(z)\\right|}", block: false)#text(" for all ")#mi("{z \\in D(0,1)}")#text(". (It may be easier to work with finite Blaschke products first to obtain this bound.)")],
[#text("(iii) Continuing the notation from (i), establish a factorisation ")#mi("{f(z) = B(z) \\exp(g(z))}")#text(" for some holomorphic function ")#mi("{g: D(0,1) \\rightarrow {\\bf C}}")#text(" with ")#tao-math("{\\mathrm{Re}(g(z)) \\leq \\log \\left\\|f\\right\\|_{H^\\infty(D(0,1)}}", block: false)#text(" for all ")#mi("{z\\in D(0,1)}")#text(".")],
[#text("(iv) (")#link("https://en.wikipedia.org/wiki/F._and_M._Riesz_theorem")[#text("Theorem of F. and M. Riesz")]#text(", special case) If ")#mi("{f \\in H^\\infty(D(0,1))}")#text(" extends continuously to the boundary ")#mi("{\\{e^{i\\theta}: 0 \\leq \\theta < 2\\pi\\}}")#text(", show that the set ")#mi("{\\{ 0 \\leq \\theta < 2\\pi: f(e^{i\\theta})=0 \\}}")#text(" has zero measure.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" The factorisation (iii) can be refined further, with ")#mi("{g}")#text(" being the Poisson integral of some finite measure on the unit circle. Using the Lebesgue decomposition of this finite measure into absolutely continuous parts one ends up factorising ")#mi("{H^\\infty(D(0,1))}")#text(" functions into “outer functions” and “inner functions”, giving the ")#link("https://en.wikipedia.org/wiki/Hardy_space#Factorization_into_inner_and_outer_functions_(Beurling)")[#text("Beurling factorisation")]#text(" of ")#mi("{H^\\infty}")#text(". There are also extensions to larger spaces ")#mi("{H^p(D(0,1))}")#text(" than ")#mi("{H^\\infty(D(0,1))}")#text(" (which are to ")#mi("{H^\\infty}")#text(" as ")#mi("{L^p}")#text(" is to ")#mi("{L^\\infty}")#text("), known as ")#link("https://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy spaces")]#text(". We will not discuss this topic further here, but see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2261424")[#text("this text of Garnett")]#text(" for a treatment.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Littlewood’s lemma)")]#text(" Let ")#mi("{f}")#text(" be holomorphic on an open neighbourhood of a rectangle ")#mi("{R = \\{ \\sigma+it: \\sigma_0 \\leq \\sigma \\leq \\sigma_1; 0 \\leq t \\leq T \\}}")#text(" for some ")#mi("{\\sigma_0 < \\sigma_1}")#text(" and ")#mi("{T>0}")#text(", with ")#mi("{f}")#text(" non-vanishing on the boundary of the rectangle. Show that")

#tao-aligned(keep: true)[


#tao-math("2\\pi \\sum_\\rho (\\mathrm{Re}(\\rho)-\\sigma_0)  & = \\int_0^T \\log \\left|f(\\sigma_0+it)\\right|\\ dt - \\int_0^T \\log \\left|f(\\sigma_1+it)\\right|\\ dt", block: true)



#tao-math(" & + \\int_{\\sigma_0}^{\\sigma_1} \\mathrm{arg} f(\\sigma+iT)\\ d\\sigma - \\int_{\\sigma_0}^{\\sigma_1} \\mathrm{arg} f(\\sigma)\\ d\\sigma", block: true)
]

#text("where ")#mi("{\\rho}")#text(" ranges over the zeroes of ")#mi("{f}")#text(" inside ")#mi("{R}")#text(" (counting multiplicity) and one uses a branch of ")#mi("{\\mathrm{arg} f}")#text(" which is continuous on the upper, lower, and right edges of ")#mi("{C}")#text(". (This lemma is a popular tool to explore the zeroes of Dirichlet series such as the Riemann zeta function.)")
]

#metadata(none) <tao-4f444b3385be3a8332c1>

#heading(level: 1)[#strong[#text(" — 2. The Weierstrass factorisation theorem — ")]]

#text("The fundamental theorem of algebra shows that every polynomial ")#mi("{P(z)}")#text(" of degree ")#mi("{n}")#text(" comes with ")#mi("{n}")#text(" complex zeroes ")#mi("{z_1,\\dots,z_n}")#text(" (counting multiplicity). In the converse direction, given any ")#mi("{n}")#text(" complex numbers ")#mi("{z_1,\\dots,z_n}")#text(" (again allowing multiplicity), one can form a degree ")#mi("{n}")#text(" polynomial ")#mi("{P(z)}")#text(" with precisely these zeroes by the formula ")#metadata(none) <tao-917adf1964c277211266>#mi("\\displaystyle  P(z) := c (z-z_1) \\dots (z-z_n) \\ \\ \\ \\ \\ (11)")#text(" ")#text(" where ")#mi("{c}")#text(" is an arbitrary non-zero constant, and by the factor theorem this is the complete set of polynomials with this set of zeroes (counting multiplicity). Thus, except for the freedom to multiply polynomials by non-zero constants, one has a one-to-one correspondence between polynomials (excluding the zero polynomial as a degenerate case) and finite (")#link("https://en.wikipedia.org/wiki/Multiset")[#text("multi")]#text("-)sets of complex numbers.")

#text("As discussed earlier in this set of notes, one can think of a entire function as a sort of infinite degree analogue of a polynomial. One can then ask what the analogue of the above correspondence is for entire functions are – can one identify entire functions (not identically zero, and up to constants) by their sets of zeroes?")

#text("There are two obstructions to this. Firstly there are a number of non-trivial entire functions with no zeroes whatsoever. Most prominently, we have the exponential function ")#mi("{\\exp(z)}")#text(" which has no zeroes despite being non-constant. More generally, if ")#mi("{g(z)}")#text(" is an entire function, then clearly ")#mi("{\\exp(g(z))}")#text(" is an entire function with no zeroes. In particular one can multiply (or divide) any other entire function ")#mi("{f(z)}")#text(" by ")#mi("{\\exp(g(z))}")#text(" without affecting the location and order of the zeroes.")

#text("Secondly, we know (see Corollary 24 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("246A Notes 3")]#text(") that the set of zeroes of an entire function (that is not identically zero) must be isolated; in particular, in any compact set there can only be finitely many zeroes. Thus, by covering the complex plane by an increasing sequence of compact sets (e.g., the disks ")#mi("{\\overline{D(0,n)}}")#text("), one can index the zeroes (counting multiplicity) by a sequence ")#mi("{z_1,z_2,\\dots}")#text(" of complex numbers (possibly with repetition) that is either finite, or goes to infinity.")

#text("Now we turn to the ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation theorem")]#text(", which asserts that once one accounts for these two obstructions, we recover a correspondence between entire functions and sequences of zeroes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Weierstrass factorization theorem)")]#text(" ")#metadata(none) <tao-714962e22ae899f03bdc>#text(" Let ")#mi("{z_1,z_2,\\dots}")#text(" be a sequence of complex numbers that is either finite or going to infinity. Then there exists an entire function ")#mi("{f}")#text(" that has zeroes precisely at ")#mi("{z_1,z_2,\\dots}")#text(", with the order of zero of ")#mi("{f}")#text(" at each ")#mi("{z_j}")#text(" equal to the number of times ")#mi("{z_j}")#text(" appears in the sequence. Furthermore, this entire function is unique up to multiplication by exponentials of entire functions; that is to say, if ")#mi("{f, \\tilde f}")#text(" are entire functions that are both of the above form, then ")#mi("{\\tilde f(z) = f(z) \\exp(g(z))}")#text(" for some entire function ")#mi("{g}")#text(".")
]

#text("We now establish this theorem. We begin with the easier uniqueness part of the theorem. If ")#mi("{\\tilde f, f}")#text(" are entire functions with the same locations and orders of zeroes, then the ratio ")#mi("{\\tilde f/f}")#text(" is a meromorphic function on ")#mi("{{\\bf C}}")#text(" which only has removable singularities, and becomes an entire function with no zeroes once the singularities are removed. Since the domain ")#mi("{{\\bf C}}")#text(" of an entire function is simply connected, we can then take a branch of the complex logarithm ")#mi("{\\tilde f/f}")#text(" (see Exercise 46 of ")#link("https://terrytao.wordpress.com/2016/10/11/math-246a-notes-4-singularities-of-holomorphic-functions/")[#text("246A Notes 4")]#text(") to write ")#mi("{\\tilde f/f = \\exp(g)}")#text(" for an entire function ")#mi("{g}")#text(" (after removing singularities), giving the uniqueness claim.")

#text("Now we turn to existence. If the sequence ")#mi("{z_1,z_2,\\dots}")#text(" is finite, we can simply use the formula ")#link(<tao-917adf1964c277211266>)[#text("(11)")]#text(" to produce the required entire function ")#mi("{f}")#text(" (setting ")#mi("{c}")#text(" to equal ")#mi("{1}")#text(", say). So now suppose that the sequence is infinite. Naively, one might try to replicate the formula ")#link(<tao-917adf1964c277211266>)[#text("(11)")]#text(" and set")

#align(center)[#tao-fit-display[#mitex("f(z) := \\prod_{n=1}^\\infty (z-z_n).")]]

#text("Here we encounter a serious problem: the infinite product ")#mi("{\\prod_{n=1}^\\infty (z-z_n)}")#text(" is likely to be divergent (that is to say, the partial products ")#mi("{\\prod_{n=1}^N (z-z_n)}")#text(") fail to converge, given that the factors ")#mi("{z-z_n}")#text(" go off to infinity. On the other hand, we do have this freedom to multiply ")#mi("{f}")#text(" by a constant (or more generally, the exponential of an entire function). One can try to use this freedom to “renormalise” the factors ")#mi("{z-z_n}")#text(" to make them more likely to converge. Much as an infinite series ")#mi("{\\sum_{n=1}^\\infty a_n}")#text(" is more likely to converge when its summands ")#mi("{a_n}")#text(" converge rapidly to zero, an infinite series ")#mi("{\\prod_{n=1}^\\infty a_n}")#text(" is more likely to converge when its factors ")#mi("{a_n}")#text(" converge rapidly to ")#mi("{1}")#text(". Here is one formalisation of this principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Absolutely convergent products)")]#text(" ")#metadata(none) <tao-6754af9632a2745e85c2>#text(" Let ")#mi("{a_n}")#text(" be a sequence of complex numbers such that ")#tao-math("{\\sum_{n=1}^\\infty \\left|a_n-1\\right| < \\infty}", block: false)#text(". Then the product ")#mi("{\\prod_{n=1}^\\infty a_n}")#text(" converges. Furthermore, this product vanishes if and only if one of the factors ")#mi("{a_n}")#text(" vanishes.")
]

#text("Products covered by this lemma are known as ")#emph[#text("absolutely convergent products")]#text(". It is possible for products to converge without being absolutely convergent, but such “conditionally convergent products” are infrequently used in mathematics.")

#emph[#text("Proof:")]#text(" By the zero test, ")#tao-math("{\\left|a_n-1\\right| \\rightarrow 0}", block: false)#text(", thus ")#mi("{a_n}")#text(" converges to ")#mi("{1}")#text(". In particular, all but finitely many of the ")#mi("{a_n}")#text(" lie in the disk ")#mi("{D(1,1/2)}")#text(". We can then factor ")#mi("{\\prod_{n=1}^\\infty a_n = \\prod_{n=1}^N a_n \\times \\prod_{n=N+1}^\\infty a_n}")#text(", where ")#mi("{N}")#text(" is such that ")#mi("{a_n \\in D(1,1/2)}")#text(" for ")#mi("{n > N}")#text(", and we see that it will suffice to show that the infinite product ")#mi("{\\prod_{n=N+1}^\\infty a_n}")#text(" converges to a non-zero number. But on using the standard branch ")#mi("{\\mathrm{Log}}")#text(" of the complex logarithm on ")#mi("{D(1,1/2)}")#text(" we can write ")#mi("{a_n = \\exp( \\mathrm{Log} a_n )}")#text(". By Taylor expansion we have ")#tao-math("{\\mathrm{Log} a_n = O( \\left|a_n-1\\right| )}", block: false)#text(", hence the series ")#mi("{\\sum_{n=N+1}^\\infty \\mathrm{Log} a_n}")#text(" is absolutely convergent. From the properties of the complex exponential we then see that the product ")#mi("{\\prod_{n=N+1}^\\infty a_n}")#text(" converges to ")#mi("{\\exp(\\sum_{n=N+1}^\\infty \\mathrm{Log} a_n)}")#text(", giving the claim. ")#mi("\\Box")

#text("It is well known that absolutely convergent series are preserved by rearrangement, and the same is true for absolutely convergent products:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-b5836afbcf79c53e3956>#text(" If ")#mi("{\\prod_{n=1}^\\infty a_n}")#text(" is an absolutely convergent product of complex numbers ")#mi("{a_n}")#text(", show that any permutation of the ")#mi("{a_n}")#text(" leads to the same absolutely convergent product, thus ")#mi("{\\prod_{n=1}^\\infty a_n = \\prod_{m=1}^\\infty a_{\\phi(m)}}")#text(" for any permutation ")#mi("{\\phi}")#text(" of the positive integers ")#mi("{\\{1,2,3,\\dots\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]

#list(
[#text("(i) Let ")#mi("{a_n}")#text(" be a sequence of real numbers with ")#mi("{a_n \\geq 1}")#text(" for all ")#mi("{n}")#text(". Show that ")#mi("{\\prod_{n=1}^\\infty a_n}")#text(" converges if and only if ")#mi("{\\sum_{n=1}^\\infty (a_n-1)}")#text(" converges.")],
[#text("(ii) Let ")#mi("{z_n}")#text(" be a sequence of complex numbers. Show that ")#mi("{\\prod_{n=1}^\\infty (1+z_n)}")#text(" is absolutely convergent if and only if ")#tao-math("{\\prod_{n=1}^\\infty (1+\\left|z_n\\right|)}", block: false)#text(" is convergent.")]
)
]

#text("To try to use Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(", we can divide each factor ")#mi("{z-z_n}")#text(" by the constant ")#mi("{-z_n}")#text(" to make it closer to ")#mi("{1}")#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\frac{z-z_n}{-z_n} = 1 - \\frac{z}{z_n}")]]

#text("we can thus attempt to construct the desired entire function ")#mi("{f}")#text(" using the formula")

#metadata(none) <tao-f284bdc3c1c9e24a494e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("f(z) = \\prod_{n=1}^\\infty (1 - \\frac{z}{z_n}).")]]

#text("Immediately there is the objection that this product is undefined if one or more of the putative zeroes ")#mi("{z_n}")#text(" is located at the origin, this objection is easily dealt with since the origin can only occur finitely many (say ")#mi("{m}")#text(") times, so if we remove the ")#mi("{m}")#text(" copies of the origin from the sequence of zeroes ")#mi("{z_n}")#text(", apply the Weierstrass factorisation theorem to the remaining zeroes, and then multiply the resulting entire function by ")#mi("{z^m}")#text(", we can reduce to the case where the origin is not one of the zeroes.")

#text("In order to apply Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(" to make this product converge, we would need ")#tao-math("{\\sum_{n=1}^\\infty \\frac{\\left|z\\right|}{\\left|z_n\\right|}}", block: false)#text(" to converge for every ")#mi("{z}")#text(", or equivalently that ")#metadata(none) <tao-dc5f8effd972f18365ee>#tao-math("\\displaystyle  \\sum_{n=1}^\\infty \\frac{1}{\\left|z_n\\right|} < \\infty. \\ \\ \\ \\ \\ (13)", block: false)#text(" ")#text(" This is basically a requirement that the ")#mi("{z_n}")#text(" converge to infinity sufficiently quickly. Not all sequences ")#mi("{z_n}")#text(" covered by Theorem ")#link(<tao-714962e22ae899f03bdc>)[#text("15")]#text(" obey this condition, but let us begin with this case for sake of argument. Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(" now tells us that ")#mi("{f(z)}")#text(" is well-defined for every ")#mi("{z}")#text(", and vanishes if and only if ")#mi("{z}")#text(" is equal to one of the ")#mi("{z_n}")#text(". However, we need to establish holomorphicity. This can be accomplished by the following product form of the ")#link("https://en.wikipedia.org/wiki/Weierstrass_M-test")[#text("Weierstrass ")#mi("{M}")#text("-test")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19 (Product Weierstrass ")#mi("{M}")#text("-test)")]#text(" ")#metadata(none) <tao-0a2374d28353b14422a5>#text(" Let ")#mi("{X}")#text(" be a set, and for any natural number ")#mi("{n}")#text(", let ")#mi("{f_n: X \\rightarrow {\\bf C}}")#text(" be a bounded function. If the sum ")#tao-math("{\\sum_{n=1}^\\infty \\sup_{x \\in X} \\left|f_n(x)-1\\right| \\leq M}", block: false)#text(" for some finite ")#mi("{M}")#text(", show that the products ")#mi("{\\prod_{n=1}^N f_n}")#text(" converge uniformly to ")#mi("{\\prod_{n=1}^\\infty f_n}")#text(" on ")#mi("{X}")#text(". (In particular, if ")#mi("{X}")#text(" is a topological space and all the ")#mi("{f_n}")#text(" are continuous, then ")#mi("{\\prod_{n=1}^\\infty f_n}")#text(" is continuous also.)")
]

#text("Using this exercise, we see that (under the assumption ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(") that the partial products ")#mi("{\\prod_{n=1}^N (1 - \\frac{z}{z_n})}")#text(" converge locally uniformly to the infinite product in ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(12)")]#text(". Since each of the partial products are entire, and the (locally) uniform limit of holomorphic functions is holomorphic (Theorem 34 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("246A Notes 3")]#text("), we conclude that the function ")#link(<tao-f284bdc3c1c9e24a494e>)[#text("(12)")]#text(" is entire. Finally, if a certain zero ")#mi("{z_j}")#text(" appears ")#mi("{m}")#text(" times in the sequence, then after factoring out ")#mi("{m}")#text(" copies of ")#mi("{(1-\\frac{z}{z_j})}")#text(" we see that ")#mi("{f(z)}")#text(" is the product of ")#mi("{(1-\\frac{z}{z_j})^m}")#text(" with an entire function that is non-vanishing at ")#mi("{z_j}")#text(", and thus ")#mi("{f}")#text(" has a zero of order exactly ")#mi("{m}")#text(" at ")#mi("{z_j}")#text(". This establishes the Weierstrass approximation theorem under the additional hypothesis that ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(" holds.")

#text("What if ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(" does not hold? The problem now is that our renormalized factors ")#mi("{1 - \\frac{z}{z_n}}")#text(" do not converge fast enough for Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(" or Exercise ")#link(<tao-0a2374d28353b14422a5>)[#text("19")]#text(" to apply. So we need to renormalize further, taking advantage of our ability to not just multiply by constants, but also by exponentials of entire functions. Observe that if ")#mi("{z}")#text(" is fixed and ")#mi("{n}")#text(" is large enough, then ")#mi("{1 - \\frac{z}{z_n}}")#text(" lies in ")#mi("{D(1,1/2)}")#text(" and we can write")

#align(center)[#tao-fit-display[#mitex("1 - \\frac{z}{z_n} = \\exp( \\mathrm{Log}( 1 - \\frac{z}{z_n} ) ).")]]

#text("The function ")#mi("{\\mathrm{Log}( 1 - \\frac{z}{z_n} )}")#text(" is not entire, but its Taylor approximation ")#mi("{-\\frac{z}{z_n}}")#text(" is. So it is natural to split")

#align(center)[#tao-fit-display[#mitex("1 - \\frac{z}{z_n} = \\exp(-\\frac{z}{z_n}) \\exp( \\mathrm{Log}( 1 - \\frac{z}{z_n} ) + \\frac{z}{z_n} ) = \\exp(-\\frac{z}{z_n}) e^{\\frac{z}{z_n}} (1-\\frac{z}{z_n}).")]]

#text("We now discard the ")#mi("{\\exp(-\\frac{z}{z_n})}")#text(" factors (which do not affect the zeroes) and now propose the new candidate entire function")

#align(center)[#tao-fit-display[#mitex("f(z) = \\prod_{n=1}^\\infty e^{\\frac{z}{z_n}} (1-\\frac{z}{z_n}).")]]

#text("The point here is that for ")#mi("{n}")#text(" large enough, Taylor expansion gives")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Log}( 1 - \\frac{z}{z_n} ) + \\frac{z}{z_n} = O( \\frac{\\left|z\\right|^2}{\\left|z_n\\right|^2})", block: true)]]

#text("and thus on exponentiating")

#align(center)[#tao-fit-display[#tao-math("e^{\\frac{z}{z_n}} (1-\\frac{z}{z_n}) = 1 + O( \\frac{\\left|z\\right|^2}{\\left|z_n\\right|^2}).", block: true)]]

#text("Repeating the previous arguments, we can then verify that ")#mi("{f}")#text(" is an entire function with the required properties as long as we have the hypothesis")

#metadata(none) <tao-20144b194de5d882f669>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\sum_{n=1}^\\infty \\frac{1}{\\left|z_n\\right|^2} < \\infty", block: true)]]

#text("which is weaker than ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(" (for instance it is obeyed when ")#mi("{z_n=n}")#text(", whereas ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(" fails in this case).")

#text("This suggests the way forward to the general case of the Weierstrass factorisation theorem, by using increasingly accurate Taylor expansions of")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Log}( 1 - \\frac{z}{z_n} ) = -\\frac{z}{z_n}-\\frac{1}{2} \\frac{z^2}{z_n^2} - \\frac{1}{3} \\frac{z^3}{z_n^3} - \\dots")]]

#text("when ")#tao-math("{\\left|z\\right|/\\left|z_n\\right| \\leq 1/2}", block: false)#text(". To formalise this strategy, it is convenient to introduce the ")#emph[#text("canonical factors")]

#metadata(none) <tao-67799471292c2c4395fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("E_k(z) := (1-z) \\exp( \\sum_{j=1}^k \\frac{z^j}{j} )")]]

#text("for any complex number ")#mi("{z}")#text(" and natural number ")#mi("{k}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("E_0(z) = 1-z; \\quad E_1(z) = e^z (1-z); \\quad E_2(z) = e^{z+z^2/2} (1-z).")]]

#text("For any fixed ")#mi("{k}")#text(", these functions are entire and have precisely one zero, at ")#mi("{z=1}")#text(". In the disk ")#mi("{D(0,1/2)}")#text(", the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Log}(1-z) = - z - \\frac{z^2}{2} - \\frac{z^3}{3} - \\dots")]]

#text("indicates that the ")#mi("{E_k(z)}")#text(" converge uniformly to ")#mi("{1}")#text(" as ")#mi("{k \\rightarrow \\infty}")#text(". Indeed, for ")#mi("{z \\in D(0,1/2)}")#text(" we have")

#tao-aligned(keep: true)[


#tao-math("E_k(z)  & = \\exp( - \\sum_{j=k+1}^\\infty \\frac{z^j}{j} )", block: true)



#tao-math(" & = \\exp( \\sum_{j=k+1}^\\infty O( 2^{-j}/k ) )", block: true)



#tao-math(" & = \\exp( O( 2^{-k} ) )", block: true)

#metadata(none) <tao-5e1cf42878df58fea7bf>

#tao-math(" & = 1 + O(2^{-k})", block: true, numbering: n => [#text("(16)")])
]

#text("For our choice of entire function ")#mi("{f}")#text(" we can now try")

#align(center)[#tao-fit-display[#mitex("f(z) := \\prod_{n=1}^\\infty E_{k_n}(z/z_n)")]]

#text("where ")#mi("{k_1,k_2,\\dots}")#text(" are natural numbers we are at liberty to choose. To get as good a convergence for the product we can make the ")#mi("{k_n}")#text(" go to infinity as fast as we please; but it turns out that the (somewhat arbitrary) choice of ")#mi("{k_n := n}")#text(" will suffice for proving Weierstrass’s theorem, that is to say the product")

#align(center)[#tao-fit-display[#mitex("f(z) := \\prod_{n=1}^\\infty E_n(z/z_n)")]]

#text("is absolutely convergent (so that Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(" and Exercise ")#link(<tao-0a2374d28353b14422a5>)[#text("19")]#text(" applies, producing an entire function with the required zeroes). Indeed, for ")#mi("{z}")#text(" in any disk ")#mi("{D(0,R)}")#text(", there is some ")#mi("{n_0}")#text(" such that ")#tao-math("{\\left|z_n\\right| \\geq 2R}", block: false)#text(" for ")#mi("{n \\geq n_0}")#text(", and for such ")#mi("{n}")#text(" we have ")#mi("{E_n(z/z_n)-1 = O( 2^{-n})}")#text(" by ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(16)")]#text(", giving the desired uniform absolute convergence on any disk ")#mi("{D(0,R)}")#text(", establishing the Weierstrass theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{U}")#text(" be a connected non-empty open subset of ")#mi("{{\\bf C}}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{z_1,z_2,\\dots}")#text(" is any sequence of points in ")#mi("{U}")#text(", that has no accumulation point inside ")#mi("{U}")#text(", then there exists a holomorphic function ")#mi("{f: U \\rightarrow {\\bf C}}")#text(" that has zeroes precisely at the ")#mi("{z_j}")#text(", with the order of each zero ")#mi("{z_j}")#text(" being the number of times ")#mi("{z_j}")#text(" occurs in the sequence.")],
[#text("(ii) Show that any meromorphic function on ")#mi("{U}")#text(" can be expressed as the ratio of two holomorphic functions on ")#mi("{U}")#text(" (with the denominator being non-zero). Conclude that the field of meromorphic functions on ")#mi("{U}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Field_of_fractions")[#text("fraction field")]#text(" of the ring of holomorphic functions on ")#mi("{U}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Mittag-Leffler theorem, special case)")]#text(" Let ")#mi("{z_n}")#text(" be a sequence of distinct complex numbers going to infinity, and for each ")#mi("{n}")#text(", let ")#mi("{P_n}")#text(" be a polynomial. Show that there exists a meromorphic function ")#mi("{f: {\\bf C} \\backslash \\{z_1,z_2,\\dots\\} \\rightarrow {\\bf C}}")#text(" whose singularity at each each ")#mi("{z_n}")#text(" is given by ")#mi("{P_n(\\frac{1}{z-z_n})}")#text(", in the sense that ")#mi("{f(z) - P_n(\\frac{1}{z-z_n})}")#text(" has a removable singularity at ")#mi("{z_n}")#text(". (")#emph[#text("Hint:")]#text(" consider a sum of the form ")#mi("{\\sum_n P_n(\\frac{1}{z-z_n}) - Q_n(z)}")#text(", where ")#mi("{Q_n(z)}")#text(" is a partial Taylor expansion of ")#mi("{P_n(\\frac{1}{z-z_n})}")#text(" in the disk ")#tao-math("{D(0,\\left|z_n\\right|/2)}", block: false)#text(", chosen so that the sum becomes locally uniformly absolutely convergent.) This is a special case of the ")#link("https://en.wikipedia.org/wiki/Mittag-Leffler%27s_theorem")[#text("Mittag-Leffler theorem")]#text(", which is the same statement but in which the domain ")#mi("{{\\bf C}}")#text(" is replaced by an arbitrary open set ")#mi("{U}")#text("; however, the proof of this generalisation is more difficult, requiring tools such as ")#link("https://en.wikipedia.org/wiki/Runge%27s_theorem")[#text("Runge’s approximation theorem")]#text(" which are not covered here.")
]

#heading(level: 1)[#strong[#text(" — 3. The Hadamard factorisation theorem — ")]]

#text("The Weierstrass factorisation theorem (and its proof) shows that any entire function ")#mi("{f}")#text(" that is not identically zero can be factorised as")

#align(center)[#tao-fit-display[#mitex("f(z) = e^{g(z)} z^m \\prod_n E_n(z/z_n)")]]

#text("where ")#mi("{m}")#text(" is the order of vanishing of ")#mi("{f}")#text(" at the origin, ")#mi("{z_n}")#text(" are the zeroes of ")#mi("{f}")#text(" away from the origin (counting multiplicity), and ")#mi("{g}")#text(" is an additional entire function. However, this factorisation is not always convenient to work with in practice, in large part because the index ")#mi("{n}")#text(" of the canonical factors ")#mi("{E_n}")#text(" involved are unbounded, and also because not much information is provided about the entire function ")#mi("{g}")#text(". It turns out the situation becomes better if the entire function ")#mi("{f}")#text(" is also known to be of ")#link("https://en.wikipedia.org/wiki/Entire_function#Order_and_type")[#text("order at most ")#mi("{\\rho}")]#text(" for some ")#mi("{\\rho \\geq 0}")#text(", by which we mean that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq C_\\varepsilon \\exp( \\left|z\\right|^{\\rho+\\varepsilon})", block: true)]]

#text("for every ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{z}")#text(", or in asymptotic notation")

#metadata(none) <tao-3097e26b7f3cbdb92076>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("f(z) = O_\\varepsilon(\\exp( \\left|z\\right|^{\\rho+\\varepsilon} )).", block: true)]]

#text("In this case we expect to obtain a more precise factorisation for the following reason. Let us suppose we are in the simplest case where ")#mi("{f}")#text(" has no zeroes whatsoever. Then we have ")#mi("{f = \\exp(g)}")#text(" for an entire function ")#mi("{g}")#text(". From ")#link(<tao-3097e26b7f3cbdb92076>)[#text("(17)")]#text(" we then have")

#metadata(none) <tao-68b076be5ba974795f92>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\mathrm{Re} g(z) \\leq O_\\varepsilon(( 1 + \\left|z\\right|)^{\\rho+\\varepsilon})", block: true)]]

#text("for all ")#mi("{z}")#text(". This only controls the real part of ")#mi("{g}")#text(" from above, but by applying the Borel-Carathéodory theorem (Exercise ")#link(<tao-1e0bbd6c686ba050b8eb>)[#text("10")]#text(") to the disks ")#tao-math("{\\overline{D(0,2\\left|z\\right|)}}", block: false)#text(" we obtain a bound of the form")

#align(center)[#tao-fit-display[#tao-math("g(z) = O_{\\rho,\\varepsilon,g(0)}( (1 + \\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("for all ")#mi("{\\varepsilon>0}")#text(" and all ")#mi("{z}")#text(". That is to say, ")#mi("{g}")#text(" is of polynomial growth of order at most ")#mi("{\\rho}")#text(". Applying Exercise 31 of ")#link("https://terrytao.wordpress.com/2016/10/02/math-246a-notes-3-cauchys-theorem-and-its-consequences/")[#text("246A Notes 3")]#text(", we conclude that ")#mi("{g}")#text(" must be a polynomial, and given its growth rate, it must have degree at most ")#mi("{d}")#text(", where ")#mi("{d := \\lfloor \\rho \\rfloor}")#text(" is the integer part of ")#mi("{\\rho}")#text(". This hints that the entire function ")#mi("{g}")#text(" that appears in the Weierstrass factorisation theorem could be taken to be a polynomial, if the theorem is formulated correctly. This is indeed the case, and is the content of the ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem#Hadamard_factorization_theorem")[#text("Hadamard factorisation theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 22 (Hadamard factorisation theorem)")]#text(" Let ")#mi("{\\rho \\geq 0}")#text(", let ")#mi("{d := \\lfloor \\rho \\rfloor}")#text(", and let ")#mi("{f}")#text(" be an entire function of order at most ")#mi("{\\rho}")#text(" (not identically zero), with a zero of order ")#mi("{m \\geq 0}")#text(" at the origin and the remaining zeroes indexed (with multiplicity) as a finite or infinite sequence ")#mi("{z_1, z_2, \\dots}")#text(". Then")

#metadata(none) <tao-c380779f6175766fdbe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("f(z) = e^{g(z)} z^m \\prod_n E_d(z/z_n)")]]

#text("for some polynomial ")#mi("{g}")#text(" of degree at most ")#mi("{d}")#text(". The convergence in the infinite product is locally uniform.")
]

#text("We now prove this theorem. By dividing out by ")#mi("{z^m}")#text(" (which does not affect the order of ")#mi("{f}")#text(") and removing the singularity at the origin, we may assume that ")#mi("{m=0}")#text(". If there are no other zeroes ")#mi("{z_n}")#text(" then we are already done by the previous discussion; similarly if there are only finitely many zeroes ")#mi("{z_n}")#text(" we can divide out by the finite number of elementary factors and remove singularities and again reduce to a case we have already established. Hence we may suppose that the sequence of zeroes ")#mi("{z_n}")#text(" is infinite. As the zeroes of ")#mi("{f}")#text(" are isolated, this forces ")#mi("{z_n}")#text(" to go to infinity as ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("Let us first check that the product ")#mi("{\\prod_{n=1}^\\infty E_d(z/z_n)}")#text(" is absolutely convergent and locally uniform. A modification of the bound ")#link(<tao-5e1cf42878df58fea7bf>)[#text("(16)")]#text(" shows that")

#align(center)[#tao-fit-display[#tao-math("E_d(z/z_n) = 1 + O_d( \\left|z\\right|^{d+1}/\\left|z_n\\right|^{d+1})", block: true)]]

#text("if ")#tao-math("{\\left|z\\right|/\\left|z_n\\right| \\leq 1/2}", block: false)#text(", which is the case for all but finitely many ")#mi("{n}")#text(" if ")#mi("{z}")#text(" is confined to a fixed compact set. Thus we will get absolute convergence from Lemma ")#link(<tao-6754af9632a2745e85c2>)[#text("16")]#text(" (and also holomorphicity of the product from Exercise ")#link(<tao-0a2374d28353b14422a5>)[#text("19")]#text(") once we establish the convergence")

#metadata(none) <tao-139d544b821b13ebea14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\sum_{n=1}^\\infty \\frac{1}{\\left|z_n\\right|^{d+1}} < \\infty", block: true)]]

#text("(compare with ")#link(<tao-dc5f8effd972f18365ee>)[#text("(13)")]#text(", ")#link(<tao-20144b194de5d882f669>)[#text("(14)")]#text(", which are basically the ")#mi("{d=0,1}")#text(" cases of this analysis).")

#text("To achieve this convergence we will use the technique of dyadic decomposition (a generalisation of the ")#link("https://en.wikipedia.org/wiki/Cauchy_condensation_test")[#text("Cauchy condensation test")]#text("). Only a finite number of zeroes ")#mi("{z_n}")#text(" lie in the disk ")#mi("{D(0,1)}")#text(", and we have already removed all zeroes at the origin, so by removing those finite zeroes we may assume that ")#tao-math("{\\left|z_n\\right| \\geq 1}", block: false)#text(" for all ")#mi("{n}")#text(". In particular, each remaining zero ")#mi("{z_n}")#text(" lies in an annulus ")#tao-math("{\\{ z: 2^k \\leq \\left|z\\right| < 2^{k+1}\\}}", block: false)#text(" for some natural number ")#mi("{k}")#text(". On each such annulus, the expression ")#tao-math("{\\frac{1}{\\left|z_n\\right|^{d+1}}}", block: false)#text(" is at most ")#mi("{2^{-k(d+1)}}")#text(" (and is in fact comparable to this quantity up to a constant depending on ")#mi("{d}")#text(", which is why we expect the dyadic decomposition method to be fairly efficient). Grouping the terms in ")#link(<tao-139d544b821b13ebea14>)[#text("(20)")]#text(" according to the annulus they lie in, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{k=0}^\\infty \\frac{N_k}{2^{k(d+1)}} < \\infty")]]

#text("where ")#mi("{N_k}")#text(" is the number of zeroes of ")#mi("{f}")#text(" (counting multiplicity) in the annulus ")#tao-math("{\\{ z: 2^k \\leq \\left|z\\right| < 2^{k+1}\\}}", block: false)#text(". But by Proposition ")#link(<tao-92da40b4ed7468ae120f>)[#text("8")]#text(", one has ")#mi("{N_k = O_{\\rho,\\varepsilon,f}( 2^{k(\\rho+\\varepsilon)})}")#text(" for any ")#mi("{\\varepsilon>0}")#text(". Since ")#mi("{d}")#text(" is the integer part of ")#mi("{\\rho}")#text(", one can choose ")#mi("{\\varepsilon}")#text(" small enough that ")#mi("{\\rho+\\varepsilon < d+1}")#text(", and so the series is dominated by a convergent geometric series and is thus itself convergent. This establishes the convergence of the product ")#mi("{\\prod_n E_d(z/z_n)}")#text(". This function has zeroes in the same locations as ")#mi("{f}")#text(" with the same orders, so by the same arguments as before we have")

#align(center)[#tao-fit-display[#mitex("f(z) = e^{g(z)} \\prod_{n=1}^\\infty E_d(z/z_n)")]]

#text("for some entire function ")#mi("{g}")#text(". It remains to show that ")#mi("{g}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(". If we could show the bound ")#link(<tao-68b076be5ba974795f92>)[#text("(18)")]#text(" for all ")#mi("{z}")#text(" and any ")#mi("{\\varepsilon>0}")#text(", we would be done. Taking absolute values and logarithms, we have")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} g(z) = \\log \\left|f(z)\\right| - \\sum_{n=1}^\\infty \\log \\left|E_d(z/z_n)\\right|", block: true)]]

#text("for ")#mi("{z \\neq z_1,z_2,\\dots}")#text(" and hence as ")#mi("{f}")#text(" is of order ")#mi("{\\rho}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} g(z) \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} ) - \\sum_{n=1}^\\infty \\log \\left|E_d(z/z_n)\\right|", block: true)]]

#text("for ")#mi("{z \\neq z_1,z_2,\\dots}")#text(". So if, for a given choice of ")#mi("{\\varepsilon>0}")#text(", we could show the lower bound")

#metadata(none) <tao-83fa74e70278e5b9ff3f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{n=1}^\\infty \\log \\left|E_d(z/z_n)\\right| \\geq - O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("for all ")#mi("{z \\neq z_1,z_2,\\dots}")#text(", we would be done (since ")#mi("{g}")#text(" is continuous at each ")#mi("{z_n}")#text(", so the restriction ")#mi("{z \\neq z_1,z_2,\\dots}")#text(" can be removed as far as upper bounding ")#mi("{g}")#text(" is concerned). Unfortunately this can’t quite work as stated, because the factors ")#mi("{E_d(z/z_n)}")#text(" go to zero as ")#mi("{z}")#text(" approaches ")#mi("{z_n}")#text(", so ")#tao-math("{\\log \\left|E_d(z/z_n)\\right|}", block: false)#text(" approaches ")#mi("{-\\infty}")#text(". So the desired bound ")#link(<tao-83fa74e70278e5b9ff3f>)[#text("(21)")]#text(" can’t work when ")#mi("{z}")#text(" gets too close to one of the zeroes ")#mi("{z_n}")#text(". On the other hand, this logarithmic divergence is rather mild, so one can hope to somehow evade it. Indeed, suppose we are still able to obtain ")#link(<tao-83fa74e70278e5b9ff3f>)[#text("(21)")]#text(" for a sufficiently “dense” set of ")#mi("{z}")#text(", and more precisely for all ")#mi("{z}")#text(" on a sequence ")#tao-math("{\\{ \\left|z\\right| = R_k \\}}", block: false)#text(" of circles of radii ")#mi("{2^k \\leq R_k <2^{k+1}}")#text(" for ")#mi("{k=1,2,\\dots}")#text(". Then the above argument lets us establish the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} g(z) \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("when ")#tao-math("{\\left|z\\right|=R_k}", block: false)#text(". But by the maximum principle (applied to the harmonic function ")#mi("{\\mathrm{Re} g}")#text(") this then gives")

#align(center)[#tao-fit-display[#tao-math("\\mathrm{Re} g(z) \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("for all ")#mi("{z}")#text(" (because we have an upper bound of ")#mi("{O_{f,\\rho,\\varepsilon}( (1+R_k)^{\\rho+\\varepsilon} )}")#text(" on each disk ")#mi("{D(0,R_k)}")#text(", and each ")#mi("{z}")#text(" lies in one of the disks ")#mi("{D(0,R_k)}")#text(" with ")#tao-math("{1+\\left|z\\right| \\sim 1+R_k}", block: false)#text(").")

#text("So it remains to establish ")#link(<tao-83fa74e70278e5b9ff3f>)[#text("(21)")]#text(" for ")#mi("{z}")#text(" in a sufficiently dense set of circles ")#tao-math("{\\{ \\left|z\\right| = R_k\\}}", block: false)#text(". We need lower bounds on ")#tao-math("{\\log \\left|E_d(z/z_n)\\right|}", block: false)#text(". In the regime where the zeroes are distant in the sense that ")#tao-math("{\\left|z\\right|/\\left|z_n\\right| \\leq 1/2}", block: false)#text(", Taylor expansion gives")

#align(center)[#tao-fit-display[#tao-math("E_d(z/z_n) = \\exp( O_d( \\left|z\\right|^{d+1}/\\left|z_n\\right|^{d+1} ) )", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| \\leq 1/2} \\log \\left|E_d(z/z_n)\\right| \\geq - O_d( \\sum_{n: \\left|z\\right|/\\left|z_n\\right| \\leq 1/2} \\left|z\\right|^{d+1}/\\left|z_n\\right|^{d+1} ).", block: true)]]

#text("We can adapt the proof of ")#link(<tao-139d544b821b13ebea14>)[#text("(20)")]#text(" to control this portion adequately:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" ")#metadata(none) <tao-a3b142af6e97cfc3bb23>#text(" Establish the upper bounds")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| \\leq 1/2} \\left|z\\right|^{d+1}/\\left|z_n\\right|^{d+1} \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\left|z\\right|^{d}/\\left|z_n\\right|^{d} \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("(the latter bound will be useful momentarily).")
]

#text("It thus remains to control the nearby zeroes, in the sense of showing that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\log \\left|E_d(z/z_n)\\right| \\geq -O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("for all ")#mi("{z}")#text(" in a set of concentric circles ")#tao-math("{\\{ \\left|z\\right| = R_k\\}}", block: false)#text(" with ")#mi("{2^k \\leq R_k < 2^{k+1}}")#text(". Thus we need to lower bound ")#tao-math("{\\log \\left|E_d(w)\\right|}", block: false)#text(" for ")#tao-math("{\\left|w\\right| > 1/2}", block: false)#text(". Here we no longer attempt to take advantage of Taylor expansion as the convergence is too poor in this regime, so we fall back to the triangle inequality. Indeed from ")#link(<tao-67799471292c2c4395fb>)[#text("(15)")]#text(" and that inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\log \\left|E_d(w)\\right|  & \\geq - \\log \\frac{1}{\\left|1-w\\right|} - \\sum_{j=1}^d \\frac{\\left|w\\right|^j}{j}", block: true)



#tao-math(" & \\geq -\\log \\frac{1}{\\left|1-w\\right|} - O_d(\\left|w\\right|^d)", block: true)
]

#text("hence")

#tao-aligned(keep: true)[


#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\log \\left|E_d(z/z_n)\\right|  & \\geq -\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\log \\frac{1}{\\left|1-z/z_n\\right|}", block: true)



#tao-math(" & - O_d(\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\frac{\\left|z\\right|^d}{\\left|z_n\\right|^d} ).", block: true)
]

#text("From the second part of Exercise ")#link(<tao-a3b142af6e97cfc3bb23>)[#text("23")]#text(", the contribution of the latter term is acceptable, so it remains to establish the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: \\left|z\\right|/\\left|z_n\\right| > 1/2} \\log \\frac{1}{\\left|1-z/z_n\\right|} \\leq O_{f,\\rho,\\varepsilon}( (1+\\left|z\\right|)^{\\rho+\\varepsilon} )", block: true)]]

#text("for ")#mi("{z}")#text(" in a set of concentric circles ")#tao-math("{\\{ \\left|z\\right| = R_k\\}}", block: false)#text(" with ")#mi("{2^k \\leq R_k < 2^{k+1}}")#text(".")

#text("Given the set of ")#mi("{z}")#text(" we are working with, it is natural to introduce the radial variable ")#tao-math("{r := \\left|z\\right|}", block: false)#text(". From the triangle inequality one has ")#tao-math("{\\left|1-z/z_n\\right| \\geq \\left|1-r/\\left|z_n\\right|\\right|}", block: false)#text(", so it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n: r/\\left|z_n\\right| > 1/2} \\log \\frac{1}{\\left|1-r/\\left|z_n\\right|\\right|} \\leq O_{f,\\rho,\\varepsilon}( 2^{(\\rho+\\varepsilon)k} )", block: true)]]

#text("for at least one radius ")#mi("{r \\in [2^k, 2^{k+1})}")#text(" for each natural number ")#mi("{k}")#text(". Note that we cannot just pick any radius ")#mi("{r}")#text(" here, because if ")#mi("{r}")#text(" happens to be too close to one of the ")#tao-math("{\\left|z_n\\right|}", block: false)#text(" then the term ")#tao-math("{\\log \\frac{1}{\\left|1-r/\\left|z_n\\right|\\right|}}", block: false)#text(" will become unbounded. But we can avoid this by the strategy of the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(": we just choose ")#mi("{r}")#text(" ")#emph[#text("randomly")]#text(" in the interval ")#mi("{[2^k, 2^{k+1})}")#text(". As long we can establish the ")#emph[#text("average")]#text(" bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2^k} \\int_{2^k}^{2^{k+1}} \\sum_{n: r/\\left|z_n\\right| > 1/2} \\log \\frac{1}{\\left|1-r/\\left|z_n\\right|\\right|}\\ dr \\leq O_{f,\\rho,\\varepsilon}( 2^{(\\rho+\\varepsilon)k} )", block: true)]]

#text("we can use the pigeonhole principle to find ")#emph[#text("one")]#text(" good radius ")#mi("{r}")#text(" in the desired range, which is all we need.")

#text("The point is that this averaging can take advantage of the mild nature of the logarithmic singularity. Indeed a routine computation shows that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2^k} \\int_{2^k}^{2^{k+1}} 1_{r/R > 1/2} \\log \\frac{1}{\\left|1-r/R\\right|}\\ dr", block: true)]]

#text("vanishes unless ")#mi("{R \\leq 2^{k+2}}")#text(" and is bounded by ")#mi("{O(1)}")#text(" otherwise, so by the linearity of integration and the triangle inequality the left-hand side is bounded by")

#align(center)[#tao-fit-display[#tao-math("O( \\sum_{n: \\left|z_n\\right| \\leq 2^{k+2}} 1 )", block: true)]]

#text("and the claim now follows from Proposition ")#link(<tao-92da40b4ed7468ae120f>)[#text("8")]#text(". This concludes the proof of the Hadamard factorisation theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Converse to Hadamard factorisation)")]#text(" ")#metadata(none) <tao-375a32eb60de071b4d66>#text(" Let ")#mi("{\\rho \\geq 0}")#text(", let ")#mi("{m}")#text(" be a natural number, and let ")#mi("{z_1,z_2,\\dots}")#text(" be a finite or infinite sequence of non-zero complex numbers such that ")#tao-math("{\\sum_{n=1}^\\infty \\frac{1}{\\left|z_n\\right|^{\\rho+\\varepsilon}} < \\infty}", block: false)#text(" for every ")#mi("{\\varepsilon>0}")#text(". Let ")#mi("{d := \\lfloor \\rho\\rfloor}")#text(". Show that for every polynomial ")#mi("{g}")#text(" of degree at most ")#mi("{d}")#text(", the function ")#mi("{f}")#text(" defined by ")#link(<tao-c380779f6175766fdbe9>)[#text("(19)")]#text(" is an entire function of order at most ")#mi("{\\rho}")#text(", with a zero of order ")#mi("{m}")#text(" at the origin, zeroes at each ")#mi("{z_j}")#text(" of order equal to the number of times ")#mi("{z_j}")#text(" occurs in the sequence, and no other zeroes. Thus we see that we have a one-to-one correspondence between non-trivial entire functions of order at most ")#mi("{\\rho}")#text(" ( up to multiplication by ")#mi("{e^{g(z)}}")#text(" factors for ")#mi("{g}")#text(" a polynomial of degree at most ")#mi("{d}")#text(") and zeroes ")#mi("{z_n}")#text(" obeying a certain growth condition.")
]

#text("As an illustration of the Hadamard factorisation theorem, we apply it to the entire function ")#mi("{\\sin(z)}")#text(". Since")

#align(center)[#tao-fit-display[#tao-math("\\sin(z) = O( \\left|e^{iz}\\right| + \\left|e^{-iz}\\right| ) = O( \\exp( \\left|z\\right| ) )", block: true)]]

#text("we see that ")#mi("{\\sin}")#text(" is of order at most ")#mi("{1}")#text(" (indeed it is not difficult to show that its order is exactly ")#mi("{1}")#text("). Also, its zeroes are the integer multiples ")#mi("{\\pi n}")#text(" of ")#mi("{\\pi}")#text(", with ")#mi("{n \\in {\\bf Z}}")#text(". The Hadamard factorisation theorem then tells us that we have the product expansion")

#align(center)[#tao-fit-display[#mitex("\\sin(z) = e^{g(z)} z \\prod_{n \\in {\\bf Z} \\backslash \\{0\\}} E_1(\\frac{z}{\\pi n})")]]

#text("for some polynomial ")#mi("{g}")#text(" of degree at most ")#mi("{1}")#text(". Writing ")#mi("{E_1(\\frac{z}{\\pi n}) = e^{z/\\pi n} (1 - \\frac{z}{\\pi n})}")#text(" we can group together the ")#mi("{n}")#text(" and ")#mi("{-n}")#text(" terms in the absolutely convergent product to get")

#align(center)[#tao-fit-display[#mitex("E_1(\\frac{z}{\\pi n}) E_1(\\frac{z}{\\pi (-n)}) = (1 - \\frac{z^2}{\\pi^2 n^2})")]]

#text("so the Hadamard factorisation can also be written in the form")

#align(center)[#tao-fit-display[#mitex("\\sin(z) = e^{g(z)} z \\prod_{n=1}^\\infty (1 - \\frac{z^2}{\\pi^2 n^2}).")]]

#text("But what is ")#mi("{g(z)}")#text("? Dividing by ")#mi("{z}")#text(" and taking a suitable branch ")#mi("{\\tilde \\log}")#text(" of the logarithm of ")#mi("{\\frac{\\sin z}{z}}")#text(" we see that")

#metadata(none) <tao-c4c62c862eb8c824a41c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\tilde \\log \\frac{\\sin z}{z} = g(z) + \\sum_{n=1}^\\infty \\mathrm{Log} (1 - \\frac{z^2}{\\pi^2 n^2})")]]

#text("for ")#mi("{z}")#text(" sufficiently close to zero (removing the singularity of ")#mi("{\\frac{\\sin z}{z}}")#text(" at the origin). By Taylor expansion we have")

#align(center)[#tao-fit-display[#mitex("\\frac{\\sin z}{z} = 1 - \\frac{z^2}{3!} + \\dots")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Log} (1 - \\frac{z^2}{\\pi^2 n^2}) = - \\frac{z^2}{\\pi^2 n^2} + \\dots")]]

#text("for ")#mi("{z}")#text(" close to ")#mi("{1}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\tilde \\log \\frac{\\sin z}{z} = 2k \\pi i - \\frac{z^2}{3!} + \\dots")]]

#text("for some integer ")#mi("{k}")#text(". Since ")#mi("{g}")#text(" is linear, we conclude on comparing coefficients that ")#mi("{g}")#text(" must in fact just be a constant ")#mi("{2k \\pi i}")#text(", and we can in fact normalise ")#mi("{k=0}")#text(" since shifting ")#mi("{g}")#text(" by an integer multiple of ")#mi("{2\\pi i}")#text(" does not affect ")#mi("{e^{g(z)}}")#text(". We conclude the ")#emph[#text("Euler sine product formula")]

#metadata(none) <tao-73ca7e07ccc925566e81>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sin(z) = z \\prod_{n=1}^\\infty (1 - \\frac{z^2}{\\pi^2 n^2})")]]

#text("(first conjectured by Euler in 1734). Inspecting the ")#mi("{z^2}")#text(" coefficients of ")#link(<tao-c4c62c862eb8c824a41c>)[#text("(22)")]#text(", we also see that")

#align(center)[#tao-fit-display[#mitex("-\\frac{1}{3!} = \\sum_{n=1}^\\infty -\\frac{1}{\\pi^2 n^2}")]]

#text("which rearranges to yield Euler’s famous formula")

#metadata(none) <tao-13b0a63aa355f8c3a697>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^2} = \\frac{\\pi^2}{6}")]]

#text("that solves the ")#link("https://en.wikipedia.org/wiki/Basel_problem")[#text("Basel problem")]#text(". Observe that by inspecting higher coefficients ")#mi("{z^{2k}}")#text(" of the Taylor series one more generally obtains identities of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\frac{1}{n^{2k}} = b_{2k} \\pi^{2k}")]]

#text("for all positive integers ")#mi("{k}")#text(" and some rational numbers ")#mi("{b_{2k}}")#text(" (which are essentially ")#link("https://en.wikipedia.org/wiki/Bernoulli_numbers")[#text("Bernoulli numbers")]#text("). Applying ")#link(<tao-73ca7e07ccc925566e81>)[#text("(23)")]#text(" to ")#mi("{z=\\pi/2}")#text(" and rearranging one also gets the famous ")#link("https://en.wikipedia.org/wiki/Wallis_product")[#text("Wallis product")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\pi}{2} = \\prod_{n=1}^\\infty (1 - \\frac{1}{4n^2})^{-1}.")]]

#text("Hadamard’s theorem also tells us that any other entire function of order at most ")#mi("{1}")#text(" that has simple zeroes at the integer multiples of ")#mi("{\\pi}")#text(", and no other zeroes, must take the form ")#mi("{e^{az+b} \\sin(z)}")#text(" for some complex numbers ")#mi("{a,b}")#text(". Thus the sine function is almost completely determined by its set of zeroes, together with the fact that it is an entire function of order ")#mi("{1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}} \\frac{1}{z^2 - n^2} = \\frac{\\pi \\cot(\\pi z)}{z}")]]

#text("for any complex number ")#mi("{z}")#text(" that is not an integer. Use this to give an alternate proof of ")#link(<tao-13b0a63aa355f8c3a697>)[#text("(24)")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. The Gamma function — ")]]

#text("As we saw in the previous section (and after applying a simple change of variables), the only entire functions of order ")#mi("{1}")#text(" that have simple zeroes at the integers (and nowhere else) are of the form ")#mi("{e^{az+b} \\sin(\\pi z)}")#text(". It is natural to ask what happens if one replaces the integers by the natural numbers ")#mi("{\\{0, 1, 2, \\dots\\}}")#text("; one could think of such functions as being in some sense “half” of the function ")#mi("{\\sin(\\pi z)}")#text(". Actually, it is traditional to normalise the problem a different way, and ask what entire functions of order ")#mi("{1}")#text(" have zeroes at the non-positive integers ")#mi("{0, -1, -2, -3, \\dots}")#text("; it is also traditional to refer to the complex variable in this problem by ")#mi("{s}")#text(" instead of ")#mi("{z}")#text(". By the Hadamard factorisation theorem, such functions must take the form")

#tao-aligned(keep: true)[


#tao-math("f(s)  & = s e^{as+b} \\prod_{n=1}^\\infty E_1(-s/n)", block: true)



#tao-math(" & =s e^{as+b} \\prod_{n=1}^\\infty e^{-s/n} (1+\\frac{s}{n})", block: true)
]

#text("for some complex numbers ")#mi("{a,b}")#text("; conversely, Exercise ")#link(<tao-375a32eb60de071b4d66>)[#text("24")]#text(" tells us that every function of this form is entire of order at most ")#mi("{1}")#text(", with simple zeroes at ")#mi("{0,-1,-2,\\dots}")#text(". We are free to select the constants ")#mi("{a,b}")#text(" as we please to produce a function ")#mi("{f}")#text(" of this class. It is traditional to normalise ")#mi("{b=0}")#text("; for the most natural normalisation of ")#mi("{a}")#text(", see below.")

#text("What properties would such functions have? The zero set ")#mi("{0,-1,-2,\\dots}")#text(" are nearly invariant with respect to the shift ")#mi("{s \\mapsto s+1}")#text(", so one expects ")#mi("{f(s)}")#text(" and ")#mi("{f(s+1)}")#text(" to be related. Indeed we have")

#tao-aligned(keep: true)[


#tao-math("f(s+1)  & = (s+1) e^{as+a} \\prod_{n=1}^\\infty e^{-(s+1)/n} (1+\\frac{s+1}{n})", block: true)



#tao-math(" & = (s+1) e^{as+a} \\prod_{n=2}^\\infty e^{-(s+1)/(n-1)} (1+\\frac{s+1}{n-1})", block: true)



#tao-math(" & = (s+1) e^{as+a} \\prod_{n=2}^\\infty e^{-s/(n-1)} (1+\\frac{s}{n}) (1+\\frac{1}{n-1}) e^{-1/(n-1)}", block: true)
]

#text("while")

#align(center)[#tao-fit-display[#mitex("f(s) = s e^{as} e^{-s} (1+s) \\prod_{n=2}^\\infty e^{-s/n} (1+\\frac{s}{n})")]]

#text("so we have (using the telescoping series ")#mi("{\\sum_{n=2}^\\infty \\frac{1}{n-1}-\\frac{1}{n} = 1}")#text(")")

#tao-aligned(keep: true)[


#tao-math("s f(s+1)  & = f(s) e^a \\prod_{n=2}^\\infty (1+\\frac{1}{n-1}) e^{-1/(n-1)}", block: true)



#tao-math(" & = f(s) e^a \\prod_{n=1}^\\infty (1+\\frac{1}{n}) e^{-1/n}.", block: true)
]

#text("It is then natural to normalise ")#mi("{a}")#text(" to be the real number ")#mi("{\\gamma}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("e^\\gamma \\prod_{n=1}^\\infty (1+\\frac{1}{n}) e^{-1/n} = 1.")]]

#text("This number is known as the ")#link("https://en.wikipedia.org/wiki/Euler%E2%80%93Mascheroni_constant")[#text("Euler-Mascheroni constant")]#text(" and is approximately equal to ")#mi("{0.577\\dots}")#text(". Taking logarithms, we can write it in a more familiar form as")

#tao-aligned(keep: true)[


#tao-math("\\gamma  & = -\\lim_{N \\rightarrow \\infty} \\sum_{n=1}^N \\mathrm{ln}(1+\\frac{1}{n}) - \\frac{1}{n}", block: true)



#tao-math(" & = \\lim_{N \\rightarrow \\infty} 1 + \\frac{1}{2} + \\dots + \\frac{1}{N} - \\mathrm{ln} (N+1).", block: true)



#tao-math(" & = \\lim_{N \\rightarrow \\infty} 1 + \\frac{1}{2} + \\dots + \\frac{1}{N} - \\mathrm{ln} N.", block: true)
]

#text("With this choice for ")#mi("{a}")#text(", ")#mi("{f(s)}")#text(" is then an entire function of order one that obeys the functional equation ")#mi("{s f(s+1) = f(s)}")#text(" for all ")#mi("{s}")#text(" and has simple zeroes at the non-positive integers and nowhere else; this uniquely specifies ")#mi("{f}")#text(" up to constants. The reciprocal")

#metadata(none) <tao-2245200055989ea796ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\Gamma(s) := e^{-\\gamma s} s^{-1} \\prod_{n=1}^\\infty e^{s/n} (1+\\frac{s}{n})^{-1},")]]

#text("known as the (Weierstrass definition of the) ")#link("https://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", is then a meromorphic function with simple poles at the non-positive integers and nowhere else that obeys the functional equation")

#metadata(none) <tao-52665c52c931e1ff628c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\Gamma(s+1) = s \\Gamma(s)")]]

#text("(for ")#mi("{z}")#text(" away from the poles ")#mi("{0,-1,-2,\\dots}")#text(") and is the reciprocal of an entire function of order ")#mi("{1}")#text(" (in particular, it has no zeroes). This uniquely defines ")#mi("{\\Gamma}")#text(" up to constants, if one also requires ")#mi("{\\Gamma}")#text(" to be real on the real axis (which forces ")#mi("{a}")#text(" to be real also).")

#text("Note that as ")#mi("{s \\rightarrow 0}")#text(", the function ")#mi("{e^{-\\gamma s} \\prod_{n=1}^\\infty e^{s/n} (1+\\frac{s}{n})^{-1}}")#text(" converges to one, hence ")#mi("{\\Gamma}")#text(" has a residue of ")#mi("{1}")#text(" at the origin ")#mi("{s=0}")#text("; equivalently, by ")#link(<tao-52665c52c931e1ff628c>)[#text("(26)")]#text(" we have ")#metadata(none) <tao-69727902b857d1e1356c>#mi("\\displaystyle  \\Gamma(1)=1. \\ \\ \\ \\ \\ (27)")#text(" ")#text(" Thus ")#mi("{\\Gamma}")#text(" is the unique reciprocal of an entire function of order ")#mi("{1}")#text(" with simple poles at the non-positive integers and nowhere else that obeys ")#link(<tao-52665c52c931e1ff628c>)[#text("(26)")]#text(", ")#link(<tao-69727902b857d1e1356c>)[#text("(27)")]#text(".")

#text("From ")#link(<tao-69727902b857d1e1356c>)[#text("(27)")]#text(", ")#link(<tao-52665c52c931e1ff628c>)[#text("(26)")]#text(" and induction we see that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(n+1) = n!")]]

#text("for all natural numbers ")#mi("{n=0,1,2,\\dots}")#text(". Thus the Gamma function can be viewed as a complex extension of the factorial function (shifted by a unit). From the definition we also see that")

#metadata(none) <tao-df90448e8a2a9f105933>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\Gamma(\\overline{s}) = \\overline{\\Gamma(s)}")]]

#text("for all ")#mi("{s}")#text(" outside of the poles of ")#mi("{\\Gamma}")#text(".")

#text("One can readily establish several more identities and asymptotics for ")#mi("{\\Gamma}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Euler reflection formula)")]#text(" ")#metadata(none) <tao-421c47d8c413985f08df>#text(" Show that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) \\Gamma(1-s) = \\frac{\\pi}{\\sin(\\pi s)}")]]

#text("whenever ")#mi("{s}")#text(" is not an integer. (")#emph[#text("Hint:")]#text(" use the Hadamard factorisation theorem.) Conclude in particular that ")#mi("{\\Gamma(1/2) = \\sqrt{\\pi}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Digamma function)")]#text(" ")#metadata(none) <tao-ebbde58a4bbe357e599b>#text(" Define the ")#link("http://en.wikipedia.org/wiki/Digamma_function")[#text("digamma function")]#text(" to be the logarithmic derivative ")#mi("{\\frac{\\Gamma^{\\prime}}{\\Gamma}}")#text(" of the Gamma function. Show that the digamma function is a meromorphic function, with simple poles of residue ")#mi("{-1}")#text(" at the non-positive integers ")#mi("{0, -1, -2, \\dots}")#text(" and no other poles, and that")

#tao-aligned(keep: true)[


#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s)  & = \\lim_{N \\rightarrow \\infty} \\log N - \\sum_{n=0}^N \\frac{1}{s+n}", block: true)



#tao-math(" & = -\\gamma + \\sum_{\\rho = 0, -1, -2, \\dots} (\\frac{1}{1-\\rho} - \\frac{1}{s-\\rho})", block: true)
]

#text("for ")#mi("{s}")#text(" outside of the poles of ")#mi("{\\frac{\\Gamma^{\\prime}}{\\Gamma}}")#text(", with the sum being absolutely convergent. Establish the reflection formula")

#metadata(none) <tao-909ca0096d519dcf94ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\frac{\\Gamma^{\\prime}}{\\Gamma}(1-s) - \\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\pi \\cot(\\pi s)")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\pi \\cot(\\pi s) = \\sum_{\\rho \\in {\\bf Z}} (\\frac{1}{s-\\rho} - \\frac{1_{\\rho \\neq 0}}{\\rho})")]]

#text("for non-integer ")#mi("{s}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Euler product formula)")]#text(" Show that for any ")#mi("{s \\neq 0,-1,-2,\\dots}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\lim_{n \\rightarrow \\infty} \\frac{n! n^s}{s(s+1) \\dots (s+n)} = \\frac{1}{s} \\prod_{n=1}^\\infty \\frac{(1+1/n)^s}{1+s/n}.")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" ")#metadata(none) <tao-323ffa49fe23683712e8>#text(" Let ")#mi("{s}")#text(" be a complex number with ")#mi("{\\mathrm{Re}(s) > 0}")#text(".")

#list(
[#text("(i) For any positive integer ")#mi("{n}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("\\frac{n! n^s}{s(s+1) \\dots (s+n)} = \\int_0^n t^s (1-\\frac{t}{n})^n\\ \\frac{dt}{t}.")]]],
[#text("(ii) (Bernoulli definition of Gamma function) Show that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(s) = \\int_0^\\infty t^s e^{-t}\\ \\frac{dt}{t}.")]]

#text("What happens if the hypothesis ")#mi("{\\mathrm{Re} s > 0}")#text(" is dropped?")],
[#text("(iii) (Beta function identity) Show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 t^{s_1-1} (1-t)^{s_2-1}\\ dt = \\frac{\\Gamma(s_1) \\Gamma(s_2)}{\\Gamma(s_1+s_2)}")]]

#text("whenever ")#mi("{s_1,s_2}")#text(" are complex numbers with ")#mi("{\\mathrm{Re}(s_1), \\mathrm{Re}(s_2) > 0}")#text(". (")#emph[#text("Hint:")]#text(" evaluate ")#mi("{\\int_0^\\infty \\int_0^\\infty t_1^{s_1-1} t_2^{s_2-1} e^{-t_1-t_2}\\ dt_1 dt_2}")#text(" in two different ways.)")]
)
]

#text("We remark that the Bernoulli definition of the ")#mi("{\\Gamma}")#text(" function is often the first definition of the Gamma function introduced in texts (see for instance ")#link("https://terrytao.wordpress.com/2014/12/15/254a-supplement-3-the-gamma-function-and-the-functional-equation-optional/")[#text("this previous blog post")]#text(" for an arrangement of the material here based on this definition). It is because of the identities (ii), (iii) that the Gamma function often frequently arises when evaluating many other integrals involving polynomials or exponentials, and in particular is a frequent presence in identities involving standard integral transforms, such as the Fourier transform, Laplace transform, or Mellin transform.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]

#list(
[#text("(i) (Quantitative form of integral test) Show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + O( \\int_x^y |f^{\\prime}(t)|\\ dt + \\left|f(y)\\right| )", block: true)]]

#text("for any real ")#mi("{y \\leq x}")#text(" and any continuously differentiable functions ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(".")],
[#text("(ii) Using (i) and Exercise ")#link(<tao-ebbde58a4bbe357e599b>)[#text("27")]#text(", obtain the asymptotic")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\text{Log}(s) + O_\\varepsilon( \\frac{1}{\\left|s\\right|} )", block: true)]]

#text("whenever ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{s}")#text(" is in the sector ")#tao-math("{\\left|\\text{Arg}(z)\\right| < \\pi - \\varepsilon}", block: false)#text(" (that is, ")#mi("{s}")#text(" makes at least a fixed angle with the negative real axis), where ")#mi("{\\text{Arg}}")#text(" and ")#mi("{\\text{Log}}")#text(" are the standard branches of the argument and logarithm respectively (with branch cut on the negative real axis).")],
[#text("(iii) (Trapezoid rule) Let ")#mi("{y < x}")#text(" be distinct ")#emph[#text("integers")]#text(", and let ")#mi("{f: [y,x] \\rightarrow {\\bf C}}")#text(" be a continuously twice differentiable function. Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{y \\leq n \\leq x} f(n) = \\int_y^x f(t)\\ dt + \\frac{1}{2} f(x) + \\frac{1}{2} f(y) + O( \\int_x^y |f^{\\prime\\prime}(t)|\\ dt ).")]]

#text("(")#emph[#text("Hint:")]#text(" first establish the case when ")#mi("{x=y+1}")#text(".)")],
[#text("(iv) Refine the asymptotics in (ii) to")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\Gamma^{\\prime}}{\\Gamma}(s) = \\text{Log}(s) - \\frac{1}{2s} + O_\\varepsilon( \\frac{1}{\\left|s\\right|^2} ).", block: true)]]],
[#text("(v) (Stirling approximation) In the sector used in (ii), (iv), establish the ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling approximation")]

#align(center)[#tao-fit-display[#tao-math("\\Gamma(s) = \\exp( (s -\\frac{1}{2}) \\text{Log}(s) - s + \\frac{1}{2} \\log 2\\pi + O_\\varepsilon( \\frac{1}{\\left|s\\right|} ) ).", block: true)]]],
[#text("(vi) Establish the size bound")

#metadata(none) <tao-6ca5cab77e702c787b4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#tao-math("\\left|\\Gamma(\\sigma+it)\\right| \\asymp e^{-\\pi\\left|t\\right|/2} \\left|t\\right|^{\\sigma-\\frac{1}{2}}", block: true)]]

#text("whenever ")#mi("{\\sigma,t}")#text(" are real numbers with ")#mi("{\\sigma = O(1)}")#text(" and ")#tao-math("{\\left|t\\right| \\gtrsim 1}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" ")#metadata(none) <tao-c7fce3cad585a3110c96>

#list(
[#text("(i) (Legendre duplication formula) Show that")

#align(center)[#tao-fit-display[#mitex("\\Gamma(\\frac{s}{2}) \\Gamma(\\frac{s+1}{2}) = \\sqrt{\\pi} 2^{1-s} \\Gamma(s)")]]

#text("whenever ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(".")],
[#text("(ii) (Gauss multiplication theorem) For any natural number ")#mi("{k}")#text(", establish the ")#link("http://en.wikipedia.org/wiki/Multiplication_theorem")[#text("multiplication theorem")]

#align(center)[#tao-fit-display[#mitex("\\Gamma(\\frac{s}{k}) \\Gamma(\\frac{s+1}{k}) \\dots \\Gamma(\\frac{s+k-1}{k}) = (2\\pi)^{(k-1)/2} k^{1/2 - s} \\Gamma(s)")]]

#text("whenever ")#mi("{s}")#text(" is not a pole of ")#mi("{\\Gamma}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Show that ")#mi("{\\Gamma^{\\prime}(1) = -\\gamma}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33 (Bohr-Mollerup theorem)")]#text(" Establish the ")#link("http://en.wikipedia.org/wiki/Bohr%E2%80%93Mollerup_theorem")[#text("Bohr-Mollerup theorem")]#text(": the function ")#mi("{\\Gamma: (0,+\\infty) \\rightarrow (0,+\\infty)}")#text(", which is the Gamma function restricted to the positive reals, is the unique ")#link("http://en.wikipedia.org/wiki/Logarithmic_convexity")[#text("log-convex function")]#text(" ")#mi("{f :(0,+\\infty) \\rightarrow (0,+\\infty)}")#text(" on the positive reals with ")#mi("{f(1)=1}")#text(" and ")#mi("{sf(s) = f(s+1)}")#text(" for all ")#mi("{s>0}")#text(".")
]

#text("The exercises below will be moved to a more appropriate location after the course has ended.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Use the argument principle to give an alternate proof of Jensen’s formula, by expressing ")#mi("{\\int_0^{2\\pi} \\frac{f^{\\prime}}{f}( z_0 + r^{\\prime} e^{i\\theta})\\ d\\theta}")#text(" for almost every ")#mi("{0 < r^{\\prime} < r}")#text(" in terms of zeroes and poles, and then integrating in ")#mi("{r^{\\prime}}")#text(" and using Fubini’s theorem and the fundamental theorem of calculus.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Let ")#mi("{f}")#text(" be an entire function of order at most ")#mi("{1}")#text(" that is not identically zero. Show that there is a constant ")#mi("{C}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{f^{\\prime}(z)}{f(z)} = C + \\sum_\\rho \\frac{1}{z-\\rho} - \\frac{1_{\\rho \\neq 0}}{\\rho}")]]

#text("for all ")#mi("{z \\in {\\bf C}}")#text(" outside of the zeroes of ")#mi("{f}")#text(", where ")#mi("{\\rho}")#text(" ranges over all the zeroes of ")#mi("{f}")#text(" (including those at the origin) counting multiplicity.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (74)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612507")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Wow, thanks for these wonderful notes, sir.")#linebreak()#text(" Just some nitpicking: in Exercise 26 it shows \\label{bern}. I think you wanted to create a link to that exercise.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("In Section 4 of the 246A notes, ")#mi("\\log")#text(" is reserved as complex logarithm and ")#mi("\\ln")#text(" is the real logarithm. (Particularly, the log-derivative of ")#mi("f")#text(" seems more related to the complex logarithm.) It may be clearer to either have a comment regarding ")#mi("\\log")#text(" in various places of this post or simply use ")#mi("\\ln")#text(". (The notation ")#mi("\\log")#text(" has already been used as ")#mi("\\ln")#text(" in Exercise 59 of 246A notes 4.)")

#text("It seems that there has never been any consent/standard regarding the use of the logarithm notation in literature and it can only be ")#emph[#text("locally")]#text(" consistent; people would ultimately have to read by context. This seems quite different from the notation issue mentioned in the recent MathOverflow question ")#link("https://mathoverflow.net/q/379441")[#text("“How to invoke constants badly”")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612575")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("I believe that ")#mi("\\ln")#text(" is just the logarithm we use for the reals. (It is easy to see that there exists only one function ")#mi("\\ln : (0, \\infty) \\to \\mathbf{R}")#text(" such that ")#mi("e^{ \\ln x}  = x")#text(" for every real number ")#mi("x,")#text(" and hence any branch of the complex logarithm which maps the positive real axis to the real axis must agree with ")#mi("\\ln")#text(" on the positive real axis.")#linebreak()#text(" And as you can see if we choose to work with the principal branch of the complex logarithm (which is usually the case unless specified otherwise), then over the real axis, these two things coincide, and so the confusion between ")#mi("\\ln")#text(" and ")#mi("\\log")#text(" is settled.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Sorry, I didn’t notice that a short remark has already been in the text:")

#emph[#linebreak()#text(" In this set of notes we use ")#mi("{\\log}")#text(" for the natural logarithm when applied to a positive real number, and ")#mi("{\\mathrm{Log}}")#text(" for the standard branch of the complex logarithm (which extends ")#mi("{\\log}")#text("); the multi-valued complex logarithm ")#mi("{\\log}")#text(" will only be used in passing.")#linebreak()#text(" ")]

#text("where the use of ")#mi("\\log")#text(" is of course clearly justified.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612631")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Yes that’s right !")

#text("Merry Christmas to prof. Tao and everyone!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("In exercise 11(i), it seems clearer to have the summands ")#tao-math("1-\\left|z_n\\right|", block: false)#text(" inside parentheses.")

#emph[#text("[Parentheses added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612570")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Typo: In exercise 6 (i), I believe the inequality should point the other direction")

#emph[#text("[Actually the ")#mi("\\infty")#text(" should have been ")#mi("-\\infty")#text(", now corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612593")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("I’m looking at equation (23) (and the next one) but not seeing why the number 4 should appear in each factor on the right-hand side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612604")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Also, one side of the Wallis product should be reciprocated.")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Similarly, in the two displayed formulas above (22), the factors 2 (in ")#mi("2 \\pi")#text(") and 4 in (")#mi("4 \\pi^2")#text(") should be deleted.")#linebreak()#text(" Also, in the third formula above (22) (for ")#mi("E_1(z/ \\pi n)")#text(") the factor 2 in the exponent should be deleted.")

#emph[#text("[Corrected – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612614")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2020")])]

#text("Is it true that the L^infinity norm of a function f is bounded by the L^1 norm of F(f)? Where F(f) denote the Fourier transform of f.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-613737")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2020")])]

#text("Of course.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612739")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2020")])]

#text("It is interesting to observe that the logarithmic convexity of ")#mi("\\Gamma(x)")#text(" over ")#mi("(0, \\infty)")#text(" is actually equivalent(!) to Holder’s inequality applied to its Bernoullian integral definition (in exercise 28(i)).")#linebreak()#text(" Another simple derivation of its log-convex property is to use (25) to represent ")#mi("\\log \\Gamma(x)")#text(" as an infinite sum of convex functions over ")#mi("(0, \\infty)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2020")])]

#text("Correction: the Bernoullian integral definition of ")#mi("\\Gamma(x)")#text(" is in exercise 28(ii) (not 28(i)).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e116ad42bc17cc26e02ec2b41665d50ae24e72830366d2f39aec0318ae7246a-5750d896b0f484796c62ffe048fa3caf4be00534965b5692b7b2e11fa545bcea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of justderiving")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612767")[#strong[#text("justderiving")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2020")])]

#text("Hello Professor Tao,")#linebreak()#text(" This is not a math-related question but how do you write latex on your blog? I have experimented with a number of tex plugins. The best option seems to be, for example, ")#mi("y = x")#text(". Thank you! Christina")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5009306c73467f6a2eaebbf0a574effb9ea5726d29dec8fcfe2d8ca10d3b84e3-f3a4dbbdfba1991a17e1717862c21c68fa42476dabd557a683e78bc8c9d5bd2f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Lowry-Duda")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-623313")[#strong[#text("David Lowry-Duda")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2021")])]

#text("The short answer is “mathjax”. See ")#link("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/")[#text("https://terrytao.wordpress.com/2009/02/10/wordpress-latex-bug-collection-drive/")]#text(" and ")#link("https://wordpress.com/support/latex/")[#text("https://wordpress.com/support/latex/")]#text(" to see some of the limitations and official support.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-612777")[#strong[#text("Tex Template – DERIVE IT")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2020")]

#text("[…] [2] ")#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic&#8230")[#text("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-613130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2020")])]

#text("In Exercise 12ii (where you define Blaschke products), the factors need to be normalized (multiply by a suitable unimodular constant) in order to ensure convergence. For example, if the z_n are real (and satisfy the Blaschke condition), then the product as stated diverges at 0.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-613408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("Are there positive numbers which are not the order of any entire function?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-613419")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2020")])]

#text("No; given any positive order ")#mi("\\rho")#text(", one can select a sequence of zeroes ")#mi("z_n")#text(" that go to infinity at the right rate (so that ")#tao-math("\\sum_n \\frac{1}{\\left|z_n\\right|^{\\rho+\\varepsilon}}", block: false)#text(" converges for any ")#mi("\\varepsilon>0")#text(", but ")#tao-math("\\sum_n \\frac{1}{\\left|z_n\\right|^{\\rho-\\varepsilon}}", block: false)#text(" diverges), and then take the entire function appearing in the Hadamard factorisation theorem and apply Exercise 23.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-613966")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2020")])]

#text("It may be added after the product representation (25) that it implies that ")#mi("\\Gamma(s)")#text(" has no zeros.")

#emph[#text("[This is mentioned after (26) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-614513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2021")])]

#text("Let ")#mi("f(z) = \\sum_{n \\ge 0} a_n z^n")#text(" be an entire function.")

#text("Define for each positive integer ")#mi("m")

#mi("f_m(z) := \\sum_{n \\ge 0} a_{m n} z^n")

#text("Note that the functions ")#mi("f_m")#text(" are also entire and satisfy the functional equation")

#mi("f_m(\\xi z) = f_m(z)")#text(" whenever ")#mi("\\xi^m =1")#linebreak()#text(" (i.e. ")#mi("f_m(z)")#text(" are invariant under rotation of ")#mi("z")#text(" by ")#mi("2\\pi /m")#text(")")

#text("Let ")#mi("w_k(z)")#text(" for ")#mi("k =1, ... , m")#text(" denote the ")#mi("m")#text(" roots of the equation ")#mi("w^m = z")#text(".")

#text("It is not difficult to verify that")

#mi("f_m(z) = m^{-1} \\sum_{k=1}^m f(w_k(z))")

#text("If ")#mi("f")#text(" has order ")#mi("\\rho")#text(", it follows that each function ")#mi("f_m")#text(" has order ")#mi("\\rho / m")#text(".")

#text("Examples: Let ")#mi("f(z) = e^z")#text(" , than")

#mi("f_2(z) = cosh(z^{1/2})")#text(" is entire with order ")#mi("1/2")#text(".")

#mi("f_4(z) = (cos(z^{1/4}) + cosh(z^{1/4}))/2")#text(" has order ")#mi("1/4")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-614662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2021")])]

#text("Correction: The above functional equation ")#mi("f_m(\\xi z)=f_m(z)")#text(" is incorrect(!) and should be deleted (along with its rotational invariance interpretation for ")#mi("f_m")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-614686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2021")])]

#text("It seems that in (17), the LHS should be ")#tao-math("\\left|f(z)\\right|", block: false)#text(" and in the RHS “exp” is missing.")#linebreak()#text(" Similarly, two lines above (17), the LHS of the displayed formula should be ")#tao-math("\\left|f(z)\\right|", block: false)#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-615015")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2021")])]

#text("In the RHS of (17), the “exp” is still missing.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-615258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("It may be added in theorem 21 that the convergence is locally uniform (which enable certain termwise operations like logarithmic derivative.)")

#emph[#text("[Suggestion implemented, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-615368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2021")])]

#text("In the second part of Exercise 22 the summation should be over |z/zn|>1/2, not <1/2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-615455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2021")])]

#text("Dear Pro Tao,")#linebreak()#text(" I have a habit of reading your blog in the early morning before brushing my teeth. It seems tobe my breakfast if I see your breakthrough problems.")#linebreak()#text(" So , it’s new year 2021 now. I am always excited about reading what new and more interesting is.")#linebreak()#text(" Thank you very much,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-620193")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("[…] for any positive real number . Explain why this is consistent with Exercise 24 from Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-620718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("Should there be a ")#mi("\\limsup_{r \\to 1^-}")#text(" before the integral in Exercise 6(ii)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-620828")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2021")])]

#text("In the statement of Theorem 2 (Jensen’s formula), I think you have a very small typo and would like to change the notation ")#mi("\\overline{D(z, r)}")#text(" to ")#mi("\\overline{D(z_0 , r)}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-620902")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("During yesterday’s class we developed an impression that the Jensen’s formula is of a similar flavour as the argument principle, and we thought that this similarity may be used somehow to derive one of these results from the other.")

#text("Interestingly, I found a related discussion on stack exchange ")#link("https://math.stackexchange.com/questions/359771/proving-jensens-formula")[#text("https://math.stackexchange.com/questions/359771/proving-jensens-formula")]

#text("(While I had a similar approach in mind while asking the question of how these two results are related during yesterday’s class, I did not have the full derivation with me at that time.)")

#emph[#text("[Nice argument; I have appended it to the notes as an exercise. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Is there something similar to Jensen’s formula if f is not meromorphic at Zo? say f has an essential singularity at Zo, but meromorphic at all other points in the complex plane.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621075")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2021")])]

#text("Well, the essential singularity is likely to generate an infinite number of zeroes near the singularity (cf. the great Picard theorem), making it difficult to describe the contribution of that singularity in any clean way. On the other hand, one can derive some Jensen type formulas for other domains than the disk, such as an annulus, for instance by applying Green’s theorem to ")#tao-math("\\log \\left|f\\right|", block: false)#text(", and this can give some relations between ")#tao-math("\\log \\left|f\\right|", block: false)#text(" and the zeroes and poles near an essential singularity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621365")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2021")])]

#text("Is there any physical interpretation of Jensen’s formula at least for holomoprphic functions ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621368")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2021")])]

#text("In the last line of Theorem 2 you have a small typo and would like to change the notation \\overline{D(z, r)} to \\overline{D(z_0 , r)}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("I think in the Borel-Carathéodory lemma f maps unit disk to {Re f(z)≤1}, but in the hint you have written f maps unit disk to {Re f(z)≥1}. But sup_|z|≤1 Re f(z) =1 so, Re f(z)≤1.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8a1bdf2b6021fed403775383e67bd5ad2072fb980e63efd95f0b2dddf5811cc-5250fbc72c4b431e10380bb743fde43273f6b3dbdbb614dc51cb19a6a05621a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wan-Teh Chang")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621783")[#strong[#text("Wan-Teh Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2021")])]

#text("Prof. Tao: I’d like to report some typos in Section 4 (The Gamma function).")

#text("1. The equation right above the sentence “It is then natural to normalise ")#mi("a")#text(" to be the real number ")#mi("\\gamma")#text(" for which …” is missing an equal sign in the second line.")

#text("2. In the definition of the Euler-Mascheroni constant ")#mi("\\gamma")#text(", the summation inside the first limit should read ")#mi("\\sum_{n=1}^N")#text(", not ")#mi("\\sum_{N=1}^{\\infty}")#text(".")

#text("3. I have a question about the second limit in the definition of the Euler-Mascheroni constant ")#mi("\\gamma")#text(". A direct calculation of ")#mi("\\sum_{n=1}^N \\log(1 + \\frac{1}{n})")#text(" would result in ")#mi("\\log (N+1)")#text(". I assume ")#mi("\\log N")#text(" is used in the definition because the limit of ")#mi("\\log  N - \\log(N+1)")#text(" is 0, right?")

#text("4. In the sentence above Equation (27), the function ")#mi("e^{-\\gamma s} \\prod_{n=1}^{\\infty} e^{s/n}(1 + \\frac{s}{n})^{-1}")#text(" converges to 1, not zero.")

#text("Thank you!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621856")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("[…] Somewhat in analogy with the discussion of the Weierstrass and Hadamard factorisation theorems in Notes 1, we then proceed instead by working with the normalised function defined by the formula (6). Let […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621873")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("Echoing on a post on the mathoverflow website and keeping in mind the answer posted by you prof. Tao, I wanted to ask whether there is a way in which the zeta function comes as a consequence of the functional equation, in the sense that just like how we see the Gamma function coming as a particular example of a class of functions because it happens to be one of them which satisfies the factorial functional equation, is there some breed of functions such that the zeta function comes as the only one from this class of functions such that the functional equation for the zeta function is satisfied ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-621875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2021")])]

#text("There is a classical ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1544475")[#text("theorem of Hamburger")]#text(" that asserts that the Riemann zeta function is essentially the only Dirichlet series that obeys the functional equation for the zeta function. However this theorem is somewhat of a curiosity and has not proven to be of much use in practice, nor does it extend well to other L-functions or give more quantitative rigidity statements about zeta. (In particular there are famous examples ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1574345")[#text("of Davenport and Heilbronn")]#text(" of Dirichlet series that obey the functional equation for some other Dirichlet L-functions, but which fail to obey the Riemann hypothesis.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622254")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2021")])]

#text("[…] for all . (The equivalence between the (5) and (6) is a routine consequence of the Euler reflection formula and the Legendre duplication formula, see Exercises 26 and 31 of Notes 1.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622443")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("In Exercise 3, assume that ")#mi("f")#text(" is a bounded nonconstant entire function. In order to apply (6), one needs a zero of ")#mi("f")#text(". How can one get that? Blindly shifting the function seems not useful.")

#emph[#text("[Subtract off ")#mi("f(z_0)")#text(" from ")#mi("f")#text(", where ")#mi("z_0")#text(" is any point for which ")#mi("f(z_0) \\neq f(0)")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622444")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("In the first step of the proof of Theorem 2, can you elaborate on how “perturbing ")#mi("r")#text("” is done when necessary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622446")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2021")])]

#text("Change r to r+/- epsilon.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2021")])]

#text("How can you show that the RHS is continuous in ")#mi("r")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622472")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2021")])]

#text("In Proposition 8, if one uses ")#tao-math("C\\exp(\\left|z\\right|^\\rho)", block: false)#text(" instead of ")#tao-math("C\\exp(C\\left|z\\right|^\\rho)", block: false)#text(", would one lose anything? Can the constant ")#mi("C")#text(" in the exponent be absorbed somewhere?")

#emph[#text("[The former instance of ")#mi("C")#text(" can be absorbed into the latter, but not conversely; if not for the ")#mi("C")#text(" in the exponent one could not use this proposition directly to get a good bound for the number of zeroes of, say, ")#mi("\\sin(2z)")#text(", unless one rescales as suggested in the comments. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2021")])]

#text("It can be absorbed by rescaling z.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2021")])]

#text("In the proof of Proposition 8, the symbol ")#mi("\\rho")#text(" is used as both the order of growth and the dummy variable that represents the zeros of ")#mi("f")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2021")])]

#text("I think typos in (13) and (14): the product should be the sum.")

#text("In the Taylor expansions right above (15), the right-hand side should be negative.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2021")])]

#text("There are several big O notations that I don’t quite follow.")

#text("1. In theorem 9, does ")#mi("O_{c_1,c_2}")#text(" mean ")#mi("O_{r\\to 0;c_1,c_2}")#text(" ?")

#text("and I’m lost in the proof for ")#mi("O(1)")#text(" and ")#mi("O(M)")#text(": what is the underlying limiting process?")

#text("2. In the second part of the proof of Theorem 15 (after Exercise 18), ")#tao-math("O(\\frac{\\left|z\\right|^2}{\\left|z_n\\right|^2})", block: false)#text(" means ")#tao-math("O_{n\\to\\infty}(\\frac{\\left|z\\right|^2}{\\left|z_n\\right|^2})", block: false)#text("?")

#text("3. What are the first two big O in (16)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2021")])]

#mi("O_{c1,c2}(1)")#text(" means a constant that depends on ")#mi("c1")#text(" and ")#mi("c2")#text(". There is no limiting process. In general, the Big O notation for sequences is always as ")#mi("n \\to \\infty")#text(", and ")#mi("O(f)")#text(" means ")#mi("O(f)=Cf")#text(" for some constant C.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("Having read Stein-Shakarchi and your notes more carefully, I think I see what you mean in (16). It is showing that the ")#mi("E_k(z)")#text(" converge uniformly to $1$ as ")#mi("k\\to\\infty")#text("; so all the big O in (16) implicitly means ")#mi("O_{k\\to\\infty}")#text(", where ")#mi("k")#text(" is the asymptotic parameter.")

#text("Ultimately it is simply the following estimate that is used")#linebreak()#text(" ")#tao-math("\\displaystyle \\left|\\sum_{j=k+1}^\\infty \\frac{z^j}{j}\\right|\\le \\sum_{j=k+1}^\\infty\\frac{2^{-j}}{k} \\le \\sum_{j=k+1}^\\infty{2^{-j}}=2^{-k}", block: false)

#text("In the writing of (16), would each ")#mi("O")#text(" bring a different constant so that the series is not convergent? (I recall that you warn such a situation somewhere in 246a, but I can’t find the exact place.)")

#text("Also, does one either need to replace the second last equality as ")#mi("\\leq")#text(" or replace the first O as ")#mi("O(2^{-j})")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("In these notes, constants in the big-O notation are uniform among all parameters that are not explicitly subscripted; no asymptotic limit is presumed (in contrast to the little-O notation). For instance, ")#mi("O(2^{-j}/k)")#text(" denotes a quantity bounded in absolute value by ")#mi("C 2^{-j} / k")#text(", where ")#mi("C")#text(" is uniform in both ")#mi("j")#text(" and ")#mi("k")#text(".")

#text("A statement with asymptotic notation on the left and right-hand sides is interpreted as saying that every expression of the form of the LHS is also of the form of the RHS, but not necessarily conversely (thus equality is not necessarily symmetric once asymptotic notation is involved). Thus for instance ")#mi("O(2^{-j}) = O(2^{-k})")#text(" whenever ")#mi("j \\geq k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("In the second obstruction mentioned above the Weierstrass factorization theorem, if one considers the constant sequence ")#mi("z_n=0")#text(", then ")#mi("0")#text(" is the limit of the sequence. But as a set, ")#mi("\\{z_n:n\\}")#text(" consists of only one point and thus isolated. Why is it still impossible to have this (constant) sequence as zeros of an entire function, i.e., zeros of nonzero entire functions must be of finite order? It seems that Corollary 24 of 246a Notes 3 does not exclude such cases explicitly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("If a zero of analytic function has infinite order, all its Taylor coefficients at this zero are vanishing – representing the constant function ")#mi("0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("There is no such thing called “infinite order”. It is unclear what one even means when saying a function ")#mi("f")#text(" having the constant ")#emph[#text("sequence")]#text(" ")#mi("z_n= 0")#text(" as zeros; but I recall the author said the notion before and hence the question.")

#text("The “order” of any zero is defined to be a finite number. If one *defines* it as the place where the first nonzero coefficient of its power series around a point, one can of course conclude that it must be constant zero around the point and thus constant.")

#text("The question specifically refers to and is meant to ask the statement of Corollary 24 of 246a notes 3, which was summarized as “Non-trivial analytic functions have isolated zeroes”. because this is mentioned explicitly in the note. The constant sequence, as a set, contains only *one* point, which is isolated, does not violate the assumptions of the corollary. And yes, this is question was meant to ask the author of this set of notes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("If all Taylor coefficients are zero, the function vanishes identically and it is the only(!) case where the zero order is defined to be infinite (since the zero order of the constant function ")#mi("0")#text(" can’t be finite by any reasonable definition).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622656")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("In the proof of Theorem 2, in the technical case of zeros or poles being on the boundary, if one makes ")#mi("r")#text(" bigger, then more zeros or poles are going into the disk ")#mi("D(z,r+\\epsilon)")#text(" so that the two sums may change dramatically, right? (If yes, it seems to be more revealing to write that one is decreasing ")#mi("r")#text(". So when perturbing, one can only make it smaller, and the two sums are left continuous in ")#mi("r")#text(".)")

#text("It may be worth adding an exercise or comment for this technical case. It is not immediate that the integral term on the right is (left) continuous in ")#mi("r")#text(" since log is not bounded. One can split the integral as")#linebreak()#text(" ")#tao-math("\\displaystyle \\int \\log\\left|f()\\right|=\\int \\min(\\max(\\log\\left|f()\\right|,-M),M)+\\textrm{error}", block: false)#linebreak()#text(" and the first term can be done by dominated convergence. How would you deal with the error term?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2021")])]

#text("There is in fact no discontinuity when poles or zeroes enter or exit the disk, this can be seen for instance by rewriting ")#tao-math("\\sum_{\\left|\\rho - z_0\\right| \\leq r} \\log \\frac{\\left|\\rho-z_0\\right|}{r}", block: false)#text(" as ")#tao-math("\\sum_\\rho \\min( \\log \\frac{\\left|\\rho-z_0\\right|}{r},  0)", block: false)#text(".")

#text("The error can bounded by ")#tao-math("\\frac{1}{M} \\int (\\log \\left|f\\right|)^2", block: false)#text(", and the latter integral can be bounded using the fact that ")#mi("f")#text(" only has a finite number of poles near the circle and the slow divergence of the logarithm function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622792")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2021")])]

#text("In the argument above (23), ")#mi("g")#text(" is determined by (22). When you say “shifting ")#mi("g")#text(" by an integer multiple of ")#mi("2\\pi i")#text("” for the normalization, do you mean changing the branch of ")#mi("\\tilde{\\log}")#text(" in (22)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2021")])]

#text("No. It means ")#mi("e^{2\\pi i+g(z)}= e^{g(z)}")#text(" since ")#mi("e^{2\\pi i}=1")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622819")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("What one concludes from the argument is that ")#mi("g=2k\\pi i")#text(" for some integer ")#mi("k")#text(". And thus one has ")#mi("e^{g(z)}=e^{g(z)-k(\\pi i)}=e^{0}=1")#text(". This is already sufficient to conclude (23). Shifting ")#mi("g")#text(" by an integer multiple of ")#mi("2\\pi i")#text(" is the same effect as changing the branch of the logarithm in (22).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622821")[#strong[#text("J.")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("*")#mi("k(2\\pi i)")#text("* in the exponent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Course announcement: 246B, complex analysis | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-622823")[#strong[#text("Course announcement: 246B, complex analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Jensen’s formula and factorisation theorems (particularly Weierstrass and Hadamard); the Gamma…; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cc5c5b58984fd8189ecbd929d29b01a826651e0c09b23f3bd634be13eedaaa9-d6d1d5cfe1043cacae035da57d5d17ba965c8e55b19bbe97d948d36de7810dd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Convergence of the sum ∑ |f(i)-1| implies convergence of the product ∏ |f(i)| over Mat(m,R) equipped with the operator norm | Aditya Guha Roy's weblog")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-628883")[#strong[#text("Convergence of the sum ∑ |f(i)-1| implies convergence of the product ∏ |f(i)| over Mat(m,R) equipped with the operator norm | Aditya Guha Roy's weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2021")])]

#text("[…] by professor Terence Tao during one of his lessons from Math 246B in context to the Lemma 16 from Math 246B Notes 1, just as a fun challenging exercise to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 5: conformal mapping | What's new")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-634695")[#strong[#text("246A, Notes 5: conformal mapping | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2021")])]

#text("[…] Previous set of notes: Notes 4. Next set of notes: 246B Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d7c1b6cb2355225c4aa81f58c25106da2b399f567af87a7508495d00d6e5f26-19de1650d1de83dd1fdbf582eeadeff0ce510532025de0101576a5993fd23004.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quân Nguyễn")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-637152")[#strong[#text("Quân Nguyễn")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2021")])]

#text("Dear professor Tao,")#linebreak()#text(" I am doing the exercise 20 and wonder what if the sequence has accumulation point on the boundary of ")#mi("U")#text(". Does the problem still hold in this case ? Cause I just know the argument for which the sequence ")#mi("\\{z_k\\}_{k\\geq 1}")#text(" is unbounded.")

#emph[#text("[Yes; the point is to adapt the latter argument to handle the former case also. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-639505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2022")])]

#text("There’s a small typo in the paragraph immediately before theorem 22. It says “Applying Exercise 29 of 246A Notes 3,” when it should be exercise 31 because Notes 3 was updated recently.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-639611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2022")])]

#text("In exercise 27 should the sum over the integers be replaced with a sum over non-zero integers and a separate term for the zero case (to avoid division by zero)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-679728")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2023")])]

#text("In proving Hadamard’s theorem, it’s mentioned that “On the other hand, this logarithmic divergence is rather mild, so one can hope to somehow evade it”.")#linebreak()#text(" what do you mean by “mild”?")#linebreak()#text(" I can’t see yet intuitively that why Hadamard’s theorem holds.")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-679762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2023")])]

#text("Functions with a logarithmic singularity, such as ")#tao-math("r \\mapsto \\log \\left|r\\right|", block: false)#text(", are still locally absolutely integrable (and in fact lie locally in every ")#mi("L^p")#text(" for ")#mi("p < \\infty")#text(", so they are really close to being bounded (or in ")#mi("L^\\infty")#text(") despite still being singular.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-684587")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2024")])]

#text("Dear Terry Tao")#linebreak()#text("I’ve been reflecting on the intuitive underpinnings of Jensen’s formula in complex analysis and found a compelling analogy in physics that I thought might resonate with others here. Imagine, if you will, the complex plane as a vast space where zeros of a holomorphic function act like massive objects generating gravitational fields. These fields influence the path of the function’s growth, much like gravity influences the motion of planets.")#linebreak()#text("keeping in mind that entire functions will to tend to infinity(since a bounded entire function needs to be constant!), every time the function gets zero, it needs to restart trying escape to infinity, so if a functions gets zero several times and is entire this actually shows that the function was able to recover from being zero fast enough, this is analog to the case of gravitational field where an object needs to move with higher velocity in order to escape the gravitational field of a massive object(one can see “failing in escaping the gravitational field” corresponding to entire function being constant!)")#linebreak()#text("Thank you for allowing me to share this perspective. I look forward to any thoughts or corrections you might have.")#linebreak()#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2020/12/23/246b-notes-1-zeroes-poles-and-factorisation-of-meromorphic-functions/#comment-687825")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("To solve exercise 20, assuming the sequence of zeros ")#mi("z_i")#text(" with finitely many accumulating points ")#mi("w_1,...,w_n")#text(" on the boundary, I guess that using the Mobius transformation sending ")#mi("w_j")#text(" to ")#mi("infty")#text(" and applying the Weierstrass factorization theorem can be used to solve the problem.")#linebreak()#text("Any hints on how to deal with the case where the accumulation points are not finite? (If this approach is correct at all)")

#emph[#text("[Adapt the proof of the Weierstrass factorization theorem, instead of using that theorem as a black box. -T]")]
]
