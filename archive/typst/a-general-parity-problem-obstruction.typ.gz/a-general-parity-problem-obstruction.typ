// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/
// Converted to Typst by tao2typ: "2026-10-14T15:19:13.810751+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A general parity problem obstruction", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A general parity problem obstruction")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")[#text("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many problems and results in analytic prime number theory can be formulated in the following general form: given a collection of (affine-)linear forms ")#mi("{L_1(n),\\dots,L_k(n)}")#text(", none of which is a multiple of any other, find a number ")#mi("{n}")#text(" such that a certain property ")#mi("{P( L_1(n),\\dots,L_k(n) )}")#text(" of the linear forms ")#mi("{L_1(n),\\dots,L_k(n)}")#text(" are true. For instance:")

#list(
[#text("For the ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(", one can use the linear forms ")#mi("{L_1(n) := n}")#text(", ")#mi("{L_2(n) := n+2}")#text(", and the property ")#mi("{P( L_1(n), L_2(n) )}")#text(" in question is the assertion that ")#mi("{L_1(n)}")#text(" and ")#mi("{L_2(n)}")#text(" are both prime.")],
[#text("For the ")#link("http://en.wikipedia.org/wiki/Goldbach%27s_conjecture")[#text("even Goldbach conjecture")]#text(", the claim is similar but one uses the linear forms ")#mi("{L_1(n) := n}")#text(", ")#mi("{L_2(n) := N-n}")#text(" for some even integer ")#mi("{N}")#text(".")],
[#text("For ")#link("http://en.wikipedia.org/wiki/Chen%27s_theorem")[#text("Chen’s theorem")]#text(", we use the same linear forms ")#mi("{L_1(n),L_2(n)}")#text(" as in the previous two cases, but now ")#mi("{P(L_1(n), L_2(n))}")#text(" is the assertion that ")#mi("{L_1(n)}")#text(" is prime and ")#mi("{L_2(n)}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost prime")]#text(" (in the sense that there are at most two prime factors).")],
[#text("In the recent results establishing bounded gaps between primes, we use the linear forms ")#mi("{L_i(n) = n + h_i}")#text(" for some admissible tuple ")#mi("{h_1,\\dots,h_k}")#text(", and take ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(" to be the assertion that at least two of ")#mi("{L_1(n),\\dots,L_k(n)}")#text(" are prime.")]
)

#text("For these sorts of results, one can try a sieve-theoretic approach, which can broadly be formulated as follows:")

#enum(start: 1, 
[#text("First, one chooses a carefully selected ")#emph[#text("sieve weight")]#text(" ")#mi("{\\nu: {\\bf N} \\rightarrow {\\bf R}^+}")#text(", which could for instance be a non-negative function having a divisor sum form")

#align(center)[#tao-fit-display[#mitex("\\nu(n) := \\sum_{d_1|L_1(n), \\dots, d_k|L_k(n); d_1 \\dots d_k \\leq x^{1-\\varepsilon}} \\lambda_{d_1,\\dots,d_k}")]]

#text("for some coefficients ")#mi("{\\lambda_{d_1,\\dots,d_k}}")#text(", where ")#mi("{x}")#text(" is a natural scale parameter. The precise choice of sieve weight is often quite a delicate matter, but will not be discussed here. (In some cases, one may work with multiple sieve weights ")#mi("{\\nu_1, \\nu_2, \\dots}")#text(".)")],
[#text("Next, one uses tools from analytic number theory (such as the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(") to obtain upper and lower bounds for sums such as")

#metadata(none) <tao-989278ad10e33d97c46f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_n \\nu(n)")]]

#text("or")

#metadata(none) <tao-8ce88e6477323ba9f5ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_n \\nu(n) 1_{L_i(n) \\text{ prime}}")]]

#text("or more generally of the form")

#metadata(none) <tao-59d4ad4c9df2ae88a988>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sum_n \\nu(n) f(L_i(n))")]]

#text("where ")#mi("{f(L_i(n))}")#text(" is some “arithmetic” function involving the prime factorisation of ")#mi("{L_i(n)}")#text(" (we will be a bit vague about what this means precisely, but a typical choice of ")#mi("{f}")#text(" might be a Dirichlet convolution ")#mi("{\\alpha*\\beta(L_i(n))}")#text(" of two other arithmetic functions ")#mi("{\\alpha,\\beta}")#text(").")],
[#text("Using some combinatorial arguments, one manipulates these upper and lower bounds, together with the non-negative nature of ")#mi("{\\nu}")#text(", to conclude the existence of an ")#mi("{n}")#text(" in the support of ")#mi("{\\nu}")#text(" (or of at least one of the sieve weights ")#mi("{\\nu_1, \\nu_2, \\dots}")#text(" being considered) for which ")#mi("{P( L_1(n), \\dots, L_k(n) )}")#text(" holds")]
)

#text("For instance, in the recent results on bounded gaps between primes, one selects a sieve weight ")#mi("{\\nu}")#text(" for which one has upper bounds on")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n)")]]

#text("and lower bounds on")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) 1_{n+h_i \\text{ prime}}")]]

#text("so that one can show that the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) (\\sum_{i=1}^k 1_{n+h_i \\text{ prime}} - 1)")]]

#text("is strictly positive, which implies the existence of an ")#mi("{n}")#text(" in the support of ")#mi("{\\nu}")#text(" such that at least two of ")#mi("{n+h_1,\\dots,n+h_k}")#text(" are prime. As another example, to prove Chen’s theorem to find ")#mi("{n}")#text(" such that ")#mi("{L_1(n)}")#text(" is prime and ")#mi("{L_2(n)}")#text(" is almost prime, one uses a variety of sieve weights to produce a lower bound for")

#align(center)[#tao-fit-display[#mitex("S_1 := \\sum_{n \\leq x} 1_{L_1(n) \\text{ prime}} 1_{L_2(n) \\text{ rough}}")]]

#text("and an upper bound for")

#align(center)[#tao-fit-display[#mitex("S_2 := \\sum_{z \\leq p < x^{1/3}} \\sum_{n \\leq x} 1_{L_1(n) \\text{ prime}} 1_{p|L_2(n)} 1_{L_2(n) \\text{ rough}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_3 := \\sum_{n \\leq x} 1_{L_1(n) \\text{ prime}} 1_{L_2(n)=pqr \\text{ for some } z \\leq p \\leq x^{1/3} < q \\leq r},")]]

#text("where ")#mi("{z}")#text(" is some parameter between ")#mi("{1}")#text(" and ")#mi("{x^{1/3}}")#text(", and “rough” means that all prime factors are at least ")#mi("{z}")#text(". One can observe that if ")#mi("{S_1 - \\frac{1}{2} S_2 - \\frac{1}{2} S_3 > 0}")#text(", then there must be at least one ")#mi("{n}")#text(" for which ")#mi("{L_1(n)}")#text(" is prime and ")#mi("{L_2(n)}")#text(" is almost prime, since for any rough number ")#mi("{m}")#text(", the quantity")

#align(center)[#tao-fit-display[#mitex("1 - \\frac{1}{2} \\sum_{z \\leq p < x^{1/3}} 1_{p|m} - \\frac{1}{2} \\sum_{z \\leq p \\leq x^{1/3} < q \\leq r} 1_{m = pqr}")]]

#text("is only positive when ")#mi("{m}")#text(" is an almost prime (if ")#mi("{m}")#text(" has three or more factors, then either it has at least two factors less than ")#mi("{x^{1/3}}")#text(", or it is of the form ")#mi("{pqr}")#text(" for some ")#mi("{p \\leq x^{1/3} < q \\leq r}")#text("). The upper and lower bounds on ")#mi("{S_1,S_2,S_3}")#text(" are ultimately produced via asymptotics for expressions of the form ")#link(<tao-989278ad10e33d97c46f>)[#text("(1)")]#text(", ")#link(<tao-8ce88e6477323ba9f5ea>)[#text("(2)")]#text(", ")#link(<tao-59d4ad4c9df2ae88a988>)[#text("(3)")]#text(" for various divisor sums ")#mi("{\\nu}")#text(" and various arithmetic functions ")#mi("{f}")#text(".")

#text("Unfortunately, there is an obstruction to sieve-theoretic techniques working for certain types of properties ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(", which ")#link("http://mathematics.stanford.edu/people/name/zeb-brady/")[#text("Zeb Brady")]#text(" and I recently formalised at ")#link("http://www.ams.org/meetings/calendar/2014_nov17-21_paloalto.html")[#text("an AIM workshop")]#text(" this week. To state the result, we recall the ")#link("http://en.wikipedia.org/wiki/Liouville_function")[#text("Liouville function")]#text(" ")#mi("{\\lambda(n)}")#text(", defined by setting ")#mi("{\\lambda(n) = (-1)^j}")#text(" whenever ")#mi("{n}")#text(" is the product of exactly ")#mi("{j}")#text(" primes (counting multiplicity). Define a ")#emph[#text("sign pattern")]#text(" to be an element ")#mi("{(\\epsilon_1,\\dots,\\epsilon_k)}")#text(" of the discrete cube ")#mi("{\\{-1,+1\\}^k}")#text(". Given a property ")#mi("{P(l_1,\\dots,l_k)}")#text(" of ")#mi("{k}")#text(" natural numbers ")#mi("{l_1,\\dots,l_k}")#text(", we say that a sign pattern ")#mi("{(\\epsilon_1,\\dots,\\epsilon_k)}")#text(" is ")#emph[#text("forbidden")]#text(" by ")#mi("{P}")#text(" if there does not exist any natural numbers ")#mi("{l_1,\\dots,l_k}")#text(" obeying ")#mi("{P(l_1,\\dots,l_k)}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("(\\lambda(l_1),\\dots,\\lambda(l_k)) = (\\epsilon_1,\\dots,\\epsilon_k).")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" ")#metadata(none) <tao-43bb00d0ce7790a53b91>#text(" Let ")#mi("{P(l_1,l_2,l_3)}")#text(" be the property that at least two of ")#mi("{l_1,l_2,l_3}")#text(" are prime. Then the sign patterns ")#mi("{(+1,+1,+1)}")#text(", ")#mi("{(+1,+1,-1)}")#text(", ")#mi("{(+1,-1,+1)}")#text(", ")#mi("{(-1,+1,+1)}")#text(" are forbidden, because prime numbers have a Liouville function of ")#mi("{-1}")#text(", so that ")#mi("{P(l_1,l_2,l_3)}")#text(" can only occur when at least two of ")#mi("{\\lambda(l_1),\\lambda(l_2), \\lambda(l_3)}")#text(" are equal to ")#mi("{-1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-3946ca64ff78d93ca610>#text(" Let ")#mi("{P(l_1,l_2)}")#text(" be the property that ")#mi("{l_1}")#text(" is prime and ")#mi("{l_2}")#text(" is almost prime. Then the only forbidden sign patterns are ")#mi("{(+1,+1)}")#text(" and ")#mi("{(+1,-1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" ")#metadata(none) <tao-bdcfc6ac707b82e80835>#text(" Let ")#mi("{P(l_1,l_2)}")#text(" be the property that ")#mi("{l_1}")#text(" and ")#mi("{l_2}")#text(" are both prime. Then ")#mi("{(+1,+1), (+1,-1), (-1,+1)}")#text(" are all forbidden sign patterns.")
]

#text("We then have a parity obstruction as soon as ")#mi("{P}")#text(" has “too many” forbidden sign patterns, in the following (slightly informal) sense:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Claim 1 (Parity obstruction)")]#text(" ")#metadata(none) <tao-a1453f380fa9f1a08e84>#text(" Suppose ")#mi("{P(l_1,\\dots,l_k)}")#text(" is such that that the convex hull of the forbidden sign patterns of ")#mi("{P}")#text(" contains the origin. Then one cannot use the above sieve-theoretic approach to establish the existence of an ")#mi("{n}")#text(" such that ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(" holds.")
]

#text("Thus for instance, the property in Example ")#link(<tao-bdcfc6ac707b82e80835>)[#text("3")]#text(" is subject to the parity obstruction since ")#mi("{0}")#text(" is a convex combination of ")#mi("{(+1,-1)}")#text(" and ")#mi("{(-1,+1)}")#text(", whereas the properties in Examples ")#link(<tao-43bb00d0ce7790a53b91>)[#text("1")]#text(", ")#link(<tao-3946ca64ff78d93ca610>)[#text("2")]#text(" are not. One can also check that the property “at least ")#mi("{j}")#text(" of the ")#mi("{k}")#text(" numbers ")#mi("{l_1,\\dots,l_k}")#text(" is prime” is subject to the parity obstruction as soon as ")#mi("{j \\geq \\frac{k}{2}+1}")#text(". Thus, the largest number of elements of a ")#mi("{k}")#text("-tuple that one can force to be prime by purely sieve-theoretic methods is ")#mi("{k/2}")#text(", rounded up.")

#text("This claim is not precisely a theorem, because it presumes a certain “Liouville pseudorandomness conjecture” (a very close cousin of the more well known “Möbius pseudorandomness conjecture”) which is a bit difficult to formalise precisely. However, this conjecture is widely believed by analytic number theorists, see e.g. ")#link("https://terrytao.wordpress.com/2012/10/14/the-chowla-conjecture-and-the-sarnak-conjecture/")[#text("this blog post")]#text(" for a discussion. (Note though that there are scenarios, most notably the “Siegel zero” scenario, in which there is a severe breakdown of this pseudorandomness conjecture, and the parity obstruction then disappears. A typical instance of this is ")#link("http://www.ams.org/mathscinet-getitem?mr=703977")[#text("Heath-Brown’s proof")]#text(" of the twin prime conjecture (which would ordinarily be subject to the parity obstruction) under the hypothesis of a Siegel zero.) The obstruction also does not prevent the establishment of an ")#mi("{n}")#text(" such that ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(" holds by introducing additional sieve axioms beyond upper and lower bounds on quantities such as ")#link(<tao-989278ad10e33d97c46f>)[#text("(1)")]#text(", ")#link(<tao-8ce88e6477323ba9f5ea>)[#text("(2)")]#text(", ")#link(<tao-59d4ad4c9df2ae88a988>)[#text("(3)")]#text(". The proof of the ")#link("http://en.wikipedia.org/wiki/Friedlander%E2%80%93Iwaniec_theorem")[#text("Friedlander-Iwaniec theorem")]#text(" is a good example of this latter scenario.")

#text("Now we give a (slightly nonrigorous) proof of the claim.")

#emph[#text("Proof:")]#text(" (Nonrigorous) Suppose that the convex hull of the forbidden sign patterns contain the origin. Then we can find non-negative numbers ")#mi("{p_{\\epsilon_1,\\dots,\\epsilon_k}}")#text(" for sign patterns ")#mi("{(\\epsilon_1,\\dots,\\epsilon_k)}")#text(", which sum to ")#mi("{1}")#text(", are non-zero only for forbidden sign patterns, and which have mean zero in the sense that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(\\epsilon_1,\\dots,\\epsilon_k)} p_{\\epsilon_1,\\dots,\\epsilon_k} \\epsilon_i = 0")]]

#text("for all ")#mi("{i=1,\\dots,k}")#text(". By Fourier expansion (or Lagrange interpolation), one can then write ")#mi("{p_{\\epsilon_1,\\dots,\\epsilon_k}}")#text(" as a polynomial")

#align(center)[#tao-fit-display[#mitex("p_{\\epsilon_1,\\dots,\\epsilon_k} = 1 + Q( \\epsilon_1,\\dots,\\epsilon_k)")]]

#text("where ")#mi("{Q(t_1,\\dots,t_k)}")#text(" is a polynomial in ")#mi("{k}")#text(" variables that is a linear combination of monomials ")#mi("{t_{i_1} \\dots t_{i_r}}")#text(" with ")#mi("{i_1 < \\dots < i_r}")#text(" and ")#mi("{r \\geq 2}")#text(" (thus ")#mi("{Q}")#text(" has no constant or linear terms, and no monomials with repeated terms). The point is that the mean zero condition allows one to eliminate the linear terms. If we now consider the weight function")

#align(center)[#tao-fit-display[#mitex("w(n) := 1 + Q( \\lambda(L_1(n)), \\dots, \\lambda(L_k(n)) )")]]

#text("then ")#mi("{w}")#text(" is non-negative, is supported solely on ")#mi("{n}")#text(" for which ")#mi("{(\\lambda(L_1(n)),\\dots,\\lambda(L_k(n)))}")#text(" is a forbidden pattern, and is equal to ")#mi("{1}")#text(" plus a linear combination of monomials ")#mi("{\\lambda(L_{i_1}(n)) \\dots \\lambda(L_{i_r}(n))}")#text(" with ")#mi("{r \\geq 2}")#text(".")

#text("The Liouville pseudorandomness principle then predicts that sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) Q( \\lambda(L_1(n)), \\dots, \\lambda(L_k(n)) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) Q( \\lambda(L_1(n)), \\dots, \\lambda(L_k(n)) ) 1_{L_i(n) \\text{ prime}}")]]

#text("or more generally")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) Q( \\lambda(L_1(n)), \\dots, \\lambda(L_k(n)) ) f(L_i(n))")]]

#text("should be asymptotically negligible; intuitively, the point here is that the prime factorisation of ")#mi("{L_i(n)}")#text(" should not influence the Liouville function of ")#mi("{L_j(n)}")#text(", even on the short arithmetic progressions that the divisor sum ")#mi("{\\nu}")#text(" is built out of, and so any monomial ")#mi("{\\lambda(L_{i_1}(n)) \\dots \\lambda(L_{i_r}(n))}")#text(" occurring in ")#mi("{Q( \\lambda(L_1(n)), \\dots, \\lambda(L_k(n)) )}")#text(" should exhibit strong cancellation for any of the above sums. If one accepts this principle, then all the expressions ")#link(<tao-989278ad10e33d97c46f>)[#text("(1)")]#text(", ")#link(<tao-8ce88e6477323ba9f5ea>)[#text("(2)")]#text(", ")#link(<tao-59d4ad4c9df2ae88a988>)[#text("(3)")]#text(" should be essentially unchanged when ")#mi("{\\nu(n)}")#text(" is replaced by ")#mi("{\\nu(n) w(n)}")#text(".")

#text("Suppose now for sake of contradiction that one could use sieve-theoretic methods to locate an ")#mi("{n}")#text(" in the support of some sieve weight ")#mi("{\\nu(n)}")#text(" obeying ")#mi("{P( L_1(n),\\dots,L_k(n))}")#text(". Then, by reweighting all sieve weights by the additional multiplicative factor of ")#mi("{w(n)}")#text(", the same arguments should also be able to locate ")#mi("{n}")#text(" in the support of ")#mi("{\\nu(n) w(n)}")#text(" for which ")#mi("{P( L_1(n),\\dots,L_k(n))}")#text(" holds. But ")#mi("{w}")#text(" is only supported on those ")#mi("{n}")#text(" whose Liouville sign pattern is forbidden, a contradiction. ")#mi("\\Box")

#text("Claim ")#link(<tao-a1453f380fa9f1a08e84>)[#text("1")]#text(" is sharp in the following sense: if the convex hull of the forbidden sign patterns of ")#mi("{P}")#text(" do ")#emph[#text("not")]#text(" contain the origin, then by the Hahn-Banach theorem (in the hyperplane separation form), there exist real coefficients ")#mi("{c_1,\\dots,c_k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("c_1 \\epsilon_1 + \\dots + c_k \\epsilon_k < -c")]]

#text("for all forbidden sign patterns ")#mi("{(\\epsilon_1,\\dots,\\epsilon_k)}")#text(" and some ")#mi("{c>0}")#text(". On the other hand, from Liouville pseudorandomness one expects that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\nu(n) (c_1 \\lambda(L_1(n)) + \\dots + c_k \\lambda(L_k(n)))")]]

#text("is negligible (as compared against ")#mi("{\\sum_n \\nu(n)}")#text(" for any reasonable sieve weight ")#mi("{\\nu}")#text(". We conclude that for some ")#mi("{n}")#text(" in the support of ")#mi("{\\nu}")#text(", that ")#metadata(none) <tao-64daa44ad493ff28a96e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("c_1 \\lambda(L_1(n)) + \\dots + c_k \\lambda(L_k(n)) > -c")]]

#text("and hence ")#mi("{(\\lambda(L_1(n)),\\dots,\\lambda(L_k(n)))}")#text(" is not a forbidden sign pattern. This does not actually imply that ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(" holds, but it does not prevent ")#mi("{P(L_1(n),\\dots,L_k(n))}")#text(" from holding purely from parity considerations. Thus, we do not expect a parity obstruction of the type in Claim ")#link(<tao-a1453f380fa9f1a08e84>)[#text("1")]#text(" to hold when the convex hull of forbidden sign patterns does not contain the origin.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4")]#text(" Let ")#mi("{G}")#text(" be a graph on ")#mi("{k}")#text(" vertices ")#mi("{\\{1,\\dots,k\\}}")#text(", and let ")#mi("{P(l_1,\\dots,l_k)}")#text(" be the property that one can find an edge ")#mi("{\\{i,j\\}}")#text(" of ")#mi("{G}")#text(" with ")#mi("{l_i,l_j}")#text(" both prime. We claim that this property is subject to the parity problem precisely when ")#mi("{G}")#text(" is two-colourable. Indeed, if ")#mi("{G}")#text(" is two-colourable, then we can colour ")#mi("{\\{1,\\dots,k\\}}")#text(" into two colours (say, red and green) such that all edges in ")#mi("{G}")#text(" connect a red vertex to a green vertex. If we then consider the two sign patterns in which all the red vertices have one sign and the green vertices have the opposite sign, these are two forbidden sign patterns which contain the origin in the convex hull, and so the parity problem applies. Conversely, suppose that ")#mi("{G}")#text(" is not two-colourable, then it contains an odd cycle. Any forbidden sign pattern then must contain more ")#mi("{+1}")#text("s on this odd cycle than ")#mi("{-1}")#text("s (since otherwise two of the ")#mi("{-1}")#text("s are adjacent on this cycle by the pigeonhole principle, and this is not forbidden), and so by convexity any tuple in the convex hull of this sign pattern has a positive sum on this odd cycle. Hence the origin is not in the convex hull, and the parity obstruction does not apply. (See also ")#link("https://terrytao.wordpress.com/2014/07/09/the-parity-problem-obstruction-for-the-binary-goldbach-problem-with-bounded-error/")[#text("this previous post")]#text(" for a similar obstruction ultimately coming from two-colourability).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" An example of a parity-obstructed property (supplied by Zeb Brady) that does not come from two-colourability: we let ")#mi("{P( l_{\\{1,2\\}}, l_{\\{1,3\\}}, l_{\\{1,4\\}}, l_{\\{2,3\\}}, l_{\\{2,4\\}}, l_{\\{3,4\\}} )}")#text(" be the property that ")#mi("{l_{A_1},\\dots,l_{A_r}}")#text(" are prime for some collection ")#mi("{A_1,\\dots,A_r}")#text(" of pair sets that cover ")#mi("{\\{1,\\dots,4\\}}")#text(". For instance, this property holds if ")#mi("{l_{\\{1,2\\}}, l_{\\{3,4\\}}}")#text(" are both prime, or if ")#mi("{l_{\\{1,2\\}}, l_{\\{1,3\\}}, l_{\\{1,4\\}}}")#text(" are all prime, but not if ")#mi("{l_{\\{1,2\\}}, l_{\\{1,3\\}}, l_{\\{2,3\\}}}")#text(" are the only primes. An example of a forbidden sign pattern is the pattern where ")#mi("{\\{1,2\\}, \\{2,3\\}, \\{1,3\\}}")#text(" are given the sign ")#mi("{-1}")#text(", and the other three pairs are given ")#mi("{+1}")#text(". Averaging over permutations of ")#mi("{1,2,3,4}")#text(" we see that zero lies in the convex hull, and so this example is blocked by parity. However, there is no sign pattern such that it and its negation are both forbidden, which is another formulation of two-colourability.")
]

#text("Of course, the absence of a parity obstruction does not automatically mean that the desired claim is true. For instance, given an admissible ")#mi("{5}")#text("-tuple ")#mi("{h_1,\\dots,h_5}")#text(", parity obstructions do not prevent one from establishing the existence of infinitely many ")#mi("{n}")#text(" such that at least three of ")#mi("{n+h_1,\\dots,n+h_5}")#text(" are prime, however we are not yet able to actually establish this, even assuming strong sieve-theoretic hypotheses such as the generalised Elliott-Halberstam hypothesis. (However, the argument giving ")#link(<tao-64daa44ad493ff28a96e>)[#text("(4)")]#text(" does easily give the far weaker claim that there exist infinitely many ")#mi("{n}")#text(" such that at least three of ")#mi("{n+h_1,\\dots,n+h_5}")#text(" have a Liouville function of ")#mi("{-1}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Another way to get past the parity problem in some cases is to take advantage of linear forms that are constant multiples of each other (which correlates the Liouville functions to each other). For instance, on GEH we can find two ")#mi("{E_3}")#text(" numbers (products of exactly three primes) that differ by exactly ")#mi("{60}")#text("; a direct sieve approach using the linear forms ")#mi("{n,n+60}")#text(" fails due to the parity obstruction, but instead one can first find ")#mi("{n}")#text(" such that two of ")#mi("{n,n+4,n+10}")#text(" are prime, and then among the pairs of linear forms ")#mi("{(15n,15n+60)}")#text(", ")#mi("{(6n,6n+60)}")#text(", ")#mi("{(10n+40,10n+100)}")#text(" one can find a pair of ")#mi("{E_3}")#text(" numbers that differ by exactly ")#mi("{60}")#text(". See ")#link("http://arxiv.org/abs/0803.2636")[#text("this paper of Goldston, Graham, Pintz, and Yildirim")]#text(" for more examples of this type.")
]

#text("I thank John Friedlander and Sid Graham for helpful discussions and encouragement.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-441544")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2014")])]

#text("typo: near the beginning of the blog, missing “can” in “…which broadly be formulated as follows…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-441577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2014")])]

#text("Dear Pro.Terry,may I ask you a question burdened of psychology. I think I miss all mathematician’s life that they contributed 1 or 2 breakthough tools to human.They spended 20 years or over only discovering a huge tool before they die.If a tool that costs much time like ,that,so the rest of 6 best proble ms of Clay maybe cost nearly 1000 years.So, could you arrange of the difficult level of 6 that problems.I imagine someone like superman can solve them only within 30 year.Maybe I am crazy,but I always wait this become true.")

#text("years..Sould you arrange the order of difficult level of")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-442052")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2014")])]

#text("In the paragraph following Claim 1, in the sentence “One can also check that the property ‘at least {j} of the {k} numbers {l_1,\\dots,l_k}’ are subject to the parity obstruction…,” the quoted property seems incomplete (e.g. it lacks a verb).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-442588")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("In the proof of Claim 1, should the monomials ")#mi("{t_{i_1} \\dots t_{i_k}}")#text(" instead be ")#mi("{t^{i_1} \\dots t^{i_k}}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-442589")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2014")])]

#text("Never mind:-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-442871")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2014")])]

#text("1) Where do you make use of the zero-mean property of the ")#mi("p_{\\epsilon_1,\\dots,\\epsilon_k}")#text("?")#linebreak()#text(" 2) In the 3rd line after the definition of w(n), should ")#mi("{r>2}")#text(" instead be ")#mi("{r \\geq 2}")#text(" (or if not what happened to Q’s quadratic terms)?")

#emph[#text("[Post edited to clarify (1) and correct (2) -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An averaged form of Chowla’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-453189")[#strong[#text("An averaged form of Chowla’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2015")])]

#text("[…] is a variant of the twin prime conjecture (though possibly a tiny bit easier to prove), and is subject to the notorious parity barrier (as discussed in this previous post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5397ebd614013cf057456e5b8e51b077dc2185a753b0168957822ed8355aec8e-35248927db644d7521b6795316036ad765a6d33a8ff67b9ba2a2bdcd43ec08e5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kurt Lovelace")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-453202")[#strong[#text("Kurt Lovelace")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2015")])]

#text("Reblogged this on ")#link("https://mathpoem.wordpress.com/2015/03/18/a-general-parity-problem-obstruction/")[#text("Inbetween Math and Poetry")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-458473")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] them from other twins of almost primes. The parity problem is discussed in these previous blog posts; this obstruction is ultimately powered by the Möbius pseudorandomness principle that asserts […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-459428")[#strong[#text("The logarithmically averaged Chowla and Elliott conjectures for two-point correlations; the Erdos discrepancy problem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2015")])]

#text("[…] as (2) or (3) are known to be subject to the “parity problem” (discussed numerous times previously on this blog), which roughly speaking means that they cannot be proven solely using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lev")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-509034")[#strong[#text("Lev")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("Is it possible to somehow break parity phenomenon for certain prime pairs (differing by 60, say) by a cooperation of Remark 1 and Bombieri sieve?")

#text("As far as I know, we are able to produce pairs of E_3-numbers which differs by 60, but 60 is the lowest such a positive integer right now, isn’t it?")

#text("Best regards!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/21/a-general-parity-problem-obstruction/#comment-509048")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2018")])]

#text("Not with current methods. The trick of using reducible linear forms can only generate almost primes that contain very small prime factors such as 2,3,5, and these are a zero density subset of the almost primes and so cannot be picked up by sieves such as the Bombieri sieve (indeed one of the very first things such sieves do is throw out all numbers that are divisible by very small primes).")

#text("Basically, numbers which are divisible by very small primes are totally unhelpful for finding primes, but they are can technically still be (say) ")#mi("E_2")#text(" or ")#mi("E_3")#text(" numbers, which is why the Remark 1 loophole around the parity problem can be used for problems involving such classes of numbers, but not for the primes themselves.")
]
]
