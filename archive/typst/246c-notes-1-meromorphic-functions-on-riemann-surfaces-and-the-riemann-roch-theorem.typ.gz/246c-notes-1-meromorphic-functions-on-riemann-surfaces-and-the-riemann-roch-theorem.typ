// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:20:03.389488+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("246C notes 1: Meromorphic functions on Riemann surfaces, and the Riemann-Roch theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")[#text("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Previous set of notes: ")#link("https://terrytao.wordpress.com/2021/02/12/246b-notes-4-the-riemann-zeta-function-and-the-prime-number-theorem/")[#text("246B Notes 4")]#text(". Next set of notes: ")#link("https://terrytao.wordpress.com/2018/04/12/246c-notes-2-circle-packings-conformal-maps-and-quasiconformal-maps/")[#text("Notes 2")]#text(".")#linebreak()#text(" The fundamental object of study in real differential geometry are the ")#link("https://en.wikipedia.org/wiki/Manifold")[#text("real manifolds")]#text(": Hausdorff topological spaces ")#mi("{M = M^n}")#text(" that locally look like open subsets of a Euclidean space ")#mi("{{\\bf R}^n}")#text(", and which can be equipped with an ")#link("https://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlas")]#text(" ")#mi("{(\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha)_{\\alpha \\in A}}")#text(" of ")#link("https://en.wikipedia.org/wiki/Atlas_(topology)#Charts")[#text("coordinate charts")]#text(" ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(" from open subsets ")#mi("{U_\\alpha}")#text(" covering ")#mi("{M}")#text(" to open subsets ")#mi("{V_\\alpha}")#text(" in ")#mi("{{\\bf R}^n}")#text(", which are homeomorphisms; in particular, the ")#emph[#text("transition maps")]#text(" ")#mi("{\\tau_{\\alpha,\\beta}: \\phi_\\alpha( U_\\alpha \\cap U_\\beta ) \\rightarrow \\phi_\\beta( U_\\alpha \\cap U_\\beta )}")#text(" defined by ")#mi("{\\tau_{\\alpha,\\beta}: \\phi_\\beta \\circ \\phi_\\alpha^{-1}}")#text(" are all continuous. (It is also common to impose the requirement that the manifold ")#mi("{M}")#text(" be second countable, though this will not be important for the current discussion.) A ")#emph[#text("smooth real manifold")]#text(" is a real manifold in which the transition maps are all smooth.")#linebreak()#text(" In a similar fashion, the fundamental object of study in complex differential geometry are the ")#link("https://en.wikipedia.org/wiki/Complex_manifold")[#text("complex manifolds")]#text(", in which the model space is ")#mi("{{\\bf C}^n}")#text(" rather than ")#mi("{{\\bf R}^n}")#text(", and the transition maps ")#mi("{\\tau_{\\alpha\\beta}}")#text(" are required to be holomorphic (and not merely smooth or continuous). In the real case, the one-dimensional manifolds (curves) are quite simple to understand, particularly if one requires the manifold to be connected; for instance, all compact connected one-dimensional real manifolds are homeomorphic to the unit circle (why?). However, in the complex case, the connected one-dimensional manifolds – the ones that look locally like subsets of ")#mi("{{\\bf C}}")#text(" – are much richer, and are known as ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surfaces")]#text(". For sake of completeness we give the (somewhat lengthy) formal definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Riemann surface)")]#text(" If ")#mi("{M}")#text(" is a Hausdorff connected topological space, a (one-dimensional complex) atlas is a collection ")#mi("{(\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha)_{\\alpha \\in A}}")#text(" of homeomorphisms from open subsets ")#mi("{(U_\\alpha)_{\\alpha \\in A}}")#text(" of ")#mi("{M}")#text(" that cover ")#mi("{M}")#text(" to open subsets ")#mi("{V_\\alpha}")#text(" of the complex numbers ")#mi("{{\\bf C}}")#text(", such that the transition maps ")#mi("{\\tau_{\\alpha,\\beta}: \\phi_\\alpha( U_\\alpha \\cap U_\\beta ) \\rightarrow \\phi_\\beta( U_\\alpha \\cap U_\\beta )}")#text(" defined by ")#mi("{\\tau_{\\alpha,\\beta}: \\phi_\\beta \\circ \\phi_\\alpha^{-1}}")#text(" are all holomorphic. Here ")#mi("{A}")#text(" is an arbitrary index set. Two atlases ")#mi("{(\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha)_{\\alpha \\in A}}")#text(", ")#mi("{(\\phi^{\\prime}_\\beta: U^{\\prime}_\\beta \\rightarrow V^{\\prime}_\\beta)_{\\beta \\in B}}")#text(" on ")#mi("{M}")#text(" are said to be ")#emph[#text("equivalent")]#text(" if their union is also an atlas, thus the transition maps ")#mi("{\\phi^{\\prime}_\\beta \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha \\cap U^{\\prime}_\\beta) \\rightarrow \\phi^{\\prime}_\\beta(U_\\alpha \\cap U^{\\prime}_\\beta)}")#text(" and their inverses are all holomorphic. A ")#link("https://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surface")]#text(" is a Hausdorff connected topological space ")#mi("{M}")#text(" equipped with an equivalence class of one-dimensional complex atlases.")#linebreak()#text(" A map ")#mi("{f: M \\rightarrow M^{\\prime}}")#text(" from one Riemann surface ")#mi("{M}")#text(" to another ")#mi("{M^{\\prime}}")#text(" is ")#emph[#text("holomorphic")]#text(" if the maps ")#mi("{\\phi^{\\prime}_\\beta \\circ f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha \\cap f^{-1}(U^{\\prime}_\\beta)) \\rightarrow {\\bf C}}")#text(" are holomorphic for any charts ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow V_\\alpha}")#text(", ")#mi("{\\phi^{\\prime}_\\beta: U^{\\prime}_\\beta \\rightarrow V^{\\prime}_\\beta}")#text(" of an atlas of ")#mi("{M}")#text(" and ")#mi("{M^{\\prime}}")#text(" respectively; it is not hard to see that this definition does not depend on the choice of atlas. It is also clear that the composition of two holomorphic maps is holomorphic (and in fact the class of Riemann surfaces with their holomorphic maps forms a ")#link("https://en.wikipedia.org/wiki/Category_(mathematics)")[#text("category")]#text(").")
]

#text("Here are some basic examples of Riemann surfaces.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Quotients of ")#mi("{{\\bf C}}")#text(")")]#text(" The complex numbers ")#mi("{{\\bf C}}")#text(" clearly form a Riemann surface (using the identity map ")#mi("{\\phi: {\\bf C} \\rightarrow {\\bf C}}")#text(" as the single chart for an atlas). Of course, maps ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" that are holomorphic in the usual sense will also be holomorphic in the sense of the above definition, and vice versa, so the notion of holomorphicity for Riemann surfaces is compatible with that of holomorphicity for complex maps. More generally, given any discrete additive subgroup ")#mi("{\\Lambda}")#text(" of ")#mi("{{\\bf C}}")#text(", the quotient ")#mi("{{\\bf C}/\\Lambda}")#text(" is a Riemann surface. There are an infinite number of possible atlases to use here; one such is to pick a sufficiently small neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{{\\bf C}}")#text(" and take the atlas ")#mi("{(\\phi_\\alpha: U_\\alpha \\rightarrow U)_{\\alpha \\in {\\bf C}/\\Lambda}}")#text(" where ")#mi("{U_\\alpha := \\alpha+U}")#text(" and ")#mi("{\\phi_\\alpha(\\alpha+z) := z}")#text(" for all ")#mi("{z \\in U}")#text(". In particular, given any non-real complex number ")#mi("{\\omega}")#text(", the ")#link("https://en.wikipedia.org/wiki/Complex_torus")[#text("complex torus")]#text(" ")#mi("{{\\bf C} / \\langle 1, \\omega \\rangle}")#text(" formed by quotienting ")#mi("{{\\bf C}}")#text(" by the lattice ")#mi("{\\langle 1, \\omega \\rangle := \\{ n + m \\omega: n,m \\in {\\bf Z}\\}}")#text(" is a Riemann surface.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" Any open connected subset ")#mi("{U}")#text(" of ")#mi("{{\\bf C}}")#text(" is a Riemann surface. By the ")#link("https://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(", all simply connected open ")#mi("{U \\subset {\\bf C}}")#text(", other than ")#mi("{{\\bf C}}")#text(" itself, are isomorphic (as Riemann surfaces) to the unit disk (or, equivalently, to the upper half-plane).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Riemann sphere)")]#text(" The Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", as a topological manifold, is the ")#link("https://en.wikipedia.org/wiki/Alexandroff_extension")[#text("one-point compactification")]#text(" of ")#mi("{{\\bf C}}")#text(". Topologically, this is a sphere and is in particular connected. One can cover the Riemann sphere by the two open sets ")#mi("{U_1 := {\\bf C}}")#text(" and ")#mi("{U_2 := {\\bf C} \\cup \\{\\infty\\} \\backslash \\{0\\}}")#text(", and give these two open sets the charts ")#mi("{\\phi_1: U_1 \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\phi_2: U_2 \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{\\phi_1(z) := z}")#text(" for ")#mi("{z \\in {\\bf C}}")#text(", ")#mi("{\\phi_2(z) := 1/z}")#text(" for ")#mi("{z \\in {\\bf C} \\backslash \\{0\\}}")#text(", and ")#mi("{\\phi_2(\\infty) := 0}")#text(". This is a complex atlas since the ")#mi("{1/z}")#text(" is holomorphic on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(".")#linebreak()#text(" An alternate way of viewing the Riemann sphere is as the projective line ")#mi("{\\mathbf{CP}^1}")#text(". Topologically, this is the punctured complex plane ")#mi("{{\\bf C}^2 \\backslash \\{(0,0)\\}}")#text(" quotiented out by non-zero complex dilations, thus elements of this space are equivalence classes ")#mi("{[z,w] := \\{ (\\lambda z, \\lambda w): \\lambda \\in {\\bf C} \\backslash \\{0\\}\\}}")#text(" with the usual quotient topology. One can cover this space by two open sets ")#mi("{U_1 := \\{ [z,1]: z \\in {\\bf C} \\}}")#text(" and ")#mi("{U_2: \\{ [1,w]: w \\in {\\bf C} \\}}")#text(" and give these two open sets the charts ")#mi("{\\phi: U_1 \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\phi_2: U_2 \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{\\phi_1([z,1]) := z}")#text(" for ")#mi("{z \\in {\\bf C}}")#text(", ")#mi("{\\phi_2([1,w]) := w}")#text(". This is a complex atlas, basically because ")#mi("{[z,1] = [1,1/z]}")#text(" for ")#mi("{z \\in {\\bf C} \\backslash \\{0\\}}")#text(" and ")#mi("{1/z}")#text(" is holomorphic on ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Verify that the Riemann sphere is isomorphic (as a Riemann surface) to the projective line.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 6 (Smooth algebraic plane curves)")]#text(" ")#metadata(none) <tao-3c5eb225c3228d59e726>#text(" Let ")#mi("{P(z_1,z_2,z_3)}")#text(" be a complex polynomial in three variables which is homogeneous of some degree ")#mi("{d \\geq 1}")#text(", thus ")#metadata(none) <tao-3485639faf1591f3c16f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P( \\lambda z_1, \\lambda z_2, \\lambda z_3) = \\lambda^d P( z_1, z_2, z_3).")]]

#text(" Define the complex projective plane ")#mi("{\\mathbf{CP}^2}")#text(" to be the punctured space ")#mi("{{\\bf C}^3 \\backslash \\{0\\}}")#text(" quotiented out by non-zero complex dilations, with the usual quotient topology. (There is another important topology to place here of fundamental importance in algebraic geometry, namely the ")#link("https://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski topology")]#text(", but we will ignore this topology here.) This is a compact space, whose elements are equivalence classes ")#mi("{[z_1,z_2,z_3] := \\{ (\\lambda z_1, \\lambda z_2, \\lambda z_3)\\}}")#text(". Inside this plane we can define the (projective, degree ")#mi("{d}")#text(") ")#link("https://en.wikipedia.org/wiki/Algebraic_curve")[#text("algebraic curve")]

#align(center)[#tao-fit-display[#mitex("Z(P) := \\{ [z_1,z_2,z_3] \\in \\mathbf{CP}^2: P(z_1,z_2,z_3) = 0 \\};")]]

#text("this is well defined thanks to ")#link(<tao-3485639faf1591f3c16f>)[#text("(1)")]#text(". It is easy to verify that ")#mi("{Z(P)}")#text(" is a closed subset of ")#mi("{\\mathbf{CP}^2}")#text(" and hence compact; it is non-empty thanks to the fundamental theorem of algebra.")#linebreak()#text(" Suppose that ")#mi("{P}")#text(" is ")#emph[#text("irreducible")]#text(", which means that it is not the product of polynomials of smaller degree. As we shall show in the appendix, this makes the algebraic curve connected. (Actually, algebraic curves remain connected even in the reducible case, thanks to ")#link("https://en.wikipedia.org/wiki/B%C3%A9zout%27s_theorem")[#text("Bezout’s theorem")]#text(", but we will not prove that theorem here.) We will in fact make the stronger ")#emph[#text("nonsingularity")]#text(" hypothesis: there is no triple ")#mi("{(z_1,z_2,z_3) \\in {\\bf C}^3 \\backslash \\{(0,0,0)\\}}")#text(" such that the four numbers ")#mi("{P(z_1,z_2,z_3), \\frac{\\partial}{\\partial z_j} P(z_1,z_2,z_3)}")#text(" simultaneously vanish for ")#mi("{j=1,2,3}")#text(". (This looks like four constraints, but is in fact essentially just three, due to the Euler identity")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^3 z_j \\frac{\\partial}{\\partial z_j} P(z_1,z_2,z_3) = d P(z_1,z_2,z_3)")]]

#text("that arises from differentiating ")#link(<tao-3485639faf1591f3c16f>)[#text("(1)")]#text(" in ")#mi("{\\lambda}")#text(". The fact that nonsingularity implies irreducibility is another consequence of Bezout’s theorem, which is not proven here.) For instance, the polynomial ")#mi("{z_1^2 z_3 - z_2^3}")#text(" is irreducible but singular (there is a “cusp” singularity at ")#mi("{[0,0,1]}")#text("). With this hypothesis, we call the curve ")#mi("{Z(P)}")#text(" ")#emph[#text("smooth")]#text(".")#linebreak()#text(" Now suppose ")#mi("{[z_1,z_2,z_3]}")#text(" is a point in ")#mi("{Z(P)}")#text("; without loss of generality we may take ")#mi("{z_3}")#text(" non-zero, and then we can normalise ")#mi("{z_3=1}")#text(". Now one can think of ")#mi("{P(z_1,z_2,1)}")#text(" as an inhomogeneous polynomial in just two variables ")#mi("{z_1,z_2}")#text(", and by nondegeneracy we see that the gradient ")#mi("{(\\frac{\\partial}{\\partial z_1} P(z_1,z_2,1), \\frac{\\partial}{\\partial z_2} P(z_1,z_2,1))}")#text(" is non-zero whenever ")#mi("{P(z_1,z_2,1)=0}")#text(". By the (complexified) implicit function theorem, this ensures that the ")#emph[#text("affine algebraic curve")]

#align(center)[#tao-fit-display[#mitex("Z(P)_{aff} := \\{ (z_1,z_2) \\in {\\bf C}^2: P(z_1,z_2,1) = 0 \\}")]]

#text("is a Riemann surface in a neighbourhood of ")#mi("{(z_1,z_2,1)}")#text("; we leave this as an exercise. This can be used to give a coordinate chart for ")#mi("{Z(P)}")#text(" in a neighbourhood of ")#mi("{[z_1,z_2,z_3]}")#text(" when ")#mi("{z_3 \\neq 0}")#text(". Similarly when ")#mi("{z_1,z_2}")#text(" is non-zero. This can be shown to give an atlas on ")#mi("{Z(P)}")#text(", which (assuming the connectedness claim that we will prove later) gives ")#mi("{Z(P)}")#text(" the structure of a Riemann surface.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" State and prove a complex version of the implicit function theorem that justifies the above claim that the charts in the above example form an atlas, and an algebraic curve associated to a non-singular polynomial is a Riemann surface.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-6575bebbc238952b7ad2>

#list(
[#text("(i) Show that all (irreducible plane projective) algebraic curves of degree ")#mi("{1}")#text(" are isomorphic to the Riemann sphere. (Hint: reduce to an explicit linear polynomial such as ")#mi("{z_3}")#text(".)")],
[#text("(ii) Show that all (irreducible plane projective) algebraic curves of degree ")#mi("{2}")#text(" are isomorphic to the Riemann sphere. (Hint: to reduce computation, first use some linear algebra to reduce the homogeneous quadratic polynomial to a standard form, such as ")#mi("{z_1^2+z_2^2+z_3^2}")#text(" or ")#mi("{z_2 z_3 - z_1^2}")#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" If ")#mi("{a,b}")#text(" are complex numbers, show that the projective cubic curve")

#align(center)[#tao-fit-display[#mitex("\\{ [z_1, z_2, z_3]: z_2^2 z_3 = z_1^3 + a z_1 z_3^2 + b z_3^3 \\}")]]

#text("is nonsingular if and only if the ")#link("https://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" ")#mi("{-16 (4a^3 + 27b^2)}")#text(" is non-zero. (When this occurs, the curve is called an ")#link("https://en.wikipedia.org/wiki/Elliptic_curve")[#text("elliptic curve")]#text(" (in Weierstrass form), which is a fundamentally important example of a Riemann surface in many areas of mathematics, and number theory in particular. One can also define the discriminant for polynomials of higher degree, but we will not do so here.)")
]

#text("A recurring theme in mathematics is that an object ")#mi("{X}")#text(" is often best studied by understanding spaces of “good” functions on ")#mi("{X}")#text(". In complex analysis, there are two basic types of good functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10")]#text(" Let ")#mi("{X}")#text(" be a Riemann surface. A ")#emph[#text("holomorphic function")]#text(" on ")#mi("{X}")#text(" is a holomorphic map from ")#mi("{X}")#text(" to ")#mi("{{\\bf C}}")#text("; the space of all such functions will be denoted ")#mi("{{\\mathcal O}(X)}")#text(". A ")#emph[#text("meromorphic function")]#text(" on ")#mi("{X}")#text(" is a holomorphic map from ")#mi("{X}")#text(" to the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(", that is not identically equal to ")#mi("{\\infty}")#text("; the space of all such functions will be denoted ")#mi("{M(X)}")#text(".")
]

#text("One can also define holomorphicity and meromorphicity in terms of charts: a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" is holomorphic if and only if, for any chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(", the map ")#mi("{f \\circ \\phi^{-1}_\\alpha: \\phi_\\alpha(U_\\alpha) \\rightarrow {\\bf C}}")#text(" is holomorphic in the usual complex analysis sense; similarly, a function ")#mi("{f: X \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" is meromorphic if and only if the preimage ")#mi("{f^{-1}(\\{\\infty\\})}")#text(" is discrete (otherwise, by analytic continuation and the connectedness of ")#mi("{X}")#text(", ")#mi("{f}")#text(" will be identically equal to ")#mi("{\\infty}")#text(") and for any chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow X}")#text(", the map ")#mi("{f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha) \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" becomes a meromorphic function in the usual complex analysis sense, after removing the discrete set of complex numbers where this map is infinite. One consequence of this alternate definition is that the space ")#mi("{{\\mathcal O}(X)}")#text(" of holomorphic functions is a commutative ")#link("https://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("complex algebra")]#text(" (a complex vector space closed under pointwise multiplication), while the space ")#mi("{M(X)}")#text(" of meromorphic functions is a ")#link("https://en.wikipedia.org/wiki/Field_(mathematics)")[#text("complex field")]#text(" (a commutative complex algebra where every non-zero element has an inverse). Another consequence is that one can define the notion of a zero of given order ")#mi("{k}")#text(", or a pole of order ")#mi("{k}")#text(", for a holomorphic or meromorphic function, by composing with a chart map and using the usual complex analysis notions there, noting (from the holomorphicity of transition maps and their inverses) that this does not depend on the choice of chart. (However, one cannot similarly define the residue of a meromorphic function on ")#mi("{X}")#text(" this way, as the residue turns out to be chart-dependent thanks to the chain rule. Residues should instead be applied to meromorphic ")#mi("{1}")#text("-forms, a concept we will introduce later.) A third consequence is analytic continuation: if two holomorphic or meromorphic functions on ")#mi("{X}")#text(" agree on a non-empty open set, then they agree everywhere.")#linebreak()#text(" On the complex numbers ")#mi("{{\\bf C}}")#text(", there are of course many holomorphic functions and meromorphic functions; for instance any power series with an infinite radius of convergence will give a holomorphic function, and the quotient of any two such functions (with non-zero denominator) will give a meromorphic function. Furthermore, we have extremely wide latitude in how to specify the zeroes of the holomorphic function, or the zeroes and poles of the meromorphic function, thanks to tools such as the ")#link("https://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation theorem")]#text(" or the ")#link("https://en.wikipedia.org/wiki/Mittag-Leffler%27s_theorem")[#text("Mittag-Leffler theorem")]#text(" (covered in previous quarters).")#linebreak()#text(" It turns out, however, that the situation changes dramatically when the Riemann surface ")#mi("{X}")#text(" is ")#emph[#text("compact")]#text(", with the holomorphic and meromorphic functions becoming much more rigid. First of all, compactness eliminates all holomorphic functions except for the constants:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-cdc2def9aec4576c7f9f>#text(" Let ")#mi("{f \\in \\mathcal{O}(X)}")#text(" be a holomorphic function on a compact Riemann surface ")#mi("{X}")#text(". Then ")#mi("{f}")#text(" is constant.")
]

#text("This result should be seen as a close sibling of ")#link("https://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(" that all bounded entire functions are constant. (Indeed, in the case of a complex torus, this lemma is a corollary of Liouville’s theorem.)")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" As ")#mi("{f}")#text(" is continuous and ")#mi("{X}")#text(" is compact, ")#tao-math("{\\left|f(z_0)\\right|}", block: false)#text(" must attain a maximum at some point ")#mi("{z_0 \\in X}")#text(". Working in a chart around ")#mi("{z_0}")#text(" and applying the ")#link("https://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(", we conclude that ")#mi("{f}")#text(" is constant in a neighbourhood of ")#mi("{z_0}")#text(", and hence is constant everywhere by analytic continuation. ")#mi("\\Box")#linebreak()#text(" This dramatically cuts down the number of possible meromorphic functions – indeed, for an abstract Riemann surface, it is not immediately obvious that there are any non-constant meromorphic functions at all! As the poles are isolated and the surface is compact, a meromorphic function can only have finitely many poles, and if one prescribes the location of the poles and the maximum order at each pole, then we shall see that the space of meromorphic functions is now finite dimensional. The precise dimensions of these spaces are in fact rather interesting, and obey a basic duality law known as the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(". We will give a mostly self-contained proof of the Riemann-Roch theorem in these notes, omitting only some facts about genus and Euler characteristic, as well as construction of certain meromorphic ")#mi("{1}")#text("-forms (also known as Abelian differentials).")#linebreak()#text(" A more detailed study of Riemann surface (and more generally, complex manifolds) can be found for instance in Griffiths and Harris’s “")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1288523")[#text("Principles of Algebraic Geometry")]#text("“.")#linebreak()#text(" ")#metadata(none) <tao-d77151782cefd35a0e2d>

#heading(level: 1)[#strong[#text(" — 1. Divisors — ")]]

#text("To discuss the zeroes and poles of meromorphic functions, it is convenient to introduce an abstraction of the concept of “a collection of zeroes and poles”, known as a ")#link("https://en.wikipedia.org/wiki/Divisor_(algebraic_geometry)")[#text("divisor")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12 (Divisor)")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface. A ")#emph[#text("divisor")]#text(" on ")#mi("{X}")#text(" is a formal integer linear combination ")#mi("{\\sum_P c_P \\cdot (P)}")#text(", where ")#mi("{P}")#text(" ranges over a finite collection of points in ")#mi("{X}")#text(", and ")#mi("{c_P}")#text(" are integers, with the obvious additive group structure; equivalently, the space ")#mi("{\\mathrm{Div}(X)}")#text(" of divisors is the free abelian group with generators ")#mi("{(P)}")#text(" with ")#mi("{P \\in X}")#text(" (where we make the usual convention ")#mi("{1 \\cdot (P) = (P)}")#text("). The number ")#mi("{\\sum_P c_P}")#text(" is the ")#emph[#text("degree")]#text(" of the divisor; we call each ")#mi("{c_P}")#text(" the ")#emph[#text("order")]#text(" of the divisor ")#mi("{D}")#text(" at ")#mi("{P}")#text(", with the convention that the order is zero for points not appearing in the sum. A divisor is ")#emph[#text("non-negative")]#text(" (or ")#emph[#text("effective")]#text(") if all the ")#mi("{c_P}")#text(" are non-negative, and we partially order the divisors by writing ")#mi("{D_1 \\geq D_2}")#text(" if ")#mi("{D_1-D_2}")#text(" is non-negative. This makes ")#mi("{\\mathrm{Div}(X)}")#text(" a lattice, so we can define the maximum ")#mi("{\\max(D_1,D_2)}")#text(" or minimum ")#mi("{\\min(D_1,D_2)}")#text(" of two divisors. Given a non-zero meromorphic function ")#mi("{f \\in M(X)}")#text(", the ")#emph[#text("principal divisor")]#text(" ")#mi("{(f)}")#text(" associated to ")#mi("{f}")#text(" is the divisor ")#mi("{\\sum_P \\mathrm{ord}_P(f) \\cdot (P)}")#text(", where ")#mi("{P}")#text(" ranges over the zeroes and poles of ")#mi("{f}")#text(", and ")#mi("{\\mathrm{ord}_P(f)}")#text(" is the order of zero (or negative the order of pole) at ")#mi("{P}")#text(". (Note that as zeroes and poles are isolated, and ")#mi("{X}")#text(" is compact, the number of zeroes and poles is automatically finite.)")
]

#text("Informally, one should think of ")#mi("{c_P \\cdot (P)}")#text(" as the abstraction of a zero of order ")#mi("{c_P}")#text(" at ")#mi("{P}")#text(", or a pole of order ")#mi("{-c_P}")#text(" if ")#mi("{c_P}")#text(" is negative.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 13")]#text(" Consider a rational function")

#align(center)[#tao-fit-display[#mitex("f(z) = \\alpha \\frac{(z-z_1) \\dots (z-z_m)}{(z-w_1)\\dots(z-w_n)}")]]

#text("for some non-zero complex number ")#mi("{\\alpha}")#text(" and some complex numbers ")#mi("{z_1,\\dots,z_m,w_1,\\dots,w_n}")#text(". This is a meromorphic function on ")#mi("{{\\bf C}}")#text(", and ")#mi("{f(1/z)}")#text(" is also meromorphic, so ")#mi("{f}")#text(" extends to a meromorphic function on the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". It has zeroes at ")#mi("{z_1,\\dots,z_m}")#text(" and poles at ")#mi("{w_1,\\dots,w_n}")#text(", and also has a zero of order ")#mi("{n-m}")#text(" (or a pole of order ")#mi("{m-n}")#text(") at ")#mi("{\\infty}")#text(", as can be seen by inspection of ")#mi("{z \\mapsto f(1/z)}")#text(" near the origin (or the growth of ")#mi("{f(z)}")#text(" near infinity), and thus")

#align(center)[#tao-fit-display[#mitex("(f) = \\sum_{j=1}^m (z_j) - \\sum_{j=1}^n (w_n) + (n-m) \\cdot (\\infty).")]]

#text("In particular, ")#mi("{(f)}")#text(" has degree zero.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Show that all meromorphic functions on the Riemann sphere come from rational functions as in the above example. Conclude in particular that every principal divisor on the Riemann sphere has degree zero. Give an alternate proof of this latter fact using the residue theorem. (We will generalise this fact to other Riemann surfaces shortly; see Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text(".)")
]

#text("It is easy to see (by working in a coordinate chart around ")#mi("{P}")#text(") that if ")#mi("{f, g \\in M(X)}")#text(" are non-zero meromorphic functions, that one has the ")#link("https://en.wikipedia.org/wiki/Valuation_(algebra)")[#text("valuation")]#text(" axioms")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{ord}_P(fg)  & = \\mathrm{ord}_P(f) + \\mathrm{ord}_P(g)", block: true)



#tao-math("\\mathrm{ord}_P(f/g)  & = \\mathrm{ord}_P(f) - \\mathrm{ord}_P(g)", block: true)



#tao-math("\\mathrm{ord}_P(f+g)  & \\geq \\min( \\mathrm{ord}_P(f), \\mathrm{ord}_P(g) )", block: true)
]

#text("for any ")#mi("{P \\in X}")#text(" (adopting the convention the zero function has order ")#mi("{+\\infty}")#text(" everywhere); thus we have ")#metadata(none) <tao-c380779f6175766fdbe9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(fg) = (f) + (g), \\quad (f/g) = (f) - (g); \\quad (f+g) \\geq \\min( (f), (g) )")]]

#text(" again adopting the convention that ")#mi("{(0)}")#text(" is larger than every divisor. In particular, the space ")#mi("{\\mathrm{PDiv}(X)}")#text(" of principal divisors of ")#mi("{X}")#text(" is a subgroup of ")#mi("{\\mathrm{Div}(X)}")#text(". We call two divisors ")#emph[#text("linearly equivalent")]#text(" if they differ by a principal divisor; this is clearly an equivalence relation.")#linebreak()#text(" The properties ")#link(<tao-c380779f6175766fdbe9>)[#text("(2)")]#text(" have the following consequence. Given a divisor ")#mi("{D}")#text(", let ")#mi("{L(D)}")#text(" be the space of all meromorphic functions ")#mi("{f \\in M(X)}")#text(" such that ")#mi("{(f)+D \\geq 0}")#text(" (including, by convention, the zero function ")#mi("{0}")#text("); thus, if ")#mi("{D = \\sum_P c_P \\cdot (P)}")#text(", then ")#mi("{L(D)}")#text(" consists of functions that have at worst a pole of order ")#mi("{c_P}")#text(" at ")#mi("{P}")#text(" (or a zero of order ")#mi("{-c_P}")#text(" or greater, if ")#mi("{c_P}")#text(" is negative). For instance, ")#mi("{L( 2(P) + (Q) - (R))}")#text(" is the space of meromorphic functions that have at most a double pole at ")#mi("{P}")#text(", a single pole at ")#mi("{Q}")#text(", and at least a simple zero at ")#mi("{R}")#text(", if ")#mi("{P,Q,R}")#text(" are distinct points in ")#mi("{X}")#text(". From ")#link(<tao-c380779f6175766fdbe9>)[#text("(2)")]#text(" (and the fact that non-zero constant functions have principal divisor zero) we see that each ")#mi("{L(D)}")#text(" is a vector space. We clearly have the nesting properties ")#mi("{L(D_1) \\subset L(D_2)}")#text(" if ")#mi("{D_1 \\leq D_2}")#text(", and also if ")#mi("{f \\in L(D_1), g \\in L(D_2)}")#text(" then ")#mi("{fg \\in L(D_1+D_2)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" In the language of ")#link("https://en.wikipedia.org/wiki/Vector_bundle")[#text("vector bundles")]#text(", one can identify a divisor ")#mi("{D}")#text(" with a certain holomorphic line bundle on ")#mi("{X}")#text(", and ")#mi("{L(D)}")#text(" can be identified with the space of sections of this bundle. This is arguably the more natural way to think about divisors; however, we will not adopt this language here.")
]

#text("If ")#mi("{D \\leq 0}")#text(" and ")#mi("{f \\in L(D)}")#text(", then ")#mi("{f}")#text(" is holomorphic on ")#mi("{X}")#text(" and hence (by Lemma ")#link(<tao-cdc2def9aec4576c7f9f>)[#text("11")]#text(") constant. We can thus easily compute ")#mi("{L(D)}")#text(" for zero or negative divisors:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 16")]#text(" ")#metadata(none) <tao-a5f02630dd666a73979b>#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface. Then ")#mi("{L(0)}")#text(" consists only of the constant functions, and ")#mi("{L(D)}")#text(" consists only of ")#mi("{0}")#text(" if ")#mi("{D<0}")#text(". In particular, ")#mi("{L(D)}")#text(" has dimension ")#mi("{1}")#text(" when ")#mi("{D=0}")#text(" and ")#mi("{0}")#text(" when ")#mi("{D<0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" If ")#mi("{(f)}")#text(" and ")#mi("{(g)}")#text(" are principal divisors with ")#mi("{(f) \\leq (g)}")#text(", show that ")#mi("{f}")#text(" is a constant multiple of ")#mi("{g}")#text(" with ")#mi("{(f) = (g)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-0136953b423d46e0070c>#text(" Let ")#mi("{D}")#text(" be a divisor. Show that ")#mi("{\\mathrm{dim}(L(D)) > 0}")#text(" if and only if ")#mi("{D}")#text(" is linearly equivalent to an effective divisor.")
]

#text("The situation for ")#mi("{D \\not \\leq 0}")#text(" (i.e., ")#mi("{D}")#text(" has positive order at at least one point) is more interesting. We first have a simple observation from linear algebra:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 19")]#text(" ")#metadata(none) <tao-8f26d6fe2a3dafd82808>#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface, ")#mi("{D}")#text(" be a divisor, and ")#mi("{P \\in X}")#text(" be a point. Then ")#mi("{L(D)}")#text(" has codimension at most ")#mi("{1}")#text(" in ")#mi("{L(D+(P))}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" be a chart that maps ")#mi("{P}")#text(" to the origin, and suppose that ")#mi("{D}")#text(" already had order ")#mi("{m}")#text(" at ")#mi("{P}")#text(" (so that ")#mi("{D+(P)}")#text(" had order ")#mi("{m+1}")#text("). Then functions ")#mi("{f \\in L(D+(P))}")#text(", when composed with the inverse ")#mi("{\\phi^{-1}}")#text(" of the chart function have Laurent expansion")

#align(center)[#tao-fit-display[#mitex("f( \\phi^{-1}(z) ) = \\frac{a_{m+1}}{z^{m+1}} + \\frac{a_m}{z^m} + \\dots")]]

#text("for some complex coefficients ")#mi("{a_{m+1},a_m,\\dots}")#text(" (which will depend on the choice of chart). The map ")#mi("{f \\mapsto a_{m+1}}")#text(" is clearly a linear map from ")#mi("{L(D+(P))}")#text(" to ")#mi("{{\\bf C}}")#text(", whose kernel is ")#mi("{L(D)}")#text(", and the claim follows. ")#mi("\\Box")#linebreak()#text(" As a corollary of this lemma and Corollary ")#link(<tao-a5f02630dd666a73979b>)[#text("16")]#text(", we see that the spaces ")#mi("{L(D)}")#text(" are all finite dimensional, with the dimension ")#mi("{\\mathrm{dim}(L(D))}")#text(" increasing by zero or one each time one adds an additional pole to ")#mi("{D}")#text(".")#linebreak()#text(" Here is another simple linear algebra relation between the dimensions of the spaces ")#mi("{L(D)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20")]#text(" ")#metadata(none) <tao-f804ff2fd8efd8445b74>#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface, and let ")#mi("{D_1,D_2}")#text(" be divisors. Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D_1) + \\mathrm{dim} L(D_2)")]]

#align(center)[#tao-fit-display[#mitex("\\leq \\mathrm{dim} L(\\min(D_1,D_2)) + \\mathrm{dim} L(\\max(D_1,D_2)).")]]
]

#emph[#text("Proof:")]#text(" From linear algebra we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D_1) + \\mathrm{dim} L(D_2) = \\mathrm{dim}(L(D_1) \\cap L(D_2)) + \\mathrm{dim} (L(D_1)+L(D_2)).")]]

#text("Since ")#mi("{L(D_1) \\cap L(D_2) = L(\\min(D_1,D_2))}")#text(" and ")#mi("{L(D_1) + L(D_2) \\subset L(\\max(D_1,D_2))}")#text(", the claim follows. ")#mi("\\Box")#linebreak()#text(" If ")#mi("{D}")#text(" is a divisor and ")#mi("{(f)}")#text(" is a principal divisor, then ")#link(<tao-c380779f6175766fdbe9>)[#text("(2)")]#text(" gives an isomorphism between ")#mi("{L(D)}")#text(" and ")#mi("{L(D+(f))}")#text(", by mapping ")#mi("{g \\in L(D)}")#text(" to ")#mi("{g/f \\in L(D+(f))}")#text(". In particular, the dimensions ")#mi("{\\mathrm{dim}(L(D))}")#text(" and ")#mi("{\\mathrm{dim}(L(D+(f)))}")#text(" of the linearly equivalent divisors ")#mi("{D, D+(f)}")#text(" are the same. If we define a ")#emph[#text("divisor class")]#text(" to be a coset ")#mi("{D + \\mathrm{PDiv}(X) = \\{ D + (f): f \\in M(X) \\backslash \\{0\\}\\}}")#text(" of the principal divisors in ")#mi("{\\mathrm{Div}(X)}")#text(" (that is to say, an equivalence class for linear equivalence), then we conclude that the dimension ")#mi("{\\mathrm{dim}(L(D))}")#text(" depends only on the divisor class ")#mi("{D + \\mathrm{PDiv}(X)}")#text(" of ")#mi("{D}")#text(". The space ")#mi("{\\mathrm{Div}(X)/\\mathrm{PDiv}(X)}")#text(" of divisor classes is an abelian group, which is known as the ")#emph[#text("divisor class group")]#text(". (For nonsingular algebraic curves, this group also coincides with the ")#link("https://en.wikipedia.org/wiki/Picard_group")[#text("Picard group")]#text(", though the situation is more subtle if one allows singularities.)")#linebreak()#text(" It is now easy to understand the spaces ")#mi("{L(D)}")#text(" for the Riemann sphere:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Show that two divisors on the Riemann sphere are equivalent if and only if they have the same degree, so that the degree map gives an isomorphism between the divisor class group of the Riemann sphere and the integers. If ")#mi("{D}")#text(" is a divisor on the Riemann sphere, show that ")#mi("{\\mathrm{dim}(L(D))}")#text(" is equal to ")#mi("{\\max( 0, \\mathrm{deg}(D) + 1 )}")#text(". (Hint: first show that for any integer ")#mi("{m}")#text(", that ")#mi("{L(m \\cdot (\\infty))}")#text(" is the space of polynomials of degree at most ")#mi("{m}")#text(".)")
]

#text("From the above exercise we observe in particular that")#linebreak()#text(" ")#metadata(none) <tao-0f58b78bc54e0c3e5556>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathrm{dim}(L(D)) - \\mathrm{dim}(L(K-D)) = \\mathrm{deg}(D) + 1,")]]

#text(" whenever ")#mi("{K}")#text(" has degree ")#mi("{-2}")#text("; as we will see later, this is a special case of the Riemann-Roch theorem.")

#heading(level: 1)[#strong[#text(" — 2. Meromorphic ")#mi("{1}")#text("-forms — ")]]

#text("To proceed further, we will introduce the concept of a ")#emph[#text("meromorphic ")#mi("{1}")#text("-form")]#text(" on a compact Riemann surface ")#mi("{X}")#text(". To motivate this concept, observe that one can think of a meromorphic function ")#mi("{f \\in M(X)}")#text(" on ")#mi("{X}")#text(" as a collection of meromorphic functions ")#mi("{f_\\alpha := f \\circ \\phi_\\alpha^{-1}: \\phi_\\alpha(U_\\alpha) \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" on open subsets of the complex plane, where ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" ranges over a suitable atlas of ")#mi("{X}")#text(". These meromorphic functions ")#mi("{f_\\alpha}")#text(" are compatible with each other in the following sense: if ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" and ")#mi("{\\phi_\\beta: U_\\beta \\rightarrow {\\bf C}}")#text(" are charts, then we have ")#metadata(none) <tao-8252aa52eaa25942e776>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f_\\beta(z_\\beta) = f_\\alpha( \\phi_\\alpha \\circ \\phi_\\beta^{-1}(z_\\beta) )")]]

#text(" for all ")#mi("{z_\\beta \\in \\phi_\\beta(U_\\alpha \\cap U_\\beta)}")#text(" (this condition is vacuous if ")#mi("{U_\\alpha, U_\\beta}")#text(" do not overlap). As already noted, one can define such concepts as the order of ")#mi("{f}")#text(" at a pole ")#mi("{P}")#text(" by declaring it to be the order of ")#mi("{f_\\alpha}")#text(" at ")#mi("{\\phi_\\alpha(P)}")#text(" for any chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" that contains ")#mi("{P}")#text(" in its domain, and the compatibility condition ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(" ensures that this definition is well defined.")#linebreak()#text(" On the other hand, several other basic notions in complex analysis do not seem to be well defined for such meromorphic functions. Consider for instance the question of how to define the residue of ")#mi("{f}")#text(" at a pole ")#mi("{P}")#text(". The natural thing to do is to again pick a chart ")#mi("{\\phi_\\alpha}")#text(" around ")#mi("{P}")#text(" and use the residue of ")#mi("{f_\\alpha}")#text("; however one can check that this is ")#emph[#text("not")]#text(" independent of the choice of chart in general, as from ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(" one will find that the residues of ")#mi("{f_\\beta}")#text(" and ")#mi("{f_\\alpha}")#text(" are related to each other, but not equal. Similarly, one encounters a difficulty integrating ")#mi("{f}")#text(" on a contour ")#mi("{\\gamma}")#text(" in ")#mi("{X}")#text(", even if the contour is short enough to fit into the domain ")#mi("{U_\\alpha}")#text(" of a single chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" and also avoids all the poles of ")#mi("{f}")#text("; the natural thing to do is to compute ")#mi("{\\int_{\\phi_\\alpha \\circ \\gamma} f_\\alpha(z)\\ dz}")#text(", but again this will depend on the choice of chart (substituting ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(" will reveal that ")#mi("{\\int_{\\phi_\\beta \\circ \\gamma} f_\\beta(z)\\ dz}")#text(" is not equal to ")#mi("{\\int_{\\phi_\\alpha \\circ \\gamma} f_\\alpha(z)\\ dz}")#text(" in general due to an additional Jacobian factor). Finally, one encounters a difficulty trying to differentiate a meromorphic function ")#mi("{f \\in M(X)}")#text("; on each chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" one would like to just differentiate ")#mi("{f_\\alpha}")#text(", but the resulting derivatives ")#mi("{(f_\\alpha)^{\\prime}}")#text(" do not obey the compatibility condition ")#link(<tao-8252aa52eaa25942e776>)[#text("(4)")]#text(", but instead (by the chain rule) obey the slightly different condition")

#align(center)[#tao-fit-display[#mitex("(f_\\beta)^{\\prime}(z_\\beta) = (f_\\alpha)^{\\prime}( \\phi_\\alpha \\circ \\phi_\\beta^{-1}(z_\\beta) ) (\\phi_\\alpha \\circ \\phi_\\beta^{-1})^{\\prime}(z_\\beta).")]]

#text("The solution to all of these issues is to introduce a new type of object on ")#mi("{X}")#text(", the ")#emph[#text("meromorphic ")#mi("{1}")#text("-forms")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 22")]#text(" A ")#emph[#text("meromorphic ")#mi("{1}")#text("-form")]#text(" ")#mi("{\\omega}")#text(" on ")#mi("{X}")#text(" is a collection of expressions ")#mi("{\\omega_\\alpha(z_\\alpha)\\ dz_\\alpha}")#text(" for each coordinate chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" of ")#mi("{X}")#text(", with ")#mi("{\\omega_\\alpha}")#text(" meromorphic on ")#mi("{\\phi_\\alpha(U_\\alpha)}")#text(", which obey the compatibility condition ")#metadata(none) <tao-cbd31fe312a05a4718b4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\omega_\\beta(z_\\beta) = \\omega_\\alpha( \\phi_\\alpha \\circ \\phi_\\beta^{-1}(z_\\beta) ) (\\phi_\\alpha \\circ \\phi^{-1}_\\beta)^{\\prime}(z_\\beta)")]]

#text(" for any pair ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(", ")#mi("{\\psi_\\beta: U_\\beta \\rightarrow {\\bf C}}")#text(" of charts and any ")#mi("{z_\\beta \\in \\phi_\\beta(U_\\alpha \\cap U_\\beta)}")#text(". If all the ")#mi("{\\omega_\\phi}")#text(" are holomorphic, we say that ")#mi("{\\omega}")#text(" is holomorphic also. The space of meromorphic ")#mi("{1}")#text("-forms will be denoted ")#mi("{M\\Omega^1(X)}")#text(".")#linebreak()#text(" As with meromorphic functions, we can define the order ")#mi("{\\mathrm{ord}_P(\\omega)}")#text(" of ")#mi("{\\omega}")#text(" at a point ")#mi("{P \\in X}")#text(" to be the order of ")#mi("{\\omega_\\phi}")#text(" at ")#mi("{\\phi(P)}")#text(" for some chart ")#mi("{\\phi}")#text(" that contains ")#mi("{P}")#text(" in its domain; from ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" we see that this is well defined. Similarly we may define the divisor ")#mi("{(\\omega)}")#text(" of ")#mi("{\\omega}")#text(". The divisor of a non-zero meromorphic ")#mi("{1}")#text("-form is called a ")#link("https://en.wikipedia.org/wiki/Canonical_bundle")[#text("canonical divisor")]#text(". (We will show later that at least one non-zero meromorphic ")#mi("{1}")#text("-form is available, so that canonical divisors exist.)")#linebreak()#text(" Let ")#mi("{\\omega}")#text(" be a meromorphic ")#mi("{1}")#text("-form. Given a contour ")#mi("{\\gamma: [a,b] \\rightarrow X}")#text(" that lies in the domain ")#mi("{U}")#text(" of a single chart ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" and avoids the poles of ")#mi("{\\omega}")#text(", we can define the integral ")#mi("{\\int_\\gamma \\omega}")#text(" to be equal to ")#mi("{\\int_{\\phi \\circ \\gamma} \\omega_\\phi(z)\\ dz}")#text(". One checks from ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" and the change of variables formula that this definition is independent of the choice of chart. One then defines ")#mi("{\\int_\\gamma \\omega}")#text(" for longer contours by partitioning into short contours; again, one can check that this definition is independent of the choice of partition.")#linebreak()#text(" The residue of ")#mi("{\\omega}")#text(" at ")#mi("{P}")#text(" can be defined as the residue of ")#mi("{\\omega_\\phi}")#text(" at ")#mi("{\\phi(P)}")#text(" for a chart ")#mi("{\\phi}")#text(" that contains ")#mi("{P}")#text(" in its domain, or equivalently (by the residue theorem) ")#mi("{\\frac{1}{2\\pi i} \\int_\\gamma \\omega}")#text(" where ")#mi("{\\gamma}")#text(" is a sufficiently small contour winding around ")#mi("{P}")#text(" once anticlockwise (note that we have a consistent orientation on ")#mi("{X}")#text(" since invertible holomorphic maps are orientation preserving).")
]

#text("Meromorphic ")#mi("{1}")#text("-forms are also known as ")#emph[#text("Abelian differentials")]#text(", while holomorphic ")#mi("{1}")#text("-forms are ")#link("https://en.wikipedia.org/wiki/Differential_of_the_first_kind")[#text("Abelian differentials of the first kind")]#text(". (Abelian differentials of the second kind are meromorphic ")#mi("{1}")#text("-forms in which all residues vanish, while Abelian differentials of the third kind are meromorphic ")#mi("{1}")#text("-forms in which all poles are simple.) To specify a meromorphic form ")#mi("{\\omega}")#text(", it suffices to prescribe ")#mi("{\\omega_\\phi}")#text(" for all ")#mi("{\\phi}")#text(" in a single atlas of ")#mi("{X}")#text("; as long as ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" is obeyed within this atlas, it is easy to see that ")#mi("{\\omega_\\psi}")#text(" can then be defined uniquely using ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" for all other coordinate charts.")#linebreak()#text(" Formally speaking, one can “derive” the condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" by applying the change of variables ")#mi("{z_\\alpha = \\phi_\\alpha \\circ \\phi_\\beta^{-1}(z_\\beta)}")#text(" to ")#mi("{\\omega_\\alpha(z_\\alpha) dz_\\alpha}")#text(" to obtain ")#mi("{\\omega_\\beta(z_\\beta) dz_\\beta}")#text(". But we will take ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" as a ")#emph[#text("definition")]#text(" of a ")#mi("{1}")#text("-form, rather than deriving it from any other concept.")#linebreak()#text(" There are two basic ways to create meromorphic ")#mi("{1}")#text("-forms. One is to start with a meromorphic function ")#mi("{f \\in M(X)}")#text(" and form its ")#link("https://en.wikipedia.org/wiki/Pushforward_(differential)")[#text("differential")]#text(" ")#mi("{df}")#text(", which when evaluated any chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" of ")#mi("{X}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#mitex("(df)_\\alpha\\ dz_\\alpha := (f \\circ \\phi_\\alpha^{-1})^{\\prime}(z_\\alpha)\\ dz_\\alpha;")]]

#text("the compatibility condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" is then clear from the chain rule. Another way is to start with an existing meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(" and multiply it by a meromorphic function ")#mi("{f}")#text(" to give a new meromorphic ")#mi("{1}")#text("-form ")#mi("{f \\omega}")#text(", which when evaluated at a given chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" of ")#mi("{X}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("(f\\omega)_\\alpha\\ dz_\\alpha := (f \\circ \\phi_\\alpha^{-1})(z_\\alpha) \\omega_\\alpha(z_\\alpha)\\ dz_\\alpha;")]]

#text("again, it is clear that the compatibility condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(" holds. Conversely, given two meromorphic ")#mi("{1}")#text("-forms ")#mi("{\\omega_1, \\omega_2}")#text(", with ")#mi("{\\omega_2}")#text(" not identically zero, one can form the ratio ")#mi("{\\omega_1/\\omega_2}")#text(" to be the unique meromorphic function ")#mi("{f}")#text(" such that ")#mi("{\\omega_1 = f \\omega_2}")#text("; it is easy to see that ")#mi("{f}")#text(" exists and is unique. These properties are compatible with taking divisors, thus ")#mi("{(f\\omega) = (f) + (\\omega)}")#text(" and ")#mi("{(\\omega_1/\\omega_2) = (\\omega_1) - (\\omega_2)}")#text(".")#linebreak()#text(" Of course, one can also add two meromorphic ")#mi("{1}")#text("-forms to obtain another meromorphic ")#mi("{1}")#text("-form. Thus ")#mi("{M\\Omega^1(X)}")#text(" is in fact a one-dimensional vector space over the field ")#mi("{M(X)}")#text(" (here we assume that non-zero meromorphic ")#mi("{1}")#text("-forms exist, a claim which we will return to later). In particular, the canonical divisor is unique up to linear equivalence.")#linebreak()#text(" Later on we will discuss a further way to create a meromorphic ")#mi("{1}")#text("-form, by taking the gradient of a harmonic function with specific types of singularities.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 23")]#text(" ")#metadata(none) <tao-1162e527383742bf0314>#text(" The coordinate function ")#mi("{z}")#text(" can be viewed as a meromorphic function on the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" (it has a simple zero at ")#mi("{0}")#text(" and a simple pole at ")#mi("{\\infty}")#text("). Its derivative ")#mi("{dz}")#text(" then has a double pole at infinity (note that in the reciprocal coordinate ")#mi("{w = 1/z}")#text(", ")#mi("{dz}")#text(" transforms to ")#mi("{-\\frac{1}{w^2} dw}")#text("), so ")#mi("{(dz) = - 2 \\cdot (\\infty)}")#text(". Any other meromorphic ")#mi("{1}")#text("-form is of the form ")#mi("{f(z) dz}")#text(", where ")#mi("{f}")#text(" is a meromorphic function (that is to say, a rational function). In particular, since meromorphic functions have divisor of degree ")#mi("{0}")#text(", all meromorphic ")#mi("{1}")#text("-forms on the Riemann sphere have a divisor of degree ")#mi("{-2}")#text("; indeed, the canonical divisors here are precisely the divisors of degree ")#mi("{-2}")#text(".")
]

#text("We now give a key application of meromorphic ")#mi("{1}")#text("-forms to the divisors of meromorphic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24")]#text(" ")#metadata(none) <tao-cd35a2426062b7d58fd4>#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface.")

#list(
[#text("(i) For any meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(", the sum of all the residues of ")#mi("{\\omega}")#text(" vanishes.")],
[#text("(ii) Every principal divisor ")#mi("{(f)}")#text(" has degree zero.")]
)
]

#emph[#text("Proof:")]#text(" We begin with (i). By evaluating at coordinate charts, the counterclockwise integral of ")#mi("{\\omega}")#text(" around any small loop ")#mi("{\\gamma}")#text(" that avoids any pole is zero; thus ")#mi("{\\omega}")#text(" is closed outside of these poles, and hence by Stokes’ theorem we conclude that the integral of ")#mi("{\\omega}")#text(" around the sum of small counterclockwise loops around every pole is zero. On the other hand, by the residue theorem applied in each chart, this integral is equal to ")#mi("{2\\pi i}")#text(" times the sum of the residues, and the claim follows.")#linebreak()#text(" To prove (ii), apply (i) to the meromorphic ")#mi("{1}")#text("-form ")#mi("{df/f}")#text(" (cf. the usual proof of the argument principle). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-5d61caeedf54c4df7064>#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface, and let ")#mi("{D}")#text(" be a divisor on ")#mi("{X}")#text(".")

#list(
[#text("(i) If ")#mi("{\\mathrm{deg}(D) < 0}")#text(", show that ")#mi("{\\mathrm{dim}(L(D)) = 0}")#text(".")],
[#text("(ii) If ")#mi("{\\mathrm{deg}(D) = 0}")#text(", show that ")#mi("{\\mathrm{dim}(L(D))}")#text(" is equal to ")#mi("{0}")#text(" or ")#mi("{1}")#text(", with the latter occurring if and only if ")#mi("{D}")#text(" is principal. Furthermore, any non-zero element of ")#mi("{L(D)}")#text(" has divisor ")#mi("{-D}")#text(".")],
[#text("(iii) If ")#mi("{\\mathrm{deg}(D) \\geq 0}")#text(", establish the bound ")#mi("{\\mathrm{dim}(L(D)) \\leq \\mathrm{deg}(D) + 1}")#text(".")]
)
]

#text("We have already discussed how algebraic curves ")#mi("{Z(P)}")#text(" give good examples of Riemann surfaces. In the converse direction, it is common for Riemann surfaces to map into algebraic curves, as hinted by the following exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface, and let ")#mi("{f, g}")#text(" be two non-constant meromorphic functions on ")#mi("{X}")#text(". Show that there exists a non-zero polynomial ")#mi("{P(z_1,z_2)}")#text(" of two variables with complex coefficients such that ")#mi("{P(f,g)=0}")#text(". (")#emph[#text("Hint:")]#text(" look at the monomials ")#mi("{f^i g^j}")#text(" for ")#mi("{i,j \\leq N}")#text(" for some large ")#mi("{N}")#text(", and show that they lie in ")#mi("{L(D_N)}")#text(" for a suitable divisor ")#mi("{D_N}")#text(". Then use part (iii) of the previous exercise and linear algebra.) Show furthermore that one can take ")#mi("{P}")#text(" to be irreducible. (This type of argument ultimately leads to ")#link("https://en.wikipedia.org/wiki/Algebraic_geometry_and_analytic_geometry#Chow's_theorem")[#text("Chow’s theorem")]#text(" that projective complex manifolds are necessarily algebraic.)")
]

#heading(level: 1)[#strong[#text(" — 3. The case of a complex torus — ")]]

#text("For the special case when the Riemann surface being studied is a complex torus ")#mi("{{\\bf C}/\\Lambda}")#text(", one can obtain more precise information on the dimensions ")#mi("{\\mathrm{dim}(L(D))}")#text(" by explicit computations. First observe we have a natural holomorphic ")#mi("{1}")#text("-form on ")#mi("{{\\bf C}/\\Lambda}")#text(", namely the form ")#mi("{dz}")#text(", defined in any small coordinate chart ")#mi("{\\phi: U \\text{ mod } \\Lambda \\rightarrow U}")#text(" on a small disk ")#mi("{U}")#text(" in ")#mi("{{\\bf C}}")#text(" (with ")#mi("{\\phi(z+\\Lambda) = z}")#text(") by ")#mi("{(dz)_\\phi = dz}")#text(", and then defined for any other coordinate chart by compatibility. This form has no poles and zeroes, and so ")#mi("{0}")#text(" is a canonical divisor. Using this ")#mi("{1}")#text("-form, we have a bijection between meromorphic functions and meromorphic ")#mi("{1}")#text("-forms on ")#mi("{{\\bf C}/\\Lambda}")#text(" which maps ")#mi("{f(z)}")#text(" to ")#mi("{f(z)\\ dz}")#text("; in contrast to the situation with other Riemann surfaces with non-zero canonical divisor, this bijection does not affect the divisor. In particular, canonical divisors are principal and vice versa. Using this bijection, we can think of the differential ")#mi("{df}")#text(" of a meromorphic function as another meromorphic function, which we call the derivative ")#mi("{f^{\\prime}}")#text(", as per the familiar formula ")#mi("{f^{\\prime} = df / dz}")#text(". Of course, with respect to the above coordinate charts, this derivative corresponds to the usual complex derivative.")#linebreak()#text(" We also have a fundamental meromorphic function on ")#mi("{{\\bf C}/\\Lambda}")#text(", or equivalently a ")#mi("{\\Lambda}")#text("-periodic function on ")#mi("{{\\bf C}}")#text(", namely the ")#link("https://en.wikipedia.org/wiki/Weierstrass%27s_elliptic_functions")[#text("Weierstrass ")#mi("{p}")#text("-function")]#text(" ")#metadata(none) <tao-b545ddf5b84555a4dd95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\wp(z) := \\frac{1}{z^2} + \\sum_{w \\in \\Lambda \\backslash\\{0\\}} (\\frac{1}{(z-w)^2} - \\frac{1}{w^2}).")]]

#text(" It is easy to see that the sum converges outside of ")#mi("{\\Lambda}")#text(", and that this is a meromorphic ")#mi("{\\Lambda}")#text("-periodic function on ")#mi("{{\\bf C}}")#text(" that has a double pole at every point in ")#mi("{\\Lambda}")#text("; this descends to a meromorphic function on ")#mi("{{\\bf C}/\\Lambda}")#text(" with divisor at least ")#mi("{-2 \\cdot (0 + \\Lambda)}")#text(". By translation we can then create a meromorphic function ")#mi("{\\wp_P}")#text(" with divisor at least ")#mi("{-2 \\cdot (P)}")#text(" for any ")#mi("{{\\bf C}/\\Lambda}")#text(".")#linebreak()#text(" Using this function and some manipulations, we can compute ")#mi("{\\mathrm{dim}(L(D))}")#text(" for most divisors ")#mi("{D}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 27")]#text(" ")#metadata(none) <tao-ac0b52a2ae6ef99999bc>#text(" Let ")#mi("{{\\bf C}/\\Lambda}")#text(" be a complex torus, and let ")#mi("{D}")#text(" be a divisor.")

#list(
[#text("(i) If ")#mi("{\\mathrm{deg}(D) < 0}")#text(", then ")#mi("{\\mathrm{dim}(L(D)) = 0}")#text(".")],
[#text("(ii) If ")#mi("{\\mathrm{deg}(D) = 0}")#text(", then ")#mi("{\\mathrm{dim}(L(D))}")#text(" is equal to ")#mi("{0}")#text(" or ")#mi("{1}")#text(". If ")#mi("{D = (P)-(Q)}")#text(" for some distinct ")#mi("{P,Q \\in {\\bf C}/\\Lambda}")#text(", then ")#mi("{\\mathrm{dim}(L(D)) = 0}")#text(". Also, ")#mi("{\\mathrm{dim}(L(D)) = \\mathrm{dim}(L(-D))}")#text(".")],
[#text("(iii) If ")#mi("{\\mathrm{deg}(D) > 0}")#text(", then ")#mi("{\\mathrm{dim}(L(D)) = \\mathrm{deg}(D)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Part (i) and the first claim of part (ii) follows from Exercise ")#link(<tao-5d61caeedf54c4df7064>)[#text("25")]#text(". To prove the second claim of part (ii), it suffices by Exercise ")#link(<tao-5d61caeedf54c4df7064>)[#text("25")]#text(" to show that there is no meromorphic function with divisor ")#mi("{(P)-(Q)}")#text(", that is to say a simple pole at ")#mi("{Q}")#text(" and a simple zero at ")#mi("{P}")#text(". But this follows from Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(i) (and identifying meromorphic functions with meromorphic ")#mi("{1}")#text("-forms) since the residue at ")#mi("{Q}")#text(" is non-zero and there is no other residue to cancel it. The third claim comes from Exercise ")#link(<tao-5d61caeedf54c4df7064>)[#text("25")]#text(" and the observation that ")#mi("{D}")#text(" is principal if and only if ")#mi("{-D}")#text(" is.")#linebreak()#text(" Call a divisor ")#mi("{D}")#text(" ")#emph[#text("good")]#text(" if ")#mi("{\\mathrm{dim}(L(D)) = \\mathrm{deg}(D)}")#text(". We need to show that all divisors of positive degree are good. First we check that ")#mi("{(P)}")#text(" is good for a point ")#mi("{P}")#text(". By Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(i) we see that the only meromorphic functions in ")#mi("{L((P))}")#text(" are constant, hence ")#mi("{\\mathrm{dim}(L((P))) = 1}")#text(", and so ")#mi("{(P)}")#text(" is good.")#linebreak()#text(" The Weierstrass ")#mi("{p}")#text("-function ")#mi("{\\wp_P}")#text(" at ")#mi("{P}")#text(" gives a an element of ")#mi("{L(2 \\cdot (P))}")#text(" which is non-constant (it has a double pole at ")#mi("{P}")#text("), so by Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" we have ")#mi("{\\mathrm{dim}(L(2 \\cdot (P))) = 2}")#text(", and so ")#mi("{2 \\cdot (P)}")#text(" is good. Taking a derivative of ")#mi("{\\wp_P}")#text(" to obtain a meromorphic function with a triple pole at ")#mi("{P}")#text(", we obtain a further element of ")#mi("{L(3 \\cdot (P))}")#text(" that is not in ")#mi("{L(2 \\cdot (P))}")#text(", and so ")#mi("{\\mathrm{dim}(L(3 \\cdot (P))) = 3}")#text(", and so ")#mi("{3 \\cdot (P)}")#text(" is good. Continuing to differentiate in this fashion we see that ")#mi("{k \\cdot (P)}")#text(" is good for any natural number ")#mi("{k}")#text(".")#linebreak()#text(" Next, for any distinct pairs of points ")#mi("{P, Q}")#text(", we write ")#mi("{Q = P + \\zeta}")#text(" for some complex number ")#mi("{\\zeta}")#text(", and define the meromorphic function")

#align(center)[#tao-fit-display[#mitex("\\wp_{P \\rightarrow Q}(z) := \\int_\\gamma \\wp_{P+w}(z)\\ dw")]]

#text("where ")#mi("{\\gamma}")#text(" is some contour from ")#mi("{0}")#text(" to ")#mi("{\\zeta}")#text(". (As ")#mi("{w \\mapsto \\wp_{P+w}(z)}")#text(" locally has an antiderivative at every point, this definition does not depend on the choice of ")#mi("{\\gamma}")#text(", though it is a little sensitive to the choice of ")#mi("{\\zeta}")#text(".) One can check that this function is meromorphic with simple poles at ")#mi("{P}")#text(" and ")#mi("{Q}")#text(", which shows that ")#mi("{\\mathrm{dim}(L((P)+(Q))) \\geq 2}")#text(". From Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" and the fact that ")#mi("{(P)}")#text(" is good, we conclude that ")#mi("{(P)+(Q)}")#text(" is good.")#linebreak()#text(" Observe from Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" and Lemma ")#link(<tao-f804ff2fd8efd8445b74>)[#text("20")]#text(" we see that if ")#mi("{D}")#text(" is a divisor and ")#mi("{P,Q}")#text(" are distinct points such that ")#mi("{D, D+(P), D+(Q)}")#text(" are good, then ")#mi("{D+(P)+(Q)}")#text(" is also good. We have just shown that all effective divisors of degree ")#mi("{1}")#text(" and ")#mi("{2}")#text(" are good; by induction one can now show that all effective divisors of positive degree are good.")#linebreak()#text(" Call a degree one divisor ")#mi("{D}")#text(" ")#emph[#text("very good")]#text(" if ")#mi("{D+D^{\\prime}}")#text(" is good for every ")#mi("{D^{\\prime} \\geq 0}")#text(". We have shown that ")#mi("{(P)}")#text(" is very good for all ")#mi("{P}")#text(". We now claim that if ")#mi("{D}")#text(" is very good then so is ")#mi("{\\tilde D := D + (P) - (Q)}")#text(" is very good. First note that ")#mi("{\\tilde D - (P)}")#text(" and ")#mi("{\\tilde D - (Q)}")#text(" cannot both be principal, since their difference ")#mi("{(P)-(Q)}")#text(" is not principal. Thus by Exercise ")#link(<tao-5d61caeedf54c4df7064>)[#text("25")]#text(", at least one of ")#mi("{\\mathrm{dim}(L(\\tilde D-(P))}")#text(" or ")#mi("{\\mathrm{dim}(L(\\tilde D- (Q))}")#text(" vanishes, and hence ")#mi("{\\mathrm{dim}(L(\\tilde D)) \\leq 1}")#text(" by Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(". On the other hand, as ")#mi("{D}")#text(" is very good, ")#mi("{\\tilde D+(Q) = D+(P)}")#text(" is good, and so ")#mi("{\\mathrm{dim}(L(\\tilde D + (Q))) = 2}")#text(". By Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" we conclude that ")#mi("{\\tilde D}")#text(" is good.")#linebreak()#text(" For any ")#mi("{R}")#text(", we know that ")#mi("{\\tilde D}")#text(" and ")#mi("{\\tilde D + (Q) + (R) = D + (P) + (R)}")#text(" are good, hence by Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" the intermediate divisor ")#mi("{\\tilde D + (R)}")#text(" must also be good. Iterating this argument we see that ")#mi("{\\tilde D +D^{\\prime}}")#text(" is good for every ")#mi("{D^{\\prime} \\geq 0}")#text(", thus ")#mi("{\\tilde D^{\\prime}}")#text(" is very good. Iterating this we see that all degree one divisors are very good, giving (iii). ")#mi("\\Box")#linebreak()#text(" An alternate way to show that ")#mi("{(P)+(Q)}")#text(" is good was shown to me by Redmond McNamara as follows. By subtracting a constant from ")#mi("{\\wp_P}")#text(" one can find a meromorphic function ")#mi("{f}")#text(" with a double pole at ")#mi("{P}")#text(" and at least a single zero at ")#mi("{Q}")#text(". If it is exactly a single zero, multiplying by ")#mi("{\\wp_Q}")#text(" will create a function with precisely a simple pole at ")#mi("{Q}")#text(" and at most a double pole at ")#mi("{P}")#text("; subtracting a multiple of ")#mi("{\\wp_P}")#text(" if necessary will then give the required non-trivial element of ")#mi("{L((P)+(Q))}")#text(". If ")#mi("{f}")#text(" has a double zero at ")#mi("{Q}")#text(" instead, multiply ")#mi("{f^{\\prime}}")#text(" by ")#mi("{\\wp_Q}")#text(" and subtract multiples of ")#mi("{\\wp_P}")#text(" and ")#mi("{\\wp^{\\prime}_P}")#text(" to obtain the same result. Note that ")#mi("{f}")#text(" cannot have more than a double zero because of Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(ii).")#linebreak()#text(" As a corollary of the above proposition we obtain the complex torus case of the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Roch_theorem")[#text("Riemann-Roch theorem")]#text(": ")#metadata(none) <tao-c871dc1dcab70d1af97e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\mathrm{dim}(L(D)) - \\mathrm{dim}(L(-D)) = \\mathrm{deg}(D),")]]

#text(" valid for any divisor ")#mi("{D}")#text(" (regardless of degree); compare with ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("(3)")]#text(". The one remaining point is to work out which degree zero divisors are principal. It turns out that there is an additional constraint beyond degree zero:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Suppose that ")#mi("{(P_1)+\\dots+(P_n)-(Q_1)-\\dots-(Q_n)}")#text(" is a principal divisor on a complex torus ")#mi("{{\\bf C}/\\Lambda}")#text(" (we allow repetition). Show that ")#mi("{P_1+\\dots+P_n-Q_1-\\dots-Q_n=0}")#text(" using the group law on ")#mi("{{\\bf C}/\\Lambda}")#text(". (")#emph[#text("Hint:")]#text(" if ")#mi("{f}")#text(" is a meromorphic function with zeroes at ")#mi("{P_1,\\dots,P_n}")#text(" and poles at ")#mi("{Q_1,\\dots,Q_n}")#text(", integrate ")#mi("{z \\frac{f^{\\prime}(z)}{f(z)}}")#text(" around a parallelogram fundamental domain of ")#mi("{{\\bf C}/\\Lambda}")#text(" (translating if necessary so that the boundary of the parallelogram avoids the zeroes and poles).)")
]

#text("In fact, this is the only condition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 29")]#text(" A degree zero divisor ")#mi("{(P_1)+\\dots+(P_n)-(Q_1)-\\dots-(Q_n)}")#text(" is principal if and only if ")#mi("{P_1+\\dots+P_n-Q_1-\\dots-Q_n=0}")#text(".")
]

#emph[#text("Proof:")]#text(" By the above exercise it suffices to establish the “if” direction. We may of course assume ")#mi("{n \\geq 1}")#text(". By Lemma ")#link(<tao-ac0b52a2ae6ef99999bc>)[#text("27")]#text(", the space ")#mi("{L( (P_1) + \\dots + (P_n) - (Q_1) - \\dots - (Q_{n-1}) )}")#text(" is one-dimensional, thus there exists a non-zero meromorphic function ")#mi("{f}")#text(" with poles at ")#mi("{P_1,\\dots,P_n}")#text(", zeroes at ")#mi("{Q_1,\\dots,Q_{n-1}}")#text(", and no further poles (counting multiplicity). By Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(ii) ")#mi("{f}")#text(" must have one further zero, and by the above exercise this zero must be ")#mi("{Q_n}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" One can explicitly write down a formula for these meromorphic functions using ")#link("https://en.wikipedia.org/wiki/Theta_function")[#text("theta functions")]#text(", but we will not do so here.")#linebreak()#text(" The above proposition links the group law on a complex torus with the group law on divisors. This is part of a more general relation involving the ")#link("https://en.wikipedia.org/wiki/Jacobian_variety")[#text("Jacobian variety")]#text(" of a curve and the ")#link("https://en.wikipedia.org/wiki/Abel%E2%80%93Jacobi_map")[#text("Abel-Jacobi theorem")]#text(", but we will not discuss this further in this course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Let ")#mi("{{\\bf C}/\\Lambda}")#text(" be a complex torus. Show that the Weierstrass function ")#mi("{\\wp}")#text(" obeys the differential equation")

#align(center)[#tao-fit-display[#mitex("\\wp^{\\prime}(z)^2 = 4\\wp(z)^3 - g_2 \\wp(z) - g_3")]]

#text("for some complex numbers ")#mi("{g_2,g_3}")#text(" depending on ")#mi("{\\Lambda}")#text(". Also show that the map ")#mi("{z \\mapsto [\\wp(z), \\wp^{\\prime}(z),1]}")#text(" for ")#mi("{z \\in {\\bf C} /\\Lambda \\backslash \\{0+\\Lambda\\}}")#text(" (with ")#mi("{0+\\Lambda}")#text(" mapping to ")#mi("{[0,1,0]}")#text(") is a holomorphic invertible map from ")#mi("{{\\bf C}/\\Lambda}")#text(" to the algebraic curve")

#align(center)[#tao-fit-display[#mitex("\\{ [z_1,z_2,z_3]: z_2^2 z_3 = 4 z_1^3 - g_2 z_1 z_3^2 - g_3 z_3^3 \\}")]]

#text("which is non-singular and irreducible. (Thus, every complex torus is isomorphic to an elliptic curve. The converse is also true, but will not be established here.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Let ")#mi("{{\\bf C}/\\Lambda}")#text(" be a complex torus, and let ")#mi("{f: {\\bf C}/\\Lambda \\rightarrow {\\bf C}/\\Lambda}")#text(" be a function. Show that ")#mi("{f}")#text(" is holomorphic if and only if it takes the form")

#align(center)[#tao-fit-display[#mitex("f( z + \\Lambda ) = \\alpha z + z_0 + \\Lambda")]]

#text("for all ")#mi("{z \\in {\\bf C}}")#text(", and some complex numbers ")#mi("{\\alpha,z_0}")#text(", with ")#mi("{\\alpha}")#text(" lying in the set ")#mi("{\\Gamma := \\{ \\alpha \\in {\\bf C}: \\alpha \\lambda \\in \\Lambda \\text{ for all } \\lambda \\in \\Lambda \\}}")#text(". Furthermore, show that ")#mi("{\\Gamma}")#text(" is either equal to the integers, or to a lattice of the form ")#mi("{\\{ n + m \\alpha_0: n,m \\in {\\bf Z} \\}}")#text(" for some quadratic algebraic integer ")#mi("{\\alpha_0}")#text(" (thus ")#mi("{\\alpha_0}")#text(" obeys an equation ")#mi("{\\alpha_0^2 + b \\alpha_0 + c = 0}")#text(" for some integers ")#mi("{b,c}")#text("). In the latter case, the complex torus is said to have ")#link("https://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. The Riemann Roch theorem — ")]]

#text("We now leave the example of the complex torus and return to more general compact Riemann surfaces ")#mi("{X}")#text(". We would like to generalise the identity ")#link(<tao-c871dc1dcab70d1af97e>)[#text("(7)")]#text(" (or ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("(3)")]#text(") to this setting. As a first step we establish")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 32 (Baby Riemann Roch theorem)")]#text(" ")#metadata(none) <tao-a3ca38ef0e8554b39ce6>#text(" Let ")#mi("{K}")#text(" be a canonical divisor in a compact Riemann surface ")#mi("{X}")#text(", and let ")#mi("{D}")#text(" be an effective divisor. Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) \\leq \\mathrm{deg}(D) + 1 - \\mathrm{dim}(L(K)).")]]
]

#emph[#text("Proof:")]#text(" Write ")#mi("{D = \\sum_{P \\in {\\mathcal P}} n_P \\cdot (P)}")#text(" where ")#mi("{P}")#text(" ranges over some finite set ")#mi("{{\\mathcal P}}")#text(" of points in ")#mi("{X}")#text(", and ")#mi("{n_P}")#text(" are positive integers. As ")#mi("{K}")#text(" is a canonical divisor, we can find a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(", not identically zero, with divisor ")#mi("{K}")#text(". If ")#mi("{h \\in L(K)}")#text(", then ")#mi("{h \\omega}")#text(" is a holomorphic ")#mi("{1}")#text("-form. The proof relies on using linear algebra to combine the following three observations that tie together ")#mi("{L(D)}")#text(", ")#mi("{L(K-D)}")#text(", and ")#mi("{L(K)}")#text(":")

#enum(start: 1, 
[#text("If ")#mi("{f \\in L(D)}")#text(" and ")#mi("{h \\in L(K)}")#text(", then ")#mi("{\\sum_{P \\in {\\mathcal P}} \\mathrm{Res}(f h \\omega, P) = 0}")#text(". This follows from Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(i) and the fact that the only possible poles of ")#mi("{f h \\omega}")#text(" are in ")#mi("{{\\mathcal P}}")#text(".")],
[#text("If ")#mi("{f \\in L(D)}")#text(" and ")#mi("{h \\in L(K-D)}")#text(", then we have the stronger assertion that ")#mi("{\\mathrm{Res}(f h \\omega, P) = 0}")#text(" for each individual ")#mi("{P \\in {\\mathcal P}}")#text(". This follows because the divisor of ")#mi("{f h \\omega}")#text(" is at least ")#mi("{-D - (K-D) + K = 0}")#text(", and so ")#mi("{f h \\omega}")#text(" has no pole at ")#mi("{P}")#text(". Furthermore this is a local statement: it holds even if ")#mi("{f}")#text(" is only defined on a small neighborhood of ")#mi("{P}")#text(", rather than on all of ")#mi("{X}")#text(". Finally, the claim is sharp: if ")#mi("{h \\not \\in L(K-D)}")#text(" then one can find ")#mi("{P \\in {\\mathcal P}}")#text(" and some ")#mi("{f}")#text(" defined locally near ")#mi("{P}")#text(" in ")#mi("{L(D)}")#text(" for which ")#mi("{\\mathrm{Res}(f h \\omega, P) \\neq 0}")],
[#text("For ")#mi("{h \\in L(K)}")#text(", ")#mi("{P \\in {\\mathcal P}}")#text(", and ")#mi("{f \\in M(X)}")#text(" is holomorphic at ")#mi("{P}")#text(", then ")#mi("{\\mathrm{Res}(f h \\omega, P) = 0}")#text(", since ")#mi("{h \\omega}")#text(" is also holomorphic at ")#mi("{P}")#text(". Again, this is a local statement, and holds even if ")#mi("{f}")#text(" is only defined in a neighbourhood of ")#mi("{P}")#text(".")]
)

#text("Let us now see how these facts combine to give the proposition. Around each ")#mi("{P}")#text(" let us form a chart ")#mi("{\\phi_P: U_P \\rightarrow {\\bf C}}")#text(" that maps ")#mi("{P}")#text(" to ")#mi("{0}")#text(". Then for any ")#mi("{f \\in L(D)}")#text(", ")#mi("{f \\circ \\phi_P^{-1}}")#text(" has a pole of order at most ")#mi("{n_P}")#text(" at the origin, and can thus be written as")

#align(center)[#tao-fit-display[#mitex("f \\circ \\phi_P^{-1}(z) = \\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j} + h_P(z)")]]

#text("for ")#mi("{z}")#text(" near ")#mi("{0}")#text(", where ")#mi("{c_{P,j}}")#text(" are complex numbers and ")#mi("{h_P(z)}")#text(" is holomorphic at the origin. We call the expression ")#mi("{\\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j}}")#text(" the ")#emph[#text("principal part")]#text(" of ")#mi("{f}")#text(" (uniformised by ")#mi("{\\phi_P}")#text(") at ")#mi("{P}")#text(". If we let ")#mi("{V}")#text(" denote the collection of tuples ")#mi("{(\\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j})_{P \\in {\\mathcal P}}}")#text(" with ")#mi("{c_{P,j}}")#text(" complex, then ")#mi("{V}")#text(" is a complex vector space of dimension ")#mi("{\\sum_{P \\in {\\mathcal P}} n_P = \\mathrm{deg}(D)}")#text(". Inside this space we have the subspace ")#mi("{W}")#text(" of tuples that can actually arise as the principal parts of a meromorphic function ")#mi("{f}")#text(" in ")#mi("{L(D)}")#text(". Observe that if two functions ")#mi("{f,g \\in L(D)}")#text(" have the same principal parts, then their difference ")#mi("{f-g}")#text(" is holomorphic and hence constant by Lemma ")#link(<tao-cdc2def9aec4576c7f9f>)[#text("11")]#text(". Thus, the space ")#mi("{W}")#text(" has dimension exactly ")#mi("{\\mathrm{dim}(L(D)) - 1}")#text(".")#linebreak()#text(" As ")#mi("{K}")#text(" is a canonical divisor, we have a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(" with divisor ")#mi("{K}")#text(". If ")#mi("{h \\in L(K)}")#text(", then ")#mi("{h \\omega}")#text(" is a holomorphic ")#mi("{1}")#text("-form. If ")#mi("{v = (\\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j})_{P \\in {\\mathcal P}}}")#text(" is a tuple in ")#mi("{V}")#text(", we can define a pairing ")#mi("{\\langle h, v \\rangle}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle h, v \\rangle := \\sum_{P \\in {\\mathcal P}} \\mathrm{Res}( ((h \\omega) \\circ \\phi_P^{-1})(z) \\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j}, 0).")]]

#text("This is a bilinear pairing from ")#mi("{L(K) \\times V}")#text(" to ")#mi("{{\\bf C}}")#text(". If ")#mi("{v \\in W}")#text(", then all the components of ")#mi("{v}")#text(" are principal parts of some ")#mi("{f \\in L(D)}")#text(", and by Observation 3 one can then write ")#mi("{\\langle h,v \\rangle}")#text(" as ")#mi("{\\sum_{P \\in {\\mathcal P}} \\mathrm{Res}(f h \\omega, P)}")#text(", which then vanishes by Observation 1. Thus ")#mi("{\\langle h,v \\rangle = 0}")#text(" whenever ")#mi("{h \\in L(K)}")#text(" and ")#mi("{v \\in W}")#text(". As row rank equals column rank, we conclude that there is a subspace ")#mi("{U}")#text(" of ")#mi("{L(K)}")#text(" of dimension at least")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K) - (\\mathrm{dim}(V) - \\mathrm{dim}(W)) = \\mathrm{dim} L(K) - \\mathrm{deg}(D) + \\mathrm{dim} L(D) - 1")]]

#text("such that ")#mi("{\\langle h, v \\rangle = 0}")#text(" whenever ")#mi("{h \\in U}")#text(" and ")#mi("{v \\in V}")#text(". But then if ")#mi("{h \\in U}")#text(", ")#mi("{h \\omega}")#text(" must vanish to order at least ")#mi("{n_P}")#text(" at each ")#mi("{P}")#text(", hence ")#mi("{(h \\omega) \\geq D}")#text(", which is equivalent to ")#mi("{(h) \\geq D-K}")#text(" and hence to ")#mi("{L(K-D)}")#text("; this is Observation 2. One concludes that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K-D) \\geq \\mathrm{dim} L(K) - \\mathrm{deg}(D) + \\mathrm{dim} L(D) - 1")]]

#text("and the claim follows by rearranging. ")#mi("\\Box")#linebreak()#text(" One can amplify this proposition if one is in possession of the following three non-trivial claims.")

#enum(start: 1, 
[#text("There is at least one non-zero meromorphic ")#mi("{1}")#text("-form; in particular, canonical divisors exist.")],
[#text("Every canonical divisor has degree ")#mi("{2g-2}")#text(", where ")#mi("{g}")#text(" is the (topological) ")#link("https://en.wikipedia.org/wiki/Genus_(mathematics)")[#text("genus")]#text(" of ")#mi("{X}")#text(".")],
[#text("The space of holomorphic ")#mi("{1}")#text("-forms has dimension ")#mi("{g}")#text(". Equivalently, for any canonical divisor ")#mi("{K}")#text(", ")#mi("{\\mathrm{dim} L(K) = g}")#text(". (In algebraic geometry language, this asserts that for compact Riemann surfaces, the topological genus is equal to the ")#link("https://en.wikipedia.org/wiki/Geometric_genus")[#text("geometric genus")]#text(".)")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 33")]#text(" The Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" has genus ")#mi("{g=0}")#text(". All meromorphic ")#mi("{1}")#text("-forms, such as ")#mi("{dz}")#text(", have degree ")#mi("{-2}")#text(" and so cannot be holomorphic, so there are no holomorphic ")#mi("{1}")#text("-forms. Meanwhile, a complex torus ")#mi("{{\\bf C}/\\Lambda}")#text(" has genus ")#mi("{1}")#text(". All meromorphic ")#mi("{1}")#text("-forms, such as ")#mi("{dz}")#text(", have degree ")#mi("{0}")#text(". In particular, a holomorphic ")#mi("{1}")#text("-form is ")#mi("{dz}")#text(" times a holomorphic function, so by Lemma ")#link(<tao-cdc2def9aec4576c7f9f>)[#text("11")]#text(" the space of holomorphic ")#mi("{1}")#text("-forms is one-dimensional.")
]

#text("Assuming these claims, the above proposition gives, for any canonical divisor ")#mi("{K}")#text(", that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) \\leq \\mathrm{deg}(D) + 1 - g")]]

#text("when ")#mi("{D}")#text(" is effective and (replacing ")#mi("{D}")#text(" by ")#mi("{K-D}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K-D) - \\mathrm{dim}L(D) \\leq (2g-2 - \\mathrm{deg}(D)) + 1 - g.")]]

#text("when ")#mi("{K-D}")#text(" is effective. Since the second right-hand side is the negative of the first, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) = \\mathrm{deg}(D) + 1 - g")]]

#text("whenever ")#mi("{D}")#text(" and ")#mi("{K-D}")#text(" are both effective. In fact we have the more general")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34 (Riemann-Roch theorem)")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface of genus ")#mi("{g}")#text(", let ")#mi("{K}")#text(" be a canonical divisor, and let ")#mi("{D}")#text(" be any divisor. Then")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) = \\mathrm{deg}(D) + 1 - g.")]]
]

#text("This of course generalises ")#link(<tao-0f58b78bc54e0c3e5556>)[#text("(3)")]#text(" on the Riemann sphere (which has genus zero) and ")#link(<tao-c871dc1dcab70d1af97e>)[#text("(7)")]#text(" on a complex torus (which has genus one).")#linebreak()#text(" It remains to establish the above three claims, and to obtain the Riemann-Roch theorem in full generality. I have not been able to locate particularly simple proofs of these steps that do not require significant machinery outside of complex analysis, so will only sketch some arguments justifying each of these.")#linebreak()#text(" To create meromorphic ")#mi("{1}")#text("-forms one can take gradients of ")#link("https://en.wikipedia.org/wiki/Harmonic_function")[#text("harmonic functions")]#text(", in the spirit of the proof of the uniformization theorem that was (mostly) given in these ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("246A lecture notes")]#text(". A function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" is said to be harmonic if, for every coordinate chart ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(", ")#mi("{f \\circ \\phi^{-1}: \\phi(U) \\rightarrow {\\bf R}}")#text(" is harmonic; as the property of being harmonic on open subsets of the complex plane is unaffected by conformal transformations, this definition does not depend on the choice of atlas that the charts are drawn from. If ")#mi("{f}")#text(" is harmonic, one can form a holomorphic ")#mi("{1}")#text("-form ")#mi("{Df}")#text(" on ")#mi("{X}")#text(" by defining")

#tao-aligned(keep: true)[


#tao-math("(Df)_\\phi(x+iy)\\ d(x+iy)  & := (\\frac{\\partial}{\\partial x} (f \\circ \\phi^{-1})(x+iy)", block: true)



#tao-math(" & - i \\frac{\\partial}{\\partial y} (f \\circ \\phi^{-1})(x+iy)) d(x+iy)", block: true)
]

#text("for each chart ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" and ")#mi("{x+iy \\in \\phi(U)}")#text(".")#linebreak()#text(" For instance, on ")#mi("{{\\bf C}}")#text(", the harmonic function ")#mi("{x^2-y^2}")#text(" gives rise to the holomorphic ")#mi("{1}")#text("-form ")#mi("{(2x + 2iy) d(x+iy) = 2z dz}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Show that this definition indeed defines a holomorphic ")#mi("{1}")#text("-form (thus the ")#mi("{(Df)_\\phi}")#text(" are all holomorphic and obey the compatibiltiy condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(". (The computations are slightly less tedious if one uses ")#link("https://en.wikipedia.org/wiki/Wirtinger_derivatives")[#text("Wirtinger derivatives")]#text(".)")
]

#text("Unfortunately, for compact Riemann surfaces ")#mi("{X}")#text(", the same maximum principle argument used to prove Lemma ")#link(<tao-cdc2def9aec4576c7f9f>)[#text("11")]#text(" shows that there are no non-constant globally harmonic functions on ")#mi("{X}")#text(", so we cannot use this construction directly to produce non-trivial holomorphic or meromorphic ")#mi("{1}")#text("-forms on ")#mi("{X}")#text(". However, one can produce harmonic functions with logarithmic singularities, a prototypical example of which is the function ")#tao-math("{\\log\\left|z\\right|}", block: false)#text(" on the Riemann sphere, which is harmonic except at ")#mi("{z=0}")#text(" and ")#mi("{z=\\infty}")#text(". More generally, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 36 (Existence of dipole Green’s function)")]#text(" Let ")#mi("{X}")#text(" be a Riemann surface, and let ")#mi("{P,Q}")#text(" be distinct points in ")#mi("{X}")#text(". Then there exists a harmonic function ")#mi("{f}")#text(" on ")#mi("{X \\backslash \\{P,Q\\}}")#text(" with the property that for any chart ")#mi("{\\phi: U \\rightarrow {\\bf C}}")#text(" that maps ")#mi("{P}")#text(" to ")#mi("{0}")#text(", ")#mi("{f \\circ \\phi^{-1}(z)}")#text(" is equal to ")#tao-math("{\\log \\left|z\\right|}", block: false)#text(" plus a bounded function near ")#mi("{0}")#text(", and for any chart ")#mi("{\\psi: V \\rightarrow {\\bf C}}")#text(" that maps ")#mi("{Q}")#text(" to ")#mi("{0}")#text(", ")#mi("{f \\circ \\psi^{-1}(z)}")#text(" is equal to ")#tao-math("{-\\log \\left|z\\right|}", block: false)#text(" plus a bounded function near ")#mi("{0}")#text(".")
]

#text("This proposition is essentially Proposition 65 of ")#link("https://terrytao.wordpress.com/2016/10/18/246a-notes-5-conformal-mapping/")[#text("these 246A notes")]#text(" and can be proven using (a somewhat technical modification of) ")#link("https://en.wikipedia.org/wiki/Perron_method")[#text("Perron’s method of subharmonic functions")]#text("; we will not do so here. One can combine this proposition with the preceding construction to obtain a non-constant meromorphic ")#mi("{1}")#text("-form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-dd7a946de80abf417970>#text(" Using the above proposition, show that if ")#mi("{X}")#text(" is a compact Riemann surface and ")#mi("{P,Q}")#text(" are distinct points in ")#mi("{X}")#text(", then there is a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega_{(P)-(Q)}}")#text(" on ")#mi("{X}")#text(" with poles only at ")#mi("{P,Q}")#text(", with a residue of ")#mi("{1}")#text(" at ")#mi("{P}")#text(" and a residue of ")#mi("{-1}")#text(" at ")#mi("{Q}")#text(".")#linebreak()#text(" Using this, conclude the ")#emph[#text("Riemann existence theorem")]#text(": for any compact Riemann surface ")#mi("{X}")#text(" and distinct points ")#mi("{P,Q}")#text(" in ")#mi("{X}")#text(", there exists a meromorphic function on ")#mi("{X}")#text(" that takes different values at ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" and is in particular non-constant. (In other words, the meromorphic functions separate points.)")
]

#text("To prove the full Riemann-Roch theorem we will also need a variant of this exercise, not proven here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 38")]#text(" ")#metadata(none) <tao-3160c321bcd0c49b6755>#text(" If ")#mi("{X}")#text(" is a compact Riemann surface, ")#mi("{P}")#text(" is a point in ")#mi("{X}")#text(", and ")#mi("{n \\geq 2}")#text(", then there exists a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega_{n \\cdot (P)}}")#text(" on ")#mi("{X}")#text(" with a pole of order ")#mi("{n}")#text(" at ")#mi("{P}")#text(" and no other poles.")
]

#text("The ")#mi("{1}")#text("-forms ")#mi("{\\omega_{n \\cdot (P)}}")#text(" constructed by this proposition can be viewed as generalisations of the Weierstrass functions ")#mi("{\\wp_P}")#text(" (and their derivatives) to other Riemann surfaces, much as the ")#mi("{1}")#text("-form ")#mi("{\\omega_{(P)-(Q)}}")#text(" constructed in Exercise ")#link(<tao-dd7a946de80abf417970>)[#text("37")]#text(" are generalisations of first integrals of these functions. (Indeed, one can think of ")#mi("{\\omega_{2 \\cdot (P)}}")#text(" as a sort of “derivative” of ")#mi("{\\omega_{(P)-(Q)}}")#text(", formed as ")#mi("{Q}")#text(" approaches ")#mi("{P}")#text(" and taking a suitable renormalised limit; more generally, one can furthermore of ")#mi("{\\omega_{(n+1) \\cdot (P)}}")#text(" as a suitably renormalised limit of ")#mi("{\\omega_{n \\cdot (P)} - \\omega_{n \\cdot (Q)}}")#text(" as ")#mi("{Q}")#text(" approaches ")#mi("{P}")#text(".) Note from Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text(" that the ")#mi("{\\omega_{n \\cdot (P)}}")#text(" constructed by the above proposition automatically have vanishing residue at ")#mi("{P}")#text(" (in classical language, these are Abelian differentials of the third kind, while the ")#mi("{\\omega_{(P)-(Q)}}")#text(" are Abelian differentials of the second kind).")#linebreak()#text(" The first claim is now settled by Exercise ")#link(<tao-dd7a946de80abf417970>)[#text("37")]#text(", so we now turn to the second. We first need some general facts about non-constant holomorphic maps ")#mi("{f: X \\rightarrow Y}")#text(" from one compact Riemann surface ")#mi("{X}")#text(" to another ")#mi("{Y}")#text(". If ")#mi("{P}")#text(" is a point in ")#mi("{X}")#text(", and ")#mi("{z = f(P)}")#text(" is its image in ")#mi("{Y}")#text(", then we define (by abuse of notation) ")#mi("{\\mathrm{ord}_P(f-z)}")#text(" to be the order of vanishing of the function ")#mi("{\\phi_\\alpha(f) - \\phi_\\alpha(z)}")#text(" for any coordinate chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" in some neighbourhood ")#mi("{U_\\alpha}")#text(" of ")#mi("{z}")#text(" in ")#mi("{Y}")#text("; it is not hard to see that this is independent of the choice of chart. Usually, this order will equal ")#mi("{1}")#text(", but there will be a finite number of places ")#mi("{P}")#text(" where it exceeds ")#mi("{1}")#text(", which we call ")#emph[#text("critical points")]#text(" or ")#emph[#text("ramification points")]#text(" (in terms of coordinate charts, this is where the derivative of ")#mi("{f}")#text(" vanishes). The values ")#mi("{z=f(P)}")#text(" are known as ")#emph[#text("critical values")]#text(" or ")#link("https://en.wikipedia.org/wiki/Branch_point")[#text("branch points")]#text(". Let ")#mi("{\\Sigma}")#text(" denote the set of all branch points; this is a finite subset of ")#mi("{Y}")#text(", and the preimage ")#mi("{f^{-1}(\\Sigma)}")#text(" is a finite subset of ")#mi("{X}")#text(".")#linebreak()#text(" If one deletes the branch points ")#mi("{\\Sigma}")#text(" from ")#mi("{Y}")#text(" and the preimage ")#mi("{f^{-1}(\\Sigma)}")#text(" from ")#mi("{X}")#text(", the resulting map can be seen to be a ")#link("https://en.wikipedia.org/wiki/Covering_space")[#text("covering map")]#text(" (this follows from Rouche’s theorem applied in local coordinate charts). In particular, since the base ")#mi("{Y \\backslash \\Sigma}")#text(" is connected, there is a natural number ")#mi("{d \\geq 1}")#text(" (the ")#link("https://en.wikipedia.org/wiki/Degree_of_a_continuous_mapping")[#text("degree")]#text(" of ")#mi("{f}")#text(") such that the map is a ")#mi("{d}")#text("-fold cover; in particular, for all ")#mi("{z \\in Y \\backslash \\Sigma}")#text(", the preimage set ")#mi("{f^{-1}(\\{z\\})}")#text(" has cardinality ")#mi("{d}")#text(". Even if ")#mi("{z}")#text(" lies in ")#mi("{\\Sigma}")#text(", by using coordinate charts near each preimage ")#mi("{P}")#text(" of ")#mi("{z}")#text(" in ")#mi("{X}")#text(" and using Rouche’s theorem, we see that we always have ")#metadata(none) <tao-1b19282db7a40e15bf3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\sum_{P \\in f^{-1}(\\{z\\})} \\mathrm{ord}_P(f-z) = d.")]]

#text(" Informally: the number of preimages of ")#mi("{z}")#text(" in ")#mi("{X}")#text(", counting multiplicity, is always equal to ")#mi("{d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Let ")#mi("{f: X \\rightarrow Y}")#text(" be a holomorphic map between a compact Riemann surface ")#mi("{X}")#text(" and a Riemann surface ")#mi("{Y}")#text(". Show that ")#mi("{f}")#text(" is either surjective or constant.")
]

#text("Next, suppose we have a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(" on ")#mi("{Y}")#text(", thus for every coordinate chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" one has a local coordinate representation ")#mi("{\\omega_\\alpha(z_\\alpha)\\ dz_\\alpha}")#text(" of ")#mi("{\\omega}")#text(" obeying the compatibility condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(". Then we can define the ")#emph[#text("pullback")]#text(" ")#mi("{f^* \\omega}")#text(" to be the meromorphic ")#mi("{1}")#text("-form on ")#mi("{X}")#text(", defined on every coordinate chart ")#mi("{\\psi_\\beta: V_\\beta \\rightarrow {\\bf C}}")#text(" of ")#mi("{X}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(f^* \\omega)_\\beta(w_\\beta)\\ dw_\\beta = \\omega_\\alpha( \\phi_\\alpha \\circ f \\circ \\psi_\\beta^{-1}(w_\\beta) ) (\\phi_\\alpha \\circ f \\circ \\psi_\\beta^{-1})^{\\prime}(w_\\beta)\\ dw_\\beta")]]

#text("for any coordinate chart ")#mi("{\\phi_\\alpha: U_\\alpha \\rightarrow {\\bf C}}")#text(" of ")#mi("{Y}")#text(" and any ")#mi("{w_\\beta \\in \\psi_\\beta( V_\\beta \\cap f^{-1}(U_\\alpha))}")#text(". One can check that this gives a well-defined ")#mi("{1}")#text("-form, as the above expression is independent of the choice of chart ")#mi("{\\phi_\\alpha}")#text(", and also obeys the compatibility condition ")#link(<tao-cbd31fe312a05a4718b4>)[#text("(5)")]#text(". An inspection of the above formula also shows that for ")#mi("{P \\in X}")#text(" and ")#mi("{z = f(P)}")#text(", the order of ")#mi("{f^* \\omega}")#text(" at ")#mi("{P}")#text(" is related to the order of ")#mi("{\\omega}")#text(" at ")#mi("{z}")#text(" by the chain rule type formula ")#metadata(none) <tao-5ab1240022676d247e9a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\mathrm{ord}_P( f^* \\omega ) = \\mathrm{ord}_z(\\omega) \\mathrm{ord}_P(f-z) + \\mathrm{ord}_P(f-z) - 1.")]]

#linebreak()#text(" Now we assert some facts from algebraic topology. To any surface ")#mi("{X}")#text(" one can assign an integer ")#mi("{\\chi(X)}")#text(" known as the ")#link("https://en.wikipedia.org/wiki/Euler_characteristic")[#text("Euler characteristic")]#text(" of ")#mi("{X}")#text("; informally, it is the constant that ")#mi("{V-E+F}")#text(" is equal to for any triangulation (or cellular complex) of ")#mi("{X}")#text(". In the case of a compact surface of genus ")#mi("{g}")#text(", this Euler characteristic is equal to ")#mi("{2-2g}")#text(". For instance, the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" has genus ")#mi("{0}")#text(" and Euler characteristic ")#mi("{2}")#text(", while a complex torus ")#mi("{{\\bf C}/\\Lambda}")#text(" has genus ")#mi("{1}")#text(" and Euler characteristic ")#mi("{0}")#text(". We now have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 40 (Riemann-Hurwitz formula)")]#text(" ")#metadata(none) <tao-19ce8b9eca7cbd01ca99>#text(" Let ")#mi("{f: X \\rightarrow Y}")#text(" be a non-constant holomorphic map between compact Riemann surfaces ")#mi("{X,Y}")#text(" of degree ")#mi("{d}")#text(", and let ")#mi("{\\Sigma \\subset Y}")#text(" be the branch points of this map. Then we have")

#align(center)[#tao-fit-display[#mitex("\\chi(X) + \\sum_{z \\in \\Sigma} \\sum_{P \\in f^{-1}(\\{z\\})} (\\mathrm{ord}_P(f-z) - 1) = d \\chi(Y).")]]

#text("Furthermore, for any meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(" on ")#mi("{Y}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("-\\mathrm{deg}(f^* \\omega) + \\sum_{z \\in \\Sigma} \\sum_{P \\in f^{-1}(\\{z\\})} (\\mathrm{ord}_P(f-z) - 1) = - d \\mathrm{deg}(\\omega).")]]
]

#emph[#text("Proof:")]#text(" We begin with the first claim. The space ")#mi("{X \\backslash f^{-1}(\\Sigma)}")#text(" is a ")#mi("{d}")#text("-fold cover of ")#mi("{Y \\backslash \\Sigma}")#text(". Any triangulation of the latter can then be pulled back to a triangulation of the former with ")#mi("{d}")#text(" times as many vertices, edges, and faces. As a consequence we have")

#align(center)[#tao-fit-display[#mitex("\\chi( X \\backslash f^{-1}(\\Sigma) ) = d \\chi(Y \\backslash \\Sigma ).")]]

#text("On the other hand, every time one removes a point from a surface, the Euler characteristic drops by one (we remove one vertex without deleting any edges or faces). Thus")

#align(center)[#tao-fit-display[#mitex("d \\chi(Y \\backslash \\Sigma ) = d \\chi(Y) - \\sum_{z \\in \\Sigma} d")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\chi( X \\backslash f^{-1}(\\Sigma) ) = \\chi(X) - \\sum_{z \\in \\Sigma} \\sum_{P \\in f^{-1}(\\{z\\})} 1.")]]

#text("Combining these identities with ")#link(<tao-1b19282db7a40e15bf3e>)[#text("(8)")]#text(", we obtain the first claim.")#linebreak()#text(" Next, if we sum ")#link(<tao-5ab1240022676d247e9a>)[#text("(9)")]#text(" over all ")#mi("{P}")#text(" in the preimage of ")#mi("{z}")#text(" using ")#link(<tao-1b19282db7a40e15bf3e>)[#text("(8)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{P \\in f^{-1}(\\{z\\})} \\mathrm{ord}_P( f^* \\omega ) = d \\mathrm{ord}_z(\\omega) + \\sum_{P \\in f^{-1}(\\{z\\})} (\\mathrm{ord}_P(f-z) - 1)")]]

#text("and then if one sums over all ")#mi("{z}")#text(", one obtain the second claim. ")#mi("\\Box")#linebreak()#text(" Now we can prove that every canonical divisor on a compact Riemann surface ")#mi("{X}")#text(" has degree ")#mi("{-\\chi(X)}")#text(", which is equal to ")#mi("{2g-2}")#text(". From Example ")#link(<tao-1162e527383742bf0314>)[#text("23")]#text(" we see that this claim is true for the Riemann sphere ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(". For any other surface ")#mi("{X}")#text(", we use Exercise ")#link(<tao-dd7a946de80abf417970>)[#text("37")]#text(" to produce a non-constant holomorphic map ")#mi("{f: X \\rightarrow {\\bf C} \\cup \\{\\infty\\}}")#text(" from ")#mi("{X}")#text(" to the Riemann sphere, and let ")#mi("{\\omega}")#text(" be any meromorphic ")#mi("{1}")#text("-form on the Riemann sphere (e.g. one could take ")#mi("{\\omega = dz}")#text("). Then ")#mi("{\\chi({\\bf C} \\cup \\{\\infty\\}) + \\mathrm{deg}(\\omega) = 2 - 2 = 0}")#text(", hence by both equations in the Riemann-Hurwitz formula we have ")#mi("{\\chi(X) + \\mathrm{deg}(f^*\\omega) = d*0 = 0}")#text(", and so the canonical divisor ")#mi("{(f^* \\omega)}")#text(" has degree ")#mi("{-\\chi(X)}")#text(". Since all canonical divisors are equivalent, the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" Let ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" be compact Riemann surfaces, with ")#mi("{Y}")#text(" having higher genus than ")#mi("{X}")#text(". Show that there does not exist any non-constant holomorphic map from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(".")
]

#text("Now we discuss the third claim. It is relatively easy to show that the dimension of the space of holomorphic ")#mi("{1}")#text("-forms is ")#emph[#text("upper bounded")]#text(" by ")#mi("{g}")#text(". Indeed, we may assume without loss of generality that there exists at least one non-zero holomorphic ")#mi("{1}")#text("-form, giving an effective canonical divisor ")#mi("{K}")#text(", which we have just shown to have degree ")#mi("{2g-2}")#text(". From Proposition ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("32")]#text(" applied to ")#mi("{D=K}")#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K) - 1 \\leq 2g-2 + 1 - \\mathrm{dim}(L(K))")]]

#text("and hence ")#mi("{\\mathrm{dim}(L(K))\\leq g}")#text(", giving the claimed upper bound.")#linebreak()#text(" The lower bound is harder. Basically, it asserts that the pairing ")#mi("{\\langle,\\rangle}")#text(" in Proposition ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("32")]#text(", when quotiented down to a pairing between ")#mi("{L(K)/L(K-D)}")#text(" and ")#mi("{V/W}")#text(", is non-degenerate. This is a special case of an algebraic geometry fact known as ")#link("https://en.wikipedia.org/wiki/Serre_duality")[#text("Serre duality")]#text(", which we will not prove here. It can also be proven from ")#link("https://en.wikipedia.org/wiki/Hodge_theory")[#text("Hodge theory")]#text(", using the fact that the first de Rham cohomology has dimension ")#mi("{2g}")#text("; we do not pursue this approach here, but see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1288523")[#text("Griffiths-Harris")]#text(". Alternatively, one can try to explicitly construct ")#mi("{g}")#text(" linearly independent holomorphic ")#mi("{1}")#text("-forms on the Riemann surface ")#mi("{X}")#text(". We will not do this in general, but show how to do this in the case of a smooth algebraic curve ")#mi("{Z(Q) = \\{ [z_1,z_2,z_3] \\in \\mathrm{CP}^2: Q(z_1,z_2,z_3)=0\\}}")#text(" of degree ")#mi("{d}")#text(". The genus of such a curve turns out to be given by the ")#link("https://en.wikipedia.org/wiki/Genus%E2%80%93degree_formula")[#text("genus-degree formula")]

#align(center)[#tao-fit-display[#mitex("g = \\frac{(d-1)(d-2)}{2}.")]]

#text("One can sketch a proof of this using the Riemann-Hurwitz formula. For simplicity of notation let us assume that the polynomial is in “general position” in a number of senses that we will not specify precisely. We can form a holomorphic map")

#align(center)[#tao-fit-display[#mitex("f: Z(Q) \\rightarrow \\mathrm{CP}^1 \\equiv {\\bf C} \\cup \\{\\infty\\}")]]

#text("by mapping ")#mi("{[z_1,z_2,z_3]}")#text(" to ")#mi("{[z_1,z_3] \\in \\mathrm{CP}^1}")#text(". Generically, this will be a non-constant map of degree ")#mi("{d}")#text(". The critical points will be those points ")#mi("{[z_1,z_2,z_3] \\in Z(Q)}")#text(" such that ")#mi("{\\frac{\\partial Q}{\\partial z_2}}")#text(" vanishes. As ")#mi("{Q}")#text(" is irreducible of degree ")#mi("{d}")#text(", and ")#mi("{\\frac{\\partial Q}{\\partial z_2}}")#text(" is irreducible of degree ")#mi("{d-1}")#text(", then Bezout’s theorem will tell us that (generically) there will be ")#mi("{d(d-1)}")#text(" critical points ")#mi("{P}")#text(", each of multiplicity one (so ")#mi("{\\mathrm{ord}_P(f-z)=2}")#text(" at each such point ")#mi("{P}")#text("). Applying the Riemann-Hurwitz formula, one concludes that")

#align(center)[#tao-fit-display[#mitex("\\chi( Z(P) ) + d (d-1) = d \\chi( {\\bf C} \\cup \\{\\infty\\} );")]]

#text("since ")#mi("{\\chi({\\bf C} \\cup \\{\\infty\\}) = 2}")#text(" and ")#mi("{\\chi(Z(P)) = 2-2g}")#text(", this gives the genus-degree formula.")#linebreak()#text(" To construct ")#mi("{\\frac{(d-1)(d-2)}{2}}")#text(" linearly independent holomorphic ")#mi("{1}")#text("-forms on ")#mi("{Z(P)}")#text(" one can argue as follows. The cases ")#mi("{d=1,2}")#text(" follow from Exercise ")#link(<tao-6575bebbc238952b7ad2>)[#text("8")]#text(", can be worked out by hand, so suppose ")#mi("{d \\geq 3}")#text(". On the projective line ")#mi("{\\mathrm{CP}^1 = \\{ [z_1,z_3]: (z_1,z_3) \\in {\\bf C}^2 \\backslash \\{(0,0)\\}\\}}")#text(", the meromorphic function ")#mi("{z_1/z_3}")#text(" has a simple pole at ")#mi("{[1,0]}")#text(", while its differential ")#mi("{d(z_1/z_3)}")#text(" has a double pole at ")#mi("{[1,0]}")#text(" (and no zeroes). Pulling back by ")#mi("{f}")#text(", we see that the meromorphic ")#mi("{1}")#text("-form ")#mi("{d(z_1/z_3)}")#text(" on ")#mi("{Z(P)}")#text(" has double poles at each of the ")#mi("{d}")#text(" preimages of ")#mi("{[1,0]}")#text(" (making the genericity hypothesis they are distinct and non-degenerate), and also acquire a simple zero at each of the ")#mi("{d(d-1)}")#text(" zeroes of ")#mi("{\\frac{\\partial Q}{\\partial z_2}}")#text(". This implies that for any polynomial ")#mi("{R(z_1,z_2)}")#text(" of degree at most ")#mi("{d-3}")#text(", the ")#mi("{1}")#text("-form")

#align(center)[#tao-fit-display[#mitex("\\frac{R(z_1/z_3,z_2/z_3)}{\\frac{\\partial Q}{\\partial z_2}(z_1/z_3,z_2/z_3)} d(z_1/z_3)")]]

#text("is well-defined and holomorphic on the projective curve ")#mi("{Z(P)}")#text(") (we have killed all the poles and removed the simple zeroes, while possibly creating new zeroes where ")#mi("{Q}")#text(" vanishes). The space of such polynomials has dimension ")#mi("{\\frac{(d-1)(d-2)}{2} = g}")#text(", giving the claim.")#linebreak()#text(" It remains to remove the condition that ")#mi("{D}")#text(" and ")#mi("{K-D}")#text(" be effective to obtain the Riemann-Roch theorem in full generality. We first prove a weaker version known as ")#emph[#text("Riemann’s inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 42 (Riemann’s inequality)")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface of genus ")#mi("{g}")#text(", and let ")#mi("{D}")#text(" be a divisor. Then ")#mi("{\\mathrm{dim} L(D) \\geq \\mathrm{deg}(D) + 1 - g}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{K}")#text(" be a canonical divisor. Choose a non-zero effective divisor ")#mi("{D^{\\prime}}")#text(" such that ")#mi("{K+D^{\\prime} \\geq D}")#text(". We will show that")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K+D^{\\prime}) = \\mathrm{deg}(D^{\\prime}) + g - 1;")]]

#text("since from Lemma ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("19")]#text(" we have ")#mi("{\\mathrm{dim} L(K+D^{\\prime}) \\leq \\mathrm{dim} L(D) + \\mathrm{deg}(K+D^{\\prime}-D)}")#text(", and ")#mi("{\\mathrm{deg}(K) = 2g-2}")#text(", Riemann’s inequality will follow after a brief calculation.")#linebreak()#text(" Dividing through by a meromorphic ")#mi("{1}")#text("-form of divisor ")#mi("{K}")#text(", we see that ")#mi("{\\mathrm{dim} L(K+D^{\\prime})}")#text(" is the dimension of the space ")#mi("{M}")#text(" of meromorphic ")#mi("{1}")#text("-forms with divisor at least ")#mi("{-D^{\\prime}}")#text(". If ")#mi("{D^{\\prime} = \\sum_{P \\in {\\mathcal P}} n_P \\cdot (P)}")#text(" with ")#mi("{n_P \\geq 1}")#text(", ")#mi("{M}")#text(" is the space of meromorphic ")#mi("{1}")#text("-forms ")#mi("{\\omega}")#text(" that have poles of order at most ")#mi("{n_P}")#text(" at each ")#mi("{P \\in {\\mathcal P}}")#text(", and no other poles.")#linebreak()#text(" As in the proof of Proposition ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("32")]#text(", let ")#mi("{V}")#text(" be the space of tuples ")#mi("{(\\sum_{j=1}^{n_P} \\frac{c_{P,j}}{z^j})_{P \\in {\\mathcal P}}}")#text(" with ")#mi("{c_{P,j}}")#text(" complex; this has dimension ")#mi("{\\mathrm{deg}(D^{\\prime}) \\geq 1}")#text(", and there is a linear map ")#mi("{T: M \\rightarrow V}")#text(" that takes a meromorphic ")#mi("{1}")#text("-form ")#mi("{\\omega}")#text(" in ")#mi("{M}")#text(" to the tuple of its principal parts at points in ")#mi("{{\\mathcal P}}")#text(". The image is constrained by Proposition ")#link(<tao-cd35a2426062b7d58fd4>)[#text("24")]#text("(i), which forces the residues ")#mi("{c_{P,1}}")#text(" to sum to zero. On the other hand, by taking linear combinations of the meromorphic ")#mi("{1}")#text("-forms from Exercise ")#link(<tao-dd7a946de80abf417970>)[#text("37")]#text(" and Propsosition ")#link(<tao-3160c321bcd0c49b6755>)[#text("38")]#text(", we see conversely that any tuple in ")#mi("{V}")#text(" whose residues sum to zero lies in the image of ")#mi("{T}")#text(". Thus the image of ")#mi("{T}")#text(" has dimension ")#mi("{\\mathrm{deg}(D^{\\prime}) - 1}")#text(". On the other hand, the kernel of ")#mi("{T}")#text(" is simply the space of holomorphic ")#mi("{1}")#text("-forms, which has dimension ")#mi("{g}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" Now we prove the Riemann-Roch theorem. We split into cases, depending on the dimensions of ")#mi("{L(D)}")#text(" and ")#mi("{L(K-D)}")#text(".")#linebreak()#text(" First suppose that ")#mi("{L(D)}")#text(" and ")#mi("{L(K-D)}")#text(" are both positive dimensional. By Exercise ")#link(<tao-0136953b423d46e0070c>)[#text("18")]#text(", ")#mi("{D}")#text(" is linearly equivalent to an effective divisor, hence by Proposition ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("32")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) \\leq \\mathrm{deg}(D) + 1 - g")]]

#text("and similarly (replacing ")#mi("{D}")#text(" by ")#mi("{K-D}")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(K-D) - \\mathrm{dim}L(D) \\leq \\mathrm{deg}(K-D) + 1 - g")]]

#text("and the claim then follows by using ")#mi("{\\mathrm{deg}(K) = 2g-2}")#text(".")#linebreak()#text(" Now suppose that ")#mi("{L(D)}")#text(" and ")#mi("{L(K-D)}")#text(" are both trivial. Riemann’s inequality then gives")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\mathrm{deg}(D) + 1-g, \\mathrm{deg}(K-D) + 1-g,")]]

#text("which (again using ")#mi("{\\mathrm{deg}(K)=2g-2}")#text(") gives ")#mi("{\\mathrm{deg}(D) = g-1}")#text(", and the claim again follows.")#linebreak()#text(" Now suppose that ")#mi("{L(K-D)}")#text(" is trivial but ")#mi("{L(D)}")#text(" is positive dimensional. From Exercise ")#link(<tao-0136953b423d46e0070c>)[#text("18")]#text(" and Proposition ")#link(<tao-a3ca38ef0e8554b39ce6>)[#text("32")]#text(" as before we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) \\leq \\mathrm{deg}(D) + 1 - g,")]]

#text("while from Riemann’s inequality and the triviality of ")#mi("{L(K-D)}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim} L(D) - \\mathrm{dim}L(K-D) \\geq \\mathrm{deg}(D) + 1 - g,")]]

#text("giving the claim. The final case when ")#mi("{L(D)}")#text(" is trivial and ")#mi("{L(K-D)}")#text(" is positive dimensional then follows by swapping ")#mi("{D}")#text(" with ")#mi("{K-D}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface of genus one, and let ")#mi("{\\infty}")#text(" be a point on ")#mi("{X}")#text(". Show that for any points ")#mi("{P,Q}")#text(" on ")#mi("{X}")#text(", there is a unique point ")#mi("{P+Q}")#text(" on ")#mi("{X}")#text(" such that ")#mi("{(P) + (Q) - (P+Q) - (\\infty)}")#text(" is a principal divisor. Furthermore show that this defines an abelian group law on ")#mi("{X}")#text(". What is this group law in the case that ")#mi("{X}")#text(" is an elliptic curve?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface, and suppose that there exists a meromorphic function ")#mi("{f}")#text(" on ")#mi("{X}")#text(" with one simple pole and no other poles. Show that ")#mi("{f}")#text(" is an isomorphism between ")#mi("{X}")#text(" and the Riemann sphere. Conclude in particular that the Riemann sphere is the only genus zero compact Riemann surface (up to isomorphism, of course).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface of genus ")#mi("{g}")#text(", and let ")#mi("{D}")#text(" be a divisor of degree ")#mi("{2g-2}")#text(". Show that ")#mi("{\\mathrm{dim}L(D)=g}")#text(" when ")#mi("{D}")#text(" is a canonical divisor, and ")#mi("{\\mathrm{dim} L(D)=g-1}")#text(" otherwise.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46 (Gap theorems)")]#text(" Let ")#mi("{X}")#text(" be a compact Riemann surface of genus ")#mi("{g}")#text(".")

#list(
[#text("(i) (Weierstrass gap theorem) If ")#mi("{P}")#text(" is a point in ")#mi("{X}")#text(", show that there are precisely ")#mi("{g}")#text(" positive integers ")#mi("{n}")#text(" with the property that there does not exist a meromorphic function on ")#mi("{X}")#text(" with a pole of order ")#mi("{n}")#text(" at ")#mi("{P}")#text(", and no other poles. Show in addition that all of these integers are less than or equal to ")#mi("{2g-1}")#text(".")],
[#text("(ii) (Noether gap theorem) If ")#mi("{P_1, P_2, \\dots}")#text(" are a sequence of distinct points in ")#mi("{X}")#text(", show that there are precisely ")#mi("{g}")#text(" positive integers ")#mi("{n}")#text(" with the property that there does not exist a meromorphic function with a simple pole at ")#mi("{P_n}")#text(", at most a simple pole at ")#mi("{P_1,\\dots,P_{n-1}}")#text(", and no other poles. Show in addition that all of these integers are less than or equal to ")#mi("{2g-1}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 5. Appendix: connectedness of irreducible algebraic curves — ")]]

#text("In this section we prove")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 47")]#text(" Let ")#mi("{P(z_1,z_2,z_3)}")#text(" be an irreducible homogeneous polynomial of degree ")#mi("{d \\geq 1}")#text(". Then ")#mi("{Z(P)}")#text(" is connected.")
]

#text("We begin with the affine version of this theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 48")]#text(" Let ")#mi("{P(z_1,z_2)}")#text(" be an irreducible polynomial of degree ")#mi("{d \\geq 1}")#text(". Then the affine curve")

#align(center)[#tao-fit-display[#mitex("Z(P)_{aff} := \\{ (z_1,z_2) \\in {\\bf C}^2: P(z_1,z_2) = 0 \\}")]]

#text("is connected.")
]

#text("We observe that this theorem fails if one replaces the complex numbers by the real ones; for instance, the quadratic polynomial ")#mi("{x_2^2 - x_1^2 - 1}")#text(" is irreducible, but the hyperbola it defines in ")#mi("{{\\bf R}^2}")#text(" is disconnected. Thus we will need properties of the complex numbers that are not true for the reals. We will rely in particular on the fundamental theorem of algebra, the removability of bounded singularities, the generalised Liouville theorem that entire functions of polynomial growth are polynomial, and the fact that the complex numbers remain connected even after removing finitely many points.")#linebreak()#text(" We now prove the proposition. We will use the classical approach of thinking of ")#mi("{Z(P)^{aff}}")#text(" as a ")#link("https://en.wikipedia.org/wiki/Branched_covering")[#text("branched ")#mi("{d}")#text("-fold cover")]#text(" over the complex numbers, possibly after some preparatory change of variables; the main difficulty is then to work around the ramification points of this cover. We turn to the details. Let ")#mi("{P(z_1,z_2)}")#text(" be an irreducible polynomial of degree ")#mi("{d \\geq 1}")#text(", then we can write it as")

#align(center)[#tao-fit-display[#mitex("P(z_1,z_2) = P_d(z_1) z_2^d + P_{d-1}(z_1) z_2^{d-1} + \\dots + P_0(z_1)")]]

#text("where for ")#mi("{j=0,\\dots,d}")#text(", ")#mi("{P_j}")#text(" lies in the space ")#mi("{\\mathrm{Poly}_{\\leq d-j}}")#text(" of polynoimals of one variable of degree at most ")#mi("{d-j}")#text(". In particular ")#mi("{P_d = P_d(z_1)}")#text(" is a constant. It could happen that this constant vanishes (e.g., consider the example ")#mi("{d=2}")#text(" and ")#mi("{P(z_1,z_2) = z_2 - z_1^2}")#text("); but in that case we will make a change of variables and consider instead the polynomial ")#mi("{P( z_1 + \\lambda z_2, z_2 )}")#text(" for a complex parameter ")#mi("{\\lambda}")#text(". Now the analogue of ")#mi("{P_d}")#text(" is a non-trivial polynomial function of ")#mi("{\\lambda}")#text(" (because one of the ")#mi("{P_j}")#text(" must have degree exactly ")#mi("{d-j}")#text("), and so this quantity will be non-zero for some ")#mi("{\\lambda}")#text(" (in fact for all but at most ")#mi("{d}")#text(" values of ")#mi("{\\lambda}")#text(").")#linebreak()#text(" Henceforth we assume we have placed ")#mi("{P(z_1,z_2)}")#text(" into a form where ")#mi("{P_d}")#text(" is non-zero. Then, for each ")#mi("{z_1}")#text(", the function ")#mi("{P_{z_1}: z_2 \\mapsto P(z_1,z_2)}")#text(" is a polynomial of one variable of degree exactly ")#mi("{d}")#text(", so it has ")#mi("{d}")#text(" roots (counting multiplicity) by the fundamental theorem of algebra. Let us call these set of roots ")#mi("{\\Sigma_{z_1}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("Z(P)_{aff} = \\bigcup_{z_1 \\in {\\bf C}} \\{z_1\\} \\times \\Sigma_{z_1}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P_{z_1}(\\zeta) = P_d \\prod_{\\zeta \\in \\Sigma_{z_1}} (z_2 - \\zeta).")]]

#text("From ")#link("https://en.wikipedia.org/wiki/Rouch%C3%A9%27s_theorem")[#text("Rouché’s theorem")]#text(" we know that the zero set varies continuously in ")#mi("{z_1}")#text(" in the following sense: for any ")#mi("{z_1}")#text(" and ")#mi("{\\varepsilon>0}")#text(", each point of ")#mi("{\\Sigma_{z^{\\prime}_1}}")#text(" will stay within ")#mi("{\\varepsilon}")#text(" of some point in ")#mi("{\\Sigma_{z_1}}")#text(" if ")#mi("{z^{\\prime}_1}")#text(" is sufficiently close to ")#mi("{z_1}")#text(". (In other words, ")#mi("{z_1 \\mapsto \\Sigma_{z_1}}")#text(" is continuous with respect to ")#link("https://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff distance")]#text(".) We also see that the elements in ")#mi("{\\Sigma_{z_1}}")#text(" grow at most polynomially in ")#mi("{z_1}")#text(". For some values of ")#mi("{Z_1}")#text(", some of these roots in ")#mi("{\\Sigma_{z_1}}")#text(" may be repeated. For instance, if ")#mi("{P(z_1,z_2) = z_2^2 + z_1^2 - 1}")#text(", then ")#mi("{P_{z_1}(z_2) = z_2^2 + (z_1^2-1)}")#text(", which has a double root at ")#mi("{z_2=0}")#text(" if ")#mi("{z_1=-1}")#text(" or ")#mi("{z_1=+1}")#text(". However, if this occurs for some ")#mi("{z_1}")#text(", the the degree ")#mi("{d}")#text(" polynomial ")#mi("{P_{z_1}(z_2)}")#text(" and the degree ")#mi("{d-1}")#text(" ")#mi("{P^{\\prime}_{z_1}(z_2)}")#text(" have a common root ")#mi("{w_{z_1}}")#text(". This only occurs when the ")#link("https://en.wikipedia.org/wiki/Resultant")[#text("resultant")]#text(" ")#mi("{\\mathrm{Res}(P_{z_1}, P^{\\prime}_{z_1})}")#text(" of ")#mi("{P_{z_1}}")#text(" and ")#mi("{P^{\\prime}_{z_1}}")#text(" vanishes. (One can also use the ")#link("https://en.wikipedia.org/wiki/Discriminant")[#text("discriminant")]#text(" of ")#mi("{P_{z_1}}")#text(" here in place of the resultant; the two are constant multiples of each other.) From the definition of the resultant we see that ")#mi("{\\mathrm{Res}(P_{z_1}, P^{\\prime}_{z_1})}")#text(" is a polynomial in ")#mi("{z_1}")#text(", and furthermore we have a Bezout identity")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Res}(P_{z_1}, P^{\\prime}_{z_1}) = P_{z_1} A_{z_1} + P^{\\prime}_{z_1} B_{z_1}")]]

#text("where ")#mi("{A_{z_1}, B_{z_1}}")#text(" are polynomials of degree at most ")#mi("{d-2}")#text(" and ")#mi("{d-1}")#text(" in ")#mi("{z_2}")#text(" respectively, with coefficients that are polynomials in ")#mi("{z_1}")#text(". The resultant cannot vanish identically, as this would mean that ")#mi("{P_{z_1}}")#text(" divides ")#mi("{P^{\\prime}_{z_1} B_{z_1}}")#text(" viewed as polynomials in ")#mi("{z_1,z_2}")#text(", which contradicts unique factorisation and the irreducibility of ")#mi("{P}")#text(" since ")#mi("{P_{z_1}}")#text(" cannot divide the lower degree polynomials ")#mi("{P^{\\prime}_{z_1}}")#text(" or ")#mi("{B_{z_1}}")#text(". Thus the resultant can only vanish for a finite number of ")#mi("{z_1}")#text(", and so for all but finitely many ")#mi("{z_1}")#text(" the roots of ")#mi("{P_{z_1}}")#text(" are distinct, thus ")#mi("{\\Sigma_{z_1}}")#text(" has cardinality exactly ")#mi("{d}")#text(" and ")#mi("{P^{\\prime}_{z_1}}")#text(" is non-vanishing at each element of ")#mi("{\\Sigma{z_1}}")#text(".")#linebreak()#text(" From this and the inverse function theorem we see that for ")#mi("{z_1}")#text(" outside of a finite number of points (known as ")#link("https://en.wikipedia.org/wiki/Ramification_(mathematics)")[#text("ramification points")]#text("), the set ")#mi("{\\Sigma_{z_1}}")#text(" varies holomorphically with ")#mi("{z_1}")#text(". Locally, one can thus describe ")#mi("{\\Sigma_{z_1}}")#text(" as a family ")#mi("{\\{f_1(z_1),\\dots,f_d(z_1)\\}}")#text(" of holomorphic functions, although the order in which one labels these points is arbitrary, as one varies ")#mi("{z_1}")#text(" around one of the ramification points, theis ordering may be permuted (consider for instance the case ")#mi("{P_{z_1}(z_2) = z_2^2 - z_1}")#text(" as ")#mi("{z_1}")#text(" goes around the origin, in which we can write ")#mi("{\\Sigma_{z_1} = \\{ + z_1^{1/2}, - z_1^{1/2} \\}}")#text(" for various branches of the square root function).")#linebreak()#text(" Now suppose that ")#mi("{Z(P)_{aff}}")#text(" is disconnected, so it splits into two non-empty clopen subsets ")#mi("{Z_1 \\cup Z_2}")#text(". At each non-ramified point ")#mi("{z_1}")#text(", the set ")#mi("{Z_1}")#text(" meets some subset of ")#mi("{\\{z_1 \\}\\times \\Sigma_{z_1}}")#text(". In local coordinates, the ")#mi("{f_j(z_1)}")#text(" are distinct and vary continuously with ")#mi("{z_1}")#text(", the number of points in which ")#mi("{Z_1}")#text(" meets ")#mi("{\\{z_1\\} \\times \\Sigma_{z_1}}")#text(" is locally constant; since ")#mi("{{\\bf C}}")#text(" with finitely many points removed is connected, this number is then globally constant, thus there is ")#mi("{0 \\leq k \\leq d}")#text(" such that ")#mi("{Z_1 \\cap \\{z_1\\} \\times \\Sigma_{z_1}}")#text(" has cardinality precisely ")#mi("{k}")#text(". This lets us factor ")#mi("{P_{z_1} = P_d Q_{z_1} R_{z_2}}")#text(", where ")#mi("{Q_{z_1}}")#text(" is the degree ")#mi("{k}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("Q_{z_1}(z_2) := \\prod_{(z_1,\\zeta) \\in Z_1 \\cap \\Sigma_{z_1}} (z_2 - \\zeta)")]]

#text("and ")#mi("{R_{z_1}}")#text(" is the degree ")#mi("{d-k}")#text(" polynomial")

#align(center)[#tao-fit-display[#mitex("Q_{z_1}(z_2) := \\prod_{(z_1,\\zeta) \\in Z_2 \\cap \\Sigma_{z_1}} (z_2 - \\zeta)")]]

#text("The coefficients of these polynomials are functions of ")#mi("{z_1}")#text(" that vary holomorphically with ")#mi("{z_1}")#text(" outside of the ramification points; they also stay bounded as one approaches these points and grow at most polynomially. Hence (by the generalised Liouville theorem) they depend polynomially on ")#mi("{z_1}")#text(", thus ")#mi("{Q_{z_1}(z_2)}")#text(" and ")#mi("{R_{z_1}(z_2)}")#text(" are in fact a polynomial jointly in ")#mi("{z_1,z_2}")#text(". But this contradicts the irreducibility of ")#mi("{P}")#text(", unless ")#mi("{k=0}")#text(" or ")#mi("{k=d}")#text(". We conclude that ")#mi("{Z(P)_{aff}}")#text(" is connected after deleting its ramification points. But from the continuous dependence of ")#mi("{\\Sigma_{z_1}}")#text(" on ")#mi("{z_1}")#text(", the ramification points adhere to the rest of ")#mi("{Z(P)_{aff}}")#text(" (the zeroes of ")#mi("{P_{z_1}}")#text(" are stable under small perturbations, even at points of ramification), so that ")#mi("{Z(P)_{aff}}")#text(" is connected, proving the proposition.")#linebreak()#text(" Now we prove the theorem. The case ")#mi("{d=1}")#text(" can be done by hand, so assume ")#mi("{d>1}")#text(". Let ")#mi("{P(z_1,z_2,z_3)}")#text(" be an irreducible homogeneous polynomial of degree ")#mi("{d}")#text(". Then ")#mi("{P(z_1,z_2,1)}")#text(" is an irreducible polynomial of degree ")#mi("{d}")#text(" (it cannot be less than ")#mi("{d}")#text(", as this will make ")#mi("{P(z_1,z_2,z_3)}")#text(" contain a power of ")#mi("{z_3}")#text(" which makes it reducible since ")#mi("{d>1}")#text("). As a consequence, we see from the proposition that the affine part ")#mi("{Z(P) \\cap \\{ [z_1,z_2,z_3] \\in \\mathbf{CP}^2: z_3 \\neq 0\\}}")#text(" is connected; similarly if we replace the condition ")#mi("{z_3 \\neq 0}")#text(" with ")#mi("{z_1 \\neq 0}")#text(" and ")#mi("{z_2 \\neq 0}")#text(". As these three pieces of ")#mi("{Z(P)}")#text(" cover the whole zero locus, it will suffice to show that they intersect each other; for instance, it will suffice to show that the zero set of ")#mi("{P(z_1,z_2,1)}")#text(" is not completely contained in any line. But this is clear from the proof of the proposition, which shows that (after a linear transformation) almost every vertical line meets this zero set in ")#mi("{d>1}")#text(" points.")

#heading(level: 1)[#text("Comments (65)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a72841d691c4583f3fda298efde2073ffdf810f7cdf039cb16b845e83095724d-b3229293ec7b8d0b735dd30ffa06f9a7fdcef58dc2ad7425c7262cc2f6e46185.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Wang")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494916")[#strong[#text("Victor Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Here is an elementary approach to removing the effectiveness assumption on D, K-D.")

#text("Let lowercase l(D) := dim L(D). We assume g = l(K) (and perhaps also deg(K) = 2g-2), in addition to the following two results:")

#text("– l(D) >= 1 + deg(D) – g (Riemann’s inequality, for arbitrary divisors D); and the more important")#linebreak()#text(" – l(D) <= 1 + deg(D) – g + l(K-D) (for D effective; I think this is your \"Baby Riemann Roch theorem\" above).")

#text("To proceed, observe that l(D) is nonzero if and only if D is linearly equivalent to some effective divisor. Now break into three cases:")

#text("(1) If l(D), l(K-D) are both nonzero, just apply the second inequality once to an eff. representative of D, and once to an eff. representative of K-D (noting that deg(K) = 2g-2, proven e.g. by taking D = 0 and D = K in the second inequality, or indirectly through Riemann-Hurwitz).")

#text("(2) Similarly, Riemann's inequality addresses the case of l(D) = l(K-D) = 0. Indeed, the vanishing of l's implies deg(D) <= g-1 and deg(K-D) <= g-1; but deg(K) = 2g-2, so in fact deg(D) = deg(K-D) = g-1. This is consistent (!) with the Riemann-Roch theorem, which resolves this case seemingly without any work.")

#text("(3) Finally, it's enough to address l(D) nonzero but l(K-D) = 0 (note that deg(K) = 2g-2 shows the symmetry of RR with D, K-D flipped), in which case Riemann's inequality and the second inequality actually do match up.")

#text("The best elementary resource I know is the sequence of exercises in Appendix A. The Riemann-Roch Theorem, Hodge Theorem, and … of Arbarello, E., Cornalba, M., Griffiths, P., Harris, J.D., \"Geometry of Algebraic Curves\" Volume I (available on Springer), starting p. 50.")

#text("I wasn't able to make everything rigorous the last time I worked through it (esp. in the first few exercises), but overall it felt convincing and enlightening. See in particular Exercise 13 for Riemann's inequality, and the key exercises 7, 8, and 10 earlier for understanding the genus and l(K), even allowing nodal singularities. (Unfortunately, there are several typos in this sequence of exercises, e.g. off-by-one errors.)")

#text("If memory serves, the idea in the \"… case of a smooth algebraic curve of degree… killed all the poles and removed the simple zeroes, while possibly creating new zeroes… space of such polynomials has dimension\" part of the blog post above is enough for Exercises 8 and 13 (the latter being Riemann's inequality). Exercise 7 is the Plucker formula allowing nodal singularities in genus computation, and Exercise 10 is a baby \"Hodge theorem\" proving, in particular, l(K) = g for the g used in the Riemann-Hurwitz formula.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Thanks for this! So basically the missing ingredient is Riemann’s inequality, I will look into proofs of this inequality and see if I can find anything that is suitable for this class, probably starting with the reference you provided.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a72841d691c4583f3fda298efde2073ffdf810f7cdf039cb16b845e83095724d-b3229293ec7b8d0b735dd30ffa06f9a7fdcef58dc2ad7425c7262cc2f6e46185.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Wang")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494924")[#strong[#text("Victor Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Great! Actually, now that I look more carefully, Lecture 6 (9/21) of Akhil’s notes ")#link("http://www.math.harvard.edu/~amathew/287y.pdf")[#text("http://www.math.harvard.edu/~amathew/287y.pdf")]#text(" (from a course by Harris) seems to cover most of the details of the argument for Riemann’s lemma, first doing it for smooth case and then with singularities. (I didn’t think to mention these notes earlier since the finishing argument still mentioned “Jacobi inversion”, which we wanted to avoid.)")

#text("Also, I misspoke when I said there are several “off-by-one” errors: I didn’t realize that ACGH was using the notation “r(D), dimension of a linear system |D|”, which is 1 less than l(D).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("Actually, I managed to derive Riemann’s inequality from the existence of Abelian differentials of the second and third kinds with prescribed principal parts (subject of course to the constraint that the residues sum to zero), which was a fact that I was basically assuming for the discussion anyways, and which also fits nicely with the complex torus discussion where the Weierstrass function is used to generate the required differentials. (Perhaps this is close in fact to Riemann’s original proof, though I think he didn’t quite use Perron’s method to construct the differentials.) So I have updated the notes accordingly.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a72841d691c4583f3fda298efde2073ffdf810f7cdf039cb16b845e83095724d-b3229293ec7b8d0b735dd30ffa06f9a7fdcef58dc2ad7425c7262cc2f6e46185.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Victor Wang")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494970")[#strong[#text("Victor Wang")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Oh, I see. I like this perspective, where the principal parts of 1-forms play a “uniform” organizational role (minimizing the need for “genus-dependent” computation). I’m far from an expert, but I don’t know if there’s a simple algebraic way to construct those distinguished differentials in the algebraic setting without assuming Riemann-Roch. I guess it should be possible at least for hyperelliptic curves (including elliptic curves, as you mentioned).")

#text("Anyways, here are some minor typos/suggestions in the notes:")

#text("– In the first line of the paragraph defining the divisor class group, “(f) is an effective divisor” should be “(f) is a principal divisor”.")

#text("– I guess the definition of linearly equivalent should precede Exercise 18 (l(D) > 0 iff…); alternatively, Exercise 18 could be moved either after the definition of linearly equivalent, or even later (e.g. close to Exercise 25).")

#text("– Following the proof of Riemann’s inequality, in the first case of the end of the RR proof, the second display l(K-D) – l(K-D) should be l(K-D) – l(D).")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494918")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("following Thm 32: “holomorhpic” -> “holomorphic” .")#linebreak()#text(" following Ex. 35, Prop. 40: “Rouche’s” -> “Rouch\\’e’s” .")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75a81f2214ae05cd91b405a5f653979e27684d525df38c839085bda1741cd880-682ebf6fdf567dadbbcfc7adb7f3c200c1c5008f4a776fc2ffac572494f0b0d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pallav123goyal")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494920")[#strong[#text("pallav123goyal")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2018")])]

#text("There’s a typo in Example 2, I guess you mean ")#mi("\\Lambda")#text(" instead of ")#mi("\\Gamma")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494928")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("In the RHS of (6), it seems clearer to have the summands inside parentheses.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44f77c7b2c73489e773354f43c3ea462146be50642452f9ebc09dd9b27426a30-54d645107d640c4cc59cd01dfc982bff4046a38f739896fa7c8d23634fbbe7eb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konrad Burnik")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494932")[#strong[#text("Konrad Burnik")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("Dear professor Tao, I think the statement “all compact connected one-dimensional real manifolds are homeomorphic to the unit circle” should be “all compact connected one-dimensional real manifolds are homeomorphic to the unit circle or to the segment [0,1]”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/44f77c7b2c73489e773354f43c3ea462146be50642452f9ebc09dd9b27426a30-54d645107d640c4cc59cd01dfc982bff4046a38f739896fa7c8d23634fbbe7eb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Konrad Burnik")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494935")[#strong[#text("Konrad Burnik")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("sorry, my last comment it’s true only for compact connected one-dimensional real manifolds with boundary")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494938")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("It seems that the beginning sentence of proposition 37 is not part of it (it appears also just before the proposition.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494962")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2018")])]

#text("In Example 3, aren’t the Riemann surfaces isomorphic to the disc the *bounded* simply connected open subsets of the plane?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05b3580e9be47ab681e882244d027134ad90f1cfb3366dc4e6161be7524aedd0-8ebae90a268cfea575f706c2daea1d0f0517223ccc716f33c6601ef617c03ded.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of christopherlloydsimon")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-494980")[#strong[#text("christopherlloydsimon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2018")])]

#text("It suffices to ask that they are open, simply connected and different from the whole complex plane.")#linebreak()#text(" For instance the upper half plane is biholomorphic to the disc via (z+i)/(z-i).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96801f2308e0cf703bb3c264e275af4a4bb564c65a75845636e01b0f8f1fc4c4-3be3ce581fb4eaafae815d897321e3eff572d30f82ed60bc5e783ae396731287.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Born")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495105")[#strong[#text("Born")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2018")])]

#text("I’m seeing")

#text("“Note from Proposition 24 that the *Formula does not parse* constructed by the above proposition automatically have vanishing residue at {P} (in classical language, these are Abelian differentials of the third kind, while the {\\omega_{(P)-(Q)}} are Abelian differentials of the second kind).”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495113")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("I always wondered what was meant by “divisor”. Let’s try ")#mi("y^2 = x(x-1)(x+1)")#text(". Then the divisor of ")#mi("(x) = (0)-(\\infty)")#text(". This this just a way of generalizing partial fractions? This curve doesn’t look very toric to me. Maybe try: $")#mi("X(\\mathbb{C}) = \\{ (x,y): y^2 = x(x-1)(x+1) \\} \\subseteq \\mathbb{C}^2")#text("$")#linebreak()#text(" This could also be an ")#mi("\\mathbb{R}")#text(" surface in a flat ")#mi("\\mathbb{R}")#text(" 4-space. So now I can try to integrate something:")#linebreak()#text(" $")#mi("\\omega = \\frac{x^2 - y^2}{\\sqrt{x(x-1)(x+1)}} \\in H^1(X)")#text("$")#linebreak()#text(" and I’ll use a circle of radius 2, ")#tao-math("C = \\{ \\left|z - 0.5\\right| = 2 \\} \\in H_1(X)", block: false)#text(". Then we could compute the pairing ")#mi("\\langle \\omega | C \\rangle")#text("?")

#text("We haven’t even found the number yet. Or explored its properties.")

#text("The word “good” in math is like the word “here” or “there”. It doesn’t mean anything by itself, and tells is to read around for a way of telling apart “good” and “bad”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495118")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2018")])]

#text("Divisors in algebraic geometry are abstractions of the elementary arithmetic notion of a divisor, in much the same fashion that ideals in commutative algebra are abstractions of numbers. Note for instance that if ")#mi("P(z), Q(z)")#text(" are non-zero polynomials, then ")#mi("P")#text(" divides ")#mi("Q")#text(" in the ring of polynomials if and only if the divisor ")#mi("(P)")#text(" is less than or equal to the divisor ")#mi("(Q)")#text(". Algebraic geometry divisors are also closely tied to divisor ideals in commutative algebra; see for instance the answer to ")#link("https://mathoverflow.net/questions/74427/does-the-name-divisor-in-algebraic-geometry-relate-to-divisor-in-the-basic-arith")[#text("this MathOverflow question")]#text(".")

#text("The complex curve ")#mi("\\{ (z,w) \\in {\\bf C}^2: w^2 = z(z-1)(z+1)\\}")#text(" (or more precisely, its projective version ")#mi("\\{ [z,w,u] \\in {\\bf CP}^2: w^2 u = z(z-u)(z+u) \\}")#text(") is topologically equivalent to a torus. The real slice ")#mi("\\{ (x,y) \\in {\\bf R}^2: y^2 = x(x-1)(x+1)\\}")#text(" (or more precisely, its projective version ")#mi("\\{ [x,y,t] \\in {\\bf RP}^2: y^2 t = x(x-t)(x+t) \\}")#text(") is a slice of this torus. More generally, real elliptic curves are to tori as conic sections are to cones. See for instance ")#link("http://www.math.purdue.edu/~dvb/graph/elliptic.pdf")[#text("this note of Arapura")]#text(" on how to visualise elliptic curves as tori.")

#text("Let me use ")#mi("z,w")#text(" for the complex coordinates of ")#mi("{\\bf C}^2")#text(" rather than ")#mi("x,y")#text(". The divisor of ")#mi("z")#text(" in the Riemann sphere is ")#mi("(0)-(\\infty)")#text(", but the divisor of ")#mi("z")#text(" in the curve ")#mi("\\{ (z,w): w^2 = z(z-1)(z+1)\\}")#text(", or more precisely (and projectively) the divisor of ")#mi("z/u")#text(" in ")#mi("X({\\bf C}) = \\{ [z,w,u]: w^2 u = z(z-u)(z+u)\\}")#text(", is ")#mi("2 \\cdot ([0,0,1]) - 2 \\cdot ([0,1,0])")#text(", as ")#mi("z/u")#text(" has a double zero at ")#mi("[0,0,1]")#text(" (using ")#mi("w")#text(" as the smooth coordinate and setting ")#mi("u=1")#text(", so that ")#mi("z \\approx -w^2")#text(") and a double pole at ")#mi("[0,1,0]")#text(" (using ")#mi("z")#text(" as the smooth coordinate and setting ")#mi("w=1")#text(", so that ")#mi("u \\approx z^3")#text(").")

#mi("\\frac{z^2-w^2}{\\sqrt{z(z-1)(z+1)}}")#text(" (or less ambiguously, ")#mi("\\frac{z^2-w^2}{w}")#text(") would be a meromorphic function on ")#mi("X")#text(", not a ")#mi("1")#text("-form; one needs to integrate something like ")#mi("f(z,w) dz + g(z,w) dw")#text(". The circle ")#tao-math("\\{ \\left|z-0.5\\right|=2\\}", block: false)#text(" is a circle in the complex numbers, but is not a curve in ")#mi("X")#text(". Integrating something like ")#mi("\\frac{z^2-w^2}{w}\\ dz")#text(" on arcs in ")#mi("X")#text(" will basically give elliptic integrals.")

#text("The fact that “good” does not have a precise pre-assigned meaning in mathematics makes it useful as a ")#link("https://en.wikipedia.org/wiki/Nonce_word")[#text("nonce")]#text(", as is done in these notes to denote a concept that is desirable to establish, but will not be needed outside of a single proof.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495248")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("You forgot to say that manifolds are second countable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495250")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("In the context of Riemann surfaces, I generally prefer to omit this condition, as it makes ")#link("https://en.wikipedia.org/wiki/Rad%C3%B3%27s_theorem_(Riemann_surfaces)")[#text("Rado’s theorem")]#text(" easier to state. Of course, once one has that theorem, the question of whether to impose second countability on Riemann surfaces becomes moot. (But I’ve added a parenthetical remark on how in other areas of mathematics it can be convenient to impose the second countability hypothesis.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63f1c25813d4783b408a6299e50962efb998756638ccdb9492f196964e2382fd-8d232437e87c72996ece39440cad3088c227b8dad4b2ba2aaabd2ca1c0178b45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M. Klazar")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495251")[#strong[#text("M. Klazar")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2018")])]

#text("In Definition 1 (map f from M to M’) there should be, I think,")#linebreak()#text(" phi_{alpha}(U_{alpha}cap…) in place of")#linebreak()#text(" V_{alpha}cap(phi)_{\\alpha}(…).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j.c.")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495273")[#strong[#text("j.c.")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("There’s a typo before Lemma 19. “(i.e. D contains at least one pole)” should be something like “")#mi("f\\in L(D)")#text(" has at least one pole.”")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of j.c.")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495289")[#strong[#text("j.c.")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2018")])]

#text("Perhaps in the correction you meant to say that D has positive order at at least one point?")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495450")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2018")])]

#text("In Example 2, it would be clearer to change “any discrete subgroup” to “any discrete additive subgroup” since it is also possible to take quotients of ")#mi("{\\bf C}\\backslash\\{0\\}")#text(" by discrete multiplicative subgroups for which the given additive atlas construction won’t work.")

#text("In the last sentence above Remark 15, I think ")#mi("L(D_1)\\leq L(D_2)")#text(" should be ")#mi("L(D_1)\\subset L(D_2)")#text(" instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495666")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2018")])]

#text("I believe there is a typo after Definition 10. The charts should map into $C$ not $X$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e07a8561353bad45520a7d6cb2ba44c86a3be665875a097f1f1b75c02cf5d03-2b108fd878322e069a09957aa7c9dfb513df050a54be6ed4691272d6b028863d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alstav Trivas Sava")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495693")[#strong[#text("Alstav Trivas Sava")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2018")])]

#text("Dear Prof Tao,")#linebreak()#text(" I would firstly like to apologize for posting this question at the wrong place, but I had to do so because I wasn’t sure if you’re busy schedule would allow you to answer the questions posted on the ‘Career Advice’ and related sections of your blog.")

#text("Sir, I am a high school student, and I aspire to become a mathematician. I wanted to know if research Mathematics is just as intuitive as high school level mathematics? Of course, the ability to develop an intuition for a certain concept depends on the person who is trying to do so. But is it always possible to develop an intuition at all?")

#text("And secondly, I wanted to know what is more important for mathematicians with respect to solving unsolved problems:")#linebreak()#text(" 1) Finding one of the possible solutions, or")#linebreak()#text(" 2) Finding an “elegant” solution.")#linebreak()#text(" (Here by elegant, I mean a solution which gives you such a deep insight into the problem, that the problem seems to be trivial, and intuitively true.)")

#text("Thanks a lot, Professor. You’re an inspiration and a source of enlightenment to many!")

#text("Yours truly,")#linebreak()#text(" Vatsal Srivastava.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ef91d7079d1e5ad1b455b15ba1a033e7ab34a6edcb3b0cea6226eb8c99a759e-d7190e757b9682f47e2cb103e5d40cc4d85f9bb799d50f8843e73d83e0c5f372.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dopemathblog")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495773")[#strong[#text("dopemathblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("In reference to Ex 21: How is L(m* (\\infity)) be the space of polynomials of degree at most m when m is negative? Are we thinking of rational functions as polynomials of negative degree? Or do polynomials have their usual definition- limited to positive, finite degree?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("By convention, the zero polynomial has degree ")#mi("-\\infty")#text(", all other constant polynomials have degree 0, and the remaining polynomials have positive degree. Other rational functions are not considered to be polynomials.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ef91d7079d1e5ad1b455b15ba1a033e7ab34a6edcb3b0cea6226eb8c99a759e-d7190e757b9682f47e2cb103e5d40cc4d85f9bb799d50f8843e73d83e0c5f372.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dopemathblog")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495831")[#strong[#text("dopemathblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("I see now…. The only possible principal divisors (f) such that (f) + m*(\\infinity) is effective are the divisors f for which f has no poles (i.e n=0 in the expansion of f given in Ex 13) Therefore, f = a(z- z1)…(z-zS) ) (f) = (1)z1 + …+(1)zS + -S*(\\infity). So that (f) + m*(\\infity) effective only when -S \\geq – m => S \\leq m. Thus f is a (pole-free) meromorphic function having total degree \\leq m. []")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495833")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2018")])]

#text("In Exercise 44, part i), “pole of order n at X” should apparently read “pole of order n at P”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-495959")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2018")])]

#text("In Definition 22 of a meromorphic 1 form, in the second paragraph regarding order of poles, it should state that $\\phi$ is a chart whose domain contains $P$, not $U.$")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("For exercise 28, the point [1,0,0] lies on the elliptic curve but is clearly not attained from the mapping (hence contradicting surjectivity). I assume there should be some reordering of the variables.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")])]

#text("Oops, you are right, ")#mi("z_1")#text(" and ")#mi("z_2")#text(" needed to be interchanged.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a177ba62708288984e92e0970581423cbb82467143dee4896ddc635c0aad9e4e-59d931430c23b27400728891eaa1cf7ab8e0e53ac004bccde74f84d98037279a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pallav Goyal")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496073")[#strong[#text("Pallav Goyal")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2018")])]

#text("In the sentence between Remark 15 and Corollary 16, you probably mean ")#mi("D\\geq 0")#text(" rather than ")#mi("D\\leq 0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496195")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2018")])]

#text("Can we find examples where ")#mi("\\dim L(D) > 1")#text(" ? I have been looking at Riemann surfaces $y^m = (x-a_1)(x-a_2)(x-a_3)(x – a_4)$ possibly with ")#mi("a_i \\in \\mathbb{R}")#text(". These examples I found in a paper of Curtis McMullen called “Braid Groups and Hodge Theory” seem to be related to the braid group.")

#text("Then maybe we could choose a divisor ")#mi("D = n(5) - (\\infty)")#text(". I still have to check your theorems to make sure that we don’t already have ")#mi("\\dim = 0")#text(" in those cases.")

#text("I can prove these are Riemann surfaces by using the projection map ")#mi("(x,y) \\to x")#text(" but this is only well-defined if we don’t cross certain line segments at the real axis. So I have a chart made of ")#mi("U_i = \\mathbb{C} \\backslash \\{\\text{ line segments} \\}")#text(". Unfortunately, computers aren’t nuanced enough to remember which sheet of the branch cover we are using and the sign jumps as I cross around the real axis. E.g. ")#mi("y = x^2")#text(" this is already a problem.")

#text("The idea is we have a wealth of examples of Holomorphic vector bundles. Which is crucial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("In exercise 41, what conditions should be placed on ")#mi("X")#text("? If ")#mi("X")#text(" is the Riemann sphere, then it seems that any point ")#mi("R")#text(" would have the property that ")#mi("(P) + (Q) - (R) - (\\infty)")#text(" is principal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496336")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Oops! The key assumption that the surface has genus 1 was omitted.")

#emph[#text("[Edit: I now realise that this exercise requires an additional assertion, namely that quasiconformal maps are absolutely continuous along lines, which is now included in the notes. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/812c4968c2829ebd771b1de0bc6f091a45091cde8239bdb623eed32c2b7c0242-fa5a85331892007a0612aa94d4088361a6d747dda3658cb448f2f56b38301898.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lexing Ying")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496328")[#strong[#text("Lexing Ying")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2018")])]

#text("Right after equation (6), should the divisor of the Weierstrass {p}-function be two poles plus two zeros? Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496382")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2018")])]

#text("Dear Prof. Tao,")

#text("As promised, I’m now reading the notes and will post any typos as I read along.")

#text("I’ve also noticed that each manifold is automatically ")#mi("T_1")#text(" (indeed locally Hausdorff implies ")#mi("T_1")#text(", but not Hausdorff, as can be seen by the line with doubled origin), so that one could require ")#mi("R_1")#text(" instead of Hausdorff.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496452")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("I was trying to prove that in fact, a compact, connected Hausdorff manifold was in fact diffeomorphic to a circle (I could handle the homeomorphic part, by using the argument that one may choose finitely many charts, eliminate superfluous charts, prove that the set of those elements not covered by any chart is a connected interval, and then define the homeomorphism using a closed, continuous, bijective loop). It seems as though we might use some convolution with some smooth kernel; monotonicity at the points where the loop was smooth before is preserved since the convolution of two positive functions is positive, and the remainder we do by continuity. (Note: Zero at an isolated point does not harm strict monotonicity.)")

#text("The definition of holomorphic atlases of course works in greater generality.")

#text("I read in the elementary book of M. Artin that there are a limited number of discrete groups in the plane. In fact, one can restrict to lattices in 0-d, 1-d and 2-d.")

#text("In example 2, the “plus” notation is bold and seems to indicate the standard action of ")#mi("(\\mathbb C, +)")#text(" on ")#mi("\\mathbb C / \\Lambda")#text(". The example seems to show that there are plenty holomorphic structures on a topological torus.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496470")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("In example 6, nonsingular curves are weirdly defined. There is a reference to “three numbers”, but only “two” or “four” gives a reasonable interpretation. (Neither seems enough to deduce that the gradient does not vanish in the case of interest, and they are further equivalent.) In order to get the gradient nonzero in the subsequent section, one needs that ")#mi("[z_1, z_2, 1]")#text(" is contained in the set of zeroes, I suppose?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496580")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Dear Prof. Tao, in example 13, it seems as though the extension of any meromorphic functions that have their singularities contained in a bounded set is meromorphic on ")#mi("\\mathbb C \\cup \\{\\infty\\}")#text(", for the simple reason that ")#mi("\\{\\infty\\}")#text(" is then a point isolated away from the other singularities. The argument given (theone about ")#mi("f(1/z)")#text(" seems to indicate that ")#mi("f")#text(" is a rational function in all charts of the atlas that we had constructed.")

#text("But very fun lecture notes!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496596")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Meromorphicity requires more than just having isolated singularities; these isolated singularities also need to be poles rather than essential singularities. For instance, the exponential function ")#mi("z \\mapsto \\exp(z)")#text(" is entire on the complex plane, but does not extend meromorphically to the Riemann sphere (using the chart variable ")#mi("w = 1/z")#text(" to analyse the behaviour near infinity, we obtain an essential singularity ")#mi("\\exp(1/w)")#text(" at the origin).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496618")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("How could I miss this? Of course!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-496619")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("Here’s a real typo: In the displaystyle equation before example 23 (in FF Strg+F gets you to the centered point) ")#mi("f")#text(" is not actually a function on ")#mi("\\phi(U)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adeb581848a0c77ec94d20cd7fda7dd266444bfb216e1c64569f68b054b4d197-7f92ba9a44cf79e8f911660d0f1f5514e07219fda8c3b2a451c28a28a6520dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Lawrence")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-498525")[#strong[#text("Scott Lawrence")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("In Exercise 17, perhaps it should say that $f$ and $g$ are both defined on a compact Riemann surface?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/adeb581848a0c77ec94d20cd7fda7dd266444bfb216e1c64569f68b054b4d197-7f92ba9a44cf79e8f911660d0f1f5514e07219fda8c3b2a451c28a28a6520dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Lawrence")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-498530")[#strong[#text("Scott Lawrence")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2018")])]

#text("Ah, this is implicit in the definition of divisor, of course. Apologies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98ef77b57cdc76efd829f7e4089989759391b0adba0f49b3d9e5055be7f470bc-797c3ced73b41e0b7342bb3c698b1cd535fb8df41b7662086e694f3a84c43095.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Stoller")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-511365")[#strong[#text("Martin Stoller")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("Thank You very much for these great notes, Prof. Tao, I learned a lot from them.")

#text("Some remarks:")

#text("In the proof of Riemann’s inequality, I think the intermediate claim that the dimension of L(K+D’) equals deg(D’) + g -1 should be replaced by the weaker claim that dim(L(K+D’)) is at least deg(D’) + g -1 (which is enough to prove the Proposition), because the kernel of the map T considered later only *contains* the space of holomorphic one forms, so has dimension at least g.")

#text("Just before Exercise 25, I think “meromorphic function” should be replaced by “meromorphic 1-form”.")

#text("In Lemma 27, part (ii), a minus sign is miss-typed. It should be dim(L(D)) = dim(L(-D)).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98ef77b57cdc76efd829f7e4089989759391b0adba0f49b3d9e5055be7f470bc-797c3ced73b41e0b7342bb3c698b1cd535fb8df41b7662086e694f3a84c43095.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Stoller")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-511374")[#strong[#text("Martin Stoller")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("Never mind about the first comment on Riemann’s inequality. No changes have to be made there. Apologies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-519205")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2019")])]

#text("In Example 2, line -3, it appears the U should be U_α.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/efa64c9c253f65a7d9cc17341c4b22ebef482e1440374dcc9f37da48992a6c01-adae0e3099b1eca8bd0752161d24380b97aab9790b1fa32b2687d7d9e5d3dd74.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Asimov")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-519206")[#strong[#text("Dan Asimov")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2019")])]

#text("I withdraw my comment.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08a7dbf0fc4f87d9dd7d9265b8d742254449560def99ea67f4a0bdffbedeff30-6357b353d4083e451e5adfb16009055f7689e1058db5dc6c29d9cb3641abf55b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Baez")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-519638")[#strong[#text("John Baez")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2019")])]

#text("A typo: “triangulartion”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of matemático joven")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-520293")[#strong[#text("matemático joven")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2019")])]

#text("One may also prove Liouville’s theorem from Lemma 11: If ")#mi("f: \\mathbb C \\to \\mathbb C")#text(" is entire, then the Riemann theorem on removable singularities implies that it extends to a holomorphic function on the compact Riemann surface ")#mi("X = S^2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f8f9f37deae6014403f0e3d90b6e8fd4f702ef87a40339ce282b089f68d1753-764e659d3dcfd8363df66f6d7b91ec47ab07718572de26278c8204df9758fd99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-581755")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2020")])]

#text("« … Stokes’ theorem we conclude that the integral of {\\gamma} around the sum of … » I guess you meant the integral of {\\omega} there.")

#text("(btw if anyone has trouble understanding this affirmation, it is detailed there ")#link("https://math.stackexchange.com/a/446273/23001")[#text("https://math.stackexchange.com/a/446273/23001")]#text(")")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/96801f2308e0cf703bb3c264e275af4a4bb564c65a75845636e01b0f8f1fc4c4-3be3ce581fb4eaafae815d897321e3eff572d30f82ed60bc5e783ae396731287.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-611151")[#strong[#text("Max")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2020")])]

#text("I appreciate that you took extra care in making the distinction between functions on the Riemann surface and their coordinate representations in a specific chart in defining meromorphic forms. It is distressingly common in books on Riemann surfaces to have something like ")#mi("f_{\\alpha} (z_{\\alpha}) dz_{\\alpha}")#text(", where ")#mi("f_{\\alpha}")#text(" is a function on an open set ")#mi("U_{\\alpha}")#text(", and ")#mi("z_{\\alpha} : U_{\\alpha} \\rightarrow \\mathbf{C}")#text(" is a chart map, and then launching into computations as if ")#mi("f_{\\alpha}")#text(" were a function defined on an open set in ")#mi("\\mathbf{C}")#text(". Why do you think this is so common, when it presents so much difficulties to the beginner?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 3: Elliptic functions and modular forms | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-621854")[#strong[#text("246B, Notes 3: Elliptic functions and modular forms | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2021")])]

#text("[…] law governing meromorphic functions on other compact Riemann surfaces (and is discussed further in these 246C notes). So far we have focused on studying a single torus . However, another important mathematical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-622833")[#strong[#text("246B, Notes 4: The Riemann zeta function and the prime number theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] Previous set of notes: Notes 3. Next set of notes: 246C Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-622836")[#strong[#text("246C notes 2: Circle packings, conformal maps, and quasiconformal maps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2021")])]

#text("[…] set of notes: Notes 1. Next set of notes: Notes 3. We now leave the topic of Riemann surfaces, and turn now to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b47a28c30c4c0a3eb17e4f5c11d9b165e5656434ca8f7453911b81e194106b32-dbc47055a1fb5f3b01bc0718aec9dec6f34aa903d241bd0c80477cbd4405ee27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georges Elencwajg")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-640656")[#strong[#text("Georges Elencwajg")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2022")])]

#text("Dear Terence,")#linebreak()#text(" thank you for this splendid synthesis in your inimitable style.")#linebreak()#text(" An infinitesimal nitpick: in Definition 2, line -4 the two equalities do not make sense because you cannot add alpha, an equivalence class of complex numbers, to a genuine complex number z (belonging to the open subset U of the complex plane).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-641335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("In section 2, “Formula does not parse” in the last sentence of:")

#text("On the other hand, several other basic notions in complex analysis do not seem to be well defined for such meromorphic functions. Consider for instance the question of how to define the residue of {f} at a pole {P}. The natural thing to do is to again pick a chart {\\phi_\\alpha} around {P} and use the residue of {f_\\alpha}; however one can check that this is not independent of the choice of chart in general, as from (4) one will find that the residues of {f_\\beta} and {f_\\alph} are related to each other, but not equal.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-641338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Are there simple examples showing integration of a 1-form ")#mi("\\int_\\gamma \\omega")#text(" coincides (does it?) with the complex integral ")#mi("\\int_\\gamma f(z)\\;dz")#text(" introduced in 246A?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-641339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Formally, it seems that one can simply let ")#mi("\\omega=f(z)dz")#text(" to connect these two notions.")

#text("You also mentioned “line integrals” are integral of forms in the set of 246A notes (Remark 19): ")#link("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")[#text("https://terrytao.wordpress.com/2016/09/27/246a-notes-2-complex-integration/")]

#text("I am wondering if that has anything to do with the integral here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-641342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2022")])]

#text("Yes, contour integrals can be viewed as an integral of a (complex) 1-form on the complex plane, at least when the contour is piecewise smooth. Contour integrals are also a special case of line integrals (writing ")#mi("dz = dx + idy")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3f8f9f37deae6014403f0e3d90b6e8fd4f702ef87a40339ce282b089f68d1753-764e659d3dcfd8363df66f6d7b91ec47ab07718572de26278c8204df9758fd99.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-674058")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2023")])]

#text("After equation (6), you say *this descends to a meromorphic function on … with divisor …* and mention a divisor which has degree 2 (just after you proved it should have degree 0, which is confusing).")#linebreak()#text(" I suppose the Weierstrass function must have zeroes somewhere…")

#emph[#text("[Typos corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-677565")[#strong[#text("Facts about divisors on a compact Riemann surface – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")]

#text("[…] am trying to prove the following question from here without relying on the Riemann-Roch […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-677570")[#strong[#text("Question about divisors on a compact Riemann surface – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")]

#text("[…] am trying to prove the following question from here without relying on the Riemann-Roch […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06079f64bde638eca956aa7ba427ca00d9ce60b0d8cf7c3e4bf65cf236e253b3-2031b3d39a0be92981bc72255e8d52d939b7a82893d42ca02c31cdf463d09a15.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2018/03/28/246c-notes-1-meromorphic-functions-on-riemann-surfaces-and-the-riemann-roch-theorem/#comment-677571")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2023")])]

#text("Dear Professor Tao,")

#text("Beginning on line 3 of lemma 27, you wrote that “…that is to say a simple pole at {P} and a simple zero at {Q}. But this follows from Proposition 24(i) (and identifying meromorphic functions with meromorphic {1}-forms) since the residue at {P} is non-zero.” Do you mean to write “a simple zero at {P} and a simple pole at {Q}” and “the residue at {Q} is non-zero” for the divisor D = (P) – (Q)? I would be thankful if you could point out if I am confusing myself. Thank you")

#emph[#text("[This was a typo, now corrected, thanks – T.]")]
]
