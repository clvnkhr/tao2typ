// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/
// Converted to Typst by tao2typ: "2026-10-14T15:17:04.198695+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Tricks Wiki: Give yourself an epsilon of room", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Tricks Wiki: Give yourself an epsilon of room")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")[#text("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Today I’d like to discuss (in the ")#link("http://gowers.wordpress.com/2008/11/28/very-brief-tricki-update/")[#text("Tricks Wiki")]#text(" format) a fundamental trick in “")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("soft")]#text("” analysis, sometimes known as the “limiting argument” or “epsilon regularisation argument”.")

#strong[#text("Title")]#text(": Give yourself an epsilon of room.")

#strong[#text("Quick description")]#text(": You want to prove some statement ")#mi("S_0")#text(" about some object ")#mi("x_0")#text(" (which could be a number, a point, a function, a set, etc.). To do so, pick a small ")#mi("\\varepsilon > 0")#text(", and first prove a weaker statement ")#mi("S_\\varepsilon")#text(" (which allows for “losses” which go to zero as ")#mi("\\varepsilon \\to 0")#text(") about some perturbed object ")#mi("x_\\varepsilon")#text(". Then, take limits ")#mi("\\varepsilon \\to 0")#text(". Provided that the dependency and continuity of the weaker conclusion ")#mi("S_\\varepsilon")#text(" on ")#mi("\\varepsilon")#text(" are sufficiently controlled, and ")#mi("x_\\varepsilon")#text(" is converging to ")#mi("x_0")#text(" in an appropriately strong sense, you will recover the original statement.")

#text("One can of course play a similar game when proving a statement ")#mi("S_\\infty")#text(" about some object ")#mi("X_\\infty")#text(", by first proving a weaker statement ")#mi("S_N")#text(" on some approximation ")#mi("X_N")#text(" to ")#mi("X_\\infty")#text(" for some large parameter N, and then send ")#mi("N \\to \\infty")#text(" at the end.")

#strong[#text("General discussion: ")]#text("Here are some typical examples of a target statement ")#mi("S_0")#text(", and the approximating statements ")#mi("S_\\varepsilon")#text(" that would converge to ")#mi("S")#text(":")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#mi("S_0")],
table.cell(colspan: 1, rowspan: 1)[#mi("S_\\varepsilon")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_0) = g(x_0)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_\\varepsilon) = g(x_\\varepsilon) + o(1)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_0) \\leq g(x_0)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_\\varepsilon) \\leq g(x_\\varepsilon) + o(1)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_0) > 0")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_\\varepsilon) \\geq c - o(1)")#text(" for some ")#mi("c>0")#text(" independent of ")#mi("\\varepsilon")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_0)")#text(" is finite")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_\\varepsilon)")#text(" is bounded uniformly in ")#mi("\\varepsilon")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_0) \\geq f(x)")#text(" for all ")#mi("x \\in X")#text(" (i.e. ")#mi("x_0")#text(" maximises f)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f(x_\\varepsilon) \\geq f(x)-o(1)")#text(" for all ")#mi("x \\in X")#text(" (i.e. ")#mi("x_\\varepsilon")#text(" nearly maximises f)")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_n(x_0)")#text(" converges as ")#mi("n \\to \\infty")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_n(x_\\varepsilon)")#text(" fluctuates by at most o(1) for sufficiently large n")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_0")#text(" is a measurable function")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_\\varepsilon")#text(" is a measurable function converging pointwise to ")#mi("f_0")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_0")#text(" is a continuous function")],
table.cell(colspan: 1, rowspan: 1)[#mi("f_\\varepsilon")#text(" is an ")#link("http://en.wikipedia.org/wiki/Equicontinuity")[#text("equicontinuous")]#text(" family of functions converging pointwise to ")#mi("f_0")#text(" ")#strong[#text("OR")]#text(" ")#mi("f_\\varepsilon")#text(" is continuous and converges (locally) uniformly to ")#mi("f_0")],
table.cell(colspan: 1, rowspan: 1)[#text("The event ")#mi("E_0")#text(" holds almost surely")],
table.cell(colspan: 1, rowspan: 1)[#text("The event ")#mi("E_\\varepsilon")#text(" holds with probability 1-o(1)")],
table.cell(colspan: 1, rowspan: 1)[#text("The statement ")#mi("P_0(x)")#text(" holds for almost every x")],
table.cell(colspan: 1, rowspan: 1)[#text("The statement ")#mi("P_\\varepsilon(x)")#text(" holds for x outside of a set of measure o(1)")]
)

#text("Of course, to justify the convergence of ")#mi("S_\\varepsilon")#text(" to ")#mi("S_0")#text(", it is necessary that ")#mi("x_\\varepsilon")#text(" converge to ")#mi("x_0")#text(" (or ")#mi("f_\\varepsilon")#text(" converge to ")#mi("f_0")#text(", etc.) in a suitably strong sense. (But for the purposes of proving just ")#emph[#text("upper")]#text(" bounds, such as ")#mi("f(x_0) \\leq M")#text(", one can often get by with quite weak forms of convergence, thanks to tools such as Fatou’s lemma or the weak closure of the unit ball.) Similarly, we need some continuity (or at least ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("semi-continuity")]#text(") hypotheses on the functions f, g appearing above.")

#text("It is also necessary in many cases that the control ")#mi("S_\\varepsilon")#text(" on the approximating object ")#mi("x_\\varepsilon")#text(" is somehow “uniform in ")#mi("\\varepsilon")#text("“, although for “")#mi("\\sigma")#text("-closed” conclusions, such as measurability, this is not required. [It is important to note that it is only the ")#emph[#text("final")]#text(" conclusion ")#mi("S_\\varepsilon")#text(" on ")#mi("x_\\varepsilon")#text(" that needs to have this uniformity in ")#mi("\\varepsilon")#text("; one is permitted to have some intermediate stages in the derivation of ")#mi("S_\\varepsilon")#text(" that depend on ")#mi("\\varepsilon")#text(" in a non-uniform manner, so long as these non-uniformities cancel out or otherwise disappear at the end of the argument.]")

#text("By giving oneself an epsilon of room, one can evade a lot of familiar issues in soft analysis. For instance, by replacing “rough”, “infinite-complexity”, “continuous”, “global”, or otherwise “infinitary” objects ")#mi("x_0")#text(" with “smooth”, “finite-complexity”, “discrete”, “local”, or otherwise “finitary” approximants ")#mi("x_\\varepsilon")#text(", one can finesse most issues regarding the justification of various formal operations (e.g. exchanging limits, sums, derivatives, and integrals). [It is important to be aware, though, that any quantitative measure on how smooth, discrete, finite, etc. ")#mi("x_\\varepsilon")#text(" should be expected to degrade in the limit ")#mi("\\varepsilon \\to 0")#text(", and so one should take extreme caution in using such quantitative measures to derive estimates that are uniform in ")#mi("\\varepsilon")#text(".] Similarly, issues such as whether the supremum ")#mi("M := \\sup \\{ f(x): x \\in X \\}")#text(" of a function on a set is actually attained by some maximiser ")#mi("x_0")#text(" become moot if one is willing to settle instead for an almost-maximiser ")#mi("x_\\varepsilon")#text(", e.g. one which comes within an epsilon of that supremum M (or which is larger than ")#mi("1/\\varepsilon")#text(", if M turns out to be infinite). Last, but not least, one can use the epsilon room to avoid degenerate solutions, for instance by perturbing a non-negative function to be strictly positive, perturbing a non-strictly monotone function to be strictly monotone, and so forth.")

#text("To summarise: one can view the epsilon regularisation argument as a “loan” in which one borrows an epsilon here and there in order to be able to ignore soft analysis difficulties, and can temporarily be able to utilise estimates which are non-uniform in epsilon, but at the end of the day one needs to “pay back” the loan by establishing a final “hard analysis” estimate which is uniform in epsilon (or whose error terms decay to zero as epsilon goes to zero).")

#strong[#text("A variant:")]#text(" It may seem that the epsilon regularisation trick is useless if one is already in “hard analysis” situations when all objects are already “finitary”, and all formal computations easily justified. However, there is an important variant of this trick which applies in this case: namely, instead of sending the epsilon parameter to zero, choose epsilon to be a ")#emph[#text("sufficiently")]#text(" small (but not ")#emph[#text("infinitesimally")]#text(" small) quantity, depending on other parameters in the problem, so that one can eventually neglect various error terms and to obtain a useful bound at the end of the day. (For instance, any result proven using the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemerédi regularity lemma")]#text(" is likely to be of this type.) Since one is not sending epsilon to zero, not every term in the final bound needs to be uniform in epsilon, though for quantitative applications one still would like the dependencies on such parameters to be as favourable as possible.")

#strong[#text("Prerequisites")]#text(": Graduate real analysis. (Actually, this isn’t so much a prerequisite as it is a ")#emph[#text("corequisite")]#text(": the limiting argument plays a central role in many fundamental results in real analysis.) Some examples also require some exposure to PDE.")

#metadata(none) <tao-cbb3aed321803c8eb4db>

#strong[#text("Example 0.")]#text(" The “soft analysis” components of any real analysis textbook will contain a large number of examples of this trick in action. In particular, any argument which exploits ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s three principles of real analysis")]#text(" is likely to utilise this trick. Of course, this trick will also occur repeatedly in ")#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("my 245B lecture notes")]#text(". ")#mi("\\diamond")

#strong[#text("Example 1.")]#text(" (")#link("http://en.wikipedia.org/wiki/Riemann-Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text(") Given any ")#link("http://en.wikipedia.org/wiki/Absolutely_integrable")[#text("absolutely integrable function")]#text(" ")#mi("f \\in L^1({\\Bbb R})")#text(", the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("\\hat f: {\\Bbb R} \\to {\\Bbb C}")#text(" is defined by the formula")

#align(center)[#mi("\\displaystyle \\hat f(\\xi) := \\int_{\\Bbb R} f(x) e^{-2\\pi i x \\xi}\\ dx")#text(".")]

#text("The ")#emph[#text("Riemann-Lebesgue lemma")]#text(" asserts that ")#mi("\\hat f(\\xi) \\to 0")#text(" as ")#mi("\\xi \\to \\infty")#text(". It is difficult to prove this estimate for f directly, because this function is too “rough”: it is absolutely integrable (which is enough to ensure that ")#mi("\\hat f")#text(" exists and is bounded), but need not be continuous, differentiable, compactly supported, bounded, or otherwise “nice”. But suppose we give ourselves an epsilon of room. Then, as the space ")#mi("C^\\infty_0")#text(" of test functions is dense in ")#mi("L^1({\\Bbb R})")#text(" (a fact I will prove later in ")#link("https://terrytao.wordpress.com/category/teaching/245b-real-analysis/")[#text("this course")]#text("), we can approximate ")#mi("f")#text(" to any desired accuracy ")#mi("\\varepsilon > 0")#text(" in the ")#mi("L^1")#text(" norm by a smooth, compactly supported function ")#mi("f_\\varepsilon: {\\Bbb R} \\to {\\Bbb C}")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_{\\Bbb R} |f(x)-f_\\varepsilon(x)|\\ dx \\leq \\varepsilon.")]]

#text("The point is that ")#mi("f_\\varepsilon")#text(" is much better behaved than f, and it is not difficult to show the analogue of the Riemann-Lebesgue lemma for ")#mi("f_\\varepsilon")#text(". Indeed, being smooth and compactly supported, we can now justifiably integrate by parts to obtain")

#align(center)[#tao-fit-display[#mitex("\\hat f_\\varepsilon(\\xi) = \\frac{1}{2\\pi i \\xi} \\int_{\\Bbb R} f^{\\prime}_\\varepsilon(x) e^{-2\\pi i x \\xi}\\ dx")]]

#text("for any non-zero ")#mi("\\xi")#text(", and it is now clear (since ")#mi("f^{\\prime}")#text(" is bounded and compactly supported) that ")#mi("\\hat f_\\varepsilon(\\xi) \\to 0")#text(" as ")#mi("\\xi \\to \\infty")#text(".")

#text("Now we need to take limits as ")#mi("\\varepsilon \\to 0")#text(". It will be enough to have ")#mi("\\hat f_\\varepsilon")#text(" converge uniformly to ")#mi("\\hat f")#text(". But from (1) and the basic estimate")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\sup_\\xi \\left|\\hat g(\\xi)\\right| \\leq \\int_{\\Bbb R} |g(x)|\\ dx", block: true)]]

#text("(which is the single “hard analysis” ingredient in the proof of the lemma) applied to ")#mi("g := f - f_\\varepsilon")#text(", we see (by the linearity of the Fourier transform) that")

#align(center)[#tao-fit-display[#tao-math("\\sup_\\xi \\left|\\hat f(\\xi) - \\hat f_\\varepsilon(\\xi)\\right| \\leq \\varepsilon", block: true)]]

#text("and we obtain the desired uniform convergence. ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" The same argument also shows that ")#mi("\\hat f")#text(" is continuous; we leave this as an exercise to the reader. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Example 1 is a model case of a much more general instance of the limiting argument: in order to prove a convergence or continuity theorem for all “rough” functions in a function space, it suffices to first prove convergence or continuity for a dense subclass of “smooth” functions, and combine that with some quantitative estimate in the function space (in this case, (2)) in order to justify the limiting argument. ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" The limiting argument in Example 1 relied on the linearity of the Fourier transform ")#mi("f \\mapsto \\hat f")#text(". But, with more effort, it is also possible to extend this type of argument to nonlinear settings. We will sketch (omitting several technical details, which can be found for instance in my ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("PDE book")]#text(") a very typical instance. Consider a nonlinear PDE, e.g. the nonlinear wave equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("- u_{tt} + u_{xx} = u^3")]]

#text("where ")#mi("u: {\\Bbb R} \\times {\\Bbb R} \\to {\\Bbb R}")#text(" is some scalar field, and the t and x subscripts denote differentiation of the field ")#mi("u(t,x)")#text(". Formally – if u is sufficiently smooth, and sufficiently decaying at spatial infinity, one can show that the energy")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("E(u)(t) := \\int_{\\Bbb R} \\frac{1}{2} \\left|u_t(t,x)\\right|^2 + \\frac{1}{2} \\left|u_x(t,x)\\right|^2 + \\frac{1}{4} \\left|u(t,x)\\right|^4\\ dx", block: true)]]

#text("is conserved, thus ")#mi("E(u)(t) = E(u)(0)")#text(" for all t. This can be formally justified by computing the derivative ")#mi("\\partial_t E(u)(t)")#text(" by ")#link("http://en.wikipedia.org/wiki/Differentiation_under_the_integral_sign")[#text("differentiating under the integral sign")]#text(", integrating by parts, and then applying the PDE (3); we leave this as an exercise for the reader. (There are also more fancy ways to see why the energy is conserved, using ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian")]#text(" or ")#link("http://en.wikipedia.org/wiki/Lagrangian_mechanics")[#text("Lagrangian")]#text(" mechanics or by the more general theory of ")#link("http://en.wikipedia.org/wiki/Stress-energy_tensor")[#text("stress-energy tensors")]#text(", but we will not discuss these here.) However, these justifications do require a fair amount of regularity on the solution u; for instance, requiring u to be three-times continuously differentiable in space and time, and compactly supported in space on each bounded time interval, would be sufficient to make the computations rigorous by applying “off the shelf” theorems about differentiation under the integration sign, etc.")

#text("But suppose one only has a much rougher solution, for instance an ")#emph[#text("energy class solution")]#text(" which has finite energy (4), but for which higher derivatives of u need not exist in the classical sense. (There is a non-trivial issue regarding how to make sense of the PDE (3) when u is only in the energy class, since the terms ")#mi("u_{tt}")#text(" and ")#mi("u_{xx}")#text(" do not then make sense classically, but there are standard ways to deal with this, e.g. using ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivatives")]#text(", which we will not discuss further here.) Then it is difficult to justify the energy conservation law directly. However, it is still possible to obtain energy conservation by the limiting argument. Namely, one takes the energy class solution u at some initial time (e.g. t=0) and approximates that initial data (the initial position ")#mi("u(0)")#text(" and initial data ")#mi("u_t(0)")#text(") by a much smoother (and compactly supported) choice ")#mi("(u^{(\\varepsilon)}(0), u^{(\\varepsilon)}_t(0))")#text(" of initial data, which converges back to ")#mi("(u(0), u_t(0))")#text(" in a suitable “energy topology” related to (4) which we will not define here. It then turns out (from the existence theory of the PDE (3)) that one can extend the smooth initial data ")#mi("(u^{(\\varepsilon)}(0), u^{(\\varepsilon)}_t(0))")#text(" to other times t, providing a smooth solution ")#mi("u^{(\\varepsilon)}")#text(" to that data. For this solution, the energy conservation law ")#mi("E( u^{(\\varepsilon)} )(t) = E( u^{(\\varepsilon)} )(0)")#text(" can be justified.")

#text("Now we take limits as ")#mi("\\varepsilon \\to 0")#text(" (keeping t fixed). Since ")#mi("(u^{(\\varepsilon)}(0), u^{(\\varepsilon)}_t(0))")#text(" converges in the energy topology to ")#mi("(u(0), u_t(0))")#text(", and the energy functional E is continuous in this topology, ")#mi("E( u^{(\\varepsilon)} )(0)")#text(" converges to ")#mi("E( u )(0)")#text(". To conclude the argument, we will also need ")#mi("E( u^{(\\varepsilon)} )(t)")#text(" to converge to ")#mi("E( u )(t)")#text(", which will be possible if ")#mi("(u^{(\\varepsilon)}(t), u^{(\\varepsilon)}_t(t))")#text(" converges in the energy topology to ")#mi("(u(t), u_t(t))")#text(". Thus in turn follows from a fundamental fact (which requires a certain amount of effort to prove) about the PDE to (4), namely that it is ")#link("http://en.wikipedia.org/wiki/Well-posed_problem")[#emph[#text("well-posed")]]#text(" in the energy class. This means that not only do solutions exist and are unique for initial data in the energy class, but they depend continuously on the initial data in the energy topology; small perturbations in the data lead to small perturbations in the solution, or more formally that the map ")#mi("(u(0),u_t(0)) \\to (u(t),u_t(t))")#text(" from data to solution (say, at some fixed time t) is continuous in the energy topology. This final fact concludes the limiting argument and gives us the desired conservation law ")#mi("E(u(t)) = E(u(0))")#text(". ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" It is important that one have a suitable well-posedness theory in order to make the limiting argument work for rough solutions to a PDE; without such a well-posedness theory, it is possible for quantities which are formally conserved to cease being conserved when the solutions become too rough or otherwise “weak”; energy, for instance, could disappear into a singularity and not come back. ")#mi("\\diamond")

#strong[#text("Example 3.")]#text(" (Maximum principle) The ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" is a fundamental tool in elliptic and parabolic PDE (for example, it is used heavily in the proof of the Poincaré conjecture, see e.g. my ")#link("https://terrytao.wordpress.com/2008/04/04/285g-lecture-3-the-maximum-principle-and-the-pinching-phenomenon/")[#text("lecture notes on this topic")]#text("). Here is a model example of this principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("u: \\overline{\\Bbb D} \\to {\\Bbb R}")#text(" be a smooth harmonic function on the closed unit disk ")#mi("\\overline{\\Bbb D} := \\{ (x,y): x^2+y^2 \\leq 1\\}")#text(". If M is a bound such that ")#mi("u(x,y) \\leq M")#text(" on the boundary ")#mi("\\partial{\\Bbb D} := \\{ (x,y): x^2+y^2 = 1 \\}")#text(". Then ")#mi("u(x,y) \\leq M")#text(" on the interior as well.")
]

#text("A naive attempt to prove Proposition 1 comes ")#emph[#text("very")]#text(" close to working, and goes like this: suppose for contradiction that the proposition failed, thus u exceeds M somewhere in the interior of the disk. Since u is continuous, and the disk is compact, there must then be a point ")#mi("(x_0,y_0)")#text(" in the interior of the disk where the maximum is attained. Undergraduate calculus then tells us that ")#mi("u_{xx}(x_0,y_0)")#text(" and ")#mi("u_{yy}(x_0,y_0)")#text(" are non-positive, which ")#emph[#text("almost")]#text(" contradicts the harmonicity hypothesis ")#mi("u_{xx} + u_{yy} = 0")#text(". However, it is still possible that ")#mi("u_{xx}")#text(" and ")#mi("u_{yy}")#text(" both vanish at ")#mi("(x_0,y_0)")#text(", so we don’t yet get a contradiction.")

#text("But we can finish the proof by giving ourselves an epsilon of room. The trick is to work not with the function u directly, but with the modified function ")#mi("u^{(\\varepsilon)}(x,y) := u(x,y) + \\varepsilon (x^2+y^2)")#text(", to boost the harmonicity into ")#link("http://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonicity")]#text(". Indeed, we have ")#mi("u^{(\\varepsilon)}_{xx} + u^{(\\varepsilon)}_{yy} = 4\\varepsilon > 0")#text(". The preceding argument now shows that ")#mi("u^{(\\varepsilon)}")#text(" cannot attain its maximum in the interior of the disk; since it is bounded by ")#mi("M+\\varepsilon")#text(" on the boundary of the disk, we we conclude that ")#mi("u^{(\\varepsilon)}")#text(" is bounded by ")#mi("M + \\varepsilon")#text(" on the interior of the disk as well. Sending ")#mi("\\varepsilon \\to 0")#text(" we obtain the claim. ")#mi("\\diamond")

#strong[#text("Remark 4.")]#text(" Of course, Proposition 1 can also be proven by much more direct means, for instance via the Green’s function for the disk. However, the argument given is extremely robust and applies to a large class of both linear and nonlinear elliptic and parabolic equations, including those with rough variable coefficients. ")#mi("\\diamond")

#strong[#text("Exercise 1")]#text(". Use the ")#link("http://en.wikipedia.org/wiki/Maximum_modulus_principle")[#text("maximum modulus principle")]#text(" to prove the ")#link("http://en.wikipedia.org/wiki/Phragm%C3%A9n-Lindel%C3%B6f_principle")[#text("Phragmén-Lindelöf principle")]#text(": if f is complex analytic on the strip ")#mi("\\{ z: 0 \\leq \\text{Re}(z) \\leq 1\\}")#text(", is bounded in magnitude by 1 on the boundary of this strip, and obeys a growth condition ")#tao-math("\\left|f(z)\\right| \\leq C e^{\\left|z\\right|^C}", block: false)#text(" on the interior of the strip, then show that f is bounded in magnitude by 1 throughout the strip. (")#emph[#text("Hint")]#text(": multiply f by ")#mi("e^{-\\varepsilon z^m}")#text(" for some even integer m.) ")#mi("\\diamond")

#strong[#text("Example 4.")]#text(" (Manipulating generalised functions) In PDE one is primarily interested in smooth (classical) solutions; but for a variety of reasons it is useful to also consider rougher solutions. Sometimes, these solutions are so rough that they are no longer functions, but are measures, ")#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")[#text("distributions")]#text(", or some other concept of “")#link("http://en.wikipedia.org/wiki/Generalized_function")[#text("generalised function")]#text("” or “")#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/")[#text("generalised solution")]#text("“. For instance, the fundamental solution to a PDE is typically just a distribution or measure, rather than a classical function. A typical example: a (sufficiently smooth) solution to the three-dimensional wave equation ")#mi("-u_{tt} + \\Delta u = 0")#text(" with initial position ")#mi("u(0,x)=0")#text(" and initial velocity ")#mi("u_t(0,x) = g(x)")#text(" is given by the classical formula")

#align(center)[#tao-fit-display[#mitex("u(t) = t g * \\sigma_t")]]

#text("where ")#mi("\\sigma_t")#text(" is the unique rotation-invariant probability measure on the sphere ")#mi("S_t := \\{ (x,y,z) \\in {\\Bbb R}^3: x^2+y^2+z^2 = t^2 \\}")#text(" of radius t, or equivalently, the ")#link("http://en.wikipedia.org/wiki/Area_element")[#text("area element")]#text(" dS on that sphere divided by the surface area ")#mi("4\\pi t^2")#text(" of that sphere. (The ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" ")#mi("f*\\mu")#text(" of a smooth function ")#mi("f")#text(" and a (compactly supported) finite measure ")#mi("\\mu")#text(" is defined by ")#mi("f*\\mu(x) := \\int f(x-y)\\ d\\mu(y)")#text(".)")

#text("For this and many other reasons, it is important to manipulate measures and distributions in various ways. For instance, in addition to convolving functions with measures, it is also useful to convolve measures with measures; the convolution ")#mi("\\mu * \\nu")#text(" of two finite measures on ")#mi("{\\Bbb R}^n")#text(" is defined as the measure which assigns to each measurable set E in ")#mi("{\\Bbb R}^n")#text(", the measure")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\mu * \\nu(E) := \\int \\int 1_E(x + y)\\ d\\mu(x) d\\nu(y).")]]

#text("For sake of concreteness, let’s focus on a specific question, namely to compute (or at least estimate) the measure ")#mi("\\sigma * \\sigma")#text(", where ")#mi("\\sigma")#text(" is the normalised rotation-invariant measure on the unit circle ")#tao-math("\\{ x \\in {\\Bbb R}^2: \\left|x\\right|=1 \\}", block: false)#text(". It turns out that while ")#mi("\\sigma")#text(" is not absolutely continuous with respect to Lebesgue measure ")#mi("m")#text(", the convolution is: ")#mi("d(\\sigma*\\sigma) = f d m")#text(" for some absolutely integrable function f on ")#mi("{\\Bbb R}^2")#text(". But what is this function f? It certainly is possible to compute it from the definition (5), or by other methods (e.g. the Fourier transform), but I would like to give one approach to computing these sorts of expressions involving measures (or other generalised functions) based on epsilon regularisation, which requires a certain amount of geometric computation but which I find to be rather visual and conceptual, compared to more algebraic approaches (e.g. based on Fourier transforms). The idea is to approximate a singular object, such as the singular measure ")#mi("\\sigma")#text(", by a smoother object ")#mi("\\sigma_\\varepsilon")#text(", such as an absolutely continuous measure. For instance, one can approximate ")#mi("\\sigma")#text(" by")

#align(center)[#tao-fit-display[#mitex("d\\sigma_\\varepsilon := \\frac{1}{m(A_\\varepsilon)} 1_{A_\\varepsilon}\\ dm")]]

#text("where ")#tao-math("A_\\varepsilon := \\{ x \\in {\\Bbb R}^2: 1-\\varepsilon \\leq \\left|x\\right| \\leq 1+\\varepsilon \\}", block: false)#text(". It is clear that ")#mi("\\sigma_\\varepsilon")#text(" converges to ")#mi("\\sigma")#text(" in the ")#link("http://en.wikipedia.org/wiki/Vague_topology")[#text("vague topology")]#text(", which implies that ")#mi("\\sigma_\\varepsilon * \\sigma_\\varepsilon")#text(" converges to ")#mi("\\sigma*\\sigma")#text(" in the vague topology also. Since")

#align(center)[#mi("\\displaystyle \\sigma_\\varepsilon * \\sigma_\\varepsilon = \\frac{1}{m(A_\\varepsilon)^2} 1_{A_\\varepsilon} * 1_{A_\\varepsilon}\\ dm")#text(",")]

#text("we will be able to understand the limit f by first considering the function")

#align(center)[#tao-fit-display[#mitex("f_\\varepsilon(x) := \\frac{1}{m(A_\\varepsilon)^2} 1_{A_\\varepsilon} * 1_{A_\\varepsilon}(x) = \\frac{m( A_\\varepsilon \\cap (x - A_\\varepsilon))}{m(A_\\varepsilon)^2}")]]

#text("and then taking (weak) limits as ")#mi("\\varepsilon \\to 0")#text(" to recover f.")

#text("Up to constants, one can compute from elementary geometry that ")#mi("m(A_\\varepsilon)")#text(" is comparable to ")#mi("\\varepsilon")#text(", and ")#mi("m( A_\\varepsilon \\cap (x - A_\\varepsilon))")#text(" vanishes for ")#tao-math("\\left|x\\right| \\geq 2 + 2 \\varepsilon", block: false)#text(", and is comparable to ")#tao-math("\\varepsilon^2 (2-\\left|x\\right|)^{-1/2}", block: false)#text(" for ")#tao-math("1 \\leq \\left|x\\right| \\leq 2 - 2 \\varepsilon", block: false)#text(" (and of size ")#mi("O(\\varepsilon^{3/2})")#text(" in the transition region ")#tao-math("\\left|x\\right| = 2 + O(\\varepsilon)", block: false)#text(") and is comparable to ")#tao-math("\\varepsilon^2 \\left|x\\right|^{-1}", block: false)#text(" for ")#tao-math("\\varepsilon \\leq \\left|x\\right| \\leq 1", block: false)#text(" (and of size about ")#mi("O(\\varepsilon)")#text(" when ")#tao-math("\\left|x\\right| \\leq \\varepsilon", block: false)#text(". (This is a good exercise for anyone who wants practice in quickly computing the orders of magnitude of geometric quantities such as areas; for such order of magnitude calculations, quick and dirty geometric methods tend to work better here than the more algebraic calculus methods you would have learned as an undergraduate.) The bounds here are strong enough to allow one to take limits and conclude what f looks like: it is comparable to ")#tao-math("\\left|x\\right|^{-1} (2-\\left|x\\right|)^{-1/2} 1_{\\left|x\\right| \\leq 2}", block: false)#text(". And by being more careful with the computations of area, one can compute the exact formula for f(x), though I will not do so here. ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" Epsilon regularisation also sheds light on why certain operations on measures or distributions are not permissible. For instance, squaring the ")#link("http://en.wikipedia.org/wiki/Dirac_delta_function")[#text("Dirac delta function")]#text(" ")#mi("\\delta")#text(" will not give a measure or distribution, because if one looks at the squares ")#mi("\\delta_\\varepsilon^2")#text(" of some smoothed out approximations ")#mi("\\delta_\\varepsilon")#text(" to the Dirac function (i.e. ")#link("http://en.wikipedia.org/wiki/Approximation_to_the_identity")[#text("approximations to the identity")]#text("), one sees that their masses go to infinity in the limit ")#mi("\\varepsilon \\to 0")#text(", and so cannot be integrated against test functions uniformly in ")#mi("\\varepsilon")#text(". On the other hand, derivatives of the delta function, while no longer measures (the total variation of derivatives of ")#mi("\\delta_\\varepsilon")#text(" become unbounded), are at least still distributions (the integrals of derivatives of ")#mi("\\delta_\\varepsilon")#text(" against test functions remain convergent). ")#mi("\\diamond")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36213")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("In the last paragraph of Example 3 you mean 4 epsilon rather than – 4 epsilon. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/951516ab72f8eb7e1f0e5e8704dfba7b644383ab92421ee28d997a0921673a9c-4b054f158dec8d55eb32281674b0ca879dfb2ab9a4d79ab87ace095e613c8875.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dima")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36214")[#strong[#text("Dima")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("In real algebraic geometry the ")#mi("\\epsilon")#text("-trick is pushed even further – one works over the field of real Puiseax series ")#mi("\\mathbb{R}\\langle\\epsilon\\rangle=\\{\\sum_{k\\geq k_0} a_k\\epsilon^{k/q}\\mid q,k_0\\in\\mathbb{Z}, q>0, a_k\\in\\mathbb{R}\\},")#text(" i.e. formal rational-power sums, with the order induced by ")#mi("0<\\epsilon< r")#text(" for all ")#mi("0<r\\in\\mathbb{R}.")#text(" Justifying that the usual real analysis results hold over such a field can be done by Tarski’s transfer argument.")#linebreak()#text(" An advantage is that exact computer algebra procedures can work with such objects, and then the final step of taking the limit ")#mi("\\epsilon\\to 0")#text(" is pure (algorithmic, too) algebra. This is all described in great detail in a recent book by S.Basu, R.Pollack, and M.-F.Roy “Algorithms in real algebraic geometry”, that has a free ")#link("http://www.math.purdue.edu/~sbasu/bpr-posted1.html")[#text("online version")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of less than epsilon")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36220")[#strong[#text("less than epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Thank you very much Prof. Tao for your wonderful post. I hope that you write some notes on ”generalized functions” and ”weak solutions of PDE”, too. You explain very well and it is very difficult to find such explanations in usuall text books or research papers.")

#text("Thanks again…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36221")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Dear less than epsilon:")

#text("Actually, I happen to have articles on these very topics at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/")[#text("PCM article: Generalised solutions")]
]

#text("and")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")[#text("PCM article: Distributions")]
]

#text("I also plan to cover distributions in my class next quarter.")

#text("Dear Dima: Thanks for the comment! This trick you mention reminds me of the trick of adjoining a nonstandard infinitesimal ")#mi("\\varepsilon")#text(" to the real number system, and then setting it to zero as a substitute for the usual limit process. Incidentally, the link to download the book you mention seems to not be working right now, but this could be a temporary issue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of less than epsilon")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36227")[#strong[#text("less than epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("Dear Prof. Tao,")

#text("I have read your articles on ”distributions” and ” generalized solutions”.")

#text("Thank you very much.")#linebreak()#text(" I am wondering whether you have written any notes on stochastic partial differential equations. I am working on this field for my Ph.D and it is really very confusing. Adding ”white noise” or ” space-time white noise” in a PDE, namely making the equation stochastic changes the story. But I have not found a nice paper so far on this topic which explains why we are adding noise, what the meaning of ”white noise” or ”space-time white noise” is, what the meaning of the solution is.")

#text("I hope you have already some notes on SPDE or one day you write and clarify our mind.")

#text("We appreciate your help for math community.")

#text("Thanks,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36236")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("I had problems downloading the book from that page; this page")

#link("http://perso.univ-rennes1.fr/marie-francoise.roy/bpr-posted1.html")[#text("http://perso.univ-rennes1.fr/marie-francoise.roy/bpr-posted1.html")]

#text("should work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36239")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("Dear less than epsilon,")

#text("you may try looking at some of the “classical” books in the field, such as")

#text("G. Da Prato and J. Zabczyk, Stochastic equations in infinite dimensions, Cambridge UP 1992")

#text("B. Rozovskii, Stochastic evolution systems, Kluwer 1990.")

#text("The first book deals with the semigroup approach, the second one with the so-called variational approach (the book treats only linear equations, but the theory works for a rather wide class of nonlinear operators satisfying monotonicity and coercivity conditions).")

#text("Both books contain (some) motivation for studying SPDEs, and discuss what one means by “white noise” and “space-time white noise”.")

#text("Unfortunately I agree with you that there is a large “industry” that makes a living by taking a deterministic PDE, adding noise to it, and trying to say something about the resulting PDE, without even mentioning why, what for, and so on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of less than epsilon")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36242")[#strong[#text("less than epsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("Dear Karabasov,")

#text("Thank you for your suggestions. Indeed, I had looked at the first book.")

#text("Mostly I am looking for a” note” like a survey paper which shows the ”big picture” , addresses the main problems, main approaches, techniques , open problems and further directions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/251075b34d7a0ec477ccb991d9c4479a23a82cab784e1a43915760f4ba7b419a-ad6b21183105ed8c11aa779bf487beb46a8aa22b569d9f5b9a8c454d8fb4addf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of albuquerqueroberta")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36245")[#strong[#text("albuquerqueroberta")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("Very nice post! Thank you !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of RK")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36252")[#strong[#text("RK")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2009")])]

#text("Hi Dr. Tao,")

#text("Thanks for the great article.")

#text("Small correction: Two paragraphs before “A variant”, the text that appears in square brackets: “It is important to aware” should be “It’s important to be aware”. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of karabasov")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36256")[#strong[#text("karabasov")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Dear less than epsilon,")#linebreak()#text(" unfortunately I do not know anything like that. Frankly speaking, what you are looking for should be provided by your advisor, i.e. he should be able to answer your very legitimate questions! Good luck")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36261")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("[…] Tricks Wiki: Give yourself an epsilon of room (será que alguém disse mollifier? ) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/390f81bc403abbaa8705d528326b2523fa57d0b8d96a8625fdf3137195984de9-d72493108d6c1d94a82de1fb4c8ac5733837bfe3934e27530cdeee359b8b1909.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nicolaennio")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36265")[#strong[#text("nicolaennio")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("third formula of example one on the left side should not have xi rather than x?")

#text("thanks a lot for this clear and useful post")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-36267")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2009")])]

#text("Dear nicolaennio: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-37409")[#strong[#text("While I’m linking… « Feed The Bears")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2009")]

#text("[…] A post on using statements “up to epsilon” and then letting to prove things. The issue is that sometimes you want to apply machinery to a situation where it doesn’t apply, so you tweak the situation by somehow so the machinery does apply and then let . This is a very standard trick that is even familiar to many undergraduate analysis students. (In opposition to the first two posts, which are more advanced and less prevalent in standard analysis course material.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 1: Interpolation of L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-37578")[#strong[#text("245C, Notes 1: Interpolation of L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] remove the assumption that goes to zero at infinity, we use the trick of giving ourselves an epsilon of room. Namely, we multiply by the holomorphic function for some . A little complex arithmetic shows […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-251085")[#strong[#text("Rigorous proofs | Gyre&Gimble")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2013")]

#text("[…] Since for all positive $epsilon$, $f(x)lt f(a)+epsilon$, then $f(x)leq f(a)$. (See also Terry Tao’s article in Tricks […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-469952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2016")])]

#text("In Example 1 can one use Schwartz functions instead of the ")#mi("C_0^\\infty")#text(" functions?")

#text("Is there any advantage that you use the uncountable family of functions ")#mi("f_\\varepsilon")#text(" to approximate ")#mi("f")#text(" instead of using a sequence of functions ")#mi("f_n")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-469982")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2016")])]

#text("Yes, there are multiple ways to implement the epsilon of room argument in this case. Whether one uses ")#mi("\\varepsilon")#text(" or ")#mi("n")#text(" as the approximating parameter is mostly a matter of personal taste. I find ")#mi("\\varepsilon")#text(" to be a more natural parameter here than ")#mi("n")#text(" (it measures the degree of approximation, whereas ")#mi("n")#text(" is just an indexing parameter), but this is a minor aesthetic preference only. Having an uncountable directed set rather than a countable one can occasionally cause some minor technical difficulties, but these can usually be resolved by passing to a countable subset (e.g. restricting to ")#mi("\\varepsilon")#text("s of the form ")#mi("\\varepsilon = 1/n")#text(" for some natural number ")#mi("n")#text(") whenever needed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246B, Notes 2: Some connections with the Fourier transform | What's new")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-620195")[#strong[#text("246B, Notes 2: Some connections with the Fourier transform | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2021")])]

#text("[…] remove the assumption that goes to zero at infinity, we use the trick of giving ourselves an epsilon of room. Namely, we multiply by the holomorphic function for some . A little complex arithmetic shows […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-691975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("Dr Tao,")

#text("Is the definition of convergence of a sequence or function, the first ε-δ language we’ve met, also a type of “give yourself an epsilon of room”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/#comment-691977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("Strictly speaking, this is a ")#link("https://en.wikipedia.org/wiki/Category_mistake")[#text("category error")]#text(": a definition is not a strategy. But giving oneself an epsilon of room can certainly let one take advantage of such convergent sequences or functions. For instance, if a sequence ")#mi("x_n")#text(" of real numbers converges to a limit ")#mi("x")#text(", one cannot conclude that ")#mi("x_n \\leq x")#text(" for any value of ")#mi("n")#text("; but if one gives an epsilon of room in the bound, one can ensure that ")#mi("x_n \\leq x + \\varepsilon")#text(" for all sufficiently large ")#mi("n")#text(".")
]
]
