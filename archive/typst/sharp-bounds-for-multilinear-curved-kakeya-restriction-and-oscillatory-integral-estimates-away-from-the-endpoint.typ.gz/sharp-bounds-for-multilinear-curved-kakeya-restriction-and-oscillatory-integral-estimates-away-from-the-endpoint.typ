// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/
// Converted to Typst by tao2typ: "2026-10-14T16:38:36.357655+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sharp bounds for multilinear curved Kakeya, restriction and oscillatory integral estimates away from the endpoint", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sharp bounds for multilinear curved Kakeya, restriction and oscillatory integral estimates away from the endpoint")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 July 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/")[#text("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I have just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/1907.11342")[#text("Sharp bounds for multilinear curved Kakeya, restriction and oscillatory integral estimates away from the endpoint")]#text("“, submitted to ")#link("https://www.cambridge.org/core/journals/mathematika")[#text("Mathematika")]#text(". In this paper I return (after more than a decade’s absence) to one of my first research interests, namely the Kakeya and restriction family of conjectures. The starting point is the following “multilinear Kakeya estimate” first established in the non-endpoint case ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("by Bennett, Carbery, and myself")]#text(", and then in the endpoint case ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2746348")[#text("by Guth")]#text(" (with further proofs and extensions by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2860188")[#text("Bourgain-Guth")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3019726")[#text("Carbery-Valdimarsson")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Multilinear Kakeya estimate)")]#text(" ")#metadata(none) <tao-29a3c59705f35e997400>#text(" Let ")#mi("{\\delta > 0}")#text(" be a radius. For each ")#mi("{j = 1,\\dots,d}")#text(", let ")#mi("{\\mathbb{T}_j}")#text(" denote a finite family of infinite tubes ")#mi("{T_j}")#text(" in ")#mi("{{\\bf R}^d}")#text(" of radius ")#mi("{\\delta}")#text(". Assume the following axiom:")

#list(
[#text("(i) (Transversality) whenever ")#mi("{T_j \\in \\mathbb{T}_j}")#text(" is oriented in the direction of a unit vector ")#mi("{n_j}")#text(" for ")#mi("{j =1,\\dots,d}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\bigwedge_{j=1}^d n_j\\right| \\geq A^{-1}", block: true)]]

#text("for some ")#mi("{A>0}")#text(", where we use the usual Euclidean norm on the wedge product ")#mi("{\\bigwedge^d {\\bf R}^d}")#text(".")]
)

#text("Then, for any ")#mi("{p \\geq \\frac{1}{d-1}}")#text(", one has ")#metadata(none) <tao-3b8d14199277153e41ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\prod_{j=1}^d \\sum_{T_j \\in \\mathbb{T}_j} 1_{T_j} \\right\\|_{L^p({\\bf R}^d)} \\lesssim_{A,p} \\delta^{\\frac{d}{p}} \\prod_{j \\in [d]} \\# \\mathbb{T}_j.", block: true)]]

#text("where ")#mi("{L^p({\\bf R}^d)}")#text(" are the usual Lebesgue norms with respect to Lebesgue measure, ")#mi("{1_{T_j}}")#text(" denotes the indicator function of ")#mi("{T_j}")#text(", and ")#mi("{\\# \\mathbb{T}_j}")#text(" denotes the cardinality of ")#mi("{\\mathbb{T}_j}")#text(".")
]

#text("The original proof of this proceeded using a heat flow monotonicity method, which in ")#link("https://terrytao.wordpress.com/2019/06/29/symmetric-functions-in-a-fractional-number-of-variables-and-the-multilinear-kakeya-conjecture/")[#text("my previous post")]#text(" I reinterpreted using a “virtual integration” concept on a fractional Cartesian product space. It turns out that this machinery is somewhat flexible, and can be used to establish some other estimates of this type. The first result of this paper is to extend the above theorem to the curved setting, in which one localises to a ball of radius ")#mi("{O(1)}")#text(" (and sets ")#mi("{\\delta}")#text(" to be small), but allows the tubes ")#mi("{T_j}")#text(" to be curved in a ")#mi("{C^2}")#text(" fashion. If one runs the heat flow monotonicity argument, one now picks up some additional error terms arising from the curvature, but as the spatial scale approaches zero, the tubes become increasingly linear, and as such the error terms end up being an integrable multiple of the main term, at which point one can conclude by Gronwall’s inequality (actually for technical reasons we use a bootstrap argument instead of Gronwall). A key point in this approach is that one obtains optimal bounds (not losing factors of ")#mi("{\\delta^{-\\varepsilon}}")#text(" or ")#mi("{\\log^{O(1)} \\frac{1}{\\delta}}")#text("), so long as one stays away from the endpoint case ")#mi("{p=\\frac{1}{d-1}}")#text(" (which does not seem to be easily treatable by the heat flow methods). Previously, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("the paper of Bennett, Carbery, and myself")]#text(" was able to use an induction on scale argument to obtain a curved multilinear Kakeya estimate losing a factor of ")#mi("{\\log^{O(1)} \\frac{1}{\\delta}}")#text(" (after optimising the argument); later arguments of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2860188")[#text("Bourgain-Guth")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3019726")[#text("Carbery-Valdimarsson")]#text(", based on algebraic topology methods, could also obtain a curved multilinear Kakeya estimate without such losses, but only in the algebraic case when the tubes were neighbourhoods of algebraic curves of bounded degree.")

#text("Perhaps more interestingly, we are also able to extend the heat flow monotonicity method to apply directly to the multilinear restriction problem, giving the following global multilinear restriction estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Multilinear restriction theorem)")]#text(" ")#metadata(none) <tao-832c3ad85e996eef8a50>#text(" Let ")#mi("{\\frac{1}{d-1} < p \\leq \\infty}")#text(" be an exponent, and let ")#mi("{A \\geq 2}")#text(" be a parameter. Let ")#mi("{M}")#text(" be a sufficiently large natural number, depending only on ")#mi("{d}")#text(". For ")#mi("{j \\in [d]}")#text(", let ")#mi("{U_j}")#text(" be an open subset of ")#mi("{B^{d-1}(0,A)}")#text(", and let ")#mi("{h_j: U_j \\rightarrow {\\bf R}}")#text(" be a smooth function obeying the following axioms:")

#list(
[#text("(i) (Regularity) For each ")#mi("{j \\in [d]}")#text(" and ")#mi("{\\xi \\in U_j}")#text(", one has")

#metadata(none) <tao-667937c3e7a68ea37471>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|\\nabla_\\xi^{\\otimes m} \\otimes h_j(\\xi)\\right| \\leq A", block: true)]]

#text("for all ")#mi("{1 \\leq m \\leq M}")#text(".")],
[#text("(ii) (Transversality) One has")

#align(center)[#tao-fit-display[#tao-math("\\left| \\bigwedge_{j \\in [d]} (-\\nabla_\\xi h_j(\\xi_j),1) \\right| \\geq A^{-1}", block: true)]]

#text("whenever ")#mi("{\\xi_j \\in U_j}")#text(" for ")#mi("{j \\in [d]}")#text(".")]
)

#text("Let ")#mi("{U_{j,1/A} \\subset U_j}")#text(" be the sets ")#metadata(none) <tao-33c9f54e4d6edd69b8b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("U_{j,1/A} := \\{ \\xi \\in U_j: B^{d-1}(\\xi,1/A) \\subset U_j \\}.")]]

#text("Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{j \\in [d]} {\\mathcal E}_j f_j \\right\\|_{L^{2p}({\\bf R}^d)} \\leq A^{O(1)} \\left(d-1-\\frac{1}{p}\\right)^{-O(1)} \\prod_{j \\in [d]} \\left\\|f_j \\right\\|_{L^2(U_{j,1/A})}", block: true)]]

#text("for any ")#mi("{f_j \\in L^2(U_{j,1/A} \\rightarrow {\\bf C})}")#text(", ")#mi("{j \\in [d]}")#text(", extended by zero outside of ")#mi("{U_{j,1/A}}")#text(", and ")#mi("{{\\mathcal E}_j}")#text(" denotes the extension operator")

#align(center)[#tao-fit-display[#mitex("{\\mathcal E}_j f_j( x^{\\prime}, x_d ) := \\int_{U_j} e^{2\\pi i (x^{\\prime} \\xi^T + x_d h_j(\\xi))} f_j(\\xi)\\ d\\xi.")]]
]

#text("Local versions of such estimate, in which ")#mi("{L^{2p}({\\bf R}^d)}")#text(" is replaced with ")#mi("{L^{2p}(B^d(0,R))}")#text(" for some ")#mi("{R \\geq 2}")#text(", and one accepts a loss of the form ")#mi("{\\log^{O(1)} R}")#text(", were already established by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("Bennett, Carbery, and myself")]#text(" using an induction on scale argument. In a later paper of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2860188")[#text("Bourgain-Guth")]#text(" these losses were removed by “epsilon removal lemmas” to recover Theorme ")#link(<tao-832c3ad85e996eef8a50>)[#text("2")]#text(", but only in the case when all the hypersurfaces involved had curvatures bounded away from zero.")

#text("There are two main new ingredients in the proof of Theorem ")#link(<tao-832c3ad85e996eef8a50>)[#text("2")]#text(". The first is to replace the usual induction on scales scheme to establish multilinear restriction by a “ball inflation” induction on scales scheme that more closely resembles the proof of decoupling theorems. In particular, we actually prove the more general family of estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\prod_{j \\in [d]} E_{r}[{\\mathcal E}_j f_j] \\right\\|_{L^{p}({\\bf R}^d)} \\leq A^{O(1)} \\left(d-1 - \\frac{1}{p}\\right)^{O(1)} r^{\\frac{d}{p}} \\prod_{j \\in [d]} \\left\\| f_j \\right\\|_{L^2(U_{j,1/A})}^2", block: true)]]

#text("where ")#mi("{E_r}")#text(" denotes the local energies")

#align(center)[#tao-fit-display[#tao-math("E_{r}[f](x^{\\prime},x_d) := \\int_{B^{d-1}(x^{\\prime},r)} \\left|f(y^{\\prime},x_d)\\right|^2\\ dy^{\\prime}", block: true)]]

#text("(actually for technical reasons it is more convenient to use a smoother weight than the strict cutoff to the disk ")#mi("{B^{d-1}(x^{\\prime},r)}")#text("). With logarithmic losses, it is not difficult to establish this estimate by an upward induction on ")#mi("{r}")#text(". To avoid such losses we use the heat flow monotonicity method. Here we run into the issue that the extension operators ")#mi("{{\\mathcal E}_j f_j}")#text(" are complex-valued rather than non-negative, and thus would not be expected to obey many good montonicity properties. However, the local energies ")#mi("{E_r[{\\mathcal E}_j f_j]}")#text(" can be expressed in terms of the magnitude squared of what is essentially the ")#link("https://en.wikipedia.org/wiki/Gabor_transform")[#text("Gabor transform")]#text(" of ")#mi("{{\\mathcal E}_j f_j}")#text(", and these are non-negative; furthermore, the dispersion relation associated to the extension operators ")#mi("{{\\mathcal E}_j f_j}")#text(" implies that these Gabor transforms propagate along tubes, so that the situation becomes quite similar (up to several additional lower order error terms) to that in the multilinear Kakeya problem. (This can be viewed as a continuous version of the usual wave packet decomposition method used to relate restriction and Kakeya problems, which when combined with the heat flow monotonicity method allows for one to use a continuous version of induction on scales methods that do not concede any logarithmic factors.)")

#text("Finally, one can combine the curved multilinear Kakeya result with the multilinear restriction result to obtain estimates for multilinear oscillatory integrals away from the endpoint. Again, this sort of implication was already established in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2275834")[#text("the previous paper of Bennett, Carbery, and myself")]#text(", but the arguments there had some epsilon losses in the exponents; here we were able to run the argument more carefully and avoid these losses.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Is it possible to extend these oscilatory integral estimates for singular integrals?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519077")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2019")])]

#text("Well, there is some precedent for using heat flow monotonicity methods to control singular integrals, most notably by the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1894362")[#text("work of Stefanie Petermichl and Alexander Volberg")]#text(" on sharp estimates for the Ahlfors-Beurling operator. On the other hand, the estimates here only work in a multilinear setting rather than a linear one, so there isn’t an obvious way to combine the two. I view heat flow monotonicity methods as a version of induction on scales (or as an analogue of the Bellman function technique in the dyadic setting, which I think was the motivation for the Petermichl-Volberg work), so if there are singular integral problems in which those techniques have already been indicated to be relevant, then a heat flow approach might be worth trying to see if one can sharpen the estimates somewhat.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2019")])]

#text("Dear elite Pro.Tao,")#linebreak()#text(" There are many good mathematicians in the world , but I only like you.Therefore, one day recent I hope you will stand on the highest stage that receives Clay millenium award. For many reasons including of far distant, I cannot meet you to tell many")#linebreak()#text(" secrets, you are very special in 52 Field medalists. Before I die, I want my wish become true, if not I am very sad")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2019")])]

#text("Dear Pro.Tao")#linebreak()#text(" Nobody sees a light needle in a dark sea. I am very delighted to see that you solved one of the hardest problems in the world in 2019 . I can not reveal that problem but in disorder letters . May be yourself knows well: N,T,E,M,N,E,I,C,J,T,R,R,C,U,W,E,O,I,P,S.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a1c2d23c9ed6215833b906d7fe79b6866aec63c821d3891f962fc46ab7f89e94-d03d7104db8e971cd6e24366d4aee5f4233a1aeca5d43a5f3c559ab735860944.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Descrambler")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519211")[#strong[#text("Descrambler")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2019")])]

#text("How does this solve TWINPRIMESCONJECTURE?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2019")])]

#text("Wow, awesome work, my lovely Pro.Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("Hello, I have a small question, why isn’t the multilinear Kakeya estimate")

#tao-math("\\displaystyle\\left\\|\\prod \\sum 1_{T_j} \\right\\|_p \\lesssim \\delta^{d/p} \\prod \\# \\mathbb T_j", block: false)

#text("a simple consequence of triangle inequality and proving the estimate for a single intersection of tubes? I.e. proving")

#tao-math("\\displaystyle \\sup \\left\\|\\prod 1_{T_j} \\right\\|_p \\lesssim \\delta^{d/p}", block: false)

#text("where the supremum is taken over all collections of tubes ")#mi("T_1, \\dots, T_d")#text(" with ")#tao-math("\\left|\\wedge n_j\\right| > A^{-1}", block: false)#text("? Isn’t this last estimate immediate? I feel that the transversality condition should guarantee the tube intersection is small. What subtlety am I missing?")

#text("Given the opportunity, I’d also like to thank you (and others) who make their work available in the form of notes, blog posts, arxiv, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519154")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2019")])]

#text("This works in two dimensions, but in higher dimensions the most important values of ")#mi("p")#text(" are less than 1, and so the triangle inequality is no longer available.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a47d47e95fcd24a3f41dfbff1015ccb0d0936409c31ad8a95de463d8e71cca86-537a73a0ee4ae2704991ef894a45295132a107125042924a108fb86d88bcfd11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allan van Hulst")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519349")[#strong[#text("Allan van Hulst")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("Sorry, but I am struggling a bit with “By construction of epsilon” (arxiv-link, page 36, line 4). Does this refer to the same restrictions on epsilon as those mentioned at the start of Theorem 3.4? Or something different? For example, the function phi is indeed defined in a constructive way (page 18, below the itemize’d).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519366")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("I am referring here to the definition of ")#mi("\\varepsilon")#text(" at the start of Section 4 on page 33. I will add a more explicit link to this in the next revision of the ms. (There is no relation here with the definition of ")#mi("\\phi")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2019")])]

#text("My question is, why are the functions not identified up to zero sets in your Fock-type construction?")

#text("Some remarks (please take with a grain of salt in case they’re wrong):")

#text("1) The fractional Cartesian product space seems to have the property that")#linebreak()#text(" ")#mi("\\Omega_1^{p_1} \\times \\Omega_1^{p_2}")#text(" is not ")#mi("\\Omega_1^{p_1 + p_2}")#text(".")

#text("2) Although ")#mi("\\mathcal L^\\infty({\\vec \\Omega}^{\\vec p} \\to \\mathbb R)")#text(" is defined for all fractional powers ")#mi("\\vec p")#text(", for integer powers the Fock-type construction is actually a subset of the space the symbol stands for (maybe dense; but as far as I understand it, definitely not equal).")

#text("3) The construction of the fractional cartesian product reminded me of free probability, although it seems an element in the fractional cartesian product is identified by what it does with every other element, whereas elements in free probability spaces are identified with their free cumulants if I recall correctly. I have not yet read the section that proves the multi linear Kakeya using this tool but I would like to eventually read it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-519509")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2019")])]

#text("The main reason I did not identify functions that agree almost everywhere is that I will need to work with multiple measures ")#mi("\\mu[t,x]")#text(" in later analysis. ")#emph[#text("A priori")]#text(" I do not assume these measures to be mutually absolutely continuous, and so functions that agree almost everywhere with respect to one measure might not do so with respect to another measure. As it turns out, in the specific applications in this paper I do have mutual absolute continuity, but instead of spending a (small) amount of time on this technical point, it seemed simpler just to not identify a.e. equivalent functions in the first place.")

#text("The space ")#mi("{\\mathcal L}^\\infty(\\vec \\Omega^{\\vec p} \\to {\\bf R})")#text(" has a natural homomorphism into ")#mi("L^\\infty(\\vec \\Omega^p \\to {\\bf R})")#text(" when ")#mi("\\vec p")#text(" is integer-valued (by mapping the virtual function ")#mi("\\Sigma_{\\vec p}(f)")#text(" to its actual function interpretation, and extending by homomorphism), but the map is neither surjective nor injective in general. For instance, the image must take values in the space of symmetric functions on ")#mi("\\vec \\Omega^{\\vec p}")#text(" (and in fact the image is dense in that space in weak topologies); in particular, the fractional power ")#mi("\\vec \\Omega^{\\vec p}")#text(" is more like a quotient space ")#mi("\\vec \\Omega^{\\vec p} / S_{\\vec p}")#text(" of the Cartesian power by the action of the relevant (product) symmetric group. I had thought about making the notation more complicated to more accurately reflect this feature, but ultimately decided that the notation was already heavy enough as it was. This also explains why ")#mi("\\Omega_1^{p_1} \\times \\Omega_1^{p_2}")#text(" is “larger” than ")#mi("\\Omega_1^{p_1+p_2}")#text(", as the functions on the former space have less symmetry demanded of them. (But there is a natural homomorphism from ")#mi("{\\mathcal L}^\\infty( \\Omega_1^{p_1+p_2} \\to {\\bf R})")#text(" to ")#mi("{\\mathcal L}^\\infty( \\Omega_1^{p_1} \\to {\\bf R}) \\otimes {\\mathcal L}^\\infty( \\Omega_1^{p_1} \\to {\\bf R})")#text(" (mapping ")#mi("\\Sigma_{p_1+p_2}(f)")#text(" to ")#mi("\\Sigma_{p_1}(f) \\otimes 1 + 1 \\otimes \\Sigma_{p_2}(f)")#text(" and extending by homomorphism), which can be viewed as a “virtual” projection map from ")#mi("\\Omega_1^{p_1} \\times \\Omega_1^{p_2}")#text(" to ")#mi("\\Omega_1^{p_1+p_2}")#text(").")

#text("Injectivity can also fail; for instance, if all the ")#mi("\\Omega_i")#text(" are finite spaces, then ")#mi("L^\\infty(\\vec \\Omega^{\\vec p} \\to {\\bf R})")#text(" is finite dimensional, but ")#mi("{\\mathcal L}^\\infty(\\vec \\Omega^{\\vec p} \\to {\\bf R})")#text(" is infinite dimensional; there are “accidental” polynomials identities relating various functions ")#mi("\\Sigma_{\\vec p}(f)")#text(" in this case that are not picked up by the abstract Fock space. One could potentially quotient out the Fock space by these additional identities to obtain a space that more accurately resembles ")#mi("L^\\infty(\\vec \\Omega^{\\vec p} \\to {\\bf R})")#text(", but there didn’t seem to be any need for this in any of the applications I was considering (and there was some minor technical convenience in keeping the Fock space “free” of such identities in order to more easily define homomorphisms out of such spaces).")

#text("Certainly my exposure to free probability (or more generally noncommutative probability) influenced my thinking when trying to abstract out the key features of integration on product spaces that could extend to the fractional power setting. Indeed the Fock space constructed here could almost be interpreted as in the framework of noncommutative probability theory (though it remains commutative in this case), except for the fact that the positivity property ")#mi("\\int_{\\vec \\Omega^{\\vec p}} F^2\\ d\\mu^{\\vec p} \\geq 0")#text(" breaks down in the non-integer case (see the discussion before Theorem 3.4); related to this, I did not impose a topology on the Fock space with which to take a suitable weak closure to recover a von Neumann algebra. But one could still view ")#mi("(\\vec \\Omega^{\\vec p}, \\vec \\mu^{\\vec p})")#text(" as a sort of “(non)commutative measure space” rather than a “(non)commutative probability space” if one wished, by abandoning the positivity axiom.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2431725da0423db949a76c4e81cfbee1b08d03cea22908cfa86ee7dd3a4a32a-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522870")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("Thomas Wolff proves in his lecture notes the decay estimate")

#mi("\\displaystyle \\hat{\\sigma(\\zeta)}  \\frac{2n}{n-1}.")

#text("So the restriction conjecture is proved for the constant functions! How come the whole conjecture be so far away then? For any essentially bounded ")#mi("f")#text(" on the unit sphere we have then an estimate")

#tao-math("\\displaystyle \\left|\\hat{f\\sigma(\\zeta)}\\right|^q = \\left|\\int_{S^{n-1}}e^{-i2\\pi\\langle x,\\zeta \\rangle}f\\sigma\\right|^q \\leq \\left|\\hat{\\sigma(\\zeta)}\\right|^q(\\left|\\left|f\\right|\\right|_{\\infty})^q.", block: false)

#text("Doesn`t Wolff`s result then show that")

#tao-math("\\displaystyle \\int \\left|\\hat{\\sigma(\\zeta)}\\right|^q(\\left|\\left|f\\right|\\right|_{\\infty})^q \\leq \\int \\left|\\hat{\\sigma(\\zeta)}\\right|^q(\\left|\\left|f\\right|\\right|_{\\infty})^q = C_q(\\left|\\left|f\\right|\\right|_{\\infty})^q?", block: false)

#text("And we have proved the whole restriction conjecture, including the Kakeya conjectures?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522897")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2019")])]

#text("Unfortunately due to the oscillation in the ")#mi("e^{-i2\\pi \\langle \\xi \\sigma}")#text(" factor, one cannot bound ")#mi("\\widehat{f d\\sigma}")#text(" pointwise by ")#tao-math("\\left\\|f\\right\\|_\\infty \\hat \\sigma", block: false)#text(". For even exponents ")#mi("q")#text(" one can obtain a domination of ")#mi("L^q")#text(" norms through Plancherel’s theorem, allowing one to prove the restriction conjecture in this case, but this method does not work in general due to the failure of the Hardy-Littlewood majorant conjecture. See for instance ")#link("https://arxiv.org/abs/math/0303244")[#text("this paper of Ben Green")]#text(" for further discussion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joas165")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522935")[#strong[#text("joas165")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Ok, I see where I did a mistake. But we can easily decompose the spherical measure to positive and negative parts. Let ")#mi("A := \\{ x :e^{-i2\\pi\\langle x, \\zeta \\rangle}\\sigma \\geq 0 \\}")#text(". For ")#mi("f")#text(" non-negative valued we can represent ")#tao-math("\\left|\\widehat{f\\sigma}\\right|", block: false)#text(" as")

#tao-math("\\displaystyle \\left|\\widehat{f\\sigma}\\right| =  \\left|\\int_A e^{-i2\\pi\\langle x, \\zeta \\rangle}f(x)\\sigma\\right|  + \\left|\\int_{A^{c}} e^{-i2\\pi\\langle x, \\zeta \\rangle} f(x)\\sigma.\\right|", block: false)

#text("So ")#mi("2")#text(" times the bigger one of the normed integrals dominates ")#tao-math("\\left|\\widehat{f\\sigma}\\right|", block: false)#text(" and each of the normed integrals are dominated by ")#tao-math("\\left\\|f\\right\\|_{\\infty}|\\hat{\\sigma}|.", block: false)

#text("For example")

#tao-math("\\displaystyle \\left|\\int_{A^{c}} e^{-i2\\pi\\langle x, \\zeta \\rangle} f(x)\\sigma.\\right| \\leq  \\left|\\int_{A^{c}} e^{-i2\\pi\\langle x, \\zeta \\rangle}\\sigma\\right|\\left|\\left|f\\right|\\right|_{\\infty}", block: false)

#text("So we have ")#tao-math("\\left|\\widehat{f\\sigma}\\right| \\leq 2\\left|\\left|f\\right|\\right|_{\\infty}\\left|\\hat{\\sigma}\\right|,", block: false)#text(" at least for non-negative functions. I think we can extend this method. Where I was wrong, is that constant ")#mi("2")#text(" or whatever will be involved in the general case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522939")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("We can define ")#mi("B := \\{ x : \\sigma \\geq 0 \\}")#text(".I just noticed that, ")#mi("\\int_B e^{-i2\\pi\\langle x, \\zeta \\rangle}f(x)\\sigma")#text(" gets dominated even by")#linebreak()#text(" ")#tao-math("\\displaystyle \\int e^{-i2\\pi\\langle x, \\zeta \\rangle}f(x) \\sigma \\leq \\int_{A}\\left|f\\left|\\sigma \\leq \\left|S^{n-1}\\right|\\right|\\left|f\\right|\\right|_{\\infty}.", block: false)

#text("In my first comment I meant that the decay estimate is")

#tao-math("\\hat{\\sigma(\\zeta)} < (1 + \\left|\\zeta\\right|)^{-(n-1)/2}.", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Unfortunately this does not work either, for the same reason: the triangle inequality does not let one bound (say) ")#tao-math("\\left|\\int_A e^{-i2\\pi \\langle x,\\zeta\\rangle} f(x)\\ d\\sigma\\right|", block: false)#text(" by ")#tao-math("\\left|\\int_{S^{n-1}} e^{-i2\\pi \\langle x,\\zeta\\rangle}\\ d\\sigma\\right|", block: false)#text(". As a general rule of thumb, one can only hope to make comparisons like this when all the oscillation on the right-hand side has been removed using absolute value signs.")

#text("Another way to see why comparisons of this sort in general must fail is that the Fourier transform ")#mi("\\widehat{d\\sigma}(\\zeta)")#text(" vanishes for some choices of ")#mi("\\zeta")#text(" (when ")#tao-math("\\left|\\zeta\\right|", block: false)#text(" is basically a zero of a Bessel function), but there is no reason why all the other Fourier transforms ")#mi("\\widehat{f d\\sigma}(\\zeta)")#text(" have to vanish there also (e.g., if ")#mi("f(x) = e^{2\\pi i \\langle x,\\zeta}")#text(" then ")#mi("\\widehat{fd\\sigma}(\\zeta)")#text(" will be positive). So there is no hope of controlling the latter pointwise by the former.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-522953")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2019")])]

#text("Ok, in general it fails. Anyway, it works for example for even non-negative real functions, because then the Fourier transform is positive. But let ")#mi("f")#text(" be non-negative. I didn`t plan to use just the triangle inequality. You have control of the imaginary part of ")#mi("\\text{Im}\\widehat{f\\sigma}")#text(" by ")#mi("\\int_{S^{n-1}} f(x)|\\sin(\\langle x, \\zeta \\rangle)|\\sigma")#text(". The ")#mi("\\sigma")#text(" is an even measure, so you have")

#tao-math("\\displaystyle \\left|\\widehat{f\\sigma}\\right| \\leq \\int_{S^{n-1}} f(x)cos(\\langle x, \\zeta \\rangle)\\sigma +  \\int_{S^{n-1}} f(x)|\\sin(\\langle x, \\zeta \\rangle)|\\sigma?", block: false)

#text("I thought that the above is controlled by")

#tao-math("\\displaystyle 2\\int_{S^{n-1}} f(x)cos(\\langle x, \\zeta \\rangle)\\sigma \\leq 2\\left|\\left|f\\right|\\right|_{\\infty}\\left|\\widehat{\\sigma}\\right|,", block: false)

#text("because I was almost sure that by symmetry")

#mi("\\displaystyle \\int_{S^{n-1}}|\\sin(\\langle x, \\zeta \\rangle)|\\sigma = \\int_{S^{n-1}}|cos(\\langle x, \\zeta \\rangle)|\\sigma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523007")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2019")])]

#text("This will probably be my last comment on the subject. In general the estimate fails. But I can show that my estimate works for even functions ")#mi("f")#text(", because then the Fourier transform is real valued.")#linebreak()#text(" Now, there exists ")#mi("a \\in \\mathbb{R}^n")#text(" and ")#mi("b \\in \\mathbb{R}^n")#text(" such that")

#mi("\\displaystyle \\int_{S^{n-1}} cos_{+}(2\\pi\\langle\\zeta,x\\rangle) f(x)\\sigma = a\\int_{S^{n-1}} cos_{+}(2\\pi\\langle\\zeta,x\\rangle)\\sigma")

#text("and")

#mi("\\displaystyle \\int_{S^{n-1}} cos_{-}(2\\pi\\langle\\zeta,x\\rangle) f(x)\\sigma = b\\int_{S^{n-1}} cos_{-}(2\\pi\\langle\\zeta,x\\rangle)\\sigma .")

#text("Thus,")

#tao-math("\\displaystyle \\left|\\widehat{f\\sigma(\\zeta)}\\right| =\\left|a-b\\right|\\left|\\widehat{f\\sigma(\\zeta)}\\right| \\leq \\left|\\left|f\\right|\\right|_{\\infty|}\\widehat{f\\sigma(\\zeta)}|.", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523211")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")])]

#text("There appear to be several LaTeX issues with your comment, but in any event this approach is unlikely to work, because the non-oscillatory integrals ")#mi("\\int_{S^{n-1}} \\cos_\\pm(2\\pi \\langle \\zeta,x\\rangle)\\ d\\sigma")#text(" are considerably larger than the oscillatory integral ")#mi("\\int_{S^{n-1}} \\cos(2\\pi \\langle \\zeta,x\\rangle)\\ d\\sigma")#text(". In particular, they do not decay to zero in the limit ")#mi("\\zeta \\to \\infty")#text(" and so one will not get any non-trivial ")#mi("L^p")#text(" estimates this way.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523359")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("Yes, there are issues in my latex. I have been moving to an another town, so I make more mistakes than usually and I make mistakes a lot.")#linebreak()#text(" I think it better to make a little bit more longer comment, but I cannot prove the whole thing in these comments. I try to run this comment through an editor, because I cannot see my comment otherwise.")#linebreak()#text(" Anyway, if ")#mi("\\widehat{\\sigma}")#text(" is small, it means that there are lot of cancellation. However, that cancellation is *fixed* for each *pointwise* estimate! So the relevant cancellation comes from ")#mi("f.")#linebreak()#text(" The worst cases are when")

#mi("\\displaystyle \\cos_{-}f{\\langle x, \\zeta \\rangle} = 0.")

#text("W.L.O.G let us suppose that")

#mi("\\displaystyle \\int \\cos_{+}{\\langle x, \\zeta \\rangle} \\geq \\int  \\cos_{-}{\\langle x, \\zeta \\rangle}.")

#text("Thus, there exists")

#mi("\\displaystyle 1 \\geq \\gamma \\geq 0,")

#text("so that")

#mi("\\displaystyle \\gamma c_{+} = c_{-}.")

#text("In other words")

#mi("\\displaystyle (1-\\gamma)c_{+} = \\widehat{\\sigma}.")

#text("On the other hand we have")

#mi("\\displaystyle Qc_{+} = \\widehat{f\\sigma},")

#text("for some")

#tao-math("\\displaystyle \\left|Q\\right| \\leq \\left|\\left|f\\right|\\right|_{\\infty}.", block: false)

#text("What we wan’t to prove is that")

#tao-math("\\displaystyle \\left|\\left|f\\right|\\right|_{\\infty}(1-\\gamma)c_{+} \\geq Qc_{+}.", block: false)

#text("The bigger ")#tao-math("\\left|\\left|f\\right|\\right|_{\\infty}", block: false)#text(" gets for fixed ")#mi("\\gamma")#text(" the more probable the estimate gets. IMO this estimate is a priori probable and it is clearly true for large ")#tao-math("\\left|\\left|f\\right|\\right|_{\\infty}.", block: false)#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523363")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("I meant that the estimate is clearly true for large ")#mi("f")#text(" if we don`t care about universal small constants. More interesting would be to quantify that cancellation ")#mi("(1-\\gamma)")#text(" as an function of ")#mi("\\zeta.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523376")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("In any case we have pointwise")

#tao-math("\\displaystyle (\\left|\\left|f\\right|\\right|_{\\infty}\\left|\\widehat{\\sigma}\\right|)^q \\geq \\left|\\widehat{f\\sigma}\\right| \\left|\\widehat{\\sigma}\\right|^q,", block: false)

#text("so ")#tao-math("\\left|\\widehat{f\\sigma}\\right|", block: false)#text(" cannot decay slower than ")#tao-math("\\left|\\widehat{f\\sigma}\\right|,", block: false)#text(" if ")#tao-math("\\left|\\widehat{\\sigma}\\right|^q", block: false)#text(" is integrable.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-523377")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2019")])]

#text("I guess the Lord tests as all. I meant the following. In any case we have pointwise")

#tao-math("\\displaystyle (\\left|\\left|f\\right|\\right|_{\\infty}\\left|\\widehat{\\sigma}\\right|)^q \\geq \\left|\\widehat{f\\sigma}\\right|^q \\left|\\widehat{\\sigma}\\right|^q,", block: false)

#text("so ")#tao-math("\\left|\\widehat{f\\sigma}\\right|", block: false)#text(" cannot decay slower than ")#tao-math("\\left|\\widehat{\\sigma}\\right|", block: false)#text(". Doesn`t this prove the resctriction conjecture?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-524004")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2019")])]

#text("No, since the factors of ")#tao-math("\\left|\\widehat \\sigma\\right|", block: false)#text(" on both sides cancel each other out and one is only left with the trivial bound ")#tao-math("\\left|\\widehat{f\\sigma}\\right| \\leq \\left\\|f\\right\\|_\\infty", block: false)#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-524089")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2019")])]

#text("Yeah, but don`t you lose information that way? If we had slower asymptotic decay to zero in infinity for $|\\widehat{f\\sigma}|^{q},$ then we would have")#linebreak()#text(" ")#tao-fit-display[#tao-math("C\\left|\\hat{\\sigma}\\right|^{q} \\leq \\left|\\widehat{f\\sigma}\\right|^{q} ,", block: true)]#text(" but this kind of contradicts the pointwise estimate. BTW, don`t you divide by zero?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdc53b1fc067edaea5be43fa7d12675533449bec2ef9b12f973c964112cfd8c6-fcf822c38a31c9f0e7498a344d5452ea0020130ca9ae1789d3724e6a2a0bfdfe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-524092")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2019")])]

#text("Why wouldn`t we scale ")#tao-fit-display[#tao-math("\\left|\\left|f\\right|\\right|_{\\infty} = 2", block: true)]#text(" and divide my pointwise estimate with $|\\widehat{\\sigma}|^{q}$ twice. Doesn`t that show that ")#tao-fit-display[#tao-math("2^q\\left|\\hat{\\sigma}\\right|^{q} < \\left|\\widehat{f\\sigma}\\right|^{q} ,", block: true)]#text(" is impossible?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-524101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2019")])]

#text("Stop wasting his time Johan you’re not going to solve the restriction problem")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55e24afea858ce8d46ffd639801d033895fbe50497673f0ec2d756835eb8b535-6ac472dff803cc204b269c12c3761e6f3f2f1618b692f84748a8129200a86740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-623744")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2021")])]

#text("I don’t still see why that oscillation really matters. After all ")#tao-math("\\left|\\widehat{(fd\\sigma)(y)}\\right|^{q}", block: false)#text(" needs to be bounded pointwise not ")#mi("\\widehat{(fd\\sigma)(y)}")#text(". Moreover for ")#mi("q")#text(" given by the constant case ")#tao-math("\\sum_{i=1}^N\\alpha_i^q\\widehat{|(1_{A_i}d\\sigma)(y)}\\left|^{q} \\leq \\max_{i \\in {1,..,N}}\\alpha_i^{q}\\widehat{|(d\\sigma)(y)}\\right|^{q}", block: false)#text(" for simple functions by linearity. It seems to me that ")#mi("\\hat{|(fd\\sigma)}|^{q}")#text(" is bounded by ")#tao-math("\\left|\\left|f\\right|\\right|_{\\infty}^{q}\\left|\\widehat{(d\\sigma)}\\right|^{q}", block: false)#text(" pointwise.")

#emph[#text("[The claims in the latter two sentences are incorrect. For instance, there are frequencies ")#mi("\\xi")#text(" where the Fourier transform ")#mi("\\widehat{d\\sigma}(\\xi)")#text(" vanishes (their magnitude is the zero of a certain Bessel function), but one can easily concoct bounded functions ")#mi("f")#text(" for which ")#mi("\\widehat{fd\\sigma}(\\xi)")#text(" is non-vanishing for such frequencies. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf0f4fe3d65881c1ad21d60ba0e774d589f6f787f894ab946103cf10365f226b-34b024389300d1880228e2e2ddde17baee90233e8d99d7bfa9da7957950def26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2019/07/29/sharp-bounds-for-multilinear-curved-kakeya-restriction-and-oscillatory-integral-estimates-away-from-the-endpoint/#comment-623890")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2021")])]

#text("Above in my post the absolute values are in wrong places. Anyway, we can let $f$ be non-negative and we have the pointwise bound for simple functions and by a limit process to all bounded continuous functions. In this way those zeroes of Bessel-functions etc. don’t matter. ")#link("https://math.stackexchange.com/questions/4070873/fourier-transform-on-functions-on-the-unit-sphere-bounded-by-the-fourier-transfo/4070874#4070874")[#text(" My question on math stack exchange ")]#text(".")

#emph[#text("[Your claimed inequality ")#tao-math("\\left|\\sum_{i=1}^N \\alpha_i \\widehat{1_{A_i} d\\sigma}(\\xi)\\right| \\leq \\left|\\sum_{i=1}^N \\widehat{1_{A_i} d\\sigma}(\\xi)\\right|", block: false)#text(" is incorrect, because the numbers ")#mi("\\widehat{1_A d\\sigma}(\\xi)")#text(" are not non-negative numbers. In particular it is possible for the right-hand side to vanish due to cancellation in the sum, while the left-hand side does not. -T.]")]
]
]
]
]
