// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/
// Converted to Typst by tao2typ: "2026-10-14T15:17:17.318396+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Talagrand’s concentration inequality", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Talagrand’s concentration inequality")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 June 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/")[#text("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the theory of discrete random matrices (e.g. matrices whose entries are random signs ")#mi("{\\pm 1}")#text("), one often encounters the problem of understanding the distribution of the random variable ")#mi("{\\text{dist}(X,V)}")#text(", where ")#mi("{X = (x_1,\\ldots,x_n) \\in \\{-1,+1\\}^n}")#text(" is an ")#mi("{n}")#text("-dimensional random sign vector (so ")#mi("{X}")#text(" is uniformly distributed in the discrete cube ")#mi("{\\{-1,+1\\}^n}")#text("), and ")#mi("{V}")#text(" is some ")#mi("{d}")#text("-dimensional subspace of ")#mi("{{\\bf R}^n}")#text(" for some ")#mi("{0 \\leq d \\leq n}")#text(".")

#text("It is not hard to compute the second moment of this random variable. Indeed, if ")#mi("{P = (p_{ij})_{1 \\leq i,j \\leq n}}")#text(" denotes the orthogonal projection matrix from ")#mi("{{\\bf R}^n}")#text(" to the orthogonal complement ")#mi("{V^\\perp}")#text(" of ")#mi("{V}")#text(", then one observes that")

#align(center)[#tao-fit-display[#mitex("\\text{dist}(X,V)^2 = X \\cdot P X = \\sum_{i=1}^n \\sum_{j=1}^n x_i x_j p_{ij}")]]

#text("and so upon taking expectations we see that ")#metadata(none) <tao-fa742e2673e90e53df17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb E} \\text{dist}(X,V)^2 = \\sum_{i=1}^n p_{ii} = \\text{tr} P = n-d")]]

#text("since ")#mi("{P}")#text(" is a rank ")#mi("{n-d}")#text(" orthogonal projection. So we expect ")#mi("{\\text{dist}(X,V)}")#text(" to be about ")#mi("{\\sqrt{n-d}}")#text(" on the average.")

#text("In fact, one has sharp concentration around this value, in the sense that ")#mi("{\\text{dist}(X,V) = \\sqrt{n-d}+O(1)}")#text(" with high probability. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Large deviation inequality)")]#text(" ")#metadata(none) <tao-2937d384bb992787f671>#text(" For any ")#mi("{t>0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb P}( \\left|\\text{dist}(X,V) - \\sqrt{n-d}\\right| \\geq t ) \\leq C \\exp(- c t^2 )", block: true)]]

#text("for some absolute constants ")#mi("{C, c > 0}")#text(".")
]

#text("In fact the constants ")#mi("{C, c}")#text(" are very civilised; for large ")#mi("{t}")#text(" one can basically take ")#mi("{C=4}")#text(" and ")#mi("{c=1/16}")#text(", for instance. This type of concentration, particularly for subspaces ")#mi("{V}")#text(" of moderately large codimension ")#mi("{n-d}")#text(", is fundamental to much of my work on random matrices with Van Vu, starting with ")#link("http://front.math.ucdavis.edu/math.CO/0411095")[#text("our first paper")]#text(" (in which this proposition first appears). (For subspaces of small codimension (such as hyperplanes) one has to use other tools to get good results, such as inverse Littlewood-Offord theory or the Berry-Esséen central limit theorem, but that is another story.)")

#text("Proposition ")#link(<tao-2937d384bb992787f671>)[#text("1")]#text(" is an easy consequence of the second moment computation and ")#link("http://www.ams.org/mathscinet-getitem?mr=1361756")[#text("Talagrand’s inequality")]#text(", which among other things provides a sharp concentration result for convex Lipschitz functions on the cube ")#mi("{\\{-1,+1\\}^n}")#text("; since ")#mi("{\\text{dist}(x,V)}")#text(" is indeed a convex Lipschitz function, this inequality can be applied immediately. The proof of Talagrand’s inequality is short and can be found in several textbooks (e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2437651")[#text("Alon and Spencer")]#text("), but I thought I would reproduce the argument here (specialised to the convex case), mostly to force myself to learn the proof properly. Note the concentration of ")#mi("{O(1)}")#text(" obtained by Talagrand’s inequality is much stronger than what one would get from more elementary tools such as ")#link("http://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma’s inequality")]#text(" or ")#link("http://en.wikipedia.org/wiki/McDiarmid%27s_inequality")[#text("McDiarmid’s inequality")]#text(", which would only give concentration of about ")#mi("{O(\\sqrt{n})}")#text(" or so (which is in fact trivial, since the cube ")#mi("{\\{-1,+1\\}^n}")#text(" has diameter ")#mi("{2\\sqrt{n}}")#text("); the point is that Talagrand’s inequality is very effective at exploiting the convexity of the problem, as well as the Lipschitz nature of the function in all directions, whereas Azuma’s inequality can only easily take advantage of the Lipschitz nature of the function in coordinate directions. On the other hand, Azuma’s inequality works just as well if the ")#mi("{\\ell^2}")#text(" metric is replaced with the larger ")#mi("{\\ell^1}")#text(" metric, and one can conclude that the ")#mi("{\\ell^1}")#text(" distance between ")#mi("{X}")#text(" and ")#mi("{V}")#text(" concentrates around its median to a width ")#mi("{O(\\sqrt{n})}")#text(", which is a more non-trivial fact than the ")#mi("{\\ell^2}")#text(" concentration bound given by that inequality. (The computation of the median of the ")#mi("{\\ell^1}")#text(" distance is more complicated than for the ")#mi("{\\ell^2}")#text(" distance, though, and depends on the orientation of ")#mi("{V}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" If one makes the coordinates of ")#mi("{X}")#text(" iid Gaussian variables ")#mi("{x_i \\equiv N(0,1)}")#text(" rather than random signs, then Proposition ")#link(<tao-2937d384bb992787f671>)[#text("1")]#text(" is much easier to prove; the probability distribution of a Gaussian vector is rotation-invariant, so one can rotate ")#mi("{V}")#text(" to be, say, ")#mi("{{\\bf R}^d}")#text(", at which point ")#mi("{\\text{dist}(X,V)^2}")#text(" is clearly the sum of ")#mi("{n-d}")#text(" independent squares of Gaussians (i.e. a ")#link("http://en.wikipedia.org/wiki/Chi-square_distribution")[#text("chi-square distribution")]#text("), and the claim follows from direct computation (or one can use the ")#link("http://en.wikipedia.org/wiki/Chernoff_inequality")[#text("Chernoff inequality")]#text("). The gaussian counterpart of Talagrand’s inequality is more classical, being essentially due to Lévy, and will also be discussed later in this post.")
]

#metadata(none) <tao-937cf13f637ee409098e>

#heading(level: 1)[#strong[#text(" — 1. Concentration on the cube — ")]]

#text("Proposition ")#link(<tao-2937d384bb992787f671>)[#text("1")]#text(" follows easily from the following statement, that asserts that if a convex set ")#mi("{A \\subset {\\bf R}^n}")#text(" occupies a non-trivial fraction of the cube ")#mi("{\\{-1,+1\\}^n}")#text(", then the neighbourhood ")#mi("{A_t := \\{ x \\in {\\bf R}^n: \\text{dist}(x,A) \\leq t \\}}")#text(" will occupy almost all of the cube for ")#mi("{t \\gg 1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Talagrand’s concentration inequality)")]#text(" ")#metadata(none) <tao-f331e134bbbbb126d7c0>#text(" Let ")#mi("{A}")#text(" be a convex set in ")#mi("{{\\bf R}^d}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(X \\in A) \\mathop{\\bf P}( X \\not \\in A_t ) \\leq \\exp( - c t^2 )")]]

#text("for all ")#mi("{t>0}")#text(" and some absolute constant ")#mi("{c > 0}")#text(", where ")#mi("{X \\in \\{-1,+1\\}^n}")#text(" is chosen uniformly from ")#mi("{\\{-1,+1\\}^n}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It is crucial that ")#mi("{A}")#text(" is convex here. If instead ")#mi("{A}")#text(" is, say, the set of all points in ")#mi("{\\{-1,+1\\}^n}")#text(" with fewer than ")#mi("{n/2-\\sqrt{n}}")#text(" ")#mi("{+1}")#text("‘s, then ")#mi("{\\mathop{\\bf P}(X \\in A)}")#text(" is comparable to ")#mi("{1}")#text(", but ")#mi("{\\mathop{\\bf P}( X \\not \\in A_t )}")#text(" only starts decaying once ")#mi("{t \\gg \\sqrt{n}}")#text(", rather than ")#mi("{t \\gg 1}")#text(". Indeed, it is not hard to show that Proposition ")#link(<tao-f331e134bbbbb126d7c0>)[#text("2")]#text(" implies the variant")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(X \\in A) \\mathop{\\bf P}( X \\not \\in A_t ) \\leq \\exp( - c t^2 / n)")]]

#text("for non-convex ")#mi("{A}")#text(" (by restricting ")#mi("{A}")#text(" to ")#mi("{\\{-1,+1\\}^n}")#text(" and then passing from ")#mi("{A}")#text(" to the convex hull, noting that distances to ")#mi("{A}")#text(" on ")#mi("{\\{-1,+1\\}^n}")#text(" may be contracted by a factor of ")#mi("{O(\\sqrt{n})}")#text(" by this latter process); this inequality can also be easily deduced from ")#link("http://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma’s inequality")]#text(".")
]

#text("To apply this proposition to the situation at hand, observe that if ")#mi("{A}")#text(" is the cylindrical region ")#mi("{\\{ x \\in {\\bf R}^n: \\text{dist}(x,V) \\leq r \\}}")#text(" for some ")#mi("{r}")#text(", then ")#mi("{A}")#text(" is convex and ")#mi("{A_t}")#text(" is contained in ")#mi("{\\{ x \\in {\\bf R}^n: \\text{dist}(x,V) \\leq r+t \\}}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(\\text{dist}(X,V) \\leq r) \\mathop{\\bf P}( \\text{dist}(X,V) > r+t ) \\leq \\exp(-ct^2).")]]

#text("Applying this with ")#mi("{r := M}")#text(" or ")#mi("{r := M-t}")#text(", where ")#mi("{M}")#text(" is the median value of ")#mi("{\\text{dist}(X,V)}")#text(", one soon obtains concentration around the median:")

#align(center)[#tao-fit-display[#tao-math("\\mathop{\\bf P}( \\left|\\text{dist}(X,V) - M\\right| > t ) \\leq 4 \\exp(-ct^2).", block: true)]]

#text("This is only compatible with ")#link(<tao-fa742e2673e90e53df17>)[#text("(1)")]#text(" if ")#mi("{M = \\sqrt{n-d} + O(1)}")#text(", and the claim follows.")

#text("To prove Proposition ")#link(<tao-f331e134bbbbb126d7c0>)[#text("2")]#text(", we use the exponential moment method. Indeed, it suffices by Markov’s inequality to show that ")#metadata(none) <tao-691dbfda5e95528425f7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mathop{\\bf P}(X \\in A) {\\Bbb E} \\exp( c \\text{dist}(X,A)^2 ) \\leq 1")]]

#text("for a sufficiently small absolute constant ")#mi("{c > 0}")#text(" (in fact one can take ")#mi("{c=1/16}")#text(").")

#text("We prove ")#link(<tao-691dbfda5e95528425f7>)[#text("(2)")]#text(" by an induction on the dimension ")#mi("{n}")#text(". The claim is trivial for ")#mi("{n=0}")#text(", so suppose ")#mi("{n \\geq 1}")#text(" and the claim has already been proven for ")#mi("{n-1}")#text(".")

#text("Let us write ")#mi("{X = (X^{\\prime},x_n)}")#text(" for ")#mi("{x_n = \\pm 1}")#text(". For each ")#mi("{t \\in {\\bf R}}")#text(", we introduce the slice ")#mi("{A_t := \\{ x^{\\prime} \\in {\\bf R}^{n-1}: (x^{\\prime},t) \\in A \\}}")#text(", then ")#mi("{A_t}")#text(" is convex. We now try to bound the left-hand side of ")#link(<tao-691dbfda5e95528425f7>)[#text("(2)")]#text(" in terms of ")#mi("{X^{\\prime}, A_t}")#text(" rather than ")#mi("{X, A}")#text(". Clearly")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(X \\in A) = \\frac{1}{2} [ \\mathop{\\bf P}( X^{\\prime} \\in A_{-1}) + \\mathop{\\bf P}( X^{\\prime} \\in A_{+1} ) ].")]]

#text("By symmetry we may assume that ")#mi("{\\mathop{\\bf P}( X^{\\prime} \\in A_{+1} ) \\geq \\mathop{\\bf P}( X^{\\prime} \\in A_{-1} )}")#text(", thus we may write ")#metadata(none) <tao-27a26bca625b22397190>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathop{\\bf P}( X^{\\prime} \\in A_{\\pm 1} ) = p (1 \\pm q)")]]

#text("where ")#mi("{p := \\mathop{\\bf P}(X \\in A)}")#text(" and ")#mi("{0 \\leq q \\leq 1}")#text(".")

#text("Now we look at ")#mi("{\\text{dist}(X,A)^2}")#text(". For ")#mi("{t = \\pm 1}")#text(", let ")#mi("{Y_t \\in {\\bf R}^{n-1}}")#text(" be the closest point of (the closure of) ")#mi("{A_t}")#text(" to ")#mi("{X^{\\prime}}")#text(", thus ")#metadata(none) <tao-c9b0c252a287143e15f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|X^{\\prime}-Y_t\\right| = \\text{dist}(X^{\\prime}, A_t).", block: true)]]

#text("Let ")#mi("{0 \\leq \\lambda \\leq 1}")#text(" be chosen later; then the point ")#mi("{(1-\\lambda) (Y_{x_n}, x_n) + \\lambda (Y_{-x_n},-x_n)}")#text(" lies in ")#mi("{A}")#text(" by convexity, and so")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(X,A) \\leq \\left|(1-\\lambda) (Y_{x_n}, x_n) + \\lambda (Y_{-x_n},-x_n) - (X^{\\prime},x_n)\\right|.", block: true)]]

#text("Squaring this and using Pythagoras, one obtains")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(X,A)^2 \\leq 4 \\lambda^2 + \\left|(1-\\lambda) (X^{\\prime}-Y_{x_n}) + \\lambda (X^{\\prime}-Y_{-x_n})\\right|^2.", block: true)]]

#text("As we will shortly be exponentiating the left-hand side, we need to linearise the right-hand side. Accordingly, we will exploit the convexity of the function ")#tao-math("{x \\mapsto \\left|x\\right|^2}", block: false)#text(" to bound")

#align(center)[#tao-fit-display[#tao-math("\\left|(1-\\lambda) (X-Y_{x_n}) + \\lambda (X-Y_{-x_n})\\right|^2 \\leq", block: true)]]

#align(center)[#tao-fit-display[#tao-math("(1-\\lambda) \\left|X^{\\prime}-Y_{x_n}\\right|^2 + \\lambda \\left|X^{\\prime}-Y_{-x_n}\\right|^2", block: true)]]

#text("and thus by ")#link(<tao-c9b0c252a287143e15f1>)[#text("(4)")]

#align(center)[#tao-fit-display[#mitex("\\text{dist}(X,A)^2 \\leq 4 \\lambda^2 + (1-\\lambda) \\text{dist}(X^{\\prime},A_{x_n})^2 + \\lambda \\text{dist}(X^{\\prime},A_{-x_n})^2.")]]

#text("We exponentiate this and take expectations in ")#mi("{X^{\\prime}}")#text(" (holding ")#mi("{x_n}")#text(" fixed for now) to get")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{X^{\\prime}} e^{c \\text{dist}(X,A)^2} \\leq e^{4 c \\lambda^2} {\\Bbb E}_{X^{\\prime}} (e^{c \\text{dist}(X^{\\prime},A_{x_n})^2})^{1-\\lambda} (e^{c \\text{dist}(X^{\\prime},A_{-x_n})^2})^{\\lambda}.")]]

#text("Meanwhile, from the induction hypothesis and ")#link(<tao-27a26bca625b22397190>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{X^{\\prime}} e^{c \\text{dist}(X^{\\prime},A_{x_n})^2} \\leq \\frac{1}{p(1 + x_n q)}")]]

#text("and similarly for ")#mi("{A_{-x_n}}")#text(". By Hölder’s inequality, we conclude")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{X^{\\prime}} e^{c \\text{dist}(X,A)^2} \\leq e^{4 c \\lambda^2} \\frac{1}{p (1 + x_n q)^{1-\\lambda} (1-x_n q)^\\lambda}.")]]

#text("For ")#mi("{x_n=+1}")#text(", the optimal choice of ")#mi("{\\lambda}")#text(" here is ")#mi("{0}")#text(", obtaining")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{X^{\\prime}} e^{c \\text{dist}(X,A)^2} = \\frac{1}{p (1+q)};")]]

#text("for ")#mi("{x_n=-1}")#text(", the optimal choice of ")#mi("{\\lambda}")#text(" is to be determined. Averaging, we obtain")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E}_{X} e^{c \\text{dist}(X,A)^2} = \\frac{1}{2} [ \\frac{1}{p (1+q)} + e^{4 c \\lambda^2} \\frac{1}{p (1 - q)^{1-\\lambda} (1 + q)^\\lambda} ]")]]

#text("so to establish ")#link(<tao-691dbfda5e95528425f7>)[#text("(2)")]#text(", it suffices to pick ")#mi("{0 \\leq \\lambda \\leq 1}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{1+q} + e^{4 c \\lambda^2} \\frac{1}{(1 - q)^{1-\\lambda} (1 + q)^\\lambda} \\leq 2.")]]

#text("If ")#mi("{q}")#text(" is bounded away from zero, then by choosing ")#mi("{\\lambda=1}")#text(" we would obtain the claim if ")#mi("{c}")#text(" is small enough, so we may take ")#mi("{q}")#text(" to be small. But then a Taylor expansion allows us to conclude if we take ")#mi("{\\lambda}")#text(" to be a constant multiple of ")#mi("{q}")#text(", and again pick ")#mi("{c}")#text(" to be small enough. The point is that ")#mi("{\\lambda=0}")#text(" already almost works up to errors of ")#mi("{O(q^2)}")#text(", and increasing ")#mi("{\\lambda}")#text(" from zero to a small non-zero quantity will decrease the LHS by about ")#mi("{O(\\lambda q) - O(c \\lambda^2)}")#text(". [By optimising everything using first-year calculus, one eventually gets the constant ")#mi("{c=1/16}")#text(" claimed earlier.]")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Talagrand’s inequality is in fact far more general than this; it applies to arbitrary products of probability spaces, rather than just to ")#mi("{\\{-1,+1\\}^n}")#text(", and to non-convex ")#mi("{A}")#text(", but the notion of distance needed to define ")#mi("{A_t}")#text(" becomes more complicated; the proof of the inequality, though, is essentially the same. Besides its applicability to convex Lipschitz functions, Talagrand’s inequality is also very useful for controlling combinatorial Lipschitz functions ")#mi("{F}")#text(" which are “locally certifiable” in the sense that whenever ")#mi("{F(x)}")#text(" is larger than some threshold ")#mi("{t}")#text(", then there exist some bounded number ")#mi("{f(t)}")#text(" of coefficients of ")#mi("{x}")#text(" which “certify” this fact (in the sense that ")#mi("{F(y) \\geq t}")#text(" for any other ")#mi("{y}")#text(" which agrees with ")#mi("{x}")#text(" on these coefficients). See e.g. the ")#link("http://www.ams.org/mathscinet-getitem?mr=2437651")[#text("text of Alon and Spencer")]#text(" for a more precise statement and some applications.")
]

#heading(level: 1)[#strong[#text(" — 2. Gaussian concentration — ")]]

#text("As mentioned earlier, there are analogous results when the uniform distribution on the cube ")#mi("{\\{-1,+1\\}^n}")#text(" are replaced by other distributions, such as the ")#mi("{n}")#text("-dimensional Gaussian distribution. In fact, in this case convexity is not needed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Gaussian concentration inequality)")]#text(" ")#metadata(none) <tao-3b8d14199277153e41ea>#text(" Let ")#mi("{A}")#text(" be a measurable set in ")#mi("{{\\bf R}^d}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(X \\in A) \\mathop{\\bf P}( X \\not \\in A_t ) \\leq \\exp( - c t^2 )")]]

#text("for all ")#mi("{t>0}")#text(" and some absolute constant ")#mi("{c > 0}")#text(", where ")#mi("{X \\equiv N(0,1)^d}")#text(" is a random Gaussian vector.")
]

#text("This inequality can be deduced from ")#link("http://en.wikipedia.org/wiki/Concentration_of_measure")[#text("Lévy’s classical concentration of measure inequality for the sphere")]#text(" (with the optimal constant), but we will give an alternate proof due to Maurey and Pisier. It suffices to prove the following variant of Proposition ")#link(<tao-3b8d14199277153e41ea>)[#text("3")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Gaussian concentration inequality for Lipschitz functions)")]#text(" ")#metadata(none) <tao-3274f46bdc9fa4158908>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a function which is Lipschitz with constant ")#mi("{1}")#text(" (i.e. ")#tao-math("{\\left|f(x)-f(y)\\right| \\leq \\left|x-y\\right|}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}^d}")#text(". Then for any ")#mi("{t}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb P}( \\left|f(X) - {\\Bbb E} f(X)\\right| \\geq t ) \\leq 2\\exp( - ct^2 )", block: true)]]

#text("for all ")#mi("{t>0}")#text(" and some absolute constant ")#mi("{c>0}")#text(", where ")#mi("{X \\equiv N(0,1)^d}")#text(" is a random variable. [Informally, Lipschitz functions of Gaussian variables concentrate as if they were Gaussian themselves; for comparison, Talagrand’s inequality implies that ")#emph[#text("convex")]#text(" Lipschitz functions of ")#emph[#text("Bernoulli")]#text(" variables concentrate as if they were Gaussian.]")
]

#text("Indeed, if one sets ")#mi("{f(x) := \\text{dist}(x,A)}")#text(", and splits into the cases whether ")#mi("{{\\Bbb E} f(X) \\geq t/2}")#text(" or ")#mi("{{\\Bbb E} f(X) < t/2}")#text(", one obtains either ")#mi("{{\\Bbb P}( X \\in A ) \\leq 2 \\exp(-ct^2/4)}")#text(" (in the former case) or ")#mi("{{\\Bbb P}( X \\not \\in A_t ) \\leq 2 \\exp(-ct^2/4)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(X \\in A) \\mathop{\\bf P}( X \\not \\in A_t ) \\leq 2\\exp( - c t^2/4 )")]]

#text("in either case. Also, since ")#mi("{\\mathop{\\bf P}(X \\in A) + \\mathop{\\bf P}( X \\not \\in A_t ) \\leq 1}")#text(", we have ")#mi("{\\mathop{\\bf P}(X \\in A) \\mathop{\\bf P}( X \\not \\in A_t ) \\leq 1/4}")#text(". Putting the two bounds together gives the claim.")

#text("Now we prove Proposition ")#link(<tao-3274f46bdc9fa4158908>)[#text("4")]#text(". By the ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("epsilon regularisation argument")]#text(" we may take ")#mi("{f}")#text(" to be smooth, and so by the Lipschitz property we have ")#metadata(none) <tao-4e448897946ead9e39e8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\nabla f(x)\\right| \\leq 1", block: true)]]

#text("for all ")#mi("{x}")#text(". By subtracting off the mean we may assume ")#mi("{{\\Bbb E} f = 0}")#text(". By replacing ")#mi("{f}")#text(" with ")#mi("{-f}")#text(" if necessary it suffices to control the upper tail probability ")#mi("{{\\Bbb P}( f(X) \\geq t )}")#text(" for ")#mi("{t > 0}")#text(".")

#text("We again use the exponential moment method. It suffices to show that")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} \\exp( t f(X) ) \\leq \\exp( C t^2 )")]]

#text("for some absolute constant ")#mi("{C}")#text(".")

#text("Now we use a variant of the ")#link("http://www.tricki.org/article/Square_and_rearrange")[#text("square and rearrange")]#text(" trick. Let ")#mi("{Y}")#text(" be an independent copy of ")#mi("{X}")#text(". Since ")#mi("{{\\Bbb E} f(Y) = 0}")#text(", we see from ")#link("http://en.wikipedia.org/wiki/Jensen%27s_inequality")[#text("Jensen’s inequality")]#text(" that ")#mi("{{\\Bbb E} \\exp( - t f(Y) ) \\geq 1}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} \\exp( t f(X) ) \\leq {\\Bbb E} \\exp( t (f(X)-f(Y)) ).")]]

#text("With an eye to exploiting ")#link(<tao-4e448897946ead9e39e8>)[#text("(5)")]#text(", one might seek to use the fundamental theorem of calculus to write")

#align(center)[#tao-fit-display[#mitex("f(X) - f(Y) = \\int_0^1 \\frac{d}{d\\lambda} f( (1-\\lambda) Y + \\lambda X )\\ d\\lambda.")]]

#text("But actually it turns out to be smarter to use a circular arc of integration, rather than a line segment:")

#align(center)[#tao-fit-display[#mitex("f(X) - f(Y) = \\int_0^{\\pi/2} \\frac{d}{d\\theta} f( Y \\cos \\theta + X \\sin \\theta )\\ d\\theta.")]]

#text("The reason for this is that ")#mi("{X_\\theta := Y \\cos \\theta + X \\sin \\theta}")#text(" is another gaussian random variable equivalent to ")#mi("{N(0,1)^d}")#text(", as is its derivative ")#mi("{X^{\\prime}_\\theta := -Y \\sin \\theta + X \\cos \\theta}")#text("; furthermore, and crucially, these two random variables are ")#emph[#text("independent")]#text(".")

#text("To exploit this, we first use Jensen’s inequality to bound")

#align(center)[#tao-fit-display[#mitex("\\exp( t (f(X) - f(Y))) \\leq \\frac{2}{\\pi} \\int_0^{\\pi/2} \\exp( \\frac{\\pi t}{2} \\frac{d}{d\\theta} f( X_\\theta ) )\\ d\\theta.")]]

#text("Applying the chain rule and taking expectations, we have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} \\exp( t (f(X) - f(Y))) \\leq \\frac{2}{\\pi} \\int_0^{\\pi/2} {\\Bbb E} \\exp( \\frac{\\pi t}{2} \\nabla f( X_\\theta ) \\cdot X^{\\prime}_\\theta )\\ d\\theta.")]]

#text("Let us condition ")#mi("{X_\\theta}")#text(" to be fixed, then ")#mi("{X^{\\prime}_\\theta \\equiv N(0,1)^d}")#text("; applying ")#link(<tao-4e448897946ead9e39e8>)[#text("(5)")]#text(", we conclude that ")#mi("{\\frac{\\pi t}{2} \\nabla f( X_\\theta ) \\cdot X^{\\prime}_\\theta}")#text(" is normally distributed with standard deviation at most ")#mi("{\\frac{\\pi t}{2}}")#text(". As such we have")

#align(center)[#tao-fit-display[#mitex("{\\Bbb E} \\exp( \\frac{2t}{\\pi} \\nabla f( X_\\theta ) \\cdot X^{\\prime}_\\theta ) \\leq \\exp( C t^2 )")]]

#text("for some absolute constant ")#mi("{C}")#text("; integrating out the conditioning on ")#mi("{X_\\theta}")#text(" we obtain the claim.")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39309")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Dear Prof Tao,")

#text("How do you pass from line segment integral to circular arc integral?")

#text("by change of variable ")#mi("\\lambda=\\sin \\theta")#text(" ?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39310")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2009")])]

#text("Dear student,")

#text("The circular arc identity is established directly from the fundamental theorem of calculus ")#mi("F(\\pi/2) - F(0) = \\int_0^{\\pi/2} \\frac{d}{d\\theta} F(\\theta)\\ d\\theta")#text(", rather than from applying a change of variables from the line segment identity (which doesn’t work). The point is that in higher dimensions, there are many inequivalent ways to apply the fundamental theorem of calculus to expand f(Y)-f(X) – one for each path from X to Y, and the key is to select the right one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39507")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2009")])]

#text("Dear Prof. Tao,")

#text("I remember once you wrote that you will teach random matrix theory next semester. my request is that")

#text("Would you please start to post little by little some notes related to prerequisite material for that course? if we start to study during summer and get enough background it would be perfect for us.")

#text("thank you very much")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39516")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("Actually, the class will be starting in the winter quarter (next January). I have not yet decided exactly what the topics will be, but apart from a basic graduate education in analysis, probability, linear algebra, and combinatorics it should be fairly self-contained.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e6a4447e02c6c901ac15c01b846047a0e5d3fd5283f5fb04c14a8dbfb331562-4efe03feac9a22080ad3f1fb7d18e47f116b5e40c79e015fddf78e4cde292a71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oded")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39525")[#strong[#text("Oded")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("One minor comment: the statement in Remark 2 seems almost vacuous. After all, the distance between *any* two points in {-1,+1}^n is at most 2\\sqrt{n}. Maybe the correct behavior should be n^{1/4}?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("Hmm, good point. On the other hand, the Azuma/McDiarmid argument also works if the ")#mi("\\ell^2")#text(" metric is replaced by the much larger ")#mi("\\ell^1")#text(" metric (although the mean or median of ")#mi("\\text{dist}(X,V)")#text(" is somewhat harder to compute in that case). I’ll adjust the text to reflect this. (One could make the case that Talagrand’s inequality is to ")#mi("\\ell^2")#text(" as Azuma’s inequality or McDiarmid’s inequality is to ")#mi("\\ell^1")#text("; note the crucial use of Pythagoras’ theorem in the middle of the proof of Talagrand’s inequality.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vedadi")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39534")[#strong[#text("vedadi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("Dear Prof. Tao,")

#text("just after ” square and rearrange trick”, you say that you use Jensen’s inequality.")

#text("I guess your convex function is ")#mi("\\exp{-tx}")#text(" for ")#mi("t>0.")

#text("in that case why do not we have ")#mi("E(\\exp{-tf(Y)}) \\geq 1")#text(" ?")

#text("Jensen’s ineq is ")#mi("E(\\phi(X)) \\geq \\phi (E(X))")#text(", right?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39535")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2009")])]

#text("Dear vedadi,")

#text("Yes, that was a typo, the expectation should be at least 1, rather than at most 1. (The subsequent inequalities did not have the typo, though.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39561")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2009")])]

#text("Dear Prof Tao,")

#text("When we say ”let Y be an independent copy of X….” How do we guarantee the existence of that copy? Don’t we have some philosophical questions here too?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39571")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear student,")

#text("Independent copies of a random variable can always be generated by the product measure construction,")

#link("http://en.wikipedia.org/wiki/Product_measure")[#text("http://en.wikipedia.org/wiki/Product_measure")]

#text("This requires extending the underlying probability space to a finer one, but probability theory is designed in such a way that one can always do this without affecting any probabilistically meaningful quantities, such as probabilities of events or expectations, moments, correlations, and distributions of random variables. (As such, one of the guiding philosophies of probability theory is to not work with the underlying probability space if at all possible. The situation is somewhat analogous to differential geometry, which is designed to be invariant under changes of coordinates, and so the philosophy is often to avoid explicit manipulation of such coordinates whenever possible.)")

#text("Kallenberg’s “Foundations of modern probability” is a good reference for these sorts of foundational issues. However, it should be said that while such issues are of course important, especially from a philosophical or logical point of view, they rarely affect day-to-day usage of probability, much as the construction of the real numbers does not play a prominent role in real arithmetic, or as the construction of the Lebesgue integral does not play a prominent role in computation and estimation of integrals.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2009")])]

#text("Dear Prof. Tao,")

#text("Could you please write a blog post on ”Large Deviation Principles” this summer by explaining the theory by examples and from your point of view?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f300a6415e888416a2a2c33c85ee4fb13c802683f9b7c257e69db82909562bc9-f405f4c4cdc4593c93b4e50522b73be6d6d5dc3f1a9d38193100f2f868001ee3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ebrima saye")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39831")[#strong[#text("ebrima saye")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("You are inspirational!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of student")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39840")[#strong[#text("student")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2009")])]

#text("Dear Prof. Tao,")

#text("I could not find in which part I am doing a mistake in the following argument :")

#text("we know that if two random variables have the same distribution then their mean is the same. now")

#text("Let ")#mi("Z")#text(" be a standard normal rv. and ")#mi("Z^{\\prime}")#text(" be an independent copy of it. then ")#mi("Z \\cdot Z")#text(" and ")#mi("Z \\cdot Z^{\\prime}")#text(" have the same distribution (?) but ")#mi("E[Z \\cdot Z]=1")#text(" and ")#mi("E[Z \\cdot Z^{\\prime}]=E[Z]E[Z^{\\prime}]=0")

#text("what is going on here?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39852")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear student:")

#text("The same issue crops up if Z is a Bernoulli distribution (equal to +1 with probability 1/2, and -1 with probability -1/2). This example is elementary enough that you can work out everything from first principles; if you do so, you should see the error.")

#text("Dear Ben: X decomposes into two orthogonal components, PX and X-PX. X-PX is the orthogonal projection of X to V, so the distance from X to V is the length of PX. Since P is an orthogonal projection, ")#tao-math("\\left\\|PX\\right\\|^2 = X \\cdot PX", block: false)#text(".")

#text("Alternatively, one can pick a coordinate system so that V is a coordinate plane, in which case all calculations can be done explicitly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39848")[#strong[#text("ben")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2009")])]

#text("Dear Prof Tao")

#text("could you explain why")

#mi("dist (X, V)^2= X \\cdot PX")#text(" ?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39896")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2009")])]

#text("Dear Prof. Tao,")

#text("I did not see at which step you are using the independence of ")#mi("X_{\\theta}")#text(" and ")#mi("X_{\\theta}^{\\prime} .")

#text("and in the last paragraf, when you say ” let’s condition ")#mi("X_{\\theta}")#text(" to be fixed….” do you mean you that you are using the following fact:")

#mi("E[......]=E[E[.....\\| X_{\\theta}]]")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("Yes, this is what is happening when one is conditioning on ")#mi("X_\\theta")#text(". The independence of ")#mi("X_\\theta")#text(" and ")#mi("X^{\\prime}_\\theta")#text(" is used precisely at this step, to ensure that ")#mi("X^{\\prime}_\\theta")#text(" retains its normal distribution even after conditioning on a fixed value of ")#mi("X_\\theta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39925")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2009")])]

#text("Dear Prof. Tao,")

#text("Let ")#mi("X, Y")#text(" be two independent standart normal r.vs. then")

#mi("E[\\exp(X \\cdot Y)]=E[E[\\exp(X \\cdot Y) | Y]]")

#text("since ")#mi("E[\\exp(X \\cdot Y) | Y=t]=\\exp(t^2/2)")#text(" we have")

#mi("E[\\exp(X \\cdot Y) | Y]=\\exp(Y^2 / 2)")#text(" therefore")

#mi("E[\\exp(X \\cdot Y)]=E[\\exp(Y^2 / 2) ]")

#text("is this argument true?")

#text("in which step we are using independence of ")#mi("X")#text(" and ")#mi("Y?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2009")])]

#text("Yes, this is correct. The independence is needed to establish the identity ")#mi("{\\Bbb E}( \\exp(X \\cdot Y) | Y=t ) = \\exp(t^2/2)")#text(" (because one needs X to remain normally distributed after conditioning on the event Y=t).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lutfu")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39952")[#strong[#text("lutfu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2009")])]

#text("Dear Prof Tao,")

#text("Let ")#mi("X_{1}, X_{2},...")#text(" be a seq of i.i.d. rvs. with mean zero.")

#text("as we know from ")#mi("SLL")#text(" as ")#mi("N \\rightarrow \\infty")#text(" the distribution of")

#mi("\\frac{S_n}{n}")#text(" concentrates on a point, i.e. limiting distribution is ")#mi("\\delta_{0}.")#text(" (a.s. implies in distribution)")

#text("Under the existence of second moment we know the limiting distribution of")

#mi("\\frac{S_n}{\\sqrt{n}}")#text(" is standard normal, i.e Gaussian measure.")

#text("my question is that do we know the distribution of")#linebreak()#text(" ")#mi("\\frac{S_n}{n^{\\alpha}}")#text(" for ")#mi("0< \\alpha <1")#text(" under the suitable conditions? to which measure do they concentrate?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-39954")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2009")])]

#text("Dear Prof. Tao,")

#text("Could you please give a proof for the Azuma-Hoeffding inequality?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Concentration of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-43072")[#strong[#text("254A, Notes 1: Concentration of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("[…] by induction on dimension . In the case when are Bernoulli variables, this can be done; see this previous blog post. In the general case, it turns out that in order to close the induction properly, one must […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-43094")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("[…] by induction on dimension . In the case when are Bernoulli variables, this can be done; see this previous blog post. In the general case, it turns out that in order to close the induction properly, one must […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/175994f916f1b380bd6ab64fde5f5c6c721aedcd8548d10b7bb31eb25900c1a8-ef2c322d36f1791a3794a1ddc32a8bcd738281a22f3252b2cf8e90f32dec0357.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Laurent Jacques")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-45484")[#strong[#text("Laurent Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")])]

#text("Dear Terence,")

#text("Thank you for this verrry interesting post. I’d like to share with you some elements.")

#text("From what I know, Sub-Gaussian Random Variable (SGRV), such as Bernoulli RV, centered Uniform RV, Gaussian RV, … are defined as follows:")

#text("X is a SGRV if there exists one c>0 such that for all real value s,")#linebreak()#text(" E[ \\exp (s X) ] <= exp (c^2 s^2/2)")

#text("See for instance V. V. Buldygin publications, e.g. \"Sub-Gaussian random variables\", doi:10.1007/BF01087176")

#text("If I'm not wrong, one interesting property of SBRV is that any linear combination of SGRV is SGRV with known characteristics. In particular, the \"Gaussian standard\", defined as the minimal \"c\" such that the definition above holds, behaves as the standard deviation of Gaussian RV with respect to linear combination of SGRV.")

#text("This implies also that if you rotate a sub-Gaussian random vector with iid SGRV components, you get also a sub-Gaussian random vector. The components of this latter are perhaps not iid anymore but at least they have all the same \"Gaussian standard\".")

#text("My question is thus the following:")

#text("**Do you think that Theorem 4 above could be easily generalized to sub-Gaussian random vectors of components with unit gaussian standard?**")

#text("It seems indeed that in many places in you proof, you use already key ingredients for this generalization:")#linebreak()#text(" * the sub-gaussian inequality definition;")#linebreak()#text(" * linear combinations (rotation) of Gaussian RVs which are themselves Gaussian.")

#text("Or perhaps this generalization is already known in the community (I didn't see it anyway in Talagrand/Ledoux's books)?")

#text("Best,")#linebreak()#text(" Laurent")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-46531")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" I have two questions about the proof for Proposition 4.")#linebreak()#text(" Firstly, It seems that there is a typo when you bound")#linebreak()#text(" exp(t(F(X)-F(Y))) by using Jensen Inequality, please check it if possible.")#linebreak()#text(" Secondly, the aim is")#linebreak()#text(" Eexp(tF(X))<=exp(Ct^2),")#linebreak()#text(" but the proof only tells us")#linebreak()#text(" Eexp(tF(X))<=exp(Ct),")#linebreak()#text(" Please give some explaination if possible.")#linebreak()#text(" Thanks.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-46580")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" Have you checked the bound of exp(t(F(X)-F(Y))) in the proof of Proposition 4? There is still a typo in my opinion.")

#mi("\\exp(t(f(X) - f(Y))) \\leq \\frac{2}{\\pi} int_0^{\\pi/2} \\exp( \\frac{\\pi t}{2} \\frac{d}{d \\theta} f(X_\\theta) \\ {d}{\\theta})")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-46611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" Can you tell me how to get ")#mi("E\\exp(\\frac{\\pi t}{2}\\nabla f(X_\\theta)X^{\\prime}_\\theta)\\leq\\exp(Ct^2)")#text("? Some hints will be OK.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-46620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("If X is a Gaussian with mean zero and variance ")#mi("\\sigma^2")#text(", then the moment generating function is ")#mi("{\\bf E} \\exp(tX) = \\exp(t^2 \\sigma^2/2)")#text(", as can be seen by completing the square.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-46632")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" I get it. Thanks for your reply. So far I have got a lot of interesting and useful mathemetical knowledge from your blog. Your earnest attitude and diligence impressed me. Thanks again.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-48133")[#strong[#text("The Determinant of Random Bernoulli Matrices « Tsourolampis Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2010")]

#text("[…] [6] Talagrand’s inequality ")#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/")[#text("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-51996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2011")])]

#text("Dear Prof. Tao,")

#text("is Talagrand concentration inequality still valid if we have independent but not identically distributed normally distributed component of ")#mi("\\mathbb{X}")#text("?")

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-142047")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2012")])]

#text("Hi Professor Tao,")

#text("Does dist(X,V) = euclidean distance(X,V)?")

#text("Thanks.")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3949e3b41126b0c0e67d1490b2dada3f8d8fd46f37ff23e224cfee81138f656f-2d24d21b3c0d8c1faabab01de00fc414c426cb19aeed44d84f8799cc574c22bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sabyasachi chatterjee")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-142680")[#strong[#text("sabyasachi chatterjee")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2012")])]

#text("Hello Professor Tao,")#linebreak()#text(" I have had to investigate the concentration of the log determinant of a matrix. Specifically, suppose M1,..Mk are random matrices p by p, iid from a given distribution(can assume that the entries of the matrix are bounded a.s or other regularity conds if needed) whose expected value is the identity matrix I. Now if I consider the matrix mean..(M1+…Mk)/k and look at its log determinant..will it concentrate around its mean? Will the mean go to zero as k go to infinity? Hence will it concentrate around 0? Is there any known result on this? Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/191624e64b1380934e3d35a2f3936582966e9880275674a116e8e49ae387479e-fa69fbec0daaee1f552e60323785436a801bd0b24aea715e0801b42e6db37576.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathepsilon")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-151130")[#strong[#text("mathepsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2012")])]

#text("Does that mean, the small constant c in the gaussian concentration inequaltiy for lipschitz function is (pi^2)/8? Thank you! I really can not find this constant elsewhere.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-151231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2012")])]

#text("Well, the arguments given in the above post are not necessarily optimal; there may be other arguments that give a better value of c. (Note also that the value of c in Proposition 3 and Proposition 4 may differ, for instance the above arguments give a loss of a factor of 4 when passing from the latter to the former.)")

#text("I would try Ledoux’s book, as it has a number of proofs of this inequality and may discuss the question of optimal constants somewhere. (For instance, log-Sobolev methods tend to be quite sharp in general, and should yield good results in this case.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f03e090dc2d4607684f9ad7e5c1c5ccbd22ff2078d67df3c99b8d98cb457e9f3-2e635b91e81f10d0b8bb64cdf86d22dbcf99b7bbd173d4a6331c99c2cdd08450.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-257402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Dear Terry Tao,")

#text("can you get limit behavior of dist(X,V) (using Talagrand inequality or otherwise)?")

#text("Proposition 1 suggests that perhaps (after properly normalizing), the distribution of dist(X,V) converges to the normal distribution. Is it true?")

#text("I think it would nicely illustrate the strength of the presented method — similarly to the comparison of Chernoff bound and Central limit theorem.")

#text("Thanks,")

#text("Robert Samal")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-257418")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("When X is a gaussian vector, then dist(X,V)^2 is a chi-squared distribution (with the number of degrees of freedom equal to the codimension of V), and so the central limit theorem shows that dist(X,V)^2 (and thus also dist(X,V)) is approximately gaussian when the codimension is large. For small codimension, one gets a chi distribution instead.")

#text("In the non-gaussian case, one can presumably get similar results either through a Lindeberg exchange argument, or through a central limit theorem for quadratic forms, although I don’t know if this has been done explicitly in the literature.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-410252")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2014")])]

#text("Is proposition 4 valid for idd rvs with exponential moments?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-459129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2015")])]

#text("Small typo in props 3 and 4: n should be d (or vice versa)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a79d0e8b49b53822901fcac4fe57d057173351988f8b2fd9af846950ad0db5ea-9133deb55ae8bc13753eac65d1f07ea2dabd19e07a7d9bc8318e4d36c2ced8e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-508812")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("Dear Prof. Tao,")

#text("I am confused about some detail of the proof to proposition 2. How is ")#mi("dist(x,A)")#text(" defined when ")#mi("A")#text(" is an open set? And how is (4) defined if ")#mi("A_{\\pm 1}")#text(" are empty sets?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a79d0e8b49b53822901fcac4fe57d057173351988f8b2fd9af846950ad0db5ea-9133deb55ae8bc13753eac65d1f07ea2dabd19e07a7d9bc8318e4d36c2ced8e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ray")]], [#link("https://terrytao.wordpress.com/2009/06/09/talagrands-concentration-inequality/#comment-508815")[#strong[#text("Ray")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("never mind, I realized that these details can be worked out and does not affect the proof.")
]
]
