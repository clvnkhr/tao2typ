// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/
// Converted to Typst by tao2typ: "2026-10-14T15:16:36.643210+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 4: Multiple recurrence", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 4: Multiple recurrence")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In the ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("previous lecture")]#text(", we established single recurrence properties for both open sets and for sequences inside a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(". In this lecture, we generalise these results to multiple recurrence. More precisely, we shall show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(". (Multiple recurrence in open covers) Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system, and let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of X. Then there exists ")#mi("U_\\alpha")#text(" such that for every ")#mi("k \\geq 1")#text(", we have ")#mi("U_\\alpha \\cap T^{-r} U_\\alpha \\cap \\ldots \\cap T^{-(k-1)r} U_\\alpha \\neq \\emptyset")#text(" for infinitely many r.")
]

#text("Note that this theorem includes Theorem 1 from the ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("previous lecture")]#text(" as the special case ")#mi("k=2")#text(". This theorem is also equivalent to the following well-known combinatorial result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(". (")#link("http://en.wikipedia.org/wiki/Van_der_Waerden%27s_theorem")[#text("van der Waerden’s theorem")]#text(") Suppose the integers ")#mi("{\\Bbb Z}")#text(" are finitely coloured. Then one of the colour classes contains arbitrarily long arithmetic progressions.")
]

#strong[#text("Exercise 1")]#text(". Show that Theorem 1 and Theorem 2 are equivalent. ")#mi("\\diamond")

#strong[#text("Exercise 2")]#text(". Show that Theorem 2 fails if “arbitrarily long” is replaced by “infinitely long”. Deduce that a similar strengthening of Theorem 1 also fails. ")#mi("\\diamond")

#strong[#text("Exercise 3")]#text(". Use Theorem 2 to deduce a finitary version: given any positive integers m and k, there exists an integer N such that whenever ")#mi("\\{1,\\ldots,N\\}")#text(" is coloured into m colour classes, one of the colour classes contains an arithmetic progression of length k. (Hint: use a “compactness and contradiction” argument, as in my ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("article on hard and soft analysis")]#text(".) ")#mi("\\diamond")

#text("We also have a stronger version of Theorem 1:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(". (Multiple Birkhoff recurrence theorem) Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system. Then for any ")#mi("k \\geq 1")#text(" there exists a point ")#mi("x \\in X")#text(" and a sequence ")#mi("r_j \\to \\infty")#text(" of integers such that ")#mi("T^{i r_j} x \\to x")#text(" as ")#mi("j \\to \\infty")#text(" for all ")#mi("0 \\leq i \\leq k-1")#text(".")
]

#text("These results already have some application to equidistribution of explicit sequences. Here is a simple example (which is also a consequence of ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("Weyl’s equidistribution theorem")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(". Let ")#mi("\\alpha")#text(" be a real number. Then there exists a sequence ")#mi("r_j \\to \\infty")#text(" of integers such that ")#mi("\\text{dist}(r_j^2 \\alpha,{\\Bbb Z}) \\to 0")#text(" as ")#mi("j \\to \\infty")#text(".")
]

#strong[#text("Proof")]#text(". Consider the skew shift system ")#mi("X = ({\\Bbb R}/{\\Bbb Z})^2")#text(" with ")#mi("T(x,y) := (x+\\alpha,y+x)")#text(". By Theorem 3, there exists ")#mi("(x,y) \\in X")#text(" and a sequence ")#mi("n_j \\to \\infty")#text(" such that ")#mi("T^{r_j}(x,y)")#text(" and ")#mi("T^{2r_j}(x,y)")#text(" both convege to ")#mi("(x,y)")#text(". If we then use the easily verified identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(x,y) - 2T^{r_j}(x,y) + T^{2r_j}(x,y) = (0, r_j^2 \\alpha)")]]

#text("we obtain the claim. ")#mi("\\Box")

#strong[#text("Exercise 4.")]#text(" Use Theorem 1 or Theorem 2 in place of Theorem 3 to give an alternate derivation of Corollary 1. ")#mi("\\diamond")

#text("As in the ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("previous lecture")]#text(", we will give both a traditional topological proof and an ultrafilter-based proof of Theorem 1 and Theorem 3; the reader is invited to see how the various proofs are ultimately equivalent to each other.")

#metadata(none) <tao-9ace4c1d3a8b0f333715>

#heading(level: 1)[#text("— Topological proof of van der Waerden —")]

#text("We begin by giving a topological proof of Theorem 1, due ")#link("http://www.ams.org/mathscinet-getitem?mr=531271")[#text("to Furstenberg and Weiss")]#text(", which is secretly a translation of van der Waerden’s original “colour focusing” combinatorial proof of Theorem 2 into the dynamical setting.")

#text("To prove Theorem 1, it suffices to show the following slightly weaker statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a topological dynamical system, and let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of X. Then for every ")#mi("k \\geq 1")#text(" there exists an open set ")#mi("U_\\alpha")#text(" which contains an arithmetic progression ")#mi("x, T^r x, T^{2r} x, \\ldots, T^{(k-1)r}x")#text(" for some ")#mi("x\\in X")#text(" and ")#mi("r > 0")#text(".")
]

#text("To see how Theorem 4 implies Theorem 1, first observe from compactness that we can take the open cover to be a finite cover. Then by the infinite pigeonhole principle, it suffices to establish Theorem 1 for each ")#mi("k \\geq 1")#text(" separately. For each such k, Theorem 4 gives a single arithmetic progression ")#mi("x, T^r x, \\ldots, T^{(k-1)r} x")#text(" inside one of the ")#mi("U_\\alpha")#text(". By replacing the system ")#mi("(X, T)")#text(" with the product system ")#mi("(X \\times {\\Bbb Z}/N{\\Bbb Z}, (x,m) \\mapsto (Tx,m+1))")#text(" for some large N and replacing the open cover ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" of X with the open cover ")#mi("(U_\\alpha \\times \\{m\\})_{\\alpha \\in A, m \\in {\\Bbb Z}/N{\\Bbb Z}}")#text(" of ")#mi("X \\times {\\Bbb Z}/N{\\Bbb Z}")#text(", one can make the spacing r in the arithmetic progression larger than any specified integer N. Thus by another application of the infinite pigeonhole principle, one of the ")#mi("U_\\alpha")#text(" contains arithmetic progressions with arbitrarily large step r, and the claim follows.")

#text("Now we need to prove Theorem 4. By Lemma 1 of ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("Lecture 2")]#text(" to establish this theorem for minimal dynamical systems. We will need to note that for minimal systems, Theorem 4 automatically implies the following stronger-looking statement:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a minimal topological dynamical system, let U be a non-empty open set in X, and let ")#mi("k \\geq 1")#text(". Then U contains an arithmetic progression ")#mi("x, T^r x, \\ldots T^{(k-1)r} x")#text(" for some ")#mi("x \\in X")#text(" and ")#mi("r \\geq 1")#text(".")
]

#text("Indeed, the deduction of Theorem 5 from Theorem 4 is immediate from the following useful fact (cf. Lemma 1 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(". Let ")#mi("(X,{\\mathcal F},T)")#text(" be a minimal topological dynamical system, and let U be a non-empty open set in X. Then X can be covered by a finite number of translates ")#mi("T^n U")#text(" of U.")
]

#strong[#text("Proof")]#text(". The set ")#mi("X \\backslash \\bigcup_{n \\in {\\Bbb Z}} T^n U")#text(" is a proper closed invariant subset of X, which must therefore be empty since X is minimal. The claim then follows from the compactness of X. ")#mi("\\Box")#text(".")

#text("(Of course, the claim is highly false for non-minimal systems; consider for instance the case when T is the identity. More generally, if X is non-minimal, consider an open set U which is the complement of a proper subsystem of X.)")

#text("Now we need to prove Theorem 4. We do this by induction on k. The case k=1 is trivial, so suppose ")#mi("k \\geq 2")#text(" and the claim has already been shown for k-1. By the above discussion, we see that Theorem 5 is also true for k-1.")

#text("Now fix a minimal system ")#mi("(X,{\\mathcal F},T)")#text(" and an open cover ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(", which we can take to be finite. We need to show that one of the ")#mi("U_\\alpha")#text(" contains an arithmetic progression ")#mi("x, T^r x, \\ldots, T^{(k-1)r} x")#text(" of length k.")

#text("To do this, we first need an auxiliary construction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(". (Construction of colour focusing sequence) Let the notation and assumptions be as above. Then for any ")#mi("J \\geq 0")#text(" there exists a sequence ")#mi("x_0,\\ldots,x_J")#text(" of points in X, a sequence ")#mi("U_{\\alpha_0}, \\ldots, U_{\\alpha_J}")#text(" of sets in the open cover (not necessarily distinct), and a sequence ")#mi("r_1,\\ldots,r_J")#text(" of positive integers such that ")#mi("T^{i(r_{a+1} + \\ldots + r_b)} x_b \\in U_{\\alpha_a}")#text(" for all ")#mi("0 \\leq a \\leq b \\leq J")#text(" and ")#mi("1 \\leq i \\leq k-1")#text(".")
]

#strong[#text("Proof")]#text(". We induct on J. The case J=0 is trivial. Now suppose inductively that ")#mi("J \\geq 1")#text(", and that we have already constructed ")#mi("x_0,\\ldots,x_{J-1}")#text(", ")#mi("U_{\\alpha_0},\\ldots,U_{\\alpha_{J-1}}")#text(", and ")#mi("r_1,\\ldots,r_{J-1}")#text(" with the required properties. Now let V be a suitably small neighbourhood of ")#mi("x_{J-1}")#text(" (depending on all the above data) to be chosen later. By Theorem 5 for k-1, V contains an arithmetic progression ")#mi("y, T^{r_J} y, \\ldots, T^{(k-2) r_J} y")#text(" of length k-1. If one sets ")#mi("x_J := T^{-r_J} y")#text(", and lets ")#mi("U_{\\alpha_J}")#text(" be an arbitrary set in the open cover containing ")#mi("x_J")#text(", then we observe that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("T^{i(r_{a+1} + \\ldots + r_J)} x_J = T^{i(r_{a+1} + \\ldots + r_{J-1})} ( T^{(i-1) r_J} y ) \\in T^{i(r_{a+1} + \\ldots + r_{J-1})}(V)")]]

#text("for all ")#mi("0 \\leq a < J")#text(" and ")#mi("1 \\leq i \\leq k-1")#text(". If V is a sufficiently small neighbourhood of ")#mi("x_{J-1}")#text(", we thus see (from the continuity of the ")#mi("T^{i(r_{a+1} + \\ldots + r_{J-1})}")#text(" that we verify all the required properties needed to close the induction. ")#mi("\\Box")

#text("We apply the above lemma with J equal to the number of sets in the open cover. By the pigeonhole principle, we can thus find ")#mi("0 \\leq a < b \\leq J")#text(" such that ")#mi("U_{\\alpha_a} = U_{\\alpha_b}")#text(". If we then set ")#mi("x := x_b")#text(" and ")#mi("r := r_{a+1} + \\ldots + r_b")#text(" we obtain Theorem 4 as required. ")#mi("\\Box")

#text("It is instructive to compare the k=2 case of the above arguments with the proof of Theorem 1 from the ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("previous lecture")]#text(". (For a comparison of this type of proof with the more classical combinatorial proof, see my ")#link("http://front.math.ucdavis.edu/math.CO/0604456")[#text("Montreal lecture notes")]#text(".)")

#heading(level: 1)[#text("— Ultrafilter proof of van der Waerden —")]

#text("We now give a translation of the above proof into the language of ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilters")]#text(" (or more precisely, the language of ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93%C4%8Cech_compactification")[#text("Stone-Čech compactifications")]#text("). This language may look a little strange, but it will be convenient when we study more general colouring theorems in the next lecture. As before, we will prove Theorem 4 instead of Theorem 1 (thus we only need to find one progression, rather than infinitely many). The key proposition is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(". (Ultrafilter version of van der Waerden) Let ")#mi("p")#text(" be a minimal element of ")#mi("\\beta {\\Bbb Z}")#text(". Then for any ")#mi("k \\geq 1")#text(" there exists ")#mi("q \\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" such that")

#mi("\\lim_{(n,r) \\to q} n + ir + p = p \\text{ for all } 0 \\leq i \\leq k-1")#text(". (3)")
]

#text("Suppose for the moment that this proposition is true. Applying it with some minimal element p of ")#mi("\\beta {\\Bbb Z}")#text(" (which must exist, thanks to Exercise 10 of the ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("previous lecture")]#text("), we obtain ")#mi("q \\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" obeying (3). If we let ")#mi("x := T^p y")#text(" for some arbitrary ")#mi("y \\in X")#text(", we thus obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\lim_{(n,r) \\to q} T^{n+ir} x = x \\text{ for all } 0 \\leq i \\leq k-1.")]]

#text("If we let ")#mi("U_\\alpha")#text(" be an element of the open cover that contains x, we thus see that ")#mi("T^{n+ir} x \\in U_\\alpha")#text(" for all ")#mi("0 \\leq i \\leq k-1")#text(" and all ")#mi("(n,r) \\in {\\Bbb Z} \\times {\\Bbb N}")#text(" which lie in a sufficiently small neighbourhood of q. Since a LCH space is always dense in its Stone-Čech compactification, the space of all (n,r) with this property is non-empty, and Theorem 4 follows.")

#strong[#text("Proof of Proposition 1")]#text(". We induct on k. The case k=1 is trivial (one could take e.g. ")#mi("q = (0,1)")#text(", so suppose ")#mi("k > 1")#text(" and that the claim has already been proven for k-1. Then we can find ")#mi("q^{\\prime} \\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lim_{(n,r) \\to q^{\\prime}} n + ir + p = p")]]

#text("for all ")#mi("0 \\leq i \\leq k-2")#text(".")

#text("Now consider the expression")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("p_{i,a,b} := \\lim_{(n_1,r_1) \\to q^{\\prime}} \\ldots \\lim_{(n_b,r_b) \\to q^{\\prime}} i(r_{a+1}+\\ldots+r_b) + m_b + p")]]

#text("for any ")#mi("1 \\leq a \\leq b")#text(" and ")#mi("1 \\leq i \\leq k-1")#text(", where")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("m_b := \\sum_{i=1}^b n_i - r_i.")]]

#text("Applying (5) to the ")#mi("(n_b,r_b)")#text(" limit in (6), we obtain the recursion ")#mi("p_{i,a,b} = p_{i,a,b-1}")#text(" for all ")#mi("b > a")#text(". Iterating this, we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("p_{i,a,b} = p_{i,a,a} = p_{0,a,a}")]]

#text("for all ")#mi("1 \\leq i \\leq k-1")#text(". For i=0, (8) need not hold, but instead we have the easily verified identity")

#align(center)[#mi("p_{0,a,b} = p_{0,b,b}")#text(". (8′)")]

#text("Now let ")#mi("p_* \\in \\beta {\\Bbb N} \\backslash {\\Bbb N}")#text(" be a non-principal ultrafilter and define ")#mi("p^{\\prime} := \\lim_{a \\to p_*} p_{0,a,a} = \\lim_{b \\to p_*} p_{0,b,b}")#text(". Observe from (6) that all the ")#mi("p_{i,a,b}")#text(" lie in the closed set ")#mi("\\beta {\\Bbb Z} + p")#text(", and so p’ does also. Since p is minimal, there must exist ")#mi("p^{\\prime\\prime} \\in \\beta {\\Bbb Z}")#text(" such that p = p” + p’. Expanding this out using (8) or (8′), we conclude that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\lim_{h \\to p^{\\prime\\prime}} \\lim_{a \\to p_*} \\lim_{b \\to p_*} h+p_{i,a,b} = p")]]

#text("for all ")#mi("0 \\leq i \\leq k-1")#text(". Applying (6), we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\lim_{h \\to p^{\\prime\\prime}} \\lim_{a \\to p_*} \\lim_{b \\to p_*} \\lim_{(n_1,r_1) \\to q^{\\prime}} \\ldots \\lim_{(n_b,r_b) \\to q^{\\prime}} n+ir+p = p")]]

#text("where ")#mi("n := h + m_b")#text(" and ")#mi("r := r_{a+1}+\\ldots+r_b")#text(". Now, define ")#mi("q \\in \\beta ({\\Bbb Z} \\times {\\Bbb N})")#text(" to be the limit")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("q := \\lim_{h \\to p^{\\prime\\prime}} \\lim_{a \\to p_*} \\lim_{b \\to p_*} \\lim_{(n_1,r_1) \\to q^{\\prime}} \\ldots \\lim_{(n_b,r_b) \\to q^{\\prime}} (n,r)")]]

#text("then we obtain Proposition 1 as desired. ")#mi("\\Box")

#strong[#text("Exercise 5")]#text(". Strengthen Proposition 1 by adding the additional conclusion ")#mi("\\lim_{(n,r) \\to q} r \\not \\in {\\Bbb N}")#text(". Using this stronger version, deduce Theorem 1 directly without using the trick of multiplying X with a cyclic shift system that was used to deduce Theorem 1 from Theorem 4. ")#mi("\\diamond")

#text("Theorem 1 can be generalised to multiple commuting shifts:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6")]#text(". (Multiple recurrence in open covers) Let ")#mi("(X,{\\mathcal F})")#text(" be a compact topological space, and let ")#mi("T_1,\\ldots,T_k: X \\to X")#text(" be commuting homeomorphisms. Let ")#mi("(U_\\alpha)_{\\alpha \\in A}")#text(" be an open cover of X. Then there exists ")#mi("U_\\alpha")#text(" such that ")#mi("T_1^{-r} U_\\alpha \\cap \\ldots \\cap T_k^{-r} U_\\alpha \\neq \\emptyset")#text(" for infinitely many r.")
]

#strong[#text("Exercise 6")]#text(". By adapting one of the above arguments, prove Theorem 6. ")#mi("\\diamond")

#strong[#text("Exercise 7")]#text(". Use Theorem 6 to establish the following the ")#emph[#text("multidimensional van der Waerden theorem")]#text(" (due to Gallai): if a lattice ")#mi("{\\Bbb Z}^d")#text(" is finitely coloured, and ")#mi("v_1,\\ldots,v_d \\in {\\Bbb Z}^d")#text(", then one of the colour classes contains a pattern of the form ")#mi("n + rv_1,\\ldots,n+rv_d")#text(" for some ")#mi("n \\in {\\Bbb Z}^d")#text(" and some non-zero r. ")#mi("\\diamond")

#strong[#text("Exercise 8")]#text(". Show that Theorem 6 can fail, even for ")#mi("k=3")#text(" and ")#mi("T_1 = \\text{id}")#text(", if the shift maps ")#mi("T_j")#text(" are not assumed to commute. (")#emph[#text("Hint")]#text(": First show that in the free group ")#mi("F_2")#text(" on two generators ")#mi("a, b")#text(", and any word ")#mi("w \\in F_2")#text(" and non-zero integer r, the three words ")#mi("w, a^n w, b^n w")#text(" cannot all begin with the same generator after reduction. This can be used to disprove a non-commutative multidimensional van der Waerden theorem, which can turn be used to disprove a non-commutative version of Theorem 6.) ")#mi("\\diamond")

#heading(level: 1)[#text("— Proof of multiple Birkhoff —")]

#text("We now use van der Waerden’s theorem and an additional Baire category argument to deduce Theorem 3 from Theorem 1. The key new ingredient is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(". (Semicontinuous functions are usually continuous) Let ")#mi("(X,d)")#text(" be a metric space, and let ")#mi("F: X \\to {\\Bbb R}")#text(" be ")#link("http://en.wikipedia.org/wiki/Semicontinuity")[#text("semicontinuous")]#text(". Then the set of points x where F is discontinuous is a set of the ")#link("http://en.wikipedia.org/wiki/First_category")[#text("first category")]#text(" (i.e. a countable union of ")#link("http://en.wikipedia.org/wiki/Nowhere_dense_set")[#text("nowhere dense sets")]#text("). In particular, by the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", if X is complete and non-empty, then F is continuous at at least one point.")
]

#strong[#text("Proof")]#text(". Without loss of generality we can take F to be upper semicontinuous. Suppose F is discontinuous at some point x. Then, by upper continuity, there exists a rational number q such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lim \\inf_{y \\to x} F(y) < q \\leq F(x).")]]

#text("In other words, x lies in the boundary of the closed set ")#mi("\\{ x : F(x) \\geq q \\}")#text(". But boundaries of closed sets are always nowhere dense, and the claim follows. ")#mi("\\Box")

#text("Now we prove Theorem 3. Without loss of generality we can take X to be minimal. Let us place a metric d on the space X. Define the function ")#mi("F: X \\to {\\Bbb R}^+")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("F(x) := \\inf_{n \\geq 1} \\sup_{1 \\leq i \\leq k-1} d( T^{i n} x, x ).")]]

#text("It will suffice to show that F(x)=0 for at least one x (notice that if the infimum is actually attained at zero for some n, then x is a periodic point and the claim is obvious). Suppose for contradiction that F is always positive. Observe that F is upper semicontinuous, and so by Lemma 3 there exists a point of continuity of F. In particular there exists a non-empty open set U such that F is bounded away from zero.")

#text("By uniform continuity of ")#mi("T^n")#text(", we see that if F is bounded away from zero on U, it is also bounded away from zero on ")#mi("T^n U")#text(" for any n (though the bound from below depends on n). Applying Lemma 1, we conclude that F is bounded away from zero on all of X, thus there exists ")#mi("\\varepsilon > 0")#text(" such that ")#mi("F(x) > \\varepsilon")#text(" for all ")#mi("x \\in X")#text(". But this contradicts Theorem 1 (or Theorem 4), using the balls of radius ")#mi("\\varepsilon/2")#text(" as the open cover. This contradiction completes the proof of Theorem 3.")

#strong[#text("Exercise 9")]#text(". Generalise Theorem 3 to the case in which T is merely assumed to be continuous, rather than be a homeomorphism. (Hint: let ")#mi("\\tilde X \\subset X^{\\Bbb Z}")#text(" denote the space of all sequences ")#mi("(x_n)_{n \\in {\\Bbb Z}}")#text(" with ")#mi("x_{n+1} = T x_n")#text(" for all n, with the topology induced from the product space ")#mi("X^{\\Bbb Z}")#text(". Use a limiting argument to show that ")#mi("\\tilde X")#text(" is non-empty. Then turn ")#mi("\\tilde X")#text(" into a topological dynamical system and apply Theorem 3.) ")#mi("\\diamond")

#strong[#text("Exercise 10")]#text(". Generalise Theorem 3 to multiple commuting shifts (analogously to how Theorem 6 generalises Theorem 1). ")#mi("\\diamond")

#strong[#text("Exercise 11")]#text(". Combine Exercises 9 and 10 by obtaining a generalisation of Theorem 3 to multiple non-invertible commuting shifts. ")#mi("\\diamond")

#strong[#text("Exercise 12")]#text(". Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a minimal topological dynamical system, and let ")#mi("k \\geq 1")#text(". Call a point x in X ")#emph[#text("k-fold recurrent")]#text(" if there exists a sequence ")#mi("n_j \\to \\infty")#text(" such that ")#mi("T^{in_j} x \\to x")#text(" for all ")#mi("0 \\leq i \\leq k-1")#text(". Show that the set of k-fold recurrent points in X is ")#link("http://en.wikipedia.org/wiki/Residual_%28mathematics%29")[#text("residual")]#text(" (i.e. the complement is of the first category). In particular, the set of k-fold recurrent points is dense. ")#mi("\\diamond")

#strong[#text("Exercise 13")]#text(". In the boolean Bernoulli system ")#mi("(2^{\\Bbb Z}, A \\mapsto A+1)")#text(", show that the set A consisting of all non-zero integers which are divisible by 2 an even number of times is almost periodic. Conclude that there exists a minimal topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" such that not every point in X is 3-fold recurrent (in the sense of the previous exercise). (Compare this with the arguments in the previous lecture, which imply that every point in X is 2-fold recurrent.) ")#mi("\\diamond")

#strong[#text("Exercise 14.")]#text(" Suppose that a sequence of continuous functions ")#mi("f_n: X \\to {\\Bbb R}")#text(" on a metric space converges pointwise everywhere to another function ")#mi("f: X \\to {\\Bbb R}")#text(". Show that f is continuous on a residual set. ")#mi("\\diamond")

#strong[#text("Exercise 15.")]#text(" Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a minimal topological dynamical system, and let ")#mi("f: X \\to {\\Bbb R}")#text(" be a function which is T-invariant, thus Tf = f. Show that if f is continuous at even one point ")#mi("x_0")#text(", then it has to be constant. (Hint: ")#mi("x_0")#text(" is in the orbit closure of every point in X.) ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Jan 15: bad link fixed.]")

#text("[")#emph[#text("Update")]#text(", Jan 21: Additional exercise added.]")

#text("[")#emph[#text("Update")]#text(", Jan 26: Another additional exercise added.]")

#text("[Update, Mar 4: Slight correction to proof of Proposition 1.]")

#heading(level: 1)[#text("Comments (34)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("The first link (to the previous lecture) is broken.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24492")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0106d1a51149435c0e7cc34d90e8026547a432e9bf1348c67b9eb9712116364-f26191209d651bb87abe0695a0206e6e25995780d590cc394681eab053fdce6f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of richard borcherds")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24499")[#strong[#text("richard borcherds")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2008")])]

#text("How easy is it to make these results about dynamical systems quantitative? For example, in theorem 4 can you give an explicit bound for r in terms of")#linebreak()#text(" k and and some invariants of the dynamical system and open sets? Presumably any such bounds would have to be rather large, given that its not easy to find reasonable bounds in van der Waerden’s theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ed Dean")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24519")[#strong[#text("Ed Dean")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Richard,")

#text("You might be interested in one of Philipp Gerhardy’s papers (click on my name for a link to the PDF), in which he applies proof-theoretic methods to topological dynamics. Girard extracted bounds for van der Waerden numbers from the Furstenberg/Weiss proof of Multiple Birkhoff which are identical to van der Waerden’s original bounds. Gerhardy proves an effective version of Multiple Birkhoff, again via an analysis of Furstenberg/Weiss, and again obtains the same bounds on vdW numbers.")

#text("But Gerhardy indicates that the reason behind this is that the topological proof and the combinatorial proof are really the same, just in different languages. He suggests the possibility of carrying out work to obtain a topological proof that, rather than mirroring van der Waerden’s original, corresponds to Shelah’s combinatorial proof, and which would enjoy the same improved bounds on van der Waerden numbers.")

#text("(I hope this information was useful, I’m new at all of this.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24542")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Dear Richard,")

#text("One can indeed make the argument quantitative, yielding the same Ackermann-type bounds as in the classical finitary proof of van der Waerden, as in the papers of Gerhardy and Girard mentioned by Ed above.")

#text("To answer your specific question, to get Theorem 4 for minimal systems with a designated metric d, the argument above gives quite concrete bounds in terms of (a) the uniform continuity modulus of the shift T, and (b) a quantitative bound for Lemma 1, in particular how many translates are needed for a ball of a given radius ")#mi("\\varepsilon")#text(" to cover all of the space. The only real difficulty is in _reducing_ to the minimal case, using the lemma from the previous lecture: the argument I gave there uses Zorn’s lemma and is thus not immediately finitisable. But one can develop substitutes for that lemma which do have quantitative (albeit Ackermann-type) bounds. It’s easiest to describe this in terms of the systems that are of immediate interest to van der Waerden’s theorem, namely orbit closures ")#mi("\\overline{T^{\\Bbb Z} c}")#text(" of a single word ")#mi("c \\in \\{1,\\ldots,k\\}^{\\Bbb Z}")#text(". In this setting, c generates a minimal system if and only if every block in c appears syndetically, thus for every L there exists F(L) such that every block of length L that appears at least once in c, will in fact appear in every F(L)-block of c. The key issue with respect to creating quantitative bounds is to obtain some good bound on F (this is the counterpart of (b) above in this setting). This is not possible if we insist on c being infinite, but we can get somewhere by truncating c to an extremely long but finite length (in particular, much larger than any given function of F(L)). Indeed, by using the finite convergence principle as discussed in my earlier post")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("Soft analysis, hard analysis, and the finite convergence principle")]
]

#text("one can obtain a quantitative version of Lemma 1 from the previous lecture: given any L and any function G, there exists an N such that in any word c of length N there exists an M and a subword of c of length G(M) such that every block of length L in that subword in fact appears in every block of length M in the subword.")

#text("(One should think of the parameters being arranged in the order L << M << G(M) << N. The quantity M is playing the role of F(L) here.)")

#text("Basically, N is going to equal an iterated power of G applied to L, where the number of iterations is equal to the number of possible blocks of length L (i.e. ")#mi("k^L")#text("). The intuition here is that if an L-block fails to appear syndetically, one can pass to a long subword in which that block fails to appear at all. Iterating this at most ")#mi("k^L")#text(" times, one eventually reaches a long subword in which all surviving L-blocks appear syndetically.")

#text("(Actually, one needs to apply the above lemma for k different values of L in order to get van der Waerden, because minimality is invoked k times in the proof of Theorem 4 once one unpacks the induction. This is what leads to the Ackermann-type behaviour in k. One has to take some care in arranging the quantifiers (i.e. deciding what parameters are large with respect to what other parameters); this is the price we pay for not using the axiom of infinity, which conveniently offers sets (namely, infinite sets) that are guaranteed to be larger than every finite set one could hope to generate by any conceivable future means, thus removing a lot of the need for epsilon management or quantifier management.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben green")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24549")[#strong[#text("ben green")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Terry,")

#text("It’s a nice observation that van der Waerden can be deduced without introducing a metric. In preparing my course I’ve been following Furstenberg’s book on this point, and he proceeds by proving Birkhoff Multiple Recurrence, only then pausing to derive combinatorial consequences. One only needs BMR in the case that ")#mi("T : X \\rightarrow X")#text(" is a homeomorphism, but then the proof of BMR seems to require that too. As you point out in your exercises one can deduce the result for continuous maps ")#mi("T")#text(" by a clever kind of lifting trick.")

#text("By the way Benji Weiss’s book “Single Orbit Dynamics” has a discussion of how to get minimality without using Zorn’s Lemma, as does “Ergodic Theory via Joinings”. Furstenberg’s book has a more erudite approach (there is a uniquely ergodic ")#mi("T")#text("-invariant measure on ")#mi("X")#text(") but this seems to be an unnecessarily large sledgehammer.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24575")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Dear Ben,")

#text("Thanks for the comments. I think (but haven’t fully checked) that one can also use Proposition 1 directly to imply Theorem 1, at least, for non-invertible T, simply by taking p to be a _positive_ minimal ultrafilter (thus ")#mi("\\lim_{n \\to p} \\text{sgn}(p) = +1")#text("). Then n+ir+p will be positive too, and we can get Theorem 1 without ever having to apply a negative power of T. The derivation of Theorem 3 from Theorem 1 seems to not require invertibility of T either.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24614")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2008")])]

#text("Prof. Green’s comment raises an issue about how “nonconstructive”")#linebreak()#text(" van der Waerden’s theorem really is. I’ve been once told that van der")#linebreak()#text(" Waerden’s theorem is actually equivalent to Baire’s theorem, but")#linebreak()#text(" I don’t recall who actually proved this. Does anyone know?")

#text("(still on the constructivity issue, Baire’s theorem turns out, on its turn,")#linebreak()#text(" to be equivalent to the Axiom of Dependent Choices, which is also")#linebreak()#text(" independent of the remaning axioms of Zermelo-Fraenkel set theory")#linebreak()#text(" and can be used as a “countable” substitute for the Axiom of Choice.")#linebreak()#text(" For instance, it’s equivalent to a countable version of Tychonoff’s")#linebreak()#text(" theorem)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24702")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2008")])]

#text("Sir")

#text("I am trying to map quantities used in Theorem 1 to those in Theorem 2. In my understanding —")#linebreak()#text(" 1. X ==> compactified version of Z.")#linebreak()#text(" 2. Since X is compact, we can have a finite subcover. We will take a finite subcover of compactified Z. The sets in the subcover will be same as the colour classes.")#linebreak()#text(" 3. k denotes the length of the arithmetic progression.")#linebreak()#text(" I think that r denotes the common difference between successive terms of the arithmetic progression but Theorem 2 has nothing to say anything on the common difference. To me it seems that Theorem 2 is weaker than Theorem 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24706")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2008")])]

#text("Dear Nilan,")

#text("One can rephrase Theorem 2 to resemble Theorem 1 more closely by replacing the phrase “contains arbitrarily long arithmetic progressions” by the equivalent phrase “contains infinitely many arithmetic progressions of length k for each k”. (Note that as a long arithmetic progression can always be chopped up into many shorter arithmetic progressions, the two statements imply each other.)")

#text("To deduce Theorem 2 from Theorem 1, one does not actually use the compactified integers (the colour classes do not cover the whole of ")#mi("\\beta {\\Bbb Z}")#text(" unless one takes the closure, in which case they are no longer open) but instead looks at a subsystem of the Bernoulli system ")#mi("\\{1,\\ldots,m\\}^{\\Bbb Z}")#text(", where m is the number of colours used. The equivalence between Theorem 1 and Theorem 2 here is in fact very analogous to the equivalence between Theorem 1 of the previous lecture and the infinite pigeonhole principle, as discussed in Exercise 1 of that lecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 5: Other topological recurrence results « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24779")[#strong[#text("254A, Lecture 5: Other topological recurrence results « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2008")])]

#text("[…] We first prove a significant generalisation of van der Waerden’s theorem (Theorem 2 from the previous lecture): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-24879")[#strong[#text("254A, Lecture 6: Isometric systems and isometric extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2008")])]

#text("[…] short proof of (a slight strengthening of) the multiple Birkhoff recurrence theorem (Theorem 3 from Lecture 4) as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-25930")[#strong[#text("254A, Lecture 10: The Furstenberg correspondence principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2008")])]

#text("[…] The Furstenberg correspondence principle can be extended to relate several other recurrence theorems to their combinatorial analogues. We give some representative examples here (without proofs). Firstly, there is a multidimensional version of Szemerédi’s theorem (compare with Exercise 7 from Lecture 4): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-26017")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("[…] dynamics, such as Proposition 3 from Lecture 6 or the Birkhoff multiple recurrence theorem from Lecture 4 (though to get the full strength of the results, one needs the syndetic van der Waerden theorem, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-26727")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2008")])]

#text("[…] this as a colouring of into colours. Applying van der Waerden’s theorem (Exercise 3 from Lecture 4), we can thus find (if K is sufficiently large depending on ) an arithmetic progression in for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-26893")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2008")])]

#text("Sir")

#text("In the proof of proposition 1, should not ")#mi("p^{\\prime}")#text(" be defined as ")#mi("p^{\\prime} := \\lim_{a \\to p_*} p_{0,a,a} = \\lim_{b \\to p_*} p_{0,b,b}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-26915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2008")])]

#text("Dear Nilay: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-34996")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2009")])]

#text("Dear Professor Tao:")

#text("Sorry I ask questions so radomly.")

#text("About exercise 9, I don’t see the reason to use a limiting argument to show ")#mi("\\tilde X")#text(" is non empty. Could I just take a x and then ")#mi("(T^nx)_{n\\in\\Bbb Z}")#text(" is in ")#mi("\\tilde X")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-35003")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2009")])]

#text("I think I figured it out: one can use the diagonal argument to find the limit point and then to prove it is also in ")#mi("\\tilde X")#text(", right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第四讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-40131")[#strong[#text("陶哲轩遍历论习题解答：第四讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于今年年初的一门课程，我尝试将所有习题做出来，这是第四讲的十五个习题。这里是本讲的链接。关于ultrafilter，我写过一个帖子。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-40741")[#strong[#text("陶哲轩遍历论习题解答：第五讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于08年年初的一门课程，我尝试将所有习题做出来，这是第五讲的二十一个习题。这里是这门课程的主页，这里是本讲的链接。有一些题目我花费的时间比较多，我将所需要的知识补充在另外的帖子中。关于ultrafilter, 我写过一个帖子.习题一中涉及到一点数论知识，尤其关于二次剩余的知识。我写过一个帖子是关于Hales-Jewett定理的归纳法证明.习题4的解答比较长，我另写了一个帖子。该过程是参考了上一讲中定理四的证明。注意这个证明方法与前述Hales-Jewett定理的归纳证明的异同。仍有几个问题没有完成，我会慢慢补上。) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-41703")[#strong[#text("Ergodic Ramsey Theory (by Yuri Lima) « Disquisitiones Mathematicae")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2009")]

#text("[…] 2. Multiple Poincaré’s Recurrence Theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-42905")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2009")])]

#text("Dear Prof. Tao,")

#text("I have some problems on exercises 10 and 14:")

#text("Ex 10. According to the hint, we can construct the ")#mi("\\tilde X \\subset X^{\\mathbb Z}")#text(". However, to apply Theorem 3, we have to first prove Theorem 4. In its proof, we need the restricted ")#mi("T")#text(" (in ")#mi("\\tilde X")#text(") to be invertible. This is not necessarily true for the restricted ")#mi("T")#text(". But we seems able to re-prove Theorem 4 by the same procedure as in the note, only modifying the definition of ")#mi("x_J=T^{-r_J} y")#text(" by taking $x_J$ as the element $r_J$ step in front of $y$ in the orbit. I was wondering if this would be okay.")

#text("Ex 14. I spent more than 6 hours on it, I am really silly. I checked the proof given by Xiaochuan Liu in the above link, it seems his proof is not right. I was wondering if you could give a hint on how to prove it.")

#text("Thanks a lot in advance!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e4a91bf17cf31d1b9e10937de949c974d1ee580335f37790f1bf40acf5a9870-11e57e907f67bef0256c7bf350cc7af193e88e6eb87f0540d6ac732a6f55ecab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salvatore Stuvard")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-47366")[#strong[#text("Salvatore Stuvard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’m sorry to bother you, but I’m working on a graduation thesis about topological dynamical systems, and I have some problems about Lemma 2 of this lecture. I will be grateful if you answer a couple of questions.")

#text("– First of all, you say about the existence of integers ")#mi("r_1,\\dots,r_J")#text(" such that ")#mi("T^{i(r_{a+1}+\\dots+r_b)}x_b \\in U_{\\alpha_a}")#text(" for all ")#mi("0 \\leq a \\leq b \\leq J")#text(" and ")#mi("1 \\leq i \\leq k-1")#text(", with ")#mi("J \\geq 0")#text(". Now, if ")#mi("J=0")#text(" should I expect the existence of two integers ")#mi("r_1,r_0")#text(" or of just one? And in the case ")#mi("a=b=J")#text(", how is it possible to consider ")#mi("r_{a+1}=r_{J+1}")#text(", which is undefined?")

#text("– After having proved it, you apply Lemma 2 to the proof of Theorem 4, to close the induction. But if I set ")#mi("x:=x_b")#text(" and ")#mi("r:=r_{a+1}+\\dots+r_b")#text(", by the Lemma I obtain that ")#mi("U_\\alpha:=U_{\\alpha_a}=U_{\\alpha_b}")#text(" contains ")#mi("T^{ir}x")#text(" for all ")#mi("1 \\leq i \\leq k-1")#text(", that is an arithmetic progression of lenght ")#mi("k-1")#text(" and not ")#mi("k")#text(" as I needed to complete the induction step. Where am I getting wrong?")

#text("Thanks a lot for your helpfulness, and good work.")

#text("Salvatore Stuvard")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-47367")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("When J=0 the sequence ")#mi("r_1,\\ldots,r_J")#text(" is empty, and the claim is trivial. If a=b, then ")#mi("r_{a+1}+\\ldots+r_b = \\sum_{a < i \\leq b} r_i")#text(" is an empty sum and is equal to zero.")

#text("When i=0, then ")#mi("T^{ir} x = x = x_b")#text(" is trivially contained in ")#mi("U_{\\alpha_b} = U_\\alpha")#text(", so the length k-1 progression with ")#mi("1 \\leq i \\leq k-1")#text(" can be automatically upgraded to a length k progression with ")#mi("0 \\leq i \\leq k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e4a91bf17cf31d1b9e10937de949c974d1ee580335f37790f1bf40acf5a9870-11e57e907f67bef0256c7bf350cc7af193e88e6eb87f0540d6ac732a6f55ecab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Salvatore Stuvard")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-47400")[#strong[#text("Salvatore Stuvard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2010")])]

#text("Thank you very much, it was a problem of notation. Now the theorem is very clear.")#linebreak()#text(" Thank you for the quickness of the answer also… and compliments for your work!")

#text("Salvatore Stuvard")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cuttheknot")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-212921")[#strong[#text("cuttheknot")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2013")])]

#text("Dear Professor, I think in the proof of Proposition 1 we should take ")#mi("p_*")#text(" such that ")#mi("{\\Bbb N} \\in p_*")#text(", as we need to be able to assume ")#mi("1\\le a\\le b")#text(" when they tend to ")#mi("p_*")

#emph[#text("[Corrected, thanks; -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-235191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Shouldn’t ")#mi("T^n U")#text(" in Lemma 1 read ")#mi("T^{-n}U")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-235192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("Sry, just now realised that ")#mi("T")#text(" is assumed invertible and ")#mi("n\\in\\mathbb{Z}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-255866")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] that Theorem 11 implies Theorem 10. (We will not prove either of these theorems here, but see e.g. this previous blog post for a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-503350")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2018")])]

#text("The links (to lectures 2 and 3) around Thm 5 don’t work, because the dates are 01/15 instead of the correct dates.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c620300871938edc7f2479f0b0ba17f6903f20059bdfee397e078d5f2e3fd338-45a5bbb177a9bc377bcb72337273c93904f6fd03f53e7444ff36d00194d60ff8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Khetan")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-508100")[#strong[#text("Abhishek Khetan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2018")])]

#text("Dear Professor Tao,")

#text("Thank you for the most interesting post. I have one question.")

#text("To prove Corollary 1 you define a map ")#mi("T:(\\mathbb R/\\mathbb Z)^2 \\to (\\mathbb R/\\mathbb Z)^2")#text(" as ")#mi("T(x, y) = (x+\\alpha, y+x)")#text(".")

#text("As you have shown, applying multiple Birkhoff recurrence to this map proves Corollary 1.")

#text("Can you please say something as to what motivated you to consider the map $T$?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-508112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2018")])]

#text("I am not sure where the connection between Diophantine approximation of polynomials and dynamics of skew shift systems such as this one first arise, but the connection is for instance made in Section 1.7 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=603625")[#text("Furstenberg’s 1981 book")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/#comment-688292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2025")])]

#text("Dear Professor Tao,")

#text("In the proof of Theorem 3 (Multiple Birkoff Recurrance Theorem), I think there is a typos. After the end of the proof of Lemma 3, in Line 12, I think it should be T^U instead of T^V.")

#text("Regards,")

#text("Nazrul")

#emph[#text("[Corrected, thanks – T.]")]
]
